import unittest


class Fixture(unittest.TestCase):
    def test_values(self):
        for value in range(45):
            with self.subTest(value=value): self.fail('individual subtest')
