import unittest


class Fixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls): raise RuntimeError('class broken')
    def test_one(self): pass
    def test_two(self): pass
