import unittest


def setUpModule(): raise unittest.SkipTest('module unavailable')
class Fixture(unittest.TestCase):
    def test_one(self): pass
    def test_two(self): pass
