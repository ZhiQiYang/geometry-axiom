import unittest


class Fixture(unittest.TestCase):
    def test_skip(self): self.skipTest('body skip')
    def tearDown(self): raise RuntimeError('teardown error')
