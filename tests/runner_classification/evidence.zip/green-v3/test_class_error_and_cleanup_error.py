import unittest


class Fixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(cls.broken_cleanup)
        raise RuntimeError('class setup broken')
    @classmethod
    def broken_cleanup(cls): raise RuntimeError('class cleanup broken')
    def test_one(self): pass
    def test_two(self): pass
