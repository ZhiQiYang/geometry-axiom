import unittest


class Fixture(unittest.TestCase):
    def test_one(self): pass
    def test_two(self): pass
raise unittest.SkipTest('import unavailable')
