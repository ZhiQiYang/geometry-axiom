import unittest


class Fixture(unittest.TestCase):
    def test_values(self):
        for value in range(205):
            with self.subTest(value=value): self.skipTest('individual subtest')
