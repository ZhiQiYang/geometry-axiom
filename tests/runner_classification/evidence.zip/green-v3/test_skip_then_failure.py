import unittest


class Fixture(unittest.TestCase):
    def test_values(self):
        with self.subTest(kind='skip'): self.skipTest('unsupported subcase')
        with self.subTest(kind='failure'): self.fail('broken')
