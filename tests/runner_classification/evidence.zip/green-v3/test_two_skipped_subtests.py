import unittest


class Fixture(unittest.TestCase):
    def test_values(self):
        for value in (1, 2):
            with self.subTest(value=value): self.skipTest('unsupported subcase')
