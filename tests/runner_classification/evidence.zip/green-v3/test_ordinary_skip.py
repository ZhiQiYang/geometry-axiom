import unittest


class Fixture(unittest.TestCase):
    def test_skip(self): self.skipTest('fixture skip')
