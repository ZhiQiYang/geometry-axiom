import unittest


class Fixture(unittest.TestCase):
    def test_ok(self): self.assertEqual(2 + 3, 5)
