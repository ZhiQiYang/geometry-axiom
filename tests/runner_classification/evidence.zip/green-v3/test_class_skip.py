import unittest


class Fixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls): raise unittest.SkipTest('class unavailable')
    def test_one(self): pass
    def test_two(self): pass
