import unittest


class Fixture(unittest.TestCase):
    def test_failure(self): self.fail('body failure')
    def tearDown(self): raise RuntimeError('teardown error')
