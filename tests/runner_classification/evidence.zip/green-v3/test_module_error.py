import unittest


def setUpModule(): raise RuntimeError('module broken')
class Fixture(unittest.TestCase):
    def test_one(self): pass
    def test_two(self): pass
