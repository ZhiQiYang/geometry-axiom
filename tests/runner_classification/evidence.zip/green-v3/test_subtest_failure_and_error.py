import unittest


class Fixture(unittest.TestCase):
    def test_values(self):
        with self.subTest(kind='failure'): self.fail('subtest assertion')
        with self.subTest(kind='error'): raise RuntimeError('subtest error')
