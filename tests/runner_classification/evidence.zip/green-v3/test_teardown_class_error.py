import unittest


class Fixture(unittest.TestCase):
    def test_one(self): pass
    def test_two(self): pass
    @classmethod
    def tearDownClass(cls): raise RuntimeError('class teardown broken')
