import unittest


class Fixture(unittest.TestCase):
    def broken_cleanup(self): raise RuntimeError('cleanup broken')
    @unittest.expectedFailure
    def test_known_bug(self):
        self.addCleanup(self.broken_cleanup)
        self.fail('known bug')
