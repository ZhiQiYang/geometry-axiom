import unittest


def tearDownModule(): raise RuntimeError('module teardown broken')
class Fixture(unittest.TestCase):
    def test_one(self): pass
    def test_two(self): pass
