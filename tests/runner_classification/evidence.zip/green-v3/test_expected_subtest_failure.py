import unittest


class Fixture(unittest.TestCase):
    @unittest.expectedFailure
    def test_known_bug(self):
        with self.subTest(value=1): self.fail('known bug')
