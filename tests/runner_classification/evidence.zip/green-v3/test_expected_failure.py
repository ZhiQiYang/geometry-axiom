import unittest


class Fixture(unittest.TestCase):
    @unittest.expectedFailure
    def test_known_bug(self): self.fail('known bug')
