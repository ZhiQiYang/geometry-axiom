import unittest


class Fixture(unittest.TestCase):
    calls = 0
    def test_repeated(self):
        type(self).calls += 1
        if self.calls == 1: self.fail('first occurrence')
def load_tests(loader, tests, pattern):
    test = Fixture('test_repeated')
    return unittest.TestSuite([test, test])
