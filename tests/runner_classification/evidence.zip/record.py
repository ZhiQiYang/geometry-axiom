import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
out = root / 'commands'
out.mkdir(exist_ok=True)
receipt = out / (label + '.json')
log = out / (label + '.log')
if receipt.exists() or log.exists():
    raise SystemExit('existing receipt: ' + label)
env = {key: value for key, value in os.environ.items() if not key.startswith('GEOMETRY_')}
env['PYTHONDONTWRITEBYTECODE'] = '1'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.perf_counter()
proc = subprocess.run(command, cwd=root / 'repo', env=env, capture_output=True, text=True)
elapsed = time.perf_counter() - clock
log.write_text(proc.stdout + proc.stderr, encoding='utf-8')
receipt.write_text(json.dumps(dict(command=command, cwd=str(root / 'repo'), started_utc=started,
                                  ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                  seconds=elapsed, exit=proc.returncode, log=str(log),
                                  environment=dict(GEOMETRY_variables='removed', PYTHONDONTWRITEBYTECODE='1')),
                              ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(proc.stdout + proc.stderr)
print(json.dumps(dict(command=command, exit=proc.returncode, seconds=elapsed, receipt=str(receipt))))
sys.exit(proc.returncode)
