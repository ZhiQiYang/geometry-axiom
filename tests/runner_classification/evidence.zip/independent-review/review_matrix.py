import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/issue118-report-review')
RUNNER = Path('/tmp/issue118-reporter-20261006/repo/tests/_unittest_runner.py')
# tuple = total, run, passed, failed, skipped, exit
EXPECT = {
    'TwoFail': (1, 1, 0, 1, 0, 1),
    'NestedFail': (1, 1, 0, 1, 0, 1),
    'TwoSkip': (1, 1, 0, 0, 1, 0),
    'Mixed': (1, 1, 0, 1, 0, 1),
    'MixedParentSkip': (1, 1, 0, 1, 0, 1),
    'BodyAndTeardown': (1, 1, 0, 1, 0, 1),
    'Expected': (1, 1, 0, 0, 1, 0),
    'Unexpected': (1, 1, 0, 1, 0, 1),
    'ExpectedAndCleanup': (1, 1, 0, 1, 0, 1),
    'ClassSkip': (2, 0, 0, 0, 2, 0),
    'ClassError': (2, 0, 0, 2, 0, 1),
    'ClassTeardown': (1, 1, 1, 1, 0, 1),
    'ModuleSkip': (2, 0, 0, 0, 2, 0),
    'ModuleError': (2, 0, 0, 2, 0, 1),
    'ModuleTeardown': (2, 2, 2, 1, 0, 1),
    'Reused': (2, 2, 1, 1, 0, 1),
    'ReusedSkip': (2, 2, 0, 1, 1, 1),
    'ClassSetupCleanup': (2, 0, 0, 2, 0, 1),
    'ClassSkipCleanup': (2, 0, 0, 2, 0, 1),
    'ModuleSetupCleanup': (2, 0, 0, 2, 0, 1),
    'ModuleSkipCleanup': (2, 0, 0, 2, 0, 1),
    'ClassTeardownMany': (2, 2, 2, 2, 0, 1),
    'ManyFailures': (1, 1, 0, 1, 0, 1),
    'ManySkips': (1, 1, 0, 0, 1, 0),
}
failed = 0
for name, expected in EXPECT.items():
    env = {k: v for k, v in os.environ.items() if not k.startswith('GEOMETRY_')}
    env['REVIEW_CASE'] = name
    path = ROOT / (name + '.json')
    child = subprocess.run([sys.executable, str(RUNNER), str(ROOT / 'independent_fixture.py'),
                            '--json-out', str(path)], env=env, capture_output=True, text=True)
    report = json.loads(path.read_text())
    actual = tuple(report[k] for k in ('total', 'run', 'passed', 'failed', 'skipped')) + (child.returncode,)
    ok = expected == actual
    if report['total'] != report['passed'] + report['failed'] - report.get('extra_errors', 0) + report['skipped']:
        ok = False
    if name in ('TwoFail', 'NestedFail', 'BodyAndTeardown') and len(report['failures']) != 2:
        ok = False
    if name == 'TwoSkip' and (len(report['skip_items']) != 2 or sum(i['count'] for i in report['skip_items']) != 1):
        ok = False
    if name in ('Mixed', 'MixedParentSkip') and any(i['count'] for i in report['skip_items']):
        ok = False
    if name == 'ManyFailures' and len(report['failures']) != 41:
        ok = False
    if name == 'ManySkips' and len(report['skip_items']) != 201:
        ok = False
    if not ok:
        failed += 1
    print(json.dumps({'case': name, 'ok': ok, 'actual': actual, 'expected': expected,
                      'failure_rows': len(report['failures']), 'skip_counts': [i['count'] for i in report['skip_items']]}))
print('independent cases:', len(EXPECT), 'failures:', failed)
sys.exit(bool(failed))
