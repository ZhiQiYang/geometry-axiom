import os
import unittest


class TwoFail(unittest.TestCase):
    def test_one(self):
        for i in range(2):
            with self.subTest(i=i):
                self.fail('bad subtest')


class NestedFail(unittest.TestCase):
    def test_one(self):
        with self.subTest(outer=1):
            for inner in (1, 2):
                with self.subTest(inner=inner):
                    self.fail('nested failing subtest')


class TwoSkip(unittest.TestCase):
    def test_one(self):
        for i in range(2):
            with self.subTest(i=i):
                self.skipTest('two skipped subtests')


class Mixed(unittest.TestCase):
    def test_one(self):
        with self.subTest(i=0):
            self.skipTest('skip before failure')
        with self.subTest(i=1):
            self.fail('failure after skip')


class MixedParentSkip(unittest.TestCase):
    def test_one(self):
        with self.subTest(i=0):
            self.fail('failure before parent skip')
        self.skipTest('parent skipped after failure')


class BodyAndTeardown(unittest.TestCase):
    def test_one(self):
        self.fail('body failure')

    def tearDown(self):
        raise ValueError('teardown error')


class Expected(unittest.TestCase):
    @unittest.expectedFailure
    def test_one(self):
        self.fail('known failure')


class Unexpected(unittest.TestCase):
    @unittest.expectedFailure
    def test_one(self):
        pass


class ExpectedAndCleanup(unittest.TestCase):
    @unittest.expectedFailure
    def test_one(self):
        self.addCleanup(lambda: (_ for _ in ()).throw(ValueError('cleanup error')))
        self.fail('known failure')


class ClassSkip(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raise unittest.SkipTest('class skipped')

    def test_one(self):
        pass

    def test_two(self):
        pass


class ClassError(ClassSkip):
    @classmethod
    def setUpClass(cls):
        raise ValueError('class setup error')


class ClassTeardown(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        raise ValueError('class teardown error')

    def test_one(self):
        pass


class ClassSetupCleanup(Plain if 'Plain' in globals() else ClassSkip):
    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(lambda: (_ for _ in ()).throw(ValueError('setup cleanup error')))
        raise ValueError('setup class error')


class ClassSkipCleanup(ClassSetupCleanup):
    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(lambda: (_ for _ in ()).throw(ValueError('setup cleanup error')))
        raise unittest.SkipTest('setup class skipped')


class ClassTeardownMany(ClassSkip):
    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(lambda: (_ for _ in ()).throw(ValueError('teardown cleanup error')))

    @classmethod
    def tearDownClass(cls):
        raise ValueError('class teardown error')


class ManyFailures(unittest.TestCase):
    def test_one(self):
        for i in range(41):
            with self.subTest(i=i):
                self.fail('retain every failure')


class ManySkips(unittest.TestCase):
    def test_one(self):
        for i in range(201):
            with self.subTest(i=i):
                self.skipTest('retain every skip')


class Plain(unittest.TestCase):
    def test_one(self):
        pass

    def test_two(self):
        pass


class Reused(unittest.TestCase):
    n = 0

    def test_one(self):
        self.n += 1
        if self.n == 1:
            for i in (1, 2):
                with self.subTest(i=i):
                    self.fail('only first occurrence fails')


class ReusedSkip(unittest.TestCase):
    n = 0

    def test_one(self):
        self.n += 1
        if self.n == 1:
            self.skipTest('only first occurrence skips')
        self.fail('second occurrence fails')


def setUpModule():
    mode = os.environ['REVIEW_CASE']
    if mode in ('ModuleSetupCleanup', 'ModuleSkipCleanup'):
        unittest.addModuleCleanup(lambda: (_ for _ in ()).throw(ValueError('module setup cleanup error')))
        if mode == 'ModuleSkipCleanup':
            raise unittest.SkipTest('module setup skipped')
        raise ValueError('module setup error')
    if mode == 'ModuleSkip':
        raise unittest.SkipTest('module skipped')
    if mode == 'ModuleError':
        raise ValueError('module setup error')


def tearDownModule():
    if os.environ['REVIEW_CASE'] == 'ModuleTeardown':
        raise ValueError('module teardown error')


def load_tests(loader, tests, pattern):
    mode = os.environ['REVIEW_CASE']
    cls = Plain if mode.startswith('Module') else globals()[mode]
    if mode.startswith('Reused'):
        one = cls('test_one')
        return unittest.TestSuite([one, one])
    return loader.loadTestsFromTestCase(cls)
