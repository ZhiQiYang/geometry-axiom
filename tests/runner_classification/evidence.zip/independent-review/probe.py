import io
import json
import unittest


class Events(unittest.TextTestResult):
    def __init__(self, *args):
        super().__init__(*args)
        self.events = []

    def record(self, kind, test):
        parent = getattr(test, 'test_case', test)
        self.events.append([kind, type(test).__name__, test.id(), parent.id()])

    def startTest(self, test):
        self.record('start', test)
        super().startTest(test)

    def addSuccess(self, test):
        self.record('success', test)
        super().addSuccess(test)

    def addFailure(self, test, err):
        self.record('failure', test)
        super().addFailure(test, err)

    def addError(self, test, err):
        self.record('error', test)
        super().addError(test, err)

    def addSkip(self, test, reason):
        self.record('skip', test)
        super().addSkip(test, reason)

    def addExpectedFailure(self, test, err):
        self.record('expected-failure', test)
        super().addExpectedFailure(test, err)

    def addUnexpectedSuccess(self, test):
        self.record('unexpected-success', test)
        super().addUnexpectedSuccess(test)

    def addSubTest(self, test, subtest, err):
        self.record('sub-success' if err is None else 'sub-failure', subtest)
        super().addSubTest(test, subtest, err)


class Parent(unittest.TestCase):
    def test_two_failures(self):
        for i in range(2):
            with self.subTest(i=i):
                self.fail('failing subtest')

    def test_skip_then_failure(self):
        with self.subTest(i=0):
            self.skipTest('skip one subtest')
        with self.subTest(i=1):
            self.fail('failure takes precedence')

    def test_failure_then_parent_skip(self):
        with self.subTest(i=0):
            self.fail('subtest failure')
        self.skipTest('skip parent after failure')

    def test_two_skips(self):
        for i in range(2):
            with self.subTest(i=i):
                self.skipTest('skip subtest')

    @unittest.expectedFailure
    def test_expected_failure(self):
        self.fail('expected failure')

    @unittest.expectedFailure
    def test_expected_with_sub_skip(self):
        with self.subTest(i=0):
            self.skipTest('subtest skipped')
        with self.subTest(i=1):
            self.fail('expected failure body')

    @unittest.expectedFailure
    def test_expected_with_teardown_error(self):
        self.addCleanup(lambda: (_ for _ in ()).throw(ValueError('cleanup error')))
        self.fail('expected body failure')

    def test_failure_and_teardown_error(self):
        self.addCleanup(lambda: (_ for _ in ()).throw(ValueError('cleanup error')))
        self.fail('body failure')


class Blocked(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(lambda: (_ for _ in ()).throw(ValueError('setup cleanup error')))
        raise ValueError('setup class error')

    def test_one(self):
        pass

    def test_two(self):
        pass


class Teardown(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        raise ValueError('teardown error')

    def test_one(self):
        pass


def run(name, suite):
    result = unittest.TextTestRunner(stream=io.StringIO(), resultclass=Events).run(suite)
    print(json.dumps({'name': name, 'run': result.testsRun, 'successful': result.wasSuccessful(),
                      'failures': len(result.failures), 'errors': len(result.errors),
                      'skips': len(result.skipped), 'expected': len(result.expectedFailures),
                      'events': result.events}))


for method in unittest.defaultTestLoader.getTestCaseNames(Parent):
    run(method, unittest.TestSuite([Parent(method)]))
run('class setup + cleanup errors', unittest.defaultTestLoader.loadTestsFromTestCase(Blocked))
run('class teardown error', unittest.defaultTestLoader.loadTestsFromTestCase(Teardown))
reused = Parent('test_two_skips')
run('same instance twice', unittest.TestSuite([reused, reused]))
