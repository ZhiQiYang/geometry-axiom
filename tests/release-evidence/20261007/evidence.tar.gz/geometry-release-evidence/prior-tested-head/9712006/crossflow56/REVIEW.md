# Final 9712006 user-flow review

Result: PASS within the verified scope. The complete 56-assertion crossflow passed on 1382 × 900 and 390 × 900 Chromium viewports, with no failed checks, page errors, console errors, or warnings. Visual review of the PDF/guide, created-source dialog, moved-source dialog, and narrow accepted-Check screenshots found no blocking issue in these flows. This review does not promote the older cf6 or a49 results to the new candidate.

## Identity and terminal evidence

- Candidate: `9712006e960f904d1357de4881dbac3742bfcda2`; `/workspace/geometry-axiom-release` clean before and after.
- Runtime: `31e7b1af0e3c1bcb12c10ccf03d93c498e71d1c70f1416861759c1b12254aeff`; fresh before/after; identical root, PID, session, and tracked product/test hashes.
- Run: 2026-10-07 12:25:37–12:26:03 UTC; 56/56, exit 0; `terminal-receipt.json` and `gate.log`.
- PID 301591 / port 8955 were owned by this run. Final native World saved before stopping the service; port closure independently confirmed in `post-review.json`.
- Installed Playwright and `/usr/bin/chromium` were used because the Browser plugin was unavailable. No repository source or HEAD was changed.

## Actual browser coverage

The story opens a production-packed project through the real file chooser, imports an actual eight-page PDF, closes/reopens its page picker, returns to the same face, and creates a guide using the authored named reference `spec:crossGuide`. The guide is moved to `spec:crossMove`. At each stage the existing inspector immediately lists the native guide and correct position (1500 mm, then 1700 mm); the source dialog displays the exact expression. Closing the source dialog leaves native World and history unchanged. Trusted Undo/Redo restores the exact prior and subsequent World, and each create/move gesture dispatches exactly one mutation.

For both `snap` and `newid`, a real native JSON reply is held without changing its content while the user clicks Back and re-enters the same face. Releasing the old reply dispatches no guide mutation and preserves exact World/history, PDF source identity, and raw attachments. This is controlled reply timing, not a fabricated successful response.

The parameter portion opens the actual new-parameter editor, enters an authored name and invalid raw expression `=1/0`, and activates an existing grid card's Check action with real focus and trusted Enter. Cancelling the browser confirmation preserves raw text, native World, history, selection, and drawer state. Accepting selects the finite grid without native mutation; the narrow inspector opens. There are six real browser confirmation dialogs across the two viewports. Both viewports have no document-wide horizontal overflow.

The loaded named parameters used by the guides come from the authored project fixture. This 56-case story does not create/update a valid parameter through native Confirm and does not inject EngineeringAdapter refresh failures. The separate queue/storage browser gates own that normal parameter-confirm/re-edit pipeline; their receipts must be considered before making a whole-release claim.

## Unit failure and new-raw preservation coverage

The persistent 16-case test contains the original nine cases plus seven additions. It executes the real ParameterUI and EngineeringAdapter closures with finite host fixtures for native responses, controls, and held/failing refreshes. Successful receipt identity is retained through postcommit adapter failures; committed state retires without allowing duplicate submission; rejected native commands preserve raw input; replacement context/new raw state survives old late failures without control or notification changes. It also checks false/undefined final render results, navigation-only retirement, and same-card selection rejection while busy. These cases verify failure contracts, not physical browser interactions.

Root's final green log reports 16/16 and exit 0. This reviewer verified that both product files and the persistent test in candidate 9712006 are byte-identical to that green execution. The same final tests against the prior cf6 product sources produce 6 pass / 10 fail and exit 1; the specific busy same-card old-code negative also remains preserved. No assertions, floors, or timeouts were weakened. `test-snapshot/unit-red-green-receipt.json` and `test-snapshot/unit-source-equivalence.json` record the distinction and hashes.

## Preserved bundle inputs

- `browser/results.json`: all checks, native World/history/raw snapshots, intercepted request/reply evidence, dialogs, and empty console/page-error list.
- `browser/placed.gcanvas`, `browser/rooms.pdf`: exact input files.
- `final-world.scene`, `runtime-before.json`, `runtime-after.json`, `runtime-final.json`, `source-before.json`, `source-after.json`.
- All eight unmodified PNGs in `browser/`; the representative four reviewed visually are listed below.
- `test-snapshot/`: exact 56-case browser script, runner, persistent 16-case unit test, related product source bytes, receipts, and SHA256 manifest.

Representative screenshots:

1. `browser/1382-pdf-guide.png`: PDF, actual guide and current inspector list.
2. `browser/1382-fresh-guide-created-source.png`: `spec:crossGuide`, 1500 mm.
3. `browser/390-move-existing-guide-moved-source.png`: `spec:crossMove`, 1700 mm; dialog/buttons fit narrow viewport.
4. `browser/390-accepted-check.png`: accepted Check opens existing narrow grid inspector.

Limits: Linux viewport emulation does not establish physical phone behavior, real IME handling, Windows graphics, or native operating-system Save-dialog behavior. The source-dialog review does not submit a new expression through its Apply button. Existing receipt timing injections are explicitly separated from normal input flows. No remaining blocker was observed in this owned scope; the separate release gates remain independent evidence.
