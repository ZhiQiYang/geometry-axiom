# P73 parameter confirmation / face navigation race

Source: clean `a49d2a5470abf6e9db4e14573535476d05647c21`, `/workspace/geometry-axiom-release`.
Runtime: `2dd5d975ce57e2d4cd8728915a4dd31a25bda7c998cedc84a61344dda0d290c9`.
The before/after source, runtime and five native helper receipts are in `uiux/`.

The unmodified P73 scope passed 65/65 in a separate fresh service/profile at
`../p73-a49-original/uiux`. That isolated pass does not erase the full-suite
failure or establish that the ordering is safe.

This diagnostic retained the P73 assertions and control hit checks. A TEMP
preload delayed delivery of successful, real native replies from the final
`parameters.js:583` confirmation refresh and `enterFocus`'s boundary read.
The transition back to the face was strengthened from the test's programmatic
`enterFocus` call to trusted clicks: dismiss the initial parameter lesson, fit
the real canvas, and click the actual boundary card's `進入` action.

Observed ordering (recorded in `P73_CAUSAL_STATE` in the raw log):

1. The final confirmation refresh requests `objects`; `ParameterUI.pending` is
   already false because `confirm` set `state = null` before awaiting refresh.
2. The actual card click starts `enterFocus`; it pins navigation sequence 9,
   sets face focus, and awaits the successful native `boundary 1` response.
3. Confirmation refresh completes and `selectObject('parameter', 1)` increments
   the navigation sequence from 9 to 10 while the face read is pending.
4. The face read returns. Its navigation guard rejects completion, leaving
   `oc.focus = {t:'face',id:1}`, `oc.edit = null`, and the object workspace hidden.
5. The unchanged P73 components-tab reachability check fails with a zero-sized
   rectangle, matching the original full CDP failure.

This is a product race reachable through a normal visible card action. Native
results were not replaced or fabricated. The diagnostic exits 1 with 31 prior
assertions passed, no assertion bypass, and the original fatal condition.

Artifacts: `uiux/gate.log`, `uiux/terminal.json`, `diagnostic-preload.cjs`,
`screens/p73-causal-after-card-enter.png`, and `screens/fatal-state.png`.
Preload SHA-256: `f46655423228fb42fec8e014454dd2013ea4077be13fc86e41ad1f65506c427e`.

Earlier diagnostic attempts remain preserved: attempt 1 failed on TEMP regex
escaping before installing the gate; attempt 2 correctly refused a real card
click obscured by the first-use lesson. Neither is counted as the product red.

All owned browser and service processes closed. No checkout source was changed.
