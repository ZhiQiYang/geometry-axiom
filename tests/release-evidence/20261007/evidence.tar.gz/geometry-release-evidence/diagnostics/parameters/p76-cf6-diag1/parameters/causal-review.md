# P76 confirmation same-card navigation: product defect

Base: clean `cf6f6010c8f4ca6ee765c113694f6710a98f290b`, runtime `9c91d25faf58cadc20bb80e90457fa813a5591fbf7516610bede0f671e2e3511`.

The unchanged formal parameters scope first failed at `確認 success 恢復後可明確試算並提交99` in `final-cf6f601-first/parameters`. This diagnostic repeated the same formal flow and assertions with TEMP logging hooks only. The hooks delegate the real selection and fetch functions, record snapshots, and do not change outcomes or inject delays. It reproduced 65 passes / 1 failure, exit 1. Both source and runtime remained identical before/after; all five native helpers were fresh. The owned service and browser were stopped after preserving the world.

## Causal sequence in gate.log

1. Line 78: the actual `engineering-confirm 37` commits native revision 38 → 39. Parameter input is 27; navigation sequence is 76; pending is true and the editor is locked. The original test holds the real native response after success.
2. Line 82: the original trusted fill attempt on a disabled input sends Ctrl+A. Because the disabled input cannot retain focus, canvas selection handling at `app.js:9095` invokes `ocSetSelection([{kind:'parameter',id:1}])`. The call returns true, increasing navigation 76 → 77 despite pending/locked remaining true.
3. Line 85: the original trusted fill attempt on the late disabled legacy input repeats the same path, increasing navigation 77 → 78.
4. Lines 86–87: releasing the real confirmation allows the adapter's real `objects`/`surfaces` reads to complete successfully. The parameter confirm's navigation owner check now fails. Its successful-commit cleanup retires state and unlocks the old editor without installing a fresh owner/listeners.
5. Lines 87–101: pending is false, controls are enabled, but status remains `正在套用…`. True typing changes DOM raw to 99. Clicking preview/confirm sends no new confirmation. Native revision remains 39, field value 27. The original assertion fails. The TEMP fetch hook records `/api` commands; it does not instrument the separate `/engineering/preview` route. The old editor's `current(s)` guard explains why its preview handler cannot operate, but lack of a preview request is an inference from this code path rather than a directly logged route count.

`diagnostic-events.json` retains exact request/response stacks and values. `diagnostic-metadata.json` pins the TEMP hook hash. `screens/fatal-state.png` preserves the visible failure.

## Classification and bounded fix

This is a user-reachable product defect, not a stale fixture or false oracle. The disabled-input edit attempts correctly leave raw 27 untouched while waiting, but their trusted keyboard input reaches the global shortcut. `DraftGate` currently grants the same-parameter selection exception before considering the busy state. Rejecting any selection while `state.busy` before that exception keeps the confirmation's navigation owner intact. The successful confirmation may still retire its state and select/render the committed card after settlement, and normal same-card selection outside a busy confirmation remains allowed.

The product patch passed the original full P76 scope, without diagnostic hooks, at `/tmp/geometry-rc-queue-review/p76-patched-formal1/parameters`: 86 passes, zero failures/skips/uncaught exceptions, completed true, exit 0. Runtime `31e7b1af0e3c1bcb12c10ccf03d93c498e71d1c70f1416861759c1b12254aeff`; before/after source and runtime stable, five native helpers fresh, owned service/browser stopped. This is a diagnostic pass on the explicitly dirty patch tree; acceptance must still be rerun on the new clean freeze. No original failure or oracle has been overwritten.
