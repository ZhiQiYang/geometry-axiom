# P14 independent diagnosis and real-entry correction

Conclusion: approve the P14 fixture synchronization after its direct `api('line spec …')`. Keep the production `referenceGuidePreparation` ownership/native-revision guard. No product change is justified by the recorded P14 failure. This is an independent review and a bounded entry-reachability diagnostic, not a new full P14 or release acceptance run.

## Evidence chain

Reviewed queue's exact-f667 held-response records:

- Red: `/tmp/geometry-rc-queue-review/p14-f667-held-red1/uiux/` — 15 original checks pass, one fails, exit 1. The spec command succeeds with `{ok:true}` and no native revision. Project revision/history update, while observed native revision stays 13. A trusted v-button click receives the real successful snap expression `spec:點放定位`. Its response is held. A real recovery dump reports native revision 14; project revision remains 5 and focus/context/viewport stay unchanged. Releasing snap causes the guard to reject; no newid/guide command follows.
- Controlled fixture-sync comparison: `/tmp/geometry-rc-queue-review/p14-f667-held-green1/uiux/` — the direct spec fixture additionally awaits `api('dump')` before the gesture. Snap is admitted with revision 14. The same held reply/recovery dump remains revision 14, then exactly one newid and one guide mutation execute. Original 16 checks pass, exit 0.
- Actual public spec flow: `/tmp/geometry-rc-queue-review/p14-f667-ui-green1/uiux/` — trusted File → shared datum manager → spec form submit → wait for existing busy completion → Close, followed by the same held snap/recovery scenario. The formal save/refresh reads revision 14 before the guide gesture. Original 16 checks pass, exit 0.

The direct fixture does not bypass `ReferenceWorkspace.observe`: `apiRequest` calls observe, which updates dirty state/history. Its bare native success reply simply lacks a revision. The fixture omits the normal post-save refresh that calls `feAfterChange → feLoadGuides → dump/source-inspect`. A read-only dump fence restores that preparation precondition without adding sleep, changing the native World, or weakening the guide oracle.

`observeNativeRevision` is session-scoped and monotone. `referenceGuidePreparation` pins the complete evidence state and exact face/edit identities; retaining this conservative guard prevents stale replies from applying after a genuine mutation, history change, or context replacement. Removing nativeRevision or renewing a captured guard after an unrelated reply is not a sound repair.

## Withdrawn user-visible counterpart hypothesis

Initial source review found an unlocked `#refSpecSave` binding in app.js and hypothesized a fast visible Save → guide overlap. That was premature: repository search finds only that binding and no production markup creating `#refSpecSave`, `#refSpecName`, or `#refSpecValue`.

The independent real browser diagnostic on clean `f6672d865eb529cd37a6486b63a78b8a82386632` explicitly checked reachability before attempting the race. It used trusted clicks on all four face-inspector tabs (prop, shape, components, underlay), the guide tool, and available details. All six observed states contain zero instances of all three controls. The actual File → shared datum manager form exists and was opened/closed by trusted clicks; its existing busy guard is the path exercised by queue's normal-flow comparison. The native World was identical before/after these observations; no page errors occurred.

Therefore the proposed `#refSpecSave` user race is withdrawn. It cannot be empirically invoked without inventing DOM or calling a dormant handler, neither of which would establish a user-visible defect. No held-response race was run through this nonexistent control. This conclusion is limited to that suspected entry; it does not claim that arbitrary overlapping gestures have all been tested.

## Independent diagnostic artifacts

Directory: `/tmp/geometry-refspec-overlap-review/reachability-f667/uiux/`

- `terminal.json`: exit 0, source/runtime stable, owned service verified before stop.
- `evidence/result.json`: six DOM observations, trusted events, formal modal entry, exact native World before/after, empty errors.
- `gate.log`, `source-before.json`, `source-after.json`, `runtime-before.json`, `runtime-after.json`, final native dump.
- `diagnostic-source.cjs`: exact executed harness; SHA256 `8c4484eb729d7c6503d94e4510856cc8401ef4f3f3fe4e33ef91ebdc638ee997`.
- Seven original screenshots remain in `evidence/`; no screenshot is required to substantiate a P14 acceptance count.

Run: 2026-10-07 13:53:01–13:53:04 UTC; root `/workspace/geometry-axiom-grid-raw`; runtime `36f76f6a49873cef9f987d1cbfdd4ead97c0f720a4849d39234440a5e55cb676`. All five native helpers were fresh. Owned service PID 408366 stopped after native dump preservation. Ports 8946 and 9466 were independently confirmed closed. No repository files were changed.
