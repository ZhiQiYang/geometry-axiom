# P14 reference guide: asynchronous native revision observation

All four diagnostic runs used clean `f6672d865eb529cd37a6486b63a78b8a82386632` at `/workspace/geometry-axiom-release`, runtime `36f76f6a49873cef9f987d1cbfdd4ead97c0f720a4849d39234440a5e55cb676`. The original full6 failure stays at `/tmp/geometry-release/cdp-round6/gate/command.log` (2174 passing assertions, one P14 failure plus its floor mismatch). Its later expected `fb-auto-probe` exception is separate, as verified by root.

## Method and evidence

TEMP `p14-extract-repro.cjs` extracts the exact original P14 section and the existing CDP driver initialization/termination. All original 16 assertions, the dump regex and all original sleeps remain unchanged. Added observation captures trusted pointer/click events with hit targets, API commands plus native JSON responses, complete dump, editor/focus/history/evidence state, viewport/SVG bounds, pan/zoom and picker coordinates. The normal guide-tool `.click()` remains the original programmatic fixture; canvas and v-direction clicks use the original trusted CDP input.

Each directory below contains terminal/source/runtime before/after JSON, copied diagnostic source and hash, `gate.log`, `evidence/extracted-cdp-diagnostic.js`, `evidence/p14-evidence.json`, `evidence/p14-after-direction.png` and the final native dump. No original red artifact was overwritten.

| Attempt | Controlled condition | Result |
| --- | --- | --- |
| `/tmp/geometry-rc-queue-review/p14-f667-baseline1/uiux` | Original fixture and timing, observations only | 16/16; exit 0 |
| `/tmp/geometry-rc-queue-review/p14-f667-held-red1/uiux` | Hold the real successful snap JSON; call real `ReferenceWorkspace.persistSession()` before releasing | 15/16; original `選 v 後建線` fails; exit 1 |
| `/tmp/geometry-rc-queue-review/p14-f667-held-green1/uiux` | Same held snap and persist schedule; only add observed `await api('dump')` after raw spec fixture | 16/16; exit 0 |
| `/tmp/geometry-rc-queue-review/p14-f667-ui-green1/uiux` | Replace raw spec fixture with trusted File → Common datums → fill/save spec → Close; same held snap and persist schedule | 16/16; exit 0 |

Every run completed with zero skipped assertions and zero uncaught browser exceptions. Source/runtime stayed identical within each run and five native helpers were fresh. Owned 8941/9461 service/browser were closed after each run.

## Causal trace

The original raw fixture `api('line spec 點放定位 2000')` returns `{ok:true}` without a revision field. Browser context revision correctly changes 4→5 but its last observed native revision stays 13, even though the core now has revision 14. Both clicked viewport coordinates remain `(670,492)`, viewport bounds `(260,116,820,752)`, and picker stores u=2000/v=1650. The trusted v click correctly hits the v button; native snap `snap 1 v 0 2000 65` really returns `{ok:true,expression:'spec:點放定位'}`.

`referenceGuidePreparation()` pins the complete evidence stamp before that asynchronous snap. Holding the real response makes the read interleaving explicit. `persistSession()` calls the ordinary dump path, observes revision 14, and returns without changing context revision 5, focus, history owner, viewport, or blocked state. Releasing the successful snap then makes `current()` false. The guarded operation emits **zero newid and zero guide commands**; the world contains the spec and no guide. This produces exactly the original P14 failing assertion without stale coordinates, fabricated native answers or additional sleep.

With the fixture's observed dump added first, the stamp already contains revision 14 before the gesture. The same persist operation observes 14 again, the guard remains valid, and native newid/guide produce `guide 1 1 v spec:點放定位`. The final dump advances to native revision 15. The held-red and held-green runner source hashes are identical (`5480be9e307ea2b5a0aa38f24f5ad5cf9a172397fbd64d8cb7a31af8e343e293`); mode environment and extracted exact diagnostic source record the single setup difference.

The normal visible spec manager already awaits `refreshActive()` and `feAfterChange()` before unlocking Close. Its trusted save/close has observed native revision 14 before the canvas gesture. It succeeds under the same controlled held-snap/persist interleaving, without the added fixture dump. Thus the evidence supports synchronizing the direct native fixture before beginning the user gesture, while preserving the product's conservative guard against changed evidence.

## Limits

The original full6 did not collect this fine-grained trace, so these artifacts are a controlled causal reproduction of its exact failed assertion, not a recovered complete timeline of that earlier execution. The stable-layout evidence rules out a coordinate mismatch in these reproductions; it does not prove all possible viewport transitions. The normal UI comparison covers this spec-manager path, not every native-editing tool. No product semantics, guard, assertion floor, or timing was changed.

## Reviewed fixture-only commit and rerun

Independent reviewer `/root/ui_fix_review` agreed that a late observation of the already-created spec is not another native mutation, and approved synchronizing this direct fixture while retaining the product guard. The reviewer separately identified an unverified overlapping gesture through the non-modal face `#refSpecSave` path; that branch is being investigated independently and is not covered by the modal green above.

Committed `66a4c89d985e5e7a34f602ff1d085c7a9943c883` in `/workspace/geometry-axiom-p14-fixture` changes only `geometry-web/cdp_test.js`: two comment lines plus `await eval_(api('dump'))` immediately after the raw spec seed. `api` already observes its results; the precise reason for the extra read is that the successful spec acknowledgement lacks a native revision. All 16 original assertions, waits and production guard stay unchanged; golden remains unchanged. Node syntax and diff checks passed.

The committed exact P14 section, with the same held real snap → real persistSession → release schedule and no extra TEMP fixture synchronization, passed **16/16**, completed true, exit 0, no skipped assertion or browser exception. Evidence: `/tmp/geometry-rc-queue-review/p14-66a4c89-committed1/uiux`. Five helpers were fresh, source/runtime before/after identical, and owned 8941/9461 closed.

The new runtime fingerprint is `503bdfe8b4762ed26720f6b81eb4b7a667bdef94cf41adfc3ef427080098c480`, because runtime_version includes tests: of 403 runtime files, only `geometry-web/cdp_test.js` differs from f667. Product files and native source files are unchanged; the overall fingerprint is not claimed identical. All five diagnostic receipt/result/script hashes are indexed in `/tmp/geometry-rc-queue-review/p14-causal-index.json`.

## Independent counterpart hypothesis resolved (2026-10-07 13:54 UTC)

`/root/ui_fix_review` independently checked the proposed non-modal `#refSpecSave` entry in a real f667 browser. Across all face tabs plus the guide tool (six recorded states), `#refSpecSave`, `#refSpecName` and `#refSpecValue` each have zero DOM matches. Only a dead binding remains in source; this is not a currently reachable user flow or an open race finding. The reviewer verified the real datums modal entry with trusted Open/Close and unchanged native world, consistent with the modal save/guide green above. Evidence is `/tmp/geometry-refspec-overlap-review/reachability-f667/uiux/evidence/result.json` with its adjacent `terminal.json`; owned 8946/9466 were stopped. This closes that specific earlier hypothesis without claiming all possible editor interactions were exhausted.
