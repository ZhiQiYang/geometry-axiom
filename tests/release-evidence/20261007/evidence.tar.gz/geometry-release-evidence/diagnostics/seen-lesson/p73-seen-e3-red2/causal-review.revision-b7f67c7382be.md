# P76 prior-seen tutorial fixture: causal reproduction

Exact source: clean e3af640c5500ad86022f1515ad03547096667743 at `/workspace/geometry-axiom-release`. Runtime `2cb2b1d8ba04c526db12040b906d68149f07103e7b38e0d050878f7a82f8dce6`; source/runtime before and after identical; five native helpers fresh. Exit 1, owned 8941 service and CDP9461 browser stopped.

The TEMP module-loading wrapper ran the unchanged formal P73 (69 assertions green). Its ordinary trusted `#paramGridLessonClose` click was recorded (`trusted: true`, event time 9895.8 ms), and the current lesson token was stored. It then issued a real `Page.reload` in the same profile and invoked the unchanged formal P76. No storage was cleared or synthesized, no production code or formal assertion was changed, and no native result was mocked.

The original P76 first assertion failed: `open` was false, while parent was canvasViewport, canvas class was true, lesson registration valid, width/length/source text present, name hit testing correct, no undersized visible controls, and no horizontal overflow. The failure snapshot shows collapsed true, all five tutorial buttons enabled, and the existing Open button visible. The current token exactly matches localStorage before and after reload.

Production `parameters.js` initializes `seen = readSeen(token(opening))` and `expanded = !seen`; its Close handler records the token. It correctly honors the earlier dismissal. P76 resets native geometry but does not reset the browser preference, so the unconditional first-visit open expectation is an invalid fixture premise after P73 and a reload. Full P74 performs such a reload; this diagnostic isolates that state transition without changing the failing P76 oracle.

Evidence: `gate.log` lines 80–89; `evidence/seen-p76-evidence.json`; `evidence/failure.png`; `evidence/failure.html`; `terminal.json`; source/runtime before/after JSON. Diagnostic exact source copied as `diagnostic-source.cjs`, SHA256 `38a10777cfe6bc90393b041d43bee6cb773cc96edc0c5c0775fcebb07babfcf6`.

Result is 69 passes / 1 failed assertion / completed false. This is a deliberately composed diagnostic, not a formal full-suite pass or a separate product defect. Proposed fixture fix adds one assertion checking fresh users auto-open and prior-seen users stay collapsed, then uses trusted existing Open only for prior-seen users before the original content/frame/dismiss assertions.

The earlier `p73-seen-e3-red1` attempt only imported the driver as a library, so its main guard ran no browser or assertion. Its empty exit-0 terminal is explicitly classified as harness_error in that attempt's `attempt-review.json`, not counted as a pass.

## Exact diagnostic replay after fixture correction

Clean `f6672d865eb529cd37a6486b63a78b8a82386632` at `/workspace/geometry-axiom-grid-raw` replayed the same copied TEMP script (identical SHA256 above), native-backed P73 trusted dismissal and real reload. With only one additional seen-dependent P76 assertion and a trusted Open for an already-seen user, the composed diagnostic completed **156/156 (P73 69 + P76 87)**, exit 0, no failed/skipped assertion or uncaught browser exception. Original 86 P76 assertions were retained verbatim. Source/runtime before and after were identical, five native helpers fresh, and owned server/browser stopped.

Green evidence: `/tmp/geometry-rc-queue-review/p73-seen-f6672d8-green1/uiux/{terminal.json,gate.log,evidence/seen-p76-evidence.json}`. Runtime `36f76f6a49873cef9f987d1cbfdd4ead97c0f720a4849d39234440a5e55cb676`. This is a composed diagnostic, not a full-suite receipt. A fresh-profile formal P76 run is retained separately to verify first-visit auto-open.
