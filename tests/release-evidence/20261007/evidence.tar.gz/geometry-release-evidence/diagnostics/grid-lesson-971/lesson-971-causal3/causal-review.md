# Shared lesson controls retain a retired grid editor's lock

Clean HEAD `9712006e960f904d1357de4881dbac3742bfcda2`; runtime `31e7b1af0e3c1bcb12c10ccf03d93c498e71d1c70f1416861759c1b12254aeff`. Source/runtime stable before and after; five native helpers fresh; owned browser/service stopped.

The original full CDP failed at `UI review target is disabled #paramGridLessonClose` after 1585 passes, no assertion failures, incomplete. This focused diagnostic demonstrates a normal user flow causing the same disabled control without previous failure fixtures or forced context changes:

1. Open the real create menu and choose a new infinite grid. All five shared lesson buttons begin enabled.
2. Fill the real grid name, preview and confirm the native transaction.
3. `grid-system-workspace.js` operation's generic control lock disables all five shared lesson buttons. The TEMP setter trace delegates the real property setter and records the exact production stack.
4. Native confirmation succeeds, the source appears, and the grid editor opens its committed replacement state. The shared singleton lesson DOM persists; the old operation's `current(s)` check is false, so it does not restore its saved controls. The replacement render restores only controls it captured before the shared lesson was placed back into its new slot.
5. Return through the real grid Close button, then create a parameter through the real menu. The same singleton lesson moves to `canvasViewport`, with all five controls still disabled. The close button is visible, not obscured or zero-sized, but enabled=false. A true pointer click cannot dismiss the expanded lesson. The world remains unchanged.

Artifacts: `evidence/lesson-repro.json` (full DOM, disabled setter stacks, all API request bodies, stage snapshots, zero pageerror), `evidence/grid-after-commit.png`, `evidence/parameter-after-grid.png`, `evidence/lesson-state.html`, plus the usual terminal/source/runtime/native/world receipts. The exact TEMP script is preserved in `diagnostic-source.cjs`; its SHA-256 is in terminal.json.

The first diagnostic attempt failed to resolve an incorrectly absolute Playwright path; the second correctly launched but omitted opening the create menu and timed out on a hidden menu item. Those are retained separately as diagnostic harness failures (`lesson-971-causal1` and `lesson-971-causal2`), not counted as product red. This third attempt reaches all normal flow prerequisites and fails the intended original behavioral requirement.

This is a product-owned persistent shared-DOM lock, not a visibility-helper false positive. Do not skip or force-click the disabled button. A bounded fix should ensure grid-owned locks never outlive their editor on shared presentation controls; the non-mutating lesson controls may also be excluded from grid data-entry locks if their independent presentation contract is made explicit. Verify normal successful replacement, cancel/failure, and retired asynchronous cleanup without enabling a newer editor's owned data inputs.
