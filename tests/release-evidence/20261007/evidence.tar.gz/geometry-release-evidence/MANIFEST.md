# Geometry Axiom raw evidence pack v2

This pack contains original bytes, not links to TEMP-only evidence. It does not approve release.

- Candidate state: **local-candidate-acceptance-complete**; final source head: 66a4c89d985e5e7a34f602ff1d085c7a9943c883
- Prior tested source: `9712006e960f904d1357de4881dbac3742bfcda2`; full CDP round4 is **command-failed**, not a full pass.
- CI startup regression: 15 local native/identity/replay checks; original base971 and workflow commit d09edbb remain in the raw receipts. Remote CI was not executed by that probe.
- Grid lesson diagnostic3: original product red. Diagnostics1/2 are preserved harness/setup failures.
- Original platform, count-unit, native-identity and fault-injection limitations remain authoritative.

`MANIFEST.json` maps every copied artifact to its original absolute source, copied snapshot, SHA256 and byte count. `SHA256SUMS` verifies those bytes. Generated manifest/index documents are not original test receipts.

## Collection coverage

| Scope | Declared tested head | Classification | Terminal collection |
| --- | --- | --- | --- |
| 971-issue123 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-space | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-timber | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-feedback | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-queue-uiux | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-queue-parameters | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-queue-workflow | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-crossflow56 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-storage35 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-blank-entry2 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-evidence110 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| storage-attempt-final971 | See original receipt | diagnostic-prior-attempt | terminal-artifacts-present |
| storage-attempt-final971-compact-entry | See original receipt | diagnostic-prior-attempt | terminal-artifacts-present |
| storage-attempt-final971-source-contract | See original receipt | diagnostic-prior-attempt | terminal-artifacts-present |
| 971-delivery32 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 971-full-cdp-round4 | 9712006e960f904d1357de4881dbac3742bfcda2 | prior-tested-head | terminal-artifacts-present |
| 6954-storage-owner/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-77-normal/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-77-exit/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-77-recovery/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-77-remove/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-evidence-adapter/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-required-modules/rule-browser | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-required-modules/rule-controller | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-required-modules/scenario-grid-interface | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-storage-required-modules/scenario-browser | See original receipt | historical-scope | terminal-artifacts-present |
| a49-storage-116/final | See original receipt | historical-scope | terminal-artifacts-present |
| a49-storage-reader/final | See original receipt | historical-scope | terminal-artifacts-present |
| a49-storage-pdf-review/final | See original receipt | historical-scope | terminal-artifacts-present |
| a49-storage-storage-challenge/final | See original receipt | historical-scope | terminal-artifacts-present |
| a49-storage-evidence/final | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-queue-t4 | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-queue-cases-races | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-queue-native300 | See original receipt | historical-scope | terminal-artifacts-present |
| a49-queue-lifecycle | See original receipt | historical-scope | terminal-artifacts-present |
| a49-queue-workflow | See original receipt | historical-scope | terminal-artifacts-present |
| a49-queue-cases-app | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-room-keyboard | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-room-worker | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-room-pan | See original receipt | historical-scope | terminal-artifacts-present |
| 6954-room-acceptance | See original receipt | historical-scope | terminal-artifacts-present |
| a49-room-acceptance | See original receipt | historical-scope | terminal-artifacts-present |
| a49-model-ui-settled-v2/ui | See original receipt | historical-scope | terminal-artifacts-present |
| a49-model-model-update | See original receipt | historical-scope | terminal-artifacts-present |
| a49-model-user-flow-v2 | See original receipt | historical-scope | terminal-artifacts-present |
| refspec-reachability-f667 | f6672d865eb529cd37a6486b63a78b8a82386632 | diagnostic-composition | terminal-artifacts-present |
| p14-f667-baseline1 | f6672d865eb529cd37a6486b63a78b8a82386632 | diagnostic-composition | terminal-artifacts-present |
| p14-f667-held-red1 | f6672d865eb529cd37a6486b63a78b8a82386632 | controlled-causal-red | terminal-artifacts-present |
| p14-f667-held-green1 | f6672d865eb529cd37a6486b63a78b8a82386632 | diagnostic-composition | terminal-artifacts-present |
| p14-f667-ui-green1 | f6672d865eb529cd37a6486b63a78b8a82386632 | diagnostic-composition | terminal-artifacts-present |
| p14-66a4c89-committed1 | 66a4c89d985e5e7a34f602ff1d085c7a9943c883 | diagnostic-composition | terminal-artifacts-present |
| ci-startup15 | See original receipt | ci-startup-causal-regression | terminal-artifacts-present |
| lesson-971-causal1 | See original receipt | diagnostic-setup-failure | terminal-artifacts-present |
| lesson-971-causal2 | See original receipt | diagnostic-setup-failure | terminal-artifacts-present |
| lesson-971-causal3 | See original receipt | product-red-diagnostic | terminal-artifacts-present |
| cdp-round5-missing-env | See original receipt | diagnostic-preflight-rejection | terminal-artifacts-present |
| strict-round5 | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| full-cdp-round5b | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| storage-family | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| delivery-cold-restart32 | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| canonical-space-family | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| grid-system-only316 | e3af640c5500ad86022f1515ad03547096667743 | prior-tested-head | terminal-artifacts-present |
| strict-round6 | f6672d865eb529cd37a6486b63a78b8a82386632 | completed-nonconforming-stack-diagnostic | terminal-artifacts-present |
| full-cdp-round6 | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-failed-execution | terminal-artifacts-present |
| raw-provenance207 | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| p73-p76-seen-combo | f6672d865eb529cd37a6486b63a78b8a82386632 | diagnostic-composition | terminal-artifacts-present |
| parameters-fresh87 | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| delivery-cold-restart32 | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| storage-family | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| canonical-space-family | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| strict-round6b | f6672d865eb529cd37a6486b63a78b8a82386632 | prior-tested-head | terminal-artifacts-present |
| full-cdp-round7 | 66a4c89d985e5e7a34f602ff1d085c7a9943c883 | candidate-tested-head | terminal-artifacts-present |

## Pending

No configured terminal files are missing. This is a collection statement, not an all-pass conclusion.
