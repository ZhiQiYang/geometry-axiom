# 2026-10-07 交付證據獨立審閱

本文件是 TEMP 審閱建議，不是發佈批准。讀取時 primary 為乾淨 `cf6f6010c8f4ca6ee765c113694f6710a98f290b`；最終 head 尚未確定。parameter worktree 正修改 `parameters.js`、`engineering-adapter.js` 及對應測試，補 adapter 已提交收據與 P76 二次編輯問題。以下通過只屬原始受測版本，不能搬成未來 head 的新通過。

交付本審閱時的更新：root 已凍結乾淨 `9712006e960f904d1357de4881dbac3742bfcda2`。cf6→971 僅 BACKLOG、engineering-adapter、parameters、parameter unit test 與 expected floor 五檔變更。下表仍保留原歷史身分，沒有把971尚未完成的執行當pass；canonical_space_review 接完整 #123 再 Space，delivery owner 明確確認 **cf6 delivery32 沒有執行／沒有receipt**，現在準備971新checkout。此更新不更動上列原始結果。

## 結論與最小補正

1. `/tmp/geometry-release/pr-body.md` 仍以 `a49d2a5`、78 suites 為主，應在最後 freeze 後整份更新；目前不可交付為「全部綠燈」。
2. cf6 完整 CDP 是主動中斷並已 superseded，不是 0 failure 的完整成功。完整 CDP、最終 strict 及受影響參數正常／失敗路徑是尚未解除的交付條件。
3. 找到一項矩陣實際遺漏：`tests/test_issue123_create_feedback_browser.py` 在本輪沒有正式 receipt。root 已確認待最後 freeze 執行，owner 為 canonical_space_review；必須完整 390／900／1400 × mouse／touch，不能設 `--repro` 或 `--width`。它包含真參數新建與二次編輯，與本次修正直接相關。
4. 非瀏覽器總數不含 `REQUIRED_OWNER_GATES`、`REQUIRED_BROWSER_GATES` 和其他明示外部入口。manifest 要逐列列出，不能靠 strict 合計或 full CDP 遮住沒有跑的獨立 gate。
5. TEMP 絕對路徑只是定位，不是 durable evidence。提交最小索引時，至少保留小型原始 receipt／terminal result，以及可下載原始日誌包的雜湊和永久定位；不能只留下已不可取得的 `/tmp/...` 連結。

## 已核對的版本與結果

| 範圍 | 真正受測版本／結果 | 證據入口及正確解讀 |
| --- | --- | --- |
| strict round3 | cf6；79 suites，78 成功＋1 Windows GDI 具名平台 skip；counted 2488／pass 2487／fail 0／skip 1，exit 0 | `/tmp/geometry-release/logs/strict-rc3.log`、`logs/run_all_round3/`。已完成的 cf6 登錄範圍；正在變更的參數測試與最後 head 尚未驗，不固定未來 census 為 2488。 |
| CDP round1 | 6954；command failed，exit 1 | `cdp-round1/gate/receipt.json`。P53 問題的歷史紅證據。 |
| CDP round2 | a49d；command failed，exit 1 | `cdp-round2/gate/receipt.json`。1585 個通過且 0 assertion failure 不能抵銷 P73 fatal／未完成。 |
| CDP round3 | cf6；interrupted，child -15／gate 130，executionVerified false | `cdp-round3/gate/receipt.json` 與 `superseded.json`；原因為獨立 P76 二編及 adapter refresh 問題。不能算 completed。 |
| 完整 Space | cf6；228／0、completed true、exit 0；7 groups 精確、filters 空、exception／console 0 | `/tmp/geometry-space-cf6f601/space/receipt.json`、`verified-summary.json`；primary root、乾淨 before／after、native hashes 穩定、runtime `9c91d25f…` fresh。最後產品修正後仍要按影響重判。 |
| Space 假紅→修正 | a49d 原 full 227／2；背景先發反例 58／2；修正反例 59／0；乾淨 aa05 full 228／0 | `/tmp/geometry-space-gate/summary.json`。2 fail 包含 1 原 oracle＋completeness；partial 59 不能冒稱 full。保留原 five-conjunct oracle、fixed floor 和 caller／loading／single-hold 前提。 |
| A/B lifecycle／workflow／formal cases | a49d；82／82、34／34、76／76 | `/tmp/geometry-rc-queue-review/final-a49d2a5-first/focused-summary.json`；不是 cf6 新跑。 |
| guide crossflow | cf6；56／56、exit 0 | `/tmp/geometry-rc-room-review/final-parameter-cross/crossflow/terminal-receipt.json`；前後 runtime 同一且 fresh。與新增參數二編 challenge 分開。 |
| room acceptance | a49d；253／253 | `/tmp/geometry-rc-room-review/final-room/acceptance/terminal-receipt.json`。pan 32／worker 78／keyboard 396 在較早 6954，見 `rc1/*/terminal-receipt.json`，不能合成同一 head 四 gate。 |
| #116／PDF composite／formal evidence／reader／raw save challenge | a49d；87／1 composite flow／110／34／29 | `/tmp/geometry-rc-storage-final/CHECKS.json`、`ARTIFACTS.sha256.json`；逐 gate 的 `final/receipt.json`＋`release-command/receipt.json`。composite flow 與 assertions 不相加。 |
| 模型庫自然 UI／模型更新 owner／自然 timber flow | a49d；155／155、28／28、18／18 | `/tmp/geometry-rc-space-final/ui-settled-v2/ui/receipt.json`、`model-update/receipt.json`、`user-flow-v2/receipt.json`。UI 初始 World 過早取樣、第一次 placeOZ selector 錯誤均另存紅紀錄。18 非 timber 正式 79 的替代。 |
| 全新 checkout 交付／Linux launcher／serve | 已直接核對 a49d；32／32、17／17、45／45，npm build exit 0 | `/tmp/geometry-rc-delivery-final/evidence-manifest.json`。fresh checkout 的 binary SHA 可因 build 路徑不同而不同；必須比 sourceFingerprint／sidecar／建置命令，不能說與 root binary 全等。新的 delivery receipt 由 owner 彙整後再入矩陣，不從 pending 訊息推定 pass。 |
| 獨立 timber／trusted feedback | 6954；79／79、38／38 | `/tmp/geometry-rc-space-review/summary.json`。timber 為明示 partial mode 的完整該 scope；feedback 38 才是真 RO／真錯／人工回報，不能用 VM predicate 測試替代。 |
| #77 owner 五項及四個 browser | 6954；5、37、61、111、46 | `/tmp/geometry-rc-storage-review/CHECKS.json`；owner adapter 自建服務只留 initial runtime，沒有聲稱 post-test probe；其限制必須保存。 |
| T4／rule races／native lifecycle | 6954；89、30、300 cycles／9 checks | `/tmp/geometry-rc-queue-review/focused-summary-6954d40.json`；native300 不是 300 assertions，也不是 UI lifecycle82。 |
| 必需 module／standalone gates | 6954；scenario browser 2 viewport／12 native requests、real GridDraft owner 1 test／0 skip、rule controller17、rule browser91、evidence adapter67 | `/tmp/geometry-rc-storage-review/MODULE-CHECKS.json`。67 是 actual app/native/Chromium＋injected memory backend，不能替代 formal evidence110；standalone module 不等於產品入口／ZIP歷史。 |

上表是本次查到的證據，不是把全部歷史總和当作 final pass。strict 的獨立 counted sum 與所有瀏覽器 scope 應保持分離。

## 最小 durable manifest

建議目錄 `tests/release-evidence/20261007/` 只保留：`manifest.json`、小型逐 gate 原始 receipt／terminal result、必要的失敗→修正摘要；大型 screenshot／ZIP／完整 log 放一個有 SHA-256、大小和持久下載位置的 evidence bundle。manifest 可引用 bundle 內相對檔案路徑。不要提交 Chrome profile/cache，也不要用重寫摘要取代原始 receipt。

manifest 必需欄位如下（可以以共用 identity/artifact 索引去重）：

| 欄位 | 必要內容 |
| --- | --- |
| schema／generatedAt／state | 版本化 schema、UTC 時間；`in_progress`／`blocked`／`verified_candidate`，不能預先 approved。 |
| candidate | 最終 `sourceHead`、`sourceTree`、root、clean 狀態、runtime/sourceVersion、平台／Chromium／Node／Python。最終 head 未定時留 null＋blocking reason。 |
| sourceClosure | 實際受測 product、harness、fixtures、floor／golden 的 git blob 或 SHA-256；必要時保存 full tracked tree 清單摘要。`app.js` 相同不等於所有前端模組相同。 |
| native | 各實體 binary 的 path（原 provenance）、SHA-256、來源 fingerprint、sidecar hash、fresh 檢查、編譯 command/toolchain/flags、16 MiB stack；服務實際採用的 env 與啟動 command。不要把 `/runtime fresh` 說成正在執行 native process 的完整身份證明。 |
| gates[].id／kind／scope | 正式入口、full/partial/filter/omitted、owner/direct-module/standalone、viewports、countUnit、真 input 與 fault injection 邊界。 |
| gates[].execution | argv、cwd、影響 scope 的 env、起迄時間、timeout、exitCode、interrupted、completed、status；`command exit0` 與 `scope accepted` 分開。 |
| gates[].identity | 原始受測 head/tree/clean、runtime before/after root/version/fresh/PID/session、native before/after；自建 adapter 沒有 after probe 時要 null＋理由，不能補造。 |
| gates[].oracle | expected floor/golden 檔案 hash、independent inventory 依據、actual per-group pass/fail/skip、具名 skip、raw expected/unexpected exception；partial 的 omitted scopes 明列。 |
| gates[].artifacts | receipt/result/full log 及 screenshot／download／final dump 的相對路徑、SHA-256、byte size、bundle locator；TEMP 原路徑可保留為 provenance，但不可是唯一保存處。 |
| gates[].applicability | `executed_on_candidate`／`retained_prior_scope`／`diagnostic_only`／`superseded`／`pending`；舊 head 沿用須列 actual old head、final head、閉包比對、變更檔案、判斷理由及 reviewer。 |
| gates[].supersession | 保留失敗／setup error／interrupted 的 id、根因、修補 commit、後續替代 run id；不能直接覆蓋舊 status 為 pass。 |
| cleanup／limitations／blockers | own browser/service 終止與最終 dump 保全；Windows GDI/SAC、實機手機/IME、OS picker、非 Chromium、A/B中斷限制；未完成 gate/remote CI 精確 head 與狀態。 |

最小 acceptance predicate：每個 required gate 必須有明確 disposition；必跑的 final scope 需 exact source/clean/fresh、完整 completed、exit0、floor相符及零非預期 error。使用 retained-prior evidence 的理由必須可審查，不能只把 prior passed 改成 final passed。

提交 manifest 會產生新 commit，避免自我參照：把「受測 source head」與「攜帶證據的交付 head」分開，若最後只補 evidence/docs，明列 product/test/native blob 全等的核對。不要為取得自指 hash 重寫 receipt，也不要把從未執行的文檔 commit 說成受測 head。

## 舊證據哪些可保留，哪些需再跑

已確認 `a49d2a5..cf6f601` 只有 8 個 tracked 檔改動：BACKLOG、parameters、uiux test、CDP golden、Space harness、run_all registry/floor、parameter unit test。`app.js`、native C/geometry-core、serve、launcher 在此跨度沒有改動。待完成 patch 額外修改 `engineering-adapter.js` 與 parameters；它們的內容尚未 frozen，因此現在不能簽最終等價。

1. **可以保留為原 scope 的證據**：a49d 的 launcher17／serve45、新 checkout build；6954 的 native300、pure native／standalone rule/module gates，在最終檔案閉包與 sourceFingerprint 全等且執行契約不變時，可記 `retained_prior_scope`。對 native300 還需核 service transport：6954→a49d 的 serve 改動是 literal executable argv 支援，使用原 `GEOMETRY_BRIDGE` 路徑保持原 branch；不能只憑 C hash 一項宣告整個 HTTP gate 全等。
2. **a49d 正常產品流程可保留為補充，不自動升級為 final pass**：A/B82/34、rules76、#116/PDF/readers、library155/modelupdate28、room253。最後修正若確實只影響參數 confirm/error settlement，且其 gate 沒有執行該入口，可以寫出閉包審閱及 final fullCDP／Space 的交叉覆蓋後保留原 scope；有「exact candidate 必跑」要求的入口仍應對 final head 完成或明列未重跑，不能用一筆全域 app blob 全等蓋過 `parameters.js`/adapter 變更。
3. **不可僅靠舊 native/app blob沿用的直接受影響範圍**：P73／P76、參數確認取消／readonly／draft、二次編輯、guide引用、adapter 已提交後 refresh失敗／owner退休。`EngineeringAdapter.confirm` 目前的直接正式消費者為 ParameterUI；formal evidence110 的 `transaction(...,render)` fixture 也會呼叫，full CDP 的 parameter/grid fixture 也會呼叫。因此 final strict＋fullCDP、P73/P76正式原 oracle、獨立參數→guide→Save/Open35、#123 mouse/touch 是明確重驗集合；formal evidence110應重跑其使用 adapter 的完整 scope。
4. **Space 最後重跑合理且必要**：已有 cf6 full228，但最後參數 owner 改動與 draft/history/admission 共存，finalfreeze後再跑完整 scope，不能借用 cf6 228 作為未知新head的結果。
5. **獨立 timber79 尚是6954**：其後 app `mutate`/`fePlaceTimberFromForm` 已實際修過 busy/refresh ownership，這正是該 flow；舊79與a49d natural18、P53 targeted controls互補而不等价，建議 final完整TIMBER_ONLY79。不能把 default Space228誤認含此 optional group。
6. **回報38、room pan/worker/keyboard、#77四gate/T4/rules races等**：沒有在新head跑就保存原head，逐scope給 closure理由；不新增模糊總綠勾。回報只有feedback.js等價仍不足證明新版服務身份守門已真跑，若交付要求當前runtime可信回報則再跑38。room acceptance253不涵蓋keyboard396或worker78；fullCDP亦不可替代明示獨立gate。
7. **新 checkout／服務重啟32**：a49d的ZIP/PDF/metadata保全與launcher可保留；最後產品頭尚未決定，最後交付流程應指向真正 final head 的 fresh checkout，至少把新參數二編後完整專案納入保存重開挑戰。若已有新 receipt，先讀取其 exact scope再採納，不把名稱含 final 當來源證明。

以上是最小風險導向重验建議，不授權跳過現有必要條件，也不要求每次測試文字修正都重跑完全不相干的十八分鐘瀏覽器套件。若某 gate 要以 blob等價沿用，請記具體閉包與理由，不能把整份a49d矩陣換一個header變成新驗收。

## 尚未滿足的完成條件

- 最後 freeze head/tree／native receipts 未定；adapter/P76 修補與 meaningful regression 尚未完成。
- 最後 strict、無 scope full CDP（目前 floor 2170，但最後需獨立盤點），及對應完整 Space尚待新head。
- #123 first-center 全範圍沒有本輪 receipt，已正式列為待跑；獨立參數/guide/Save/Open35是計畫，不是pass。
- 所有其餘 required入口都須在 durable matrix 有 exact-run、retained-prior或pending disposition；目前 PR body把多項藏在舊head一句話，無法逐項稽核。
- `RELEASE-CANDIDATE.md` 的「連續兩輪未發現新交付阻塞」尚不能以本輪cf6 Space綠燈推定滿足，因同版本P76仍發現阻塞。最終修補後要記兩輪審查的來源、範圍與結果，不能把修补前成功scope拿來湊輪數。
- remote CI尚須精確交付head查核；本地pass與remote狀態分開。此審閱沒有跑browser、沒有改任何repo檔案。

## 後續執行補充（971，與上方審閱時點分開）

root 另行授權後，canonical_space_review 已在乾淨971 primary串行完成：完整 #123 **138／138**（390/900 mouse/touch各26、1400 mouse/touch各17）、完整Space **228／228**、獨立TIMBER_ONLY **79／79**、trusted feedback **38／38**。全部exit0、completed，source/runtime/nativeFresh與binary hashes前後穩定；owned服務／browser已停止。四組不相加為單一suite；#123原缺口於此解除。總索引 `/tmp/geometry-rc-space-9712006/summary.json` 保留各receipt／log SHA，feedback原始回報在 `/tmp/geometry-fb-ro-1HkQek`。原生與平台限制仍適用。

delivery owner 已另交971 fresh-checkout32／32，證據 `/tmp/geometry-rc-delivery-971/evidence-manifest.json`；其launcher17／serve45仍是a49d既有執行，`retained-evidence-identity.json` 明列六檔git blobs全等與nativeSourceDelta空。該32使用真UI新增模型、PDF/A/B完整保存冷重啟，沒有raw草稿fixture；不宣稱raw保存由它驗過。最後strict/fullCDP與其他owner的gate結果仍由root各自核終態；本補充不替尚未收到的結果宣告成功。
