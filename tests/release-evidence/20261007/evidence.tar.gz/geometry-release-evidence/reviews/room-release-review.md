# Room release review evidence

## Final candidate follow-up: P2 fixed and independently verified

Final freeze: `a49d2a5470abf6e9db4e14573535476d05647c21`, clean root `/workspace/geometry-axiom-release`; runtime `2dd5d975ce57e2d4cd8728915a4dd31a25bda7c998cedc84a61344dda0d290c9`.

- `final-guide/crossflow/terminal-receipt.json`: **56/56**, exit 0, 1382×900 and 390×900, fresh identical source/runtime before and after. The formerly stale inspector now exposes each newly created or moved guide with its exact current mm position. Trusted source-button activation opens the correct stored expression, and Cancel preserves exact World/history. Actual native late snap/newid replies still cannot mutate the departed face. PDF close/reopen and raw draft Check cancel/accept all pass. No browser console warning, error, or pageerror. Four representative guide/source screenshots were visually inspected.
- `final-room/acceptance/terminal-receipt.json`: **253/253**, exit 0, complete default suite rerun against the final freeze. Fresh identical source/runtime before and after, 11 real `.gcanvas` downloads and fresh-context reopen checks, no browser errors. Desktop rectangle and 390px L-shaped candidate screenshots were visually inspected again.
- **309/309 on the final candidate.** Earlier pan32/worker78/keyboard396 remain explicitly bound to the previous freeze below; they were not repeated after the presentation fix, per root's affected-scope decision.

Both final services preserved native dumps and then exited through owned-process cleanup. Browser slot was handed to `storage_flow_review`. Repository remains clean.

Final exact cross-flow harness: `final-guide/crossflow/browser/cross-flow.js`, SHA-256 `86ebbd64ffe0458aa69a27c3bc8158eb21d347a765dd555c927b74f4375a792d`; its receipt enforces a minimum of all 56 assertions. No shortened smoke substitutes the complete two-viewport run.

Persistent regression added to `tests/test_source_inspector.js` executes the shipped helper/callers and tests drag creation, existing-guide movement, and picker creation. It delays derived cache completion, verifies refreshed inspector snapshots, independently replaces World/face/project/history-frame/session ownership during reload, and verifies rejection does not replace inspector input. Current-owner native revision/undo changes are allowed. Complete source-inspector suite passed **28/28** in settlement. The same three new cases against the old frozen `app.js` produced **2 failures / 1 pass**, detecting the missing inspector refresh and stale repaint. Logs: `guide-inspector-persistent-red.log`, `guide-inspector-persistent-green.log`. Root owns product implementation; reviewer changed only the designated test file before final freeze.

## Earlier frozen snapshot and discovery trail

Snapshot: `6954d40f49f68f5a5c7d7d161f072c7a10ff9f9d`, RC root `/workspace/geometry-axiom-release`.
Runtime: `c276c2894659a760ade2389ca7270adb8d5ae1c7c6cba3e62e9dd2c2f1409f9e`.

All services below were owned on ports 8951–8955, used fresh isolated feedback/native/browser state, recorded source/runtime before and after, saved the final native dump, and were stopped after testing. No product files were changed by this reviewer after freeze.

## Complete first-round gates

| Gate | Full default assertions | Exit | Receipt |
| --- | --- | --- | --- |
| Room acceptance | 253/253 | 0 | `rc1/acceptance/terminal-receipt.json` |
| Room pan | 32/32 | 0 | `rc1/pan/terminal-receipt.json` |
| Room worker races | 78/78 | 0 | `rc1/worker/terminal-receipt.json` |
| Room keyboard | 396/396 | 0 | `rc1/keyboard/terminal-receipt.json` |

Total 759/759. Every receipt reports fresh runtime, identical source/runtime before and after, no failed assertions, and saved native dump. Acceptance includes 11 real `.gcanvas` download/reopen cases, real PDF/image source bytes and calibration metadata, and desktop/390px browser flows. Action counts are synthetic automation evidence and do not establish human task efficiency. Worker late replies use held real native MessageEvents and explicit late-consumer injection; the test does not claim that terminated workers naturally produced those replies. Keyboard IME/stale-DOM paths include labeled synthetic events. These Linux tests do not establish physical phone, real IME, Windows GDI, or native OS Save behavior.

## Different-angle second-round cross-flow

Initial complete flow passed 44/44 at 1382px and 390px: `rc2-complete-controls/crossflow/terminal-receipt.json` (exit 0, same fresh source/runtime).

The flow opens a production-packed project through a true file chooser, attaches a real PDF to a placed face, closes/reopens its PDF pages, holds actual unchanged `snap` and `newid` replies across visible Back and same-face reentry, and proves no old reply dispatches a guide mutation. It then creates and moves a guide through trusted pointer actions, proves exact native Undo/Redo, and tests raw invalid parameter draft preservation/discard through trusted keyboard activation of a finite grid card Check. Native World, history, raw attachments, selection, narrow drawer state, and console errors are recorded in `browser/results.json`.

The authored input fixture and actual-return transport hold are explicit test seams, not native-result substitutes. Exact initial green harness is preserved as `rc2-complete-controls/crossflow/browser/cross-flow.js`, SHA-256 `11358a1bff56ab8262f0d669f85bcc2e3be9f6482dca210a5b0259a985151551`.

## Confirmed remaining P2 at this snapshot

Visual inspection of the green screenshot revealed a missed user-facing defect: after a successful guide drag, the right components inspector still says `尚無參考線` and exposes no source button, while both native and `fe.guides` contain the new reference at 1500 mm. An independent DOM challenge waits a full second and reproduces the same stale state.

Authoritative red: `rc2-inspector-red/crossflow/terminal-receipt.json`, exit 1, 13 successful checks followed by one actual failing assertion and its terminal-error record. Runtime/source remain fresh and identical. See `browser/results.json`, `browser/failure.png`, `browser/1382-pdf-guide.png`. Exact red harness is preserved as `browser/cross-flow.js`, SHA-256 `ba029f5da51c29a12d21d5d019ccbea3b4f35d25364eda343c071af68fe897a6`.

Likely cause: `feUp` guide creation and guide movement, and the direction picker completion, call `feLoadGuides`, redraw the canvas, and redraw face layers, but omit inspector refresh. `feAfterChange` does refresh the inspector. Product owner was notified; no fix is claimed in this record.

TEMP follow-up harness now checks new and moved guide IDs/coordinates in the existing inspector, opens the actual source dialog to compare the exact current expression, and verifies source inspection leaves World/history unchanged at both viewport widths. It awaits a new source freeze.

## Earlier PDF ownership red/green

Reviewer tests in `tests/test_reference_workspace_races.js` cover successful catalog-leaf temporary PDF cleanup and failed/cancelled/unknown scenario adoption without destroying the live original PDF document or bytes. Root fixed cleanup in `reference-workspace.js`.

Red: `pdf-scenario-red-v2.log` (0/2, exit 1). Focused green: `pdf-scenario-focused-green.log` (3/3 including the original timeout case). Full native-env green: `pdf-scenario-native-full-green.log` (61/61, no skipped/cancelled tests, exit 0). Source-bound hashes: `pdf-ownership-receipt.json`.

An earlier full invocation without the prebuilt native environment timed out during the existing 5-second hash case because its fallback bridge cold compilation took 8.4 seconds. Build fingerprint time matches the timeout log. No assertion or timeout was weakened; the correctly configured full suite passed.
