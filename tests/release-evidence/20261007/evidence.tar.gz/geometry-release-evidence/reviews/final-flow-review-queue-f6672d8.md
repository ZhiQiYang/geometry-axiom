# 9712006 使用流程與實作第二次對照審查

**後續驗收更新（12:40 UTC）：本候選的完整 full CDP 在 P73 遇到共用教學按鈕永久停用；已用正常「建立網格→確認→返回→建立參數」真 UI 因果重現。這是新的產品阻塞，以下三項隔離 gate 的成功與當時限定複審保留為歷史收據，不能據此批准971交付。證據：`/tmp/geometry-rc-queue-review/lesson-971-causal3/uiux/`。**

審查者：release_queue_review。結論：下列限定範圍未發現尚未處理、足以阻擋本候選交付的問題。這是本分工的驗收與唯讀複審；完整交付仍以主代理的 full CDP、strict 與其他獨立審查收據為準。

## 唯一驗收版本與收據

- Root：`/workspace/geometry-axiom-release`
- Clean HEAD：`9712006e960f904d1357de4881dbac3742bfcda2`
- Tree：`2b031104fe97384cd1b4462b3510dcb9f9477b99`
- Runtime：`31e7b1af0e3c1bcb12c10ccf03d93c498e71d1c70f1416861759c1b12254aeff`
- 統整：`/tmp/geometry-rc-queue-review/final-9712006-third/focused-summary.json`

| 正式 gate | 結果 | 收據目錄 |
| --- | --- | --- |
| P73 UI/UX 與參數確認末段 | 69/69，completed true，exit 0 | `final-9712006-third/uiux` |
| P76 完整參數流程與候選所有權 | 86/86，completed true，exit 0 | `final-9712006-third/parameters` |
| A/B 使用流程 | 34/34，exit 0 | `final-9712006-third/workflow` |

上述目錄皆位於 `/tmp/geometry-rc-queue-review/`，各有原 gate.log、server.log、terminal.json、source-before/after.json、runtime-before/after.json、停止前原生 dump。三個 gate 各自序列啟停隔離服務及瀏覽器；前後 HEAD、clean status、所有來源指紋、runtime 均一致，五個 native helper 都 fresh。P73/P76 無失敗、略過或未捕捉瀏覽器例外；workflow 桌面及手機均無 pageerror。完成後 8941 與 9461 均無 listener，browser slot 已交 delivery_audit。

`final-9712006-first/uiux` 是我誤選舊 UI_REVIEW_ONLY scope 後主動中止的紀錄，分類為 superseded。`final-9712006-second/uiux` 是舊 owned Chromium 尚未釋放 port、launcher 正確拒絕附加的 0-assertion harness_error。兩者原檔及原因均保留，不合併進正式 gate 計數，也不當產品結果。原 cf6 的真 P76 失敗與診斷仍獨立保存，沒有用新成功覆蓋。

## 對照結果

### 同一編輯狀態、卡片切換與確認末段

`parameters.js` 的 confirm 在真正原生提交、初始卡片位置設定與最後 renderObjects 期間保持 busy；每個關鍵 await 後都核對 context/state 與 navigationSequence。最後 refresh 必須明確回傳 true，才退役原 state、選取正式參數卡並建立新 editor handler。DraftGate 現在先拒絕 busy，再處理同一參數卡的選取例外，因此 disabled input 的真 Ctrl+A 不會再經全選捷徑增加 navigationSequence、誤使自己退役。

P73 精確持有 confirm 自己最後一次 `objects` 的真成功回覆；不把 adapter 的較早刷新或其他消費者當持有點。持有時檢查 native OK、single claim、pending、所有欄位鎖定。真確認點擊、面卡 pointer 與 Enter 都不能改 context/frame/focus/edit/navigation、歷史身分、raw 或世界，也只送一筆確認。放行後再真點面卡，components 可見，focus/edit 一致；原後續參數來源與 guide 測試仍繼續通過。

本候選沒有重現先前「晚 selectObject 使已進入面卡失效」或「原生成功但殘留無 owner 的可編輯表單」問題。

### 延遲回覆、失敗與第二次編輯

preview 使用 context/state、generation、serial、previewRequest 四層歸屬檢查。開始重算便撤銷舊候選，過期成功回覆只取消它自己的 token，finally 只清理同一 request 的 pending。P76 持有真 native read/preview/confirm 回覆，覆蓋兩次重算亂序、回覆交付失敗、捨棄後新草稿、換專案後舊回覆，以及真連點／直接舊 handler。

P76 的 confirmation success 與 stale 路徑都持有真回覆，讓晚載入的 legacy controls 插入，再真嘗試輸入99。期間 raw 27 不變、欄位鎖定；成功保留正式27，stale 保留正式11與可修正27草稿。完成後使用原表單明確重新輸入99、試算、確認，兩條均真提交到99，證明新的 handler 仍有效，而非只檢查 pending=false 或按鈕外觀。

`engineering-adapter.js` 在 native success 後若刷新或 context 檢查失敗，保留成功收據；parameters 因而消耗已提交 token、拒絕復用，對仍屬原 owner 的畫面提供重新選卡訊息。失敗留下的退役 editor 控制保持停用，不再接受無 owner 的 raw。foreign context 不接受晚狀態訊息或選取。這一段額外例外分支本複審以程式檢視為主，未另外啟新 browser 注入所有 refresh failure；其專門單元由主代理驗收，這裡不冒列為新增真 browser 情境。

### Undo / Redo 與 A/B 隔離

P76 驗證只有最新看過的候選提交一次、單次原生 undo 移除新參數、redo 恢復逐字相同 dump，保存再載入也相同。

A/B workflow 在1280與390兩個 viewport 走原正式編輯器：建立 A、fork B、隔離 child native session 修改 B 的200→300、完成試改、比較、整體採用、正常按 Undo / Redo、保存、New、Open。A 的完整 scenario record 與 live world 在編輯 B 時不變；B 沒有猜測 origin mapping；採用是一筆 history，Undo 同時恢復 A 世界及完整 catalog，Redo 恢復 B。

程式對照：ScenarioWorkspace 的 lease 固定 context/native revision/session/history frame，只有同步的 owned draft flush 可更新資料戳；非同步結果不能重新取得已失效的操作。compare/adopt 重新驗 guard，隔離 native verifier 提供 final scene；參數比較使用各 scenario 自己的 canonical 最終定義，不解析 live A 冒充 B。reset、重建、CRLF 三種場景亦由正式 verifier 驗證，畫面只顯示最終定義且比較前後完整 root state 不變。

### ZIP 完整度與可見流程

workflow 使用真手動 PDF 矩形與明確參數欄位建立 evidence-only source，移除 underlay 後，真 ZIP download 仍包含原始 PDF bytes。ZIP 檢查 root 與 A/B 各完整 snapshot 都保有相同精確 source hash、evidence links，且沒有臆造 face underlay。New 後先確認空白 context 沒有 scenario catalog，Open 再深度比對完整 A/B catalog 及原生世界。

已唯讀查看本候選 `workflow/evidence/scenarios-390.png`：A200mm / B300mm、比較與整體採用按鈕可讀，定義比較與「幾何與料長尚未求值」限制清楚，沒有水平溢出。正式流程在1280及390都檢查無水平溢出；P76另檢查手機44px控制與確認鈕可視範圍。ZIP與PNG都保留於同 evidence 目錄。

## 範圍與限制

- 本次只唯讀對照以上三個正式 gate 與相關 implementation，沒有修改候選、降低 oracle 或追加相同已綠 gate 重跑。
- 189是斷言數，不代表189個獨立端到端旅程。P73/P76混合 trusted input、程式化fixture/防禦呼叫、DOM觀察與真 native；A/B 部分幾何 fixture 仍使用 native API，保存下載與編輯採正式控制。
- 延遲 gates 是可控持有真 native 結果，不窮舉所有 OS/網路排程、程序崩潰或磁碟失敗。此處也未新增不同瀏覽器／作業系統、長時間多使用者及大型專案壓測。
- 本次 ZIP 覆蓋具體 evidence-only PDF 與兩個 A/B snapshot；其他來源、網格raw、room/space、rule-case與fresh checkout由其他分工的獨立收據補足，不能把本報告延伸為所有附件組合皆已實測。
- A/B目前明確提供定義比較與整體採用；不宣稱已計算幾何／料長差異或推測實物配對。這是已明示的產品範圍，並非這次修補新增的阻塞。

在以上 scope 內，未找到新的 blocking finding。舊 P73/P76 真問題已有因果重現、保留原紅例、產品修補以及同一新 clean HEAD 的正式原 oracle 綠例，足以關閉本分工的阻塞。

## 後續修補與有限範圍重驗（2026-10-07 13:00 UTC）

971 全量後發現的共用教學鎖定問題已由 e3af640c5500ad86022f1515ad03547096667743 修補：網格工作區的四種資料控制鎖，透過同一個 selector helper 排除 `#paramGridLesson` 內只操作圖解呈現的按鈕。此變更不提早釋放原生交易或工作區資料控制鎖。

我在同一 clean e3af640 正式執行 GRID_SYSTEM_ONLY，完整 316/316（P70 117、P71 9、P78 23、P87 60、P88 107），exit 0、completed true、0 fail/skip/browser exception。新增四個 P70 regression 使用真網格確認造成 owner 更替，驗同一 lesson DOM/button 仍可操作，真 Open→Frame2→Close→Open，並移回參數後再驗一次；完整 native dump、history 身分與 raw（包含 `00027`）均保持。既有 ZIP、來源規則、延遲查詢及手機斷言未降低。

完整收據：`/tmp/geometry-rc-queue-review/final-e3af640-grid1/focused-summary.json`；runtime `2cb2b1d8ba04c526db12040b906d68149f07103e7b38e0d050878f7a82f8dce6`，before/after source/runtime 相同，五 native helpers fresh，owned service 與 browser 已關。此段只證明 e3af640 的 grid scope；早先 P73/P76/workflow、lifecycle/cases 收據仍保留其原 head，不作跨 head 計數。全量 CDP 與 strict release 判定由 root 的新收據決定。

## 參數教學的跨流程前提（2026-10-07 13:13 UTC）

另以 clean e3af640 重播完整原 P73，再同 profile 真 reload 與原 P76，證實 P76 第一項把「已看過且已關閉圖解」錯當首次使用：P73 的真 Close 為 trusted 事件，localStorage 保存 current token，reload 後圖解正確收合，五個按鈕都可用。原 P76 的其餘第一項條件均符合，只有強制 open 假設不符，故是 fixture 前提問題，與前述 971 教學按鈕 disabled 的產品缺陷不同。紅例與原判定保留於 `/tmp/geometry-rc-queue-review/p73-seen-e3-red2/uiux/causal-review.md`。

在獨立 clean f6672d865eb529cd37a6486b63a78b8a82386632（`/workspace/geometry-axiom-grid-raw`）增加一項 seen-dependent 初始呈現檢查，保留 fresh 自動展開並驗 prior-seen 收合，僅已看過時透過真 Open 建立原內容測試前提，沒有清除偏好或刪除原 86 項 assertions。同一 TEMP script 重播 P73→reload→P76 完整 **156/156（69+87）**；再以全新 profile 正式 GEOMETRY_PARAMETERS_ONLY 完整 **87/87**。兩輪均 completed true / exit 0 / 0 fail、skip、browser exception，source/runtime stable，五 native helpers fresh；8941/9461 已關。

收據索引 `/tmp/geometry-rc-queue-review/parameters-f6672d8-summary.json`。runtime `36f76f6a49873cef9f987d1cbfdd4ead97c0f720a4849d39234440a5e55cb676`。156 是明確標示的 TEMP 組合診斷，87 是新 profile 正式 scope；均不能替代 root 的新 full CDP/strict 收據。seen 分支的前提是本頁初始偏好尚未再被手動重開覆蓋；已核對 full P74 reload 後 P75 不操作此教學，符合這次 full 流程與獨立新 profile 的入口。
