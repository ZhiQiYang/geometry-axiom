# Final model UI and owner update gates

Reviewed candidate: clean `a49d2a5470abf6e9db4e14573535476d05647c21` in `/workspace/geometry-axiom-release`.
Runtime: `2dd5d975ce57e2d4cd8728915a4dd31a25bda7c998cedc84a61344dda0d290c9`.

## Complete successful gates

- Model library UI: **155/155**, exit 0. Receipt: `ui-settled-v2/ui/receipt.json`; complete browser evidence: `ui-settled-v2/ui/artifacts/results.json`. Full desktop 1382×804 and 390×844 flows were run with all original assertions. Create rectangle/L models, remove, button and keyboard Undo/Redo, terminal history ends and immediate fallback activation, real downloads and chooser Open, native World and full model records, original DOM identity, native modal focus, accessible control hit areas, and no console warnings/errors all passed.
- Model update through shared owner entry: **28/28**, exit 0. Receipt: `model-update/receipt.json`; browser evidence: `model-update/artifacts/evidence.json`. This is `GEOMETRY_MODEL_UPDATE_ENTRY=owner`, not the direct-module fallback. Actual producer replies are delayed without substituting fabricated success. Source/history/context replacement and cancellation races, strict-store validation, native embedded geometry boundaries, and real saved archive checks passed.

**183/183 on this exact final candidate.** Each gate records fresh runtime, exact root/PID/session before and after, stable source identity, final native dump, and owned-service cleanup. Ports 8973, 8974, 9493, and 9494 had no listeners after cleanup. Repository stayed clean. Desktop/narrow restored model library screenshots and the 390px model-update review were visually inspected without a new defect.

The UI test explicitly disables `showSaveFilePicker` to exercise the shipping real-download fallback. Native OS Save behavior and physical mobile devices are not established by these Linux browser checks.

## Original UI red and exact diagnosis

The original `ui/` run failed after 52 successful checks at the final Undo back to the service's initial default project. Original test and artifacts were not overwritten. The exact native difference was one added line:

```diff
+canvas-pos boundary 1 60 60
```

No geometry line was deleted or altered. Modal membership, focus on available Redo, full model list, original project context, and 1/3 → 0/4 history lengths were correct. Initial and final native scenes are `ui/actual-initial-world.scene` and `ui/final-world.scene`; diff is `ui/initial-vs-final.diff`.

`ui-diagnostic/` repeated the unchanged exact assertion while recording browser `apiRequest` and external HTTP dumps, native objects, UI cache, project/context/evidence state, model/source/catalog metadata, and every terminal history snapshot. Both transport paths agreed in the same service session. The UI cache had `hasPos=true,cx=60,cy=60`, while the early native read still had `hasPos=false,cx=0,cy=0`. History group remained null.

`ui-diagnostic-v2/` also instrumented the shipped functions and native request/response times without changing their data or results. It established that the initial oracle was captured during the ordinary layout write from real `btnCanvasView` → `setView3(false)` → `renderObjects({persistPositions:true})`, sequence 2:

- initial diagnostic dump dispatched at 1791.6 ms;
- `line canvas-pos boundary 1 60 60` dispatched at 1794.8 ms;
- that same command's receipt arrived at 1839.7 ms.

The original precondition relied on client `hasPos`, which is set before the native write completes. Its exact initial World was therefore pinned before the canonical layout operation settled.

## Fixture correction, without weakening the oracle

The successful TEMP copy adds a read-only native completion condition before initial-world capture: same face IDs/count, native `hasPos`, and native `cx/cy` must match the displayed face cache, with no pending workspace operation. It uses Python's explicit await of `page.evaluate` and checks the returned Boolean against a bounded deadline. It never writes the coordinates, ignores layout lines, recomputes an expected result from the restored scene, or changes any of the original 155 assertions.

The first async `wait_for_function` attempt in `ui-settled/` was ineffective: its immediately saved native observation was still false. That failed attempt remains preserved and is not counted as acceptance. The final `ui-settled-v2/` records the desktop fence observations **false, false, true**; the third observation shows the native and UI positions both 60,60 before the unchanged initial-world oracle is captured. History remains 0/0 with no open group.

The authoritative successful fixture is `ui-settled-v2/browser_ui.py`; its runner and all artifacts remain in that namespace. No repository source was changed for this diagnosis or fixture correction.
