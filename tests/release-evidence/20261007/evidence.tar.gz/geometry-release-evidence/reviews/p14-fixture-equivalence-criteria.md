# P14 fixture-only follow-up: evidence criteria

Base candidate: `f6672d865eb529cd37a6486b63a78b8a82386632`.
New head and canonical full outcome are pending. This document is planning and review criteria, not a pass receipt.

## Source identity required before retaining old scope

1. Pin the new clean root, HEAD and tree. Compare complete recursive `git ls-tree` inventories against f667, including path, mode, type and object ID. The only allowed changed tracked path is `geometry-web/cdp_test.js`; additions, deletions, renames, executable-bit changes and submodule changes elsewhere must stop the equivalence claim.
2. Record the exact old/new cdp_test.js blob IDs, SHA256 and complete diff. Confirm the change is limited to the P14 fixture and that the original trusted gesture, guide result oracle, timeout policy, counters, filters and failure behavior remain. In particular, retain the original P14 floor16 and full golden2175; no result-dependent floor editing.
3. Compare all runtime source/served-asset bytes, not just app.js. `runtime_version.source_files()` and `static_files()` include root-level web JavaScript, so changing the served test file legitimately changes the runtime fingerprint. Record the new version and fresh owned service receipt. Do not relabel an old version as the new runtime or reuse a running old snapshot.
4. Confirm unchanged native sources, binary files and official freshness receipts; unchanged launcher/server/runtime identity code; unchanged SSOT and canonical reader. Record these facts separately from HTTP/browser execution evidence.
5. `tests/test_cdp_navigation.js` directly imports `evaluationValue` from cdp_test.js. Retaining f667 strict6b therefore requires checking that exported helper, its dependencies, module import path and main/exports guard are unchanged. The P14 block runs only in the browser main path. Do not describe the entire changed harness as byte-equivalent. A focused new-head navigation test, if assigned, belongs to its own exact-head receipt; do not rerun the unrelated80 suites merely to replace their original head labels.

## Why the fixture change is acceptable only with causal evidence

The proposed setup seeds the API-observed revision through a real `apiRequest('dump')` before the P14 gesture. Queue's reported counterexample holds the real snap response while actual `persistSession` exposes the previously unobserved revision change13→14. An unseeded old gesture is then invalidated by that first observation. Require the saved deterministic red and fixed green to use the same native scene and public request sequence, retaining the guard and guide oracle. Neither disabling autosave, modifying product revision guards, skipping the trusted gesture, arbitrary retries, nor extending a sleep establishes this cause.

The new canonical full run is still required: fresh own service/browser, exact new clean source, no scope filters/modifiers, receipt exit0, `completed:true`, zero failed assertions/skipped groups, and an exact section-to-golden match. Bind the parsed `CDP_RESULT` to the command log SHA in the terminal receipt. A focused P14 result cannot replace this run. Qualify the raw exception counter against the harness's intentional P38 error instead of inventing a zero-raw-error claim.

## Retained scope and final matrix policy

| Existing evidence | Applicability after the allowed test-only delta |
| --- | --- |
| f667 #123138, Space228, timber79, raw207, storage35/2/8, delivery32 | Retain the original f667 head/root/runtime and exact scope. Product and those harness blobs must compare equal; this is not a new-head execution claim. |
| f667 strict6b80 suites (2508 mixed counted checks:2507pass/0fail/1GDI skip) | Retain f667 and its16MiB/--build provenance. Review the changed harness import exception above; original strict6 with8MiB remains diagnostic. |
| Older6954/a49d/971/e3 prior scopes | Keep original tested heads and limitations. Recompute each existing principal-owner/shared-consumer comparison endpoint; inherited product fixes still rely on the named scoped complements. |
| f667 full6 | Keep failed2174/2 and its complete log/receipt. A later corrected harness does not rewrite this historical outcome. |
| New full CDP | Only new-head actual terminal success can remove the full-gate blocker. Local verification and remoteCI approval remain distinct. |

Preserve immutable `prior-scope-applicability-f6672d8.json` (pending SHA `ad883f34b630f0e701eca501a949f8e074f375087ca55f140830bbba744d61b3`) and `prior-scope-applicability-f6672d8-full6-failed.json` (SHA `904c6e80d29e35b86e2e1a5def452d78da43646af1a54fb9ba88725553963df3`). Produce a separate new-head final matrix only after the actual new full pass. Its `releaseApproved` may remain false while remoteCI/release approval is separate.

## Concise PR validation wording to finalize after evidence exists

The release fixes PDF reader ownership during project/history changes, waits for angle-member transaction refreshes before accepting another operation, preserves guide inspector edits, and makes parameter creation/second edit settle consistently. Shared grid teaching controls remain usable through workspace locks; restored unknown raw grid choices now request explicit reselection without changing the saved raw draft or presenting invented geometry. The Linux launcher/build uses versioned native receipts and a16MiB stack, including paths with spaces. Native geometry and the axiom source remain unchanged.

Validation should link the exact new-head full CDP terminal and source-equivalence report, then identify f667's canonical138/228/79, raw207, storage35/2/8, delivery32 and strict80 as retained original-head evidence. Describe earlier scopes with their original heads through the matrix. State the one allowed Windows GDI skip and Linux/Chromium/physical-device limits; do not combine heterogeneous counts or claim remoteCI before its exact-head status is known.
