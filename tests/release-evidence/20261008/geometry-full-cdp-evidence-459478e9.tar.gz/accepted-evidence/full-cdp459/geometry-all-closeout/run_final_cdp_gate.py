import argparse
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/geometry-final')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--head', required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--port', type=int, default=8825)
    ap.add_argument('--cdp-port', type=int, default=9455)
    a = ap.parse_args()
    if git('rev-parse', 'HEAD') != a.head or git('status', '--porcelain'):
        raise RuntimeError('Expected exact clean frozen head')
    a.out.mkdir(parents=True, exist_ok=False)
    artifacts = a.out / 'cdp-full-artifacts'
    artifacts.mkdir()
    env = dict(os.environ)
    for key in list(env):
        if key.startswith('GEOMETRY_') and (key.endswith('_ONLY') or key in {'GEOMETRY_CDP_FROM_P31', 'GEOMETRY_CDP_UPDATE_GOLDEN'}):
            del env[key]
    env.update(
        GEOMETRY_TEST_URL=f'http://127.0.0.1:{a.port}/',
        GEOMETRY_FEEDBACK_DIR=f'/tmp/geometry-final-feedback-{a.port}',
        GEOMETRY_TEST_BRIDGE='/tmp/geometry-final-native/bridge',
        GEOMETRY_BRIDGE='/tmp/geometry-final-native/bridge',
        GEOMETRY_MODEL_BASE='/tmp/geometry-final-native/model-base',
        GEOMETRY_CHROME='/usr/bin/chromium',
        GEOMETRY_CHROME_FLAGS='--no-sandbox --disable-dev-shm-usage',
        GEOMETRY_CDP_PORT=str(a.cdp_port),
        GEOMETRY_CHROME_PROFILE=str(artifacts / 'chrome-profile'),
        GEOMETRY_TEST_SCREENSHOT=str(artifacts / 'phase1-shell.png'),
        PYTHONDONTWRITEBYTECODE='1',
    )
    # Only relocate explicitly supported evidence directories; no scope or
    # behavioral options are inferred or changed.
    keys = set()
    for file in (ROOT / 'geometry-web').glob('*test.js'):
        keys.update(re.findall(r'process\.env\.(GEOMETRY_[A-Z_]*(?:SCREENSHOT_DIR|ARTIFACT_DIR|TEST_DIR))\b', file.read_text()))
    for key in sorted(keys):
        directory = artifacts / key.lower()
        directory.mkdir()
        env[key] = str(directory)
    (a.out / 'launcher.json').write_text(json.dumps({'head':a.head,'command':['node','geometry-web/cdp_test.js'],'scope':'full','evidenceDirectoryOverrides':{k:env[k] for k in sorted(keys)}}, indent=2)+'\n')
    command = ['python3', 'tests/release_gate.py', '--url', env['GEOMETRY_TEST_URL'], '--output', str(a.out / 'cdp-full-receipt'), '--timeout', '3600', '--', 'node', 'geometry-web/cdp_test.js']
    return subprocess.run(command, cwd=ROOT, env=env).returncode

if __name__ == '__main__':
    raise SystemExit(main())
