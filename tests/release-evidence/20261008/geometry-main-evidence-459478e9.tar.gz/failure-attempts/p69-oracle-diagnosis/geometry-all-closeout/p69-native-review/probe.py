import copy
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/workspace/geometry-final')
OUT = Path(__file__).resolve().parent
BINARY = Path('/tmp/geometry-final-native/bridge')
RAW = Path('/workspace/scratch/geometry-all-closeout/root-browser/cdp-full-receipt/command.log')
sys.path.insert(0, str(ROOT))
from tests._bridge import BridgeSession
from tests.test_engineering_core import EngineeringCore

resource.setrlimit(resource.RLIMIT_STACK, (16 * 1024 * 1024, resource.RLIM_INFINITY))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def identity():
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
            'bridgeSha256': sha(BINARY), 'rawRedSha256': sha(RAW)}
def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

before_identity = identity()
trace = []
with BridgeSession(str(BINARY), cwd=OUT) as bridge:
    def cmd(command):
        response = bridge.command(command)
        trace.append({'command': command, 'response': response})
        return response
    def preview(operations):
        path = OUT / 'transaction.json'
        path.write_text(json.dumps({'schema': 'engineering-transaction/1',
                                  'expectedRevision': cmd('engineering-read')['revision'],
                                  'operations': operations}), encoding='utf-8')
        reply = cmd('engineering-preview ' + str(path))
        assert reply['ok'] and reply['preview']['valid'], reply
        return reply['preview']
    assert cmd('reset')['ok']
    assert cmd('line surface 1 origin 0 0 2500 u +x v +y outline 0,0 4000,0 4000,3000 0,3000')['ok']
    for line in ['spec EngineeringWidth 29', 'spec EngineeringCenter 1500']:
        assert cmd('line ' + line)['ok']
    seeded = preview(EngineeringCore.seed(None))
    assert cmd('engineering-confirm ' + str(seeded['token']))['ok']
    before = cmd('engineering-read')
    dump_before = cmd('dump')['text']
    pending = preview([{'op': 'archive', 'kind': 'material', 'id': 'panel-a', 'version': 1, 'value': True}])
    assert cmd('line spec EngineeringStale 100')['ok']
    after = cmd('engineering-read')
    dump_after = cmd('dump')['text']
    expected = copy.deepcopy(before['state'])
    expected['specs'].append({'name': 'EngineeringStale', 'value': 100})
    changed_keys = [k for k in before['state'] if before['state'][k] != after['state'][k]]
    assert changed_keys == ['specs'], changed_keys
    assert expected == after['state']
    assert before['state'] != after['state'], 'Original P69 oracle must reject the legitimate change'
    stale = cmd('engineering-confirm ' + str(pending['token']))
    assert not stale['ok'], stale
    final = cmd('engineering-read')
    assert final == after, 'Rejected confirm changed World/revision'
    assert cmd('dump')['text'] == dump_after
    save('before.json', before)
    save('after.json', after)
    save('expected.json', expected)
    save('trace.json', trace)
    (OUT / 'before.scene').write_text(dump_before, encoding='utf-8')
    (OUT / 'after.scene').write_text(dump_after, encoding='utf-8')
    after_identity = identity()
    assert before_identity == after_identity
    result = {'beforeIdentity': before_identity, 'afterIdentity': after_identity,
              'changedStateKeys': changed_keys, 'exactExpectedFullState': expected == after['state'],
              'originalOracleRejectsLegitimateSpec': before['state'] != after['state'],
              'nativeStaleReply': stale, 'rejectedConfirmZeroWrites': final == after,
              'scope': 'Isolated native reproduction with nonempty material/method/application/grid/source state; not a browser P69 rerun.'}
    save('result.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
