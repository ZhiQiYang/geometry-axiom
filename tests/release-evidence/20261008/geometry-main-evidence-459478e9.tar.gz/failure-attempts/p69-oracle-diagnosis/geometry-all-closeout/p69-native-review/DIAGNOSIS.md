# P69 engineering state oracle drift

Investigated frozen head `3c65cedc062a32209fd4e6f1a083da98749fba8d` without changing repository files, shared services, or the original failed full-CDP receipt.

`geometry-web/engineering_workflow_test.js:269–273` takes the entire `engineering-read.state`, previews a transaction, deliberately adds `spec EngineeringStale 100`, waits successfully for the old confirmation UI to be revoked, and then compares the entire state to the value captured before the new spec. The comparison now includes `state.specs`.

The user-authored upstream commit `fb6ef45cf651235250523aa88a7fa89d0e6acb34` added that field in `geometry-web/engineering_bridge.inc:37–43` to disclose cross-domain preview impact. The native response is therefore correctly different even when all existing engineering sources remain unchanged. The failed assertion is an outdated expected state, not evidence that the preceding UI invalidation wait failed.

`probe.py` uses a separate disposable native bridge process and an independently seeded, nonempty material/method/application/grid/source fixture. It verifies that the only changed top-level state key is `specs`, and that the entire after-state equals the before-state plus exactly `{name: 'EngineeringStale', value: 100}`. The full canonical scene differs by exactly the corresponding new spec line. The previous pending material archive token returns `STALE`; after that rejection, the full read including revision/hash and canonical dump remain identical. This is a bounded native reproduction, not a rerun or replacement of P69 browser acceptance.

Recommended test correction: retain the original single assertion and deep equality over every state field, with expected state `{...beforeStale, specs: [...beforeStale.specs, {name: 'EngineeringStale', value: 100}]}`. Do not remove `specs` from the comparison.

`oracle-counterexamples.cjs` independently uses the same `util.isDeepStrictEqual`: eight checks pass, including rejection of an extra spec, changed pre-existing spec, source effective-value change, source identity change, leaked material archive, and an unexpected state field. The original unadjusted comparison rejects the legitimate addition, as reproduced.

Receipts include exact before/after native JSON, full command trace, canonical scenes, and before/after source/binary/raw-red identities. Original red log SHA256: `415bc0f32c7fa2f3950087b483a2e47c570b687d5d1af53ab0a6f98c30e7a2a3`. Bridge SHA256: `386b3549bdc1bfbf251a6eb9ef9ef9ece0f3ecc5c2aa331f725f9d93fe1387b3`.

Commands:

```sh
python3 /workspace/scratch/geometry-all-closeout/p69-native-review/probe.py
node /workspace/scratch/geometry-all-closeout/p69-native-review/oracle-counterexamples.cjs
```

No source change was made by this investigation; parent owns the narrowly scoped harness correction and subsequent formal gates.
