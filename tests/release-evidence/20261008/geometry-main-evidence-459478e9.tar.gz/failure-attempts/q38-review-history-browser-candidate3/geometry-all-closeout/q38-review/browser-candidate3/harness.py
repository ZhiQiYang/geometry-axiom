#!/usr/bin/env python3
"""Independent rendered UI probes with real API data; response delay is explicit."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback
import urllib.request
import zipfile
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser()
parser.add_argument('--url',required=True)
parser.add_argument('--out',required=True)
parser.add_argument('--repo',required=True)
args=parser.parse_args()
out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
fixture=json.loads(Path(__file__).with_name('fixture.json').read_text())
checks=[];errors=[];downloads=[];raw=[];error=None
expected=['B01','B02','B03','B04','B05','B06','B07','B08']
started=datetime.now(timezone.utc).isoformat()
def runtime():
    with urllib.request.urlopen(args.url.rstrip('/')+'/runtime') as r:return json.load(r)
def write(name,value): (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))
def check(identifier,message,ok,details=None):
    row={'id':identifier,'message':message,'pass':bool(ok),'details':details};checks.append(row)
    print(identifier,'PASS' if ok else 'FAIL',message,flush=True)
def ready(page):page.wait_for_function("connection.phase==='ready'&&!ReferenceWorkspace.busy&&!oc.busy")
def native(page,cmd):
    value=page.evaluate('(cmd)=>apiRequest(cmd)',cmd);raw.append({'command':cmd,'response':value});write('commands.json',raw)
    if not value.get('ok'):raise AssertionError(value)
    return value
def state(page):
    return page.evaluate("""async()=>{const w=await apiRequest('dump'),s=await apiRequest('section-profile-read'),c=ReferenceWorkspace.context(),o=ReferenceWorkspace.getModelOperationState();return {world:w.text,revision:s.revision,context:o.context,frame:o.frame,undo:o.undo,redo:o.redo,group:o.group,project:ReferenceWorkspace.getProjectState(),flags:{saved:!!c.saved,downloaded:!!c.downloaded,dirty:!!c.dirty,dirtyReason:c.dirtyReason||''}}} """)
def transact(page,ops):
    value=page.evaluate("""async operations=>{const r=await apiRequest('section-profile-read'),response=await fetch('/section-profile/preview',{method:'POST',headers:{'Content-Type':'application/json','X-Geometry-Version':pageRuntimeVersion},body:JSON.stringify({schema:'section-profile-transaction/1',expectedRevision:r.revision,operations})});const p=await response.json();if(!p.ok||!p.preview.valid)throw Error(JSON.stringify(p));const result=await apiRequest('section-profile-confirm '+p.preview.token);if(!result.ok)throw Error(JSON.stringify(result));await renderObjects();return {expectedRevision:r.revision,preview:p,result};}""",ops)
    raw.append({'route':'/section-profile/preview','operations':ops,'response':value});write('commands.json',raw)
    return value
def open_library(page):
    page.locator('#fileMenuBtn').click();page.locator('#btnModelLibraryMenu').click()
    page.wait_for_function("document.querySelector('[data-sp-open-run]')!==null")
def open_run(page,identifier):
    open_library(page);page.locator(f'[data-sp-open-run="{identifier}"]').click()
    page.wait_for_function("id=>document.getElementById('sectionProfileWorkspace').open&&document.getElementById('spModelRun').value===String(id)&&!document.getElementById('spExportModel').disabled",arg=identifier)
def attach(page):
    page.on('dialog',lambda d:d.accept())
    page.on('pageerror',lambda e:errors.append({'type':'pageerror','message':str(e)}))
    page.on('console',lambda m:errors.append({'type':'console','message':m.text}) if m.type=='error' else None)
    page.on('download',lambda d:downloads.append(d.suggested_filename))

before=runtime();after=None
try:
    assert before['fresh'] and Path(before['root']).resolve()==Path(args.repo).resolve()
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--remote-debugging-port=9456'])
        context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
        page=context.new_page();attach(page);page.goto(args.url);ready(page)
        page.locator('#fileMenuBtn').click();page.locator('#btnNewProject').click();ready(page)
        for line in fixture['worldSetup']:
            reply=page.evaluate('(line)=>apiRequest("line "+line)',line)
            if reply.get('preview'):native(page,'line confirm '+str(reply['preview']['token']))
            else:assert reply['ok'],reply
        transact(page,[{'op':'put-'+kind,'value':value} for kind,key in [('profile','profiles'),('member','members'),('run','runs')] for value in fixture[key]])
        page.wait_for_function('SectionProfileWorkspace.runCount===2')
        # Delay one genuine native read response after the service has already
        # produced it. No API result, geometry or revision is fabricated.
        page.evaluate("""()=>{const original=window.fetch.bind(window);window.__q38OriginalFetch=original;window.__q38HoldRead=false;window.__q38ReadHeld=false;window.__q38HoldModel=false;window.__q38ModelHeld=false;window.fetch=async(...args)=>{const init=args[1]||{},url=String(args[0]);let cmd='';try{cmd=JSON.parse(init.body||'{}').cmd||''}catch(_){}if(url==='/api'&&cmd==='section-profile-read'&&window.__q38HoldRead){window.__q38HoldRead=false;const response=await original(...args);window.__q38ReadHeld=true;await new Promise(resolve=>window.__q38ReleaseRead=resolve);return response;}if(url==='/model'&&window.__q38HoldModel){window.__q38HoldModel=false;const response=await original(...args);window.__q38ModelHeld=true;await new Promise(resolve=>window.__q38ReleaseModel=resolve);return response;}return original(...args);};window.__q38HoldRead=true;void SectionProfileWorkspace.refreshLibrary();}""")
        page.wait_for_function('window.__q38ReadHeld===true')
        extra=deepcopy(fixture['runs'][0]);extra['id']=205
        transact(page,[{'op':'put-run','value':extra}])
        page.wait_for_function('SectionProfileWorkspace.runCount===3')
        page.evaluate('()=>window.__q38ReleaseRead()');page.wait_for_timeout(150)
        library={'count':page.evaluate('SectionProfileWorkspace.runCount'),'markup':page.evaluate('SectionProfileWorkspace.libraryMarkup()'),'native':native(page,'section-profile-read')}
        write('B01-library-response-order.json',library)
        page.screenshot(path=str(out/'B01-library-response-order.png'),full_page=True)
        check('B01','A genuine older same-context read cannot overwrite newer library data',library['count']==3 and 'data-sp-open-run="205"' in library['markup'],library)
        transact(page,[{'op':'delete-run','id':205}]);page.wait_for_function('SectionProfileWorkspace.runCount===2')
        open_run(page,201)
        summary=page.locator('#spModelSummary').inner_text();desktop=page.evaluate("({title:document.title,overflow:document.documentElement.scrollWidth>innerWidth,dialogOverflow:document.getElementById('sectionProfileWorkspace').scrollWidth>document.getElementById('sectionProfileWorkspace').clientWidth,canvas:document.getElementById('spModelCanvas').getBoundingClientRect().toJSON()})")
        page.screenshot(path=str(out/'B02-desktop-world.png'),full_page=True)
        check('B02','Desktop actual positioned model shows independent exact material volume and no overflow',
              '1116435 mm³' in summary and not desktop['overflow'] and not desktop['dialogOverflow'] and desktop['canvas']['width']>100,desktop)
        page.evaluate('()=>{window.__q38HoldModel=true;window.__q38ModelHeld=false}')
        page.locator('#spBuildModel').click();page.wait_for_function('window.__q38ModelHeld===true')
        page.locator('[data-sp-run="202"]').click();page.evaluate('()=>window.__q38ReleaseModel()');page.wait_for_timeout(150)
        check('B03','Real late model response for previous run cannot enable export after same-context switch',page.locator('#spExportModel').is_disabled() and page.locator('#spModelRun').input_value()=='202')
        page.locator('[data-sp-run="201"]').click();page.locator('#spBuildModel').click();page.wait_for_function("!document.getElementById('spExportModel').disabled")
        with page.expect_download() as downloading:page.locator('#spExportModel').click()
        exported=out/'B04-world.model.json';downloading.value.save_as(exported)
        package=json.loads(exported.read_text())
        check('B04','Actual UI export contains geometry/solid-set package with native run/member identity',package['request']['role']=='geometry' and package['request']['target']=='solid-set' and package['request']['roots']==[{'kind':'profile-run','id':201}] and len(package['derived']['objects'])==3)
        page.locator('#spClose').click()
        readonly=context.new_page();attach(readonly);readonly.goto(args.url);ready(readonly)
        readonly.wait_for_function('ReferenceWorkspace.getProjectInfo().editingBlocked')
        rb=state(readonly);locks=readonly.evaluate('()=>navigator.locks.query()')
        open_run(readonly,201);ra=state(readonly)
        disabled=all(readonly.locator(sel).is_disabled() for sel in ['#spLengthSource','#spPlacement','#spPreview','#spConfirm','#spNewRun','#btnUndo','#btnRedo'])
        readonly.screenshot(path=str(out/'B05-real-readonly.png'),full_page=True)
        check('B05','Real second-tab readonly lease opens actual run mesh while preserving World/history/save flags',
              readonly.evaluate("ReferenceWorkspace.getProjectInfo().recovery.state==='readonly'") and disabled and rb==ra and '1116435 mm³' in readonly.locator('#spModelSummary').inner_text(),{'locks':locks,'before':rb,'after':ra})
        readonly.close();page.set_viewport_size({'width':390,'height':844});open_run(page,204)
        mobile=page.evaluate("({overflow:document.documentElement.scrollWidth>innerWidth,dialogOverflow:document.getElementById('sectionProfileWorkspace').scrollWidth>document.getElementById('sectionProfileWorkspace').clientWidth,text:document.getElementById('spEditor').innerText})")
        page.screenshot(path=str(out/'B06-mobile-copied.png'),full_page=True)
        check('B06','390px copied-host view preserves source description and exact model without overflow',not mobile['overflow'] and not mobile['dialogOverflow'] and '依獨立測試牆取值' in mobile['text'] and '1116435 mm³' in page.locator('#spModelSummary').inner_text(),mobile)
        saved_world=native(page,'dump')['text']
        with page.expect_download() as saving:page.locator('#sectionProfileWorkspace [data-project-action="save"]').click()
        archive=out/'B07-section.gcanvas';saving.value.save_as(archive);ready(page)
        with zipfile.ZipFile(archive) as z:
            manifest=json.loads(z.read('manifest.json'));saved_scene=z.read('world.scene').decode()
        check('B07','Actual UI Save preserves all native definitions in geometry-canvas/16 with known capability',manifest['format']=='geometry-canvas/16' and 'section-profile/1' in manifest['requiredCapabilities'] and saved_scene==saved_world)
        # Export stale-source check bypasses frontend observation deliberately:
        # the raw API mutation is real and revision/source comparison must catch it.
        count=len(downloads)
        mutation=page.evaluate("""async()=>{const r=await __q38OriginalFetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Geometry-Version':pageRuntimeVersion},body:JSON.stringify({cmd:'line spec IndependentExportSource 19'})});return r.json()}""")
        assert mutation.get('ok'),mutation
        page.locator('#spExportModel').click();page.wait_for_timeout(150)
        status=page.locator('#spStatus').inner_text()
        check('B08','Export rechecks actual native revision/source immediately before creating download',len(downloads)==count and ('已改變' in status or '更新 3D' in status),{'status':status,'downloads':downloads})
        after=runtime();assert after['version']==before['version'];assert not errors,errors
        browser.close()
except BaseException as exc:
    error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()};print(error['traceback'],flush=True)
finally:
    def git(*parts):return subprocess.check_output(['git','-C',args.repo,*parts],text=True).strip()
    result={'schema':'q38-independent-browser-probes/1','started':started,'finished':datetime.now(timezone.utc).isoformat(),'command':sys.argv,
            'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'gitStatus':git('status','--short'),
            'fixtureSha256':hashlib.sha256(Path(__file__).with_name('fixture.json').read_bytes()).hexdigest(),
            'harnessSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'expectedIds':expected,'actualIds':[r['id'] for r in checks],
            'checks':checks,'error':error,'errors':errors,'downloads':downloads,'before':before,'after':after,
            'fallback':'Browser plugin not available; Python Playwright with system Chromium','faultInjection':'Only genuine response delivery is delayed; API payloads are never fabricated.'}
    result['pass']=error is None and result['actualIds']==expected and all(r['pass'] for r in checks) and not errors
    write('result.json',result)
sys.exit(0 if result['pass'] else 1)
