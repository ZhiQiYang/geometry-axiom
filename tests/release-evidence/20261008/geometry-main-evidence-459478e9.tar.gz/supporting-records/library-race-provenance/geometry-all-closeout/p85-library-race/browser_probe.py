import argparse,asyncio,hashlib,json,subprocess
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import urlopen
from playwright.async_api import async_playwright
ROOT=Path('/workspace/geometry-final');OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
async def run(label):
    out=OUT/label;out.mkdir(exist_ok=False);started=datetime.now(timezone.utc).isoformat()
    identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'sourceSha256':sha(ROOT/'geometry-web/space-workspace.js'),'harnessSha256':sha(__file__),'runtime':json.load(urlopen('http://127.0.0.1:8834/runtime'))}
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':1400,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        await page.goto('http://127.0.0.1:8834/');await page.wait_for_function("typeof SpaceModelWorkspace==='object'&&connection.phase==='ready'")
        await page.evaluate("""async scene=>{SpaceModelWorkspace.close();resetSceneFocus();const bytes=await GeometryProject.pack(scene,{projectId:'public-source-navigation',name:'公開來源定位測例',sources:[],faces:[]},new Map(),fflate);await ReferenceWorkspace.importBytes(bytes,'public-source-navigation.gcanvas');await renderObjects({persistPositions:false});await enterFocus('face',1,{placementId:10});fiShowTab('prop');const input={mode:'plan',base_scene:(await api('dump')).text,placement_id:20,obstacles:[],settings:{bottom:0,height:3000,edges:[0,1,2,3],floor:'boundary',ceiling:'boundary',holes:'none',wall_thickness:null}};const response=await fetch('/model/space-preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)}),result=await response.json();if(!result.ok)throw Error(JSON.stringify(result));for(const id of ['p85-a','p85-b'])ReferenceWorkspace.addSpaceModel({id,name:id,created_at:new Date().toISOString(),source:{kind:'scene',placement_id:20,boundary_id:1,scene_hash:result.source_sha256},input,result});await SectionProfileWorkspace.refreshLibrary();} """,(ROOT/'_p2_source_navigation.scene').read_text())
        await page.evaluate("""()=>{const original=apiRequest,g=window.__libraryProbe={held:false,released:false,events:[]};const gate=new Promise(resolve=>g.release=resolve);g.restore=()=>apiRequest=original;apiRequest=async(...args)=>{const r=await original(...args);if(args[0]==='section-profile-read'&&!g.held){g.held=true;g.nativeOK=r.ok;g.events.push('native-read-held');await gate;g.released=true;}return r;};window.addEventListener('section-profile-library-changed',()=>g.events.push('library-refresh-event'));SpaceModelWorkspace.openLibrary();SourceInspectorApp.sync();} """)
        await page.wait_for_function('__libraryProbe.held')
        selector='#smLibraryList .sm-model-card:has([data-sm-open-model="p85-a"]) [data-source-inspector]'
        await page.locator(selector+' summary').click()
        await page.locator(selector+' [data-source-locate="timber:7"]').wait_for()
        before=await page.evaluate("""()=>{const card=document.querySelector('[data-sm-open-model="p85-a"]').closest('.sm-model-card'),detail=card.querySelector('[data-source-inspector]');__libraryProbe.card=card;__libraryProbe.detail=detail;return {cardIds:[...document.querySelectorAll('#smLibraryList [data-sm-open-model]')].map(b=>b.dataset.smOpenModel),cardConnected:card.isConnected,detailOpen:detail.open,sourceLocate:!!detail.querySelector('[data-source-locate="timber:7"]'),events:[...__libraryProbe.events]};}""")
        await page.screenshot(path=str(out/'before.png'))
        await page.evaluate('__libraryProbe.restore();__libraryProbe.release()')
        await page.wait_for_function("__libraryProbe.events.includes('library-refresh-event')")
        after=await page.evaluate("""()=>{const card=document.querySelector('[data-sm-open-model="p85-a"]').closest('.sm-model-card'),detail=card.querySelector('[data-source-inspector]');return {oldCardConnected:__libraryProbe.card.isConnected,oldDetailConnected:__libraryProbe.detail.isConnected,sameCard:card===__libraryProbe.card,sameDetail:detail===__libraryProbe.detail,detailOpen:detail.open,sourceLocate:!!detail.querySelector('[data-source-locate="timber:7"]'),events:[...__libraryProbe.events],models:ReferenceWorkspace.getSpaceModels().map(m=>({id:m.id,placement:m.source.placement_id}))};}""")
        await page.screenshot(path=str(out/'after.png'))
        result={'started':started,'finished':datetime.now(timezone.utc).isoformat(),'command':['python3',__file__,label],'identity':identity,'before':before,'after':after,'browserErrors':errors,'raceObserved':not after['sameCard'] and before['detailOpen'] and not after['detailOpen'],'scope':'Real browser/native result with only the actual Q38 read response held before UI observation; no source data fabricated.'}
        (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False));await browser.close()
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('label');a=ap.parse_args();asyncio.run(run(a.label))
