import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/geometry-final')
OUT = Path('/workspace/scratch/geometry-all-closeout/p85-focused-development')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def main():
    expected = sys.argv[1]
    OUT.mkdir(parents=True, exist_ok=True)
    for scope, script, modifiers in [('timber-schedule', 'cdp_test.js', {'GEOMETRY_TIMBER_SCHEDULE_ONLY': '1'})    ]:
        if git('rev-parse', 'HEAD') != expected:
            raise RuntimeError('Expected exact clean frozen head')
        artifacts = OUT / (scope + '-artifacts')
        artifacts.mkdir(exist_ok=False)
        env = dict(os.environ)
        for key in list(env):
            if key.startswith('GEOMETRY_') and (key.endswith('_ONLY') or key in {'GEOMETRY_CDP_FROM_P31', 'GEOMETRY_CDP_UPDATE_GOLDEN'}):
                del env[key]
        env.update(
            GEOMETRY_TEST_URL='http://127.0.0.1:8834/',
            GEOMETRY_FEEDBACK_DIR='/tmp/geometry-final-feedback-8834',
            GEOMETRY_TEST_BRIDGE='/tmp/geometry-final-native/bridge',
            GEOMETRY_BRIDGE='/tmp/geometry-final-native/bridge',
            GEOMETRY_MODEL_BASE='/tmp/geometry-final-native/model-base',
            GEOMETRY_CHROME='/usr/bin/chromium',
            GEOMETRY_CHROME_FLAGS='--no-sandbox --disable-dev-shm-usage',
            GEOMETRY_CDP_PORT='9464',
            GEOMETRY_CHROME_PROFILE=str(artifacts / 'chrome-profile'),
            GEOMETRY_TEST_SCREENSHOT=str(artifacts / 'phase1-shell.png'),
            GEOMETRY_GRID_SCREENSHOT_DIR=str(artifacts / 'grid'),
            GEOMETRY_REPAIR_SCREENSHOT_DIR=str(artifacts / 'repair'),
            GEOMETRY_SPACE_TEST_DIR=str(artifacts / 'space'),
            GEOMETRY_SOURCE_NAVIGATION_SCREENSHOT_DIR=str(artifacts / 'source-navigation'),
            PYTHONDONTWRITEBYTECODE='1',
        )
        env.update(modifiers)
        command = ['node', 'geometry-web/' + script]
        print(json.dumps({'scope': scope, 'state': 'starting', 'head': expected}), flush=True)
        result = subprocess.run(command, cwd=ROOT, env=env)
        print(json.dumps({'scope': scope, 'exitCode': result.returncode}), flush=True)
        if result.returncode:
            return result.returncode
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
