import ast, asyncio, hashlib, json, subprocess, sys, traceback
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import urlopen
from playwright.async_api import async_playwright

ROOT=Path('/workspace/geometry-final')
BASE=Path(__file__).resolve().parent
FIXTURE_HARNESS=BASE/'browser_probe.py'
SETUP=next(n.value for n in ast.walk(ast.parse(FIXTURE_HARNESS.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('async scene=>'))
URL='http://127.0.0.1:8834/'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity():
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True), 'sourceSha256':sha(ROOT/'geometry-web/space-workspace.js'),'harnessSha256':sha(__file__),'setupHarnessSha256':sha(FIXTURE_HARNESS),'runtime':json.load(urlopen(URL+'runtime'))}
GATE="""()=>{const original=apiRequest,g=window.__lifeGate={held:false,done:false};const gate=new Promise(resolve=>g.release=resolve);g.restore=()=>apiRequest=original;apiRequest=async(...args)=>{const r=await original(...args);if(args[0]==='section-profile-read'&&!g.held){g.held=true;g.native=r;await gate;}return r;};g.pending=SectionProfileWorkspace.refreshLibrary().finally(()=>g.done=true);} """
SNAP="""async()=>({dump:(await api('dump')).text,models:ReferenceWorkspace.getSpaceModels(),project:ReferenceWorkspace.getProjectState(),dirty:ReferenceWorkspace.context().dirty,history:{undo:ReferenceWorkspace.history.undo.length,redo:ReferenceWorkspace.history.redo.length,frame:ReferenceWorkspace.history.frame}})"""
async def run(label):
    out=BASE/label;out.mkdir(exist_ok=False)
    result={'command':['python3',__file__,label],'started':datetime.now(timezone.utc).isoformat(),'beforeIdentity':identity(),'cases':[],'browserErrors':[],'scope':'Bounded real browser/native library lifecycle checks. Fixture uses real model producer and native preview/confirm APIs; only actual read response observation is held. Does not replace canonical CDP.'}
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':1400,'height':900})
        page.on('pageerror',lambda e:result['browserErrors'].append(str(e)))
        async def accept_dialog(dialog):
            result.setdefault('acceptedTestDialogs',[]).append({'type':dialog.type,'message':dialog.message})
            await dialog.accept()
        page.on('dialog',accept_dialog)
        def check(name,condition,observed):
            result['cases'].append({'name':name,'passed':bool(condition),'observed':observed})
            if not condition:raise AssertionError(name)
        try:
            await page.goto(URL);await page.wait_for_function("typeof SpaceModelWorkspace==='object'&&connection.phase==='ready'")
            await page.evaluate(SETUP,(ROOT/'_p2_source_navigation.scene').read_text())
            created=await page.evaluate("""async()=>{const read=await apiRequest('section-profile-read'),data={schema:'section-profile-transaction/1',expectedRevision:read.revision,operations:[{op:'put-profile',value:{id:1,name:'lifecycle profile',outline:[[0,0],[40,0],[40,40],[0,40]]}},{op:'put-run',value:{id:1,profileId:1,length:{kind:'literal',value:100},placement:{kind:'advanced',origin:[0,0,0],N:'+Y',V:'-Z'}}}]};const r=await fetch('/section-profile/preview',{method:'POST',headers:{'Content-Type':'application/json','X-Geometry-Version':pageRuntimeVersion},body:JSON.stringify(data)});const preview=await r.json();if(!preview.preview?.valid)throw Error(JSON.stringify(preview));const confirm=await apiRequest('section-profile-confirm '+preview.preview.token);if(!confirm.ok)throw Error(JSON.stringify(confirm));await SectionProfileWorkspace.refreshLibrary();SpaceModelWorkspace.openLibrary();return {preview,confirm};}""")
            (out/'real-run-transaction.json').write_text(json.dumps(created,ensure_ascii=False,indent=2)+'\n')
            await page.wait_for_function("document.querySelector('#smLibraryList [data-sp-open-run=\"1\"]')&&$('smModelCount').textContent==='3'")
            await page.locator('#smLibraryList [data-sp-open-run="1"]').click()
            await page.wait_for_function("$('sectionProfileWorkspace').open&&!$('spExportModel').disabled")
            opened=await page.evaluate("({profileDialog:$('sectionProfileWorkspace').open,libraryDialog:$('smWorkspace').open,summary:$('spModelSummary').textContent})")
            check('placed run remains naturally operable from mixed library',opened['profileDialog'] and not opened['libraryDialog'],opened)
            await page.screenshot(path=str(out/'run-open.png'))
            await page.locator('#spClose').click()
            await page.evaluate('SpaceModelWorkspace.openLibrary()');await page.evaluate('SectionProfileWorkspace.refreshLibrary()')
            await page.evaluate(GATE);await page.wait_for_function('__lifeGate.held')
            before=await page.evaluate(SNAP)
            await page.locator('#smClose').click()
            await page.evaluate('__lifeGate.restore();__lifeGate.release()');await page.wait_for_function('__lifeGate.done')
            closed=await page.evaluate("({closed:!$('smWorkspace').open,profileClosed:!$('sectionProfileWorkspace').open,models:ReferenceWorkspace.getSpaceModels().map(x=>x.id),runs:[...document.querySelectorAll('#smLibraryList [data-sp-open-run]')].map(x=>x.dataset.spOpenRun),count:$('smModelCount').textContent})")
            check('late refresh after natural close never revives library or changes durable context',closed['closed'] and closed['profileClosed'] and closed['models']==['p85-a','p85-b'] and closed['runs']==['1'] and closed['count']=='3' and before==await page.evaluate(SNAP),closed)
            await page.evaluate('SpaceModelWorkspace.openLibrary()');await page.evaluate('SectionProfileWorkspace.refreshLibrary()')
            await page.evaluate(GATE);await page.wait_for_function('__lifeGate.held')
            held=await page.evaluate('__lifeGate.native')
            check('old owner response genuinely contains the placed run',held['ok'] and len(held['state']['runs'])==1,held)
            await page.evaluate('async()=>{SpaceModelWorkspace.close();return await ReferenceWorkspace.newProject();}')
            await page.evaluate('SectionProfileWorkspace.refreshLibrary()')
            newBefore=await page.evaluate(SNAP)
            await page.evaluate('SpaceModelWorkspace.openLibrary()');await page.evaluate('SectionProfileWorkspace.refreshLibrary()')
            await page.evaluate('__lifeGate.restore();__lifeGate.release()');await page.wait_for_function('__lifeGate.done')
            empty=await page.evaluate("({models:ReferenceWorkspace.getSpaceModels().map(x=>x.id),runs:[...document.querySelectorAll('#smLibraryList [data-sp-open-run]')].map(x=>x.dataset.spOpenRun),count:$('smModelCount').textContent,outerCount:$('spaceModelCount').textContent,empty:document.querySelectorAll('#smLibraryList .sm-library-empty').length,cards:document.querySelectorAll('#smLibraryList .sm-model-card').length})")
            check('late old-context response cannot revive either duplicate saved model or placed run',empty=={'models':[],'runs':[],'count':'0','outerCount':'0','empty':1,'cards':0} and newBefore==await page.evaluate(SNAP),empty)
            await page.screenshot(path=str(out/'new-context-empty.png'))
            check('browser remained free of uncaught exceptions',not result['browserErrors'],result['browserErrors'])
            result['completed']=True
        except Exception as error:
            result['completed']=False;result['error']=repr(error);result['traceback']=traceback.format_exc()
            await page.screenshot(path=str(out/'failure.png'))
        finally:
            result['afterIdentity']=identity();result['finished']=datetime.now(timezone.utc).isoformat();result['passed']=sum(c['passed'] for c in result['cases']);result['failed']=sum(not c['passed'] for c in result['cases']);result['stableIdentity']=result['beforeIdentity']==result['afterIdentity'];result['exitCode']=0 if result['completed'] and result['stableIdentity'] else 1
            (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False));await browser.close()
    return result['exitCode']
if __name__=='__main__':sys.exit(asyncio.run(run(sys.argv[1])))
