import datetime,hashlib,json,os,pathlib,re,subprocess,sys
R=pathlib.Path('/workspace/geometry-final'); S=pathlib.Path('/workspace/scratch/geometry-all-closeout'); O=S/'library-race-impact-459478e'
O.mkdir(exist_ok=True)
A='3c65cedc062a32209fd4e6f1a083da98749fba8d'; B='f23a65a764974f71a8f05d293ca8dc2340049f06'; C='459478e9f68fe8ee9252a5f6b4a1ffb2213a5207'
P='geometry-web/space-workspace.js'; T='geometry-web/source_navigation_test.js'
def git(*args,binary=False):
 p=subprocess.run(['git',*args],cwd=R,capture_output=True,check=True);return p.stdout if binary else p.stdout.decode().strip()
def h(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def ref(p):p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
def tree(rev):
 d={}
 for x in git('ls-tree','-r','-z','--full-tree',rev,binary=True).split(b'\0'):
  if x:
   a,p=x.split(b'\t',1);mode,kind,oid=a.decode().split();d[p.decode()]={'mode':mode,'kind':kind,'blob':oid}
 return d
trees={k:tree(k) for k in [A,B,C]}
def delta(x,y):return {p:{'before':trees[x].get(p),'after':trees[y].get(p)} for p in sorted(trees[x].keys()|trees[y].keys()) if trees[x].get(p)!=trees[y].get(p)}
changesBC=delta(B,C);changesAC=delta(A,C)
diffs={}
for x,y,n in [(B,C,'f23-to-459.diff'),(A,C,'3c-to-459.diff')]:
 d=git('diff','--no-ext-diff','--no-color',x,y,binary=True);(O/n).write_bytes(d);diffs[n]={'sha256':h(d),'bytes':len(d)}
sys.path.insert(0,str(R/'geometry-web'));import runtime_version
sys.path.insert(0,str(R/'tests'));import binaries,mutate
binaries.OUT_DIR=pathlib.Path('/tmp/geometry-final-native')
paths=[p.relative_to(R).as_posix() for p in runtime_version.source_files(R)]
assert all(p in trees[k] and trees[k][p]['mode']=='100644' for p in paths for k in [A,B,C])
oids=sorted({trees[k][p]['blob'] for k in [A,B,C] for p in paths})
data=subprocess.run(['git','cat-file','--batch'],cwd=R,input=(''.join(x+'\n' for x in oids)).encode(),capture_output=True,check=True).stdout
pos=0;blobs={}
for expected in oids:
 end=data.index(b'\n',pos);oid,kind,size=data[pos:end].decode().split();size=int(size);assert oid==expected and kind=='blob'
 start=end+1;blobs[oid]=data[start:start+size];pos=start+size+1
assert pos==len(data)
versions={k:runtime_version._content_version(R,[(R/p,blobs[trees[k][p]['blob']]) for p in paths]) for k in [A,B,C]}
runtimeFiles=[]
for p in paths:
 d={'path':p,'versions':{k:{'blob':trees[k][p]['blob'],'rawSha256':h(blobs[trees[k][p]['blob']]),'runtimeIdentitySha256':h(runtime_version._identity_content(R,R/p,blobs[trees[k][p]['blob']]))} for k in [A,B,C]},'currentWorktreeEqualsFinalBlob':(R/p).read_bytes()==blobs[trees[C][p]['blob']]}
 runtimeFiles.append(d)
aggdir=S/'final-native-retry'; ab=read(aggdir/'aggregate-before-identity.json');aa=read(aggdir/'aggregate-after-identity.json');ar=read(aggdir/'aggregate-execution.json'); audit=read(aggdir/'aggregate-independent-review.json')
native={}
for b in binaries.REGISTRY:
 if not b.applicable():continue
 fp,files,cmd=binaries.compute_fingerprint(b);d={'fingerprint':fp,'files':files,'command':cmd}
 d['equalsActualAggregateClosure']=all(d[k]==ab['binarySources'][b.name][k] for k in ['fingerprint','files','command']);native[b.name]=d
aggDelta=[p for p,old in aa['trackedFilesSha256'].items() if not (R/p).exists() or h((R/p).read_bytes())!=old]
harnesses=sorted(p for p in trees[C] if (p.startswith('tests/') and pathlib.Path(p).suffix in {'.py','.js','.cjs','.mjs','.scene','.json'}) or (p.startswith('geometry-web/') and (p.endswith('_test.js') or p.endswith('_check.js') or p.endswith('_browser_test.py'))))
harnessRecords=[{'path':p,'threeCBlob':trees[A].get(p,{}).get('blob'),'priorF23Blob':trees[B].get(p,{}).get('blob'),'finalBlob':trees[C][p]['blob']} for p in harnesses]
mb=read(S/'final-native/mutation-before.json');ms=mutate.Sources(R);oracle=mutate.oracle_hash();tool=mutate.tool_hash();mr=R/'tests/mutants_results.json'
mcheck=subprocess.run([sys.executable,'tests/mutate.py','--check'],cwd=R,env={**os.environ,'MUTATE_CACHE':'/tmp/geometry-final-native/mutants'},capture_output=True,text=True)
(O/'mutation-readonly-check.log').write_text(mcheck.stdout+mcheck.stderr);(O/'mutation-readonly-check.exit').write_text(str(mcheck.returncode)+'\n')

G='geometry-web/cdp_sections.golden.json';earlier={'geometry-web/engineering-workspace.js','geometry-web/engineering_workflow_test.js'}
expectedBC={P,T,G};expectedAC=expectedBC|earlier
oldNav=git('show',B+':'+T);newNav=git('show',C+':'+T)
oldCheckLines=[x.strip() for x in oldNav.splitlines() if re.search(r'\bcheck\(',x)]
newCheckLines=[x.strip() for x in newNav.splitlines() if re.search(r'\bcheck\(',x)]
newOnlyLines=[x for x in newCheckLines if x not in oldCheckLines]
keptOldLines=[x for x in newCheckLines if x in oldCheckLines]
oldGolden=json.loads(git('show',B+':'+G));newGolden=json.loads(git('show',C+':'+G))
goldenKeys=oldGolden['sections'].keys()|newGolden['sections'].keys()
goldenDelta={k:{'before':oldGolden['sections'].get(k),'after':newGolden['sections'].get(k)} for k in goldenKeys if oldGolden['sections'].get(k)!=newGolden['sections'].get(k)}
checks=[]
def ck(n,ok,detail=None):checks.append({'name':n,'pass':bool(ok),'detail':detail})
ck('exact final HEAD clean',git('rev-parse','HEAD')==C and git('status','--porcelain=v1')=='')
ck('f23 to459 exact product library plus regression plus golden',set(changesBC)==expectedBC,changesBC)
ck('3c to459 exact five paths',set(changesAC)==expectedAC,changesAC)
ck('runtime catalog430 unique tracked regular files',len(paths)==len(set(paths))==430)
ck('all current runtime bytes equal final exact Git blobs',all(x['currentWorktreeEqualsFinalBlob'] for x in runtimeFiles))
ck('independent initial andf23 runtime identities match original receipts',versions[A]=='cef147968bf1f869086317708fbc99bf24dbbbee3275f6448a23cc2cc82f95e1' and versions[B]=='24c5ac8dce8b3f590d014d2f5094c64ba138db6e7b56783b9390c8e567831351')
ck('actual final runtime source_version equals independent Git reconstruction',runtime_version.source_version(R)==versions[C])
ck('only expected catalog sources changed sincef23',{p for p in paths if trees[B][p]!=trees[C][p]}=={P,T})
ck('all other tracked test harness and fixture blobs unchanged sincef23',all(x['priorF23Blob']==x['finalBlob'] for x in harnessRecords if x['path']!=T))
ck('original P85 check statements kept byte-for-byte in original order',oldCheckLines==keptOldLines,{'beforeStatements':len(oldCheckLines),'retainedStatements':len(keptOldLines)})
ck('exactly two new P85 check statements',len(newOnlyLines)==2 and all('late profile read preserves' in x for x in newOnlyLines),newOnlyLines)
loops=["for(const [name,options,width] of [['canvas',{},1400],['open10',{open:true},1400],['zero',{open:true,zero:true},1400],['mobile',{open:true},390]])","for(const mode of ['cancel','page','reuse','missing'])","for(const stage of ['render','final'])for(const action of ['collapse','close','switch'])"]
ck('all original case loop enumerations preserved',all(x in oldNav and x in newNav for x in loops))
ck('golden only P85 increases29to31 and total2175to2177',goldenDelta=={'P85':{'before':29,'after':31}} and oldGolden['total']==2175 and newGolden['total']==2177 and {k:v for k,v in oldGolden.items() if k not in ['sections','total']}=={k:v for k,v in newGolden.items() if k not in ['sections','total']},goldenDelta)
ck('new full golden equals independent sum of unchanged sections plus2',sum(newGolden['sections'].values())==2177 and len(newGolden['sections'])==len(oldGolden['sections']))
ck('all applicable native binary fingerprint files commands unchanged since07b aggregate',all(x['equalsActualAggregateClosure'] for x in native.values()))
ck('existing tracked-file delta from aggregate actual after-state exactly five paths',set(aggDelta)==expectedAC,aggDelta)
ck('aggregate runner registration and expected floor bytes match execution records',all(h((R/p).read_bytes())==aa['trackedFilesSha256'][p] for p in ['tests/run_all.py','tests/run_all.expected.json']) and (R/'tests/run_all.expected.json').read_bytes()==(aggdir/'aggregate-expected-after.json').read_bytes())
ck('mutation source closure oracle and tool unchanged since935 execution',ms.closure==mb['closure_sha256'] and oracle==mb['oracle_sha256'] and tool==mb['tool_sha256'])
ck('formal mutation result bytes unchanged',h(mr.read_bytes())=='3065fc03773c326b9256a7ffeb05cd602cd254dcab2d267626abc42101f38392')
ck('read-only mutation --check exit0 no mutants executed',mcheck.returncode==0,mcheck.stdout)
ck('aggregate driver and wrapper bytes unchanged',h((S/'run_final_native.py').read_bytes())==ab['driverSha256'] and h((aggdir/'run_aggregate.py').read_bytes())==ab['wrapperSha256'])
baseline=read(S/'p85-library-race/baseline-f23/result.json');fixed=read(S/'p85-library-race/fixed-development/result.json')
ck('same exact probe reproduces baseline and retains cards after fix',baseline['identity']['harnessSha256']==fixed['identity']['harnessSha256'] and baseline['raceObserved'] is True and fixed['raceObserved'] is False and all(fixed['after'][k] is True for k in ['oldCardConnected','oldDetailConnected','sameCard','sameDetail','detailOpen','sourceLocate']))
ck('development observed product bytes equal final committed product',fixed['identity']['sourceSha256']==h((R/P).read_bytes()))
ck('f23 prior proof stays byte-for-byte preserved',h((S/'renderer-impact-f23a65a/change-impact.json').read_bytes())=='90a1c54450a7c084e8bb09a18e3954d6e0c596b52fdaf60a04f4f0ec10f13e77')
red=[]
for rel in ['root-browser/cdp-full-receipt/receipt.json','root-browser-retry/cdp-full-receipt/receipt.json','root-browser-final-f23/cdp-full-receipt/receipt.json']:
 p=S/rel;r=read(p);lp=pathlib.Path(r['log']['path']);ls=lp.read_text().splitlines();result=next((json.loads(x[len('CDP_RESULT '):]) for x in ls if x.startswith('CDP_RESULT ')),None)
 red.append({'receipt':ref(p),'actualHead':r['before']['git']['head'],'beforeStatus':r['before']['git']['status'],'afterStatus':r['after']['git']['status'],'exitCode':r['execution']['exitCode'],'status':r['status'],'executionVerified':r['executionVerified'],'log':ref(lp),'canonicalResult':result})
ck('three original fullCDP red attempts kept incomplete exit1',len(red)==3 and all(x['exitCode']==1 and x['canonicalResult']['completed'] is False for x in red))
ck('final source stays clean no repository writes',git('rev-parse','HEAD')==C and git('status','--porcelain=v1')=='')
planned=[{'id':'full-cdp','required':2177},{'id':'P80P81P85','required':68,'sections':{'P80':23,'P81':14,'P85':31}},{'id':'canonical-room','required':120},{'id':'room-diagnostic','required':36},{'id':'space','required':228},{'id':'model-history','required':35},{'id':'save-roundtrip','required':33},{'id':'q38-fresh-browser-save','required':18},{'id':'q38-ui','required':68}]
doc={'schema':'geometry-library-race-change-impact/1','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'overallSourceChecksPassed':all(x['pass'] for x in checks),'checks':checks,'source':{'originalFormalHead':A,'priorRendererFixHead':B,'finalHead':C,'finalTree':git('rev-parse',C+'^{tree}'),'trackedFileCounts':{k:len(trees[k]) for k in [A,B,C]},'changesF23To459':changesBC,'changes3cTo459':changesAC,'exactDiffs':diffs,'productEquivalentTo3c':False,'productEquivalentToF23':False},'impact':{'classification':'Second late product fix, confined to space-model library rendering; original engineering renderer fix and prior P69 test oracle change remain present.','rootCause':'An asynchronously returning Q38 section-profile read dispatched library-changed and rebuilt all saved-model cards. It detached the open source inspector; its in-flight native source result no longer had a live owner. Native timber7→placement20→boundary1 remained correct.','fix':'sectionProfileLibraryList updates only Q38 run cards, count and empty state. Existing saved-model cards and SourceInspector DOM remain intact. Added Q38 run buttons use the existing disabled state and libraryActionAllowed(view) guard. Real saved-model changes still use libraryList; source/project/owner cancellation guards are unchanged.','changedProductFilesSince3c':['geometry-web/engineering-workspace.js',P],'changedTestFilesSince3c':['geometry-web/engineering_workflow_test.js',T,G],'scopeLimits':['Runtime/product bytes changed; this is not a blanket equivalent-source claim for old browser receipts.','Native binary closures, aggregate runner/floors and mutation oracle/tool/results unchanged; entire served-runtime closure differs.','New formal affected gates are tracked separately and must actually run exact finalhead. Current source audit is not a full-browser pass.']},'runtime':{'method':'Exact Git blobs for unchanged430-path catalog; unchanged runtime_version normalization; working bytes matched exact final commit.','versions':versions,'sourceFileCount':len(paths),'files':runtimeFiles},'harnessAndFixtures':{'count':len(harnessRecords),'files':harnessRecords},'P85Census':{'previous':29,'current':31,'oldCheckStatements':oldCheckLines,'newCheckStatements':newOnlyLines,'originalCaseLoops':loops,'fullGoldenBefore':oldGolden,'fullGoldenAfter':newGolden,'authorization':'Root relayed user-authorized bounded regression increase29→31 and2175→2177; no old checks removed.'},'nativeAggregate':{'actualExecutionHead':ar['executionHead'],'actualExit':ar['exitCode'],'recordedTotals':audit['totals'],'registrySuiteCount':len(ab['registry']),'countedSuiteCount':sum(bool(x['counted']) for x in ab['registry']),'exitOnlySuiteCount':sum(not x['counted'] for x in ab['registry']),'nativeClosures':native,'existingTrackedChangesSinceActualAfter':aggDelta,'runnerSha256':h((R/'tests/run_all.py').read_bytes()),'expectedSha256':h((R/'tests/run_all.expected.json').read_bytes()),'noRerun':True},'mutation':{'actualExecutionHead':mb['head'],'sourceClosure':ms.closure,'sourceFiles':ms.hashes,'oracleHash':oracle,'toolHash':tool,'resultsSha256':h(mr.read_bytes()),'readOnlyCheckExit':mcheck.returncode,'readOnlyCheckLog':ref(O/'mutation-readonly-check.log'),'noMutantsExecuted':True},'raceReproduction':{'baseline':{'file':ref(S/'p85-library-race/baseline-f23/result.json'),'actualIdentity':baseline['identity'],'raceObserved':baseline['raceObserved'],'after':baseline['after']},'fixedDevelopment':{'file':ref(S/'p85-library-race/fixed-development/result.json'),'actualIdentity':fixed['identity'],'raceObserved':fixed['raceObserved'],'after':fixed['after']},'notRelabeledCleanFormal':True},'threeOriginalRedFullCDP':red,'priorProofs':{'f23RendererImpact':ref(S/'renderer-impact-f23a65a/change-impact.json'),'earlierTestOnly3cTo5c':ref(S/'harness-equivalence-5c3d36c/source-equivalence.json'),'independentP85Diagnosis':ref(S/'p85-independent-review/diagnosis.json')},'newHeadExecution':{'statusAtCapture':'pending collection; owners running formal gates','expectedScopes':planned,'newFormalPassClaim':False,'followupFile':'gate-followup.json (produced only after formal result/identity reconciliation)'},'limits':['No suite executed by this audit; only source comparisons and mutation --check read-only.','P85 regression holds a genuine section-profile-read completion; it does not fabricate native graph/model data.','Windows/physical phone/IME/native OS picker and #128 unresolved semantics remain outside this proof.','Before/after source identity does not prove absence of transient changes; each original receipt preserves its own recorded limitation.']}
(O/'change-impact.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
manifest={'schema':'geometry-impact-evidence-manifest/1','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[ref(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='manifest.json']}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':doc['overallSourceChecksPassed'],'failed':[x['name'] for x in checks if not x['pass']],'runtime':versions[C],'files':len(paths),'report':ref(O/'change-impact.json'),'manifest':ref(O/'manifest.json')},ensure_ascii=False))
