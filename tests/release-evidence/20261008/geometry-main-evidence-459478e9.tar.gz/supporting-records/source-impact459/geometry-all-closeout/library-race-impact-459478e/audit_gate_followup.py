import collections,datetime,hashlib,json,pathlib,subprocess
R=pathlib.Path('/workspace/geometry-final');S=pathlib.Path('/workspace/scratch/geometry-all-closeout');O=S/'library-race-impact-459478e';H='459478e9f68fe8ee9252a5f6b4a1ffb2213a5207';V='4f89407fd3b542efa28b5eb5837657105f1244442bd9ee7b6a848e22ab0b65e3'
def h(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def ref(p):p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
checks=[]
def ck(n,v,d=None):checks.append({'name':n,'pass':bool(v),'detail':d})
def gate(name,path,result=None):
 r=read(path);a=r['before'];b=r['after'];lp=pathlib.Path(r['log']['path'])
 ok=r['executionVerified'] is True and r['gateExitCode']==r['execution']['exitCode']==0 and not r['problems'] and not r['execution']['timedOut'] and not r['execution']['interrupted']
 exact=all(x['git']['head']==H and x['git']['status']=='' and x['sourceVersion']==V and x['runtime']['fresh'] is True and x['runtime']['version']==V for x in [a,b])
 stable=all(a['runtime'][k]==b['runtime'][k] for k in ['pid','session','version','root'])
 logMatch=h(lp.read_bytes())==r['log']['sha256'] and lp.stat().st_size==r['log']['bytes']
 ck(name+' clean exacthead stable runtime successful wrapper and exact log',ok and exact and stable and logMatch)
 d={'id':name,'receipt':ref(path),'actualHead':a['git']['head'],'runtimeBefore':a['runtime'],'runtimeAfter':b['runtime'],'sourceStatusBefore':a['git']['status'],'sourceStatusAfter':b['git']['status'],'exitCode':r['execution']['exitCode'],'wrapperExecutionVerified':r['executionVerified'],'wrapperCompletionVerified':r['evidence']['completionVerified'],'releaseApproved':r['releaseApproved'],'rawLog':ref(lp),'command':r['command'],'scope':r['evidence'].get('scope'),'limitations':r['limitations']}
 if result:d['result']=ref(result)
 return r,d
rows=[];delivery=read(S/'save-gates-delivery-459478e.json')
ck('save-delivery exact expected providedSHA',h((S/'save-gates-delivery-459478e.json').read_bytes())=='92699d35a26f721f3b00fca33016662580b3defd80469566ad559f594024a2b5')
for g in delivery['gates']:
 rp=pathlib.Path(g['result']);r,d=gate(g['gate'],g['releaseReceipt'],rp);raw=read(rp);items=raw['checks'];expected=g['expected'];key='ok' if g['gate']=='save-roundtrip' else 'pass'
 census=raw['completed'] is True and raw['passed']==expected==len(items) and raw['failed']==0 and all(x[key] is True for x in items)
 if g['gate']=='model-library-history':
  census=census and raw['expectedAssertions']==expected and dict(collections.Counter(x['case'] for x in items))==raw['expectedCases'] and raw['development'] is False and raw['browserErrors']==[] and raw['consoleErrors']==[]
 else:census=census and raw['expected']==expected and raw['ok'] is True
 ck(g['gate']+' independently complete own census',census)
 ck(g['gate']+' all delivery artifact hashes match',all(pathlib.Path(p).exists() and h(pathlib.Path(p).read_bytes())==sha for p,sha in g['artifactsSha256'].items()))
 harness={'model-library-history':'tests/integration/model_library_history_browser.py','save-roundtrip':'tests/integration/save_roundtrip_acceptance.cjs','q38-fresh-save':'tests/integration/q38_save_roundtrip.py'}[g['gate']]
 blob=subprocess.check_output(['git','show',H+':'+harness],cwd=R);ck(g['gate']+' harness equals exactfinal Git blob',h(blob)==g['harnessSha256'])
 d.update({'expected':expected,'passed':raw['passed'],'failed':raw['failed'],'actualRows':len(items),'censusVerifiedSeparately':census,'harness':{'path':harness,'sha256':h(blob)},'gateLimitations':g['limitations']});rows.append(d)
p=S/'p85-focused-final/timber-schedule-receipt/receipt.json';r,d=gate('P80P81P85',p);c=r['evidence']['canonicalResult']
ck('P80P81P85 exact68 complete23/14/31 no exception/failure/skips',r['evidence']['completionVerified'] and c['completed'] and c['passedAssertions']==68 and c['failedAssertions']==0 and c['sections']=={'P80':23,'P81':14,'P85':31} and c['skipped']==[] and c['uncaughtBrowserExceptions']==0)
ck('P85 provided receiptSHA matches',h(p.read_bytes())=='521129c21917678cb78bd3f366fdbcfc72191c3632c0a6dec34e328d0206b6ce')
d['canonicalResult']=c;rows.append(d)
p=S/'q38-ui/integrated-459478e-01-release/receipt.json';rp=S/'q38-ui/integrated-459478e-01/result.json';r,d=gate('q38-ui',p,rp);raw=read(rp)
ck('q38-ui own fixed68 complete allrows noerrors',raw['ok'] and raw['completed'] and raw['expected']==raw['passed']==len(raw['results'])==68 and all(x['ok'] for x in raw['results']) and raw['errors']==[])
d.update({'expected':68,'passed':68,'censusVerifiedSeparately':True,'saveMode':raw['saveMode']});rows.append(d)
tail=S/'multiroom/final-room-tail-459478e'
for ident,count,section in [('canonical-room',120,{'P79':87,'P84':33}),('canonical-space-full',228,None),('diagnostic-model-tail',36,{'P83':16,'P86':20})]:
 p=tail/ident/'release-receipt/receipt.json';r,d=gate(ident,p)
 if ident=='diagnostic-model-tail':
  log=pathlib.Path(r['log']['path']).read_text();cr=[json.loads(x[len('CDP_RESULT '):]) for x in log.splitlines() if x.startswith('CDP_RESULT ')];assert len(cr)==1;c=cr[0]
  tr=read(tail/ident/'transform.json');original=(tail/ident/'original-cdp-source.js').read_bytes();current=subprocess.check_output(['git','show',H+':geometry-web/cdp_test.js'],cwd=R);rebuilt=original.decode()
  for e in tr['edits']:assert rebuilt.count(e['before'])==e['occurrences'];rebuilt=rebuilt.replace(e['before'],e['after'])
  actual=(tail/ident/'transformed-cdp-source.js').read_bytes()
  ck('diagnostic loader exactthree import-scope edits only',original==current and h(original)==tr['originalSHA256'] and rebuilt.encode()==actual and h(actual)==tr['transformedSHA256'])
  d['transform']=ref(tail/ident/'transform.json');d['scopeClarification']='Diagnostic transformed loader: executes unchanged P83/P86 modules only. ROOM_OUTLINE_ONLY is loader routing, not canonical room coverage. Not fullCDP and no golden comparison.'
 else:c=r['evidence']['canonicalResult'];ck(ident+' wrapper completion verified',r['evidence']['completionVerified'] is True)
 if section:valid=c['completed'] and c['passedAssertions']==count and c['failedAssertions']==0 and c['sections']==section and c['skipped']==[] and c['uncaughtBrowserExceptions']==0
 else:valid=c['completed'] and c['passed']==count and c['failed']==0 and c['completenessProblems']==[] and c['exceptions']==[] and c['consoleErrors']==[] and all(x['completed'] and x['expected']==x['passed'] and x['failed']==0 for x in c['groups'].values())
 ck(ident+' complete exact bounded census',valid);d['canonicalResult']=c;rows.append(d)
remote=read(O/'remote-readback.json')
ck('remote guard unchanged',remote['mainUnchanged'] and remote['prHeadUnchanged'] and remote['bodyUnchanged'] and remote['openCount']==23 and remote['openHeadChanges']=={})
ck('source impact proof unchanged',h((O/'change-impact.json').read_bytes())=='7e3fd4fded25b46b0ec3c6ad50a7465dbfb168b77746226661bec666333b0e0f')
full=S/'root-browser-final-459478e/cdp-full-receipt/receipt.json'
doc={'schema':'geometry-library-race-gate-followup/1','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'sourceVersion':V,'sourceImpact':ref(O/'change-impact.json'),'overallReviewedChecksPassed':all(x['pass'] for x in checks),'checks':checks,'rows':rows,'fullCDP':{'receiptPath':str(full),'terminalExistsAtCapture':full.exists(),'reviewed':False,'status':'pending root completion and independent final2177 census/golden review; no full pass claim'},'remoteReadback':ref(O/'remote-readback.json'),'limits':['This file supplements the immutable source-only proof whose pending field reflected its capture time.','Each row retains actual clean459 head, separate own census and wrapper completion semantics; no summed scenario count.','Diagnostic36 is transformed-loader evidence, not canonical full or room.','No suites rerun by this audit.']}
(O/'gate-followup.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
manifest={'schema':'geometry-impact-evidence-manifest/1','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[ref(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='manifest.json']}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'rows':len(rows),'passed':doc['overallReviewedChecksPassed'],'failed':[x['name'] for x in checks if not x['pass']],'report':ref(O/'gate-followup.json'),'manifest':ref(O/'manifest.json')},ensure_ascii=False))
