import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

base=Path(sys.argv[1]).resolve()
scopes=['canonical-room','diagnostic-model-tail','canonical-space-full']
rows={}
for scope in scopes:
    r=json.loads((base/scope/'scope-receipt.json').read_text())
    g=json.loads((base/scope/'release-receipt/receipt.json').read_text())
    assert r['status']=='pass' and not r['problems'] and r['releaseGateExitCode']==0
    assert g['executionVerified'] is True and g['gateExitCode']==0 and g['execution']['exitCode']==0
    assert g['before']['git']==g['after']['git'] and g['before']['git']['head']==r['head']
    assert r['runtimeBefore']==r['runtimeAfter']
    rows[scope]={'head':r['head'],'scopeReceipt':str(base/scope/'scope-receipt.json'),
        'releaseReceipt':str(base/scope/'release-receipt/receipt.json'),
        'log':str(base/scope/'release-receipt/command.log'),
        'scope':scope,'command':r['command'],'runtime':r['runtimeBefore'],
        'expectedCensus':r['expectedSections'],'passed':sum(r['expectedSections'].values()),
        'result':r['canonicalStructuredResults'][0],'diagnosticTransform':r.get('transform'),
        'sourceSHA256':r['sourceSHA256'],'gateExitCode':g['gateExitCode'],'commandExitCode':g['execution']['exitCode']}
assert len({r['head'] for r in rows.values()})==1
cleanup=json.loads((base/'service-cleanup.json').read_text())
assert cleanup['aliveAfter'] is False
log=(base/'diagnostic-model-tail/release-receipt/command.log').read_text()
producer=[json.loads(s[len('P83_EVIDENCE '):]) for s in log.splitlines() if s.startswith('P83_EVIDENCE ')]
assert len(producer)==1
downloads=Path(producer[0]['downloads'])
assert downloads.is_relative_to('/tmp')
shutil.copytree(downloads,base/'diagnostic-model-tail/producer-downloads')
shutil.copy2(Path(__file__).parent/'run_cdp_room_tail.py',base/'runner.py')
summary={'schema':'geometry-room-tail-summary/1','head':next(iter(rows.values()))['head'],
    'status':'pass','canonicalRoomAssertions':120,'diagnosticModelTailAssertions':36,'canonicalFullSpaceAssertions':228,
    'gates':rows,'serviceCleanup':cleanup,'producerEvidence':producer[0],
    'limitations':['Room-only canonical scope is P79/P84, not complete CDP.',
        'P83/P86 used an explicitly transformed diagnostic loader; source and exact three-line diff retained.',
        'Full Space is canonical unfiltered; full CDP is independently owned by root.',
        'No physical phone or OS-picker claim; mixed trusted UI and programmatic/native fixture integration.',
        'Archive excludes browser profile caches; includes receipts, logs, screenshots, real producer downloads and transformation sources.']}
(base/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files=[f for f in sorted(base.rglob('*')) if f.is_file() and 'chrome-profile' not in f.parts
    and f.name not in {'evidence.tar.gz','artifact-manifest.json'}]
manifest={str(f.relative_to(base)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(base/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=base/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for file in [*files,base/'artifact-manifest.json']:
        t.add(file,arcname=str(file.relative_to(base)))
print(json.dumps({'summary':str(base/'summary.json'),'archive':str(archive),'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+1,'census':[120,36,228]}))
