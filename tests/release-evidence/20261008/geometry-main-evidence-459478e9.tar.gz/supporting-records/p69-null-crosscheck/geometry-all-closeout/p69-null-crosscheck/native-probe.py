import copy,hashlib,json,os,resource,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/workspace/geometry-final');OUT=Path(__file__).resolve().parent
os.environ['GEOMETRY_TEST_BRIDGE']='/tmp/geometry-final-native/bridge'
resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,resource.RLIM_INFINITY))
sys.path.insert(0,str(ROOT))
from tests._bridge import BridgeSession
from tests.test_engineering_core import EngineeringCore
from tests.test_parameters_core import card,field
from tests.test_assembly_generation import Generation
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'bridgeSha256':sha(os.environ['GEOMETRY_TEST_BRIDGE'])}
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
started=datetime.now(timezone.utc).isoformat();before_identity=identity();trace=[]
with BridgeSession(os.environ['GEOMETRY_TEST_BRIDGE'],cwd=OUT) as bridge:
    def cmd(c):
        r=bridge.command(c);trace.append({'command':c,'response':r});return r
    def preview(ops):
        p=OUT/'parameter-request.json';p.write_text(json.dumps({'schema':'engineering-transaction/1','expectedRevision':cmd('engineering-read')['revision'],'operations':ops}))
        r=cmd('engineering-preview '+str(p));assert r['ok'];return r['preview']
    def apply(ops):
        p=preview(ops);assert p['valid'],p;assert cmd('engineering-confirm '+str(p['token']))['ok']
    assert cmd('reset')['ok']
    for line in ['surface 1 origin 0 0 2500 u +x v +y outline 0,0 4000,0 4000,3000 0,3000','spec Center 1500','guide 0 1 v spec:Center']:
        assert cmd('line '+line)['ok']
    apply(EngineeringCore.seed(None)+[card(),{'op':'set-source','target':{'kind':'grid','id':1,'axis':'u','field':'panel'},'source':{'kind':'parameter','parameterId':1,'fieldId':1}}])
    before=cmd('engineering-read');dump=cmd('dump')
    parameter=preview([card(fields=[field(1,'1'),field(2,'1830')])])
    assert not parameter['valid'];assert parameter['after']['geometry']['guides']==[None]
    assert cmd('engineering-read')==before;assert cmd('dump')==dump
    save('parameter-invalid.json',parameter);save('parameter-trace.json',trace)

class ObservedGeneration(Generation):
    def command(self,c):
        r=super().command(c);self.trace.append({'command':c,'response':r});return r
g=ObservedGeneration();g.trace=[]
try:
    g.setUp();g.apply([g.create()]);before=g.read();dump=g.dump()
    binding=copy.deepcopy(before['state']['bindings'][0]);binding['value']['slots'][0]['A']={'kind':'literal','value':5000}
    assembly=g.request([{'op':'edit-binding','id':binding['value']['id'],'expectedFingerprint':binding['fingerprint'],'value':binding['value']}],False)['preview']
    assert not assembly['valid'],assembly
    assert any(row['after'] is None for row in assembly['impact']['timbers'])
    assert all(isinstance(row,dict) and 'id' in row for kind in ['timbers','guides'] for row in assembly['impact'][kind])
    assert g.read()==before;assert g.dump()==dump
    save('assembly-invalid.json',assembly);save('assembly-trace.json',g.trace)
finally:g.doCleanups()
after_identity=identity();assert before_identity==after_identity
result={'started':started,'finished':datetime.now(timezone.utc).isoformat(),'command':['python3',str(Path(__file__))],'beforeIdentity':before_identity,'afterIdentity':after_identity,'parameterInvalidGuideNull':True,'assemblyNullableTimberAfterRows':[row['id'] for row in assembly['impact']['timbers'] if row['after'] is None],'assemblyAllImpactRowsIdentified':True,'worldDumpRevisionUnchangedBoth':True,'scope':'Two isolated native invalid candidates; no browser service and no aggregate suite.'}
save('native-result.json',result);print(json.dumps(result,ensure_ascii=False))
