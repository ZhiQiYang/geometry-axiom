const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto'),cp=require('child_process'),assert=require('assert').strict;
const ROOT='/workspace/geometry-final',OUT=__dirname,started=new Date().toISOString();
const paths=['geometry-web/parameters.js','geometry-web/assembly-workspace.js','geometry-web/engineering-adapter.js','geometry-web/reference-ui.js'];
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function identity(){return {head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}),sources:Object.fromEntries(paths.map(p=>[p,sha(path.join(ROOT,p))])),harnessSha256:sha(__filename)};}
const beforeIdentity=identity();assert.equal(beforeIdentity.head,'f23a65a764974f71a8f05d293ca8dc2340049f06');assert.equal(beforeIdentity.status,'');
const clone=x=>JSON.parse(JSON.stringify(x)),esc=x=>String(x).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const elements=new Map();function el(id){if(!elements.has(id))elements.set(id,{id,addEventListener(){},setAttribute(){},removeAttribute(){},append(){},dataset:{},querySelectorAll(){return[];}});return elements.get(id);}
const env={window:{addEventListener(){}},ReferenceWorkspace:{escape:esc,context:()=>null},document:{getElementById:el,createElement:()=>el('dialog'),addEventListener(){},body:{append(){}}},oc:{parameters:[],gridSystems:[]},structuredClone,console};
let parameterSource=fs.readFileSync(path.join(ROOT,paths[0]),'utf8');
const end=parameterSource.indexOf('\n})();');assert(end>0);parameterSource=parameterSource.slice(0,end+6);
assert.equal(parameterSource.split('return {value,formatDefinition:expression').length,2);
parameterSource=parameterSource.replace('return {value,formatDefinition:expression','return {probe:{impactHtml,applyFieldResults},value,formatDefinition:expression');
vm.runInNewContext(parameterSource,env,{filename:paths[0]});
const adapter=fs.readFileSync(path.join(ROOT,paths[2]),'utf8');
const start=adapter.indexOf('  const normalizeRecord = record => {'),finish=adapter.indexOf('  async function read() {',start);
const normalize=vm.runInNewContext(`const clone=x=>JSON.parse(JSON.stringify(x));${adapter.slice(start,finish)};normalize`);
const raw=JSON.parse(fs.readFileSync(path.join(OUT,'parameter-invalid.json'),'utf8'));
const p={...raw,before:normalize(clone(raw.before)),after:normalize(clone(raw.after)),diagnostics:raw.violations};
const state={fresh:false,previewKind:'put',card:{id:1,name:'板材',fields:[{id:1},{id:2}]},failure:null};
const checks=[];function check(name,v){assert.equal(v,true,name);checks.push({name,passed:true});}
check('Real parameter candidate has unavailable guide row',p.valid===false&&p.after.guides[0]===null);
env.window.ParameterUI.probe.applyFieldResults(state,p);
const parameterHtml=env.window.ParameterUI.probe.impactHtml(state,p);
check('Actual parameter renderer handles null guide without TypeError',typeof parameterHtml==='string'&&parameterHtml.length>0);
check('Parameter renderer preserves original I10 native blocker',parameterHtml.includes('I10')&&parameterHtml.includes(esc(raw.violations[0].message)));
const guarded={valid:false,diagnostics:raw.violations};
Object.defineProperty(guarded,'after',{get(){throw Error('invalid branch must not inspect candidate geometry');}});
Object.defineProperty(guarded,'before',{get(){throw Error('invalid branch must not inspect old geometry');}});
check('Invalid parameter renderer exits before any before/after geometry access',typeof env.window.ParameterUI.probe.impactHtml(state,guarded)==='string');

let assemblySource=fs.readFileSync(path.join(ROOT,paths[1]),'utf8');
assert.equal(assemblySource.split('return {open,close,flush,card,inspector,remove,').length,2);
assemblySource=assemblySource.replace('return {open,close,flush,card,inspector,remove,','return {probe:{previewCopy},open,close,flush,card,inspector,remove,');
vm.runInNewContext(assemblySource,env,{filename:paths[1]});
const assembly=JSON.parse(fs.readFileSync(path.join(OUT,'assembly-invalid.json'),'utf8'));
const assemblyHtml=env.window.AssemblyWorkspace.probe.previewCopy(assembly);
check('Actual assembly renderer handles native null timber after geometry',typeof assemblyHtml==='string'&&assemblyHtml.length>0);
check('Assembly renders every unresolved identified timber',assembly.impact.timbers.filter(r=>r.after===null).every(r=>assemblyHtml.includes('角材 #'+r.id)&&assemblyHtml.includes('→ 無')));
check('Assembly impact has identified wrapper rows rather than null slots',['timbers','guides'].every(k=>assembly.impact[k].every(r=>r&&Number.isInteger(r.id))));
check('Assembly source records retain member identity when geometry unavailable',assembly.after.instances.every(i=>i.members.every(m=>Number.isInteger(m.memberId)&&Number.isInteger(m.timberId))));
const afterIdentity=identity();assert.deepEqual(afterIdentity,beforeIdentity);
fs.writeFileSync(path.join(OUT,'parameter-impact.html'),parameterHtml);
fs.writeFileSync(path.join(OUT,'assembly-impact.html'),assemblyHtml);
const result={started,finished:new Date().toISOString(),command:['node',__filename],beforeIdentity,afterIdentity,passed:checks.length,failed:0,checks,limitations:['Actual committed functions executed through external export seams with DOM stubs; this is not a browser gate.','Native fixtures are independently generated real invalid candidates and preserve live World.','Ordinary reference UI reviewed statically: native before-only placed timber list and identified guide wrappers prevent null-row access.']};
fs.writeFileSync(path.join(OUT,'render-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:checks.length,failed:0,head:beforeIdentity.head,harnessSha256:beforeIdentity.harnessSha256}));
