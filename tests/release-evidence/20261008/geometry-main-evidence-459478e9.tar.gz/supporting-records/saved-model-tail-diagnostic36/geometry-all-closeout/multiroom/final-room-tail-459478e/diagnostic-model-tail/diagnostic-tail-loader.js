'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const originalFilename="/workspace/geometry-final/geometry-web/cdp_test.js";
const transformedSource=fs.readFileSync("/workspace/scratch/geometry-all-closeout/multiroom/final-room-tail-459478e/diagnostic-model-tail/transformed-cdp-source.js","utf8");
const loaded=new Module(originalFilename);loaded.filename=originalFilename;loaded.paths=Module._nodeModulePaths(path.dirname(originalFilename));
process.mainModule=loaded;require.cache[originalFilename]=loaded;loaded._compile(transformedSource,originalFilename);loaded.loaded=true;
