import datetime,hashlib,json,os,pathlib,re,subprocess,sys
R=pathlib.Path('/workspace/geometry-final'); S=pathlib.Path('/workspace/scratch/geometry-all-closeout'); O=S/'renderer-impact-f23a65a'
O.mkdir(exist_ok=True)
A='3c65cedc062a32209fd4e6f1a083da98749fba8d'; B='5c3d36ca317cfd085bfb344bfab71de5b2f43992'; C='f23a65a764974f71a8f05d293ca8dc2340049f06'
P='geometry-web/engineering-workspace.js'; T='geometry-web/engineering_workflow_test.js'
def git(*args,binary=False):
 p=subprocess.run(['git',*args],cwd=R,capture_output=True,check=True);return p.stdout if binary else p.stdout.decode().strip()
def h(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def ref(p):p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
def tree(rev):
 d={}
 for x in git('ls-tree','-r','-z','--full-tree',rev,binary=True).split(b'\0'):
  if x:
   a,p=x.split(b'\t',1);mode,kind,oid=a.decode().split();d[p.decode()]={'mode':mode,'kind':kind,'blob':oid}
 return d
trees={k:tree(k) for k in [A,B,C]}
def delta(x,y):return {p:{'before':trees[x].get(p),'after':trees[y].get(p)} for p in sorted(trees[x].keys()|trees[y].keys()) if trees[x].get(p)!=trees[y].get(p)}
changesBC=delta(B,C);changesAC=delta(A,C)
diffs={}
for x,y,n in [(B,C,'5c-to-f23.diff'),(A,C,'3c-to-f23.diff')]:
 d=git('diff','--no-ext-diff','--no-color',x,y,binary=True);(O/n).write_bytes(d);diffs[n]={'sha256':h(d),'bytes':len(d)}
sys.path.insert(0,str(R/'geometry-web'));import runtime_version
sys.path.insert(0,str(R/'tests'));import binaries,mutate
binaries.OUT_DIR=pathlib.Path('/tmp/geometry-final-native')
paths=[p.relative_to(R).as_posix() for p in runtime_version.source_files(R)]
assert all(p in trees[k] and trees[k][p]['mode']=='100644' for p in paths for k in [A,B,C])
oids=sorted({trees[k][p]['blob'] for k in [A,B,C] for p in paths})
data=subprocess.run(['git','cat-file','--batch'],cwd=R,input=(''.join(x+'\n' for x in oids)).encode(),capture_output=True,check=True).stdout
pos=0;blobs={}
for expected in oids:
 end=data.index(b'\n',pos);oid,kind,size=data[pos:end].decode().split();size=int(size);assert oid==expected and kind=='blob'
 start=end+1;blobs[oid]=data[start:start+size];pos=start+size+1
assert pos==len(data)
versions={k:runtime_version._content_version(R,[(R/p,blobs[trees[k][p]['blob']]) for p in paths]) for k in [A,B,C]}
runtimeFiles=[]
for p in paths:
 d={'path':p,'versions':{k:{'blob':trees[k][p]['blob'],'rawSha256':h(blobs[trees[k][p]['blob']]),'runtimeIdentitySha256':h(runtime_version._identity_content(R,R/p,blobs[trees[k][p]['blob']]))} for k in [A,B,C]},'currentWorktreeEqualsFinalBlob':(R/p).read_bytes()==blobs[trees[C][p]['blob']]}
 runtimeFiles.append(d)
aggdir=S/'final-native-retry'; ab=read(aggdir/'aggregate-before-identity.json');aa=read(aggdir/'aggregate-after-identity.json');ar=read(aggdir/'aggregate-execution.json'); audit=read(aggdir/'aggregate-independent-review.json')
native={}
for b in binaries.REGISTRY:
 if not b.applicable():continue
 fp,files,cmd=binaries.compute_fingerprint(b);d={'fingerprint':fp,'files':files,'command':cmd}
 d['equalsActualAggregateClosure']=all(d[k]==ab['binarySources'][b.name][k] for k in ['fingerprint','files','command']);native[b.name]=d
aggDelta=[p for p,old in aa['trackedFilesSha256'].items() if not (R/p).exists() or h((R/p).read_bytes())!=old]
harnesses=sorted(p for p in trees[C] if (p.startswith('tests/') and pathlib.Path(p).suffix in {'.py','.js','.cjs','.mjs','.scene','.json'}) or (p.startswith('geometry-web/') and (p.endswith('_test.js') or p.endswith('_check.js') or p.endswith('_browser_test.py'))))
harnessRecords=[{'path':p,'threeCBlob':trees[A].get(p,{}).get('blob'),'fiveCBlob':trees[B].get(p,{}).get('blob'),'finalBlob':trees[C][p]['blob']} for p in harnesses]
mb=read(S/'final-native/mutation-before.json');ms=mutate.Sources(R);oracle=mutate.oracle_hash();tool=mutate.tool_hash();mr=R/'tests/mutants_results.json'
mcheck=subprocess.run([sys.executable,'tests/mutate.py','--check'],cwd=R,env={**os.environ,'MUTATE_CACHE':'/tmp/geometry-final-native/mutants'},capture_output=True,text=True)
(O/'mutation-readonly-check.log').write_text(mcheck.stdout+mcheck.stderr);(O/'mutation-readonly-check.exit').write_text(str(mcheck.returncode)+'\n')
checks=[]
def ck(n,ok,detail=None):checks.append({'name':n,'pass':bool(ok),'detail':detail})
ck('exact final HEAD clean',git('rev-parse','HEAD')==C and git('status','--porcelain=v1')=='')
ck('5c to f23 only intended PRODUCT renderer file',set(changesBC)=={P},changesBC)
ck('3c to f23 exactly one test oracle and one PRODUCT file',set(changesAC)=={P,T},changesAC)
ck('runtime catalog 430 unique tracked regular files',len(paths)==len(set(paths))==430)
ck('current runtime content equals final exact Git blobs',all(x['currentWorktreeEqualsFinalBlob'] for x in runtimeFiles))
ck('independent runtime versions match all three known formal sources',versions=={A:'cef147968bf1f869086317708fbc99bf24dbbbee3275f6448a23cc2cc82f95e1',B:'80ba31c696e25ae4cb41a50cdfb7f1de3668b128e3f386812e59dca8be7749af',C:'24c5ac8dce8b3f590d014d2f5094c64ba138db6e7b56783b9390c8e567831351'},versions)
ck('actual final runtime source_version matches independent Git reconstruction',runtime_version.source_version(R)==versions[C])
ck('all tracked test harness/fixture blobs unchanged 5c to f23',all(x['fiveCBlob']==x['finalBlob'] for x in harnessRecords))
ck('native binary closure fingerprints/files/commands unchanged since actual07b aggregate',all(x['equalsActualAggregateClosure'] for x in native.values()))
ck('only two existing tracked files differ from aggregate actual after-state',set(aggDelta)=={P,T},aggDelta)
ck('aggregate runner registration and expected floor bytes match executed evidence',all(h((R/p).read_bytes())==aa['trackedFilesSha256'][p] for p in ['tests/run_all.py','tests/run_all.expected.json']) and (R/'tests/run_all.expected.json').read_bytes()==(aggdir/'aggregate-expected-after.json').read_bytes())
ck('mutation source closure/oracle/tool unchanged since actual935 full run',ms.closure==mb['closure_sha256'] and oracle==mb['oracle_sha256'] and tool==mb['tool_sha256'])
ck('formal mutation result bytes unchanged',h(mr.read_bytes())=='3065fc03773c326b9256a7ffeb05cd602cd254dcab2d267626abc42101f38392')
ck('current READ ONLY mutation --check exit0 (no mutants executed)',mcheck.returncode==0,mcheck.stdout)
ck('aggregate driver and wrapper unchanged',h((S/'run_final_native.py').read_bytes())==ab['driverSha256'] and h((aggdir/'run_aggregate.py').read_bytes())==ab['wrapperSha256'])
def wrapper(rel):
 p=S/rel;d=read(p);before=d['before'];after=d['after']
 log=pathlib.Path(d['log']['path']);logok=log.exists() and h(log.read_bytes())==d['log']['sha256'] and log.stat().st_size==d['log']['bytes']
 verified=d['executionVerified'] is True and not d['problems'] and d['gateExitCode']==d['execution']['exitCode']==0 and not d['execution']['timedOut'] and not d['execution']['interrupted']
 clean=all(z['git']['head']==C and z['git']['status']=='' and z['sourceVersion']==versions[C] and z['runtime']['fresh'] is True and z['runtime']['version']==versions[C] for z in [before,after])
 same=all(before['runtime'][k]==after['runtime'][k] for k in ['root','pid','session','version'])
 return d,{'receipt':ref(p),'actualHead':before['git']['head'],'sourceVersion':before['sourceVersion'],'exitCode':d['execution']['exitCode'],'executionVerified':d['executionVerified'],'wrapperCompletionVerified':d['evidence']['completionVerified'],'releaseApproved':d['releaseApproved'],'log':ref(log),'logHashMatchesReceipt':logok,'cleanExactFinalBeforeAfter':clean,'stableRuntimeIdentity':same,'allExecutionChecks':verified and logok and clean and same}
p69,p69out=wrapper('root-engineering-focused-f23/engineering-full-scope-receipt/receipt.json');canonical=p69['evidence']['canonicalResult'];p69out['canonicalResult']=canonical
ck('P69 full section clean exactf23 complete160 no failures/skips',p69out['allExecutionChecks'] and p69['evidence']['completionVerified'] and canonical['completed'] and canonical['passedAssertions']==160 and canonical['failedAssertions']==0 and canonical['sections']=={'P69':160} and canonical['skipped']==[] and canonical['uncaughtBrowserExceptions']==0)
q,qout=wrapper('q38-ui/integrated-f23a65a-01-release/receipt.json');qr=read(S/'q38-ui/integrated-f23a65a-01/result.json');qout['result']=ref(S/'q38-ui/integrated-f23a65a-01/result.json');qout['ownCensus']={'expected':qr['expected'],'passed':qr['passed'],'actualRows':len(qr['results']),'allRowsPassed':all(x['ok'] is True for x in qr['results']),'completed':qr['completed'],'ok':qr['ok'],'errors':qr['errors'],'saveMode':qr['saveMode']}
ck('Q38 UI exactf23 own fixed census68 complete with all rows pass',qout['allExecutionChecks'] and qr['ok'] and qr['completed'] and qr['expected']==qr['passed']==len(qr['results'])==68 and all(x['ok'] for x in qr['results']) and qr['errors']==[])
fc=read(S/'p69-capacity-native-review/counterchecks-f23-result.json')
fcok=fc['beforeIdentity']==fc['afterIdentity'] and fc['beforeIdentity']['head']==C and fc['beforeIdentity']['status']=='' and fc['beforeIdentity']['workspaceSha256']==h((R/P).read_bytes()) and fc['passed']==len(fc['checks'])==17 and fc['failed']==0 and all(x['passed'] for x in fc['checks'])
ck('actual-function seam checks17 tied to exactf23 renderer bytes',fcok)
legacy=[]
for rel in ['space-timber-final/space-full-receipt/receipt.json','space-timber-final/timber-receipt/receipt.json']:
 p=S/rel;d=read(p);legacy.append({'receipt':ref(p),'actualHead':d['before']['git']['head'],'runtime':d['before']['sourceVersion'],'executionVerified':d['executionVerified'],'completionVerified':d['evidence']['completionVerified'],'canonicalResult':d['evidence']['canonicalResult'],'status':'Original actual5c execution retained; not rerun or relabeled f23; shared engineering renderer changed after this execution.'})
remote=read(O/'remote-comparison.json')
ck('remote main and23open head map andPR162 body unchanged',remote['prHeadUnchanged'] and remote['bodyUnchanged'] and remote['mainUnchanged'] and remote['openCount']==23 and remote['openHeadChanges']=={})
ck('no repo writes and final source stays clean',git('rev-parse','HEAD')==C and git('status','--porcelain=v1')=='')
fullpath=S/'root-browser-final-f23/cdp-full-receipt/receipt.json'
doc={'schema':'geometry-renderer-change-impact/1','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'overallPassed':all(x['pass'] for x in checks),'checks':checks,'source':{'initialFormalHead':A,'priorHarnessFixHead':B,'finalHead':C,'finalTree':git('rev-parse',C+'^{tree}'),'trackedFiles':{k:len(trees[k]) for k in [A,B,C]},'changes5cToF23':changesBC,'changes3cToF23':changesAC,'exactDiffs':diffs,'productEquivalent3cToF23':False,'productEquivalent5cToF23':False},'impact':{'classification':'Product renderer fix plus previously documented browser-test oracle correction; NOT test-harness-only equivalence.','changedFunctions':['diffSnapshots','requestPreview'],'affectedCollections':['materials','methods','applications','sources','bindings','grids','guides','timbers'],'behavior':['A null/undefined record in a native candidate collection previously dereferenced target/id and threw before diagnostics could render. The new branch retains exact previous/next raw collection arrays in one unresolved row.','No object identifier or deletion is invented for unresolved slots; complete-record comparison uses the same key and Map algorithm.','A valid=true preview containing any unresolved row is explicitly rejected before state.preview is assigned; invalid native candidates can render their original diagnostics while confirmation remains blocked.','This changes engineering preview/diff presentation and the malformed-valid-candidate guard. C/core, API/transport, persistence, World mutation implementation and all other product blobs are unchanged.'],'scopeLimits':['Shared index.html loads engineering-workspace.js, so all browser receipts have a changed served product asset. Absence of a direct string reference is not a proof of dynamic call-graph non-reachability.','The actual07b aggregate runner, registry, expected floors, native binary closures and registered harness files remain identical. Its entire served-asset runtime fingerprint is NOT identical; aggregate is not claimed rerun atf23.','The3c→5c test-only proof cannot be extended to3c→f23 product equivalence. Retained3c/5c receipt heads and runtime fingerprints stay unchanged.']},'runtime':{'identityMethod':'Unchanged runtime_version.source_files and _identity_content; all430 catalog files independently read as exact Git blobs; public content bytes exact and nonserved sources normalize CRLF per implementation.','versions':versions,'sourceFileCount':len(paths),'files':runtimeFiles},'harnessAndFixtures':{'count':len(harnessRecords),'files':harnessRecords},'nativeAggregate':{'actualExecutionHead':ar['executionHead'],'recordedExit':ar['exitCode'],'recordedTotals':audit['totals'],'recordedSuiteCounts':audit['suiteCounts'],'registeredSuites':ab['registry'],'nativeClosures':native,'existingTrackedChangesSinceActualAfter':aggDelta,'aggregateExecution':ref(aggdir/'aggregate-execution.json'),'aggregateReview':ref(aggdir/'aggregate-independent-review.json'),'expectedSha256':h((R/'tests/run_all.expected.json').read_bytes()),'noAggregateExecutionRerun':True},'mutation':{'actualExecutionHead':mb['head'],'sourceClosure':ms.closure,'sourceFiles':ms.hashes,'oracleHash':oracle,'toolHash':tool,'resultSha256':h(mr.read_bytes()),'readOnlyCheckExit':mcheck.returncode,'readOnlyCheckLog':ref(O/'mutation-readonly-check.log'),'noMutantsExecuted':True},'affectedScopeNewExecution':{'P69':p69out,'Q38UI':qout,'actualFunctions':{'result':ref(S/'p69-capacity-native-review/counterchecks-f23-result.json'),'harness':ref(S/'p69-capacity-native-review/counterchecks-f23.cjs'),'passed':fc['passed'],'failed':fc['failed'],'checks':fc['checks'],'limitations':fc['limitations'],'notBrowserEndToEnd':True}},'retainedPriorExecution':legacy,'fullCDP':{'receiptPath':str(fullpath),'terminalReceiptExistsAtCapture':fullpath.exists(),'status':'not assessed here; awaiting root terminal receipt before any full pass claim','claimComplete':False},'remoteReadback':remote,'limits':['All counts are assertion/check counts with each original scope, not a summed end-to-end scenario total.','No additional certification of Windows, real phone, IME or native OS picker.','This report reads existing evidence and source; only mutation --check was invoked in read-only mode. No tests, mutants or browser suites rerun by this audit.']}
(O/'change-impact.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
manifest={'schema':'geometry-impact-evidence-manifest/1','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[ref(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='manifest.json']}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'overallPassed':doc['overallPassed'],'checks':len(checks),'failed':[x['name'] for x in checks if not x['pass']],'sourceVersion':versions[C],'runtimeFiles':len(paths),'harnessFiles':len(harnesses),'report':ref(O/'change-impact.json'),'manifest':ref(O/'manifest.json')},ensure_ascii=False))
