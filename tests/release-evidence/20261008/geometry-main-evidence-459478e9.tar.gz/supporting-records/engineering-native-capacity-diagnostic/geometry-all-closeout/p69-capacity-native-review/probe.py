import copy
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/workspace/geometry-final')
OUT = Path(__file__).resolve().parent
BINARY = Path('/tmp/geometry-final-native/bridge')
RAW = Path('/workspace/scratch/geometry-all-closeout/root-browser-retry/cdp-full-receipt/command.log')
sys.path.insert(0, str(ROOT))
from tests._bridge import BridgeSession
from tests.test_engineering_core import EngineeringCore
resource.setrlimit(resource.RLIMIT_STACK, (16 * 1024 * 1024, resource.RLIM_INFINITY))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def identity():
    return {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'status': subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),
            'bridgeSha256': sha(BINARY), 'originalRedSha256': sha(RAW)}
def save(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
trace=[]
before_identity=identity()
with BridgeSession(str(BINARY),cwd=OUT) as bridge:
    def cmd(command):
        response=bridge.command(command);trace.append({'command':command,'response':response});return response
    def preview(operations):
        path=OUT/'request.json'
        path.write_text(json.dumps({'schema':'engineering-transaction/1','expectedRevision':cmd('engineering-read')['revision'],'operations':operations}))
        reply=cmd('engineering-preview '+str(path));assert reply['ok'],reply;return reply['preview']
    assert cmd('reset')['ok']
    for line in [
        'surface 1 origin 0 0 2500 u +x v +y outline 0,0 4000,0 4000,3000 0,3000',
        'surface 2 origin 6000 0 2500 u +x v +y outline 0,0 3000,0 3000,3000 0,3000',
        'surface 3 origin 12000 0 2500 u +x v +y outline 0,0 100000,0 100000,3000 0,3000',
        'spec EngineeringCenter 1500','guide 0 1 v spec:EngineeringCenter']:
        assert cmd('line '+line)['ok'],line
    seeded=preview(EngineeringCore.seed(None));assert seeded['valid']
    assert cmd('engineering-confirm '+str(seeded['token']))['ok']
    before=cmd('engineering-read');before_dump=cmd('dump')
    operations=[]
    for identifier in [2,3]:
        app=copy.deepcopy(EngineeringCore.seed(None)[2]['value'])
        app.update(id='application-'+str(identifier),placement_id=identifier)
        operations.extend([{'op':'put-application','value':app},{'op':'bind-grid','id':identifier,'application':app['id'],'create':True}])
    invalid=preview(operations)
    assert invalid['valid'] is False
    null_rows={}
    for side in ['before','after']:
        candidate=invalid[side]
        for prefix,container in [('',candidate),('geometry.',candidate['geometry'])]:
            for key,rows in container.items():
                if isinstance(rows,list):
                    positions=[index for index,row in enumerate(rows) if row is None]
                    if positions:null_rows[side+'.'+prefix+key]=positions
    assert invalid['after']['geometry']['guides']==[None],invalid['after']['geometry']['guides']
    assert invalid['before']['geometry']['guides'][0]['id']==0
    assert cmd('engineering-read')==before
    assert cmd('dump')==before_dump
    rejected=cmd('engineering-confirm '+str(invalid['token']))
    assert not rejected['ok']
    assert cmd('engineering-read')==before
    assert cmd('dump')==before_dump
    after_identity=identity();assert before_identity==after_identity
    result={'beforeIdentity':before_identity,'afterIdentity':after_identity,'nullRows':null_rows,
            'violations':invalid['violations'],'invalidConfirm':rejected,'worldRevisionDumpUnchanged':True,
            'scope':'Isolated actual native three-face batch with pre-existing guide; not a rerun of browser acceptance.'}
    save('preview.json',invalid);save('trace.json',trace);save('result.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
