# P69 invalid-candidate guide row integration failure

Frozen source: `5c3d36ca317cfd085bfb344bfab71de5b2f43992`, clean before and after this read-only investigation. Native bridge SHA256: `386b3549bdc1bfbf251a6eb9ef9ef9ece0f3ecc5c2aa331f725f9d93fe1387b3`.

The second full-CDP red is a separate integration defect from the previous specs oracle drift. Its original command log remains unchanged, SHA256 `c3f4dec16f09f72098d3ea4f8e41a92938df92fceba584aaec98bfc049c9e489`.

## Reproduced native result

`probe.py` starts an isolated native process, creates three faces of width 4000, 3000, and 100000, seeds a valid material/method/application/grid, and retains a guide on the first face referencing EngineeringCenter=1500. A single candidate creates bound grids on the second and third faces. Grid 3 exceeds the existing line capacity.

The actual preview has `valid:false`, an I10 primary message, and the generic I8 candidate-rejected diagnostic. `before.geometry.guides[0]` is the complete guide with id 0; `after.geometry.guides[0]` is `null`. This is the only null array row in this bounded fixture. Both violation records are objects, not null. The live World, revision, definition hash, and complete dump remain unchanged after preview and rejected confirmation. See `preview.json`, `trace.json`, and `result.json`.

## Exact source chain

1. `geometry-core/references.inc:13–22`: `reference_capture_trial` deliberately marks guide geometry unresolved and timbers unplaced after a rejected upstream candidate. The cache clearing predates Q38 (commit `28913c05`).
2. `geometry-web/engineering_bridge.inc:104–106`: Q38 commit `51dde2cf` enabled trial capture for batch preview and retains the rejected trial to disclose actual candidate effects.
3. `geometry-web/reference_bridge.inc:21–25`: `json_reference_guide` emits `null` when the guide is unresolved.
4. `geometry-web/engineering_bridge.inc:58`: candidate engineering geometry includes each guide through that serializer.
5. `geometry-web/engineering-adapter.js:23`: normalization spreads geometry into the top-level snapshot.
6. `geometry-web/engineering-workspace.js:684–686`: `diffSnapshots` maps every guide row through `r.target`, which throws for this native null row before the invalid preview can be displayed.

Native transaction atomicity is intact. The interface must tolerate unavailable candidate geometry while retaining the capacity diagnostic and disabling confirmation. Simply dropping the null row and representing the guide as deleted would misstate the candidate; any fix should distinguish unavailable evaluation from an actual definition removal. No source or shared service was modified here. Parent owns the product change and focused/full browser reruns.
