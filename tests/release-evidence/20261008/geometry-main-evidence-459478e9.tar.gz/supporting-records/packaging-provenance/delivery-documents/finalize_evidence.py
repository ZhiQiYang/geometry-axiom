#!/usr/bin/env python3
"""Plan by default. Final packing requires explicit all-gates-complete approval.
Reads sources only; writes solely to this delivery directory. Never runs gates.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, collections, hashlib, io, json, os, re, shutil, stat, subprocess, tarfile, zlib
ROOT=Path('/workspace/geometry-final')
RAW=Path('/workspace/scratch/geometry-all-closeout')
OUT=Path(__file__).resolve().parent
AUDIT=Path('/workspace/scratch/geometry-evidence-inventory-3c65cedc')
ROOM=Path('/tmp/geometry-final-room-ui-3c65cedc')
CROSS=Path('/tmp/geometry-final-crossflow')
WM=Path('/workspace/scratch/geometry-advance/work-manager')
DEFAULT_FREEZE='459478e9f68fe8ee9252a5f6b4a1ffb2213a5207'
IMPACT=RAW/'renderer-impact-f23a65a/change-impact.json'
LIBRARY_IMPACT=RAW/'library-race-impact-459478e/change-impact.json'
ENGINEERING_CHANGED_PATHS=['geometry-web/engineering-workspace.js','geometry-web/engineering_workflow_test.js']
LIBRARY_CHANGED_PATHS=['geometry-web/cdp_sections.golden.json','geometry-web/source_navigation_test.js','geometry-web/space-workspace.js']
DECLARED_CHANGED_PATHS=sorted(ENGINEERING_CHANGED_PATHS+LIBRARY_CHANGED_PATHS)
FINALIZATION_SUSPENDED=False  # root explicitly confirmed all scopes complete; sealed matrix is required below
ENGINEERING_FIX_HEAD='f23a65a764974f71a8f05d293ca8dc2340049f06'
COLLECTED_DOWNLOADS={}
REVIEW_ARTIFACT_ALIASES={}
ORIGINAL_SHA='d557783696db1112ae5636150b89929a36c8b2feee4f0029af045838b160c4be'
SOURCE_BASE='3c65cedc062a32209fd4e6f1a083da98749fba8d'
SUFFIXES={'.json','.log','.png','.gcanvas','.scene','.stderr','.exit','.txt','.py','.js','.cjs','.md','.diff','.patch','.html','.csv'}
DENY_PARTS={'.git','__pycache__','node_modules','cache','code cache','gpucache','shadercache','component_crx_cache','chrome-profile','browser-profile','profiles','profile','user-data-dir'}
SECRET_PATTERNS={
 'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'github-token':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})',
 'openai-key':rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{35,}',
 'aws-access-id':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'credential-bearing-url':rb'https?://[^\s/"<>:@]{2,}:[^\s/"<>@]{2,}@',
}
def now():return datetime.now(timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def readjson(p):
 try:return json.loads(Path(p).read_text())
 except (OSError,ValueError):return None
def writejson(p,value):Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def at(d,path):
 for k in path.split('.'):
  if not isinstance(d,dict):return None
  d=d.get(k)
 return d
HEAD_FIELDS=['executionHead','before.git.head','before.head','head','identityBefore.head','beforeIdentity.head','identity.head','source.finalHead','beforeHead','resultCommit']
def observed_head(data):
 for key in HEAD_FIELDS:
  v=at(data,key)
  if isinstance(v,str) and re.fullmatch('[0-9a-f]{40}',v):return v
 return None
def observed_status(data):
 for key in ['before.git.status','before.status','identityBefore.status','beforeIdentity.status','identity.status','gitStatus','executionStatusBefore']:
  value=at(data,key)
  if isinstance(value,str):return value
 return None

def passed(data):
 if not isinstance(data,dict):return False
 if data.get('executionVerified') is True:return bool(data.get('finished')) and not data.get('problems')
 if data.get('status')=='pass':return data.get('failed',0)==0 and data.get('passed',data.get('expected'))==data.get('expected',data.get('passed'))
 if data.get('completed') is True:return data.get('failed',0)==0 and data.get('ok',True) is True
 if data.get('pass') is True:return True
 if data.get('schema')=='geometry-renderer-change-impact/1':return data.get('overallPassed') is True and len(data.get('checks',[]))==20 and all(r.get('pass') is True for r in data['checks'])
 if data.get('schema')=='geometry-library-race-change-impact/1':return data.get('overallSourceChecksPassed') is True and len(data.get('checks',[]))==26 and all(r.get('pass') is True for r in data['checks'])
 if data.get('exitCode')==0 and (data.get('ended') or data.get('finished')):return True
 if data.get('schema')=='geometry-work-manager-unit-execution/1':return data.get('exit')==0 and data.get('tests')==data.get('passed') and data.get('failed')==0
 return False

def collect_scattered_downloads(scope, directory):
 log=directory/'cdp-full-receipt/command.log'
 if not log.is_file():return []
 records=[]
 for line_number,line in enumerate(log.read_text().splitlines(),1):
  match=re.match(r'^(.*?)saved artifact (/.+)$',line)
  if not match:continue
  original=Path(match.group(2));record={'scope':scope,'logPath':str(log),'line':line_number,'marker':match.group(1).strip(),'originalPath':str(original)}
  if not original.is_relative_to('/tmp') or not original.parts[2].startswith('geometry-') or any('feedback' in v.lower() for v in original.parts) or original.suffix not in {'.gcanvas','.json','.png'}:
   record['disposition']='omitted-unapproved-path-or-type';records.append(record);continue
  destination=OUT/'scattered-originals'/scope/original.relative_to('/tmp')
  if original.exists():
   if original.is_symlink() or any(p.is_symlink() for p in original.parents):
    record['disposition']='omitted-symlink';records.append(record);continue
   data=original.read_bytes();digest=sha(data)
   if destination.exists() and sha(destination.read_bytes())!=digest:raise ValueError('scattered original changed since its first capture: '+str(original))
   destination.parent.mkdir(parents=True,exist_ok=True)
   if not destination.exists():destination.write_bytes(data)
   record.update(disposition='preserved-exact',originalStillPresent=True,bytes=len(data),sha256=digest,storedCopyPath=str(destination))
  else:
   previous=readjson(OUT/'scattered-download-index.json') or {}
   prior=next((r for r in previous.get('records',[]) if r.get('scope')==scope and r.get('originalPath')==str(original)),None)
   if prior and destination.is_file() and sha(destination.read_bytes())==prior.get('sha256'):
    record.update(disposition='preserved-before-original-cleanup',originalStillPresent=False,bytes=destination.stat().st_size,sha256=prior['sha256'],storedCopyPath=str(destination))
   else:record['disposition']='omitted-original-missing-no-preserved-copy'
  if record.get('storedCopyPath'):COLLECTED_DOWNLOADS[record['storedCopyPath']]=record
  records.append(record)
 return records

def catalog():
 scopes=[]
 def add(id,scope,paths,proofs,kind='accepted-gate',head=None,required=True,harness=None,eq=None):
  scopes.append(dict(id=id,scope=scope,paths=[str(p) for p in paths],proofs=[str(p) for p in proofs],kind=kind,declaredHead=head,required=required,harness=harness or [],sourceEquivalenceRef=eq))
 add('aggregate','82-suite native/Node/Python aggregate; preserve original execution head and named skip census',[RAW/'final-native-retry',RAW/'run_final_native.py'],[RAW/'final-native-retry/aggregate-execution.json'],eq=str(RAW/'final-native-retry/delivery.json'))
 mutation=[p for p in (RAW/'final-native').glob('*') if p.is_file() and (p.name.startswith('mutation-') or p.name in ['mutants_results.json','run_mutation.py','audit_mutation.py','build-runtime.log'])]
 add('mutation','full mutation execution and unchanged result closure',mutation,[RAW/'final-native/mutation-execution.json'],head=at(readjson(RAW/'final-native/mutation-delivery.json'),'executionHead'),eq=str(RAW/'final-native/mutation-delivery.json'))
 for n,count in [('model-history',35),('save-roundtrip',33),('q38-save',18)]:
  add(n,str(count)+' complete rerun cases at clean459478e',[RAW/(n+'-459478e-01'),RAW/(n+'-459478e-01-release'),RAW/(n+'-459478e-01-gate.log')],[RAW/(n+'-459478e-01-release/receipt.json')])
  add('prior-'+n+'-3c','historical'+str(count)+' at clean3c; superseded by459 rerun',[RAW/(n+'-release-01'),RAW/(n+'-release-receipt-01')],[RAW/(n+'-release-receipt-01/receipt.json')],kind='historical-prior-pass',required=False)
 add('q38-ui','68 desktop/mobile authoring, native/model/Save/Open cases at clean459478e',[RAW/'q38-ui/integrated-459478e-01',RAW/'q38-ui/integrated-459478e-01-release'],[RAW/'q38-ui/integrated-459478e-01-release/receipt.json'],harness=['tests/test_section_profile_browser.js'])
 add('q38-restart','13 transport restart/recovery cases; run04 only',[RAW/'q38-restart-recovery-04',RAW/'q38-restart-recovery-receipt-04',RAW/'q38-restart-recovery.py',RAW/'q38-restart-recovery-delivery-5c3d36c.json'],[RAW/'q38-restart-recovery-receipt-04/receipt.json'])
 add('q38-independent-browser','8 independent browser probes including async/read-only guards',[RAW/'q38-review/browser-final',RAW/'q38-review/browser-final-release',RAW/'q38-review/browser_probes.py'],[RAW/'q38-review/browser-final-release/receipt.json'])
 for n,count,harness in [('native',16,'native_probes.py'),('container',6,'container_probes.cjs')]:
  add('q38-independent-'+n,str(count)+' independent '+n+' probes; prior actual execution reused by exact source equivalence',[RAW/f'q38-review/{n}-final',RAW/'q38-review'/harness,RAW/'q38-review/final-source-equivalence.json'],[RAW/f'q38-review/{n}-final/result.json'],eq=str(RAW/'q38-review/final-source-equivalence.json'))
 for n in ['evidence-adapter67','evidence-formal110','feedback38','grid-raw207','grid-reader34']:
  add(n,'canonical scoped '+n+' browser gate',[RAW/'q38-review'/n,RAW/'q38-review'/(n+'-release')],[RAW/'q38-review'/(n+'-release')/'receipt.json'])
 for n in ['acceptance','display','issue77-browser','issue77-exit','issue77-recovery','issue77-remove','keyboard','multiroom','owner-five','pan','worker']:
  p=ROOM/n;d=readjson(p/'receipt.json');h=[d['script']] if isinstance(d,dict) and d.get('script') else []
  add('room-'+n,'room '+n+' exact receipt census',[p],[p/'receipt.json'],harness=h)
 for n in ['rule-case-app','rule-case-component','rule-case-races','scenario-lifecycle','scenario-workflow']:
  add(n,'cross-domain '+n+' exact gate census',[CROSS/n,RAW/'crossflow'/(n+'-receipt'),RAW/'crossflow'/(n+'-census.json')],[RAW/'crossflow'/(n+'-receipt')/'receipt.json'])
 add('prior-space-full-5c','historical228 Space at clean5c; superseded by459 rerun',[RAW/'space-timber-final/space-full-artifacts',RAW/'space-timber-final/space-full-receipt',RAW/'space-timber-final/space-full-invocation.json'],[RAW/'space-timber-final/space-full-receipt/receipt.json'],kind='historical-prior-pass',required=False)
 add('timber','existing timber-support browser gate',[RAW/'space-timber-final/timber-artifacts',RAW/'space-timber-final/timber-receipt',RAW/'space-timber-final/timber-invocation.json'],[RAW/'space-timber-final/timber-receipt/receipt.json'])
 tail=RAW/'multiroom/final-room-tail-459478e'
 for id,n,description in [('room-canonical120','canonical-room','canonical partial room120 (P79=87,P84=33)'),('space-full','canonical-space-full','canonical full Space228 across seven declared groups')]:
  add(id,description,[tail/n],[tail/n/'scope-receipt.json',tail/n/'release-receipt/receipt.json'])
 add('saved-model-tail-diagnostic36','supplement36 (P83=16,P86=20) uses explicit external driver transformation; diagnostic only, not canonical fullCDP or room',[tail/'diagnostic-model-tail'],[tail/'diagnostic-model-tail/scope-receipt.json',tail/'diagnostic-model-tail/release-receipt/receipt.json'],kind='supporting-record')
 add('room-tail-provenance','runner, source hashes and artifact inventory for new120/36/228 scopes; nested duplicate tar omitted',[p for p in tail.iterdir() if p.is_file()]+[RAW/'multiroom/run_cdp_room_tail.py',RAW/'multiroom/collect_room_tail.py'],[],kind='supporting-record',head=DEFAULT_FREEZE,required=False)
 add('timber-source-schedule68','canonical partial P80=23/P81=14/P85=31; retains original29 plus two real delayed-read regression assertions',[RAW/'p85-focused-final'],[RAW/'p85-focused-final/timber-schedule-receipt/receipt.json'])
 race=RAW/'p85-library-race'
 add('library-race-provenance','exact probe/runner and index; baseline/development and supplemental scope identities remain distinct',[p for p in race.iterdir() if p.is_file()],[],kind='supporting-record',required=False)
 for n in ['baseline-f23','fixed-development','lifecycle-final-459','lifecycle-final-459-run2','lifecycle-final-459-run3','lifecycle-final-459-run4']:
  incomplete=n in ['lifecycle-final-459','lifecycle-final-459-run2']
  add('library-race-'+n,('exploratory incomplete Playwright attempt, no formal pass' if incomplete else 'supporting real-response browser probe; original head/dirty identity retained, not a formal gate'),[race/n],[race/n/'result.json'],kind='failure-attempt' if incomplete else 'supporting-record',required=False)
 add('library-node48','48 existing model-store and mocked DOM/history Node contract tests; not a browser gate or aggregate rerun',[RAW/'library-node-459478e'],[RAW/'library-node-459478e/receipt.json',RAW/'library-node-459478e/result.json'])
 add('full-cdp459','canonical full CDP2177 at clean459478e; require complete exact84-section census, one named expected exception and no unexpected exceptions',[RAW/'root-browser-final-459478e',RAW/'run_final_cdp_gate.py',RAW/'root-cdp-final-459478e.log'],[RAW/'root-browser-final-459478e/cdp-full-receipt/receipt.json'],harness=['geometry-web/cdp_sections.golden.json'])
 add('failed-full-cdp-f23','third full CDP RED: 2006 assertions passed, fatal P85, incomplete; never accepted',[RAW/'root-browser-final-f23',RAW/'run_root_cdp_final_f23.py'],[RAW/'root-browser-final-f23/cdp-full-receipt/receipt.json'],kind='failure-attempt',required=False)
 add('engineering-focused160','canonical partial P69 engineering browser scope, exact160; not fullCDP',[RAW/'root-engineering-focused-f23'],[RAW/'root-engineering-focused-f23/engineering-full-scope-receipt/receipt.json'])
 add('engineering-counterchecks17','17 actual production function counterchecks against native unresolved/null geometry fixture',[RAW/'p69-capacity-native-review/counterchecks-f23-result.json',RAW/'p69-capacity-native-review/counterchecks-f23.cjs'],[RAW/'p69-capacity-native-review/counterchecks-f23-result.json'])
 add('engineering-native-capacity-diagnostic','actual native invalid batch/confirm refusal/World unchanged; diagnosis, not browser acceptance',[p for p in (RAW/'p69-capacity-native-review').iterdir() if p.is_file() and not p.name.startswith('counterchecks-')],[RAW/'p69-capacity-native-review/result.json'],kind='supporting-record',required=False)
 add('p69-null-crosscheck','two isolated native fixtures and eight actual-function VM checks; supporting diagnostic, not an additional formal gate',[RAW/'p69-null-crosscheck'],[RAW/'p69-null-crosscheck/native-result.json',RAW/'p69-null-crosscheck/render-result.json'],kind='supporting-record',required=False)
 add('source-impact-f23','bounded two-path change-impact review; explicitly includes product fix; capture-time fullCDP pending is historical snapshot',[IMPACT.parent],[IMPACT],kind='supporting-record',required=False)
 add('source-impact459','bounded three-path library race impact and exact five-path cumulative change; capture-time pending fields are historical snapshots',[LIBRARY_IMPACT.parent],[LIBRARY_IMPACT],kind='supporting-record',required=False)
 for n,label in [('3c65ced','3c'),('f23a65a','f23')]:
  add('prior-q38-ui-'+label,'historical68 at clean'+label+'; retained actual head, superseded by459 rerun',[RAW/('q38-ui/integrated-'+n+'-01'),RAW/('q38-ui/integrated-'+n+'-01-release')],[RAW/('q38-ui/integrated-'+n+'-01-release/receipt.json')],kind='historical-prior-pass',required=False)
 add('save459-provenance','new35/33/18 execution/source index and explicitly audited synthetic service cleanup record',[RAW/'save-gates-delivery-459478e.json',RAW/'service-8836-459478e.json',RAW/'service-8836-459478e.log',RAW/'service-8836-459478e-cleanup.json',RAW/'service-8836-459478e-final-world.scene'],[],kind='supporting-record',head=DEFAULT_FREEZE,required=False)
 add('final-validation-matrix','independent sealed documentary receipt/census reconciliation; not an additional test execution',[RAW/'final-validation-matrix.json'],[RAW/'final-validation-matrix.json'],kind='supporting-record',required=True)
 aliases=[]
 for source,target in [('evidence-adapter','evidence-adapter67'),('evidence-formal','evidence-formal110'),('grid-raw','grid-raw207'),('grid-reader','grid-reader34')]:
  source_root=Path('/tmp/geometry-final-review-gates')/source;target_root=RAW/'q38-review'/target
  for p in sorted(source_root.rglob('*')):
   if not p.is_file() or p.is_symlink():continue
   q=target_root/p.relative_to(source_root)
   if not q.is_file() or q.is_symlink() or sha(p.read_bytes())!=sha(q.read_bytes()):raise ValueError('review artifact staged copy mismatch: '+str(p))
   row={'originalTemporaryPath':str(p),'selectedArchiveSourcePath':str(q),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'scopeRef':target};aliases.append(row);REVIEW_ARTIFACT_ALIASES[str(q)]=row
 writejson(OUT/'review-artifact-copy-index.json',{'schema':'geometry-exact-staged-artifacts/1','capturedAt':now(),'records':aliases,'meaning':'All83 original temp gate artifacts match their selected archived copies byte-for-byte. Do not duplicate temp directories.'})
 add('packaging-provenance','re-runnable finalization script, inclusion policy and exact staged-artifact provenance; no additional test claim',[OUT/'finalize_evidence.py',OUT/'README.md',OUT/'review-artifact-copy-index.json'],[],kind='supporting-record',required=False)
 add('work-manager-unit-public','142 unit tests actually run at clean5c prior head; public summary only, all raw WM data excluded',[RAW/'work-manager-unit-final/public-summary.json'],[RAW/'work-manager-unit-final/public-summary.json'])
 add('work-manager-history-document','documentary facts only: historical66 at dirty477 and six source hashes; no raw execution data',[OUT/'work-manager-public-history.json'],[],kind='supporting-record',head='47750677dc11f98929e232168068b952e05c5abd',required=False)
 # Supporting immutable evidence has no independent pass count.
 add('scope-and-equivalence','gate inventory, source-equivalence, static release identity and visual review',[RAW/'q38-review/canonical-gates-summary.json',RAW/'q38-review/reconciliation.json',RAW/'q38-review/independent-probe-plan.json',RAW/'crossflow/evidence-index.json',RAW/'crossflow/archive-formats.json',RAW/'save-gates-delivery-3c65ced.json',RAW/'final-source-review.json',RAW/'root-visual-review.json',RAW/'multiroom/final-ui-config.json',RAW/'space-timber-final/evidence-index.json',RAW/'space-timber-final/expected-identity.json'],[],kind='supporting-record',required=False)
 # Red evidence remains red, outside successful scopes. No failed bytes are altered.
 add('failed-full-cdp-original','original full CDP RED before oracle correction; keep separate',[RAW/'root-browser',RAW/'run_root_gates.py'],[RAW/'root-browser/cdp-full-receipt/receipt.json'],kind='failure-attempt',required=False)
 add('failed-full-cdp-retry5c','second full CDP RED at5c revealing product null-geometry bug; not the finalf23 run',[RAW/'root-browser-retry',RAW/'run_root_cdp_retry.py'],[RAW/'root-browser-retry/cdp-full-receipt/receipt.json'],kind='failure-attempt',required=False)
 add('p69-oracle-diagnosis','native fixture and counterexamples diagnosing original P69 oracle failure',[RAW/'p69-native-review'],[RAW/'p69-native-review/result.json'],kind='failure-diagnosis',required=False)
 oldagg=[p for p in (RAW/'final-native').glob('aggregate*')]
 add('failed-aggregate-original','original aggregate attempt; later corrected legacy VM fixture',[*oldagg],[RAW/'final-native/aggregate-execution.json'],kind='failure-attempt',required=False)
 for n in ['01','02','03']:
  add('failed-q38-restart-'+n,'restart recovery RED run'+n+'; retained verbatim',[RAW/('q38-restart-recovery-'+n),RAW/('q38-restart-recovery-receipt-'+n),RAW/('q38-restart-recovery-gate-'+n+'.log')],[RAW/('q38-restart-recovery-receipt-'+n)/'receipt.json'],kind='failure-attempt',required=False)
 for p in sorted((RAW/'q38-ui').glob('full-*')):
  d=readjson(p/'result.json')
  if isinstance(d,dict) and d.get('ok') is False:add('failed-q38-ui-'+p.name,'earlier UI/harness development failure; not acceptance',[p],[p/'result.json'],kind='failure-attempt',required=False)
 for p in sorted((RAW/'q38-review').glob('browser-candidate*')):
  if p.is_dir():add('q38-review-history-'+p.name,'independent probe history; never current success census',[p],[p/'result.json'],kind='failure-attempt',required=False)
 downloads=[]
 for scope in scopes:
  if scope['id'].startswith('failed-full-cdp') or scope['id'].startswith('full-cdp'):
   records=collect_scattered_downloads(scope['id'],Path(scope['paths'][0]));downloads.extend(records)
   scope['paths'].extend(r['storedCopyPath'] for r in records if r.get('storedCopyPath'))
 writejson(OUT/'scattered-download-index.json',{'schema':'geometry-canonical-scattered-downloads/1','capturedAt':now(),'records':downloads,'claim':'Exact originals referenced by canonical saved-artifact log lines; missing or excluded paths are explicit. Profiles/feedback paths are excluded by policy.'})
 add('scattered-download-inventory','canonical full-CDP log citations, original paths and exact staged copy hashes',[OUT/'scattered-download-index.json'],[],kind='supporting-record',required=False)
 return scopes

def excluded(p,scope):
 parts=[x.lower() for x in p.parts]
 if p.is_relative_to(WM):return 'all raw work-manager execution data private by AGENTS.md; never bundle'
 if p.is_relative_to(RAW/'work-manager-unit-final') and p.name!='public-summary.json':return 'raw work-manager unit data private; only public-summary allowed'
 if p.is_symlink() or not p.is_file():return 'nonregular or symlink'
 if any(x in DENY_PARTS or x.endswith('-profile') for x in parts):return 'profile/cache/source-control/interpreter state'
 # The feedback38 gate receipt is allowed; a service feedback directory is not.
 if any(x.startswith('geometry-final-feedback') or x in ['feedback','user-data','userdata'] for x in parts):return 'service feedback/user data'
 if p.suffix not in SUFFIXES:return 'not an allowed output/harness type (including native, DB, PDF, nested archive)'
 if (p.name.startswith('service') or p.name in ['server.log','server.json','final-service.log']) and scope['id']!='save459-provenance':return 'service log/metadata'
 if scope['id']=='work-manager':
  if any('state' in x or 'restored' in x for x in p.relative_to(WM).parts) if p.is_relative_to(WM) else False:return 'WM state/SQLite excluded'
  if p.name in ['commands.json','api-before.json','desktop-ui-backup.json','mobile-ui-backup.json'] or p.name.startswith('served-'):return 'WM backup/API state/duplicate served sources excluded'
 if '.partial.' in p.name and scope['kind']=='accepted-gate':return 'partial file is not successful final evidence'
 return None

def files_for(path):
 p=Path(path)
 if p.is_file() or p.is_symlink():return [p]
 if not p.exists():return []
 return sorted(x for x in p.rglob('*') if x.is_file() or x.is_symlink())

def relative_label(p):
 for root,label in [(RAW,'geometry-all-closeout'),(ROOM,ROOM.name),(CROSS,CROSS.name),(WM,'work-manager-original'),(AUDIT,'archive-audit'),(OUT,'delivery-documents')]:
  if p.is_relative_to(root):return label+'/'+p.relative_to(root).as_posix()
 raise ValueError('source outside explicit roots: '+str(p))

def pack_info(data,archive):
 info=tarfile.TarInfo(archive);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';return info

def original_copy():
 p=RAW/'pr162-oracle-evidence.tar.gz';data=p.read_bytes()
 if sha(data)!=ORIGINAL_SHA:raise ValueError('original d557 archive changed')
 dest=OUT/'historical-pr162-d557.tar.gz'
 if dest.exists() and sha(dest.read_bytes())!=ORIGINAL_SHA:raise ValueError('existing original copy mismatch')
 if not dest.exists():dest.write_bytes(data)
 with tarfile.open(fileobj=io.BytesIO(data)) as t:
  members=[{'name':v.name,'bytes':v.size,'type':v.type.decode('ascii','replace')} for v in t.getmembers()]
 obj={'schema':'geometry-original-historical-archive/1','originalPath':str(p),'copiedPath':str(dest),'bytes':len(data),'sha256':ORIGINAL_SHA,'unchanged':True,'separateFromMainBundle':True,'containsNativeExecutables':['oracle/native/bridge','oracle/native/core','oracle/native/model-base'],'members':members,'claim':'Original historical d557 bytes, not rewritten and not a clean final-head run.'}
 writejson(OUT/'historical-pr162-d557.inventory.json',obj);return obj

def build(freeze):
 scopes=catalog();records=[];omissions=[];holds=[];sensitive=[];compressed_estimate=0;seen=set()
 if FINALIZATION_SUSPENDED:holds.append({'scope':'root-all-complete-confirmation','reason':'459478e configuration is installed; root has not confirmed all gates complete. No final archive may be written.'})
 diff=git('diff','--name-only',SOURCE_BASE,freeze).splitlines()
 impact=readjson(IMPACT);library_impact=readjson(LIBRARY_IMPACT)
 equivalence={'schema':'geometry-delivery-change-impact/2','targetFreeze':freeze,'base':SOURCE_BASE,'changedPaths':diff,'matchesDeclaredChangedPaths':diff==DECLARED_CHANGED_PATHS,'containsProductFix':True,'productChangedPaths':['geometry-web/engineering-workspace.js','geometry-web/space-workspace.js'],'testOracleChangedPath':'geometry-web/engineering_workflow_test.js','regressionAndCensusChangedPaths':['geometry-web/source_navigation_test.js','geometry-web/cdp_sections.golden.json'],'sourceImpactProofOriginalPaths':[str(IMPACT),str(LIBRARY_IMPACT)],'sourceImpactProofSha256':{str(p):sha(p.read_bytes()) for p in [IMPACT,LIBRARY_IMPACT] if p.is_file()},'meaning':'Two product changes are explicitly reviewed. This is NOT whole-product source equivalence. Prior scopes retain actual execution heads; only specialized linked native/container/WM proofs assert exact byte equivalence. Engineering160/actual-functions17 remain at f23. New Q38UI68/model-history35/Save33/fresh18/room120/Space228/timber-source68/fullCDP2177 execute at459; supplemental diagnostic36 and race probes remain separately scoped.'}
 impact_valid=isinstance(impact,dict) and impact.get('schema')=='geometry-renderer-change-impact/1' and passed(impact) and at(impact,'source.finalHead')==ENGINEERING_FIX_HEAD and sorted(at(impact,'source.changes3cToF23') or {})==ENGINEERING_CHANGED_PATHS and at(impact,'source.productEquivalent3cToF23') is False and at(impact,'source.productEquivalent5cToF23') is False
 library_valid=isinstance(library_impact,dict) and library_impact.get('schema')=='geometry-library-race-change-impact/1' and passed(library_impact) and at(library_impact,'source.finalHead')==freeze and sorted(at(library_impact,'source.changesF23To459') or {})==LIBRARY_CHANGED_PATHS and sorted(at(library_impact,'source.changes3cTo459') or {})==DECLARED_CHANGED_PATHS and at(library_impact,'source.productEquivalentTo3c') is False and at(library_impact,'source.productEquivalentToF23') is False
 equivalence['priorEngineeringImpactProofValidated']=impact_valid;equivalence['libraryImpactProofValidated']=library_valid
 if not impact_valid:holds.append({'scope':'source-impact-f23','reason':'mandatory bounded product impact proof missing or invalid for exact two-path product change','proofs':[str(IMPACT)]})
 if not library_valid:holds.append({'scope':'source-impact459','reason':'mandatory bounded library product impact proof missing or invalid for exact declared changes','proofs':[str(LIBRARY_IMPACT)]})
 for s in scopes:
  proofdata=[readjson(p) for p in s['proofs']];heads=[observed_head(d) for d in proofdata if d]
  s['executionHead']=s['declaredHead'] or next((h for h in heads if h),None)
  s['executionWorktreeStatus']=next((v for d in proofdata if d for v in [observed_status(d)] if v is not None),None)
  s['completionObserved']=bool(proofdata) and all(passed(d) for d in proofdata)
  s['sourceImpactReviewRef']=str(LIBRARY_IMPACT) if s['executionHead']!=freeze else None
  s['executionRelation']='same-freeze' if s['executionHead']==freeze else 'specialized-source-equivalence-proof-linked' if s['sourceEquivalenceRef'] else 'prior-head-retained-no-global-equivalence'
  if s['id']=='engineering-counterchecks17':
   d=proofdata[0] if proofdata else {};checks=d.get('checks',[]) if isinstance(d,dict) else []
   s['completionObserved']=d.get('passed')==17 and d.get('failed')==0 and len(checks)==17 and len({r.get('name') for r in checks})==17 and all(r.get('passed') is True for r in checks) and at(d,'beforeIdentity.head')==ENGINEERING_FIX_HEAD and at(d,'afterIdentity.head')==ENGINEERING_FIX_HEAD
  if s['id']=='final-validation-matrix':
   d=proofdata[0] if proofdata and isinstance(proofdata[0],dict) else {}
   s['completionObserved']=d.get('schema')=='geometry-final-validation-matrix/1' and d.get('sealed') is True and d.get('reviewHead')==freeze and d.get('pending')==[] and d.get('gaps')==[] and d.get('releaseApproved') is False
  if s['id']=='full-cdp459':
   d=proofdata[0] if proofdata and isinstance(proofdata[0],dict) else {};c=at(d,'evidence.canonicalResult') or {};log=Path(s['paths'][0])/'cdp-full-receipt/command.log';text=log.read_text() if log.is_file() else ''
   golden=json.loads(git('show',freeze+':geometry-web/cdp_sections.golden.json'))
   s['expectedAssertions']=2177
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and at(d,'evidence.completionVerified') is True and c.get('completed') is True and c.get('passedAssertions')==2177 and c.get('failedAssertions')==0 and c.get('skipped')==[] and at(c,'scope.mode')=='full' and at(c,'scope.filters')==[] and at(c,'scope.modifiers')==[] and c.get('goldenCompare')=='matched' and golden.get('total')==2177 and len(golden.get('sections',{}))==84 and c.get('sections')==golden.get('sections') and c.get('uncaughtBrowserExceptions')==1 and len(re.findall(r'^\[EXPECTED EXCEPTION\] Error: fb-auto-probe\s*$',text,re.MULTILINE))==1 and text.count('[EXPECTED EXCEPTION]')==1 and '[UNEXPECTED EXCEPTION]' not in text
  if s['id']=='library-node48':
   d=proofdata[1] if len(proofdata)>1 and isinstance(proofdata[1],dict) else {}
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and d.get('counts')=={'tests':48,'pass':48,'fail':0,'cancelled':0,'skipped':0,'todo':0}
  if s['id']=='q38-ui':
   d=readjson(RAW/'q38-ui/integrated-459478e-01/result.json') or {}
   s['expectedChecks']=68
   rows=d.get('results',[])
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and d.get('completed') is True and d.get('ok') is True and d.get('expected')==68 and d.get('passed')==68 and len(rows)==68 and len({r.get('name') for r in rows})==68 and all(r.get('ok') is True for r in rows) and not d.get('errors')
  if s['id'] in ['model-history','save-roundtrip','q38-save']:
   filename='results.json' if s['id']=='save-roundtrip' else 'result.json';d=readjson(Path(s['paths'][0])/filename) or {};count={'model-history':35,'save-roundtrip':33,'q38-save':18}[s['id']]
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and d.get('completed') is True and d.get('passed')==count and d.get('failed')==0
  if s['id']=='timber-source-schedule68':
   c=at(proofdata[0],'evidence.canonicalResult') if proofdata else {};c=c or {}
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and c.get('completed') is True and c.get('passedAssertions')==68 and c.get('failedAssertions')==0 and c.get('sections')=={'P80':23,'P81':14,'P85':31}
  if s['id'] in ['room-canonical120','space-full','saved-model-tail-diagnostic36']:
   d=proofdata[0] if proofdata and isinstance(proofdata[0],dict) else {};cs=d.get('canonicalStructuredResults',[]);c=cs[0] if len(cs)==1 else {};count={'room-canonical120':120,'space-full':228,'saved-model-tail-diagnostic36':36}[s['id']]
   s['completionObserved']=s['completionObserved'] and s['executionHead']==freeze and c.get('completed') is True and c.get('passedAssertions',c.get('passed'))==count and c.get('failedAssertions',c.get('failed'))==0
  for d in proofdata:
   for command in (d.get('command',[]) if isinstance(d,dict) else []):
    if not isinstance(command,str):continue
    cp=Path(command)
    if cp.is_absolute() and cp.is_relative_to(ROOT):cp=cp.relative_to(ROOT)
    if not cp.is_absolute() and cp.suffix in ['.py','.js','.cjs'] and (ROOT/cp).is_file() and cp.as_posix() not in s['harness']:s['harness'].append(cp.as_posix())
  if (s['kind']=='accepted-gate' or s['required']) and not s['completionObserved']:
   holds.append({'scope':s['id'],'reason':'required completion proof missing or not passing','proofs':s['proofs']});continue
  namespace='failure-attempts' if s['kind'].startswith('failure') else 'accepted-evidence'
  if s['kind']=='supporting-record':namespace='supporting-records'
  if s['kind']=='historical-prior-pass':namespace='historical-prior-passes'
  if s['id']=='work-manager':namespace='historical-source-equivalent'
  for path in s['paths']:
   for p in files_for(path):
    reason=excluded(p,s)
    if reason:omissions.append({'source':str(p),'reason':reason,'scope':s['id']});continue
    st=p.stat();data=p.read_bytes();after=p.stat()
    if data.startswith(b'\x7fELF') or data.startswith(b'MZ'):
     omissions.append({'source':str(p),'reason':'native executable signature','scope':s['id']});continue
    if (st.st_size,st.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):holds.append({'scope':s['id'],'source':str(p),'reason':'source changed during read'});continue
    if p.suffix in {'.json','.log','.txt','.py','.js','.cjs','.md','.stderr','.scene','.html','.diff','.patch'}:
     for key,pat in SECRET_PATTERNS.items():
      count=len(re.findall(pat,data))
      if count:sensitive.append({'source':str(p),'flag':key,'count':count,'matchedValuesOmitted':True})
    archive=namespace+'/'+s['id']+'/'+relative_label(p)
    if archive in seen:continue
    seen.add(archive);compressed_estimate+=len(zlib.compress(data,6))
    records.append({'archivePath':archive,'sourceOriginalPath':str(p),'bytes':len(data),'sha256':sha(data),'mtimeNs':st.st_mtime_ns,'executionHead':s['executionHead'],'executionHeadStatus':'recorded' if s['executionHead'] else 'not recorded in original proof; never inferred','executionWorktreeStatus':s['executionWorktreeStatus'],'scopeRef':s['id'],'proofOriginalPaths':s['proofs'],'classification':s['kind'],'executionRelation':s['executionRelation'],'sourceEquivalenceRef':s['sourceEquivalenceRef'],'sourceImpactReviewRef':s['sourceImpactReviewRef'],'finalHeadRerun':s['executionHead']==freeze and s['kind']=='accepted-gate'})
    if str(p) in REVIEW_ARTIFACT_ALIASES:records[-1]['identicalTemporaryOriginal']=REVIEW_ARTIFACT_ALIASES[str(p)]
  for record in records:
   captured=COLLECTED_DOWNLOADS.get(record['sourceOriginalPath'])
   if captured and 'sourceArchiveReadPath' not in record:
    record['sourceArchiveReadPath']=record['sourceOriginalPath'];record['sourceOriginalPath']=captured['originalPath'];record['canonicalLogCitation']={'path':captured['logPath'],'line':captured['line'],'marker':captured['marker']};record['originalSha256AtCapture']=captured['sha256']
  # Preserve the actual tested harness bytes, addressed by execution Git head.
  for path in s['harness']:
   head=s['executionHead']
   if not head:continue
   try:data=subprocess.check_output(['git','show',head+':'+path],cwd=ROOT,stderr=subprocess.DEVNULL)
   except subprocess.CalledProcessError:continue
   archive=namespace+'/'+s['id']+'/tested-harness/'+path
   compressed_estimate+=len(zlib.compress(data,6))
   records.append({'archivePath':archive,'sourceOriginalPath':'git:'+head+':'+path,'bytes':len(data),'sha256':sha(data),'executionHead':head,'executionWorktreeStatus':s['executionWorktreeStatus'],'scopeRef':s['id'],'proofOriginalPaths':s['proofs'],'classification':'exact-tested-harness','sourceEquivalenceRef':s['sourceEquivalenceRef'],'sourceImpactReviewRef':s['sourceImpactReviewRef'],'finalHeadRerun':head==freeze and s['kind']=='accepted-gate'})
 summary=collections.defaultdict(lambda:{'files':0,'bytes':0})
 for r in records:summary[r['archivePath'].split('/')[0]]['files']+=1;summary[r['archivePath'].split('/')[0]]['bytes']+=r['bytes']
 plan={'schema':'geometry-evidence-delivery-plan/1','createdAt':now(),'isFinal':False,'targetFreeze':freeze,'sourceReadOnly':True,'summary':dict(summary),'sumIndividuallyDeflatedBytesEstimate':compressed_estimate,'tarEstimateCaveat':'Estimate only; final gzip has different dictionary and tar headers. Running gates are held and absent.','holds':holds,'possibleSensitiveFlags':sensitive,'excluded':omissions,'scopeCatalog':scopes,'sourceChangeReview':equivalence,'files':records,'originalHistoricalArchive':original_copy()}
 return plan

def source_bytes(r):
 src=r.get('sourceArchiveReadPath',r['sourceOriginalPath'])
 if src.startswith('git:'):
  _,head,path=src.split(':',2);data=subprocess.check_output(['git','show',head+':'+path],cwd=ROOT)
 else:
  p=Path(src)
  if p.is_symlink() or not p.is_file():raise ValueError('source is no longer regular: '+src)
  data=p.read_bytes()
 if len(data)!=r['bytes'] or sha(data)!=r['sha256']:raise ValueError('source changed since plan: '+src)
 return data

def assign_bundles(records, freeze):
 # Separate the canonical full-CDP scopes, including every RED attempt. Shard
 # by whole files before 70 MiB raw payload, leaving generous room below GitHub's
 # 100 MiB compressed limit. Never split or rewrite an original evidence file.
 limit=70*1024*1024;groups=collections.defaultdict(list)
 for r in records:
  group='full-cdp' if 'full-cdp' in r['scopeRef'] or r['scopeRef']=='scattered-download-inventory' else 'main'
  groups[group].append(r)
 bundles=[]
 for group,rows in sorted(groups.items()):
  parts=[];part=[];size=0
  for r in rows:
   if r['bytes']>limit:raise ValueError('single original needs explicit large-file delivery decision: '+r['sourceOriginalPath'])
   if part and size+r['bytes']>limit:parts.append(part);part=[];size=0
   part.append(r);size+=r['bytes']
  if part:parts.append(part)
  for i,part in enumerate(parts,1):
   suffix=('-part%02d'%i) if len(parts)>1 else ''
   name='geometry-'+group+'-evidence-'+freeze[:8]+suffix+'.tar.gz'
   for r in part:r['bundleName']=name
   bundles.append({'name':name,'scopeFamily':group,'files':len(part),'rawBytes':sum(r['bytes'] for r in part)})
 return bundles

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--freeze',default=DEFAULT_FREEZE);ap.add_argument('--finalize',action='store_true');ap.add_argument('--approval-file',type=Path);ap.add_argument('--plan-while-source-changing',action='store_true');a=ap.parse_args()
 if not re.fullmatch('[0-9a-f]{40}',a.freeze):raise ValueError('explicit 40-hex freeze required')
 identity={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain')}
 if a.finalize and a.plan_while_source_changing:raise ValueError('source-changing planning is never a finalization mode')
 if (identity['head']!=a.freeze or identity['status']) and not a.plan_while_source_changing:raise ValueError('repository must remain the selected clean freeze')
 plan=build(a.freeze);plan['repositoryObservation']=identity
 if a.plan_while_source_changing:plan['holds'].append({'scope':'repository-freeze','reason':'planning only while product source is changing; final freeze not yet approved'})
 plan['bundles']=assign_bundles(plan['files'],a.freeze)
 plan['publicFilenameMapping']={**{b['name']:b['name'] for b in plan['bundles']},'machine-manifest.json':'integration-evidence-manifest.json','historical-pr162-d557.tar.gz':'pr162-oracle-evidence.tar.gz'}
 plan['publicHistoricalInventory']={'publicFilename':'pr162-oracle-inventory.json','providedBy':'root','meaning':'Original independently reviewed34-check inventory supplied by root; historical-pr162-d557.inventory.json is a local convenience listing and does not replace it.'}
 writejson(OUT/'bundle-plan.json',plan);writejson(OUT/'bundle-plan-summary.json',{k:plan[k] for k in ['createdAt','isFinal','targetFreeze','summary','bundles','sumIndividuallyDeflatedBytesEstimate','holds','possibleSensitiveFlags']})
 (OUT/'main-allowlist.txt').write_text('\n'.join(r['sourceOriginalPath'] for r in plan['files'])+'\n')
 if not a.finalize:
  print(json.dumps({'mode':'plan-only','summary':plan['summary'],'gzipEstimateBytes':plan['sumIndividuallyDeflatedBytesEstimate'],'holds':plan['holds'],'possibleSensitiveFlags':len(plan['possibleSensitiveFlags'])},ensure_ascii=False));return
 approval=readjson(a.approval_file) if a.approval_file else None
 if not approval or approval.get('allGatesComplete') is not True or approval.get('freeze')!=a.freeze or approval.get('confirmedBy')!='root':raise ValueError('finalization requires root all-gates-complete approval for this exact freeze')
 if plan['holds'] or plan['possibleSensitiveFlags']:raise ValueError('held or sensitive evidence must be resolved before finalization')
 if not plan['sourceChangeReview']['matchesDeclaredChangedPaths']:raise ValueError('unexpected source changes require refreshed bounded impact review')
 targets=[OUT/b['name'] for b in plan['bundles']]
 if any(p.exists() for p in targets):raise ValueError('final archive exists; never overwrite immutable delivery')
 # Validate every source before opening final output; recheck again while writing.
 for r in plan['files']:source_bytes(r)
 manifest={**plan,'schema':'geometry-evidence-delivery-manifest/1','isFinal':True,'finalizedAt':now(),'approval':approval,'claim':'Evidence archive with distinct accepted, failed, and historical source-equivalent scopes. Not a global release approval.'}
 payload=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();temporaries=[]
 try:
  for target in targets:
   tmp=target.with_suffix(target.suffix+'.partial');temporaries.append((tmp,target))
   with tarfile.open(tmp,'w:gz',compresslevel=6) as tar:
    tar.addfile(pack_info(payload,'manifest.json'),io.BytesIO(payload))
    for r in plan['files']:
     if r['bundleName']!=target.name:continue
     data=source_bytes(r);tar.addfile(pack_info(data,r['archivePath']),io.BytesIO(data))
   if tmp.stat().st_size>=95*1024*1024:raise ValueError('archive exceeds conservative95MiB delivery limit: '+target.name)
  if git('rev-parse','HEAD')!=a.freeze or git('status','--porcelain'):raise ValueError('freeze changed during packing')
  for tmp,target in temporaries:tmp.rename(target)
  writejson(OUT/'machine-manifest.json',manifest)
  archives=[{'path':str(target),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'files':sum(r['bundleName']==target.name for r in plan['files'])} for target in targets]
  info={'archives':archives,'files':len(plan['files']),'freeze':a.freeze,'manifestSha256':sha(payload),'originalPr162Sha256':ORIGINAL_SHA}
  writejson(OUT/'delivery-receipt.json',info);print(json.dumps(info))
 except Exception:
  for tmp,_ in temporaries:
   if tmp.exists():tmp.unlink()
  raise
if __name__=='__main__':main()
