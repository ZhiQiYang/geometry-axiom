# Geometry evidence delivery — 459478e verified evidence package

`finalize_evidence.py` reads the selected clean repository and original evidence; it only writes this delivery directory. It never runs tests, changes source, resets native state or stops services.

Run a fresh plan safely:

```sh
python /workspace/scratch/geometry-delivery-20261008/finalize_evidence.py
```

The plan contains explicit scopes, required completion proofs, held gates, omitted files, original paths, actual execution heads and dirty status, source-equivalence references, every selected file's SHA-256 and estimated sizes. A missing original execution identity stays unrecorded; it is never inferred from the final commit. The selected clean freeze is `459478e9f68fe8ee9252a5f6b4a1ffb2213a5207`. Root confirmed completion of all required local scopes, and the independent final matrix is sealed with no pending scopes. Internal approval authorizes evidence packaging, not external publication or global release. The mandatory full-CDP target is `root-browser-final-459478e/cdp-full-receipt/receipt.json`, exact census 2177. Its predecessor at f23 ended with a fatal P85 timeout after 2006 passed assertions and remains the third RED attempt.

The exact cumulative diff from `3c65ced` contains five paths: the engineering oracle correction and null-geometry product fix, then the space-workspace product fix, source-navigation regression and its increased golden census. Mandatory source proofs are `renderer-impact-f23a65a/change-impact.json` (20 checks, original f23 scope) and `library-race-impact-459478e/change-impact.json` (26 checks, current459 scope). This is not whole-product equivalence. New Q38 68, model-history35, Save33, fresh-profile18, room120, Space228 and timber-source68 were rerun at459; the transformed-driver36 and lifecycle5 probes remain separately identified as supporting diagnostics. Focused P69 160 and actual-function17 preserve their actual f23 heads. The former Q38 68 runs at3c/f23, model35/Save33/fresh18 at3c and Space228 at5c stay in `historical-prior-passes/`. Other unaffected scopes retain their original heads and specialized applicability references.

Planned delivery separates a `geometry-main-evidence-<freeze>.tar.gz` and `geometry-full-cdp-evidence-<freeze>.tar.gz`. Every original file remains byte-exact. Either family is sharded by whole files before 70 MiB raw payload; final packing rejects any compressed archive at or above 95 MiB. Each part has the full machine manifest with exact per-file `bundleName`; public artifact links must list both families. The independent original d557 tar remains a third separate historical attachment. Public names preserve `geometry-main-evidence-459478e9.tar.gz` and `geometry-full-cdp-evidence-459478e9.tar.gz`; the machine manifest is published as `integration-evidence-manifest.json`. The explicit `publicFilenameMapping` maps the unchanged local `historical-pr162-d557.tar.gz` to existing public `pr162-oracle-evidence.tar.gz`. Root supplies the original34-check `pr162-oracle-inventory.json`; the shorter local inventory is not its replacement.

The main bundle uses `accepted-evidence/`, `supporting-records/` and `failure-attempts/` namespaces. Earlier RED aggregate, the two separate full CDP attempts (`root-browser` and `root-browser-retry`), restart recovery runs 01–03 and failed UI/probe attempts stay visibly separate, with their original bytes. A completed negative-control artifact is not described as a valid project. Partial success files are omitted from accepted scopes. `root-browser-final-f23` is retained in `failure-attempts/`, alongside the two earlier full-CDP RED runs. The new full-CDP scope completed2177 with all84 sections exactly matching the frozen golden, no filters/modifiers, no failed/skipped assertions and only the one explicitly expected feedback exception. `p69-null-crosscheck/` is supporting evidence only: two native invalid fixtures and eight actual-function VM checks, not a new formal gate. The focused 160 is partial P69 scope and never substitutes for full CDP. The 17 actual-function counterchecks are separately identified from the native capacity diagnosis.

All profiles, caches, `.git`, SQLite, native executables, service feedback, raw fixture PDFs and duplicate tar files are excluded. All work-manager raw execution data is excluded under its AGENTS.md: no private PNGs, identity receipts, harness dumps, fixture exports, state, backups or local execution paths. Only the explicitly allowed `work-manager-unit-final/public-summary.json` and a documentary historical summary of counts, actual dirty head and six product hashes are selected.

`historical-pr162-d557.tar.gz` is a byte-for-byte copy of the original independent PR162 bundle. Its SHA-256 is `d557783696db1112ae5636150b89929a36c8b2feee4f0029af045838b160c4be`; it contains three original native executables and is **not** inside the clean main archive. `historical-pr162-d557.inventory.json` lists the unchanged historical contents. `oracle/` is not duplicated.

Scattered download collection reads canonical `saved artifact` log lines, captures exact copies under `scattered-originals/`, and records original temporary path, log line, marker, size and hash in `scattered-download-index.json`. Missing or excluded references remain explicit omissions. The same manifest keeps `sourceOriginalPath` and separate stable `sourceArchiveReadPath`; no temporary original is rewritten.

During active product fixes, `--plan-while-source-changing` may refresh the non-final inventory but adds a mandatory hold and is forbidden with `--finalize`.

The recorded root completion confirmation uses an internal approval JSON with `allGatesComplete: true`, `confirmedBy: "root"`, and the exact `freeze`. Then run:

```sh
python /workspace/scratch/geometry-delivery-20261008/finalize_evidence.py \
  --finalize --approval-file /workspace/scratch/geometry-delivery-20261008/root-completion-approval.json
```

Finalization refuses missing/failed required receipts, unexpected source changes, possible credential matches, a changed or dirty HEAD, changed file hashes and an existing final archive. It checks bytes before packing and again while packing, writes a temporary tar, then renames it only after success. The tar contains `manifest.json`; external `machine-manifest.json` and `delivery-receipt.json` record the final archive hash. Existing immutable outputs are never overwritten. This is an evidence archive, not an automatic global release approval.
