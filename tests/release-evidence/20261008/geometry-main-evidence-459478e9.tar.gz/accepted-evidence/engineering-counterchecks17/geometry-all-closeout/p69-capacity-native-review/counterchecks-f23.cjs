const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto'),cp=require('child_process');
const assert=require('assert').strict;
const ROOT='/workspace/geometry-final',OUT=__dirname;
const sourcePath=path.join(ROOT,'geometry-web/engineering-workspace.js');
const adapterPath=path.join(ROOT,'geometry-web/engineering-adapter.js');
const source=fs.readFileSync(sourcePath,'utf8'),adapterSource=fs.readFileSync(adapterPath,'utf8');
const fixturePath=path.join(OUT,'preview.json');
const raw=JSON.parse(fs.readFileSync(fixturePath,'utf8'));
const trace=JSON.parse(fs.readFileSync(path.join(OUT,'trace.json'),'utf8'));
const validRaw=trace.find(x=>x.response.preview?.valid===true).response.preview;
const clone=x=>JSON.parse(JSON.stringify(x));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function identity(){return {head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}),workspaceSha256:sha(sourcePath),adapterSha256:sha(adapterPath),nativeFixtureSha256:sha(fixturePath),harnessSha256:sha(__filename)};}
const beforeIdentity=identity();
assert.equal(beforeIdentity.head,'f23a65a764974f71a8f05d293ca8dc2340049f06');assert.equal(beforeIdentity.status,'');
const adapterStart=adapterSource.indexOf('  const normalizeRecord = record => {');
const adapterEnd=adapterSource.indexOf('  async function read() {',adapterStart);
assert(adapterStart>0&&adapterEnd>adapterStart);
const normalizer=vm.runInNewContext(`const clone=value=>JSON.parse(JSON.stringify(value));\n${adapterSource.slice(adapterStart,adapterEnd)}\nnormalize;`);
const exportAnchor='  return {configure,open,close,refresh:()=>load(false),get isOpen(){return !!dialog?.open;}};';
assert.equal(source.split(exportAnchor).length,2);
const injection=`  return {diffSnapshots,renderDiff,requestPreview,confirm,probeConfigure(options){
    adapter=options.adapter;dialog=options.dialog;Object.assign(state,{snapshot:options.snapshot,context:context(),busy:false,preview:null,intent:null,request:0,formRevision:0,section:'apply',mode:'apply',inlineKind:null});
    renderPreview=options.renderPreview;
  },probeState(){return state;}};`;
const sandbox={window:{},WorkspaceShell:{refresh(){}},console};
vm.runInNewContext(source.replace(exportAnchor,injection),sandbox,{filename:sourcePath});
const api=sandbox.window.EngineeringWorkspace;
const checks=[];
function check(name,value){assert.equal(value,true,name);checks.push({name,passed:true});}
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const before=normalizer(clone(raw.before)),after=normalizer(clone(raw.after));
const rows=api.diffSnapshots(before,after),unresolved=rows.filter(r=>r.unresolved);
check('Actual native null guide collection does not throw and has one unresolved row',unresolved.length===1);
check('Unresolved row preserves exact complete before guide array',equal(unresolved[0].before,{guides:raw.before.geometry.guides}));
check('Unresolved row preserves exact native after null guide array',equal(unresolved[0].after,{guides:raw.after.geometry.guides}));
check('Unresolved native guide is not represented as an identified deletion',!rows.some(r=>r.collection==='guides'&&r.after===null));
check('Actual renderDiff does not label unresolved raw collection as removed',!api.renderDiff(unresolved[0]).includes('已移除'));
const sameRows=api.diffSnapshots(before,normalizer(clone(raw.before)));
check('Identical source and geometry snapshot creates no false rows',sameRows.length===0);
const deleted=clone(raw.before);deleted.geometry.guides=[];
const removedRows=api.diffSnapshots(before,normalizer(deleted));
check('Actual empty guide array is represented as one true deletion',removedRows.length===1&&removedRows[0].collection==='guides'&&removedRows[0].before.id===0&&removedRows[0].after===null&&!removedRows[0].unresolved);
check('Actual renderDiff labels genuine guide deletion as removed',api.renderDiff(removedRows[0]).includes('已移除'));
function configure(reply){
  const elements=new Map(),observed={renders:0,previews:0,confirms:0,messages:[]};
  function element(selector){if(!elements.has(selector))elements.set(selector,{dataset:{},disabled:false,hidden:false,checked:true,textContent:'',inert:false});return elements.get(selector);}
  const dialog={open:true,querySelector:element};
  const result={...clone(reply),before:normalizer(clone(reply.before)),after:normalizer(clone(reply.after)),diagnostics:clone(reply.violations)};
  api.probeConfigure({snapshot:before,dialog,adapter:{getProjectState:()=>({id:'probe',contextToken:'fixed'}),preview:async()=>{observed.previews++;return result;},confirm:async()=>{observed.confirms++;return {ok:true};}},renderPreview:()=>{observed.renders++;}});
  return {elements,element,observed,result};
}
const intent={action:'archive',draft:{kind:'material',reference:{id:'panel-a',version:1},archived:true}};
(async()=>{
  const invalid=configure(raw);await api.requestPreview(intent);
  check('Real requestPreview accepts invalid native reply for blocked review',api.probeState().preview?.valid===false&&invalid.observed.renders===1);
  check('Invalid preview preserves native diagnostic objects exactly',equal(api.probeState().preview.diagnostics,raw.violations));
  check('Invalid preview leaves actual confirmation action disabled',invalid.element('#ewConfirm').disabled===true);
  check('Invalid preview displays blocker message rather than TypeError',invalid.element('#ewStatus').textContent.includes('有阻擋')&&!invalid.element('#ewStatus').textContent.includes('target'));
  const wrong=clone(raw);wrong.valid=true;
  const inconsistent=configure(wrong);await api.requestPreview(intent);
  check('Mislabelled valid unresolved result is not installed as a preview',api.probeState().preview===null&&inconsistent.observed.renders===0);
  check('Mislabelled valid unresolved result produces explicit guard error',inconsistent.element('#ewStatus').dataset.kind==='error'&&inconsistent.element('#ewStatus').textContent.includes('不能確認套用'));
  check('Mislabelled valid unresolved result remains confirmation-disabled',inconsistent.element('#ewConfirm').disabled===true);
  await api.confirm();check('Actual confirm exits without mutation transport after guard rejection',inconsistent.observed.confirms===0);
  const good=configure(validRaw);await api.requestPreview(intent);
  check('Positive control valid resolved result reaches preview and enables reviewed confirmation',api.probeState().preview?.valid===true&&good.observed.renders===1&&good.element('#ewConfirm').disabled===false);
  const afterIdentity=identity();assert.deepEqual(afterIdentity,beforeIdentity);
  const result={beforeIdentity,afterIdentity,passed:checks.length,failed:0,checks,unresolvedRows:clone(unresolved),trueDeletionRows:clone(removedRows),limitations:[
    'Executes actual committed workspace IIFE and adapter normalize functions with a test-only export seam, without repository edits.',
    'Adapter reply comes from saved real native JSON; the transport, dialog elements and renderPreview DOM insertion are fixture seams.',
    'Actual diffSnapshots, requestPreview, validateIntent, buildOperations, invalidate, updateActions, confirm, renderDiff and rendering helpers execute unchanged.',
    'This bounded countercheck is not a replacement for the focused or full browser gate.'
  ]};
  fs.writeFileSync(path.join(OUT,'counterchecks-f23-result.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({passed:result.passed,failed:result.failed,head:beforeIdentity.head,sourceSha256:beforeIdentity.workspaceSha256,harnessSha256:beforeIdentity.harnessSha256}));
})().catch(error=>{console.error(error);process.exitCode=1;});
