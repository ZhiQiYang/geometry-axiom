/* #46 scenario lifecycle gate: real official app, real isolated native B,
 * exact handler completion, and held/lost replies. Synthetic scenes only.
 * GEOMETRY_TEST_URL and TEMP GEOMETRY_FEEDBACK_DIR/GEOMETRY_SCENARIO_OUT required.
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),url=process.env.GEOMETRY_TEST_URL,out=process.env.GEOMETRY_SCENARIO_OUT,feedback=process.env.GEOMETRY_FEEDBACK_DIR;
if(!url||![out,feedback].every(p=>p&&path.resolve(p).startsWith(os.tmpdir()+path.sep)))throw Error('Explicit isolated URL and TEMP feedback/output directories required');
fs.mkdirSync(out,{recursive:true});const results=[],errors=[];
function check(label,value){results.push({label,passed:!!value});assert.ok(value,label);console.log('PASS '+label);}
async function snapshot(page){return page.evaluate(async()=>({world:(await apiRequest('dump')).text,catalog:ReferenceWorkspace.readScenarioCatalog().catalog,drafts:ReferenceWorkspace.getEngineeringDrafts(),state:ReferenceWorkspace.getProjectState(),operation:ReferenceWorkspace.getEvidenceState(),history:{undo:ReferenceWorkspace.history.undo.map(s=>s.action),redo:ReferenceWorkspace.history.redo.map(s=>s.action)}}));}
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
async function ready(page){await page.waitForFunction(()=>typeof connection!=='undefined'&&connection.phase==='ready'&&!ReferenceWorkspace.busy);}
async function openScenarios(page){await page.locator('#projectInfoButton').click();if(!await page.locator('#scenarioOpen').isVisible())await page.locator('.project-concepts summary').click();await page.locator('#scenarioOpen').click();}
async function fresh(browser){const context=await browser.newContext({viewport:{width:1280,height:900}}),page=await context.newPage();page.on('dialog',d=>d.accept());page.on('pageerror',e=>errors.push(e.message));await page.addLocatorHandler(page.locator('#paramGridLessonClose'),async locator=>locator.click());await page.goto(url);await ready(page);const id=await page.evaluate(()=>ReferenceWorkspace.getProjectState().id);await page.locator('#fileMenuBtn').click();await page.locator('#btnNewProject').click();await page.waitForFunction(id=>ReferenceWorkspace.getProjectState().id!==id&&!ReferenceWorkspace.busy,id);await openScenarios(page);return page;}
async function catalog(page,n){await page.waitForFunction(n=>ReferenceWorkspace.readScenarioCatalog().catalog?.scenarios.length===n&&!document.querySelector('#scenarioCapture').disabled,n);}
async function fork(page){await page.locator('#scenarioCapture').click();await catalog(page,1);await page.locator('#scenarioName').fill('B');await page.locator('#scenarioFork').click();await catalog(page,2);const ids=await page.evaluate(()=>ReferenceWorkspace.readScenarioCatalog().catalog.scenarios.map(s=>s.scenarioId));await page.locator('#scenarioAfter').selectOption(ids[1]);}
async function edit(page){await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioFinishEdit').disabled);const child=page.frames().find(f=>f.url().includes('scenario='));const result=await child.evaluate(()=>apiRequest('line spec syntheticCandidate 42'));assert.equal(result.ok,true);return child;}
async function edited(page){await fork(page);await edit(page);await page.locator('#scenarioFinishEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioEditorDialog').open);await page.locator('#scenarioCompare').click();await page.waitForFunction(()=>!document.querySelector('#scenarioAdopt').disabled);}
async function watch(page,button){await page.evaluate(button=>{const b=document.querySelector(button),original=b.onclick;window.__gate={done:false,entered:false};b.onclick=function(e){const result=original.call(this,e);Promise.resolve(result).finally(()=>__gate.done=true);return result;};},button);}
async function hold(page,kind,button){await watch(page,button);await page.evaluate(kind=>{
 let release;const wait=new Promise(r=>release=r);__gate.release=release;
 if(kind==='export'){
  const listener=e=>{if(e.data?.ok!==true||!(e.data?.bytes instanceof Uint8Array))return;e.stopImmediatePropagation();__gate.entered=true;const data=e.data,origin=e.origin,source=e.source;wait.then(()=>{window.removeEventListener('message',listener,true);window.dispatchEvent(new MessageEvent('message',{data,origin,source}));__gate.released=true;});};window.addEventListener('message',listener,true);__gate.restore=()=>window.removeEventListener('message',listener,true);
 }else if(kind==='unpack'){
  const original=GeometryProject.unpack;GeometryProject.unpack=async(...args)=>{__gate.entered=true;await wait;try{return await original(...args);}finally{__gate.released=true;}};__gate.restore=()=>GeometryProject.unpack=original;
 }else{
  const original=window.fetch;window.fetch=async function(input,init){const response=await original.call(this,input,init),body=String(init?.body||''),route=kind==='capture'?'/api':kind==='verifier'?'/scenarios/verify-native':'/upload/confirm';if(!__gate.entered&&String(input)===route&&(kind!=='capture'||body.includes('"dump"'))){__gate.entered=true;await wait;__gate.released=true;}return response;};__gate.restore=()=>window.fetch=original;
 }
 },kind);}
async function released(page){await page.evaluate(()=>__gate.release());await page.waitForFunction(()=>__gate.released&&__gate.done);await page.evaluate(()=>__gate.restore());}
async function closedNative(page,context){return page.evaluate(async context=>{const r=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Geometry-Scenario':context},body:'{"cmd":"dump"}'});return r.status===410;},context);}
async function lostEditorReplies(page,action,button){await watch(page,button);await page.evaluate(action=>{const original=window.fetch;__gate.responses=[];__gate.closeCount=0;__gate.restore=()=>window.fetch=original;window.fetch=async function(input,init){const response=await original.call(this,input,init);if(String(input)==='/scenarios/editor'&&init?.method==='POST'){const request=JSON.parse(init.body);if(request.action==='close')__gate.closeCount++;if(request.action===action&&__gate.responses.length<2){const result=await response.clone().json();__gate.responses.push({request,result});throw new TypeError('Synthetic reply loss after server terminal');}}return response;};},action);}
const ticket=page=>page.evaluate(()=>ReferenceWorkspace.readScenarioEditorTicket());
const contextFrom=src=>new URL(src,url).searchParams.get('scenario');
// Browser observation survives real document reloads; it never substitutes a
// mock native service or a hand-authored recovery record for the shipped owner.
function auditRequests(page){const calls=[];page.on('request',request=>{
 const route=new URL(request.url()).pathname;if(request.method()!=='POST')return;
 let body;try{body=request.postDataJSON();}catch(_){body=request.postData();}
 calls.push({route,context:request.headers()['x-geometry-scenario']||null,body});
});return calls;}
const editorCalls=calls=>calls.filter(c=>c.route==='/scenarios/editor');
const destructive=calls=>calls.filter(c=>c.route.startsWith('/upload')||c.route==='/api'&&/^(line |drag |reset$|default$|undo$|redo$|loadfile |engineering-confirm |assembly-confirm )/.test(c.body?.cmd||''));
async function nativeDump(page,context){return page.evaluate(async context=>{const r=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Geometry-Scenario':context},body:'{"cmd":"dump"}'});return {status:r.status,result:await r.json()};},context);}
async function recoveryRecords(page){return page.evaluate(async()=>{
 const db=await new Promise((resolve,reject)=>{const q=indexedDB.open('geometry-canvas-recovery',1);q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
 const rows=await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readonly'),s=tx.objectStore('projects'),keys=s.getAllKeys(),values=s.getAll();tx.oncomplete=()=>resolve(keys.result.map((key,i)=>({key,record:values.result[i]})));tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});db.close();
 return Promise.all(rows.map(async({key,record})=>{if(!record.bytes)return {key,ticket:record};const p=await GeometryProject.unpack(record.bytes,fflate);return {key,session:record.session,sceneHash:record.sceneHash,packageHash:await GeometryProject.sha(record.bytes),finishReceipt:record.finishReceipt||null,project:record.project,manifest:p.manifest,scene:p.scene,sources:await Promise.all([...p.sources].map(async([id,bytes])=>[id,await GeometryProject.sha(bytes)]))};}));
});}
async function waitForCheckpoint(page,key,expected){await page.waitForFunction(async({key,expected})=>{
 const db=await new Promise((resolve,reject)=>{const q=indexedDB.open('geometry-canvas-recovery',1);q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
 const record=await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readonly'),q=tx.objectStore('projects').get(key);tx.oncomplete=()=>resolve(q.result);tx.onerror=()=>reject(tx.error);});db.close();if(!record?.bytes)return false;
 const p=await GeometryProject.unpack(record.bytes,fflate);return (expected.scene===undefined||p.scene===expected.scene)&&(!expected.draftId||p.manifest.engineeringDrafts?.records.some(r=>r.id===expected.draftId))&&(!expected.finishReceipt||record.finishReceipt===expected.finishReceipt);
},{key,expected});}
// Context/frame/revision and Undo are intentionally document-local. After a
// reload compare durable project content, never pretend volatile history was restored.
function durable(snapshot){return {world:snapshot.world,catalog:snapshot.catalog,drafts:snapshot.drafts,state:{id:snapshot.state.id,dirty:snapshot.state.dirty,saved:snapshot.state.saved}};}
async function frozenMutationProbe(child){return child.evaluate(async()=>{
 const sample=async()=>({world:(await apiRequest('dump')).text,state:ReferenceWorkspace.getProjectState(),drafts:ReferenceWorkspace.getEngineeringDrafts(),history:{undo:ReferenceWorkspace.history.undo.map(s=>s.action),redo:ReferenceWorkspace.history.redo.map(s=>s.action)}}),before=await sample();
 const native=await Promise.all(['line spec forbiddenDuringFinish 99','line undo','line redo'].map(cmd=>apiRequest(cmd)));
 let metadataBlocked=false;try{ReferenceWorkspace.removeEngineeringDraft('synthetic-nonexistent');}catch(_){metadataBlocked=true;}
 return {before,after:await sample(),native,metadataBlocked};
});}
async function assertFrozen(page,child,label){const result=await frozenMutationProbe(child);check(label+' blocks native mutation, Undo/Redo and metadata for frozen B',result.native.every(r=>r.ok===false)&&result.metadataBlocked&&same(result.before,result.after)&&await page.locator('#scenarioEditorFrame').evaluate(frame=>frame.inert));}
async function reloadRetained(page,expected,before){await page.reload();await ready(page);check(expected.phase+' reload restores complete A without importing B',same(durable(before),durable(await snapshot(page))));await openScenarios(page);await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>document.querySelector('#scenarioEditorDialog').open&&!document.querySelector('#scenarioCancelEdit').disabled);check(expected.phase+' reload retains the exact ticket and makes interrupted Resume unavailable',same(expected,await ticket(page))&&await page.locator('#scenarioFinishEdit').isDisabled()&&(await page.locator('#scenarioEditorStatus').textContent()).includes('無法安全續接')&&await page.locator('#scenarioEditorFrame').evaluate(frame=>frame.inert));}
async function discardRetained(page,expected,context){
 // First decline the real identified destructive prompt, then explicitly
 // accept it. The normal blanket test dialog handler is suspended here.
 const handlers=page.listeners('dialog');page.removeAllListeners('dialog');let prompt='';
 try{page.once('dialog',async d=>{prompt=d.message();await d.dismiss();});await watch(page,'#scenarioCancelEdit');await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>__gate.done);
  check('declined discard identifies scenario and editor and preserves exact pending ticket',prompt.includes(expected.label)&&prompt.includes(expected.scenarioId)&&prompt.includes(expected.context||expected.request.requestId)&&same(expected,await ticket(page))&&!(await closedNative(page,context)));
  page.once('dialog',async d=>{prompt=d.message();await d.accept();});await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioEditorDialog').open);
  check('explicit identified discard retires only the retained context and clears its ticket',await closedNative(page,context)&&(await ticket(page))===null);
 }finally{for(const handler of handlers)page.on('dialog',handler);}
}
async function traceTransactions(page){await page.evaluate(()=>{
 const transaction=IDBDatabase.prototype.transaction,put=IDBObjectStore.prototype.put,del=IDBObjectStore.prototype.delete,entries=new WeakMap();
 window.__storageGate={transactions:[],hashes:[],restore(){IDBDatabase.prototype.transaction=transaction;IDBObjectStore.prototype.put=put;IDBObjectStore.prototype.delete=del;}};
 IDBDatabase.prototype.transaction=function(...args){const tx=transaction.apply(this,args);if(this.name==='geometry-canvas-recovery'){const row={mode:args[1],requestedDurability:args[2]?.durability||null,actualDurability:tx.durability,writes:[],completed:false,aborted:false};entries.set(tx,row);__storageGate.transactions.push(row);tx.addEventListener('complete',()=>row.completed=true);tx.addEventListener('abort',()=>row.aborted=true);}return tx;};
 IDBObjectStore.prototype.put=function(value,key){const row=entries.get(this.transaction);if(row){const write={key,phase:value?.phase||null};row.writes.push(write);if(value?.bytes)__storageGate.hashes.push(GeometryProject.sha(value.bytes).then(hash=>{write.packageHash=hash;}));}return put.call(this,value,key);};
 IDBObjectStore.prototype.delete=function(key){const row=entries.get(this.transaction);if(row)row.writes.push({key,deleted:true});return del.call(this,key);};
});}
(async()=>{
 const git=(...args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim(),head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain');if(process.env.GEOMETRY_REQUIRE_CLEAN==='1')assert.equal(status,'','Frozen clean head required');
 const runtime=await fetch(new URL('/runtime',url)).then(r=>r.json());check('runtime is fresh and belongs to selected worktree',runtime.fresh===true&&path.resolve(runtime.root)===root);
 const browser=await chromium.launch({executablePath:process.env.GEOMETRY_CHROME||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
  for(const kind of ['export','unpack','verifier']){const page=await fresh(browser);try{await fork(page);const child=await edit(page),before=await snapshot(page);await hold(page,kind,'#scenarioFinishEdit');await page.locator('#scenarioFinishEdit').click();await page.waitForFunction(()=>__gate.entered);await assertFrozen(page,child,kind+' held Finish');await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioEditorDialog').open);await released(page);check(kind+' cancel preserves World/catalog/dirty/saved/context/revision/history at actual handler terminal',same(before,await snapshot(page)));}finally{await page.context().close();}}
  for(const reopen of [false,true]){const page=await fresh(browser);try{const before=await snapshot(page);await hold(page,'capture','#scenarioCapture');await page.locator('#scenarioCapture').click();await page.waitForFunction(()=>__gate.entered);await page.locator('[data-scenario-close]').click();if(reopen){await page.locator('#projectInfoButton').click();await page.locator('#scenarioOpen').click();}await released(page);check('Capture close'+(reopen?' / reopen':'')+' cannot renew ownership after held native dump',same(before,await snapshot(page)));}finally{await page.context().close();}}
  {const page=await fresh(browser);try{await edited(page);const before=await snapshot(page);await hold(page,'confirm','#scenarioAdopt');await page.locator('#scenarioAdopt').click();await page.waitForFunction(()=>__gate.entered);await page.locator('[data-scenario-close]').click();check('held confirm keeps common mutation lease after attempted dialog Close',await page.evaluate(()=>document.querySelector('#scenarioDialog').open&&ReferenceWorkspace.busy));const rejected=await page.evaluate(async()=>({mutation:await apiRequest('line spec forbiddenLate 99'),undo:await apiRequest('line undo'),redo:await apiRequest('line redo')}));check('held native commit rejects new native mutation and both history directions',Object.values(rejected).every(r=>r.ok===false));await released(page);const after=await snapshot(page);check('confirmed adoption reconciles exactly one complete history transaction',after.world!==before.world&&after.history.undo.length===before.history.undo.length+1&&after.history.undo.at(-1)==='整體採用候選方案'&&same(before.catalog,after.catalog));await page.locator('[data-scenario-close]').click();await page.locator('#btnUndo').click();await page.waitForFunction(()=>!oc.busy&&ReferenceWorkspace.history.redo.at(-1)?.action==='整體採用候選方案');check('real Undo restores native A and complete catalog after held confirm',(await snapshot(page)).world===before.world&&same(before.catalog,(await snapshot(page)).catalog));await page.locator('#btnRedo').click();await page.waitForFunction(()=>!oc.busy&&ReferenceWorkspace.history.undo.at(-1)?.action==='整體採用候選方案');check('real Redo restores native B after held confirm',(await snapshot(page)).world===after.world);}finally{await page.context().close();}}
  {const page=await fresh(browser);try{await edited(page);const before=await snapshot(page);await watch(page,'#scenarioAdopt');await page.evaluate(()=>{const original=window.fetch;__gate.confirms=0;__gate.restore=()=>window.fetch=original;window.fetch=async function(input,init){const response=await original.call(this,input,init);if(String(input)==='/upload/confirm'){__gate.confirms++;__gate.terminal=await response.clone().json();throw new TypeError('Synthetic committed confirmation reply loss');}return response;};});await page.locator('#scenarioAdopt').click();await page.waitForFunction(()=>__gate.done&&connection.phase==='error');check('unknown committed response keeps mutation and Undo blocked',await page.evaluate(async()=>!(await apiRequest('line spec unknownMutation 1')).ok&&!(await apiRequest('line undo')).ok));await page.locator('[data-scenario-close]').click();await page.evaluate(()=>__gate.restore());await page.locator('#connectionRetry').click();await page.waitForFunction(()=>connection.phase==='ready'&&!ReferenceWorkspace.busy&&ReferenceWorkspace.history.undo.at(-1)?.action==='整體採用候選方案');const after=await snapshot(page);check('normal reconnect retrieves exact terminal without a second confirm',await page.evaluate(()=>__gate.confirms===1)&&after.world!==before.world&&after.history.undo.length===before.history.undo.length+1&&same(before.catalog,after.catalog));await page.locator('#btnUndo').click();await page.waitForFunction(()=>!oc.busy&&ReferenceWorkspace.history.redo.at(-1)?.action==='整體採用候選方案');check('unknown-result recovery retains exact complete A for real Undo',(await snapshot(page)).world===before.world&&same((await snapshot(page)).catalog,before.catalog));}finally{await page.context().close();}}
  {const page=await fresh(browser);try{
   await fork(page);const before=await snapshot(page),calls=auditRequests(page);await traceTransactions(page);await lostEditorReplies(page,'create','#scenarioEdit');await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>__gate.done);
   const gate=await page.evaluate(()=>({responses:__gate.responses,closes:__gate.closeCount})),pending=await ticket(page),context=gate.responses[0]?.result.context;
   check('two lost create replies use the same request identity and one native context',gate.responses.length===2&&same(gate.responses[0].request,gate.responses[1].request)&&context===gate.responses[1].result.context);
   const rows=await recoveryRecords(page),checkpoint=rows.find(r=>r.key===pending.parentCheckpoint.key),writes=await page.evaluate(async()=>{await Promise.all(__storageGate.hashes);return __storageGate.transactions;});
   check('pre-create strict browser transaction commits complete A and exact creating ticket together',pending.phase==='creating'&&pending.context===null&&pending.eligible===false&&same(pending.request,gate.responses[0].request)&&same(checkpoint.manifest.scenarioCatalog,before.catalog)&&writes.some(t=>t.completed&&!t.aborted&&t.requestedDurability==='strict'&&t.actualDurability==='strict'&&t.writes.some(w=>w.key===pending.parentCheckpoint.key&&w.packageHash===pending.parentCheckpoint.packageHash)&&t.writes.some(w=>w.phase==='creating')));
   check('lost create retains native B without implicit discard and changes no complete root state',gate.closes===0&&!(await closedNative(page,context))&&same(before,await snapshot(page)));
   await page.evaluate(()=>{__gate.restore();__storageGate.restore();});
   // Ten real reload/Edit cycles exceed the server's unchanged eight-context
   // ceiling. Merely revisiting an unresolved ticket must allocate nothing.
   for(let i=0;i<10;i++)await reloadRetained(page,pending,before);
   check('ten reload/Edit cycles preserve one create tuple with no import or automatic close',editorCalls(calls).length===2&&editorCalls(calls).every(c=>c.body.action==='create'&&same(c.body,pending.request))&&destructive(calls).length===0&&!(await closedNative(page,context)));
   await discardRetained(page,pending,context);check('explicit discard after lost create preserves recovered A',same(durable(before),durable(await snapshot(page))));
  }finally{await page.context().close();}}
  for(const phase of ['initializing','active']){const page=await fresh(browser);let standalone;try{
   // Direct synthetic writes omit a native revision in their reply. Observe the
   // finished fixture before capture so its lease pins the actual native state.
   assert.equal((await page.evaluate(async()=>{
    const result=await apiRequest('line spec syntheticInitial 41');
    const observed=await apiRequest('dump');
    if(!observed.ok||!Number.isSafeInteger(observed.revision)||ReferenceWorkspace.getEvidenceState().nativeRevision!==observed.revision)
     throw new Error('Synthetic fixture native revision was not observed');
    return result;
   })).ok,true);await fork(page);const before=await snapshot(page),calls=auditRequests(page);
   await page.context().addInitScript(({holdImport})=>{if(!new URL(location.href).searchParams.has('scenario'))return;const original=window.fetch;window.__importGate={held:false};window.__bootstrapGate={checked:false,blocked:false,metadataBlocked:false};window.fetch=async function(input,init){const request=input instanceof Request?input:new Request(input,init),route=new URL(request.url).pathname;
    if(route==='/api'&&!__bootstrapGate.checked){__bootstrapGate.checked=true;try{ReferenceWorkspace.assertEditable();}catch(error){__bootstrapGate.blocked=error.message.includes('完整資料');}try{ReferenceWorkspace.removeEngineeringDraft('synthetic-bootstrap-probe');}catch(error){__bootstrapGate.metadataBlocked=error.message.includes('完整資料');}}
    const response=await original.call(this,input,init);if(holdImport&&route==='/upload/confirm'){__importGate.terminal=await response.clone().json();__importGate.held=true;await new Promise(()=>{});}return response;};},{holdImport:phase==='initializing'});
   if(phase==='initializing'){
    // Hold an actual successful child import confirmation after the native
    // commit, before the importing document can acknowledge it to its parent.
    await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>document.querySelector('#scenarioEditorFrame').contentWindow?.__importGate?.held===true);
   }else await edit(page);
   const pending=await ticket(page),context=pending.context,beforeB=await nativeDump(page,context);check(phase+' interruption has exact live B and durable non-resumable ticket',pending.phase===phase&&pending.eligible===false&&beforeB.status===200&&beforeB.result.ok===true);
   if(phase==='initializing')check('interrupted import held an actual successful native confirmation for the selected B',await page.locator('#scenarioEditorFrame').evaluate(frame=>frame.contentWindow.__importGate.terminal.ok===true)&&beforeB.result.text===before.catalog.scenarios[1].snapshot.worldScene);
   else check('active interruption preserves a genuinely changed native B',beforeB.result.text!==before.world&&beforeB.result.text.includes('syntheticCandidate'));
   check(phase+' original B bootstrap is blocked before its first native request',await page.locator('#scenarioEditorFrame').evaluate(frame=>{const gate=frame.contentWindow.__bootstrapGate;return gate.checked&&gate.blocked&&gate.metadataBlocked;}));
   const cutoff=calls.length;await reloadRetained(page,pending,before);
   check(phase+' root reload/Edit neither replays create nor imports old catalog over B',editorCalls(calls.slice(cutoff)).length===0&&destructive(calls.slice(cutoff)).length===0&&same(beforeB,await nativeDump(page,context)));
   // Same-origin standalone B shares the real IndexedDB, but gets a different
   // top-level sessionStorage. It must block before any recovery import/write.
   standalone=await page.context().newPage();standalone.on('pageerror',e=>errors.push(e.message));const standaloneCalls=auditRequests(standalone),storedBefore=await recoveryRecords(page);
   await standalone.goto(new URL('/?scenario='+context,url).href);await ready(standalone);
   const blocked=await standalone.evaluate(async()=>({context:GeometryNativeContext.scenario,early:__bootstrapGate,info:ReferenceWorkspace.getProjectInfo(),mutation:await apiRequest('line spec forbiddenBootstrap 98')}));
   await standalone.evaluate(()=>ReferenceWorkspace.persistSession());
   check(phase+' standalone bootstrap blocks mutation and performs no old import or recovery write',blocked.context===context&&blocked.early.checked&&blocked.early.blocked&&blocked.early.metadataBlocked&&blocked.info.editingBlocked&&blocked.info.recovery.state==='scenario-blocked'&&blocked.mutation.ok===false&&destructive(standaloneCalls).length===0&&same(storedBefore.filter(r=>r.key==='geometry-scenario-recovery-'+context), (await recoveryRecords(page)).filter(r=>r.key==='geometry-scenario-recovery-'+context))&&same(beforeB,await nativeDump(page,context)));
   await standalone.close();standalone=null;await discardRetained(page,pending,context);check(phase+' explicit discard preserves complete recovered A',same(durable(before),durable(await snapshot(page))));
  }finally{if(standalone)await standalone.close();await page.context().close();}}
  {const page=await fresh(browser);try{
   await fork(page);const before=await snapshot(page),records=[];let first;
   for(let i=0;i<2;i++){
    const child=await edit(page),pending=await ticket(page),key='geometry-scenario-recovery-'+pending.context;
    const scene=await child.evaluate(async()=>(await apiRequest('dump')).text);await child.evaluate(()=>ReferenceWorkspace.persistSession());await waitForCheckpoint(page,key,{scene});
    const rows=await recoveryRecords(page),rootRecord=rows.find(r=>r.key===pending.parentCheckpoint.key),childRecord=rows.find(r=>r.key===key),locks=await child.evaluate(()=>navigator.locks.query());
    check('B'+(i+1)+' owns native-specific recovery key and lock while preserving complete A',key!==pending.parentCheckpoint.key&&childRecord?.session===pending.context&&rootRecord?.session===pending.rootSession&&same(rootRecord.manifest.scenarioCatalog,before.catalog)&&childRecord.manifest.scenarioCatalog==null&&locks.held.some(l=>l.name==='geometry-canvas-recovery-'+key)&&locks.held.some(l=>l.name==='geometry-canvas-recovery-'+pending.parentCheckpoint.key));
    if(first)check('second B never overwrites the first B recovery namespace',key!==first.key&&same(first,rows.find(r=>r.key===first.key)));
    records.push(childRecord);await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioEditorDialog').open);first ||= (await recoveryRecords(page)).find(r=>r.key===key);
   }
   check('two independently persisted B lifecycles preserve complete live A',records.length===2&&same(before,await snapshot(page)));
  }finally{await page.context().close();}}
  {const page=await fresh(browser);try{
   await fork(page);const before=await snapshot(page),calls=auditRequests(page);await edit(page);const context=contextFrom(await page.locator('#scenarioEditorFrame').getAttribute('src')),active=await ticket(page);
   await lostEditorReplies(page,'close','#scenarioCancelEdit');await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>__gate.done);const pending=await ticket(page),gate=await page.evaluate(()=>__gate.responses);
   check('two lost close replies retire exact context, retain durable discard identity and preserve A',await closedNative(page,context)&&pending.phase==='retiring'&&pending.retirement.reason==='cancel'&&same(pending.request,active.request)&&gate.length===2&&gate.every(r=>same(r.request,{...active.request,action:'close'}))&&same(before,await snapshot(page)));
   await page.evaluate(()=>__gate.restore());await page.reload();await ready(page);await openScenarios(page);await watch(page,'#scenarioEdit');await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>__gate.done);
   check('reload/Edit drains only the authorized close before any new allocation',(await ticket(page))===null&&editorCalls(calls).filter(c=>c.body.action==='create').length===1&&editorCalls(calls).filter(c=>c.body.action==='close').length===3&&!await page.locator('#scenarioEditorDialog').evaluate(d=>d.open));
   await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioFinishEdit').disabled);check('a separate normal Edit after confirmed retirement creates a fresh context',contextFrom(await page.locator('#scenarioEditorFrame').getAttribute('src'))!==context);
   await page.locator('#scenarioCancelEdit').click();await page.waitForFunction(()=>!document.querySelector('#scenarioEditorDialog').open);check('recovered editor lifecycle leaves complete durable A unchanged',same(durable(before),durable(await snapshot(page))));
  }finally{await page.context().close();}}
  {const page=await fresh(browser);try{
   await fork(page);const before=await snapshot(page),calls=auditRequests(page),child=await edit(page),active=await ticket(page),bScene=(await nativeDump(page,active.context)).result.text;
   await traceTransactions(page);await lostEditorReplies(page,'close','#scenarioFinishEdit');
   await page.evaluate(()=>{const original=window.fetch,restore=__gate.restore;let release;const wait=new Promise(r=>release=r);__gate.release=release;__gate.closeBoundary=null;__gate.restore=()=>{window.fetch=original;restore();};window.fetch=async function(input,init){if(String(input)==='/scenarios/editor'&&init?.method==='POST'&&JSON.parse(init.body).action==='close'&&!__gate.entered){await Promise.all(__storageGate.hashes);__gate.closeBoundary=structuredClone(__storageGate.transactions);__gate.entered=true;await wait;__gate.released=true;}return original.call(this,input,init);};});
   await page.locator('#scenarioFinishEdit').click();await page.waitForFunction(()=>__gate.entered);
   const retiring=await ticket(page),after=await snapshot(page),rows=await recoveryRecords(page),pin=retiring.retirement.checkpoint,receipt=rows.find(r=>r.key===pin.key),rootRecord=rows.find(r=>r.key===pin.parentKey),txs=await page.evaluate(()=>__gate.closeBoundary);
   check('Finish reaches native close only after one strict browser transaction committed A, immutable receipt and retiring ticket',retiring.phase==='retiring'&&retiring.retirement.reason==='finish'&&same(retiring.request,active.request)&&txs.some(t=>t.completed&&!t.aborted&&t.requestedDurability==='strict'&&t.actualDurability==='strict'&&t.writes.length===3&&t.writes.some(w=>w.key===pin.parentKey&&w.packageHash===pin.packageHash)&&t.writes.some(w=>w.key===pin.key&&w.packageHash===pin.packageHash)&&t.writes.some(w=>w.phase==='retiring')));
   check('Finish receipt contains exact complete A with changed B catalog and exactly one local history entry',receipt.packageHash===pin.packageHash&&receipt.sceneHash===pin.sceneHash&&receipt.manifest.projectId===pin.projectId&&same(receipt.manifest,rootRecord.manifest)&&same(receipt.manifest.scenarioCatalog,after.catalog)&&same(receipt.sources,rootRecord.sources)&&same(before.catalog.scenarios[0],after.catalog.scenarios[0])&&after.catalog.scenarios[1].snapshot.worldScene===bScene&&before.world===after.world&&same(after.history.undo,[...before.history.undo,'保存候選方案'])&&after.history.redo.length===0);
   await assertFrozen(page,child,'Finish durable checkpoint / held close');check('held retirement keeps exact B alive until close is dispatched',!(await closedNative(page,active.context)));
   await page.evaluate(()=>__gate.release());await page.waitForFunction(()=>__gate.released&&__gate.done);
   const losses=await page.evaluate(()=>__gate.responses);check('two lost Finish close replies preserve the exact completed receipt and retiring ticket without another history entry',losses.length===2&&losses.every(r=>same(r.request,{...active.request,action:'close'}))&&same(retiring,await ticket(page))&&same(after.history,(await snapshot(page)).history)&&await closedNative(page,active.context)&&await page.locator('#scenarioFinishEdit').isDisabled());
   await page.evaluate(()=>{__gate.restore();__storageGate.restore();});await page.evaluate(()=>ReferenceWorkspace.persistSession());
   check('ordinary parent recovery writes never alter the immutable Finish receipt',same(receipt,(await recoveryRecords(page)).find(r=>r.key===pin.key)));
   await page.reload();await ready(page);check('pending Finish reload restores the exact complete A receipt before retirement retry',same(durable(after),durable(await snapshot(page)))&&same(retiring,await ticket(page)));
   const draftId='synthetic-parent-after-finish';await page.evaluate(id=>ReferenceWorkspace.setEngineeringDraft({id,kind:'material',base_ref:null,data:{raw:'new parent metadata after Finish'},updated_at:'2026-10-06T00:00:00.000Z'}),draftId);
   const descendant=await snapshot(page);await page.evaluate(()=>ReferenceWorkspace.persistSession());await waitForCheckpoint(page,pin.parentKey,{draftId,finishReceipt:pin.packageHash});await page.reload();await ready(page);
   check('acknowledged descendant A metadata survives another reload while the immutable Finish receipt stays exact',same(durable(descendant),durable(await snapshot(page)))&&same(receipt,(await recoveryRecords(page)).find(r=>r.key===pin.key)));
   const historyBeforeRetry=(await snapshot(page)).history;
   await openScenarios(page);await watch(page,'#scenarioEdit');await page.locator('#scenarioEdit').click();await page.waitForFunction(()=>__gate.done);
   check('Finish close retry clears only the ticket without a new create, second history entry or loss of completed A',(await ticket(page))===null&&editorCalls(calls).filter(c=>c.body.action==='create').length===1&&editorCalls(calls).filter(c=>c.body.action==='close').length===3&&same(durable(descendant),durable(await snapshot(page)))&&same(historyBeforeRetry,(await snapshot(page)).history)&&same(receipt,(await recoveryRecords(page)).find(r=>r.key===pin.key)));
  }finally{await page.context().close();}}
  check('zero unexpected browser exceptions',errors.length===0);
 }finally{await browser.close();fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({schema:'geometry-scenario-lifecycle-gate/1',head,tree,worktreeClean:status==='',runtime,results,errors},null,2));}
 console.log('SCENARIO_LIFECYCLE_RESULT '+JSON.stringify({head,passed:results.length,failed:0,output:out}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
