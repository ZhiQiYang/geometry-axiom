#!/usr/bin/env python3
"""Independent Q38 black-box probes; external scratch artifact, no source edits."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import traceback
from copy import deepcopy
from datetime import datetime, timezone

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--bridge', required=True)
parser.add_argument('--model-base', required=True)
parser.add_argument('--out', required=True)
args = parser.parse_args()
repo, out = Path(args.repo).resolve(), Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
fixture = json.loads(Path(__file__).with_name('fixture.json').read_text())
resource.setrlimit(resource.RLIMIT_STACK, (16 * 1024 * 1024, resource.getrlimit(resource.RLIMIT_STACK)[1]))
rows, raw = [], []
expected_ids = ['N01','N02','N03','N04','N05','N06','N07','N08','N09','N10','M01','M02','M03','M04','M05','M06']
started = datetime.now(timezone.utc).isoformat()
source_before = {'head': subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
                 'tree': subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip(),
                 'status': subprocess.check_output(['git','-C',str(repo),'status','--short'],text=True).strip()}
stderr = (out / 'bridge.stderr').open('w')
process = subprocess.Popen([args.bridge], cwd=out, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)

def command(text):
    process.stdin.write(text + '\n'); process.stdin.flush()
    line = process.stdout.readline()
    if not line:
        raise RuntimeError('native bridge ended before reply')
    value = json.loads(line)
    raw.append({'command': text, 'response': value})
    (out / 'commands.json').write_text(json.dumps(raw, ensure_ascii=False, indent=2))
    return value

def check(identifier, message, condition, details=None):
    rows.append({'id': identifier, 'message': message, 'pass': bool(condition), 'details': details})
    print(identifier, 'PASS' if condition else 'FAIL', message, flush=True)

def read(): return command('section-profile-read')
def dump(): return command('dump')['text']
def snapshot(): return {'dump': dump(), 'state': read()}
def put(kind, value): return {'op': 'put-' + kind, 'value': deepcopy(value)}
def byid(values, identifier): return next(v for v in values if v['value']['id'] == identifier)
def transact(operations, commit=False):
    path = out / f'transaction-{len(raw):04}.json'
    path.write_text(json.dumps({'schema': 'section-profile-transaction/1', 'expectedRevision': read()['revision'], 'operations': operations}, ensure_ascii=False))
    reply = command('section-profile-preview ' + str(path))
    if not reply.get('ok'):
        raise AssertionError(reply)
    preview = reply['preview']
    if commit:
        assert preview['valid'], preview
        assert command('section-profile-confirm ' + str(preview['token']))['ok']
    return preview
def reject(operations):
    before = snapshot()
    preview = transact(operations)
    denied = command('section-profile-confirm ' + str(preview['token']))
    return preview, not preview['valid'] and not denied['ok'] and snapshot() == before

error = None
try:
    assert command('reset')['ok']
    for line in fixture['worldSetup']:
        reply = command('line ' + line)
        if reply.get('preview'):
            assert reply['preview']['valid']
            assert command('line confirm ' + str(reply['preview']['token']))['ok']
        else:
            assert reply['ok'], reply
    transact([put(kind, value) for kind, key in [('profile','profiles'),('member','members'),('run','runs')] for value in fixture[key]], True)
    baseline = snapshot()
    (out / 'fixture.scene').write_text(baseline['dump'])
    initial = baseline['state']['state']; expected = fixture['expected']
    live = byid(initial['runs'], 201); copied = byid(initial['runs'], 204)
    bounds = {m['memberId']: m['bounds'] for m in live['members']}
    check('N01', 'Rotated host and vertical extrusion use V=-up and U=V cross N',
          live['frame'] == expected['run201Frame'] and bounds[101] == expected['run201Member101Bounds'] and bounds[102] == expected['run201Member102Bounds'], live)
    graph = command('source-inspect'); edges = {(e['from'], e['to']) for e in graph['edges']}
    check('N02', 'Live host has typed dependency; copied host has no live placement dependency',
          ('profile-run:201','placement:901') in edges and not any(a == 'profile-run:204' and b.startswith(('placement:','space:')) for a,b in edges), graph)
    hole = deepcopy(fixture['runs'][3]); hole['placement'].update(p=250,q=250)
    preview, atomic = reject([put('run',hole)])
    check('N03', 'Copied effective hole rejects interior point without clamping or writes', atomic and any(v.get('runId') == 204 for v in preview['violations']), preview)
    reply = command('line placement 901 on boundary 901 origin 100 200 330 u +y v +z')
    before_move = snapshot()
    assert reply.get('preview', {}).get('valid'), reply
    assert command('line confirm ' + str(reply['preview']['token']))['ok']
    moved = read()['state']
    check('N04', 'Live host move previews atomically, copied frame and holes remain exact',
          before_move == baseline and byid(moved['runs'],201)['frame']['origin'] == [100,240,380] and byid(moved['runs'],204) == copied, moved)
    assert command('line undo')['ok']
    assert dump() == baseline['dump']
    transact([{'op':'convert-run-to-advanced','id':201}],True)
    advanced = byid(read()['state']['runs'],201)
    preview, missing_atomic = reject([{'op':'convert-run-to-simple','id':201}])
    transact([{'op':'convert-run-to-simple','id':201,'host':{'kind':'placement','placementId':901}}], True)
    check('N05', 'Both representations preserve exact frame/bounds; missing explicit host rejects',
          advanced['frame'] == live['frame'] and advanced['members'] == live['members'] and missing_atomic and byid(read()['state']['runs'],201) == live)
    small = deepcopy(fixture['profiles'][0]); small['outline'] = [[0,0],[15,0],[15,20],[0,20]]
    third = deepcopy(fixture['members'][0]); third.update(id=103,u0=10,v0=15)
    preview, atomic = reject([put('profile',small),put('member',third)])
    outside = {v['memberId']: v for v in preview['violations'] if v['code'] == 'V_PROFILE_OUTSIDE'}
    overlaps = [v for v in preview['violations'] if v['code'] == 'V_PROFILE_OVERLAP']
    check('N06', 'All invalid members have exact outside regions, pair intersection and original rectangles',
          atomic and set(outside) == {101,102,103} and
          outside[101]['outsideRegions'] == [[15,11,20,20],[7,20,20,28]] and
          outside[102]['outsideRegions'] == [[30,0,229,6]] and
          outside[101]['originalRectangle'] == [7,11,20,28] and
          outside[103]['originalRectangle'] is None and
          any(v['intersection'] == [10,15,20,28] and {v['memberId'],v['otherMemberId']} == {101,103} for v in overlaps), preview)
    named = deepcopy(fixture['members'][0]); named['A'] = {'kind':'spec','name':'ReviewWidth'}
    transact([{'op':'put-spec','name':'ReviewWidth','value':13},put('member',named)],True)
    updated = transact([{'op':'put-spec','name':'ReviewWidth','value':14}],True)
    typed = read()['state']; typed_edges = {(e['from'],e['to']) for e in command('source-inspect')['edges']}
    check('N07', 'Typed source remains a spec while both placed and local dependents recompute',
          byid(typed['members'],101)['value']['A'] == named['A'] and byid(typed['members'],101)['rect'] == [7,11,21,28] and
          byid(typed['runs'],201)['members'][0]['bounds'] == [[79,212,350],[93,229,1139]] and
          byid(typed['runs'],202)['members'][0]['bounds'] == [[7,11,0],[21,28,2001]] and
          ('profile-member:101','spec:ReviewWidth') in typed_edges, updated)
    preview, atomic = reject([{'op':'delete-spec','name':'ReviewWidth'}])
    check('N08', 'Deleting a live dimension source rejects atomically with member-specific diagnostic',
          atomic and any(v.get('memberId') == 101 and v.get('field') == 'A' for v in preview['violations']), preview)
    assert command('loadfile ' + str(out / 'fixture.scene'))['ok']
    check('N09', 'Native dump roundtrip preserves unused empty profile, local run and full copied host values',
          dump() == baseline['dump'] and read()['state'] == initial)
    invalid = out / 'unknown.scene'; invalid.write_text(baseline['dump'].replace('section-profile/1','section-profile/99'))
    before = snapshot(); denied = command('loadfile ' + str(invalid))
    check('N10', 'Unknown native capability refuses without changing current definitions or revision', not denied['ok'] and snapshot() == before, denied)

    sys.path.insert(0, str(repo / 'geometry-core'))
    from modeling import build_package, verify_package, ModelError
    from modeling_cli import obj_bytes
    def build(ids):
        return build_package({'base_scene':baseline['dump'],'extensions':[]},
                             {'roots':[{'kind':'profile-run','id':i} for i in ids], 'role':'geometry','target':'solid-set','allow_partial':False},base_executable=args.model_base)
    package = build([201,202,203,204]); objects = package['derived']['objects']
    (out / 'package.json').write_text(json.dumps(package,ensure_ascii=False,indent=2))
    identities = [(o['root']['id'],o['section_profile']['member_id']) for o in objects]
    check('M01', 'Producer emits unique run/member identity plus reference envelope for each root',
          len(objects) == 10 and len(set(identities)) == 10 and set(identities) == {(r,m) for r in [201,202,204] for m in [None,101,102]} | {(203,None)}, identities)
    a = next(o for o in objects if o['root']['id']==201 and o['section_profile']['member_id']==101)
    b = next(o for o in objects if o['root']['id']==201 and o['section_profile']['member_id']==102)
    check('M02', 'Independent exact native/producer member volumes, dimensions and world bounds agree',
          a['section_profile']['bounds_mm'] == expected['run201Member101Bounds'] and a['volume_mm3']==str(expected['run201Member101Volume']) and
          b['section_profile']['bounds_mm'] == expected['run201Member102Bounds'] and b['volume_mm3']==str(expected['run201Member102Volume']) and
          a['section_profile']['dimensions_mm']==[13,17,789] and b['section_profile']['dimensions_mm']==[6,199,789], [a['section_profile'],b['section_profile']])
    empty = next(o for o in objects if o['root']['id']==203)
    check('M03', 'Concave empty-profile envelope is exact reference geometry and contributes zero material',
          empty['role']=='reference' and empty['volume_mm3']==str(expected['run203EnvelopeVolume']) and empty['section_profile']['material_volume_mm3']=='0' and
          all(not(v[0]>40 and v[1]>40) for v in empty['vertices_mm']), empty['section_profile'])
    local = next(o for o in objects if o['root']['id']==202 and o['section_profile']['member_id']==102)
    check('M04', 'Long panel remains one closed solid, local geometry stays in local coordinates',
          local['section_profile']['coordinate_space']=='local' and local['section_profile']['dimensions_mm']==[6,199,2001] and
          local['section_profile']['bounds_mm']==expected['run202Member102Bounds'] and local['status']=='COMPLETE' and local['closure']=='closed',local['section_profile'])
    check('M05', 'Exact model package verifies and independently selected local run preserves same objects',
          verify_package(package,base_executable=args.model_base)==package and [o for o in objects if o['root']['id']==202]==build([202])['derived']['objects'])
    denied = None
    try: obj_bytes(package)
    except ModelError as exc: denied = exc.as_dict()
    check('M06', 'Plain OBJ refuses mixed independent local/world frames; local export labels its own axes',
          denied is not None and b'no world position or world up' in obj_bytes(build([202])),denied)
except BaseException as exc:
    error = {'type':type(exc).__name__, 'message':str(exc), 'traceback':traceback.format_exc()}
    print(error['traceback'],flush=True)
finally:
    process.stdin.close()
    try: process.wait(timeout=10)
    except subprocess.TimeoutExpired: process.kill();process.wait()
    stderr.close()
    def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    def git(*parts): return subprocess.check_output(['git','-C',str(repo),*parts],text=True).strip()
    result = {'schema':'q38-independent-native-probes/1','started':started,'finished':datetime.now(timezone.utc).isoformat(),
              'command':sys.argv,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'gitStatus':git('status','--short'),
              'sourceBefore':source_before,
              'harnessSha256':sha(__file__),'fixtureSha256':sha(Path(__file__).with_name('fixture.json')),
              'bridgeSha256':sha(args.bridge),'modelBaseSha256':sha(args.model_base),'nativeExit':process.returncode,
              'expectedIds':expected_ids,'actualIds':[r['id'] for r in rows],'checks':rows,'error':error}
    result['pass'] = error is None and result['actualIds']==expected_ids and all(r['pass'] for r in rows) and process.returncode==0
    (out / 'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(0 if result['pass'] else 1)
