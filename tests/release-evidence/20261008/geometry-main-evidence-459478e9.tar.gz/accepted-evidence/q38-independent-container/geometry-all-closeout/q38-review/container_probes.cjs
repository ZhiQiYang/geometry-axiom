// Independent validation of the actual browser-produced /16 archive.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),cp=require('node:child_process');
const [repo,archive,out]=process.argv.slice(2),P=require(path.join(repo,'geometry-web/project-store.js')),zip=require(path.join(repo,'geometry-web/vendor/fflate/umd/index.js'));
assert(repo&&archive&&out);assert(!fs.existsSync(out)||fs.readdirSync(out).length===0);fs.mkdirSync(out,{recursive:true});
const checks=[],started=new Date().toISOString(),original=fs.readFileSync(archive),sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const check=(id,condition,message)=>{checks.push({id,pass:!!condition,message});console.log(id,condition?'PASS':'FAIL',message);};
const mutate=(change)=>{const files=zip.unzipSync(original),manifest=JSON.parse(Buffer.from(files['manifest.json']));change(manifest,files);manifest.sceneHash=sha(files['world.scene']);files['manifest.json']=Buffer.from(JSON.stringify(manifest));return zip.zipSync(files);};
const rejects=async bytes=>{try{await P.unpack(bytes,zip);return false;}catch(error){return String(error.message);}};
let error=null;
(async()=>{try{
const actual=await P.unpack(original,zip);
check('C01',actual.manifest.format==='geometry-canvas/16'&&actual.manifest.requiredCapabilities.includes('section-profile/1')&&actual.scene.includes('section-profile run '),'Actual downloaded archive opens with full section capability');
check('C02',await rejects(mutate(m=>m.requiredCapabilities=m.requiredCapabilities.map(c=>c==='section-profile/1'?'section-profile/2':c))),'Unknown required capability rejects even when ZIP and scene hashes are valid');
check('C03',await rejects(mutate(m=>m.format='geometry-canvas/15')),'Downgrading container while retaining valid section source rejects');
check('C04',await rejects(mutate((m,f)=>f['world.scene']=Buffer.from(Buffer.from(f['world.scene']).toString().replace('requires section-profile/1\n','')))),'Missing native capability marker rejects even after recomputing scene hash');
let denied=false;try{P.assertProjectCapabilities(actual.manifest,P.readerCapabilities(['section-profile-native/1']));}catch(_){denied=true;}
check('C05',denied,'Native-only section capability cannot authorize complete /16 project reader');
P.assertProjectCapabilities(actual.manifest,P.readerCapabilities(['section-profile/1']));
check('C06',!P.readerCapabilities([]).includes('section-profile/1')&&P.readerCapabilities(['section-profile/1']).filter(c=>c==='section-profile/1').length===1,'Complete native support is required and remains a single capability identity');
}catch(e){error={message:e.message,stack:e.stack};}
const result={schema:'q38-independent-container-probes/1',started,finished:new Date().toISOString(),command:process.argv,head:cp.execFileSync('git',['-C',repo,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),harnessSha256:sha(fs.readFileSync(__filename)),projectStoreSha256:sha(fs.readFileSync(path.join(repo,'geometry-web/project-store.js'))),archiveSha256:sha(original),checks,error};
result.pass=!error&&checks.length===6&&checks.every(c=>c.pass);fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
})();
