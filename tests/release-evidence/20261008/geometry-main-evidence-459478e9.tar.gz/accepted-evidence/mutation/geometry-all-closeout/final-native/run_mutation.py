import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/workspace/geometry-final')
OUT = Path('/workspace/scratch/geometry-all-closeout/final-native')
sys.path.insert(0, str(ROOT / 'tests'))
import mutate

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    p = subprocess.run(['git', *args], cwd=ROOT, text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout.strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identity():
    src = mutate.Sources(ROOT)
    names = sorted({s['scene'] for s in mutate.TESTS} | {'tests/run_tests.py'})
    oracle_files = {n: hashlib.sha256((ROOT / n).read_bytes().replace(b'\r\n', b'\n')).hexdigest() for n in names}
    return {'timestamp': utc(), 'root': str(ROOT), 'head': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1'),
            'closure_sha256': src.closure, 'source_files_normalized_sha256': src.hashes,
            'oracle_sha256': mutate.oracle_hash(), 'oracle_files_normalized_sha256': oracle_files,
            'tool_sha256': mutate.tool_hash(), 'compile_sha256': mutate.compile_hash(),
            'stack_limit_bytes': list(resource.getrlimit(resource.RLIMIT_STACK)),
            'mutation_ids': [m['id'] for m in mutate.MUTANTS]}

def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

OUT.mkdir(parents=True, exist_ok=True)
result = Path(os.environ['MUTATE_RESULTS'])
if result.exists():
    raise SystemExit('Refusing to overwrite pre-existing scratch results')
if resource.getrlimit(resource.RLIMIT_STACK)[0] != 16777216:
    raise SystemExit('Expected inherited 16 MiB stack limit')
before = identity()
write('mutation-before.json', before)
cmd = [sys.executable, 'tests/mutate.py']
started = utc()
t0 = time.monotonic()
with (OUT / 'mutation-full.log').open('w') as log:
    p = subprocess.Popen(cmd, cwd=ROOT, env={**os.environ, 'PYTHONUNBUFFERED':'1'}, stdout=log, stderr=subprocess.STDOUT)
    write('mutation-process.json', {'command': cmd, 'cwd': str(ROOT), 'pid': p.pid, 'started': started,
                                   'MUTATE_RESULTS': str(result), 'MUTATE_CACHE': os.environ['MUTATE_CACHE'],
                                   'stack_limit_bytes': before['stack_limit_bytes']})
    print('mutation PID', p.pid, 'head', before['head'], 'closure', before['closure_sha256'], flush=True)
    code = p.wait()
after = identity()
write('mutation-after.json', after)
counts = collections.Counter()
execution_heads = collections.Counter()
records = json.loads(result.read_text()) if result.exists() else {}
for rec in records.values():
    counts[rec.get('verdict', 'missing')] += 1
    if rec.get('execution'):
        execution_heads[rec['execution']['head']] += 1
receipt = {'schema': 'geometry-full-mutation-wrapper/1', 'command': cmd, 'cwd': str(ROOT),
           'started': started, 'ended': utc(), 'duration_seconds': time.monotonic()-t0, 'exitCode': code,
           'before': before, 'after': after, 'fullScope': True, 'selectedIds': [],
           'sourceClosureUnchanged': before['closure_sha256'] == after['closure_sha256'],
           'oracleUnchanged': before['oracle_sha256'] == after['oracle_sha256'],
           'toolUnchanged': before['tool_sha256'] == after['tool_sha256'],
           'recordCount': len(records), 'counts': dict(counts), 'executionHeads': dict(execution_heads),
           'log_sha256': sha(OUT / 'mutation-full.log'),
           'results_sha256': sha(result) if result.exists() else None,
           'note': 'Raw subprocess log and unchanged tool-generated result retained. No result head rewriting.'}
write('mutation-execution.json', receipt)
(OUT / 'mutation-full.exit').write_text(str(code) + '\n')
print(json.dumps({k:receipt[k] for k in ['exitCode','recordCount','counts','executionHeads','sourceClosureUnchanged','oracleUnchanged','toolUnchanged']}, ensure_ascii=False), flush=True)
sys.exit(code)
