import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/geometry-final')
OUT = Path('/workspace/scratch/geometry-all-closeout/final-native')
sys.path.insert(0, str(ROOT / 'tests'))
import mutate

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

records = json.loads((OUT / 'mutants_results.json').read_text())
execution = json.loads((OUT / 'mutation-execution.json').read_text())
src = mutate.Sources(ROOT)
oracle = mutate.oracle_hash()
checks = []
def check(name, ok, detail=None):
    checks.append({'name': name, 'pass': bool(ok), 'detail': detail})

ids = [m['id'] for m in mutate.MUTANTS]
check('exact 48 registered IDs with no extras', len(ids) == 48 and set(records) == set(ids), sorted(records))
check('full command has no mutant selection arguments', execution['command'][1:] == ['tests/mutate.py'])
check('full run exit zero', execution['exitCode'] == 0, execution['exitCode'])
check('source closure unchanged through run and now', execution['before']['closure_sha256'] == execution['after']['closure_sha256'] == src.closure, src.closure)
check('oracle unchanged through run and now', execution['before']['oracle_sha256'] == execution['after']['oracle_sha256'] == oracle, oracle)
check('tool unchanged through run and now', execution['before']['tool_sha256'] == execution['after']['tool_sha256'] == mutate.tool_hash())
check('raw result matches execution receipt', sha(OUT / 'mutants_results.json') == execution['results_sha256'])
check('raw log matches execution receipt', sha(OUT / 'mutation-full.log') == execution['log_sha256'])
check('stack limit was 16 MiB', execution['before']['stack_limit_bytes'][0] == 16777216)
table = mutate.evaluate_table(mutate.MUTANTS, records, src, datetime.date.today().isoformat(), oracle, require_execution=True)
counts = mutate.tally(table)
check('strict evaluated table has no stale/invalid/blocked/survived/unrun', not any(counts[k] for k in ['stale','invalid','blocked','survived','unrun']), counts)
check('expected classifications retained', {k:counts[k] for k in ['killed','crashed','equivalent','retired']} == {'killed':40,'crashed':1,'equivalent':4,'retired':3}, counts)
active = [r for r in records.values() if r['verdict'] != 'retired']
check('45 non-retired records have real execution receipts', len(active) == 45 and all(r.get('execution') for r in active))
check('actual execution heads preserved', {r['execution']['head'] for r in active} == {execution['before']['head']}, sorted({r['execution']['head'] for r in active}))
baseline_digests = {hashlib.sha256(json.dumps(r['execution']['baseline'],sort_keys=True).encode()).hexdigest() for r in active}
check('one shared unmodified baseline receipt', len(baseline_digests) == 1)
baseline = active[0]['execution']['baseline']
check('baseline has 139 passing case results', baseline.get('exit_code') == 0 and baseline['result']['counts'] == {'pass':139,'fail':0,'infrastructure':0} and len(baseline['result']['cases']) == 139, baseline)
check('all four equivalent mutants actually executed and survived complete oracle', all(r['execution']['attempts'][-1]['exit_code'] == 0 and r['execution']['attempts'][-1]['result']['counts'] == {'pass':139,'fail':0,'infrastructure':0} for r in active if r['verdict']=='equivalent'))
retired = [r for r in records.values() if r['verdict'] == 'retired']
check('retired records not relabeled with execution', len(retired)==3 and all('execution' not in r for r in retired))
git = subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True).stdout.strip()
report = {'schema':'geometry-mutation-independent-census/1','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditHead':git,'executionHead':execution['before']['head'],'closureSha256':src.closure,'counts':counts,'checks':checks,'pass':all(c['pass'] for c in checks),'scope':'Independent census/provenance audit of complete tool-generated records; no tests or judgments rewritten.'}
(OUT/'mutation-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass':report['pass'],'checkCount':len(checks),'counts':counts,'failed':[c['name'] for c in checks if not c['pass']]},ensure_ascii=False))
sys.exit(0 if report['pass'] else 1)
