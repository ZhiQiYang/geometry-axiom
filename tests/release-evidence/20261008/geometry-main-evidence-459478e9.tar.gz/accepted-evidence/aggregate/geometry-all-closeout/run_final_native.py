"""Run the actual aggregate with an isolated binary registry, without shell overrides."""
import resource
import runpy
import sys
from pathlib import Path

root = Path('/workspace/geometry-final')
sys.path.insert(0, str(root / 'tests'))
import binaries

binaries.OUT_DIR = Path('/tmp/geometry-final-native')
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
minimum = 16 * 1024 * 1024
if soft != resource.RLIM_INFINITY and soft < minimum:
    resource.setrlimit(resource.RLIMIT_STACK, (minimum, hard))
sys.argv = [str(root / 'tests/run_all.py'), *sys.argv[1:]]
runpy.run_path(sys.argv[0], run_name='__main__')
