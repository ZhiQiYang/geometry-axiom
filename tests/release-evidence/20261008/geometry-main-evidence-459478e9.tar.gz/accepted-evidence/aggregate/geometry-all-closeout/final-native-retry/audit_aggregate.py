import datetime,hashlib,json,re,sys
from pathlib import Path
OUT=Path('/workspace/scratch/geometry-all-closeout/final-native-retry')
ROOT=Path('/workspace/geometry-final')
BASE=Path('/workspace/scratch/geometry-all-closeout/aggregate-before.json')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
execution=read(OUT/'aggregate-execution.json')
before=read(OUT/'aggregate-before-identity.json'); after=read(OUT/'aggregate-after-identity.json')
base=read(BASE)['suites']; old=read(OUT/'aggregate-expected-before.json')['suites']; new=read(OUT/'aggregate-expected-after.json')['suites']
registry={r['name']:r for r in before['registry']}
log=(OUT/'aggregate-full.log').read_text()
checks=[]
def ck(n,ok,d=None):checks.append({'name':n,'pass':bool(ok),'detail':d})
rows=[]
for i,line in enumerate(log.splitlines(),1):
 m=re.match(r'^(\S+)\s+(\d+|-)\s+(\d+|ok|-)\s+(\d+|FAIL|-)\s+(\d+|-)\s+([\d.]+|-)\s*(.*)$',line)
 if m and m[1] in registry:
  rows.append(dict(name=m[1],total=int(m[2]) if m[2].isdigit() else m[2],passed=int(m[3]) if m[3].isdigit() else m[3],failed=int(m[4]) if m[4].isdigit() else m[4],skipped=int(m[5]) if m[5].isdigit() else m[5],seconds=float(m[6]) if m[6]!='-' else None,note=m[7],line=i))
by={r['name']:r for r in rows}
ck('82 unique rows equal registry',len(rows)==len(by)==len(new)==len(registry)==82 and set(by)==set(registry)==set(new))
ck('82 progress entries in full registry order',re.findall(r'^\[(\d+)/(\d+)\] (\S+) …$',log,re.M)==[(str(i+1),'82',n) for i,n in enumerate(registry)])
ck('all prior 81 suites retained',len(base)==len(old)==81 and set(base)<=set(new) and set(old)<=set(new))
down=[n for n,v in base.items() if new.get(n,{}).get('mode')!=v['mode'] or (v['mode']=='count' and new.get(n,{}).get('count',-1)<v['count'])]
ck('no decreases or changed count modes',not down,down)
changes={n:{'baseline':base.get(n),'freeze':old.get(n),'final':v} for n,v in new.items() if v!=base.get(n)}
planned={'py:test_section_profile_modeling':19,'py:test_section_profile_native':26,'py:test_modeling_transport':3,'node:tests-js':636}
ck('only expected four scope changes',set(changes)==set(planned) and all(new[k].get('count')==v for k,v in planned.items()),changes)
ck('only new modeling suite',set(new)-set(base)=={'py:test_section_profile_modeling'})
bad=[]; ex=[]
for n,v in new.items():
 r=by.get(n,{})
 if v['mode']=='count':
  if r.get('total')!=v['count']:bad.append(n)
 else:
  ex.append(n)
  if r.get('total')!='-' or (r.get('passed')!='ok' and not(n=='mutation:check' and r.get('note')=='mutation inventory freshness (not test assertions); exit 0')):bad.append(n)
ck('every row equals expected with six exit-only cases',not bad and len(ex)==6,bad)
counted=[r for r in rows if isinstance(r['total'],int)]
tot={k:sum(r[k] for r in counted) for k in ('total','passed','failed','skipped')}
m=re.search(r'^合計\(已執行、有計數者\)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+',log,re.M)
ck('independent summed totals match print',m and list(tot.values())==list(map(int,m.groups())),tot)
ck('all row arithmetic complete and no failures',all(r['total']==r['passed']+r['failed']+r['skipped'] and r['failed']==0 for r in counted))
gdi=read(OUT/'aggregate-suite-logs/py_test_gdi_contract.json')
skips=[r for r in counted if r['skipped']]
ck('one exact named Windows GDI skip',len(skips)==1 and skips[0]['name']=='py:test_gdi_contract' and skips[0]['skipped']==1 and gdi['skipped']==1 and 'test_gdi_contract.GdiContract.test_confirmed_failures_release_real_resources' in json.dumps(gdi) and 'requires compiled Windows GDI contract harness' in json.dumps(gdi),gdi['skip_items'])
bad=[]
for n,s in registry.items():
 if s['kind']=='unittest':
  d=read(OUT/'aggregate-suite-logs'/(n.replace(':','_')+'.json')); r=by[n]
  if any(d[k]!=r[k] for k in ('total','passed','failed','skipped')) or d.get('blocked_by_error') or d.get('import_error') or d.get('extra_errors'):bad.append(n)
ck('all unittest raw structured counts agree independently',not bad,bad)
ck('real process exit zero and strict complete terminal',execution['exitCode']==0 and (OUT/'aggregate-full.exit').read_text().strip()=='0' and re.search(r'^exit 0：完整非瀏覽器登錄測試',log,re.M))
ck('exact clean head stable',before['head']==after['head']==execution['executionHead']=='07bca2991ec7984b18b11792bbdbd2e7616dc0c1' and before['status']=='')
ck('only expected artifact changed during run',set(execution['trackedChanges'])=={'tests/run_all.expected.json'})
ck('all binary source closures unchanged',execution['binarySourcesUnchanged'] and before['binarySources']==after['binarySources'])
ck('mutation source and oracle unchanged',execution['mutationClosureUnchanged'] and execution['mutationOracleUnchanged'])
ck('aggregate and wrappers unchanged',before['trackedFilesSha256']['tests/run_all.py']==after['trackedFilesSha256']['tests/run_all.py'] and execution['driverUnchanged'] and before['wrapperSha256']==after['wrapperSha256'])
ck('no filters/allow-skip/registry errors',execution['fullScope'] and not execution['filters'] and not execution['allowSkip'] and not execution['registryErrors'])
ck('16MiB stack inherited',before['stackLimitBytes'][0]==after['stackLimitBytes'][0]==16777216)
ck('raw log checksum intact',sha(OUT/'aggregate-full.log')==execution['logSha256'])
bi=read(OUT/'aggregate-binaries-after.json')
ck('all applicable binary identities fresh',all(v['state']=='fresh' for k,v in bi.items() if k!='gdi') and bi['gdi']['state']=='n/a')
ck('formal expected identical to discovery bytes',(ROOT/'tests/run_all.expected.json').read_bytes()==(OUT/'aggregate-expected-after.json').read_bytes())
mu=(OUT/'aggregate-suite-logs/mutation_check.log').read_text()
ck('mutation formal check complete and fresh',all(s in mu for s in ['變異表 48 筆,紀錄 48 筆','killed 40','crashed 1','equivalent 4','survived 0','invalid 0','stale 0','blocked 0','retired 3']))
report={'schema':'geometry-aggregate-independent-review/2','reviewer':'/root/github_progress','method':'Independent external summary parser, raw unittest JSON and closure verification; run_all.py unchanged. Prior red attempt separately reviewed by evidence_audit.','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'overallPassed':all(c['pass'] for c in checks),'executionHead':execution['executionHead'],'checks':checks,'suiteCounts':{'baseline':81,'freeze':81,'final':82,'rows':len(rows),'exitOnly':len(ex)},'totals':tot,'expectedTransitions':changes,'rows':rows,'priorRedReceiptSha256':sha(OUT.parent/'final-native/aggregate-independent-review.json'),'limitation':'Non-browser aggregate only; standalone browser/Windows/device/IME/OS picker not inferred.'}
(OUT/'aggregate-independent-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass':report['overallPassed'],'checkCount':len(checks),'totals':tot,'failed':[c['name'] for c in checks if not c['pass']]},ensure_ascii=False))
sys.exit(0 if report['overallPassed'] else 1)
