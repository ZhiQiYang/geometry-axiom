import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/geometry-final')
OUT = Path('/workspace/scratch/geometry-all-closeout/final-native-retry')
FROZEN_HEAD = '07bca2991ec7984b18b11792bbdbd2e7616dc0c1'
DRIVER = Path('/workspace/scratch/geometry-all-closeout/run_final_native.py')
sys.path.insert(0, str(ROOT / 'tests'))
import binaries
binaries.OUT_DIR = Path('/tmp/geometry-final-native')
import run_all
import mutate

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.run(['git',*args],cwd=ROOT,capture_output=True,text=True,check=True).stdout.strip()

def identity():
    paths = subprocess.run(['git','ls-files','-z'],cwd=ROOT,capture_output=True,check=True).stdout.decode().split('\0')
    tracked = {p:sha(ROOT/p) for p in paths if p and (ROOT/p).is_file()}
    binary_sources = {}
    for b in binaries.REGISTRY:
        if b.applicable():
            fp, files, command = binaries.compute_fingerprint(b)
            binary_sources[b.name]={'fingerprint':fp,'files':files,'command':command}
    return {'time':utc(),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
            'status':git('status','--porcelain=v1'),'trackedFilesSha256':tracked,
            'binarySources':binary_sources,'mutationClosure':mutate.Sources(ROOT).closure,
            'mutationOracle':mutate.oracle_hash(),'stackLimitBytes':list(resource.getrlimit(resource.RLIMIT_STACK)),
            'driverSha256':sha(DRIVER),'wrapperSha256':sha(Path(__file__)),
            'registry':[{'name':s.name,'kind':s.kind,'counted':s.counted,'needs':s.needs} for s in run_all.build_suites()],
            'registryErrors':run_all.check_registry()}

def write(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

if (OUT/'aggregate-execution.json').exists() or (OUT/'aggregate-full.log').exists():
    raise SystemExit('Refusing to overwrite an existing aggregate attempt')
if git('rev-parse','HEAD') != FROZEN_HEAD or git('status','--porcelain=v1'):
    raise SystemExit('Expected exact clean frozen head')
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
before=identity()
write('aggregate-before-identity.json',before)
shutil.copyfile(ROOT/'tests/run_all.expected.json',OUT/'aggregate-expected-before.json')
cmd=[sys.executable,str(DRIVER),'--build','--update-expected']
started=utc()
t0=time.monotonic()
with (OUT/'aggregate-full.log').open('w') as log:
    proc=subprocess.Popen(cmd,cwd=ROOT,env={**os.environ,'PYTHONUNBUFFERED':'1'},stdout=log,stderr=subprocess.STDOUT)
    write('aggregate-process.json',{'command':cmd,'cwd':str(ROOT),'pid':proc.pid,'started':started,'MUTATE_CACHE':os.environ.get('MUTATE_CACHE'),'binaryDirectory':str(binaries.OUT_DIR),'stackLimitBytes':before['stackLimitBytes']})
    print('aggregate PID',proc.pid,'head',before['head'],'suites',len(before['registry']),flush=True)
    code=proc.wait()
after=identity()
write('aggregate-after-identity.json',after)
shutil.copyfile(ROOT/'tests/run_all.expected.json',OUT/'aggregate-expected-after.json')
if run_all.LOG_DIR.exists():
    shutil.copytree(run_all.LOG_DIR,OUT/'aggregate-suite-logs',dirs_exist_ok=False)
binary_infos={k:v.as_dict() for k,v in binaries.inspect_all().items()}
write('aggregate-binaries-after.json',binary_infos)
sidecars={p.name:json.loads(p.read_text()) for p in binaries.OUT_DIR.glob('*.fingerprint.json')}
write('aggregate-binary-fingerprints.json',sidecars)
diffs={p:{'before':before['trackedFilesSha256'].get(p),'after':after['trackedFilesSha256'].get(p)} for p in before['trackedFilesSha256'].keys()|after['trackedFilesSha256'].keys() if before['trackedFilesSha256'].get(p)!=after['trackedFilesSha256'].get(p)}
receipt={'schema':'geometry-full-aggregate-execution/1','command':cmd,'cwd':str(ROOT),'started':started,'ended':utc(),'durationSeconds':time.monotonic()-t0,'exitCode':code,'executionHead':before['head'],'headAfter':after['head'],'fullScope':True,'filters':[],'allowSkip':False,'trackedChanges':diffs,'binarySourcesUnchanged':before['binarySources']==after['binarySources'],'mutationClosureUnchanged':before['mutationClosure']==after['mutationClosure'],'mutationOracleUnchanged':before['mutationOracle']==after['mutationOracle'],'driverUnchanged':before['driverSha256']==after['driverSha256'],'logSha256':sha(OUT/'aggregate-full.log'),'expectedBeforeSha256':sha(OUT/'aggregate-expected-before.json'),'expectedAfterSha256':sha(OUT/'aggregate-expected-after.json'),'registryCount':len(before['registry']),'registryErrors':before['registryErrors'],'note':'Actual run_all.py executed unchanged through supplied binary-directory/stack wrapper; counts audited separately from raw logs.'}
write('aggregate-execution.json',receipt)
(OUT/'aggregate-full.exit').write_text(str(code)+'\n')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
sys.exit(code)
