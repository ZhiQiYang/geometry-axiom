'use strict';
const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto');
const {chromium}=require('playwright'),root='/workspace/geometry-final',out=process.argv[2];
const {waitCardCanvasPos}=require(root+'/geometry-web/cdp_helpers.js'),{createRetainedEvaluator}=require(root+'/geometry-web/cdp_evaluation.js');
if(fs.existsSync(out))throw Error('Fresh output required');fs.mkdirSync(out,{recursive:true});
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const identity=async()=>({head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}),runtime:await(await fetch('http://127.0.0.1:8834/runtime')).json(),helperSHA256:sha(root+'/geometry-web/cdp_helpers.js'),harnessSHA256:sha(__filename)});
(async()=>{
 const result={command:['node',__filename,out],started:new Date().toISOString(),beforeIdentity:await identity(),expected:5,cases:[],browserErrors:[],scope:'True first-position card drag. Fixture uses native DSL and renderObjects({persistPositions:false}); only actual canvas-pos dispatch held. No fabricated geometry reply. Local-unpositioned transition is covered by Node controls, not claimed as browser setup.'};
 const check=(name,passed)=>{result.cases.push({name,passed:passed===true});if(passed!==true)throw Error(name);};
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}),page=await browser.newPage({viewport:{width:1440,height:1000}});
 page.on('pageerror',e=>result.browserErrors.push(String(e)));
 try{
 await page.goto('http://127.0.0.1:8834/');await page.waitForFunction(()=>connection.phase==='ready');const session=await page.context().newCDPSession(page),read=createRetainedEvaluator((m,p)=>session.send(m,p),r=>{if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;});
 await read(`(async()=>{resetSceneFocus();await apiRequest('reset');const r=await apiRequest('line boundary 902 outline 0,0 2400,0 2400,2400 0,2400');if(!r.ok)throw Error(JSON.stringify(r));await renderObjects({persistPositions:false});selectObject('boundary',902);centerOnNode('boundary',902);setOcTool('select');})()`);
 result.before=await read(`(async()=>{window.__firstHistory={frame:ReferenceWorkspace.history.frame,undo:ReferenceWorkspace.history.undo.slice(),redo:ReferenceWorkspace.history.redo.slice()};return {native:(await apiRequest('objects')).faces.find(o=>o.id===902),local:ocFind('boundary',902),dump:(await apiRequest('dump')).text,zoom:oc.zoom};})()`);
 check('real rendered card has no persisted native position',result.before.native.hasPos===false&&result.before.local.hasPos===true&&!result.before.dump.includes('canvas-pos boundary 902 '));
 await read(`(()=>{const original=apiRequest,g=window.__firstPosition={held:false,reads:0};const gate=new Promise(resolve=>g.release=resolve);g.restore=()=>apiRequest=original;apiRequest=async(...args)=>{if(args[0].startsWith('line canvas-pos boundary 902 ')){g.command=args[0];g.held=true;await gate;}const r=await original(...args);if(args[0]==='objects')g.reads++;return r;};})()`);
 const hit=await read(`(()=>{const e=document.querySelector('.ocard[data-kind="boundary"][data-id="902"]'),r=e.getBoundingClientRect(),x=r.x+50,y=r.y+20;return {x,y,hit:e.contains(document.elementFromPoint(x,y))};})()`);if(!hit.hit)throw Error('Card covered');
 await page.mouse.move(hit.x,hit.y);await page.mouse.down();await page.mouse.move(hit.x+80,hit.y+40,{steps:8});await page.mouse.up();await page.waitForFunction(()=>__firstPosition.held);
 let settled=false;const p=waitCardCanvasPos(read,{kind:'boundary',id:902,beforeCx:result.before.local.cx,beforeCy:result.before.local.cy,timeoutMs:4000,pollMs:25}).then(value=>{settled=true;return value;});
 await page.waitForFunction(()=>__firstPosition.reads>=2);
 result.held=await read(`(async()=>({native:(await apiRequest('objects')).faces.find(o=>o.id===902),dump:(await apiRequest('dump')).text}))()`);
 check('first unpersisted position remains pending while actual write is held',!settled&&result.held.native.hasPos===false&&result.held.dump===result.before.dump);
 await read('__firstPosition.restore();__firstPosition.release();void 0');result.commit=await p;
 result.after=await read(`(async()=>{const h=ReferenceWorkspace.history,p=__firstHistory,same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);return {native:(await apiRequest('objects')).faces.find(o=>o.id===902),local:ocFind('boundary',902),dump:(await apiRequest('dump')).text,command:__firstPosition.command,historyUnchanged:h.frame===p.frame&&same(h.undo,p.undo)&&same(h.redo,p.redo)};})()`);await page.screenshot({path:out+'/after.png'});
 check('single released drag persists and converges before helper succeeds',result.commit.ok===true&&result.after.native.hasPos===true&&result.after.native.cx===result.after.local.cx&&result.after.native.cy===result.after.local.cy&&result.after.native.cx!==result.before.local.cx);
 check('only the new position line changes and history stays intact',result.after.dump===result.before.dump+result.after.command.replace(/^line /,'')+'\n'&&result.after.historyUnchanged);
 check('browser has no uncaught exceptions',result.browserErrors.length===0);result.completed=result.cases.length===result.expected;
 }catch(e){result.completed=false;result.error=e.stack;await page.screenshot({path:out+'/failure.png'});}
 finally{result.afterIdentity=await identity();result.identityStable=JSON.stringify(result.beforeIdentity)===JSON.stringify(result.afterIdentity);result.finished=new Date().toISOString();result.passed=result.cases.filter(c=>c.passed).length;result.failed=result.cases.filter(c=>!c.passed).length;result.exitCode=result.completed&&result.identityStable?0:1;fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n');console.log('FIRST_POSITION_RESULT '+JSON.stringify(result));await browser.close();process.exitCode=result.exitCode;}
})();
