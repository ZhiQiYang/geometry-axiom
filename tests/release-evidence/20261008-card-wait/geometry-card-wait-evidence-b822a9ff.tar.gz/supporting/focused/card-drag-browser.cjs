'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const {chromium}=require('playwright');
const root='/workspace/geometry-final',url='http://127.0.0.1:8834/',out=process.argv[2];
if(!out||fs.existsSync(out))throw Error('Fresh explicit output required');fs.mkdirSync(out,{recursive:true});
const {waitCardCanvasPos}=require(root+'/geometry-web/cdp_helpers.js');
const {createRetainedEvaluator}=require(root+'/geometry-web/cdp_evaluation.js');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const identity=async()=>({head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}),runtime:await (await fetch(url+'runtime')).json(),helperSHA256:sha(root+'/geometry-web/cdp_helpers.js'),harnessSHA256:sha(__filename)});
const kinds=[['boundary',901,'faces'],['column',901,'columns'],['grid-binding',901,'gridBindings'],['assembly-rule',1,'assemblyRules']];
const labels=['persisted initial identity','pending native write stays uncommitted','pending reply waits for local convergence','actual committed position and DOM agree','exact single position change preserves definitions and history'];
const result={schema:'geometry-card-drag-browser/1',command:['node',__filename,out],started:new Date().toISOString(),expected:20,cases:[],browserErrors:[],consoleErrors:[],scope:'Four actual desktop card drags through trusted pointer input; native fixture uses official assembly project and DSL. Actual canvas-pos request held before native dispatch and actual response held before local update. No geometry reply fabricated. Focused helper regression, not full CDP or native aggregate.'};
function check(name,passed,details){result.cases.push({name,passed:passed===true,details});if(passed!==true)throw Error(name);}
(async()=>{
 result.before=await identity();let browser,page,read;
 try {
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  page=await browser.newPage({viewport:{width:1440,height:1000}});page.on('pageerror',e=>result.browserErrors.push(String(e)));page.on('console',m=>{if(m.type()==='error')result.consoleErrors.push(m.text());});
  await page.goto(url);await page.waitForFunction(()=>typeof SpaceModelWorkspace==='object'&&connection.phase==='ready');
  const session=await page.context().newCDPSession(page);
  read=createRetainedEvaluator((method,args)=>session.send(method,args),response=>{if(response.exceptionDetails)throw Error(response.exceptionDetails.exception?.description||response.exceptionDetails.text);return response.result.value;});
  await read(`(async()=>{const r=await fetch('/examples/assembly-rules-v1.gcanvas');if(!r.ok)throw Error('missing fixture');await ReferenceWorkspace.importBytes(new Uint8Array(await r.arrayBuffer()),'assembly-rules-v1.gcanvas');resetSceneFocus();await setView3(false);for(const line of ${JSON.stringify(['boundary 901 outline 0,0 2400,0 2400,2400 0,2400','boundary-vertex-keys 901 outer 1 2 3 4 next-key 5','grid-system 901 name-hex 50726f6265 main-along none u repeat 0 400 v repeat 0 600','grid-binding 901 on-boundary 901 from-system 901 vertex-key 1 cell 0 0 anchor 0 1 0 1','column 901 at 5000 5000 size 400 400 z 0 2600','canvas-pos boundary 901 1500 100','canvas-pos column 901 2000 100','canvas-pos grid-binding 901 1500 600','canvas-pos assembly-rule 1 2000 600'])}){let a=await apiRequest('line '+line);if(a.preview){if(!a.preview.valid)throw Error(JSON.stringify(a));a=await apiRequest('line confirm '+a.preview.token);}if(!a.ok)throw Error(JSON.stringify(a));}await renderObjects();closePanels();setOcTool('select');})()`);
  fs.writeFileSync(path.join(out,'initial-world.scene'),await read(`apiRequest('dump').then(r=>r.text)`));
  for(const [kind,id,list] of kinds){
   await read(`selectObject(${JSON.stringify(kind)},${id});centerOnNode(${JSON.stringify(kind)},${id});void 0`);
   const before=await read(`(async()=>{const r=await apiRequest('objects'),o=r[${JSON.stringify(list)}].find(x=>x.id===${id}${kind==='boundary'?'&&x.kind===\'boundary\'':''}),local=ocFind(${JSON.stringify(kind)},${id});window.__dragHistory={frame:ReferenceWorkspace.history.frame,undo:ReferenceWorkspace.history.undo.slice(),redo:ReferenceWorkspace.history.redo.slice()};return {native:o,local:{cx:local.cx,cy:local.cy,hasPos:local.hasPos},dump:(await apiRequest('dump')).text,zoom:oc.zoom,snap:$('snapToggle').classList.contains('on')};})()`);
   check(kind+' '+labels[0],before.native.hasPos===true&&before.local.hasPos===true&&before.native.cx===before.local.cx&&before.native.cy===before.local.cy&&Number.isFinite(before.local.cx)&&Number.isFinite(before.local.cy),before);
   await read(`(()=>{const original=apiRequest,g=window.__dragGate={phase:'ready',reads:0,commands:[],kind:${JSON.stringify(kind)},id:${id}};const dispatch=new Promise(resolve=>g.dispatch=resolve),reply=new Promise(resolve=>g.reply=resolve);g.restore=()=>apiRequest=original;apiRequest=async(...args)=>{const cmd=args[0];if(cmd.startsWith('line canvas-pos ')){g.commands.push(cmd);if(g.commands.length!==1)throw Error('more than one position mutation');g.phase='write-held';await dispatch;const r=await original(...args);g.nativeReply=r;g.phase='reply-held';await reply;g.phase='released';return r;}const r=await original(...args);if(cmd==='objects')g.reads++;return r;};})()`);
   const hit=await read(`(()=>{const e=document.querySelector('.ocard[data-kind="${kind}"][data-id="${id}"]'),r=e.getBoundingClientRect(),x=r.x+Math.min(50,r.width/3),y=r.y+18;return {x,y,hit:e.contains(document.elementFromPoint(x,y))};})()`);
   if(!hit.hit)throw Error('Actual card is covered: '+kind);
   await page.mouse.move(hit.x,hit.y);await page.mouse.down();await page.mouse.move(hit.x+80,hit.y+40,{steps:8});await page.mouse.up();await page.waitForFunction(()=>__dragGate.phase==='write-held');
   let settled=false;const pending=waitCardCanvasPos(read,{kind,id,beforeCx:before.native.cx,beforeCy:before.native.cy,timeoutMs:4000,pollMs:25}).then(value=>{settled=true;return value;});
   await page.waitForFunction(()=>__dragGate.reads>=2);
   const held=await read(`(async()=>({phase:__dragGate.phase,dump:(await apiRequest('dump')).text,local:{cx:ocFind(${JSON.stringify(kind)},${id}).cx,cy:ocFind(${JSON.stringify(kind)},${id}).cy},commands:__dragGate.commands.slice(),reads:__dragGate.reads}))()`);
   check(kind+' '+labels[1],!settled&&held.phase==='write-held'&&held.dump===before.dump&&held.local.cx===before.local.cx&&held.local.cy===before.local.cy&&held.commands.length===1,held);
   await read(`__dragGate.dispatch();void 0`);await page.waitForFunction(()=>__dragGate.phase==='reply-held');const reads=await read('__dragGate.reads');await page.waitForFunction(n=>__dragGate.reads>=n+2,reads);
   const middle=await read(`(async()=>{const r=await apiRequest('objects');return {native:r[${JSON.stringify(list)}].find(x=>x.id===${id}${kind==='boundary'?'&&x.kind===\'boundary\'':''}),local:{cx:ocFind(${JSON.stringify(kind)},${id}).cx,cy:ocFind(${JSON.stringify(kind)},${id}).cy},reply:__dragGate.nativeReply,commands:__dragGate.commands.slice()};})()`);
   check(kind+' '+labels[2],!settled&&middle.reply.ok===true&&(middle.native.cx!==before.native.cx||middle.native.cy!==before.native.cy)&&middle.local.cx===before.local.cx&&middle.local.cy===before.local.cy,middle);
   await read(`__dragGate.reply();void 0`);const commit=await pending;
   const after=await read(`(async()=>{const r=await apiRequest('objects'),o=r[${JSON.stringify(list)}].find(x=>x.id===${id}${kind==='boundary'?'&&x.kind===\'boundary\'':''}),local=ocFind(${JSON.stringify(kind)},${id}),h=ReferenceWorkspace.history,p=__dragHistory,same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);return {native:o,local:{cx:local.cx,cy:local.cy,hasPos:local.hasPos},dump:(await apiRequest('dump')).text,historyUnchanged:h.frame===p.frame&&same(h.undo,p.undo)&&same(h.redo,p.redo),transform:document.querySelector('.ocard[data-kind="${kind}"][data-id="${id}"]').getAttribute('transform'),commands:__dragGate.commands.slice()};})()`);
   const coords=after.commands[0].split(/\s+/).slice(-2).map(Number),expectedRaw=[before.native.cx+80/before.zoom,before.native.cy+40/before.zoom],expected=expectedRaw.map(v=>Math.round(before.snap?Math.round(v/20)*20:v));
   check(kind+' '+labels[3],commit.ok===true&&coords.every((n,i)=>n===expected[i])&&after.native.cx===coords[0]&&after.native.cy===coords[1]&&after.local.cx===coords[0]&&after.local.cy===coords[1]&&after.transform===`translate(${coords[0]},${coords[1]})`,{commit,after,expected});
   const oldLine=`canvas-pos ${kind} ${id} ${before.native.cx} ${before.native.cy}`,newLine=`canvas-pos ${kind} ${id} ${coords[0]} ${coords[1]}`;
   check(kind+' '+labels[4],before.dump.split('\n').filter(x=>x===oldLine).length===1&&after.dump===before.dump.split('\n').map(x=>x===oldLine?newLine:x).join('\n')&&after.historyUnchanged&&after.commands.length===1,{oldLine,newLine,historyUnchanged:after.historyUnchanged});
   await page.screenshot({path:path.join(out,kind+'-committed.png')});await read('__dragGate.restore();void 0');
  }
  fs.writeFileSync(path.join(out,'final-world.scene'),await read(`apiRequest('dump').then(r=>r.text)`));
  if(result.cases.length!==result.expected||result.browserErrors.length||result.consoleErrors.length)throw Error('Completion census or browser health mismatch');
  result.completed=true;
 }catch(error){result.completed=false;result.error=error.stack||String(error);if(page)await page.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});}
 finally{result.after=await identity();result.identityStable=JSON.stringify(result.before)===JSON.stringify(result.after);result.passed=result.cases.filter(c=>c.passed).length;result.failed=result.cases.filter(c=>!c.passed).length;result.finished=new Date().toISOString();result.exitCode=result.completed&&result.identityStable?0:1;fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n');console.log('CARD_POSITION_RESULT '+JSON.stringify(result));await browser?.close();process.exitCode=result.exitCode;}
})();
