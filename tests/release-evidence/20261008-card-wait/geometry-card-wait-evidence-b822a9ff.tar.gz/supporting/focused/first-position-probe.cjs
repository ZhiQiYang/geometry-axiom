'use strict';
const fs=require('node:fs'),cp=require('node:child_process'),crypto=require('node:crypto');
const {chromium}=require('playwright'),root='/workspace/geometry-final',out=process.argv[2];
const {waitCardCanvasPos}=require(root+'/geometry-web/cdp_helpers.js'),{createRetainedEvaluator}=require(root+'/geometry-web/cdp_evaluation.js');
if(fs.existsSync(out))throw Error('Fresh output required');fs.mkdirSync(out,{recursive:true});
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const identity=async()=>({head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}),runtime:await(await fetch('http://127.0.0.1:8834/runtime')).json(),helperSHA256:sha(root+'/geometry-web/cdp_helpers.js'),harnessSHA256:sha(__filename)});
(async()=>{
 const result={command:['node',__filename,out],started:new Date().toISOString(),beforeIdentity:await identity(),scope:'True first-position card drag. Fixture uses native DSL and renderObjects({persistPositions:false}); only actual canvas-pos dispatch held. No fabricated geometry reply.'};
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}),page=await browser.newPage({viewport:{width:1440,height:1000}});
 try{
 await page.goto('http://127.0.0.1:8834/');await page.waitForFunction(()=>connection.phase==='ready');const session=await page.context().newCDPSession(page),read=createRetainedEvaluator((m,p)=>session.send(m,p),r=>{if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;});
 await read(`(async()=>{resetSceneFocus();await apiRequest('reset');const r=await apiRequest('line boundary 902 outline 0,0 2400,0 2400,2400 0,2400');if(!r.ok)throw Error(JSON.stringify(r));await renderObjects({persistPositions:false});selectObject('boundary',902);centerOnNode('boundary',902);setOcTool('select');})()`);
 result.before=await read(`(async()=>({native:(await apiRequest('objects')).faces.find(o=>o.id===902),local:ocFind('boundary',902),dump:(await apiRequest('dump')).text}))()`);
 if(result.before.native.hasPos!==false||result.before.local.hasPos!==true)throw Error('Fixture did not create native-unpositioned real card');
 await read(`(()=>{const original=apiRequest,g=window.__firstPosition={held:false};const gate=new Promise(resolve=>g.release=resolve);g.restore=()=>apiRequest=original;apiRequest=async(...args)=>{if(args[0].startsWith('line canvas-pos boundary 902 ')){g.command=args[0];g.held=true;await gate;}return original(...args);};})()`);
 const hit=await read(`(()=>{const e=document.querySelector('.ocard[data-kind="boundary"][data-id="902"]'),r=e.getBoundingClientRect(),x=r.x+50,y=r.y+20;return {x,y,hit:e.contains(document.elementFromPoint(x,y))};})()`);if(!hit.hit)throw Error('Card covered');
 await page.mouse.move(hit.x,hit.y);await page.mouse.down();await page.mouse.move(hit.x+80,hit.y+40,{steps:8});await page.mouse.up();await page.waitForFunction(()=>__firstPosition.held);
 const p=waitCardCanvasPos(read,{kind:'boundary',id:902,beforeCx:result.before.local.cx,beforeCy:result.before.local.cy,timeoutMs:1000,pollMs:25});
 result.helperWhileDispatchHeld=await p;
 await read('__firstPosition.restore();__firstPosition.release();void 0');await page.waitForFunction(()=>ocFind('boundary',902).cx!==60);
 result.after=await read(`(async()=>({native:(await apiRequest('objects')).faces.find(o=>o.id===902),local:ocFind('boundary',902),dump:(await apiRequest('dump')).text,command:__firstPosition.command}))()`);await page.screenshot({path:out+'/after.png'});
 result.reproducedPrematureFailure=result.helperWhileDispatchHeld.ok===false&&result.helperWhileDispatchHeld.reason==='invalid-position-record'&&result.after.native.hasPos===true&&result.after.native.cx===result.after.local.cx&&result.after.native.cy===result.after.local.cy;result.completed=true;
 }catch(e){result.completed=false;result.error=e.stack;await page.screenshot({path:out+'/failure.png'});}
 finally{result.afterIdentity=await identity();result.finished=new Date().toISOString();result.exitCode=result.completed?0:1;fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));await browser.close();process.exitCode=result.exitCode;}
})();
