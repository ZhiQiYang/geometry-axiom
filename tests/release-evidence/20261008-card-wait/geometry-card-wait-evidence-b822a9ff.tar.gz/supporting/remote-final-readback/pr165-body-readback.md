決策與驗收文件仍把已採納的 Q38、已合併的 #85／#119 修復及已有的 #77 owner 寫成待完成，容易讓後續工作重複等待。本次同步已查證狀態，保留各次原始驗收的時間、head 和限制。

目前 head `794569e809216b14c4956da5a50ccd4b4a368a43`；保留 PR165 原 README 修正與輔助核對，正常 merge main `5cc1ffa` 後更新：

- Q38 已採納的 D35–D40／I43–I51／R36–R40，與一般 profile、完成面、任意流程等未定範圍分開；目前僅 1A 第一個原生核心子切片在另一分支開發，完整 1A 未交付。
- #85 PR98、#119 PR124 已合併的狀態；#85 的 48 筆核對是既有收據 freshness check，不冒稱重跑變異。
- #77 正式 owner／adapter 已存在，獨立 gate 仍需分別執行。`run_all.py` 只有四筆排除原因文字更新。
- PR162 `bc1f6fe` 的新 35／33 與 80-suite 收尾、baseline `751471e` 的 CDP／Space／timber、舊 `a49d2a5` 的 A/B 82／34 及 cases 76 各自列出受測來源；保留原 PR165 歷史，不改標成目前 main 驗收。

驗證：**15 項文件／來源檢查、128 個連結與 diff check 通過**；AST 比對確認測試行為、floor、數量未變，公理／canonical reader 與 main 相同。沒有搬入 PR162 產品變更，也沒有因文件更新重跑整套產品測試。

詳見 [AUX-REVIEW-20261008.md](https://github.com/ZhiQiYang/geometry-axiom/blob/794569e809216b14c4956da5a50ccd4b4a368a43/geometry-web/docs/AUX-REVIEW-20261008.md)。PR 保持 draft，未 merge／部署；原 Windows／實體裝置／IME／OS picker 邊界與 hosted CI 帳務限制保持明示。

本 head 的 [Actions run 37730534281](https://github.com/ZhiQiYang/geometry-axiom/actions/runs/37730534281) 因帳戶付款／spending limit 未啟動：七個 jobs 均 failure、零 steps，非測試失敗結果。
