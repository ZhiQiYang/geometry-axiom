'use strict';
/* Independent bounded VM audit. Exact committed helper source and its generated
 * browser expression execute unchanged. API replies and clock are explicit
 * fixtures; this is not native/browser acceptance. No repository writes. */
const fs=require('node:fs'),vm=require('node:vm'),cp=require('node:child_process'),crypto=require('node:crypto'),path=require('node:path');
const repo='/workspace/geometry-final',original='a1b2f785e1bdcf13380c56b3b4c8c95093ea615c';
const final=process.argv[2],out=process.argv[3];
if(!/^[0-9a-f]{40}$/.test(final||'')||!out)throw Error('exact final SHA and external JSON output required');
if(path.resolve(out).startsWith(repo+path.sep))throw Error('output must be outside checkout');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const source=ref=>cp.execFileSync('git',['show',ref+':geometry-web/cdp_helpers.js'],{cwd:repo,encoding:'utf8'});
const originalSource=source(original),finalSource=source(final),harnessSource=fs.readFileSync(__filename);
function native(x=30,y=40,hasPos=true,kind='grid-binding',id=7){
  const record={id,cx:x,cy:y,hasPos,...(kind==='boundary'?{kind}:{} )};
  return {ok:true,[kind==='boundary'?'faces':'gridBindings']:[record]};
}
const local=(cx=30,cy=40,hasPos=true)=>({id:7,cx,cy,hasPos});
const scenarios=[
 {id:'converged-native-local',expected:'success',frames:[{reply:native(),local:local()}]},
 {id:'wait-until-both-converge',expected:'success',frames:[{reply:native(10,20),local:local(10,20)},{reply:native(),local:local(10,20)},{reply:native(),local:local()}],minimumReads:3},
 {id:'missing-both-native-and-local',expected:'reject',frames:[{reply:{ok:true,gridBindings:[]},local:null}]},
 {id:'missing-native-only',expected:'reject',frames:[{reply:{ok:true,gridBindings:[]},local:local()}]},
 {id:'missing-local-only',expected:'reject',frames:[{reply:native(),local:null}]},
 {id:'api-not-ok-even-with-coordinate-shaped-payload',expected:'reject',frames:[{reply:{...native(),ok:false,error:'Injected objects failure'},local:local()}]},
 {id:'native-hasPos-false',expected:'reject',frames:[{reply:native(30,40,false),local:local()}]},
 {id:'transient-native-hasPos-false-eventually-persisted',expected:'success',frames:[{reply:native(30,40,false),local:local()},{reply:native(),local:local()}],minimumReads:2},
 {id:'transient-local-hasPos-false-eventually-converged',expected:'success',frames:[{reply:native(),local:local(30,40,false)},{reply:native(),local:local()}],minimumReads:2},
 {id:'never-moved',expected:'reject',frames:[{reply:native(10,20),local:local(10,20)}]},
 {id:'native-local-never-match',expected:'reject',frames:[{reply:native(),local:local(10,20)}]},
 {id:'late-converged-response-after-deadline',expected:'reject',frames:[{delayMs:60,reply:native(),local:local()}]},
 {id:'read-never-resolves',expected:'reject',frames:[{never:true,reply:native(),local:local()}]},
 {id:'faces-boundary-list-converges',expected:'success',kind:'boundary',frames:[{reply:native(30,40,true,'boundary'),local:local()}]},
];
async function runOne(code,spec){
 let now=0,seq=0,active=null,frameIndex=0,reads=0;const timers=new Map(),events=[],errors=[];
 const schedule=(fn,ms=0,...args)=>{const id=++seq,handle={id,unref(){return this;}};timers.set(id,{at:now+Math.max(0,Number(ms)||0),fn:()=>fn(...args),handle});return handle;};
 const clear=handle=>timers.delete(typeof handle==='number'?handle:handle?.id);
 class ClockDate extends Date{static now(){return now;}}
 const module={exports:{}};
 const ctx=vm.createContext({module,exports:module.exports,require,console,Date:ClockDate,performance:{now:()=>now},setTimeout:schedule,clearTimeout:clear,Promise,AbortController,AbortSignal,Buffer,URL});
 vm.runInContext(code,ctx,{filename:'exact-cdp-helpers.js'});
 if(typeof module.exports.waitCardCanvasPos!=='function')throw Error('helper missing');
 const browser=vm.createContext({
  apiRequest:async cmd=>{
   events.push({at:now,cmd});if(cmd!=='objects')throw Error('Unexpected mutation/command '+cmd);
   reads++;active=spec.frames[Math.min(frameIndex++,spec.frames.length-1)];
   if(active.never)return new Promise(()=>{});
   const selected=active;
   if(selected.delayMs)await new Promise(resolve=>schedule(resolve,selected.delayMs));
   return structuredClone(selected.reply);
  },
  ocFind:(kind,id)=>{if(kind!==(spec.kind||'grid-binding')||id!==7)throw Error('Wrong fixture identity lookup');return active?structuredClone(active.local):null;}
 });
 const expressions=[];
 const evaluate=expr=>{expressions.push(expr);return vm.runInContext(expr,browser,{filename:'actual-helper-browser-expression.js'});};
 let done=false,result=null,error=null,watchdog=false;
 const options={kind:spec.kind||'grid-binding',id:7,beforeCx:10,beforeCy:20,timeoutMs:40,pollMs:5};
 Promise.resolve().then(()=>module.exports.waitCardCanvasPos(evaluate,options)).then(x=>{done=true;result=x;},e=>{done=true;error={name:e.name,message:e.message};});
 schedule(()=>{watchdog=true;},120);
 for(let turns=0;turns<2000&&!done&&!watchdog;turns++){
  for(let i=0;i<100;i++)await Promise.resolve();
  if(done||watchdog)break;
  const next=[...timers.entries()].sort((a,b)=>a[1].at-b[1].at||a[0]-b[0])[0];
  if(!next){watchdog=true;break;}
  timers.delete(next[0]);now=next[1].at;try{next[1].fn();}catch(e){errors.push({name:e.name,message:e.message});throw e;}
 }
 for(let i=0;i<100;i++)await Promise.resolve();
 const succeeded=done&&!error&&result?.ok===true;
 const correct=spec.expected==='success'?succeeded&&now<=40&&reads>=(spec.minimumReads||1):done&&!succeeded&&now<=40;
 return {id:spec.id,expected:spec.expected,correct,settled:done,virtualElapsedMs:now,watchdogFired:watchdog,result,error,reads,events,expressionSha256:expressions.length?sha(expressions[0]):null,generatedExpressionsIdentical:expressions.every(x=>x===expressions[0]),onlyReadonlyObjects:events.every(x=>x.cmd==='objects'),unexpectedTimerErrors:errors};
}
(async()=>{
 const baseline=[],after=[];
 for(const s of scenarios){baseline.push(await runOne(originalSource,s));after.push(await runOne(finalSource,s));}
 const result={
  schema:'geometry-pr168-independent-vm-review/2',capturedAt:new Date().toISOString(),
  source:{originalHead:original,finalHead:final,originalHelperSha256:sha(originalSource),finalHelperSha256:sha(finalSource),harnessSha256:sha(harnessSource)},
  method:'Exact committed helper executes in NodeVM with deterministic virtualDate/timers; each actual generated browser expression executes unchanged in a secondVM against labelled read-only objects/local fixtures. This tests helper decisions/deadline, not a real browser/native producer.',
  options:{timeoutMs:40,pollMs:5,watchdogMs:120},scenarios,baseline,after,
  baselineCounterexamples:baseline.filter(x=>!x.correct).map(x=>x.id),
  finalAllPassed:after.every(x=>x.correct&&x.onlyReadonlyObjects&&x.generatedExpressionsIdentical&&x.unexpectedTimerErrors.length===0),
  noRepositoryEdits:true,noBrowserOrNativeExecution:true,
  limits:['Virtual elapsed times are injected control evidence, not measured network latency.','A thrown error is fail-closed; it is recorded and is not converted into a success.','The external120ms watchdog is a control that distinguishes an unbounded pending read from helper rejection by40ms.','This does not prove drag hit-testing, trusted CDP gestures or application persistence; those require separate real-browser evidence.']
 };
 fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');
 process.stdout.write(JSON.stringify({output:out,baselineCounterexamples:result.baselineCounterexamples,finalPassed:after.filter(x=>x.correct).length,finalTotal:after.length,finalAllPassed:result.finalAllPassed})+'\n');
 if(!result.finalAllPassed)process.exitCode=1;
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=2;});
