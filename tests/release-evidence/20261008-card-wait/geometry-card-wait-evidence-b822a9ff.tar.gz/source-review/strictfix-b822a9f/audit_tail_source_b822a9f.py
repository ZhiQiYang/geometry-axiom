import datetime,hashlib,json,os,pathlib,re,subprocess,sys
R=pathlib.Path('/workspace/geometry-final'); S=pathlib.Path('/workspace/scratch/geometry-all-closeout'); O=S/'pr168-review'/'strictfix-b822a9f'
A='5fddf18d18cb70b3bfc5f3d39ad2684eec97aa39'; B='b822a9ff7c0deb74f7d6f05e70aa43d6f00dd8d5'; P='a1b2f785e1bdcf13380c56b3b4c8c95093ea615c'; H='459478e9f68fe8ee9252a5f6b4a1ffb2213a5207'
def run(args,**kw):return subprocess.run(args,cwd=R,capture_output=True,**kw)
def git(*args,binary=False):
 r=run(['git',*args],check=True);return r.stdout if binary else r.stdout.decode().strip()
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(pathlib.Path(p).read_text())
def ref(p):
 p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}
def tree(rev):
 out={}
 for rec in git('ls-tree','-r','-z','--full-tree',rev,binary=True).split(b'\0'):
  if rec:
   meta,p=rec.split(b'\t',1);mode,kind,oid=meta.decode().split();out[p.decode()]={'mode':mode,'kind':kind,'blob':oid}
 return out
def ancestor(x,y):return run(['git','merge-base','--is-ancestor',x,y]).returncode==0
trees={k:tree(k) for k in [A,B,H]}
changes={p:{'before':trees[A].get(p),'after':trees[B].get(p)} for p in sorted(trees[A].keys()|trees[B].keys()) if trees[A].get(p)!=trees[B].get(p)}
browser={'geometry-web/assembly_workflow_test.js','geometry-web/cdp_helpers.js','geometry-web/cdp_test.js','geometry-web/composition_canvas_test.js','geometry-web/grid_system_test.js'}
node={'tests/test_cdp_card_position.js'}
meta={'tests/run_all.expected.json','tests/run_all.py'}
for p,d in changes.items():
 for label,sha in [('before',A),('after',B)]:
  if d[label] is None:continue
  raw=git('show',sha+':'+p,binary=True); target=O/'tail-source'/label/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  d[label]['sha256']=h(raw);d[label]['bytes']=len(raw);d[label]['artifact']=str(target)
 d['classification']='browser_test_harness' if p in browser else 'new_node_negative_controls' if p in node else 'test_registry_or_floor'
rawdiff=git('diff','--no-ext-diff','--no-color','--binary',A,B,binary=True);(O/'5fdd-to-b822a9f.diff').write_bytes(rawdiff)
strictdiff=git('diff','--no-ext-diff','--no-color','--binary','c364591dd30afa666940be1858d48329ea2c9e1a',B,binary=True);(O/'strictfix-b822a9f.diff').write_bytes(strictdiff)
sys.path.insert(0,str(R/'geometry-web'));import runtime_version
sys.path.insert(0,str(R/'tests'));import binaries,mutate
binaries.OUT_DIR=pathlib.Path('/tmp/geometry-final-native')
paths=[p.relative_to(R).as_posix() for p in runtime_version.source_files(R)]
oids=sorted({trees[k][p]['blob'] for k in [A,B,H] for p in paths})
raw=run(['git','cat-file','--batch'],input=(''.join(x+'\n' for x in oids)).encode(),check=True).stdout
blobs={};pos=0
for oid in oids:
 e=raw.index(b'\n',pos);actual,kind,size=raw[pos:e].decode().split();size=int(size);assert(actual,kind)==(oid,'blob')
 start=e+1;blobs[oid]=raw[start:start+size];pos=start+size+1
assert pos==len(raw)
versions={k:runtime_version._content_version(R,[(R/p,blobs[trees[k][p]['blob']]) for p in paths]) for k in [A,B,H]}
runtimeRows=[{'path':p,'beforeBlob':trees[A][p]['blob'],'afterBlob':trees[B][p]['blob'],'beforeSha256':h(blobs[trees[A][p]['blob']]),'afterSha256':h(blobs[trees[B][p]['blob']]),'changed':trees[A][p]!=trees[B][p],'worktreeEqualsFinal':(R/p).read_bytes()==blobs[trees[B][p]['blob']]} for p in paths]
unchanged=[{'path':p,**trees[B][p]} for p in sorted(trees[B]) if p not in changes and trees[A].get(p)==trees[B][p]]
productRows=[x for x in runtimeRows if x['path'] not in browser]
oldExpected=json.loads(git('show',A+':tests/run_all.expected.json'));newExpected=json.loads(git('show',B+':tests/run_all.expected.json'))
oldmap=oldExpected['suites'];newmap=newExpected['suites'];newkeys=sorted(newmap.keys()-oldmap.keys());removed=sorted(oldmap.keys()-newmap.keys());changedfloors={k:{'before':oldmap[k],'after':newmap[k]} for k in oldmap.keys()&newmap.keys() if oldmap[k]!=newmap[k]}
oldRunner=git('show',A+':tests/run_all.py');newRunner=git('show',B+':tests/run_all.py')
regLine="    'node:cdp_card_position': 'tests/test_cdp_card_position.js',"
nodeProgram="""const vm=require('node:vm'),fs=require('node:fs'),crypto=require('node:crypto');const payload=JSON.parse(fs.readFileSync(0,'utf8'));const output={};for(const[k,code]of Object.entries(payload)){const module={exports:{}};vm.runInNewContext(code,{module,exports:module.exports,require,console,setTimeout,clearTimeout,Date,Promise});output[k]={};for(const[name,v]of Object.entries(module.exports))output[k][name]={type:typeof v,functionSha256:typeof v==='function'?crypto.createHash('sha256').update(v.toString()).digest('hex'):null};}process.stdout.write(JSON.stringify(output));"""
exportsRun=run(['node','-e',nodeProgram],input=json.dumps({k:git('show',k+':geometry-web/cdp_helpers.js') for k in [A,B]}).encode(),check=True)
exports=json.loads(exportsRun.stdout)
census={}
for p in sorted(browser-{'geometry-web/cdp_helpers.js'}):
 a=git('show',A+':'+p);b=git('show',B+':'+p)
 census[p]={'checkCallsBefore':len(re.findall(r'\bcheck\s*\(',a)),'checkCallsAfter':len(re.findall(r'\bcheck\s*\(',b)),'explicitVerdictBefore':len(re.findall(r'\bexplicitVerdict\s*\(',a)),'explicitVerdictAfter':len(re.findall(r'\bexplicitVerdict\s*\(',b)),'checkNamesBefore':re.findall(r"""\bcheck\(\s*['"]([^'"]+)['"]""",a),'checkNamesAfter':re.findall(r"""\bcheck\(\s*['"]([^'"]+)['"]""",b)}
goldenpath='geometry-web/cdp_sections.golden.json';golden=json.loads(git('show',B+':'+goldenpath))
ab=j(S/'final-native-retry/aggregate-before-identity.json');mb=j(S/'final-native/mutation-before.json')
native={}
for binary in binaries.REGISTRY:
 if not binary.applicable():continue
 fp,files,cmd=binaries.compute_fingerprint(binary);d={'fingerprint':fp,'files':files,'command':cmd};d['sameAsActual07bAggregate']=all(d[k]==ab['binarySources'][binary.name][k] for k in ['fingerprint','files','command']);native[binary.name]=d
ms=mutate.Sources(R);oracle=mutate.oracle_hash();tool=mutate.tool_hash()
mcheck=run([sys.executable,'tests/mutate.py','--check'],env={**os.environ,'MUTATE_CACHE':'/tmp/geometry-final-native/mutants'})
(O/'tail-mutation-readonly-check.log').write_bytes(mcheck.stdout+mcheck.stderr);(O/'tail-mutation-readonly-check.exit').write_text(str(mcheck.returncode)+'\n')
vmResult=j(O/'independent-helper-vm-b822a9f.json')
coveragepath=S/'final-pr-coverage/final-pr-source-coverage.json';coverage=j(coveragepath)
priorExact=[x for x in coverage['pullRequests'] if x['coverageKind']=='exact_commit_ancestor']
coverageRows=[{'number':x['number'],'head':x['headRefOid'],'priorClassification':x['coverageKind'],'headInNewFreeze':ancestor(x['headRefOid'],B)} for x in priorExact]
checks=[]
def ck(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
ck('exact clean freeze before and after',git('rev-parse','HEAD')==B and git('status','--porcelain=v1')=='')
ck('exact eight paths only: five browser harness plus node controls plus registry/floor',set(changes)==browser|node|meta,sorted(changes))
ck('all other tracked entries unchanged including app native SSOT reader docs and prior evidence',len(unchanged)==len(trees[A])-len(browser|meta))
ck('native/core and canonical files specifically same Git blobs',all(trees[A][p]==trees[B][p] for p in trees[A] if p.startswith('geometry-core/') or p in ['current_geometry.c','公理層.md','geometry-guide/公理層-閱讀器.html','geometry-guide/公理層-白話.md','AGENTS.md']))
ck('runtime catalog430 only five browser harness asset bytes changed',len(paths)==430 and {x['path'] for x in runtimeRows if x['changed']}==browser)
ck('all final runtime working bytes match Git blobs',all(x['worktreeEqualsFinal'] for x in runtimeRows))
ck('original459 and5fdd runtime identical to sealed execution identity',versions[A]==versions[H]=='4f89407fd3b542efa28b5eb5837657105f1244442bd9ee7b6a848e22ab0b65e3')
ck('new runtime identity independently reconstructed from Git matches current runtime',versions[B]==runtime_version.source_version(R) and versions[B]!=versions[A])
ck('all existing helper exports retain exact function-source hashes',all(exports[A][k]==exports[B].get(k) for k in exports[A]))
ck('only new helper export waitCardCanvasPos',set(exports[B])-set(exports[A])=={'waitCardCanvasPos'})
ck('old callsite check and explicitVerdict census and check labels retained',all(x['checkCallsBefore']==x['checkCallsAfter'] and x['explicitVerdictBefore']==x['explicitVerdictAfter'] and x['checkNamesBefore']==x['checkNamesAfter'] for x in census.values()))
ck('full CDP golden bytes unchanged since actual459 execution',trees[A][goldenpath]==trees[B][goldenpath]==trees[H][goldenpath] and golden['total']==sum(golden['sections'].values())==2177)
ck('only floor addition node:cdp_card_position21 no old changes or deletions',newkeys==['node:cdp_card_position'] and not removed and not changedfloors and newmap['node:cdp_card_position']=={'mode':'count','count':21,'unit':'node test'})
ck('registry changed only explicit new control registration',newRunner.replace(regLine+'\n','')==oldRunner)
ck('all applicable native binary closure fingerprints still match actual07b execution',all(x['sameAsActual07bAggregate'] for x in native.values()))
ck('mutation source closure oracle and tool still match original935 execution',ms.closure==mb['closure_sha256'] and oracle==mb['oracle_sha256'] and tool==mb['tool_sha256'])
ck('mutation result bytes preserved and readonly check success',h((R/'tests/mutants_results.json').read_bytes())=='3065fc03773c326b9256a7ffeb05cd602cd254dcab2d267626abc42101f38392' and mcheck.returncode==0)
ck('independent14caseVM passes strictfreeze and exposes original7counterexamples',vmResult['source']['finalHead']==B and len(vmResult['after'])==14 and vmResult['finalAllPassed'] and len(vmResult['baselineCounterexamples'])==7)
ck('originalPR168 exacthead is ancestor preserved by ordinarymerge',ancestor(P,B) and ancestor(A,B) and git('show','-s','--format=%P','c364591dd30afa666940be1858d48329ea2c9e1a').split()==[A,P])
ck('prior20exactheads inherited without relabeling old23snapshot',len(coverageRows)==20 and all(x['headInNewFreeze'] for x in coverageRows))
ck('sealed prior sourcecoverage preserved',h(coveragepath.read_bytes())=='c994ed3cb239d06dd180810d1c10da2f65aba479d37b8da5b7c77bb72f584ace')
ck('diff check clean',run(['git','diff','--check',A,B]).returncode==0)
ck('source remains exact clean freeze at completion',git('rev-parse','HEAD')==B and git('status','--porcelain=v1')=='')
doc={'schema':'geometry-pr168-tail-source-proof/2','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allChecksPassed':all(x['pass'] for x in checks),'checks':checks,
 'source':{'publishedIntegrationBase':A,'originalPR168Head':P,'ordinaryMergeHead':'c364591dd30afa666940be1858d48329ea2c9e1a','strictFreeze':B,'tree':git('rev-parse',B+'^{tree}'),'parents':git('show','-s','--format=%P',B).split(),'status':git('status','--porcelain=v1'),'changes':changes,'diff':ref(O/'5fdd-to-b822a9f.diff'),'strictFixDiff':ref(O/'strictfix-b822a9f.diff'),'unchangedTrackedEntryCount':len(unchanged),'unchangedTrackedEntries':unchanged},
 'classification':{'productSourceEquivalentTo5fdd':True,'wholeRuntimeEquivalentTo5fdd':False,'browserHarnessFiles':sorted(browser),'newControlFiles':sorted(node),'registryOrFloorFiles':sorted(meta),'rationale':'All exact Git tree changes are test harness/control/registration/floor files. Application/native/SSOT/reader blobs and old evidence artifacts are unchanged. Runtime identity includes the five browser harness JavaScript assets and therefore changes.'},
 'runtime':{'versions':versions,'catalogCount':len(paths),'files':runtimeRows,'unchangedCatalogExcludingChangedHarnessCount':len(productRows),'method':'Runtime source_files catalog430; exact Git blobs; existing runtime_version identity normalization. Unchanged catalog subset excludes these five changed browser test assets; it contains product sources and other unchanged test assets, so its count is not a pure product-file count.'},
 'helpers':{'exports':exports,'deadlineContract':'Absolute Date.now deadline; Promise.race bounds unresolved read; late completion cannot pass; only one in-flight read; invalid/missing/API!ok/nonfinite records reject; finite existing hasPosfalse records remain pending until convergence or deadline. Read transport is not cancelled, so a late response may finish but cannot change returned verdict.','independentVM':ref(O/'independent-helper-vm-b822a9f.json'),'independentHarness':ref(O/'independent_helper_vm_v2.cjs'),'browserExecutionClaim':False},
 'census':{'staticCallsiteCounts':census,'staticCountsAreNotExecutionTotals':True,'golden':golden,'goldenBlob':trees[B][goldenpath],'fullExecutionHeadRetained':H,'fullExecutionPassed':2177,'newFull2177ExecutionClaim':False},
 'registration':{'oldFloorEntries':len(oldmap),'newFloorEntries':len(newmap),'added':{k:newmap[k] for k in newkeys},'removed':removed,'changedOldEntries':changedfloors,'oldAggregateActualExecutionHead':ab['head'],'noNewCompleteAggregateExecutionClaim':True,'note':'The new21-case Node gate was registered separately. This does not relabel the old82-suite native aggregate as a new83-suite execution; unrelated browser harness assets have changed since07b.'},
 'native':{'actualAggregateExecutionHead':ab['head'],'closures':native,'noRebuildOrRerun':True},
 'mutation':{'actualExecutionHead':mb['head'],'closure':ms.closure,'oracle':oracle,'tool':tool,'sourceFiles':ms.hashes,'resultSha256':h((R/'tests/mutants_results.json').read_bytes()),'readOnlyCheckExit':mcheck.returncode,'readOnlyLog':ref(O/'tail-mutation-readonly-check.log'),'noMutantsExecuted':True},
 'sourceCoverageTail':{'old23Snapshot':ref(coveragepath),'oldSnapshotNotModified':True,'additionalWorkItemOrdinal':24,'number':168,'url':'https://github.com/ZhiQiYang/geometry-axiom/pull/168','head':P,'coverageKind':'exact_commit_ancestor_with_additional_strict_test_fix','ordinaryMergeHead':'c364591dd30afa666940be1858d48329ea2c9e1a','inNewFreeze':ancestor(P,B),'priorExactAncestorChecks':coverageRows,'scopeNote':'This is an additional source-work item, not a fresh claim that current total openPR count is24; PR169 is the integration PR. Old23 snapshot remains as-of its capture; old #141/#129/#157 classifications remain semantic/blob-based.'},
 'limits':['Independent VM proves bounded helper decisions on explicit fixtures, not real browser hit-testing or native persistence. Separate focused actual-browser receipts are required for changed callers.','Full2177 remains actual459 execution with its original harness. New2177 golden is unchanged but is not a rerun proof.','All old sealed44-row matrix and archives retain original hashes and execution identities. This tail does not grant main merge, platform clearance or release approval.','No Windows/physical-phone/IME/OS-picker or billing permissions claim is added.']}
(O/'tail-source-proof-b822a9f.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':doc['allChecksPassed'],'failed':[x['name'] for x in checks if not x['pass']],'runtime':versions[B],'proof':ref(O/'tail-source-proof-b822a9f.json'),'floorEntries':[len(oldmap),len(newmap)],'unchangedCatalogExcludingChangedHarnessPaths':len(productRows)},ensure_ascii=False))
raise SystemExit(0 if doc['allChecksPassed'] else 1)
