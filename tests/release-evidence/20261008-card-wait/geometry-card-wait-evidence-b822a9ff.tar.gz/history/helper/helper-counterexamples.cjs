'use strict';
const fs=require('node:fs'),vm=require('node:vm'),cp=require('node:child_process'),crypto=require('node:crypto'),path=require('node:path');
const root='/workspace/geometry-final',head='a1b2f785e1bdcf13380c56b3b4c8c95093ea615c',out=__dirname;
const source=cp.execFileSync('git',['show',head+':geometry-web/cdp_helpers.js'],{cwd:root,encoding:'utf8'}),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const identity=()=>({head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),status:cp.execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim()});
const before=identity(),row=(cx,cy,hasPos=true)=>({id:1,kind:'boundary',cx,cy,hasPos}),state=(native,local=native,delay=0,ok=true)=>({r:{ok,faces:native?[native]:[]},local,delay});
async function probe(name,states,expected){
 let clock=0,reads=0;class Clock extends Date{static now(){return clock;}}
 const box={module:{exports:{}},Date:Clock,setTimeout:(f,ms)=>{clock+=ms;queueMicrotask(f);}};vm.runInNewContext(source,box,{filename:'git:'+head+':geometry-web/cdp_helpers.js'});
 const observed=[];
 const evaluate=async expression=>{const s=states[Math.min(reads++,states.length-1)];clock+=s.delay;observed.push(s);return vm.runInNewContext(expression,{apiRequest:async cmd=>{if(cmd!=='objects')throw Error('Unexpected mutation/read '+cmd);return s.r;},ocFind:(kind,id)=>kind==='boundary'&&id===1?s.local:null});};
 const result=await box.module.exports.waitCardCanvasPos(evaluate,{kind:'boundary',id:1,beforeCx:60,beforeCy:60,timeoutMs:4000,pollMs:50});
 return {name,expectedOK:expected,actualOK:result.ok,contractSatisfied:result.ok===expected,reads,result,observed};
}
(async()=>{
 const cases=[];
 for(const [name,states,expected] of [
  ['missing native and local records must fail',[state(null)],false],
  ['native API failure with missing local must fail',[state(null,null,0,false)],false],
  ['coordinates without persisted hasPos must fail',[state(row(200,100,false))],false],
  ['unchanged persisted coordinates time out',[state(row(60,60))],false],
  ['native commit waits until local copy converges',[state(row(200,100),row(60,60)),state(row(200,100))],true],
  ['local movement before native commit does not pass',[state(row(60,60),row(200,100))],false],
  ['one-axis actual persisted movement succeeds',[state(row(60,100))],true],
  ['response beyond declared timeout is accepted (soft timeout boundary)',[state(row(200,100),row(200,100),4001)],false],
 ])cases.push(await probe(name,states,expected));
 const after=identity();const result={schema:'geometry-pr168-readonly-helper-review/1',command:['node',__filename],scope:'Actual helper source executed in isolated Node VMs with synthetic read-only objects replies and deterministic time. No browser/native/service call, no product source mutation; counterexamples are not browser acceptance.',reviewedHead:head,sourceSHA256:sha(source),harnessSHA256:sha(fs.readFileSync(__filename)),beforeIdentity:before,afterIdentity:after,identityStable:JSON.stringify(before)===JSON.stringify(after),cases,contractSatisfied:cases.filter(c=>c.contractSatisfied).length,contractViolated:cases.filter(c=>!c.contractSatisfied).length,executionExitCode:0};
 fs.writeFileSync(path.join(out,'helper-counterexamples-result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({reviewedHead:head,sourceSHA256:result.sourceSHA256,contractSatisfied:result.contractSatisfied,contractViolated:result.contractViolated,cases:cases.map(({name,expectedOK,actualOK,reads})=>({name,expectedOK,actualOK,reads}))},null,2));
})();
