"""Prepare a non-final inventory only; this program has no archive/write-to-repo mode."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/geometry-final')
RAW = Path('/workspace/scratch/geometry-all-closeout')
OUT = Path('/workspace/scratch/geometry-delivery-20261008-card-wait')
FREEZE = 'b822a9ff7c0deb74f7d6f05e70aa43d6f00dd8d5'
PUBLIC = 'tests/release-evidence/20261008-card-wait'
DENY_PARTS = {'.git', '__pycache__', 'node_modules', 'chrome-profile', 'browser-profile',
              'profile', 'profiles', 'feedback', 'cache', 'caches', 'wm', 'work-manager',
              'work-manager-unit-final', 'credentials', '.ssh', '.aws', '.config'}
ALLOW_SUFFIX = {'.json', '.log', '.txt', '.md', '.js', '.cjs', '.py', '.diff', '.png',
                '.scene', '.gcanvas', '.stdout', '.stderr'}
SENSITIVE = {
    'private-key': rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    'github-token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,})\b',
    'aws-access-key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'credential-url': rb'https?://[^\s/"<>:@]{2,}:[^\s/"<>@]{2,}@',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_file(path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, ValueError):
        return None


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def files_in(path):
    """Prune private/runtime directories before traversal and never follow links."""
    if not path.exists():
        return
    if path.is_file():
        yield path
        return
    for folder, dirs, names in os.walk(path, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d.lower() not in DENY_PARTS and
                         not d.lower().endswith('-profile') and not (Path(folder) / d).is_symlink())
        for name in sorted(names):
            yield Path(folder) / name


def inspect_file(path):
    if path.is_symlink() or any(p.is_symlink() for p in path.parents):
        return None, 'symlink'
    if not path.is_file() or path.suffix.lower() not in ALLOW_SUFFIX:
        return None, 'nonregular-or-unapproved-type'
    if any(p.lower() in DENY_PARTS or p.lower().endswith('-profile') for p in path.parts):
        return None, 'private-runtime-directory'
    data = path.read_bytes()
    if data.startswith((b'\x7fELF', b'MZ', b'SQLite format 3')):
        return None, 'native-executable-or-database'
    matches = [name for name, pattern in SENSITIVE.items() if re.search(pattern, data)]
    return {'source': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'possibleSensitivePatterns': matches}, None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    hold = json_file(OUT / 'packaging-hold.json')
    if hold and hold.get('active') is True and '--refresh-plan' not in sys.argv:
        print(json.dumps({'status': 'paused-awaiting-final-freeze', 'reason': hold['reason']}))
        return
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain=v1'], text=True)
    assert head == FREEZE and status == '', 'Expected the exact clean freeze; no silent relabelling.'
    old_dir = ROOT / 'tests/release-evidence/20261008'
    immutable = sorted(p for p in old_dir.iterdir() if p.is_file())
    immutable += [RAW / 'final-validation-matrix.json',
                  Path('/workspace/scratch/geometry-delivery-20261008/machine-manifest.json'),
                  Path('/workspace/scratch/geometry-delivery-20261008/delivery-receipt.json')]
    snapshot = {'schema': 'geometry-card-wait-original-artifacts/1',
                'files': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in immutable]}
    guard_path = OUT / 'original-artifacts-guard.json'
    if guard_path.exists():
        assert json_file(guard_path) == snapshot, 'A sealed original changed; stop.'
    else:
        write(guard_path, snapshot)

    scopes = [
        {'id': 'merge-and-review', 'kind': 'supporting-records', 'path': RAW / 'pr168-review',
         'scope': 'Merge, exact source snapshots and independent follow-up matrix; preparation is not execution.'},
        {'id': 'independent-helper', 'kind': 'historical-and-independent-controls', 'path': RAW / 'pr168-independent',
         'scope': 'Original eight VM counterexamples retain reviewed PR168 head and four contract failures; final comparison remains separately labelled.'},
    ]
    gate_root = RAW / 'multiroom/final-card-wait-b822a9f'
    for name, count in [('grid-system', 316), ('assembly', 150), ('composition', 52)]:
        scopes.append({'id': name, 'kind': 'affected-browser-gate', 'path': gate_root / name,
                       'expectedChecks': count, 'scope': 'Canonical named partial scope only; never full CDP.',
                       'proof': gate_root / name / 'release-receipt/receipt.json'})
    selected, omitted, held, scope_rows = [], [], [], []
    for scope in scopes:
        proof = json_file(scope.get('proof', Path('/nonexistent')))
        complete = bool(proof and proof.get('executionVerified') is True and
                        proof.get('execution', {}).get('exitCode') == 0 and
                        proof.get('before', {}).get('git', {}).get('head') == FREEZE and
                        proof.get('before', {}).get('git') == proof.get('after', {}).get('git'))
        gated = scope['kind'] == 'affected-browser-gate'
        row = {k: str(v) if isinstance(v, Path) else v for k, v in scope.items()}
        row['status'] = 'wrapper-complete-census-review-pending' if complete else 'running-or-receipt-pending' if gated else 'supporting-draft'
        scope_rows.append(row)
        if gated and not complete:
            held.append(scope['id'])
            continue
        for path in files_in(scope['path']):
            record, reason = inspect_file(path)
            if reason:
                omitted.append({'source': str(path), 'reason': reason})
                continue
            record.update(scope=scope['id'], kind=scope['kind'],
                          archivePath=scope['kind'] + '/' + scope['id'] + '/' + str(path.relative_to(scope['path'])))
            selected.append(record)
    required = [
        'root confirms all completed raw sources are frozen and permits final packaging',
        'independent source-equivalence report binds all eight changed paths to cleanb822a9ff',
        'sealed followup matrix contains no pending entries and links exact raw receipts/census',
        'GRID316 ASSEMBLY150 COMPOSITION52 complete with exact filters and terminal census',
        'focused Node30 receipt records 21 new controls plus 9 affected existing tests, not full aggregate',
        'four-card browser probe has exact owner-declared assertion census and actual drag evidence',
        'independent original-versus-fixed helper comparison is complete and preserves failures as historical',
        'final selected-file hash reread, nested gcanvas inspection, zero sensitive flags and independent tar review',
    ]
    plan = {'schema': 'geometry-card-wait-package-plan/1', 'preparedAt': datetime.now(timezone.utc).isoformat(),
            'status': 'preparation-only-no-tar-no-repo-writes', 'sealed': False, 'freeze': FREEZE,
            'publicDirectory': PUBLIC, 'archiveName': 'geometry-card-wait-evidence-b822a9ff.tar.gz',
            'sidecars': ['manifest.json', 'delivery-receipt.json', 'followup-validation-matrix.json',
                         'source-equivalence.json', 'independent-review.json'],
            'originalArtifactsGuard': str(guard_path), 'scopes': scope_rows, 'heldScopes': held,
            'requiredBeforeSeal': required, 'files': selected, 'omissions': omitted,
            'packagingHold': hold,
            'selectedFiles': len(selected), 'selectedBytes': sum(r['bytes'] for r in selected),
            'sensitiveFlags': [{'source': r['source'], 'patterns': r['possibleSensitivePatterns']}
                               for r in selected if r['possibleSensitivePatterns']],
            'limits': ['Original459 archives and matrices are referenced and remain byte-for-byte unchanged.',
                       'Windows205 is limited documentary history at its original head, not latest-head verification.',
                       'Original full CDP2177 and aggregate82/2571 retain their actual prior execution heads.',
                       'Adding the 21-control registry entry does not imply a new full aggregate execution.',
                       'All WM raw data, browser profiles, private databases, credentials and native executables are outside this appendix.',
                       'Hash inventory is a preparation snapshot; no running gate has been sealed or counted as passed.']}
    write(OUT / 'bundle-plan.json', plan)
    print(json.dumps({k: plan[k] for k in ['status', 'freeze', 'selectedFiles', 'selectedBytes', 'heldScopes', 'sensitiveFlags']}))


if __name__ == '__main__':
    main()
