# PR168 card-wait evidence appendix preparation

**Final evidence ready:** root froze `b822a9ff7c0deb74f7d6f05e70aa43d6f00dd8d5` after fixing candidate250's real false-negative for temporary `hasPos=false`. All final scopes passed, and the independent seven-row matrix is sealed. Existing250 results remain historical candidate evidence; its GRID run was interrupted with no terminal census, and ASSEMBLY/COMPOSITION never started.

`finalize-card-wait.py` defaults to a read-only-source preflight and scratch inventory. With `--seal --authorization-file root-completion-authorization.json`, it rechecks exact clean b822, all raw identities/census and hashes, original immutable artifacts, private/runtime exclusions and nested project contents, then writes a new tar and sidecars. Independent tar review must finish before root's later docs-only merge or publication staging. All preflight checker errors and corrections are recorded in `preflight-diagnostics.json`; they did not rerun or modify any acceptance evidence.

This independent appendix targets clean `b822a9ff7c0deb74f7d6f05e70aa43d6f00dd8d5`.
The immutable 459478e delivery remains unchanged; this is not a replacement package.

`python prepare-card-wait.py` only writes a draft inventory and immutable-original hash guard in this scratch directory. It has no archive mode and never writes to the repository. Running gates are held until a successful complete wrapper exists; their final census still requires separate review.

Planned public destination is `tests/release-evidence/20261008-card-wait/`:

- `geometry-card-wait-evidence-b822a9ff.tar.gz`
- `manifest.json`
- `delivery-receipt.json`
- `followup-validation-matrix.json`
- `source-equivalence.json`
- `independent-review.json`

Before sealing, owners must provide final GRID 316, ASSEMBLY 150, COMPOSITION 52, focused Node 30 (21 new controls plus 9 affected existing tests), four-card browser 20 and independent helper-comparison receipts. Four card types do not imply four assertions. The real first-position probe must preserve candidate250 RED and new PASS separately. The original aggregate 82 / 2571 is never relabelled as a latest-head full run. Full CDP 2177 and Windows 205 retain their original execution identities and limits.

After root confirms all data complete and frozen, the final process must freeze a per-file path/size/SHA-256 manifest, reread every byte while packing, write a new temporary tar then rename it atomically, and produce an independent review of exact members, content hashes, census/identity links, no duplicates, no links/traversal, excluded runtime/private material, and the unchanged original-artifact guard. No credential match may be published. Original failing helper counterexamples remain visibly historical rather than rewritten as passes.

Only explicitly approved geometry evidence roots are traversed. Browser profiles/cache/storage, all WM raw data, private databases, credentials, native executables, source-control internals and symlinks are excluded before traversal. The finalizer will inspect any selected `.gcanvas` members too. Root must authorize final packaging after the complete reviewable inventory; this preparation does not request or imply external publication.
