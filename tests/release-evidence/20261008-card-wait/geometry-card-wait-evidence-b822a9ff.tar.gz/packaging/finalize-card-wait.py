"""Validate/freeze an additive evidence bundle outside the repository.

Default is a draft plan. --seal requires a recorded root completion authorization.
Run only before root's later docs-only merge/publication staging, at exact clean FREEZE.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
from datetime import datetime, timezone
import zipfile

ROOT = Path('/workspace/geometry-final')
RAW = Path('/workspace/scratch/geometry-all-closeout')
OUT = Path('/workspace/scratch/geometry-delivery-20261008-card-wait')
FREEZE = 'b822a9ff7c0deb74f7d6f05e70aa43d6f00dd8d5'
TREE = 'fb528657190ebdf39733a71bdaea6f908ff72a48'
RUNTIME = '6afef13e28d609e5d785c6b90d08e924d948a0cf11a40088e54639fa48283379'
ARCHIVE = 'geometry-card-wait-evidence-b822a9ff.tar.gz'
REVIEW = RAW / 'pr168-review'
INDEPENDENT = RAW / 'pr168-independent'
CANONICAL = RAW / 'multiroom/final-card-wait-b822a9f'
PRIOR = RAW / 'multiroom/final-card-wait-2503260'
SOURCE = REVIEW / 'strictfix-b822a9f'
PROOF = SOURCE / 'tail-source-proof-b822a9f.json'
MATRIX = REVIEW / 'followup-validation-matrix.json'
SOURCE_PROOF_SHA = '7d5a21a9b550b242e16af59dd876d9db5be13c9610079b7afb47e9b0d143e94f'
MODEL_INDEX_SHA = '542e25d6aeca016e007b1b657c5dcaec694939a146eac223f92c638ad32a653e'
MATRIX_SHA = '346169bb73f513d2a43aee84c52f4b39b8e436e8bddfe336dd5764541cc2a8e8'
DENY = {'.git', '__pycache__', 'node_modules', 'chrome-profile', 'browser-profile',
        'profile', 'profiles', 'feedback', 'cache', 'caches', 'wm', 'work-manager',
        'work-manager-unit-final', 'credentials', '.ssh', '.aws', '.config'}
SUFFIXES = {'.json', '.log', '.txt', '.md', '.js', '.cjs', '.py', '.diff', '.png',
            '.scene', '.gcanvas', '.stdout', '.stderr'}
SECRETS = {'private-key': rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
           'github-token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,})\b',
           'aws-access-key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
           'credential-url': rb'https?://[^\s/"<>:@]{2,}:[^\s/"<>@]{2,}@'}
SECTIONS = {'grid-system': ('GEOMETRY_GRID_SYSTEM_ONLY', {'P70': 117, 'P71': 9, 'P78': 23, 'P87': 60, 'P88': 107}),
            'assembly': ('GEOMETRY_ASSEMBLY_ONLY', {'P77': 134, 'P82': 16}),
            'composition': ('GEOMETRY_COMPOSITION_ONLY', {'P72': 52})}
LIMITS = [
    'This appendix preserves actual execution identities and separate scopes; no summed product-acceptance total is claimed.',
    'GRID316, ASSEMBLY150 and COMPOSITION52 are canonical partial modes, not a new full2177 run.',
    'Focused Node30 means 21 card-position controls plus 9 evaluator controls; no new full aggregate execution is claimed.',
    'Original full CDP2177 and aggregate82/2571 remain at their original execution heads and in unchanged original archives.',
    'Four-card20 is supplemental actual drag coverage for four types; it is not the complete P5/P11 canonical sections.',
    'First-position5 covers native false-to-true persistence; local flag transition is covered by Node controls.',
    'Original PR168 Windows205 is limited documentary history, not latest-head Windows verification.',
    'Candidate250 GRID was interrupted without CDP_RESULT; ASSEMBLY/COMPOSITION were not started. Its raw evidence is historical.',
    'Original helper counterexamples and exploratory failures retain original outcomes and source lineage limits.',
    'The PR165 remote-head review and hypothetical docs merge are previews only; actual merge belongs to later publication metadata.',
    'No WM raw data, profiles, private databases, credentials or native executables are included.',
    'Packaging approval is internal evidence preparation; it does not grant global release or external-publication approval.',
]


def now(): return datetime.now(timezone.utc).isoformat()
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(Path(path).read_bytes())
def load(path): return json.loads(Path(path).read_text())
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def write(path, value): Path(path).write_bytes(encoded(value))


def identity():
    def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    value = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1')}
    assert value == {'head': FREEZE, 'tree': TREE, 'status': ''}, value
    return value


def check_originals():
    guard = load(OUT / 'original-artifacts-guard.json')
    for row in guard['files']:
        p = Path(row['path'])
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'sealed original changed: ' + str(p)
    return guard


def safe_name(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in name and bool(p.parts)


def reference(row, base=None):
    p = Path(row['path'])
    if not p.is_absolute():
        assert base is not None and safe_name(row['path'])
        p = base / p
    assert p.is_file() and not p.is_symlink(), p
    assert sha(p) == row['sha256'], 'reference hash mismatch: ' + str(p)
    if 'bytes' in row: assert p.stat().st_size == row['bytes'], p
    return p


def all_references(value, base=None):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and re.fullmatch(r'[a-f0-9]{64}', str(value.get('sha256', ''))):
            reference(value, base)
        for child in value.values(): all_references(child, base)
    elif isinstance(value, list):
        for child in value: all_references(child, base)


def wrapper(path):
    value = load(path)
    assert value['executionVerified'] is True and value['status'] == 'execution-verified'
    assert value['execution']['exitCode'] == 0 and not value['execution']['timedOut'] and not value['execution']['interrupted']
    assert not value['problems']
    before, after = value['before'], value['after']
    assert before['git'] == after['git'] == {'root': str(ROOT), 'head': FREEZE, 'tree': TREE, 'status': ''}
    assert before['runtime'] == after['runtime'] and before['runtime']['fresh'] is True
    assert before['runtime']['version'] == RUNTIME and before['runtime']['root'] == str(ROOT)
    assert before['native'] == after['native'] and all(v['state'] == 'fresh' for v in before['native'].values())
    reference(value['log'])
    return value


def validate_source():
    assert sha(PROOF) == SOURCE_PROOF_SHA
    proof = load(PROOF)
    assert proof['allChecksPassed'] is True and len(proof['checks']) == 23 and all(r['pass'] for r in proof['checks'])
    assert proof['source']['strictFreeze'] == FREEZE and proof['source']['tree'] == TREE and proof['source']['status'] == ''
    manifest = load(SOURCE / 'proof-files-manifest.json')
    assert manifest['freeze'] == FREEZE and manifest['count'] == len(manifest['files']) == 24
    for row in manifest['files']: reference(row, SOURCE)
    vm = load(reference(proof['helpers']['independentVM']))
    assert vm['finalAllPassed'] is True and len(vm['scenarios']) == len(vm['after']) == 14
    assert len(vm['baselineCounterexamples']) == 7
    remote = REVIEW / 'remote-final-readback'
    all_references(load(remote / 'manifest-with-merge-preview.json'), remote)
    preview = load(remote / 'pr165-merge-preview.json')
    assert preview['allChecksPassed'] is True and len(preview['checks']) == 6 and all(r['pass'] for r in preview['checks'])


def validate_focused():
    index_path = INDEPENDENT / 'evidence-index-b822.json'
    assert sha(index_path) == MODEL_INDEX_SHA
    index = load(index_path)
    assert index['freeze'] == FREEZE
    all_references(index)
    assert [(r['expected'], r['passed'], r['failed']) for r in index['independentScopes']] == [(30, 30, 0), (20, 20, 0), (5, 5, 0)]
    n = load(INDEPENDENT / 'node30-b822-census.json')
    assert n['completed'] is True and n['executionHead'] == FREEZE
    assert n['rawCounts'] == {'tests': 30, 'pass': 30, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    assert n['suites'] == {'node:cdp_card_position': 21, 'node:cdp_evaluation': 9}
    node = wrapper(INDEPENDENT / 'node30-b822-receipt/receipt.json')
    log = Path(node['log']['path']).read_text()
    for field, count in [('tests', 30), ('pass', 30), ('fail', 0), ('cancelled', 0), ('skipped', 0), ('todo', 0)]:
        assert re.findall(r'^[#ℹ] ' + field + r' (\d+)\s*$', log, re.M) == [str(count)]
    for name, count in [('card-drag-b822', 20), ('first-position-b822', 5)]:
        r = load(INDEPENDENT / name / 'result.json')
        assert r['expected'] == r['passed'] == count and r['failed'] == 0 and r['completed'] is True
        assert len(r['cases']) == count and all(c['passed'] for c in r['cases'])
        assert r['identityStable'] is True and not r['browserErrors'] and not r.get('consoleErrors')
        wrapper(INDEPENDENT / (name + '-receipt') / 'receipt.json')


def validate_canonical():
    summary = load(CANONICAL / 'summary.json')
    assert summary['head'] == FREEZE and summary['status'] == 'pass' and summary['canonicalPartialScopes'] == 3
    assert summary['serviceCleanup']['aliveAfter'] is False
    for name, (filter_name, sections) in SECTIONS.items():
        scope = load(CANONICAL / name / 'scope-receipt.json')
        assert scope['status'] == 'pass' and not scope['problems'] and scope['releaseGateExitCode'] == 0
        assert scope['head'] == scope['headAfter'] == FREEZE and scope['statusAfter'] == ''
        assert scope['canonicalFullCDP'] is False and scope['harnessModified'] is False
        assert scope['expectedSections'] == sections and len(scope['canonicalStructuredResults']) == 1
        r = scope['canonicalStructuredResults'][0]
        assert r['completed'] is True and r['passedAssertions'] == sum(sections.values()) and r['failedAssertions'] == 0
        assert not r['skipped'] and r['uncaughtBrowserExceptions'] == 0 and r['sections'] == sections
        assert r['scope']['mode'] == 'partial' and r['scope']['filters'] == [filter_name] and not r['scope']['modifiers']
        w = wrapper(CANONICAL / name / 'release-receipt/receipt.json')
        raw = Path(w['log']['path']).read_text()
        terminal = [json.loads(line[len('CDP_RESULT '):]) for line in raw.splitlines() if line.startswith('CDP_RESULT ')]
        assert terminal == [r], 'canonical terminal mismatch: ' + name
        for path, value in scope['scopeSourceSHA256'].items(): assert sha(ROOT / path) == value
        for path, value in scope['orchestrationSHA256'].items(): assert sha(Path(path)) == value
    manifest = load(CANONICAL / 'artifact-manifest.json')
    assert len(manifest) == 63  # the owner's 64-file tar also contains this manifest
    for path, value in manifest.items():
        row = {'path': path, **value} if isinstance(value, dict) else {'path': path, 'sha256': value}
        reference(row, CANONICAL)


def validate_matrix():
    assert sha(MATRIX) == MATRIX_SHA
    matrix = load(MATRIX)
    assert matrix['sealed'] is True and not matrix['pending'], 'independent matrix is not sealed'
    assert matrix['targetFreeze'] == {'head': FREEZE, 'tree': TREE, 'status': '', 'runtimeVersion': RUNTIME}
    required = {'pr168-grid': 316, 'pr168-assembly': 150, 'pr168-composition': 52,
                'pr168-wait-helper-node': 30, 'pr168-four-card-drag': 20}
    rows = {r['id']: r for r in matrix['rows']}
    assert set(required).issubset(rows)
    for name, count in required.items():
        row = rows[name]
        assert row['expectedChecks'] == count and row['status'] not in ['pending', 'failed', 'blocked']
    assert all(r['status'] not in ['pending', 'failed', 'blocked'] for r in matrix['rows'])
    all_references(matrix, ROOT)  # relative entries explicitly name committed test/helper sources


def validate_historical():
    interruption = load(PRIOR / 'interruption.json')
    old = load(PRIOR / 'grid-system/release-receipt/receipt.json')
    assert old['executionVerified'] is False and old['status'] == 'interrupted'
    log = Path(old['log']['path']).read_text()
    assert not any(line.startswith('CDP_RESULT ') for line in log.splitlines())
    assert (PRIOR / 'interruption-manifest.json').is_file()
    counter = load(INDEPENDENT / 'helper-counterexamples-result.json')
    assert len(counter['cases']) == 8 and sum(r['contractSatisfied'] for r in counter['cases']) == 4
    assert counter['reviewedHead'] == 'a1b2f785e1bdcf13380c56b3b4c8c95093ea615c'


def read_safe(path):
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'MZ', b'SQLite format 3')), 'private/executable bytes: ' + str(path)
    for name, pattern in SECRETS.items():
        assert not re.search(pattern, data), 'possible ' + name + ': ' + str(path)
    if path.suffix == '.gcanvas':
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            assert len(names) == len(set(names)) and sum(i.file_size for i in z.infolist()) < 100_000_000
            for info in z.infolist():
                assert safe_name(info.filename) and not any(p.lower() in DENY for p in PurePosixPath(info.filename).parts)
                assert (info.external_attr >> 16) & 0o170000 != 0o120000
                content = z.read(info)
                assert not content.startswith((b'\x7fELF', b'MZ', b'SQLite format 3'))
                for pattern in SECRETS.values(): assert not re.search(pattern, content), path
    return data


def file_class(path, root):
    relative = path.relative_to(root)
    top = relative.parts[0]
    if root == CANONICAL: return 'accepted-canonical-partial', 'canonical-b822', 'accepted/canonical/' + str(relative)
    if root == PRIOR: return 'interrupted-historical-candidate', 'grid-candidate250-interrupted', 'history/grid-candidate250/' + str(relative)
    if root == REVIEW:
        if top == 'strictfix-b822a9f': return 'independent-source-and-vm-review', 'source-b822', 'source-review/' + str(relative)
        if top == 'remote-final-readback': return 'docs-merge-preview-not-execution', 'remote-docs-preview', 'supporting/' + str(relative)
        return 'merge-source-and-historical-review', 'merge-and-prior-review', 'supporting/pr168-review/' + str(relative)
    if root == INDEPENDENT:
        if top.startswith(('node30-b822', 'card-drag-b822', 'first-position-b822')):
            return 'accepted-focused-scope', top.split('/')[0], 'accepted/focused/' + str(relative)
        if top.startswith(('card-drag-development', 'first-position-250', 'node28', 'helper-counterexamples')):
            return 'historical-control-or-development', 'prior-helper-evidence', 'history/helper/' + str(relative)
        return 'focused-supporting-source', 'focused-supporting', 'supporting/focused/' + str(relative)
    return 'packaging-procedure', 'packaging', 'packaging/' + path.name


def inventory():
    rows, omitted = [], []
    for root in [REVIEW, INDEPENDENT, CANONICAL, PRIOR]:
        for folder, dirs, names in os.walk(root, followlinks=False):
            keep = []
            for name in sorted(dirs):
                p = Path(folder) / name
                if name.lower() in DENY or name.lower().endswith('-profile') or p.is_symlink():
                    omitted.append({'source': str(p), 'reason': 'excluded-runtime-private-directory'})
                else: keep.append(name)
            dirs[:] = keep
            for name in sorted(names):
                p = Path(folder) / name
                if p.is_symlink() or not p.is_file() or p.suffix.lower() not in SUFFIXES:
                    omitted.append({'source': str(p), 'reason': 'nonregular-link-unapproved-type-or-duplicate-tar'})
                    continue
                assert not any(x.is_symlink() for x in p.parents)
                classification, scope, archive_path = file_class(p, root)
                data = read_safe(p)
                rows.append({'sourceOriginalPath': str(p), 'archivePath': archive_path, 'bytes': len(data),
                             'sha256': digest(data), 'classification': classification, 'scope': scope})
    for name in ['finalize-card-wait.py', 'prepare-card-wait.py', 'README.md', 'review-packaging-notes.json',
                 'original-artifacts-guard.json', 'preflight-diagnostics.json', 'root-completion-authorization.json',
                 'review-card-wait.py']:
        p = OUT / name
        data = read_safe(p)
        rows.append({'sourceOriginalPath': str(p), 'archivePath': 'packaging/' + name,
                     'bytes': len(data), 'sha256': digest(data), 'classification': 'packaging-procedure', 'scope': 'packaging'})
    assert len({r['archivePath'] for r in rows}) == len(rows)
    assert all(safe_name(r['archivePath']) for r in rows)
    return sorted(rows, key=lambda r: r['archivePath']), omitted


def tar_entry(archive, name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.mtime = 0
    archive.addfile(info, io.BytesIO(data))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seal', action='store_true')
    parser.add_argument('--authorization-file', type=Path)
    args = parser.parse_args()
    before = identity()
    checks, problems = [], []
    for name, fn in [('original-artifacts-unchanged', check_originals), ('source-vm-and-doc-preview', validate_source),
                     ('focused-30-20-5', validate_focused), ('canonical-316-150-52', validate_canonical),
                     ('independent-matrix-sealed', validate_matrix), ('historical-outcomes-preserved', validate_historical)]:
        try:
            fn()
            checks.append({'name': name, 'pass': True})
        except Exception as exc:
            problems.append(name + ': ' + str(exc))
            checks.append({'name': name, 'pass': False, 'error': str(exc)})
    rows, omitted = inventory()
    plan = {'schema': 'geometry-card-wait-seal-plan/1', 'at': now(), 'freeze': FREEZE, 'tree': TREE,
            'archiveName': ARCHIVE, 'sealed': False, 'before': before, 'checks': checks, 'problems': problems,
            'files': rows, 'omissions': omitted, 'selectedFiles': len(rows), 'selectedBytes': sum(r['bytes'] for r in rows),
            'limits': LIMITS}
    write(OUT / 'seal-plan.json', plan)
    history = OUT / 'preflight-history'
    history.mkdir(exist_ok=True)
    write(history / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ') + '.json'), plan)
    if not args.seal:
        print(json.dumps({k: plan[k] for k in ['sealed', 'freeze', 'selectedFiles', 'selectedBytes', 'problems']}))
        return
    assert not problems, problems
    assert args.authorization_file is not None
    authorization = load(args.authorization_file)
    assert authorization['confirmedBy'] == 'root' and authorization['freeze'] == FREEZE
    assert all(authorization[k] is True for k in ['allGatesComplete', 'matrixSealed', 'sourceReviewComplete', 'rawFilesFrozen'])
    public_names = [ARCHIVE, 'manifest.json', 'delivery-receipt.json', 'followup-validation-matrix.json', 'source-equivalence.json', 'independent-review.json']
    assert not any((OUT / n).exists() for n in public_names), 'Final artifacts already exist; never overwrite.'
    claims = {'canonicalPartial': {'GRID': 316, 'ASSEMBLY': 150, 'COMPOSITION': 52},
              'focusedNode': {'cardPosition': 21, 'evaluation': 9, 'total': 30},
              'fourCardBrowser': 20, 'firstPositionBrowser': 5,
              'independentSourceChecks': 23, 'independentVM': 14, 'oldSameVMViolations': 7}
    manifest = {'schema': 'geometry-card-wait-evidence-manifest/1', 'createdAt': now(), 'freeze': FREEZE, 'tree': TREE,
                'archiveName': ARCHIVE, 'files': rows, 'fileCount': len(rows), 'claims': claims, 'omissions': omitted,
                'limits': LIMITS, 'originalArtifactsGuardSha256': sha(OUT / 'original-artifacts-guard.json')}
    manifest_bytes = encoded(manifest)
    temporary = OUT / (ARCHIVE + '.partial')
    assert not temporary.exists()
    with temporary.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                tar_entry(archive, 'manifest.json', manifest_bytes)
                for row in rows:
                    data = read_safe(Path(row['sourceOriginalPath']))
                    assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['sourceOriginalPath']
                    tar_entry(archive, row['archivePath'], data)
    assert temporary.stat().st_size < 95 * 1024 * 1024
    for row in rows: assert sha(Path(row['sourceOriginalPath'])) == row['sha256'], 'source changed during packing'
    check_originals()
    after = identity()
    assert before == after
    temporary.rename(OUT / ARCHIVE)
    (OUT / 'manifest.json').write_bytes(manifest_bytes)
    for target, source in [('followup-validation-matrix.json', MATRIX), ('source-equivalence.json', PROOF)]:
        (OUT / target).write_bytes(source.read_bytes())
    sidecars = [{'name': n, 'bytes': (OUT / n).stat().st_size, 'sha256': sha(OUT / n)}
                for n in ['manifest.json', 'followup-validation-matrix.json', 'source-equivalence.json']]
    receipt = {'schema': 'geometry-card-wait-delivery/1', 'completed': True, 'createdAt': now(), 'freeze': FREEZE,
               'before': before, 'after': after, 'archive': {'name': ARCHIVE, 'bytes': (OUT / ARCHIVE).stat().st_size, 'sha256': sha(OUT / ARCHIVE)},
               'manifestSha256': digest(manifest_bytes), 'sidecars': sidecars, 'fileCount': len(rows), 'claims': claims,
               'authorization': {'path': str(args.authorization_file), 'sha256': sha(args.authorization_file)},
               'checks': checks, 'independentReview': 'independent-review.json required before publication; separate immutable result',
               'publicFiles': public_names, 'repositoryWrites': False, 'originalArtifactsUnchanged': True,
               'laterPublicationContract': 'Root may merge docs-only165 and stage metadata after this clean-freeze archive audit. Do not rerun freeze-gated sealing after publication staging.',
               'releaseApproved': False, 'limits': LIMITS}
    write(OUT / 'delivery-receipt.json', receipt)
    print(json.dumps({'sealed': True, 'archive': receipt['archive'], 'fileCount': len(rows), 'needsIndependentReview': True}))


if __name__ == '__main__':
    main()
