"""Canonical room scope plus explicitly transformed diagnostic late-tail scope."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import socket
import subprocess
import sys
import time
import urllib.request

ROOT = Path('/workspace/geometry-final')
SERVICE = Path('/workspace/scratch/geometry-all-closeout/launch_final_service.py')
URL = 'http://127.0.0.1:8835/'
FEEDBACK = '/tmp/geometry-final-feedback-8835'
CDP_PORT = 9495
SCOPES = {'canonical-room': {'P79': 87, 'P84': 33}, 'diagnostic-model-tail': {'P83': 16, 'P86': 20},
    'canonical-space-full': {'setup':2,'space-height-library':112,'projection-lifecycle':18,
        'projection-placement':36,'font-layout':19,'space-flow':39,'browser-health':2}}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def clean(head):
    assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain'), 'Expected exact clean frozen head'

def runtime():
    with urllib.request.urlopen(URL+'runtime', timeout=10) as response:
        return json.load(response)

def prepare_diagnostic(out):
    original_file = ROOT/'geometry-web/cdp_test.js'
    original_bytes = original_file.read_bytes()
    original = original_bytes.decode('utf-8')
    transformed = original
    edits = [
        ("if(scope.mode==='full'||process.env.GEOMETRY_ROOM_OUTLINE_ONLY)await require('./room_outline_test.js')",
         "if(false)await require('./room_outline_test.js')"),
        ("if(scope.mode==='full')await require('./model_snapshot_schedule_test.js')",
         "if(scope.mode==='full'||process.env.GEOMETRY_ROOM_OUTLINE_ONLY)await require('./model_snapshot_schedule_test.js')"),
        ("if(scope.mode==='full')await require('./model_snapshot_navigation_test.js')",
         "if(scope.mode==='full'||process.env.GEOMETRY_ROOM_OUTLINE_ONLY)await require('./model_snapshot_navigation_test.js')"),
    ]
    for before, after in edits:
        assert transformed.count(before) == 1, 'Canonical source no longer matches exact diagnostic transform: '+before
        transformed = transformed.replace(before, after)
    transformed_file=out/'transformed-cdp-source.js'
    transformed_file.write_bytes(transformed.encode('utf-8'))
    (out/'original-cdp-source.js').write_bytes(original_bytes)
    (out/'transform.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), transformed.splitlines(True),
        fromfile='canonical/geometry-web/cdp_test.js', tofile='diagnostic/geometry-web/cdp_test.js')))
    transform={'schema':'geometry-diagnostic-tail-transform/1','canonicalFilename':str(original_file),
        'originalSHA256':sha(original_bytes),'transformedSHA256':sha(transformed.encode('utf-8')),
        'edits':[{'before':a,'after':b,'occurrences':1} for a,b in edits],
        'scope':'partial diagnostic P83/P86 only; not canonical full or canonical room scope',
        'unchanged':'All assertions, fixtures, imports and application source remain unchanged.'}
    (out/'transform.json').write_text(json.dumps(transform,indent=2)+'\n')
    loader=out/'diagnostic-tail-loader.js'
    loader.write_text("'use strict';\nconst fs=require('node:fs'),path=require('node:path'),Module=require('node:module');\n"
        + 'const originalFilename='+json.dumps(str(original_file))+';\n'
        + 'const transformedSource=fs.readFileSync('+json.dumps(str(transformed_file))+',"utf8");\n'
        + "const loaded=new Module(originalFilename);loaded.filename=originalFilename;loaded.paths=Module._nodeModulePaths(path.dirname(originalFilename));\n"
        + "process.mainModule=loaded;require.cache[originalFilename]=loaded;loaded._compile(transformedSource,originalFilename);loaded.loaded=true;\n")
    return loader, transform

def run_scope(scope, expected, head, base, identity):
    clean(head)
    out=base/scope
    out.mkdir()
    artifacts=out/'artifacts'
    artifacts.mkdir()
    env=dict(os.environ)
    for key in list(env):
        if key.startswith('GEOMETRY_') and (key.endswith('_ONLY') or key in {'GEOMETRY_CDP_FROM_P31','GEOMETRY_CDP_UPDATE_GOLDEN'}):
            del env[key]
    selected=dict(GEOMETRY_TEST_URL=URL,GEOMETRY_FEEDBACK_DIR=FEEDBACK,
        GEOMETRY_TEST_BRIDGE='/tmp/geometry-final-native/bridge',GEOMETRY_BRIDGE='/tmp/geometry-final-native/bridge',
        GEOMETRY_MODEL_BASE='/tmp/geometry-final-native/model-base',GEOMETRY_CHROME='/usr/bin/chromium',
        GEOMETRY_CHROME_FLAGS='--no-sandbox --disable-dev-shm-usage',GEOMETRY_CDP_PORT=str(CDP_PORT),
        GEOMETRY_CHROME_PROFILE=str(artifacts/'chrome-profile'),GEOMETRY_TEST_SCREENSHOT=str(artifacts/'shell.png'),
        GEOMETRY_ROOM_SCREENSHOT_DIR=str(artifacts/'room'),GEOMETRY_MODEL_SNAPSHOT_SCREENSHOTS=str(artifacts/'model'),
        GEOMETRY_REPAIR_SCREENSHOT_DIR=str(artifacts/'repair'),GEOMETRY_GRID_SCREENSHOT_DIR=str(artifacts/'grid'),
        GEOMETRY_SPACE_TEST_DIR=str(artifacts/'space'),GEOMETRY_ROOM_OUTLINE_ONLY='1',PYTHONDONTWRITEBYTECODE='1')
    env.update(selected)
    command=['node','geometry-web/cdp_test.js']
    is_space=scope=='canonical-space-full'
    if is_space:
        selected.pop('GEOMETRY_ROOM_OUTLINE_ONLY')
        env.pop('GEOMETRY_ROOM_OUTLINE_ONLY')
        command=['node','geometry-web/space_model_test.js']
    detail={'schema':'geometry-room-tail-execution/1','scope':scope,'head':head,'expectedSections':expected,
        'runtimeBefore':runtime(),'environment':selected,'canonicalFullCDP':False,
        'canonicalFullSpace':is_space,'sourceSHA256':{}}
    assert detail['runtimeBefore']==identity
    for name in ['geometry-web/cdp_test.js','geometry-web/room_outline_test.js','geometry-web/pdf_tracing_snap_test.js',
                 'geometry-web/model_snapshot_schedule_test.js','geometry-web/model_snapshot_navigation_test.js','geometry-web/cdp_sections.golden.json',
                 'geometry-web/space_model_test.js','geometry-web/space_test_floor.js']:
        detail['sourceSHA256'][name]=sha((ROOT/name).read_bytes())
    if scope=='diagnostic-model-tail':
        loader,transform=prepare_diagnostic(out)
        detail['transform']=transform
        command=['node',str(loader)]
    detail['command']=command
    gate=['python3','tests/release_gate.py','--url',URL,'--output',str(out/'release-receipt'),'--timeout','1800','--',*command]
    print(json.dumps({'scope':scope,'head':head,'command':command,'expectedSections':expected,'state':'starting'}),flush=True)
    result=subprocess.run(gate,cwd=ROOT,env=env)
    detail['releaseGateExitCode']=result.returncode
    clean(head)
    detail['runtimeAfter']=runtime()
    problems=[]
    if detail['runtimeAfter']!=identity:problems.append('runtime changed')
    receipt=json.loads((out/'release-receipt/receipt.json').read_text())
    detail['releaseReceiptPath']=str(out/'release-receipt/receipt.json')
    raw=(out/'release-receipt/command.log').read_text()
    prefix='SPACE_RESULT ' if is_space else 'CDP_RESULT '
    rows=[json.loads(line[len(prefix):]) for line in raw.splitlines() if line.startswith(prefix)]
    detail['canonicalStructuredResults']=rows
    if result.returncode!=0:problems.append('release gate rejected or command failed')
    if len(rows)!=1:problems.append('expected exactly one structured canonical result')
    else:
        row=rows[0]
        if is_space:
            actual={name:group['passed'] for name,group in row.get('groups',{}).items()}
            if row.get('completed') is not True or row.get('failed')!=0 or row.get('completenessProblems')!=[]:
                problems.append('incomplete full-space run or failed assertions')
            if actual!=expected or row.get('passed')!=sum(expected.values()):problems.append('full-space exact census mismatch')
            if row.get('scope',{}).get('mode')!='full-space-suite' or row['scope'].get('filters')!=[]:
                problems.append('space suite was filtered')
        else:
            if row.get('completed') is not True or row.get('failedAssertions')!=0 or row.get('skipped')!=[] or row.get('sectionsFailed'):
                problems.append('incomplete run or failed/skipped assertions')
            if row.get('sections')!=expected or row.get('passedAssertions')!=sum(expected.values()):
                problems.append('exact scope census mismatch')
            if row.get('scope',{}).get('mode')!='partial' or row['scope'].get('filters')!=['GEOMETRY_ROOM_OUTLINE_ONLY'] or row['scope'].get('modifiers')!=[]:
                problems.append('unexpected scope flags')
    detail['status']='pass' if not problems else 'fail'
    detail['problems']=problems
    detail['releaseApproved']=False
    (out/'scope-receipt.json').write_text(json.dumps(detail,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'scope':scope,'status':detail['status'],'problems':problems,'receipt':str(out/'scope-receipt.json')}),flush=True)
    return not problems

def main():
    p=argparse.ArgumentParser()
    p.add_argument('head')
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--prepare-only',action='store_true')
    args=p.parse_args()
    if args.prepare_only:
        args.output.mkdir(parents=True,exist_ok=False)
        prepare_diagnostic(args.output)
        print('Diagnostic source transform prepared only; no service, browser or tests started.')
        return 0
    clean(args.head)
    golden=json.loads((ROOT/'geometry-web/cdp_sections.golden.json').read_text())['sections']
    assert all(golden[k]==n for scope,values in SCOPES.items() if scope!='canonical-space-full' for k,n in values.items()), 'Committed census changed; review before testing'
    with socket.socket() as check:
        check.bind(('127.0.0.1',CDP_PORT))
    args.output.mkdir(parents=True,exist_ok=False)
    resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,resource.RLIM_INFINITY))
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    service=None
    cleanup={}
    try:
        log=(args.output/'service.log').open('w')
        service=subprocess.Popen([sys.executable,str(SERVICE),'8835'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        for attempt in range(100):
            if service.poll() is not None:raise RuntimeError('Owned service exited during startup; see service.log')
            try:
                identity=runtime()
                break
            except Exception:
                time.sleep(.1)
        else:raise RuntimeError('Owned service did not become ready')
        assert identity['fresh'] is True and identity['root']==str(ROOT) and identity['pid']==service.pid, identity
        (args.output/'service-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
        for scope,expected in SCOPES.items():
            if not run_scope(scope,expected,args.head,args.output,identity):return 1
        return 0
    finally:
        if service is not None:
            cleanup={'ownedPid':service.pid,'signal':'SIGINT'}
            if service.poll() is None:
                service.send_signal(signal.SIGINT)
                try:service.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    service.terminate();service.wait(timeout=10);cleanup['escalatedTo']='SIGTERM exact owned PID'
            cleanup['exitCode']=service.returncode
            cleanup['aliveAfter']=Path('/proc/'+str(service.pid)).exists()
            (args.output/'service-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

if __name__=='__main__':
    raise SystemExit(main())
