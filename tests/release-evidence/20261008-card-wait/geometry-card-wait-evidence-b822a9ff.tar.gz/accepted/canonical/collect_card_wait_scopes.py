import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

base=Path(sys.argv[1]).resolve()
counts={'grid-system':316,'assembly':150,'composition':52}
gates={}
for scope, count in counts.items():
    receipt=base/scope/'scope-receipt.json'
    release=base/scope/'release-receipt/receipt.json'
    r=json.loads(receipt.read_text())
    g=json.loads(release.read_text())
    result=r['canonicalStructuredResults'][0]
    assert r['status']=='pass' and not r['problems'] and r['releaseGateExitCode']==0
    assert g['executionVerified'] and g['gateExitCode']==g['execution']['exitCode']==0
    assert g['before']['git']==g['after']['git'] and g['before']['git']['head']==r['head']
    assert r['runtimeBefore']==r['runtimeAfter']
    assert result['passedAssertions']==sum(r['expectedSections'].values())==count
    assert result['sections']==r['expectedSections'] and not result['failedAssertions'] and result['completed']
    gates[scope]={'head':r['head'],'scopeReceipt':str(receipt),'releaseReceipt':str(release),
        'log':str(release.parent/'command.log'),'scope':scope,'command':r['command'],
        'runtime':r['runtimeBefore'],'expectedSections':r['expectedSections'],'assertions':count,
        'result':result,'scopeSourceSHA256':r['scopeSourceSHA256'],'orchestrationSHA256':r['orchestrationSHA256'],
        'gateExitCode':g['gateExitCode'],'commandExitCode':g['execution']['exitCode'],
        'capturedTemporaryDirectories':r['capturedTemporaryDirectories'],'capturedFixedScreenshots':r['capturedFixedScreenshots']}
assert len({r['head'] for r in gates.values()})==1
cleanup=json.loads((base/'service-cleanup.json').read_text())
assert cleanup['aliveAfter'] is False
for source in ['run_card_wait_scopes.py','run_cdp_room_tail.py','collect_card_wait_scopes.py']:
    shutil.copy2(Path(__file__).parent/source,base/source)
summary={'schema':'geometry-card-wait-canonical-scopes-summary/1','head':next(iter(gates.values()))['head'],
    'status':'pass','canonicalPartialScopes':3,'assertions':518,'gates':gates,'serviceCleanup':cleanup,
    'limitations':['Three unchanged canonical partial CDP scopes only; prior full CDP 2177 remains bound to its original executed head.',
        'Existing Chromium via canonical CDP harness; mixed trusted input, programmatic fixture and native API assertions.',
        'Source and harness were not modified during execution; golden was only read, never updated.',
        'Archive excludes browser profile caches; includes complete logs, receipts, screenshots, and captured native ZIP/save downloads.',
        'Temporary download directories captured by exact known fixture prefixes and before/after discovery; original paths are recorded.']}
(base/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files=[f for f in sorted(base.rglob('*')) if f.is_file() and 'chrome-profile' not in f.parts
    and f.name not in {'evidence.tar.gz','artifact-manifest.json'}]
manifest={str(f.relative_to(base)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(base/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=base/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as bundle:
    for file in [*files,base/'artifact-manifest.json']:
        bundle.add(file,arcname=str(file.relative_to(base)))
print(json.dumps({'summary':str(base/'summary.json'),'archive':str(archive),'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+1,'census':counts}))
