"""Run three unchanged canonical CDP scopes affected by the card commit helper."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE=Path(__file__).parent
OWNER=BASE/'run_cdp_room_tail.py'
spec=importlib.util.spec_from_file_location('owned_scope_service',OWNER)
owner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)
CONFIG={
    'grid-system':('GEOMETRY_GRID_SYSTEM_ONLY',{'P70':117,'P71':9,'P78':23,'P87':60,'P88':107}),
    'assembly':('GEOMETRY_ASSEMBLY_ONLY',{'P77':134,'P82':16}),
    'composition':('GEOMETRY_COMPOSITION_ONLY',{'P72':52}),
}
PREFIXES=('geometry-infinite-grid-download-','geometry-rule-editor-','geometry-rule-lines-','geometry-composition-save-')

def temporary_directories():
    return {p for p in Path('/tmp').iterdir() if p.is_dir() and p.name.startswith(PREFIXES)}

def run_scope(scope,expected,head,base,identity):
    owner.clean(head)
    flag=CONFIG[scope][0]
    out=base/scope
    out.mkdir()
    artifacts=out/'artifacts'
    artifacts.mkdir()
    env=dict(os.environ)
    for key in list(env):
        if key.startswith('GEOMETRY_') and (key.endswith('_ONLY') or key in {
            'GEOMETRY_CDP_FROM_P31','GEOMETRY_CDP_UPDATE_GOLDEN','GEOMETRY_ASSEMBLY_INJECT_SWAP'}):
            del env[key]
    selected=dict(GEOMETRY_TEST_URL=owner.URL,GEOMETRY_FEEDBACK_DIR=owner.FEEDBACK,
        GEOMETRY_TEST_BRIDGE='/tmp/geometry-final-native/bridge',GEOMETRY_BRIDGE='/tmp/geometry-final-native/bridge',
        GEOMETRY_MODEL_BASE='/tmp/geometry-final-native/model-base',GEOMETRY_CHROME='/usr/bin/chromium',
        GEOMETRY_CHROME_FLAGS='--no-sandbox --disable-dev-shm-usage',GEOMETRY_CDP_PORT=str(owner.CDP_PORT),
        GEOMETRY_CHROME_PROFILE=str(artifacts/'chrome-profile'),GEOMETRY_TEST_SCREENSHOT=str(artifacts/'shell.png'),
        GEOMETRY_GRID_SCREENSHOT_DIR=str(artifacts/'grid'),GEOMETRY_GRID_SYSTEM_SCREENSHOT_DIR=str(artifacts/'grid-system'),
        GEOMETRY_GRID_RULE_SCREENSHOT_DIR=str(artifacts/'grid-rule'),GEOMETRY_REPAIR_SCREENSHOT_DIR=str(artifacts/'repair'),
        GEOMETRY_COMPOSITION_SCREENSHOT_DIR=str(artifacts/'composition'),
        GEOMETRY_ASSEMBLY_CONTEXT_SCREENSHOTS=str(artifacts/'assembly-context'),
        PYTHONDONTWRITEBYTECODE='1')
    selected[flag]='1'
    env.update(selected)
    command=['node','geometry-web/cdp_test.js']
    detail={'schema':'geometry-card-wait-canonical-scopes/1','scope':scope,'head':head,
        'expectedSections':expected,'command':command,'environment':selected,
        'runtimeBefore':owner.runtime(),'canonicalFullCDP':False,
        'harnessModified':False,'scopeSourceSHA256':{},'orchestrationSHA256':{}}
    assert detail['runtimeBefore']==identity
    names=['geometry-web/cdp_test.js','geometry-web/cdp_helpers.js','geometry-web/cdp_floor.js',
        'geometry-web/cdp_sections.golden.json','geometry-web/cdp_evaluation.js','geometry-web/cdp_navigation.js',
        'geometry-web/grid_system_test.js','geometry-web/infinite_grid_face_test.js','geometry-web/grid_trial_test.js',
        'geometry-web/grid_rule_editor_test.js','geometry-web/grid_rule_lines_test.js',
        'geometry-web/assembly_workflow_test.js','geometry-web/assembly_review_test.js','geometry-web/assembly_id_test.js',
        'geometry-web/assembly_generation_test.js','geometry-web/assembly_candidate_impact_test.js',
        'geometry-web/assembly_context_entry_test.js','geometry-web/composition_canvas_test.js']
    for name in names:
        detail['scopeSourceSHA256'][name]=owner.sha((owner.ROOT/name).read_bytes())
    for file in [Path(__file__),OWNER,owner.SERVICE]:
        detail['orchestrationSHA256'][str(file)]=owner.sha(file.read_bytes())
    before_dirs=temporary_directories()
    start_ns=time.time_ns()
    gate=['python3','tests/release_gate.py','--url',owner.URL,'--output',str(out/'release-receipt'),
        '--timeout','1800','--',*command]
    print(json.dumps({'scope':scope,'head':head,'expectedSections':expected,'state':'starting'}),flush=True)
    result=subprocess.run(gate,cwd=owner.ROOT,env=env)
    detail['releaseGateExitCode']=result.returncode
    detail['runtimeAfter']=owner.runtime()
    detail['headAfter']=owner.git('rev-parse','HEAD')
    detail['statusAfter']=owner.git('status','--porcelain')
    raw=(out/'release-receipt/command.log').read_text()
    results=[json.loads(line[len('CDP_RESULT '):]) for line in raw.splitlines() if line.startswith('CDP_RESULT ')]
    detail['canonicalStructuredResults']=results
    problems=[]
    if result.returncode!=0:problems.append('release gate rejected or command failed')
    if detail['runtimeAfter']!=identity:problems.append('runtime changed')
    if detail['headAfter']!=head or detail['statusAfter']:problems.append('source changed')
    if len(results)!=1:problems.append('expected exactly one CDP_RESULT')
    else:
        row=results[0]
        if row.get('completed') is not True or row.get('failedAssertions')!=0 or row.get('skipped')!=[] or row.get('sectionsFailed'):
            problems.append('incomplete, failed or skipped assertions')
        if row.get('sections')!=expected or row.get('passedAssertions')!=sum(expected.values()):
            problems.append('exact canonical scope census mismatch')
        if row.get('scope',{}).get('mode')!='partial' or row['scope'].get('filters')!=[flag] or row['scope'].get('modifiers')!=[]:
            problems.append('unexpected scope flags')
    detail['capturedTemporaryDirectories']=[]
    for directory in sorted(temporary_directories()-before_dirs):
        target=artifacts/'downloads'/directory.name
        shutil.copytree(directory,target)
        detail['capturedTemporaryDirectories'].append({'original':str(directory),'copy':str(target),
            'basis':'known canonical fixture prefix, absent before and present after this isolated scope'})
    detail['capturedFixedScreenshots']=[]
    if scope=='assembly':
        for file in sorted(Path('/tmp/geometry-tests').glob('assembly-*.png')):
            if file.stat().st_mtime_ns>=start_ns:
                target=artifacts/'assembly-fixed'/file.name
                target.parent.mkdir(exist_ok=True)
                shutil.copy2(file,target)
                detail['capturedFixedScreenshots'].append({'original':str(file),'copy':str(target)})
    detail['status']='pass' if not problems else 'fail'
    detail['problems']=problems
    detail['releaseApproved']=False
    (out/'scope-receipt.json').write_text(json.dumps(detail,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'scope':scope,'status':detail['status'],'problems':problems,'receipt':str(out/'scope-receipt.json')}),flush=True)
    return not problems

owner.SCOPES={scope:config[1] for scope,config in CONFIG.items()}
owner.run_scope=run_scope
if __name__=='__main__':
    raise SystemExit(owner.main())
