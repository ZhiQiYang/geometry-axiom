import ast,hashlib,json,pathlib
root=pathlib.Path('/tmp/geometry-wake31-pf2');repo=pathlib.Path('/tmp/geometry-209-segments');path=repo/'tests/test_panel_fill_layout.py'
current=path.read_bytes();old=b'for t in [None,"0","9.5"]:';new=b'for t in [None,"0","9.5","12.5"]:'
assert current.count(new)==1
reconstructed=current.replace(new,old)
before=json.loads((root/'before-identity.json').read_text())
assert hashlib.sha256(reconstructed).hexdigest()==before['source_sha256']['tests/test_panel_fill_layout.py']
(root/'before-oracle-reconstructed.py.txt').write_bytes(reconstructed)
def method(source):
 text=source.decode();tree=ast.parse(text)
 node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='test_PF13_integer_thickness_keeps_full_published_representation')
 return ast.get_source_segment(text,node).encode()
assert method(current)==method(reconstructed)
(root/'oracle-binding.json').write_text(json.dumps({'before_file_sha256':hashlib.sha256(reconstructed).hexdigest(),'current_file_sha256':hashlib.sha256(current).hexdigest(),
 'selected_method_sha256':hashlib.sha256(method(current)).hexdigest(),'selected_method_identical':True,
 'reconstruction':'Remove only the later 12.5 negative case in another method; matches SHA recorded before product changes.'},indent=2)+'\n')
