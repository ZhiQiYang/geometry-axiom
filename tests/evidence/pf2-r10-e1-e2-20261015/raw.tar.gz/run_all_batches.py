import json,pathlib,subprocess,sys,time
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2');sys.path.insert(0,str(repo/'tests'));import mutate
ids=[m['id'] for m in mutate.MUTANTS if m['id']!='M01'];groups=[ids[i::4] for i in range(4)]
assert len(ids)==47 and len(set(ids))==47
started=[]
for number,group in enumerate(groups):
 label='batch-'+str(number+1);stdout=(root/(label+'.stdout')).open('wb');stderr=(root/(label+'.stderr')).open('wb')
 process=subprocess.Popen(['python3',str(root/'run_mutation_batch.py'),label,*group],cwd=repo,stdout=stdout,stderr=stderr)
 started.append((process,stdout,stderr,label,group))
print(json.dumps({'processes':[{'pid':p.pid,'batch':label,'ids':group} for p,_,_,label,group in started],'cpu_quota':4}),flush=True)
results=[]
for process,stdout,stderr,label,group in started:
 code=process.wait();stdout.close();stderr.close();results.append({'batch':label,'pid':process.pid,'exit':code,'ids':group});print(json.dumps(results[-1]),flush=True)
(root/'mutation-batches.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(1 if any(r['exit'] for r in results) else 0)
