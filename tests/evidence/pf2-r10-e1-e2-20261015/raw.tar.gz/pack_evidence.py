import hashlib,json,pathlib,shutil,tarfile
root=pathlib.Path('/tmp/geometry-wake31-pf2');repo=pathlib.Path('/tmp/geometry-209-segments');dest=root/'delivery';dest.mkdir(exist_ok=True)
native=json.loads((root/'native/result.json').read_text())
assert native['exit']==0 and native['source_unchanged_except_declared_expected'] and native['expected_change_exactly_one_test']
assert native['head']==native['head_after'] and native['status_after']=='M tests/run_all.expected.json'
refresh=json.loads((root/'mutation-refresh.json').read_text());assert refresh['counts']=={'killed':40,'crashed':1,'equivalent':4,'retired':3} and refresh['actual_check_exit']==0
proof=json.loads((root/'thickness-mutant/receipt.json').read_text());assert [r['actual_os_exit'] for r in proof['runs']]==[0,1,0]
assert all(not r['result']['errors'] and not r['result']['skips'] for r in proof['runs'])
chosen=['before.stdout','before.stderr','before.exit','before-identity.json','before-oracle-reconstructed.py.txt','oracle-binding.json',
 'build.stdout','build.stderr','build.exit','layout-after.json','layout-after.log','layout-after.stdout','layout-after.stderr','layout-after.exit',
 'surface-after.json','surface-after.log','surface-after.stdout','surface-after.stderr','surface-after.exit',
 'engineering-after.json','engineering-after.log','engineering-after.stdout','engineering-after.stderr','engineering-after.exit',
 'thickness-mutant','thickness-mutant.stdout','thickness-mutant.stderr','thickness-mutant.exit','mutation-batches','mutation-batches.json',
 'batches-driver.stdout','batches-driver.stderr','batches-driver.exit','mutation-refresh.json','mutation-check.stdout','mutation-check.stderr','mutation-check.exit',
 'mutants_results.before.json','mutants_results.merged.json','research-R10.json','BOARD-cloud-codex.read.md','native',
 'run_thickness_case.py','run_thickness_mutant.py','run_mutation_batch.py','run_all_batches.py','merge_mutation_results.py','run_native.py','bind_before_oracle.py','pack_evidence.py',
 'preserve_expected_format.py','expected-submitted.json','expected-format-proof.json']
sidecars=root/'mutation-sidecars';sidecars.mkdir(exist_ok=True)
for file in sorted((root/'mutation-cache').rglob('*.fingerprint.json')):
 target=sidecars/file.relative_to(root/'mutation-cache');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
chosen.append('mutation-sidecars')
manifest={}
for name in chosen:
 p=root/name
 for file in sorted(p.rglob('*')) if p.is_dir() else [p]:
  if file.is_file():manifest[str(file.relative_to(root))]={'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(dest/'raw.tar.gz','w:gz') as archive:
 for name in chosen:archive.add(root/name,arcname=name)
with tarfile.open(dest/'raw.tar.gz') as archive:
 members={m.name:m for m in archive if m.isfile()};assert set(members)==set(manifest)
 for name,entry in manifest.items():assert hashlib.sha256(archive.extractfile(members[name]).read()).hexdigest()==entry['sha256'],name
digest=hashlib.sha256((dest/'raw.tar.gz').read_bytes()).hexdigest();(dest/'raw.tar.gz.sha256').write_text(digest+'  raw.tar.gz\n')
for source,target in [('native/result.json','native.json'),('native/stdout','native.stdout'),('native/stderr','native.stderr'),
 ('native/expected-before.json','expected-before.json'),('native/expected-after.json','expected-after.json'),
 ('thickness-mutant/receipt.json','thickness-mutant.json')]:shutil.copyfile(root/source,dest/target)
summary={'raw_files':len(manifest),'raw_archive_sha256':digest,'native_head':native['head'],'native_exit':native['exit'],'native_seconds':native['seconds'],
 'expected_change_exactly_one_test':native['expected_change_exactly_one_test'],'standard_mutations':refresh['counts'],
 'thickness_control_actual_os_exits':[r['actual_os_exit'] for r in proof['runs']],'same_selected_method_sha256':json.loads((root/'oracle-binding.json').read_text())['selected_method_sha256']}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary))
