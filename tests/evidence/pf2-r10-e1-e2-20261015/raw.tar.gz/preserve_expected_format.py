import hashlib,json,pathlib
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2')
before=(root/'native/expected-before.json').read_bytes();generated=(root/'native/expected-after.json').read_bytes()
anchor=b'"py:test_panel_fill_layout": {';start=before.index(anchor);end=before.index(b'}',start)
block=before[start:end];assert block.count(b'"count": 17')==1
formatted=before[:start]+block.replace(b'"count": 17',b'"count": 18')+before[end:]
assert json.loads(formatted)==json.loads(generated)
(repo/'tests/run_all.expected.json').write_bytes(formatted)
(root/'expected-submitted.json').write_bytes(formatted)
(root/'expected-format-proof.json').write_text(json.dumps({'before_sha256':hashlib.sha256(before).hexdigest(),'native_generated_sha256':hashlib.sha256(generated).hexdigest(),
 'submitted_sha256':hashlib.sha256(formatted).hexdigest(),'submitted_semantically_equals_complete_census':True,'only_semantic_change':'py:test_panel_fill_layout count 17 -> 18',
 'formatting':'Preserve base whitespace, property order and suite order; generated full census is retained verbatim.'},indent=2)+'\n')
