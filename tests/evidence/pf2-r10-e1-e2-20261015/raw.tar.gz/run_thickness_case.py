import argparse,hashlib,json,os,pathlib,sys,time,unittest
parser=argparse.ArgumentParser();parser.add_argument('--binary',type=pathlib.Path,required=True);parser.add_argument('--out',type=pathlib.Path,required=True);args=parser.parse_args()
repo=pathlib.Path('/tmp/geometry-209-segments');sys.path.insert(0,str(repo))
from tests import test_panel_fill_layout as tests
out=args.out;out.mkdir(parents=True)
binary=args.binary.resolve();assert binary.is_file()
tests.pf1.find_bridge=lambda:str(binary)
original=tests.pf1.BridgeSession.command
trace=(out/'bridge.jsonl').open('w')
def command(self,text):
 start=time.monotonic_ns();reply=original(self,text)
 trace.write(json.dumps({'command':text,'reply':reply,'start_ns':start,'end_ns':time.monotonic_ns(),'test_pid':os.getpid(),'bridge_pid':self.process.pid},ensure_ascii=False)+'\n');trace.flush()
 return reply
tests.pf1.BridgeSession.command=command
class Result(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.subtests=[]
 def addSubTest(self,test,subtest,error):
  self.subtests.append({'id':subtest.id(),'ok':error is None,'exception':None if error is None else error[0].__name__,'message':None if error is None else str(error[1])})
  super().addSubTest(test,subtest,error)
case='test_PF13_integer_thickness_keeps_full_published_representation';start=time.monotonic_ns()
with (out/'unittest.log').open('w') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(unittest.TestSuite([tests.PanelFillLayout(case)]))
trace.close()
code=0 if result.wasSuccessful() else 1
data={'test_pid':os.getpid(),'case':case,'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
 'oracle_sha256':hashlib.sha256((repo/'tests/test_panel_fill_layout.py').read_bytes()).hexdigest(),'tests_run':result.testsRun,
 'failures':[{'id':t.id(),'traceback':message} for t,message in result.failures],'errors':[{'id':t.id(),'traceback':message} for t,message in result.errors],
 'skips':[(t.id(),reason) for t,reason in result.skipped],'subtests':result.subtests,'unittest_result_code':code,'seconds':(time.monotonic_ns()-start)/1e9,
 'binary_selection':'explicit standalone diagnostic executable; original BridgeSession protocol and assertions'}
(out/'result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'subtests':len(result.subtests),'result_code':code}))
raise SystemExit(code)
