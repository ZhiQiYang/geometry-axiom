import hashlib,json,pathlib,subprocess,time
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2');out=root/'thickness-mutant';out.mkdir()
target=repo/'geometry-core/panel_fill_layout.inc';old=b'char thickness[ENG_THICKNESS_CAPACITY];';replacement=b'char thickness[64];'
original=target.read_bytes();assert original.count(old)==1
changed=out/'panel_fill_layout.inc';changed.write_bytes(original.replace(old,replacement))
core=(repo/'current_geometry.c').read_bytes();anchor=b'#include "geometry-core/panel_fill_layout.inc"';assert core.count(anchor)==1
new_core=out/'core.c';new_core.write_bytes(core.replace(anchor,b'#include "'+str(changed).encode()+b'"'))
bridge=(repo/'geometry-web/web_bridge.c').read_bytes();anchor=b'#include "../current_geometry.c"';assert bridge.count(anchor)==1
new_bridge=out/'bridge.c';new_bridge.write_bytes(bridge.replace(anchor,b'#include "'+str(new_core).encode()+b'"'))
exe=out/'bridge';argv=['cc','-std=c11','-O2','-I'+str(repo),'-I'+str(repo/'geometry-web'),str(new_bridge),'-lm','-o',str(exe)]
start=time.monotonic_ns();compiled=subprocess.run(argv,capture_output=True)
(out/'compile.stdout').write_bytes(compiled.stdout);(out/'compile.stderr').write_bytes(compiled.stderr)
receipt={'mutation':{'path':str(target.relative_to(repo)),'old':old.decode(),'new':replacement.decode()},'compile_argv':argv,'compile_exit':compiled.returncode,'compile_seconds':(time.monotonic_ns()-start)/1e9,
 'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [target,changed,new_core,new_bridge]},'current_geometry_crlf_preserved':new_core.read_bytes().count(b'\n')==new_core.read_bytes().count(b'\r\n')}
assert compiled.returncode==0,compiled.stderr.decode()
results=[]
for label,binary in [('fixed-before',pathlib.Path('/tmp/geometry-tests/bridge')),('withdrawn',exe),('fixed-restored',pathlib.Path('/tmp/geometry-tests/bridge'))]:
 folder=out/label;argv=['python3',str(root/'run_thickness_case.py'),'--binary',str(binary),'--out',str(folder)]
 start=time.monotonic_ns();process=subprocess.Popen(argv,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=process.communicate()
 (folder/'stdout').write_bytes(stdout);(folder/'stderr').write_bytes(stderr);data=json.loads((folder/'result.json').read_text())
 result={'label':label,'argv':argv,'pid':process.pid,'actual_os_exit':process.returncode,'seconds':(time.monotonic_ns()-start)/1e9,'result':data};results.append(result)
 assert data['tests_run']==1 and len(data['subtests'])==3 and not data['errors'] and not data['skips'],(label,data)
 if label=='withdrawn':
  assert process.returncode==1 and len(data['failures'])==2
  assert all('PF2_THICKNESS_VALUE_9' in failure['traceback'] and 'I52' in failure['traceback'] for failure in data['failures'])
  assert [s['ok'] for s in data['subtests']]==[True,False,False]
 else:assert process.returncode==0 and not data['failures'] and all(s['ok'] for s in data['subtests'])
 print(label,process.returncode,'failures',len(data['failures']),'errors',len(data['errors']),'skips',len(data['skips']),flush=True)
receipt['runs']=results;(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
assert target.read_bytes()==original
