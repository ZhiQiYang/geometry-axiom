import hashlib,json,os,pathlib,shutil,subprocess,sys
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2');sys.path.insert(0,str(repo/'tests'));import mutate
expected={m['id'] for m in mutate.MUTANTS};merged={};batches=[]
for label in ['warm','batch-1','batch-2','batch-3','batch-4']:
 folder=root/'mutation-batches'/label;receipt=json.loads((folder/'receipt.json').read_text());assert receipt['exit']==0,receipt
 records=json.loads((folder/'results.json').read_text())
 assert set(receipt['ids'])==set(records),(label,set(records))
 for name,record in records.items():
  assert name not in merged,name
  assert record['verdict'] in ['killed','crashed','equivalent','retired'],(label,name,record)
  merged[name]=record
 batches.append(receipt)
assert set(merged)==expected
path=root/'mutants_results.merged.json';mutate.save_records(path,merged)
run=subprocess.run(['python3','tests/mutate.py','--check'],cwd=repo,env=dict(os.environ,MUTATE_RESULTS=str(path),MUTATE_CACHE=str(root/'mutation-cache')),capture_output=True)
(root/'mutation-check.stdout').write_bytes(run.stdout);(root/'mutation-check.stderr').write_bytes(run.stderr);(root/'mutation-check.exit').write_text(str(run.returncode)+'\n')
assert run.returncode==0,run.stdout.decode()
if not (root/'mutants_results.before.json').exists():shutil.copyfile(repo/'tests/mutants_results.json',root/'mutants_results.before.json')
shutil.copyfile(path,repo/'tests/mutants_results.json')
counts={verdict:sum(r['verdict']==verdict for r in merged.values()) for verdict in ['killed','crashed','equivalent','retired']}
(root/'mutation-refresh.json').write_text(json.dumps({'counts':counts,'total':len(merged),'actual_check_exit':run.returncode,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'ledger_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'MUTATE_CACHE':str(root/'mutation-cache'),'batches':batches},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'total':len(merged),'check_exit':run.returncode}))
