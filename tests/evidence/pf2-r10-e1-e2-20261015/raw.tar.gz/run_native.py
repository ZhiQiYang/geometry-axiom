import datetime,hashlib,json,os,pathlib,platform,resource,shutil,subprocess,time
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2');out=root/'native';out.mkdir()
def git(*argv):return subprocess.check_output(['git',*argv],cwd=repo,text=True).strip()
def source_hashes():
 files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
 return {f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in files if f and (repo/f).is_file() and f!='tests/run_all.expected.json'}
assert git('status','--porcelain')==''
expected=repo/'tests/run_all.expected.json';shutil.copyfile(expected,out/'expected-before.json')
metadata={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'started_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'platform':platform.platform(),'stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK),'source_before':source_hashes(),'argv':['python3','-u','tests/run_all.py','--build','--update-expected'],
 'environment_override':{'MUTATE_CACHE':str(root/'mutation-cache')},'formal_WSL':False,
 'declared_generated_change':'run_all --update-expected may update only py:test_panel_fill_layout 17 -> 18 after the complete census'}
start=time.monotonic_ns()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 p=subprocess.Popen(metadata['argv'],cwd=repo,env=dict(os.environ,MUTATE_CACHE=str(root/'mutation-cache')),stdout=stdout,stderr=stderr)
 metadata['pid']=p.pid;(out/'started.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');code=p.wait()
metadata.update(exit=code,seconds=(time.monotonic_ns()-start)/1e9,ended_at=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 source_after=source_hashes(),head_after=git('rev-parse','HEAD'),status_after=git('status','--porcelain'))
metadata['source_unchanged_except_declared_expected']=metadata['source_before']==metadata['source_after']
shutil.copyfile(expected,out/'expected-after.json')
before=json.loads((out/'expected-before.json').read_text());after=json.loads(expected.read_text())
intended=json.loads(json.dumps(before));intended['suites']['py:test_panel_fill_layout']['count']=18
metadata['expected_change_exactly_one_test']=after==intended
metadata['binary_fingerprints']={p.name:json.loads(p.read_text()) for p in pathlib.Path('/tmp/geometry-tests').glob('*.fingerprint.json')}
shutil.copytree('/tmp/geometry-tests/run_all-logs',out/'logs')
for name in ['stdout','stderr']:
 data=(out/name).read_bytes();metadata[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'result.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');(out/'exit').write_text(str(code)+'\n')
print(json.dumps({'head':metadata['head'],'exit':code,'seconds':metadata['seconds'],'source_unchanged_except_declared_expected':metadata['source_unchanged_except_declared_expected'],'expected_change_exactly_one_test':metadata['expected_change_exactly_one_test']}),flush=True)
raise SystemExit(code)
