import datetime,hashlib,json,os,pathlib,subprocess,sys,time
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake31-pf2')
label=sys.argv[1];ids=sys.argv[2:];out=root/'mutation-batches'/label;out.mkdir(parents=True)
cache=root/'mutation-cache';results=out/'results.json';env=dict(os.environ,MUTATE_CACHE=str(cache),MUTATE_RESULTS=str(results))
argv=['python3','-u','tests/mutate.py',*ids];start=time.monotonic_ns()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 p=subprocess.Popen(argv,cwd=repo,env=env,stdout=stdout,stderr=stderr)
 metadata={'argv':argv,'pid':p.pid,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
  'started_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'MUTATE_CACHE':str(cache),'MUTATE_RESULTS':str(results),'ids':ids}
 (out/'started.json').write_text(json.dumps(metadata,indent=2)+'\n');code=p.wait()
metadata.update(exit=code,seconds=(time.monotonic_ns()-start)/1e9,ended_at=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat())
for name in ['stdout','stderr']:
 data=(out/name).read_bytes();metadata[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'receipt.json').write_text(json.dumps(metadata,indent=2)+'\n');(out/'exit').write_text(str(code)+'\n')
print(json.dumps({'batch':label,'exit':code,'seconds':metadata['seconds'],'ids':ids}),flush=True)
raise SystemExit(code)
