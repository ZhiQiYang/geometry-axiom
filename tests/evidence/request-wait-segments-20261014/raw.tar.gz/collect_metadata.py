import datetime,hashlib,json,pathlib,resource,subprocess,time

repo=pathlib.Path('/tmp/geometry-209-segments')
out=pathlib.Path('/tmp/geometry-wake29-209')
checks=[['git','rev-parse','HEAD'],['git','rev-parse','HEAD^{tree}'],['git','status','--porcelain'],
 ['git','diff','--exit-code','f9ada2201fedd0c962b9384f1c83ed53d3b7f876','--','geometry-web','geometry-core','current_geometry.c','公理層.md','geometry-guide','BACKLOG.md','決策佇列.md','sketchup-plugin'],
 ['python3','tests/binaries.py','status','bridge'],['node','--check','tests/diagnostics/request_wait_segments/browser.cjs'],
 ['python3','-m','py_compile','tests/diagnostics/request_wait_segments/server.py','tests/diagnostics/request_wait_segments/analyze.py'],
 ['uname','-a'],['python3','--version'],['node','--version'],['gcc','--version'],['/usr/bin/chromium','--version'],
 ['node','-p',"JSON.stringify({playwright:require('playwright/package.json').version,path:require.resolve('playwright')})"]]
results=[]
for command in checks:
 start=time.monotonic_ns();run=subprocess.run(command,cwd=repo,capture_output=True,text=True)
 results.append({'argv':command,'exit':run.returncode,'elapsed_ms':(time.monotonic_ns()-start)/1e6,'stdout':run.stdout,'stderr':run.stderr})
assert all(r['exit']==0 for r in results),results
files=['geometry-web/serve.py','geometry-web/app.js','geometry-web/runtime_version.py','geometry-web/cdp_test.js','tests/run_all.expected.json','current_geometry.c','公理層.md']
hashes={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files}
metadata={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'taipei':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'base':'f9ada2201fedd0c962b9384f1c83ed53d3b7f876','stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK),
 'os_release':pathlib.Path('/etc/os-release').read_text(),'checks':results,'source_sha256':hashes,
 'binary_fingerprint':json.loads(pathlib.Path('/tmp/geometry-tests/bridge.fingerprint.json').read_text()),
 'browser_plugin_available':False,'browser_plugin_discovery':'ALL_TOOLS filter browser/tool_search returned []; used existing Playwright with system Chromium; no installation'}
(out/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(results),'all_exit_zero':True,'base':metadata['base'],'stack_rlimit':metadata['stack_rlimit']}))
