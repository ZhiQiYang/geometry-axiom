## 現象
- #188 head 6855f9b1 的正式 canvas 首跑,在 P78「建立前矩形與角材試擺(不改世界)」中止。
- 等待條件 `$('igTrial')?.dataset.trialState==='ready'` 超時。
- 同時 connection.phase=error,錯誤訊息是 `The user aborted a request.`(grid-trial-query 被前端中止)。
- 收據:wsl-ci/6855f9b1-proxy-188-main005,原件見 #188 留言 6126602394。

## 已知
- 同一段在 #197(2f2c900e)、#189(10f385d2)、#184(3835c43b)的 canvas 都通過。#188 同 head 單獨重跑也通過(2207/0、golden 84 段一致)。
- 那一輪各 job 都明顯變慢(assembly 456 秒,上輪 289 秒;grid 860 秒)。
- **根因未證實**。dot 指出缺少 P78 候選代次、排隊/server/bridge 起迄、abort 與 state 的完整時間線。

## 要查的
1. grid-trial-query 的前端中止時限是多少?被中止後,UI 會不會重試或回報錯誤,還是永遠停在非 ready?如果是後者,這是產品的強韌性問題,不只是測試問題。
2. 在 CPU 節流下重現,記錄完整時間線(請求起迄、abort、trialState 變化)。
3. 依結果修:產品端(中止後可恢復)或測試端(有界等待,比照 #197)。要附修前紅、修後綠、移除修正變紅。

## 和合併的關係
#188 只改 Q17 的 space 測試,沒碰這段。依 P-067 以同 head 正式重跑補足 canvas;這個間歇問題在 main 上另行追查,不擋 #188。
