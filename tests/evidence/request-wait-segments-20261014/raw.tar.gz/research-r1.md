【ChatGPT 研究】R1 完整研究交付：15 秒逾時、UI 就緒與狀態不變量的分流診斷

研究日期：2026-10-14。開工與交付前核對的 main 均為 `0eb447e00605f6df117711b03e6c98ccabbcd026`。已讀根目錄 AGENTS.md、研究看板、本 issue 正文與交付前全部 24 則留言（最後一則為 6153998756）。以下程式引用全部固定到此 main；歷史執行資料另以原留言連結標示。

**交付性質：原始碼與既有診斷紀錄的交叉研究、逐症狀假說與可交辦實驗。這次沒有執行瀏覽器／WSL 測試，也沒有重新解包核验歷史原件；不宣稱已實測修好或證明所有歷史失敗具有同一根因。R1 研究交付完成不等於 #209 缺陷已閉合。**

## 一、最重要的結論

1. 「15 秒」來自前端 `/api` 的 `AbortSignal.timeout(15000)`，不是 C 核心的運算期限。請求可能尚在伺服器前置檢查、等鎖、等原生回覆，或回覆尚未被前端完整讀取；單憑這句錯誤不能定位是哪一段慢。
2. HTTP 伺服器是多執行緒，但有兩種不同層級的序列化：**全域 RuntimeSnapshot 來源檢查鎖**，以及**每個 NativeContext 的 bridge 鎖**。不能只研究 bridge 的 30 秒設定。
3. 前端一旦進入 `connection.phase === 'error'`，後續多個 `apiRequest()` 可在送出 fetch 之前直接返回同一錯誤。因此 P7 的後續讀取、P52 最後的 reset，未必各自發生一次新的 15 秒網路逾時。
4. P74／P87／P88／igBoundary 有「UI 尚未就緒、選單關閉、DOM 被換掉」這一類機制；P85 則是「狀態快照不相等」的另一類。不能把這些全部改寫成 bridge 慢。
5. 固定 main **已經有** P88 的每次重捲、來源／配置模式有界就緒等待，以及 P74 第二分頁診斷與編輯鎖釋放等待。研究必須把「舊紅燈」「目前已有防護」「仍未證明閉合」分開。

## 二、實際請求路徑與時限

### 2.1 前端：15 秒是請求／回覆期限，不是 native 計算時間

位置：
- [geometry-web/app.js:615–653](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/app.js#L615-L653)：連線守門、變更指令 requestId、POST `/api` 與 15000 ms signal。
- [geometry-web/app.js:654–700](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/app.js#L654-L700)：讀 JSON、失敗後讀 receipt、錯誤分類與 connectionFailed。
- [geometry-web/app.js:500–613](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/app.js#L500-L613)：receipt 的 35000 ms signal、連線恢復、inert 與重試控制。

已確認：只有符合變更指令條件且已有 session 的請求才帶業務 requestId。失去回覆後讀的是**同一操作的 receipt**，不是重送原變更。一般 `references`、`boundary`、`source-inspect`、`grid-trial-query` 不走此變更 receipt 路徑。前端 error 狀態的守門發生在 fetch 之前；守門拒絕會沿用 connection.error。

### 2.2 HTTP 並非單執行緒；原生通道按 context 串行

位置：
- [geometry-web/serve.py:318–340](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/serve.py#L318-L340)：`PreviewHTTPServer(http.server.ThreadingHTTPServer)`、request queue size 128、回覆寫入。
- [geometry-web/native_context.py:9–36](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/native_context.py#L9-L36)：每個 context 啟動一個 bridge 子程序、RLock、stdout reader thread 與回覆 Queue。
- [geometry-web/serve.py:85–146](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/serve.py#L85-L146)：30 秒設定、bridge_lock.acquire、stdin.write／flush、bridge_responses.get。
- [geometry-web/serve.py:168–207](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/serve.py#L168-L207)：receipt_lock、快取原結果、先到的 receipt 封存未送達操作。

`bridge_lock.acquire(timeout=30)` 與 `bridge_responses.get(timeout=30)` 是**前後兩段等待**，不是共用一個端到端 30 秒額度。變更請求還可能先等 receipt_lock。stdin.write／flush 在此函式沒有另設期限。故不能把 30 秒當作整個 HTTP 請求的硬上限，更不能推論前端 15 秒內必定拿到資料。

不同 NativeContext 的 bridge 鎖分開；同一個 context 上，讀取也會和其他 bridge 指令互相等待。此證據定位的是宿主的序列化邊界，不是宣稱 C 程式內部所有工作都只有一個執行緒。也不應以移除 bridge 鎖作為提速捷徑，否則原本共用 stdin/stdout 與 World 的指令／回覆配對會失去既有保護。

### 2.3 本輪補出的前置等待來源：全域來源檢查鎖

位置：
- [geometry-web/serve.py:463–480](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/serve.py#L463-L480)：按 command 判斷是否略過 RUNTIME.fresh。
- [geometry-web/runtime_version.py:107–170](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/runtime_version.py#L107-L170)：RuntimeSnapshot 的 Lock 與 fresh() 逐檔讀取、比對來源內容及檔案集合。

**已確認：** fresh() 持有同一個 RuntimeSnapshot 的 `_lock`，鎖取得處沒有 timeout；每次檢查都讀取來源檔案內容，不只是看 mtime。`grid-trial-query` 不在上述略過清單，因此會經過 fresh()；`source-inspect`、`references`、`dump` 等清單內讀取，以及 receipt 則略過。這是 bridge 之前、跨 native context 仍可能共用的序列化點。

**推測：** 高磁碟／主機負載下，fresh() 的鎖等待或讀檔可能消耗 P78、變更請求的前端期限。這次沒有量到它在歷史失敗中的實際耗時，不能列為已證實根因。它也不能直接解釋所有 `references`／`source-inspect` 逾時，因為那些命令略過這項檢查。

**驗證：** 分開記 fresh() 入場、取得鎖、檔案列舉／讀取結束、離場，再與橋接鎖／原生回覆階段對照。不能用 TTL、只看時間戳、關閉來源核對或放寬版本守門來換取綠燈；那會改變現有保護。

### 2.4 最容易誤讀的診斷欄位

[geometry-web/cdp_test.js:116–150](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/cdp_test.js#L116-L150) 的 `observeAssetNetwork` 只收 Script／Stylesheet 或 `.js/.css` 資源。**FATAL_NETWORK 的 failures／pendingAssets 為空，不代表 `/api` 沒有卡住或中止。** `/api` 必須另外記錄完整 request/response 時間線。

## 三、逐症狀：假說優先度、最小實驗、修正歸屬

下列排序是依目前證據安排的調查優先度，不是統計機率；尚無失敗欄位／時間線者，不能給出可靠的機率高低。歷史記錄與目前控制流的對照是機制推測，不假定所有舊 head 和目前 main 位元相同。

### A. P7：15 秒錯誤之後出現 undefined／[0]

**程式位置：** 上述 app.js 請求／守門；另見 [geometry-web/cdp_test.js:1074–1100](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/cdp_test.js#L1074-L1100)。P7 的 ortho 計算雖檢查 b.ok，接下來 return 的 `b.loops[0].verts.length` 仍直接讀取 loops。

**既有證據：** [第 6 班 r2 記錄](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6148652177) 描述 source-inspect／dump／boundary 與後續 TypeError；首跑 91 pass、0 assertion fail，但未完成、未比較 golden，不能當綠燈。

**推測排序：** ① 最早的真請求先失敗，後續讀取被前端 error 守門拒絕，再由未檢查的 b.loops 造成第二層例外；② 最早失敗本身來自 bridge 排隊／回覆交付或瀏覽器處理延遲；③ 若完整 API 全部成功，才另查邊界資料／凹口操作的實作錯誤。

**最小實驗：** 在隔離 P7 流程中只延遲一筆實際 source-inspect 讀取，分別使用小於與大於 15 秒的診斷條件。保留原始輸入與斷言，記 apiRequest 呼叫、實際 fetch、伺服器收到的 cmd、第一筆失敗與 b 的原始 ok/error。看 dump／boundary 是否真的送出，而不是依同一錯誤字串計三次逾時。

**修正方向：** 測試先檢查查詢成功，失敗時保留最早錯誤及階段，仍判失敗；不能用預設空 loops 或跳過斷言掩蓋。只有確定是尚未完成、且 connection 未進 error 的非同步流程，才增加對應的有界完成等待。原始 transport／恢復缺陷則歸產品端。

### B. P52：at-line 斷言先紅，下一組 reset 才報 15 秒

**程式位置：** [geometry-web/app.js:615–700](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/app.js#L615-L700) 的錯誤傳播與 requestId／receipt 路徑。

**既有證據：** [第 9 班原摘要](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6152481808) 已記 `references` 先於失敗斷言回報 signal timed out、15007 ms；失敗組出現空 tbAnchor、sent=[]、rng=null，下一組 setup 的 reset 才沿用 15 秒錯誤。原結果是 707 pass／1 fail，未完成，不能改寫成「沒有 assertion 失敗，只有 reset 太慢」。

**推測排序：** ① references 的 transport 失敗造成定位資料未就緒，後續 UI 操作與 reset 連鎖失敗；② 在 transport 正常的情況下，檢查器重建／選項初始化競態使 anchor 丟失；③ 只有確認正確 at-line 指令確曾送達且回覆成功後，才支持 `-u+n` 幾何方向的真錯誤。

**最小實驗：** 僅在該組進入面工作區時延遲 references 的真回覆，量 tbAnchor options/value、面／承載面 id、connection、sent 原指令與實際 HTTP reset 入場次數。用 3 秒條件區分「尚在載入」；用超過前端期限的條件區分「永久 error，需要恢復」。不重送變更命令。

**修正方向：** 就緒等待只適用於 references 正常但尚未發布到 UI 的情況；connection 已 error 不能靠多 sleep 解決。若 error 後仍允許操作依賴缺失資料的定位控制，需產品端停止該路徑並提供可到達的恢復。不能改幾何期望值來配合 rng=null。

### C. P78：連線恢復，不等於同一份試擺已恢復

**程式位置：** [geometry-web/grid-trial.js:35–80](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid-trial.js#L35-L80) 的 invalidate、newKey/key、serial、error、pending 與 trialState；app.js 的 recoverConnection 見上節。

**已確認的機制：** 查詢排程只在 `newKey !== key` 時建立。失敗把 error 留下，但不把 key 清空；對同一鍵單純 redraw 不會重送查詢。輸入 invalidate 或不同來源／查詢鍵才會另起代次。因此不能把 connection.ready 當作 trial.ready 的等價條件。

**既有證據：** [P78 控制實驗摘要](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6131012315)：CPU 20 倍節流單獨條件可通過；另注入約 18 秒持鎖延遲會觸發前端逾時，原生稍後仍成功。診斷直接恢復連線後舊 trial 仍 error，改寬度才產生新代次；當時對話框下真重試按鈕 hit=false。這是既有診斷的記錄，不是本輪重現，也不是原始首敗根因證明。

**推測排序：** ① 首次查詢失敗後，同鍵的錯誤快取／缺少可達恢復流程放大為持續不 ready；② 首次失敗耗時來自 fresh 全域鎖／讀檔、bridge 等待或交付延遲；③ trial 真資料過密／不完整，需要和 transport 分開，不能把 QUERY_CAPACITY 也當成暫時逾時重試。

**最小實驗：** 固定同一份草稿、矩形、sourceFingerprint 和 context，延遲一筆真 grid-trial-query；移除延遲後只使用真實可點的既有恢復入口，不偷偷改尺寸。記 key/serial、trialState、connection、原生查詢次數與過期代次是否被丟棄，核對 World／歷史不變。分別在 fresh 前置階段與 bridge 階段注入，不能只注入一種後就認定另一種不存在。

**修正方向：產品端優先。** 使使用者能在保留原稿的情況下恢復目前仍有效的唯讀試擺；優先沿用既有恢復／狀態入口。不能重新送出任何未確認的 World 變更；也不能讓已離開／已換 context 的舊候選被復活。測試仍等真正的 exact ready，不把 error 算完成。

### D. P74：第二分頁取得權限後，控制項仍不可點

**程式位置：** [geometry-web/ux_refinement_test.js:204–260](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/ux_refinement_test.js#L204-L260)：第二分頁 until／control、diagnostics、真實分頁關閉與 WebLock 釋放等待。

**目前已有防護：** 新分頁等待 connection.ready、非 busy、recovery 非 pending；關閉原編輯分頁後也會確認 target 消失及指定 editor lock 不再 held。不能再把「增加 owner 關閉等待」當作本輪新修正。control 本身仍是一次捲動／量測，失敗直接丟錯；成功後固定等 180 ms。目前已有 rect、hit、menu 與鎖診斷，比[早期只有 unreachable 的記錄](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6137125695)完整。

**推測排序：** ① 編輯權限旗標完成，但共用 project bar／popover 的版面與命中狀態尚未穩定；② 晚到的 UI 重建、覆蓋層或錯誤的共享節點歸屬使按鈕持續不可點；③ 僅在現有 lock 診斷證實沒有釋放時，才回頭查編輯鎖本身，不能預設是鎖未放。

**最小實驗：** 兩個真實分頁沿原流程執行，單獨對瀏覽器端施加節流；保留目前既有 ownerClosed/editorReleased 條件。從點恢復到點 projectInfoButton 逐次記 button 節點身分／父容器、rect、disabled、inert、elementFromPoint、popover、connection、editingBlocked、held/pending locks。比較「旗標完成」到「控制可達」間是否存在有限間隔。

**修正方向：** 有限間隔且最終可達，測試在同一指定 session 內等有界可達條件後只點一次；持續被覆蓋、共享節點歸屬錯誤或表面解鎖但使用者無法操作，歸產品。不要把原失敗控制直接改成程式呼叫來替代真點擊。

### E. P85：zero navigation 快照不相等

**程式位置：** [geometry-web/source_navigation_test.js:10–32](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/source_navigation_test.js#L10-L32)。snapshot 包含 dump.text、dirty、project state、history；比對是整包 JSON.stringify 相等。dump 沒有先要求 ok，失敗時也沒有印出前後快照與差異欄位。

**既有證據：** [P-097 重跑](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6149872027) 是 P7 通過後在 zero navigation 快照斷言失敗；既有[原件核回摘要](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6150945400)明說沒有 before/after，不能由這一個 false 確認哪個欄位改變。

**推測優先度：** ① setup 尚有晚到的狀態發布，在 before／after 之間被比較到；② 導航本身錯改 World、dirty、revision 或 history；③ dump 讀取失敗／非原子快照造成不可比較資料。①②目前沒有足夠證據區分高低；先補差異輸出，不能武斷歸給測試。前一個實際目標選取斷言通過，也不足以排除導航後半段的零 ID 問題。

**最小實驗：** 固定 zero 場景，保留原相等斷言，另輸出逐欄 diff、dump 的 ok/error/text hash、project revision、history frame 與 entries 的身分。做一個不導航的同時間控制組；再對一筆真來源讀取加入受控延遲。為 setup 完成、導航開始／完成與所有變更指令記因果序號。若不導航也漂移，優先查 baseline；若只有導航漂移且指向具體寫入，交產品修復。

**修正方向：先補診斷，不放寬 invariant。** 不把 dirty/revision/history 從比較中刪掉，也不把 0 改成其他 ID 避開失敗。只有證明 baseline 未完成，才改有界等待；若純導航真的改世界，必須修產品。

### F. P87：#btnNewProject 寬高 0

**程式位置：** [geometry-web/grid_rule_editor_test.js:15–34](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid_rule_editor_test.js#L15-L34) 的 newProject 先離開網格、點 fileMenuBtn，再點 btnNewProject；[geometry-web/index.html:56–67](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/index.html#L56-L67) 顯示按鈕位於預設 hidden 的 fileMenuPop；[geometry-web/app.js:314–325](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/app.js#L314-L325) 的共享 header 同步會搬移控制並呼叫 closeMenus。

**推測排序：** ① 選單原本已開，被無條件 toggle 點擊關閉，或離開工作區的晚到同步再次關閉它；② shared header／對話框的切換尚未完成，節點仍在不顯示的容器；③ 真正的樣式／版面錯誤。零尺寸優先查 hidden/display/父容器，不應直接當作一般「在視窗外，多捲幾次」問題。

**最小實驗：** 在原 P87 newProject 前後記 fileMenuPop.hidden/display、fileMenuBtn expanded、btnNewProject rect／父鏈、目前 dialog、焦點，以及 closeMenus 的呼叫時序。分別用初始選單開／關作控制，不增加世界操作。固定只使用真點擊，確認一次明確的開啟之後是否被晚到事件關閉。

**修正方向：** 若是測試對已開選單無條件 toggle，改為明確開門並有界等待項目可見；若產品在正常使用路徑晚到關閉／移走使用者剛開的選單，修產品。共用 makeCtl 的重捲不能修 hidden 祖先。這項在本 issue 現有 24 則中未取得足以定位原因的完整原始 rect／menu 軌跡，以上不冒充已重現。

### G. P88：DOM 重建後失去原捲動位置

**程式位置：** [geometry-web/grid-system-workspace.js:307–385](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid-system-workspace.js#L307-L385) 的 render 初始化、detach 共用列、整個 dialog.innerHTML 重建；[geometry-web/cdp_helpers.js:139–167](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/cdp_helpers.js#L139-L167) 的 makeCtl；[geometry-web/grid_rule_lines_test.js:6–24](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid_rule_lines_test.js#L6-L24) 採用該 helper。

**既有證據：** 必須採[更正後的同 viewport 診斷](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6132620092)：舊 .ig-settings scrollTop=805、新容器=0；目標由 top 394.828125／hit=true 變成 1199.828125／hit=false。不能沿用較早「兩邊都是 0」的錯誤摘要；該診斷還記 undo 19→20，不能宣稱完整 history 零變更。

**推測排序：** ① 捲動後 DOM 被換掉，量到的是未捲動的新節點；② 高度／折疊內容後來改變使目標離開 viewport；③ 持續覆蓋層／真正不可達的產品版面。

**最小實驗：** 固定 viewport 與場景，在「完成第一次捲動」與「下一次量測」之間受控觸發一次既有 DOM 重建；同時保存新舊節點身分、isConnected、scrollTop、rect 與 elementFromPoint。原目標、原斷言不變。

**修正方向與目前狀態：** main 的 makeCtl **已在每次量測前重新查詢並捲入**，不是只在迴圈外捲一次。先驗證這項防護，不能再交辦一個相同補丁。對照突變是移回迴圈外只捲一次，受控重建案例必須轉紅；若目前每次重捲仍長期不可達，才交產品查覆蓋／版面，而非再擴 attempts。

### H. igBoundary：仍在來源模式／初始化，卻已讀配置欄位

**程式位置：** [geometry-web/grid-system-workspace.js:307–385](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid-system-workspace.js#L307-L385) 依 mode 決定 igBindingForm 是否 hidden；[geometry-web/grid_rule_lines_test.js:39–61](https://github.com/ZhiQiYang/geometry-axiom/blob/0eb447e00605f6df117711b03e6c98ccabbcd026/geometry-web/grid_rule_lines_test.js#L39-L61) 的 usable、bindingEntry、newSourceReady。

**既有證據：** [擴充診斷](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6132451457) 在 3 秒持鎖條件觀察到 source mode、binding form hidden、connection ready；原量測先紅，待同一次開啟完成後原 boundary 選擇可操作。18 秒條件則進 error，不能與單純延遲混作一種恢復成功。

**推測排序：** ① 新模式尚未完成，讀到仍留在 DOM 的舊／隱藏欄位；② 真請求已失敗，初始化不能完成；③ 配置模式完成後資料中真的沒有預期 boundary option。

**最小實驗：** 對同一次新增配置分別施加 3 秒與超過前端期限的延遲，記 mode、初始化代次、saveSource/saveBinding 可見性、igBoundary 尺寸／disabled／options、context 與 connection。第一組應由有界就緒等待解決；第二組應明確進失敗／恢復，而不是延長等待到偶爾通過；第三組應報資料缺失，不自動選另一個面。

**修正方向與目前狀態：** main 的 P88 bindingEntry **已等 igSaveBinding 顯示、igBoundary 非零尺寸且可用**，newSourceReady 也不再只靠舊 igName 節點存在。這些是現有防護；其他測試路徑是否仍只等節點存在，要以其自身入口核對。產品若實際留下不可恢復的初始化狀態，不能只改测试等待。

## 四、可直接交辦的最小診斷包

**D1｜先做分段時間線，不先調大時限。** 固定待測 SHA、runtime version、binary hash、server/browser/native pid、context/session、獨立 port、TEMP/profile。每筆請求區分「apiRequest 被呼叫／本地守門拒絕／fetch 真送出」。伺服器分 fresh 鎖等待與檔案檢查、receipt 鎖等待、bridge 鎖等待、stdin 完成、reader 收到回覆、HTTP 寫回。診斷識別與業務 requestId 分開，不改 receipt 語義。耗時在各自 monotonic clock 內相減，跨程序只靠關聯識別排序，不直接相減不同時鐘。

**D2｜用小型、可控的負載定位，而非再跑一輪未知重負載。** 同一 fixture 先無注入，再每次只注入一個階段：前置來源檢查、橋接等待、真回覆交付、UI DOM 重建。3 秒／18 秒是用來跨越既有 15 秒門檻的診斷條件，不是新的產品時限。瀏覽器 CPU 節流、native 程序負載、磁碟延遲要分組，不能把 renderer 節流說成 Windows 主機／WSL 全部已被模擬。所有操作限隔離測試服務，不重設使用者服務。

**D3｜先辨識第一個錯誤，再判連鎖。** 對 P7/P52 儲存首筆真 API error 和後續是否實際送出；遇 transport error 後不可把缺資料的幾何欄位当作正常結果。對 P85 儲存逐欄差異；對 P74/P87/P88 儲存原始命中與容器狀態。不要只有單一 false／undefined／unreachable。

**D4｜產品與測試分開驗收。** pending 能正常完成才用有界等待；error 要可達的恢復；純導航的不變量不可放寬。P78 用「不改原稿、真點恢復、同份有效試擺重新 ready」作恢復驗收，另加舊代次不可回填；P88 驗證現有重捲防護，而不是重做已存在的補丁。

**D5｜保留紅→綠→移除修正再紅。** 每個方案都需受控重現的原紅、修後通過、拿掉該修正再紅，且失敗指向同一病因。等待 helper 的突變不能只靠整輪總逾時；要點名 mode/rect/hit/transport/key/差異欄位。原 assertion、golden、原始首敗收據保持原身分，不以多次重跑挑一份綠取代。

## 五、最不確定之處與不得超推的結論

- **最不確定的是歷史第一次慢在哪個階段。** 目前沒有把 Windows 主機、WSL、fresh 鎖、bridge 鎖、native、浏览器回覆消費串成同一條可核對時間線。全域 fresh 鎖是本輪確認的程式機制，但它在歷史事件中花多久仍未知。
- [既有登記](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6153695228) 明說 Windows 高負載是裁決引用，本機沒有保存當時 Windows 連續取樣；不得把 WSL foreign 取樣為空等同整台電腦無競爭，也不能把「都只在高負載出現」提升成已證明的必要條件。
- [下一班完整 canvas 通過](https://github.com/ZhiQiYang/geometry-axiom/issues/209#issuecomment-6153998756) 支持指定的後班驗證條件，不證明先前 P7/P52/P85 的共同根因。完整 job 耗時與單一 API 的 15 秒期限也不是同一個量。
- P85 缺 before/after、P87 缺完整 menu/rect 軌跡，現階段不能可靠地把它們歸到測試或產品任一邊。P88 的 controlled DOM 重建機制證據較強，但不能因此替其他症狀結案。

**研究結案：R1 所需的請求／鎖分析、全部列名症狀的程式對照、排序假說、最小鑑別實驗與修正分流已交付。#209 仍保留未實測閉合事項；本次未改檔、未開 PR、未合併或關閉任何項目。下一個看板研究項目為 R2。**
