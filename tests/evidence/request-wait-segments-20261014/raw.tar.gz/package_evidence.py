import csv,hashlib,json,pathlib,shutil,tarfile

root=pathlib.Path('/tmp/geometry-wake29-209')
repo=pathlib.Path('/tmp/geometry-209-segments')
dest=repo/'tests/evidence/request-wait-segments-20261014';dest.mkdir(parents=True,exist_ok=True)
shutil.copyfile(repo/'tests/diagnostics/request_wait_segments/analyze.py',root/'analyze.executed.py')
shutil.copyfile('/tmp/geometry-board-wake29.md',root/'BOARD-cloud-codex.read.md')
chosen=['baseline-run','cohorts','cohorts-drained','baseline.stdout','baseline.stderr','baseline.exit','cohorts.stdout','cohorts.stderr','cohorts.exit','cohorts-drained.stdout','cohorts-drained.stderr','cohorts-drained.exit','analysis.stdout','analysis.stderr','analysis.exit','analysis-drained.stdout','analysis-drained.stderr','analysis-drained.exit','metadata.json','metadata.stdout','metadata.stderr','metadata.exit','collect_metadata.py','analyze.executed.py','issue209.md','research-r1.md','BOARD-cloud-codex.read.md','package_evidence.py']
manifest={}
for name in chosen:
 p=root/name
 for file in (sorted(p.rglob('*')) if p.is_dir() else [p]):
  if file.is_file():manifest[str(file.relative_to(root))]={'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(dest/'raw.tar.gz','w:gz') as archive:
 for name in chosen:archive.add(root/name,arcname=name)
with tarfile.open(dest/'raw.tar.gz','r:gz') as archive:
 members={m.name:m for m in archive.getmembers() if m.isfile()}
 assert set(members)==set(manifest)
 for name,entry in manifest.items():assert hashlib.sha256(archive.extractfile(members[name]).read()).hexdigest()==entry['sha256'],name
for source,target in [('cohorts-drained/analysis.json','analysis.json'),('metadata.json','metadata.json'),('analysis-drained.stdout','analysis.stdout'),('cohorts-drained.stdout','cohorts.stdout')]:shutil.copyfile(root/source,dest/target)
for name in ['baseline','bridge18']:shutil.copyfile(root/'cohorts-drained'/name/'state.png',dest/(name+'.png'))
data=json.loads((dest/'analysis.json').read_text())
with (dest/'timeouts.csv').open('w',newline='') as stream:
 stages=list(data[1]['timeouts'][0]['stages'])
 writer=csv.DictWriter(stream,fieldnames=['case','id','command','browser_fetch_ms',*stages,'browser_headers_received','http_error']);writer.writeheader()
 for case in data:
  for request in case['timeouts']:
   writer.writerow({'case':case['case'],'id':request['id'],'command':request['command'],'browser_fetch_ms':request['browser_fetch_ms'],**request['stages'],'browser_headers_received':request['browser_headers_received'],'http_error':','.join(e['exception'] for e in request['http_write_errors'])})
archive=dest/'raw.tar.gz';(dest/'raw.tar.gz.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  raw.tar.gz\n')
print(json.dumps({'raw_files':len(manifest),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_member_hashes_verified':True}))
