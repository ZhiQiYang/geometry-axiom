(async()=>{
    await api("line reset");
    await api("line surface 1 origin 0 0 0 u +x v +y outline 0,0 200,0 200,100 0,100");
    await renderObjects();
    await enterFocus("face", 1);
    feSetTool("select");
    const hit = document.querySelector('[data-face-hit="e:0:0"]');
    await feDown({x: 100, y: 0}, {target: hit, clientX: 0, clientY: 0});
    await feUp({x: 100, y: 0}, {target: hit, clientX: 0, clientY: 0});
    document.querySelector('#feActionBar [data-fe-act="op:notch"]').click();
    const panel = !$("feOpPanel").hidden;
    const w = document.querySelector('#feOpPanel [data-fe-param="w"]');
    const d = document.querySelector('#feOpPanel [data-fe-param="d"]');
    w.value = "100"; w.dispatchEvent(new Event("input"));
    d.value = "50"; d.dispatchEvent(new Event("input"));
    document.querySelector("#feOpApply").click();
    await window.__cdpSettleUI(300);
    const b = await api("boundary 1");
    const ortho = b.ok && b.loops[0].verts.every((v,i,vs)=>{
      const nx = vs[(i+1)%vs.length];
      return v[0]===nx[0] || v[1]===nx[1];
    });
    return {tool: fe.tool, verts: b.loops[0].verts.length,
            fixity: b.loops[0].fixity.length, ortho, panel};
  })()