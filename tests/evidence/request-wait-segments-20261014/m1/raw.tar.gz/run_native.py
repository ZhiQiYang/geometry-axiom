import datetime,hashlib,json,pathlib,platform,resource,shutil,subprocess,time
repo=pathlib.Path('/tmp/geometry-209-segments');out=pathlib.Path('/tmp/geometry-wake30-235/native');out.mkdir()
def git(*argv):return subprocess.check_output(['git',*argv],cwd=repo,text=True).strip()
def hashes():
 files=['current_geometry.c','geometry-web/serve.py','geometry-web/app.js','tests/run_all.py','tests/run_all.expected.json','tests/diagnostics/request_wait_segments/analyze.py','tests/diagnostics/request_wait_segments/check_counterexamples.py']
 return {f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in files}
def binaries():return {p.name:json.loads(p.read_text()) for p in pathlib.Path('/tmp/geometry-tests').glob('*.fingerprint.json')}
assert git('status','--porcelain')==''
metadata={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'started_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'os':platform.platform(),'python':platform.python_version(),'stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK),'source_before':hashes(),'binaries_before':binaries(),
 'argv':['python3','-u','tests/run_all.py','--build'],'formal_WSL':False}
start=time.monotonic_ns()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 process=subprocess.Popen(metadata['argv'],cwd=repo,stdout=stdout,stderr=stderr)
 metadata['pid']=process.pid
 (out/'started.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
 code=process.wait()
metadata.update({'exit':code,'elapsed_seconds':(time.monotonic_ns()-start)/1e9,'ended_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'source_after':hashes(),'binaries_after':binaries(),'head_after':git('rev-parse','HEAD'),'status_after':git('status','--porcelain')})
metadata['source_unchanged']=metadata['source_before']==metadata['source_after']
for name in ['stdout','stderr']:
 data=(out/name).read_bytes();metadata[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
shutil.copytree('/tmp/geometry-tests/run_all-logs',out/'logs')
(out/'result.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');(out/'exit').write_text(str(code)+'\n')
print(json.dumps({'head':metadata['head'],'exit':code,'seconds':metadata['elapsed_seconds'],'source_unchanged':metadata['source_unchanged']}),flush=True)
raise SystemExit(code)
