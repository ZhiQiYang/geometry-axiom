import hashlib,json,pathlib,shutil,tarfile
root=pathlib.Path('/tmp/geometry-wake30-235');repo=pathlib.Path('/tmp/geometry-209-segments')
dest=root/'delivery';dest.mkdir(exist_ok=True)
native=json.loads((root/'native/result.json').read_text())
isolated=json.loads((root/'native-isolated/result.json').read_text())
counter=json.loads((root/'counterexamples/summary.json').read_text())
assert native['head']==native['head_after']=='644f187fbca3ac085a48eb1310b0a150625479e3'
assert native['source_unchanged'] and not native['status_after']
assert isolated['head']==isolated['head_after']=='a3ce4a84d29d7b26bac1d97b0f092e5e53a487a4'
assert isolated['exit']==0 and isolated['source_unchanged'] and not isolated['status_after']
assert isolated['source_before']==native['source_before'] and isolated['mutate_cache_empty_before'] and isolated['mutate_cache_empty_after']
assert counter['counterexamples_rejected']==12 and counter['unchanged_accepted']
chosen=['reanalysis','counterexamples.stdout','counterexamples.stderr','counterexamples.exit',
 'counterexamples/summary.json','counterexamples/analyze-before-M1.py','counterexamples/analyze.executed.py','counterexamples/cases',
 'native','native-isolated','run_native.py','run_native_isolated.py','package_m1.py','diagnose_cache.py','cache-diagnosis.json','cache-probe.stdout','cache-probe.stderr','cache-probe.exit',
 'check_cache_negative.py','cache-negative.json','cache-negative.stdout','cache-negative.stderr','cache-negative.exit']
manifest={}
for name in chosen:
 p=root/name
 for file in sorted(p.rglob('*')) if p.is_dir() else [p]:
  if file.is_file():manifest[str(file.relative_to(root))]={'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
(dest/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(dest/'raw.tar.gz','w:gz') as archive:
 for name in chosen:archive.add(root/name,arcname=name)
with tarfile.open(dest/'raw.tar.gz') as archive:
 members={m.name:m for m in archive if m.isfile()};assert set(members)==set(manifest)
 for name,entry in manifest.items():assert hashlib.sha256(archive.extractfile(members[name]).read()).hexdigest()==entry['sha256'],name
shutil.copyfile(root/'counterexamples/summary.json',dest/'counterexamples.json')
shutil.copyfile(root/'counterexamples.stdout',dest/'counterexamples.stdout')
shutil.copyfile(root/'native-isolated/result.json',dest/'native.json')
shutil.copyfile(root/'native-isolated/stdout',dest/'native.stdout');shutil.copyfile(root/'native-isolated/stderr',dest/'native.stderr')
shutil.copyfile(root/'reanalysis/stdout',dest/'analysis.stdout')
shutil.copyfile(root/'counterexamples/source/cohorts-drained/analysis.json',dest/'analysis.json')
digest=hashlib.sha256((dest/'raw.tar.gz').read_bytes()).hexdigest();(dest/'raw.tar.gz.sha256').write_text(digest+'  raw.tar.gz\n')
print(json.dumps({'files':len(manifest),'archive_bytes':(dest/'raw.tar.gz').stat().st_size,'sha256':digest,'first_native_exit':native['exit'],'isolated_native_exit':isolated['exit'],'counterexamples':12}))
