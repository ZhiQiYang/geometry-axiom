import hashlib,json,os,pathlib,shutil,subprocess,time
repo=pathlib.Path('/tmp/geometry-209-segments');out=pathlib.Path('/tmp/geometry-wake30-235')
cache=out/'negative-mutants';(cache/'M01').mkdir(parents=True)
source=pathlib.Path('/tmp/geometry-tests/mutants/M01')
for name in ['_mut.exe','_mut.exe.fingerprint.json']:shutil.copyfile(source/name,cache/'M01'/name)
start=time.monotonic_ns()
run=subprocess.run(['python3','tests/mutate.py','--check'],cwd=repo,env=dict(os.environ,MUTATE_CACHE=str(cache)),capture_output=True)
(out/'cache-negative.stdout').write_bytes(run.stdout);(out/'cache-negative.stderr').write_bytes(run.stderr);(out/'cache-negative.exit').write_text(str(run.returncode)+'\n')
assert run.returncode==1 and b'STALE M01' in run.stdout and b'cached binary differs from executed receipt' in run.stdout
(out/'cache-negative.json').write_text(json.dumps({'argv':['python3','tests/mutate.py','--check'],'environment_override':{'MUTATE_CACHE':str(cache)},
 'exit':run.returncode,'elapsed_ms':(time.monotonic_ns()-start)/1e6,'injected_mutant':'M01','copied_from':str(source),
 'binary_sha256':hashlib.sha256((cache/'M01/_mut.exe').read_bytes()).hexdigest(),'sidecar':json.loads((cache/'M01/_mut.exe.fingerprint.json').read_text()),
 'expected_rejection':'cached binary differs from executed receipt','default_cache_untouched':True},ensure_ascii=False,indent=2)+'\n')
print(run.stdout.decode())
