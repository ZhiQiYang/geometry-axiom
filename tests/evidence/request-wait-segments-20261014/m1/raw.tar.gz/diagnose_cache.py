import hashlib,json,pathlib,subprocess,sys,time
repo=pathlib.Path('/tmp/geometry-209-segments');out=pathlib.Path('/tmp/geometry-wake30-235')
sys.path.insert(0,str(repo/'tests'));import mutate
source=mutate.Sources(repo);ledger=json.loads((repo/'tests/mutants_results.json').read_text());cache=out/'isolated-mutants';cache.mkdir(exist_ok=False)
items=[]
for name,record in ledger.items():
 path=pathlib.Path('/tmp/geometry-tests/mutants')/name/'_mut.exe'
 if 'execution' not in record or not path.is_file():continue
 sidecar=path.with_name(path.name+'.fingerprint.json')
 items.append({'mutant':name,'recorded_binary_sha256':record['execution']['exe_sha256'],'cached_binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
  'current_closure_sha256':source.closure,'recorded_closure_sha256':record['closure_sha256'],'cached_sidecar':json.loads(sidecar.read_text())})
env=dict(__import__('os').environ,MUTATE_CACHE=str(cache));start=time.monotonic_ns()
run=subprocess.run(['python3','tests/mutate.py','--check'],cwd=repo,env=env,capture_output=True)
(out/'cache-probe.stdout').write_bytes(run.stdout);(out/'cache-probe.stderr').write_bytes(run.stderr);(out/'cache-probe.exit').write_text(str(run.returncode)+'\n')
data={'default_cache':'/tmp/geometry-tests/mutants','isolated_cache':str(cache),'isolated_initially_empty':True,'isolated_empty_after_check':not any(cache.iterdir()),
 'check_exit':run.returncode,'check_elapsed_ms':(time.monotonic_ns()-start)/1e6,'check_argv':['python3','tests/mutate.py','--check'],'cache_items':items,
 'contract_reference':'tests/mutate.py:723-735; tests/test_mutation_freshness.py:test_portable_receipt_accepts_clean_checkout_without_temp_binary',
 'default_cache_untouched':True,'ledger_untouched':True}
(out/'cache-diagnosis.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert run.returncode==0 and data['isolated_empty_after_check']
assert all(item['current_closure_sha256']==item['recorded_closure_sha256'] for item in items)
assert any(item['cached_sidecar']['fingerprint']['closure_sha256']!=item['current_closure_sha256'] for item in items)
print(json.dumps({'isolated_check_exit':run.returncode,'cache_items':len(items),'original_cache_retained':True,'ledger_unchanged':True}))
