import datetime,hashlib,json,os,pathlib,platform,resource,shutil,subprocess,time
repo=pathlib.Path('/tmp/geometry-209-segments');root=pathlib.Path('/tmp/geometry-wake30-235');out=root/'native-isolated';out.mkdir()
cache=root/'isolated-mutants';assert cache.is_dir() and not any(cache.iterdir())
def git(*argv):return subprocess.check_output(['git',*argv],cwd=repo,text=True).strip()
def hashes():
 files=json.loads((root/'native/result.json').read_text())['source_before']
 result={f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in files}
 assert result==files,'product and test source must equal first run'
 return result
def binaries():return {p.name:json.loads(p.read_text()) for p in pathlib.Path('/tmp/geometry-tests').glob('*.fingerprint.json')}
assert git('status','--porcelain')==''
metadata={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'started_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'os':platform.platform(),'python':platform.python_version(),'stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK),'source_before':hashes(),'binaries_before':binaries(),
 'argv':['python3','-u','tests/run_all.py','--build'],'formal_WSL':False,'environment_override':{'MUTATE_CACHE':str(cache)},'mutate_cache_empty_before':True,
 'first_native_head':'644f187fbca3ac085a48eb1310b0a150625479e3','same_product_and_test_sources_as_first_run':True}
start=time.monotonic_ns()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 process=subprocess.Popen(metadata['argv'],cwd=repo,stdout=stdout,stderr=stderr,env=dict(os.environ,MUTATE_CACHE=str(cache)))
 metadata['pid']=process.pid;(out/'started.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');code=process.wait()
metadata.update({'exit':code,'elapsed_seconds':(time.monotonic_ns()-start)/1e9,'ended_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'source_after':hashes(),'binaries_after':binaries(),'head_after':git('rev-parse','HEAD'),'status_after':git('status','--porcelain'),'mutate_cache_empty_after':not any(cache.iterdir())})
metadata['source_unchanged']=metadata['source_before']==metadata['source_after']
for name in ['stdout','stderr']:
 data=(out/name).read_bytes();metadata[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
shutil.copytree('/tmp/geometry-tests/run_all-logs',out/'logs')
(out/'result.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');(out/'exit').write_text(str(code)+'\n')
print(json.dumps({'head':metadata['head'],'exit':code,'seconds':metadata['elapsed_seconds'],'source_unchanged':metadata['source_unchanged'],'mutate_cache_empty_after':metadata['mutate_cache_empty_after']}),flush=True)
raise SystemExit(code)
