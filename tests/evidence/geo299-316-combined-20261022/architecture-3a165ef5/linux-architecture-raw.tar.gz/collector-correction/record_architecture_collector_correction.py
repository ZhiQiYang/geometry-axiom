"""Record the external retirement collector's CRLF correction; no product writes."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

TOOLS = Path('/workspace/geo299316-architecture-tools-r2')
OLD = Path('/workspace/geo299316-architecture-l-3a165ef5')
path = TOOLS / 'refresh_architecture_core.py'
before = (OLD / 'tools' / path.name).read_bytes()
after = path.read_bytes()
expected = before.replace(b"scanner_module.lex(raw.decode('utf-8-sig'), path, c=True)",
                          b"scanner_module.lex(normalized(raw).decode('utf-8-sig'), path, c=True)")
expected = expected.replace(b"scanner_module.lex(body.decode('utf-8-sig'), path, c=True)",
                            b"scanner_module.lex(normalized(body).decode('utf-8-sig'), path, c=True)")
assert after == expected and before != after
ast.parse(after.decode())
failed = json.loads((OLD / 'refresh/FAILED.json').read_text())
codes = {row['label']: row['exitCode'] for row in failed['commands']
         if row['label'] in ('final-scan', 'generic-tests', 'product-tests')}
assert codes == {'final-scan': 0, 'generic-tests': 0, 'product-tests': 0}
(TOOLS / 'R1_RUNTIME_CORRECTION.patch').write_text(''.join(difflib.unified_diff(
    before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
    fromfile='r1/refresh_architecture_core.py', tofile='r2/refresh_architecture_core.py')))
(TOOLS / 'R1_RUNTIME_CORRECTION.json').write_text(json.dumps({
    'schema': 'geo299316-external-collector-crlf-correction/1',
    'failed_original_output': str(OLD), 'original_outer_exit': 1,
    'original_three_judge_exits': codes,
    'before_sha256': hashlib.sha256(before).hexdigest(), 'after_sha256': hashlib.sha256(after).hexdigest(),
    'changed_only': ['retired API current-C raw decoder normalizes CRLF to LF before original lex',
                     'retired API old Git blob decoder normalizes CRLF to LF before original lex'],
    'reason': '原 scanner 先 raw.replace(CRLF,LF).decode(utf8)；原 lex.physical_lines(splice=c) 僅 splice 反斜線+LF。collector 直接 raw.decode 保 CRLF，導致假 lexical error。現沿原 normalize+lex，不自製預處理、不忽略錯誤。',
    'product_test_scanner_manifest_changed': False, 'ledger_regeneration_required': False,
    'ast_passed': True, 'new_runtime_result': None,
}, ensure_ascii=False, indent=2) + '\n')
files = [p for p in sorted(TOOLS.rglob('*')) if p.is_file() and p != TOOLS / 'SHA256SUMS']
(TOOLS / 'SHA256SUMS').chmod((TOOLS / 'SHA256SUMS').stat().st_mode | 0o200)
(TOOLS / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(TOOLS).as_posix() + '\n' for p in files))
print(json.dumps({'original_three_judge_exits': codes, 'external_tool_ast': 0,
                  'core_sha256': hashlib.sha256(after).hexdigest()}))
