#!/usr/bin/env python3
"""動態固定來源 #299+#316 Linux 架構重產；只窄開具名dead API guard退役，不改來源／manifest。"""
from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import resource
import signal
import subprocess
import sys
import time
import traceback

ARTIFACT_DIR = 'geometry-core/domain-decoupling'
ARTIFACTS = ('product-architecture.json', 'product-architecture-scan.json',
             'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json')
ROOTS = ('geometry-core', 'geometry-app', 'geometry-templates', 'geometry-web', 'geometry-guide')
STANDALONE = ('current_geometry.c', 'tests/__init__.py', 'tests/binaries.py')
SSOT = ('公理層.md', '決策佇列.md')
TOOLS = ('tests/architecture_contract.py', 'tests/test_architecture_contract.py', 'tests/test_product_architecture.py')
SUFFIXES = {'.c', '.cc', '.cjs', '.cpp', '.cxx', '.h', '.hh', '.hpp', '.htm', '.html', '.inc', '.js', '.jsx', '.mjs', '.py', '.ts', '.tsx'}
RETIRED_IDENTIFIER = 'wood_contact_footprint_collides'
SCANNER_MODULE = 'geo299316_w_policy_original_scanner'
SERIALIZATION = 'SHA-256 of UTF-8 JSON for the path-sorted inputs array, with ensure_ascii=false and separators=(comma,colon); each entry has path then sha256, and no trailing newline.'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalized(data):
    return data.replace(b'\r\n', b'\n')


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def file_info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'rawSha256': digest(raw), 'lfSha256': digest(normalized(raw))}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def collect_w_guard_inventory(repo, sealed, current, source_sha, scanner_info):
    # 僅在固定P完整Git blob／原scanner hash綁定之後執行；原W lexer規則不改。
    spec = importlib.util.spec_from_file_location(SCANNER_MODULE, repo / TOOLS[0])
    scanner_module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = scanner_module
    spec.loader.exec_module(scanner_module)
    identifier_origins, string_origins = collections.defaultdict(set), collections.defaultdict(set)
    w_c_files = []
    for entry in current['sources']:
        if entry['layer'] != 'W' or entry['language'] != 'c':
            continue
        relative = entry['path']
        raw = (repo / relative).read_bytes()
        w_c_files.append({'path': relative, 'rawSha256': digest(raw), 'lfSha256': digest(normalized(raw))})
        _, _, tokens = scanner_module.lex(raw.decode('utf-8-sig'), relative, c=True)
        for token in tokens:
            if token.kind == 'identifier' and token.value.startswith(('Wood', 'WOOD_', 'wood_')):
                identifier_origins[token.value].add((relative, token.line))
        # 與原 scan_c 一樣先串接相鄰 C string tokens，再盤點 namespaced literal。
        index = 0
        while index < len(tokens):
            if tokens[index].kind == 'string':
                start, value = tokens[index].line, tokens[index].value
                index += 1
                while index < len(tokens) and tokens[index].kind == 'string':
                    value += tokens[index].value
                    index += 1
                if re.match(r'^(?:wood|woodworking)[./-]', value):
                    string_origins[value].add((relative, start))
            else:
                index += 1
    old_identifiers = set(sealed['policy']['forbiddenIdentifiers'])
    old_strings = set(sealed['policy']['forbiddenStrings'])
    actual_identifiers_list = current['policy']['forbiddenIdentifiers']
    actual_strings_list = current['policy']['forbiddenStrings']
    require(isinstance(actual_identifiers_list, list) and isinstance(actual_strings_list, list) and all(isinstance(x, str) for x in actual_identifiers_list + actual_strings_list), 'guard集合必須是原schema字串lists')
    actual_identifiers = set(actual_identifiers_list); actual_strings = set(actual_strings_list)
    expected_identifiers = (old_identifiers | set(identifier_origins)) - {RETIRED_IDENTIFIER}
    expected_strings = old_strings | set(string_origins)
    def origins(rows, key):
        return [{'path': path, 'line': line} for path, line in sorted(rows.get(key, set()))]
    added_identifiers = sorted(expected_identifiers - old_identifiers)
    added_strings = sorted(expected_strings - old_strings)
    other_old = {key: value for key, value in sealed['policy'].items() if key not in ('forbiddenIdentifiers', 'forbiddenStrings')}
    other_current = {key: value for key, value in current['policy'].items() if key not in ('forbiddenIdentifiers', 'forbiddenStrings')}
    return {
        'schema': 'geometry-W-native-guard-inventory/1', 'sourceBaseHead': source_sha,
        'method': '沿既有refresh_architecture_w_linux.py原lex(c=True) loop；盤點P manifest所有W-owned C，再與上份sealed完整guard集合取union，僅減具名已授權dead API；不手選新增名字、不改manifest。',
        'identifierRule': '全部 manifest W-owned C 來源的原 lex(c=True) executable Wood*/WOOD_*/wood_* token，與完整舊 guard 做 union後僅減RETIRED_IDENTIFIER；當前W出現該token即拒絕。',
        'stringRule': '保留全部舊 guard；沿原 scan_c 串接相鄰 C string tokens，盤點 wood/woodworking namespaced decoded literal。',
        'scanner': scanner_info, 'wCInputs': w_c_files,
        'allCurrentWIdentifiers': [{'identifier': name, 'origins': origins(identifier_origins, name)} for name in sorted(identifier_origins)],
        'allCurrentWStrings': [{'value': value, 'origins': origins(string_origins, value)} for value in sorted(string_origins)],
        'addedIdentifiers': [{'identifier': name, 'origins': origins(identifier_origins, name)} for name in added_identifiers],
        'addedStrings': [{'value': value, 'origins': origins(string_origins, value)} for value in added_strings],
        'oldIdentifiersBefore': sorted(old_identifiers), 'oldIdentifiersPreserved': sorted(old_identifiers - {RETIRED_IDENTIFIER}), 'oldStringsPreserved': sorted(old_strings),
        'allowedRetiredIdentifiers': [RETIRED_IDENTIFIER],
        'currentRetiredWIdentifierOrigins': origins(identifier_origins, RETIRED_IDENTIFIER),
        'retiredIdentifierAbsentFromCurrentW': RETIRED_IDENTIFIER not in identifier_origins,
        'expectedIdentifiers': sorted(expected_identifiers), 'expectedStrings': sorted(expected_strings),
        'missingIdentifiers': sorted(expected_identifiers - actual_identifiers),
        'unexpectedIdentifiers': sorted(actual_identifiers - expected_identifiers),
        'missingStrings': sorted(expected_strings - actual_strings),
        'unexpectedStrings': sorted(actual_strings - expected_strings),
        'removedIdentifiers': sorted(old_identifiers - actual_identifiers),
        'removedStrings': sorted(old_strings - actual_strings),
        'identifiersBefore': len(old_identifiers), 'identifiersAfter': len(expected_identifiers),
        'stringsBefore': len(old_strings), 'stringsAfter': len(expected_strings),
        'allOtherPolicyFieldsEqual': other_old == other_current,
        'manifestMatchesMechanicalUnion': actual_identifiers == expected_identifiers and actual_strings == expected_strings and len(actual_identifiers) == len(actual_identifiers_list) and len(actual_strings) == len(actual_strings_list) and RETIRED_IDENTIFIER not in identifier_origins,
        'automaticManifestEdits': False, 'guardRetirementAllowed': [RETIRED_IDENTIFIER],
        'retirementProofState': 'W-only preliminary; full owned-C identifier census is required after the original three judges; not yet proved',
    }


def collect_retired_api_inventory(repo, sealed, current, source_sha, scanner_info,
                                  scan, scan_record, old_receipt, old_inputs, git):
    """同P原scanner的include邊＋原lexer全owned C普查；不是callgraph或native test。"""
    scanner_module = sys.modules[SCANNER_MODULE]
    entries = {entry['path']: entry for entry in current['sources']}
    c_entries = {path: entry for path, entry in entries.items() if entry['language'] == 'c'}
    seeds = sorted(c_entries)
    include_edges = [edge for edge in scan['edges']
                     if edge['source'] in c_entries and edge['target'] in c_entries]
    adjacency = collections.defaultdict(set)
    for edge in include_edges:
        adjacency[edge['source']].add(edge['target'])
    closure, pending = set(seeds), list(seeds)
    while pending:
        for target in adjacency[pending.pop()]:
            if target not in closure:
                closure.add(target)
                pending.append(target)
    # 所有manifest C（含.h/.inc）都是seed，不因入口不可達漏掉孤立來源。
    require(closure == set(c_entries), '全owned C seeds的include closure集合不一致')
    current_files, current_origins = [], []
    for path in sorted(closure):
        raw = (repo / path).read_bytes()
        _, _, tokens = scanner_module.lex(raw.decode('utf-8-sig'), path, c=True)
        refs = [{'path': path, 'line': token.line, 'layer': c_entries[path]['layer']}
                for token in tokens
                if token.kind == 'identifier' and token.value == RETIRED_IDENTIFIER]
        current_origins.extend(refs)
        current_files.append({'path': path, 'layer': c_entries[path]['layer'], 'bytes': len(raw),
                              'rawSha256': digest(raw), 'lfSha256': digest(normalized(raw)),
                              'retiredIdentifierOrigins': refs})

    old_entries = {entry['path']: entry for entry in sealed['sources'] if entry['language'] == 'c'}
    old_paths = sorted(old_entries)
    old_source = old_receipt['sourceBaseHead']
    require(re.fullmatch('[0-9a-f]{40}', old_source) is not None, '舊receipt需要完整來源SHA')
    require(all(path in old_inputs and '\n' not in path and '\r' not in path for path in old_paths), '舊owned C需完整登記在其sealed inputs')
    refs = ''.join(old_source + ':' + path + '\n' for path in old_paths).encode('utf-8')
    blobs = git('retired-api-old-owned-c-blobs', 'cat-file', '--batch', input_bytes=refs)
    old_files, old_origins, cursor = [], [], 0
    for path in old_paths:
        end = blobs.index(b'\n', cursor)
        header = blobs[cursor:end].split()
        require(len(header) == 3 and header[1] == b'blob', '舊owned C不是Git blob：' + path)
        size, begin = int(header[2]), end + 1
        body = blobs[begin:begin + size]
        require(len(body) == size and blobs[begin + size:begin + size + 1] == b'\n', '舊owned C batch blob不完整：' + path)
        require(digest(normalized(body)) == old_inputs[path], '舊owned C Git blob不符sealed receipt：' + path)
        _, _, tokens = scanner_module.lex(body.decode('utf-8-sig'), path, c=True)
        found = [{'path': path, 'line': token.line, 'layer': old_entries[path]['layer']}
                 for token in tokens
                 if token.kind == 'identifier' and token.value == RETIRED_IDENTIFIER]
        old_origins.extend(found)
        old_files.append({'path': path, 'layer': old_entries[path]['layer'], 'bytes': len(body),
                          'gitBlobOid': header[0].decode('ascii'), 'rawSha256': digest(body),
                          'lfSha256': digest(normalized(body)), 'retiredIdentifierOrigins': found})
        cursor = begin + size + 1
    require(cursor == len(blobs), '舊owned C batch多出非預期資料')
    old_identifiers = set(sealed['policy']['forbiddenIdentifiers'])
    old_strings = set(sealed['policy']['forbiddenStrings'])
    new_identifiers = set(current['policy']['forbiddenIdentifiers'])
    new_strings = set(current['policy']['forbiddenStrings'])
    w_origins = [row for row in current_origins if row['layer'] == 'W']
    removed = sorted(old_identifiers - new_identifiers)
    return {
        'schema': 'geometry-single-dead-api-guard-retirement/1', 'sourceBaseHead': source_sha,
        'identifier': RETIRED_IDENTIFIER, 'onlyAuthorizedRetiredIdentifier': RETIRED_IDENTIFIER,
        'authorizationBasis': '使用者已授權#316具名dead API退役；原804afbb4 combined patch明列同一manifest identifier移除。',
        'scanner': scanner_info, 'originalSuccessfulScanStdout': scan_record['stdoutInfo'],
        'graphKind': 'same-P original scanner owned-C literal-include edges; not a function call graph',
        'seedsMethod': '全部P manifest.sources language=c，包含C/header/inc與孤立來源；不是只從兩個consumer入口起步。',
        'seeds': seeds, 'closurePaths': sorted(closure), 'includeEdges': include_edges,
        'identifierRule': '同P原lex(c=True)的token.kind=identifier且token.value精確等具名API；comments/strings/文字absence assertion不算；沒有忽略任何owned C檔。',
        'currentOwnedCInputs': current_files, 'currentOwnedCOrigins': current_origins,
        'currentWOrigins': w_origins, 'zeroCurrentOwnedCIdentifierReferences': not current_origins,
        'zeroCurrentWIdentifierReferences': not w_origins,
        'previousSourceBaseHead': old_source,
        'previousOwnedCInputsReadFromGit': old_files,
        'previousOwnedCOrigins': old_origins,
        'previousWOrigins': [row for row in old_origins if row['layer'] == 'W'],
        'oldOriginsMethod': 'P原lexer讀previousSourceBaseHead全部sealed owned C Git blobs；逐blob LF hash實核old receipt；不是執行舊產品/tests。',
        'removedIdentifiers': removed,
        'removedStrings': sorted(old_strings - new_strings),
        'allOtherOldIdentifiersPreserved': old_identifiers - {RETIRED_IDENTIFIER} <= new_identifiers,
        'allOldStringsPreserved': old_strings <= new_strings,
        'retiredGuardAbsentFromCurrentManifest': RETIRED_IDENTIFIER not in new_identifiers,
        'passed': not current_origins and RETIRED_IDENTIFIER not in new_identifiers
                  and set(removed) <= {RETIRED_IDENTIFIER}
                  and old_identifiers - {RETIRED_IDENTIFIER} <= new_identifiers
                  and old_strings <= new_strings,
        'automaticManifestEdits': False,
        'notClaimed': ['產品native absence test已執行', 'dynamic call graph或runtime行為證明', '任意其他guard退役'],
    }


def compare_manifest(sealed, current, guard_inventory):
    result = {'addedSources': [], 'addedExclusions': [], 'updatedExclusions': [], 'forbiddenChanges': [], 'automaticEdits': False}
    for key in sorted(set(sealed) | set(current)):
        if key not in ('sources', 'exclusions', 'policy') and sealed.get(key) != current.get(key):
            result['forbiddenChanges'].append({'field': key, 'before': sealed.get(key), 'after': current.get(key)})
    if not guard_inventory['allOtherPolicyFieldsEqual']:
        result['forbiddenChanges'].append({'field': 'policy except guard collections', 'before': {k: v for k, v in sealed['policy'].items() if k not in ('forbiddenIdentifiers', 'forbiddenStrings')}, 'after': {k: v for k, v in current['policy'].items() if k not in ('forbiddenIdentifiers', 'forbiddenStrings')}})
    if not guard_inventory['manifestMatchesMechanicalUnion']:
        result['forbiddenChanges'].append({'field': 'policy guard collections', 'basis': 'P manifest必須恰等old集合union完整真W token集合，僅減已授權wood_contact_footprint_collides且當前W無該token；其他舊guard一律保留，不接受手選extra或漏項', 'mismatch': {k: guard_inventory[k] for k in ('missingIdentifiers', 'unexpectedIdentifiers', 'missingStrings', 'unexpectedStrings', 'removedIdentifiers', 'removedStrings')}})
    result['policyGuardInventory'] = guard_inventory
    old_paths = {row['path'] for key in ('sources', 'exclusions') for row in sealed[key]}
    for key in ('sources', 'exclusions'):
        old = {row['path']: row for row in sealed[key]}; new = {row['path']: row for row in current[key]}
        require(len(old) == len(sealed[key]) and len(new) == len(current[key]), 'manifest有重複entry')
        for path in sorted(set(old) - set(new)):
            result['forbiddenChanges'].append({'field': key, 'removed': old[path]})
        for path in sorted(set(new) - set(old)):
            if path in old_paths or (key == 'sources' and new[path].get('layer') == 'vendor'):
                result['forbiddenChanges'].append({'field': key, 'reclassificationOrNewVendor': new[path]})
            result['addedSources' if key == 'sources' else 'addedExclusions'].append(new[path])
        for path in sorted(set(old) & set(new)):
            if old[path] == new[path]:
                continue
            before = {k: v for k, v in old[path].items() if k != 'sha256'}
            after = {k: v for k, v in new[path].items() if k != 'sha256'}
            if key == 'exclusions' and before == after:
                result['updatedExclusions'].append({'path': path, 'before': old[path], 'after': new[path], 'basis': 'P已明列相同分類/reason的逐檔digest更新；原scanner仍實核新digest，driver未改值。'})
            else:
                result['forbiddenChanges'].append({'field': key, 'path': path, 'before': old[path], 'after': new[path]})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--sha', required=True, help='乾淨受驗來源的完整可解析 SHA；不以舊receipt來源代替')
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    require(not sys.flags.optimize, '拒絕 Python optimize；原裁判 assertions 必須生效')
    require(re.fullmatch('[0-9a-f]{40}', args.sha) is not None, '必須明列完整40碼來源 SHA')
    require(resource.getrlimit(resource.RLIMIT_STACK)[0] == 16384 * 1024, '由公開run.py保持soft stack16MiB／hard不降')
    require(repo.is_dir() and not out.exists(), '來源必須存在且輸出目錄必須不存在，拒絕覆蓋')
    require(not out.is_relative_to(repo), '輸出必須在來源 checkout 外')
    out.mkdir(parents=True)
    previous, new = out / 'previous', out / 'new'
    previous.mkdir(); new.mkdir()
    started = now()
    steps = []
    env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8',
               PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(out / 'tmp'))
    (out / 'tmp').mkdir()
    safe_env = {name: env.get(name) for name in ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'TMPDIR', 'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'GITHUB_SHA', 'GITHUB_WORKSPACE', 'GEO261_REAPER_LOG')}
    script_before = file_info(Path(__file__).resolve())
    command_number = 0
    bound_head = args.sha

    def command(label, argv, *, input_bytes=None):
        nonlocal command_number
        folder = out / 'commands' / f'{command_number:03d}-{label}'
        command_number += 1
        folder.mkdir(parents=True)
        if input_bytes is not None:
            (folder / 'stdin').write_bytes(input_bytes)
        record = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(repo), 'startedUtc': now(),
                  'sourceBaseHead': bound_head, 'environment': safe_env, 'stdout': str(folder / 'stdout'), 'stderr': str(folder / 'stderr')}
        record['stdinProvided'] = input_bytes is not None
        record['stdinSha256'] = digest(input_bytes or b'')
        write_json(folder / 'request.json', record)
        t0 = time.monotonic()
        interrupted = None
        with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
            process = subprocess.Popen(list(map(str, argv)), cwd=repo, env=env, stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=False)
            try:
                if input_bytes is not None:
                    process.communicate(input_bytes)
                else:
                    process.wait()
            except BaseException as error:
                interrupted = type(error).__name__
                try:
                    process.terminate()
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise
            finally:
                record.update(complete=interrupted is None, exitCode=process.returncode, interrupted=interrupted,
                              finishedUtc=now(), seconds=round(time.monotonic() - t0, 6))
                record['stdoutInfo'] = file_info(folder / 'stdout')
                record['stderrInfo'] = file_info(folder / 'stderr')
                write_json(folder / 'run.json', record)
                steps.append(record)
                write_json(out / 'commands.json', steps)
        return record, (folder / 'stdout').read_bytes(), (folder / 'stderr').read_bytes()

    def git(label, *parts, input_bytes=None):
        record, stdout, stderr = command(label, ['git', *parts], input_bytes=input_bytes)
        require(record['exitCode'] == 0, 'Git 讀取失敗：' + label + '；詳原始輸出')
        return stdout

    try:
        head = git('head-before', 'rev-parse', '--verify', 'HEAD^{commit}').decode().strip()
        require(re.fullmatch('[0-9a-f]{40}', head) is not None, '需要可解析完整來源 SHA')
        require(head == args.sha, '來源 HEAD 與指定固定 SHA 不同')
        bound_head = head
        require(git('status-before', 'status', '--porcelain=v1', '--untracked-files=all') == b'', '來源 checkout 必須乾淨')
        architecture = repo / ARTIFACT_DIR
        previous_hashes = {}
        for name in ARTIFACTS:
            raw = (architecture / name).read_bytes()
            (previous / name).write_bytes(raw)
            previous_hashes[name] = file_info(previous / name)
        manifest_raw = (architecture / ARTIFACTS[0]).read_bytes()
        manifest = json.loads(manifest_raw)
        old_receipt = json.loads((previous / 'product-architecture-receipt.json').read_text(encoding='utf-8'))
        require(old_receipt['schema'] == 'geometry-product-architecture-receipt/1', '未知舊 receipt schema')
        require(set(manifest['sourceRoots']) == set(ROOTS) and set(manifest['sourceFiles']) == set(STANDALONE), '完整五roots／三standalone必須保留；不能改成變更subset')
        previous_commit = git('previous-receipt-commit', 'log', '-1', '--format=%H', '--', ARTIFACT_DIR + '/product-architecture-receipt.json').decode().strip()
        git('previous-source-ancestor', 'merge-base', '--is-ancestor', old_receipt['sourceBaseHead'], head)
        git('previous-receipt-ancestor', 'merge-base', '--is-ancestor', previous_commit, head)
        previous_from_git = out / 'previous-from-git'
        previous_from_git.mkdir()
        previous_git_hashes = {}
        for name in ARTIFACTS:
            frozen = git('previous-output-' + name.replace('.', '-'), 'show', previous_commit + ':' + ARTIFACT_DIR + '/' + name)
            (previous_from_git / name).write_bytes(frozen)
            previous_git_hashes[name] = file_info(previous_from_git / name)
            if name != 'product-architecture.json':
                require(normalized(frozen) == normalized((previous / name).read_bytes()), '舊scan/report/receipt與上一份產物 Git blob 不同：' + name)

        sealed_manifest = json.loads((previous_from_git / 'product-architecture.json').read_bytes())
        require(digest(normalized((previous_from_git / 'product-architecture.json').read_bytes())) == old_receipt['manifestSha256'], '上一份Git manifest不符原receipt digest')
        require(previous_git_hashes['product-architecture-scan.json']['lfSha256'] == old_receipt['scanSha256'] and previous_git_hashes['PRODUCT-ARCHITECTURE.md']['lfSha256'] == old_receipt['reportSha256'], '上一份scan/report不符原receipt digest')
        (new / 'product-architecture.json').write_bytes(manifest_raw)

        def inventory():
            paths = set(STANDALONE)
            for relative in STANDALONE:
                require((repo / relative).is_file() and not (repo / relative).is_symlink(), 'standalone來源不存在或為symlink：' + relative)
            def walk_error(error):
                raise error
            for relative in ROOTS:
                directory = repo / relative
                require(directory.is_dir() and not directory.is_symlink(), '來源 root 不存在或是別名：' + relative)
                for parent, directories, files in os.walk(directory, followlinks=False, onerror=walk_error):
                    for name in directories:
                        require(not (Path(parent) / name).is_symlink(), '拒絕來源目錄 symlink：' + str(Path(parent) / name))
                    for name in files:
                        path = Path(parent) / name
                        if path.suffix.lower() in SUFFIXES:
                            require(path.is_file() and not path.is_symlink(), '拒絕來源檔別名或不可讀檔：' + str(path))
                            paths.add(path.relative_to(repo).as_posix())
            require(len({p.casefold() for p in paths}) == len(paths), '來源路徑有大小寫衝突')
            return sorted(paths)

        def snapshot():
            records = []
            for relative in inventory():
                raw = (repo / relative).read_bytes()
                records.append({'path': relative, 'rawSha256': digest(raw), 'sha256': digest(normalized(raw)), 'bytes': len(raw)})
            return records

        before = snapshot()
        before_paths = [row['path'] for row in before]
        declared = sorted(row['path'] for row in manifest['sources'] + manifest['exclusions'])
        registration = {'sourceBaseHead': head, 'unregistered': sorted(set(before_paths) - set(declared)), 'missing': sorted(set(declared) - set(before_paths)), 'duplicateDeclaredPaths': len(declared) != len(set(declared)), 'filesystemCount': len(before_paths), 'declaredCount': len(declared), 'automaticRegistrationPerformed': False}
        write_json(out / 'manifest-registration.json', registration)
        require(before_paths == declared and not registration['duplicateDeclaredPaths'], '完整inventory登錄有缺口；詳manifest-registration.json，不猜分類或默加排除')
        tracked_raw = git('tracked-inputs', 'ls-tree', '-r', '-z', '--name-only', head, '--', *ROOTS, *STANDALONE)
        tracked_inputs = sorted(p for p in tracked_raw.decode().split('\0') if p and Path(p).suffix.lower() in SUFFIXES)
        require(before_paths == tracked_inputs, '獨立 inventory 與固定 Git tree 不相等')
        refs = b''.join((head + ':' + p + '\n').encode() for p in before_paths)
        blobs = git('frozen-input-blobs', 'cat-file', '--batch', input_bytes=refs)
        cursor = 0
        for row in before:
            end = blobs.index(b'\n', cursor)
            header = blobs[cursor:end].split()
            require(len(header) == 3 and header[1] == b'blob', '固定輸入不是 blob：' + row['path'])
            size = int(header[2]); begin = end + 1
            body = blobs[begin:begin + size]
            require(len(body) == size and blobs[begin + size:begin + size + 1] == b'\n', 'Git batch blob 格式不完整')
            require(digest(normalized(body)) == row['sha256'], '工作檔與固定 Git blob 不同：' + row['path'])
            row['gitBlobOid'] = header[0].decode()
            cursor = begin + size + 1
        require(cursor == len(blobs), 'Git batch 多出未預期資料')
        baseline_snapshot = [{k: v for k, v in row.items() if k != 'gitBlobOid'} for row in before]
        inputs = [{'path': row['path'], 'sha256': row['sha256']} for row in before]
        raw_inputs = [{'path': row['path'], 'sha256': row['rawSha256']} for row in before]
        closure = digest(json.dumps(inputs, ensure_ascii=False, separators=(',', ':')).encode())
        raw_closure = digest(json.dumps(raw_inputs, ensure_ascii=False, separators=(',', ':')).encode())
        write_json(out / 'source-inputs.json', before)
        tool_hashes = {p: file_info(repo / p) for p in TOOLS}
        for relative in TOOLS:
            frozen_tool = git('frozen-judge-' + Path(relative).stem, 'show', head + ':' + relative)
            require(digest(normalized(frozen_tool)) == tool_hashes[relative]['lfSha256'], '原裁判不是指定SHA bytes：' + relative)
        # 現在完整source inputs與原scanner已綁真正P；沿原真lexer盤點全部W-native。
        w_guard_inventory = collect_w_guard_inventory(repo, sealed_manifest, manifest, head, tool_hashes[TOOLS[0]])
        write_json(out / 'policy-guard-inventory.json', w_guard_inventory)
        manifest_delta = compare_manifest(sealed_manifest, manifest, w_guard_inventory)
        write_json(out / 'manifest-delta.json', manifest_delta)
        require(not manifest_delta['forbiddenChanges'], 'manifest非完整W機械guard增量／exact登錄，或改roots/其他policy/責任/trust；精確差異已保留，不改P manifest或等待人工批准')
        protected = {relative: file_info(repo / relative) for relative in SSOT}
        protected_dir = out / 'protected-source-bytes'; protected_dir.mkdir()
        for relative in SSOT:
            frozen_ssot = git('frozen-ssot-' + str(SSOT.index(relative)), 'show', head + ':' + relative)
            require(digest(normalized(frozen_ssot)) == protected[relative]['lfSha256'], 'SSOT不是指定SHA bytes：' + relative)
            (protected_dir / relative).write_bytes((repo / relative).read_bytes())
        write_json(out / 'protected-ssot.json', {'sourceBaseHead': head, 'before': protected, 'separateFromExecutableClosure': True})
        old_inputs = {row['path']: row['sha256'] for row in old_receipt['inputs']}
        require(len(old_inputs) == len(old_receipt['inputs']), '舊receipt inputs重複')
        require(set(old_inputs) == {row['path'] for row in sealed_manifest['sources'] + sealed_manifest['exclusions']}, '舊receipt inputs與其sealed manifest集合不同')
        require(not (set(old_inputs) - set(before_paths)), '不自動縮減來源普查集合')
        changed = [{'path': row['path'], 'previousSha256': old_inputs[row['path']], 'sha256': row['sha256']}
                   for row in inputs if row['path'] in old_inputs and row['sha256'] != old_inputs[row['path']]]
        new_inputs = [row for row in before if row['path'] not in old_inputs]
        allowed = {row['path'] for row in changed}
        def unchanged(label):
            require(snapshot() == baseline_snapshot, '來源於執行期間變動：' + label)
            require(all(file_info(repo / p) == info for p, info in tool_hashes.items()), '裁判工具於執行期間變動：' + label)
            require((architecture / 'product-architecture.json').read_bytes() == manifest_raw, 'manifest 於執行期間變動')
            require(all(file_info(repo / relative) == info for relative, info in protected.items()), 'SSOT於執行期間變動')
            observed = git('head-check-' + label, 'rev-parse', 'HEAD').decode().strip()
            require(observed == head, 'HEAD 於執行期間變動：' + label)
            require(git('status-check-' + label, 'status', '--porcelain=v1', '--untracked-files=all') == b'', '工作樹於執行期間變動：' + label)

        versions = []
        for label, argv in [('python', [sys.executable, '--version']), ('git', ['git', '--version'])]:
            record, stdout, stderr = command('version-' + label, argv)
            require(record['exitCode'] == 0, '版本查詢失敗')
            versions.append(record)
        # 政策完全不變：三條原命令只各跑一次；先收齊所有真退出與 raw 再判定紅綠。
        scan_record, scan_raw, scan_error = command('final-scan', [sys.executable, '-B', 'tests/architecture_contract.py', '--root', '.', '--manifest', ARTIFACT_DIR + '/product-architecture.json'])
        scan_record['sourceBaseHead'] = head
        unchanged('scan')
        validation_runs = []
        for label, relative in [('generic-tests', TOOLS[1]), ('product-tests', TOOLS[2])]:
            record, stdout, stderr = command(label, [sys.executable, '-B', relative])
            record['sourceBaseHead'] = head
            validation_runs.append((label, relative, record, stdout, stderr))
            unchanged(label)
        require(scan_record['exitCode'] == 0, '原 scanner CLI 非零退出；三條真輸出已保存，不產生通過收據')
        scan = json.loads(scan_raw)
        require(scan.get('ok') is True and scan.get('diagnostics') == [], '原 scanner 有 diagnostics')
        require(set(scan['sources']) == {row['path'] for row in manifest['sources']}, 'scanner owned sources 與宣告不同')
        (new / 'product-architecture-scan.json').write_bytes(scan_raw)

        retirement = collect_retired_api_inventory(repo, sealed_manifest, manifest, head,
            tool_hashes[TOOLS[0]], scan, scan_record, old_receipt, old_inputs, git)
        write_json(out / 'retired-api-inventory.json', retirement)
        manifest_delta['deadApiGuardRetirement'] = retirement
        write_json(out / 'manifest-delta.json', manifest_delta)
        require(retirement['passed'], '具名dead API退役未成立；全owned C原identifier普查／舊origins／原raw均已保留，不產通過收據')

        validations = []
        for label, relative, record, stdout, stderr in validation_runs:
            require(record['exitCode'] == 0, '原架構測試非零退出；三條真輸出已保存：' + label)
            text = (stdout + b'\n' + stderr).decode('utf-8', 'replace')
            counts = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s\s*$', text, re.M)
            require(len(counts) == 1 and int(counts[0][0]) > 0, '測試數缺少、為零或不唯一：' + label)
            ending = text.rstrip().splitlines()[-1]
            outcome = re.fullmatch(r'OK(?: \(skipped=(\d+)\))?', ending)
            require(outcome is not None, '原測試摘要不是乾淨 OK：' + label)
            skipped = int(outcome[1] or 0)
            total = int(counts[0][0])
            require(skipped <= total, 'skip 數不合法')
            record.update(command='python -B ' + relative, tests=total, passed=total - skipped, failed=0, skipped=skipped, unittestSeconds=float(counts[0][1]))
            validations.append(record)

        counts = {'executableFiles': len(inputs), 'ownedSources': len(manifest['sources']), 'exclusions': len(manifest['exclusions']),
                  'edges': len(scan['edges']), 'diagnostics': len(scan['diagnostics']),
                  'layers': dict(sorted(collections.Counter(row['layer'] for row in manifest['sources']).items())),
                  'languages': dict(sorted(collections.Counter(row['language'] for row in manifest['sources']).items())),
                  'forbiddenIdentifiers': len(manifest['policy']['forbiddenIdentifiers']),
                  'forbiddenStrings': len(manifest['policy']['forbiddenStrings'])}
        old_report = normalized((previous / 'PRODUCT-ARCHITECTURE.md').read_bytes()).decode('utf-8')
        report = '# Product architecture — Linux 固定來源重產\n\n'
        report += f'本輪真受驗來源 `{head}`；上一份receipt產物提交 `{previous_commit}`。本輪只使用指定來源的原scanner、generic與product裁判。\n\n'
        report += f'完整五roots加三standalone：{counts["executableFiles"]} executable inputs，owned {counts["ownedSources"]}、excluded {counts["exclusions"]}、edges {counts["edges"]}、diagnostics {counts["diagnostics"]}。LF closure `{closure}`。\n\n'
        report += 'manifest輸出逐bytes等指定P已登記版本；driver未自動修改任何來源／manifest。guard增量由全部真W-native原lexer集合與舊集合的union實證，其餘政策、roots、routes、vendor trust及既有責任保留。\n\n'
        report += f'完整W native詞彙盤點：{len(w_guard_inventory["wCInputs"])}檔；新增{len(w_guard_inventory["addedIdentifiers"])} identifiers／{len(w_guard_inventory["addedStrings"])} strings，全部path/line見policy-guard-inventory.json。僅wood_contact_footprint_collides具名退役；其餘舊guard保留，不是手選新增清單或新數值門檻。\n\n'
        report += f'具名dead API `{RETIRED_IDENTIFIER}`：全owned C seeds／include closure {len(retirement["closurePaths"])}檔，原lexer精確identifier引用0；舊owned C origins {len(retirement["previousOwnedCOrigins"])}筆（其中W {len(retirement["previousWOrigins"])}筆），原Git blobs及path/line見retired-api-inventory.json與完整commands。這是include/identifier普查，不是callgraph，未代稱native產品test已執行。\n\n'
        report += f'相對上份sealed manifest：新增owned {len(manifest_delta["addedSources"])}、新增逐檔exclusion {len(manifest_delta["addedExclusions"])}、既有exclusion digest更新 {len(manifest_delta["updatedExclusions"])}。逐項原/新內容見本輪manifest-delta.json；未登錄檔不會被自動排除。\n\n'
        report += '變更既有input：' + ('、'.join('`'+row['path']+'`' for row in changed) if changed else '無') + '。\n\n'
        for row in validations:
            report += f'- `{row["command"]}`：真退出{row["exitCode"]}，{row["tests"]} tests／{row["passed"]} passed／{row["failed"]} failed／{row["skipped"]} skipped；原argv/cwd/env/stdout/stderr另完整保存。\n'
        report += '\n四檔衍生產物不進executable closure，receipt不hash自己。SSOT另按指定P綁定並核前後不變；不冒稱closure自然涵蓋SSOT。未跑native、ledger、browser、專項或歷史額外policy probes；不把先前Windows或#288結果重標成本輪結果。\n\n## 上一份歷史報告（原文保留，非本輪判決）\n\n' + old_report
        (new / 'PRODUCT-ARCHITECTURE.md').write_text(report, encoding='utf-8')
        unchanged('before-seal')
        require(file_info(Path(__file__).resolve()) == script_before, '封裝器於執行期間變動')

        def schema_record(record):
            converted = dict(record)
            converted['stdout'] = dict(record['stdoutInfo'])
            converted['stderr'] = dict(record['stderrInfo'])
            converted['stdoutRawPath'] = record['stdout']
            converted['stderrRawPath'] = record['stderr']
            converted.pop('stdoutInfo', None)
            converted.pop('stderrInfo', None)
            return converted

        scan_record['command'] = 'python -B tests/architecture_contract.py --root . --manifest ' + ARTIFACT_DIR + '/product-architecture.json'
        old_tool_hashes = old_receipt.get('completeInventoryVerification', {}).get('toolHashesAfter', {})
        receipt = {
            'schema': 'geometry-product-architecture-receipt/1',
            'headBinding': '來源 closure 排除四份衍生稽核產物；後續僅稽核產物提交不會遞迴改變受驗產品來源。所有本輪命令的 sourceBaseHead 均為實際固定來源。',
            'hashMode': 'sha256 after CRLF-to-LF normalization', 'inputClosureHashSerialization': SERIALIZATION,
            'inputClosureExcludes': [ARTIFACT_DIR + '/' + name for name in ARTIFACTS],
            'inputClosureExclusionReason': '四份非執行性衍生稽核產物不屬產品來源；manifest、scan、report 分別雜湊，receipt 不雜湊自己。',
            'notClaimed': ['native 編譯或執行', 'runtime import blocker', '完整 JavaScript dataflow 證明', 'vendor internals', 'mutation ledger 執行或新鮮度', '瀏覽器與所有專項驗收', '未來變更的來源'],
            'createdUtc': now(), 'basis': '乾淨固定 Git HEAD 與獨立完整 inventory，原三條架構裁判在同一來源實際執行。',
            'sourceBaseHead': head, 'headObservedBefore': head, 'headObservedAfter': head,
            'manifestSha256': digest(normalized((new / 'product-architecture.json').read_bytes())),
            'scannerSha256': tool_hashes[TOOLS[0]]['lfSha256'], 'scanSha256': digest(normalized(scan_raw)),
            'reportSha256': digest(normalized((new / 'PRODUCT-ARCHITECTURE.md').read_bytes())),
            'inputClosureSha256': closure, 'counts': counts,
            'manifestRefresh': {'previousManifestSha256': previous_git_hashes['product-architecture.json']['lfSha256'],
                'previousReceiptSha256': previous_hashes['product-architecture-receipt.json']['lfSha256'],
                'previousScanSha256': previous_hashes['product-architecture-scan.json']['lfSha256'],
                'previousReportSha256': previous_hashes['PRODUCT-ARCHITECTURE.md']['lfSha256'],
                'previousReceiptCreatedUtc': old_receipt.get('createdUtc'), 'previousSourceBaseHead': old_receipt['sourceBaseHead'],
                'previousReceiptCommit': previous_commit, 'firstObservedHead': head,
                'previousOutputsPreserved': {'directory': str(previous), 'hashes': previous_hashes},
                'lastSealedOutputsReadFromGit': {'commit': previous_commit, 'directory': str(previous_from_git), 'hashes': previous_git_hashes,
                    'note': '舊四檔逐一從上一份receipt產物commit讀回Git blobs；scan/report/receipt與P現檔比LF hash，P manifest如已合法登錄新項則另記exact delta而不假稱等舊manifest。兩份raw分開保全，不改寫舊驗收。'},
                'headManifestSha256Before': digest(normalized(manifest_raw)),
                'addedSources': manifest_delta['addedSources'], 'addedExclusions': manifest_delta['addedExclusions'], 'updatedExclusions': manifest_delta['updatedExclusions'], 'newInputs': new_inputs,
                'changedPreviouslySealedInputs': changed, 'allowedChangedInputs': sorted(allowed),
                'staleExcludedVendorOrEmbedDigestsBefore': [], 'staleExcludedVendorOrEmbedDigestsAfter': [],
                'digestEvidence': '沿原 manifest 執行 scanner exit0；不更新 vendor、excluded 或 iframe driver/router digest 來掩蓋失效。',
                'classificationNote': '不自動改manifest；P已登記新owned/exclusion digest逐項記錄；guard只接受完整W真lexer集合與全部舊集合的機械union，僅wood_contact_footprint_collides由全owned C零identifier證據具名退役；其餘guard不得移除。禁止移除來源、改既有責任、其他policy/roots/routes/vendor trust。', 'manifestDelta': manifest_delta, 'policyGuardInventory': w_guard_inventory, 'deadApiGuardRetirement': retirement, 'changedInputScope': '由固定P與上一份真sealed inputs計算完整差異，非舊P73單檔allowlist。',
                'toolChanges': [{'path': p, 'previous': old_tool_hashes.get(p), 'current': tool_hashes[p]['lfSha256']} for p in TOOLS if old_tool_hashes.get(p) != tool_hashes[p]['lfSha256']]},
            'scanPassed': True, 'actualCliScan': schema_record(scan_record), 'validation': [schema_record(row) for row in validations],
            'supplementalStaticGuardProbes': {'executedAtCurrentHead': False, 'reason': '未執行舊 Windows driver 的額外 in-memory probes；原 generic／product suites 已實際執行並各自記錄，不套用舊來源的探針綠燈。'},
            'nativeAcceptance': '此封裝器沒有執行 native、mutation ledger、瀏覽器或專項；它們必須有另一份實際同最終受驗來源的收據。',
            'inputs': inputs,
            'completeInventoryVerification': {'method': '獨立 os.walk 五 roots 加三個 standalone，與 manifest 登記集合及固定 Git tree 比較；逐 Git blob 比 LF hash；每個原裁判後重算完整 raw/LF inputs、工具 bytes、HEAD 與乾淨狀態。',
                'sourceRoots': list(ROOTS), 'sourceFiles': list(STANDALONE), 'executableSuffixes': sorted(SUFFIXES),
                'filesBefore': len(inputs), 'filesAfter': len(inputs), 'unregisteredBeforeRefresh': [], 'unregisteredAfter': [], 'missingAfter': [], 'changedInputs': [],
                'inputClosureSha256Before': closure, 'inputClosureSha256After': closure,
                'rawInputClosureSha256Before': raw_closure, 'rawInputClosureSha256After': raw_closure,
                'rawHashBasis': '實際 Linux checkout bytes；可攜產品身分以 CRLF-to-LF 與固定 Git blobs 比較。',
                'toolHashesBefore': {p: x['lfSha256'] for p, x in tool_hashes.items()}, 'toolHashesAfter': {p: x['lfSha256'] for p, x in tool_hashes.items()},
                'rawToolHashesBefore': {p: x['rawSha256'] for p, x in tool_hashes.items()}, 'rawToolHashesAfter': {p: x['rawSha256'] for p, x in tool_hashes.items()},
                'allRawAndLfInputsUnchanged': True, 'headObservedAfterIndependentAudit': head, 'checkedUtc': now(), 'protectedSsotBefore': protected, 'protectedSsotAfter': {p: file_info(repo / p) for p in SSOT}},
            'refreshDriver': {**script_before, 'runDirectory': str(out), 'argv': [sys.executable, *sys.argv],
                'note': '由#314動態完整inventory/schema工具複製；沿既有W原lex方法實證機械union，僅具名dead API由全owned C零引用退役，不改P manifest。公開run.py持指定heavy lock/soft16MiB與原subreaper，先收齊原三裁判raw；非Windows driver。'},
            'environment': {'system': platform.system(), 'release': platform.release(), 'machine': platform.machine(),
                'python': sys.version, 'safeVariables': safe_env, 'versions': versions},
            'uncertainties': ['未重現舊 Windows driver 的額外 probes；原三條裁判結果與本封裝器有限完整 inventory 是本輪主張範圍。',
                '本工具只輸出 out/new 四檔，不修改 repo；尚未提交的產物不能稱作已發布。',
                '後續最終候選 SHA 仍須執行使用者要求的完整動態清單。'],
        }
        write_json(new / 'product-architecture-receipt.json', receipt)
        hashes = {name: file_info(new / name) for name in ARTIFACTS}
        summary = {'schema': 'geo299316-linux-architecture-refresh/1', 'source_sha': head, 'startedUtc': started, 'finishedUtc': now(),
                   'passed': True, 'scan_exit_code': scan_record['exitCode'], 'validation_exit_codes': [r['exitCode'] for r in validations],
                   'counts': counts, 'changedPreviouslySealedInputs': changed, 'inputClosureSha256': closure,
                   'allRawAndLfInputsUnchanged': True, 'manifest_byte_unchanged': (new / 'product-architecture.json').read_bytes() == manifest_raw,
                   'previous_outputs': previous_hashes, 'outputs': hashes, 'checkout_modified': False,
                   'note': '僅四檔重產與原架構三裁判的有限收據；不表示其他最終驗收完成。'}
        write_json(out / 'RESULT.json', summary)
        print(json.dumps(summary, ensure_ascii=False), flush=True)
        return 0
    except BaseException as error:
        write_json(out / 'FAILED.json', {'startedUtc': started, 'finishedUtc': now(), 'passed': False,
            'error_type': type(error).__name__, 'error': str(error), 'commands': steps,
            'note': '不得把部分產物或已完成的子命令當成架構重產完成；詳完整 stdout/stderr。'})
        traceback.print_exc()
        return 130 if isinstance(error, KeyboardInterrupt) else 1


if __name__ == '__main__':
    sys.exit(main())
