"""CR acceptance against actual native candidates; coordinates are independent constants.

CR24 is the UI slice and is not registered as a fake native pass or skip here.
CR18 tests the currently supported no-ledger context; marked identity-ledger/1
acceptance remains with its implementation owner (no native ledger is advertised).
"""
from copy import deepcopy
import base64
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'geometry-core'))
from tests import test_engineering_core as eng_harness
from tests.test_parameters_core import card, field
from tests.test_grid_system_contract import rejection_reason
from modeling import build_package, verify_package, ModelError


def source(parameter=10, u=3, v=8):
    return {'parameterId': parameter, 'uFieldId': u, 'vFieldId': v}


def grid(identifier=4, ref=True, u='repeat -5 card', v='repeat 7 card'):
    value = {'id': identifier, 'name': 'G', 'mainAlong': 'none', 'u': u, 'v': v}
    if ref:
        value['cardReference'] = source() if ref is True else ref
    return {'op': 'put-grid-system', 'value': value}


def parameter(a='12', b='30', identifier=10, extras=(), order=False, name='P'):
    fields = [field(3, a, name='a'), field(8, b, name='b')]
    return card(identifier, name, (fields[::-1] if order else fields) + list(extras))


def swap(identifier=4):
    return {'op': 'swap-grid-card-reference', 'id': identifier}


def unbind(mode='direct', identifier=4):
    return {'op': 'unbind-grid-card-reference', 'id': identifier, 'mode': mode}


class GridCardReference(unittest.TestCase):
    setUpClass = classmethod(eng_harness.EngineeringCore.setUpClass.__func__)
    setUp = eng_harness.EngineeringCore.setUp
    command = eng_harness.EngineeringCore.command
    read = eng_harness.EngineeringCore.read
    request = eng_harness.EngineeringCore.request
    apply = eng_harness.EngineeringCore.apply
    apply_line = eng_harness.EngineeringCore.apply_line

    def seed(self, **kwargs):
        self.apply([parameter(**kwargs), grid()])

    def dump(self):
        return self.command('dump')['text']

    def systems(self):
        return {s['id']: s for s in self.command('objects')['gridSystems']}

    def state(self):
        return self.dump(), self.read(), self.command('objects')

    def reject(self, ops, reason, label, identity=None):
        before = self.state()
        result = self.request(ops)
        self.assertTrue(result['ok'], (label, result))
        self.assertFalse(result['preview']['valid'], (label, result))
        errors = [v.get('message', '') for v in result['preview']['violations']]
        matching = [message for message in errors if reason in message]
        self.assertTrue(matching, (label, reason, errors))
        if identity is not None:
            grid_id, parameter_id, field_id = identity
            parts = (f'grid-system {grid_id}', f'parameter {parameter_id}', f'field {field_id}')
            self.assertTrue(any(all(re.search(r'\b' + re.escape(part) + r'\b', message)
                                    for part in parts) for message in matching), (label, errors))
        self.assertFalse(self.command(f"engineering-confirm {result['preview']['token']}")['ok'], label)
        self.assertEqual(before, self.state(), label + ': World/metadata/revision unchanged')
        return result

    def lines(self, axis):
        result = self.command('grid-query system 4 rect -100 -100 100 100 mode exact limit 64')
        self.assertTrue(result['ok'], result)
        values = {int(row['index']): row['coordinate'] for row in result['axes'][axis]['lines']}
        return [values[k] for k in (-1, 0, 1)]

    def lengths(self):
        s = self.systems()[4]
        return tuple(next(s[a + 'Definition'][key] for key in ('effectiveStep', 'effectivePanel', 'step', 'panel')
                          if key in s[a + 'Definition']) for a in ('u', 'v'))

    def assert_source(self, expected=source(), label='CARD_UNIT'):
        s = self.systems()[4]
        self.assertEqual(expected, s.get('cardReference'), label)
        for axis in ('u', 'v'):
            d = s[axis + 'Definition']; slot = 'step' if d['source'] == 'repeat' else 'panel'
            self.assertEqual('card', d.get(slot + 'Source'), label)
            self.assertNotIn(slot, d.get('parameterRefs', {}), label)
            self.assertNotIn(slot, d, label + ': no independent direct value in the definition')
        definition = next(l for l in self.dump().splitlines() if l.startswith('grid-system 4 '))
        self.assertIn(f"card-reference {expected['parameterId']} {expected['uFieldId']} {expected['vFieldId']}", definition, label)
        self.assertEqual(2, definition.split().count('card'), label)

    def test_CR01_CARD_UNIT(self):
        self.seed(); self.assert_source()
        self.assertEqual([-17, -5, 7], self.lines('u'), 'CARD_UNIT')
        self.assertEqual([-23, 7, 37], self.lines('v'), 'CARD_UNIT')
        uses = [u for u in self.command('objects')['parameterUses'] if u['kind'] == 'grid-card-reference']
        self.assertEqual(1, len(uses), 'CARD_UNIT usage is one relationship')
        self.assertEqual([3, 8], [p['fieldId'] for p in uses[0]['paths']])

    def test_CR02_MIXED_MODE(self):
        self.seed(extras=[field(9, '3')])
        self.apply([grid(u='repeat-panel card gap param:10:9 from -5')])
        self.assertEqual([-7, 8, 23], self.lines('u'), 'MIXED_MODE')
        self.assertEqual([-23, 7, 37], self.lines('v'))
        self.assert_source()

    def test_CR03_SWAP_MAPPING_ONLY(self):
        self.seed(); self.apply([grid(u='repeat-panel card gap 3 from -5'), swap()])
        self.assertEqual([-7, 26, 59], self.lines('u'), 'SWAP_MAPPING_ONLY')
        self.assertEqual([-5, 7, 19], self.lines('v'))
        self.assert_source(source(u=8, v=3))
        self.assertEqual((3, -5), tuple(self.systems()[4]['uDefinition'][x] for x in ('gap', 'anchor')))

    def test_CR04_EQUAL_VALUE_IDENTITY(self):
        self.seed(b='12')
        graph = lambda: self.command('source-inspect')
        node = lambda g: next(n for n in g['nodes'] if n['key'] == 'grid-system:4')
        old_graph = graph(); old_node = node(old_graph)
        self.assertTrue(old_graph['complete'], 'EQUAL_VALUE_IDENTITY complete native source index')
        edges = {(e['to'], e['field']) for e in old_graph['edges'] if e['from'] == 'grid-system:4'}
        self.assertTrue({('parameter:10', 'card-reference'), ('parameter-field:10:f3', 'u.step'), ('parameter-field:10:f8', 'v.step')} <= edges, 'EQUAL_VALUE_IDENTITY source unit and paths')
        before = self.dump(); preview, _ = self.apply([swap()])
        self.assertNotEqual(before, self.dump(), 'EQUAL_VALUE_IDENTITY')
        self.assertEqual(source(u=8, v=3), preview['preview']['after']['geometry']['gridSystems'][0]['cardReference'])
        swapped = node(graph())
        self.assertNotEqual(old_node['definitionFingerprint'], swapped['definitionFingerprint'], 'EQUAL_VALUE_IDENTITY mapping is a definition')
        self.assertEqual(old_node['valueFingerprint'], swapped['valueFingerprint'])
        self.apply([parameter(a='18', b='12')]); self.assertEqual((12, 18), self.lengths())
        changed = node(graph())
        self.assertEqual(swapped['definitionFingerprint'], changed['definitionFingerprint'], 'EQUAL_VALUE_IDENTITY values are not definitions')
        self.assertNotEqual(swapped['valueFingerprint'], changed['valueFingerprint'])

    def test_CR05_STABLE_FIELD_IDS(self):
        self.seed(); p = self.request([swap()])['preview']
        self.apply_line('canvas-pos parameter 10 3 4')
        self.assertTrue(self.command(f"engineering-confirm {p['token']}")['ok'])
        p = self.request([swap()])['preview']
        self.apply([parameter(order=True, name='renamed')])
        self.assertFalse(self.command(f"engineering-confirm {p['token']}")['ok'], 'STABLE_FIELD_IDS stale rename')
        self.assert_source(source(u=8, v=3)); self.assertEqual((30, 12), self.lengths())

    def test_CR06_EXTRA_FIELD_DEPENDENCY(self):
        self.seed(); self.apply([parameter(extras=[field(9, '7')])]); self.assert_source()
        self.apply([parameter()]); self.assert_source()
        self.apply([parameter(extras=[field(11, '7')], a='=@10:11')])
        self.reject([parameter(a='=@10:11')], 'MISSING', 'EXTRA_FIELD_DEPENDENCY')

    def test_CR07_CARD_SHAPE_DISTINCT_FIELDS_SAME_CARD(self):
        self.apply([card(10, 'P', [field(3, '12')])])
        self.reject([grid()], 'field 8', 'CARD_SHAPE')
        self.apply([parameter()])
        self.reject([grid(ref=source(u=3, v=3))], 'DISTINCT_FIELDS', 'DISTINCT_FIELDS')
        bad = source(); bad['vParameterId'] = 11
        rejected = self.reject([grid(ref=bad)], 'SAME_CARD', 'SAME_CARD', identity=(4, 10, 8))
        self.assertNotIn('COMPLETE_MAPPING', rejected['preview']['violations'][0]['message'])
        bad['vParameterId'] = 10
        self.reject([grid(ref=bad)], 'SAME_CARD', 'SAME_CARD rejects per-axis card id even when equal', identity=(4, 10, 8))

    def test_CR08_MAPPED_SOURCE_PROTECTION(self):
        self.seed()
        self.reject([card(10, 'P', [field(3, '12')])], 'grid-system 4', 'MAPPED_SOURCE_PROTECTION', identity=(4, 10, 8))
        for kind in ('count', 'ratio'):
            self.reject([card(10, 'P', [field(3, '12'), field(8, '30', kind)])], 'not a dimension', 'MAPPED_SOURCE_PROTECTION', identity=(4, 10, 8))
        self.reject([{'op': 'delete-parameter', 'id': 10}, parameter(identifier=11)], 'grid-system 4', 'MAPPED_SOURCE_PROTECTION', identity=(4, 10, 3))

    def test_CR09_EXACT_TARGET_LENGTH(self):
        self.seed()
        for b, why in [('0', 'POSITIVE'), ('-1', 'POSITIVE'), ('1/2', 'integer mm'), ('100000001', 'D1 range')]:
            self.reject([parameter(b=b)], why, 'EXACT_TARGET_LENGTH ' + b)
        for b in ('1', '100000000'):
            self.apply([parameter(b=b)]); self.assertEqual(int(b), self.lengths()[1])

    def test_CR10_FIELD_GRAPH_AND_PRECISION(self):
        self.seed(); self.apply([parameter(b='=3 mm/2*2')]); self.assertEqual((12, 3), self.lengths())
        exact = parameter(); b = exact['value']['fields'][1]; del b['input']
        b['expression'] = {'op': 'mul', 'left': {'op': 'literal', 'num': '3', 'den': '2', 'unit': 'mm'},
                           'right': {'op': 'literal', 'num': '2', 'den': '1', 'unit': '1'}}
        self.apply([exact]); self.assertEqual((12, 3), self.lengths(), 'FIELD_GRAPH_AND_PRECISION exact fractional AST')
        self.reject([parameter(b='=3/2*2')], 'UNIT', 'FIELD_GRAPH_AND_PRECISION unit')
        self.reject([parameter(b='=9223372036854775807 mm*2')], 'PRECISION', 'FIELD_GRAPH_AND_PRECISION precision')
        self.reject([parameter(b='=1 mm/9223372036854775807/2')], 'PRECISION', 'FIELD_GRAPH_AND_PRECISION denominator precision')
        self.reject([parameter(b='=@10:8')], 'CYCLE', 'FIELD_GRAPH_AND_PRECISION cycle')
        self.apply([parameter(b='=@11:3'), parameter(identifier=11, b='=@10:3')])
        self.assertEqual((12, 12), self.lengths(), 'FIELD_GRAPH_AND_PRECISION cross-card acyclic')

    def test_CR11_SOURCE_EXCLUSIVITY_COMPLETE_MAPPING_MODE_SCOPE(self):
        self.seed()
        for token in ('12', 'param:10:3'):
            self.reject([grid(u='repeat -5 ' + token)], 'SOURCE_EXCLUSIVITY', 'SOURCE_EXCLUSIVITY')
        bad = source(); del bad['vFieldId']
        rejected = self.reject([grid(ref=bad)], 'COMPLETE_MAPPING', 'COMPLETE_MAPPING')
        error = rejected['preview']['violations'][0]['message']
        self.assertIn('grid-system 4', error)
        self.assertNotIn('SAME_CARD', error)
        self.reject([grid(v='none')], 'MODE_SCOPE', 'MODE_SCOPE')
        self.reject([grid(u='series 0 12 3')], 'MODE_SCOPE', 'MODE_SCOPE legacy identity')
        self.reject([{'op': 'set-grid-card-reference', 'id': 4, 'value': bad}], 'COMPLETE_MAPPING', 'COMPLETE_MAPPING set operation')
        self.apply([unbind(), grid(ref=False, v='none', u='repeat -5 12')])
        self.reject([{'op': 'set-grid-card-reference', 'id': 4, 'value': source()}], 'grid-system 4', 'MODE_SCOPE set operation')

    def test_CR12_ATOMIC_REBIND(self):
        self.seed(); self.apply([parameter(identifier=11, a='20', b='40'), {'op': 'set-grid-card-reference', 'id': 4, 'value': source(11)}])
        self.assertEqual((20, 40), self.lengths(), 'ATOMIC_REBIND')
        self.assert_source(source(11))
        self.apply([card(12, 'Qbad', [field(3, '25'), field(8, '45', 'count')])])
        self.reject([{'op': 'set-grid-card-reference', 'id': 4, 'value': source(12)}], 'not a dimension', 'ATOMIC_REBIND')
        self.apply([parameter(identifier=13, a='20', b='40')])
        before = self.dump(); preview = self.request([{'op': 'set-grid-card-reference', 'id': 4, 'value': source(13)}])['preview']
        self.assertEqual(source(13), preview['after']['geometry']['gridSystems'][0]['cardReference'], 'ATOMIC_REBIND same values different card')
        self.assertEqual(before, self.dump()); self.command(f"engineering-cancel {preview['token']}")

    def test_CR13_EXPLICIT_UNBIND_ORDERED_CAPTURE(self):
        self.seed(extras=[field(9, '3')]); self.apply([grid(u='repeat-panel card gap param:10:9 from -5'), unbind('parameter')])
        self.assertNotIn('cardReference', self.systems()[4]); self.apply([parameter(a='18', extras=[field(9, '3')])])
        self.assertEqual((18, 30), self.lengths(), 'EXPLICIT_UNBIND follows parameter')
        self.apply([{'op': 'set-grid-card-reference', 'id': 4, 'value': source()}, parameter(a='12', extras=[field(9, '3')])])
        p, _ = self.apply([parameter(a='18', extras=[field(9, '3')]), unbind()])
        self.assertEqual([18, 30], p['preview']['cardCaptures'][0]['values'], 'EXPLICIT_UNBIND capture preview')
        self.assertEqual('ordered-candidate-step', p['preview']['cardCaptures'][0]['timing'])
        self.assertEqual((18, 30), self.lengths(), 'EXPLICIT_UNBIND capture current step')
        self.assertIn('gap param:10:9', self.dump(), 'EXPLICIT_UNBIND preserves other source')
        self.apply([parameter(a='12', extras=[field(9, '3')]), {'op': 'set-grid-card-reference', 'id': 4, 'value': source()}])
        p, _ = self.apply([unbind(), parameter(a='18', extras=[field(9, '3')])])
        self.assertEqual([12, 30], p['preview']['cardCaptures'][0]['values'], 'EXPLICIT_UNBIND earlier capture preview')
        self.assertEqual((12, 30), self.lengths(), 'EXPLICIT_UNBIND must not capture future value')
        self.apply([{'op': 'set-grid-card-reference', 'id': 4, 'value': source()}])
        self.reject([{'op': 'delete-parameter', 'id': 10}, unbind(), parameter(extras=[field(9, '3')])], 'MISSING', 'EXPLICIT_UNBIND cannot borrow future/deleted sources')
        self.apply([grid()])
        preview, _ = self.apply([{'op': 'delete-parameter', 'id': 10}, parameter(extras=[field(9, '3')]), unbind('parameter')])
        self.assertNotIn('cardReference', self.systems()[4], 'EXPLICIT_UNBIND new field refs are explicit post-delete declarations')
        self.assertEqual({2, 8}, {r['owner']['slot'] for r in preview['preview']['redeclaredReferences'] if r['owner']['kind'] == 'grid-system' and r['owner']['slot']}, 'EXPLICIT_UNBIND declares only both length slots')
        self.apply([{'op': 'set-grid-card-reference', 'id': 4, 'value': source()}, grid(u='repeat param:10:9 card')])
        self.reject([{'op': 'delete-parameter', 'id': 10}, parameter(extras=[field(9, '3')]), unbind('parameter')], 'u phase', 'EXPLICIT_UNBIND must not redeclare unrelated references')

    def test_CR14_MODE_TRANSITION(self):
        self.seed(); self.apply([grid(v='repeat-panel card gap 3 from 7')]); self.assertEqual((12, 30), self.lengths())
        self.reject([grid(v='repeat-panel card')], 'MODE_TRANSITION', 'MODE_TRANSITION missing new fields')
        self.reject([grid(v='none')], 'MODE_SCOPE', 'MODE_TRANSITION half reference')
        self.apply([unbind(), grid(ref=False, u='repeat -5 12', v='none')])
        self.assertNotIn('cardReference', self.systems()[4])

    def binding_fixture(self):
        for identifier in (2, 3):
            self.apply_line(f'boundary {identifier} outline 100,200 1300,200 1300,1000 100,1000')
            self.apply_line(f'boundary-vertex-keys {identifier} outer 1 2 3 4 next-key 5')
            self.apply_line(f'grid-binding {identifier} on-boundary {identifier} from-system 4 vertex-key 1 cell -2 1 anchor 1 2 1 2')

    def test_CR15_ALL_BINDINGS_RECOMPUTE(self):
        self.seed(); self.binding_fixture()
        bindings = lambda: self.command('objects')['gridBindings']
        before = deepcopy(bindings()); self.apply([parameter(a='20')]); after = bindings()
        self.assertEqual([[123, 148]] * 2, [b['translation'] for b in before], 'ALL_BINDINGS_RECOMPUTE exact old value')
        self.assertEqual([[135, 148]] * 2, [b['translation'] for b in after], 'ALL_BINDINGS_RECOMPUTE exact new value')
        for a, b in zip(before, after):
            self.assertEqual(a['cell'], b['cell'], 'ALL_BINDINGS_RECOMPUTE cell')
            self.assertEqual(a['vertexKey'], b['vertexKey'])
            self.assertEqual(a['anchor'], b['anchor'])
        self.assertNotEqual(before, after, 'ALL_BINDINGS_RECOMPUTE effective geometry')
        self.apply_line('grid-binding 2 on-boundary 2 from-system 4 vertex-key 1 cell -2 1 anchor 0 1 1 2')
        self.reject([parameter(a='13')], 'integer', 'ALL_BINDINGS_RECOMPUTE half millimetre')

    def test_CR16_INDEX_AND_DOWNSTREAM(self):
        self.seed(); self.apply([grid(u='repeat -5 card stagger 6')]); self.binding_fixture()
        self.apply([parameter(a='18')]); self.assertEqual((-2, 1), tuple(map(int, self.command('objects')['gridBindings'][0]['cell'])))
        self.reject([parameter(a='6')], '整數倍', 'INDEX_AND_DOWNSTREAM stagger')
        before = self.state(); r = self.command('line grid-source-rule 4 create name-hex 52 selector all-cells divide 2 2')
        self.assertFalse(r.get('preview', {}).get('valid', r.get('ok')), 'INDEX_AND_DOWNSTREAM stagger cannot gain source subgrid')
        self.assertIn('SOURCE_KIND', rejection_reason(r)); self.assertEqual(before, self.state())
        # D19a rules retain keys when the parent's actual length changes.
        self.apply([grid()]); self.apply_line('grid-source-rule 4 create name-hex 52 selector all-cells divide 2 2')
        self.apply_line('placement 2 on boundary 2 origin 0 0 0 u +x v +y')
        self.apply_line('grid 12 on 2 from-binding 2')
        for line in ['timber 90 2 4 role boundary', 'place 90 on 2 at-face e0 +u +n',
                     'timber 91 2 4 role boundary', 'place 91 on 2 at-face e2 +u +n',
                     'guide 50 2 v gridrule:12:4:1:-1:1:u:0',
                     'timber 1 2 4 role primary', 'place 1 on 2 at-line guide 50 +v +n']:
            self.apply_line(line)
        timber = lambda: next(t for t in self.command('references')['timbers'] if t['id'] == 1)
        self.assertEqual(118, timber()['geometry']['centerline'], 'INDEX_AND_DOWNSTREAM original rule coordinate')
        anchor = timber()['definition']['anchor']
        before = self.systems()[4]['rules']; self.apply([parameter(a='20')]); self.assertEqual(before, self.systems()[4]['rules'])
        self.assertEqual(120, timber()['geometry']['centerline'], 'INDEX_AND_DOWNSTREAM downstream recomputed')
        self.assertEqual(anchor, timber()['definition']['anchor'], 'INDEX_AND_DOWNSTREAM source-rule key and signed cell remain')
        self.assertIn('gridrule:12:4:1:-1:1:u:0', self.dump(), 'INDEX_AND_DOWNSTREAM exact rule-line identity')

    def test_CR17_CANDIDATE_LIFECYCLE(self):
        self.seed()
        self.apply_line('boundary-vertex-keys 1 outer 1 2 3 4 next-key 5')
        self.apply_line('grid-binding 2 on-boundary 1 from-system 4 vertex-key 1 cell 0 0 anchor 0 1 0 1')
        before = self.dump(); p = self.request([swap()])['preview']
        self.assertEqual(before, self.dump()); self.command(f"engineering-cancel {p['token']}")
        self.assertFalse(self.command(f"engineering-confirm {p['token']}")['ok']); self.assertEqual(before, self.dump())
        p = self.request([swap()])['preview']; self.apply([parameter(a='18')])
        self.assertFalse(self.command(f"engineering-confirm {p['token']}")['ok'], 'CANDIDATE_LIFECYCLE stale')
        p = self.request([swap()])['preview']; self.apply_line('spec stale_marker 3')
        stale = self.command(f"engineering-confirm {p['token']}")
        self.assertEqual('STALE', stale.get('code'), 'CANDIDATE_LIFECYCLE unrelated definition expiry')
        before = self.dump(); self.apply([swap()]); after = self.dump()
        self.apply_line('undo'); self.assertEqual(before, self.dump(), 'CANDIDATE_LIFECYCLE one undo')
        self.apply_line('redo'); self.assertEqual(after, self.dump(), 'CANDIDATE_LIFECYCLE full redo')
        scene = self.directory / 'confirm.scene'; scene.write_text(self.dump(), encoding='utf-8')
        probe = self.directory / 'confirm-probe'
        bridge_source = ROOT / 'geometry-web/web_bridge.c'
        instrumented = bridge_source.read_text().replace('int main(void)', 'int geometry_bridge_main(void)')
        instrumented = re.sub(r'#include "([^"]+)"', lambda m: '#include "' + str((bridge_source.parent / m[1]).resolve()) + '"', instrumented)
        included = self.directory / 'bridge-main-renamed.inc'; included.write_text(instrumented, encoding='utf-8')
        compile_result = subprocess.run(['cc', '-std=c11', '-O0', '-DCR_BRIDGE_SOURCE="' + str(included) + '"', str(ROOT / 'geometry-core/card-reference/confirmation_probe.c'), '-lm', '-o', str(probe)], capture_output=True, text=True, timeout=60)
        self.assertEqual(0, compile_result.returncode, compile_result.stderr)
        result = subprocess.run([str(probe), str(scene), str(self.directory / 'confirm.json')], capture_output=True, text=True, timeout=30)
        self.assertEqual(0, result.returncode, 'CANDIDATE_LIFECYCLE injection: ' + result.stdout + result.stderr)

    def test_CR18_INCARNATION_NOT_CONTENT_NO_LEDGER_CONTEXT(self):
        self.seed(); before = self.dump()
        self.apply([unbind(), {'op': 'delete-parameter', 'id': 10}, parameter(name='rebuilt'), {'op': 'set-grid-card-reference', 'id': 4, 'value': source()}])
        self.assert_source(); self.assertNotIn('requires identity-ledger/1', self.dump(), 'INCARNATION_NOT_CONTENT no invented marks')
        self.apply_line('undo'); self.assertEqual(before, self.dump())
        self.apply_line('redo'); self.assert_source()

    def test_CR19_CARD_SAVE_ROUNDTRIP(self):
        self.seed(extras=[field(9, '3')]); self.apply([grid(u='repeat param:10:9 card'), grid(identifier=5)])
        self.binding_fixture(); before = self.dump()
        path = self.directory / 'card.scene'; path.write_text(before, encoding='utf-8')
        self.command('reset'); self.assertTrue(self.command('loadfile ' + str(path))['ok'])
        self.assertEqual(before, self.dump(), 'CARD_SAVE_ROUNDTRIP full definitions')
        self.assert_source(); self.assertIn(5, self.systems(), 'CARD_SAVE_ROUNDTRIP unused grid')
        # Exercise the real ZIP writer/reader, then a fresh native context.
        result = subprocess.run(['node', str(ROOT / 'geometry-core/card-reference/archive_roundtrip.cjs'), str(path)],
                                capture_output=True, text=True, cwd=ROOT, timeout=30)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        self.command('reset'); self.assertTrue(self.command('loadfile ' + str(path) + '.reopened')['ok'])
        self.assertEqual(before, self.dump(), 'CARD_SAVE_ROUNDTRIP gcanvas and fresh native context')

    def test_CR20_NO_SILENT_DOWNGRADE(self):
        self.seed(); before = self.state(); text = self.dump()
        bad = [text.replace('requires grid-card-reference/1\n', ''), text.replace('grid-card-reference/1', 'grid-card-reference/2'),
               text.replace('card-reference 10 3 8', 'card-reference 10 3 99'), text.replace('card-reference 10 3 8', 'card-reference 11 3 8'),
               text.replace('repeat -5 card', 'repeat -5 mystery')]
        for n, scene in enumerate(bad):
            path = self.directory / f'bad{n}.scene'; path.write_text(scene, encoding='utf-8')
            self.assertFalse(self.command('loadfile ' + str(path))['ok'], 'NO_SILENT_DOWNGRADE')
            self.assertEqual(before, self.state(), 'NO_SILENT_DOWNGRADE current context retained')
        self.command('reset'); empty = self.state()
        for n in range(len(bad)):
            self.assertFalse(self.command('loadfile ' + str(self.directory / f'bad{n}.scene'))['ok'])
            self.assertEqual(empty, self.state(), 'NO_SILENT_DOWNGRADE empty context retained')

    def test_CR21_LEGACY_UNCHANGED(self):
        self.apply([parameter(), grid(ref=False, u='repeat -5 param:10:3', v='repeat 7 param:10:8')])
        self.assertNotIn('cardReference', self.systems()[4]); self.assertNotIn('grid-card-reference', self.dump())
        self.apply([grid(ref=False, u='repeat -5 18', v='repeat 7 param:10:8')]); self.assertEqual((18, 30), self.lengths())
        self.apply_line('grid-system 5 name-hex 4c main-along none u series 1 2 3 v explicit 4 8')
        self.assertEqual('legacy-finite', self.systems()[5]['mode'])

    def import_fixture(self):
        self.seed(); self.apply([card(i, f'constant{i}', [field(1, '1')]) for i in range(10)])
        c = deepcopy(next(c for c in self.read()['state']['parameters'] if c['id'] == 10))
        for f in c['fields']: f.pop('value', None)
        return {'op': 'import-parameters', 'value': {'schema': 'geometry-parameters/1', 'cards': [c]}}

    def test_CR22_IMPORT_REUSED_KEY_GUARD_IMPORT_ISOLATION(self):
        imported = self.import_fixture()
        self.apply([imported])
        self.assertEqual(11, self.read()['state']['parameters'][-1]['id'], 'IMPORT_ISOLATION same name receives independent id')
        self.reject([{'op': 'delete-parameter', 'id': 10}, imported], 'grid-system 4', 'IMPORT_REUSED_KEY_GUARD', identity=(4, 10, 3))
        self.apply([unbind(), {'op': 'delete-parameter', 'id': 10}, imported])
        c = self.read()['state']['parameters'][-1]
        self.assertEqual(10, c['id'], 'IMPORT_ISOLATION first unused id')
        self.assertEqual([3, 8], [f['id'] for f in c['fields']])
        self.assertNotIn('cardReference', self.systems()[4])

    def test_CR25_EXPLICIT_REVERSED_MAPPING(self):
        self.apply([parameter(), grid(ref=source(u=8, v=3))]); self.assert_source(source(u=8, v=3))
        self.assertEqual([-35, -5, 25], self.lines('u'), 'EXPLICIT_REVERSED_MAPPING')
        self.assertEqual([-5, 7, 19], self.lines('v'))
        self.apply([parameter(a='18')]); self.assertEqual([-11, 7, 25], self.lines('v'))

    def test_CR26_SAME_KEY_REFERENCE_GUARD(self):
        self.seed(); self.reject([{'op': 'delete-parameter', 'id': 10}, parameter()], 'grid-system 4', 'SAME_KEY_REFERENCE_GUARD', identity=(4, 10, 3))

    def test_CR27_EXPLICIT_POST_DELETE_REBIND(self):
        self.seed(); self.apply([{'op': 'delete-parameter', 'id': 10}, parameter(), grid()])
        self.apply([grid(identifier=5)])
        self.reject([{'op': 'delete-parameter', 'id': 10}, parameter(), grid()], 'grid-system 5', 'EXPLICIT_POST_DELETE_REBIND all owners')
        preview, _ = self.apply([{'op': 'delete-parameter', 'id': 10}, parameter(), grid(), grid(identifier=5)])
        self.assertEqual({4, 5}, {r['owner']['id'] for r in preview['preview']['redeclaredReferences']}, 'EXPLICIT_POST_DELETE_REBIND preview')

    def test_CR28_ORDERED_REFERENCE_PROTECTION(self):
        self.seed()
        self.reject([grid(), {'op': 'delete-parameter', 'id': 10}, parameter()], 'grid-system 4', 'ORDERED_REFERENCE_PROTECTION before delete', identity=(4, 10, 3))
        self.reject([{'op': 'delete-parameter', 'id': 10}, parameter(), grid(), {'op': 'delete-parameter', 'id': 10}, parameter()], 'grid-system 4', 'ORDERED_REFERENCE_PROTECTION last delete', identity=(4, 10, 3))
        self.apply([unbind(), {'op': 'delete-parameter', 'id': 10}, parameter()])

    def test_CR29_D25_CARD_CLOSURE(self):
        self.apply([parameter(b='=@11:8'), parameter(identifier=11), grid()])
        # Both providers are explicitly present; the fixture is a real placed timber.
        self.apply_line('boundary-vertex-keys 1 outer 1 2 3 4 next-key 5')
        self.apply_line('grid-binding 2 on-boundary 1 from-system 4 vertex-key 1 cell 0 0 anchor 0 1 0 1')
        self.apply_line('grid 10 on 1 from-binding 2')
        for line in ['timber 90 20 33 role boundary', 'place 90 on 1 at-face e0 +u +n',
                     'timber 91 20 33 role boundary', 'place 91 on 1 at-face e2 +u +n',
                     'timber 1 5 5 role primary', 'place 1 on 1 at-line grid 10 u 1 +v +n']:
            self.apply_line(line)
        definitions = {'base_scene': self.dump(), 'extensions': []}
        req = {'roots': [{'kind': 'timber', 'id': 1}], 'role': 'geometry', 'target': 'solid-set', 'allow_partial': False}
        try:
            pkg = build_package(definitions, req)
            rebuilt = verify_package(pkg)
        except ModelError as error:
            self.fail('D25_CARD_CLOSURE failed to retain/rebuild card sources: ' + str(error))
        self.assertEqual(pkg['derived'], rebuilt['derived'], 'D25_CARD_CLOSURE recompute')
        text = pkg['definitions']['base_scene']
        self.assertIn('card-reference 10 3 8 u repeat -5 card v repeat 7 card', text, 'D25_CARD_CLOSURE keep mapping/source')
        self.assertIn('grid-card-reference/1', pkg['manifest']['capabilities'], 'D25_CARD_CLOSURE capability')
        self.assertIn('parameters/1', pkg['manifest']['capabilities'])
        records = [(line.split()[1], json.loads(base64.b64decode(line.split()[2])))
                   for line in text.splitlines() if line.startswith(('parameters card ', 'parameters field '))]
        self.assertEqual({10, 11}, {r['id'] for kind, r in records if kind == 'card'}, 'D25_CARD_CLOSURE provider cards')
        b = next(r for kind, r in records if kind == 'field' and r['parameterId'] == 10 and r['id'] == 8)
        self.assertEqual({'op': 'ref', 'parameterId': 11, 'fieldId': 8}, b['expression'], 'D25_CARD_CLOSURE transitive source')
        without_q = []
        for line in text.splitlines():
            if line.startswith(('parameters card ', 'parameters field ')):
                r = json.loads(base64.b64decode(line.split()[2]))
                if (r.get('parameterId') if 'parameterId' in r else r['id']) == 11: continue
            without_q.append(line)
        for bad_text in ('\n'.join(without_q) + '\n', text.replace('card-reference 10 3 8', 'card-reference 10 3')):
            broken = deepcopy(pkg); broken['definitions']['base_scene'] = bad_text
            with self.assertRaises(ModelError, msg='D25_CARD_CLOSURE missing provider or mapping'): verify_package(broken)
        for removal in ['requires grid-card-reference/1\n', 'requires parameters/1\n']:
            broken = deepcopy(pkg); broken['definitions']['base_scene'] = text.replace(removal, '')
            with self.assertRaises(ModelError, msg='D25_CARD_CLOSURE stripped source capability'): verify_package(broken)
        broken = deepcopy(pkg); broken['manifest']['capabilities'].remove('grid-card-reference/1')
        with self.assertRaises(ModelError, msg='D25_CARD_CLOSURE stripped manifest capability'): verify_package(broken)

    def test_CR30_SWAP_REVALIDATES_STAGGER(self):
        self.seed(); self.apply([grid(u='repeat -5 card stagger 30')])
        self.reject([swap()], '整數倍', 'SWAP_REVALIDATES_STAGGER')
        self.apply([grid(u='repeat -5 card stagger 6'), swap()]); self.assertEqual((30, 12), self.lengths())

    def test_CR31_CONTROLLED_TOKEN_REJECT(self):
        self.seed()
        for token in ('12', 'param:10:3'):
            before = self.state(); r = self.command('line grid-system 4 name-hex 47 main-along none u repeat -5 ' + token + ' v repeat 7 30')
            self.assertFalse(r.get('ok') and r.get('preview', {}).get('valid', True), 'CONTROLLED_TOKEN_REJECT')
            self.assertIn('CONTROLLED_TOKEN_REJECT', rejection_reason(r)); self.assertEqual(before, self.state())
        self.apply([unbind('parameter')]); self.apply_line('grid-system 4 name-hex 47 main-along none u repeat -5 param:10:3 v repeat 7 param:10:8')

    def test_CR32_FIELD_KEY_RECREATION_GUARD(self):
        self.seed(); omit = card(10, 'P', [field(3, '12')])
        self.reject([omit, parameter()], 'grid-system 4', 'FIELD_KEY_RECREATION_GUARD', identity=(4, 10, 8))
        self.apply([omit, parameter(), grid()])
        self.reject([omit, parameter(), grid(), omit, parameter()], 'grid-system 4', 'FIELD_KEY_RECREATION_GUARD last deletion', identity=(4, 10, 8))

    def test_P146_ERROR_FIELDS_ONLY(self):
        self.seed()
        rejected = self.request([parameter(b='0')])
        rejected['preview']['after']['nonErrorTestMarker'] = 'ONLY_IN_PREVIEW_DATA'
        with mock.patch.object(self, 'request', return_value=rejected):
            with self.assertRaisesRegex(AssertionError, 'ONLY_IN_PREVIEW_DATA'):
                self.reject([parameter(b='0')], 'ONLY_IN_PREVIEW_DATA', 'ERROR_FIELDS_ONLY')

    def test_P154_GRID_DEFINITION_DIAGNOSTIC(self):
        self.seed()
        for name, change in (
                ('missing name', lambda v: v.pop('name')),
                ('unknown key', lambda v: v.update(extra=True)),
                ('mainAlong type', lambda v: v.update(mainAlong=42)),
                ('mainAlong value', lambda v: v.update(mainAlong='diagonal'))):
            operation = grid()
            change(operation['value'])
            with self.subTest(case=name):
                rejected = self.reject([operation], 'GRID_DEFINITION', 'GRID_DEFINITION ' + name)
                messages = [v['message'] for v in rejected['preview']['violations']]
                self.assertTrue(any(re.search(r'\bgrid-system 4\b', m) for m in messages), name)
                self.assertFalse(any('COMPLETE_MAPPING' in m for m in messages), name)
        bad = source()
        del bad['vFieldId']
        rejected = self.reject([grid(ref=bad)], 'COMPLETE_MAPPING', 'mapping remains distinct')
        self.assertFalse(any('GRID_DEFINITION' in v['message'] for v in rejected['preview']['violations']))

    def test_P154_IDENTITY_IN_ONE_DIAGNOSTIC_WITH_TOKEN_BOUNDARIES(self):
        self.seed()
        original = self.request([parameter(b='0')])
        for messages in (
                ['P154_REASON grid-system 4 parameter 10 field 30'],
                ['P154_REASON grid-system 4', 'parameter 10 field 3'],
                ['P154_REASON', 'grid-system 4 parameter 10 field 3']):
            rejected = deepcopy(original)
            rejected['preview']['violations'] = [{'message': m} for m in messages]
            with self.subTest(messages=messages), mock.patch.object(self, 'request', return_value=rejected):
                with self.assertRaisesRegex(AssertionError, 'P154_IDENTITY'):
                    self.reject([parameter(b='0')], 'P154_REASON', 'P154_IDENTITY', identity=(4, 10, 3))

    def test_P146_CARD_DIRECT_REBUILT_CURRENT_VALUE(self):
        self.seed()
        pending, _ = self.apply([{'op': 'delete-parameter', 'id': 10}, parameter(a='99', b='47'), unbind()])
        self.assertEqual([99, 47], pending['preview']['cardCaptures'][0]['values'])
        self.assertEqual((99, 47), self.lengths(), 'CARD_DIRECT_REBUILT_CURRENT_VALUE must read this ordered step')
        self.assertNotIn('cardReference', self.systems()[4])

    def test_P146_CARD_DIRECT_MISSING_SOURCE(self):
        self.seed()
        self.reject([{'op': 'delete-parameter', 'id': 10}, unbind()], 'MISSING', 'CARD_DIRECT_MISSING_SOURCE', identity=(4, 10, 3))

    def test_CR33_PARAMETER_PACKAGE_BOUNDARY(self):
        self.seed()
        package = lambda ops: {'op': 'parameter-package', 'operations': ops}
        self.reject([package([parameter(a='18'), unbind()])], 'PARAMETER_PACKAGE_BOUNDARY', 'PARAMETER_PACKAGE_BOUNDARY')
        self.apply([package([parameter(a='18')]), unbind()]); self.assertEqual((18, 30), self.lengths())
        self.apply([parameter(), {'op': 'set-grid-card-reference', 'id': 4, 'value': source()}])
        self.apply([unbind(), package([parameter(a='18')])]); self.assertEqual((12, 30), self.lengths())

    # P-142 B2: the whole-card grid owner and the D44 panel-fill owners are one
    # parameter_uses enumeration and one I38 rejection; the fixture values match
    # test_parameters_core's panel-fill owner fixture (board 100 x 100, refs = 8).
    PANEL_BOARD = {'id': 'b2-board', 'version': 1, 'name': '板', 'kind': 'panel',
                   'width': 100, 'length': 100, 'thickness': '9'}

    def panel_fill_transaction(self, operation):
        path = self.directory / 'panel-fill-owner.json'
        path.write_text(json.dumps({'schema': 'panel-fill-transaction/1', 'expectedRevision': self.read()['revision'],
                                    'operations': [operation]}, ensure_ascii=False), encoding='utf-8')
        preview = self.command('panel-fill-preview ' + str(path))
        self.assertTrue(preview['ok'] and preview['preview']['valid'], preview)
        self.assertTrue(self.command('panel-fill-confirm ' + str(preview['preview']['token']))['ok'])

    def put_panel_fill(self, target, ref):
        keep = {'parameterId': 91, 'fieldId': 1}
        value = {'id': 1, 'finishSurfaceId': 1, 'panel': {'id': 'b2-board', 'version': 1},
                 'lengthAlong': 'v', 'origin': [0, 0], 'gap': ref if target == 'gap' else 3,
                 'pattern': 'stagger' if target == 'stagger' else 'straight',
                 'threshold': ref if target == 'threshold' else keep}
        if target == 'stagger':
            value['stagger'] = {'axis': 'u', 'value': ref}
        return {'op': 'put-panel-fill', 'value': value}

    @staticmethod
    def i38_messages(result):
        return [v.get('message', '') for v in result['preview']['violations'] if 'I38 MISSING' in v.get('message', '')]

    def panel_fill_owner(self, target, ref):
        """Finish surface 1 on boundary 8 and panel-fill 1 whose `target` slot uses `ref`."""
        self.apply_line('boundary 8 outline 0,0 250,0 250,250 0,250 kind room_plan')
        self.apply([{'op': 'publish-material', 'value': self.PANEL_BOARD}, card(91, 'threshold', [field(1, '8')])])
        self.panel_fill_transaction({'op': 'put-finish-surface', 'value': {
            'id': 1, 'name': '完成面', 'boundaryId': 8, 'frame': {'origin': [0, 0, 0], 'U': '+X', 'V': '+Y', 'N': '+Z'},
            'structureSide': 1, 'obstacles': []}})
        self.panel_fill_transaction(self.put_panel_fill(target, ref))

    def card_and_panel_fill_share_rejection(self, target):
        self.seed(a='8')  # grid-system 4 card-reference 10 3 8; field 3 = 8 is also the panel-fill source
        self.panel_fill_owner(target, {'parameterId': 10, 'fieldId': 3})
        panel_owner = re.compile(r'\bpanel-fill 1 ' + target + r'\b')
        card_owner = re.compile(r'\bgrid-system 4 card-reference u field 3\b')
        delete = {'op': 'delete-parameter', 'id': 10}
        both = self.i38_messages(self.reject([delete], 'I38 MISSING', 'B2 both owners', identity=(4, 10, 3)))
        self.assertTrue(any(panel_owner.search(m) and card_owner.search(m) and '另成一筆後再刪' in m for m in both),
                        ('B2: one I38 rejection names the panel-fill and the whole-card owner', both))
        # The card owner is handled in this candidate; the native-only panel-fill owner still blocks.
        native = self.i38_messages(self.reject([unbind(), delete], 'I38 MISSING', 'B2 panel-fill still unhandled'))
        self.assertTrue(any(panel_owner.search(m) and '另成一筆後再刪' in m for m in native), native)
        self.assertFalse(any(re.search(r'\bgrid-system 4\b', m) for m in native), ('B2: handled card owner listed', native))
        # Panel-fill repointed in its own transaction: the card owner alone is the same I38 rejection.
        self.panel_fill_transaction(self.put_panel_fill(target, {'parameterId': 91, 'fieldId': 1}))
        card_only = self.i38_messages(self.reject([delete], 'I38 MISSING', 'B2 card owner alone', identity=(4, 10, 3)))
        self.assertFalse(any(re.search(r'\bpanel-fill 1\b', m) or '另成一筆後再刪' in m for m in card_only), card_only)
        self.apply([unbind(), delete])
        self.assertNotIn(10, [c['id'] for c in self.read()['state']['parameters']])

    def test_P142_B2_CARD_AND_PANEL_FILL_GAP_SHARE_I38_REJECTION(self):
        self.card_and_panel_fill_share_rejection('gap')

    def test_P142_B2_CARD_AND_PANEL_FILL_STAGGER_SHARE_I38_REJECTION(self):
        self.card_and_panel_fill_share_rejection('stagger')

    def test_P142_B2_CARD_AND_PANEL_FILL_THRESHOLD_SHARE_I38_REJECTION(self):
        self.card_and_panel_fill_share_rejection('threshold')

    def test_P142_B2_LONG_OWNER_LIST_KEEPS_COMPLETE_NAMES(self):
        """B2 review: the message reaches callers through the 256-byte engineering error;
        names that do not fit are counted, never cut (field 4000000012 must not become 40000)."""
        F, grids = 4000000012, (4000000001, 4000000002, 4000000004)
        self.apply([card(10, 'P', [field(F, '8', name='a'), field(8, '30', name='b')])] +
                   [grid(identifier=g, ref=source(u=F, v=8)) for g in grids])
        self.panel_fill_owner('stagger', {'parameterId': 10, 'fieldId': F})
        guidance = '; 先在原生 DSL 或該物件自己的交易裡改掉引用，另成一筆後再刪 (other references: '
        untruncated = ('I38 MISSING: parameter 10 is still referenced by panel-fill 1 stagger' + guidance + '3: ' +
                       '; '.join(f'grid-system {g} card-reference u field {F}' for g in grids) + ')')
        self.assertGreater(len(untruncated.encode('utf-8')), 255, 'fixture must exceed the engineering error buffer')
        messages = self.i38_messages(self.reject([{'op': 'delete-parameter', 'id': 10}], 'I38 MISSING', 'B2 long owner list'))
        self.assertEqual(1, len(messages), messages)
        message = messages[0]
        self.assertLessEqual(len(message.encode('utf-8')), 255, message)
        match = re.fullmatch(re.escape('I38 MISSING: parameter 10 is still referenced by panel-fill 1 stagger' + guidance + '3: ') +
                             r'(.+?)(?: and (\d+) more)?\)', message)
        self.assertTrue(match and match.group(2), ('complete names plus "and N more"', message))
        listed = match.group(1).split('; ')
        for name in listed:
            owner = re.fullmatch(r'grid-system (\d+) card-reference u field (\d+)', name)
            self.assertTrue(owner, ('truncated owner name', name, message))
            self.assertIn(int(owner.group(1)), grids, message)
            self.assertEqual(F, int(owner.group(2)), ('listed field id must be the real one', message))
        self.assertEqual(len(set(listed)), len(listed), message)
        self.assertEqual(len(grids), len(listed) + int(match.group(2)), ('exact owner count', message))

    def test_P142_S1_GRID_SYSTEM_FIELD_REBIND_IN_SAME_CANDIDATE(self):
        """P-142 S1: put-grid-system rebinds DSL grid-system field references inside the candidate."""
        self.apply([parameter(), parameter(identifier=11, a='20', b='40')])
        self.apply_line('grid-system 4 name-hex 47 main-along none u repeat -5 param:10:3 v repeat 7 param:10:8')
        self.assertNotIn('cardReference', self.systems()[4]); self.assertEqual((12, 30), self.lengths())
        field_grid = lambda identifier: grid(ref=False, u=f'repeat -5 param:{identifier}:3', v=f'repeat 7 param:{identifier}:8')
        delete = {'op': 'delete-parameter', 'id': 10}
        step_owner = re.compile(r'\bgrid-system 4 u step\b')
        for operations, label in (([delete], 'S1 control: not rebound'),
                                  ([delete, parameter()], 'S1 control: rebuilding the key is not a rebinding')):
            messages = self.i38_messages(self.reject(operations, 'I38 MISSING', label))
            self.assertTrue(any(step_owner.search(m) and 'unbind or repoint' in m for m in messages), (label, messages))
            self.assertFalse(any('另成一筆後再刪' in m for m in messages), (label, 'grid-system is no longer native-only', messages))
        self.apply([delete, field_grid(11)])
        self.assertEqual((20, 40), self.lengths(), 'S1 rebound to another card in the same candidate')
        self.assertNotIn(10, [c['id'] for c in self.read()['state']['parameters']])
        self.assertIn('grid-system 4 name-hex 47 main-along none u repeat -5 param:11:3 v repeat 7 param:11:8', self.dump())
        # Same key: deleted, rebuilt and explicitly redeclared by put-grid-system after the deletion.
        self.apply([parameter(), field_grid(10)]); self.assertEqual((12, 30), self.lengths())
        preview, _ = self.apply([delete, parameter(a='18'), field_grid(10)])
        self.assertEqual((18, 30), self.lengths(), 'S1 explicit post-delete redeclaration of the rebuilt key')
        owner = {'kind': 'grid-system', 'id': 4, 'slot': 0}
        self.assertEqual({(10, 3), (10, 8)}, {(r['source']['parameterId'], r['source']['fieldId'])
                                              for r in preview['preview']['redeclaredReferences'] if r['owner'] == owner},
                         'S1 preview discloses the put-grid-system redeclaration')

    def test_P142_S1_REDECLARATION_WITHOUT_REBUILD_REJECTS(self):
        """P-142 S1 counterexample: [delete-parameter 10, put-grid-system still on card 10].
        The post-delete put-grid-system satisfies the deletion guard's declaration order,
        so the still-missing source itself must reject (I38 MISSING naming grid, card, field)."""
        self.apply([parameter()])
        self.apply_line('grid-system 4 name-hex 47 main-along none u repeat -5 param:10:3 v repeat 7 param:10:8')
        still_on_10 = grid(ref=False, u='repeat -5 param:10:3', v='repeat 7 param:10:8')
        self.reject([{'op': 'delete-parameter', 'id': 10}, still_on_10], 'I38 MISSING',
                    'S1 redeclared reference to a deleted, unrebuilt card', identity=(4, 10, 3))
        self.assertIn(10, [c['id'] for c in self.read()['state']['parameters']])
        self.assertEqual((12, 30), self.lengths())

    def test_P142_S2_INTEGRATED_FIELD_AND_CARD_REBUILD_READS_99(self):
        """P-142 S2 on the merged #193 source: one ordered candidate rebuilds card 10 and
        unbinds both the whole-card grid and a field-level timber source; both read 99."""
        self.seed(extras=[field(9, '27')])
        self.apply_line('timber 1 27 33 role boundary')
        self.apply_line('place 1 on 1 at-face e0 +u +n')  # same placement as test_parameters_core's verified 99 case
        target = {'kind': 'timber', 'id': 1, 'field': 'A'}
        self.apply([{'op': 'set-source', 'target': target, 'source': {'kind': 'parameter', 'parameterId': 10, 'fieldId': 9}}])
        before = self.dump()
        pending, _ = self.apply([{'op': 'delete-parameter', 'id': 10}, parameter(a='99', b='47', extras=[field(9, '99')]),
                                 unbind(), {'op': 'unbind-source', 'target': target}])
        self.assertEqual([99, 47], pending['preview']['cardCaptures'][0]['values'], 'card direct reads this ordered step')
        self.assertEqual((99, 47), self.lengths())
        self.assertNotIn('cardReference', self.systems()[4])
        self.assertRegex(self.dump(), r'(?m)^timber 1 99 33 role boundary$', 'field unbind reads the rebuilt 99, not the deleted 27')
        self.assertEqual([], self.read()['state']['sources'])
        self.apply_line('undo'); self.assertEqual(before, self.dump(), 'one history step')


if __name__ == '__main__':
    unittest.main()
