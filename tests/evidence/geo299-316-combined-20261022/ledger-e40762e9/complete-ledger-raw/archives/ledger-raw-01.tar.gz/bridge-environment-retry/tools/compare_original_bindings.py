
import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
source,work=map(Path,sys.argv[1:3]); sys.path.insert(0,str(source/'tests'))
spec=importlib.util.spec_from_file_location('original_combined_mutate',source/'tests/mutate.py')
mt=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mt;spec.loader.exec_module(mt)
import mutation_bridge
src,copy=mt.Sources(source),mt.Sources(work)
assert src.closure==copy.closure
ids=[m['id'] for m in mt.MUTANTS if m.get('binary')=='bridge']
assert ids==json.loads(sys.argv[3])
rows=[]
for m in mt.MUTANTS:
 if m.get('binary')=='bridge':
  a,b=mutation_bridge.oracle_hash(m,source),mutation_bridge.oracle_hash(m,work)
  assert a==b
  rows.append({'id':m['id'],'source_oracle_sha256':a,'scratch_oracle_sha256':b})
assert (source/'tests/mutate.py').read_bytes()==(work/'tests/mutate.py').read_bytes()
assert (source/'tests/mutation_bridge.py').read_bytes()==(work/'tests/mutation_bridge.py').read_bytes()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head==sys.argv[4]
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=work)
print(json.dumps({'source':str(source),'scratch':str(work),'head':head,'source_closure':src.closure,
 'scratch_closure':copy.closure,'bridge_ids':ids,'oracle_bindings':rows,
 'restored_methods':mutation_bridge.RESTORED,'restored_method_count':len(mutation_bridge.RESTORED),
 'original_tool_sha256':mt.tool_hash(),'comparison_only':True},ensure_ascii=False,indent=2))
