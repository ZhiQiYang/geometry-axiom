"""Resume only the original bridge phase blocked by ENOSPC, without changing its judges."""
from pathlib import Path
import collections
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import resource
import shutil
import sys
import traceback

ROOT = Path('/tmp/g261-next299316')
S = 'e40762e99b078335d78c65a3a2682a0c9ab875d0'
ORIGINAL = Path('/workspace/geo299316-ledger-regenerate-e40762e9')
OUT = Path('/workspace/geo299316-ledger-environment-retry-e40762e9-r2')
LOCK = Path('/workspace/geo299316-work/private-diagnostics.lock')
IDS = ['M61', 'M62', 'M63', 'M64', 'M65', 'M66', 'M67', 'M68', 'M69', 'M70',
       'M78', 'M84', 'M79', 'M80', 'M81', 'M85', 'M82', 'M83']
HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_SHA = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
BINDING_CODE = r'''
import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
source,work=map(Path,sys.argv[1:3]); sys.path.insert(0,str(source/'tests'))
spec=importlib.util.spec_from_file_location('original_combined_mutate',source/'tests/mutate.py')
mt=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mt;spec.loader.exec_module(mt)
import mutation_bridge
src,copy=mt.Sources(source),mt.Sources(work)
assert src.closure==copy.closure
ids=[m['id'] for m in mt.MUTANTS if m.get('binary')=='bridge']
assert ids==json.loads(sys.argv[3])
rows=[]
for m in mt.MUTANTS:
 if m.get('binary')=='bridge':
  a,b=mutation_bridge.oracle_hash(m,source),mutation_bridge.oracle_hash(m,work)
  assert a==b
  rows.append({'id':m['id'],'source_oracle_sha256':a,'scratch_oracle_sha256':b})
assert (source/'tests/mutate.py').read_bytes()==(work/'tests/mutate.py').read_bytes()
assert (source/'tests/mutation_bridge.py').read_bytes()==(work/'tests/mutation_bridge.py').read_bytes()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head==sys.argv[4]
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=work)
print(json.dumps({'source':str(source),'scratch':str(work),'head':head,'source_closure':src.closure,
 'scratch_closure':copy.closure,'bridge_ids':ids,'oracle_bindings':rows,
 'restored_methods':mutation_bridge.RESTORED,'restored_method_count':len(mutation_bridge.RESTORED),
 'original_tool_sha256':mt.tool_hash(),'comparison_only':True},ensure_ascii=False,indent=2))
'''


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


assert not OUT.exists() and ROOT.is_dir() and LOCK.is_file()
assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
assert digest(HELPER.read_bytes()) == CAPTURE_SHA
old_receipt = json.loads((ORIGINAL / 'receipt.json').read_text())
assert old_receipt['exit_code'] == 1
assert [(r['label'], r['original_command_result']['actual_process_returncode'])
        for r in old_receipt['steps']] == [('precheck', 1), ('full-ledger', 2)]
assert any('No space left on device' in error for error in old_receipt['errors'])
old_raw = (ORIGINAL / 'ledger.json').read_bytes()
old_ledger = json.loads(old_raw)
preserved = {key: row for key, row in old_ledger.items()
             if row.get('execution', {}).get('head') == S}
assert preserved and not any(key in preserved for key in IDS)
assert all(row['execution']['schema'] == 'geometry-mutation-execution/1' for row in preserved.values())
OUT.mkdir()
(OUT / 'tools').mkdir()
(OUT / 'tmp').mkdir()
(OUT / 'cache').mkdir()
(OUT / 'ledger.json').write_bytes(old_raw)
for path in (Path(__file__), HELPER):
    shutil.copy2(path, OUT / 'tools' / path.name)
(OUT / 'tools/compare_original_bindings.py').write_text(BINDING_CODE)
spec = importlib.util.spec_from_file_location('unchanged_original_capture', HELPER)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
cleared = sorted(k for k in os.environ if k.startswith(('GEOMETRY_', 'GIT_')) or k in
                 ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'NODE_OPTIONS', 'PYTHONOPTIMIZE',
                  'LD_PRELOAD', 'MUTATE_RESULTS', 'MUTATE_CACHE'))
env = {k: v for k, v in os.environ.items() if k not in cleared}
env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
           TMPDIR=str(OUT / 'tmp'), GITHUB_SHA=S, GITHUB_WORKSPACE=str(ROOT),
           MUTATE_RESULTS=str(OUT / 'ledger.json'), MUTATE_CACHE=str(OUT / 'cache'))
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16777216, hard))
recorder = capture.Recorder(OUT, env, S)
report = {'schema': 'geo299316-ledger-environment-retry/1', 'source_sha': S,
          'repo': str(ROOT), 'started_utc': now(), 'steps': [], 'errors': [],
          'original_full_phase_receipt': str(ORIGINAL / 'receipt.json'),
          'original_full_phase_receipt_sha256': digest((ORIGINAL / 'receipt.json').read_bytes()),
          'original_full_phase_exit': 2, 'original_outer_exit': 1,
          'original_partial_ledger_sha256': digest(old_raw),
          'environment_failure': 'ENOSPC in fresh bridge checkout; original core phase completed before bridge baseline',
          'original_core_records_preserved': list(preserved), 'bridge_ids_to_retry': IDS,
          'new_cache': str(OUT / 'cache'), 'original_cache_modified': False,
          'cleared_environment_names': cleared, 'environment': {k: env.get(k) for k in
              ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'GITHUB_SHA', 'GITHUB_WORKSPACE',
               'MUTATE_RESULTS', 'MUTATE_CACHE', 'PYTHONOPTIMIZE', 'CC', 'CFLAGS', 'CPPFLAGS',
               'C_INCLUDE_PATH', 'CPATH', 'LIBRARY_PATH', 'LD_LIBRARY_PATH')},
          'platform': platform.platform(), 'python': sys.version, 'python_executable': sys.executable,
          'stack_before': [soft, hard], 'stack_during': resource.getrlimit(resource.RLIMIT_STACK),
          'tool_sha256': digest(Path(__file__).read_bytes()), 'original_capture_sha256': CAPTURE_SHA}


def save():
    pending = OUT / 'receipt.json.writing'
    pending.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    pending.replace(OUT / 'receipt.json')


def state():
    head = recorder.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=30)[1].decode().strip()
    status = recorder.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=ROOT, timeout=30)[1].decode()
    return {'head': head, 'status': status}


def run(label, command, cwd=ROOT, timeout=None):
    row, stdout, stderr = recorder.run(command, cwd=cwd, timeout=timeout, check=False,
        source_sha=S, source_variant='same-committed-source-environment-only-bridge-resumption')
    report['steps'].append({'label': label, 'original_command_result': row})
    save()
    return row, stdout, stderr


code = 1
save()
with LOCK.open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        report['source_before'] = state()
        assert report['source_before'] == {'head': S, 'status': ''}
        scratch = OUT / 'cache/_bridge-work' / S / 'repo'
        scratch.parent.mkdir(parents=True)
        preparations = [
            ('environment-clone', ['git', 'clone', '--shared', '--no-checkout', str(ROOT), str(scratch)], ROOT),
            ('environment-sparse', ['git', 'sparse-checkout', 'set', '--no-cone', '/*', '!/evidence/', '!/tests/evidence/', '!/tests/release-evidence/'], scratch),
            ('environment-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', S], scratch),
            ('source-oracle-bindings', [sys.executable, '-B', str(OUT / 'tools/compare_original_bindings.py'),
                                        str(ROOT), str(scratch), json.dumps(IDS), S], ROOT),
        ]
        for label, command, cwd in preparations:
            row, stdout, _ = run(label, command, cwd)
            assert row['actual_process_returncode'] == 0, label
            if label == 'source-oracle-bindings':
                report['original_source_oracle_bindings'] = json.loads(stdout)
        for label, command in (
                ('strict-precheck', ['python3', 'tests/mutate.py', '--check']),
                ('bridge-environment-retry', ['python3', 'tests/mutate.py', *IDS]),
                ('strict-checkafter', ['python3', 'tests/mutate.py', '--check'])):
            run(label, command)
        exits = {row['label']: row['original_command_result']['actual_process_returncode'] for row in report['steps']}
        assert exits['strict-precheck'] == 1 and exits['bridge-environment-retry'] == exits['strict-checkafter'] == 0, exits
        final = json.loads((OUT / 'ledger.json').read_text())
        assert all(final[key] == row for key, row in preserved.items())
        active = {key: row for key, row in final.items() if row['verdict'] != 'retired'}
        assert all(row.get('execution', {}).get('head') == S for row in active.values())
        counts = dict(collections.Counter(row['verdict'] for row in final.values()))
        assert not set(counts) - {'killed', 'equivalent', 'crashed', 'retired'}, counts
        report.update(records=len(final), executions_at_S=len(active), verdict_counts=counts,
                      original_core_records_byte_equivalent=True,
                      complete_regeneration_in_two_environment_phases=True,
                      single_full_command_passed=False)
        code = 0
    except BaseException:
        report['errors'].append(traceback.format_exc())
        code = 1
    finally:
        try:
            report['source_after'] = state()
            assert report['source_after'] == report['source_before']
            assert (ORIGINAL / 'ledger.json').read_bytes() == old_raw
            assert digest(Path(__file__).read_bytes()) == report['tool_sha256']
        except BaseException:
            report['errors'].append(traceback.format_exc())
            code = 1
        report.update(exit_code=code, ended_utc=now(), commands=recorder.rows,
                      ledger_sha256=digest((OUT / 'ledger.json').read_bytes()))
        save()
resource.setrlimit(resource.RLIMIT_STACK, (soft, hard))
print(json.dumps({'receipt': str(OUT / 'receipt.json'), 'exit_code': code, 'same_source_sha': S}, ensure_ascii=False))
raise SystemExit(code)
