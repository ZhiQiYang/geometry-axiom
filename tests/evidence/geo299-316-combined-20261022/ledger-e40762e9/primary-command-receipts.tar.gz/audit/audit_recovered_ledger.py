"""Independently audit the two environment phases without rewriting either original receipt."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess

S = 'e40762e99b078335d78c65a3a2682a0c9ab875d0'
ROOT = Path('/tmp/g261-next299316')
OLD = Path('/workspace/geo299316-ledger-regenerate-e40762e9')
NEW = Path('/workspace/geo299316-ledger-environment-retry-e40762e9-r2')
OUTER = Path('/workspace/geo299316-ledger-retry-outer/combined-ledger-bridge-env-retry-e40762e9-r2')
DEST = Path('/workspace/geo299316-work/ledger-recovery-terminal-audit.json')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def raw_records(raw):
    text = raw.decode()
    decoder = json.JSONDecoder()
    offset = 1
    records = {}
    while True:
        while text[offset].isspace():
            offset += 1
        if text[offset] == '}':
            return records
        key, offset = decoder.raw_decode(text, offset)
        while text[offset].isspace():
            offset += 1
        assert text[offset] == ':'
        offset += 1
        while text[offset].isspace():
            offset += 1
        beginning = offset
        _, offset = decoder.raw_decode(text, offset)
        records[key] = text[beginning:offset].encode()
        while text[offset].isspace():
            offset += 1
        if text[offset] == ',':
            offset += 1
        else:
            assert text[offset] == '}'


assert not DEST.exists()
old = json.loads((OLD / 'receipt.json').read_text())
new = json.loads((NEW / 'receipt.json').read_text())
outer = json.loads((OUTER / 'receipt.json').read_text())
assert [(step['label'], step['original_command_result']['actual_process_returncode'])
        for step in old['steps']] == [('precheck', 1), ('full-ledger', 2)]
assert old['exit_code'] == 1 and 'source_after' not in old
assert any('No space left on device' in error for error in old['errors'])
assert new['exit_code'] == outer['outer_process']['actual_process_returncode'] == 0
assert not new['errors']
assert new['source_before'] == new['source_after'] == {'head': S, 'status': ''}
assert new['complete_regeneration_in_two_environment_phases'] and not new['single_full_command_passed']
assert [(step['label'], step['original_command_result']['actual_process_returncode'])
        for step in new['steps']][-3:] == [('strict-precheck', 1), ('bridge-environment-retry', 0), ('strict-checkafter', 0)]
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == S
assert subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=ROOT) == b''
old_raw, new_raw = (OLD / 'ledger.json').read_bytes(), (NEW / 'ledger.json').read_bytes()
assert digest(old_raw) == new['original_partial_ledger_sha256']
assert digest(new_raw) == new['ledger_sha256']
old_records, final = json.loads(old_raw), json.loads(new_raw)
old_slices, final_slices = raw_records(old_raw), raw_records(new_raw)
preserved = {key: row for key, row in old_records.items() if row.get('execution', {}).get('head') == S}
core_checks = []
for key, row in preserved.items():
    assert row == final[key] and old_slices[key] == final_slices[key], key
    core_checks.append({'id': key, 'original_record_bytes': len(old_slices[key]),
                        'original_record_sha256': digest(old_slices[key]),
                        'recovered_record_sha256': digest(final_slices[key]), 'exact_record_bytes_equal': True})
active = {key: row for key, row in final.items() if row['verdict'] != 'retired'}
assert all(row.get('execution', {}).get('head') == S for row in active.values())
counts = dict(collections.Counter(row['verdict'] for row in final.values()))
assert not set(counts) - {'killed', 'equivalent', 'crashed', 'retired'}
bridges = {key: row for key, row in active.items()
           if row['execution']['schema'] == 'geometry-bridge-mutation-execution/1'}
assert set(bridges) == set(new['bridge_ids_to_retry'])
for row in bridges.values():
    evidence = row['execution']
    assert all(evidence[name]['exit_code'] == 0 for name in ('baseline_build', 'mutant_build', 'restored_build'))
    assert evidence['baseline']['exit_code'] == evidence['restored']['exit_code'] == 0
protected = {}
for relative in ('公理層.md', '決策佇列.md', 'BACKLOG.md'):
    raw = (ROOT / relative).read_bytes()
    expected = subprocess.check_output(['git', 'show', S + ':' + relative], cwd=ROOT)
    assert raw.replace(b'\r\n', b'\n') == expected.replace(b'\r\n', b'\n')
    protected[relative] = digest(raw.replace(b'\r\n', b'\n'))
report = {'schema': 'geo299316-recovered-ledger-terminal-audit/1', 'source_sha': S,
          'original_full_phase_exit': 2, 'original_outer_exit': 1,
          'original_source_after_and_checkafter_missing': True,
          'retry_bridge_exit': 0, 'strict_checkafter_exit': 0, 'retry_outer_exit': 0,
          'source_after_independently_observed_clean': True,
          'records': len(final), 'executions_at_S': len(active), 'verdict_counts': counts,
          'preserved_core_records': core_checks, 'bridge_executions': len(bridges),
          'restored_original_method_count': new['original_source_oracle_bindings']['restored_method_count'],
          'ledger_sha256': digest(new_raw), 'protected_sources_lf_sha256': protected,
          'single_full_command_passed': False, 'original_receipts_rewritten': False,
          'new_controls': {key: {field: final[key].get(field) for field in ('verdict', 'why', 'killed_by', 'crashed_on')}
                           for key in ('M89', 'M90', 'M91', 'M92', 'M93', 'M94', 'M95', 'M96', 'M97', 'M98')}}
DEST.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'audit': str(DEST), 'records': len(final), 'core_record_bytes_equal': len(core_checks),
                  'bridge_executions': len(bridges), 'verdicts': counts}, ensure_ascii=False))
