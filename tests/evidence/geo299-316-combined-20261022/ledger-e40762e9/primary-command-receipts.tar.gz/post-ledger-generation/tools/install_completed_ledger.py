"""Install the original completed combined ledger and archive its primary receipts."""
from pathlib import Path
import collections
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/g261-next299316')
WORK = Path('/workspace/geo299316-work')
S = 'e40762e99b078335d78c65a3a2682a0c9ab875d0'
ORIGINAL = Path('/workspace/geo299316-ledger-regenerate-e40762e9')
ORIGINAL_OUTER = Path('/workspace/geo299316-ledger-outer/combined-ledger-s-e40762e9')
INNER = Path('/workspace/geo299316-ledger-environment-retry-e40762e9-r2')
OUTER = Path('/workspace/geo299316-ledger-retry-outer/combined-ledger-bridge-env-retry-e40762e9-r2')
GENERATION = Path('/workspace/geo299316-post-ledger-generation-e40762e9')
DEST = ROOT / 'tests/evidence/geo299-316-combined-20261022/ledger-e40762e9'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, capture_output=True)
    assert result.returncode == 0, (args, result.stderr)
    return result.stdout


assert not GENERATION.exists() and not DEST.exists()
assert git('rev-parse', 'HEAD').decode().strip() == S
assert git('status', '--porcelain=v1', '--untracked-files=all') == b''
inner = json.loads((INNER / 'receipt.json').read_text())
outer = json.loads((OUTER / 'receipt.json').read_text())
assert inner['exit_code'] == outer['outer_process']['actual_process_returncode'] == 0
assert not inner['errors']
assert inner['source_before'] == inner['source_after'] == {'head': S, 'status': ''}
steps = [(row['label'], row['original_command_result']['actual_process_returncode'])
         for row in inner['steps']]
assert steps[-3:] == [('strict-precheck', 1), ('bridge-environment-retry', 0), ('strict-checkafter', 0)]
original_receipt = json.loads((ORIGINAL / 'receipt.json').read_text())
assert [(row['label'], row['original_command_result']['actual_process_returncode'])
        for row in original_receipt['steps']] == [('precheck', 1), ('full-ledger', 2)]
assert original_receipt['exit_code'] == 1 and any('No space left on device' in e for e in original_receipt['errors'])
assert inner['complete_regeneration_in_two_environment_phases'] and not inner['single_full_command_passed']
original = (INNER / 'ledger.json').read_bytes()
assert sha(original) == inner['ledger_sha256']
ledger = json.loads(original)
counts = dict(collections.Counter(row['verdict'] for row in ledger.values()))
assert not set(counts) - {'killed', 'equivalent', 'crashed', 'retired'}, counts
executed = {key: row for key, row in ledger.items() if row['verdict'] != 'retired'}
assert all(row['execution']['head'] == S for row in executed.values())
for row in executed.values():
    evidence = row['execution']
    if evidence['schema'] == 'geometry-mutation-execution/1':
        assert evidence['compile_exit_code'] == 0
    else:
        assert evidence['schema'] == 'geometry-bridge-mutation-execution/1'
        assert all(evidence[name]['exit_code'] == 0 for name in ('baseline_build', 'mutant_build', 'restored_build'))
assert all(key in ledger for key in ('M89', 'M90', 'M91', 'M92', 'M93', 'M94', 'M95', 'M96', 'M97', 'M98'))
protected = {name: (ROOT / name).read_bytes() for name in ('公理層.md', '決策佇列.md', 'BACKLOG.md')}
GENERATION.mkdir()
(GENERATION / 'tools').mkdir()
(GENERATION / 'tmp').mkdir()
for source in (Path(__file__), WORK / 'record_command.py'):
    shutil.copy2(source, GENERATION / 'tools' / source.name)
(ROOT / 'tests/mutants_results.json').write_bytes(original)
ignore = ROOT / '.gitignore'
before_ignore = ignore.read_bytes()
allow = b'!/evidence/geo299-316-final-*/\n'
assert allow not in before_ignore and before_ignore.endswith(b'\n')
ignore.write_bytes(before_ignore + allow)
canonical = ROOT / 'geometry-guide/公理層-閱讀器.html'
canonical_before = canonical.read_bytes()
commands = []
for label, command in (
        ('canonical-sync', ['python3', '-B', 'geometry-guide/sync_axiom_reader.py']),
        ('canonical-check', ['python3', '-B', 'geometry-guide/sync_axiom_reader.py', '--check']),
        ('reader-full', ['python3', '-B', 'tests/test_axiom_reader.py']),
        ('installed-ledger-check', ['env', 'MUTATE_CACHE=' + str(INNER / 'cache'), 'python3', '-B', 'tests/mutate.py', '--check'])):
    argv = [sys.executable, '-B', str(WORK / 'record_command.py'), str(GENERATION / label), *command]
    result = subprocess.run(argv, capture_output=True, env=dict(os.environ, TMPDIR=str(GENERATION / 'tmp')))
    (GENERATION / (label + '.launcher.stdout')).write_bytes(result.stdout)
    (GENERATION / (label + '.launcher.stderr')).write_bytes(result.stderr)
    commands.append({'command': argv, 'actual_process_returncode': result.returncode})
(GENERATION / 'commands.json').write_text(json.dumps(commands, ensure_ascii=False, indent=2) + '\n')
assert all(row['actual_process_returncode'] == 0 for row in commands), commands
assert git('rev-parse', 'HEAD').decode().strip() == S
assert (ROOT / 'tests/mutants_results.json').read_bytes() == original
assert all((ROOT / name).read_bytes() == raw for name, raw in protected.items())
allowed = {'.gitignore', 'tests/mutants_results.json', 'geometry-guide/公理層-閱讀器.html'}
changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) - {''}
assert changed <= allowed, changed
DEST.mkdir(parents=True)
archive = DEST / 'primary-command-receipts.tar.gz'
entries = []
for label, base in (('original-full-phase', ORIGINAL), ('original-outer', ORIGINAL_OUTER),
                    ('environment-retry', INNER), ('retry-outer', OUTER),
                    ('collector-order-preflight', Path('/workspace/geo299316-ledger-environment-retry-e40762e9')),
                    ('collector-order-preflight-outer', Path('/workspace/geo299316-ledger-retry-outer/combined-ledger-bridge-env-retry-e40762e9')),
                    ('cloud-capacity-repair', Path('/tmp/geo261-cold-main-clone-release')),
                    ('post-enospc-read-only-observation', Path('/tmp/geo299316-ledger-environment-red-e40762e9'))):
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if path.is_file() and relative.parts[0] not in ('tmp', 'cache'):
            entries.append((label + '/' + relative.as_posix(), path))
for path in sorted(GENERATION.rglob('*')):
    if path.is_file():
        entries.append(('post-ledger-generation/' + path.relative_to(GENERATION).as_posix(), path))
entries.append(('audit/ledger-recovery-terminal-audit.json', WORK / 'ledger-recovery-terminal-audit.json'))
entries.append(('audit/audit_recovered_ledger.py', WORK / 'audit_recovered_ledger.py'))
members = []
with tarfile.open(archive, 'w:gz', compresslevel=6) as handle:
    for name, path in entries:
        raw = path.read_bytes()
        members.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw)})
        handle.add(path, arcname=name, recursive=False)
assert archive.stat().st_size < 95 * 1024 * 1024
with tarfile.open(archive) as handle:
    for entry, expected in zip(handle.getmembers(), members, strict=True):
        raw = handle.extractfile(entry).read()
        assert entry.name == expected['path'] and len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
(DEST / 'MEMBER_INVENTORY.json').write_text(json.dumps({'archive': archive.name, 'bytes': archive.stat().st_size,
    'sha256': sha(archive.read_bytes()), 'members': members}, ensure_ascii=False, indent=2) + '\n')
new = {key: {field: ledger[key].get(field) for field in ('verdict', 'why', 'killed_by', 'crashed_on')}
       for key in ('M89', 'M90', 'M91', 'M92', 'M93', 'M94', 'M95', 'M96', 'M97', 'M98')}
summary = {'schema': 'geo299316-installed-ledger-primary/1', 'execution_source_sha': S,
    'environment_retry_steps': steps, 'environment_retry_inner_exit': inner['exit_code'], 'environment_retry_outer_exit': outer['outer_process']['actual_process_returncode'],
    'original_full_phase_exit': 2, 'original_outer_exit': 1, 'original_source_after_missing_due_to_ENOSPC': True,
    'original_source_after_observed_separately': '/tmp/geo299316-ledger-environment-red-e40762e9',
    'complete_regeneration_in_two_environment_phases': True, 'single_full_command_passed': False,
    'cloud_capacity_repair': '/tmp/geo261-cold-main-clone-release/receipt.json',
    'ledger_sha256': sha(original), 'records': len(ledger), 'executions_at_S': len(executed), 'verdict_counts': counts,
    'new_controls': new, 'canonical_changed': canonical.read_bytes() != canonical_before,
    'canonical_before_sha256': sha(canonical_before), 'canonical_after_sha256': sha(canonical.read_bytes()),
    'post_ledger_commands': commands, 'primary_archive_members': len(members), 'primary_archive_bytes': archive.stat().st_size,
    'large_temporary_build_raw_published': False,
    'scope': '完整原top-level命令stdout/stderr、環境、SHA、ledger structured executions已封；tmp內bridge build/test raw另補。原工具刪除暫存mutant C，且core內層未全部落盤，不冒稱逐core內層原stdout均保存。'}
(DEST / 'SUMMARY.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(DEST / 'PROGRESS.md').write_text(f'''# #299+#316 整份突變帳本與追溯同步

本輪帳本來源 S：`{S}`。原整份 `python3 tests/mutate.py` 真退出 2，外層真退出 1：67 個 core execution 已完成，但 fresh bridge checkout 因雲端 workspace ENOSPC 受阻；原 checkafter 與 source_after 錄製未能開始，原缺項保留。另行只讀 HEAD／status／diff 證明來源仍是 S 且乾淨，沒有補寫原收據。

修好容量後，同 S 以全新 private cache 只環境重跑原 18 個 bridge IDs，原命令真 0；其後原 strict `python3 tests/mutate.py --check` 真 0，環境重試外層 subreaper 真 0。新 scratch 僅 sparse 排除已公開 evidence，其 C include closure、原完整 Python／scene oracle hashes、原工具 bytes 與原 RESTORED 方法名單均核同。原 67 個 core 紀錄逐值保留，沒有改 execution SHA／挑綠重跑；這是兩個環境 phase 完成整份重產，不能稱單次原 full 命令退出 0。

帳本 {len(ledger)} 筆，{len(executed)} 筆實跑 `execution.head` 全為 S；原 verdict 分布為 `{counts}`，M20 crashed 與 killed 分欄。新 M89–M98 的原 verdict／why／killed_by 完整見 SUMMARY.json；未將保存帳本的提交冒成其實跑來源。

將原 ledger bytes 安裝後，僅以原同步器重建唯一正典，再跑原 `--check`、完整 reader suite 與安裝後原 `mutate.py --check`，各真 0；是否改變 HTML bytes 見 SUMMARY.json。公理層、決策佇列、BACKLOG bytes 全保留。

封包保存原 primary 指令、退出碼、完整 stdout／stderr、安全環境、SHA、原工具、collector 順序前置失敗、追溯生成 Git patch，以及三個已公開乾淨舊比較 clone 的雲端容量修復完整命令／guard／每檔 hash／空間前後收據；每個 member 已逐 bytes／SHA256 核同。tmp 內大量 build／test raw 另補；原 core 內層未落盤 streams 不冒稱已保存。

下一步：一般推送帳本保存提交 L；在 L 以 Linux 重產架構 manifest／scan／report／receipt 四檔及三條原裁判，然後固定正式驗收 F。
''', encoding='utf-8')
files = [path for path in sorted(DEST.rglob('*')) if path.is_file()]
(DEST / 'SHA256SUMS').write_text(''.join(sha(path.read_bytes()) + '  ' + path.relative_to(DEST).as_posix() + '\n' for path in files))
print(json.dumps({'destination': str(DEST), **summary}, ensure_ascii=False, indent=2))
