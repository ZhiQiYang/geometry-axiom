"""Materialize only three already-tracked sparse fixtures, preserving their original Git bytes."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(sys.argv[1])
EXPECTED_HEAD = sys.argv[2]
OUT = Path(sys.argv[3])
SOURCE = '2bd45fc9413397637cd0c56c39ac2b6704806d72'
PATHS = ('tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
         'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
         'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas')
OUT.mkdir(parents=True, exist_ok=False)

def git(label, args):
    command = ['git', *args]
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    (OUT / (label + '.json')).write_text(json.dumps({'command': command, 'cwd': str(ROOT), 'exit': result.returncode}) + '\n')
    assert result.returncode == 0
    return result.stdout

assert git('before-head', ['rev-parse', 'HEAD']).decode().strip() == EXPECTED_HEAD
assert git('before-status', ['status', '--porcelain']) == b''
git('before-sparse-flags', ['ls-files', '-v', '--', *PATHS])
records = []
for number, relative in enumerate(PATHS):
    old_oid = git(f'{number}-source-oid', ['rev-parse', SOURCE + ':' + relative]).decode().strip()
    current_oid = git(f'{number}-head-oid', ['rev-parse', EXPECTED_HEAD + ':' + relative]).decode().strip()
    assert old_oid == current_oid
    body = git(f'{number}-blob', ['show', SOURCE + ':' + relative])
    target = ROOT / relative
    if target.exists():
        assert target.read_bytes() == body, 'Preserve any unexpectedly different fixture; never overwrite it.'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    assert target.read_bytes() == body
    records.append({'path': relative, 'source_sha': SOURCE, 'head_sha': EXPECTED_HEAD,
                    'blob_oid': old_oid, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
git('clear-skip-worktree', ['update-index', '--no-skip-worktree', '--', *PATHS])
git('after-sparse-flags', ['ls-files', '-v', '--', *PATHS])
assert git('after-status', ['status', '--porcelain']) == b''
assert git('after-head', ['rev-parse', 'HEAD']).decode().strip() == EXPECTED_HEAD
(OUT / 'materialization.json').write_text(json.dumps({'source': SOURCE, 'worktree_head': EXPECTED_HEAD,
    'fixtures': records, 'versioned_bytes_changed': False, 'worktree_clean': True,
    'scope': 'Only already-tracked exact blobs; no fixture version is committed.'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'repo': str(ROOT), 'sha': EXPECTED_HEAD, 'materialized': len(records), 'bytes': sum(row['bytes'] for row in records)}, ensure_ascii=False))
