"""Prove the canonical regeneration with unchanged original reader assertions."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/tmp/g261-next299316')
WORK = Path('/workspace/geo299316-work')
P = 'e4557b3f5fab70d70ebb44cd5489cd8841bb3670'
RELATIVE = 'geometry-guide/公理層-閱讀器.html'
OUT = WORK / 'reader-reversion-proof-01'
OUT.mkdir(exist_ok=False)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == P
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
target = ROOT / RELATIVE
fixed = target.read_bytes()
assert fixed == subprocess.check_output(['git', 'show', P + ':' + RELATIVE], cwd=ROOT)
commands = []

def run(label, *selectors):
    command = [sys.executable, '-B', str(WORK / 'run_repair_suite.py'), label, 'reader', *selectors]
    result = subprocess.run(command, capture_output=True)
    commands.append({'command': command, 'exit': result.returncode,
                     'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
    return result.returncode

assert run('reader-fixed-baseline-01') == 0
baseline_stderr = (WORK / 'reader-fixed-baseline-01/command.stderr').read_text()
assert 'Ran 51 tests' in baseline_stderr and baseline_stderr.rstrip().endswith('OK')
old_command = ['git', 'show', '2bd45fc9413397637cd0c56c39ac2b6704806d72:' + RELATIVE]
old = subprocess.run(old_command, cwd=ROOT, capture_output=True)
(OUT / 'old-canonical.stdout').write_bytes(old.stdout)
(OUT / 'old-canonical.stderr').write_bytes(old.stderr)
(OUT / 'old-canonical.json').write_text(json.dumps({'command': old_command, 'exit': old.returncode}) + '\n')
assert old.returncode == 0 and old.stdout != fixed
try:
    target.write_bytes(old.stdout)
    reverted = run('reader-reverted-canonical-01',
                   'CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews')
finally:
    target.write_bytes(fixed)
assert reverted == 1
stderr = (WORK / 'reader-reverted-canonical-01/command.stderr').read_text()
assert 'Ran 1 test' in stderr and 'FAILED (failures=1)' in stderr
assert 'AssertionError:' in stderr and 'ERROR:' not in stderr
assert run('reader-fixed-restored-01') == 0
assert 'Ran 51 tests' in (WORK / 'reader-fixed-restored-01/command.stderr').read_text()
assert target.read_bytes() == fixed
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
(OUT / 'proof.json').write_text(json.dumps({'source_sha': P, 'baseline_exit': 0,
    'reverted_exit': reverted, 'restored_exit': 0, 'baseline_and_restored_scope': 'original full 51 cases',
    'reverted_scope': 'original CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews',
    'changed_only': RELATIVE, 'fixed_sha256': hashlib.sha256(fixed).hexdigest(),
    'reverted_sha256': hashlib.sha256(old.stdout).hexdigest(), 'commands': commands,
    'protected_inputs_unchanged': ['公理層.md', '決策佇列.md', 'BACKLOG.md']}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_sha': P, 'baseline': 0, 'reverted': reverted, 'restored': 0}))
