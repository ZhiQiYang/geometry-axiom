"""Diagnostic adapter: set only official binaries.OUT_DIR, then run the original aggregate."""
from pathlib import Path
import os
import runpy
import sys

root = Path('/workspace/g299316-native-e2bd')
sys.path.insert(0, str(root / 'tests'))
import binaries
binaries.OUT_DIR = Path(os.environ['GEO299316_NATIVE_CACHE'])
sys.argv = [str(root / 'tests/run_all.py'), '--build']
runpy.run_path(str(root / 'tests/run_all.py'), run_name='__main__')
