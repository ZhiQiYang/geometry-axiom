"""Record one complete, original combined native diagnostic in a detached private worktree."""
from pathlib import Path
import hashlib
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path('/workspace/g299316-native-e2bd')
WORK = Path('/workspace/geo299316-work')
OUT = Path('/workspace/geo299316-native-20261022-e2bd')
SHA = '2bd45fc9413397637cd0c56c39ac2b6704806d72'
OUT.mkdir(exist_ok=False)
CACHE = OUT / 'cache'
TMP = OUT / 'tmp'
CACHE.mkdir()
TMP.mkdir()

def git(label, args):
    command = ['git', *args]
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    (OUT / (label + '.json')).write_text(json.dumps({'command': command, 'cwd': str(ROOT), 'exit': result.returncode}) + '\n')
    assert result.returncode == 0
    return result.stdout

assert git('before-head', ['rev-parse', 'HEAD']).decode().strip() == SHA
assert git('before-status', ['status', '--porcelain']) == b''
assert git('before-patch', ['diff', '--binary', 'HEAD']) == b''
ledger = ROOT / 'tests/mutants_results.json'
(OUT / 'ledger-before.json').write_bytes(ledger.read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('GEOMETRY_') or name in ('MUTATE_RESULTS', 'MUTATE_CACHE', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE'):
        env.pop(name)
env.update({'TMPDIR': str(TMP), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1',
            'PYTHONIOENCODING': 'utf-8', 'GITHUB_SHA': SHA, 'GITHUB_WORKSPACE': str(ROOT),
            'GEO299316_NATIVE_CACHE': str(CACHE), 'GEO299316_EXECUTION_LOG': str(OUT / 'native-executions.jsonl'),
            'GEO261_REAPER_LOG': str(OUT / 'reaper.jsonl')})
stack_before = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16777216, stack_before[1]))
adapter = WORK / 'native_adapter.py'
reaper = Path('/workspace/geo261-environment/reap_children.py')
command = ['python3', '-B', str(adapter)]
actual = [sys.executable, '-B', str(reaper), *command]
receipt = {'schema': 'geo299316-complete-native-diagnostic/1', 'sha': SHA, 'cwd': str(ROOT),
           'command': command, 'original_argv': ['python3', '-B', str(ROOT / 'tests/run_all.py'), '--build'],
           'reaper_command': actual, 'adapter_scope': 'Only official binaries.OUT_DIR is set to the private cache before runpy; original suite/expected/assertions are unchanged and no suite is skipped.',
           'sparse_checkout': 'Only /evidence/ and /tests/evidence/ excluded; complete architecture roots preserved.',
           'ledger_scope': 'Original run_all forces MUTATE_RESULTS to this detached copy tests/mutants_results.json; its before/after raw bytes and resulting dirty patch are preserved. Primary combined branch ledger is not touched.',
           'stack_before': stack_before, 'stack_during': resource.getrlimit(resource.RLIMIT_STACK),
           'python': sys.version, 'platform': platform.platform(), 'started_epoch': time.time(),
           'environment': {key: env.get(key) for key in ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS',
             'GITHUB_SHA', 'GITHUB_WORKSPACE', 'PYTHONOPTIMIZE', 'PYTHONDONTWRITEBYTECODE', 'PYTHONIOENCODING',
             'GEO299316_NATIVE_CACHE', 'GEO299316_EXECUTION_LOG', 'GEO261_REAPER_LOG')},
           'actual_process_returncode': None}
tools = OUT / 'tools'
tools.mkdir()
for source in (Path(__file__), adapter, reaper):
    shutil.copy2(source, tools / source.name)
for label, argv in [('python-version', ['python3', '--version']), ('compiler-version', [os.environ.get('CC', 'cc'), '--version']),
                    ('node-version', ['node', '--version']), ('chrome-version', ['google-chrome', '--version'])]:
    result = subprocess.run(argv, capture_output=True, env=env)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    (OUT / (label + '.json')).write_text(json.dumps({'command': argv, 'exit': result.returncode}) + '\n')
(OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'command.stdout').open('wb') as stdout, (OUT / 'command.stderr').open('wb') as stderr:
    result = subprocess.run(actual, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
(OUT / 'ledger-after.json').write_bytes(ledger.read_bytes())
receipt.update({'actual_process_returncode': result.returncode, 'ended_epoch': time.time(),
                'head_after': git('after-head', ['rev-parse', 'HEAD']).decode().strip(),
                'status_after': git('after-status', ['status', '--porcelain']).decode(),
                'patch_after_sha256': hashlib.sha256(git('after-patch', ['diff', '--binary', 'HEAD'])).hexdigest(),
                'stdout_sha256': hashlib.sha256((OUT / 'command.stdout').read_bytes()).hexdigest(),
                'stderr_sha256': hashlib.sha256((OUT / 'command.stderr').read_bytes()).hexdigest(),
                'ledger_before_sha256': hashlib.sha256((OUT / 'ledger-before.json').read_bytes()).hexdigest(),
                'ledger_after_sha256': hashlib.sha256((OUT / 'ledger-after.json').read_bytes()).hexdigest()})
(OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
members = []
with tarfile.open(OUT / 'private-cache-all-bytes.raw.tar.gz', 'w:gz', compresslevel=6) as tar:
    for source in sorted(CACHE.rglob('*')):
        if source.is_file() and not source.is_symlink():
            body = source.read_bytes()
            name = source.relative_to(CACHE).as_posix()
            members.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
            tar.add(source, arcname=name, recursive=False)
(OUT / 'private-cache-all-bytes.inventory.json').write_text(json.dumps(members, indent=2) + '\n')
print(json.dumps({'out': str(OUT), 'sha': SHA, 'actual_process_returncode': result.returncode}))
sys.exit(result.returncode)
