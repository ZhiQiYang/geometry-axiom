"""Run the unchanged selected test entry, freezing all private NativeBuild bytes before atexit."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys
import tarfile

target = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(target.parents[1]))
sys.argv = [str(target), *sys.argv[2:]]
try:
    runpy.run_path(str(target), run_name='__main__')
finally:
    scratch = Path(os.environ['TMPDIR']).resolve()
    output = Path(os.environ['GEO299316_RECORD_OUT']).resolve()
    inventory = []
    with tarfile.open(output / 'native-build-all-bytes.raw.tar.gz', 'w:gz', compresslevel=6) as archive:
        for source in sorted(scratch.rglob('*')):
            if source.is_symlink() or not source.is_file():
                continue
            body = source.read_bytes()
            name = source.relative_to(scratch).as_posix()
            inventory.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
            archive.add(source, arcname=name, recursive=False)
    (output / 'native-build-all-bytes.inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
