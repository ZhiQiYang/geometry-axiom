"""Prepare/run one authorized Node environment retry on the original detached E2bd.

CLI (run only after the parent releases the performance window):
  python3 -B /workspace/geo299316-work/run_node_environment_retry.py \
    --out /workspace/geo299316-node-environment-retry-e2bd-001

No fixture is materialized here. The caller must first restore the three exact
already-tracked blobs. The only adapter assignment is official binaries.OUT_DIR;
the original run_all argv, suite, expected counts, freshness and assertions run.
"""
from pathlib import Path
import argparse
import fcntl
import hashlib
import json
import os
import platform
import resource
import runpy
import shutil
import subprocess
import sys
import tarfile
import time
import traceback


ROOT = Path('/workspace/g299316-native-e2bd')
SHA = '2bd45fc9413397637cd0c56c39ac2b6704806d72'
ORIGIN_CACHE = Path('/workspace/geo299316-native-20261022-e2bd/cache')
LOCK = Path('/workspace/geo299316-work/private-diagnostics.lock')
REAPER = Path('/workspace/geo261-environment/reap_children.py')
FIXTURES = (
    'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas',
)
ENV_NAMES = (
    'PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS',
    'GITHUB_SHA', 'GITHUB_WORKSPACE', 'PYTHONOPTIMIZE', 'PYTHONDONTWRITEBYTECODE',
    'PYTHONIOENCODING', 'GEO299316_NODE_RETRY_CACHE', 'GEO261_REAPER_LOG',
)
OUTPUT_FOR_EXCEPTION = None


def digest(body):
    return hashlib.sha256(body).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def adapter():
    """Only configure the official cache path, then run the original entry."""
    sys.path.insert(0, str(ROOT / 'tests'))
    import binaries
    binaries.OUT_DIR = Path(os.environ['GEO299316_NODE_RETRY_CACHE'])
    sys.argv = [str(ROOT / 'tests/run_all.py'), '--build', '--only', 'node:tests-js']
    runpy.run_path(str(ROOT / 'tests/run_all.py'), run_name='__main__')


def main():
    global OUTPUT_FOR_EXCEPTION
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--out', type=Path, required=True, help='A new external evidence directory; must not exist.')
    parser.add_argument('--no-copy-cache', action='store_true', help='Let the original --build create its own binaries instead of copying the original private cache.')
    args = parser.parse_args()
    output = args.out.resolve()
    if output == ROOT or ROOT in output.parents or output == ORIGIN_CACHE or ORIGIN_CACHE in output.parents:
        parser.error('--out must be outside the original source and original cache')
    if output == Path('/tmp/geometry-tests') or Path('/tmp/geometry-tests') in output.parents:
        parser.error('--out must not use the shared /tmp/geometry-tests cache')
    output.mkdir(parents=True, exist_ok=False)
    OUTPUT_FOR_EXCEPTION = output
    cache, scratch = output / 'cache', output / 'tmp'
    cache.mkdir()
    scratch.mkdir()
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith('GEOMETRY_') or name in ('MUTATE_RESULTS', 'MUTATE_CACHE', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE'):
            environment.pop(name)
    environment.update({
        'PATH': '/workspace/geo261-environment/bin:' + environment['PATH'],
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TMPDIR': str(scratch),
        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8',
        'GITHUB_SHA': SHA, 'GITHUB_WORKSPACE': str(ROOT),
        'GEO299316_NODE_RETRY_CACHE': str(cache),
        'GEO261_REAPER_LOG': str(output / 'reaper.jsonl'),
    })
    sequence = 0

    def command(label, argv):
        nonlocal sequence
        sequence += 1
        folder = output / 'commands' / ('%03d-' % sequence + label)
        folder.mkdir(parents=True)
        started = time.time()
        result = subprocess.run(argv, cwd=ROOT, env=environment, capture_output=True)
        (folder / 'stdout.bin').write_bytes(result.stdout)
        (folder / 'stderr.bin').write_bytes(result.stderr)
        write_json(folder / 'command.json', {
            'command': argv, 'cwd': str(ROOT), 'exit': result.returncode,
            'started_epoch': started, 'ended_epoch': time.time(),
            'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr),
        })
        return result

    def git(label, arguments):
        result = command(label, ['git', *arguments])
        if result.returncode:
            raise RuntimeError('Read-only Git command failed: ' + label)
        return result.stdout

    receipt = {
        'schema': 'geo299316-node-environment-retry/1', 'sha': SHA, 'cwd': str(ROOT),
        'original_argv': ['python3', '-B', str(ROOT / 'tests/run_all.py'), '--build', '--only', 'node:tests-js'],
        'suite_scope': 'Only original node:tests-js; this partial environment retry is not complete native acceptance.',
        'adapter_scope': 'Only official binaries.OUT_DIR is assigned; original --build/freshness, suite, expected counts and assertions are unchanged.',
        'lock': str(LOCK), 'started_epoch': time.time(), 'stage': 'waiting-for-private-diagnostics-lock',
        'environment': {name: environment.get(name) for name in ENV_NAMES},
        'actual_process_returncode': None, 'runner_error': None,
        'terminal_tool_exit_code': None,
        'terminal_scope': 'Only the invoking exec tool can report its terminal status; this recorder never invents it.',
        'fixture_materialization': 'None: the parent materializes exact tracked blobs separately; this runner only verifies bytes.',
    }
    write_json(output / 'receipt.json', receipt)
    result_code = None
    runner_error = None
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        receipt['lock_acquired_epoch'] = time.time()
        try:
            receipt['stage'] = 'preflight'
            before_head = git('before-head', ['rev-parse', 'HEAD']).decode().strip()
            before_status = git('before-status', ['status', '--porcelain']).decode()
            before_patch = git('before-patch', ['diff', '--binary', 'HEAD'])
            receipt.update(head_before=before_head, status_before=before_status, patch_before_sha256=digest(before_patch))
            if before_head != SHA or before_status or before_patch:
                raise RuntimeError('Original detached E2bd must have the exact clean tracked source before retry.')
            git('fixture-index-flags', ['ls-files', '-v', '--', *FIXTURES])
            fixture_records = []
            for number, relative in enumerate(FIXTURES):
                expected = git('fixture-%d-original-blob' % number, ['show', SHA + ':' + relative])
                path = ROOT / relative
                if not path.is_file():
                    raise RuntimeError('Required sparse fixture has not been materialized: ' + relative)
                actual = path.read_bytes()
                if actual != expected:
                    raise RuntimeError('Materialized fixture differs from the original tracked blob: ' + relative)
                fixture_records.append({'path': relative, 'bytes': len(actual), 'sha256': digest(actual), 'source_sha': SHA})
            write_json(output / 'fixtures-before.json', fixture_records)
            ledger = ROOT / 'tests/mutants_results.json'
            (output / 'ledger-before.json').write_bytes(ledger.read_bytes())
            tools = output / 'tools'
            tools.mkdir()
            for source in (Path(__file__), REAPER, ROOT / 'tests/run_all.py', ROOT / 'tests/binaries.py'):
                shutil.copy2(source, tools / source.name)
            write_json(output / 'tools.json', [
                {'path': str(path.relative_to(output)), 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
                for path in sorted(tools.iterdir())
            ])
            copied = []
            if not args.no_copy_cache:
                for sidecar in sorted(ORIGIN_CACHE.glob('*.fingerprint.json')):
                    metadata = json.loads(sidecar.read_text())
                    executable = metadata['exe']
                    if Path(executable).name != executable or sidecar.name != executable + '.fingerprint.json':
                        raise RuntimeError('Unexpected original cache filename: ' + str(sidecar))
                    for source in (ORIGIN_CACHE / executable, sidecar):
                        if not source.is_file() or source.is_symlink():
                            raise RuntimeError('Original private cache input is not a regular file: ' + str(source))
                        body = source.read_bytes()
                        before = source.stat()
                        target = cache / source.name
                        shutil.copy2(source, target)
                        if target.read_bytes() != body or source.read_bytes() != body:
                            raise RuntimeError('Cache changed during copy2: ' + str(source))
                        copied.append({'source': str(source), 'destination': str(target), 'bytes': len(body),
                                       'sha256': digest(body), 'source_mtime_ns': before.st_mtime_ns,
                                       'destination_mtime_ns': target.stat().st_mtime_ns,
                                       'freshness': 'Not accepted by this copy: original run_all --build must still inspect/rebuild.'})
            write_json(output / 'cache-copy.json', copied)
            stack = resource.getrlimit(resource.RLIMIT_STACK)
            resource.setrlimit(resource.RLIMIT_STACK, (16777216, stack[1]))
            receipt.update(stack_before=stack, stack_during=resource.getrlimit(resource.RLIMIT_STACK),
                           python=sys.version, platform=platform.platform())
            for label, argv in (
                ('python-version', ['python3', '--version']), ('node-version', ['node', '--version']),
                ('compiler-version', [environment.get('CC', 'cc'), '--version']),
                ('chrome-version', ['google-chrome', '--version']),
            ):
                version = command(label, argv)
                if label == 'node-version' and (version.returncode or not version.stdout.decode().strip().startswith('v24.')):
                    raise RuntimeError('The cloud retry requires the configured Node 24 environment.')
            invocation = ['python3', '-B', str(tools / Path(__file__).name), '--adapter']
            actual = [sys.executable, '-B', str(REAPER), *invocation]
            receipt.update(command=invocation, reaper_command=actual, stage='running-original-node-suite')
            write_json(output / 'receipt.json', receipt)
            with (output / 'command.stdout').open('wb') as stdout, (output / 'command.stderr').open('wb') as stderr:
                result = subprocess.run(actual, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
            result_code = result.returncode
            receipt.update(actual_process_returncode=result_code, stage='original-node-suite-complete')
        except BaseException as error:
            runner_error = {'type': type(error).__name__, 'message': str(error)}
            (output / 'runner-error.stderr').write_text(traceback.format_exc(), encoding='utf-8')
        finally:
            receipt['runner_error'] = runner_error
            try:
                receipt.update(head_after=git('after-head', ['rev-parse', 'HEAD']).decode().strip(),
                               status_after=git('after-status', ['status', '--porcelain']).decode(),
                               patch_after_sha256=digest(git('after-patch', ['diff', '--binary', 'HEAD'])))
                ledger = ROOT / 'tests/mutants_results.json'
                (output / 'ledger-after.json').write_bytes(ledger.read_bytes())
                write_json(output / 'fixtures-after.json', [
                    {'path': relative, 'bytes': (ROOT / relative).stat().st_size,
                     'sha256': digest((ROOT / relative).read_bytes()), 'source_sha': SHA}
                    for relative in FIXTURES if (ROOT / relative).is_file()
                ])
            except BaseException as error:
                receipt['after_capture_error'] = {'type': type(error).__name__, 'message': str(error)}
                (output / 'after-capture-error.stderr').write_text(traceback.format_exc(), encoding='utf-8')
            receipt['ended_epoch'] = time.time()
            for name in ('command.stdout', 'command.stderr', 'ledger-before.json', 'ledger-after.json'):
                path = output / name
                if path.exists():
                    receipt[name + '_sha256'] = digest(path.read_bytes())
            receipt['source_clean_after'] = (receipt.get('head_after') == SHA and receipt.get('status_after') == ''
                                              and receipt.get('patch_after_sha256') == digest(b''))
            if (output / 'fixtures-before.json').exists() and (output / 'fixtures-after.json').exists():
                receipt['fixtures_unchanged_after'] = (json.loads((output / 'fixtures-before.json').read_text())
                                                        == json.loads((output / 'fixtures-after.json').read_text()))
            receipt['runner_intended_exit_code'] = (1 if runner_error or receipt.get('after_capture_error')
                                                     or not receipt.get('source_clean_after')
                                                     or not receipt.get('fixtures_unchanged_after', False)
                                                     else result_code if result_code is not None else 1)
            write_json(output / 'receipt.json', receipt)
            suite_logs = cache / 'run_all-logs'
            if suite_logs.exists():
                shutil.copytree(suite_logs, output / 'suite-logs')
            fingerprints = output / 'fingerprints'
            fingerprints.mkdir()
            identities = []
            for sidecar in sorted(cache.glob('*.fingerprint.json')):
                shutil.copy2(sidecar, fingerprints / sidecar.name)
                metadata = json.loads(sidecar.read_text())
                executable = cache / metadata['exe']
                if executable.is_file():
                    identities.append({'path': str(executable), 'bytes': executable.stat().st_size,
                                       'sha256': digest(executable.read_bytes()), 'mtime_ns': executable.stat().st_mtime_ns,
                                       'excluded_reason': 'Rebuildable ELF: preserve identity, not executable bytes in the evidence archive.'})
            write_json(output / 'binary-identities.json', identities)
            selection = {'excluded_subtrees': ['cache', 'tmp'], 'scope': 'Original command/streams, receipts, per-suite logs, source tools, versions, Git captures, fixture blobs/hashes and fingerprints only; no ELF/object archive.'}
            write_json(output / 'SELECTION.json', selection)
            members = []
            archive = output / 'raw-evidence.tar.gz'
            with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
                for path in sorted(output.rglob('*')):
                    if not path.is_file() or path.is_symlink() or path == archive:
                        continue
                    relative = path.relative_to(output)
                    if relative.parts[0] in ('cache', 'tmp'):
                        continue
                    body = path.read_bytes()
                    members.append({'path': relative.as_posix(), 'bytes': len(body), 'sha256': digest(body)})
                    tar.add(path, arcname=relative.as_posix(), recursive=False)
            with tarfile.open(archive) as tar:
                for member, expected in zip(tar.getmembers(), members, strict=True):
                    body = tar.extractfile(member).read()
                    if member.name != expected['path'] or len(body) != expected['bytes'] or digest(body) != expected['sha256']:
                        raise RuntimeError('Frozen evidence member mismatch: ' + member.name)
            write_json(output / 'raw-evidence.inventory.json', {
                'archive': archive.name, 'bytes': archive.stat().st_size,
                'sha256': digest(archive.read_bytes()), 'members': members,
            })
    print(json.dumps({'out': str(output), 'sha': SHA, 'actual_process_returncode': result_code,
                      'source_clean_after': receipt.get('source_clean_after'), 'runner_error': runner_error}, ensure_ascii=False))
    if runner_error or receipt.get('after_capture_error') or not receipt.get('source_clean_after') or not receipt.get('fixtures_unchanged_after', False):
        return 1
    return result_code if result_code is not None else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['--adapter']:
        adapter()
    else:
        try:
            code = main()
        except BaseException as error:
            # Preserve a packaging/recorder exception separately from any original
            # test return code already captured. Reraise to keep the real terminal.
            if OUTPUT_FOR_EXCEPTION is not None:
                folder = OUTPUT_FOR_EXCEPTION
                (folder / 'wrapper-exception.stderr').write_text(traceback.format_exc(), encoding='utf-8')
                path = folder / 'receipt.json'
                current = json.loads(path.read_text()) if path.exists() else {'schema': 'geo299316-node-environment-retry/1', 'sha': SHA, 'actual_process_returncode': None}
                current.update(wrapper_exception={'type': type(error).__name__, 'message': str(error)},
                               runner_intended_exit_code=1, terminal_tool_exit_code=None)
                write_json(path, current)
            raise
        sys.exit(code)
