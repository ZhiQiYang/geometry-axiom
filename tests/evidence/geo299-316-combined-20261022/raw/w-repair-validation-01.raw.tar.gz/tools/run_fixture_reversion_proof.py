"""Use the original full W suite to prove the fixture ordering repair is necessary."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/tmp/g261-next299316')
WORK = Path('/workspace/geo299316-work')
P = 'e4557b3f5fab70d70ebb44cd5489cd8841bb3670'
RELATIVE = 'tests/geo261_contact_world_harness.c'
target = ROOT / RELATIVE
OUT = WORK / 'fixture-reversion-proof-01'
OUT.mkdir(exist_ok=False)
baseline = json.loads((WORK / 'contact-world-fixed-baseline-01/receipt.json').read_text())
assert baseline['actual_process_returncode'] == 0 and baseline['sha'] == baseline['head_after'] == P
assert baseline['status_before'] == baseline['status_after'] == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == P
fixed = target.read_bytes()
assert fixed == subprocess.check_output(['git', 'show', P + ':' + RELATIVE], cwd=ROOT)
old_command = ['git', 'show', '2bd45fc9413397637cd0c56c39ac2b6704806d72:' + RELATIVE]
old = subprocess.run(old_command, cwd=ROOT, capture_output=True)
(OUT / 'old-harness.stdout').write_bytes(old.stdout)
(OUT / 'old-harness.stderr').write_bytes(old.stderr)
(OUT / 'old-harness.json').write_text(json.dumps({'command': old_command, 'exit': old.returncode}) + '\n')
assert old.returncode == 0 and old.stdout != fixed
commands = []
try:
    target.write_bytes(old.stdout)
    command = [sys.executable, '-B', str(WORK / 'run_repair_suite.py'), 'contact-world-reverted-fixture-01', 'contact-world']
    result = subprocess.run(command, capture_output=True)
    commands.append({'command': command, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
finally:
    target.write_bytes(fixed)
assert result.returncode == 1, 'Only a normal assertion failure proves the reverted repair.'
stderr = (WORK / 'contact-world-reverted-fixture-01/command.stderr').read_text()
assert 'Ran 9 tests' in stderr and 'FAILED (failures=1)' in stderr
assert "'ASSERT:i5-notched-footprint-deferred' not found in 'ASSERT:boundary-edge-failure-leaves-outputs\\n'" in stderr
assert 'compile/link failed' not in stderr and 'ERROR:' not in stderr
command = [sys.executable, '-B', str(WORK / 'run_repair_suite.py'), 'contact-world-fixed-restored-01', 'contact-world']
result = subprocess.run(command, capture_output=True)
commands.append({'command': command, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
assert result.returncode == 0
assert target.read_bytes() == fixed
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
(OUT / 'proof.json').write_text(json.dumps({'source_sha': P, 'baseline_exit': 0, 'reverted_exit': 1, 'restored_exit': 0,
    'changed_only': RELATIVE, 'fixed_sha256': hashlib.sha256(fixed).hexdigest(),
    'reverted_sha256': hashlib.sha256(old.stdout).hexdigest(), 'original_assertions_preserved': True,
    'negative_reason': 'Original complete-footprint control sees the new failure-output assertion before its original I5 marker.',
    'commands': commands}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_sha': P, 'baseline': 0, 'reverted': 1, 'restored': 0}))
