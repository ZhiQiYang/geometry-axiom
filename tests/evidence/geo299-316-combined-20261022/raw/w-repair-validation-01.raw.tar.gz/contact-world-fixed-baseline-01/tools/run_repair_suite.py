"""Record only the two root-authorized W suites, without the shared heavy lock/cache."""
from pathlib import Path
import hashlib
import fcntl
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import time

ROOT = Path('/tmp/g261-next299316')
WORK = Path('/workspace/geo299316-work')
allowed = {'contacts': 'test_geo261_wood_contacts.py', 'contact-world': 'test_geo261_wood_contact_world.py',
           'reader': 'test_axiom_reader.py'}
label = sys.argv[1]
kind = sys.argv[2]
assert kind in allowed
lock = (WORK / 'private-diagnostics.lock').open('a+')
fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
output = WORK / label
output.mkdir(exist_ok=False)
scratch = Path('/tmp/g299316-private-tmp') / output.name
scratch.mkdir(parents=True, exist_ok=False)

def git(label, arguments):
    cmd = ['git', *arguments]
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    (output / (label + '.stdout')).write_bytes(result.stdout)
    (output / (label + '.stderr')).write_bytes(result.stderr)
    (output / (label + '.json')).write_text(json.dumps({'command': cmd, 'cwd': str(ROOT), 'exit': result.returncode}) + '\n')
    assert result.returncode == 0
    return result.stdout

sha = git('before-head', ['rev-parse', 'HEAD']).decode().strip()
status_before = git('before-status', ['status', '--porcelain']).decode()
patch_before = git('before-patch', ['diff', '--binary', 'HEAD'])
environment = os.environ.copy()
for name in list(environment):
    if name.startswith('GEOMETRY_') or name in ('MUTATE_RESULTS', 'MUTATE_CACHE', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE'):
        environment.pop(name)
environment.update({'TMPDIR': str(scratch), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8',
                    'GITHUB_SHA': sha, 'GITHUB_WORKSPACE': str(ROOT),
                    'GEO299316_EXECUTION_LOG': str(output / 'native-executions.jsonl'),
                    'GEO299316_RECORD_OUT': str(output),
                    'GEO261_REAPER_LOG': str(output / 'reaper.jsonl')})
stack_before = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16777216, stack_before[1]))
command = ['python3', '-B', str(WORK / 'test_entry_full.py'), str(ROOT / 'tests' / allowed[kind]), *sys.argv[3:]]
reaper = Path('/workspace/geo261-environment/reap_children.py')
actual = [sys.executable, '-B', str(reaper), *command]
receipt = {'schema': 'geo299316-private-W-diagnostic/1', 'sha': sha, 'cwd': str(ROOT),
           'status_before': status_before, 'patch_before_sha256': hashlib.sha256(patch_before).hexdigest(),
           'source_variant': 'HEAD with exact before/after patch; intentional reverted repairs are not clean final-source acceptance',
           'command': command, 'reaper_command': actual, 'stack_before': stack_before,
           'stack_during': resource.getrlimit(resource.RLIMIT_STACK), 'python': sys.version,
           'platform': platform.platform(), 'started_epoch': time.time(),
           'environment': {key: environment.get(key) for key in
                           ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS',
                            'GITHUB_SHA', 'GITHUB_WORKSPACE', 'PYTHONOPTIMIZE', 'PYTHONDONTWRITEBYTECODE',
                            'PYTHONIOENCODING', 'GEO299316_EXECUTION_LOG', 'GEO299316_RECORD_OUT', 'GEO261_REAPER_LOG')},
           'authorized_scope': 'Root reopened after formal performance/profile: selected W/reader diagnostics and named reverted-repair controls only; one compiler at a time under private lock. No shared cache, aggregate, ledger, browser or performance run.',
           'private_lock': str(WORK / 'private-diagnostics.lock'),
           'actual_process_returncode': None}
tools = output / 'tools'
tools.mkdir()
for tool in (Path(__file__), WORK / 'test_entry_full.py', reaper):
    shutil.copy2(tool, tools / tool.name)
for name, cmd in [('compiler-version', [os.environ.get('CC', 'cc'), '--version']), ('python-version', ['python3', '--version'])]:
    result = subprocess.run(cmd, capture_output=True, env=environment)
    (output / (name + '.stdout')).write_bytes(result.stdout)
    (output / (name + '.stderr')).write_bytes(result.stderr)
    (output / (name + '.json')).write_text(json.dumps({'command': cmd, 'exit': result.returncode}) + '\n')
(output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
with (output / 'command.stdout').open('wb') as stdout, (output / 'command.stderr').open('wb') as stderr:
    result = subprocess.run(actual, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
receipt.update({'actual_process_returncode': result.returncode, 'ended_epoch': time.time(),
                'head_after': git('after-head', ['rev-parse', 'HEAD']).decode().strip(),
                'status_after': git('after-status', ['status', '--porcelain']).decode(),
                'patch_after_sha256': hashlib.sha256(git('after-patch', ['diff', '--binary', 'HEAD'])).hexdigest(),
                'stdout_sha256': hashlib.sha256((output / 'command.stdout').read_bytes()).hexdigest(),
                'stderr_sha256': hashlib.sha256((output / 'command.stderr').read_bytes()).hexdigest()})
(output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'out': str(output), 'sha': sha, 'actual_process_returncode': result.returncode}))
sys.exit(result.returncode)
