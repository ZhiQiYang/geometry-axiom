from pathlib import Path
import collections,json,sys
repo,ledger_path,expected=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
sys.path.insert(0,str(repo/'tests'))
import mutate as mt
import mutation_bridge as mb
ledger=json.loads(ledger_path.read_text());m=next(m for m in mt.MUTANTS if m['id']=='M110');row=ledger['M110'];src=mt.Sources(repo)
problems=mb.execution_problems(mt,m,row,row['verdict'],src)
execution=row.get('execution',{})
report={'schema':'geo314-M110-original-single-record-validation/1','scope':'Only M110 original execution validator; not global strict-check acceptance',
 'verdict':row['verdict'],'definition_kind':mt.definition_kind(m,src)[0], 'execution_problems':problems,
 'execution_head':execution.get('head'),'baseline_exit':execution.get('baseline',{}).get('exit_code'),
 'mutant_exit':execution.get('mutant',{}).get('exit_code'),'restored_exit':execution.get('restored',{}).get('exit_code'),
 'complete_record':row,'all_ledger_verdict_counts':dict(collections.Counter(r['verdict'] for r in ledger.values()))}
print(json.dumps(report,ensure_ascii=False))
assert row['verdict']==expected and mt.definition_kind(m,src)[0]=='equivalent'
if expected=='equivalent':
 assert not problems and [report[k] for k in ('baseline_exit','mutant_exit','restored_exit')]==[0,0,0]
else:
 assert expected=='invalid' and not execution and problems
