"""Prove the bridge-equivalence fix with original M110 CLI/real bridge on committed 0/1/0 variants."""
from pathlib import Path
import argparse
import ast
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import resource
import shutil
import sys
import traceback

HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
PREPARER = Path('/workspace/geo314-work/regenerate_ledger_fixed_source.py')
PATCH = Path('/workspace/geo314-work/bridge-equivalence-fix-DRAFT/runner-only.patch')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, data):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)

VALIDATE = r'''from pathlib import Path
import collections,json,sys
repo,ledger_path,expected=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
sys.path.insert(0,str(repo/'tests'))
import mutate as mt
import mutation_bridge as mb
ledger=json.loads(ledger_path.read_text());m=next(m for m in mt.MUTANTS if m['id']=='M110');row=ledger['M110'];src=mt.Sources(repo)
problems=mb.execution_problems(mt,m,row,row['verdict'],src)
execution=row.get('execution',{})
report={'schema':'geo314-M110-original-single-record-validation/1','scope':'Only M110 original execution validator; not global strict-check acceptance',
 'verdict':row['verdict'],'definition_kind':mt.definition_kind(m,src)[0], 'execution_problems':problems,
 'execution_head':execution.get('head'),'baseline_exit':execution.get('baseline',{}).get('exit_code'),
 'mutant_exit':execution.get('mutant',{}).get('exit_code'),'restored_exit':execution.get('restored',{}).get('exit_code'),
 'complete_record':row,'all_ledger_verdict_counts':dict(collections.Counter(r['verdict'] for r in ledger.values()))}
print(json.dumps(report,ensure_ascii=False))
assert row['verdict']==expected and mt.definition_kind(m,src)[0]=='equivalent'
if expected=='equivalent':
 assert not problems and [report[k] for k in ('baseline_exit','mutant_exit','restored_exit')]==[0,0,0]
else:
 assert expected=='invalid' and not execution and problems
'''

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--heavy-lock', type=Path, required=True)
    args = parser.parse_args()
    repo, out, source = args.repo.resolve(), args.out.resolve(), args.sha
    assert not out.exists() and not out.is_relative_to(repo) and not repo.is_relative_to(out)
    assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
    assert sha(HELPER.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
    out.mkdir(parents=True); (out / 'tools').mkdir(); (out / 'tmp').mkdir()
    for p in (Path(__file__), HELPER, PREPARER, PATCH):
        shutil.copy2(p, out / 'tools' / p.name)
    preparer_tree = ast.parse(PREPARER.read_text())
    verify_text = next(ast.literal_eval(node.value) for node in preparer_tree.body
                       if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VERIFY' for t in node.targets))
    (out / 'tools/verify_scratch.py').write_text(verify_text, encoding='utf-8')
    (out / 'tools/validate_M110.py').write_text(VALIDATE, encoding='utf-8')
    tools = {str(p): sha(p.read_bytes()) for p in (Path(__file__), HELPER, PREPARER, PATCH)}
    spec = importlib.util.spec_from_file_location('geo314_real_equivalence_capture', HELPER)
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    cleared = sorted(key for key in os.environ if key.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_'))
                     or key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE', 'NODE_OPTIONS', 'LD_PRELOAD'))
    base_env = {key: value for key, value in os.environ.items() if key not in cleared}
    base_env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(out / 'tmp'), GITHUB_SHA=source, GITHUB_WORKSPACE=str(repo))
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
    recorder = capture.Recorder(out, base_env, source)
    report = {'schema': 'geo314-bridge-equivalence-real-proof/1', 'source_sha': source, 'source_repo': str(repo),
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'platform': platform.platform(), 'python': sys.version,
              'tool_hashes': tools, 'cleared_environment_names': cleared, 'stack_before': [soft, hard], 'stack_during': [16384 * 1024, hard],
              'scope': 'Original M110 subset CLI and original single-record validator; global strict --check is reserved for the subsequent complete new-S ledger.',
              'original_behavior_assertions_modified': False, 'mutation_runner_is_target_of_proof': True,
              'mock_build_or_oracle_used': False, 'phases': [], 'steps': [], 'errors': [], 'exit_code': None}
    def record():
        report['commands'] = recorder.rows
        save(out / 'receipt.json', report)
    def command(label, argv, cwd=repo, data=None, expected=0, phase_sha=source, env=None):
        recorder.env = env or base_env
        row, stdout, stderr = recorder.run(argv, cwd=cwd, data=data, timeout=None, check=False,
            source_sha=phase_sha, source_variant=label)
        report['steps'].append({'label': label, 'expected_exit': expected, 'original_command_result': row}); record()
        assert row['actual_process_returncode'] == expected, (label, row['actual_process_returncode'], expected)
        return row, stdout, stderr
    def state(label):
        _, head, _ = command(label + '-head', ['git', 'rev-parse', 'HEAD'])
        _, status, _ = command(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
        return {'head': head.decode().strip(), 'status': status.decode()}
    def prepare_scratch(invoking, phase_root, phase_sha, env):
        work = phase_root / 'cache/_bridge-work' / phase_sha / 'repo'; work.parent.mkdir(parents=True)
        command('scratch-clone', ['git', 'clone', '--shared', '--no-checkout', str(invoking), str(work)], cwd=invoking, phase_sha=phase_sha, env=env)
        command('scratch-sparse', ['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=work,
                data=b'/*\n!/evidence/\n!/tests/evidence/\n!/tests/release-evidence/\n', phase_sha=phase_sha, env=env)
        command('scratch-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', phase_sha], cwd=work, phase_sha=phase_sha, env=env)
        _, stdout, _ = command('scratch-identity', [sys.executable, '-B', str(out / 'tools/verify_scratch.py'), str(invoking), str(work)], cwd=invoking, phase_sha=phase_sha, env=env)
        save(phase_root / 'SCRATCH_IDENTITY.json', json.loads(stdout))
    def phase(label, invoking, phase_sha, expected_exit, expected_verdict):
        phase_root = out / label; phase_root.mkdir(); (phase_root / 'cache').mkdir(); (phase_root / 'tmp').mkdir()
        shutil.copy2(invoking / 'tests/mutants_results.json', phase_root / 'ledger.json')
        env = dict(base_env, TMPDIR=str(phase_root / 'tmp'), MUTATE_CACHE=str(phase_root / 'cache'),
                   MUTATE_RESULTS=str(phase_root / 'ledger.json'), GITHUB_SHA=phase_sha, GITHUB_WORKSPACE=str(invoking))
        _, before_head, _ = command(label + '-source-before-head', ['git', 'rev-parse', 'HEAD'], cwd=invoking, phase_sha=phase_sha, env=env)
        _, before_status, _ = command(label + '-source-before-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=invoking, phase_sha=phase_sha, env=env)
        assert before_head.decode().strip() == phase_sha and not before_status
        prepare_scratch(invoking, phase_root, phase_sha, env)
        row, _, _ = command(label + '-original-M110', ['python3', '-B', 'tests/mutate.py', 'M110'], cwd=invoking, expected=expected_exit, phase_sha=phase_sha, env=env)
        _, stdout, _ = command(label + '-original-single-record-validator', [sys.executable, '-B', str(out / 'tools/validate_M110.py'), str(invoking), str(phase_root / 'ledger.json'), expected_verdict], cwd=invoking, phase_sha=phase_sha, env=env)
        validation = json.loads(stdout); save(phase_root / 'M110_VALIDATION.json', validation)
        _, after_head, _ = command(label + '-source-after-head', ['git', 'rev-parse', 'HEAD'], cwd=invoking, phase_sha=phase_sha, env=env)
        _, after_status, _ = command(label + '-source-after-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=invoking, phase_sha=phase_sha, env=env)
        assert after_head == before_head and after_status == before_status
        report['phases'].append({'label': label, 'source_sha': phase_sha, 'original_subset_exit': row['actual_process_returncode'],
                                 'verdict': validation['verdict'], 'execution_head': validation['execution_head'],
                                 'execution_problems': validation['execution_problems'],
                                 'real_baseline_mutant_restored_exits': [validation[k] for k in ('baseline_exit', 'mutant_exit', 'restored_exit')]})
        record()
    code = 1
    record()
    with args.heavy_lock.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            report['source_before'] = state('before')
            assert report['source_before'] == {'head': source, 'status': ''}
            command('original-honesty-suite', ['python3', '-B', 'tests/test_mutation_freshness.py'])
            phase('fixed-baseline', repo, source, 0, 'equivalent')
            controlled = out / 'controlled-repo'
            command('control-clone', ['git', 'clone', '--shared', '--no-checkout', str(repo), str(controlled)])
            command('control-sparse', ['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=controlled,
                    data=b'/*\n!/evidence/\n!/tests/evidence/\n!/tests/release-evidence/\n')
            command('control-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', source], cwd=controlled)
            command('control-withdraw-only-fix', ['git', 'apply', '--reverse', str(out / 'tools/runner-only.patch')], cwd=controlled)
            _, diff, _ = command('control-exact-diff', ['git', 'diff', '--binary', '--', 'tests/mutation_bridge.py'], cwd=controlled)
            (out / 'CONTROL_WITHDRAWAL.diff').write_bytes(diff)
            command('control-add', ['git', 'add', 'tests/mutation_bridge.py'], cwd=controlled)
            command('control-commit', ['git', '-c', 'user.name=Codex', '-c', 'user.email=codex@openai.com', 'commit', '-m', 'Withdraw bridge equivalence support for controlled proof'], cwd=controlled)
            _, raw_sha, _ = command('control-head', ['git', 'rev-parse', 'HEAD'], cwd=controlled)
            control_sha = raw_sha.decode().strip(); report['controlled_withdrawal_sha'] = control_sha
            _, commit_raw, _ = command('control-raw-commit', ['git', 'cat-file', 'commit', control_sha], cwd=controlled, phase_sha=control_sha)
            (out / 'CONTROL_COMMIT.txt').write_bytes(commit_raw)
            phase('withdrawn', controlled, control_sha, 1, 'invalid')
            phase('fixed-restored', repo, source, 0, 'equivalent')
            assert [row['original_subset_exit'] for row in report['phases']] == [0, 1, 0]
            code = 0
        except BaseException:
            report['errors'].append(traceback.format_exc()); code = 1
        finally:
            try:
                report['source_after'] = state('after')
                assert report['source_before'] == report['source_after']
                assert all(sha(Path(path).read_bytes()) == value for path, value in tools.items())
            except BaseException:
                report['errors'].append(traceback.format_exc()); code = 1
            report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            record()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code}, ensure_ascii=False), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
