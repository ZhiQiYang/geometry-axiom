"""Run the complete original mutation command at a clean SHA with a small exact scratch checkout."""
from pathlib import Path
import argparse
import ast
import collections
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import resource
import shutil
import sys
import traceback

HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)

VERIFY = r'''from pathlib import Path
import hashlib,json,sys,subprocess
repo,work=map(Path,sys.argv[1:3]);sys.path.insert(0,str(repo/'tests'))
import mutate as mt
import mutation_bridge as mb
h=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo)==subprocess.check_output(['git','rev-parse','HEAD'],cwd=work)
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=work).strip()
a,b=mt.Sources(repo),mt.Sources(work);assert a.closure==b.closure
def inputs(root):
 files=sorted([*root.glob('tests/*.py'),*root.glob('tests/*.c'),*root.glob('tests/fixtures/**/*.scene'),*root.glob('*.scene')])
 return [{'path':p.relative_to(root).as_posix(),'lfSha256':h(p.read_bytes().replace(b'\r\n',b'\n'))} for p in files]
left,right=inputs(repo),inputs(work);assert left==right
hashes=[]
for m in mt.MUTANTS:
 if m.get('binary')=='bridge':
  x,y=mb.oracle_hash(m,repo),mb.oracle_hash(m,work);assert x==y
  hashes.append({'id':m['id'],'sourceOracleSha256':x,'scratchOracleSha256':y,'methods':m['tests']})
print(json.dumps({'schema':'geo314-fixed-scratch-identity/1','source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'closure_sha256':a.closure,'sourceAndScratchClosureEqual':True,'completeOracleInputsEqual':True,'oracleInputCount':len(left),'oracleInputs':left,'restoredMethods':mb.RESTORED,'bridgeMutants':hashes},ensure_ascii=False))
'''

SEED_CACHE = r'''from pathlib import Path
import hashlib,json,shutil,sys
repo,old_cache,new_cache,old_ledger=map(Path,sys.argv[1:5]);sys.path.insert(0,str(repo/'tests'))
import mutate as mt
h=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
source=mt.Sources(repo);records=json.loads(old_ledger.read_text());rows=[]
def retain(label,old_binary,new_binary,fingerprint,recorded_hash,origin_sha):
 state=mt.cache_state(old_binary,fingerprint)
 row={'id':label,'source':str(old_binary),'destination':str(new_binary),'original_cache_state':state,'copied':False,'compilation_execution_source_sha':origin_sha}
 if state=='hit' and h(old_binary)==recorded_hash:
  new_binary.parent.mkdir(parents=True,exist_ok=True)
  files=[]
  for source_path,target_path in [(old_binary,new_binary),(mt.sidecar_path(old_binary),mt.sidecar_path(new_binary))]:
   before=h(source_path);shutil.copy2(source_path,target_path);assert h(source_path)==h(target_path)==before
   files.append({'source':str(source_path),'destination':str(target_path),'bytes':source_path.stat().st_size,'sha256':before})
  assert mt.cache_state(new_binary,fingerprint)=='hit'
  row.update(copied=True,new_cache_state='hit',files=files)
 rows.append(row)
core=[m for m in mt.MUTANTS if m.get('binary')!='bridge' and mt.definition_kind(m,source)[0] in ('run','equivalent')]
for m in core:
 record=records.get(m['id'],{});execution=record.get('execution',{})
 retain(m['id'],old_cache/m['id']/'_mut.exe',new_cache/m['id']/'_mut.exe',mt.mutant_fingerprint(m,source),execution.get('exe_sha256'),execution.get('head'))
first=next(record['execution'] for record in records.values() if record.get('execution',{}).get('baseline_exe_sha256'))
retain('_baseline',old_cache/'_baseline/baseline.exe',new_cache/'_baseline/baseline.exe',mt.baseline_fingerprint(source),first['baseline_exe_sha256'],first['head'])
print(json.dumps({'schema':'geo314-original-compile-cache-copy/1','policy':'Only original fingerprint/cache_state hits copied with exact original sidecars; original compilation provenance retained. Every oracle must still actually execute in subsequent full original command at new SHA.', 'sourceClosureSha256':source.closure,'oldLedgerPath':str(old_ledger),'oldLedgerSha256':h(old_ledger),'copied':sum(row['copied'] for row in rows),'candidates':len(rows),'rows':rows},ensure_ascii=False))
'''

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--heavy-lock', type=Path, required=True)
    parser.add_argument('--reuse-core-cache', type=Path)
    parser.add_argument('--reuse-core-ledger', type=Path)
    args = parser.parse_args()
    repo, out, source = args.repo.resolve(), args.out.resolve(), args.sha
    assert not out.exists() and not out.is_relative_to(repo) and not repo.is_relative_to(out)
    assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
    assert (args.reuse_core_cache is None) == (args.reuse_core_ledger is None)
    assert digest(HELPER.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
    out.mkdir(parents=True)
    for name in ('tmp', 'cache', 'tools'):
        (out / name).mkdir()
    shutil.copy2(repo / 'tests/mutants_results.json', out / 'ledger.json')
    shutil.copy2(repo / 'tests/mutants_results.json', out / 'seed-ledger.json')
    shutil.copy2(Path(__file__), out / 'tools' / Path(__file__).name)
    shutil.copy2(HELPER, out / 'tools/capture.py')
    (out / 'tools/verify_scratch.py').write_text(VERIFY, encoding='utf-8')
    (out / 'tools/seed_compile_cache.py').write_text(SEED_CACHE, encoding='utf-8')
    spec = importlib.util.spec_from_file_location('geo314_fixed_regen_capture', HELPER)
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    cleared = sorted(key for key in os.environ if key.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_'))
                     or key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE', 'NODE_OPTIONS', 'LD_PRELOAD'))
    env = {key: value for key, value in os.environ.items() if key not in cleared}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(out / 'tmp'), MUTATE_CACHE=str(out / 'cache'), MUTATE_RESULTS=str(out / 'ledger.json'),
               GITHUB_SHA=source, GITHUB_WORKSPACE=str(repo))
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
    recorder = capture.Recorder(out, env, source)
    report = {'schema': 'geo314-complete-ledger-small-scratch/1', 'sha': source, 'repo': str(repo),
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'policy': '完整原python3 tests/mutate.py不帶IDs，所有原mutants全量實跑；只於private scratch filesystem排歷史evidence，原closure/oracle/RESTORED判準不改。',
              'environment': {key: env.get(key) for key in ('PATH', 'LANG', 'LC_ALL', 'PYTHONDONTWRITEBYTECODE', 'PYTHONOPTIMIZE', 'TMPDIR', 'MUTATE_CACHE', 'MUTATE_RESULTS', 'GITHUB_SHA', 'GITHUB_WORKSPACE')},
              'cleared_environment_names': cleared, 'platform': platform.platform(), 'python': sys.version,
              'stack_before': [soft, hard], 'stack_during': [16384 * 1024, hard], 'steps': [], 'errors': [], 'exit_code': None}
    def record():
        report['commands'] = recorder.rows
        save(out / 'receipt.json', report)
    def command(label, argv, cwd=repo, data=None, timeout=None):
        row, stdout, stderr = recorder.run(argv, cwd=cwd, data=data, timeout=timeout, check=False,
            source_sha=source, source_variant='clean-fixed-source-complete-original-ledger')
        report['steps'].append({'label': label, 'original_command_result': row}); record()
        return row, stdout, stderr
    def state(label):
        hr, head, _ = command(label + '-head', ['git', 'rev-parse', 'HEAD'])
        sr, status, _ = command(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
        assert hr['actual_process_returncode'] == sr['actual_process_returncode'] == 0
        return {'head': head.decode().strip(), 'status': status.decode()}
    code = 1
    record()
    with args.heavy_lock.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            report['source_before'] = state('before')
            assert report['source_before'] == {'head': source, 'status': ''}
            work = out / 'cache/_bridge-work' / source / 'repo'
            work.parent.mkdir(parents=True)
            clone, _, _ = command('scratch-clone', ['git', 'clone', '--shared', '--no-checkout', str(repo), str(work)])
            assert clone['actual_process_returncode'] == 0
            sparse, _, _ = command('scratch-sparse', ['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=work,
                                  data=b'/*\n!/evidence/\n!/tests/evidence/\n!/tests/release-evidence/\n')
            assert sparse['actual_process_returncode'] == 0
            checkout, _, _ = command('scratch-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', source], cwd=work)
            assert checkout['actual_process_returncode'] == 0
            verify, stdout, _ = command('scratch-identity', [sys.executable, '-B', str(out / 'tools/verify_scratch.py'), str(repo), str(work)])
            assert verify['actual_process_returncode'] == 0
            identity = json.loads(stdout); save(out / 'SCRATCH_IDENTITY.json', identity)
            if args.reuse_core_cache is not None:
                copied, stdout, _ = command('original-fingerprint-compile-cache-copy', [sys.executable, '-B', str(out / 'tools/seed_compile_cache.py'), str(repo), str(args.reuse_core_cache.resolve()), str(out / 'cache'), str(args.reuse_core_ledger.resolve())])
                assert copied['actual_process_returncode'] == 0
                save(out / 'COMPILE_CACHE_COPY.json', json.loads(stdout))
            for label, argv in [('precheck', ['python3', 'tests/mutate.py', '--check']),
                                ('full-ledger', ['python3', 'tests/mutate.py']),
                                ('checkafter', ['python3', 'tests/mutate.py', '--check'])]:
                command(label, argv)
            outcomes = {step['label']: step['original_command_result']['actual_process_returncode'] for step in report['steps']}
            final = json.loads((out / 'ledger.json').read_text())
            report['all_record_verdict_counts'] = dict(collections.Counter(row['verdict'] for row in final.values()))
            report['record_count'] = len(final)
            report['all_nonretired_execution_head_equal_source'] = all(row.get('execution', {}).get('head') == source for row in final.values() if row['verdict'] != 'retired')
            code = next((outcomes[label] for label in ('full-ledger', 'checkafter') if outcomes[label] != 0), 0)
            if code == 0:
                assert report['all_nonretired_execution_head_equal_source']
        except BaseException:
            report['errors'].append(traceback.format_exc()); code = 1
        finally:
            try:
                report['source_after'] = state('after')
                assert report['source_after'] == report['source_before']
            except BaseException:
                report['errors'].append(traceback.format_exc()); code = 1
            report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), ledger_sha256=digest((out / 'ledger.json').read_bytes()))
            record()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code}, ensure_ascii=False), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
