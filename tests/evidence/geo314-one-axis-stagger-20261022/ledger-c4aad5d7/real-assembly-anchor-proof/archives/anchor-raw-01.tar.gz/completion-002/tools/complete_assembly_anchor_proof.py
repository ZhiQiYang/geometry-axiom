"""Preserve the original collector failure and complete only the missing restored anchor-test run."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import traceback

REPO = Path('/tmp/g261-next314')
SOURCE = 'c4aad5d7bb98ea864639f9e6d85c99bb2613c24b'
FIRST = Path('/workspace/geo314-work/anchor-repair-proof-c4aad5d7-001')
OUT = Path('/workspace/geo314-work/anchor-repair-proof-c4aad5d7-002')
HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')

FINDING = r'''from pathlib import Path
import importlib.util,json,sys
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'tests'))
spec=importlib.util.spec_from_file_location('original_withdrawn_anchor_finding',root/'tests/test_mutation_anchors.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MutationAnchors.setUpClass();found=module.MutationAnchors().found()
rows=[{'tool':key[0],'id':key[1],'detail':value} for key,value in found.items()]
print(json.dumps({'schema':'geo314-original-anchor-withdrawal-finding/1','findings':rows},ensure_ascii=False))
assert len(rows)==1 and rows[0]['tool']=='tests/assembly_mutation_check.py' and rows[0]['id']=='cancelled-preview'
assert rows[0]['detail'].startswith('anchor occurs 0 times in geometry-web/engineering_bridge.inc:')
'''

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    assert not OUT.exists()
    first = json.loads((FIRST / 'receipt.json').read_text())
    assert first['exit_code'] == 1 and first['source_before'] == first['source_after'] == {'head': SOURCE, 'status': ''}
    old_phases = first['phases']; assert len(old_phases) == 1 and old_phases[0]['original_exit'] == 0
    row = next(item['original_command_result'] for item in first['steps'] if item['label'] == 'withdrawn-original-three-methods')
    assert row['actual_process_returncode'] == 1 and not row['timeout_expired']
    for name, key in [('stdout.bin', 'stdout_sha256'), ('stderr.bin', 'stderr_sha256')]:
        assert sha((Path(row['directory']) / name).read_bytes()) == row[key]
    stderr = (Path(row['directory']) / 'stderr.bin').read_text()
    assert 'Ran 3 tests' in stderr and 'FAILED (failures=2)' in stderr and 'ERROR:' not in stderr
    assert stderr.count('AssertionError') == 2 and 'cancelled-preview' in stderr
    control = first['controlled_withdrawal_sha']; work = FIRST / 'source'
    OUT.mkdir(); (OUT / 'tools').mkdir(); (OUT / 'tmp').mkdir()
    for p in (Path(__file__), HELPER): shutil.copy2(p, OUT / 'tools' / p.name)
    (OUT / 'tools/original_finding.py').write_text(FINDING, encoding='utf-8')
    spec = importlib.util.spec_from_file_location('anchor_completion_capture', HELPER)
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    env = {key: value for key, value in os.environ.items() if not key.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_'))
           and key not in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE', 'NODE_OPTIONS', 'LD_PRELOAD')}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(OUT / 'tmp'), MUTATE_CACHE=str(OUT / 'unused-cache'), MUTATE_RESULTS=str(OUT / 'unused-ledger.json'), GITHUB_SHA=SOURCE, GITHUB_WORKSPACE=str(REPO))
    recorder = capture.Recorder(OUT, env, SOURCE)
    report = {'schema': 'geo314-assembly-anchor-proof-completion/1', 'source_sha': SOURCE,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_attempt': str(FIRST), 'original_collector_exit': 1,
              'original_receipt_sha256': sha((FIRST / 'receipt.json').read_bytes()),
              'policy': 'Original baseline0/withdrawn1 and collector1 are preserved. This run reads the original finding and executes only the missing restored phase; no rerun of baseline/withdrawn, no compiler, no product/judge edits.',
              'original_baseline_phase': old_phases[0], 'original_withdrawn_command': row, 'steps': [], 'errors': [], 'exit_code': None}
    def record():
        report['commands'] = recorder.rows; save(OUT / 'receipt.json', report)
    def command(label, argv, cwd=REPO, source_sha=SOURCE):
        result, stdout, stderr = recorder.run(argv, cwd=cwd, timeout=None, check=False, source_sha=source_sha, source_variant=label)
        report['steps'].append({'label': label, 'original_command_result': result}); record()
        assert result['actual_process_returncode'] == 0
        return stdout, stderr
    def main_state(label):
        head, _ = command(label + '-head', ['git', 'rev-parse', 'HEAD'])
        status, _ = command(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
        return {'head': head.decode().strip(), 'status': status.decode()}
    code = 1; record()
    try:
        report['source_before'] = main_state('main-before'); assert report['source_before'] == {'head': SOURCE, 'status': ''}
        head, _ = command('control-head-before', ['git', 'rev-parse', 'HEAD'], cwd=work, source_sha=control)
        status, _ = command('control-status-before', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=work, source_sha=control)
        assert head.decode().strip() == control and not status
        finding, _ = command('exact-original-withdrawn-finding', [sys.executable, '-B', str(OUT / 'tools/original_finding.py'), str(work)], cwd=work, source_sha=control)
        save(OUT / 'ORIGINAL_WITHDRAWN_FINDING.json', json.loads(finding))
        command('restore-original-fixed-commit', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', SOURCE], cwd=work)
        stdout, stderr = command('restored-original-three-methods', ['python3', '-B', 'tests/test_mutation_anchors.py'], cwd=work)
        text = (stdout + stderr).decode('utf-8', 'replace'); assert 'Ran 3 tests' in text and text.rstrip().endswith('OK')
        head, _ = command('restored-head-after', ['git', 'rev-parse', 'HEAD'], cwd=work)
        status, _ = command('restored-status-after', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=work)
        assert head.decode().strip() == SOURCE and not status
        report['proof_original_exits'] = [0, 1, 0]
        report['proof_source_shas'] = [SOURCE, control, SOURCE]
        report['completed_original_methods_per_phase'] = [3, 3, 3]
        report['negative_normal_assertion_failures'] = 2
        code = 0
    except BaseException:
        report['errors'].append(traceback.format_exc()); code = 1
    finally:
        try:
            report['source_after'] = main_state('main-after'); assert report['source_after'] == report['source_before']
        except BaseException:
            report['errors'].append(traceback.format_exc()); code = 1
        report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()); record()
    print(json.dumps({'receipt': str(OUT / 'receipt.json'), 'exit_code': code}, ensure_ascii=False), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
