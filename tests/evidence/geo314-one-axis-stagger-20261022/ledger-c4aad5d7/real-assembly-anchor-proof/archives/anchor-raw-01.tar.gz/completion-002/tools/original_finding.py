from pathlib import Path
import importlib.util,json,sys
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'tests'))
spec=importlib.util.spec_from_file_location('original_withdrawn_anchor_finding',root/'tests/test_mutation_anchors.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MutationAnchors.setUpClass();found=module.MutationAnchors().found()
rows=[{'tool':key[0],'id':key[1],'detail':value} for key,value in found.items()]
print(json.dumps({'schema':'geo314-original-anchor-withdrawal-finding/1','findings':rows},ensure_ascii=False))
assert len(rows)==1 and rows[0]['tool']=='tests/assembly_mutation_check.py' and rows[0]['id']=='cancelled-preview'
assert rows[0]['detail'].startswith('anchor occurs 0 times in geometry-web/engineering_bridge.inc:')
