from pathlib import Path
import hashlib,importlib.util,json,sys
repo=Path(sys.argv[1]);sys.path.insert(0,str(repo/'tests'))
spec=importlib.util.spec_from_file_location('original_anchor_discovery',repo/'tests/test_mutation_anchors.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MutationAnchors.setUpClass()
cls=module.MutationAnchors
paths={'tests/test_mutation_anchors.py','tests/mutate.py','tests/mutation_bridge.py','tests/binaries.py','tests/run_tests.py','tests/__init__.py',*module.TOOLS}
for entries in cls.entries.values():
 for identifier,patches in entries:
  paths.update(relative for relative,old,new in patches)
source=cls.mutate.Sources(repo);paths.update(source.texts)
rows=[]
for relative in sorted(paths):
 raw=(repo/relative).read_bytes()
 rows.append({'path':relative,'bytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'lfSha256':hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()})
print(json.dumps({'schema':'geo314-original-anchor-input-discovery/1','method':'Original MutationAnchors.setUpClass tables, every original patch target, complete original mutate.Sources include closure, original direct Python import files. No judge executes or compiles at discovery.', 'sourceClosureSha256':source.closure,'inputs':rows,'inputCount':len(rows),'rawBytes':sum(row['bytes'] for row in rows)},ensure_ascii=False))
