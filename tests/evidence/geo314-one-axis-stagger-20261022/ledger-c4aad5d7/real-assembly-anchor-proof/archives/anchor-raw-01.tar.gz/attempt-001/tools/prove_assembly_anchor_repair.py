"""Run the original three anchor tests on exact committed fixed/withdrawn/restored source subsets."""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import sys
import traceback

HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
SOURCE = 'c4aad5d7bb98ea864639f9e6d85c99bb2613c24b'
OLD = '291ce90abf9c3bfaf68bd61c4969f2ff9a1be6f6'
REPO = Path('/tmp/g261-next314')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

DISCOVER = r'''from pathlib import Path
import hashlib,importlib.util,json,sys
repo=Path(sys.argv[1]);sys.path.insert(0,str(repo/'tests'))
spec=importlib.util.spec_from_file_location('original_anchor_discovery',repo/'tests/test_mutation_anchors.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MutationAnchors.setUpClass()
cls=module.MutationAnchors
paths={'tests/test_mutation_anchors.py','tests/mutate.py','tests/mutation_bridge.py','tests/binaries.py','tests/run_tests.py','tests/__init__.py',*module.TOOLS}
for entries in cls.entries.values():
 for identifier,patches in entries:
  paths.update(relative for relative,old,new in patches)
source=cls.mutate.Sources(repo);paths.update(source.texts)
rows=[]
for relative in sorted(paths):
 raw=(repo/relative).read_bytes()
 rows.append({'path':relative,'bytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'lfSha256':hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()})
print(json.dumps({'schema':'geo314-original-anchor-input-discovery/1','method':'Original MutationAnchors.setUpClass tables, every original patch target, complete original mutate.Sources include closure, original direct Python import files. No judge executes or compiles at discovery.', 'sourceClosureSha256':source.closure,'inputs':rows,'inputCount':len(rows),'rawBytes':sum(row['bytes'] for row in rows)},ensure_ascii=False))
'''

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve(); assert not out.exists() and not out.is_relative_to(REPO)
    assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
    assert sha(HELPER.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
    out.mkdir(parents=True); (out / 'tools').mkdir(); (out / 'tmp').mkdir()
    shutil.copy2(Path(__file__), out / 'tools' / Path(__file__).name)
    shutil.copy2(HELPER, out / 'tools/capture.py')
    (out / 'tools/discover_original_inputs.py').write_text(DISCOVER, encoding='utf-8')
    spec = importlib.util.spec_from_file_location('geo314_anchor_capture', HELPER)
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    env = {key: value for key, value in os.environ.items() if not key.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_'))
           and key not in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE', 'NODE_OPTIONS', 'LD_PRELOAD')}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(out / 'tmp'), MUTATE_CACHE=str(out / 'unused-private-cache'), MUTATE_RESULTS=str(out / 'unused-results.json'),
               GITHUB_SHA=SOURCE, GITHUB_WORKSPACE=str(REPO))
    recorder = capture.Recorder(out, env, SOURCE)
    report = {'schema': 'geo314-assembly-anchor-withdrawal/1', 'source_sha': SOURCE, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Exact P3 one-line assembly cancellation-anchor repair only; original three test_mutation_anchors methods, not a rerun of full ASM mutation behavior gate.',
              'original_assertions_modified': False, 'compiler_requested': False, 'platform': platform.platform(), 'python': sys.version,
              'steps': [], 'phases': [], 'errors': [], 'exit_code': None}
    def record():
        report['commands'] = recorder.rows; save(out / 'receipt.json', report)
    def command(label, argv, cwd=REPO, expected=0, data=None, source_sha=SOURCE):
        row, stdout, stderr = recorder.run(argv, cwd=cwd, data=data, timeout=None, check=False, source_sha=source_sha, source_variant=label)
        report['steps'].append({'label': label, 'original_command_result': row}); record()
        assert row['actual_process_returncode'] == expected, (label, row['actual_process_returncode'])
        return stdout, stderr
    def source_state(label):
        head, _ = command(label + '-head', ['git', 'rev-parse', 'HEAD'])
        status, _ = command(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
        return {'head': head.decode().strip(), 'status': status.decode()}
    def phase(label, root, phase_sha, expected):
        head, _ = command(label + '-head-before', ['git', 'rev-parse', 'HEAD'], cwd=root, source_sha=phase_sha)
        status, _ = command(label + '-status-before', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, source_sha=phase_sha)
        assert head.decode().strip() == phase_sha and not status
        stdout, stderr = command(label + '-original-three-methods', ['python3', '-B', 'tests/test_mutation_anchors.py'], cwd=root, source_sha=phase_sha, expected=expected)
        text = (stdout + stderr).decode('utf-8', 'replace')
        assert 'Ran 3 tests' in text
        if expected == 0:
            assert text.rstrip().endswith('OK')
        else:
            assert 'AssertionError' in text and 'cancelled-preview' in text and 'anchor occurs 0 times' in text
            assert 'ERROR:' not in text
        after_head, _ = command(label + '-head-after', ['git', 'rev-parse', 'HEAD'], cwd=root, source_sha=phase_sha)
        after_status, _ = command(label + '-status-after', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, source_sha=phase_sha)
        assert head == after_head and status == after_status
        report['phases'].append({'label': label, 'source_sha': phase_sha, 'original_exit': expected, 'original_methods': 3,
                                 'normal_assertion_failure': expected == 1, 'source_clean_before_after': True}); record()
    code = 1; record()
    try:
        report['source_before'] = source_state('main-before'); assert report['source_before'] == {'head': SOURCE, 'status': ''}
        stdout, _ = command('discover-original-complete-anchor-inputs', [sys.executable, '-B', str(out / 'tools/discover_original_inputs.py'), str(REPO)])
        discovery = json.loads(stdout); save(out / 'INPUTS.json', discovery)
        work = out / 'source'
        command('source-clone', ['git', 'clone', '--shared', '--no-checkout', str(REPO), str(work)])
        patterns = ''.join('/' + row['path'] + '\n' for row in discovery['inputs']).encode()
        command('source-sparse-exact-inputs', ['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=work, data=patterns)
        command('source-fixed-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', SOURCE], cwd=work)
        for row in discovery['inputs']:
            actual = (work / row['path']).read_bytes()
            assert sha(actual.replace(b'\r\n', b'\n')) == row['lfSha256']
        report['complete_original_anchor_inputs_exactly_bound'] = True; record()
        phase('baseline', work, SOURCE, 0)
        old_bytes, _ = command('original-P2-anchor-tool-bytes', ['git', 'show', OLD + ':tests/assembly_mutation_check.py'])
        target = work / 'tests/assembly_mutation_check.py'; fixed = target.read_bytes()
        before = b'if(cancelled){g_preview.ready=false;app_world_candidate_discard(g_preview.transaction);}'
        after = b'if(cancelled){g_preview.ready=false;app_candidate_discard(g_preview.transaction->control);}'
        assert fixed.count(before) == 1 and fixed.replace(before, after, 1) == old_bytes
        target.write_bytes(old_bytes)
        diff, _ = command('exact-single-anchor-withdrawal-diff', ['git', 'diff', '--binary', '--', 'tests/assembly_mutation_check.py'], cwd=work)
        (out / 'CONTROL_WITHDRAWAL.diff').write_bytes(diff)
        command('control-add', ['git', 'add', 'tests/assembly_mutation_check.py'], cwd=work)
        command('control-commit', ['git', '-c', 'user.name=Codex', '-c', 'user.email=codex@openai.com', 'commit', '-m', 'Withdraw assembly cancellation anchor repair for controlled proof'], cwd=work)
        control, _ = command('control-head', ['git', 'rev-parse', 'HEAD'], cwd=work)
        control_sha = control.decode().strip(); report['controlled_withdrawal_sha'] = control_sha
        commit, _ = command('control-commit-object', ['git', 'cat-file', 'commit', control_sha], cwd=work, source_sha=control_sha)
        (out / 'CONTROL_COMMIT.txt').write_bytes(commit)
        phase('withdrawn', work, control_sha, 1)
        command('restore-fixed-committed-source', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', SOURCE], cwd=work)
        phase('restored', work, SOURCE, 0)
        assert [row['original_exit'] for row in report['phases']] == [0, 1, 0]
        code = 0
    except BaseException:
        report['errors'].append(traceback.format_exc()); code = 1
    finally:
        try:
            report['source_after'] = source_state('main-after'); assert report['source_after'] == report['source_before']
        except BaseException:
            report['errors'].append(traceback.format_exc()); code = 1
        report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()); record()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code}, ensure_ascii=False), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
