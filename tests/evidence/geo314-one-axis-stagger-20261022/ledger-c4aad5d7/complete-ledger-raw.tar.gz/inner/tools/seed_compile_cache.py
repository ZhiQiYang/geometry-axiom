from pathlib import Path
import hashlib,json,shutil,sys
repo,old_cache,new_cache,old_ledger=map(Path,sys.argv[1:5]);sys.path.insert(0,str(repo/'tests'))
import mutate as mt
h=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
source=mt.Sources(repo);records=json.loads(old_ledger.read_text());rows=[]
def retain(label,old_binary,new_binary,fingerprint,recorded_hash,origin_sha):
 state=mt.cache_state(old_binary,fingerprint)
 row={'id':label,'source':str(old_binary),'destination':str(new_binary),'original_cache_state':state,'copied':False,'compilation_execution_source_sha':origin_sha}
 if state=='hit' and h(old_binary)==recorded_hash:
  new_binary.parent.mkdir(parents=True,exist_ok=True)
  files=[]
  for source_path,target_path in [(old_binary,new_binary),(mt.sidecar_path(old_binary),mt.sidecar_path(new_binary))]:
   before=h(source_path);shutil.copy2(source_path,target_path);assert h(source_path)==h(target_path)==before
   files.append({'source':str(source_path),'destination':str(target_path),'bytes':source_path.stat().st_size,'sha256':before})
  assert mt.cache_state(new_binary,fingerprint)=='hit'
  row.update(copied=True,new_cache_state='hit',files=files)
 rows.append(row)
core=[m for m in mt.MUTANTS if m.get('binary')!='bridge' and mt.definition_kind(m,source)[0] in ('run','equivalent')]
for m in core:
 record=records.get(m['id'],{});execution=record.get('execution',{})
 retain(m['id'],old_cache/m['id']/'_mut.exe',new_cache/m['id']/'_mut.exe',mt.mutant_fingerprint(m,source),execution.get('exe_sha256'),execution.get('head'))
first=next(record['execution'] for record in records.values() if record.get('execution',{}).get('baseline_exe_sha256'))
retain('_baseline',old_cache/'_baseline/baseline.exe',new_cache/'_baseline/baseline.exe',mt.baseline_fingerprint(source),first['baseline_exe_sha256'],first['head'])
print(json.dumps({'schema':'geo314-original-compile-cache-copy/1','policy':'Only original fingerprint/cache_state hits copied with exact original sidecars; original compilation provenance retained. Every oracle must still actually execute in subsequent full original command at new SHA.', 'sourceClosureSha256':source.closure,'oldLedgerPath':str(old_ledger),'oldLedgerSha256':h(old_ledger),'copied':sum(row['copied'] for row in rows),'candidates':len(rows),'rows':rows},ensure_ascii=False))
