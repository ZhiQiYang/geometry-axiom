"""Release only three authorised, clean standalone comparison Git clones; preserve raw runtimes."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, stat, subprocess, traceback
ROOT=Path('/tmp/geo261-cold-main-clone-release')
COLD=Path('/workspace/geo261-cold')
PUBLIC=Path('/workspace/geometry-axiom')
EXPECTED='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
BRANCH='architecture/geo261-integration-20261016'
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
report={'schema':'geo261-completed-cold-comparison-clone-release/1','started_utc':now(),'authorised_scope':[str(COLD/x/'work/p52-main/main') for x in ['g261r1','g261a1','g261r2']],'tool_sha256':sha(Path(__file__).read_bytes()),'clones':[]}
def write(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def run(dest,label,argv,cwd=None,check=True):
 d=dest/'commands'/label;d.mkdir(parents=True,exist_ok=False)
 r=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (d/'stdout.bin').write_bytes(r.stdout);(d/'stderr.bin').write_bytes(r.stderr)
 row={'command':argv,'cwd':str(cwd) if cwd else None,'actual_process_returncode':r.returncode,'stdout_bytes':len(r.stdout),'stdout_sha256':sha(r.stdout),'stderr_bytes':len(r.stderr),'stderr_sha256':sha(r.stderr),'ended_utc':now()}
 write(d/'command.json',row)
 if check:assert r.returncode==0,(label,r.returncode,r.stderr[:1000])
 return r.stdout
run(ROOT,'df-before',['df','-B1','/workspace','/tmp'])
public=run(ROOT,'github-public-head',['git','ls-remote','https://github.com/ZhiQiYang/geometry-axiom.git','refs/heads/'+BRANCH],PUBLIC).decode().strip().split()
assert len(public)==2 and public[1]=='refs/heads/'+BRANCH
pubsha=public[0];report['github_public_head']=pubsha
for name in ['g261r1','g261a1','g261r2']:
 dest=ROOT/name;dest.mkdir(exist_ok=False);repo=COLD/name/'work/p52-main/main';runtime=repo.parent
 row={'repo':str(repo),'expected_sha':EXPECTED,'started_utc':now(),'released':False};report['clones'].append(row)
 try:
  assert repo.is_dir() and not repo.is_symlink() and (repo/'.git').is_dir() and not (repo/'.git').is_symlink()
  def git(label,*args):return run(dest,label,['git',*args],repo)
  assert git('head','rev-parse','HEAD').decode().strip()==EXPECTED
  assert not git('status','status','--porcelain=v1','--untracked-files=all')
  assert not git('untracked','ls-files','--others','--exclude-standard','-z')
  assert not git('ignored','ls-files','--others','--ignored','--exclude-standard','-z')
  assert not git('unpublished','rev-list','--all','--not','--remotes=origin')
  worktrees=git('worktrees','worktree','list','--porcelain').decode()
  assert worktrees.count('worktree ')==1 and f'worktree {repo}\n' in worktrees
  flags=git('index-flags','ls-files','-v','-z').split(b'\0');assert all(x.startswith(b'H ') for x in flags if x)
  git('diff-index','diff-index','--exit-code','HEAD','--')
  git('refs','show-ref');git('reflogs','reflog','show','--all','--format=%H %gD %gs')
  tips=git('origin-tips','for-each-ref','--format=%(objectname) %(refname)','refs/remotes/origin').decode().splitlines();assert tips
  for i,line in enumerate(tips):
   tip,ref=line.split(' ',1)
   run(dest,f'public-ancestor-{i:02d}',['git','merge-base','--is-ancestor',tip,pubsha],PUBLIC)
  row['origin_tip_public_ancestry_verified']=True
  raw_index=git('index','ls-files','--stage','-z');raw_tree=git('tree','ls-tree','-rz','HEAD')
  index={};tree={}
  for line in raw_index.split(b'\0'):
   if not line:continue
   meta,path=line.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0';index[path]=(mode.decode(),oid.decode())
  for line in raw_tree.split(b'\0'):
   if not line:continue
   meta,path=line.split(b'\t',1);mode,kind,oid=meta.split();assert kind==b'blob';tree[path]=(mode.decode(),oid.decode())
  assert index==tree
  inventory=[]
  for path,(mode,oid) in sorted(index.items()):
   actual=repo/os.fsdecode(path);before=actual.lstat()
   if mode=='120000':assert actual.is_symlink();data=os.fsencode(os.readlink(actual))
   else:
    assert mode in ('100644','100755') and actual.is_file() and not actual.is_symlink()
    assert bool(before.st_mode&0o111)==(mode=='100755')
    data=actual.read_bytes()
   after=actual.lstat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
   blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==oid,('raw-bytes-differ-from-public-Git-blob',os.fsdecode(path),blob,oid)
   inventory.append({'path':os.fsdecode(path),'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data)})
  write(dest/'tracked-bytes-and-modes.json',inventory)
  row.update(tracked_files=len(inventory),tracked_bytes=sum(x['bytes'] for x in inventory),tracked_git_blobs_all_match=True)
  receipts=[]
  for label in ['p52-prepare-main','p52','p52-verifier']:
   rp=COLD/name/'special'/label/'receipt.json';data=rp.read_bytes();original=json.loads(data)
   assert original.get('ended') and original.get('exit_code') is not None and original.get('status')!='執行中'
   shutil.copy2(rp,dest/f'original-{label}-receipt.json')
   receipts.append({'path':str(rp),'sha256':sha(data),'ended':original['ended'],'status':original['status'],'original_exit_code':original['exit_code']})
  row['completed_original_receipts']=receipts
  preserved=[]
  for rawroot in [runtime/'tmp',COLD/name/'special/p52',COLD/name/'special/p52-verifier',COLD/name/'special/p52-prepare-main']:
   for f in sorted(rawroot.rglob('*')):
    if f.is_symlink():preserved.append({'path':str(f),'symlink':os.readlink(f)})
    elif f.is_file():preserved.append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
  write(dest/'preserved-runtime-raw-before.json',preserved)
  active=[]
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
   try:
    cwd=os.readlink(proc/'cwd')
    if cwd==str(repo) or cwd.startswith(str(repo)+'/'):active.append({'pid':int(proc.name),'cwd':cwd})
   except (OSError,PermissionError):pass
  write(dest/'active-cwd-users.json',active);assert not active
  assert git('final-head','rev-parse','HEAD').decode().strip()==EXPECTED
  assert not git('final-status','status','--porcelain=v1','--untracked-files=all')
  assert not git('final-ignored','ls-files','--others','--ignored','--exclude-standard','-z')
  assert git('final-index','ls-files','--stage','-z')==raw_index
  row['all_guards_passed']=True;write(dest/'receipt-before-delete.json',row)
  before=shutil.disk_usage('/workspace').free
  shutil.rmtree(repo)
  assert not repo.exists() and runtime.is_dir() and (runtime/'tmp').is_dir()
  after=shutil.disk_usage('/workspace').free
  for item in preserved:
   f=Path(item['path'])
   if 'symlink' in item:assert f.is_symlink() and os.readlink(f)==item['symlink']
   else:assert f.is_file() and f.stat().st_size==item['bytes'] and sha(f.read_bytes())==item['sha256']
  row.update(released=True,free_before_bytes=before,free_after_bytes=after,free_delta_bytes=after-before,preserved_runtime_raw_unchanged=True)
 except BaseException:
  row['error']=traceback.format_exc()
 row['ended_utc']=now();write(dest/'receipt.json',row);write(ROOT/'receipt.json',report)
 print(json.dumps({'name':name,'released':row['released'],'free_delta_bytes':row.get('free_delta_bytes'),'error':row.get('error')},ensure_ascii=False),flush=True)
run(ROOT,'df-after',['df','-B1','/workspace','/tmp'])
report['ended_utc']=now();report['released_count']=sum(x['released'] for x in report['clones']);write(ROOT/'receipt.json',report)
print(json.dumps({'released_count':report['released_count'],'receipt':str(ROOT/'receipt.json')}),flush=True)
