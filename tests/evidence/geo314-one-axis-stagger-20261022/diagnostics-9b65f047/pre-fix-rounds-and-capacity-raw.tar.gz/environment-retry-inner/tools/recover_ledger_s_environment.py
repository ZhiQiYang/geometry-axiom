"""Retry only the original #314 bridge mutation jobs after ENOSPC; preserve r1 core records."""
from pathlib import Path
import argparse
import ast
import collections
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import resource
import shutil
import sys
import traceback

SOURCE = '9b65f047d5fd470cdc89ce45e613d06af493b616'
REPO = Path('/tmp/g261-next314')
ORIGINAL = Path('/workspace/geo314-core-regenerate-s')
ORIGINAL_OUTER = Path('/workspace/geo314-core-outer/geo314-ledger-regenerate-s')
HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)

# This is only an environment identity check; it does not modify any original judge.
VERIFY = r'''from pathlib import Path
import hashlib,json,sys,subprocess
repo,work=map(Path,sys.argv[1:3]);sys.path.insert(0,str(repo/'tests'))
import mutate as mt
import mutation_bridge as mb
h=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo)==subprocess.check_output(['git','rev-parse','HEAD'],cwd=work)
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=work).strip()
a,b=mt.Sources(repo),mt.Sources(work)
assert a.closure==b.closure
def inputs(root):
 files=sorted([*root.glob('tests/*.py'),*root.glob('tests/*.c'),*root.glob('tests/fixtures/**/*.scene'),*root.glob('*.scene')])
 return [{'path':p.relative_to(root).as_posix(),'lfSha256':h(p.read_bytes().replace(b'\r\n',b'\n'))} for p in files]
left,right=inputs(repo),inputs(work);assert left==right
bridges=[m for m in mt.MUTANTS if m.get('binary')=='bridge']
hashes=[]
for m in bridges:
 x,y=mb.oracle_hash(m,repo),mb.oracle_hash(m,work);assert x==y
 hashes.append({'id':m['id'],'sourceOracleSha256':x,'scratchOracleSha256':y,'methods':m['tests']})
print(json.dumps({'schema':'geo314-recovery-scratch-identity/1','source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'closure_sha256':a.closure,'sourceAndScratchClosureEqual':True,'completeOracleInputsEqual':True,'oracleInputCount':len(left),'oracleInputs':left,'restoredMethods':mb.RESTORED,'bridgeMutants':hashes},ensure_ascii=False))
'''

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--heavy-lock', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    assert not out.exists() and not out.is_relative_to(REPO) and not REPO.is_relative_to(out)
    assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
    assert digest(HELPER.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
    original = json.loads((ORIGINAL / 'receipt.json').read_text())
    original_outer = json.loads((ORIGINAL_OUTER / 'receipt.json').read_text())
    assert original['sha'] == SOURCE and original['exit_code'] == 1 and original_outer['outer_process']['actual_process_returncode'] == 1
    assert [(x['label'], x['original_command_result']['actual_process_returncode']) for x in original['steps']] == [('precheck', 1), ('full-ledger', 2)]
    assert any('Errno 28' in x for x in original['errors'])
    seed = (ORIGINAL / 'ledger.json').read_bytes()
    old = json.loads(seed)
    tree = ast.parse((REPO / 'tests/mutate.py').read_text())
    bridge_ids = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'dict':
            keywords = {k.arg: k.value for k in node.keywords}
            if isinstance(keywords.get('binary'), ast.Constant) and keywords['binary'].value == 'bridge':
                bridge_ids.append(keywords['id'].value)
    assert len(bridge_ids) == len(set(bridge_ids)) == 40
    preserved = {key: row for key, row in old.items() if key not in bridge_ids and row.get('execution', {}).get('head') == SOURCE}
    assert len(preserved) == 57
    assert dict(collections.Counter(row['verdict'] for row in preserved.values())) == {'killed': 52, 'equivalent': 4, 'crashed': 1}
    out.mkdir(parents=True)
    (out / 'tmp').mkdir(); (out / 'cache').mkdir(); (out / 'tools').mkdir()
    (out / 'ledger.json').write_bytes(seed)
    (out / 'seed-ledger-r1.json').write_bytes(seed)
    shutil.copy2(Path(__file__), out / 'tools' / Path(__file__).name)
    shutil.copy2(HELPER, out / 'tools/capture.py')
    (out / 'tools/verify_scratch.py').write_text(VERIFY, encoding='utf-8')
    spec = importlib.util.spec_from_file_location('geo314_recovery_capture', HELPER)
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    cleared = sorted(k for k in os.environ if k.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_')) or k in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE', 'NODE_OPTIONS', 'LD_PRELOAD'))
    env = {k: v for k, v in os.environ.items() if k not in cleared}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(out / 'tmp'), MUTATE_CACHE=str(out / 'cache'), MUTATE_RESULTS=str(out / 'ledger.json'),
               GITHUB_SHA=SOURCE, GITHUB_WORKSPACE=str(REPO))
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
    recorder = capture.Recorder(out, env, SOURCE)
    report = {'schema': 'geo314-ledger-environment-recovery/1', 'sha': SOURCE, 'repo': str(REPO), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'policy': 'r1 full-ledger 2 與缺失 checkafter/source_after 原封保留；同S只重40原bridge IDs，原57core execution紀錄逐bytes保留；不冒稱單次full0。',
              'original_attempt': {'inner': str(ORIGINAL), 'outer': str(ORIGINAL_OUTER), 'inner_exit': original['exit_code'], 'full_ledger_exit': 2,
                  'checkafter_executed': False, 'source_after_recorded': False, 'receipt_sha256': digest((ORIGINAL / 'receipt.json').read_bytes()),
                  'outer_receipt_sha256': digest((ORIGINAL_OUTER / 'receipt.json').read_bytes()), 'seed_ledger_sha256': digest(seed)},
              'bridge_ids': bridge_ids, 'preserved_core_ids': sorted(preserved), 'preserved_core_count': len(preserved),
              'environment': {key: env.get(key) for key in ('PATH', 'LANG', 'LC_ALL', 'PYTHONDONTWRITEBYTECODE', 'PYTHONOPTIMIZE', 'TMPDIR', 'MUTATE_CACHE', 'MUTATE_RESULTS', 'GITHUB_SHA', 'GITHUB_WORKSPACE')},
              'cleared_environment_names': cleared, 'platform': platform.platform(), 'python': sys.version,
              'stack_before': [soft, hard], 'stack_during': [16384 * 1024, hard], 'steps': [], 'errors': [], 'exit_code': None}
    def record():
        report['commands'] = recorder.rows
        save(out / 'receipt.json', report)
    def command(label, argv, cwd=REPO, data=None, timeout=None):
        row, stdout, stderr = recorder.run(argv, cwd=cwd, data=data, timeout=timeout, check=False,
            source_sha=SOURCE, source_variant='clean-same-source-environment-recovery')
        report['steps'].append({'label': label, 'original_command_result': row}); record()
        return row, stdout, stderr
    def state(label):
        hr, head, _ = command(label + '-head', ['git', 'rev-parse', 'HEAD'])
        sr, status, _ = command(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
        assert hr['actual_process_returncode'] == sr['actual_process_returncode'] == 0
        return {'head': head.decode().strip(), 'status': status.decode()}
    code = 1
    record()
    with args.heavy_lock.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            report['source_before'] = state('before')
            assert report['source_before'] == {'head': SOURCE, 'status': ''}
            work = out / 'cache/_bridge-work' / SOURCE / 'repo'
            work.parent.mkdir(parents=True)
            clone, _, _ = command('scratch-clone', ['git', 'clone', '--shared', '--no-checkout', str(REPO), str(work)])
            assert clone['actual_process_returncode'] == 0
            # Remove only historical evidence payload from the temporary filesystem.
            # The complete product include closure, every oracle input and original RESTORED judge stay exact.
            sparse, _, _ = command('scratch-sparse', ['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=work,
                                    data=b'/*\n!/evidence/\n!/tests/evidence/\n!/tests/release-evidence/\n')
            assert sparse['actual_process_returncode'] == 0
            checkout, _, _ = command('scratch-checkout', ['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', SOURCE], cwd=work)
            assert checkout['actual_process_returncode'] == 0
            verify, stdout, _ = command('scratch-identity', [sys.executable, '-B', str(out / 'tools/verify_scratch.py'), str(REPO), str(work)])
            assert verify['actual_process_returncode'] == 0
            identity = json.loads(stdout); save(out / 'SCRATCH_IDENTITY.json', identity)
            assert [row['id'] for row in identity['bridgeMutants']] == bridge_ids
            check_before, _, _ = command('precheck-partial-r1', ['python3', '-B', 'tests/mutate.py', '--check'])
            subset, _, _ = command('original-bridge-ids', ['python3', '-B', 'tests/mutate.py', *bridge_ids])
            check_after, _, _ = command('strict-checkafter', ['python3', '-B', 'tests/mutate.py', '--check'])
            final = json.loads((out / 'ledger.json').read_text())
            report['preserved_core_records_exactly_equal'] = all(final[key] == row for key, row in preserved.items())
            assert report['preserved_core_records_exactly_equal']
            report['all_record_verdict_counts'] = dict(collections.Counter(row['verdict'] for row in final.values()))
            report['record_count'] = len(final)
            report['all_nonretired_execution_head_equal_source'] = all(row['execution']['head'] == SOURCE for row in final.values() if row['verdict'] != 'retired')
            assert report['all_nonretired_execution_head_equal_source']
            code = next((row['actual_process_returncode'] for row in (subset, check_after) if row['actual_process_returncode'] != 0), 0)
        except BaseException:
            report['errors'].append(traceback.format_exc()); code = 1
        finally:
            try:
                report['source_after'] = state('after')
                assert report['source_after'] == report['source_before']
            except BaseException:
                report['errors'].append(traceback.format_exc()); code = 1
            report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), ledger_sha256=digest((out / 'ledger.json').read_bytes()))
            record()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code}, ensure_ascii=False), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
