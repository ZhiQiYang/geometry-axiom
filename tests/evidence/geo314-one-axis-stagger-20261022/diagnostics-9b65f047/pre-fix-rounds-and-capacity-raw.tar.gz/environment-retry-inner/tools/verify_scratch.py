from pathlib import Path
import hashlib,json,sys,subprocess
repo,work=map(Path,sys.argv[1:3]);sys.path.insert(0,str(repo/'tests'))
import mutate as mt
import mutation_bridge as mb
h=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo)==subprocess.check_output(['git','rev-parse','HEAD'],cwd=work)
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=work).strip()
a,b=mt.Sources(repo),mt.Sources(work)
assert a.closure==b.closure
def inputs(root):
 files=sorted([*root.glob('tests/*.py'),*root.glob('tests/*.c'),*root.glob('tests/fixtures/**/*.scene'),*root.glob('*.scene')])
 return [{'path':p.relative_to(root).as_posix(),'lfSha256':h(p.read_bytes().replace(b'\r\n',b'\n'))} for p in files]
left,right=inputs(repo),inputs(work);assert left==right
bridges=[m for m in mt.MUTANTS if m.get('binary')=='bridge']
hashes=[]
for m in bridges:
 x,y=mb.oracle_hash(m,repo),mb.oracle_hash(m,work);assert x==y
 hashes.append({'id':m['id'],'sourceOracleSha256':x,'scratchOracleSha256':y,'methods':m['tests']})
print(json.dumps({'schema':'geo314-recovery-scratch-identity/1','source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'closure_sha256':a.closure,'sourceAndScratchClosureEqual':True,'completeOracleInputsEqual':True,'oracleInputCount':len(left),'oracleInputs':left,'restoredMethods':mb.RESTORED,'bridgeMutants':hashes},ensure_ascii=False))
