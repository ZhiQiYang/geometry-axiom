#!/usr/bin/env python3
"""在固定乾淨SHA以Linux原subreaper/既有heavy lock重產架構四檔；不寫來源repo。"""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import signal
import subprocess
import sys
import traceback

BASE=Path(__file__).resolve().parent
NAMES=('run.py','refresh_architecture_core.py','reap_children.py')

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def require(ok,message):
    if not ok:raise RuntimeError(message)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--heavy-lock',required=True,type=Path)
    args=parser.parse_args()
    require(platform.system()=='Linux','本driver使用Linux原subreaper')
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0'),'拒絕Python optimize，原裁判assertions必須生效')
    require(re.fullmatch('[0-9a-f]{40}',args.sha) is not None,'須明列固定來源完整40碼SHA')
    repo,out,lock_path=args.repo.resolve(),args.out.resolve(),args.heavy_lock.resolve()
    require(repo.is_dir() and not out.exists(),'repo須存在，out必須全新')
    require(not out.is_relative_to(repo) and not repo.is_relative_to(out),'out須在repo外且不能是repo祖先')
    require(lock_path.is_file() and not lock_path.is_relative_to(out),'須使用排程既有heavy-lock；不可另建或放out內')
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
    require(hard==resource.RLIM_INFINITY or hard>=16384*1024,'hard stack不足16MiB，不降低hard')
    out.mkdir(parents=True)
    (out/'tools').mkdir();(out/'outer').mkdir()
    sources={}
    for name in NAMES:
        raw=(BASE/name).read_bytes();sources[str(BASE/name)]={'bytes':len(raw),'sha256':digest(raw)}
        (out/'tools'/name).write_bytes(raw)
    cleared=[];env=dict(os.environ)
    for key in list(env):
        if key.startswith('GIT_') or key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP'):
            cleared.append(key);env.pop(key)
    env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',GITHUB_SHA=args.sha,GITHUB_WORKSPACE=str(repo),GEO261_REAPER_LOG=str(out/'outer/reaper.jsonl'))
    safe={key:env.get(key) for key in ('PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','GITHUB_SHA','GITHUB_WORKSPACE','GEO261_REAPER_LOG')}
    command=[sys.executable,'-B',str(out/'tools/reap_children.py'),sys.executable,'-B',str(out/'tools/refresh_architecture_core.py'),'--repo',str(repo),'--sha',args.sha,'--out',str(out/'refresh')]
    receipt={'schema':'geo323-linux-architecture-refresh-outer/1','source_sha':args.sha,'repo':str(repo),'out':str(out),'heavy_lock':str(lock_path),'argv':[sys.executable,*sys.argv],'command':command,'cwd':str(repo),'environment':safe,'clearedInheritedEnvironmentNames':cleared,'startedUtc':now(),'toolSources':sources,'stackBefore':[soft,hard],'stackDuring':[16384*1024,hard],'python':sys.version,'pythonExecutable':sys.executable,'platform':platform.platform(),'actual_process_returncode':None,'passed':False,'errors':[],'receivedSignals':[],'outputsDirectory':str(out/'refresh/new'),'sourceCheckoutModifiedByDriver':False,'publicationPerformed':False}
    save(out/'receipt.json',receipt)
    process=None;old_handlers={};lock=None
    def forward(signum,frame):
        receipt['receivedSignals'].append({'signal':signum,'utc':now()})
        if process is not None and process.poll() is None:
            process.send_signal(signum)
    try:
        lock=lock_path.open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
        for signum in (signal.SIGINT,signal.SIGTERM):
            old_handlers[signum]=signal.signal(signum,forward)
        save(out/'outer/request.json',receipt)
        with (out/'outer/stdout.bin').open('wb') as stdout,(out/'outer/stderr.bin').open('wb') as stderr:
            process=subprocess.Popen(command,cwd=repo,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
            process.wait()
        receipt['actual_process_returncode']=process.returncode
        receipt['stdout']={'path':str(out/'outer/stdout.bin'),'bytes':(out/'outer/stdout.bin').stat().st_size,'sha256':digest((out/'outer/stdout.bin').read_bytes())}
        receipt['stderr']={'path':str(out/'outer/stderr.bin'),'bytes':(out/'outer/stderr.bin').stat().st_size,'sha256':digest((out/'outer/stderr.bin').read_bytes())}
        reaper=[json.loads(line) for line in (out/'outer/reaper.jsonl').read_text().splitlines()]
        require(reaper and reaper[-1].get('event')=='完成','原subreaper未留下完整回收終態')
        primary=reaper[-1]['primary_returncode'];mapped=primary if primary>=0 else 128-primary
        require(mapped==process.returncode,'原subreaper真primary/outer退出碼不一致')
        receipt['reaperCompletion']=reaper[-1]
        result_path=out/'refresh/RESULT.json'
        if result_path.is_file():receipt['refreshResult']=json.loads(result_path.read_text())
        require(process.returncode==0 and receipt.get('refreshResult',{}).get('passed') is True,'架構重產未全綠；保留所有原raw/FAILED與部分產物，不聲稱完成')
        receipt['passed']=True
    except BaseException:
        receipt['errors'].append(traceback.format_exc())
    finally:
        for signum,handler in old_handlers.items():signal.signal(signum,handler)
        if process is not None and process.poll() is None:
            process.send_signal(signal.SIGTERM);process.wait()
        if process is not None:receipt['actual_process_returncode']=process.returncode
        for path,info in sources.items():
            if digest(Path(path).read_bytes())!=info['sha256']:
                receipt['errors'].append('driver source changed during execution: '+path)
        receipt['passed']=receipt['passed'] and not receipt['errors']
        receipt['finishedUtc']=now();receipt['exit_code']=0 if receipt['passed'] else 1
        save(out/'receipt.json',receipt)
        resource.setrlimit(resource.RLIMIT_STACK,(soft,hard))
        if lock is not None:
            fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    print(json.dumps({'receipt':str(out/'receipt.json'),'source_sha':args.sha,'actual_process_returncode':receipt['actual_process_returncode'],'passed':receipt['passed'],'outputs':receipt['outputsDirectory']},ensure_ascii=False),flush=True)
    return receipt['exit_code']

if __name__=='__main__':raise SystemExit(main())
