"""Freeze completed, original #323 PF3 and selected-suite diagnostics without rerunning."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/tmp/g261-next323')
WORK = Path('/workspace/geo323-work')
P = 'e9fffc1cb036b6e4538a23f4dd12a9e10c5136f9'
EMPTY = hashlib.sha256(b'').hexdigest()
SUITES = ('c:integrity', 'core:run_tests', 'py:test_bridge_integrity',
          'py:test_geo261_assembly_graph_product', 'py:test_geo261_candidate_cache',
          'py:test_geo261_contact_sources', 'py:test_geo261_graph_product',
          'py:test_geo261_host_facts_authority', 'py:test_geo261_load_residual',
          'py:test_geo261_source_index', 'py:test_geo261_wood_world_validation',
          'py:test_mutation_anchors')

def read_json(path):
    return json.loads(path.read_text())

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def digest(body):
    return hashlib.sha256(body).hexdigest()

def receipt(label):
    d = read_json(WORK / label / 'receipt.json')
    assert d['actual_process_returncode'] == 0, (label, d['actual_process_returncode'])
    assert d['sha'] == d['head_after'] == P
    assert d['status_before'] == d['status_after'] == ''
    assert d['patch_sha256'] == d['patch_after_sha256'] == EMPTY
    return d

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == P
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for label in ('pf3-full-01', 'targeted-12-01'):
    receipt(label)

summary = read_json(Path('/tmp/g261-next323-pf3-full-01/summary.json'))
assert summary['originalSourcesUnchanged'] is True
for label in ('baseline', 'restored'):
    d = summary[label]
    assert d['verdict'] == 'pass' and d['exit'] == 0
    assert d['counts'] == {'run': 20, 'failures': 0, 'errors': 0, 'skipped': 0}
assert len(summary['mutations']) == 19
for d in summary['mutations']:
    assert d['verdict'] == 'killed' and d['exit'] == 1
    assert d['counts'] == {'run': 1, 'failures': 1, 'errors': 0, 'skipped': 0}

frozen = WORK / 'targeted-12-frozen'
assert not frozen.exists()
shutil.copytree(WORK / 'targeted-12-01', frozen / 'outer')
logs = Path('/tmp/geometry-tests/run_all-logs')
stdout = (frozen / 'outer/command.stdout').read_text()
assert re.findall(r'^\[\d+/12\] (\S+) …$', stdout, re.M) == list(SUITES)
assert 'exit 0：' in stdout
rows = []
for name in SUITES:
    stem = name.replace(':', '_')
    chosen = [logs / (stem + '.log')]
    if name.startswith('py:'):
        chosen += [logs / (stem + '.json'), logs / (stem + '.unittest.log')]
        d = read_json(chosen[1])
        assert d['total'] == d['run'] == d['passed']
        assert d['failed'] == d['skipped'] == d['extra_errors'] == 0
        assert d['import_error'] is None
        rows.append({'suite': name, 'total': d['total'], 'passed': d['passed'],
                     'failed': 0, 'skipped': 0, 'seconds': d['seconds'],
                     'counts_source': 'original _unittest_runner JSON'})
    for source in chosen:
        assert source.is_file(), source
        target = frozen / 'suite-logs' / source.name
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(source, target)
    if name == 'c:integrity':
        body = chosen[0].read_text()
        m = re.search(r'^(\d+)/(\d+) integrity checks passed', body, re.M)
        assert m and m[1] == m[2]
        rows.append({'suite': name, 'total': int(m[2]), 'passed': int(m[1]),
                     'failed': 0, 'skipped': 0, 'counts_source': 'original C check-point result line'})
    if name == 'core:run_tests':
        body = chosen[0].read_text()
        m = re.search(r'^GEOMETRY_TEST_RESULT (.*)$', body, re.M)
        assert m
        d = json.loads(m[1])
        assert d['total'] == d['counts']['pass']
        assert d['counts']['fail'] == d['counts']['infrastructure'] == 0
        rows.append({'suite': name, 'total': d['total'], 'passed': d['counts']['pass'],
                     'failed': 0, 'skipped': 0, 'counts_source': 'original GEOMETRY_TEST_RESULT JSON line'})
write_json(frozen / 'metadata/suite-counts.json', rows)

binaries = []
for name in ('bridge', 'core', 'integrity'):
    source = Path('/tmp/geometry-tests') / (name + '.fingerprint.json')
    d = read_json(source)
    body = (source.parent / name).read_bytes()
    assert len(body) == d['exe_size'] and digest(body) == d['exe_sha256']
    for relative, expected in d['files'].items():
        assert digest((ROOT / relative).read_bytes().replace(b'\r\n', b'\n')) == expected, (name, relative)
    target = frozen / 'binaries' / source.name
    target.parent.mkdir(exist_ok=True)
    shutil.copy2(source, target)
    binaries.append({'path': str(source.parent / name), 'bytes': len(body),
                     'sha256': digest(body), 'source_fingerprint_files_verified': len(d['files']),
                     'source_fingerprint_hash_rule': 'original binaries.py SHA256 after CRLF to LF normalization',
                     'excluded_reason': 'rebuildable executable; original fingerprint and bytes/hash preserved'})
write_json(frozen / 'metadata/excluded-binaries.json', binaries)
shutil.copytree(WORK / 'targeted-12-freeze-attempt-01', frozen / 'packager-attempt-01')

tools = {'run_recorded.py': WORK / 'run_recorded.py', 'test_entry.py': WORK / 'test_entry.py',
         'reap_children.py': Path('/workspace/geo261-environment/reap_children.py'),
         'run_all.py': ROOT / 'tests/run_all.py', '_unittest_runner.py': ROOT / 'tests/_unittest_runner.py',
         'binaries.py': ROOT / 'tests/binaries.py', 'run_all.expected.json': ROOT / 'tests/run_all.expected.json',
         'publish_final_progress.py': Path(__file__)}
for name, source in tools.items():
    target = frozen / 'tools' / name
    target.parent.mkdir(exist_ok=True)
    shutil.copy2(source, target)

write_json(frozen / 'metadata/SCOPE.json', {
    'sha': P, 'source_tree_clean_before_and_after': True,
    'original_command': receipt('targeted-12-01')['command'],
    'selected_suites': list(SUITES), 'full_native_acceptance': False,
    'note': 'Original selected suites only. Whole-project ledger/architecture/native/performance run belongs to later final SHA.',
    'raw_streams': 'outer command stdout/stderr and original per-suite combined log/unittest log; original tools are unchanged',
    'excluded': 'Unselected preexisting /tmp/geometry-tests logs, rebuildable executables, and object files are excluded.',
})

evidence = ROOT / 'tests/evidence/geo261-load-residual-20261022'
raw = evidence / 'raw'
archive = raw / 'targeted-12-01.raw.tar.gz'
assert not archive.exists()
members = []
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for source in sorted(frozen.rglob('*')):
        if source.is_symlink() or not source.is_file():
            continue
        body = source.read_bytes()
        name = source.relative_to(frozen).as_posix()
        members.append({'path': name, 'bytes': len(body), 'sha256': digest(body)})
        tar.add(source, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for member, expected in zip(tar.getmembers(), members, strict=True):
        body = tar.extractfile(member).read()
        assert member.name == expected['path']
        assert len(body) == expected['bytes'] and digest(body) == expected['sha256']
write_json(raw / 'targeted-12-01.inventory.json', {'archive': archive.name,
           'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'members': members})
shutil.copytree(WORK / 'pf3-archive-preparation', evidence / 'pf3-full-original')

table = '\n'.join('| {suite} | {passed}/{total} | 0 | 0 |'.format(**row) for row in rows)
progress = f'''
## 固定公開 P 的完整 PF3 與原必要 targeted suites

產品／tests SHA 為 `{P}`，兩個原外層收據皆實際退出0，前後 HEAD 同 P、工作樹 clean、patch hash 為空patch SHA256。此段只增加證據；帳本、架構與完整 native／175 A/B/C／36交錯性能／profile 由後續最終 SHA 收據另列。

完整原 `tests/pf3_mutation_check.py --out /tmp/g261-next323-pf3-full-01 --jobs 1` 沒有縮減 CASES：baseline20／19個具名突變各正常退出1且killed／restored20，所有 errors=0、skips=0，原 summary 的 originalSourcesUnchanged=true。原21案完整build/tests/結果/fingerprints、20份實際mutant目標原bytes、外層command/env/SHA/exit/streams及原工具已封存；42份可重建執行檔以bytes/SHA另列。這不是只跑host-identity的替代工具。

原 `tests/run_all.py --build` 選定原必要八套與前三已修四套，真實12套全綠；runner的原始結尾明示部分執行，不能當完整驗收。結果如下（C integrity是check-point數）：

| suite | pass/total | fail | skip |
|---|---:|---:|---:|
{table}

所有12套專屬原logs、10份原unittest JSON、三份execution JSONL、temporary-build inputs、三個實際binary原fingerprint和bytes/SHA、外層命令／環境／SHA／退出碼／完整streams均已凍結。沒有收進其他舊suite日誌；沒有重新解讀紅燈成通過。

**邊界仍保留：** placement guard單刪的合法生命期fixture為0／0／0等價；配對控制只證明在anchor-invalidator fault前置下的第二防線0／1／0，不冒稱單fault必要性。舊 `AppFootprintMemo` never-invalidate檢查保留原斷言，只是手動memo單元檢查，不能當產品member_reads失效保證；新增自然warm的member fixture才對真產品路徑取證。sealed新guard只恢復內部H既有warm facts的相容性，不改公開K/W sealed新query政策。

下一步由固定最終來源重新檢查／必要時整份更新帳本，Linux重產架構四檔，再跑完整原native、175 A/B/C、36交錯量測與profile。不宣稱本段已完成整個#323。
'''
with (evidence / 'PROGRESS.md').open('a') as stream:
    stream.write(progress)
hashes = []
for path in sorted(evidence.rglob('*')):
    if path.is_file() and path != evidence / 'SHA256SUMS':
        hashes.append(digest(path.read_bytes()) + '  ' + path.relative_to(evidence).as_posix())
(evidence / 'SHA256SUMS').write_text('\n'.join(hashes) + '\n')
print(json.dumps({'sha': P, 'suites': rows, 'targeted_archive_bytes': archive.stat().st_size,
                  'targeted_members': len(members), 'evidence_files': len(hashes)}, ensure_ascii=False))
