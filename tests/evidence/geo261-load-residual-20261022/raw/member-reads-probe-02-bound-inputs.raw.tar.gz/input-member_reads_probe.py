"""Exercise real member-read cache keys and retain each original process stream."""
import json
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/tmp/g261-next323')
sys.path.insert(0, str(ROOT))
from tests.test_geo261_native_kernel import NativeBuild

OUT = Path(os.environ['GEO323_RECORD_OUT'])
H = ROOT / 'geometry-app/native/reference_sources.inc'
R = ROOT / 'geometry-core/references.inc'
G = ROOT / 'current_geometry.c'
CASES = ROOT / 'tests/geo261_member_reads_cases.inc'
ANCHORS = {
    'id': ('ctx->member_reads[i].anchor_valid&&ctx->member_reads[i].id==id',
           'ctx->member_reads[i].anchor_valid'),
    'invalidator': ('ctx->member_reads[i].anchor_valid=true;ctx->member_reads[i].footprint_valid=false;return true;',
                    'ctx->member_reads[i].anchor_valid=true;return true;'),
    'placement': ('&&ctx->member_reads[i].placement==request->placement_id', ''),
}

def absolute_includes(source, path):
    return re.sub(r'(^\s*#\s*include\s*)"([^"\n]+)"',
                  lambda m: m[1] + '"' + (path.parent / m[2]).resolve().as_posix() + '"', source, flags=re.M)

build = NativeBuild(kernel_only=True)
case_copy = build.work / 'member-reads-cases.inc'
case_copy.write_bytes(CASES.read_bytes())
inputs = []
for path in (H, R, G, CASES, Path(__file__).resolve()):
    body = path.read_bytes()
    target = OUT / ('input-' + path.name)
    target.write_bytes(body)
    inputs.append({'path': str(path), 'snapshot': str(target), 'bytes': len(body),
                   'sha256': hashlib.sha256(body).hexdigest()})
(OUT / 'INPUTS.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
source = absolute_includes(H.read_text(), H)
refs = absolute_includes(R.read_text(), R)
geometry = absolute_includes(G.read_bytes().decode('utf-8'), G)

def compile_variant(label, changes):
    changed = source
    for name in changes:
        before, after = ANCHORS[name]
        assert changed.count(before) == 1, name
        changed = changed.replace(before, after)
    h = build.work / (label + '-sources.inc')
    h.write_text(changed)
    r = build.work / (label + '-references.inc')
    r.write_text(refs.replace(H.as_posix(), h.as_posix()))
    g = build.work / (label + '-geometry.c')
    g.write_text(geometry.replace(R.as_posix(), r.as_posix()))
    client = build.work / (label + '-probe.c')
    client.write_text('#ifdef _WIN32\n#undef _WIN32\n#endif\n'
        '#define main member_read_product_main\n#include "' + g.as_posix() + '"\n#undef main\n'
        '#define REQUIRE(label,expr) do { if(!(expr)){fprintf(stderr,"ASSERT:%s line=%d expr=%s\\n",label,__LINE__,#expr);return false;} } while(0)\n'
        '#include "' + case_copy.as_posix() + '"\n'
        'int main(int argc,char **argv){if(argc!=2)return 2;bool ok;'
        'if(!strcmp(argv[1],"anchor-id"))ok=member_reads_anchor_id_case();'
        'else if(!strcmp(argv[1],"anchor-miss"))ok=member_reads_anchor_miss_case();'
        'else if(!strcmp(argv[1],"placement"))ok=member_reads_placement_key_case();'
        'else return 2;if(ok)printf("PASS %s\\n",argv[1]);return ok?0:1;}\n')
    return build.link(label, [build.compile(client, label)])

executables = {name: compile_variant(name, changes) for name, changes in (
    ('fixed', ()), ('old-id', ('id',)), ('old-invalidator', ('invalidator',)),
    ('old-placement-only', ('placement',)), ('old-invalidator-and-placement', ('invalidator', 'placement')))}

records = []
def run(phase, variant, case, expected, marker=None):
    command = [str(executables[variant]), case]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=30)
    record = {'phase': phase, 'variant': variant, 'case': case, 'argv': command, 'cwd': str(ROOT),
              'actual_process_returncode': result.returncode, 'timeout_expired': False,
              'stdout': result.stdout, 'stderr': result.stderr, 'expected_exit': expected,
              'expected_marker': marker}
    records.append(record)
    (OUT / 'member-reads-proof.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)
    assert result.returncode == expected, record
    if marker:
        assert result.stdout == '' and result.stderr.startswith('ASSERT:' + marker + ' ') and len(result.stderr.splitlines()) == 1, record
    else:
        assert result.stdout == 'PASS ' + case + '\n' and result.stderr == '', record

run('anchor-id-baseline', 'fixed', 'anchor-id', 0)
run('anchor-id-withdrawn', 'old-id', 'anchor-id', 1, 'member-anchor-cache-id-must-match')
run('anchor-id-restored', 'fixed', 'anchor-id', 0)
run('anchor-miss-baseline', 'fixed', 'anchor-miss', 0)
run('anchor-miss-withdrawn', 'old-invalidator', 'anchor-miss', 1, 'member-anchor-miss-invalidates-footprint')
run('anchor-miss-restored', 'fixed', 'anchor-miss', 0)
run('placement-single-fault-baseline', 'fixed', 'placement', 0)
run('placement-single-fault-still-green', 'old-placement-only', 'placement', 0)
run('placement-single-fault-restored', 'fixed', 'placement', 0)
run('placement-paired-invalidator-fault-baseline', 'old-invalidator', 'placement', 0)
run('placement-paired-guard-withdrawn', 'old-invalidator-and-placement', 'placement', 1, 'contact-footprint-cache-placement-must-match')
run('placement-paired-guard-restored', 'old-invalidator', 'placement', 0)
for item in inputs:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
