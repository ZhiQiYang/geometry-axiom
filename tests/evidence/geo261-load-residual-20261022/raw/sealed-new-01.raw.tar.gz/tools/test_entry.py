"""Run an unchanged Python test entry and preserve disposable build source/logs."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import tarfile

target = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(target.parents[1]))
sys.argv = [str(target), *sys.argv[2:]]
try:
    runpy.run_path(str(target), run_name='__main__')
finally:
    scratch = Path(os.environ['TMPDIR']).resolve()
    output = Path(os.environ['GEO323_RECORD_OUT']).resolve()
    files = []
    with tarfile.open(output / 'temporary-build-inputs.tar.gz', 'w:gz', compresslevel=6) as archive:
        for path in sorted(scratch.rglob('*')):
            if path.is_symlink() or not path.is_file():
                continue
            if path.suffix not in ('.c', '.h', '.inc', '.json', '.jsonl', '.log', '.txt'):
                continue
            body = path.read_bytes()
            name = path.relative_to(scratch).as_posix()
            files.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
            archive.add(path, arcname=name, recursive=False)
    (output / 'temporary-build-inputs.inventory.json').write_text(json.dumps(files, ensure_ascii=False, indent=2) + '\n')
