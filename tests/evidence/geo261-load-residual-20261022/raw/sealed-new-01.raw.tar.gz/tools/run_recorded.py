"""Record one #323 diagnostic/test run under the shared cloud heavy lock."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
repo = a.repo.resolve()
out = a.out.resolve()
if out.exists() or not out.is_relative_to(Path('/workspace/geo323-work')):
    raise ValueError('Use a new output directory under /workspace/geo323-work')
out.mkdir(parents=True)
command = a.command[1:] if a.command[:1] == ['--'] else a.command
if not command:
    raise ValueError('A real command is required')
scratch = Path('/tmp/g261-next323-tmp') / out.name
scratch.mkdir(parents=True, exist_ok=False)
def dump(name, data):
    (out / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
def digest(body):
    return hashlib.sha256(body).hexdigest()
def git(label, *args):
    result = subprocess.run(['git', *args], cwd=repo, capture_output=True)
    (out / (label + '.stdout')).write_bytes(result.stdout)
    (out / (label + '.stderr')).write_bytes(result.stderr)
    dump(label + '.json', {'command': ['git', *args], 'cwd': str(repo), 'exit': result.returncode})
    if result.returncode:
        raise RuntimeError('Git metadata failed: ' + label)
    return result.stdout
base = git('before-head', 'rev-parse', 'HEAD').decode().strip()
status = git('before-status', 'status', '--porcelain=v1', '--untracked-files=all')
patch = git('before-patch', 'diff', '--binary', 'HEAD')
env = {k: v for k, v in os.environ.items() if not k.startswith(('GEOMETRY_', 'GEO261_')) and k != 'PYTHONOPTIMIZE'}
env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8',
           TMPDIR=str(scratch), GITHUB_SHA=base, GITHUB_WORKSPACE=str(repo),
           GEO261_REAPER_LOG=str(out / 'reaper.jsonl'), GEO323_RECORD_OUT=str(out),
           GEO261_HOST_FACTS_EXECUTION_LOG=str(out / 'host-facts-execution.jsonl'),
           GEO261_CONTACT_SOURCES_EXECUTION_LOG=str(out / 'contact-sources-execution.jsonl'),
           GEO261_LOAD_RESIDUAL_EXECUTION_LOG=str(out / 'load-residual-execution.jsonl'))
before_stack = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, before_stack[1]))
argv = [sys.executable, '-B', '/workspace/geo261-environment/reap_children.py', *command]
row = {'schema': 'geo323-recorded-diagnostic/1', 'sha': base, 'source_variant': 'working-tree-with-explicit-patch',
       'status_before': status.decode(), 'patch_sha256': digest(patch), 'command': command,
       'reaper_command': argv, 'cwd': str(repo), 'started_epoch': time.time(),
       'environment': {k: env.get(k) for k in ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'GITHUB_SHA', 'GITHUB_WORKSPACE',
           'PYTHONOPTIMIZE', 'PYTHONDONTWRITEBYTECODE', 'PYTHONIOENCODING', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS',
           'GEO261_REAPER_LOG', 'GEO323_RECORD_OUT', 'GEO261_HOST_FACTS_EXECUTION_LOG', 'GEO261_CONTACT_SOURCES_EXECUTION_LOG',
           'GEO261_LOAD_RESIDUAL_EXECUTION_LOG')}, 'python': sys.version, 'platform': platform.platform(),
       'stack_before': before_stack, 'stack_during': resource.getrlimit(resource.RLIMIT_STACK), 'actual_process_returncode': None}
dump('receipt.json', row)
with Path('/tmp/g261r3/heavy.lock').open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    with (out / 'command.stdout').open('wb') as stdout, (out / 'command.stderr').open('wb') as stderr:
        result = subprocess.run(argv, cwd=repo, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    row.update(actual_process_returncode=result.returncode, ended_epoch=time.time(),
               stdout_sha256=digest((out / 'command.stdout').read_bytes()),
               stderr_sha256=digest((out / 'command.stderr').read_bytes()))
    row['head_after'] = git('after-head', 'rev-parse', 'HEAD').decode().strip()
    row['status_after'] = git('after-status', 'status', '--porcelain=v1', '--untracked-files=all').decode()
    row['patch_after_sha256'] = digest(git('after-patch', 'diff', '--binary', 'HEAD'))
    dump('receipt.json', row)
print(json.dumps({'out': str(out), 'sha': base, 'actual_process_returncode': result.returncode}, ensure_ascii=False))
raise SystemExit(result.returncode)
