"""Read-only W vocabulary inventory using the unchanged architecture lexer."""
import argparse, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--sha',required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args();repo=a.repo.resolve();out=a.out.resolve()
assert not out.exists() and not out.is_relative_to(repo)
out.mkdir(parents=True)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def state():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=repo).decode()}
before=state();assert before=={'head':a.sha,'status':''}
manifest_path=repo/'geometry-core/domain-decoupling/product-architecture.json'
receipt_path=repo/'geometry-core/domain-decoupling/product-architecture-receipt.json'
raw=manifest_path.read_bytes();current=json.loads(raw);sealed_receipt=json.loads(receipt_path.read_bytes())
assert digest(raw.replace(b'\r\n',b'\n'))==sealed_receipt['manifestSha256']
helper=Path('/workspace/geo314-architecture-tools/refresh_architecture_core.py')
scanner=repo/'tests/architecture_contract.py'
spec=importlib.util.spec_from_file_location('fixed_w_inventory_helper',helper)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
info={'path':str(scanner),'rawSha256':digest(scanner.read_bytes()),'lfSha256':digest(scanner.read_bytes().replace(b'\r\n',b'\n'))}
value=module.collect_w_guard_inventory(repo,current,current,a.sha,info)
(out/'inventory.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
after=state();assert after==before and manifest_path.read_bytes()==raw
report={'schema':'geometry-W-vocabulary-readiness/1','source_sha':a.sha,'source_before':before,'source_after':after,'manifest_sha256':digest(raw),'previous_receipt_source':sealed_receipt['sourceBaseHead'],'helper_sha256':digest(helper.read_bytes()),'tool_sha256':digest(Path(__file__).read_bytes()),'scanner':info,'missing_identifiers':value['missingIdentifiers'],'unexpected_identifiers':value['unexpectedIdentifiers'],'missing_strings':value['missingStrings'],'unexpected_strings':value['unexpectedStrings'],'manifest_matches_full_mechanical_union':value['manifestMatchesMechanicalUnion'],'scope':'唯讀完整W-token盤點，不代替架構三裁判或重產收據；不寫manifest。'}
(out/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(out/'audit-tool.py.txt').write_bytes(Path(__file__).read_bytes());(out/'inventory-helper.py.txt').write_bytes(helper.read_bytes())
print(json.dumps(report,ensure_ascii=False))
