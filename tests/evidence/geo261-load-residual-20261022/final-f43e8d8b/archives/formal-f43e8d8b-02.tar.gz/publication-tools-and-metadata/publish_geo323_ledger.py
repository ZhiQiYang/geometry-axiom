"""Install the genuinely completed ledger and its small primary command receipts."""
import collections
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

repo = Path('/tmp/g261-next323')
source = 'b823903e44aea091b70fd2f45b74dff6229776dc'
output = Path('/workspace/geo323-core-regenerate-e')
dest = repo / 'tests/evidence/geo261-load-residual-20261022/ledger-b823903e'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=repo)
report = json.loads((output / 'receipt.json').read_text())
outer = json.loads(Path('/workspace/geo323-core-outer/ledger-regenerate-e/receipt.json').read_text())
assert report['exit_code'] == outer['outer_process']['actual_process_returncode'] == 0
assert [(s['label'], s['original_command_result']['actual_process_returncode']) for s in report['steps']] == [('precheck', 1), ('full-ledger', 0), ('checkafter', 0)]
assert report['source_before'] == report['source_after'] == {'head': source, 'status': ''}
data = json.loads((output / 'ledger.json').read_text())
counts = dict(collections.Counter(row['verdict'] for row in data.values()))
assert counts == {'killed': 70, 'equivalent': 4, 'crashed': 1, 'retired': 3}
assert all(row['execution']['head'] == source for row in data.values() if row['verdict'] != 'retired')
dest.mkdir(parents=True, exist_ok=False)
for label, root in [('inner', output), ('outer', Path('/workspace/geo323-core-outer/ledger-regenerate-e'))]:
    target = dest / label
    target.mkdir()
    for p in root.iterdir():
        if p.is_file() and p.name != 'ledger.json':
            shutil.copy2(p, target / p.name)
        elif p.is_dir() and p.name in ('subcommands', 'tools'):
            shutil.copytree(p, target / p.name)
shutil.copy2(output / 'ledger.json', repo / 'tests/mutants_results.json')
(dest / 'PROGRESS.md').write_text('''# #323 整份突變帳本重產

產品／測試提交 P：`e9fffc1cb036b6e4538a23f4dd12a9e10c5136f9`。
本輪完整重產實跑來源 S：`b823903e44aea091b70fd2f45b74dff6229776dc`（執行前後 HEAD 相同且乾淨）。

| 原命令 | 真實退出碼 |
|---|---:|
| `python3 tests/mutate.py --check`（重產前） | 1：75 stale |
| `python3 tests/mutate.py`（整份） | 0 |
| `python3 tests/mutate.py --check`（重產後） | 0 |

外層 reaper 的原子程序退出碼也是 0。完整重產始於 2026-10-22 22:51 UTC，於 23:38 UTC 結束。
78 筆紀錄中，75 筆實跑的 `execution.head` 全為上述 S：70 killed、4 equivalent、1 crashed（M20）；另 3 retired。
沒有 survived／invalid／stale／blocked；M20 沒有冒稱斷言 killed。帳本保留原真實執行來源，不改成保存帳本的提交 SHA。

本目錄 `inner/` 與 `outer/` 保存原 argv／退出碼／完整 stdin、stdout、stderr、安全環境、SHA、堆疊與工具 bytes。
較大量的實際 mutant 原始碼、bridge build／test raw 正在獨立封存，後續補公開，原雲端檔案仍保留。
下一步：在保存本帳本的新提交上重產 Linux 架構四檔，固定可解析的正式驗收 F，再跑完整 #323 原清單。
''', encoding='utf-8')
files = [p for p in sorted(dest.rglob('*')) if p.is_file()]
(dest / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(dest).as_posix()}\n' for p in files))
print(json.dumps({'source': source, 'counts': counts, 'primary_receipt_files': len(files), 'ledger_sha256': hashlib.sha256((repo / 'tests/mutants_results.json').read_bytes()).hexdigest(), 'directory': str(dest)}, ensure_ascii=False))
