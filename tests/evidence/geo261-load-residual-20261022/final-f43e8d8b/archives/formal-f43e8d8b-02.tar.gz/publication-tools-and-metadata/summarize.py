#!/usr/bin/env python3
"""只讀GEO-323 v2已保存receipt/raw，輸出新JSON；不執行或重判產品。"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

STAGES=('prepare','build','compare','perf','profile','required-eight','pf3','native')
SYMBOLS=('geo_eval_source','geo_eval_depend','wd_read','contact_order',
         'wood_contact_collect_stops','app_reference_member_footprint')
REQUIRED=('py:test_geo261_source_index','py:test_geo261_candidate_cache','py:test_geo261_graph_product',
          'py:test_geo261_assembly_graph_product','py:test_bridge_integrity','c:integrity',
          'core:run_tests','py:test_geo261_load_residual')
TOTAL=re.compile(r'^合計\(已執行、有計數者\)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+(?:\.\d+)?)\s*$')
TABLE=re.compile(r'^(\S+)\s+(\d+|-)\s+(\d+|ok|-)\s+(\d+|FAIL|-)\s+(\d+|-)\s+(\d+(?:\.\d+)?)\s*(.*)$')
PROGRESS=re.compile(r'^\[(\d+)/(\d+)\]\s+(\S+)\s+…')
NAMED=re.compile(r'^\s*(?:ASSERT:|AssertionError:|FAIL:|ERROR:|Traceback \(most recent call last\):)')

def observed(mapping,keys):
    return {k:mapping[k] for k in keys if k in mapping}

def epoch(value):
    try:return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
    except (TypeError,ValueError,AttributeError):return None

class Summary:
    def __init__(self,root):
        self.root=root.resolve();self.unavailable=[];self.refs={};self.command_rows=[]

    def path(self,value):
        p=Path(value);return p if p.is_absolute() else self.root/p

    def ref(self,value):
        p=self.path(value);key=str(p)
        if key in self.refs:return self.refs[key]
        row={'path':key,'bytes':None,'sha256':None,'available':False}
        self.refs[key]=row
        try:
            resolved=p.resolve()
            if not resolved.is_relative_to(self.root):raise ValueError('out外檔案不讀取')
            row['relative_path']=resolved.relative_to(self.root).as_posix()
            if not p.is_file():raise FileNotFoundError('檔案不存在或不是regular file')
            before=p.stat();digest=hashlib.sha256()
            with p.open('rb') as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
            after=p.stat()
            if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                raise ValueError('整理期間檔案變動；不視為固定raw')
            row.update(available=True,bytes=after.st_size,sha256=digest.hexdigest())
        except (OSError,ValueError) as error:
            row['unavailable']=str(error);self.unavailable.append({'path':key,'reason':str(error)})
        return row

    def data(self,value):
        p=self.path(value);ref=self.ref(p)
        if not ref['available']:return None
        try:return json.loads(p.read_bytes())
        except (OSError,ValueError,UnicodeError) as error:
            self.unavailable.append({'path':str(p),'reason':'JSON無法解析：'+str(error)})
            return None

    def text(self,value):
        p=self.path(value)
        if not self.ref(p)['available']:return None
        try:return p.read_bytes().decode('utf-8',errors='replace')
        except OSError as error:
            self.unavailable.append({'path':str(p),'reason':str(error)});return None

    def first_reply(self,value):
        text=self.text(value)
        if text is None:return None
        first=next((line for line in text.splitlines() if line.strip()),None)
        if first is None:return {'available':False,'reason':'空stdout，沒有loadfile JSON回覆'}
        try:reply=json.loads(first)
        except ValueError:return {'available':False,'reason':'第一非空行不是完整JSON；不猜測接受／拒絕'}
        if not isinstance(reply,dict) or type(reply.get('ok')) is not bool:
            return {'available':False,'reason':'第一JSON沒有明確boolean ok；不猜測接受／拒絕'}
        return {'available':True,'ok':reply['ok'],'original_first_reply':reply}

    def commands(self):
        for p in sorted((self.root/'invocations').glob('*/commands/*/result.json')):
            row=self.data(p)
            if not isinstance(row,dict):continue
            item=observed(row,('command','cwd','acceptance_sha','source_sha','source_role','started_utc',
                'ended_utc','started_epoch','ended_epoch','seconds','actual_process_returncode','timeout_expired',
                'launch_or_recording_error','stdout_bytes','stdout_sha256','stderr_bytes','stderr_sha256',
                'stdin_provided','stdin_sha256'))
            item['result_ref']=self.ref(p);item['directory']=str(p.parent)
            item['raw_paths']={name:str(p.parent/name) for name in ('stdout.bin','stderr.bin')}
            if row.get('stdin_provided') is True or (p.parent/'stdin.bin').is_file():item['raw_paths']['stdin.bin']=str(p.parent/'stdin.bin')
            item['raw_availability']={name:Path(path).is_file() for name,path in item['raw_paths'].items()}
            for name,present in item['raw_availability'].items():
                if not present:self.unavailable.append({'path':item['raw_paths'][name],'reason':'原command stream／stdin缺檔；僅存原result記錄hash'})
            item['stream_hash_origin']='原result.json記錄值；此索引不重新散列所有command streams'
            self.command_rows.append(item)
        return self.command_rows

    def stage(self,name,receipt):
        stages=receipt.get('stages') if isinstance(receipt,dict) else None
        value=stages.get(name) if isinstance(stages,dict) else None
        if not isinstance(value,dict):return {'recorded':None,'completed':None,'commands':None,'unavailable':'stage未記錄'}
        start,end=epoch(value.get('started_utc')),epoch(value.get('ended_utc'))
        related=None if start is None or end is None else [i for i in self.command_rows
            if isinstance(i.get('started_epoch'),(int,float)) and start<=i['started_epoch']<=end]
        identity={}
        for key in ('source_before','source_after'):
            state=value.get(key);answer=None
            if isinstance(state,dict) and 'head' in state and 'status' in state and receipt.get('source_sha') is not None:
                answer=state['head']==receipt['source_sha'] and state['status']==''
            identity[key]={'recorded':state,'matches_recorded_source_and_clean':answer}
        return {'recorded':value,'completed':True if end is not None and value.get('execution_exit') is not None else None,
                'source_identity':identity,'commands':related}

    def abc(self,receipt):
        path=self.root/'evidence/equivalence.json';data=self.data(path)
        inventory=self.data('evidence/scene-inventory.json')
        answer={'equivalence_ref':self.ref(path),'scene_inventory_ref':self.ref('evidence/scene-inventory.json'),
                'scene_inventory':inventory,'recorded_session_result':receipt.get('ABC_result'),
                'recorded_scenes':None,'recorded_version_runs':None,'original_failures':None,
                'failures_by_original_label':None,'load_reply_counts':None,'runs':None,
                'scope':'base/fix；B為每seal完整ordered graph，C為每scene/process五guard總數；不重新跑A/B/C裁判'}
        if not isinstance(data,dict):return answer
        runs=data.get('runs');failures=data.get('failures')
        answer.update(recorded_scenes=data.get('scenes'),recorded_version_runs=len(runs) if isinstance(runs,list) else None,
                      original_failures=failures)
        if isinstance(failures,list):
            answer['failures_by_original_label']={label:[f for f in failures if isinstance(f,list) and len(f)>1 and f[1]==label]
                for label in ('stdout','source graph (possible cross-consumer dependency loss)','guard traffic')}
        if not isinstance(runs,list):return answer
        counts={};observations=[]
        for row in runs:
            if not isinstance(row,dict):continue
            name,version=row.get('scene'),row.get('version')
            if not isinstance(name,str) or Path(name).name!=name or version not in ('base','fix'):
                observations.append({'recorded':row,'unavailable':'無法定位raw：scene/version schema不符'});continue
            stdout=self.root/'evidence/stdout'/version/(name+'.stdout')
            stderr=stdout.with_suffix('.stderr')
            graph=self.root/'evidence/graphs'/version/(name+'.bin.gz')
            reply=self.first_reply(stdout)
            bucket=counts.setdefault(version,{'accepted':0,'rejected':0,'unknown':0,'observed_runs':0})
            bucket['observed_runs']+=1
            bucket['accepted' if reply and reply.get('available') and reply['ok'] is True else
                   'rejected' if reply and reply.get('available') and reply['ok'] is False else 'unknown']+=1
            observations.append({'recorded':row,'loadfile_first_reply':reply,
                'stdout_ref':self.ref(stdout),'stderr_ref':self.ref(stderr),'graph_gzip_ref':self.ref(graph)})
        answer.update(load_reply_counts=counts,runs=observations)
        return answer

    def perf(self,receipt):
        path=self.root/'evidence/performance.json';data=self.data(path)
        answer={'performance_ref':self.ref(path),'recorded_targets':receipt.get('quantitative_targets'),
                'sample_count':None,'recorded_medians':None,'sample_exit_counts':None,'samples':None,
                'scope':'原base→fix→main交錯；不重算中位數／1.3／4.5門檻或新增判決'}
        if not isinstance(data,dict):return answer
        answer['recorded_medians']=data.get('medians');samples=data.get('samples')
        if not isinstance(samples,list):return answer
        answer['sample_count']=len(samples);counts=Counter();observations=[]
        for row in samples:
            if not isinstance(row,dict):continue
            counts[str(row.get('exit'))]+=1
            n,version,round_=row.get('n'),row.get('version'),row.get('round')
            if not isinstance(n,int) or not isinstance(round_,int) or version not in ('base','fix','main'):
                observations.append({'recorded':row,'unavailable':'sample schema不符，不猜測raw路徑'});continue
            path=self.root/'evidence/performance-stdout'/f'{version}-{n}-{round_}.stdout'
            observations.append({'recorded':row,'loadfile_first_reply':self.first_reply(path),
                'stdout_ref':self.ref(path),'stderr_ref':self.ref(path.with_suffix('.stderr'))})
        answer.update(sample_exit_counts=dict(counts),samples=observations);return answer

    def profile(self,receipt):
        data=self.data('evidence/profile-counts.json');profiles={}
        for version in ('base','fix'):
            for n in (32,64):
                key=f'{version}-{n}';row=data.get(key) if isinstance(data,dict) else None
                checks={}
                for step in ('load','gprof'):
                    path=self.root/'evidence/checks'/f'profile-{key}-{step}.json'
                    checks[step]={'recorded':self.data(path),'result_ref':self.ref(path),
                        'stdout_ref':self.ref(path.with_suffix('.stdout')),'stderr_ref':self.ref(path.with_suffix('.stderr'))}
                profiles[key]={'recorded':row,'gprof_stdout_ref':self.ref(f'evidence/gprof-{key}.stdout'),
                    'gmon_gzip_ref':self.ref(f'evidence/gmon-{key}.gz'),'commands':checks}
        targets=receipt.get('quantitative_targets')
        return {'counts_ref':self.ref('evidence/profile-counts.json'),'profiles':profiles,'symbols':SYMBOLS,
                'recorded_geo_eval_target':targets.get('geo_eval_source_64_32') if isinstance(targets,dict) else None,
                'scope':'原4profiles／6symbols；counts、matched_lines、missing原樣引用；缺檔不補0；不重新解析gprof或計算ratio'}

    def suite(self,kind):
        candidates=[]
        for row in self.command_rows:
            argv=row.get('command') or []
            is_run_all=any(str(x).replace('\\','/').endswith('tests/run_all.py') for x in argv)
            if is_run_all and (('--only' in argv)==(kind=='required-eight')):candidates.append(row)
        answer={'commands':candidates,'aggregate':None,'registered_progress':None,'table_rows':None,
                'original_final_exit_lines':None,'unittest_results':[],'suite_logs_directory':str(self.root/'evidence'/(kind+'-suite-logs'))}
        if len(candidates)!=1:
            answer['unavailable']='預期一個原run_all命令，實際找到'+str(len(candidates))+'個；不猜選哪次'
        else:
            command=candidates[0];stdout=Path(command['directory'])/'stdout.bin';text=self.text(stdout)
            answer['stdout_ref']=self.ref(stdout);answer['stderr_ref']=self.ref(Path(command['directory'])/'stderr.bin')
            if text is not None:
                totals=[];table=[];progress=[];exits=[];in_table=False
                for line in text.splitlines():
                    if re.match(r'^suite\s+測試數\s+pass\s+fail\s+skip\s+秒',line):in_table=True
                    match=TOTAL.match(line)
                    if match:
                        a,b,c,d,seconds=match.groups();totals.append({'total':int(a),'passed':int(b),'failed':int(c),'skipped':int(d),'suite_sum_seconds':float(seconds),'raw_line':line})
                        in_table=False
                    match=TABLE.match(line) if in_table else None
                    if match:
                        name,total,passed,failed,skip,seconds,note=match.groups()
                        table.append({'suite':name,'original_cells':{'total':total,'passed':passed,'failed':failed,'skipped':skip,'seconds':seconds},
                            'observed_numeric_counts':{key:int(value) if value.isdigit() else None for key,value in
                                (('total',total),('passed',passed),('failed',failed),('skipped',skip))},
                            'seconds':float(seconds),'note':note,'raw_line':line})
                    match=PROGRESS.match(line)
                    if match:progress.append({'index':int(match[1]),'registered_count':int(match[2]),'suite':match[3]})
                    if re.match(r'^exit \d+：',line):exits.append(line)
                answer['aggregate']=totals[0] if len(totals)==1 else None
                answer['aggregate_candidates']=totals;answer['table_rows']=table;answer['registered_progress']=progress
                answer['table_row_count']=len(table);answer['last_progress_marker']=progress[-1] if progress else None
                answer['original_final_exit_lines']=exits
                answer['partial_notice_present']='==== 部分／示範執行，不可當完整驗收 ====' in text
        logs=self.root/'evidence'/(kind+'-suite-logs')
        for path in sorted(logs.glob('*.json')):
            data=self.data(path)
            answer['unittest_results'].append({'ref':self.ref(path),'recorded':data,
                'suite_log_ref':self.ref(path.with_suffix('.log')),'unittest_log_ref':self.ref(path.with_suffix('.unittest.log'))})
        answer['scope_note']='aggregate取原合計列；不以unittest JSON加總替代C/node/exit-code-only等混合計數；不自行判允許skip'
        if kind=='required-eight':answer['required_names_reference']=REQUIRED
        return answer

    def pf3(self):
        root=self.root/'evidence/pf3';path=root/'summary.json';data=self.data(path)
        answer={'summary_ref':self.ref(path),'sources_ref':self.ref(root/'sources.json'),'format':None,
                'recorded_summary':data,'mutant_count':None,'verdict_counts':None,'cases':None,
                'scope':'summary為最終verdict；case result/stdout可能仍是identical-binary重分類前值；不自行重判killed'}
        if isinstance(data,list):answer['format']='baseline-only-list';rows=data
        elif isinstance(data,dict):
            answer['format']='normal-object';mutants=data.get('mutations')
            answer['mutant_count']=len(mutants) if isinstance(mutants,list) else None
            answer['verdict_counts']=dict(Counter(r.get('verdict','missing') for r in mutants if isinstance(r,dict))) if isinstance(mutants,list) else None
            rows=[data.get('baseline'),*(mutants if isinstance(mutants,list) else []),data.get('restored')]
        else:return answer
        cases=[]
        for row in rows:
            if not isinstance(row,dict):continue
            name=row.get('id')
            if not isinstance(name,str) or Path(name).name!=name:
                cases.append({'recorded':row,'unavailable':'沒有安全可定位id'});continue
            directory=root/name;entry={'final_recorded':row,'case_result_ref':self.ref(directory/'result.json'),
                'tests_counts_ref':self.ref(directory/'binaries/tests.json'),'tests_counts':self.data(directory/'binaries/tests.json')}
            for step in ('build','tests'):
                base=directory/step;entry[step]={'execution_ref':self.ref(base/'execution.json'),'recorded_execution':self.data(base/'execution.json'),
                    'stdout_ref':self.ref(base/'stdout'),'stderr_ref':self.ref(base/'stderr')}
            cases.append(entry)
        answer['cases']=cases;return answer

    def jsonl(self,kind,name):
        path=self.root/'evidence'/(kind+'-executions')/(name+'.jsonl');ref=self.ref(path)
        answer={'ref':ref,'record_count':None,'parse_errors':None,'observed_exit_counts':None,'records':None,
            'scope':'只索引觀察；不以phase名稱或exit1推定killed，不補不存在的environment欄；timeout/啟動例外可能未寫任何行'}
        text=self.text(path)
        if text is None:return answer
        records=[];errors=[];counts=Counter()
        for line_no,line in enumerate(text.splitlines(),1):
            if not line.strip():continue
            try:row=json.loads(line)
            except ValueError as error:errors.append({'line':line_no,'error':str(error)});continue
            if not isinstance(row,dict):errors.append({'line':line_no,'error':'不是JSON object'});continue
            exits=observed(row,('actual_process_returncode','actual_exit','returncode'))
            values=list(exits.values());code=values[0] if values and all(v==values[0] for v in values) else None
            counts[str(code)]+=1
            entry={'line':line_no,'recorded_keys':list(row),'exit_fields_present':exits,'unambiguous_observed_exit':code,
                'recorded_metadata':observed(row,('test','case','argv','command','cwd','phase','control','expected_assertion','source_sha',
                        'executable_sha256','timeout_expired','capture_mode','exception','error','launch_or_recording_error')),
                'environment_field_present':'environment' in row,'named_failure_lines':[]}
            if 'environment' in row:entry['recorded_environment']=row['environment']
            for stream in ('stdout','stderr'):
                if isinstance(row.get(stream),str):
                    entry['named_failure_lines'] += [{'stream':stream,'text':s} for s in row[stream].splitlines() if NAMED.match(s)]
            records.append(entry)
        answer.update(record_count=len(records),parse_errors=errors,observed_exit_counts=dict(counts),records=records)
        return answer

    def collect(self):
        receipt=self.data('receipt.json');receipt=receipt if isinstance(receipt,dict) else {}
        self.commands()
        result={'schema':'geo323-receipt-summary/1','created_utc':datetime.now(timezone.utc).isoformat(),
            'out':str(self.root),'root_receipt_ref':self.ref('receipt.json'),
            'recorded_root':observed(receipt,('schema','source_sha','source_repo','base','main','started_utc','updated_utc','status','errors',
                'wrapper_exit','full_acceptance_passed','all_executed_stage_commands_passed','all_measured_original_targets_met',
                'all_required_stages_completed','original_judges_modified','environment','platform','stack_before','stack_during','tool_hashes')),
            'stages':{n:self.stage(n,receipt) for n in STAGES},'builds_recorded':receipt.get('builds'),
            'ABC':self.abc(receipt),'performance':self.perf(receipt),'profile':self.profile(receipt),
            'required_eight':self.suite('required-eight'),'native':self.suite('native'),'PF3':self.pf3(),
            'native_execution_jsonl':{kind:{name:self.jsonl(kind,name) for name in ('host-facts','contact-sources','load-residual')}
                                      for kind in ('required-eight','native')},'outer_invocations':[],
            'policy':{'not_acceptance_gate':True,'product_executed':False,'tests_compiled_or_run':False,'git_tar_commit_push_executed':False,
                'new_thresholds_or_verdicts_created':False,'missing_is_unavailable_not_pass':True},
            'schema_limitations':[
                'run_all無全域JSON；總數採原文字合計列，個別unittest JSON只作細目，failed不等於failures陣列長度。',
                'stage.execution_exit可能是wrapper捕捉後的1；真子程序退出保留於command.actual_process_returncode，不互相覆寫。',
                'ABC只整理原report與raw接受/拒絕；不重新解壓完整圖或執行另一個A/B/C裁判。',
                'performance/profile medians、targets、counts、raw matches及missing皆引用原欄位；不補零／重算目標。',
                'JSONL沒有schema版本，host目前actual_process_returncode，contact/load目前actual_exit；只採原有欄位。',
                'JSONL timeout/啟動exception可能無紀錄；行數或沒有timeout=true不能證沒有例外。',
                'load舊負控可能phase=positive且marker=null；single-mutant-equivalent可能exit0，不能按名稱分類killed。',
                'PF3最終summary可將verdict改為identical-binary而case檔未改；baseline失敗時summary是list。']}
        for path in sorted((self.root/'control').glob('*/receipt.json')):
            result['outer_invocations'].append({'ref':self.ref(path),'recorded':self.data(path),
                                               'reaper_ref':self.ref(path.parent/'reaper.jsonl')})
        result['unavailable']=self.unavailable
        return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();output=args.output.resolve()
    if output.exists():parser.error('--output必須是新檔，不覆寫任何原收據')
    summary=Summary(args.out);result=summary.collect()
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'output':str(output),'unavailable_entries':len(summary.unavailable),'not_acceptance_gate':True},ensure_ascii=False))
    return 0

if __name__=='__main__':raise SystemExit(main())
