"""Archive completed original follow-up evidence; never run or reinterpret product tests."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--selection', type=Path, required=True)
parser.add_argument('--summary', type=Path, required=True)
parser.add_argument('--dest', type=Path, required=True)
args = parser.parse_args()
out, dest = args.out.resolve(), args.dest.resolve()
assert not dest.exists() and not dest.is_relative_to(Path('/tmp/g261-next323'))
receipt = json.loads((out / 'receipt.json').read_text())
assert receipt['source_sha'] == 'f43e8d8b876f587c11778fa74a80b205b51396b6'
assert receipt['all_required_stages_completed']
assert all(row.get('ended_utc') and row.get('execution_exit') is not None for row in receipt['stages'].values())
selection = json.loads(args.selection.read_text())
assert Path(selection['root']).resolve() == out
digest = lambda data: hashlib.sha256(data).hexdigest()
files = []
for row in selection['files']:
    p = Path(row['absolute'])
    assert p.resolve().is_relative_to(out) and p.is_file() and not p.is_symlink()
    files.append((p, 'acceptance-r1/' + row['path'], row['bytes'], row['sha256']))
for prefix, root in [('architecture-final', Path('/workspace/geo323-final-architecture-f43e8d8b')), ('architecture-final-outer', Path('/workspace/geo323-final-outer/architecture-f43e8d8b'))]:
    for p in sorted(root.rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            data = p.read_bytes()
            files.append((p, prefix + '/' + p.relative_to(root).as_posix(), len(data), digest(data)))
for p in [Path(__file__).resolve(), Path('/workspace/geo261-environment/geo323-preformal-cache-isolation.json'), Path('/workspace/geo261-environment/publish_geo323_ledger.py'), Path('/workspace/geo261-environment/install_geo323_architecture.py'), Path('/workspace/geo323-publication-tools/summarize.py'), args.selection.resolve(), args.summary.resolve()]:
    data = p.read_bytes()
    files.append((p, 'publication-tools-and-metadata/' + p.name, len(data), digest(data)))
assert len({name for _, name, _, _ in files}) == len(files)
dest.mkdir(parents=True)
(dest / 'archives').mkdir()
(dest / 'inventories').mkdir()
groups = [[]]
cost = 0
for row in files:
    estimate = ((row[2] + 511) // 512) * 512 + 2048
    assert estimate < 80 * 1024 * 1024, ('single raw member requires separate preservation', row[1], row[2])
    if groups[-1] and cost + estimate > 80 * 1024 * 1024:
        groups.append([])
        cost = 0
    groups[-1].append(row)
    cost += estimate
archives = []
for index, group in enumerate(groups, 1):
    archive = dest / 'archives' / f'formal-f43e8d8b-{index:02d}.tar.gz'
    members = []
    with tarfile.open(archive, 'w:gz', compresslevel=6) as handle:
        for p, name, size, expected in group:
            data = p.read_bytes()
            assert len(data) == size and digest(data) == expected, ('changed before archive', p)
            handle.add(p, arcname=name, recursive=False)
            members.append({'path': name, 'bytes': size, 'sha256': expected})
    with tarfile.open(archive) as handle:
        entries = handle.getmembers()
        assert len(entries) == len(members)
        for entry, row in zip(entries, members):
            assert entry.isfile() and entry.name == row['path'] and entry.size == row['bytes']
            data = handle.extractfile(entry).read()
            assert len(data) == row['bytes'] and digest(data) == row['sha256']
    assert archive.stat().st_size < 95 * 1024 * 1024
    inventory = dest / 'inventories' / (archive.name + '.members.json')
    inventory.write_text(json.dumps({'archive': archive.relative_to(dest).as_posix(), 'members': members}, ensure_ascii=False, indent=2) + '\n')
    archives.append({'path': archive.relative_to(dest).as_posix(), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'members': len(members), 'inventory': inventory.relative_to(dest).as_posix()})
shutil.copytree('/workspace/geo323-ledger-publication-STAGING', dest / 'ledger-audit')
shutil.copy2(args.summary, dest / 'FORMAL_METRICS.json')
shutil.copy2(out / 'receipt.json', dest / 'FORMAL_RECEIPT.json')
metadata = {'schema': 'geo323-formal-publication/1', 'source_sha': receipt['source_sha'], 'archive_count': len(archives), 'archives': archives, 'member_count': len(files), 'raw_bytes': sum(row[2] for row in files), 'product_commands_rerun': False, 'product_judgments_modified': False, 'original_wrapper_exit': receipt['wrapper_exit'], 'original_full_acceptance_passed': receipt['full_acceptance_passed'], 'measured_original_targets': receipt['quantitative_targets'], 'excluded_elf': selection['excluded_elf'], 'excluded_rebuildable_working_trees': selection['not_copied'], 'ledger_original_limitations': json.loads((dest / 'ledger-audit/SUMMARY.json').read_text())['limitations']}
(dest / 'PUBLICATION.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
(dest / 'README.md').write_text('''# #323 固定最終來源的完整雲端收據

正式受驗來源 F：`f43e8d8b876f587c11778fa74a80b205b51396b6`。
`FORMAL_RECEIPT.json` 保留各原 stage 退出、來源前後、量測目標與封裝退出碼；`FORMAL_METRICS.json` 只整理原資料，不代替裁判。
N64 fix/main **1.7457212386，未達原 1.3 目標**；source calls 64/32 **4.4704196928，達到原 ≤4.5**，三個小 N/base 亦達原不變慢目標。沒有放寬門檻或重抽。完整測試結果以原收據與 metrics 為準，不能將性能未達標寫成全驗收通過。

封包含原 175 場景 A/B/C、完整 ordered graphs、逐場景五 guard 總數、36 原計時、四原 profile/gprof/gmon、required-eight／完整 PF3／完整 native 的 argv、退出碼、環境、SHA 與完整 stdout/stderr；另有同 F 的三條原架構裁判。每個封包成員已解包核對 path／bytes／SHA-256。
原 Git archive stdout tar 原樣保留。可重建 checkout 與 ELF 未當作原始收據複製，排除項另列 metadata/hash。

`ledger-audit/` 是前一輪真 S=b823903e 的整份帳本稽核，與本輪 F 的正式驗收分欄。原工具未保存 core 內層各 attempt/compiler streams；完整 top-level 命令輸出、結構化結果與原 stream hashes 仍保留。75 mutant C 明標重建且逐一符合原編譯指紋，不能冒稱原捕獲。

本目錄只封存原結果，未重跑產品或改寫判準。產品／測試 P、帳本實跑 S／產物 L、架構實跑 L／產物 A=F、後續證據保存 E 的完整角色，見 PR 正文。
''', encoding='utf-8')
rows = [p for p in sorted(dest.rglob('*')) if p.is_file()]
(dest / 'SHA256SUMS').write_text(''.join(f'{digest(p.read_bytes())}  {p.relative_to(dest).as_posix()}\n' for p in rows))
print(json.dumps({'dest': str(dest), 'archives': len(archives), 'members': len(files), 'raw_bytes': metadata['raw_bytes'], 'wrapper_exit': receipt['wrapper_exit'], 'full_acceptance_passed': receipt['full_acceptance_passed']}))
