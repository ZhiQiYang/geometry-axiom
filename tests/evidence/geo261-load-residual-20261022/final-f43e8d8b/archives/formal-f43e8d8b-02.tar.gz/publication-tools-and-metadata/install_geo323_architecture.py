"""Install the Linux architecture artifacts without changing their execution source SHA."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

repo = Path('/tmp/g261-next323')
source = 'b7ca7843532098c4d3433035cde8dc2c43654978'
out = Path('/workspace/geo323-architecture-l-b7ca7843')
report = json.loads((out / 'refresh/RESULT.json').read_text())
outer = json.loads((out / 'receipt.json').read_text())
assert report['passed'] and report['scan_exit_code'] == 0 and report['validation_exit_codes'] == [0, 0]
assert outer['actual_process_returncode'] == 0 and outer['passed']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=repo)
dest = repo / 'tests/evidence/geo261-load-residual-20261022/architecture-b7ca7843'
dest.mkdir(parents=True, exist_ok=False)
archive = dest / 'linux-architecture-raw.tar.gz'
members = []
with tarfile.open(archive, 'w:gz') as handle:
    for p in sorted(out.rglob('*')):
        if p.is_file():
            name = p.relative_to(out).as_posix()
            data = p.read_bytes()
            members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
            handle.add(p, arcname=name, recursive=False)
with tarfile.open(archive) as handle:
    rows = handle.getmembers()
    assert len(rows) == len(members)
    for entry, row in zip(rows, members):
        data = handle.extractfile(entry).read()
        assert entry.name == row['path'] and len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
(dest / 'MEMBER_INVENTORY.json').write_text(json.dumps({'archive': archive.name, 'members': members}, indent=2) + '\n')
for name in ('product-architecture.json', 'product-architecture-scan.json', 'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json'):
    shutil.copy2(out / 'refresh/new' / name, repo / 'geometry-core/domain-decoupling' / name)
(dest / 'PROGRESS.md').write_text('''# #323 Linux 架構四檔

本輪重產實跑來源／帳本保存提交 L：`b7ca7843532098c4d3433035cde8dc2c43654978`。
原三條裁判均真 0：`architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json`、`test_architecture_contract.py`、`test_product_architecture.py`。
Linux 重產成功，601 executable files、333 owned sources、268 exclusions、796 edges、0 diagnostics；918 forbidden identifiers／55 forbidden strings。
manifest 原 bytes 未改。全部 input 的 raw／LF hashes、Git blobs、SSOT 與來源前後均核對，四個產物保留真 sourceBaseHead=L，不改寫為產物保存提交。

`linux-architecture-raw.tar.gz` 保存整輪原 argv、退出碼、完整 stdout／stderr、環境、工具、原始與新四檔、來源清單及 hash；每個封包成員已依 inventory 逐 bytes／SHA-256 核同。
下一步：一般推送這四份產物，固定正式驗收 F；等待其他診斷／封存停止重型工作後，依序執行 #323 完整清單與交錯性能量測。
''', encoding='utf-8')
files = [p for p in sorted(dest.iterdir()) if p.is_file()]
(dest / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in files))
print(json.dumps({'source': source, 'archive_bytes': archive.stat().st_size, 'members': len(members), 'counts': report['counts']}, ensure_ascii=False))
