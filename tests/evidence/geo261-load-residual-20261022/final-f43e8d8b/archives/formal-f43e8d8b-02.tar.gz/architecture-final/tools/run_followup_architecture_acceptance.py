"""Record the three original architecture commands at a fixed final source SHA."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
from pathlib import Path
import resource
import shutil
import sys
import traceback

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--sha', required=True)
parser.add_argument('--out', required=True, type=Path)
parser.add_argument('--heavy-lock', required=True, type=Path)
parser.add_argument('--mode', choices=('ledger-check', 'ledger-regenerate', 'native', 'architecture'), required=True)
args = parser.parse_args()
repo, out = args.repo.resolve(), args.out.resolve()
assert repo.is_dir() and not out.exists() and not out.is_relative_to(repo)
assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
out.mkdir(parents=True)
(out / 'tmp').mkdir()
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('original_capture', helper)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
cleared = sorted(k for k in os.environ if k.startswith(('GEOMETRY_', 'GIT_')) or k in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'NODE_OPTIONS', 'PYTHONOPTIMIZE', 'LD_PRELOAD', 'MUTATE_RESULTS', 'MUTATE_CACHE'))
env = {k: v for k, v in os.environ.items() if k not in cleared}
env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(out / 'tmp'), GITHUB_SHA=args.sha, GITHUB_WORKSPACE=str(repo))
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
if args.mode.startswith('ledger'):
    shutil.copy2(repo / 'tests/mutants_results.json', out / 'ledger.json')
    env['MUTATE_RESULTS'] = str(out / 'ledger.json')
(out / 'tools').mkdir()
for source in (Path(__file__).resolve(), helper):
    shutil.copy2(source, out / 'tools' / source.name)
recorder = capture.Recorder(out, env, args.sha)
report = {'schema': 'geometry-followup-core-acceptance/1', 'sha': args.sha, 'repo': str(repo), 'mode': args.mode, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stack_before': [soft, hard], 'stack_during': resource.getrlimit(resource.RLIMIT_STACK), 'tool_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'steps': [], 'errors': [], 'platform': platform.platform(), 'python': sys.version, 'python_executable': sys.executable, 'clearedInheritedEnvironmentNames': cleared, 'environment': {k: env.get(k) for k in ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'PYTHONOPTIMIZE', 'TMPDIR', 'GITHUB_SHA', 'GITHUB_WORKSPACE', 'MUTATE_RESULTS', 'MUTATE_CACHE', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'C_INCLUDE_PATH', 'CPATH', 'LIBRARY_PATH', 'LD_LIBRARY_PATH', 'GCC_EXEC_PREFIX', 'COMPILER_PATH')}}

def save():
    temporary = out / 'receipt.json.writing'
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(out / 'receipt.json')

def state():
    head = recorder.run(['git', 'rev-parse', 'HEAD'], cwd=repo, timeout=30)[1].decode().strip()
    status = recorder.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=repo, timeout=30)[1]
    return {'head': head, 'status': status.decode()}

code = 1
save()
with args.heavy_lock.open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        report['source_before'] = state()
        assert report['source_before'] == {'head': args.sha, 'status': ''}
        versions = []
        for argv in ([sys.executable, '--version'], ['gcc', '--version'], ['git', '--version']):
            row, stdout, stderr = recorder.run(argv, cwd=repo, timeout=30)
            versions.append({'original_command_result': row, 'stdout': stdout.decode(errors='replace'), 'stderr': stderr.decode(errors='replace')})
        report['versions'] = versions
        if args.mode == 'architecture':
            commands = [('architecture-cli', [sys.executable, '-B', 'tests/architecture_contract.py', '--root', '.', '--manifest', 'geometry-core/domain-decoupling/product-architecture.json']), ('architecture-tests', [sys.executable, '-B', 'tests/test_architecture_contract.py']), ('product-architecture-tests', [sys.executable, '-B', 'tests/test_product_architecture.py'])]
        elif args.mode == 'native':
            commands = [('native', ['bash', '-c', 'ulimit -s 16384; exec python3 tests/run_all.py --build'])]
        elif args.mode == 'ledger-check':
            commands = [('check', ['python3', 'tests/mutate.py', '--check'])]
        else:
            commands = [('precheck', ['python3', 'tests/mutate.py', '--check']), ('full-ledger', ['python3', 'tests/mutate.py']), ('checkafter', ['python3', 'tests/mutate.py', '--check'])]
        for label, argv in commands:
            row, _, _ = recorder.run(argv, cwd=repo, timeout=None, check=False, source_sha=args.sha, source_variant='clean-fixed-source')
            report['steps'].append({'label': label, 'original_command_result': row})
            save()
        exits = [step['original_command_result']['actual_process_returncode'] for step in report['steps']]
        # A stale precheck is an original recorded red; regeneration and final check must pass.
        code = exits[-1] if args.mode != 'ledger-regenerate' else next((x for x in exits[1:] if x != 0), 0)
        if args.mode == 'architecture':
            code = next((value for value in exits if value != 0), 0)
        if args.mode == 'native':
            original_logs = Path('/tmp/geometry-tests/run_all-logs')
            if original_logs.is_dir():
                shutil.copytree(original_logs, out / 'run_all-logs', symlinks=True)
    except BaseException:
        report['errors'].append(traceback.format_exc())
        code = 1
    finally:
        try:
            report['source_after'] = state()
            assert report['source_after'] == report['source_before']
        except BaseException:
            report['errors'].append(traceback.format_exc())
            code = 1
        report.update(exit_code=code, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=recorder.rows)
        if args.mode.startswith('ledger'):
            report['ledger_sha256'] = hashlib.sha256((out / 'ledger.json').read_bytes()).hexdigest()
        save()
print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code, 'mode': args.mode}))
raise SystemExit(code)
