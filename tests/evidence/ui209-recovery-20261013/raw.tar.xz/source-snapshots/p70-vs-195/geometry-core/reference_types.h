/* D6a/D6b/I13: persistent definitions; evaluated geometry is only a cache. */
#define REF_EXPR_MAX 512
#define SPEC_NAME_MAX 96
#define WORLD_MAX_SPECS 64
#define WORLD_MAX_DATUMS 64
/* D6c: only axis and spec expression are persistent; position is a cache. */
typedef struct { uint32_t id; int axis; char expression[REF_EXPR_MAX]; Coord position; } DatumPlane;
typedef enum { GUIDE_LOCAL = 0, GUIDE_DATUM = 1 } GuideSource;
typedef struct { char name[SPEC_NAME_MAX]; Coord value; } SpecValue;
typedef struct { int kind, hole, edge; TimberId timber; } ReferenceFace;
