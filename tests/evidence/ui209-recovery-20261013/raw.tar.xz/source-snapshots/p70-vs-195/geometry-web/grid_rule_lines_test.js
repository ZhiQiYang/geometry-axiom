/* #61 slice 2: normal source/rule/binding/apply UI. Native fixture calls only
 * author initial faces/supports or explicit stale/rejection adversaries. */
'use strict';
const cdp=require('./cdp_helpers.js');
module.exports=async function({send,eval_,sleep,click,waitForUI,expectNativeDialog,exceptionCount}){
  console.log('=== P88. 原生來源子線顯示、完整引用、兩面及正式重開 ===');
  const fs=require('fs'),os=require('os'),path=require('path'),P=require('./project-store.js'),zip=require('./vendor/fflate/umd/index.js');
  const read=cdp.makeRead(eval_),wait=cdp.makeWait(waitForUI,25000),settle=cdp.makeSettle({waitForUI,eval_},{tag:'P88',timeoutMs:25000}),check=cdp.makeCheck({prefix:'P88 ',throwOnFail:true}),exceptions=exceptionCount();
  const baseCtl=cdp.makeCtl({eval_,sleep,click},{scroll:'center',attempts:12,pollMs:70,settleMs:100,hitElement:true,missing:'Missing ',unreachable:(s,p)=>'Rule line control unreachable '+s+' '+JSON.stringify(p)});
  const ctl=async selector=>{if(await read('innerWidth<=900')){
    const root=await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)});return n?.closest('#objectList')?'left':n?.closest('#inspectorContent')?'right':n?.closest('.face-inspector-panel')?'face':n?.closest('.face-layer-panel')?'face-left':null;})()`);
    if(root==='left'&&!await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#toggleLeft');
    if(root==='right'){if(await read(`document.body.classList.contains('canvas-composition')`)){if(await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#toggleLeft');}else if(!await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#toggleRight');}
    if(root==='face'&&!await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#workspaceToggleRight');
    if(root==='face-left'&&!await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#workspaceToggleLeft');
    if(selector.startsWith('.face-rule-hit')&&await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#workspaceToggleRight');
  }if(await read(`document.querySelector(${JSON.stringify(selector)})?.closest('#createObjectPop')?.hidden===true`))await baseCtl(await read(`innerWidth<=900?'#mobileCreateObject':'#btnCreateObject'`));// #123 S3 exposes one component form at a time. Enter its existing tab
  // with the same trusted hit-tested controls before using a migrated field.
  const section=await read(`document.querySelector(${JSON.stringify(selector)})?.closest('[data-component-section]')?.dataset.componentSection||null`);
  if(section&&await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)}),p=n?.closest('[data-fi-pane]'),s=n?.closest('[data-component-section]');return !!p?.hidden||!!s?.classList.contains('component-collapsed');})()`)){
    await baseCtl('#faceInspectorTabs [data-fi-tab="components"]');
    await baseCtl('[data-component-tab="'+section+'"]');
  }
  return baseCtl(selector);};
  // A default-valued select must not pass after a click reached another
  // element. Check the actual keyboard target before sending input.
  const focusedCtl=async selector=>{await ctl(selector);await wait(`document.activeElement===document.querySelector(${JSON.stringify(selector)})`);};
  const key=cdp.makeKey({send,sleep}),fill=cdp.makeFill({ctl:focusedCtl,key,send,sleep},{afterMs:35});
  // Native button activation also needs Enter's character event in Chromium.
  const activateKey=cdp.makeKey({send,sleep},{enterText:true});
  const historyOracle=cdp.makeHistoryOracle(read,'P88');
  const shot=cdp.makeShot(send,['GEOMETRY_GRID_RULE_SCREENSHOT_DIR']);
  const query=cmd=>read(`apiRequest(${JSON.stringify(cmd)}).then(r=>{if(!r.ok)throw Error(JSON.stringify(r));return r;})`),dump=async()=>(await query('dump')).text,objects=()=>query('objects'),settled=()=>wait('!oc.busy&&!ReferenceWorkspace.busy');
  const impact=()=>wait(`!!document.querySelector('.reference-impact[open]')`),confirm=async()=>{await ctl('#impact-confirm');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();},cancel=async()=>{await ctl('.reference-impact .impact-actions button:first-child');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();};
  const choose=async(selector,value)=>{const n=await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)});return [...n.options].filter(o=>!o.disabled).findIndex(o=>o.value===${JSON.stringify(value)});})()`);if(n<0)throw Error('Missing enabled option '+selector+' '+value);await focusedCtl(selector);await key('Home','Home',36);for(let i=0;i<n;i++)await key('ArrowDown','ArrowDown',40);await key('Enter','Enter',13);await wait(`document.querySelector(${JSON.stringify(selector)}).value===${JSON.stringify(value)}`);};
  const fixture=async cmd=>read(`(async()=>{let r=await apiRequest('line '+${JSON.stringify(cmd)});if(r.preview){if(!r.preview.valid)throw Error(JSON.stringify(r));r=await apiRequest('line confirm '+r.preview.token);}if(!r.ok)throw Error(JSON.stringify(r));await renderObjects();return true;})()`);
  const leave=async()=>{if(await read(`$('infiniteGridWorkspace').open`))await ctl('#igClose');if(await read(`!!oc.focus`))await ctl('#workspaceBackButton');await settled();};
  const newSource=async()=>ctl(await read(`innerWidth<=900?'#btnQuickGrid':'#btnNewGridSystem'`));
  // ctl only has ~840ms of patience, but #igEditSource / #igNewBinding start open(): a serial run of native reads, then render()
  // swaps the whole workspace DOM (scroll container rebuilt, controls disabled until initialization ends). Under a slow native
  // service that outlasts ctl, so wait for the next control to really be there (rendered, visible, enabled) before using it.
  const usable=selector=>`(()=>{const n=document.querySelector(${JSON.stringify(selector)}),r=n?.getBoundingClientRect();return !!n&&!n.disabled&&r.width>0&&r.height>0;})()`;
  const seen=`({open:$('infiniteGridWorkspace')?.open,saveSourceVisible:!!$('igSaveSource')&&!$('igSaveSource').hidden,saveBindingVisible:!!$('igSaveBinding')&&!$('igSaveBinding').hidden,newBinding:$('igNewBinding')?{w:$('igNewBinding').getBoundingClientRect().width,disabled:$('igNewBinding').disabled}:null,boundary:$('igBoundary')?{w:$('igBoundary').getBoundingClientRect().width,disabled:$('igBoundary').disabled}:null,status:document.querySelector('#igDraftNote,#igStatus')?.textContent?.slice(0,120)??null})`;
  const bindingEntry=async fromBinding=>{
    if(fromBinding){await ctl('#igEditSource');await settle('回到來源模式：igSaveSource 顯示且「新增配置」鈕已渲染可用',`!!$('igSaveSource')&&!$('igSaveSource').hidden&&${usable('#igNewBinding')}`,{observe:seen});}
    else await settle('來源模式的「新增配置」鈕已渲染可用',usable('#igNewBinding'),{observe:seen});
    await ctl('#igNewBinding');
    await settle('配置模式已渲染：igSaveBinding 顯示，#igBoundary 可見且可用',`!!$('igSaveBinding')&&!$('igSaveBinding').hidden&&${usable('#igBoundary')}`,{observe:seen});
  };
  // `fresh()`/`leave()` close the workspace but leave its old DOM (with a stale #igName) behind, so `!!$('igName')` is already true
  // before the new source form exists; require the dialog to be open and #igName really rendered, visible and enabled.
  const newSourceReady=async()=>{await newSource();await settle('新來源工作區已開啟：對話框 open 且 #igName 可見可用',`$('infiniteGridWorkspace').open&&${usable('#igName')}`,{observe:seen});};
  const fresh=async()=>{await leave();const dirty=await read('ReferenceWorkspace.context().dirty');await ctl('#fileMenuBtn');await expectNativeDialog(()=>ctl('#btnNewProject'),{message:'建立一份空白新專案，切換為新的專案識別及「未命名專案」。'+(dirty?'目前尚未保存的變更不會自動寫入檔案。':'')+'本次切換可一步復原；僅保存在本頁的形狀特徵參數不會恢復。確定繼續嗎？',accept:true});await settled();};
  const openSource=async sid=>{await leave();await ctl(`#objectList .object-row[data-kind="grid-system"][data-id="${sid}"]`);await ctl('#gridObjectOpen');await wait(`$('infiniteGridWorkspace').open&&!$('igRuleAdd').disabled`);};
  const face=async bid=>{await leave();await ctl(`#objectList .object-row[data-kind="boundary"][data-id="${bid}"]`);await ctl('#inspEnter');await wait(`oc.edit?.bid===${bid}`);await wait(`GridRuleLines.entries().some(l=>l.segments.length)`);};
  const focusCell=async(cell,rule=1)=>{await ctl('#faceInspectorTabs [data-fi-tab="components"]');await wait(`!!document.querySelector('[data-rule-exact]')`);await choose('[data-rule-focus-key]',String(rule));await fill('[data-rule-cell-i]',cell[0]);await fill('[data-rule-cell-j]',cell[1]);await ctl('[data-rule-exact]');await wait(`GridRuleLines.entries().every(l=>l.cell.join(',')===${JSON.stringify(cell.join(','))}&&l.ruleKey===${rule})&&document.querySelector('[data-rule-focus-status]').textContent.includes('已核對')`);};
  const pickRule=async ref=>{if(await read(`innerWidth<=900&&document.body.classList.contains('drawer-right-open')`))await ctl('#workspaceToggleRight');if(await read(`innerWidth<=900&&document.body.classList.contains('drawer-left-open')`))await ctl('#workspaceToggleLeft');const point=await read(`(()=>{const key=${JSON.stringify(ref)},line=GridRuleLines.entries().find(l=>GridRuleLines.key(l.ref)===key),box=$('faceEditorViewport').getBoundingClientRect();for(const segment of line?.segments||[])for(const f of [.5,.3,.7,.15,.85]){const x=box.left+fe.panX+(segment[0][0]+(segment[1][0]-segment[0][0])*f)*fe.zoom,y=box.top+fe.panY+(segment[0][1]+(segment[1][1]-segment[0][1])*f)*fe.zoom,hit=document.elementFromPoint(x,y);if(hit?.classList.contains('face-rule-hit')&&hit.dataset.ruleLineKey===key)return {x,y};}return null;})()`);if(!point)throw Error('No visible native rule hit '+ref);await click(point.x,point.y);await sleep(100);};
  const save=async()=>{const directory=fs.mkdtempSync(path.join(os.tmpdir(),'geometry-rule-lines-'));await send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:directory});await read(`window.__linePicker=Object.getOwnPropertyDescriptor(window,'showSaveFilePicker');Object.defineProperty(window,'showSaveFilePicker',{value:undefined,configurable:true});void 0`);let file;try{await ctl('#projectBar [data-project-action="save"]');for(let i=0;i<150;i++){const files=fs.readdirSync(directory).filter(f=>f.endsWith('.gcanvas'));if(files.length===1){file=path.join(directory,files[0]);break;}await sleep(100);}}finally{await read(`if(window.__linePicker)Object.defineProperty(window,'showSaveFilePicker',window.__linePicker);else delete window.showSaveFilePicker;delete window.__linePicker;void 0`);}if(!file)throw Error('Missing formal ZIP');return {file,directory};};
  const reopen=async file=>{await fresh();check('重開前確有新空白 context',await read('oc.gridSystems.length===0&&oc.gridBindings.length===0&&oc.faces.length===0'));await send('Page.setInterceptFileChooserDialog',{enabled:true});try{await ctl('#fileMenuBtn');await ctl('#btnOpenProject');const d=await send('DOM.getDocument',{depth:0}),n=await send('DOM.querySelector',{nodeId:d.result.root.nodeId,selector:'#projectFile'});await send('DOM.setFileInputFiles',{nodeId:n.result.nodeId,files:[file]});await settled();await wait('oc.gridBindings.length===2');}finally{await send('Page.setInterceptFileChooserDialog',{enabled:false});}};
  for(const width of [1280,390]){
    await send('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:false});await fresh();
    const cells=[['-2','1'],['9007199254740993','-9007199254740995']];
    for(const bid of [1,2]){await fixture(`boundary ${bid} outline ${bid===1?'0,0 1200,0 1200,800 0,800':'0,0 1200,0 1200,800 800,800 800,600 0,600 hole 170,80 170,280 230,280 230,80'}`);await fixture(`placement ${bid} on boundary ${bid} origin 0 0 ${(bid-1)*2000} u +x v +y`);}
    await newSourceReady();await fill('#igName',`Authored shared rule ${width}`);await ctl('#igSaveSource');await impact();await confirm();const sid=(await objects()).gridSystems[0].id;
    await ctl('#igRuleAdd');await fill('#igRuleName','Native inner lines');await ctl('#igRulePreview');await impact();await confirm();
    await wait(`!!document.querySelector('[data-ig-source-rule="1"]')`);check(`${width} 来源原生子線顯示而 ref:null 未轉成 applied 引用`,await read(`document.querySelectorAll('[data-ig-source-rule]').length>0&&[...document.querySelectorAll('[data-ig-source-rule]')].every(n=>n.dataset.igRuleRef==='none')`));
    for(let index=0;index<2;index++){
      await bindingEntry(index>0);await choose('#igBoundary',String(index+1));await wait(`$('igVertex').options.length>1&&!$('igCellI').disabled`);await choose('#igVertex','outer:0');await fill('#igCellI',cells[index][0]);await fill('#igCellJ',cells[index][1]);await ctl('#igSaveBinding');await impact();await confirm();
      await wait(`!!document.querySelector('[data-ig-result-rule="1"]')`);check(`${width} 配置 ${index} 真 signed cell 保存及只讀裁切顯示`,(await objects()).gridBindings[index].cell.join(',')===cells[index].join(',')&&await read(`[...document.querySelectorAll('[data-ig-result-rule]')].every(n=>n.dataset.igRuleRef==='none')`));
      await choose('#igSurface',String(index+1));await ctl('#igApplyBinding');await impact();await confirm();
    }
    const refs=await query('references'),grids=refs.grids.map(g=>g.id);check(`${width} 兩面正常 UI 共用同來源、兩配置及兩 applied grids`,grids.length===2&&refs.grids.every(g=>g.sourceSystem===sid&&g.bindingId!=null));
    for(let index=0;index<2;index++){
      await face(index+1);await focusCell(cells[index]);const lines=await read(`GridRuleLines.entries().map(l=>({ref:l.ref,segments:l.segments,bounds:l.bounds}))`),native=await query(`grid-rule-query grid ${grids[index]} rule 1 cell ${cells[index].join(' ')}`);
      check(`${width} 面 ${index} exact cell 線段與 native 相同，完整 tuple 含真正大索引`,lines.length===3&&lines.every(l=>l.ref.appliedGridId===grids[index]&&l.ref.systemId===sid&&l.ref.cellI===cells[index][0]&&l.ref.cellJ===cells[index][1])&&JSON.stringify(lines.map(l=>l.segments))===JSON.stringify(native.lines.map(l=>l.segments)));
      if(index===0){
        const keyboardWorld=await dump(),keyboardHistory=await historyOracle.capture(),keyboardRaw=await read(`ReferenceWorkspace.readFeatureAttachment('grid-draft')`);
        // Input clears the previous receipt; Tab and Enter activate the real
        // next button. Wait for a new native result, not the previous value.
        await fill('[data-rule-cell-j]',cells[index][1]);
        await wait(`document.querySelector('[data-rule-focus-status]').textContent===''`);
        await key('Tab','Tab',9);
        await wait(`document.activeElement===document.querySelector('[data-rule-exact]')`);
        await activateKey('Enter','Enter',13);await wait(`document.querySelector('[data-rule-focus-status]').textContent.includes('已核對')`);
        check(`${width} 真 Tab/Enter 完整定位保留按鈕焦點且 World/raw/history 零寫入`,await read(`document.activeElement===$('gridRuleExact')&&!$('gridRuleExact').disabled`)&&(await dump())===keyboardWorld&&await historyOracle.unchanged(keyboardHistory)&&JSON.stringify(await read(`ReferenceWorkspace.readFeatureAttachment('grid-draft')`))===JSON.stringify(keyboardRaw));
        await historyOracle.release(keyboardHistory);
      }
      for(const axis of ['u','v']){
        await choose('#tbAnchor',`at-line rule ${grids[index]} ${sid} 1 ${cells[index].join(' ')} ${axis} 0`);await fill('#tbA','20');await fill('#tbB','20');await ctl('#tbAnchor');
        const preview=await read(`(()=>{const nodes=[...document.querySelectorAll('.fe-anchor-hi,.fe-anchor-band,.fe-anchor-band-label')],info=feAnchorLineInfo(${index+1},$('tbAnchor').value),rect=document.querySelector('.fe-anchor-band');return {info,finite:nodes.length===3&&nodes.every(n=>[...n.attributes].filter(a=>['x','y','x1','y1','x2','y2','width','height'].includes(a.name)).every(a=>Number.isFinite(Number(a.value)))),rect:rect&&['x','y','width','height'].map(a=>Number(rect.getAttribute(a))),materialClip:nodes.every(n=>n.closest('[clip-path="url(#face-material-clip)"]'))};})()`);
        check(`${width} 面 ${index} ${axis} 真 anchor 預示四數 bounds、全部座標 finite、parent/孔裁切`,preview.finite&&Array.isArray(preview.info.bounds)&&preview.info.bounds.length===4&&preview.materialClip&&preview.rect[0]>=preview.info.bounds[0]&&preview.rect[1]>=preview.info.bounds[1]&&preview.rect[0]+preview.rect[2]<=preview.info.bounds[2]&&preview.rect[1]+preview.rect[3]<=preview.info.bounds[3]);
      }
      await ctl('[data-face-tool="select"]');
      const before=await dump(),count=await read('ReferenceWorkspace.history.undo.length'),raw=await read(`ReferenceWorkspace.readFeatureAttachment('grid-draft')`);
      if(width===390){await ctl('#faceInspectorTabs [data-fi-tab="components"]');await ctl('[data-component-tab="grid"]');const sizes=await read(`({controls:[...document.querySelectorAll('.grid-rule-details button,.grid-rule-details input,.grid-rule-details select')].map(n=>({id:n.id,height:n.getBoundingClientRect().height})),panel:[$('faceInspectorContent').scrollWidth,$('faceInspectorContent').clientWidth],page:[document.documentElement.scrollWidth,innerWidth]})`);check(`390 面 ${index} source/cell 觸控高度及 inspector 無水平溢出`,sizes.controls.every(n=>n.height>=44)&&sizes.panel[0]<=sizes.panel[1]&&sizes.page[0]<=sizes.page[1],sizes);}
      await ctl('#faceReferenceVisibility [data-ref-visible="all"]');check(`${width} 面 ${index} 共用參考線隱藏同時停用 rule hit/anchor 且零寫入`,await read(`document.querySelectorAll('.face-rule-hit').length===0&&!ReferenceVisibility.anchorVisible($('tbAnchor').value)`)&&(await dump())===before);await ctl('#faceReferenceVisibility [data-ref-visible="all"]');
      await pickRule(`${grids[index]}:${sid}:1:${cells[index].join(':')}:u:0`);
      check(`${width} 面 ${index} 首指標選取及標籤不改 native/raw/history`,await read(`fe.ruleSelection?.appliedGridId===${grids[index]}&&!!document.querySelector('[data-rule-label]')&&document.querySelector('[data-rule-selected]').textContent.includes(${JSON.stringify(cells[index][0])})`)&&(await dump())===before&&await read('ReferenceWorkspace.history.undo.length')===count&&JSON.stringify(await read(`ReferenceWorkspace.readFeatureAttachment('grid-draft')`))===JSON.stringify(raw));
      await shot(`rule-lines-${width}-face-${index+1}`);
      const loops=await read(`oc.bmap[${index+1}]`);
      await ctl('[data-rule-source="1"]');await wait(`$('infiniteGridWorkspace').open&&!!document.querySelector('[data-ig-rule-key="1"].is-focus')`);
      check(`${width} 面 ${index} 來源 jump 同 editor+systemId/ruleKey，零寫入`,await read(`$('igTitle').textContent===${JSON.stringify('Authored shared rule '+width)}`)&&(await dump())===before&&await read(`ReferenceWorkspace.readFeatureAttachment('grid-draft')`)===null);
      check(`${width} 面 ${index} source jump 保留凹形/孔原始快取及 boundary 卡`,JSON.stringify(await read(`oc.bmap[${index+1}]`))===JSON.stringify(loops)&&await read(`document.querySelectorAll('.ocard[data-kind="boundary"][data-id="${index+1}"] polygon').length===${loops.length}`));
    }
    // Source edit previews both actual bindings. Cancel is zero-write;
    // confirmation is one history step and undo/redo preserve rule identity.
    await fill('#igUStep','1200');const before=await dump(),count=await read('ReferenceWorkspace.history.undo.length'),historyPin=await historyOracle.capture();await ctl('#igSaveSource');await impact();
    check(`${width} 真來源預覽含兩個 typed 配置及兩面`,await read(`document.querySelectorAll('[data-impact-binding]').length===2`)&&(await dump())===before);await cancel();check(`${width} 取消逐字 World/history 不變`,(await dump())===before&&await historyOracle.unchanged(historyPin));
    await ctl('#igSaveSource');await impact();await confirm();const changed=await dump(),singleStep=await historyOracle.single(historyPin);await historyOracle.release(historyPin);check(`${width} 原子確認單步更新全部配置，key 不重配`,changed!==before&&singleStep&&(await objects()).gridSystems[0].rules[0].ruleKey===1,{beforeCount:count,limit:historyPin.limit,singleStep});
    await leave();await ctl('#btnUndo');await settled();check(`${width} 來源變更單步 undo`,(await dump())===before);await ctl('#btnRedo');await settled();check(`${width} 來源變更單步 redo`,(await dump())===changed);
    await openSource(sid);await fill('#igUStep','600');await ctl('#igSaveSource');await impact();await confirm();await leave();
    await openSource(sid);await fill('#igUStep','6');await fill('#igVStep','4');await ctl('#igSaveSource');await impact();await confirm();await face(1);const denseWorld=await dump();
    check(`${width} 高密度原生 sample 有界且明示 incomplete，查询零寫入`,await read(`GridRuleLines.entries().length<=96&&$('feRuleDensity')?.textContent.includes('抽樣未完整')`)&&(await dump())===denseWorld);await focusCell(cells[0]);check(`${width} 高密度仍可用真正 cell 完整定位`,await read(`GridRuleLines.entries().length===3&&GridRuleLines.entries().every(l=>l.ref.cellI==='-2'&&l.ref.cellJ==='1')`));
    await openSource(sid);await fill('#igUStep','600');await fill('#igVStep','400');await ctl('#igSaveSource');await impact();await confirm();await leave();
    // Actual R6 supports are authored fixtures; guide and RuleLineRef timber
    // are created through existing normal controls below.
    for(const [id,edge] of [[81,'e0'],[82,'e2']]){await fixture(`timber ${id} 20 20 role boundary`);await fixture(`place ${id} on 1 at-face ${edge} +u +n`);}
    for(const [id,position] of [[91,120],[92,480]]){await fixture(`spec support_${id} ${position}`);await fixture(`guide ${id} 1 v spec:support_${id}`);await fixture(`timber ${id} 20 20 role primary`);await fixture(`place ${id} on 1 at-line guide ${id} +v +n`);}
    await face(1);await focusCell(cells[0]);await ctl('#faceInspectorTabs [data-fi-tab="components"]');await choose('#refGuideAxis','u');await choose('#refGuideMode','source');const expr=`gridrule:${grids[0]}:${sid}:1:-2:1:v:0`;await choose('#refGuideSource',expr);await ctl('#refGuideCreate');await settled();await wait(`fe.guides.some(g=>g.expression===${JSON.stringify(expr)})`);
    check(`${width} 既有 guide 選項送真正 gridrule 引用，不翻 U/V`,(await query('references')).guides.some(g=>g.expression===expr&&g.axis==='u'&&g.off===200));
    const wrongSourceWorld=await dump(),wrongSourceHistory=await read('ReferenceWorkspace.history.undo.length');await choose('#refGuideMode','advanced');await fill('#refGuideExpr',`gridrule:${grids[0]}:${sid+99}:1:-2:1:v:0`);await ctl('#refGuideCreate');await impact();check(`${width} 真 guide 進階入口錯 source 保留 native 拒絕、零 World/history`,await read(`$('impact-confirm').disabled&&document.querySelector('.reference-impact').textContent.includes('WRONG_SOURCE')`)&&(await dump())===wrongSourceWorld);await cancel();check(`${width} 錯 source 取消後 history 不變`,await read('ReferenceWorkspace.history.undo.length')===wrongSourceHistory);await choose('#refGuideMode','source');
    await focusCell(cells[0]);const anchor=`at-line rule ${grids[0]} ${sid} 1 -2 1 v 0`;await choose('#tbAnchor',anchor);await fill('#tbA','20');await fill('#tbB','20');await choose('#tbDir','+u');await choose('#tbRole','secondary');await ctl('#tbNewSegmentDetails > summary');await fill('#tbSelector','between t91 t9999');
    const retryWorld=await dump(),retryPin=await historyOracle.capture();
    await ctl('#tbPlace');await settled();await wait(`$('toastRegion').textContent.includes('cannot be reconstructed')&&!!GridRuleLines.find(GridRuleLines.parseAnchor(${JSON.stringify(anchor)}))`);
    check(`${width} 真 at-line native 拒絕保留同表單完整定位及角色截面，World/undo/redo 零寫入`,(await dump())===retryWorld&&await historyOracle.unchanged(retryPin)&&await read(`$('tbAnchor').value===${JSON.stringify(anchor)}&&$('tbA').value==='20'&&$('tbB').value==='20'&&$('tbRole').value==='secondary'&&$('tbSelector').value==='between t91 t9999'&&$('faceInspectorContent').dataset.tbRoleManual==='true'&&$('faceInspectorContent').dataset.tbSectionManual==='true'`));
    await fill('#tbSelector','between t91 t92');await ctl('#tbPlace');await settled();await wait(`fe.timbers.some(t=>t.definition?.anchor===${JSON.stringify(anchor)})`);
    check(`${width} 只修 selector 原地重試成功且 native 單步 history`,await historyOracle.single(retryPin));await historyOracle.release(retryPin);
    const timber=(await query('references')).timbers.find(t=>t.definition.anchor===anchor);check(`${width} 真 direct at-line 原生支撐、父 cell 足跡及明選角色截面`,timber.role==='secondary'&&timber.geometry.A===20&&timber.geometry.B===20&&timber.geometry.dir==='+u'&&timber.definition.selector==='between t91 t92');
    await focusCell(cells[0]);check(`${width} 單規則引用數只計該 rule guide/timber`,await read(`document.querySelector('[data-rule-summary="1"]').textContent.includes('1 參考線／1 角材')`));
    const locked=await dump();await ctl('[data-rule-source="1"]');await wait(`$('infiniteGridWorkspace').open`);await ctl('[data-ig-rule-key="1"] [data-ig-rule-action="delete"]');await ctl('#igRulePreview');await impact();check(`${width} 引用鎖 native 預覽不可確認`,await read(`$('impact-confirm').disabled`));await cancel();check(`${width} 引用鎖拒絕零 World 寫入`,(await dump())===locked);await ctl('#igRuleCancel');await leave();
    const saved=await save(),package_=await P.unpack(new Uint8Array(fs.readFileSync(saved.file)),zip);check(`${width} 真 Save ZIP 含兩配置及 guide/direct typed 引用`,package_.scene===locked&&package_.scene.includes(expr)&&package_.scene.includes(anchor));await reopen(saved.file);check(`${width} 新空白 context 真重開逐字場景、來源 key 及 signed binding`,(await dump())===locked&&(await objects()).gridBindings[1].cell.join(',')===cells[1].join(','));await face(2);await focusCell(cells[1]);await shot(`rule-lines-${width}-reopened`);
    fs.writeFileSync(path.join(saved.directory,'rule-lines-receipt.json'),JSON.stringify({width,scene:locked,manifest:package_.manifest,sourceId:sid,grids,cells},null,2));console.log(`P88 saved artifact ${saved.file}`);
    // Hold real native results while the user edits the same live owner.
    // Sampling may redraw presentation; exact responses also own their raw tuple.
    await leave();await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);if(cmd.startsWith('grid-rule-query grid ')&&cmd.includes('mode sample')&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
    try{await ctl('#objectList .object-row[data-kind="boundary"][data-id="2"]');await ctl('#inspEnter');await wait(`!!window.__ruleRelease`);await ctl('#faceInspectorTabs [data-fi-tab="components"]');await fill('#gridRuleCellI','9007199254740994');await fill('#gridRuleCellJ','-9007199254740996');await read(`__ruleRelease();void 0`);await wait(`GridRuleLines.entries().length>0`);check(`${width} late sample 保住真正大索引 raw 及鍵盤 focus`,await read(`$('gridRuleCellI').value==='9007199254740994'&&$('gridRuleCellJ').value==='-9007199254740996'&&document.activeElement.id==='gridRuleCellJ'`));}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;void 0`);}
    await focusCell(cells[1]);await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);if(cmd.startsWith('grid-rule-query grid ')&&cmd.includes(' cell ')&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
    try{await ctl('[data-rule-exact]');await wait(`!!window.__ruleRelease`);await fill('#gridRuleCellI','9007199254740994');await fill('#gridRuleCellJ','-9007199254740996');await read(`__ruleRelease();void 0`);await wait(`!document.querySelector('[data-rule-exact]').disabled`);check(`${width} late exact 不覆寫新 raw/focus 或把舊 tuple 宣稱完成`,await read(`$('gridRuleCellI').value==='9007199254740994'&&$('gridRuleCellJ').value==='-9007199254740996'&&document.activeElement.id==='gridRuleCellJ'&&$('faceInspectorContent').querySelector('[data-rule-focus-status]').textContent===''`));}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;void 0`);}
    // Native read completion may update the canvas, but it cannot replace the
    // nested named-spec editor or its currently focused raw input.
    await leave();await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);if(cmd.startsWith('grid-rule-query grid ')&&cmd.includes('mode sample')&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
    try{await ctl('#objectList .object-row[data-kind="boundary"][data-id="1"]');await ctl('#inspEnter');await wait(`!!window.__ruleRelease`);await ctl('#faceInspectorTabs [data-fi-tab="components"]');await ctl('#refParameterOpen');await wait(`!!$('paramSpecValue')`);await fill('#paramSpecValue','901');const scene=await dump(),history=await read('ReferenceWorkspace.history.undo.length');await read(`__ruleRelease();void 0`);await wait(`GridRuleLines.entries().length>0`);check(`${width} late rule query 保住具名規格 editor/raw/focus、World/history`,await read(`!!$('paramSpecValue')&&$('paramSpecValue').value==='901'&&document.activeElement.id==='paramSpecValue'`)&&(await dump())===scene&&await read('ReferenceWorkspace.history.undo.length')===history);await ctl('#paramLegacyBack');}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;void 0`);}
    await face(1);await focusCell(['98','101']);check(`${width} 零可見 exact cell 有即時完成狀態`,await read(`GridRuleLines.entries().every(l=>l.segments.length===0)&&document.querySelector('[data-rule-focus-status]').textContent.includes('零可見線段')`));
    // The reserved ID belongs to the initiating context, even if a different
    // context reopens identical IDs, native supports and the same saved ZIP.
    await focusCell(cells[0]);await choose('#tbAnchor',anchor);await fill('#tbA','20');await fill('#tbB','20');await choose('#tbDir','+u');await choose('#tbRole','secondary');if(!await read(`$('tbNewSegmentDetails').open`))await ctl('#tbNewSegmentDetails > summary');await fill('#tbSelector','between t91 t92');
    for(const race of ['raw','native','history']){
      await face(1);await focusCell(cells[0]);await choose('#tbAnchor',anchor);await fill('#tbA','20');await fill('#tbB','20');await choose('#tbDir','+u');await choose('#tbRole','secondary');if(!await read(`$('tbNewSegmentDetails').open`))await ctl('#tbNewSegmentDetails > summary');await fill('#tbSelector','between t91 t92');
      await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;window.__ruleWrites=[];apiRequest=async function(cmd,...rest){if(cmd.startsWith('line '))__ruleWrites.push(cmd);const r=await __ruleApi(cmd,...rest);if(cmd==='newid'&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
      try{await ctl('#tbPlace');await wait(`!!window.__ruleRelease`);if(race==='raw')await fill('#tbSelector','between t92 t91');else if(race==='native')await query(`line spec p88_lease_${width} 1`);else{const n=await read('ReferenceWorkspace.history.undo.length');await send('Input.dispatchKeyEvent',{type:'keyDown',key:'z',code:'KeyZ',windowsVirtualKeyCode:90,modifiers:2});await send('Input.dispatchKeyEvent',{type:'keyUp',key:'z',code:'KeyZ',windowsVirtualKeyCode:90,modifiers:2});await settled();await wait(`ReferenceWorkspace.history.undo.length<${n}`);}const scene=await dump(),history=await read('ReferenceWorkspace.history.undo.length');await read(`__ruleWrites=[];__ruleRelease();void 0`);await sleep(250);check(`${width} newid ${race} 漂移後零 history-begin/timber/place/World/history`,await read(`__ruleWrites.length===0`)&&(await dump())===scene&&await read('ReferenceWorkspace.history.undo.length')===history);}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;delete window.__ruleWrites;void 0`);}
    }
    await face(1);await focusCell(cells[0]);await choose('#tbAnchor',anchor);await fill('#tbA','20');await fill('#tbB','20');await choose('#tbDir','+u');await choose('#tbRole','secondary');if(!await read(`$('tbNewSegmentDetails').open`))await ctl('#tbNewSegmentDetails > summary');await fill('#tbSelector','between t91 t92');
    const oldToken=await read('ReferenceWorkspace.getProjectState().contextToken');await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;window.__ruleWrites=[];apiRequest=async function(cmd,...rest){if(cmd.startsWith('line '))__ruleWrites.push(cmd);const r=await __ruleApi(cmd,...rest);if(cmd==='newid'&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
    try{await ctl('#tbPlace');await wait(`!!window.__ruleRelease`);await reopen(saved.file);await face(1);await focusCell(cells[0]);await choose('#tbAnchor',anchor);await fill('#tbA','20');await fill('#tbB','20');await choose('#tbDir','+u');await choose('#tbRole','secondary');if(!await read(`$('tbNewSegmentDetails').open`))await ctl('#tbNewSegmentDetails > summary');await fill('#tbSelector','between t91 t92');const scene=await dump(),history=await read('ReferenceWorkspace.history.undo.length');await read(`__ruleWrites=[];__ruleRelease();void 0`);await wait(`!![...document.querySelectorAll('#toastRegion span')].find(n=>n.textContent.includes('放置來源或輸入已變更'))`);check(`${width} newid 晚返同 ID/同輸入新 context 零 history-begin/timber/place/World/history`,await read(`ReferenceWorkspace.getProjectState().contextToken!==${JSON.stringify(oldToken)}&&__ruleWrites.length===0`)&&(await dump())===scene&&await read('ReferenceWorkspace.history.undo.length')===history);}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;delete window.__ruleWrites;void 0`);}
    await face(2);await focusCell(cells[1]);
    // Delayed native query / source navigation must not move the new owner.
    await read(`window.__ruleApi=apiRequest;window.__ruleHold=null;window.__ruleRelease=null;apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);if(cmd.startsWith('grid-rule-query ')&&!window.__ruleHold){window.__ruleHold=cmd;await new Promise(resolve=>window.__ruleRelease=resolve);}return r;};void 0`);
    try{await ctl('[data-rule-exact]');await wait(`!!window.__ruleRelease`);await ctl('#workspaceBackButton');const scene=await dump();await read(`__ruleRelease();void 0`);await sleep(300);check(`${width} 延遲 exact query 返回時不改新 view/native`,await read(`!oc.edit&&$('objectWorkspace').hidden&&GridRuleLines.entries().length===0`)&&(await dump())===scene);}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleHold;delete window.__ruleRelease;void 0`);}
    await face(1);await focusCell(cells[0]);await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);if(cmd==='objects'&&!window.__ruleRelease)await new Promise(resolve=>window.__ruleRelease=resolve);return r;};void 0`);
    try{await ctl('[data-rule-source="1"]');await wait(`!!window.__ruleRelease`);check(`${width} detached source jump 讀取尚未提前離開 face`,await read(`oc.edit?.bid===1&&!$('infiniteGridWorkspace').open`));await ctl('#workspaceBackButton');await read(`__ruleRelease();void 0`);await sleep(300);check(`${width} 延遲 source jump 對換 view 零定位`,await read(`!oc.edit&&!$('infiniteGridWorkspace').open`));}finally{await read(`apiRequest=__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;void 0`);}
    // A late rule reply rebuilds the inspector. Keyboard targets the user has
    // already moved must survive that rebuild. Click, Tab and Enter only.
    const guideTarget=()=>read(`(()=>{const e=document.activeElement;return e?[e.tagName,e.id||'',e.getAttribute('aria-label')||'',e.dataset.kind||'',e.dataset.id||''].join('|'):'';})()`);
    const armGuide=async()=>{
      await face(1);await focusCell(cells[0]);await ctl('#faceInspectorTabs [data-fi-tab="components"]');
      await choose('#refGuideMode','advanced');await focusedCtl('#refGuideExpr');
      await key('Enter','Enter',13);await wait(`document.activeElement===document.querySelector('#refGuideExpr')`);
      await key('Tab','Tab',9);await wait(`document.activeElement===document.querySelector('#refGuideCreate')`);
    };
    const lateGuide=async(label,move,accept,settle,mode)=>{
      await armGuide();
      await read(`window.__ruleApi=apiRequest;window.__ruleRelease=null;window.__ruleOrigRender=renderFaceInspector;window.__ruleGate={phase:'arming',rebuilt:null,clickSettled:false,seqAtRelease:null};
        renderFaceInspector=function(){const out=window.__ruleOrigRender.apply(this,arguments);const g=window.__ruleGate;if(g&&g.phase==='released'&&g.seqAtRelease!=null&&fe.gridPreviewSeq!==g.seqAtRelease)g.rebuilt=fe.gridPreviewSeq;return out;};
        const exact=document.querySelector('[data-rule-exact]');const origClick=exact&&exact.onclick;window.__ruleExact=exact;window.__ruleOrigClick=origClick;
        if(exact)exact.onclick=async function(...args){try{return await origClick.apply(this,args);}finally{if(window.__ruleGate)window.__ruleGate.clickSettled=true;}};
        apiRequest=async function(cmd,...rest){const r=await __ruleApi(cmd,...rest);const g=window.__ruleGate;if(g&&g.phase==='arming'&&cmd.startsWith('grid-rule-query ')){g.phase='held';await new Promise(resolve=>window.__ruleRelease=resolve);g.phase='released';g.seqAtRelease=fe.gridPreviewSeq;}return r;};void 0`);
      const done=mode==='rebuild'
        ?`window.__ruleGate.phase==='released'&&window.__ruleGate.clickSettled===true&&window.__ruleGate.rebuilt>window.__ruleGate.seqAtRelease`
        :mode==='dropped'
        ?`window.__ruleGate.phase==='released'&&window.__ruleGate.clickSettled===true&&window.__ruleGate.rebuilt==null&&fe.gridPreviewSeq===window.__ruleGate.seqAtRelease`
        :`window.__ruleGate.phase==='released'&&window.__ruleGate.clickSettled===true`;
      try{
        await ctl('[data-rule-exact]');await wait(`window.__ruleGate.phase==='held'&&!!window.__ruleRelease&&window.__ruleGate.clickSettled===false`);
        // The query starts in Grid; the later real Guide focus owns the reply
        // while the original move and no-focus-steal oracles remain unchanged.
        await ctl('[data-component-tab="guide"]');await focusedCtl('#refGuideExpr');
        await key('Enter','Enter',13);await wait(`document.activeElement===document.querySelector('#refGuideExpr')`);
        await key('Tab','Tab',9);await wait(`document.activeElement===document.querySelector('#refGuideCreate')`);
        await move();
        const before=await guideTarget();
        check(`${width} ${label} 已離開引用式`,await accept(before));
        check(`${width} ${label} 回覆未完成前不得判斷焦點`,await read(done)===false);
        check(`${width} ${label} 搶回引用式會被判失敗`,await read(`(()=>{const stole=id=>id==='refGuideExpr';return stole('refGuideExpr')===true&&stole(document.activeElement?.id||'')===false;})()`)===true);
        await read(`if(window.__ruleRelease)window.__ruleRelease();window.__ruleRelease=null;void 0`);
        await wait(done);
        const observed=await read(`window.__ruleGate.rebuilt==null?'沒有再重建檢查器':'釋放後重建 '+window.__ruleGate.rebuilt`);
        check(`${width} ${label} 處理結束時${observed}`,await read(`window.__ruleGate.clickSettled===true&&(window.__ruleGate.rebuilt==null||window.__ruleGate.rebuilt>window.__ruleGate.seqAtRelease)`));
        const after=await guideTarget();
        check(`${width} ${label} 舊查詢不搶回焦點`,await read(`document.activeElement?.id!=='refGuideExpr'`)&&await settle(before,after));
      }finally{await read(`if(window.__ruleRelease)window.__ruleRelease();window.__ruleRelease=null;if(window.__ruleOrigRender)renderFaceInspector=window.__ruleOrigRender;if(window.__ruleExact&&window.__ruleOrigClick)window.__ruleExact.onclick=window.__ruleOrigClick;if(window.__ruleApi)apiRequest=window.__ruleApi;delete window.__ruleApi;delete window.__ruleRelease;delete window.__ruleOrigRender;delete window.__ruleOrigClick;delete window.__ruleExact;delete window.__ruleGate;void 0`);}
    };
    const sameTarget=(before,after)=>before===after&&before!=='';
    await lateGuide('檢查器外',async()=>{await ctl('#fileMenuBtn');await wait(`document.activeElement===$('fileMenuBtn')`);},async()=>read(`document.activeElement===$('fileMenuBtn')`),sameTarget,'rebuild');
    if(!await read(`$('fileMenuPop').hidden`))await ctl('#fileMenuBtn');
    await lateGuide(await read(`innerWidth<=680&&document.body.classList.contains('drawer-right-open')`)?'關閉抽屜':'其他對話框',async()=>{
      if(await read(`innerWidth<=680&&document.body.classList.contains('drawer-right-open')&&$('workspaceToggleRight').getClientRects().length>0`)){await ctl('#workspaceToggleRight');await wait(`document.activeElement===$('workspaceToggleRight')`);}
      else{await ctl('#refParameterOpen');await wait(`!!$('paramSpecValue')`);await focusedCtl('#paramSpecValue');}
    // Opening the parameter editor removes the rule details, and closing the
    // 390 drawer can change the viewport key. Either way paintQuery may not
    // call renderFaceInspector again. Wait until the click handler finishes;
    // a rebuild after release is still recorded and must not steal focus.
    },async before=>before.includes('workspaceToggleRight')||before.includes('paramSpecValue'),sameTarget,'settled');
    if(await read(`!!$('paramLegacyBack')`))await ctl('#paramLegacyBack');
    await lateGuide('切換選取並離開面',async()=>{
      await ctl('#workspaceBackButton');await wait(`!oc.edit`);
      await ctl('#objectList .object-row[data-kind="boundary"][data-id="2"]');
      await wait(`oc.selection.some(s=>s.kind==='boundary'&&s.id===2)`);
      await key('Enter','Enter',13);
    },async()=>read(`!oc.edit&&oc.selection.some(s=>s.kind==='boundary'&&s.id===2)&&document.activeElement?.id!=='refGuideExpr'`),async()=>read(`!oc.edit&&oc.selection.some(s=>s.kind==='boundary'&&s.id===2)`),'dropped');
    // The leave case opens the 390 object drawer to click a row. Leave it closed
    // before the next scenario opens the file menu; the drawer otherwise covers
    // #btnNewProject. Same toggle click the suite already uses.
    if(await read(`document.body.classList.contains('drawer-left-open')`))await ctl('#toggleLeft');
    // Cell selectors are a separate native scenario: all-cells and cell rules
    // cannot overlap within a source (I25a), so do not invent a UI exception.
    await fresh();await fixture('boundary 1 outline 0,0 1200,0 1200,800 800,800 800,600 0,600 hole 170,80 170,280 230,280 230,80');await fixture('placement 1 on boundary 1 origin 0 0 0 u +x v +y');
    await newSourceReady();await fill('#igName',`Signed cell source ${width}`);await ctl('#igSaveSource');await impact();await confirm();const cellSid=(await objects()).gridSystems[0].id;
    await ctl('#igRuleAdd');await fill('#igRuleName','Signed cell only');await choose('#igRuleSelector','cell');await fill('#igRuleCellI',cells[1][0]);await fill('#igRuleCellJ',cells[1][1]);await ctl('#igRulePreview');await impact();await confirm();
    await bindingEntry(false);await choose('#igBoundary','1');await wait(`$('igVertex').options.length>1&&!$('igCellI').disabled`);await choose('#igVertex','outer:0');await fill('#igCellI',cells[1][0]);await fill('#igCellJ',cells[1][1]);await ctl('#igSaveBinding');await impact();await confirm();await choose('#igSurface','1');await ctl('#igApplyBinding');await impact();await confirm();
    const cellGrid=(await query('references')).grids[0].id;await face(1);await focusCell(cells[1]);const exact=await query(`grid-rule-query grid ${cellGrid} rule 1 cell ${cells[1].join(' ')}`);
    check(`${width} 指定 signed cell 規則原生裁切及完整 source/grid/cell 引用`,await read(`GridRuleLines.entries().length===3&&GridRuleLines.entries().every(l=>l.ref.systemId===${cellSid}&&l.ref.appliedGridId===${cellGrid}&&l.ref.cellI===${JSON.stringify(cells[1][0])}&&l.ref.cellJ===${JSON.stringify(cells[1][1])})`)&&JSON.stringify(await read(`GridRuleLines.entries().map(l=>l.segments)`))===JSON.stringify(exact.lines.map(l=>l.segments)));
    const cellWorld=await dump();await fill('#gridRuleCellI',String(BigInt(cells[1][0])+1n));await ctl('[data-rule-exact]');await wait(`document.querySelector('[data-rule-focus-status]').textContent.includes('SELECTOR_MISS')`);check(`${width} 指定規則 selector 外保留 native 拒絕且零寫入`,await read(`GridRuleLines.entries().length===0`)&&(await dump())===cellWorld);
  }
  check('本切片無新增未捕捉瀏覽器例外',exceptionCount()===exceptions);await leave();
};
