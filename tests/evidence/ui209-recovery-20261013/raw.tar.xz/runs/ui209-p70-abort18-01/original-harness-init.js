(()=>{
    let pending=0,last=performance.now();const original=window.fetch.bind(window);
    window.fetch=(...args)=>{pending++;last=performance.now();return original(...args).finally(()=>{pending--;last=performance.now();});};
    const observer=new MutationObserver(()=>{last=performance.now();});
    document.addEventListener('DOMContentLoaded',()=>observer.observe(document.body,{subtree:true,childList:true,attributes:true,characterData:true}));
    window.__cdpSettleUI=async ms=>{
      await new Promise(r=>setTimeout(r,ms));const end=performance.now()+5000;
      while(performance.now()<end){if(pending===0&&performance.now()-last>=150)return;await new Promise(r=>setTimeout(r,50));}
      // Opportunistic settling only: some race tests deliberately keep a fetch
      // pending. Their explicit waitForUI predicate/assertion is authoritative.
    };
  })()