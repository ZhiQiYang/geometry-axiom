/* D29/D30/I37/R32: actual browser input, native independent read-back.
 * Fixtures supply host geometry and dimension cards. Grid declarations, cell and vertex
 * selection use real CDP pointers; declarations are checked against hand oracles.
 */
const cdp=require('./cdp_helpers.js');
module.exports = async function gridSystemTests({send,eval_,sleep,click,drag,waitForUI,expectNativeDialog,exceptionCount,ui209}) {
  // S2 keeps the same exact discard question inside the active workspace.
  const discardDraft=async({message,accept})=>{
    await ctl('#igDiscardDraft');
    await waitForUI(`!!$('igDiscardConfirmation')&&$('igDiscardConfirmation').getAttribute('role')==='alertdialog'`,10000);
    const actual=await eval_(`$('igDiscardQuestion').textContent`);
    if(actual!==message)throw Error('Discard question changed: '+JSON.stringify({expected:message,actual}));
    await ctl(accept?'#igDiscardConfirm':'#igDiscardCancel');
    await waitForUI(`!$('igDiscardConfirmation')`,10000);
  };

  console.log('=== P70. 無限格線、獨立邊界與 cell 對齊 ===');
  const fs=require('fs'),path=require('path'),os=require('os'),same=require('util').isDeepStrictEqual,exceptions=exceptionCount();
  const check=cdp.makeCheck({prefix:'P70 ',throwOnFail:true});
  const read=cdp.makeRead(eval_);
  const wait=cdp.makeWait(waitForUI,20000);
  const baseCtl=cdp.makeCtl({eval_,sleep,click},{scroll:'center',attempts:12,pollMs:80,settleMs:140,missing:'Missing ',
    unreachable:(selector,p)=>'Grid control unreachable '+selector+' '+JSON.stringify(p)});
  // 2a: 相鄰格子相位差 is added on demand. Reaching its field first uses the real「相鄰格子相位差」control.
  const ctl=async(selector,...rest)=>{const m=/^#ig([UV])Stagger/.exec(String(selector));
    if(m&&await eval_(`(()=>{const n=document.getElementById('ig${m[1]}Stagger');return !!n&&n.getClientRects().length===0;})()`))await baseCtl(`[data-ig-add-stagger="${m[1].toLowerCase()}"]`);
    return baseCtl(selector,...rest);};
  const key=cdp.makeKey({send,sleep});
  const fill=cdp.makeFill({ctl,key,send,sleep},{afterMs:60});
  const choose=async(selector,value)=>{
    // 2a: 排格方式 is a segmented radio group, not a native select.
    if(/^#ig[UV]Source$/.test(selector))return ctl(`${selector} input[value="${value}"]`);
    const index=await read(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});return [...e.options].filter(o=>!o.disabled).findIndex(o=>o.value===${JSON.stringify(String(value))});})()`);if(index<0)throw Error('Missing enabled option '+selector+'='+value);await ctl(selector);await key('Home','Home',36);for(let i=0;i<index;i++)await key('ArrowDown','ArrowDown',40);await key('Enter','Enter',13);await wait(`document.querySelector(${JSON.stringify(selector)})?.value===${JSON.stringify(String(value))}`);};
  const query=command=>read(`apiRequest(${JSON.stringify(command)}).then(r=>{if(!r.ok)throw Error(JSON.stringify(r));return r;})`);
  const dump=async()=>(await query('dump')).text,objects=()=>query('objects'),refs=()=>query('references');
  const snapshot=async()=>({scene:await dump(),objects:await objects(),references:await refs()});
  const settled=()=>wait(`!oc.busy && !document.body.classList.contains('oc-busy')`),impact=()=>wait(`!!document.querySelector('.reference-impact[open]')`);
  const confirm=async()=>{await ctl('#impact-confirm');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();await sleep(220);};
  const cancel=async()=>{await ctl('.reference-impact .impact-actions button:first-child');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();};
  const card=(kind,id)=>`.ocard[data-kind="${kind}"][data-id="${id}"]`;
  const close=async(discard=false)=>{if(await read(`!!$('infiniteGridWorkspace')?.open`)){
    // This native-geometry suite explicitly abandons its raw test inputs.
    // The separate portable-draft browser gate verifies ordinary return/resume.
    if(discard||await read(`!!ReferenceWorkspace.readFeatureAttachment('grid-draft')`))
      await discardDraft({message:'捨棄這份未發布的原始草稿？已保存到場景的網格保持不變。',accept:true});
    else await ctl('#igClose');
  }};
  const open=async(kind,id)=>{await close();await ctl('#btnZoom');
    // A fresh partial-run profile has not dismissed this existing canvas
    // lesson. Use its real action before hitting a card behind the lesson.
    if(await read(`(()=>{const b=document.querySelector('#ocSelectionSummary .guidance-dismiss');return !!b&&b.getBoundingClientRect().width>0&&!b.hidden;})()`))await ctl('#ocSelectionSummary .guidance-dismiss');
    await ctl(card(kind,id));await ctl('#gridObjectOpen');await wait(`!!$('infiniteGridWorkspace')?.open && !!$('igGridView')`);if(kind==='grid-binding')await wait(`$('igVertex').value!=='' && $('igSurface').options.length>0`);};
  const axis=async(letter,source,fields)=>{await choose('#ig'+letter+'Source',source);for(const [field,value] of Object.entries(fields))await fill('#ig'+letter+field,value);};
  const saveSource=async()=>{await ctl('#igSaveSource');await impact();await confirm();};
  const create=async(name,u=['repeat',{Phase:0,Step:600}],v=['repeat',{Phase:0,Step:400}],entry='#btnNewGridSystem')=>{
    await close();const ids=new Set((await objects()).gridSystems.map(g=>g.id));await ctl(entry);await wait(`!!$('infiniteGridWorkspace')?.open`);await fill('#igName',name);await axis('U',...u);await axis('V',...v);await ctl('#igMainAlong input[value="none"]');
    const before=await dump();await ctl('#igSaveSource');await impact();check('新增來源先預覽，沒有提前寫入世界',(await dump())===before);await confirm();const added=(await objects()).gridSystems.filter(g=>!ids.has(g.id));check('確認建立無限來源並保存名稱',added.length===1&&added[0].name===name&&added[0].mode==='infinite',added);return added[0].id;
  };
  const pickCell=async(u,v)=>{await read(`$('igGridView').scrollIntoView({block:'center'});void 0`);await sleep(160);const p=await read(`(()=>{const g=$('igGridView'),c=g.dataset.igCamera.split(' ').map(Number),r=g.querySelector('[data-ig-plot]').getBoundingClientRect(),k=r.width/(c[2]-c[0]);return {x:r.left+(${u}-c[0])*k,y:r.top+(${v}-c[1])*k};})()`);await click(p.x,p.y);await sleep(100);};
  const binding=async(source,boundary,vertex,anchor,expected)=>{
    await open('grid-system',source);await ctl('#igNewBinding');await choose('#igBoundary',boundary);await wait(`!!document.querySelector('[data-ig-vertex="${vertex}"]')`);await ctl(`[data-ig-vertex="${vertex}"]`);await pickCell(-900,600);await ctl(`[data-ig-anchor="${anchor}"]`);
    check('真正點選負索引格子與邊界頂點',await read(`$('igCellI').value==='-2' && $('igCellJ').value==='1' && $('igVertex').value===${JSON.stringify(vertex)}`));const before=await dump(),ids=new Set((await objects()).gridBindings.map(b=>b.id));await ctl('#igSaveBinding');await impact();check('配置與首次頂點 key 一起預覽，確認前沒有保存',(await dump())===before);await confirm();const added=(await objects()).gridBindings.filter(b=>!ids.has(b.id));check('配置保存精確 cell 與手算平移',added.length===1&&same(added[0].cell,['-2','1'])&&same(added[0].translation,expected),added);return added[0].id;
  };
  const shot=cdp.makeShot(send,['GEOMETRY_GRID_SYSTEM_SCREENSHOT_DIR']);
  const fixture=async lines=>read(`(async()=>{for(const line of ${JSON.stringify(lines)}){const r=await apiRequest('line '+line);if(!r.ok||r.preview)throw Error(line+' '+JSON.stringify(r));}if(!await renderObjects())throw Error('Fixture render failed '+JSON.stringify(connection));return true;})()`);
  const reset=async()=>read(`(async()=>{for(const d of document.querySelectorAll('dialog[open]'))d.close();resetSceneFocus();await setView3(false);closePanels();const r=await api('reset');if(!r.ok)throw Error(JSON.stringify(r));if(!await renderObjects())throw Error('Reset render failed');setOcTool('select');return true;})()`);


  await reset();
  await fixture(['boundary 301 outline 100,200 1300,200 1300,1000 100,1000']);
  await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await sleep(200);
  if(!await read("$('btnNewGridSystem').getBoundingClientRect().width>0"))await ctl('#toggleLeft');
  const mobile=await create('手機 無限');
  await ui209({ctl,choose,wait,read,open,mobile});
};
