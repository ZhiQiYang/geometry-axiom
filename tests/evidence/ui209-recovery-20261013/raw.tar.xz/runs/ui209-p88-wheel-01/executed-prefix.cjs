/* #61 slice 2: normal source/rule/binding/apply UI. Native fixture calls only
 * author initial faces/supports or explicit stale/rejection adversaries. */
'use strict';
const cdp=require('./cdp_helpers.js');
module.exports=async function({send,eval_,sleep,click,waitForUI,expectNativeDialog,exceptionCount,ui209}){
  console.log('=== P88. 原生來源子線顯示、完整引用、兩面及正式重開 ===');
  const fs=require('fs'),os=require('os'),path=require('path'),P=require('./project-store.js'),zip=require('./vendor/fflate/umd/index.js');
  const read=cdp.makeRead(eval_),wait=cdp.makeWait(waitForUI,25000),check=cdp.makeCheck({prefix:'P88 ',throwOnFail:true}),exceptions=exceptionCount();
  const baseCtl=cdp.makeCtl({eval_,sleep,click},{scroll:'center',attempts:12,pollMs:70,settleMs:100,hitElement:true,missing:'Missing ',unreachable:(s,p)=>'Rule line control unreachable '+s+' '+JSON.stringify(p)});
  const ctl=async selector=>{if(await read('innerWidth<=900')){
    const root=await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)});return n?.closest('#objectList')?'left':n?.closest('#inspectorContent')?'right':n?.closest('.face-inspector-panel')?'face':n?.closest('.face-layer-panel')?'face-left':null;})()`);
    if(root==='left'&&!await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#toggleLeft');
    if(root==='right'){if(await read(`document.body.classList.contains('canvas-composition')`)){if(await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#toggleLeft');}else if(!await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#toggleRight');}
    if(root==='face'&&!await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#workspaceToggleRight');
    if(root==='face-left'&&!await read(`document.body.classList.contains('drawer-left-open')`))await baseCtl('#workspaceToggleLeft');
    if(selector.startsWith('.face-rule-hit')&&await read(`document.body.classList.contains('drawer-right-open')`))await baseCtl('#workspaceToggleRight');
  }if(await read(`document.querySelector(${JSON.stringify(selector)})?.closest('#createObjectPop')?.hidden===true`))await baseCtl(await read(`innerWidth<=900?'#mobileCreateObject':'#btnCreateObject'`));// #123 S3 exposes one component form at a time. Enter its existing tab
  // with the same trusted hit-tested controls before using a migrated field.
  const section=await read(`document.querySelector(${JSON.stringify(selector)})?.closest('[data-component-section]')?.dataset.componentSection||null`);
  if(section&&await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)}),p=n?.closest('[data-fi-pane]'),s=n?.closest('[data-component-section]');return !!p?.hidden||!!s?.classList.contains('component-collapsed');})()`)){
    await baseCtl('#faceInspectorTabs [data-fi-tab="components"]');
    await baseCtl('[data-component-tab="'+section+'"]');
  }
  return baseCtl(selector);};
  // A default-valued select must not pass after a click reached another
  // element. Check the actual keyboard target before sending input.
  const focusedCtl=async selector=>{await ctl(selector);await wait(`document.activeElement===document.querySelector(${JSON.stringify(selector)})`);};
  const key=cdp.makeKey({send,sleep}),fill=cdp.makeFill({ctl:focusedCtl,key,send,sleep},{afterMs:35});
  // Native button activation also needs Enter's character event in Chromium.
  const activateKey=cdp.makeKey({send,sleep},{enterText:true});
  const historyOracle=cdp.makeHistoryOracle(read,'P88');
  const shot=cdp.makeShot(send,['GEOMETRY_GRID_RULE_SCREENSHOT_DIR']);
  const query=cmd=>read(`apiRequest(${JSON.stringify(cmd)}).then(r=>{if(!r.ok)throw Error(JSON.stringify(r));return r;})`),dump=async()=>(await query('dump')).text,objects=()=>query('objects'),settled=()=>wait('!oc.busy&&!ReferenceWorkspace.busy');
  const impact=()=>wait(`!!document.querySelector('.reference-impact[open]')`),confirm=async()=>{await ctl('#impact-confirm');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();},cancel=async()=>{await ctl('.reference-impact .impact-actions button:first-child');await wait(`!document.querySelector('.reference-impact[open]')`);await settled();};
  const choose=async(selector,value)=>{const n=await read(`(()=>{const n=document.querySelector(${JSON.stringify(selector)});return [...n.options].filter(o=>!o.disabled).findIndex(o=>o.value===${JSON.stringify(value)});})()`);if(n<0)throw Error('Missing enabled option '+selector+' '+value);await focusedCtl(selector);await key('Home','Home',36);for(let i=0;i<n;i++)await key('ArrowDown','ArrowDown',40);await key('Enter','Enter',13);await wait(`document.querySelector(${JSON.stringify(selector)}).value===${JSON.stringify(value)}`);};
  const fixture=async cmd=>read(`(async()=>{let r=await apiRequest('line '+${JSON.stringify(cmd)});if(r.preview){if(!r.preview.valid)throw Error(JSON.stringify(r));r=await apiRequest('line confirm '+r.preview.token);}if(!r.ok)throw Error(JSON.stringify(r));await renderObjects();return true;})()`);
  const leave=async()=>{if(await read(`$('infiniteGridWorkspace').open`))await ctl('#igClose');if(await read(`!!oc.focus`))await ctl('#workspaceBackButton');await settled();};
  const newSource=async()=>ctl(await read(`innerWidth<=900?'#btnQuickGrid':'#btnNewGridSystem'`));
  const fresh=async()=>{await leave();const dirty=await read('ReferenceWorkspace.context().dirty');await ctl('#fileMenuBtn');await expectNativeDialog(()=>ctl('#btnNewProject'),{message:'建立一份空白新專案，切換為新的專案識別及「未命名專案」。'+(dirty?'目前尚未保存的變更不會自動寫入檔案。':'')+'本次切換可一步復原；僅保存在本頁的形狀特徵參數不會恢復。確定繼續嗎？',accept:true});await settled();};
  const openSource=async sid=>{await leave();await ctl(`#objectList .object-row[data-kind="grid-system"][data-id="${sid}"]`);await ctl('#gridObjectOpen');await wait(`$('infiniteGridWorkspace').open&&!$('igRuleAdd').disabled`);};
  const face=async bid=>{await leave();await ctl(`#objectList .object-row[data-kind="boundary"][data-id="${bid}"]`);await ctl('#inspEnter');await wait(`oc.edit?.bid===${bid}`);await wait(`GridRuleLines.entries().some(l=>l.segments.length)`);};
  const focusCell=async(cell,rule=1)=>{await ctl('#faceInspectorTabs [data-fi-tab="components"]');await wait(`!!document.querySelector('[data-rule-exact]')`);await choose('[data-rule-focus-key]',String(rule));await fill('[data-rule-cell-i]',cell[0]);await fill('[data-rule-cell-j]',cell[1]);await ctl('[data-rule-exact]');await wait(`GridRuleLines.entries().every(l=>l.cell.join(',')===${JSON.stringify(cell.join(','))}&&l.ruleKey===${rule})&&document.querySelector('[data-rule-focus-status]').textContent.includes('已核對')`);};
  const pickRule=async ref=>{if(await read(`innerWidth<=900&&document.body.classList.contains('drawer-right-open')`))await ctl('#workspaceToggleRight');if(await read(`innerWidth<=900&&document.body.classList.contains('drawer-left-open')`))await ctl('#workspaceToggleLeft');const point=await read(`(()=>{const key=${JSON.stringify(ref)},line=GridRuleLines.entries().find(l=>GridRuleLines.key(l.ref)===key),box=$('faceEditorViewport').getBoundingClientRect();for(const segment of line?.segments||[])for(const f of [.5,.3,.7,.15,.85]){const x=box.left+fe.panX+(segment[0][0]+(segment[1][0]-segment[0][0])*f)*fe.zoom,y=box.top+fe.panY+(segment[0][1]+(segment[1][1]-segment[0][1])*f)*fe.zoom,hit=document.elementFromPoint(x,y);if(hit?.classList.contains('face-rule-hit')&&hit.dataset.ruleLineKey===key)return {x,y};}return null;})()`);if(!point)throw Error('No visible native rule hit '+ref);await click(point.x,point.y);await sleep(100);};
  const save=async()=>{const directory=fs.mkdtempSync(path.join(os.tmpdir(),'geometry-rule-lines-'));await send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:directory});await read(`window.__linePicker=Object.getOwnPropertyDescriptor(window,'showSaveFilePicker');Object.defineProperty(window,'showSaveFilePicker',{value:undefined,configurable:true});void 0`);let file;try{await ctl('#projectBar [data-project-action="save"]');for(let i=0;i<150;i++){const files=fs.readdirSync(directory).filter(f=>f.endsWith('.gcanvas'));if(files.length===1){file=path.join(directory,files[0]);break;}await sleep(100);}}finally{await read(`if(window.__linePicker)Object.defineProperty(window,'showSaveFilePicker',window.__linePicker);else delete window.showSaveFilePicker;delete window.__linePicker;void 0`);}if(!file)throw Error('Missing formal ZIP');return {file,directory};};
  const reopen=async file=>{await fresh();check('重開前確有新空白 context',await read('oc.gridSystems.length===0&&oc.gridBindings.length===0&&oc.faces.length===0'));await send('Page.setInterceptFileChooserDialog',{enabled:true});try{await ctl('#fileMenuBtn');await ctl('#btnOpenProject');const d=await send('DOM.getDocument',{depth:0}),n=await send('DOM.querySelector',{nodeId:d.result.root.nodeId,selector:'#projectFile'});await send('DOM.setFileInputFiles',{nodeId:n.result.nodeId,files:[file]});await settled();await wait('oc.gridBindings.length===2');}finally{await send('Page.setInterceptFileChooserDialog',{enabled:false});}};
  for(const width of [1280]){
    await send('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:false});await fresh();
    const cells=[['-2','1'],['9007199254740993','-9007199254740995']];
    for(const bid of [1,2]){await fixture(`boundary ${bid} outline ${bid===1?'0,0 1200,0 1200,800 0,800':'0,0 1200,0 1200,800 800,800 800,600 0,600 hole 170,80 170,280 230,280 230,80'}`);await fixture(`placement ${bid} on boundary ${bid} origin 0 0 ${(bid-1)*2000} u +x v +y`);}
    await newSource();await wait(`!!$('igName')&&!$('igName').disabled`);await fill('#igName',`Authored shared rule ${width}`);await ctl('#igSaveSource');await impact();await confirm();const sid=(await objects()).gridSystems[0].id;
    await ctl('#igRuleAdd');await fill('#igRuleName','Native inner lines');await ctl('#igRulePreview');await impact();await confirm();
    await wait(`!!document.querySelector('[data-ig-source-rule="1"]')`);check(`${width} 来源原生子線顯示而 ref:null 未轉成 applied 引用`,await read(`document.querySelectorAll('[data-ig-source-rule]').length>0&&[...document.querySelectorAll('[data-ig-source-rule]')].every(n=>n.dataset.igRuleRef==='none')`));
    for(let index=0;index<2;index++){
      if(index)await ctl('#igEditSource');await ui209(()=>ctl('#igNewBinding'),index);await choose('#igBoundary',String(index+1));await wait(`$('igVertex').options.length>1&&!$('igCellI').disabled`);await choose('#igVertex','outer:0');await fill('#igCellI',cells[index][0]);await fill('#igCellJ',cells[index][1]);await ctl('#igSaveBinding');await impact();await confirm();
      await wait(`!!document.querySelector('[data-ig-result-rule="1"]')`);check(`${width} 配置 ${index} 真 signed cell 保存及只讀裁切顯示`,(await objects()).gridBindings[index].cell.join(',')===cells[index].join(',')&&await read(`[...document.querySelectorAll('[data-ig-result-rule]')].every(n=>n.dataset.igRuleRef==='none')`));
      await choose('#igSurface',String(index+1));await ctl('#igApplyBinding');await impact();await confirm();
    }

  }
};
