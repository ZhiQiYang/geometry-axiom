"""Observe the original Q38 gate; retain inputs and binaries before its cleanup.

No product/test functions, subprocess arguments, return values or timeouts are
patched.  The original gate owns compilation, discovery and every verdict.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import runpy
import sys


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    tmp = Path(os.environ['TMPDIR']).resolve()
    out.mkdir(parents=True, exist_ok=False)
    records, errors, commands = [], [], []
    safe = ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'GITHUB_SHA', 'GITHUB_WORKSPACE',
            'PYTHONDONTWRITEBYTECODE', 'PYTHONOPTIMIZE', 'GEOMETRY_TEST_BRIDGE')

    def save():
        (out / 'RETENTION.json').write_text(json.dumps(
            {'files': records, 'errors': errors, 'popen': commands},
            ensure_ascii=False, indent=2) + '\n')

    def retain(path, destination):
        body = path.read_bytes()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(body)
        records.append({'original': str(path), 'retained': str(destination),
                        'bytes': len(body), 'sha256': sha(body)})

    def audit(event, values):
        try:
            if event == 'subprocess.Popen':
                executable, argv, cwd, env = values
                actual_env = os.environ if env is None else env
                commands.append({'executable': os.fsdecode(executable),
                                 'argv': [os.fsdecode(v) for v in argv],
                                 'cwd': os.fsdecode(cwd) if cwd else os.getcwd(),
                                 'environment': {k: actual_env.get(k) for k in safe}})
                save()
            if event != 'shutil.rmtree' or not values:
                return
            path = Path(os.fsdecode(values[0]))
            if not path.is_absolute():
                return
            path = path.resolve()
            if not path.is_relative_to(tmp):
                return
            if path.name in ('SPM43', 'SPM44') and path.parent.name.startswith('section-profile-mutations-'):
                for source in sorted(path.rglob('*')):
                    if source.is_file():
                        retain(source, out / 'inputs' / path.name / source.relative_to(path))
            elif path.name.startswith('section-profile-mutations-'):
                source_root = path / 'base-source'
                for source in sorted(source_root.rglob('*')):
                    if source.is_file():
                        retain(source, out / 'inputs' / 'baseline' / source.relative_to(source_root))
                for name in ('bridge-baseline', 'bridge-SPM43', 'bridge-SPM44'):
                    binary = path / name
                    if binary.is_file():
                        retain(binary, out / 'binaries' / name)
            save()
        except BaseException as error:
            # Observer errors remain separate; never replace a subject result.
            errors.append({'event': event, 'error': repr(error)})
            try:
                save()
            except BaseException:
                pass

    sys.addaudithook(audit)
    target = root / 'tests' / 'section_profile_mutation_check.py'
    sys.argv = [str(target), '--group', 'native', '--only', 'SPM43', '--only', 'SPM44',
                '--jobs', '1', '--receipt', str(out / 'gate-receipt.json'),
                '--logs', str(out / 'gate-logs')]
    original_exit = None
    try:
        runpy.run_path(str(target), run_name='__main__')
        original_exit = 0
    except SystemExit as result:
        original_exit = result.code
        raise
    finally:
        (out / 'ORIGINAL_EXIT.json').write_text(json.dumps(
            {'original_exit': original_exit, 'observer_errors': errors,
             'gate_argv': sys.argv}, ensure_ascii=False, indent=2) + '\n')
        save()


if __name__ == '__main__':
    main()
