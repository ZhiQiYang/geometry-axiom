本 PR 補 Q38 AC23 面材貼齊案例的具名故障反證。原閘門的接觸判式雖由角材案例打紅，寬 346 mm 的面材案例位於不參與突變閘門的 source-index 方法，缺少自身的反證。產品碼與公理不變。

目前是 draft；修正後的 native focused gate 尚未重跑，不可合併。

產品／測試來源 S=`af4fd36c17d05b5da2411b70266ed040e22a6561`；固定基底=`5b0ce47d25393fad675bf506a9d296cbab43c35d`，base branch 為 `codex/train-337-continue-20261024`。來源分支已一般推送；證據提交與正文分支尚待本輪反證完成後發布。

| Gate | 實測來源 | 原 exit／結果 | 範圍與未完成項 |
|---|---|---|---|
| 原 selection／exception-evidence Python 單元 | S | 0；30 tests／OK | 前後 HEAD／clean 相符；不是 native aggregate 或 AC23 反證 |
| 第一輪原 native focused gate | `c9269e13` | 2；baseline 29 tests，27 過、2 errors | 兩個新案例被接受後，測試誤讀構件 id 所在層級而 KeyError。只編譯 baseline 一次，mutants 未啟動；原件保留 |
| schema 修正 | S | 僅兩處 `m["id"]` 改讀 `m["value"]["id"]` | 原 6 個 literal rect asserts 全保，16 項窄靜審／0；不能當成動態通過 |
| 修正後 focused gate／恢復 | S | 未跑 | 待原 baseline→SPM43／SPM44→同 hash baseline 恢復的 0/1/0；不得把 KeyError 算 killed |
| 原完整 44-case Q38 閘門 | 待合流來源 | 未跑 | 本輪 focused 不替代原全量閘門 |
| run_all expected／完整整合／帳本／架構 | 待合流來源 | 未跑 | native 方法數 28→30；共用 expected key 暫由 root 按合流順序更新，這個分支尚未改該檔 |

兩個新 native 方法沿用 AC23 的 27／346／373／400 mm 幾何與板厚 6 mm。第二個方法只交換 u/v，以獨立字面矩形驗證另一方向。I45／R36 既定「正面積才重疊、等號接觸合法」，沒有新增尺寸門檻。

保留原 28 方法、42 cases、SPM03／SPM04 的 killers、PAIR_CORNERS 與 verdict／exception 判官。新增 SPM43／SPM44，使用原相應故障與相同跨層閉包，各自只認該 AC23 方法的具名 AssertionError，避免原角材 TOUCH 已紅遮住面材測試回歸。全帳本的 123 個 M 定義未改；本分支不自行重產帳本。

首輪失敗的 source=`c9269e13`，未在後續 schema 編輯前另錄 final-clean，因此不宣稱有該末端守門；初始 HEAD／clean、原完整輸出與實際 C 輸入另存。它和修正後來源分欄，沒有改寫成環境通過或產品反證。

雲端原件目前在 `/tmp/geo260-ac23-run-c9269e13/`、`/tmp/geo260-ac23-pure-unit-af4fd36c/` 與 `/tmp/geo260-ac23-prep-20261024/`。原 compile／child 時限保持 600／900 秒，沒有放寬 assertions、goldens、裁判或 skip。
