# #314 舊雙軸場景產製收據

以下為本次實際執行結果；完整指令與原始輸出在 raw 目錄。

- 結果：`passed`。
- 來源 SHA：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。
- bridge SHA-256：`44c425c7eb9b840630964de0ec04266d69b3fc5159f7bb47a7493d510104037c`。
- sidecar SHA-256：`ac83586a0f096b8e376c153a36ed2c4c104a4a57e03a109c5481113e41265e47`。
- process exit：`0`。
- fixture SHA-256：`fa88adca750f837fe989fc1736f0364badc367be255dceb8f571ef3f43887958`。
- loadfile/dump 位元組相同：`True`。
- 環境：`environment.json`；來源與編法：`source-identity.json`。
- 逐項收據：`legacy-two-axis-stagger-inspector-direct.receipt.json`。
