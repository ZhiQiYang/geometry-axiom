from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

ROOT = Path('/tmp/geometry-r06-main359-integration-20261102')
OUT = Path(__file__).resolve().parent
BASE = 'df7eb43af3389ff2afc1a73aaf4e57580ae612fc'
OURS = '7a876ed6a772f3bb5fff0f9644421d6ec6e6cea4'
THEIRS = 'fca3f1a80f1dab564f5dd4c01c9e1226eaf09e2d'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
PATTERN = re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n', re.M | re.S)
decisions = []


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], env=ENV)


def original(ref, path):
    return git('show', f'{ref}:{path}')


def resolve(path, resolutions):
    target = ROOT / path
    data = target.read_bytes().decode()
    blocks = list(PATTERN.finditer(data))
    assert len(blocks) == len(resolutions), (path, len(blocks), len(resolutions))
    index = 0

    def choose(match):
        nonlocal index
        action = resolutions[index]
        index += 1
        ours, theirs = match.group(1), match.group(2)
        result = action(ours, theirs) if callable(action) else (ours if action == 'ours' else theirs)
        decisions.append({'path': path, 'block': index, 'oursSha256': hashlib.sha256(ours.encode()).hexdigest(), 'theirsSha256': hashlib.sha256(theirs.encode()).hexdigest(), 'resultSha256': hashlib.sha256(result.encode()).hexdigest()})
        return result

    result = PATTERN.sub(choose, data)
    assert not PATTERN.search(result)
    target.write_bytes(result.encode())


for path in ['geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md', 'geometry-core/domain-decoupling/product-architecture-scan.json', 'geometry-core/domain-decoupling/product-architecture-receipt.json', 'tests/mutants_results.json']:
    # Original derived bytes are retained without a fabricated fresh stamp.
    (ROOT / path).write_bytes(original(THEIRS, path))
    decisions.append({'path': path, 'action': 'exact-main-derived-bytes', 'needsFreshFinalRegeneration': True})

resolve('geometry-templates/woodworking/native/assembly_sources.c', [lambda a, b: a.replace('e->source_named!=a->source_named', 'e->last_terminal!=a->last_terminal||e->source_named!=a->source_named')])
resolve('geometry-web/engineering_bridge.inc', [lambda a, b: a.replace('\\\"grid-card-reference/1\\\"]', '\\\"grid-card-reference/1\\\",\\\"definition-import/1\\\"]')])
resolve('geometry-web/scenario_verify.py', [lambda a, b: '# definition-import/1 is bridge-only, never a scene/project requirement.\n' + a.replace('"assembly-bay-repeat/1"}', '"assembly-bay-repeat/1", "definition-import/1"}')])


def reader(a, b):
    result = a.replace('recordProfile=null) {', 'recordProfile=null,options={}) {')
    anchor = '    const supported=nativeReaderCapabilities(nativeCapabilities);\n'
    prefix = '''    // Retain the explicit K1 options call and the finite R06 profile call.
    // A non-array profile cannot become a PF-H credential through options.
    if(arguments.length<=2 && keys(nativeProfiles,[],['cutting'])) {
      options=nativeProfiles;nativeProfiles=[];
    }
    if(!keys(options,[],['cutting']) || Object.hasOwn(options,'cutting')&&typeof options.cutting!=='boolean')
      fail('專案讀取能力選項不合法。');
    const shared=format17Capabilities.filter(capability=>capability!==CUTTING_CAPABILITY||options.cutting===true);
'''
    assert anchor in result
    result = result.replace(anchor, prefix + anchor, 1)
    return result.replace('...format17Capabilities, Features.ROOM_CAPABILITY', '...shared, Features.ROOM_CAPABILITY')


resolve('geometry-web/project-store.js', [reader, lambda a, b: a.replace('return { Features, ', 'return { Features, CUTTING_FORMAT, CUTTING_CAPABILITY, ', 1)])
resolve('geometry-web/reference-workspace.js', [lambda a, b: a.replace('candidate.final_scene,hostRecordProfile)', 'candidate.final_scene,hostRecordProfile,{cutting:true})')])


def schedule_source(a, b):
    result = a.replace('throw Error(`角材 ${t.id} 的生成尺寸來源尚未核對，料單未就緒。`);', "throw failure('ASSEMBLY_SOURCE_UNVERIFIED',`角材 ${t.id} 的生成尺寸來源尚未核對，料單未就緒。`);")
    return result.replace('path:effective[field].path,override:false}))', "path:effective[field].path,override:false,\n      ...(Object.hasOwn(effective[field],'terminal')?{terminal:JSON.parse(JSON.stringify(effective[field].terminal))}:{})}))")


resolve('geometry-web/timber-schedule.js', [schedule_source, lambda a, b: a.replace('JSON.stringify(r.sources)', "JSON.stringify(r.sources,(key,value)=>key==='terminal'?undefined:value)")])
resolve('tests/run_all.py', [lambda a, b: a + b])


def json_merge_rows(path, field, special=None):
    documents = {name: json.loads(original(ref, path)) for name, ref in [('base', BASE), ('F4', OURS), ('main', THEIRS)]}
    before, left, right = [documents[name][field] for name in ['base', 'F4', 'main']]
    rows = {}; proof = []
    for key in sorted(left.keys() | right.keys()):
        base, ours, theirs = before.get(key), left.get(key), right.get(key)
        if ours == theirs:
            result, action = ours, 'both-identical'
        elif ours == base:
            result, action = theirs, 'main-only-change'
        elif theirs == base:
            result, action = ours, 'F4-only-change'
        else:
            assert special and key in special, (path, key, base, ours, theirs)
            result, action = special[key](base, ours, theirs)
        rows[key] = result
        proof.append({'key': key, 'base': base, 'F4': ours, 'main': theirs, 'merged': result, 'decision': action})
    result = documents['main']; result[field] = rows
    return result, proof


expected, expected_proof = json_merge_rows('tests/run_all.expected.json', 'suites', {'node:tests-js': lambda b, a, t: (t, 'main-original740-retained-STILL-STALE-until-original-producer')})
(ROOT/'tests/run_all.expected.json').write_text(json.dumps(expected, ensure_ascii=False, indent=2)+'\n')
(OUT/'EXPECTED_THREE_WAY_ROWS.json').write_text(json.dumps({'rows': expected_proof, 'nodeAggregate': 'UNMEASURED on merged source; retained main740 is intentionally not claimed correct. No arithmetic/max/downgrade. Root must run original producer.'}, ensure_ascii=False, indent=2)+'\n')
golden, golden_proof = json_merge_rows('geometry-web/cdp_sections.golden.json', 'sections')
golden['total'] = sum(golden['sections'].values())
assert golden['total'] == 2360 and len(golden['sections']) == 88
(ROOT/'geometry-web/cdp_sections.golden.json').write_text(json.dumps(golden, ensure_ascii=False, indent=2)+'\n')
(OUT/'GOLDEN_THREE_WAY_ROWS.json').write_text(json.dumps({'rows': golden_proof, 'total': golden['total'], 'allExistingSectionValuesPreserved': True, 'originalTotals': {'F4': 2317, 'main': 2310}, 'newFullRuntime': 'UNRUN; only exact pre-existing metadata union authorized by root'}, ensure_ascii=False, indent=2)+'\n')

# The only policy conflict is the dedicated CDP test-driver exclusion identity.
resolve('geometry-core/domain-decoupling/product-architecture.json', ['theirs'])
manifest_path = ROOT/'geometry-core/domain-decoupling/product-architecture.json'
manifest = json.loads(manifest_path.read_bytes())
found = []


def update_identity(value):
    if isinstance(value, dict):
        if value.get('path') == 'geometry-web/cdp_test.js' and 'sha256' in value:
            old = value['sha256']; value['sha256'] = hashlib.sha256((ROOT/value['path']).read_bytes().replace(b'\r\n', b'\n')).hexdigest(); found.append({'old': old, 'new': value['sha256'], 'reasonUnchanged': value.get('reason'), 'hashMode': value.get('hashMode')})
        for child in value.values(): update_identity(child)
    elif isinstance(value, list):
        for child in value: update_identity(child)


update_identity(manifest)
assert len(found) == 1
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
(OUT/'MANIFEST_EXCLUSION_CONFLICT.json').write_text(json.dumps({'cdpExclusion': found, 'ownershipRulesChanged': False, 'derivedReceiptStillPending': True}, ensure_ascii=False, indent=2)+'\n')
(OUT/'MERGE_RESOLUTION_DECISIONS.json').write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': BASE, 'F4': OURS, 'main': THEIRS, 'decisions': decisions, 'newRuntime': 'UNRUN', 'productWriter': 'root/r06_main359_closure on private branch only'}, ensure_ascii=False, indent=2)+'\n')

for path in git('diff', '--name-only', '--diff-filter=U').decode().splitlines():
    data = (ROOT/path).read_bytes()
    assert b'<<<<<<< HEAD' not in data and b'>>>>>>> '+THEIRS.encode() not in data, path
print('PRIVATE_CONFLICT_RESOLUTIONS_READY: no original assertion or section value relaxed; new runtime UNRUN')
