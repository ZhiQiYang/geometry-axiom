from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import resource
import subprocess
import time

ROOT=Path('/tmp/geometry-r06-main359-integration-20261102')
OUT=Path(__file__).resolve().parent/'private-controls'
OUT.mkdir(exist_ok=False)
NODE='/tmp/geometry-resume-20261102/pr363/node-v24.22.1-linux-x64/bin/node'
P='c2eb5edc99d2880a65583f46085617d99a6f191b'
git_env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,env=git_env).decode().strip()==P
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,env=git_env)
paths=['geometry-web/project-store.js','geometry-web/reference-workspace.js','geometry-web/feature-attachments.js','geometry-web/cutting-settings.js','geometry-web/scenario-catalog.js','geometry-web/vendor/fflate/umd/index.js','tests/diagnostics/r06_main359_merge_contract.cjs']
inputs={p:{'bytes':(ROOT/p).stat().st_size,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in paths}
(OUT/'FIXED_INPUTS.json').write_text(json.dumps({'sourceP':P,'inputs':inputs,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'meaning':'Original source unchanged; private source-copy controls only. Pure contract/transport fakes, not browser/native.'},indent=2)+'\n')

mutants=[
 ('drop-pfh-reader','geometry-web/project-store.js','supported.push(PANEL_FILL_CAPABILITY);','void PANEL_FILL_CAPABILITY;','GEOMETRY_R06_PRIVATE_PROJECT_STORE','R06_MAIN359_PFH_AND_CUTTING_ARCHIVE'),
 ('drop-workspace-cutting-option','geometry-web/reference-workspace.js','hostRecordProfile,{cutting:true})','hostRecordProfile)','GEOMETRY_R06_PRIVATE_REFERENCE_WORKSPACE','R06_MAIN359_PREPARE_FORWARDS_BOTH_CONTRACTS'),
 ('advertise-cutting-without-optin','geometry-web/project-store.js','capability!==CUTTING_CAPABILITY||options.cutting===true','capability!==CUTTING_CAPABILITY||true','GEOMETRY_R06_PRIVATE_PROJECT_STORE','R06_MAIN359_CUTTING_OPTIN_REMAINS_EXPLICIT'),
]
rows=[]


def run(name,environment,expected_name=None):
    directory=OUT/name;directory.mkdir(exist_ok=False)
    argv=[NODE,'--test','--test-reporter=tap','tests/diagnostics/r06_main359_merge_contract.cjs']
    env=dict(os.environ,**environment)
    (directory/'REQUEST.json').write_text(json.dumps({'sourceP':P,'argv':argv,'cwd':str(ROOT),'environmentOverride':environment,'stackBytes':16777216,'timeoutSeconds':60,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
    start=time.monotonic();old=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16777216,old[1]))
    try:
        with (directory/'stdout').open('wb') as stdout,(directory/'stderr').open('wb') as stderr:
            r=subprocess.run(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,timeout=60)
    finally:resource.setrlimit(resource.RLIMIT_STACK,old)
    text=(directory/'stdout').read_text();failures=re.findall(r'^not ok \d+ - (.*)$',text,re.M)
    observed={k:int(re.search(r'^# '+k+r' (\d+)$',text,re.M).group(1)) for k in ['tests','pass','fail','cancelled','skipped']}
    valid=(r.returncode==0 and observed=={'tests':8,'pass':8,'fail':0,'cancelled':0,'skipped':0}) if expected_name is None else (r.returncode==1 and expected_name in failures and observed['cancelled']==0 and observed['skipped']==0)
    result={'name':name,'sourceP':P,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-start,'exit':r.returncode,'observed':observed,'namedFailures':failures,'expectedNamedFailure':expected_name,'validControl':valid,'productSourceUnchanged':all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==meta['sha256'] for p,meta in inputs.items()),'newNativeExecutions':0,'newBrowserExecutions':0}
    (directory/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');rows.append(result)
    print(name,r.returncode,observed,failures,flush=True)
    assert valid and result['productSourceUnchanged'],result


run('fixed',{})
for name,path,before,after,variable,expected in mutants:
    source=(ROOT/path).read_text();assert source.count(before)==1,(name,source.count(before))
    changed=source.replace(before,after,1);file=OUT/(name+Path(path).suffix);file.write_text(changed)
    (OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(source.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile=path,tofile=path)))
    run(name,{variable:str(file)},expected)
run('restored',{})
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,env=git_env)
(OUT/'RESULT.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceP':P,'status':'PASS_PRIVATE_CONTRACT_0_1_1_1_0','runs':rows,'originalSourceCleanBeforeAfter':True,'mutantFilesOutsideProduct':True,'newRealBrowserRuns':0,'newNativeProductRuns':0,'limitations':['Archive and source-text scheduling tests are not fresh Chrome profile or native World execution.','Node aggregate expected740 is deliberately still stale; original full producer pending root.','Generic final ledger/architecture/full native/browser remain UNRUN on this source.']},ensure_ascii=False,indent=2)+'\n')
