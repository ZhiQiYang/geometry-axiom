# Product architecture — GitHub 新來源收據

來源 `abbf1465e4617110f16892ba3925b20615345177`；採入 main `8f82b207e87c086705a1d8b7a00e2f215c07cbcf`；Actions run `41453934297`。

這份衍生資料來自原 scanner CLI 與原兩支 unittest 的實際執行；三命令均 exit 0、零 skip。它只證明靜態依賴契約，不能替代演算法責任審查、原生／突變／瀏覽器或 SSOT 驗證。

本次 614 inputs、342 owned、272 exclusions、816 edges、0 diagnostics；architecture-unit=205、architecture-product=22。完整命令、原始輸出與雜湊在同 artifact。

| Layer | Sources |
|---|---:|
| H | 198 |
| K | 70 |
| W | 68 |
| vendor | 6 |

main 的歷史收據保留在 Git `8f82b207e87c086705a1d8b7a00e2f215c07cbcf`，本次沒有改寫其來源或沿用其綠燈。
