"""Read-only final GitHub CI acquisition; no dispatch or product execution."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.parse
import urllib.request

OUT = Path(__file__).resolve().parent
BASE = 'https://api.github.com/repos/ZhiQiYang/geometry-axiom'
RUN = 41453943080
HEAD = 'abbf1465e4617110f16892ba3925b20615345177'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        redirected = super().redirect_request(request, response, code, message, headers, new_url)
        if urllib.parse.urlparse(request.full_url).hostname != urllib.parse.urlparse(new_url).hostname:
            redirected.remove_header('Authorization')
        return redirected


def fetch(url, destination):
    started = utc()
    headers = {'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'geometry-pr340-main359-evidence-readonly'}
    if os.environ.get('GH_TOKEN'):
        headers['Authorization'] = 'Bearer ' + os.environ['GH_TOKEN']
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.build_opener(SafeRedirect()).open(request, timeout=120) as response:
        data = response.read()
        status = response.status
        content_type = response.headers.get('Content-Type')
        next_link = response.headers.get('Link')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    return {'url': url, 'file': str(destination), 'startedUTC': started, 'endedUTC': utc(), 'http_status': status, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'content_type': content_type, 'link_header': next_link}


def main():
    started = utc()
    results = []
    errors = []
    metadata = [(BASE + f'/actions/runs/{RUN}' + suffix, OUT / name) for suffix, name in [('', 'run.json'), ('/jobs?filter=all&per_page=100', 'jobs-all.json'), ('/artifacts?per_page=100', 'artifacts.json')]]
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for result in pool.map(lambda task: fetch(*task), metadata):
                results.append(result)
        run = json.loads((OUT / 'run.json').read_text())
        jobs = json.loads((OUT / 'jobs-all.json').read_text())['jobs']
        artifacts = json.loads((OUT / 'artifacts.json').read_text())['artifacts']
        assert run['id'] == RUN and run['head_sha'] == HEAD
        assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['run_attempt'] == 1
        assert len(jobs) == 10 and len({j['name'] for j in jobs}) == 10
        assert all(j['run_attempt'] == 1 and j['head_sha'] == HEAD and j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
        assert len(artifacts) == 12
        tasks = [(BASE + f"/actions/jobs/{j['id']}/logs", OUT / 'job-logs' / f"{j['id']}.log", None) for j in jobs]
        tasks += [(a['archive_download_url'], OUT / 'zips' / f"{a['id']}-{a['name']}.zip", a) for a in artifacts]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            pending = {pool.submit(fetch, url, path): (url, path, artifact) for url, path, artifact in tasks}
            for future in concurrent.futures.as_completed(pending):
                url, path, artifact = pending[future]
                try:
                    result = future.result()
                    if artifact:
                        result.update(artifactId=artifact['id'], apiDigest=artifact['digest'], digestVerified=artifact['digest'] == 'sha256:' + result['sha256'])
                        assert result['digestVerified'] and result['bytes'] == artifact['size_in_bytes']
                        assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
                    results.append(result)
                    print(path.name, result['bytes'], 'digest verified' if artifact else 'job log', flush=True)
                except Exception as error:
                    errors.append({'url': url, 'file': str(path), 'error_type': type(error).__name__, 'error': str(error)})
    except Exception as error:
        errors.append({'error_type': type(error).__name__, 'error': str(error)})
    receipt = {'startedUTC': started, 'endedUTC': utc(), 'command': [sys.executable, str(Path(__file__).resolve())], 'exit': int(bool(errors)), 'run': RUN, 'head': HEAD, 'requestCount': len(results), 'requests': results, 'errors': errors, 'onlyGET': True, 'noDispatchOrRerun': True}
    (OUT / 'ACQUISITION.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'exit': receipt['exit'], 'requests': len(results), 'errors': errors}, ensure_ascii=False), flush=True)
    raise SystemExit(receipt['exit'])


if __name__ == '__main__':
    main()
