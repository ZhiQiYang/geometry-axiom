"""Actual disposable K1 JS source mutations. Never edit the working checkout."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['test_cutting_plan.js', 'test_cutting_project_store.js', 'test_cutting_session.js', 'test_cutting_owner.js']
POLICY = '../geometry-templates/woodworking/cutting.js'
# Each case must fail with an assertion or an explicit conservation/identity
# validator diagnosis, never an import, syntax or environment error.
CASES = [
 ('between-kerf',POLICY,'s.pieces.at(-1).end+settings.kerf','s.pieces.at(-1).end','T1'),
 ('original-end',POLICY,"kind:s.tailTrim?'trim':'none'","kind:'trim'",'T2'),
 ('short-last-kerf',POLICY,'Math.min(settings.kerf,s.length-y)','settings.kerf','T2'),
 ('omit-last-cut',POLICY,"{kind:'separate',consumed:Math.min(settings.kerf,s.length-y),cuts:1}","{kind:'separate',consumed:0,cuts:0}",'T2'),
 ('leftover-threshold',POLICY,'usable>=settings.minRemnant','length>=settings.minRemnant','T4'),
 ('negative-usable',POLICY,'Math.max(0,length-s.tailTrim)','length-s.tailTrim','T4'),
 ('remnant-order',POLICY,'(a.length-a.headTrim-a.tailTrim)-(b.length-b.headTrim-b.tailTrim)','(b.length-b.headTrim-b.tailTrim)-(a.length-a.headTrim-a.tailTrim)','T5'),
 ('dimension-dedupe','cutting-plan.js','rows.set(row.id,row)','rows.set(row.L,row)','T6'),
 ('world-kind','cutting-plan.js',"request.world?.kind!=='live'",'false','T7'),
 ('scope-capacity','cutting-plan.js','request.scopes.length>64','false','T7'),
 ('demand-capacity','cutting-plan.js','rows.size>4096','false','T7'),
 ('stale-selection','cutting-plan.js','placements.get(id)?.geometry?.surface!==scope.surface','false','T7'),
 ('empty-scope','cutting-plan.js','if(!snapshot.rows.length)diagnose','if(false)diagnose','T7'),
 ('unordered-section',POLICY,"[...s].sort((a,b)=>a-b).join('x')","s.join('x')",'T8'),
 ('material-fingerprint',POLICY,'[m.id,m.version,m.fingerprint]','[m.id,m.version]','T26'),
 ('null-terminal',POLICY,"diagnose('INCOMPLETE','MATERIAL_UNRESOLVED'","diagnose('INCOMPLETE','MATERIAL_MIXED'",'T10'),
 ('missing-terminal',POLICY,"diagnose('UNSUPPORTED','NATIVE_CAPABILITY'","diagnose('INCOMPLETE','MATERIAL_UNRESOLVED'",'T10'),
 ('mixed-terminal',POLICY,"diagnose('INCOMPLETE','MATERIAL_MIXED'","diagnose('INCOMPLETE','NO_STOCK'",'T10'),
 ('allowance',POLICY,'row.L+(settings.allowance??0)','row.L','T4'),
 ('tie-break',POLICY,'b.C-a.C||a.timberId-b.timberId','b.C-a.C||b.timberId-a.timberId','T1'),
 ('canonical-stocks','cutting-settings.js','n.stockTypes.sort((a,b)=>a.key-b.key);','', 'R1.1 R5'),
 ('canonical-remnants','cutting-settings.js','n.remnants.sort((a,b)=>a.key-b.key);','', 'R1.1 R5'),
 ('missing-setting',POLICY,"filter(([,value])=>value===null)","filter(()=>false)",'T19'),
 ('phase-order',POLICY,'overlength.push({timberId:row.id,C,maximum})',"diagnose('INVALID','OVER_LENGTH',{timberId:row.id,C,maximum})",'R47 material'),
 ('overlength-remnants',POLICY,'...settings.remnants.filter(r=>r.stockType===stock.key).map(r=>r.length-r.headTrim-r.tailTrim)','0','T23'),
 ('exhaustion-code',POLICY,"diagnose('INCOMPLETE','REMNANT_EXHAUSTED'","diagnose('INVALID','OVER_LENGTH'",'T23'),
 ('exhaustion-all-groups',POLICY,'if(failed)continue;','if(failed)break;','R1.1'),
 ('conservation',POLICY,'function verify(plan,expectedIds=null){','function verify(plan,expectedIds=null){return true;','conservation detects'),
 ('typed-error','timber-schedule.js',"failure('NOT_EVALUATED'","failure('REFERENCES_UNVERIFIED'",'typed derive'),
 ('legacy-csv','timber-schedule.js',"JSON.stringify(r.sources,(key,value)=>key==='terminal'?undefined:value)",'JSON.stringify(r.sources)','F4a'),
 ('owned-terminal','timber-schedule.js',"Object.hasOwn(effective[field],'terminal')",'false','F4a'),
 ('integer-range',POLICY,'&&n<=100000000','','T12 strict'),
 ('stock-lock',POLICY,'if(n&&old.remnants.some','if(false&&old.remnants.some','T12b'),
 ('key-reuse','cutting-settings.js','row.key<old[counter]','false','key allocation'),
 ('stock-capacity',POLICY,'stockTypes.length>32','false','T18 settings'),
 ('undo-highwater','project-store.js','cutting=Features.Cutting.preserveHighwater(cutting,highwater)','cutting=cutting||Features.Cutting.empty()','P-047'),
 ('new-capability','project-store.js','capability!==CUTTING_CAPABILITY||cutting','capability!==CUTTING_CAPABILITY','T17 archive'),
 ('old-format','project-store.js','![GRID_DRAFTS_FORMAT,CARD_FORMAT].includes(manifest.format)','false','T17b'),
 ('export-state','cutting-workspace.js','function guard(before){','function guard(before){return;','T16'),
 ('export-world','cutting-workspace.js','latest.sourceFingerprint!==candidate.worldFingerprint','false','T16 world'),
 ('export-reentry','cutting-workspace.js','if(exporting)return false;','if(false)return false;','T16 late'),
 ('context-clear','cutting-workspace.js','identity=context;scopes=[];','identity=context;','session scopes'),
 ('stock-diagnostic','cutting-workspace.js','if(Array.isArray(d.detail?.section))','if(false)', 'T8b diagnostics'),
 ('owner-stock-lock','reference-workspace.js','if(kind===P.Features.Cutting.KIND)P.Features.Cutting.transition(previous,value);','', 'actual owner rejects'),
 ('owner-history-kind','reference-workspace.js','kind === P.Features.Cutting.KIND ? "裁切設定" :','', 'actual owner P-047'),
]

def classify_failure(code, log, pattern):
 failures=re.findall(r'^not ok \d+ - (.+)$',log,re.M)
 cause='assertion' if 'AssertionError' in log else 'invariant' if 'CONSERVATION' in log or 'DEMAND_IDENTITY' in log else None
 blocked=any(word in log for word in ('SyntaxError','MODULE_NOT_FOUND','ReferenceError','TypeError','uncaughtException','unhandledRejection'))
 named=any(re.search(pattern,name) for name in failures)
 return cause if code==1 and cause and named and not blocked else None

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();args.out.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='geometry-k1-js-') as directory:
  work=Path(directory);(work/'geometry-web').mkdir();(work/'tests').mkdir()
  for path in (ROOT/'geometry-web').glob('*.js'):shutil.copy2(path,work/'geometry-web'/path.name)
  # Follow the real host -> fixed W -> K JavaScript dependency closure. Keep
  # mutations relative to geometry-web so the existing anchor self-test remains
  # a check of the exact owner file, including paths moved out of the host.
  for source_root in ['geometry-core','geometry-app','geometry-templates']:
   for path in (ROOT/source_root).rglob('*.js'):
    target=work/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
  target=work/'geometry-web/vendor/fflate/umd';target.mkdir(parents=True);shutil.copy2(ROOT/'geometry-web/vendor/fflate/umd/index.js',target/'index.js')
  for name in FILES:shutil.copy2(ROOT/'tests'/name,work/'tests'/name)
  def run(pattern=None):
   command=['node','--test','--test-reporter=tap']
   if pattern:command+=['--test-name-pattern',pattern]
   return subprocess.run(command+[str(work/'tests'/f) for f in FILES],capture_output=True,text=True,encoding='utf-8',timeout=60)
  baseline=run();(args.out.parent/'frontend-baseline.log').write_text(baseline.stdout+baseline.stderr,encoding='utf-8')
  if baseline.returncode:print('baseline failed');return 2
  rows=[]
  for name,file,old,new,pattern in CASES:
   path=work/'geometry-web'/file;original=path.read_text(encoding='utf-8');assert original.count(old)==1,(name,'mutation anchor missing or nonunique')
   path.write_text(original.replace(old,new,1),encoding='utf-8')
   try:result=run(pattern)
   finally:path.write_text(original,encoding='utf-8')
   log=result.stdout+result.stderr;(args.out.parent/(name+'.log')).write_text(log,encoding='utf-8')
   cause=classify_failure(result.returncode,log,pattern)
   killed=cause is not None
   rows.append({'id':name,'status':'killed' if killed else 'not-killed','detectedBy':cause,'testPattern':pattern,'exitCode':result.returncode,'sourceHash':hashlib.sha256(original.encode()).hexdigest(),'mutationHash':hashlib.sha256((old+'\0'+new).encode()).hexdigest()})
   print(name+': '+rows[-1]['status'],flush=True)
  report={'schema':'k1-frontend-mutations/1','sources':{p.relative_to(work).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['geometry-web','geometry-core','geometry-app','geometry-templates'] for p in sorted((work/directory).rglob('*.js'))},'tests':{f:hashlib.sha256((ROOT/'tests'/f).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for f in FILES},'baseline':'passed','results':rows}
  args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  return 0 if all(r['status']=='killed' for r in rows) else 1

if __name__=='__main__':raise SystemExit(main())
