from pathlib import Path
import ast
import re

OUT=Path(__file__).resolve().parent
old=Path('/tmp/geometry-resume-20261102/ci-documents-checkout-final-ci/audit_originals.py').read_text()
text=re.sub(r'\bU\b','M',old)
text=text.replace('sourceU','sourceM').replace('sameTreeUAndExecution','sameTreeMAndExecution').replace('exactActualAndUBytes','exactActualAndMBytes')
text=text.replace("M = 'b2432c9ea79a6927675883ddde04f629b159be2d'", "M = 'abbf1465e4617110f16892ba3925b20615345177'")
text=text.replace("EXECUTION = '310bebb505ea04309634279b7025c1849a35d88d'", "EXECUTION = '8ba69d740da47031fe1a84b23b83340dca912d8c'")
text=text.replace("BASE = 'e02057b4c725d6f03ae52c3bc30776bf9442b0cf'", "BASE = 'fca3f1a80f1dab564f5dd4c01c9e1226eaf09e2d'")
text=text.replace('RUN = 41447885087','RUN = 41453943080')
text=text.replace("run['pull_requests'][0]['number'] == 368", "run['pull_requests'][0]['number'] == 340")
text=text.replace('saved PR base is original e020','saved PR base is precise main359 fca3')
text=text.replace('37255a53c002dd39960ff85b0d2404c710912faa','48b4ec466454ead214e44a4984f4bd0c83d87238')
before="    check('source', 'only workflow differs from original base', (OUT / 'source-M-vs-base.names').read_text() == 'M\\t.github/workflows/integration-tests.yml\\n')"
assert text.count(before)==1
after="""    diff_names = [line.split('\\t',1)[1] for line in (OUT/'source-M-vs-base.names').read_text().splitlines()]
    permitted_derived = {'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md','geometry-core/domain-decoupling/product-architecture-receipt.json'}
    check('source', 'M differs from precise current main only in 17 historical evidence plus two derived files', len(diff_names)==19 and {p for p in diff_names if not p.startswith('evidence/')}==permitted_derived and sum(p.startswith('evidence/') for p in diff_names)==17)
    check('source', 'original integration workflow unchanged from main359', (OUT/'source-M-vs-base.diff').read_bytes()==b'')"""
text=text.replace(before,after)
text=text.replace("check('native', 'static registry exact 237', len(universe) == len(set(universe)) == 237 and set(universe) == set(expected))", "check('native', 'static registry exactly matches original expected without assumed count', len(universe) == len(set(universe)) and set(universe) == set(expected))")
text=text.replace("check('native', 'union 237 exactly once', len(rows) == 237 and Counter(row['name'] for row in rows) == Counter(universe))", "check('native', 'union original registry exactly once', len(rows) == len(universe) and Counter(row['name'] for row in rows) == Counter(universe))")
text=text.replace("gdi = json.loads(contents['native-logs-1']['py_test_gdi_contract.json'])", "gdi_candidates = [body['py_test_gdi_contract.json'] for name,body in contents.items() if name.startswith('native-logs-') and 'py_test_gdi_contract.json' in body]\n    check('native','exactly one original GDI raw',len(gdi_candidates)==1)\n    gdi = json.loads(gdi_candidates[0])")
text=text.replace("check('native', '5421/5420/1', (summary['counted_tests'], summary['counted_passed'], summary['allowed_skips']) == (5421, 5420, 1))", "check('native', 'observed strict counts conserved and one allowed skip', summary['counted_tests']==summary['counted_passed']+summary['allowed_skips'] and summary['allowed_skips']==1)")
text=text.replace("'original 2286 /86 golden /full scope', output['passedAssertions'] == 2286 and len(output['sections']) == 86", "'actual full original golden/count/scope', output['passedAssertions'] == golden['total'] and len(output['sections']) == len(golden['sections'])")
text=text.replace("and golden['total'] == 2286", "and golden['total'] == sum(golden['sections'].values())")
old_doc="""                special = steps['Checkout document job primary sources']
                check('documents', 'old generic step skipped /new checkout success', len(standard) == 1 and standard[0]['conclusion'] == 'skipped' and special['conclusion'] == 'success')
                check('documents', 'actual sparse filter settings in raw log', 'filter: blob:none' in text and 'sparse-checkout-cone-mode: false' in text and '!/evidence/' in text and 'persist-credentials: false' in text)
                record['raw_PASS_lines'] = pass_lines
                record['generic_checkout'] = standard
                record['new_checkout'] = special"""
new_doc="""                check('documents', 'original generic checkout actually successful', len(standard)==1 and standard[0]['conclusion']=='success' and 'Checkout document job primary sources' not in steps)
                record['raw_PASS_lines'] = pass_lines
                record['generic_checkout'] = standard"""
assert text.count(old_doc)==1;text=text.replace(old_doc,new_doc)
start=text.index("    old_job = read_json(OUT / 'reference-old-documents/JOB.json')")
end=text.index('    failures = [c for c in checks if not c[\'passed\']]',start)
text=text[:start]+text[end:]
text=text.replace('geometry-pr368-final-ci-originals/1','geometry-pr340-main359-final-ci-originals/1')
start=text.index("    (OUT / 'README.md').write_text(")
end=text.index('    raise SystemExit(int(bool(failures)))',start)
text=text[:start]+"    print(json.dumps({'checks':len(checks),'failures':failures,'ZIPs':12,'members':final['actualMemberCount'],'finalSha256':sha((OUT/'FINAL_ACCEPTANCE.json').read_bytes())},ensure_ascii=False))\n"+text[end:]
text=text.replace("'只回收既存run41447885087終態；未dispatch／rerun。'", "'只回收既存run41453943080終態；未dispatch／rerun。'")
text=text.replace("'十個GHA執行均屬U／actual310b／base e020；不能移標至後來fca3或其他新main。'", "'十個GHA執行只屬M abbf／actual8ba69／base fca3；不可移標至最後採入衍生檔的新F或其他SHA。'")
text=text.replace("'十個GHA執行均屬M／actual310b／base e020；不能移標至後來fca3或其他新main。'", "'十個GHA執行只屬M abbf／actual8ba69／base fca3；不可移標至最後採入衍生檔的新F或其他SHA。'")
text=text.replace("'canvas2286是原assertion數，非端到端情境數；P38單次例外是原預期探針。'", "'canvas數字是原assertion數，非端到端情境數；P38單次例外是原預期探針。'")
text=text.replace("'source-actual只物化聚合裁判需要的331個固定blob；其.git指標不列入可發布內容。'", "'source-actual只物化固定原純聚合所需／registry inventory blobs；其.git指標不列入可發布內容。'")
text=text.replace(", '舊PR345 cancelled documents僅作問題來源，未混作本次成功執行。'", '')
ast.parse(text)
(OUT/'audit_originals.py').write_text(text)
print('ADAPTED_AUDIT_READY: fixed M, actual source registry/golden; no product/ELF execution')
