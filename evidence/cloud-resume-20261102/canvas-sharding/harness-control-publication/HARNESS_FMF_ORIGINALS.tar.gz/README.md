Local original legacy harness F/M/F evidence

D: e5b0bc23b04e872a68b066bd5b51d57e2c104943
M: aec3ea1bdcf46f2416dfa7cb79d28221673c315a (local only; parent D; only false && before S2 predicate)

The completed original controls are fixed-before-03 / mutant-02 / fixed-restored-02, with actual original CLI exits 0 / 1 / 0 and 2100-second bounds each. F/R report 898 passed, zero failed/skipped, all 62 original golden projection sections matched. M retains its actual 897 passed / 2 failed / zero skipped result: one true journal false at S2 plus the original strict count floor consequence. Its original Python supervisor rejects CANVAS_PROCESS_FAILED: 1. The separate unchanged original Node verifier rejects the same actual M journal with CANVAS_ASSERTION_FAILED: S2 結構:.

Every phase retained 737 source input identities and all three fresh copied native executable/sidecar identities before/after. P38 original expected fb-auto-probe exception remains 1. LOCAL run_id 0 / attempt 1 is never represented as GitHub Actions. This is local legacy control evidence, not another full product or two-shard GHA pass.

Earlier environment failures remain separate: first-fixed-enospc-originals, fixed-before-02 socket startup failure, failed smoke/client-close and bind-preflight attempts. None is rewritten as a pass or used as the intended negative control. All three owned phase services have been stopped; no live owned Chrome/CDP/server/native process remains. D remains clean and unchanged; M was not pushed.

The small archive includes every raw command stream, receipt, plan, journal, phase metadata, source identity snapshot and original verifier request/result under this prefix. Operational tmp directories (native copies, browser profiles and temporary runtime working state) remain untouched at their original SHM paths and are excluded from the transport archive; executable/sidecar identities and paths are recorded. All standard canvas_evidence.py receipt FILES are included.
