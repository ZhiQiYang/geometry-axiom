"""Private #341 input seal and thin adapter around the original run_logged.
No product, build or performance execution is exposed by this CLI.
"""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import os
import platform
import resource
import subprocess
import sys

OUT=Path(__file__).resolve().parent
V1=OUT.parent/'private-cost-preparation'
ROOT=Path('/tmp/geometry-pr340-20261102')
FIXED='edf556eedc204bb285fb4504e246e4310f4e1e88'
MANIFEST=OUT/'SEAL.json'
SHA=lambda data:hashlib.sha256(data).hexdigest()
SYNTHETIC=[('normal','printf normal-out; printf normal-err >&2; exit 0',b'normal-out',b'normal-err',False),('timeout','printf timeout-out; printf timeout-err >&2; exec /bin/sleep 0.08',b'timeout-out',b'timeout-err',True),('restored','printf restored-out; printf restored-err >&2; exit 0',b'restored-out',b'restored-err',False)]

def require(condition,message):
    if not condition:raise ValueError(message)

def write_new(path,data):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')

def identity(path):
    path=Path(path)
    return {'path':str(path),'resolved':str(path.resolve()),'bytes':path.stat().st_size,'sha256':SHA(path.read_bytes())}

def seal():
    require(not MANIFEST.exists(),'SEAL_ALREADY_EXISTS')
    result=json.loads((V1/'POSITIVE_RESULT.json').read_text())
    require(result['status']=='PASS_MINIMAL_FUNCTIONAL_ONLY_NOT_B1','V1_NOT_FUNCTIONAL_PASS')
    files=set(p for p in V1.rglob('*') if p.is_file())
    files.update(Path(entry['path']) for entry in result['importedRepoModules'])
    files.update([ROOT/'tests/test_geo261_wood_contact_world.py',ROOT/'tests/test_geo261_wood_contacts.py',ROOT/'tests/assembly_mutation_check.py',Path(__file__),OUT/'README.md',OUT/'FIXTURES.json'])
    compiler=Path(json.loads((V1/'build/build-log.json').read_text())[0]['arguments'][0])
    files.update([compiler,Path(sys.executable),Path('/bin/sh'),Path('/bin/sleep'),Path('/lib/x86_64-linux-gnu/libc.so.6'),Path('/lib/x86_64-linux-gnu/libm.so.6'),Path('/lib64/ld-linux-x86-64.so.2')])
    (OUT/'runtime').mkdir(exist_ok=True)
    (OUT/'future-build').mkdir(exist_ok=True)
    env={'PATH':os.defpath,'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','TMPDIR':str(OUT/'runtime'),'PYTHONDONTWRITEBYTECODE':'1','CC':str(compiler)}
    steps=json.loads((V1/'build/build-log.json').read_text())
    document={'schema':'geometry-pr341-private-readiness-seal/2','utc':datetime.now(timezone.utc).isoformat(),'fixedSource':FIXED,'v1ResultSha256':SHA((V1/'RESULT.json').read_bytes()),'status':'SEALED_PRE_SAMPLE_ALL_COST_UNRUN','inputs':[identity(p) for p in sorted(files)],'exactPriorBuildCommands':[entry['arguments'] for entry in steps],'futureRuntimeEnvironment':env,'futureCwd':str(OUT),'futureBuildCwd':str(OUT/'future-build'),'limits':{'stackBytes':16777216,'nativeSubjectSeconds':20,'originalBuildSeconds':300,'syntheticTimeoutSeconds':0.04},'fixtures':json.loads((OUT/'FIXTURES.json').read_text()),'platform':{'system':platform.system(),'machine':platform.machine(),'kernel':platform.release(),'python':sys.version},'actualGeometryOrCostRunsInV2':0,'meaning':'Seal of existing F340 private source/build/binary and exact future wrapper inputs. It predates only v2 synthetic or future execution; it does not retroactively pre-seal v1 executions or authorize formal B1.'}
    document['allowedSubjectArgv']=[entry['argv'] for entry in result['runs']]
    document['allowedSyntheticArgv']=[['/bin/sh','-c',entry[1]] for entry in SYNTHETIC]
    document['allowedFutureBuildArgv']=[[arg.replace(str(V1/'build'),str(OUT/'future-build')) for arg in entry['arguments']] for entry in steps]
    git_env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
    head=subprocess.run(['git','-C',str(ROOT),'rev-parse','HEAD'],env=git_env,capture_output=True)
    status=subprocess.run(['git','-C',str(ROOT),'status','--porcelain=v1','--untracked-files=all'],env=git_env,capture_output=True)
    require(head.returncode==0 and status.returncode==0 and head.stdout.decode().strip()==FIXED and not status.stdout,'SOURCE_HEAD_OR_STATUS_CHANGED')
    document['sourceGitRead']={'head':head.stdout.decode().strip(),'headExit':head.returncode,'statusExit':status.returncode,'clean':not status.stdout,'lazyFetchDisabled':True}
    write_new(MANIFEST,document)
    digest=SHA(MANIFEST.read_bytes())
    (OUT/'SEAL.sha256').write_text(digest+'  SEAL.json\n')
    print(digest)

def verify(expected):
    require(len(expected)==64 and SHA(MANIFEST.read_bytes())==expected,'SEAL_DIGEST_MISMATCH')
    document=json.loads(MANIFEST.read_text())
    for entry in document['inputs']:
        require(identity(entry['path'])==entry,'INPUT_CHANGED: '+entry['path'])
    return document

def capture_logged(argv,directory,expected,*,kind='subject',synthetic=False):
    """All inputs checked before Popen; original raw/execution.json untouched."""
    document=verify(expected)
    allowed=document['allowedSyntheticArgv'] if synthetic else document[{'subject':'allowedSubjectArgv','build':'allowedFutureBuildArgv'}[kind]]
    require(list(argv) in allowed,'ARGV_NOT_SEALED')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    timeout=0.04 if synthetic else document['limits'][{'subject':'nativeSubjectSeconds','build':'originalBuildSeconds'}[kind]]
    cwd=document['futureBuildCwd'] if kind=='build' else document['futureCwd']
    env=document['futureRuntimeEnvironment'].copy()
    write_new(directory/'REQUEST.json',{'utc':datetime.now(timezone.utc).isoformat(),'sealSha256':expected,'allInputChecksCompletedBeforePopen':True,'argv':list(argv),'cwd':cwd,'environment':env,'timeoutSeconds':timeout,'stackBytes':16777216,'kind':kind,'syntheticOnly':synthetic})
    spec=importlib.util.spec_from_file_location('_geo341_original_logged',ROOT/'tests/assembly_mutation_check.py')
    tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
    original_namespace=tool.subprocess
    popen=original_namespace.Popen
    observed=[]
    def observe(*args,**kwargs):
        process=popen(*args,**kwargs);observed.append(process);return process
    tool.subprocess=SimpleNamespace(Popen=observe,TimeoutExpired=original_namespace.TimeoutExpired)
    old_limits=resource.getrlimit(resource.RLIMIT_STACK)
    try:
        resource.setrlimit(resource.RLIMIT_STACK,(16777216,old_limits[1]))
        code,timed_out,group=tool.run_logged(list(argv),directory,Path(cwd),env,timeout)
    finally:
        tool.subprocess=original_namespace
        resource.setrlimit(resource.RLIMIT_STACK,old_limits)
    actual=observed[0].returncode if len(observed)==1 else None
    after_error=None
    try:verify(expected)
    except BaseException as error:after_error=str(error)
    outcome={'originalSupervisorExit':code,'timedOut':timed_out,'observedPopenCount':len(observed),'actualProcessReturncode':actual,'processGroup':group,'sealSha256':expected,'inputChecksAfter':after_error is None,'inputCheckError':after_error,'syntheticOnly':synthetic,'completedNormally':not timed_out and actual==0 and code==0 and after_error is None and len(observed)==1,'notAPerformanceSample':True,'streams':{name:identity(directory/name) for name in ['stdout','stderr']},'originalExecutionJson':identity(directory/'execution.json'),'meaning':'Timeout keeps original exit=None and timedOut=true; observed negative signal returncode is separate, never promoted to normal success.'}
    write_new(directory/'OUTCOME.json',outcome)
    return outcome

def logged_native_build(build,args,directory,expected):
    """Optional external run_build hook; original compile/link flag logic stays.
    Not executed in v2. Caller gives one new directory per original command.
    """
    document=verify(expected)
    require(str(build.work)==document['futureBuildCwd'],'BUILD_CWD_NOT_SEALED')
    outcome=capture_logged(args,directory,expected,kind='build')
    entry={'command':list(args),'arguments':list(args),'exit':outcome['actualProcessReturncode'],'stdout':(Path(directory)/'stdout').read_text(errors='replace'),'stderr':(Path(directory)/'stderr').read_text(errors='replace'),'timedOut':outcome['timedOut'],'rawDirectory':str(directory)}
    build.logs.append(entry)
    (build.work/'build-log.json').write_text(json.dumps(build.logs,indent=2)+'\n')
    if not outcome['completedNormally']:
        raise AssertionError('Native compile/link failed; preserved raw, not a valid negative control: '+str(directory))

def synthetic(expected):
    verify(expected)
    result=[]
    for name,program,stdout,stderr,timeout in SYNTHETIC:
        directory=OUT/'synthetic'/name
        # All three use only tiny synthetic children and <=40ms deadlines.
        outcome=capture_logged(['/bin/sh','-c',program],directory,expected,synthetic=True)
        passed=(directory/'stdout').read_bytes()==stdout and (directory/'stderr').read_bytes()==stderr and outcome['inputChecksAfter'] and outcome['observedPopenCount']==1
        if timeout:
            passed=passed and outcome['timedOut'] and outcome['originalSupervisorExit'] is None and outcome['actualProcessReturncode']==-9 and outcome['processGroup']['checked'] and outcome['processGroup']['afterKill']==[]
        else:passed=passed and not outcome['timedOut'] and outcome['actualProcessReturncode']==0 and outcome['originalSupervisorExit']==0
        result.append({'case':name,'pass':bool(passed),'outcome':outcome})
        write_new(directory/'CHECK.json',{'pass':bool(passed),'rawMarkersExact':(directory/'stdout').read_bytes()==stdout and (directory/'stderr').read_bytes()==stderr})
    write_new(OUT/'SYNTHETIC_RESULT.json',{'status':'PASS_ENVELOPE_ONLY' if all(row['pass'] for row in result) else 'FAIL_KEEP_ALL_RAW_NO_RETRY','sealSha256':expected,'cases':result,'geometryExecutions':0,'performanceSamples':0,'builds':0,'restoredInputSealMatches':SHA(MANIFEST.read_bytes())==expected,'limitations':['Only direct tiny shell/sleep children tested; no descendant-tree cleanup attestation beyond original observed group record.','No geometry timeout/build-timeout execution. The optional build hook is statically prepared only.','Only already-written raw bytes are retained; unflushed child userspace buffers cannot be recovered.']})
    require(all(row['pass'] for row in result),'SYNTHETIC_REJECTED_SEE_PRESERVED_RAW')
    print('PASS_ENVELOPE_ONLY: observed0/timeout(-9)/0; no product or cost runs')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['seal','check','synthetic']);parser.add_argument('--expected');args=parser.parse_args()
    if args.action=='seal':seal()
    else:
        require(args.expected,'Expected seal SHA must be supplied from the approved external receipt, not inferred from a mutable sidecar.')
        if args.action=='check':verify(args.expected);print('PASS_SEAL_INPUTS')
        else:synthetic(args.expected)
