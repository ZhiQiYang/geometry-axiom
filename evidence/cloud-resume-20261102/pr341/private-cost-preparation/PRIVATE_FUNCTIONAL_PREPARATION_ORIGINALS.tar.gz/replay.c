/* Private semantic replay, no timers or cost sampling. Original helpers and
 * assertions stay byte-identical in the included fixture. */
#define main geo341_original_main
#include "original-contact-world-client.c"
#undef main
#include <inttypes.h>

static int replay(const char *label)
{
    enum { N=WOOD_CONTACT_MEMBER_CAPACITY, MANY=WOOD_CONTACT_FACE_CAPACITY/2+1 };
    static WoodMember members[N];
    static WoodContactMemberFact facts[MANY];
    static WoodStopFace out[MANY*2+1];
    WoodMember shared=member(42,WOOD_MEMBER_ROLE_PRIMARY,2);
    size_t facts_n=N,cap=WOOD_CONTACT_FACE_CAPACITY,admitted=N*2,expected=N*2;
    bool dense=!strcmp(label,"D"),overflow=!strcmp(label,"X"),sparse=!strcmp(label,"S");
    CHECK("private-known-recipe",dense||overflow||sparse||!strcmp(label,"U"));
    if(dense||overflow){
        if(overflow){facts_n=MANY;cap=MANY*2;admitted=MANY*2;}
        for(size_t i=0;i<facts_n;++i)facts[i]=fact(&shared,(uint64_t)i,false,(GeoRect2){0,0,100,27});
        expected=2;
    }else{
        for(size_t i=0;i<N;++i){
            members[i]=member((uint32_t)(100+i),WOOD_MEMBER_ROLE_PRIMARY,2);
            facts[i]=fact(&members[i],N-i,false,(GeoRect2){10000+(GeoCoord)i*10,200,10002+(GeoCoord)i*10,210});
        }
        if(sparse){facts[1].footprint=facts[0].footprint;expected-=2;}
    }
    WoodContactWorld world={.placement_id=7,.members=facts,.member_count=facts_n};
    memset(out,0x5a,sizeof out);WoodStopFace tail=out[admitted];
    size_t n=wood_contact_collect_stops(&world,false,NULL,out,cap);
    CHECK("private-literal-count",n==expected);
    CHECK("private-uncollected-tail",!memcmp(&out[admitted],&tail,sizeof tail));
    if(dense||overflow){
        CHECK("private-original-final-pair",face(&out[0],WOOD_STOP_MEMBER_SIDE,0,42,-1,0,WOOD_STOP_FIXED,0,0,27)&&face(&out[1],WOOD_STOP_MEMBER_SIDE,0,42,-1,1,WOOD_STOP_FIXED,100,0,27));
    }else{
        size_t at=0;
        for(size_t i=N;i-->0;){
            if(sparse&&i==0)continue;
            const GeoRect2 *f=&facts[i].footprint;
            for(int side=0;side<2;++side){
                CHECK("private-independent-complete-order",face(&out[at],WOOD_STOP_MEMBER_SIDE,0,(uint32_t)(100+i),-1,side,WOOD_STOP_FIXED,side?f->max_u:f->min_u,f->min_v,f->max_v));
                ++at;
            }
        }
        CHECK("private-independent-output-length",at==n);
    }
    printf("recipe=%s count=%zu tail=unchanged\n",label,n);
    for(size_t i=0;i<n;++i){const WoodStopFace *f=&out[i];
        printf("%d,%" PRIu32 ",%" PRIu32 ",%d,%d,%d,%" PRId64 ",%" PRId64 ",%" PRId64 "\n",f->kind,f->boundary_id,f->timber_id,f->hole_index,f->edge_index,f->fixity,(int64_t)f->fixed,(int64_t)f->lo,(int64_t)f->hi);
    }
    return 0;
}
int main(int argc,char **argv)
{if(argc!=2)return 2;return replay(argv[1]);}
