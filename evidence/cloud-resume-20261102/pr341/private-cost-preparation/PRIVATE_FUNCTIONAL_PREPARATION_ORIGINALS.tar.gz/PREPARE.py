"""One bounded private preparation using original NativeBuild methods.

No benchmark, product source edits, replacement assertions, or mutant runner.
"""
from pathlib import Path
import ast
import difflib
import hashlib
import importlib
import json
import os
import re
import resource
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT=Path('/tmp/geometry-pr340-20261102')
OUT=Path(__file__).resolve().parent
FIXED='edf556eedc204bb285fb4504e246e4310f4e1e88'
PRE='d1578d22f6d085ebd109ae1ce5a82b41c9d6a8a2'
REL='geometry-templates/woodworking/native/contact_world.c'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
SHA=lambda b:hashlib.sha256(b).hexdigest()

def git(*args):
    run=subprocess.run(['git','-C',str(ROOT),*args],env=ENV,capture_output=True)
    assert run.returncode==0,run.stderr.decode()
    return run.stdout

def write_json(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

def source_closure(seeds):
    pending=list(seeds);seen={}
    while pending:
        path=pending.pop().resolve()
        if path in seen:continue
        rel=path.relative_to(ROOT).as_posix();data=path.read_bytes()
        assert git('show',FIXED+':'+rel)==data,rel
        seen[path]=data
        for name in re.findall(r'^\s*#\s*include\s+"([^"]+)"',data.decode(),re.M):
            # The original NativeBuild relocates this client beside wood headers.
            choices=(path.parent/name,ROOT/name,ROOT/'geometry-core/kernel'/name,
                     ROOT/'geometry-templates/woodworking/native'/name)
            selected=next((x for x in choices if x.is_file()),None)
            assert selected is not None,(rel,name)
            pending.append(selected)
    return seen

def prepare():
    assert git('rev-parse','HEAD').decode().strip()==FIXED
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert not (OUT/'build').exists()
    current=git('show',FIXED+':'+REL);old=git('show',PRE+':'+REL)
    text=current.decode();historical=old.decode()
    start=text.index('    /* D11 placement order')
    end=text.index('\n}\nbool wood_contact_boundary_edge',start)
    old_start=historical.index('    /* D11 placement order')
    old_end=historical.index('\n}\nbool wood_contact_boundary_edge',old_start)
    joint=text[:start]+historical[old_start:old_end]+text[end:]
    # Retain343 indexed ownership of active/final compact. Only the other
    # branch uses original immediate deletion and returns its reduced count.
    before='    bool compact=count<=WOOD_CONTACT_FACE_CAPACITY;size_t remaining=count;\n'
    after='    size_t first=0;while(first<count&&out[first].kind!=WOOD_STOP_MEMBER_SIDE)++first;\n    bool compact=count<=WOOD_CONTACT_FACE_CAPACITY&&orders.indexed&&orders.unique&&first<count;size_t remaining=count;\n'
    assert text.count(before)==1
    fallback=text.replace(before,after)
    duplicate='    size_t first=0;while(first<count&&out[first].kind!=WOOD_STOP_MEMBER_SIDE)++first;\n'
    assert fallback.count(duplicate)==2
    at=fallback.index(duplicate,fallback.index(duplicate)+len(duplicate))
    fallback=fallback[:at]+fallback[at+len(duplicate):]
    assert fallback.count('if(compact&&orders.indexed&&orders.unique&&first<count)')==1
    variants={'C':text,'R_fallback':fallback,'R_joint':joint}
    for label,variant in variants.items():
        (OUT/(label+'.c')).write_bytes(variant.encode())
        if label!='C':
            patch=''.join(difflib.unified_diff(text.splitlines(True),variant.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL))
            (OUT/(label+'.diff')).write_text(patch)
    (OUT/'pre341-contact-world.c').write_bytes(old)
    sources=['geometry-templates/woodworking/native/contact_world.c','geometry-templates/woodworking/native/contacts.c','geometry-templates/woodworking/native/supports.c','geometry-core/kernel/geometry.c','geometry-core/kernel/exact.c','tests/geo261_contact_world_harness.c']
    closure=source_closure([ROOT/p for p in sources])
    manifest=[]
    for path,data in sorted(closure.items()):
        rel=path.relative_to(ROOT);target=OUT/'source'/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==data
        target.write_bytes(data)
        manifest.append({'path':rel.as_posix(),'bytes':len(data),'sha256':SHA(data)})
    judge=ROOT/'tests/test_geo261_wood_contact_world.py';judgedata=judge.read_bytes();tree=ast.parse(judgedata)
    stop_filter=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='STOP_FILTER' for t in n.targets))
    class ResolveFixtureConstant(ast.NodeTransformer):
        def visit_Name(self,node):
            assert node.id=='STOP_FILTER',node.id
            return ast.Constant(value=stop_filter)
        def visit_Call(self,node):
            self.generic_visit(node)
            assert isinstance(node.func,ast.Attribute) and node.func.attr=='replace'
            assert isinstance(node.func.value,ast.Constant) and not node.keywords
            assert all(isinstance(arg,ast.Constant) for arg in node.args)
            return ast.Constant(value=node.func.value.value.replace(*(arg.value for arg in node.args)))
    controls_node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
    controls=ast.literal_eval(ResolveFixtureConstant().visit(controls_node))
    methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    assert len(methods)==14 and len(controls)==41
    applicability=[]
    for control in controls:
        name,anchor,_,case,assertion=control
        applicability.append({'control':name,'case':case,'assertion':assertion,'anchors':{k:v.count(anchor) for k,v in variants.items()},'execution':'UNRUN'})
    write_json('PREPARATION.json',{'utc':datetime.now(timezone.utc).isoformat(),'fixedSource':FIXED,'pre341Source':PRE,'pre341FullSha256':SHA(old),'currentFullSha256':SHA(current),'replacementRanges':{'current':[225,270],'pre341':[84,107]},'currentBlockSha256':SHA(text[start:end].encode()),'pre341BlockSha256':SHA(historical[old_start:old_end].encode()),'variants':{k:{'sha256':SHA(v.encode()),'bytes':len(v.encode())} for k,v in variants.items()},'closure':manifest,'copiedClosureBytes':sum(len(v) for v in closure.values()),'judge':{'path':str(judge),'sha256':SHA(judgedata),'methods':methods,'methodCount':len(methods),'controlCount':len(controls),'changed':False,'executedWholeSuite':False},'controlApplicability':applicability,'costSamples':'UNRUN','branchesAndSourceChanged':False})
    print('PREPARED',len(closure),'files',sum(len(v) for v in closure.values()),'bytes')

def positive():
    assert git('rev-parse','HEAD').decode().strip()==FIXED
    assert not git('status','--porcelain=v1','--untracked-files=all')
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
    sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT))
    module=importlib.import_module('tests.test_geo261_native_kernel')
    build=module.NativeBuild.__new__(module.NativeBuild)
    build.work=OUT/'build';build.work.mkdir(exist_ok=False)
    build.kernel=OUT/'source/geometry-core/kernel'
    build.woodworking=OUT/'source/geometry-templates/woodworking/native'
    build.windows=False;build.suffix='';build.logs=[];build.cc=shutil.which(os.environ.get('CC','cc'))
    assert build.cc
    original=OUT/'source/tests/geo261_contact_world_harness.c'
    client=build.woodworking/'original-contact-world-client.c';shutil.copy2(original,client)
    replay=build.woodworking/'private-replay.c';shutil.copy2(OUT/'replay.c',replay)
    common=[build.compile(build.kernel/'exact.c','exact'),build.compile(build.kernel/'geometry.c','geometry'),build.compile(build.woodworking/'contacts.c','contacts'),build.compile(build.woodworking/'supports.c','supports')]
    client_obj=build.compile(client,'original-client');replay_obj=build.compile(replay,'replay-client')
    runs=[];outputs={};subjects=['ordering','regions','active-dedup','indexed-dedup','indexed-sort','intervals','extensions','ends']
    try:
        for label in ['C','R_fallback','R_joint']:
            subject=build.woodworking/(label+'.c');shutil.copy2(OUT/(label+'.c'),subject)
            obj=build.compile(subject,label)
            original_exe=build.link(label+'-original',[client_obj,obj,*common])
            replay_exe=build.link(label+'-replay',[replay_obj,obj,*common])
            for kind,exe,cases in [('original',original_exe,subjects),('replay',replay_exe,['U','S','D','X'])]:
                for case in cases:
                    argv=[str(exe),case]
                    run=subprocess.run(argv,capture_output=True,timeout=20,env=ENV)
                    prefix=label+'-'+kind+'-'+case
                    (OUT/(prefix+'.stdout')).write_bytes(run.stdout);(OUT/(prefix+'.stderr')).write_bytes(run.stderr)
                    entry={'variant':label,'kind':kind,'case':case,'argv':argv,'timeoutSeconds':20,'actualReturnCode':run.returncode,'stdoutSha256':SHA(run.stdout),'stderrSha256':SHA(run.stderr),'executableSha256':SHA(exe.read_bytes())}
                    runs.append(entry)
                    if kind=='replay':outputs[(label,case)]=run.stdout
                    write_json('POSITIVE_RESULT.json',{'status':'IN_PROGRESS','runs':runs})
        problems=[r for r in runs if r['actualReturnCode']!=0]
        equality={case:{label:outputs[(label,case)]==outputs[('C',case)] for label in ['R_fallback','R_joint']} for case in ['U','S','D','X']}
        assert not problems,problems
        assert all(all(pair.values()) for pair in equality.values()),equality
        repo_modules=[]
        for name,mod in sorted(sys.modules.items()):
            path=getattr(mod,'__file__',None)
            if path and Path(path).is_relative_to(ROOT):
                p=Path(path);repo_modules.append({'module':name,'path':str(p),'sha256':SHA(p.read_bytes())})
        assert git('rev-parse','HEAD').decode().strip()==FIXED and not git('status','--porcelain=v1','--untracked-files=all')
        used=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
        assert used<128*1024*1024,used
        write_json('POSITIVE_RESULT.json',{'status':'PASS_MINIMAL_FUNCTIONAL_ONLY_NOT_B1','fixedSource':FIXED,'runs':runs,'runCount':len(runs),'allOriginalAssertionsUnchanged':SHA(original.read_bytes())==SHA(client.read_bytes()),'replayCanonicalOutputsByteEqual':equality,'rlimitStack':resource.getrlimit(resource.RLIMIT_STACK),'originalBuildTool':{'path':module.__file__,'sha256':SHA(Path(module.__file__).read_bytes()),'constructorNotUsed':'Only selected necessary sources copied and original compile/link methods called; no full product/native suite or unneeded objects built.','methodArgsUnchanged':True,'buildTimeoutSeconds':300},'importedRepoModules':repo_modules,'buildLog':str(build.work/'build-log.json'),'sourceHeadAndStatusUnchanged':True,'outBytes':used,'costSamples':'UNRUN','full14Methods41Controls':'UNRUN; applicability is static only'})
        print('FUNCTIONAL_PASS',len(runs),'runs',used,'bytes; cost UNRUN')
    except BaseException as error:
        write_json('POSITIVE_RESULT.json',{'status':'INVALID_BASELINE_OR_SETUP_KEEP_RAW','runs':runs,'exceptionType':type(error).__name__,'error':str(error),'costSamples':'UNRUN','meaning':'A semantic or setup failure is preserved and is not a product failure or killed optimization.'})
        raise

if __name__=='__main__':
    {'prepare':prepare,'positive':positive}[sys.argv[1]]()
