#ifndef GEO341_PRIVATE_PILOT_WORK_H
#define GEO341_PRIVATE_PILOT_WORK_H
#include <stdint.h>
typedef struct {
    uint64_t collector_calls,admitted_faces,order_calls,earlier_calls;
    uint64_t plane_compare_calls,member_index_before_calls,indexed_calls;
    uint64_t bitmap_init_writes,active_clears,inactive_skips,pair_visits;
    uint64_t full_cover_checks,duplicate_removals,compaction_scans,compaction_moves;
    uint64_t memmove_calls,memmove_bytes,fenwick_insert_nodes,fenwick_query_nodes;
} Geo341PrivateWork;
extern Geo341PrivateWork geo341_work;
#endif
