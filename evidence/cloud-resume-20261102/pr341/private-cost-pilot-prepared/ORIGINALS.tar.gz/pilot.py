"""Exactly one reviewed private pilot. Preparation uses only the check action.
The run action remains uninvoked until root releases the exclusive window.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import time
from envelope import logged

OUT=Path(__file__).resolve().parent
SEAL=OUT/'PILOT_SEAL.json'
V2=OUT.parent/'private-cost-readiness-v2'
SHA=lambda data:hashlib.sha256(data).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def verify(expected):
    require(SHA(SEAL.read_bytes())==expected,'PILOT_SEAL_DIGEST_MISMATCH')
    document=json.loads(SEAL.read_text())
    for entry in document['inputs']:
        path=Path(entry['path'])
        require(str(path.resolve())==entry['resolved'] and path.stat().st_size==entry['bytes'] and SHA(path.read_bytes())==entry['sha256'],'INPUT_CHANGED: '+entry['path'])
    require(len(document['schedule'])==24,'SCHEDULE_CHANGED')
    return document
def write(path,data):
    with path.open('x') as stream:json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')
def parse(directory,row,fixtures):
    raw=(directory/'stderr').read_text();lines=[line[len('PILOT_METRICS\t'):] for line in raw.splitlines() if line.startswith('PILOT_METRICS\t')]
    require(len(lines)==1,'ONE_METRICS_RECORD_REQUIRED')
    data=json.loads(lines[0]);require(data['mode']==row['mode'] and data['probeCalls']==1 and data['stackSoftBytes']==16777216,'METRICS_MODE_CALL_OR_STACK_MISMATCH')
    require(data['returned']==fixtures[row['recipe']]['expectedReturned'],'ORIGINAL_REPLAY_COUNT_MISMATCH')
    if row['mode']=='work':
        work=data['work'];require(work['collector_calls']==1 and work['admitted_faces']==fixtures[row['recipe']]['admitted'],'WORK_ENTRY_OR_ADMISSION_MISMATCH')
        indexed=int(row['variant']!='R_joint' and row['recipe'] in ['U','S'])
        require(work['indexed_calls']==indexed,'WORK_ACTUAL_ROUTE_MISMATCH')
        require(work['duplicate_removals']==work['admitted_faces']-data['returned'],'WORK_REMOVAL_ACCOUNTING_MISMATCH')
        require(data['collectorWallNs'] is None and data['collectorUserUs'] is None,'WORK_TIMING_NOT_ALLOWED_AS_PRIMARY')
    else:require(data['work'] is None,'TIMED_BINARY_MUST_NOT_HAVE_COUNTERS')
    return data,(directory/'stdout').read_bytes()
def run(expected):
    document=verify(expected)
    destination=OUT/'pilot-results';destination.mkdir(exist_ok=False)
    fixtures=json.loads((V2/'FIXTURES.json').read_text())
    write(destination/'PRE_EXECUTION.json',{'utc':datetime.now(timezone.utc).isoformat(),'expectedSealSha256':expected,'completeInputsVerifiedBeforeAnyChild':True,'fixedSource':document['fixedSource'],'maximumChildren':24,'launchCutoffSeconds':30,'perSubjectSeconds':20,'meaning':'Private single pilot; no retries, no formal B1/R16/512 acceptance.'})
    rows=[];outputs={};problem=None;began=time.monotonic_ns()
    # No input/raw hashing, build, external monitor or other CLI in this window.
    for scheduled in document['schedule']:
        if (time.monotonic_ns()-began)/1e9>=30:break
        directory=destination/('%02d-%s-%s-%s'%(scheduled['index'],scheduled['recipe'],scheduled['variant'],scheduled['mode']))
        outcome=logged(scheduled['argv'],directory,Path(document['cwd']),document['environment'],20,launch_before_ns=began+30_000_000_000)
        row={'scheduled':scheduled,'outcome':outcome};rows.append(row)
        if outcome['launchBudgetExhaustedNoChild']:
            row['status']='UNRUN_LAUNCH_DEADLINE';problem='COHORT_LAUNCH_BUDGET_EXHAUSTED';break
        if not outcome['completedNormally']:
            problem='CHILD_DID_NOT_COMPLETE_NORMALLY';break
        try:
            metrics,output=parse(directory,scheduled,fixtures);row['metrics']=metrics
            key=(scheduled['recipe'],scheduled['variant'],scheduled['mode']);outputs[key]=output
            if scheduled['mode']=='work':require(output==outputs[(scheduled['recipe'],scheduled['variant'],'timed')],'WORK_VS_UNINSTRUMENTED_OUTPUT_MISMATCH')
            previous=[data for key2,data in outputs.items() if key2[0]==scheduled['recipe']]
            require(all(data==output for data in previous),'C_RF_RJ_OUTPUT_MISMATCH')
        except BaseException as error:
            problem=type(error).__name__+': '+str(error);row['validationProblem']=problem;break
    closed=time.monotonic_ns()
    within_budget=closed-began<=60_000_000_000
    if not within_budget:problem='EXCLUSIVE_WINDOW_BUDGET_EXCEEDED'
    executed={row['scheduled']['index'] for row in rows if row['outcome']['observedPopenCount']==1}
    write(destination/'WINDOW_CLOSED.json',{'elapsedSupervisorNs':closed-began,'childInvocations':len(executed),'within60SecondBudget':within_budget,'noMoreChildrenWillBeLaunched':True,'problem':problem})
    # Post-window identity checks and hashes never enter collector timers.
    input_error=None
    try:verify(expected)
    except BaseException as error:input_error=str(error)
    hashes={p.relative_to(destination).as_posix():SHA(p.read_bytes()) for p in destination.rglob('*') if p.is_file()}
    result={'status':'COMPLETE_PRIVATE_DIAGNOSTIC_NOT_B1' if len(executed)==24 and not problem and not input_error else 'INCOMPLETE_OR_INVALID_KEEP_ALL_RAW_NO_RETRY','fixedSource':document['fixedSource'],'sealSha256':expected,'rows':rows,'actualChildInvocations':len(executed),'unrunSchedule':[row for row in document['schedule'] if row['index'] not in executed],'problem':problem,'postWindowInputError':input_error,'windowElapsedSupervisorNs':closed-began,'within60SecondBudget':within_budget,'rawSha256AfterWindow':hashes,'memoryBoundary':document['rssBoundary'],'wallBoundary':document['wallBoundary'],'allSamplesRetained':True,'replicatesPerVariantRecipeMode':1,'performanceThresholdsAdded':False,'significance':'UNMEASURED; one observation, report resolution/noise/zero/regression without retakes.','formalB1R16And512World':'UNVERIFIED'}
    write(destination/'RESULT.json',result)
    print(result['status'],'children',len(rows),'problem',problem)
    require(result['status']=='COMPLETE_PRIVATE_DIAGNOSTIC_NOT_B1','PILOT_NOT_COMPLETE_SEE_PRESERVED_RAW')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['check','run']);parser.add_argument('--expected',required=True);args=parser.parse_args()
    if args.action=='check':verify(args.expected);print('READY_FOR_ONE_PILOT; binary executions0 by check')
    else:run(args.expected)
