"""Prepare/build/seal exactly one private F340 pilot; never execute its binaries."""
from pathlib import Path
import ast
import difflib
import hashlib
import importlib
import importlib.util
import json
import os
import shutil
import sys
from datetime import datetime,timezone

OUT=Path(__file__).resolve().parent
V1=OUT.parent/'private-cost-preparation'
V2=OUT.parent/'private-cost-readiness-v2'
ROOT=Path('/tmp/geometry-pr340-20261102')
FIXED='edf556eedc204bb285fb4504e246e4310f4e1e88'
V2_SHA='32352be140c5037123cd384ec962f9355f5bb8e8a81056eccff3ce1929d97363'
SHA=lambda data:hashlib.sha256(data).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def record(path,data):
    with path.open('x') as stream:json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')
def identity(path):
    path=Path(path);return {'path':str(path),'resolved':str(path.resolve()),'bytes':path.stat().st_size,'sha256':SHA(path.read_bytes())}
def counter_copy(label,text):
    edits=[];work=text
    def edit(name,before,after,expected,meaning):
        nonlocal work
        require(work.count(before)==expected,(label,name,work.count(before),expected))
        line=work[:work.index(before)].count('\n')+1 if expected else None
        edits.append({'name':name,'before':before,'after':after,'occurrences':expected,'lineBeforeThisEdit':line,'meaning':meaning})
        if expected:work=work.replace(before,after)
    edit('counter-storage','#include "contact_world.h"','#include "contact_world.h"\n#include "work.h"\nGeo341PrivateWork geo341_work;',1,'Private per-process zero-initialized counters; never linked into timed binary.')
    signature='size_t wood_contact_collect_stops(const WoodContactWorld *world,bool along_v,const WoodMember *exclude,WoodStopFace *out,size_t cap)\n{'
    edit('collector-calls',signature,signature+'\n    ++geo341_work.collector_calls;',1,'Actual collector entries.')
    edit('admitted-faces','    /* D11 placement order','    geo341_work.admitted_faces+=count;\n    /* D11 placement order',1,'Count after original truncate/collection and before sort/dedup.')
    for name,signature in [('order_calls','static uint64_t contact_order(const WoodContactWorld *world,const ContactOrderIndex *index,uint32_t id)\n{'),('earlier_calls','static bool contact_earlier(const WoodContactWorld *world,const ContactOrderIndex *index,uint32_t id,uint64_t order)\n{')]:
        edit(name,signature,signature+'\n    ++geo341_work.'+name+';',1,'Actual helper entries without altering return expressions.')
    edit('plane-compare','{return (a>b)-(a<b);}','{++geo341_work.plane_compare_calls;return (a>b)-(a<b);}',1,'Full-width comparator invocations; original comparator retained.')
    marker='    uint64_t left=contact_order(world,orders,out[a].timber_id),right=contact_order(world,orders,out[b].timber_id);'
    edit('member-sort-comparisons',marker,'    ++geo341_work.member_index_before_calls;\n'+marker,1,'Indexed stable-sort comparator entries.')
    marker='    ContactFaceIndex index;contact_member_index_sort(world,orders,out,count,first,&index);'
    edit('indexed-route',marker,'    ++geo341_work.indexed_calls;\n'+marker,1,'Indexed pipeline calls; Rj helper definitions remain but its call route is absent.')
    marker='if(compact)for(size_t i=0;i<count;++i)active[i]=true;'
    edit('bitmap-init',marker,'if(compact)for(size_t i=0;i<count;++i){active[i]=true;++geo341_work.bitmap_init_writes;}',0 if label=='R_joint' else 1,'One count per original bitmap initialization write.')
    edit('active-clear','active[i]=false;','++geo341_work.active_clears;++geo341_work.duplicate_removals;active[i]=false;',1 if label=='R_joint' else 2,'Original active clear also records one duplicate removal.')
    marker='if(compact&&!active[j])continue;'
    edit('inactive-skip',marker,'if(compact&&!active[j]){++geo341_work.inactive_skips;continue;}',0 if label=='R_joint' else 1,'Counts only skips actually taken.')
    marker='for(size_t j=0;j<count&&!duplicate;++j){'
    edit('pair-visits',marker,marker+'++geo341_work.pair_visits;',1,'Actual fallback candidate visits before filtering.')
    marker='if(earlier&&out[j].lo<=out[i].lo&&out[j].hi>=out[i].hi)duplicate=true;'
    edit('full-cover-checks',marker,'if(earlier){++geo341_work.full_cover_checks;if(out[j].lo<=out[i].lo&&out[j].hi>=out[i].hi)duplicate=true;}',1,'Preserves short circuit: count coverage predicates only when earlier is true.')
    marker='for(size_t i=0;i<count;++i)if(active[i]){if(write!=i)out[write]=out[i];++write;}'
    edit('compaction',marker,'for(size_t i=0;i<count;++i){++geo341_work.compaction_scans;if(active[i]){if(write!=i){++geo341_work.compaction_moves;out[write]=out[i];}++write;}}',0 if label=='R_joint' else 1,'Count original scan iterations and actual complete-face assignments.')
    marker='memmove(out+i,out+i+1,(count-i-1)*sizeof *out)'
    edit('memmove',marker,'do{++geo341_work.memmove_calls;++geo341_work.duplicate_removals;geo341_work.memmove_bytes+=(count-i-1)*sizeof *out;'+marker+';}while(0)',1,'Original byte expression and memmove retained; ABI sizeof is not assumed.')
    marker='while(at<=length){size_t *value=&index->maximum[begin+at-1];'
    edit('fenwick-insert-nodes',marker,'while(at<=length){++geo341_work.fenwick_insert_nodes;size_t *value=&index->maximum[begin+at-1];',1,'Original insertion-loop visits.')
    marker='for(size_t at=lo-begin;at;at-=at&(~at+1)){'
    edit('fenwick-query-nodes',marker,marker+'++geo341_work.fenwick_query_nodes;',1,'Original prefix-query-loop visits.')
    restored=work
    for change in reversed(edits):
        if change['occurrences']:
            require(restored.count(change['after'])==change['occurrences'],('roundtrip anchor',label,change['name']))
            restored=restored.replace(change['after'],change['before'])
    require(restored==text,'COUNTER_ROUNDTRIP_FAILED '+label)
    return work,edits

def main():
    spec=importlib.util.spec_from_file_location('_geo341_v2',V2/'readiness.py');v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
    old_seal=v2.verify(V2_SHA)
    require(not (OUT/'source').exists(),'PREPARATION_ALREADY_STARTED')
    prep=json.loads((V1/'PREPARATION.json').read_text())
    for entry in prep['closure']:
        source=V1/'source'/entry['path'];target=OUT/'source'/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    wood=OUT/'source/geometry-templates/woodworking/native';kernel=OUT/'source/geometry-core/kernel'
    shutil.copy2(V1/'source/tests/geo261_contact_world_harness.c',wood/'original-contact-world-client.c')
    shutil.copy2(OUT/'work.h',wood/'work.h');shutil.copy2(OUT/'driver.c.in',wood/'driver-common.inc')
    replay=(V1/'replay.c').read_text();before='int main(int argc,char **argv)\n{if(argc!=2)return 2;return replay(argv[1]);}'
    require(replay.count(before)==1,'ONE_EXTERNAL_REPLAY_ENTRY')
    (wood/'replay-entry.inc').write_text(replay.replace(before,before.replace('int main(','int geo341_private_replay_entry(')))
    (wood/'timed-client.c').write_text('#define PILOT_WORK 0\n#include "driver-common.inc"\n')
    (wood/'work-client.c').write_text('#define PILOT_WORK 1\n#include "driver-common.inc"\n')
    variants={};all_edits={}
    for label in ['C','R_fallback','R_joint']:
        data=(V1/(label+'.c')).read_bytes();require(SHA(data)==prep['variants'][label]['sha256'],'V1_VARIANT_CHANGED')
        (wood/(label+'.c')).write_bytes(data)
        instrumented,edits=counter_copy(label,data.decode());(wood/(label+'-work.c')).write_text(instrumented)
        patch=''.join(difflib.unified_diff(data.decode().splitlines(True),instrumented.splitlines(True),fromfile='a/'+label+'.c',tofile='b/'+label+'-work.c'))
        (OUT/(label+'-counters.diff')).write_text(patch);all_edits[label]=edits
        variants[label]={'sourceSha256':SHA(data),'workSourceSha256':SHA(instrumented.encode()),'counterRoundtripExact':True}
    record(OUT/'COUNTER_EDITS.json',{'variants':variants,'edits':all_edits,'semanticExecution':'UNRUN','meaning':'Source-level reversible work vector, not a weighted instruction count or timed sample.'})
    build_dir=OUT/'build';build_dir.mkdir();(OUT/'runtime').mkdir()
    sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT))
    module=importlib.import_module('tests.test_geo261_native_kernel');build=module.NativeBuild.__new__(module.NativeBuild)
    build.work=build_dir;build.kernel=kernel;build.woodworking=wood;build.windows=False;build.suffix='';build.logs=[];build.cc=old_seal['futureRuntimeEnvironment']['CC']
    planned=[];build.run_build=lambda args:planned.append(list(args))
    def build_all():
        common=[build.compile(kernel/'exact.c','exact'),build.compile(kernel/'geometry.c','geometry'),build.compile(wood/'contacts.c','contacts'),build.compile(wood/'supports.c','supports')]
        timed=build.compile(wood/'timed-client.c','timed-client');work_client=build.compile(wood/'work-client.c','work-client')
        for label in variants:
            real=build.compile(wood/(label+'.c'),label);work=build.compile(wood/(label+'-work.c'),label+'-work')
            build.link(label+'-timed',[timed,real,*common]);build.link(label+'-work',[work_client,work,*common])
    build_all();require(len(planned)==18,'EXPECTED18ORIGINAL_BUILD_COMMANDS')
    env=old_seal['futureRuntimeEnvironment'].copy();env['TMPDIR']=str(OUT/'runtime')
    inputs=[identity(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
    record(OUT/'BUILD_INPUTS.json',{'fixedSource':FIXED,'v2SealSha256':V2_SHA,'inputs':inputs,'argv':planned,'cwd':str(build_dir),'environment':env,'timeoutSeconds':300,'stackBytes':16777216,'originalCompileLinkTool':identity(Path(module.__file__)),'geometryExecutions':0})
    from envelope import logged
    outcomes=[]
    def actual_build(args):
        i=len(outcomes);require(list(args)==planned[i],'ORIGINAL_BUILD_FLAGS_CHANGED')
        outcome=logged(args,OUT/'commands'/('build-%02d'%i),build_dir,env,300);outcomes.append(outcome)
        build.logs.append({'command':list(args),'arguments':list(args),'exit':outcome['actualProcessReturncode'],'timedOut':outcome['timedOut'],'rawDirectory':str(OUT/'commands'/('build-%02d'%i))})
        (build_dir/'build-log.json').write_text(json.dumps(build.logs,indent=2)+'\n')
        require(outcome['completedNormally'],'BUILD_FAILED_KEEP_RAW '+str(i))
    build.run_build=actual_build
    build_all()
    v2.verify(V2_SHA)
    for entry in inputs:require(identity(entry['path'])==entry,'BUILD_INPUT_CHANGED')
    schedule=[]
    order=[('U','C'),('U','R_fallback'),('U','R_joint'),('S','R_fallback'),('S','R_joint'),('S','C'),('D','R_joint'),('D','C'),('D','R_fallback'),('X','C'),('X','R_joint'),('X','R_fallback')]
    for recipe,label in order:
        for mode in ['timed','work']:schedule.append({'index':len(schedule),'group':len(schedule)//2,'recipe':recipe,'variant':label,'mode':mode,'argv':[str(build_dir/(label+'-'+mode)),recipe]})
    record(OUT/'SCHEDULE.json',{'fixedSource':FIXED,'groups':12,'maximumChildInvocations':24,'newLaunchCutoffSeconds':30,'perChildTimeoutSeconds':20,'originalCleanupSecondsAtMost':5,'maximumExclusiveWindowSeconds':60,'rows':schedule,'samples':'UNRUN'})
    record(OUT/'BUILD_RESULT.json',{'status':'PASS_BUILD_ONLY_NO_BINARY_EXECUTION','fixedSource':FIXED,'outcomes':outcomes,'originalCompileLinkCommandsExact':True,'counterRoundtripExact':True,'geometryExecutions':0,'samples':'UNRUN'})
    sealed_files={p for p in OUT.rglob('*') if p.is_file()}
    sealed_files.update(Path(entry['path']) for entry in old_seal['inputs'])
    sealed_files.add(V2/'SEAL.json')
    seal={'schema':'geometry-pr341-one-private-pilot/1','utc':datetime.now(timezone.utc).isoformat(),'fixedSource':FIXED,'v2SealSha256':V2_SHA,'inputs':[identity(p) for p in sorted(sealed_files)],'environment':env,'cwd':str(OUT),'schedule':schedule,'limits':{'stackBytes':16777216,'perSubjectSeconds':20,'buildSeconds':300,'noNewLaunchAfterSeconds':30,'maxWindowSeconds':60},'status':'SEALED_BUILT_NOT_EXECUTED','collectorTiming':'CLOCK_MONOTONIC and RUSAGE_SELF bracket one uninstrumented collector call; CPU includes the two clock reads.','rssBoundary':'Fresh direct child RUSAGE_SELF.ru_maxrss at driver end after output/oracle; not independently observed after final stderr/exit.','wallBoundary':'External supervisor span includes Popen/wait overhead; collector-only wall is the primary wall observation.','original14Methods41Controls':'UNRUN_IN_PILOT','formalB1R16And512World':'UNVERIFIED'}
    record(OUT/'PILOT_SEAL.json',seal)
    (OUT/'PILOT_SEAL.sha256').write_text(SHA((OUT/'PILOT_SEAL.json').read_bytes())+'  PILOT_SEAL.json\n')
    size=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());require(size<128*1024*1024,'PRIVATE_OUTPUT_EXCEEDS128MiB')
    print('READY_FOR_ONE_PILOT',SHA((OUT/'PILOT_SEAL.json').read_bytes()),'bytes',size,'geometry executions0')

if __name__=='__main__':main()
