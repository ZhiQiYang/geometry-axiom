# Launcher revision R2 — original build and seal retained

No C source, fixture, assertion, counter patch, object, executable, compile
command or original7f31 seal was changed. No produced binary has run.

The original launcher hashed SEAL.read_bytes() and then parsed a second
SEAL.read_text() read. R2 hashes and parses the same raw byte buffer, binding
the adopted schedule/inputs/environment to the externally held expected SHA.
It uses PILOT_SEAL_R2.json and a new pilot-results-r2 destination. Those are
the only three launcher changes. The original launcher remains an unreleased
historical snapshot; use only pilot-r2.py with the new R2 digest.

The current U/S64 unique-ID cases keep343 in C/Rf and cannot establish341
no/low-duplicate fallback costs. A future separately frozen65-fact public
helper replay was suggested by root, remains UNRUN, and was not added here.
Rj stays a341+343 pipeline joint withdrawal retaining unique bookkeeping.
The fixed24 schedule and all original20/300s/16MiB limits stay unchanged.

Only root's next explicit exclusive-window release can authorize the run
action. R2 check remains metadata-only and invokes no produced executable.
