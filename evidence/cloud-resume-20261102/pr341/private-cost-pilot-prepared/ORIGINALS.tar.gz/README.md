# Built private pilot, samples not started

Only fixed F340 `edf556eedc204bb285fb4504e246e4310f4e1e88` is the primary source.
v1/v2 are read-only. New340/main merges cannot inherit this identity. This
directory prepares a private diagnostic, not formal B1/R16/512 acceptance.

`PREPARE.py` copies only the16 v1 C/header/fixture inputs, preserves all original
assertions and literal recipes, and renames only the private replay entry point.
It uses the exact original NativeBuild.compile/link methods and their O0 flags.
It first collects their18 exact commands without executing them, seals source,
commands/cwd/environment, then invokes those same commands through the original
run_logged with300s. Raw stdout/stderr and original/actual exit survive failure.
No produced executable is invoked during preparation.16MiB is inherited.

Timed binaries link the exact uninstrumented C/Rf/Rj source bytes. The new
external driver brackets exactly one collector with CLOCK_MONOTONIC and
RUSAGE_SELF; world setup, original oracle and serialization stay outside.
CPU deltas include the clock-read overhead inside that outer CPU interval.
The probe verifies one call and reports actual stack soft limit/ABI face size.

Work binaries use separate counter copies. `COUNTER_EDITS.json` records every
literal anchor, expected occurrence count, meaning and intermediate line;
three diffs show the complete edits. Reversing all edits mechanically must
restore each original source hash. Fields count actual entries/visits/writes,
preserve short circuits and original memmove byte expressions. No weighted
work score or new numerical performance threshold exists. Work timing fields
are null, and work executables never supply primary CPU/wall comparisons.

`driverEndMaxRssKiB` is fresh-process RUSAGE_SELF at driver end after oracle and
stdout flush; it is not independently sampled after final stderr/exit. The
parent separately brackets RUSAGE_CHILDREN deltas around its single direct
child for whole-child CPU after wait. External supervisor wall includes
Popen/wait/file overhead. Those boundaries stay separate from collector wall.
Page granularity/shared fixture storage may hide bitmap differences.

The fixed schedule is12 groups, timed then separate work process: at most24
invocations, each original20s. The observer checks the shared30s launch deadline
immediately before original.Popen; a rejected launch stays UNRUN. Original
cleanup can use5s, leaving5s of the60s exclusive budget for finalization.
The launch cutoff is a diagnostic budget, not a speed gate. On timeout, setup,
assertion, output or route/accounting mismatch, preserve raw and leave later
rows UNRUN; no retry or best-of selection. An elapsed window over60s cannot
receive complete status. There is no R8/R16 retake.

Root must explicitly release the performance window before the run action.
The check action hashes sealed inputs but never invokes a produced executable:

```text
python -B pilot.py check --expected EXTERNALLY_HELD_FULL_PILOT_SEAL_SHA256
```

After root release only, one run is available; output refuses overwrite:

```text
python -B pilot.py run --expected EXTERNALLY_HELD_FULL_PILOT_SEAL_SHA256
```

All hashing/builds finish before the sample window; the single producer runs
only its fixed children and validates its own raw outputs during the window.
Post-window hashes/readback happen after WINDOW_CLOSED.json. Rf retains the
active declaration and343 route; Rj is only a341+343 indexed-pipeline joint
withdrawal, retaining shared unique bookkeeping/uncalled helper definitions.
Full14/41, restored-C, semantic runtime of these new drivers, all work/cost
values and formal acceptance remain UNRUN until the allowed single pilot.
