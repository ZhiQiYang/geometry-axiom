"""Pilot-local use of unchanged run_logged; no input/raw hashing in the window."""
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json
import resource
import time

ORIGINAL=Path('/tmp/geometry-pr340-20261102/tests/assembly_mutation_check.py')

def logged(argv,directory,cwd,env,timeout,*,launch_before_ns=None):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    request={'argv':list(argv),'cwd':str(cwd),'environment':env,'timeoutSeconds':timeout,'stackBytes':16777216,'latestLaunchMonotonicNs':launch_before_ns}
    (directory/'REQUEST.json').write_text(json.dumps(request,indent=2)+'\n')
    spec=importlib.util.spec_from_file_location('_geo341_pilot_original_logged',ORIGINAL)
    tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
    original=tool.subprocess;observed=[];budget_exhausted=False
    def observe(*args,**kwargs):
        nonlocal budget_exhausted
        if launch_before_ns is not None and time.monotonic_ns()>=launch_before_ns:
            budget_exhausted=True
            raise OSError('PILOT_LAUNCH_BUDGET_EXHAUSTED_NO_CHILD_STARTED')
        process=original.Popen(*args,**kwargs);observed.append(process);return process
    tool.subprocess=SimpleNamespace(Popen=observe,TimeoutExpired=original.TimeoutExpired)
    old=resource.getrlimit(resource.RLIMIT_STACK)
    before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.monotonic_ns()
    try:
        resource.setrlimit(resource.RLIMIT_STACK,(16777216,old[1]))
        code,timed_out,group=tool.run_logged(list(argv),directory,Path(cwd),env,timeout)
    finally:
        tool.subprocess=original
        resource.setrlimit(resource.RLIMIT_STACK,old)
    ended=time.monotonic_ns();after=resource.getrusage(resource.RUSAGE_CHILDREN)
    actual=observed[0].returncode if len(observed)==1 else None
    result={'argv':list(argv),'originalSupervisorExit':code,'actualProcessReturncode':actual,'timedOut':timed_out,'processGroup':group,'observedPopenCount':len(observed),'launchBudgetExhaustedNoChild':budget_exhausted,'supervisorWallNs':ended-started,'reapedChildUserSeconds':after.ru_utime-before.ru_utime,'reapedChildSystemSeconds':after.ru_stime-before.ru_stime,'completedNormally':code==0 and actual==0 and not timed_out and len(observed)==1,'wholeChildCpuMeaning':'RUSAGE_CHILDREN deltas bracket exactly this one sequential direct child.','wallMeaning':'Supervisor span includes file/Popen/wait overhead; collector wall is separate.'}
    (directory/'OUTCOME.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
