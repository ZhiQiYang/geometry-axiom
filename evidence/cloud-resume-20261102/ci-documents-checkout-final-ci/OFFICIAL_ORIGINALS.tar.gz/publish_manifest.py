"""Build and immediately verify a portable manifest after all receipt writers end."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'source-actual/.git', 'PUBLICATION_MANIFEST.json', 'PUBLICATION_MANIFEST.sha256'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


files = []
for path in sorted(ROOT.rglob('*')):
    relative = path.relative_to(ROOT).as_posix()
    if path.is_file() and relative not in EXCLUDED:
        data = path.read_bytes()
        files.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
manifest = {
    'schema': 'geometry-pr368-publication-manifest/1',
    'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'builderCommand': ['python3', str(Path(__file__).resolve())],
    'run': 41447885087,
    'sourceU': 'b2432c9ea79a6927675883ddde04f629b159be2d',
    'execution': '310bebb505ea04309634279b7025c1849a35d88d',
    'executionBase': 'e02057b4c725d6f03ae52c3bc30776bf9442b0cf',
    'fileCount': len(files),
    'totalBytes': sum(f['bytes'] for f in files),
    'excluded': [
        {'path': 'source-actual/.git', 'reason': 'private linked-worktree administrative pointer; no source or CI evidence'},
        {'path': 'PUBLICATION_MANIFEST.json', 'reason': 'self-reference excluded; detached checksum sidecar supplied'},
        {'path': 'PUBLICATION_MANIFEST.sha256', 'reason': 'manifest checksum sidecar'},
    ],
    'files': files,
}
path = ROOT / 'PUBLICATION_MANIFEST.json'
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
digest = sha(path.read_bytes())
(ROOT / 'PUBLICATION_MANIFEST.sha256').write_text(digest + '  PUBLICATION_MANIFEST.json\n')
errors = []
for item in json.loads(path.read_text())['files']:
    data = (ROOT / item['path']).read_bytes()
    if len(data) != item['bytes'] or sha(data) != item['sha256']:
        errors.append(item['path'])
assert not errors, errors
print(json.dumps({'exit': 0, 'verifiedFiles': len(files), 'bytes': manifest['totalBytes'], 'manifestSHA256': digest}))
