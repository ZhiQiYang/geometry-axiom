"""Hash/parse saved original receipts only; never invokes runtime or repository code."""
import ast
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import struct
import zipfile

OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'source-actual'
U = 'b2432c9ea79a6927675883ddde04f629b159be2d'
EXECUTION = '310bebb505ea04309634279b7025c1849a35d88d'
BASE = 'e02057b4c725d6f03ae52c3bc30776bf9442b0cf'
RUN = 41447885087


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data), 'sha256': sha(data)}


def read_json(path):
    return json.loads(path.read_text())


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    checks = []

    def check(group, label, passed, detail=None):
        checks.append({'group': group, 'check': label, 'passed': bool(passed), **({'detail': detail} if detail is not None else {})})

    run = read_json(OUT / 'run.json')
    jobs_object = read_json(OUT / 'jobs-all.json')
    jobs = jobs_object['jobs']
    artifacts_object = read_json(OUT / 'artifacts.json')
    artifacts = artifacts_object['artifacts']
    acquisition = read_json(OUT / 'ACQUISITION.json')
    isolation = read_json(OUT / 'SOURCE_ISOLATION.json')
    check('run', 'exact source and completed attempt1', run['id'] == RUN and run['head_sha'] == U and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success')
    check('run', 'saved PR base is original e020', run['pull_requests'][0]['number'] == 368 and run['pull_requests'][0]['head']['sha'] == U and run['pull_requests'][0]['base']['sha'] == BASE)
    check('run', '10 real jobs, no aliases', jobs_object['total_count'] == len(jobs) == 10 and len({j['name'] for j in jobs}) == 10 and all(j['run_attempt'] == 1 for j in jobs))
    check('source', 'U and actual exact tree', isolation['commits']['U']['tree'] == isolation['commits']['execution']['tree'] == '37255a53c002dd39960ff85b0d2404c710912faa')
    check('source', 'only workflow differs from original base', (OUT / 'source-U-vs-base.names').read_text() == 'M\t.github/workflows/integration-tests.yml\n')
    for label, expected in [('U', U), ('execution', EXECUTION), ('base', BASE)]:
        data = (OUT / f'source-{label}-commit.txt').read_bytes()
        oid = hashlib.sha1(b'commit ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        check('source', 'raw commit object ' + label, oid == expected)
    commit = (OUT / 'source-execution-commit.txt').read_text()
    check('source', 'synthetic merge actual parents', re.findall(r'^parent ([0-9a-f]{40})$', commit, re.M) == [BASE, U])
    for entry in isolation['files']:
        data = (SOURCE / entry['path']).read_bytes()
        check('source', entry['path'], sha(data) == entry['sha256'] and len(data) == entry['bytes'] and entry['exactActualAndUBytes'])
    for entry in acquisition['requests']:
        data = Path(entry['file']).read_bytes()
        check('acquisition', Path(entry['file']).name, entry['http_status'] == 200 and len(data) == entry['bytes'] and sha(data) == entry['sha256'])
    check('acquisition', 'one complete 25 GET acquisition', acquisition['exit'] == 0 and not acquisition['errors'] and acquisition['requestCount'] == 25 and acquisition['onlyGET'] and acquisition['noDispatchOrRerun'])
    expected_names = {'canvas-wait-trace', 'grid-trial-screens-canvas', 'document-reader-screens', 'assembly-review-screens', 'native-complete-coverage', 'native-logs-1', 'native-logs-2', 'native-logs-3', 'native-shard-1', 'native-shard-2', 'native-shard-3', 'grid-trial-screens-grid'}
    check('artifacts', '12 exact official artifact names', artifacts_object['total_count'] == len(artifacts) == 12 and {a['name'] for a in artifacts} == expected_names and len(list((OUT / 'zips').glob('*.zip'))) == 12)
    artifact_rows, contents = [], {}
    for artifact in artifacts:
        path = OUT / 'zips' / f"{artifact['id']}-{artifact['name']}.zip"
        data = path.read_bytes()
        check('artifacts', artifact['name'] + ' API digest/size/source', artifact['digest'] == 'sha256:' + sha(data) and artifact['size_in_bytes'] == len(data) and artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == U and not artifact['expired'])
        members, body = [], {}
        with zipfile.ZipFile(path) as archive:
            check('members', artifact['name'] + ' no duplicates/path escape', len(archive.namelist()) == len(set(archive.namelist())) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in archive.namelist()))
            for info in archive.infolist():
                member = archive.read(info)
                body[info.filename] = member
                check('members', artifact['name'] + '/' + info.filename, len(member) == info.file_size)
                record = {'name': info.filename, 'bytes': len(member), 'sha256': sha(member), 'crc32': format(info.CRC, '08x')}
                if info.filename.endswith('.png'):
                    good = member.startswith(b'\x89PNG\r\n\x1a\n')
                    check('members', 'PNG ' + info.filename, good)
                    if good:
                        record['dimensions'] = list(struct.unpack('>II', member[16:24]))
                members.append(record)
        contents[artifact['name']] = body
        artifact_rows.append({**file_identity(path), 'id': artifact['id'], 'name': artifact['name'], 'api_digest': artifact['digest'], 'members': members})
    check('members', 'screens actual member counts', [len(contents[n]) for n in ('document-reader-screens', 'assembly-review-screens', 'grid-trial-screens-grid', 'grid-trial-screens-canvas')] == [8, 9, 4, 4])
    constants = {}
    for node in ast.parse((SOURCE / 'tests/run_all.py').read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    universe = ['c:integrity', 'core:run_tests', 'mutation:check', 'oracle:framing-selftest'] + ['py:' + n for n in sorted(constants['PY_NEEDS'])] + ['node:tests-js', 'node:model_viewer', 'node:polydraft', 'node:canvas_direct'] + list(constants['NODE_DOCUMENT_SCRIPT_FILES']) + list(constants['NODE_PURE_TEST_FILES'])
    expected = read_json(SOURCE / 'tests/run_all.expected.json')['suites']
    check('native', 'static registry exact 237', len(universe) == len(set(universe)) == 237 and set(universe) == set(expected))
    weights = read_json(SOURCE / 'tests/native_shard_timings.json')['timings_ms']
    loads, owners = [0, 0, 0], {}
    for name in sorted(universe, key=lambda n: (-weights.get(n, 1000), n)):
        index = min(range(3), key=lambda i: (loads[i], i))
        loads[index] += weights.get(name, 1000)
        owners[name] = index
    parts = [[name for name in universe if owners[name] == i] for i in range(3)]
    expected_sha = sha((SOURCE / 'tests/run_all.expected.json').read_bytes().replace(b'\r\n', b'\n'))
    timings_sha = sha((SOURCE / 'tests/native_shard_timings.json').read_bytes().replace(b'\r\n', b'\n'))
    rows, shards = [], []
    for index in (1, 2, 3):
        name = f'shard-{index}.json'
        data = contents[f'native-shard-{index}'][name]
        receipt = json.loads(data)
        check('native', 'original shard bytes ' + str(index), data == (OUT / 'native-input' / name).read_bytes())
        check('native', 'shard identity/plan ' + str(index), receipt['schema'] == 'geometry-native-shard/1' and receipt['shard'] == [index, 3] and receipt['commit_sha'] == EXECUTION and receipt['universe'] == universe and receipt['selected'] == parts[index - 1] and receipt['expected_sha256'] == expected_sha and receipt['timings_sha256'] == timings_sha and receipt['exit_code'] == 0 and not receipt['registry_errors'] and not receipt['expected_problems'])
        check('native', 'selected suites exact rows ' + str(index), Counter(row['name'] for row in receipt['rows']) == Counter(receipt['selected']))
        for row in receipt['rows']:
            check('native_rows', row['name'] + ' strict runtime receipt', row['ran'] and row['process_exit_code'] == 0 and not row['failed'] and not row['crashed'] and not row['env_problem'] and not row['expected_problem'] and row['allowed_skips'] == row['skipped'])
            registered = expected[row['name']]
            good_count = row['total'] == registered.get('count') and row['passed'] + row['skipped'] == row['total'] if row['counted'] else registered['mode'] == 'exit-code-only' and row['total'] == 0 and row['passed'] == (0 if row['name'] == 'mutation:check' else 1)
            check('native_rows', row['name'] + ' count', good_count)
            if row['name'].startswith('py:'):
                raw = json.loads(contents[f'native-logs-{index}'][row['name'].replace(':', '_') + '.json'])
                check('native_raw', row['name'], all(raw[k] == row[k] for k in ('total', 'passed', 'failed', 'skipped')) and not raw['failures'] and raw['import_error'] is None and raw['extra_errors'] == 0)
        rows.extend(receipt['rows'])
        shards.append({'index': index, 'suites': len(receipt['rows']), 'seconds': receipt['seconds'], 'sha256': sha(data)})
    check('native', 'union 237 exactly once', len(rows) == 237 and Counter(row['name'] for row in rows) == Counter(universe))
    skipped = [row for row in rows if row['skipped']]
    gdi = json.loads(contents['native-logs-1']['py_test_gdi_contract.json'])
    allowed = next(a for a in constants['ALLOWED_SKIPS'] if a['suite'] == 'py:test_gdi_contract')
    check('native', 'only original allowed named GDI skip', len(skipped) == 1 and skipped[0]['name'] == 'py:test_gdi_contract' and skipped[0]['skipped'] == 1 and len(gdi['skip_items']) == 1 and gdi['skip_items'][0]['test'] == allowed['test'] and gdi['skip_items'][0]['reason'] == allowed['reason'] and 'posix' in allowed['platforms'])
    summary = {'passed': True, 'commit_sha': EXECUTION, 'parts': 3, 'suite_count': len(universe), 'executed_suites': len(rows), 'union_equals_full_registry': True, 'overlap': [], 'counted_tests': sum(r['total'] for r in rows if r['counted']), 'counted_passed': sum(r['passed'] for r in rows if r['counted']), 'allowed_skips': sum(r['allowed_skips'] for r in rows), 'shard_suites': {str(i + 1): len(p) for i, p in enumerate(parts)}, 'expected_sha256': expected_sha, 'timings_sha256': timings_sha}
    check('native', '5421/5420/1', (summary['counted_tests'], summary['counted_passed'], summary['allowed_skips']) == (5421, 5420, 1))
    official = contents['native-complete-coverage']['native-complete.json']
    replay = (OUT / 'native-replay.json').read_bytes()
    replay_execution = read_json(OUT / 'NATIVE_REPLAY_EXECUTION.json')
    check('native', 'official aggregate equals independent summary', json.loads(official) == summary)
    check('native', 'original CLI exit0 and byte-exact official summary', replay_execution['actualExit'] == 0 and official == replay and json.loads((OUT / 'native-replay.stdout').read_text()) == summary and (OUT / 'native-replay.stderr').read_bytes() == b'')
    proof = json.loads(contents['native-complete-coverage']['native-sharding-proof/receipt.json'])
    check('native', 'official coverage deletion proof 0/1/0', proof['passed'] and proof['baseline_mutant_restored_exit'] == [0, 1, 0] and proof['rows'][1]['removed'] == ['c:integrity'] and proof['rows'][1]['failures'] == 1)
    golden = read_json(SOURCE / 'geometry-web/cdp_sections.golden.json')
    gate_rows, browser = [], {}
    for job in jobs:
        log = OUT / 'job-logs' / f"{job['id']}.log"
        lines = log.read_text().splitlines()
        text = '\n'.join(lines)
        check('jobs', job['name'] + ' actual source success', job['run_id'] == RUN and job['head_sha'] == U and job['status'] == 'completed' and job['conclusion'] == 'success' and f'Merge {U} into {BASE}' in text and any(re.search(r'Z ' + EXECUTION + r'$', line) for line in lines))
        checkout = [i for i, line in enumerate(lines, 1) if re.search(r'Z ' + EXECUTION + r'$', line)]
        result = []
        for i, line in enumerate(lines, 1):
            match = re.search(r'\b(CDP_RESULT|SPACE_RESULT|DOCUMENTS_RESULT) (\{.*\})$', line)
            if match:
                result.append({'line': i, 'marker': match[1], 'result': json.loads(match[2])})
        record = {'name': job['name'], 'id': job['id'], 'run_attempt': job['run_attempt'], 'started_at': job['started_at'], 'completed_at': job['completed_at'], 'log': file_identity(log), 'checkout_sha_lines': checkout, 'results': result}
        if job['name'].startswith('browser'):
            check('browser', job['name'] + ' unique raw output', len(result) == 1)
            output = result[0]['result']
            suite = job['name'][9:-1]
            browser[suite] = output
            steps = {s['name']: s for s in job['steps']}
            check('browser', suite + ' build and browser actually successful', steps['Build current native executables']['conclusion'] == 'success' and steps['Run actual browser regression group']['conclusion'] == 'success' and '##[group]Run npm run build' in text)
            if result[0]['marker'] == 'CDP_RESULT':
                check('browser', suite + ' no fail/skip and complete', output['completed'] and output['failedAssertions'] == 0 and not output['skipped'] and sum(output['sections'].values()) == output['passedAssertions'])
                if suite == 'canvas':
                    check('canvas', 'original 2286 /86 golden /full scope', output['passedAssertions'] == 2286 and len(output['sections']) == 86 and output['sections'] == golden['sections'] and golden['total'] == 2286 and output['goldenCompare'] == 'matched' and output['scope']['mode'] == 'full' and not output['scope']['filters'] and not output['scope']['modifiers'])
                    expected_lines = [i for i, line in enumerate(lines, 1) if '[EXPECTED EXCEPTION] Error: fb-auto-probe' in line]
                    check('canvas', 'sole original P38 expected exception', output['uncaughtBrowserExceptions'] == 1 and len(expected_lines) == 1 and '[UNEXPECTED EXCEPTION]' not in text and 'P38 預期的單次例外確實抵達 ✓' in text)
                    record['P38_expected_exception_lines'] = expected_lines
                else:
                    expected_filter, expected_count = {'grid': ('GEOMETRY_GRID_SYSTEM_ONLY', 356), 'assembly': ('GEOMETRY_ASSEMBLY_ONLY', 150)}[suite]
                    check('browser', suite + ' original partial scope', output['scope']['mode'] == 'partial' and output['scope']['filters'] == [expected_filter] and output['passedAssertions'] == expected_count and output['uncaughtBrowserExceptions'] == 0)
            elif result[0]['marker'] == 'SPACE_RESULT':
                check('browser', suite + ' exact group completeness', output['completed'] and output['failed'] == 0 and not output['completenessProblems'] and not output['exceptions'] and not output['consoleErrors'] and all(g['completed'] and g['failed'] == 0 and g['passed'] == g['expected'] for g in output['groups'].values()) and sum(g['passed'] for g in output['groups'].values()) == output['passed'])
                check('browser', suite + ' original scope/count', output['passed'] == (242 if suite == 'space' else 79) and output['scope']['mode'] == ('full-space-suite' if suite == 'space' else 'partial') and output['scope']['filters'] == ([] if suite == 'space' else ['GEOMETRY_TIMBER_ONLY']))
            else:
                pass_lines = [i for i, line in enumerate(lines, 1) if re.search(r'Z PASS ', line)]
                check('documents', '47 raw PASS /0 FAIL /47-0 result', len(pass_lines) == 47 and not re.search(r'Z FAIL ', text) and output['passedAssertions'] == 47 and output['failedAssertions'] == 0 and output['viewport'] == [1400, 900, 390, 844])
                standard = [s for s in job['steps'] if s['name'].startswith('Run actions/checkout@')]
                special = steps['Checkout document job primary sources']
                check('documents', 'old generic step skipped /new checkout success', len(standard) == 1 and standard[0]['conclusion'] == 'skipped' and special['conclusion'] == 'success')
                check('documents', 'actual sparse filter settings in raw log', 'filter: blob:none' in text and 'sparse-checkout-cone-mode: false' in text and '!/evidence/' in text and 'persist-credentials: false' in text)
                record['raw_PASS_lines'] = pass_lines
                record['generic_checkout'] = standard
                record['new_checkout'] = special
        elif job['name'] == 'native complete coverage':
            aggregates = [json.loads(line[line.index('{'):]) for line in lines if '"union_equals_full_registry"' in line and '"suite_count"' in line]
            check('native', 'aggregate actually printed in official job', len(aggregates) == 1 and aggregates[0] == summary)
        gate_rows.append(record)
    check('browser', 'six exact real browser outputs', set(browser) == {'assembly', 'grid', 'canvas', 'space', 'timber', 'documents'})
    trace = json.loads(contents['canvas-wait-trace']['receipt.json'])
    check('canvas', 'original wait trace disabled runner receipt', trace['head'] == EXECUTION and trace['status'] == 'trace-disabled-for-this-runner' and trace['records'] == 0)
    old_job = read_json(OUT / 'reference-old-documents/JOB.json')
    old_text = (OUT / 'reference-old-documents/original-job.log').read_text()
    old_steps = {s['name']: s for s in old_job['steps']}
    check('old_reference', 'cancelled original remains separate', old_job['id'] == 125251333430 and old_job['head_sha'] == 'f8f0b433ee01429c2c4d7d5f20a85d3d9a9f1b12' and old_job['conclusion'] == 'cancelled' and old_steps['Build current native executables']['conclusion'] == 'skipped' and old_steps['Run actual browser regression group']['conclusion'] == 'skipped' and 'The operation was canceled.' in old_text and 'DOCUMENTS_RESULT' not in old_text)
    failures = [c for c in checks if not c['passed']]
    final = {'schema': 'geometry-pr368-final-ci-originals/1', 'startedUTC': started, 'endedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'run': RUN, 'runURL': run['html_url'], 'sourceU': U, 'execution': EXECUTION, 'executionBase': BASE, 'tree': isolation['commits']['execution']['tree'], 'sameTreeUAndExecution': True, 'all10RealJobsSuccess': not failures, 'checkCount': len(checks), 'failures': failures, 'officialZIPs': 12, 'actualMemberCount': sum(len(a['members']) for a in artifact_rows), 'native': summary, 'nativeOriginalCLIExit': replay_execution['actualExit'], 'nativeSummaryBytesExactOfficial': official == replay, 'officialSummarySha256': sha(official), 'canvas': browser['canvas'], 'documents': browser['documents'], 'browserOutputs': browser, 'canvasWaitTrace': trace, 'logicalGates': gate_rows, 'artifactInventory': artifact_rows, 'checks': checks, 'sourceFiles': isolation['files'], 'limits': ['只回收既存run41447885087終態；未dispatch／rerun。', '本地僅執行固定來源原純Python聚合CLI及hash／解析，沒有產品／ELF／Chrome／suite執行。', '十個GHA執行均屬U／actual310b／base e020；不能移標至後來fca3或其他新main。', 'canvas2286是原assertion數，非端到端情境數；P38單次例外是原預期探針。', 'GDI在原Linux執行依原allowlist跳過一次；未以此宣稱Windows真資源測試。', 'source-actual只物化聚合裁判需要的331個固定blob；其.git指標不列入可發布內容。', '舊PR345 cancelled documents僅作問題來源，未混作本次成功執行。']}
    (OUT / 'FINAL_ACCEPTANCE.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'README.md').write_text('PR #368 既存最終 CI 原件回收。run 41447885087，U b2432c9ea79a6927675883ddde04f629b159be2d，actual 310bebb505ea04309634279b7025c1849a35d88d，base e02057b4c725d6f03ae52c3bc30776bf9442b0cf；U／actual同tree。\n\n12個官方ZIP與10份真正attempt1 job logs已保存。原純Python聚合CLI exit0，summary逐byte等於官方；native237/237、5421 counted／5420 pass／1原允許GDI。完整canvas2286／86段golden／0fail／0skip，P38原預期例外1；documents47/0，普通checkout skipped、專用checkout success。\n\n獨立hash／解析核對'+str(len(checks))+'項，失敗'+str(len(failures))+'。詳細原件、來源、命令、退出碼與UTC見FINAL_ACCEPTANCE、ACQUISITION、SOURCE_ISOLATION及NATIVE_REPLAY_EXECUTION。PUBLICATION_MANIFEST列可發布檔案；不發布私有worktree .git指標。\n\n沒有dispatch／rerun、產品／ELF／Chrome執行或作者source／branch／PR／body改動。新main fca3不屬本次execution，不移標結果。\n')
    files = []
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.name not in ('PUBLICATION_MANIFEST.json', 'PUBLICATION_MANIFEST.sha256') and path.relative_to(OUT).as_posix() != 'source-actual/.git':
            files.append(file_identity(path))
    manifest = {'schema': 'geometry-pr368-publication-manifest/1', 'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'run': RUN, 'sourceU': U, 'execution': EXECUTION, 'executionBase': BASE, 'fileCount': len(files), 'totalBytes': sum(f['bytes'] for f in files), 'excluded': [{'path': 'source-actual/.git', 'reason': 'private linked-worktree administrative pointer, not source or CI evidence'}, {'path': 'PUBLICATION_MANIFEST.json', 'reason': 'self-reference excluded; detached sha256 file provided'}, {'path': 'PUBLICATION_MANIFEST.sha256', 'reason': 'manifest checksum sidecar'}], 'files': files}
    path = OUT / 'PUBLICATION_MANIFEST.json'
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'PUBLICATION_MANIFEST.sha256').write_text(sha(path.read_bytes()) + '  PUBLICATION_MANIFEST.json\n')
    print(json.dumps({'checks': len(checks), 'failures': failures, 'ZIPs': 12, 'members': final['actualMemberCount'], 'publicationFiles': len(files), 'publicationBytes': manifest['totalBytes'], 'finalSha256': sha((OUT / 'FINAL_ACCEPTANCE.json').read_bytes()), 'manifestSha256': sha(path.read_bytes())}, ensure_ascii=False))
    raise SystemExit(int(bool(failures)))


if __name__ == '__main__':
    main()
