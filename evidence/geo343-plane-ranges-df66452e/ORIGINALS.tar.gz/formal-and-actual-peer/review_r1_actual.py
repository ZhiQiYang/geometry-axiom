from pathlib import Path
import json,hashlib
B=Path('/workspace/geo343-plane-ranges-formal-20261024');L=Path('/workspace/geo343-plane-ranges-formal-launch-20261024');O=Path(__file__).parent;S='7c4a40a71fe46242c302efaa85f1a4d13df0c19a';passed=0;fail=[]
def j(p):return json.loads(p.read_bytes())
def h(b):return hashlib.sha256(b).hexdigest()
def ck(v,l):
 global passed
 if v:passed+=1
 else:fail.append(l)
r=j(B/'RESULT.json');outer=j(L/'RESULT.json');ck(r['exit']==outer['exit']==outer['primary_exit']==outer['reaper_exit']==1,'originalR1true1 allouterlevels');ck(r['source_sha']==S and r['source_clean_after']is True and r['errors']==[],'originalsourceclean')
for root in [B,L]:
 for i,row in enumerate(j(root/'subcommands.json'),1):
  d=Path(row['directory']);ck(j(d/'result.json')==row and row['source_sha']==S and row['timeout_expired']is False,'originalc387row '+str(d))
  for stream in ['stdout','stderr']:
   raw=(d/(stream+'.bin')).read_bytes();ck(h(raw)==row[stream+'_sha256']and len(raw)==row[stream+'_bytes'],'c387full '+str(d)+stream)
  ck(h((d/'stdin.bin').read_bytes())==row['stdin_sha256'],'c387stdin '+str(d))
suites=r['suites'];ck(len(suites)==3 and [x['state']for x in suites]==['COMPLETED','UNRUN_ENVIRONMENT','UNRUN_ENVIRONMENT'],'onlywoodrun/twooriginalENV');ck(all(x.get('reason')=='original100MiB disk guard'for x in suites[1:]),'environmentcause exactoriginalguard')
T=B/'wood-contact';runner=j(T/'runner.json');ck(runner['total']==runner['run']==14 and runner['passed']==13 and runner['failed']==1 and runner['skipped']==0,'original14/13/1/0skip');ck(len(runner['failures'])==1 and runner['failures'][0]['message']=='AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate','exactassertion classified surviving existing guard')
obs=T/'observed';entry=j(obs/'ORIGINAL_ENTRY.json');observation=j(obs/'OBSERVATION.json');m=j(B/'SOURCE_MANIFEST.json');ck(entry['original_exit']==1 and entry['original_completed']is True and entry['observer_complete']is True and observation['observer_complete']is True,'originalcomplete dualobserver evenred');ck(entry['source_files_before']==entry['source_files_after']==m['files'] and entry['source_sha']==observation['source_sha']==S,'capture beforeafterclosure immutable')
cmds=[]
for d in sorted(obs.glob('command-*')):
 x=j(d/'receipt.json');cmds.append((x,d));ck(x['number']==len(cmds)and x['completed_process_returned']is True and x['exception']is None,'observer true OS result '+d.name)
 for stream in ['stdout','stderr']:
  data=(d/(stream+'.bin')).read_bytes();pin=x[stream];ck(pin['captured']is True and len(data)==pin['bytes']and h(data)==pin['sha256'],'observercomplete stream '+d.name+stream)
ck(len(cmds)==observation['commands']==416,'all416childreceipts')
native=[json.loads(line)for line in (T/'native-executions.jsonl').read_text().splitlines()];cursor=0
for x in native:
 found=None
 for i in range(cursor,len(cmds)):
  y,d=cmds[i]
  if y['args']==[x['command']] and y['returncode']==x['actual_exit']and (d/'stdout.bin').read_bytes()==x['stdout'].encode() and(d/'stderr.bin').read_bytes()==x['stderr'].encode():found=(i,y);break
 ck(found is not None,'native originalstream ordered match '+str(cursor))
 if found:
  cursor=found[0]+1;y=found[1];ck(y['executable']['sha256']==x['executable_sha256'],'nativeactualELFhash match');ck(x['source_sha']==S,'native source binding')
ck(len(native)==233,'233originalnativeevents')
q=[x for x in native if x.get('control')=='indexed-plane-coordinate'];ck([(x['phase'],x['actual_exit'])for x in q]==[('baseline',0),('mutant',0)],'survivor is0/0,no imaginaryrestored')
q=[x for x in native if x.get('control')=='plane-whole'];ck([(x['phase'],x['actual_exit'])for x in q]==[('fixed',0),('withdrawn',1),('restored',0)]and q[1]['stderr']=='ASSERT:plane-cached-query-no-plane-search\n','newwhole fix0/1/0 exactnamedassert')
for control in ['physical-ordinal','nonfirst-begin','nonfirst-end','singleton-end','truncated-plane']:
 q=[x for x in native if x.get('control')==control];ck([(x['phase'],x['actual_exit'])for x in q]==[('baseline',0),('mutant',1),('restored',0)] and q[1]['stderr']=='ASSERT:plane-linear-range-oracle\n','fivecompanion exacttriples '+control)
report={'scope':'Independent true R1 terminal/high-level raw and all416observerstreams/native233 ordered reconciliation; no C,source writes,compile-payload fullaudit or current-source relabel','source_sha':S,'passed':passed,'failed':len(fail),'failures':fail,'subject_exit':1,'original_runner':runner,'unrun_environment':[x['label']for x in suites[1:]],'limits':['All runtime streams checked against retained originals; compiler input payload full roundtrip remains collector/package scope.','Surviving indexed-plane-coordinate is a real original test red, not a valid mutation kill. NewsourceR2 must execute independently.','Two exploratory metadata path reads assumed commands/result.json instead of actual subcommands/receipt.json; read-only FileNotFoundError occurred only in reviewer, original outputs unchanged.']};report['exit']=int(bool(fail));(O/'R1_ACTUAL_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['passed','failed','exit']}));print(h((O/'R1_ACTUAL_REVIEW.json').read_bytes()));raise SystemExit(report['exit'])
