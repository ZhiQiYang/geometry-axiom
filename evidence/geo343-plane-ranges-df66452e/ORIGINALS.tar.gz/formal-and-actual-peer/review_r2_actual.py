from pathlib import Path
import ast,hashlib,json
R=Path('/workspace/geo343-plane-ranges-formal-r2-20261024');L=Path('/workspace/geo343-plane-ranges-formal-r2-launch-20261024');D=Path('/workspace/geo343-plane-range-draft-20261024');W=Path('/workspace/geo343-plane-ranges-work-20261024');O=Path(__file__).parent;S='df66452e7a514032453bea93b8b18ab74d7b1457';passed=0;fail=[];cache={}
def j(p):return json.loads(p.read_bytes())
def ck(v,n):
 global passed
 if v:passed+=1
 else:fail.append(n)
def digest(p):
 p=Path(p)
 if p not in cache:cache[p]=hashlib.sha256(p.read_bytes()).hexdigest()
 return cache[p]
def retain(x):
 p=Path(x['retained']);ck(p.stat().st_size==x['bytes']and digest(p)==x['sha256'],'retained input '+x['sha256']);return p.read_bytes()
r=j(R/'RESULT.json');outer=j(L/'RESULT.json');manifest=j(R/'SOURCE_MANIFEST.json');ck(r['exit']==outer['exit']==outer['primary_exit']==outer['reaper_exit']==0,'true subject/outer/reaper0');ck(r['source_sha']==outer['source_sha']==manifest['source_sha']==S and r['source_clean_after']is True and not r['errors'],'fixedsource clean');ck(not r['full_native']and not r['performance']and not r['ledger_regenerated'],'scope not full acceptance');ck([x['label']for x in r['suites']]==['wood-contact','contact-sources','reading-a'],'all three original suites')
for base in [R,L]:
 for x in j(base/'subcommands.json'):
  p=Path(x['directory']);ck(j(p/'result.json')==x and not x['timeout_expired'],'exact c387row')
  for k in ['stdout','stderr']:ck((p/(k+'.bin')).stat().st_size==x[k+'_bytes']and digest(p/(k+'.bin'))==x[k+'_sha256'],'full c387 '+k)
  ck(digest(p/'stdin.bin')==x['stdin_sha256'],'c387stdin')
compile_count=0;all_native={};snapshots=[];command_total=0;session_total=0
for suite,count,timeout in zip(r['suites'],[14,15,7],[20,30,20]):
 label=suite['label'];root=R/label;obs=root/'observed';entry=j(obs/'ORIGINAL_ENTRY.json');overview=j(obs/'OBSERVATION.json');runner=j(root/'runner.json');ck(suite['state']=='COMPLETED'and suite['actual_exit']==0 and suite['passed']is True,'actual suite0 '+label);ck(runner==suite['runner']and runner['run']==runner['passed']==runner['total']==count and not any(runner[k]for k in ['failed','skipped','explicit_skipped','unrun_skipped','blocked_by_error','expected_failed','extra_errors'])and runner['import_error']is None,'strictmethods '+label);ck(entry['original_exit']==0 and entry['original_completed']is True and entry['observer_complete']is True and overview['observer_complete']is True and not overview['observation_errors']and not overview['incomplete_sessions'],'dualcomplete '+label);ck(entry['source_files_before']==entry['source_files_after']==manifest['files']and entry['source_sha']==overview['source_sha']==S,'beforeafterexact '+label)
 commands=[]
 for path in sorted(obs.glob('command-*/receipt.json')):
  c=j(path);argv=c['args'][0];commands.append((path,c));ck(c['number']==len(commands)and c['completed_process_returned']is True and c['exception']is None and type(c['returncode'])is int,'true child result '+label+str(c['number']))
  for stream in ['stdout','stderr']:
   pin=c[stream];p=path.parent/(stream+'.bin')
   if pin['captured']:ck(p.stat().st_size==pin['bytes']and digest(p)==pin['sha256'],'full child '+label+str(c['number'])+stream)
   else:ck(label=='reading-a'and stream=='stderr'and argv==['git','-C',str(W),'rev-parse','HEAD']and c['kwargs'].get('stdout')==-1 and 'stderr'not in c['kwargs']and not c['kwargs'].get('capture_output')and not p.exists(),'original inherited stderr explicit')
  if Path(argv[0]).name in ['cc','gcc','cl']:compile_count+=1;ck(c['returncode']==0 and c['kwargs']['timeout']==300,'actual compiler300 zero')
 ck(len(commands)==overview['commands'],'all childreceipt count '+label);command_total+=len(commands)
 for path in obs.glob('session-*/receipt.json'):
  c=j(path);session_total+=1;ck(c['complete']is True and c['actual_returncode']==0 and c['source_sha']==S,'true bridge session '+label)
  for k,v in c['streams'].items():ck(Path(v['path']).stat().st_size==v['bytes']and digest(v['path'])==v['sha256'],'complete session stream '+label+k)
 for snapshot in j(obs/'native-inputs/compiler-input-snapshots.json'):
  for x in snapshot['inputs']:retain(x)
  snapshots.append(snapshot)
 native=[json.loads(line)for line in(root/'native-executions.jsonl').read_text().splitlines()];all_native[label]=native;cursor=0
 for x in native:
  found=None
  for i in range(cursor,len(commands)):
   path,c=commands[i]
   if c['args']==[x['command']]and c['returncode']==x['actual_exit']and(path.parent/'stdout.bin').read_bytes()==x['stdout'].encode()and(path.parent/'stderr.bin').read_bytes()==x['stderr'].encode():found=(i,path,c);break
  ck(found is not None,'native ordered original '+label+str(cursor))
  if found:
   cursor=found[0]+1;c=found[2];ck(c['executable']['sha256']==x['executable_sha256']and x['source_sha']==S,'native ELF/source '+label);ck(c['kwargs']['timeout']==timeout,'native original timeout '+label)
rows=all_native['wood-contact'];new=[x for x in rows if'test_cached_plane_ranges'in x['test']];ck(len(new)==57,'57new native observations');q=[x for x in rows if x.get('control')=='indexed-plane-coordinate'];ck([(x['phase'],x['actual_exit'])for x in q]==[('baseline',0),('mutant',1),('restored',0)]and q[1]['stderr']=='ASSERT:indexed-full-coordinate-plane\n','restored old indexed-plane-coordinate counterexample0/1/0')
for phase,comparisons,exitcode in [('fixed',0,0),('withdrawn',84,1),('restored',0,0)]:
 public=[x for x in new if x['phase']==phase and x['control']=='plane-whole-public'];oracle=[x for x in new if x['phase']==phase and x['control']=='plane-whole-oracle'];ck(len(public)==8 and len(oracle)==5 and all(x['actual_exit']==0 for x in public+oracle),'all13semantic baseline/withdraw/restore '+phase);work=[x for x in new if x['phase']==phase and x['control']=='plane-whole'];ck(len(work)==1 and work[0]['actual_exit']==exitcode and work[0]['stdout']==f'CASE work faces=16 plane_comparisons={comparisons}\n'and work[0]['stderr']==('ASSERT:plane-cached-query-no-plane-search\n'if exitcode else''),'whole observed work0/84/0 '+phase)
test=W/'tests/test_geo261_wood_contact_world.py';product=W/'geometry-templates/woodworking/native/contact_world.c';ck(digest(test)==manifest['files']['tests/test_geo261_wood_contact_world.py']and digest(product)==manifest['files']['geometry-templates/woodworking/native/contact_world.c'],'test/product actual frozen bytes');tree=ast.parse(test.read_text());assignment=lambda name:ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)));method=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='test_cached_plane_ranges_match_linear_oracle_and_remove_repeat_search');controls=ast.literal_eval(next(n.value for n in method.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='controls'for t in n.targets)));ck(len(controls)==5,'five original controls')
for label,before,after,case in controls:
 q=[x for x in new if x['control']==label];ck([(x['phase'],x['actual_exit'])for x in q]==[('baseline',0),('mutant',1),('restored',0)]and q[1]['stderr']=='ASSERT:plane-linear-range-oracle\n'and all(x['case']==case for x in q),'companion exactnamed0/1/0 '+label)
fixed=product.read_bytes();withdrawn=fixed
for before,after in reversed(assignment('PLANE_RANGE_EDITS')):ck(withdrawn.count(after.encode())==1,'unique exact wholewithdraw site');withdrawn=withdrawn.replace(after.encode(),before.encode())
variants={'fixed':fixed,'withdrawn':withdrawn,'restored':fixed};variants.update({label:fixed.replace(before.encode(),after.encode())for label,before,after,_ in controls});anchor=b'static int contact_face_plane_order(const WoodContactWorld *world,size_t a,size_t b)\n{'
# Read the exact original instrument anchor/count expression from the method definition, not a new product threshold.
instmethod=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='plane_executable');local={}
for node in instmethod.body:
 if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id=='anchor':anchor=ast.literal_eval(node.value).encode()
counted=b'static size_t geo_test_plane_comparisons;\n'+anchor+b'++geo_test_plane_comparisons;'
selected=[s for s in snapshots if'actual-contact-included-TU-at-compile'in s['roles']];plane_items=[x for s in selected for x in s['inputs']if Path(x['original']).name.startswith('contact-plane-')and Path(x['original']).name.endswith('-source.c')];ck(len(plane_items)==8,'threewhole plus five actual included TU')
for label,expected in variants.items():
 items=[x for x in plane_items if Path(x['original']).name=='contact-plane-'+label+'-source.c'];ck(len(items)==1,'unique compiled plane '+label)
 if items:ck(expected.count(anchor)==1 and retain(items[0])==expected.replace(anchor,counted),'actual compiled product variant '+label)
report={'scope':'Independent full original three-suite runtime streams, native events, compile-input payload and eight plane instrumented-TU audit; no C/Git mutation/performance rerun','source_sha':S,'passed':passed,'failed':len(fail),'failures':fail,'methods':36,'compile_link_zero':compile_count,'observer_commands':command_total,'bridge_sessions':session_total,'native_events':{k:len(v)for k,v in all_native.items()},'plane_new_native_events':57,'plane_whole_comparisons':[0,84,0],'limits':['OriginalR1 source7c4 red and environment-unrun remain separate.','This proves selected three suites only, not fullnative/browser/ledger/architecture or formal N64wall.','Initial read-only metadata display had a Python conditional whitespace SyntaxError before any read; no subject tool/source changed.']};report['exit']=int(bool(fail));(O/'R2_ACTUAL_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['passed','failed','exit','compile_link_zero']}));print(digest(O/'R2_ACTUAL_REVIEW.json'));raise SystemExit(report['exit'])
