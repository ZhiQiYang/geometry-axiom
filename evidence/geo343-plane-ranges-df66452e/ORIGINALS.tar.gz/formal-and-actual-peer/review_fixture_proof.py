from pathlib import Path
import ast,json,hashlib
D=Path('/workspace/geo343-plane-range-draft-20261024');R=Path('/workspace/geo343-plane-fixture-proof-20261024');L=Path('/workspace/geo343-plane-fixture-proof-launch-20261024');OLD=Path('/workspace/geo343-plane-ranges-formal-tools-20261024/observer');OBS=Path('/workspace/geo343-plane-fixture-proof-tools-20261024/observer');O=Path(__file__).parent;S='df66452e7a514032453bea93b8b18ab74d7b1457';LEAF='tests/geo261_contact_world_harness.c';n=0;fail=[];cache={}
def j(p):return json.loads(p.read_bytes())
def h(p):
 p=Path(p)
 if p not in cache:cache[p]=hashlib.sha256(p.read_bytes()).hexdigest()
 return cache[p]
def ck(v,l):
 global n
 if v:n+=1
 else:fail.append(l)
for name,pin in [('run_fixture_proof.py','ca656a69e29ac686951a99ba6c1c74313d2fbe5eeec276475ad69682fde0d2a6'),('launch_fixture_proof.py','2563bd6e527da4554b00240f588584e5f7b32b1b83833175810b04f593511738')]:ck(h(D/name)==pin,'fixedtool '+name);ast.parse((D/name).read_text());ck(True,'AST '+name)
ck(h(OBS/'TOOL_PINS.json')=='4cb7637ffcf7bb329872436efe39a29399fb9f7a6f9798e98e6760adf333fdbb','observerfixed')
for x in j(OBS/'TOOL_PINS.json')['tools']:
 name=x['name'];ck(h(OLD/name)==x['old_sha256']and h(OBS/name)==x['bound_sha256'],'observerpins '+name);body=(OLD/name).read_text()
 if name=='run_observed_original.py':body=body.replace("relative!='tests/test_geo261_timber_capacity_host.py'","relative!='tests/geo261_contact_world_harness.c'")
 ck(body==(OBS/name).read_text(),'only narrow withdrawal leaf '+name)
fix=j(D/'v2/EXACT_TEST_FIX.json');ck(h(D/'v2/EXACT_TEST_FIX.json')=='847837110ed6f5f73371fdc24a2ebdd55952a24e157d2b11a7483508195fe251','exactdelta fixed');ck(fix['leaf']==LEAF and fix['after'].count(fix['delta_after'])==1 and fix['after'].replace(fix['delta_after'],fix['delta_before'])==fix['before']and fix['before'].replace(fix['delta_before'],fix['delta_after'])==fix['after'],'solefourline reversible witness')
driver=(D/'run_fixture_proof.py').read_text()
for token in ['100*1024*1024','16*1024*1024','fcntl.LOCK_EX|fcntl.LOCK_NB',"'/tmp/g261r3/heavy.lock'","'-m','unittest','-v',TARGET",'timeout=None,check=False',"finally:(ROOT/LEAF).write_bytes(fixed)","FAILED (failures=1)",'Guard survived: indexed-plane-coordinate']:ck(token in driver,'original exactgate '+token)
static={'scope':'Independent fixture proof tool static review; original method and assertion retained','checks':n,'failed':len(fail),'findings':list(fail),'source_sha':S};(O/'FIXTURE_TOOL_REVIEW.json').write_text(json.dumps(static,indent=2)+'\n')
r=j(R/'RESULT.json');outer=j(L/'RESULT.json');m=j(D/'source-publication-r2/SOURCE_MANIFEST.json');ck(r['exit']==outer['exit']==outer['primary_exit']==outer['reaper_exit']==0 and not r['errors'],'actualouter0');ck(r['source_clean_after']is True and r['fixed_bytes_restored']is True and r['source_sha']==outer['source_sha']==S,'actual restored source');ck([(p['phase'],p['actual_exit'])for p in r['phases']]==[('fixed',0),('withdrawn',1),('restored',0)],'actualselectedmethod0/1/0')
for base in [R,L]:
 for row in j(base/'subcommands.json'):
  p=Path(row['directory']);ck(j(p/'result.json')==row and not row['timeout_expired'],'raw c387row')
  for stream in ['stdout','stderr']:ck((p/(stream+'.bin')).stat().st_size==row[stream+'_bytes']and h(p/(stream+'.bin'))==row[stream+'_sha256'],'originalc387full '+stream)
  ck(h(p/'stdin.bin')==row['stdin_sha256'],'originalstdin')
counts={};compilecount=0
for phase,expected in [('fixed',0),('withdrawn',1),('restored',0)]:
 root=R/phase;obs=root/'observed';result=j(root/'RESULT.json');entry=j(obs/'ORIGINAL_ENTRY.json');overview=j(obs/'OBSERVATION.json');fm=j(root/'manifest.json');files=dict(m['files']);body=(fix['before']if expected else fix['after']).encode();files[LEAF]=hashlib.sha256(body).hexdigest();ck(fm['files']==files and fm['source_sha']==S and fm['source_variant']==phase,'onlyfixture phase source '+phase);ck(entry['source_files_before']==entry['source_files_after']==files and entry['source_sha']==S,'entrysource '+phase);ck(entry['original_completed']is True and entry['original_exit']==expected and entry['observer_complete']is True and overview['observer_complete']is True and not overview['incomplete_sessions']and not overview['observation_errors'],'dualactualcomplete '+phase)
 cmd=result['command'];stderr=Path(cmd['directory'])/'stderr.bin';text=stderr.read_text();ck(cmd['command'][-5:]==['--','-m','unittest','-v','tests.test_geo261_wood_contact_world.WoodContactWorld.test_actual_guard_controls_fail_the_named_numeric_assertions'],'exact original selected method '+phase);ck('Ran 1 test in 'in text and ('FAILED (failures=1)'in text and 'AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate'in text if expected else '\nOK\n'in text),'named verdict '+phase)
 commands=[]
 for path in sorted(obs.glob('command-*/receipt.json')):
  c=j(path);commands.append((c,path));ck(c['number']==len(commands)and c['completed_process_returned']is True and c['exception']is None,'truechild '+phase)
  for st in ['stdout','stderr']:
   p=path.parent/(st+'.bin');ck(c[st]['captured']is True and p.stat().st_size==c[st]['bytes']and h(p)==c[st]['sha256'],'fullchild '+phase+st)
  if Path(c['args'][0][0]).name in ['cc','gcc','cl']:compilecount+=1;ck(c['returncode']==0 and c['kwargs']['timeout']==300,'originalcompile300zero')
 ck(len(commands)==overview['commands'],'allchildcount '+phase)
 snapshots=j(obs/'native-inputs/compiler-input-snapshots.json');harness=[]
 for snap in snapshots:
  for item in snap['inputs']:
   ck(Path(item['retained']).stat().st_size==item['bytes']and h(item['retained'])==item['sha256'],'compiled originalpayload')
   if Path(item['original']).name=='contact-world-client.c':harness.append(Path(item['retained']).read_bytes())
 ck(bool(harness)and all(b==body for b in harness),'actualcompiled soleharness '+phase)
 rows=[json.loads(x)for x in(root/'native-executions.jsonl').read_text().splitlines()];counts[phase]={'commands':len(commands),'native':len(rows)};cursor=0
 for x in rows:
  match=None
  for i in range(cursor,len(commands)):
   c,p=commands[i]
   if c['args']==[x['command']]and c['returncode']==x['actual_exit']and(p.parent/'stdout.bin').read_bytes()==x['stdout'].encode()and(p.parent/'stderr.bin').read_bytes()==x['stderr'].encode():match=(i,c);break
  ck(match is not None,'native originalordered '+phase)
  if match:cursor=match[0]+1;ck(match[1]['executable']['sha256']==x['executable_sha256']and x['source_sha']==S and match[1]['kwargs']['timeout']==20,'native ELF/time/source '+phase)
 q=[x for x in rows if x.get('control')=='indexed-plane-coordinate'];ck([(x['phase'],x['actual_exit'])for x in q]==([('baseline',0),('mutant',0)]if expected else[('baseline',0),('mutant',1),('restored',0)]),'actualoriginal control effect '+phase)
report={'scope':'Independent static and actual exact fixture withdrawal proof; all original streams, compiler payload and named method0/1/0; no C/source mutation','source_sha':S,'passed':n,'failed':len(fail),'failures':fail,'subject_exit':r['exit'],'phase_counts':counts,'compile_link_zero':compilecount,'limits':['Product remains fixed throughout; this is four-line test-witness proof, separate from whole product plane0/1/0.','OriginalR1 red and R2 selected36 green retain distinct sources and receipts.','Initial reviewer searched repository harness basename in compiler inputs, but original setUpClass copies exact bytes to contact-world-client.c; initial4180/3 and helper preserved, subject unchanged.']};report['exit']=int(bool(fail));(O/'FIXTURE_ACTUAL_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['passed','failed','exit']}));print(h(O/'FIXTURE_ACTUAL_REVIEW.json'));raise SystemExit(report['exit'])
