from pathlib import Path
import ast,hashlib,json,re,subprocess
P=Path('/workspace/geo343-plane-range-draft-20261024');O=Path(__file__).parent
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(name,ok):
 checks.append({'name':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
def function(text,name):
 at=text.index(name+'(');begin=text.index('{',at);depth=0
 for end in range(begin,len(text)):
  if text[end]=='{':depth+=1
  elif text[end]=='}':
   depth-=1
   if depth==0:return text[at:end+1]
 raise ValueError(name)
m=json.loads((P/'MANIFEST.json').read_text());old=(P/'before/contact_world.c').read_bytes();new=(P/'candidate/contact_world.c').read_bytes();patch=(P/'PRODUCT_ONLY.patch').read_bytes();s=old.decode();t=new.decode()
check('exact proposed source SHA',m['source_sha']=='a22df116c7e9f6b7d074451f1c8052d59e7e4f3e')
for name,body,pin in [('before',old,m['before_sha256']),('candidate',new,m['candidate_sha256']),('patch',patch,m['patch_sha256'])]:check(name+' manifest byte pin',sha(body)==pin)
argv=['git','-C','/workspace/geometry-axiom','show',m['source_sha']+':'+m['leaf']];r=subprocess.run(argv,capture_output=True)
(O/'ORIGINAL_R.stdout.bin').write_bytes(r.stdout);(O/'ORIGINAL_R.stderr.bin').write_bytes(r.stderr);(O/'ORIGINAL_R.COMMAND.json').write_text(json.dumps({'argv':argv,'actual_exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)},indent=2)+'\n')
check('original R exact Git source with true0',r.returncode==0and r.stdout==old)
check('exact five edits',len(m['edits'])==5)
a=s
for row in m['edits']:
 check('unique original anchor '+row['label'],a.count(row['before'])==1);a=a.replace(row['before'],row['after'],1)
check('no unrelated product modifications',a==t)
a=t
for row in reversed(m['edits']):
 check('unique withdrawal anchor '+row['label'],a.count(row['after'])==1);a=a.replace(row['after'],row['before'],1)
check('whole withdrawal equals exact R bytes',a.encode()==old)
for n in ['contact_face_index_before','contact_face_plane_compare','contact_prefix_lo','contact_prefix_hi','contact_member_index_sort','contact_order_index','contact_order','contact_earlier']:
 check('unchanged original function '+n,function(s,n)==function(t,n))
structure=r'typedef struct \{\s*size_t sorted\[WOOD_CONTACT_FACE_CAPACITY\],scratch\[WOOD_CONTACT_FACE_CAPACITY\];\s*size_t rank\[WOOD_CONTACT_FACE_CAPACITY\],maximum\[WOOD_CONTACT_FACE_CAPACITY\];\s*\} ContactFaceIndex;'
check('identical four existing stack arrays',re.search(structure,s).group()==re.search(structure,t).group())
build=function(t,'contact_face_index_build');bounds=function(t,'contact_face_index_bounds');dedup=function(t,'contact_indexed_dedup');covered=function(t,'contact_face_index_covered');insert=function(t,'contact_face_index_insert')
check('rank initialized for every face before metadata',build.index('index->rank[index->sorted[i]]=i;')<build.index('for(size_t begin=0;begin<count;)'))
check('group uses full-coordinate equality without cast/subtraction','out[index->sorted[end]].fixed==plane'in build and 'GeoCoord plane='in build)
check('every group first stores exclusive end','index->scratch[begin]=end;'in build)
check('every interior rank stores group begin','for(size_t rank=begin+1;rank<end;++rank)index->scratch[rank]=begin;'in build)
check('begin/end decoding matches disjoint marker cases','*begin=marker>rank?rank:marker;'in bounds and '*end=index->scratch[*begin];'in bounds)
check('no new pointer subtraction',not re.search(r'\b(?:face|out|ordinal)\s*-\s*(?:face|out)\b',bounds+covered+insert))
check('covered has explicit valid ordinal and exactly one caller','size_t count,size_t ordinal)'in covered and t.count('contact_face_index_covered(')==2and 'contact_face_index_covered(&index,out,count,i)'in dedup)
check('insert ordinals remain bounded existing loops','for(size_t i=0;i<first;++i)contact_face_index_insert(&index,out,count,i);'in dedup and 'while(pending<i&&'in dedup and 'contact_face_index_insert(&index,out,count,pending)'in dedup)
check('member sort remains before plane build',dedup.index('contact_member_index_sort(')<dedup.index('contact_face_index_build('))
check('scratch not written/read by membership path beyond bounds','scratch'not in insert and 'scratch'not in covered and 'scratch'not in dedup)
check('maximum admission and prefix bodies otherwise unchanged',function(s,'contact_face_index_insert').split('    size_t length=',1)[1]==insert.split('    size_t length=',1)[1]and function(s,'contact_face_index_covered').split('    size_t lo=',1)[1]==covered.split('    size_t lo=',1)[1])
check('public collect function only covered caller change',function(s,'wood_contact_collect_stops')==function(t,'wood_contact_collect_stops'))
# Existing negative control keeps the same inserted guard, case and assertion;
# only its exact anchor spelling follows the mechanical private helper change.
def find_control(path,label):
 tree=ast.parse(path.read_text())
 for n in ast.walk(tree):
  if isinstance(n,ast.Tuple)and n.elts and isinstance(n.elts[0],ast.Constant)and n.elts[0].value==label:return ast.literal_eval(n)
 raise ValueError(label)
b=find_control(P/'before/tests/test_geo261_wood_contact_world.py','indexed-reversed-skip');c=find_control(P/'candidate/tests/test_geo261_wood_contact_world.py','indexed-reversed-skip')
check('old reversed negative retains label/case/assertion',b[0]==c[0]and b[3:]==c[3:])
check('old reversed negative retains exactly original rejection guard',b[2].removesuffix(b[1])==c[2].removesuffix(c[1])=='if(face->hi<face->lo)return false;')
check('updated negative anchor is unique and face already initialized',t.count(c[1])==1and covered.index('const WoodStopFace *face=&out[ordinal];')<covered.index(c[1]))
proof={
 'marker':'For each maximal equal-plane group [b,e), scratch[b]=e>b; each rank r>b stores b<r. Thus marker>rank selects exactly the first-rank case. The decoded begin is b and decoded end is e, never scratch[count].',
 'bounds':'The only bounds callers pass out ordinals i or pending with 0<=ordinal<count; rank is the permutation inverse built for all faces. Public indexed path requires count<=existing capacity and first<count, so count>=1 and end=begin+1 does not approach SIZE_MAX. Empty input never calls this index.',
 'coordinate':'GeoCoord is signed int64_t. The unchanged comparator (a>b)-(a<b) has zero exactly when a==b. The new grouping introduces no truncation, arithmetic on coordinates or floating comparison.',
 'lifetime':'Member sorting finishes before rank/group construction. The indexed pass changes active and maximum only; physical out compaction occurs after it returns. Group membership deliberately includes inactive/later-covered faces exactly as old binary plane bounds did.',
 'policy':'No fixity, RC identity, interval prefix, witness, placement order, capacity, fallback, active admission or output count rule changes. This is cached lookup for existing faces only, not a new policy query accepting an external plane/face.',
 'limits':'Static product review only. No C compilation, original three suites, sanitizer, full ledger, browser or performance executed by this review. Existing negative controls and whole runtime proof still require true original execution at the new source.'}
report={'subject':str(P),'source_sha':m['source_sha'],'pins':{n:sha((P/n).read_bytes())for n in ['MANIFEST.json','PRODUCT_ONLY.patch','candidate/contact_world.c']},'checks':len(checks),'passed':all(x['passed']for x in checks),'findings':[],'details':checks,'proof':proof,'C_executed':False,'product_tests_executed':False,'exit_code':0}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':len(checks),'exit_code':0,'findings':[]}))
