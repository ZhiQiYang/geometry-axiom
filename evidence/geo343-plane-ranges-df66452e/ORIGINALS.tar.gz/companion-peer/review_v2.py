from pathlib import Path
import ast,hashlib,json,difflib
O=Path(__file__).resolve().parent;D=Path('/workspace/geo343-plane-range-draft-20261024');V=D/'v2';checks=[]
def ck(x,m):checks.append({'check':m,'passed':bool(x)})
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((V/'COMPANION_MANIFEST.json').read_text());old=json.loads((D/'COMPANION_MANIFEST.json').read_text())
for name,pin in old['files'].items():ck((V/'candidate'/name).read_bytes()==(D/'candidate'/name).read_bytes(),'original four leaves byte-identical '+name)
name='tests/geo261_contact_world_harness.c';a=(V/'before'/name).read_text();b=(V/'candidate'/name).read_text()
block='''    /* A later face on the first plane must remain in the same full-width
     * group even with an intervening plane whose low 32 bits are equal. */
    w.member_count=3;n=wood_contact_collect_stops(&w,false,NULL,out,8);
    CHECK("indexed-full-coordinate-plane",n==4&&sides(out,n,51)==2&&sides(out,n,52)==2&&sides(out,n,53)==0);
'''
ck(b.count(block)==1 and b.replace(block,'',1)==a,'only precise additional old-case witness; all old code/assertions retained')
ck('WoodStopFace out[8]'in a and 'w.member_count=3;'in block,'three paired-member faces fit existing8 buffer')
ck('fact(&m[0],1,false,(GeoRect2){0,0,100,27})'in a and 'fact(&m[1],2,false,(GeoRect2){INT64_C(4294967296),0,INT64_C(4294967396),27})'in a and 'fact(&m[2],3,false,(GeoRect2){0,0,100,27})'in a,'existing distinct IDs/strict order/identical first-third footprints')
ck(b.index(block)<b.index('f[0]=fact(&m[0],1,false,(GeoRect2){0,0,100,5})'),'new witness before later fixture reset')
ck(set(m['files'])==set(old['files'])|{name},'only fifth original C harness leaf added')
for n,pin in m['files'].items():ck(sha((V/'candidate'/n).read_bytes())==pin,'frozen v2 leaf '+n)
patch=(V/'FIVE_LEAF.patch').read_bytes();ck(sha(patch).startswith('0739953c'),'v2 five-leaf requested pin')
# Existing four-leaf diff is unchanged; compare full canonical generated patch.
parts=[]
for n in sorted(m['files']):
 oldp=V/'before'/n;aa=oldp.read_text().splitlines(True)if oldp.exists()else[];bb=(V/'candidate'/n).read_text().splitlines(True)
 parts.extend(difflib.unified_diff(aa,bb,fromfile='a/'+n if oldp.exists()else '/dev/null',tofile='b/'+n))
# Diff generation file order is not semantic; each named segment must equal generated diff.
def sections(t):
 rows=t.splitlines(True);starts=[i for i,x in enumerate(rows)if x.startswith('--- ')];return {rows[i+1][6:].strip():''.join(rows[i:starts[j+1]if j+1<len(starts)else len(rows)])for j,i in enumerate(starts)}
ck(sections(patch.decode())==sections(''.join(parts)),'all five exact complete unified diffs')
# Pure independent range-group illustration: not compiled C evidence.
faces=[(0,51,1),(100,51,1),(2**32,52,2),(2**32+100,52,2),(0,53,3),(100,53,3)]
def remaining(truncated):
 def coord(v):return ((v+2**31)%2**32)-2**31 if truncated else v
 order=sorted(range(6),key=lambda i:coord(faces[i][0]));group={};g=0;last=None
 for i in order:
  if last is None or faces[i][0]!=last:g+=1
  group[i]=g;last=faces[i][0]
 live=[]
 for i in range(6):
  if not any(group[j]==group[i]and faces[j][2]<faces[i][2]for j in live):live.append(i)
 return [faces[i][1]for i in live],order,group
fixed=remaining(False);mutant=remaining(True)
ck(fixed[0]==[51,51,52,52],'independent exact-coordinate groups remove both later53 faces')
ck(mutant[0]==[51,51,52,52,53,53],'independent truncated comparator splits0/wide0/0 and leaves53')
ck(b.count('CHECK("indexed-full-coordinate-plane"')==a.count('CHECK("indexed-full-coordinate-plane"')+1,'same original normal assertion marker strengthened')
failed=[x for x in checks if not x['passed']];report={'exit':int(bool(failed)),'checks':len(checks),'passed':len(checks)-len(failed),'findings':failed,'patch_sha256':sha(patch),'harness_sha256':sha(b.encode()),'independent_formula_fixed':fixed,'independent_formula_mutant':mutant,'scope':'Only static five-leaf preservation, unchanged original4 plus added old harness witness and pure coordinate-group formula. Original formal R1 control survivor remains red until v2 C runs. No C, compile,0/1/0,timing claims.'}
(O/'V2_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');(O/'V2_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['exit','checks','passed','findings']},ensure_ascii=False));raise SystemExit(report['exit'])
