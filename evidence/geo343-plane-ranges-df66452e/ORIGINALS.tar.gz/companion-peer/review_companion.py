from pathlib import Path
import ast,hashlib,json,re,subprocess,random
O=Path(__file__).resolve().parent;D=Path('/workspace/geo343-plane-range-draft-20261024');checks=[];gitreads=[]
def ck(x,m):checks.append({'check':m,'passed':bool(x)})
def sha(b):return hashlib.sha256(b).hexdigest()
M=json.loads((D/'COMPANION_MANIFEST.json').read_text());R='a22df116c7e9f6b7d074451f1c8052d59e7e4f3e'
ck(M['source_sha']==R,'fixed R manifest')
ck(sha((D/'FOUR_LEAF.patch').read_bytes())==M['four_leaf_patch_sha256']=='97918ee90787be5ca5dc698769203fa9be0febbbd82ad5c467fcc705a3d534ea','four-leaf patch frozen')
for n,p in M['files'].items():ck(sha((D/'candidate'/n).read_bytes())==p,'frozen leaf '+n)
for p in [D/'before'/n for n in M['files']]:
 if p.is_file():
  n=p.relative_to(D/'before').as_posix();r=subprocess.run(['git','-C','/workspace/geometry-axiom','show',R+':'+n],capture_output=True);gitreads.append({'argv':['show',R+':'+n],'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_hex':r.stderr.hex()});ck(r.returncode==0 and r.stdout==p.read_bytes(),'before exact original R '+n)
# Rebuild each accepted leaf from the complete unified diff, without writes.
lines=(D/'FOUR_LEAF.patch').read_text().splitlines(True);i=0;rebuilt={}
while i<len(lines):
 if not lines[i].startswith('--- '):i+=1;continue
 old=lines[i][4:].strip();new=lines[i+1][4:].strip();name=new[2:]if new.startswith('b/')else new;before=(D/'before'/name).read_text().splitlines(True)if(D/'before'/name).exists()else[];i+=2;at=0;output=[]
 while i<len(lines)and not lines[i].startswith('--- '):
  if not lines[i].startswith('@@ '):i+=1;continue
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);start=max(int(m[1])-1,0);ck(start>=at,'hunk order '+name);output.extend(before[at:start]);at=start;i+=1
  while i<len(lines)and not lines[i].startswith(('@@ ','--- ')):
   line=lines[i]
   if line.startswith('\\'):raise AssertionError('unexpected no-newline marker')
   if line[0]in' -':ck(at<len(before)and before[at]==line[1:],'hunk original exact '+name);at+=1
   if line[0]in' +':output.append(line[1:])
   i+=1
 output.extend(before[at:]);raw=''.join(output).encode();rebuilt[name]=raw;ck(raw==(D/'candidate'/name).read_bytes(),'full four-leaf reconstruct '+name)
ck(set(rebuilt)==set(M['files']),'exact patch four-leaf scope')
path='tests/test_geo261_wood_contact_world.py';old=(D/'before'/path).read_text();new=(D/'candidate'/path).read_text();A=ast.parse(old);B=ast.parse(new)
def defs(tree):return {n.name:ast.dump(n,include_attributes=False)for n in ast.walk(tree)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a=defs(A);b=defs(B);ck(len(a)==24,'original24 function definitions');ck(set(b)-set(a)=={'plane_executable','test_cached_plane_ranges_match_linear_oracle_and_remove_repeat_search'},'only intended two Python helpers')
for n,v in a.items():ck(b[n]==v,'old function AST unchanged '+n)
def const(t,name):return ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id==name for x in n.targets)))
controls_node=lambda t:next(n.value for n in t.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='CONTROLS'for x in n.targets))
oc=controls_node(A).elts;nc=controls_node(B).elts;ck(len(oc)==len(nc),'all original controls retained')
for x,y in zip(oc,nc):
 if x.elts[0].value!='indexed-reversed-skip':ck(ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False),'original control exact '+x.elts[0].value)
 else:
  x,y=ast.literal_eval(x),ast.literal_eval(y)
  replacement='size_t begin,end;contact_face_index_bounds(index,ordinal,&begin,&end);'
  ck(y==(x[0],replacement,'if(face->hi<face->lo)return false;'+replacement,x[3],x[4]),'reversed-span control only mechanical signature anchor')
ck(new.count('timeout=20')==old.count('timeout=20'),'original 20-second case threshold')
oldj=json.loads((D/'before/tests/run_all.expected.json').read_text());newj=json.loads((D/'candidate/tests/run_all.expected.json').read_text())
# Generic recursive differences reveal the exact sole registry count leaf.
def differences(a,b,p=''):
 if isinstance(a,dict)and isinstance(b,dict):
  if set(a)!=set(b):return [(p,a,b)]
  return [v for k in a for v in differences(a[k],b[k],p+'/'+k)]
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return[v for i,(x,y)in enumerate(zip(a,b))for v in differences(x,y,p+'/'+str(i))]
 return []if a==b else[(p,a,b)]
delta=differences(oldj,newj);ck(len(delta)==1 and delta[0][1:]==(13,14)and'test_geo261_wood_contact_world'in delta[0][0],'registry sole13to14 exact entry')
product='geometry-templates/woodworking/native/contact_world.c';before=(D/'before'/product).read_text();source=(D/'candidate'/product).read_text();edits=const(B,'PLANE_RANGE_EDITS');ck(len(edits)==5,'five exact whole-withdrawal edits')
v=source
for x,y in reversed(edits):ck(v.count(y)==1,'unique withdrawal after');v=v.replace(y,x,1)
ck(v==before,'whole withdrawal byte-for-byte R product')
for x,y in edits:ck(v.count(x)==1,'unique restoration before');v=v.replace(x,y,1)
ck(v==source,'whole restore exact candidate')
h=(D/'candidate/tests/geo343_plane_range_harness.c').read_text();method=next(n for n in ast.walk(B)if isinstance(n,ast.FunctionDef)and n.name=='test_cached_plane_ranges_match_linear_oracle_and_remove_repeat_search')
ct=next(ast.literal_eval(n.value)for n in method.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='controls');ck(len(ct)==5,'five named controls')
for label,x,y,case in ct:ck(source.count(x)==1,'one product mutant site '+label)
ck('calloc(1,sizeof *index)'in h and 'calloc(n+1,sizeof *out)'in h,'full capacity heap metadata and tail sentinel')
ck(h.index('CHECK("plane-linear-range-oracle"')<h.index('contact_face_index_insert(index,out,n,i)'),'all bounds checked before any mutated metadata insert')
ck('if(!work&&(!full||remaining==1))for' in h,'full capacity linear oracle only once; quadratic not cubic')
ck('geo_test_plane_comparisons=0;'in h and h.index('geo_test_plane_comparisons=0;')>h.index('contact_face_index_build(index,out,n)'),'work excludes one-time build')
ck(h.index('size_t calls=geo_test_plane_comparisons;')<h.index('if(work)CHECK'),'captured real count before final work assertion')
ck('if(work)CHECK("plane-cached-query-no-plane-search",calls==0)'in h,'work gate exact deterministic no plane query searches')
ck('for(size_t i=0;i<=n;++i)CHECK("plane-source-fields-and-tail-preserved"'in h,'all fields plus tail preserved')
ck('contact-plane-'+ '"+label+"-source.c' in new and '"contact-plane-"+label+"-exe"'in new,'distinct source/executable paths avoid old directory collision')
# Independent Python range model: pure formulas, not C or runtime proof.
planes=[0,-2**63,2**63-1,0,2**32,-2**63,-2**63+2**32,2**63-1,0,-7,2**32,-7,-2**63,2**63-1,0,-2**63+2**32]
los=[-10,0,5,10,20,10,-20,-10];his=[30,0,4,20,10,10,40,30]
def model(n,mut=None):
 vals=[(planes[i%16],los[i%8],his[i%8])for i in range(n)];order=sorted(range(n),key=lambda i:(vals[i][0],vals[i][1]));rank=[0]*n;scratch=[0]*n
 for j,i in enumerate(order):rank[i]=j
 begin=0
 while begin<n:
  end=begin+1;plane=vals[order[begin]][0]
  while end<n and ((vals[order[end]][0]&0xffffffff)==(plane&0xffffffff)if mut=='truncated-plane'else vals[order[end]][0]==plane):end+=1
  scratch[begin]=end-1 if mut=='singleton-end'else end
  for j in range(begin+1,end):scratch[j]=begin
  begin=end
 for i,(plane,lo,hi)in enumerate(vals):
  r=i if mut=='physical-ordinal'else rank[i];marker=scratch[r];b=r if marker>r else marker
  if mut=='nonfirst-begin':b=r
  e=marker if mut=='nonfirst-end'else scratch[b]
  expected=(sum(x[0]<plane for x in vals),sum(x[0]<=plane for x in vals))
  if (b,e)!=expected:return i,(b,e),expected
 return None
for n in [0,1,2,3,7,16,17,31,64]:ck(model(n)is None,'independent cached interval formula n='+str(n))
for label,x,y,case in ct:ck(model(1 if case=='singleton'else 16,label)is not None,'model predicts exact pre-insert range assertion '+label)
failed=[c for c in checks if not c['passed']];report={'exit':int(bool(failed)),'checks':len(checks),'passed':len(checks)-len(failed),'findings':failed,'source_R':R,'four_leaf_patch_sha256':M['four_leaf_patch_sha256'],'registry_difference':delta,'known_runtime_limit':'Owner reported original indexed-plane-coordinate control survived on first C run; this static review does not supersede that red. A strengthened existing-case witness v2 is separately reviewed and must rerun normal original control.', 'scope':'Static full patch reconstruction, original Git/AST/control preservation and small independent Python range-model checks. No C compilation/subject execution, whole actual0/1/0, original20s behavior, capacityruntime, native or timing pass is claimed. Product change itself separately reviewed by evidence agent.'}
(O/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');(O/'GIT_READS.json').write_text(json.dumps(gitreads,indent=2)+'\n');(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['exit','checks','passed','findings']},ensure_ascii=False));raise SystemExit(report['exit'])
