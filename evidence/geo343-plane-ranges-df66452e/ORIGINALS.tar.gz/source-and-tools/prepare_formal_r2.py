from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
old=HERE/'run_formal.py';s=old.read_text();assert sha(s.encode())=='1b21e21d6719a68531e03faebfa45ad76a225f871f15a0fa7224acdbe1511c74'
p=json.loads((HERE/'source-publication-r2/RESULT.json').read_bytes());assert p['exit']==0 and p['pushed']
m=HERE/'source-publication-r2/SOURCE_MANIFEST.json'
for a,b in [("PUB=HERE/'source-publication'","PUB=HERE/'source-publication-r2'"),('7c4a40a71fe46242c302efaa85f1a4d13df0c19a',p['source_sha']),('a89af59cd867f6727e9a0c92648d46249f970b1ec75cd2abbae138ae6cf958e9',sha(m.read_bytes())),('geo343-plane-ranges-formal-20261024','geo343-plane-ranges-formal-r2-20261024'),('geo343-plane-ranges-formal-tmp-20261024','geo343-plane-ranges-formal-r2-tmp-20261024')]:
 assert a in s;s=s.replace(a,b)
(HERE/'run_formal_r2.py').write_text(s);driver=sha(s.encode())
s=(HERE/'launch_formal.py').read_text();assert sha(s.encode())=='f1623683e90728eb5dc96f19953c6c52706c19520dfbfd6602f97abbab3719b6'
s=s.replace('geo343-plane-ranges-formal-launch-20261024','geo343-plane-ranges-formal-r2-launch-20261024').replace("DRIVER=HERE/'run_formal.py'","DRIVER=HERE/'run_formal_r2.py'").replace('source-publication/RESULT.json','source-publication-r2/RESULT.json').replace('1b21e21d6719a68531e03faebfa45ad76a225f871f15a0fa7224acdbe1511c74',driver)
(HERE/'launch_formal_r2.py').write_text(s)
print(json.dumps({'source':p['source_sha'],'manifest':sha(m.read_bytes()),'driver':driver,'launcher':sha(s.encode())}))
