"""Capture the original reaper and driver exits without an outer timeout."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
HERE=Path(__file__).resolve().parent;OUT=Path('/workspace/geo343-plane-fixture-proof-launch-20261024')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');REAPER=Path('/workspace/geo261-environment/reap_children.py');DRIVER=HERE/'run_fixture_proof.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if OUT.exists():raise RuntimeError('fresh outer required')
 pins={str(CAP):'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',str(REAPER):'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760',str(DRIVER):'ca656a69e29ac686951a99ba6c1c74313d2fbe5eeec276475ad69682fde0d2a6'}
 for path,pin in pins.items():
  if sha(Path(path))!=pin:raise RuntimeError('fixed tool pin '+path)
 pub=json.loads((HERE/'source-publication-r2/RESULT.json').read_bytes())
 if pub['exit']!=0 or pub['pushed'] is not True:raise RuntimeError('public source required')
 S=pub['source_sha'];OUT.mkdir();strip={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
 env={k:v for k,v in os.environ.items() if k not in strip and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GEO261_REAPER_LOG=str(OUT/'reaper.jsonl'))
 spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT,env,S)
 argv=[sys.executable,'-B',str(REAPER),sys.executable,'-B',str(DRIVER)]
 request={'source_sha':S,'argv':argv,'cwd':pub['worktree'],'timeout':None,'tools':pins,'reaper_log':env['GEO261_REAPER_LOG'],'slot':'primary only; secondary remains independent'}
 (OUT/'REQUEST.json').write_text(json.dumps(request,indent=2)+'\n')
 row,stdout,stderr=rec.run(argv,cwd=pub['worktree'],check=False,timeout=None);errors=[];primary=None
 try:
  ends=[json.loads(line)for line in (OUT/'reaper.jsonl').read_text().splitlines() if json.loads(line).get('event')=='完成']
  if len(ends)!=1:raise RuntimeError('one terminal reaper event required')
  primary=ends[0]['primary_returncode']
  if type(primary) is not int or (primary if primary>=0 else 128-primary)!=row['actual_process_returncode']:raise RuntimeError('primary/reaper exact exit required')
 except BaseException as e:errors.append(repr(e))
 exit_code=2 if errors else row['actual_process_returncode'];request.update(primary_exit=primary,reaper_exit=row['actual_process_returncode'],exit=exit_code,errors=errors,commands=rec.rows)
 (OUT/'RESULT.json').write_text(json.dumps(request,indent=2)+'\n');print(json.dumps({'source_sha':S,'exit':exit_code,'primary':primary,'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace')}),flush=True);return exit_code
if __name__=='__main__':sys.exit(main())
