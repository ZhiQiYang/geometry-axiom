from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;OLD=Path('/workspace/geo343-plane-ranges-formal-tools-20261024/observer');NEW=Path('/workspace/geo343-plane-fixture-proof-tools-20261024/observer')
def sha(b):return hashlib.sha256(b).hexdigest()
pins=json.loads((OLD/'TOOL_PINS.json').read_bytes());assert sha((OLD/'TOOL_PINS.json').read_bytes())=='3d9c2da369bc80929aa0f66143d08619aef18fc3fe1bcfb73cc45a8349509b1b'
NEW.mkdir(parents=True,exist_ok=False);items=[]
for item in pins['tools']:
 name=item['name'];body=(OLD/name).read_bytes();assert sha(body)==item['bound_sha256'];new=body
 if name=='run_observed_original.py':
  old=b"relative!='tests/test_geo261_timber_capacity_host.py'";replacement=b"relative!='tests/geo261_contact_world_harness.c'"
  assert body.count(old)==1;new=body.replace(old,replacement)
 (NEW/name).write_bytes(new);items.append({'name':name,'old_sha256':sha(body),'bound_sha256':sha(new)})
(NEW/'TOOL_PINS.json').write_text(json.dumps({'base_toolpins':sha((OLD/'TOOL_PINS.json').read_bytes()),'tools':items},indent=2)+'\n')
print(json.dumps({'observer':sha((NEW/'TOOL_PINS.json').read_bytes()),'exact_test_fix':sha((HERE/'v2/EXACT_TEST_FIX.json').read_bytes())}))
