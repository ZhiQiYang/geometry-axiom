from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;OUT=Path('/workspace/geo343-plane-ranges-formal-r2-20261024');S='df66452e7a514032453bea93b8b18ab74d7b1457'
def read(p):return json.loads(p.read_bytes())
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
r=read(OUT/'RESULT.json');o=read(Path(str(OUT).replace('-r2-','-r2-launch-'))/'RESULT.json')
need(r['source_sha']==o['source_sha']==S and r['exit']==o['exit']==o['primary_exit']==o['reaper_exit']==0 and r['source_clean_after'],'fixed terminal source')
summary={'source_sha':S,'actual_exit':0,'suites':[],'work':[],'fine_controls':[],'included_sources':[],'new_wall_measurement':False}
for suite in r['suites']:
 base=OUT/suite['label'];runner=read(base/'runner.json');count=suite['expected_methods']
 need(suite['passed'] and suite['actual_exit']==0 and runner['total']==runner['run']==runner['passed']==count,'strict original method count')
 need(all(runner.get(k,0)==0 for k in ['failed','skipped','extra_errors','blocked_by_error','expected_failed']),'no skipped/red methods')
 logs=[]
 for row in read(base/'observed/native-inputs/cleanup-retention.json'):
  p=Path(row['build_log']['retained']);need(sha(p.read_bytes())==row['build_log']['sha256'],'original buildlog pin');logs+=read(p)
 need(logs and all(x['exit']==0 for x in logs),'successful real compile/link')
 summary['suites'].append({'label':suite['label'],'methods':count,'actual_exit':0,'skipped':0,'compile_link_count':len(logs)})
allrows=[json.loads(x)for x in (OUT/'wood-contact/native-executions.jsonl').read_text().splitlines()]
rows=[x for x in allrows if x['test'].endswith('test_cached_plane_ranges_match_linear_oracle_and_remove_repeat_search')];need(len(rows)==57,'42 whole and15 fine native cases')
for phase,code,calls in [('fixed',0,0),('withdrawn',1,84),('restored',0,0)]:
 a=[x for x in rows if x['control']=='plane-whole' and x['phase']==phase];need(len(a)==1,'one work phase');x=a[0]
 need(x['actual_exit']==code and x['stdout']==f'CASE work faces=16 plane_comparisons={calls}\n' and x['stderr']==('ASSERT:plane-cached-query-no-plane-search\n'if code else ''),'normal exact work verdict')
 summary['work'].append({k:x[k]for k in ['phase','actual_exit','stdout','stderr','executable_sha256','command']})
for label in ['physical-ordinal','nonfirst-begin','nonfirst-end','singleton-end','truncated-plane']:
 a=[x for x in rows if x['control']==label];need([x['phase']for x in a]==['baseline','mutant','restored'] and [x['actual_exit']for x in a]==[0,1,0],'fine control triplet')
 need(a[1]['stderr']=='ASSERT:plane-linear-range-oracle\n','named range oracle assertion');summary['fine_controls'].append({'label':label,'phases':[{k:x[k]for k in ['phase','actual_exit','stdout','stderr','executable_sha256','command']}for x in a]})
semantic=[x for x in rows if x['control']in ['plane-whole-public','plane-whole-oracle']];need(len(semantic)==39 and all(x['actual_exit']==0 for x in semantic),'same semantic cases across complete withdrawal')
a=[x for x in allrows if x.get('control')=='indexed-plane-coordinate'];need([x['actual_exit']for x in a]==[0,1,0] and a[1]['stderr']=='ASSERT:indexed-full-coordinate-plane\n','old coordinate mutation remains killed')
summary['old_coordinate_control']=[{k:x[k]for k in ['phase','actual_exit','stdout','stderr','executable_sha256']}for x in a]
snapshots=read(OUT/'wood-contact/observed/native-inputs/compiler-input-snapshots.json')
for row in snapshots:
 if 'actual-contact-included-TU-at-compile'not in row['roles']:continue
 sources=[x for x in row['inputs']if Path(x['original']).name.startswith('contact-plane-')and x['original'].endswith('-source.c')]
 for x in sources:need(sha(Path(x['retained']).read_bytes())==x['sha256'],'real included variant bytes');summary['included_sources'].append(x)
need(len(summary['included_sources'])==8,'eight independently compiled plane variants')
proof=Path('/workspace/geo343-plane-fixture-proof-20261024');pr=read(proof/'RESULT.json');po=read(Path('/workspace/geo343-plane-fixture-proof-launch-20261024/RESULT.json'))
need(pr['source_sha']==po['source_sha']==S and pr['exit']==po['exit']==po['primary_exit']==po['reaper_exit']==0 and pr['source_clean_after'] and pr['fixed_bytes_restored'],'fixture proof terminal/restored')
need([x['actual_exit']for x in pr['phases']]==[0,1,0] and all(x['passed']for x in pr['phases']),'fixture witness true three-phase proof')
summary['fixture_repair_proof']={'actual_outer_exit':0,'original_phase_exits':[0,1,0],'source_restored':True,'exact_failure':'AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate','original_locator':str(proof)}
summary['total_methods']=sum(x['methods']for x in summary['suites']);summary['compile_link_count']=sum(x['compile_link_count']for x in summary['suites']);summary['semantic_cases_across_whole_withdrawal']=39
summary['prior_r1']={'source_sha':'7c4a40a71fe46242c302efaa85f1a4d13df0c19a','actual_exit':1,'wood_passed':13,'wood_failed':1,'remaining_suites':'UNRUN_ENVIRONMENT original100MiB','failure':'AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate','raw_locator':'/workspace/geo343-plane-ranges-formal-20261024'}
(HERE/'ACTUAL_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'methods':summary['total_methods'],'compiles':summary['compile_link_count'],'work':[0,84,0],'fixture':[0,1,0],'exit':0}))
