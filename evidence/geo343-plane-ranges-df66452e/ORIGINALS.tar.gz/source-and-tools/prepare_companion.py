from pathlib import Path
import ast,difflib,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/geometry-axiom')
S='a22df116c7e9f6b7d074451f1c8052d59e7e4f3e'
def sha(x):return hashlib.sha256(x).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((HERE/'MANIFEST.json').read_bytes())
product='geometry-templates/woodworking/native/contact_world.c'
py='tests/test_geo261_wood_contact_world.py';reg='tests/run_all.expected.json';c='tests/geo343_plane_range_harness.c'
before={product:(HERE/'before/contact_world.c').read_bytes()}
for i,name in enumerate((py,reg)):
 argv=['git','-c','gc.auto=0','-c','maintenance.auto=false','show',S+':'+name]
 d=HERE/'companion-source-reads'/str(i)
 assert json.loads((d/'result.json').read_bytes())=={'argv':argv,'cwd':str(ROOT),'exit':0}
 before[name]=(d/'stdout').read_bytes()
old=before[py].decode();new=old
anchor='size_t begin,end;contact_face_plane_range(index,out,count,face->fixed,&begin,&end);'
assert new.count(anchor)==2
new=new.replace(anchor,'size_t begin,end;contact_face_index_bounds(index,ordinal,&begin,&end);')
constant='PLANE_RANGE_EDITS = '+repr(tuple((x['before'],x['after'])for x in manifest['edits']))+'\n\n'
assert new.count('class WoodContactWorld(')==1
new=new.replace('class WoodContactWorld(',constant+'class WoodContactWorld(')
new=new.replace('    def extension_transaction(self, executable):',(HERE/'companion_methods.py.txt').read_text()+'    def extension_transaction(self, executable):')
tree=ast.parse(new);oldtree=ast.parse(old)
olddefs={x.name:ast.dump(x,include_attributes=False)for x in ast.walk(oldtree)if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
newdefs={x.name:ast.dump(x,include_attributes=False)for x in ast.walk(tree)if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert all(newdefs[k]==v for k,v in olddefs.items())
regold=before[reg].decode();regnew=regold.replace('"py:test_geo261_wood_contact_world": {\n      "mode": "count",\n      "count": 13,','"py:test_geo261_wood_contact_world": {\n      "mode": "count",\n      "count": 14,')
assert regold!=regnew
a=json.loads(regold);b=json.loads(regnew)
key=next(k for k,v in a.items()if isinstance(v,dict)and 'py:test_geo261_wood_contact_world' in v)
assert a[key]['py:test_geo261_wood_contact_world']['count']==13 and b[key]['py:test_geo261_wood_contact_world']['count']==14
candidate={product:(HERE/'candidate/contact_world.c').read_bytes(),py:new.encode(),reg:regnew.encode(),c:(HERE/'plane_harness.c').read_bytes()}
patch=''
for name,body in candidate.items():
 p=HERE/'candidate'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 if name in before:
  p=HERE/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before[name])
 patch+=''.join(difflib.unified_diff(before.get(name,b'').decode().splitlines(True),body.decode().splitlines(True),fromfile='a/'+name if name in before else '/dev/null',tofile='b/'+name))
(HERE/'FOUR_LEAF.patch').write_text(patch)
result={'source_sha':S,'files':{n:sha(b)for n,b in candidate.items()},'four_leaf_patch_sha256':sha(patch.encode()),'old_definitions_unchanged':len(olddefs),'old_controls_change':'Only indexed-reversed-skip anchor spelling; original inserted guard/case/assertion unchanged','registry':'wood contact 13 -> 14 only','original_timeouts_preserved':True,'whole_withdrawal':'all five exact edits -> original R; full public cases and independent linear oracle identical; only work assertion expects1','compiled':False,'C_executed':False}
dump(HERE/'COMPANION_MANIFEST.json',result);print(json.dumps(result))
