from pathlib import Path
import hashlib
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
s=(HERE/'launch_formal_r2.py').read_text();assert sha(s.encode())=='71fdd94df5a63ab03a9a36207596b0ce4fe268ef1f41da96aaeb0d5dc667ec36'
s=s.replace('geo343-plane-ranges-formal-r2-launch-20261024','geo343-plane-fixture-proof-launch-20261024').replace("DRIVER=HERE/'run_formal_r2.py'","DRIVER=HERE/'run_fixture_proof.py'").replace('83c90ea367e13852ba3a85a0bf093121497eb4c1b21b04b4e1744111f1c3fd0e',sha((HERE/'run_fixture_proof.py').read_bytes()))
(HERE/'launch_fixture_proof.py').write_text(s);print(sha(s.encode()))
