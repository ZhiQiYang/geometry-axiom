from pathlib import Path
import difflib,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent;NEW=HERE/'v2';ROOT=Path('/workspace/geometry-axiom')
def sha(b):return hashlib.sha256(b).hexdigest()
NEW.mkdir(exist_ok=False);m=json.loads((HERE/'COMPANION_MANIFEST.json').read_bytes());leaf='tests/geo261_contact_world_harness.c'
cmd=['git','-c','gc.auto=0','-c','maintenance.auto=false','show',m['source_sha']+':'+leaf]
r=subprocess.run(cmd,cwd=ROOT,capture_output=True);(NEW/'source.stdout').write_bytes(r.stdout);(NEW/'source.stderr').write_bytes(r.stderr)
(NEW/'source-result.json').write_text(json.dumps({'argv':cmd,'cwd':str(ROOT),'exit':r.returncode},indent=2)+'\n');assert r.returncode==0
old=r.stdout.decode();anchor='    CHECK("indexed-full-coordinate-plane",n==4&&sides(out,n,51)==2&&sides(out,n,52)==2&&out[2].fixed==INT64_C(4294967296));\n'
new=anchor+'''    /* A later face on the first plane must remain in the same full-width
     * group even with an intervening plane whose low 32 bits are equal. */
    w.member_count=3;n=wood_contact_collect_stops(&w,false,NULL,out,8);
    CHECK("indexed-full-coordinate-plane",n==4&&sides(out,n,51)==2&&sides(out,n,52)==2&&sides(out,n,53)==0);
'''
assert old.count(anchor)==1;body=old.replace(anchor,new).encode();before={};candidate={}
for n in m['files']:
 p=HERE/'before'/n
 if p.exists():before[n]=p.read_bytes()
 candidate[n]=(HERE/'candidate'/n).read_bytes()
before[leaf]=r.stdout;candidate[leaf]=body;patch=''
for n,b in candidate.items():
 p=NEW/'candidate'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 if n in before:p=NEW/'before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before[n])
 patch+=''.join(difflib.unified_diff(before.get(n,b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+n if n in before else '/dev/null',tofile='b/'+n))
(NEW/'FIVE_LEAF.patch').write_text(patch)
m.update(files={n:sha(b)for n,b in candidate.items()},five_leaf_patch_sha256=sha(patch.encode()),new_control_witness='Keep original two-member assertion; add same marker for nonadjacent full-width group and later redundant member',previous_patch=m.pop('four_leaf_patch_sha256'))
(NEW/'COMPANION_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
(NEW/'EXACT_TEST_FIX.json').write_text(json.dumps({'leaf':leaf,'before':old,'after':body.decode(),'delta_before':anchor,'delta_after':new,'original_7c4_witness_gap':'indexed-plane-coordinate mutant exited0; original assertion expected1','withdrawal_expected':'original old control survived assertion; no product/threshold change'},indent=2)+'\n')
print(json.dumps({'five_leaf_patch_sha256':sha(patch.encode()),'test_harness_sha256':sha(body)}))
