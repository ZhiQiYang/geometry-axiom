# 平面群查詢後續（#338／#343）

產品來源 R：`a22df116c7e9f6b7d074451f1c8052d59e7e4f3e`。
目前公開來源 F：`df66452e7a514032453bea93b8b18ab74d7b1457`，分支 `codex/train337-plane-ranges-20261024`。

R5 的原 N64/main 比例 `1.3369644933292553 > 1.3` 保留為紅燈，沒有重抽樣。排序查詢已減少，但原 profile 仍有 1,124,276 次平面範圍二分查詢。本修改把已排序群的邊界存在既有 scratch 中；不增陣列或堆疊、不改公開順序、接觸語意或時限。

第一次正式來源 `7c4a40a71fe46242c302efaa85f1a4d13df0c19a`：wood 13/14 綠，唯一失敗是原 `indexed-plane-coordinate` 突變未被原兩成員場景捕捉，精確 assertion 為 `AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate`。新的 exact 平面群隔開兩種完整座標，舊反例不足；這不是編譯錯誤或 timeout。其餘兩套件因原 100 MiB 空間守門標為 `UNRUN_ENVIRONMENT`，第一次整批原 exit=1。

F 只追加第三個同第一平面、排序較晚的成員，保留原所有案例與 assertion，並用同一具名 assertion 驗證它必須被去重。錯誤 32 位元排序會把相同完整平面切成兩群並留下該成員。原五處產品修改未再更動。

第一輪新增完整撤回的真工作量：16 個 face，insert 區間的 plane comparator 呼叫為 0／84／0；正常退出碼為 0／1／0，撤回精確首紅 `ASSERT:plane-cached-query-no-plane-search`。五個細控制均為正常 assertion 1。以上是第一輪歷史來源實績，不冒稱 F 正式已跑。

F 的 14／15／7 三套原裁判工具已固定；保原 wood 20 秒、sources 30 秒、reading A 20 秒、compile 300 秒與 100 MiB 守門。等待可用空間期間持續準備收據與對抗審查；未啟動 F 正式前不標綠。完整 native／六 browser、帳本、架構與新的正式 wall ratio 尚未完成，不標 READY。
