from pathlib import Path
import hashlib
HERE=Path(__file__).resolve().parent
source=Path('/workspace/geo343-monotonic-sort-draft-20261024/collect_originals.py').read_text()
start=source.index('roots=');end=source.index('\ndef sha(',start)
roots="""roots={
 'formal':R,'outer':L,'source-and-tools':HERE,
 'prior-red-formal':Path('/workspace/geo343-plane-ranges-formal-20261024'),
 'prior-red-outer':Path('/workspace/geo343-plane-ranges-formal-launch-20261024'),
 'fixture-proof':Path('/workspace/geo343-plane-fixture-proof-20261024'),
 'fixture-proof-outer':Path('/workspace/geo343-plane-fixture-proof-launch-20261024'),
 'fixture-proof-observer':Path('/workspace/geo343-plane-fixture-proof-tools-20261024/observer'),
 'bound-observer':Path('/workspace/geo343-plane-ranges-formal-tools-20261024/observer'),
 'product-peer':Path('/workspace/geo343-plane-range-product-peer-evidence-20261024'),
 'companion-peer':Path('/workspace/geo343-plane-range-peer-backlog-20261024'),
 'formal-and-actual-peer':Path('/workspace/geo343-plane-wrapper-peer-specials-20261024')}
"""
s=source[:start]+roots+source[end:]
s=s.replace("S='aa16e73d6e1f2965e0a911581e2a545aaaf66870'","S='df66452e7a514032453bea93b8b18ab74d7b1457'")
s=s.replace('/workspace/geo343-monotonic-formal-20261024','/workspace/geo343-plane-ranges-formal-r2-20261024').replace('/workspace/geo343-monotonic-formal-launch-20261024','/workspace/geo343-plane-ranges-formal-r2-launch-20261024').replace('/workspace/geo343-monotonic-evidence-package-20261024','/workspace/geo343-plane-ranges-evidence-package-20261024')
start=s.index(" for name in ['GEO343_MONOTONIC");end=s.index(" for name,path in",start);s=s[:start]+s[end:]
s=s.replace('Original35-method targeted acceptance','Original36-method targeted acceptance')
s=s.replace('Original publication R1 ignored-parent add exit1 is retained; R2 normal commit/push439 child commands exit0.','Prior source7c4 formal red and both environment-unrun suites are retained; Fdf664 source repair and complete original36-method acceptance plus test-witness0/1/0 are distinct.')
(HERE/'collect_originals.py').write_text(s);print(hashlib.sha256(s.encode()).hexdigest())
