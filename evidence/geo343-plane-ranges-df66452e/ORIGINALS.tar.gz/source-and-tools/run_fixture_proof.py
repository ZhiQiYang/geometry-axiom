"""Withdraw only the new C witness; preserve the original selected unittest."""
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,resource,shutil,sys,traceback
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/geo343-plane-ranges-work-20261024')
OUT=Path('/workspace/geo343-plane-fixture-proof-20261024');TMP=Path('/workspace/geo343-plane-fixture-proof-tmp-20261024')
OBS=Path('/workspace/geo343-plane-fixture-proof-tools-20261024/observer');CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
S='df66452e7a514032453bea93b8b18ab74d7b1457';LEAF='tests/geo261_contact_world_harness.c'
TARGET='tests.test_geo261_wood_contact_world.WoodContactWorld.test_actual_guard_controls_fail_the_named_numeric_assertions'
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def read(p):return json.loads(p.read_bytes())
def main():
 need(not OUT.exists() and not TMP.exists(),'fresh original proof roots')
 need(shutil.disk_usage('/workspace').free>=100*1024*1024,'original100MiB guard')
 manifest_path=HERE/'source-publication-r2/SOURCE_MANIFEST.json';need(sha(manifest_path.read_bytes())=='745b34f388365ee939de995bbc5c94212d7f48c1efd3c1665ddb1ad03826a4a1','fixed source manifest');manifest=read(manifest_path)
 need(manifest['source_sha']==S,'exact source');fixpath=HERE/'v2/EXACT_TEST_FIX.json';need(sha(fixpath.read_bytes())=='847837110ed6f5f73371fdc24a2ebdd55952a24e157d2b11a7483508195fe251','exact four-line witness delta')
 fix=read(fixpath);fixed=fix['after'].encode();withdrawn=fix['before'].encode()
 need(fix['leaf']==LEAF and fixed.count(fix['delta_after'].encode())==1,'single fixed witness');need(fixed.replace(fix['delta_after'].encode(),fix['delta_before'].encode())==withdrawn,'withdraw exactly new witness')
 need(withdrawn.replace(fix['delta_before'].encode(),fix['delta_after'].encode())==fixed,'restore exact original fixed bytes')
 need((ROOT/LEAF).read_bytes()==fixed,'fixed source before any mutation')
 need(sha((OBS/'TOOL_PINS.json').read_bytes())=='4cb7637ffcf7bb329872436efe39a29399fb9f7a6f9798e98e6760adf333fdbb','narrow proof observer')
 for item in read(OBS/'TOOL_PINS.json')['tools']:need(sha((OBS/item['name']).read_bytes())==item['bound_sha256'],'frozen observer '+item['name'])
 need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original recorder')
 lock=Path('/tmp/g261r3/heavy.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 OUT.mkdir();TMP.mkdir();stack=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,stack[1]))
 strip={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
 env={k:v for k,v in os.environ.items()if k not in strip and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))};env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LANG='C.UTF-8',LC_ALL='C.UTF-8')
 spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT,env,S)
 report={'source_sha':S,'root':str(ROOT),'phases':[],'errors':[],'exit':None,'scope':'Only four-line test witness withdrawal; product fixed, all original selected controls and assertions run unchanged.'}
 def git(*args):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=ROOT)[1]
 def clean():
  need(git('rev-parse','HEAD').decode().strip()==S,'fixed HEAD');need(git('status','--porcelain=v1','--untracked-files=all')==b'','restored clean source')
  for name,pin in manifest['files'].items():need(sha((ROOT/name).read_bytes())==pin,'fixed closure '+name)
 try:
  rec.run(['df','-B1','/workspace','/tmp'],cwd=ROOT);clean()
  for phase,body,expected in [('fixed',fixed,0),('withdrawn',withdrawn,1),('restored',fixed,0)]:
   if shutil.disk_usage('/workspace').free<100*1024*1024:report['phases'].append({'phase':phase,'state':'UNRUN_ENVIRONMENT','passed':False});continue
   clean();where=OUT/phase;where.mkdir();(ROOT/LEAF).write_bytes(body)
   files=dict(manifest['files']);files[LEAF]=sha(body);phase_manifest={'source_sha':S,'source_variant':phase,'files':files};dump(where/'manifest.json',phase_manifest)
   env.update(GEO299316_EXECUTION_LOG=str(where/'native-executions.jsonl'))
   try:
    row,stdout,stderr=rec.run([sys.executable,'-B',str(OBS/'run_observed_original.py'),'--root',str(ROOT),'--sha',S,'--out',str(where/'observed'),'--manifest',str(where/'manifest.json'),'--','-m','unittest','-v',TARGET],cwd=ROOT,timeout=None,check=False)
    entry=read(where/'observed/ORIGINAL_ENTRY.json');observation=read(where/'observed/OBSERVATION.json')
    complete=entry['observer_complete'] is True and observation['observer_complete'] is True and entry['original_completed'] is True and entry['original_exit']==row['actual_process_returncode'] and entry['source_files_before']==entry['source_files_after']==files
    named=(b'Ran 1 test in 'in stderr and (b'FAILED (failures=1)'in stderr and b'AssertionError: 1 != 0 : Guard survived: indexed-plane-coordinate'in stderr if expected else b'\nOK\n'in stderr))
    result={'phase':phase,'state':'COMPLETED','source_sha':S,'source_variant':phase,'expected_exit':expected,'actual_exit':row['actual_process_returncode'],'observation_complete':complete,'named_original_verdict':named,'passed':complete and named and row['actual_process_returncode']==expected,'command':row}
    report['phases'].append(result);dump(where/'RESULT.json',result);print(json.dumps({'phase':phase,'exit':result['actual_exit'],'passed':result['passed']}),flush=True)
   finally:(ROOT/LEAF).write_bytes(fixed)
   clean();dump(OUT/'PROGRESS.json',report)
  clean();report['source_clean_after']=True;report['exit']=0 if len(report['phases'])==3 and all(x['passed']for x in report['phases'])else 1
 except BaseException:report['errors'].append(traceback.format_exc());report['exit']=1
 finally:
  (ROOT/LEAF).write_bytes(fixed);report['fixed_bytes_restored']=(ROOT/LEAF).read_bytes()==fixed;dump(OUT/'RESULT.json',report);fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
 return report['exit']
if __name__=='__main__':sys.exit(main())
