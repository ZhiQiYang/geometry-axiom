from pathlib import Path
import hashlib,json,difflib
HERE=Path(__file__).resolve().parent;OLD=Path('/workspace/geo343-monotonic-sort-draft-20261024')
OBSOLD=Path('/workspace/geo343-monotonic-formal-tools-20261024/observer')
OBS=Path('/workspace/geo343-plane-ranges-formal-tools-20261024/observer')
def sha(b):return hashlib.sha256(b).hexdigest()
pub=json.loads((HERE/'source-publication/RESULT.json').read_bytes());assert pub['exit']==0 and pub['pushed'] is True
S=pub['source_sha'];manifest=HERE/'source-publication/SOURCE_MANIFEST.json'
pins=json.loads((OBSOLD/'TOOL_PINS.json').read_bytes());assert sha((OBSOLD/'TOOL_PINS.json').read_bytes())=='5107e0020a8a35213a560e50c79a61e87d4e79254f0ef3078e72a9eafe8093f7'
OBS.mkdir(parents=True,exist_ok=False);changes=[]
for item in pins['tools']:
 name=item['name'];body=(OBSOLD/name).read_bytes();assert sha(body)==item['bound_sha256'];s=body.decode()
 if name=='retain_native_inputs.py':
  a="source.name.startswith('contact-monotonic-')";b="source.name.startswith(('contact-monotonic-','contact-plane-'))"
  assert s.count(a)==1;s=s.replace(a,b)
  a='(contact-monotonic-[^"/]+-source\\.c)';b='(contact-(?:monotonic|plane)-[^"/]+-source\\.c)'
  assert s.count(a)==1;s=s.replace(a,b)
  s=s.replace('One actual monotonic included subject required','One actual contact included subject required').replace('actual-monotonic-included-TU-at-compile','actual-contact-included-TU-at-compile')
 (OBS/name).write_text(s);changes.append({'name':name,'original_sha256':sha(body),'bound_sha256':sha(s.encode())})
 if s.encode()!=body:(OBS/(name+'.diff')).write_text(''.join(difflib.unified_diff(body.decode().splitlines(True),s.splitlines(True),fromfile='old/'+name,tofile='new/'+name)))
(OBS/'TOOL_PINS.json').write_text(json.dumps({'original_toolpins':sha((OBSOLD/'TOOL_PINS.json').read_bytes()),'tools':changes},indent=2)+'\n')
s=(OLD/'run_formal.py').read_text();assert sha(s.encode())=='ea1ad8a0c0bab9f39f56017bf52355a786be33a1ed7dd04f9852eeb710b942ef'
s=s.replace("PUB=HERE/'source-publication-r2'","PUB=HERE/'source-publication'")
s=s.replace('geo343-monotonic-','geo343-plane-ranges-')
s=s.replace("'tests/test_geo261_wood_contact_world.py',13","'tests/test_geo261_wood_contact_world.py',14")
s=s.replace('aa16e73d6e1f2965e0a911581e2a545aaaf66870',S)
s=s.replace('1b2216ea8ab7bf123caf36bd36cec251100a3bb66bc45ee4324862455ba3b933',sha(manifest.read_bytes()))
s=s.replace('5107e0020a8a35213a560e50c79a61e87d4e79254f0ef3078e72a9eafe8093f7',sha((OBS/'TOOL_PINS.json').read_bytes()))
(HERE/'run_formal.py').write_text(s);driver=sha(s.encode())
s=(OLD/'launch_formal.py').read_text();s=s.replace('geo343-monotonic-','geo343-plane-ranges-').replace('source-publication-r2/RESULT.json','source-publication/RESULT.json').replace('ea1ad8a0c0bab9f39f56017bf52355a786be33a1ed7dd04f9852eeb710b942ef',driver)
(HERE/'launch_formal.py').write_text(s)
print(json.dumps({'source':S,'manifest':sha(manifest.read_bytes()),'driver':driver,'launcher':sha(s.encode()),'observer':sha((OBS/'TOOL_PINS.json').read_bytes())}))
