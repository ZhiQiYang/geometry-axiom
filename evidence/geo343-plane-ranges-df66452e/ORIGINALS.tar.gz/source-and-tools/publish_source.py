"""Publish reviewed four-leaf monotonic change on an isolated ordinary branch."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,re,shutil,subprocess,sys,traceback
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/geometry-axiom');WORK=Path('/workspace/geo343-plane-ranges-work-20261024')
BASE='a22df116c7e9f6b7d074451f1c8052d59e7e4f3e';BRANCH='codex/train337-plane-ranges-20261024'
OUT=HERE/'source-publication';PATCH='97918ee90787be5ca5dc698769203fa9be0febbbd82ad5c467fcc705a3d534ea'
report={'source_parent':BASE,'branch':BRANCH,'worktree':str(WORK),'commands':[],'source_sha':None,'pushed':False,'C_executed':False,'exit':None}
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def run(args,cwd=ROOT,data=None,allowed=(0,)):
 command=['git','-c','gc.auto=0','-c','maintenance.auto=false',*args];env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(command,cwd=cwd,input=data,capture_output=True,env=env)
 folder=OUT/'commands'/('%03d'%(len(report['commands'])+1));folder.mkdir(parents=True)
 (folder/'stdout').write_bytes(p.stdout);(folder/'stderr').write_bytes(p.stderr)
 row={'argv':command,'cwd':str(cwd),'started_utc':start,'exit':p.returncode,'stdout':{'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'bytes':len(p.stderr),'sha256':sha(p.stderr)}}
 if data is not None:(folder/'stdin').write_bytes(data);row['stdin']={'bytes':len(data),'sha256':sha(data)}
 dump(folder/'result.json',row);report['commands'].append(row);need(p.returncode in allowed,'original Git failure '+str(folder));return p.stdout
def git(*args,cwd=ROOT):return run(list(args),cwd)
def private(name):
 p=Path(git('rev-parse','--git-path',name,cwd=WORK).decode().strip());return p if p.is_absolute() else WORK/p
def clean():
 need(git('status','--porcelain=v1','--untracked-files=all',cwd=WORK)==b'','own source clean')
 need(git('diff','--cached','HEAD','--name-only',cwd=WORK)==b'','index equals HEAD')
def main():
 OUT.mkdir(exist_ok=False)
 try:
  report['free_before']=shutil.disk_usage('/workspace').free;need(report['free_before']>=100*1024*1024,'original100MiB guard')
  need(not WORK.exists(),'fresh owned worktree');need(git('config','--get','extensions.worktreeConfig').strip()==b'true','worktree-specific config')
  need(git('rev-parse',BASE+'^{commit}').decode().strip()==BASE,'fixed U object')
  need(git('for-each-ref','--format=%(refname)','refs/heads/'+BRANCH)==b'','fresh own branch')
  need(git('ls-remote','--heads','origin','refs/heads/'+BRANCH)==b'','fresh remote branch')
  need(sha((HERE/'COMPANION_MANIFEST.json').read_bytes())=='b50d249c14507f1454b607d5c9f8fc04a71019e2f767e9ac6c1d90f5ef62c47a','frozen reviewed companion manifest')
  manifest=json.loads((HERE/'COMPANION_MANIFEST.json').read_bytes());need(sha((HERE/'FOUR_LEAF.patch').read_bytes())==PATCH,'reviewed patch frozen')
  allow=sorted(manifest['files']);bodies={};need(allow==['geometry-templates/woodworking/native/contact_world.c', 'tests/geo343_plane_range_harness.c', 'tests/run_all.expected.json', 'tests/test_geo261_wood_contact_world.py'],'fixed four leaves')
  for name,pin in manifest['files'].items():
   need(sha((HERE/'candidate'/name).read_bytes())==pin,'reviewed candidate '+name)
   if (HERE/'before'/name).exists():need(git('show',BASE+':'+name)==(HERE/'before'/name).read_bytes(),'reviewed U '+name)
  seed={'.gitattributes','.gitignore','AGENTS.md','room_a.scene','tests/__init__.py','tests/_bridge.py','tests/_unittest_runner.py','tests/binaries.py','tests/test_geo261_native_kernel.py','tests/test_engineering_json.py','tests/test_geo261_wood_contacts.py','tests/test_geo261_wood_contact_world.py','tests/test_geo261_contact_sources.py','tests/test_geo318_reading_a_native.py','tests/geo261_exact_harness.c','tests/geo343_monotonic_sort_harness.c','tests/geo261_contact_world_harness.c','tests/geo261_contact_sources_harness.c','tests/geo261_contact_pose_product_harness.c','tests/geo318_boundary_ends_harness.c','tests/geo318_host_boundary_ends_harness.c','geometry-core/domain-decoupling/product-architecture.json','tests/run_all.expected.json','current_geometry.c','geometry-web/web_bridge.c'}
  listing=git('ls-tree','-r','--name-only',BASE,'--','geometry-core/kernel','geometry-app/native','geometry-templates/woodworking/native')
  seed.update(n for n in listing.decode().splitlines() if n.endswith(('.c','.h','.inc')))
  architecture=json.loads(git('show',BASE+':geometry-core/domain-decoupling/product-architecture.json'))
  seed.update(x['path'] for x in architecture['sources'] if x['language']=='c')
  pending=sorted(seed);unresolved=[]
  def norm(parent,literal):
   parts=[]
   for part in (PurePosixPath(parent)/literal).parts:
    if part=='..':need(bool(parts),'include escapes root');parts.pop()
    elif part!='.':parts.append(part)
   return '/'.join(parts)
  while pending:
   name=pending.pop()
   if name in bodies:continue
   body=git('show',BASE+':'+name);bodies[name]=body
   if name.endswith(('.c','.h','.inc')):
    for match in re.findall(rb'^\s*#\s*include\s*"([^"]+)"',body,re.M):
     literal=match.decode();candidates=[norm(str(PurePosixPath(name).parent),literal),literal,norm('geometry-core/kernel',literal)]
     chosen=None
     for candidate in dict.fromkeys(candidates):
      if candidate in bodies or candidate in pending:chosen=candidate;break
      raw=run(['cat-file','-e',BASE+':'+candidate],allowed=(0,128));row=report['commands'][-1]
      if row['exit']==0:chosen=candidate;pending.append(candidate);break
     if chosen is None:unresolved.append({'including':name,'literal':literal,'candidates':candidates})
  paths=sorted(set(bodies)|set(allow));patterns=''.join('/'+n+'\n' for n in paths).encode();(OUT/'SPARSE_STDIN.txt').write_bytes(patterns)
  git('worktree','add','--no-checkout','-b',BRANCH,str(WORK),BASE)
  need(sorted(p.name for p in WORK.iterdir())==['.git'],'fresh empty checkout')
  need(not private('index').exists(),'fresh missing index')
  run(['sparse-checkout','set','--no-cone','--stdin'],cwd=WORK,data=patterns)
  need(private('info/sparse-checkout').read_bytes()==patterns,'exact private patterns');need(not private('index').exists(),'original no-checkout bootstrap')
  git('read-tree','--dry-run','-m','-u',BASE,cwd=WORK);git('read-tree','-m','-u',BASE,cwd=WORK);clean()
  for name,body in bodies.items():need((WORK/name).read_bytes()==body,'materialized U bytes '+name)
  for name in allow:
   path=WORK/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((HERE/'candidate'/name).read_bytes())
  need(sorted(git('diff','--name-only',cwd=WORK).decode().splitlines())==sorted(n for n in allow if n in bodies),'exact tracked change allowlist')
  need(not private('index.lock').exists(),'no concurrent index writer')
  git('diff','--check',cwd=WORK);git('add','-f','--sparse','--',*allow,cwd=WORK)
  need(sorted(git('diff','--cached','--name-only',cwd=WORK).decode().splitlines())==allow,'exact four staged leaves')
  git('diff','--cached','--check',cwd=WORK);git('commit','-m','Reuse sorted plane boundaries during contact deduplication',cwd=WORK)
  source=git('rev-parse','HEAD',cwd=WORK).decode().strip();report['source_sha']=source
  need(git('show','-s','--format=%P',source,cwd=WORK).decode().strip()==BASE,'ordinary U parent');clean()
  files={}
  for name in paths:
   body=(WORK/name).read_bytes();expected=(HERE/'candidate'/name).read_bytes() if name in allow else bodies[name]
   need(body==expected,'fixed final closure '+name);need(git('show',source+':'+name,cwd=WORK)==body,'committed final closure '+name)
   files[name]=sha(body)
  dump(OUT/'SOURCE_MANIFEST.json',{'source_sha':source,'source_variant':'fixed','files':files,'unresolved_quotes':unresolved,'closure_bytes':sum((WORK/n).stat().st_size for n in paths)})
  git('push','origin','HEAD:refs/heads/'+BRANCH,cwd=WORK)
  need(git('ls-remote','--heads','origin','refs/heads/'+BRANCH,cwd=WORK).decode().split()[0]==source,'remote resolves source')
  report['pushed']=True;report['exit']=0;report['free_after']=shutil.disk_usage('/workspace').free
 except BaseException:report['error']=traceback.format_exc();report['exit']=1
 finally:dump(OUT/'RESULT.json',report);print(json.dumps({k:report.get(k)for k in ['source_sha','pushed','exit','error']}),flush=True)
 return report['exit']
if __name__=='__main__':sys.exit(main())
