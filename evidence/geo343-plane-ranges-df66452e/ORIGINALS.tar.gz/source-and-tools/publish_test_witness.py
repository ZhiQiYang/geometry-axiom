from pathlib import Path
import hashlib,importlib.util,json,shutil,sys,traceback
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source_publisher',HERE/'publish_source.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.OUT=HERE/'source-publication-r2';PARENT='7c4a40a71fe46242c302efaa85f1a4d13df0c19a';LEAF='tests/geo261_contact_world_harness.c'
PIN='a37db07b493ce9b137e8f49b7e896a9c5c9aceaad728f14ef697bcbd345838fb'
def main():
 p.OUT.mkdir(exist_ok=False)
 try:
  p.report['source_parent']=PARENT;p.report['publication_min_free_bytes']=16*1024*1024;p.report['free_before']=shutil.disk_usage('/workspace').free
  p.need(p.report['free_before']>=16*1024*1024,'single-leaf publication index/objects budget; formal100MiB unchanged')
  p.need(p.git('rev-parse','HEAD',cwd=p.WORK).decode().strip()==PARENT,'exact original source parent');p.clean()
  p.need(p.git('symbolic-ref','--short','HEAD',cwd=p.WORK).decode().strip()==p.BRANCH,'own branch')
  p.need(p.git('ls-remote','--heads','origin','refs/heads/'+p.BRANCH,cwd=p.WORK).decode().split()[0]==PARENT,'published original source')
  p.need(not p.private('index.lock').exists(),'no concurrent index writer')
  candidate=(HERE/'v2/candidate'/LEAF).read_bytes();p.need(p.sha(candidate)==PIN,'frozen new witness')
  before=(HERE/'v2/before'/LEAF).read_bytes();p.need(p.git('show',PARENT+':'+LEAF,cwd=p.WORK)==before==(p.WORK/LEAF).read_bytes(),'unchanged old fixture')
  (p.WORK/LEAF).write_bytes(candidate)
  p.need(p.git('diff','--name-only',cwd=p.WORK).decode().splitlines()==[LEAF],'one test fixture only')
  p.git('diff','--check',cwd=p.WORK);p.git('add','-f','--sparse','--',LEAF,cwd=p.WORK)
  p.need(p.git('diff','--cached','--name-only',cwd=p.WORK).decode().splitlines()==[LEAF],'exact single staged leaf')
  p.need(p.git('show',':'+LEAF,cwd=p.WORK)==candidate,'staged exact witness');p.git('diff','--cached','--check',cwd=p.WORK)
  p.git('commit','-m','Preserve full-coordinate mutation coverage for cached plane groups',cwd=p.WORK)
  S=p.git('rev-parse','HEAD',cwd=p.WORK).decode().strip();p.report['source_sha']=S
  p.need(p.git('show','-s','--format=%P',S,cwd=p.WORK).decode().strip()==PARENT,'ordinary parent');p.clean()
  manifest=json.loads((HERE/'source-publication/SOURCE_MANIFEST.json').read_bytes());manifest['source_sha']=S;manifest['files'][LEAF]=PIN
  manifest['closure_bytes']=sum((p.WORK/n).stat().st_size for n in manifest['files'])
  for n,h in manifest['files'].items():p.need(p.sha((p.WORK/n).read_bytes())==h,'exact unchanged closure '+n)
  p.dump(p.OUT/'SOURCE_MANIFEST.json',manifest)
  p.git('push','origin','HEAD:refs/heads/'+p.BRANCH,cwd=p.WORK)
  p.need(p.git('ls-remote','--heads','origin','refs/heads/'+p.BRANCH,cwd=p.WORK).decode().split()[0]==S,'remote new source')
  p.report.update(pushed=True,exit=0,free_after=shutil.disk_usage('/workspace').free)
 except BaseException:p.report.update(exit=1,error=traceback.format_exc())
 finally:p.dump(p.OUT/'RESULT.json',p.report);print(json.dumps({k:p.report.get(k)for k in ['source_sha','pushed','exit','error']}),flush=True)
 return p.report['exit']
if __name__=='__main__':sys.exit(main())
