from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/geo343-monotonic-sort-draft-20261024/publish_source.py')
def sha(b):return hashlib.sha256(b).hexdigest()
s=OLD.read_text();assert sha(s.encode())=='94ab689850558cdf084de4454333a5a69fb2c5312397fc13501b9bd163aae4db'
m=json.loads((HERE/'COMPANION_MANIFEST.json').read_bytes())
for a,b in [
 ('geo343-monotonic-work-20261024','geo343-plane-ranges-work-20261024'),
 ('ca7838e0f4950452b9befcf40899d606db9b81fa',m['source_sha']),
 ('codex/train337-monotonic-sort-20261024','codex/train337-plane-ranges-20261024'),
 ('746a58a5f3b16182fad4e8c5338d56ad64472ae1178670e76cb6cb6c6aebd20d',m['four_leaf_patch_sha256']),
 ("git('add','--sparse','--',*allow,cwd=WORK)","git('add','-f','--sparse','--',*allow,cwd=WORK)"),
 ('Skip redundant member sorting while preserving stable face order','Reuse sorted plane boundaries during contact deduplication'),
 ("'tests/geo261_contact_world_harness.c'","'tests/geo343_monotonic_sort_harness.c','tests/geo261_contact_world_harness.c'"),
 ]:
 assert a in s,a;s=s.replace(a,b)
old="  manifest=json.loads((HERE/'COMPANION_MANIFEST.json').read_bytes());"
new="  need(sha((HERE/'COMPANION_MANIFEST.json').read_bytes())=="+repr(sha((HERE/'COMPANION_MANIFEST.json').read_bytes()))+",'frozen reviewed companion manifest')\n"+old
assert s.count(old)==1;s=s.replace(old,new)
old='  allow=sorted(manifest[\'files\']);bodies={}'
new=old+";need(allow=="+repr(sorted(m['files']))+",'fixed four leaves')"
assert s.count(old)==1;s=s.replace(old,new)
old="  git('diff','--check',cwd=WORK);git('add'"
new="  need(not private('index.lock').exists(),'no concurrent index writer')\n"+old
assert s.count(old)==1;s=s.replace(old,new)
(HERE/'publish_source.py').write_text(s)
print(json.dumps({'publisher_sha256':sha(s.encode()),'manifest_sha256':sha((HERE/'COMPANION_MANIFEST.json').read_bytes()),'patch_sha256':m['four_leaf_patch_sha256']}))
