# reference_member_footprint 兩個獨立小候選（靜態證明，未編譯／執行）

基線是準備時實際 dirty root H bytes，HEAD `293fae31806eb33f456bac9f87217ffb38b6a689`。不是以 551 的乾淨 H 覆蓋現有 rawsnapshot 工作。`baseline-H-diff.stdout`、四份完整來源與函式 exact slices、`candidate.json` 保存此基線。準備工具只寫 repo 外，最後確認 root H bytes 完全未變。

## 可分開審查／套用

- `exists-guard.patch`：只讓 noncurrent 路徑用 K store 的存在查詢，保留 current 路徑完整 raw placement compose。
- `narrow-only.patch`：只把本函式唯一使用 `placement_id` 的 W 完整 anchor 讀取改成已有的 canonical contact view。
- `narrow-after-exists.patch`：第二小候選以第一個已套用為基線，可依序套用。
- `combined.patch`：兩者合併，對準備時實際 dirty H 基線。

這四個 patch 都只改 `reference_member_footprint()`。其他函式與當時既有 rawsnapshot dirty edits 逐 bytes 保留。不要先套 `exists-guard.patch` 再強套相對原基線的 `narrow-only.patch`；兩者 context 相近，應使用 `narrow-after-exists.patch` 或一次套 combined。

## A：存在 guard 的等價範圍

原 `app_placement_read()` 的流程是 `geo_placements_count/at` 找第一個 matching ID，再 `app_placement_at()` 組合到 caller-owned local `PlacementSurface`。後者只讀 K placement、H metadata、W policy，呼叫 `app_boundary_compose()` 寫 local components。這條路徑沒有：

- source describe/evaluate callback；
- allocation／free；
- World／store／policy 寫入；
- error buffer／log／外部 I/O；
- 對 caller 的 `GeoRect2 *out` 寫入。

noncurrent 原本組出的 `placement` 在接下來整段完全未使用；投影使用的真實 frame 是後面的 `reference_placement_frame(ctx,placement_id,&frame)`，不能拿 raw frame 替代。新 guard 只省略這個無輸出用途的 compose，不移除 `reference_placement_frame` 或任何 canonical dependency。

| 條件 | 原路徑 | 新路徑 | 可觀察結果 |
|---|---|---|---|
| timber index 不存在 | 第一個 `||` 短路 | 第一個獨立 guard 短路 | false、無 source callback、`out` 不變 |
| current=true，placement 不存在 | raw read 失敗 | 同一個 raw read 失敗 | false、無 source callback、`out` 不變 |
| current=true，placement 存在 | raw compose → `timber_a0_footprint_uv` | 同樣完整 raw compose → 同樣函式／參數 | raw/snapshot 行為不變 |
| current=false，placement 不存在 | raw read 找不到，ensure 前 false | `geo_placements_find` 找不到，ensure 前 false | 無 source callback、`out` 不變 |
| current=false，placement 存在 | compose 到未使用 local → canonical sequence | 存在查詢 → 相同 canonical sequence | 相同定義、BOX、FRAME、投影及輸出 |

`ctx->use_current_values` 的讀取移到純 local compose 之前。由於 compose 無 callback／World 寫入，兩個讀取點之間不存在會改 ctx flag 的產品動作。新舊都是在首個 source callback 前選一次 current/noncurrent 分支；不新增後續 flag 判斷。這是 callback 順序／階段的等價，不是聲稱相同 wall-clock 時間。

此等價證明對合法的 K store 成立：`count <= GEO_PLACEMENT_CAPACITY`，由產品 `geo_placements_stage`／remove／clone 路徑維持。須明說其界線：`geo_placements_find` 對手工破壞為 `count > capacity` 的私有 store 會回 NULL；原 `app_placement_read` 在這種狀態可能對 `geo_placements_at` 的 NULL 解參考。沒有宣稱保留未定義行為，也不把它當新的數值門檻或正常產品錯誤。

## B：canonical anchor 窄讀取

原函式宣告 `WoodMemberPlacement anchor`，呼叫 `wood_definition_sources_placement(...)` 後只讀 `anchor.placement_id`。沒有讀 UV、grid、between、length direction、order 或其他欄位。因此可在這一處換成 `WoodMemberPlacementContact` 與已存在的 `wood_definition_sources_placement_contact(...)`，不擴到其他完整 anchor 消費者。

兩個 W accessor 都經相同 `wd_reader`／`wd_get`：

1. 同一 `APP_SOURCE_WOOD_DEFINITION` provider 與 placement kind/id key；
2. 同一次 `GEO_DEPENDENCY_DEFINITION_REQUIRED` 來源呼叫；
3. 相同 schema、content pointer／size 合法性；
4. 相同 canonical id、全部固定段 bounds、三個字串容量與 payload bounds、完整 exact tail 驗證；
5. 失敗不 publish `out`，成功才 assign local result。

窄 accessor 不是 raw anchor cache，也不是 H 跨 consumer cache。它直接讀該次 K typed definition 返回的 canonical bytes。原 full decoder 不對 enum／embedded NUL 加額外語意限制，窄 reader 也沒有新增限制。既有 551 的 72,634 組 O2／ASan+UBSan 差分可作這個 API 等價性的既存佐證；它不等於本次 H 候選已實跑，仍須原 authority／整套驗收。

## source callback／錯誤順序

兩個小候選前後，noncurrent 的條件順序保持：

1. `reference_sources_ensure(ctx)`；
2. W canonical placement accessor（B 只換等價 reader）；
3. 返回的 `anchor.placement_id == placement_id`；
4. `geo_eval_source(... APP_SOURCE_MEMBER_POSE ..., VALUE_REQUIRED)`；
5. BOX kind 檢查；
6. `reference_placement_frame(... FRAME ..., VALUE_REQUIRED)`；
7. `wood_member_face_spec`、`geo_box_face`、四點投影；
8. 最後才 `*out=rect`。

每個短路 false 的先後不動；不增加 eager callback，不減少 source call／edge，不把讀到的 raw host frame 當 canonical frame，也不改 stored World。A 的 guard-only candidate 保留整段原 canonical suffix bytes；B／combined 在該 suffix 只改兩個型別／accessor tokens。

## 原負控與回歸影響（必須適配，不可假紅）

`tests/test_geo261_host_facts_authority.py` 的 13 個 `CONTROLS` 之中，只有 `raw-footprint` 的舊單行 anchor 會消失。其餘 12 個 name／anchor／case／marker 不變，額外 hole-vertex control 也不受影響。`tests/test_geo261_host_authority.py` 的 `FOOTPRINT_ANCHOR` 與 boundary assertion 亦用同一舊單行，需最小同步。

不能把舊 mutant 生硬塞進新 noncurrent 分支；新 `PlacementSurface placement` 只在 current block 內存在。正確適配：

- facts 的 `raw-footprint` 以完整新 current block 作唯一 anchor；mutant 先在自己的 scope 宣告 local、`app_placement_read` 初始化它，再套回原本「所有模式先用 raw footprint 拒絕，current 則直接 true」的壞法。原 `moved` case、`facts-moved-actual-anchor-footprint` marker、正常 exit 1、baseline／restore 要求全部保留。
- host-authority 的 `FOOTPRINT_ANCHOR` 也換完整新 current block；其既有 `current → true` mutation 會保留 block 內 raw read 初始化，再提前回傳 raw geometry。仍要求 `origin` case 的原 `host-footprint-actual-box-and-frame` 正常斷言紅。

永久測試 agent 已接手這兩處相容性 patch，本交付不另改 tests，避免重疊。既有 `frame`、`snapshot`、`moved`、exact source edges、world unchanged、失敗原子性等真 authority 案例應全部重跑；不能以 boundary anchor 找不到、編譯失敗、未初始化資料或 crash 當突變被偵測。

目前只是候選與靜態證明。收益、原紅撤回／恢復綠、原 tests／負控均未在本交付執行；root 將由效能診斷決定是否採用。若採用，H 是 native unity closure 與架構來源，帳本 freshness 與 Linux 架構四檔仍須按最新影響完整處理，最後固定新 SHA 重跑完整清單。
