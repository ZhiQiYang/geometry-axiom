本輪只做靜態分析與唯讀 DWARF 核對，沒有修改 repository、編譯、啟動 inferior 或跑測試。新 K header API 目前停在設計，等 root 先量較小 H 候選，沒有可套用產品 patch。

PC 採樣 v2 的 274 筆中，memcpy／memmove 共用 entry 92 筆、memset 61 筆，合計 153／274 = 55.84%。這能支持優先檢查大量複製與清零；沒有 caller backtrace，不能把該比例全部歸因於下列任一呼叫鏈。PC 原證據由另一 agent 保存於 `/tmp/g261sigprof/v2/runtime-entry-disassembly/CFG_PROOF.json`。

實際型別大小

`DWARF-SIZES.json` 從已成功建置的 O0 diagnostic binary `/tmp/g261raw-callback-v2-o0/diagnostic-baseline` 讀取 GCC 14.2.0 的 typedef → struct DIE 鏈。`dwarf-depth2.command.json` 保存 binary SHA256、指令、結束碼與安全版本資料；`dwarf-depth2.stdout.txt` 是完整 1,686,092 bytes 原輸出。沒有載入執行該 binary。首次 depth=1 只印出 compilation unit、未取得型別，原始輸出也分別保留。

| 型別 | DWARF bytes | 與熱路徑相關的初始化／複製 |
|---|---:|---|
| GeoPlacementDefinition | 37,720 | 8 個 components 佔 37,568；RECT／REGION_REF 也有完整 inactive storage |
| GeoRegionDefinition | 4,696 | 8 組 components 為 37,568 |
| PlacementSurface | 46,952 | 8 個 components 佔 46,784 |
| WoodBoundaryRegion | 5,848 | outline／holes／fixity inline |
| WoodContactSourceFacts | 50,896 | 8 個 regions 46,784 + 64 個 member facts 4,096 + 兩個 count 16 |
| AppContactFacts | 10,048 | world 104 + private effective 5,848 + members 4,096 |
| AppContactRawSnapshot | 48 | 64 個為 3,072；目前沒有全陣列 memset |
| WoodMemberPlacement | 1,736 | 3 個 512-byte 字串及完整 placement；完整 reader 先清 local 再成功複製 |
| WoodMemberPlacementContact | 16 | 現有窄讀 API，仍完整驗 wire |
| GeoSourceValue | 128 | 這個 tagged union 並非 37–50 KiB 的大型 record |
| GeoSourceNode | 200 | 首次新節點 calloc，包含 128-byte value |
| GeoEvalContext | 2,176 | 含 2,048-byte hint；建立／reset 層級 |
| WoodStopFace | 48 | 6 個 4-byte 欄位 + 3 個 8-byte 欄位，這個 ABI 沒有 padding |

精確呼叫鏈與每次次數

`reference_contact_facts` → `reference_host_read` → `geo_placement_sources_definition` → `geo_placement_definition_decode`：每一次這個 full accessor 成功讀取固定包含：

1. decoder 的 `memset(&next,0,sizeof next)`：37,720 bytes。
2. decoder 成功的 `memcpy(out,&next,sizeof next)`，此 out 指 wrapper 的 local result：37,720 bytes。
3. wrapper 成功的 `memcpy(out,&result,sizeof result)`，此 out 指 H local definition：37,720 bytes。

因此這個明文路徑每次為 113,160 bytes 的一清兩複製。這是每次 C 呼叫的確定操作數，不是宣稱實際每個 memcpy 都成為 shared-libc call，也不是已量得 N64 動態呼叫次數。編譯器可能 inline、合併或刪除部分操作；現有 PC 資料沒有 caller，不能直接換算時間。

同一 `reference_host_read` 在前面還呼叫 `app_placement_read` → `app_placement_at`，後者先清整個 46,952-byte output。讀取實際 source geometry 後，H 又清 `actual.components` 46,784 bytes，再於 derived 情況從 `derived.components` 複製整個 46,784 bytes。這些有不同 output 契約，不可因某次 domain=RECT 就直接省略清零。

K `geo_placement_sources_evaluate` 初始化 FRAME／REGIONS node 時，也走 full accessor，並額外複製 37,720-byte decoded 到 record。這通常是每個新 source node 的工作；已 VALID 的 node 由 K 快取，不應把它當作每次 `reference_host_read` 都重新執行。相反，H 顯式呼叫 full accessor 會再次解碼同一 cached canonical bytes，這才是 header 窄讀的具體省工位置。

較小的 H 機會已交 root／node agent：`reference_member_footprint` false 分支的 full `WoodMemberPlacement` 只消費 placement_id，可改用既有 16-byte Contact reader；完整 full reader 先清 1,736 bytes，成功再複製同樣大小，另有最多三段文字 memcpy。這與僅作 exists guard 的完整 PlacementSurface 重建可分別量測，不需要新增 K API。

最小 K header 設計（尚未實作）

新增中性、即時、無跨 consumer cache 的輸出：

```c
typedef struct {
    uint32_t id;
    GeoPlacementDomain domain;
    uint32_t region_id;
} GeoPlacementDefinitionHeader;

bool geo_placement_sources_definition_header(
    GeoPlacementSources *, uint32_t id, GeoPlacementDefinitionHeader *out);
```

此 ABI 上預期 12 bytes；尚無新 C binary 驗這個未實作型別，不能寫成已編譯 sizeof。只先替換熱的 `reference_host_read` local definition 型別與 accessor 呼叫：它後續只讀 domain／region_id。其餘三個 H 只用 domain 的 consumer 可另評估，但不混入最小收益量測；`reference_eng_placement` 另有明確 static full-accessor 測試，現在保留原碼，避免沒有必要的測試面擴張。

新 wrapper 必須在原相同點呼叫相同 `geo_eval_source`，相同 provider/key、`GEO_DEPENDENCY_DEFINITION_REQUIRED`、kind／schema／requested-id 判準。先驗 out 非 NULL，失敗完全保留 output；成功才賦值完整 12-byte header。full decode API、full accessor、record decoded、source descriptors／依賴／錯誤狀態、既有 mutable provider bytes 的即時重讀語意都保留原碼。

完整 canonical 接受集合不能縮小或放寬：

- 同樣拒絕 content=NULL、size 超過 `GEO_PLACEMENT_DEFINITION_MAX_BYTES`，同樣必須 exact trailing end。
- 固定 prefix 為 BE32 id + 12 個 BE64 frame 數值 + domain byte，共 101 bytes；frame 原 decoder 對所有 64-bit bit pattern 都接受，只轉 signed，沒有 frame／D1 semantic validation。因此有界跳過 96 bytes 與逐數讀取在既有 readable-buffer 合約內等價，不能新增 frame-valid 或座標範圍限制。
- RECT 必須完整消耗 32-byte endpoints，長度精確 133；REGION_REF 必須完整讀 4-byte region_id，長度精確 105。inactive domain fields 原 wire 沒有編碼；header 的 inactive region_id 必須是零。
- REGION_SET 讀 4-byte component_count 且 ≤8；每個 component 仍讀 id、outline count≤32、outline 的全部 `16*count` bytes、hole_count≤8、每個 hole count≤32 與全部 `16*count` bytes。每段先檢查剩餘長度，再移動 reader；不能只看 header/count 就返回成功。零 count 原 decoder 接受，不能新增至少四點／正面積等判準。
- 最大 wire 37,321 bytes；不需要建立 37,720-byte decoded struct，也不能省略任何活動 payload 的 bounds 或 exact trailing check。讀得到的 canonical id 必須等於 requested id；schema、value.kind、upstream failure 仍在同一 wrapper 拒絕。

若採用，需以真 graph canonical replacement 對 full／header 比較：各 domain、所有 prefix truncation、每個 count 的 0／上限／超界、所有 int64 極值、空 set、schema/id/kind、trailing、mutable borrowed bytes 重讀、out-on-error、完整 ordered dependency graph。具名隔離負控應分別移除 schema、id、每個 nested count／payload bound、trailing，而不是只以新實作自身算 expected。

其他省工候選及不應動處

- `WoodContactSourceFacts *facts=calloc(1,sizeof *facts)` 的 50,896 bytes 不能直接換 malloc：callback 合約明訂由 evaluator 提供全零 facts，而且 inactive bytes／失敗 prefix 有可觀察性。
- `AppContactFacts` 是 private workspace。`placement_effective_boundary` 凡回傳 private storage 的分支都自行全量清零；回傳外部 boundary/component 時不讀 private effective。因此可另論證只初始化 world104 bytes 與 active N 個完整 member facts，再由原 helper 完整初始化 effective，省每次重複的 5,848 bytes。必須保持 active facts 的完整零 bytes；不能跳過公共 output 初始化。root 尚未採用，沒有 patch 或動態證據。
- private result faces 的 `calloc(n,48)` 可依完整九欄寫入與失敗即 free 的證明另評估 malloc，但 root 已決定先不加：沒有實際 n 分布前不擴修。已採的 cap faces malloc 與 facts calloc 維持現狀。
- K node 的 200-byte calloc、128-byte local value 清零與成功值複製不是此處的巨大 record。不能為了泛稱 tagged union 優化就取消 provider 零初值、公開回傳初始化或改配置失敗時點。先前 node/key 合併還有 allocation-fault 相容風險，未重新建議。

結論是有確切的每次資料流量與新窄讀可行性設計，但還沒有 host caller 的時間占比，也沒有新 header 的收益或動態驗收。root 先量較小 H 候選；若足夠，保持本設計不落地。
