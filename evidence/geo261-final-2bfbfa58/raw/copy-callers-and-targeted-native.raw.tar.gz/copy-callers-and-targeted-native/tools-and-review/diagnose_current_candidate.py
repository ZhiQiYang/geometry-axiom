"""Compare a dirty candidate with main and a prior recorded candidate, diagnostic only."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',required=True,type=Path)
p.add_argument('--old-root',required=True,type=Path)
p.add_argument('--old-meaning',required=True)
a=p.parse_args()
repo=Path('/workspace/geometry-axiom')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
out=a.root/'timing'
assert not out.exists()
out.mkdir()
work=a.root/'work';work.mkdir()
candidate=a.root/'candidate';candidate.mkdir()
shutil.copy2(a.root/'candidate-bridge',candidate/'bridge')
original=json.loads(Path('/tmp/g261p3/tools/p189-551b00f6/provenance.json').read_text())
old_provenance=a.old_root/'timing/provenance.json'
old=json.loads(old_provenance.read_text())
sides={'main':Path('/tmp/g261p3/work/p189-551b00f6/main'),'old':a.old_root/'candidate','candidate':candidate}
assert digest(sides['main']/'bridge')==original['binaries_sha256']['main']
assert digest(sides['old']/'bridge')==old['binaries_sha256']['candidate']
changed=git('diff','--name-only').decode().splitlines()
assert changed
(out/'source.patch').write_bytes(git('diff','--binary'))
for name in changed:
    target=out/'source-snapshot'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((repo/name).read_bytes())
driver=Path('/tmp/g261r1/tools/scale_compare2.py')
args=[sys.executable,str(driver),str(work),str(out),*[name+'='+str(path) for name,path in sides.items()],
      '--ns','16,32,48,64','--reps','3','--gen','/tmp/g261r1/tools/gen_scene.py']
record={'purpose':'候選診斷，不能替代新最終 SHA 的完整 P-189','formalAcceptance':False,
        'base_head':git('rev-parse','HEAD').decode().strip(),'dirty_paths':changed,
        'patch_sha256':digest(out/'source.patch'),'reference_shas':original['shas'],
        'old_candidate_provenance':str(old_provenance),'old_candidate_provenance_sha256':digest(old_provenance),
        'old_candidate_meaning':a.old_meaning,'binaries_sha256':{name:digest(path/'bridge') for name,path in sides.items()},
        'timing_driver_sha256':digest(driver),'diagnostic_driver_sha256':digest(Path(__file__)),
        'source_hashes':{name:digest(repo/name) for name in changed},'command':args}
(out/'provenance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
result=subprocess.run(args)
record['timing_exit']=result.returncode
with (out/'samples.tsv').open() as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
assert len(rows)==36 and all(row['status']=='ok' and row['ok']=='True' for row in rows)
ratios=[]
for n in (16,32,48,64):
    medians={}
    for label in sides:
        chosen=[row for row in rows if row['n']==str(n) and row['side']==label]
        assert len(chosen)==3 and {row['round'] for row in chosen}=={'0','1','2'}
        medians[label]=statistics.median(float(row['seconds']) for row in chosen)
    ratios.append({'n':n,'medians':medians,'candidate_main':medians['candidate']/medians['main'],
                   'candidate_old':medians['candidate']/medians['old']})
record['ratios']=ratios
record['eligible_under_existing_p189_limit']=result.returncode==0 and all(row['candidate_main']<=2 for row in ratios)
for name,expected in record['source_hashes'].items():assert digest(repo/name)==expected,name
(out/'diagnosis.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False),flush=True)
raise SystemExit(0 if record['eligible_under_existing_p189_limit'] else 1)
