這是撤回 footprintnarrow 後的 rawsnapshot 永久測試 v3；舊7acb版完整保留在相鄰目錄，不覆寫歷史。

candidate.patch 僅修改現有 tests/geo261_host_facts_authority_harness.c 與 test_geo261_host_facts_authority.py。22案例、8新具名負控、2新Python方法維持；原CONTROLS=13整個原文區塊逐byte不變，也不修改test_geo261_host_authority.py。

舊21a eager facts與callback只凍結兩個小函式，避免共用候選prepare(NULL)。比較同址完整out/canarytail、World、ordered provider calls、typed graph、ctx/error；包含excludedprefix anchorfail與foreignprefix posefail。每個新控制要求baseline0、正常mutant1與精確ASSERT、restored0；crash/timeout不能算紅。原13控制與斷言保留。

只作檔案準備、Python AST、原文相等與checksum檢查；未編譯、未測試、未修改root、未commit/push。動態通過仍須root執行原suite和8個具名紅→恢復綠。census必須如實登記新2方法，不能只允許W7→9。
