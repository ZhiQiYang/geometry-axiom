#!/usr/bin/env python3
"""保留7acb舊版，只準備撤回footprint anchor適配後的新兩檔候選。"""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,subprocess
R=Path('/workspace/geometry-axiom');S=Path('/workspace/geo261-environment/h-rawsnapshot-permanent-candidate');O=Path(__file__).resolve().parent
H='tests/geo261_host_facts_authority_harness.c';P='tests/test_geo261_host_facts_authority.py'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
oldmeta=json.loads((S/'PREPARED.json').read_text())
assert sha((S/'candidate.patch').read_bytes())=='7acb72833da0d6b837dc48836363d39a6f2fa350eeb2d741fef3c6d8256b8002'
base={r:(R/r).read_bytes() for r in [H,P]}
assert all(sha(base[r])==oldmeta['beforeRawSha256'][r] for r in [H,P]),'root測試已變，拒絕借用舊base'
h=(S/H).read_bytes();p=(S/P).read_text();orig=base[P].decode()
a=p.index("    ('raw-footprint',");b=p.index("    ('raw-contact',",a)
x=orig.index("    ('raw-footprint',");y=orig.index("    ('raw-contact',",x)
p=p[:a]+orig[x:y]+p[b:]
# Preserve the original control tuple and all nearby descriptions verbatim.
a=orig.index('CONTROLS = (');b=orig.index('class HostFactsAuthorityBoundary')
assert orig[a:b] in p
ast.parse(p)
for r,v in [(H,h),(P,p.encode())]:
 f=O/r;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(v)
patch=''.join(''.join(difflib.unified_diff(base[r].decode().splitlines(keepends=True),v.decode().splitlines(keepends=True),fromfile='a/'+r,tofile='b/'+r)) for r,v in [(H,h),(P,p.encode())])
(O/'candidate.patch').write_text(patch)
meta={**oldmeta,'preparedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':git('rev-parse','HEAD').decode().strip(),'sourceStatus':git('status','--porcelain=v1').decode(),'revision':'v3-rawsnapshot-only-after-footprintnarrow-withdrawal','preservedEarlierProposal':str(S),'preservedEarlierPatchSha256':'7acb72833da0d6b837dc48836363d39a6f2fa350eeb2d741fef3c6d8256b8002','beforeRawSha256':{r:sha(v) for r,v in base.items()},'candidateRawSha256':{H:sha(h),P:sha(p.encode())},'patchSha256':sha(patch.encode()),'existing13ControlsByteUnchanged':True,'rawFootprintAnchorAdaptedToInitializedScopedPlacement':False,'hostAuthorityAnchorAdaptedOnly':False,'testHostAuthorityModified':False,'compiled':False,'executed':False}
meta.pop('other12OriginalControlsByteUnchanged',None)
meta['productSourceSha256AtPreparation']={r:sha((R/r).read_bytes()) for r in ['current_geometry.c','geometry-app/native/reference_sources.inc','geometry-core/kernel/source.c','geometry-templates/woodworking/native/contact_sources.c']}
(O/'PREPARED.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
(O/'README.md').write_text('''這是撤回 footprintnarrow 後的 rawsnapshot 永久測試 v3；舊7acb版完整保留在相鄰目錄，不覆寫歷史。

candidate.patch 僅修改現有 tests/geo261_host_facts_authority_harness.c 與 test_geo261_host_facts_authority.py。22案例、8新具名負控、2新Python方法維持；原CONTROLS=13整個原文區塊逐byte不變，也不修改test_geo261_host_authority.py。

舊21a eager facts與callback只凍結兩個小函式，避免共用候選prepare(NULL)。比較同址完整out/canarytail、World、ordered provider calls、typed graph、ctx/error；包含excludedprefix anchorfail與foreignprefix posefail。每個新控制要求baseline0、正常mutant1與精確ASSERT、restored0；crash/timeout不能算紅。原13控制與斷言保留。

只作檔案準備、Python AST、原文相等與checksum檢查；未編譯、未測試、未修改root、未commit/push。動態通過仍須root執行原suite和8個具名紅→恢復綠。census必須如實登記新2方法，不能只允許W7→9。
''')
(O/'SHA256SUMS').write_text(''.join(sha(f.read_bytes())+'  '+str(f.relative_to(O))+'\n' for f in sorted(O.rglob('*')) if f.is_file() and f.name!='SHA256SUMS'))
print(json.dumps({'out':str(O),'patchSha256':meta['patchSha256'],'twoFilesOnly':True,'original13ByteUnchanged':True,'compiled':False,'executed':False}))
