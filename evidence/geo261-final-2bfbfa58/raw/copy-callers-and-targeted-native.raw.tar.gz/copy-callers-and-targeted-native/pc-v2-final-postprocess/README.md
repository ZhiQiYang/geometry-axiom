# SIGPROF PC 診斷第二輪

此為單次N64 CPU取樣診斷，不是P-189驗收。重用第一輪凍結產品的nonpg O2-g bridge，binary SHA b882cbab35f02972f2a29b7e001e05a81b44867c6da6ef9e2633683a5f07044e。HEAD21a966a8加rawsnapshot/malloc/hashhint dirty產品，確切4來源hash與全部2896產品檔hash在SNAPSHOT_READY.json/source-inputs.json。

receipt.json保留所有命令/cwd/退出碼/原stdoutstderr；load-process.json是真bridge rc0和stack16MiB，load ok=true。原PC是pcs.bin，mainbase/count/overflow在pcs.bin.json；maps是在timer停止且SIGPROF blocked後由同一程序保存的pcs.bin.maps。pcs.bin.symbols是同程序dlsym(RTLD_NEXT)取得10個實際runtime入口，非nm nearest symbol。shared-module-identities.json及raw/shared-*保存libc SHA、buildid、programheaders、完整dynamic symbols、addr2line全文。第一輪沒有保存shared maps，不能事後把它的outside PCs確定歸函式。

runtime-entry-disassembly/CFG_PROOF.json用實際memcpy/memmove共用入口0x17b800、memset0x17c080、memcmp0x172200、strcmp0x175040，沿反組譯的direct branch/fallthrough追至ret，為每個matched sample保留可核對跳轉witness。四CFG無未解target。忽略objdump印出的最近_dl_mcount_wrapper名稱。

274samples中：copy92(33.58%)、memset61(22.26%)、memcmp14(5.11%)、strcmp1、calloc1/free1、unknown3。無caller backtrace，不可將bulkcopyzero的55.84%直接歸到host decoder，也不能排除calloc/realloc啟動這些搬移/清零。這只說明此輪實際PC主要在bulk memory指令；樣本小，門檻仍由原正式三方P-189決定。

第一輪和第二輪raw輸出都保留。此輪heavy.lock已釋放，subreaper主退出碼0，沒有再編譯產品或重採樣。
