#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <limits.h>
#include <link.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum { CAPACITY=16384 };
typedef struct {uintptr_t caller;uint64_t calls,bytes,maximum;unsigned operation;} Count;
static Count counts[CAPACITY];
static uintptr_t main_base,main_low=UINTPTR_MAX,main_high;
static uint64_t overflow;
static volatile int table_lock;
static int configured,active,error_code;
static char output_path[PATH_MAX];
static __thread unsigned recursive __attribute__((tls_model("initial-exec")));
static void *(*copy_real)(void *,const void *,size_t);
static void *(*move_real)(void *,const void *,size_t);
static void *(*set_real)(void *,int,size_t);

/* volatile 加上編譯旗標，避免啟動期備援迴圈再被降低成被攔截的同名函式。 */
static void *copy_fallback(void *to,const void *from,size_t size)
{volatile unsigned char *d=to;const volatile unsigned char *s=from;for(size_t i=0;i<size;++i)d[i]=s[i];return to;}
static void *move_fallback(void *to,const void *from,size_t size)
{volatile unsigned char *d=to;const volatile unsigned char *s=from;
 if((uintptr_t)to<(uintptr_t)from){for(size_t i=0;i<size;++i)d[i]=s[i];}
 else while(size){--size;d[size]=s[size];}return to;}
static void *set_fallback(void *to,int value,size_t size)
{volatile unsigned char *d=to;for(size_t i=0;i<size;++i)d[i]=(unsigned char)value;return to;}
static void count_call(unsigned operation,uintptr_t caller,size_t size)
{
    while(__sync_lock_test_and_set(&table_lock,1)){}
    size_t slot=((caller>>4)^(caller>>17)^operation)&(CAPACITY-1);
    for(size_t probe=0;probe<CAPACITY;++probe){Count *c=&counts[slot];
        if(!c->operation){c->operation=operation;c->caller=caller;}
        if(c->operation==operation&&c->caller==caller){++c->calls;c->bytes+=size;
            if(size>c->maximum)c->maximum=size;__sync_lock_release(&table_lock);return;}
        slot=(slot+1)&(CAPACITY-1);
    }
    ++overflow;__sync_lock_release(&table_lock);
}
void *memcpy(void *to,const void *from,size_t size)
{
    if(!copy_real)return copy_fallback(to,from,size);
    if(!active||recursive)return copy_real(to,from,size);
    recursive=1;count_call(1,(uintptr_t)__builtin_extract_return_addr(__builtin_return_address(0)),size);
    void *result=copy_real(to,from,size);recursive=0;return result;
}
void *memmove(void *to,const void *from,size_t size)
{
    if(!move_real)return move_fallback(to,from,size);
    if(!active||recursive)return move_real(to,from,size);
    recursive=1;count_call(2,(uintptr_t)__builtin_extract_return_addr(__builtin_return_address(0)),size);
    void *result=move_real(to,from,size);recursive=0;return result;
}
void *memset(void *to,int value,size_t size)
{
    if(!set_real)return set_fallback(to,value,size);
    if(!active||recursive)return set_real(to,value,size);
    recursive=1;count_call(3,(uintptr_t)__builtin_extract_return_addr(__builtin_return_address(0)),size);
    void *result=set_real(to,value,size);recursive=0;return result;
}
static int main_image(struct dl_phdr_info *info,size_t size,void *user)
{
    (void)size;(void)user;if(info->dlpi_name&&info->dlpi_name[0])return 0;
    main_base=info->dlpi_addr;
    for(ElfW(Half) i=0;i<info->dlpi_phnum;++i){const ElfW(Phdr) *p=&info->dlpi_phdr[i];
        if(p->p_type==PT_LOAD){uintptr_t low=main_base+p->p_vaddr,high=low+p->p_memsz;
            if(low<main_low)main_low=low;if(high>main_high)main_high=high;}}
    return 1;
}
__attribute__((constructor)) static void begin_counting(void)
{
    recursive=1;
    copy_real=(void *(*)(void *,const void *,size_t))dlsym(RTLD_NEXT,"memcpy");
    move_real=(void *(*)(void *,const void *,size_t))dlsym(RTLD_NEXT,"memmove");
    set_real=(void *(*)(void *,int,size_t))dlsym(RTLD_NEXT,"memset");
    recursive=0;
    const char *out=getenv("GEO261_MEM_OUT"),*expected=getenv("GEO261_MEM_EXE");char actual[PATH_MAX];
    ssize_t size=readlink("/proc/self/exe",actual,sizeof actual-1);
    if(!out||!expected||size<0||size>=(ssize_t)sizeof actual-1)return;
    actual[size]=0;if(strcmp(actual,expected)||strncmp(out,"/tmp/g261memcalls/",18)||strlen(out)>=sizeof output_path)return;
    strcpy(output_path,out);configured=1;dl_iterate_phdr(main_image,NULL);
    if(!copy_real||!move_real||!set_real||main_low==UINTPTR_MAX){error_code=1;return;}
    active=1;
}
__attribute__((destructor)) static void finish_counting(void)
{
    active=0;if(!configured)return;
    int fd=open(output_path,O_WRONLY|O_CREAT|O_EXCL,0600);if(fd<0)return;
    dprintf(fd,"{\"schema\":\"geo261-memory-call-count/1\",\"kind\":\"metadata\",\"pid\":%ld,\"base\":%llu,\"low\":%llu,\"high\":%llu,\"overflow\":%llu,\"error\":%d}\n",
        (long)getpid(),(unsigned long long)main_base,(unsigned long long)main_low,(unsigned long long)main_high,(unsigned long long)overflow,error_code);
    const char *names[]={"","memcpy","memmove","memset"};
    for(size_t i=0;i<CAPACITY;++i){const Count *c=&counts[i];if(!c->operation)continue;
        dprintf(fd,"{\"kind\":\"count\",\"operation\":\"%s\",\"caller\":%llu,\"main\":%s,\"relative_return_pc\":%llu,\"calls\":%llu,\"bytes\":%llu,\"maximum\":%llu}\n",
            names[c->operation],(unsigned long long)c->caller,c->caller>=main_low&&c->caller<main_high?"true":"false",(unsigned long long)(c->caller-main_base),
            (unsigned long long)c->calls,(unsigned long long)c->bytes,(unsigned long long)c->maximum);
    }
    close(fd);
}
