# 動態memcpy/memmove/memset caller byte-count診斷

這是單次N64呼叫量診斷，不是性能量測、P-189或最終SHA驗收。重用第一輪PC採樣凍結的nonpg O2-g bridge b882cbab35f02972f2a29b7e001e05a81b44867c6da6ef9e2633683a5f07044e；產品源碼身分在SNAPSHOT_READY.json、source-inputs.json與root-dirty.patch。只bridge子程序設LD_PRELOAD，launcher及其餘工具不注入。

.so帶-fno-builtin及-fno-tree-loop-distribute-patterns，dlsym(RTLD_NEXT)只在ctor初始化3個real函式指標；啟動期遞迴使用volatile byte loop備援。wrapper不配置記憶體，只更新固定16384slot表與三個operation標籤，保留__builtin_return_address(0)；dtor關閉記錄後才輸出。raw/counter-disassembly.stdout保留實際組譯可查備援路徑。

counts.jsonl是原始全量83caller記錄與main PIEbase、overflow/error。resolved-callers.json保留caller absolute/relative returnPC、callcount、totalbytes、maximum與addr2line inline全文；解析PC-1以回到call指令，tail-call最佳化可能使returnPC代表上一層，不能當完整call stack。SUMMARY.json按operation＋最內層函式/行彙總。

真正rc0、loadoktrue、overflow/error0。可見bytes總35,272,515,250。最大為app_placement_at memset10.651GB，其次reference_host_read memcpy4.004GB及memset3.989GB，K placement definition full decode/wrapper memset/copy共9.682GB，app_grid_host_value memset2.478GB。此為byte量不是CPU時間百分比，不能把35GB直接換成特定倍數改善。

限制：只攔可動態interpose的符號，libc hidden/internal別名、編譯器inline memops不可見；真正實作內部遞迴被guard排除，避免雙算。原PC取樣的bulkcopyzero份額不必全部出現在本表。本次沒有改產品、不改守門、也不據wrapper下耗時宣稱性能。
