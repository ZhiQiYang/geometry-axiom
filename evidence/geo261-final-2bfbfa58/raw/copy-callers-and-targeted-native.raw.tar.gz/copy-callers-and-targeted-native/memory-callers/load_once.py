import json,os,subprocess,sys
from pathlib import Path
e=os.environ.copy();e.update(LD_PRELOAD=sys.argv[2],GEO261_MEM_EXE=sys.argv[1],GEO261_MEM_OUT=sys.argv[3])
p=subprocess.run([sys.argv[1]],input=Path(sys.argv[4]).read_bytes(),env=e)
Path(sys.argv[5]).write_text(json.dumps({'exit_code':p.returncode,'bridge_only_environment':{k:e[k] for k in ('LD_PRELOAD','GEO261_MEM_EXE','GEO261_MEM_OUT')}})+'\n')
raise SystemExit(p.returncode)
