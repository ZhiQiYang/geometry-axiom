這是2bfbfa58加各具名dirty patch的診斷，不是乾淨最終SHA的完整驗收。

footprintnarrow build0、36筆timing wrapper1，N64 candidate/main=2.067469、candidate/old=0.994780，已完整撤回；低N收益仍保留原樣本，不挑綠樣本。

新增永久測試首輪65項為1failure+1error：缺limits.h、結構測試仍只讀wrapper。補直接include，並精確檢查wrapper委派、保留原identity/boundary斷言後，82項全部0；新8負控全部基線0/正常具名突變1/恢復0。未改產品修正以遷就斷言。

記憶體caller診斷83caller、overflow0，觀察35.27GB可見動態操作；raw caller PC及full inlinechain齊。它不是時間或P189驗收，不涵蓋inline/libc hidden操作，完整限制見README。
