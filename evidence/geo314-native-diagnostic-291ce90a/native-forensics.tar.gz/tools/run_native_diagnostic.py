#!/usr/bin/env python3
"""External diagnostic adapter: canonical run_all, only binaries.OUT_DIR adapted.

Temporary build coverage is observed, not guaranteed: child suites can delete
their own TemporaryDirectory before an outer process can archive it. Linux
inotify plus periodic/final scans preserve observed versions and report misses.
This adapter never patches test code, cleanup, build flags, suites or verdicts.
"""
from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import runpy
import select
import shutil
import struct
import subprocess
import sys
import tarfile
import threading
import time
import traceback


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def command(args, root):
    result = subprocess.run(args, cwd=root, capture_output=True)
    return result.returncode, result.stdout, result.stderr


def git_snapshot(root, out, label):
    values = {}
    for name, args in (("head", ["rev-parse", "HEAD"]), ("status", ["status", "--porcelain=v2", "--branch"]),
                       ("diff", ["diff", "--binary", "HEAD"]), ("cached-diff", ["diff", "--cached", "--binary"])):
        code, stdout, stderr = command(["git", *args], root)
        for suffix, raw in (("stdout", stdout), ("stderr", stderr)):
            (out / f"{label}-git-{name}.{suffix}").write_bytes(raw)
        values[name] = {"command": ["git", *args], "exit_code": code,
                        "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)}
        if name == "head" and code == 0:
            values["sha"] = stdout.decode().strip()
    return values


def backup_ledger(root, out, label):
    path = root / "tests/mutants_results.json"
    if not path.is_file():
        return {"path": str(path), "exists": False}
    raw = path.read_bytes()
    target = out / f"ledger-{label}.json"
    target.write_bytes(raw)
    return {"path": str(path), "exists": True, "bytes": len(raw), "sha256": sha(raw), "backup": target.name}


def source_archive(root, out, label):
    code, names, stderr = command(["git", "ls-files", "-z"], root)
    if code:
        raise RuntimeError("cannot enumerate tracked source inputs: " + stderr.decode(errors="replace"))
    rows, missing = [], []
    archive = out / f"source-inputs-{label}.tar.gz"
    excluded = {"evidence", "release-evidence", ".git", "node_modules", "__pycache__"}
    with tarfile.open(archive, "w:gz", compresslevel=1, dereference=False) as bundle:
        for name in sorted(names.decode("utf-8").rstrip("\0").split("\0")):
            if not name or any(part in excluded for part in Path(name).parts):
                continue
            path = root / name
            if path.is_symlink():
                rows.append({"path": name, "symlink": os.readlink(path)})
                bundle.add(path, arcname=name, recursive=False)
            elif path.is_file():
                raw = path.read_bytes()
                rows.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
                bundle.add(path, arcname=name, recursive=False)
            else:
                missing.append(name)  # sparse omissions are recorded, never silently called archived
    write_json(out / f"source-inputs-{label}.manifest.json", {"files": rows, "missing_tracked": missing})
    return {"archive": archive.name, "sha256": sha(archive.read_bytes()), "files": len(rows), "missing_tracked": missing}


class ObservedBuildArchive:
    """Read-only inotify observer with content-addressed raw-byte versions."""
    MASK = 0x00000008 | 0x00000080 | 0x00000100 | 0x00000200 | 0x00000400 | 0x00000040
    ISDIR, OVERFLOW, IGNORED = 0x40000000, 0x00004000, 0x00008000

    def __init__(self, roots, out):
        self.roots, self.out = roots, out
        self.objects = out / "observed-build-objects"
        self.objects.mkdir()
        self.events = (out / "observed-build-events.jsonl").open("w", encoding="utf-8")
        self.latest, self.watches, self.watched = {}, {}, set()
        self.issues, self.stop_event = [], threading.Event()
        self.libc = ctypes.CDLL(None, use_errno=True)
        self.libc.inotify_init1.argtypes, self.libc.inotify_init1.restype = [ctypes.c_int], ctypes.c_int
        self.libc.inotify_add_watch.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32]
        self.libc.inotify_add_watch.restype = ctypes.c_int
        self.fd = self.libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise OSError(ctypes.get_errno(), "inotify_init1")
        for label, path in self.roots.items():
            self.scan(label, path, "initial-scan")
        self.thread = threading.Thread(target=self.watch, name="native-diagnostic-read-only-observer", daemon=True)

    def log(self, value):
        self.events.write(json.dumps(dict(at=now(), **value), ensure_ascii=False) + "\n")
        self.events.flush()

    def issue(self, kind, **value):
        row = dict(kind=kind, **value)
        self.issues.append(row)
        self.log(row)

    def add_watch(self, label, path):
        if path in self.watched:
            return
        wd = self.libc.inotify_add_watch(self.fd, os.fsencode(path), self.MASK)
        if wd < 0:
            self.issue("watch-missing", root=label, path=str(path), errno=ctypes.get_errno())
        else:
            self.watches[wd] = (label, path)
            self.watched.add(path)

    def observe(self, label, path, reason, force=False):
        key = label + "/" + str(path.relative_to(self.roots[label]))
        try:
            if path.is_symlink():
                self.log({"kind": "symlink", "path": key, "target": os.readlink(path), "reason": reason})
                return
            before = path.stat()
            if not path.is_file():
                return
            signature = [before.st_size, before.st_mtime_ns, before.st_ctime_ns, before.st_ino]
            if not force and self.latest.get(key, {}).get("signature") == signature:
                return
            raw = path.read_bytes()
            after = path.stat()
            if signature != [after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_ino]:
                self.issue("changed-during-observation", path=key, reason=reason)
                return
            digest = sha(raw)
            target = self.objects / digest
            if not target.exists():
                target.write_bytes(raw)
            row = {"path": key, "bytes": len(raw), "sha256": digest, "mode": before.st_mode,
                   "signature": signature, "reason": reason}
            self.latest[key] = row
            self.log(dict(kind="file-version", **row))
        except (FileNotFoundError, PermissionError, OSError) as exc:
            self.issue("observation-missing", path=key, reason=reason, error=repr(exc))

    def scan(self, label, start, reason):
        if not start.is_dir():
            return
        for directory, dirs, files in os.walk(start, followlinks=False):
            path = Path(directory)
            self.add_watch(label, path)
            dirs[:] = [name for name in dirs if not (path / name).is_symlink()]
            for name in files:
                self.observe(label, path / name, reason)

    def watch(self):
        next_scan = time.monotonic() + 1
        try:
            while not self.stop_event.is_set():
                ready, _, _ = select.select([self.fd], [], [], 0.2)
                if ready:
                    try:
                        data = os.read(self.fd, 1 << 20)
                    except BlockingIOError:
                        data = b""
                    offset = 0
                    while offset + 16 <= len(data):
                        wd, mask, cookie, size = struct.unpack_from("iIII", data, offset)
                        name = os.fsdecode(data[offset + 16:offset + 16 + size].split(b"\0", 1)[0])
                        offset += 16 + size
                        if mask & self.OVERFLOW:
                            self.issue("inotify-overflow", cookie=cookie)
                            continue
                        if wd not in self.watches:
                            continue
                        label, directory = self.watches[wd]
                        path = directory / name if name else directory
                        if mask & self.IGNORED:
                            self.watched.discard(directory)
                            self.watches.pop(wd, None)
                        elif mask & self.ISDIR:
                            if mask & (0x100 | 0x80):
                                self.scan(label, path, "directory-created-scan")
                        elif mask & (0x8 | 0x80):
                            self.observe(label, path, "close-write-or-move", force=True)
                        elif mask & (0x200 | 0x40):
                            key = label + "/" + str(path.relative_to(self.roots[label]))
                            self.log({"kind": "delete-or-move-from", "path": key, "observed": key in self.latest})
                            if key not in self.latest:
                                self.issue("deleted-before-observed", path=key)
                if time.monotonic() >= next_scan:
                    for label, path in self.roots.items():
                        self.scan(label, path, "periodic-scan")
                    next_scan = time.monotonic() + 1
        except BaseException as exc:
            self.issue("observer-failed", error=repr(exc), traceback=traceback.format_exc())

    def start(self):
        self.thread.start()

    def finish(self):
        self.stop_event.set()
        self.thread.join()
        for label, path in self.roots.items():
            self.scan(label, path, "final-scan-before-outer-atexit")
        write_json(self.out / "observed-build-manifest.json", {
            "coverage": "observed versions only; no claim that every child temp file was captured",
            "roots": {key: str(value) for key, value in self.roots.items()},
            "files": list(self.latest.values()), "issues": self.issues,
            "object_storage": "observed-build-objects/<sha256>, exact raw bytes"})
        os.close(self.fd)
        self.events.close()


def binary_contract(module):
    records = []
    for binary in module.REGISTRY:
        fingerprint, files, portable = module.compute_fingerprint(binary)
        records.append({"name": binary.name, "posix_flags": list(binary.posix_flags),
                        "win_flags": list(binary.win_flags), "win_link": list(binary.win_link),
                        "portable_command": portable, "fingerprint": fingerprint, "files": files})
    return records


def archive_tree(path, out, label):
    if not path.exists():
        return {"exists": False}
    target = out / (label + ".tar.gz")
    with tarfile.open(target, "w:gz", compresslevel=1, dereference=False) as bundle:
        bundle.add(path, arcname=label)
    return {"exists": True, "archive": target.name, "sha256": sha(target.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--source-sha")
    parser.add_argument("--stdout-file")
    parser.add_argument("--stderr-file")
    args = parser.parse_args()
    root, out = args.root.resolve(), args.outdir.resolve()
    if out == root or out.is_relative_to(root):
        parser.error("outdir must be external to the repository")
    out.mkdir(parents=True, exist_ok=False)
    tmp, private, mutation_cache = out / "native-tmp", out / "private-cache", out / "mutation-cache"
    for path in (tmp, private, mutation_cache):
        path.mkdir()
    original_tmp = {key: os.environ.get(key) for key in ("TMPDIR", "MUTATE_CACHE", "MUTATE_RESULTS")}
    os.environ["TMPDIR"] = str(tmp)
    os.environ["MUTATE_CACHE"] = str(mutation_cache)
    # No tempfile import/use precedes this point; native children inherit TMPDIR.
    os.chdir(root)
    sys.path.insert(0, str(root / "tests"))
    spec = importlib.util.spec_from_file_location("binaries", root / "tests/binaries.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["binaries"] = module
    spec.loader.exec_module(module)
    before_contract = binary_contract(module)
    original_out = str(module.OUT_DIR)
    module.OUT_DIR = private  # The only adapted original module attribute.
    adapted_contract = binary_contract(module)
    adapter = Path(__file__).resolve()
    tool_body = (root / "tests/mutate.py").read_bytes().replace(b"\r\n", b"\n")
    backend = root / "tests/mutation_bridge.py"
    if backend.is_file():
        tool_body += b"\0mutation_bridge.py\0" + backend.read_bytes().replace(b"\r\n", b"\n")
    before = git_snapshot(root, out, "before")
    meta = {"schema": "geo314-native-diagnostic/1", "classification": "diagnostic, not formal final-SHA acceptance",
            "started_at": now(), "root": str(root), "source_sha": before.get("sha"), "expected_sha": args.source_sha,
            "original_command": [sys.executable, "tests/run_all.py", "--build"],
            "adapter_command": [sys.executable, *sys.argv], "adapter_sha256": sha(adapter.read_bytes()),
            "binaries_module_sha256": sha((root / "tests/binaries.py").read_bytes()),
            "run_all_sha256": sha((root / "tests/run_all.py").read_bytes()),
            "mutation_tool_sha256": sha(tool_body), "binaries_OUT_DIR_before": original_out,
            "binaries_OUT_DIR_adapted": str(private), "only_module_adaptation": "binaries.OUT_DIR",
            "contract_before": before_contract, "contract_after_OUT_DIR": adapted_contract,
            "OUT_DIR_adaptation_preserves_flags_commands_fingerprints": before_contract == adapted_contract,
            "before_git": before, "ledger_before": backup_ledger(root, out, "before"),
            "original_environment_paths": original_tmp, "stdout_file": args.stdout_file, "stderr_file": args.stderr_file,
            "environment": {key: os.environ[key] for key in ("PATH", "CC", "CXX", "CFLAGS", "CXXFLAGS", "LDFLAGS",
                "LANG", "LC_ALL", "LC_CTYPE", "TZ", "TMPDIR", "MUTATE_CACHE", "MUTATE_RESULTS", "NODE_OPTIONS",
                "PYTHONPATH", "PYTHONSTARTUP", "PYTHONOPTIMIZE", "PYTHONIOENCODING", "PYTHONUTF8") if key in os.environ},
            "platform": platform.platform(), "python": sys.version, "stack_rlimit": resource.getrlimit(resource.RLIMIT_STACK),
            "mutation_results_policy": "unchanged: run_all mutation:check pins root/tests/mutants_results.json",
            "suite_policy": "original complete run_all --build, no --only, no skip flags, no update-expected"}
    meta["source_inputs_before"] = source_archive(root, out, "before")
    write_json(out / "receipt.json", meta)
    if args.source_sha and args.source_sha != before.get("sha"):
        raise RuntimeError("detached source SHA does not match the requested diagnostic source")
    if before_contract != adapted_contract:
        raise RuntimeError("OUT_DIR adaptation unexpectedly changed compilation contracts")
    watcher = ObservedBuildArchive({"native-tmp": tmp, "private-cache": private}, out)
    watcher.start()
    original_argv = sys.argv[:]
    code = 0
    try:
        sys.argv = [str(root / "tests/run_all.py"), "--build"]
        print("GEO314 DIAGNOSTIC: original run_all --build; only binaries.OUT_DIR adapted", flush=True)
        runpy.run_path(str(root / "tests/run_all.py"), run_name="__main__")
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 0 if exc.code is None else 1
        if not isinstance(exc.code, (int, type(None))):
            print(exc.code, file=sys.stderr)
    except KeyboardInterrupt:
        code = 130
        traceback.print_exc()
    except BaseException:
        code = 1
        traceback.print_exc()
    finally:
        sys.argv = original_argv
        # This executes before this outer process's atexit. Child cleanup has
        # already happened; the observer's explicit coverage record reflects it.
        try:
            watcher.finish()
            meta["after_git"] = git_snapshot(root, out, "after")
            meta["ledger_after"] = backup_ledger(root, out, "after")
            meta["contract_after_run"] = binary_contract(module)
            meta["contract_unchanged_after_run"] = meta["contract_after_run"] == before_contract
            meta["private_cache_archive"] = archive_tree(private, out, "official-private-cache")
            meta["surviving_tmp_archive"] = archive_tree(tmp, out, "surviving-native-tmp")
            meta["source_inputs_after"] = source_archive(root, out, "after")
        except BaseException:
            meta["archive_error"] = traceback.format_exc()
            traceback.print_exc()
        meta.update(ended_at=now(), original_run_all_exit_code=code,
                    observed_tmp_coverage="observed-only; see events, missing events and content-addressed manifest")
        write_json(out / "receipt.json", meta)
    return code  # Never turn a stale ledger, suite failure or census mismatch into success.


if __name__ == "__main__":
    raise SystemExit(main())
