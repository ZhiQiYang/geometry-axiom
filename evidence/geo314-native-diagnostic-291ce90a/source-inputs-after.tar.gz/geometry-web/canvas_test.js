/* 畫布橋接器／幾何整合測試：透過 serve.py 的 /api HTTP 介面（或直連 bridge）。
 * 不執行 DOM 或瀏覽器點擊；實際介面操作由 cdp_test.js 驗證。
 * 用法：node canvas_test.js          → 走 http://localhost:8765/api
 *       node canvas_test.js direct   → 直接 spawn web_bridge.exe
 * 不重實作幾何——照抄前端的仿射/編輯算式，對照 bridge 的 uv/proj/bhit。
 */
const { spawn } = require("child_process");

const DIRECT = process.argv.includes("direct");
const API_URL = new URL("/api", process.env.GEOMETRY_TEST_URL || "http://localhost:8765/").href;
let api;
if (DIRECT) {
  const bridge = spawn(`"${__dirname.replace(/\//g, "\\")}\\web_bridge.exe"`,
                       [], { shell: true });
  let buf = "";
  const resolveQ = [];
  bridge.stdout.on("data", d => {
    buf += d;
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      try { (resolveQ.shift() || (()=>{}))(JSON.parse(line)); }
      catch (e) { console.log("BAD JSON:", line); }
    }
  });
  api = cmd => { bridge.stdin.write(cmd + "\n");
                 return new Promise(r => resolveQ.push(r)); };
  process.on("exit", () => bridge.kill());
} else {
  api = cmd => fetch(API_URL, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cmd })
  }).then(r => r.json());
}

/* --- 抄自 index.html 的算式 --- */
async function uvMapFor(v, sid) {
  const [p00, p10, p01] = await Promise.all([
    api(`proj ${v} 0 0 ${sid}`), api(`proj ${v} 1000 0 ${sid}`), api(`proj ${v} 0 1000 ${sid}`)
  ]);
  if (!p00.ok || !p10.ok || !p01.ok) return null;
  const m = { ox: p00.x, oy: p00.y,
    ax: (p10.x - p00.x) / 1000, ay: (p10.y - p00.y) / 1000,
    bx: (p01.x - p00.x) / 1000, by: (p01.y - p00.y) / 1000 };
  m.det = m.ax * m.by - m.ay * m.bx;
  return m.det ? m : null;
}
const mapUv = (m,u,v) => ({ x: m.ox + u*m.ax + v*m.bx, y: m.oy + u*m.ay + v*m.by });
const unmapView = (m,x,y) => {
  const dx = x - m.ox, dy = y - m.oy;
  return { u: Math.round((dx*m.by - m.bx*dy)/m.det),
           v: Math.round((m.ax*dy - dx*m.ay)/m.det) };
};
const vertsStr = pts => pts.map(p => `${p[0]},${p[1]}`).join(" ");
function applyVertexEdit(pts, i, uv) {
  const n = pts.length, prev = pts[(i-1+n)%n], next = pts[(i+1)%n], cur = pts[i];
  if (prev[1] === cur[1]) prev[1] = uv.v; else prev[0] = uv.u;
  if (next[0] === cur[0]) next[0] = uv.u; else next[1] = uv.v;
  cur[0] = uv.u; cur[1] = uv.v;
}
function applyEdgeEdit(pts, i, uv) {
  const a = pts[i], b = pts[(i+1)%pts.length];
  if (a[1] === b[1]) { a[1] = b[1] = uv.v; } else { a[0] = b[0] = uv.u; }
}

let pass = 0, fail = 0;
function check(name, cond, detail="") {
  if (cond) { pass++; console.log("  PASS", name); }
  else { fail++; console.log("  FAIL", name, detail); }
}

(async () => {
  /* A. 新平面拉矩形(模擬:isNew + view 2 恆等映射) */
  console.log("== A. 新平面拉矩形 ==");
  await api("reset");
  const ids = await api("newid");
  const nid = Math.max(ids.boundary, ids.placement);
  const r1 = await api(`line surface ${nid} origin 0 0 0 u +x v +y outline 0,0 4000,0 4000,3000 0,3000`);
  check("建立矩形面", r1.ok, JSON.stringify(r1));
  const sf = await api("surfaces");
  check("surfaces 列出新面", sf.ok && sf.surfaces.some(s => s.id === nid));

  /* B. 仿射映射:JS 解出的 map 與 bridge 的 uv/proj 一致 */
  console.log("== B. 仿射映射一致性 ==");
  const sid = nid;
  const m = await uvMapFor(2, sid);   /* 俯視圖 */
  check("uvMapFor 取得映射", !!m);
  for (const [u,v] of [[0,0],[1500,700],[4000,3000],[1,2999]]) {
    const pj = await api(`proj 2 ${u} ${v} ${sid}`);
    const mq = mapUv(m, u, v);
    check(`mapUv(${u},${v})==proj`, pj.ok && Math.abs(pj.x-mq.x)<1 && Math.abs(pj.y-mq.y)<1,
          `proj=(${pj.x},${pj.y}) map=(${mq.x},${mq.y})`);
    const uvq = await api(`uv 2 ${pj.x} ${pj.y} ${sid}`);
    const uq = unmapView(m, pj.x, pj.y);
    check(`unmapView 逆解`, uvq.ok && uvq.u === uq.u && uvq.v === uq.v,
          `uv=(${uvq.u},${uvq.v}) unmap=(${uq.u},${uq.v})`);
  }
  const mFront = await uvMapFor(0, sid);
  check("前視圖看不到水平面(det=0)", mFront === null);

  /* C. bhit 命中頂點與邊 */
  console.log("== C. bhit ==");
  const hv = await api(`bhit ${sid} 0 0 60`);
  check("頂點命中", hv.ok && hv.kind === "vertex" && hv.loop === -1 && hv.index === 0, JSON.stringify(hv));
  const he = await api(`bhit ${sid} 2000 0 60`);
  check("邊命中", he.ok && he.kind === "edge" && he.loop === -1 && he.index === 0, JSON.stringify(he));
  const hn = await api(`bhit ${sid} 2000 1500 60`);
  check("中央不命中", !hn.ok, JSON.stringify(hn));

  /* D. 編輯:頂點拉角(4000,3000 → 5000,3000) */
  console.log("== D. 編輯頂點 ==");
  const b1 = await api(`boundary ${sid}`);
  const loops = b1.loops.map(l => ({ verts: l.verts.map(p=>[...p]), fixity: [...l.fixity] }));
  applyVertexEdit(loops[0].verts, 2, { u: 5000, v: 3000 });
  check("拉角後仍正交", loops[0].verts[2].join()==="5000,3000" &&
        loops[0].verts[1].join()==="5000,0" && loops[0].verts[3].join()==="0,3000");
  let s = `boundary ${sid} outline ` + vertsStr(loops[0].verts);
  const re = await api("line " + s);
  check("重宣告成功", re.ok, JSON.stringify(re));
  const b2 = await api(`boundary ${sid}`);
  check("邊界已更新", b2.ok && b2.loops[0].verts[1][0] === 5000);

  /* E. 編輯:拖邊(上邊 v=0 → v=200) */
  console.log("== E. 拖邊 ==");
  const b3 = await api(`boundary ${sid}`);
  const loops3 = b3.loops.map(l => ({ verts: l.verts.map(p=>[...p]), fixity: [...l.fixity] }));
  applyEdgeEdit(loops3[0].verts, 0, { u: 0, v: 200 });
  const re3 = await api(`line boundary ${sid} outline ` + vertsStr(loops3[0].verts));
  check("拖邊重宣告", re3.ok, JSON.stringify(re3));
  const b4 = await api(`boundary ${sid}`);
  check("邊已平移", b4.ok && b4.loops[0].verts[0].join()==="0,200" && b4.loops[0].verts[1].join()==="5000,200");

  /* F. 挖孔:矩形併入邊界重宣告 */
  console.log("== F. 挖孔 ==");
  const b5 = await api(`boundary ${sid}`);
  b5.loops.push({ verts: [[1000,1000],[2000,1000],[2000,2000],[1000,2000]], fixity: [1,1,1,1] });
  let sb = `boundary ${sid} outline ` + vertsStr(b5.loops[0].verts);
  for (let i = 1; i < b5.loops.length; ++i) sb += " hole " + vertsStr(b5.loops[i].verts);
  const re5 = await api("line " + sb);
  check("挖孔重宣告", re5.ok, JSON.stringify(re5));
  const b6 = await api(`boundary ${sid}`);
  check("孔已在", b6.ok && b6.loops.length === 2);
  const hh = await api(`bhit ${sid} 1000 1500 60`);
  check("孔邊可命中", hh.ok && hh.kind === "edge" && hh.loop === 0, JSON.stringify(hh));

  /* G. 非法輸入拒絕 */
  console.log("== G. 拒絕非法 ==");
  const g1 = await api(`line surface 9 origin 0 0 0 u +x v +y outline 0,0 4000,0 4000,3000 500,1500 0,3000`);
  check("非正交拒絕", !g1.ok);
  const g2 = await api(`line surface 9 origin 0 0 0 u +x v +y outline 0,0 4000,0 2000,0 2000,3000 4000,3000`);
  check("自交拒絕", !g2.ok);
  const g3 = await api(`line boundary ${sid} outline 0,200 5000,200 5000,3000 0,3000 hole -50,0 100,0 100,100 -50,100`);
  check("越界孔拒絕", !g3.ok);
  const b7 = await api(`boundary ${sid}`);
  check("拒絕後邊界未變", b7.ok && b7.loops.length === 2);

  /* H. dump round-trip + 引用錨點 */
  console.log("== H. dump round-trip ==");
  const d = await api("dump");
  check("dump 有內容", d.ok && d.text.includes("boundary"));
  check("dump 不含自由錨點", !/ at |at-guides|grid-ref|span-auto/.test(d.text));
  /* 重放 */
  await api("reset");
  for (const ln of d.text.split("\n").filter(l => l.trim())) {
    const rr = await api("line " + ln);
    if (!rr.ok) { check("重放: " + ln, false, JSON.stringify(rr)); }
  }
  const d2 = await api("dump");
  check("重放後 dump 相同", d2.ok && d2.text === d.text,
        "\n---原---\n" + d.text + "\n---重放---\n" + (d2.text||""));

  /* I. dump 引用保真：at-line grid 放角材後移動格線,dump 必須仍重放同一位置 */
  console.log("== I. 引用保真 ==");
  await api("reset");
  const setup = [
    "line surface 1 origin 0 0 0 u +x v +y outline 0,0 4000,0 4000,3000 0,3000",
    "line grid 1 on 1 u 2000 v 1000",
    "line timber 2 20 20 role boundary",
    "line timber 3 20 20 role boundary",
    "line place 2 on 1 at-face e0 +u +n",
    "line place 3 on 1 at-face e2 -u +n",
    "line timber 1 27 33 role primary",
    "line place 1 on 1 at-line grid 1 u 0 +v +n"
  ];
  for (const ln of setup) {
    const r = await api(ln);
    check("I setup: " + ln, r.ok, JSON.stringify(r));
  }
  const lockedMove = await api("line grid 1 on 1 u 1500");
  check("I 移動錨定軸先預覽", !lockedMove.ok && lockedMove.preview?.valid, JSON.stringify(lockedMove));
  check("I 確認後引用重算", (await api(`line confirm ${lockedMove.preview.token}`)).ok);
  const d3 = await api("dump");
  check("dump 保留線引用", d3.ok && /place 1 on 1 at-line grid 1 u 0/.test(d3.text), d3.text);
  await api("reset");
  let replayOk = true;
  for (const ln of d3.text.split("\n").filter(l => l.trim())) {
    const rr = await api("line " + ln);
    if (!rr.ok) replayOk = false;
  }
  check("引用 dump 可重放", replayOk);
  const d4 = await api("dump");
  check("引用 dump round-trip 相同", d4.ok && d4.text === d3.text,
        "\n---原---\n" + d3.text + "\n---重放---\n" + (d4.text||""));

  console.log("== J. 物件畫布層 ==");
  await api("line reset");
  check("建游離面(無承載面)",
        (await api("line boundary 10 outline 0,0 400,0 400,300 0,300")).ok);
  check("建空容器空間", (await api("line space 9")).ok);
  check("canvas-pos 面", (await api("line canvas-pos boundary 10 120 80")).ok);
  check("canvas-pos 空間", (await api("line canvas-pos space 9 500 60")).ok);
  const ob = await api("objects");
  check("objects 列游離面",
        ob.ok && ob.faces.some(f => f.id === 10 && !f.placed));
  check("objects 列空容器",
        ob.ok && ob.spaces.some(s => s.id === 9 && s.members.length === 0 && !s.closed));
  const f10 = ob.faces.find(f => f.id === 10);
  check("objects 帶畫布座標", f10 && f10.hasPos && f10.cx === 120 && f10.cy === 80,
        JSON.stringify(f10));
  check("canvas-pos 壞目標被拒",
        !(await api("line canvas-pos boundary 999 0 0")).ok);
  check("canvas-pos 壞類別被拒",
        !(await api("line canvas-pos foo 10 0 0")).ok);
  check("放置游離面",
        (await api("line placement 10 on boundary 10 origin 0 0 0 u +x v +y")).ok);
  check("面入空間(重宣告)", (await api("line space 9 boundary 10")).ok);
  const ob2 = await api("objects");
  check("空間成員可見", ob2.ok && ob2.spaces[0].members.includes(10));
  const dA = (await api("dump")).text;
  check("dump 含 canvas-pos 與空間",
        /canvas-pos boundary 10 120 80/.test(dA) && /canvas-pos space 9/.test(dA)
        && /space 9 boundary 10/.test(dA), dA);
  await api("line reset");
  let replayOk2 = true;
  for (const l of dA.trim().split("\n")) {
    if (!(await api("line " + l)).ok) replayOk2 = false;
  }
  check("物件層 dump 可重放", replayOk2);
  const dB = (await api("dump")).text;
  check("物件層 round-trip 相同", dA === dB, "\n---原---\n" + dA + "\n---重放---\n" + dB);
  /* K. RC 柱/樑(B-2):建立、z/top 推導、拒絕路徑、delete 脫鉤、round-trip */
  console.log("== K. RC 柱/樑 ==");
  await api("line reset");
  const room = [
    "boundary 1 outline 0,0 4000,0 4000,3000 0,3000",
    "placement 1 on boundary 1 origin 0 0 2500 u +x v +y",   /* 天花 +Z */
    "boundary 2 outline 0,0 3000,0 3000,4000 0,4000",
    "placement 2 on boundary 2 origin 0 0 0 u +y v +x",      /* 地板 -Z */
    "boundary 3 outline 0,0 4000,0 4000,2500 0,2500",
    "placement 3 on boundary 3 origin 0 0 0 u +x v +z",      /* 牆 y=0 -Y */
    "boundary 4 outline 0,0 2500,0 2500,4000 0,4000",
    "placement 4 on boundary 4 origin 0 3000 0 u +z v +x",   /* 牆 y=3000 +Y */
    "boundary 5 outline 0,0 2500,0 2500,3000 0,3000",
    "placement 5 on boundary 5 origin 0 0 0 u +z v +y",      /* 牆 x=0 -X */
    "boundary 6 outline 0,0 3000,0 3000,2500 0,2500",
    "placement 6 on boundary 6 origin 4000 0 0 u +y v +z",   /* 牆 x=4000 +X */
    "space 1 boundary 1 2 3 4 5 6",
  ];
  let roomOk = true;
  for (const ln of room) if (!(await api("line " + ln)).ok) roomOk = false;
  check("六面盒空間", roomOk);
  const nidK = await api("newid");
  check("newid 含 column/beam", nidK.column >= 1 && nidK.beam >= 1);
  check("柱 z 推導成功",
        (await api(`line column ${nidK.column} in 1 at 1000 800 size 500 500`)).ok);
  const dK1 = (await api("dump")).text;
  check("推導 z=0~2500 寫進 dump", /column \d+ in 1 at 1000 800 size 500 500 z 0 2500/.test(dK1), dK1);
  check("樑 top 推導成功",
        (await api(`line beam ${nidK.beam} in 1 along x from 0 to 4000 at 1500 width 300 depth 500`)).ok);
  const dK2 = (await api("dump")).text;
  check("推導 top=2500 寫進 dump", /beam \d+ in 1 along x from 0 to 4000 at 1500 width 300 depth 500 top 2500/.test(dK2), dK2);
  check("游離柱無 z 拒絕", !(await api("line column 90 at 5000 5000 size 400 400")).ok);
  check("游離柱明寫 z 成立", (await api("line column 90 at 5000 5000 size 400 400 z 0 2600")).ok);
  check("游離樑無 top 拒絕", !(await api("line beam 90 along x from 0 to 1000 at 500 width 300 depth 500")).ok);
  check("游離樑明寫 top 成立", (await api("line beam 90 along x from 0 to 1000 at 500 width 300 depth 500 top 2600")).ok);
  check("柱-柱重疊拒絕", !(await api("line column 91 in 1 at 1100 900 size 500 500")).ok);
  check("柱足跡越界拒絕", !(await api("line column 91 in 1 at 3800 2800 size 500 500")).ok);
  check("樑非法軸拒絕", !(await api("line beam 91 in 1 along z from 0 to 100 at 100 width 300 depth 500")).ok);
  check("in 不存在空間拒絕", !(await api("line column 92 in 99 at 100 100 size 300 300")).ok);
  const obK = await api("objects");
  check("objects 列柱樑",
        obK.ok && obK.columns.length === 2 && obK.beams.length === 2 &&
        obK.columns[0].box.length === 6, JSON.stringify(obK.columns));
  check("canvas-pos 柱", (await api(`line canvas-pos column ${nidK.column} 700 60`)).ok);
  check("canvas-pos 樑", (await api(`line canvas-pos beam ${nidK.beam} 900 60`)).ok);
  const obK2 = await api("objects");
  const colK = obK2.columns.find(c => c.id === nidK.column);
  check("柱卡座標落地", colK && colK.hasPos && colK.cx === 700, JSON.stringify(colK));
  /* 三視圖 render:柱/樑的投影矩形要出現在 ops(style 13/14) */
  const rdK = await api("render");
  const rcOps = (rdK.ops || []).filter(o => o.s === 13 || o.s === 14);
  check("三視圖有柱/樑投影", rcOps.length >= 2, `rc ops=${rcOps.length}`);
  /* delete 語意 */
  check("刪柱", (await api(`line delete column ${nidK.column}`)).ok);
  const obK3 = await api("objects");
  check("刪後柱消失", obK3.columns.length === 1);
  check("刪空間→柱樑脫鉤", (await api("line delete space 1")).ok);
  const dK3 = (await api("dump")).text;
  check("脫鉤後柱變游離", /column 90 at 5000 5000/.test(dK3) && !/column \d+ in 1 /.test(dK3), dK3);
  check("脫鉤後樑變游離", !/beam \d+ in 1 /.test(dK3), dK3);
  /* dump round-trip(含柱樑) */
  await api("line reset");
  let replayK = true;
  for (const l of dK3.trim().split("\n")) {
    if (!(await api("line " + l)).ok) replayK = false;
  }
  check("柱樑 dump 可重放", replayK);
  check("柱樑 round-trip 相同", (await api("dump")).text === dK3);

  /* ==== §L. obstacles 鬼影分類(R7 五種接觸,P12)==== */
  await api("line reset");
  let roomL = true;
  for (const ln of room) if (!(await api("line " + ln)).ok) roomL = false;
  check("L 六面盒重建", roomL);
  const mkL = async l => (await api("line " + l)).ok;
  check("L 獨立柱", await mkL("column 1 in 1 at 1000 1000 size 400 400"));
  check("L 貼牆柱", await mkL("column 2 in 1 at 0 1500 size 400 400"));
  check("L 角柱", await mkL("column 3 in 1 at 3600 2600 size 400 400"));
  check("L 搭牆樑", await mkL("beam 1 in 1 along y from 0 to 3000 at 2000 width 300 depth 500"));
  check("L 邊樑", await mkL("beam 2 in 1 along x from 0 to 4000 at 150 width 300 depth 400"));

  const obL1 = await api("obstacles 1");   /* 天花 +Z */
  const cls1 = Object.fromEntries((obL1.items || []).map(i => [i.type + i.id, i.cls]));
  check("天花:獨立柱→孔", cls1.column1 === "hole", JSON.stringify(cls1));
  check("天花:貼牆柱→凹口", cls1.column2 === "notch");
  check("天花:角柱→角凹", cls1.column3 === "corner");
  check("天花:搭牆樑→條帶", cls1.beam1 === "strip");
  check("天花:邊樑→條帶", cls1.beam2 === "strip");

  const obL2 = await api("obstacles 2");   /* 地板 -Z:樑不該出現 */
  const cls2 = Object.fromEntries((obL2.items || []).map(i => [i.type + i.id, i.cls]));
  check("地板:柱三分類", cls2.column1 === "hole" && cls2.column2 === "notch" &&
        cls2.column3 === "corner", JSON.stringify(cls2));
  check("地板:無樑影", !cls2.beam1 && !cls2.beam2);

  const obL3 = await api("obstacles 3");   /* 牆 y=0 -Y */
  const cls3 = Object.fromEntries((obL3.items || []).map(i => [i.type + i.id, i.cls]));
  check("牆:搭牆樑→頂凹", cls3.beam1 === "top_notch", JSON.stringify(cls3));
  check("牆:邊樑→頂降", cls3.beam2 === "top_drop");
  check("牆:柱2 不貼牆→無項", !cls3.column2);

  const obL5 = await api("obstacles 5");   /* 牆 x=0 -X:柱2 貼牆 → split */
  const cls5 = Object.fromEntries((obL5.items || []).map(i => [i.type + i.id, i.cls]));
  check("牆:貼牆柱→拆分", cls5.column2 === "split", JSON.stringify(cls5));
  check("牆:邊樑端搭→頂凹", cls5.beam2 === "top_notch");

  const obL6 = await api("obstacles 6");   /* 牆 x=4000 +X:柱3 角貼 → split */
  const cls6 = Object.fromEntries((obL6.items || []).map(i => [i.type + i.id, i.cls]));
  check("牆:角柱→拆分", cls6.column3 === "split", JSON.stringify(cls6));

  /* 鬼影不改 boundary:obstacles 前後 boundary 1 的輪廓要相同 */
  const bBefore = await api("boundary 1");
  await api("obstacles 1");
  const bAfter = await api("boundary 1");
  check("鬼影不改邊界", JSON.stringify(bBefore) === JSON.stringify(bAfter));
  /* 未放置面 → ok:false(R9) */
  const unplacedBoundary = await api("line boundary 7 outline 0,0 100,0 100,100 0,100");
  check("未放置面建立成功", unplacedBoundary.ok === true, JSON.stringify(unplacedBoundary));
  const unplacedObstacles = await api("obstacles 7");
  check("未放置面拒絕", unplacedObstacles.ok === false &&
        /尚未放置/.test(unplacedObstacles.error || ""), JSON.stringify(unplacedObstacles));

  /* ==== §M. apply-proj 套用(P13:B-1 七種分類 + 拆分/回滾)==== */
  console.log("== M. apply-proj ==");
  const freshRoom = async () => {
    await api("line reset");
    let ok = true;
    for (const ln of room) if (!(await api("line " + ln)).ok) ok = false;
    for (const ln of [
      "column 1 in 1 at 1000 1000 size 400 400",
      "column 2 in 1 at 0 1500 size 400 400",
      "column 3 in 1 at 3600 2600 size 400 400",
      "beam 1 in 1 along y from 0 to 3000 at 2000 width 300 depth 500",
      "beam 2 in 1 along x from 0 to 4000 at 150 width 300 depth 400",
    ]) if (!(await api("line " + ln)).ok) ok = false;
    return ok;
  };
  check("M 六面盒+五夾具", await freshRoom());

  /* M1 天花柱孔(id 1 同時套柱1孔+樑1條帶;條帶未勾=不裁→外環不變) */
  check("M1 apply 柱孔", (await api("line apply-proj 1 1")).ok);
  const bM1 = await api("boundary 1");
  check("M1 孔進 boundary", bM1.ok && bM1.loops.length === 2 &&
        bM1.loops[1].verts.length === 4, JSON.stringify(bM1.loops));
  check("M1 條帶未裁:外環仍是 4 頂點",
        bM1.loops[0].verts.length === 4);
  check("M1 孔 fixity 全 F", bM1.loops[1].fixity.every(f => f));

  /* M2 角柱 → 角凹(4→6 頂點) */
  check("M2 apply 角柱", (await api("line apply-proj 1 3")).ok);
  const bM2 = await api("boundary 1");
  check("M2 外環 6 頂點", bM2.loops[0].verts.length === 6,
        JSON.stringify(bM2.loops[0].verts));

  /* M3 地板貼邊柱 → 凹口(4→8 頂點) */
  check("M3 apply 貼邊柱", (await api("line apply-proj 2 2")).ok);
  const bM3 = await api("boundary 2");
  check("M3 外環 8 頂點", bM3.loops[0].verts.length === 8,
        JSON.stringify(bM3.loops[0].verts));

  /* M4 貼牆柱 → 牆拆分(同時套樑2 頂凹):面變多、空間成員掉 5 */
  check("M4 apply 牆拆分", (await api("line apply-proj 5 2")).ok);
  const obM4 = await api("objects");
  check("M4 面數 6→8(拆片+柱側面)", obM4.faces.length === 8,
        `faces=${obM4.faces.length}`);
  const spM4 = obM4.spaces.find(s => s.id === 1);
  check("M4 空間成員剔除原牆", spM4 && !spM4.members.includes(5) &&
        spM4.members.length === 5, JSON.stringify(spM4 && spM4.members));
  const bM4 = await api("boundary 5");
  check("M4 原 id 留最大片", bM4.ok && bM4.loops[0].verts.length >= 4);
  /* dump 回讀 */
  const dM4 = (await api("dump")).text;
  await api("line reset");
  let rpM4 = true;
  for (const l of dM4.trim().split("\n"))
    if (!(await api("line " + l)).ok) rpM4 = false;
  check("M4 dump 可重放", rpM4);
  check("M4 round-trip 相同", (await api("dump")).text === dM4);

  /* M5 條帶裁切:天花拆兩片 + 樑底 + 樑兩側 = +4 面,孔重分配 */
  check("M5 重建", await freshRoom());
  check("M5 apply 柱孔先落", (await api("line apply-proj 1 c1")).ok);
  check("M5 重套同孔拒絕(快照)", !(await api("line apply-proj 1 c1")).ok);
  check("M5 apply cut-strip", (await api("line apply-proj 1 b1 cut-strip")).ok);
  const obM5 = await api("objects");
  check("M5 面數 6→10", obM5.faces.length === 10,
        `faces=${obM5.faces.length}`);
  const spM5 = obM5.spaces.find(s => s.id === 1);
  check("M5 天花退出空間", spM5 && !spM5.members.includes(1));
  /* 孔(在 u<1850 片)要跟著到新片,不該留在保留片 */
  const bM5 = await api("boundary 1");
  check("M5 保留片無孔", bM5.ok && bM5.loops.length === 1,
        JSON.stringify(bM5.loops && bM5.loops.length));
  const holePiece = obM5.faces.find(f => f.id !== 1 && f.id > 6);
  const bM5b = holePiece && await api(`boundary ${holePiece.id}`);
  check("M5 孔隨片走", bM5b && bM5b.loops && bM5b.loops.length === 2,
        JSON.stringify(holePiece));
  /* render 一致性:新片+樑面照常出 ops */
  const rdM5 = await api("render");
  check("M5 render 有面", (rdM5.ops || []).length > 0);

  /* M6 回滾:不存在的項目 id → 拒絕且世界不變 */
  const dPre = (await api("dump")).text;
  check("M6 壞 id 拒絕", !(await api("line apply-proj 1 99")).ok);
  check("M6 世界未變", (await api("dump")).text === dPre);
  /* M7 未放置面拒絕(R9) */
  check("M7 不存在面拒絕", !(await api("line apply-proj 20 1")).ok);
  check("M7 建未放置面", (await api("line boundary 20 outline 0,0 100,0 100,100 0,100")).ok);
  check("M7 未放置面拒絕(R9)", !(await api("line apply-proj 20 1")).ok);

  /* M8 拆分時承載面輔助資料跟著含錨點的那片走(R13):
     天花(u=x 0-4000, v=y 0-3000)被 x=2800±150 的樑條帶裁切 →
     保留片 u<2650(id 1 留最大片),新片 u>2950(新 id)。
     錨在新片的 guide/grid/timber 要改掛新承載面;
     錨在移除帶的 guide → 整筆拒絕回滾。 */
  check("M8 重建", await freshRoom());
  check("M8 建樑(x=2800)", (await api(
        "line beam 3 in 1 along y from 0 to 3000 at 2800 width 300 depth 500")).ok);
  let auxOk = true;
  for (const ln of [
    "spec 分片定位 3500", "guide 1 1 v spec:分片定位",        /* 固定 u=3500 → 只在新片 */
    "spec 兩片共線 1500", "guide 2 1 u spec:兩片共線",        /* 固定 v=1500 → 兩片都合法 → 留原片 */
    "grid 1 on 1 u 3500 v 1500",/* u 座標 3500 → 只在新片 */
  ]) if (!(await api("line " + ln)).ok) { auxOk = false; console.log("  M8 aux fail:", ln); }
  check("M8 輔助資料就緒", auxOk);
  check("M8 apply cut-strip", (await api("line apply-proj 1 b3 cut-strip")).ok);
  const dM8 = (await api("dump")).text;
  check("M8 新片 guide 改掛", /guide 1 7 v spec:分片定位/.test(dM8), dM8);
  check("M8 兩棲 guide 留原片", /guide 2 1 u spec:兩片共線/.test(dM8), dM8);
  check("M8 網格改掛新片", /grid 1 on 7/.test(dM8), dM8);
  /* 引用角材隨分片的交易由 test_reference_contract.py 驗收。 */
  /* M8b 錨在移除帶(u=2800)的 guide → 整筆拒絕,世界不變 */
  check("M8b 重建", await freshRoom() &&
        (await api("line beam 3 in 1 along y from 0 to 3000 at 2800 width 300 depth 500")).ok &&
        (await api("line spec 帶上定位 2800")).ok && (await api("line guide 1 1 v spec:帶上定位")).ok);
  const dM8b = (await api("dump")).text;
  check("M8b 帶上錨點拒絕", !(await api("line apply-proj 1 b3 cut-strip")).ok);
  check("M8b 世界未變", (await api("dump")).text === dM8b);

  if (process.env.GEOMETRY_AUDIT === "1") {
    console.log("== Audit: projection transactions ==");
    check("Audit 多樑場景", await freshRoom());
    for (const ln of [
      "delete column 1", "delete column 2", "delete column 3",
      "beam 1 in 1 along y from 0 to 3000 at 2800 width 300 depth 500",
      "beam 2 in 1 along y from 0 to 3000 at 3500 width 200 depth 400",
    ]) check("Audit setup " + ln, (await api("line " + ln)).ok);
    const multiBefore = (await api("dump")).text;
    const multi = await api("line apply-proj 1 b1 b2 cut-strip");
    check("Audit 同時裁兩條互不相交樑", multi.ok, JSON.stringify(multi));
    if (multi.ok) check("Audit 兩條樑共生成八個新面", (await api("objects")).faces.length === 14);
    else check("Audit 多樑失敗完整回滾", (await api("dump")).text === multiBefore);

    check("Audit 混合有效/無效項目場景", await freshRoom());
    const invalidBefore = (await api("dump")).text;
    const invalid = await api("line apply-proj 1 c1 c999");
    check("Audit 不得靜默忽略不存在的指定項目", !invalid.ok, JSON.stringify(invalid));
    check("Audit 無效清單世界不變", (await api("dump")).text === invalidBefore);

    check("Audit 牆面投影場景", await freshRoom());
    const topNotch = await api("line apply-proj 3 b1");
    check("Audit 搭牆樑頂凹可套用", topNotch.ok, JSON.stringify(topNotch));
    check("Audit 整段降牆場景", await freshRoom());
    const dropBefore = (await api("dump")).text;
    const topDrop = await api("line apply-proj 3 b2");
    check("Audit 邊樑整段降牆可套用", topDrop.ok, JSON.stringify(topDrop));
    if (!topDrop.ok) check("Audit 降牆失敗完整回滾", (await api("dump")).text === dropBefore);
    check("Audit 貼牆柱場景", await freshRoom());
    const side = await api("line apply-proj 5 c2");
    check("Audit 貼牆柱拆分成功", side.ok, JSON.stringify(side));
    const generated = (await api("surfaces")).surfaces.filter(s => s.id > 6);
    check("Audit 柱露出面位於柱前緣x=400而非原牆x=0", generated.some(s => s.origin[0] === 400 && s.u[0] === 0 && s.v[0] === 0), JSON.stringify(generated));

    for (const fixture of ["_rc_col_free.scene", "_rc_col_wall.scene", "_rc_col_corner.scene", "_rc_beam_cross.scene", "_rc_beam_edge.scene"]) {
      const loaded = await api("loadfile " + require("path").resolve(__dirname, "..", fixture));
      check("Audit 載入 " + fixture, loaded.ok);
      const original = (await api("dump")).text;
      await api("line reset");
      let replayed = true;
      for (const ln of original.trim().split("\n")) if (!(await api("line " + ln)).ok) replayed = false;
      check("Audit 回讀保真 " + fixture, replayed && (await api("dump")).text === original);
    }
  }

  /* ==== §N. 協定防護(Bugfix 2026-09-14,僅 http 模式)==== */
  if (!DIRECT) {
    console.log("== N. 協定防護 ==");
    /* N1:cmd 含換行 → serve.py 直接拒絕,不送 bridge;
       之後 dump/newid 回應仍一一對得上(無錯位) */
    const n1 = await api("objects\nobjects");
    check("N1 含換行 cmd 拒絕", n1.ok === false && !!n1.error, JSON.stringify(n1));
    check("N1b 含 \\r cmd 拒絕", (await api("objects\robjects")).ok === false);
    const dN = await api("dump");
    check("N1 dump 仍對得上", dN.ok === true && typeof dN.text === "string");
    const idN = await api("newid");
    check("N1 newid 仍對得上", idN.ok === true && idN.boundary >= 1);

    /* N2:超過 bridge 4096 緩衝的單行 → 伺服器先擋 */
    const n2 = await api("line " + "x".repeat(5000));
    check("N2 5000 bytes cmd 拒絕", n2.ok === false && !!n2.error, JSON.stringify(n2));
    check("N2 後續 newid 正常", (await api("newid")).ok === true);

    /* N3:Origin/Host 白名單(L3) */
    const post = (path, headers, body) => fetch(new URL(path, API_URL), {
      method: "POST", headers, body
    });
    const n3a = await post("/api", { "Content-Type": "application/json",
      "Origin": "http://evil.example" }, JSON.stringify({ cmd: "newid" }));
    check("N3 惡意 Origin → 403", n3a.status === 403, "status=" + n3a.status);
    const n3b = await post("/api", { "Content-Type": "application/json",
      "Origin": new URL(API_URL).origin }, JSON.stringify({ cmd: "newid" }));
    check("N3 本機 Origin → 200", n3b.status === 200 && (await n3b.json()).ok === true);
    const n3c = await post("/api", { "Content-Type": "application/json" },
      JSON.stringify({ cmd: "newid" }));
    check("N3 無 Origin 放行", n3c.status === 200 && (await n3c.json()).ok === true);
    /* Host 偽造:fetch 禁改 Host,走 http.request */
    const n3d = await new Promise(res => {
      const rq = require("http").request(
        { host: new URL(API_URL).hostname, port: new URL(API_URL).port, path: "/api", method: "POST",
          headers: { "Content-Type": "application/json", "Host": "evil.example" } },
        r => { r.resume(); res(r.statusCode); });
      rq.on("error", () => res(0));
      rq.end(JSON.stringify({ cmd: "newid" }));
    });
    check("N3 偽造 Host → 403", n3d === 403, "status=" + n3d);
  }

  /* ==== §U. undo 歷史語義(Bugfix 2026-09-14,L1+L2)==== */
  console.log("== U. undo 歷史語義 ==");
  await api("default");

  /* U1 L1:canvas-pos 是展示中繼資料,不進歷史——undo/redo 不得把卡片擺位倒回去 */
  await api("line boundary 2 outline 0,0 100,0 100,100 0,100");
  await api("line boundary 3 outline 200,0 300,0 300,100 200,100");
  await api("line canvas-pos boundary 2 777 333");
  await api("line undo");      /* 退掉 boundary 3;面2 的擺位應保留 */
  const u1o = await api("objects");
  const u1f = u1o.faces.find(f => f.id === 2);
  check("U1 undo 保留 canvas-pos",
        u1f && u1f.hasPos === true && u1f.cx === 777 && u1f.cy === 333,
        JSON.stringify(u1f));
  await api("line canvas-pos boundary 2 555 111");   /* undo 後又拖 */
  await api("line redo");                            /* boundary 3 回來 */
  const u1o2 = await api("objects");
  const u1f2 = u1o2.faces.find(f => f.id === 2);
  check("U1b redo 保留 canvas-pos",
        u1f2 && u1f2.hasPos === true && u1f2.cx === 555 && u1f2.cy === 111,
        JSON.stringify(u1f2));

  /* U2 L2:history-begin/end 把多行收成一步歷史 */
  await api("default");
  const u2b = await api("objects");
  await api("line history-begin");
  await api("line boundary 5 outline 0,0 50,0 50,50 0,50");
  await api("line boundary 6 outline 60,0 110,0 110,50 60,50");
  await api("line boundary 7 outline 120,0 170,0 170,50 120,50");
  await api("line history-end");
  const u2c = await api("objects");
  check("U2 群組建 3 面", u2c.faces.length === u2b.faces.length + 3,
        `${u2c.faces.length} vs ${u2b.faces.length}`);
  await api("line undo");
  check("U2 一次 undo 全退",
        (await api("objects")).faces.length === u2b.faces.length);
  await api("line redo");
  check("U2 一次 redo 全回",
        (await api("objects")).faces.length === u2b.faces.length + 3);

  /* U3 L2:群組第 2 行失敗 → 整組回滾,世界與群組前逐字相同,不留歷史 */
  await api("default");        /* world_default 內 history_clear,歷史歸零 */
  const d0 = (await api("dump")).text;
  await api("line history-begin");
  check("U3 群組內首行成功",
        (await api("line boundary 8 outline 0,0 50,0 50,50 0,50")).ok === true);
  check("U3 群組內壞行回絕",
        (await api("line boundary 8 bogus")).ok === false);
  check("U3 失敗群組世界復原", (await api("dump")).text === d0);
  const u3u = await api("line undo");
  check("U3 失敗群組不留歷史", u3u.ok === false, JSON.stringify(u3u));

  /* R. timber role 子句（GEO-090、I18）：
     無 role / custom 無 priority / priority 配非 custom → 拒絕;
     合法宣告後 dump 帶角色,重放 round-trip 逐字相同。 */
  console.log("== R. 角色子句（GEO-090）==");
  await api("reset");
  check("R1 無 role 拒絕",
        !(await api("line timber 9 27 33")).ok);
  check("R1b 明寫無 role 拒絕",
        !(await api("line timber 9 1800 27 33")).ok);
  check("R2 custom 無 priority 拒絕",
        !(await api("line timber 9 27 33 role custom")).ok);
  check("R3 priority 配非 custom 拒絕",
        !(await api("line timber 9 27 33 role primary priority 2")).ok);
  check("R3b 不認得角色拒絕",
        !(await api("line timber 9 27 33 role foo")).ok);
  check("R3c priority 0 拒絕",
        !(await api("line timber 9 27 33 role custom priority 0")).ok);
  check("R3d 壞行後世界無角材",
        !(await api("dump")).text.includes("timber"));
  for (const ln of [
    "line surface 1 origin 0 0 0 u +x v +y outline 0,0 4000,0 4000,3000 0,3000",
    "line timber 90 20 20 role boundary", "line place 90 on 1 at-face e0 +u +n",
    "line timber 91 20 20 role boundary", "line place 91 on 1 at-face e2 +u +n",
    "line grid 1 on 1 u 500 2000",
    "line timber 1 27 33 role primary", "line place 1 on 1 at-line grid 1 u 0 +v +n",
    "line timber 2 20 20 role custom priority 4", "line place 2 on 1 at-line grid 1 u 1 +v +n",
  ]) await api(ln);
  const dR = (await api("dump")).text;
  check("R4 dump 含角色",
        /timber 1 27 33 role primary/.test(dR) &&
        /timber 2 20 20 role custom priority 4/.test(dR), dR);
  await api("reset");
  let okR = true;
  for (const ln of dR.split("\n").filter(l => l.trim())) {
    if (!(await api("line " + ln)).ok) okR = false;
  }
  check("R5 含角色 dump 可重放", okR);
  check("R6 含角色 round-trip 相同",
        (await api("dump")).text === dR);

  /* S. 主支軸與有效擋面，所有放置皆經新引用語法。 */
  await api("reset");
  for (const ln of setup) check("S setup", (await api(ln)).ok, ln);
  await api("line timber 4 27 33 role primary");
  const axisBefore = (await api("dump")).text;
  const axisBad = await api("line place 4 on 1 at-line grid 1 v 0 through 2500 +u +n");
  check("S 換主支軸拒絕", !axisBad.ok && /V_PRIMARY_AXIS/.test(axisBad.error), JSON.stringify(axisBad));
  check("S 換軸失敗回滾", (await api("dump")).text === axisBefore);
  await api("line delete timber 4");
  const removePrimary = await api("line delete timber 1");
  check("S 刪除主支需預覽", removePrimary.preview?.valid);
  check("S 刪除確認", (await api(`line confirm ${removePrimary.preview.token}`)).ok);
  await api("line timber 4 27 33 role primary");
  const fallback = await api("line place 4 on 1 at-line grid 1 v 0 +u +n");
  check("S 刪除後由 boundary 定軸", !fallback.ok && /V_PRIMARY_AXIS/.test(fallback.error), JSON.stringify(fallback));

  console.log("== Review regression ==");
  await api("default");
  check("失敗前建立可重做操作", (await api("line space 77")).ok);
  check("復原成功", (await api("line undo")).ok);
  check("壞指令拒絕", !(await api("line bogus")).ok);
  check("失敗不清 redo", (await api("line redo")).ok);
  check("redo 恢復空間", (await api("objects")).spaces.some(s => s.id === 77));

  await api("default");
  for (let i = 0; i < 32; i++) check("填滿歷史 " + i, (await api(`line spec 歷史步驟 ${400 + i}`)).ok);
  check("滿歷史壞指令拒絕", !(await api("line bogus")).ok);
  let undoCount = 0;
  while ((await api("line undo")).ok) undoCount++;
  check("失敗不擠掉最舊歷史", undoCount === 32, String(undoCount));

  for (const bad of [
    "line canvas-pos boundary 999 1 2",
    "line space 77 " + "junk ".repeat(160),
    "line space 77 " + " ".repeat(2050) + "garbage",
  ]) {
    await api("default");
    const before = (await api("dump")).text;
    check("群組開始", (await api("line history-begin")).ok);
    check("群組首行", (await api("line space 77")).ok);
    check("群組壞行拒絕 " + bad.slice(0, 38), !(await api(bad)).ok);
    check("群組壞行自動回滾", (await api("dump")).text === before);
    check("群組壞行後不能提交", !(await api("line history-end")).ok);
    await api("line history-abort");
    check("群組壞行不留歷史", !(await api("line undo")).ok);
  }

  await api("default");
  const inputBefore = (await api("dump")).text;
  // Scene lines now support 16 KiB, while this bridge command transport is
  // still bounded to 4094 UTF-8 bytes including the "line " prefix. Use valid
  // definitions with trailing comments so rejection really tests capacity.
  for (const bad of ["line space 77 #".padEnd(4095, "x"),
                     "line space 88 #".padEnd(4200, " "),
                     "line space 88 #" + "界".repeat(1361)]) {
    check("超限橋接指令拒絕", !(await api(bad)).ok);
    check("超限橋接指令不修改世界", (await api("dump")).text === inputBefore);
    check("超限後下一筆指令仍完整", (await api("newid")).ok);
  }
  check("合法空白 DSL 接受", (await api("line   ")).ok);
  check("合法註解接受", (await api("line # empty")).ok);
  check("合法多位元組註解不受舊2KiB上限限制", (await api("line space 88 #" + "界".repeat(700))).ok);
  const maxLine = "line space 77 #".padEnd(4094, "x");
  check("橋接指令4094-byte邊界接受", (await api(maxLine)).ok);
  const atLimit = (await api("dump")).text;
  check("橋接指令4095-byte拒絕", !(await api(maxLine + "x")).ok);
  check("橋接邊界後拒絕不修改世界", (await api("dump")).text === atLimit);

  await api("reset");
  for (const ln of setup) check("grid-ref setup", (await api(ln)).ok, ln);
  const gridDump = (await api("dump")).text;
  check("dump 保留 at-line grid", /place 1 on 1 at-line grid 1 u 0/.test(gridDump.split("\n").find(l => l.startsWith("place 1 ")) || ""));
  const renderBefore = await api("render");
  const lockedChange = "line grid 1 on 1 u 1500";
  let locked = await api(lockedChange);
  check("重放前引用變更需預覽", !locked.ok && /I8a/.test(locked.error || ""));
  await api("reset");
  for (const ln of gridDump.split("\n").filter(l => l.trim())) check("grid-ref 重放", (await api("line " + ln)).ok, ln);
  check("grid-ref dump 往返一致", (await api("dump")).text === gridDump);
  check("grid-ref 幾何不重算", JSON.stringify(await api("render")) === JSON.stringify(renderBefore));
  locked = await api(lockedChange);
  check("重放後引用變更需預覽", !locked.ok && /I8a/.test(locked.error || ""));
  locked = await api("line delete grid 1");
  check("重放後不能刪引用網格", !locked.ok && /I8a/.test(locked.error || ""));
  check("重放後追加格線合法", (await api("line grid 1 on 1 u 2000 2500")).ok);
  check("重放後仍驗 auto 端面支撐", !(await api("line delete timber 2")).ok);

  const savedPlace = gridDump.split("\n").find(l => l.startsWith("place 1 "));
  for (const suffix of ["grid-ref 999 u 0", "grid-ref 1 v 0", "grid-ref 1 u -1", "grid-ref 1 u 99", "grid-ref 1 u 1", "grid-ref 1 u 2147483648"]) {
    await api("reset");
    for (const ln of gridDump.split("\n").filter(l => l.trim() && !l.startsWith("place 1 "))) check("壞引用 setup", (await api("line " + ln)).ok, ln);
    check("壞引用 setup 追加線", (await api("line grid 1 on 1 u 2000 2500")).ok);
    const before = (await api("dump")).text;
    const ln = savedPlace.replace(/ grid-ref .*/, "") + " " + suffix;
    check("壞引用拒絕 " + suffix, !(await api("line " + ln)).ok);
    check("壞引用不修改世界", (await api("dump")).text === before);
  }

  await api("default");
  check("default 可建世界", (await api("dump")).ok);
  await api("line space 99");
  check("reset 前可 undo", (await api("line undo")).ok);
  await api("line space 99");
  await api("reset");
  check("reset 後 undo 疊已清", !(await api("line undo")).ok);

  await api("reset");
  for (const ln of [
    "surface 1 origin 0 0 2500 u +x v +y outline 0,0 4000,0 4000,3000 0,3000",
    "grid 1 on 1 u 2000",
    "timber 1 20 20 role boundary",
    "timber 2 20 20 role boundary",
    "place 1 on 1 at-face e0 +u +n",
    "place 2 on 1 at-face e2 -u +n",
    "timber 3 27 33 role primary",
  ]) check("through-short setup", (await api("line " + ln)).ok, ln);
  const beforeShort = (await api("dump")).text;
  const shortPlace = await api("line place 3 on 1 at-line grid 1 u 0 through 1000");
  check("through 漏方向拒絕", !shortPlace.ok);
  check("through 漏方向不改世界", (await api("dump")).text === beforeShort);

  await api("reset");
  const priorityFixture = require("fs").readFileSync(require("path").join(__dirname, "../_edge_i19_place_order.scene"), "utf8").trim().split(/\r?\n/).filter(l => l && !l.startsWith("#"));
  const priorityLast = priorityFixture.pop();
  for (const ln of priorityFixture) check("I19 setup", (await api("line " + ln)).ok, ln);
  const beforeI19 = (await api("dump")).text;
  const i19 = await api("line " + priorityLast);
  check("I19 後放高優先級不得被副支裁切", !i19.ok && /V_CUT_PRIORITY/.test(i19.error || ""), JSON.stringify(i19));
  check("I19 後放不改世界", (await api("dump")).text === beforeI19);

  await api("default");

  for (const cmd of ["", "   ", "\t"]) {
    try {
      const r = await Promise.race([
        api(cmd),
        new Promise((_, reject) => setTimeout(() => reject(new Error("空指令逾時")), 2000).unref()),
      ]);
      check("空指令拒絕 " + JSON.stringify(cmd), r.ok === false && !!r.error);
      const next = await Promise.race([
        api("newid"),
        new Promise((_, reject) => setTimeout(() => reject(new Error("後續指令逾時")), 2000).unref()),
      ]);
      check("空指令後通道可用", next.ok && Number.isInteger(next.boundary));
    } catch (err) {
      check("空指令不能阻塞通道", false, err.message);
      break;
    }
  }

  console.log(`\n${pass} pass / ${fail} fail`);
  process.exit(fail ? 1 : 0);
})();
