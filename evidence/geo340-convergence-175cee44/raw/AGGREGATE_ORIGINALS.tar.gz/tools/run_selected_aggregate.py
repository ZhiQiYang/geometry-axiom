"""Run the unchanged selected aggregate row at S175, preserving shared logs."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import resource
import shutil
import traceback

S = '175cee44c56c89871803d955c0c525236727ba65'
OLD = 'bfbab207a92a809fca50fefcefb3fa4b2af05ea9'
R = Path('/tmp/geo340-L-merge-work-20261024')
O = Path('/workspace/geo340-S175-selected-aggregate-20261024')
P = Path('/workspace/geo340-aggregate-preparation-20261024')
T = Path('/tmp/geo340-S175-selected-aggregate-scratch')
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
LOGS = Path('/tmp/geometry-tests/run_all-logs')
LOCK = Path('/tmp/g261r3/secondary.lock')
BIN_NAMES = ('core', 'bridge', 'pf3-algorithm', 'integrity', 'gdi-contract', 'model-base', 'engineering-json-test')

def need(value, message):
    if not value:
        raise RuntimeError(message)

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(data):
    return hashlib.sha256(data).hexdigest()

need(sha(CAP.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'capture original pin')
closure = json.loads((P / 'SELECTED_AGGREGATE_CLOSURE.json').read_text())
need(closure['source'] == S and closure['selectedNeeds'] == [] and closure['counts']['totalLeaves'] == 329,
     'fixed original closure')
need(closure['expected'] == {'mode': 'count', 'count': 13, 'unit': 'unittest'}, 'fixed expected13')
need(not O.exists() and not T.exists(), 'fresh distinct output and native scratch required')
O.mkdir()
report = {'schema': 'kernel-selected-original-aggregate/1', 'source': S,
          'argv': ['python3', '-B', 'tests/run_all.py', '--only', 'test_rectangular_template'],
          'subjectExit': None, 'exitCode': None, 'sourceBeforeAfter': False,
          'fullAggregate': False, 'originalSuiteTimeoutSeconds': 1200,
          'originalCompilerTimeoutSeconds': 120, 'originalNativeCaseTimeoutSeconds': 10,
          'globalBinaryBuildRequested': False, 'globalBinaryCacheUnchanged': None,
          'priorRowLogsRestored': None, 'ledgerRegenerated': False, 'sevenJobsRun': False,
          'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'errors': []}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8',
           GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', TMPDIR=str(T),
           GITHUB_SHA=S, GITHUB_WORKSPACE=str(R), GEO261_RECTANGULAR_EVIDENCE=str(O / 'NATIVE_LOG.json'))
for key in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONSTARTUP', 'GIT_INDEX_FILE', 'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR'):
    env.pop(key, None)
spec = importlib.util.spec_from_file_location('cap', CAP)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
rec = cap.Recorder(O, env, S)
prior_logs = {}
cache_before = None
slot = None

def run(argv, cwd=R, data=None, check=True):
    row, out, err = rec.run(argv, cwd=cwd, data=data, timeout=None, check=False,
                           source_sha=S, source_variant='original-selected-aggregate-unchanged-judges')
    if check:
        need(row['actual_process_returncode'] == 0, 'original command failed: ' + row['directory'])
    return row, out, err

def git(*argv, data=None):
    return run(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *argv], data=data)[1]

def clean():
    need(git('rev-parse', 'HEAD').decode().strip() == S, 'real fixed source HEAD')
    need(git('symbolic-ref', '--short', 'HEAD').decode().strip() == 'codex/kernel-without-woodworking-20261023', 'owned source branch')
    need(git('status', '--porcelain=v1', '--untracked-files=all') == b'', 'dirty checkout')
    need(git('diff', '--cached', '--exit-code', '--name-status', 'HEAD') == b'', 'tracked deletion or index drift')
    need(git('diff', '--exit-code', '--name-status') == b'', 'working source drift')

def space(stage):
    values = {p: shutil.disk_usage(p).free for p in ('/workspace', '/tmp')}
    report.setdefault('spaceObservations', []).append({'stage': stage, 'freeBytes': values})
    dump(O / 'LIVE.json', report)
    need(all(n >= 20 * 1024 * 1024 for n in values.values()), 'ENV_SPACE: original 20MiB WS/TMP planning guard')

def source_snapshot(label):
    rows = []
    for name, entry in sorted(closure['entries'].items()):
        p = R / name
        need(p.is_file() and not p.is_symlink(), 'missing real source: ' + name)
        b = p.read_bytes()
        oid = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        need(oid == entry['blob'] and len(b) == entry['bytes'], 'Git source mismatch: ' + name)
        rows.append({'path': name, 'bytes': len(b), 'gitBlob': oid, 'sha256': sha(b)})
    dump(O / (label + '-source.json'), rows)
    return rows

def cache_state():
    rows = {}
    for name in BIN_NAMES:
        for suffix in ('', '.fingerprint.json', '.pending.json'):
            p = Path('/tmp/geometry-tests') / (name + suffix)
            if p.exists():
                s = p.stat()
                value = {'bytes': s.st_size, 'device': s.st_dev, 'inode': s.st_ino,
                         'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}
                if suffix:
                    value['sha256'] = sha(p.read_bytes())
                rows[str(p)] = value
            else:
                rows[str(p)] = None
    return rows

try:
    space('before-materialization')
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    slot = LOCK.open('a+b')
    fcntl.flock(slot.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    report['secondarySlotHeld'] = str(LOCK)
    clean()
    pattern = (P / 'SELECTED_SPARSE_STDIN.txt').read_bytes()
    need(pattern == ''.join('/' + p + '\n' for p in sorted(closure['entries'])).encode(), 'exact original source paths')
    git('sparse-checkout', 'set', '--no-cone', '--stdin', data=pattern)
    clean()
    before = source_snapshot('before')
    need(json.loads((R / 'tests/run_all.expected.json').read_text())['suites']['py:test_rectangular_template'] == closure['expected'], 'exact original strict row')
    for name in json.loads(Path('/workspace/geo340-339-L-normal-merges-20261024-r2/RESULT.json').read_text())['originalElevenKernelGitEntries']:
        old_bytes = git('show', OLD + ':' + name)
        need(old_bytes == (R / name).read_bytes(), 'old actual11 closure differs: ' + name)
    (O / 'prior-row-logs').mkdir()
    for suffix in ('.log', '.json', '.unittest.log'):
        p = LOGS / ('py_test_rectangular_template' + suffix)
        need(p.is_file(), 'expected original shared row log missing: ' + str(p))
        b = p.read_bytes()
        (O / 'prior-row-logs' / p.name).write_bytes(b)
        prior_logs[p.name] = {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
    dump(O / 'PRIOR_ROW_LOGS.json', prior_logs)
    cache_before = cache_state()
    dump(O / 'GLOBAL_CACHE_BEFORE.json', cache_before)
    T.mkdir()
    space('before-formal-row')
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK, (16 * 1024 * 1024, hard))
    report['stackLimitBytes'] = 16 * 1024 * 1024
    row, out, err = run(report['argv'], check=False)
    report['subjectExit'] = row['actual_process_returncode']
    report['subjectCommandDirectory'] = row['directory']
    (O / 'new-row-logs').mkdir()
    for suffix in ('.log', '.json', '.unittest.log'):
        p = LOGS / ('py_test_rectangular_template' + suffix)
        if p.is_file():
            (O / 'new-row-logs' / p.name).write_bytes(p.read_bytes())
    clean()
    after = source_snapshot('after')
    need(before == after, 'formal changed source bytes')
    report['sourceBeforeAfter'] = True
    detail = json.loads((O / 'new-row-logs/py_test_rectangular_template.json').read_text())
    report['originalUnittestDetail'] = detail
    need(row['actual_process_returncode'] == 0, 'original aggregate row nonzero; raw retained')
    need(detail['total'] == detail['run'] == detail['passed'] == 13 and detail['failed'] == detail['skipped'] == 0,
         'original aggregate13 result not complete')
    need(detail['extra_errors'] == 0 and detail['import_error'] is None, 'runner error')
    native = json.loads((O / 'NATIVE_LOG.json').read_text())
    need(native['commands'] and all(isinstance(c.get('exit'), int) for c in native['commands']), 'native original command records required')
    report['nativeCommandCount'] = len(native['commands'])
    report['nativeExitHistogram'] = {str(code): sum(c['exit'] == code for c in native['commands'])
                                   for code in sorted({c['exit'] for c in native['commands']})}
    report['exitCode'] = 0
except BaseException:
    report['errors'].append(traceback.format_exc())
    report['exitCode'] = 1
finally:
    try:
        for name, entry in prior_logs.items():
            original = (O / 'prior-row-logs' / name).read_bytes()
            need(sha(original) == entry['sha256'], 'prior row backup corrupted')
            Path(entry['path']).write_bytes(original)
            need(Path(entry['path']).read_bytes() == original, 'prior row restoration failed')
        report['priorRowLogsRestored'] = bool(prior_logs)
        if cache_before is not None:
            after_cache = cache_state()
            dump(O / 'GLOBAL_CACHE_AFTER.json', after_cache)
            need(after_cache == cache_before, 'global binaries or sidecars changed')
            report['globalBinaryCacheUnchanged'] = True
    except BaseException:
        report['errors'].append(traceback.format_exc())
        report['exitCode'] = 1
    if slot is not None:
        slot.close()
    report['endedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['limitations'] = ['Selected aggregate row only, not full native or seven jobs.',
        'Original NativeBuild text compiler capture and native text output retained; original test cleanup remains unchanged.',
        'Unused global binary fingerprints may be stale for the thin checkout; no fake fresh state and no build requested.',
        'No mutation ledger regeneration or new seven-phase proof; original bfb proof retained by exact11 source closure.']
    dump(O / 'RESULT.json', report)
print(json.dumps(report, ensure_ascii=False))
raise SystemExit(report['exitCode'])
