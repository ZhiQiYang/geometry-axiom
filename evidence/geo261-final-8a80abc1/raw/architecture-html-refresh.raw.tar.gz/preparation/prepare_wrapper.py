#!/usr/bin/env python3
"""只產生 HTML-only wrapper 與精確 diff；不 import/執行 wrapper 或裁判。"""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/geo261-environment')
OUT = Path(__file__).resolve().parent
SOURCE = ROOT/'refresh_architecture_linux.py'
TARGET = ROOT/'refresh_architecture_canonical_html_linux.py'
raw = SOURCE.read_bytes()
text = raw.decode()
adaptations = []


def replace(old, new, label):
    global text
    count = text.count(old)
    if count != 1:
        raise RuntimeError(label+': expected one exact anchor, found '+str(count))
    text = text.replace(old, new, 1)
    adaptations.append({'label': label, 'exact_anchor_count': count})


replace('"""雲端 Linux 的有限架構四檔重產封裝器；保留原裁判，不修改來源 checkout。"""',
        '"""canonical HTML 同步後的 Linux 架構四檔重產；不改 manifest 政策或來源 checkout。"""', 'tool name and scope')
replace("SERIALIZATION = 'SHA-256", "HTML_INPUT = 'geometry-guide/公理層-閱讀器.html'\nSERIALIZATION = 'SHA-256", 'one explicit HTML source')
replace("    parser.add_argument('--allow-changed', action='append', default=[], help='允許改動的既有產品輸入；預設僅 geometry-web/app.js')",
        "    parser.add_argument('--sha', required=True, help='已正常推送、乾淨固定來源的完整 SHA；由外層流程先證明可由 GitHub 解析')\n"
        "    parser.add_argument('--allow-changed', action='append', default=[], help='僅可明列 geometry-guide/公理層-閱讀器.html；不得擴張範圍')", 'explicit fixed SHA and nonextensible source')
replace("    repo, out = args.repo.resolve(), args.out.resolve()\n",
        "    repo, out = args.repo.resolve(), args.out.resolve()\n"
        "    require(sys.flags.optimize == 0, '拒絕最佳化 Python；裁判完整 guard 必須生效')\n"
        "    require(re.fullmatch('[0-9a-f]{40}', args.sha) is not None, '必須明填完整40位固定 SHA')\n"
        "    require(not args.allow_changed or args.allow_changed == [HTML_INPUT], '本工具不批准 HTML 以外來源或重複旗標')\n", 'fixed SHA and single allowed-path guards')
replace("    env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8',",
        "    env = dict({key: value for key, value in os.environ.items() if key != 'PYTHONOPTIMIZE'}, LANG='C.UTF-8', LC_ALL='C.UTF-8',", 'preserve active assertions in children')
replace("    safe_env = {name: env[name] for name in ('LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'TMPDIR')}",
        "    safe_env = {name: env.get(name) for name in ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'TMPDIR', 'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP')}", 'record effective Python and path environment')
replace("    bound_head = None", "    bound_head = args.sha", 'first command also binds requested SHA')
replace("        require(re.fullmatch('[0-9a-f]{40}', head) is not None, '需要可解析完整來源 SHA')",
        "        require(re.fullmatch('[0-9a-f]{40}', head) is not None and head == args.sha, 'HEAD 必須等明填的完整固定 SHA')", 'actual HEAD must match requested SHA')
replace("        (new / 'product-architecture.json').write_bytes(manifest_raw)",
        "        require(digest(normalized(manifest_raw)) == old_receipt['manifestSha256'], '目前 manifest 必須等舊 receipt 已封存 digest，不批准政策偷換')\n"
        "        require(previous_hashes['product-architecture-scan.json']['lfSha256'] == old_receipt['scanSha256'] and previous_hashes['PRODUCT-ARCHITECTURE.md']['lfSha256'] == old_receipt['reportSha256'], '舊 scan/report 必須等舊 receipt 已封存 digest')\n"
        "        require(len(manifest['sources']) == 333 and len(manifest['exclusions']) == 268, '本工具只接受既有601=333+268 inventory')\n"
        "        html_entries = [row for row in manifest['sources'] if row['path'] == HTML_INPUT]\n"
        "        require(len(html_entries) == 1 and html_entries[0]['layer'] == 'H' and html_entries[0]['language'] == 'html' and 'sha256' not in html_entries[0], 'canonical HTML 必須是無 immutable digest 的既有 H owned source')\n"
        "        require(not any(row['path'] == HTML_INPUT for row in manifest['exclusions']), 'canonical HTML 不得改列 exclusion')\n"
        "        require(not any(HTML_INPUT in row.values() for row in manifest.get('htmlScriptRoutes', []) + manifest.get('htmlEmbedRoutes', [])), '本工具不批准 canonical HTML 新增 script/embed route')\n"
        "        require(HTML_INPUT not in json.dumps(manifest.get('trustedVendorBundles', []), ensure_ascii=False), 'canonical HTML 不得成為 vendor trust exception')\n"
        "        require(len(manifest['policy']['forbiddenIdentifiers']) == 920, '應沿用上一輪已封存的920個 W guard，不新增或刪除')\n"
        "        (new / 'product-architecture.json').write_bytes(manifest_raw)", 'preserve H HTML ownership, inventory, existing policy and manifest bytes')
replace("        tool_hashes = {p: file_info(repo / p) for p in TOOLS}",
        "        tool_hashes = {p: file_info(repo / p) for p in TOOLS}\n"
        "        old_judge_hashes = old_receipt.get('completeInventoryVerification', {}).get('toolHashesAfter', {})\n"
        "        require(all(old_judge_hashes.get(p) == tool_hashes[p]['lfSha256'] for p in TOOLS), '本次 HTML 同步不得改三個原裁判')", 'reject judge changes')
replace("        allowed = set(args.allow_changed or ['geometry-web/app.js'])\n        require({row['path'] for row in changed} <= allowed, '變更超出明列的既有來源範圍')",
        "        allowed = {HTML_INPUT}\n"
        "        require({row['path'] for row in changed} == allowed and len(changed) == 1, '相對上份 receipt 必須恰好只有 canonical HTML 一個既有 input 改變')\n"
        "        require(len(before_paths) == 601, '完整 inventory 必須保持601')", 'exactly one changed existing HTML input')
old_commands = """        scan_record, scan_raw, scan_error = command('final-scan', [sys.executable, '-B', 'tests/architecture_contract.py', '--root', '.', '--manifest', ARTIFACT_DIR + '/product-architecture.json'])
        scan_record['sourceBaseHead'] = head
        require(scan_record['exitCode'] == 0, '原 scanner CLI 非零退出；不產生通過收據')
        scan = json.loads(scan_raw)
        require(scan.get('ok') is True and scan.get('diagnostics') == [], '原 scanner 有 diagnostics')
        require(set(scan['sources']) == {row['path'] for row in manifest['sources']}, 'scanner owned sources 與宣告不同')
        (new / 'product-architecture-scan.json').write_bytes(scan_raw)
        unchanged('scan')

        validations = []
        for label, relative in [('generic-tests', TOOLS[1]), ('product-tests', TOOLS[2])]:
            record, stdout, stderr = command(label, [sys.executable, '-B', relative])
            record['sourceBaseHead'] = head
            require(record['exitCode'] == 0, '原架構測試非零退出：' + label)
"""
new_commands = """        # 政策完全不變：三條原命令只各跑一次；先收齊所有真退出與 raw 再判定紅綠。
        scan_record, scan_raw, scan_error = command('final-scan', [sys.executable, '-B', 'tests/architecture_contract.py', '--root', '.', '--manifest', ARTIFACT_DIR + '/product-architecture.json'])
        scan_record['sourceBaseHead'] = head
        unchanged('scan')
        validation_runs = []
        for label, relative in [('generic-tests', TOOLS[1]), ('product-tests', TOOLS[2])]:
            record, stdout, stderr = command(label, [sys.executable, '-B', relative])
            record['sourceBaseHead'] = head
            validation_runs.append((label, relative, record, stdout, stderr))
            unchanged(label)
        require(scan_record['exitCode'] == 0, '原 scanner CLI 非零退出；三條真輸出已保存，不產生通過收據')
        scan = json.loads(scan_raw)
        require(scan.get('ok') is True and scan.get('diagnostics') == [], '原 scanner 有 diagnostics')
        require(set(scan['sources']) == {row['path'] for row in manifest['sources']}, 'scanner owned sources 與宣告不同')
        (new / 'product-architecture-scan.json').write_bytes(scan_raw)

        validations = []
        for label, relative, record, stdout, stderr in validation_runs:
            require(record['exitCode'] == 0, '原架構測試非零退出；三條真輸出已保存：' + label)
"""
replace(old_commands, new_commands, 'capture all three original judges before red classification; do not duplicate execution')
replace("            validations.append(record)\n            unchanged(label)", "            validations.append(record)", 'do not duplicate source-check commands after summary parsing')
replace("report = old_report.rstrip() + '\\n\\n## 雲端 Linux 有限重產：P73 來源修正後\\n\\n'",
        "report = old_report.rstrip() + '\\n\\n## 雲端 Linux 有限重產：canonical HTML trace 同步後\\n\\n'", 'correct current report claim')
replace("manifest 登記、所有政策與排除理由均未修改。\\n\\n'",
        "本次恰一個既有 H canonical HTML input 同步；manifest 登記、920個既有 guard、所有政策、排除理由及 route/vendor digests 均保持原 bytes，不把上一輪新增兩個 W guard 重算為本輪新生成。\\n\\n'", 'explicit empty policy/digest delta')
replace("        unchanged('before-seal')",
        "        require((new / 'product-architecture.json').read_bytes() == manifest_raw, '輸出 manifest 必須保持原 bytes')\n        unchanged('before-seal')", 'output manifest exact byte equality')
replace("                'digestEvidence': '沿原 manifest 執行 scanner exit0；不更新 vendor、excluded 或 iframe driver/router digest 來掩蓋失效。',",
        "                'digestEvidence': 'canonical HTML 是無 immutable digest 的既有 H owned source；manifest raw bytes、vendor/exclusion/iframe driver/router digest 全保持原值。只更新 source closure 與該 HTML input hash，原 scanner exit0。',\n"
        "                'canonicalHtmlScope': {'path': HTML_INPUT, 'layer': 'H', 'language': 'html', 'immutableManifestDigest': False, 'changedInputCount': 1},\n"
        "                'policyDelta': {'addedIdentifiers': [], 'removedIdentifiers': [], 'addedStrings': [], 'removedStrings': [], 'identifiersBefore': 920, 'identifiersAfter': 920, 'allOtherManifestFieldsEqual': True, 'manifestByteUnchanged': True},", 'receipt explicit HTML-only scope and empty policy delta')
replace("                'note': '新撰 Linux 封裝器；不是舊 Windows driver 的路徑適配副本，未宣稱兩者程式 hash 相同。'},",
        "                'note': '由既有 Linux appjs-only wrapper 衍生的 canonical HTML-only 封裝器；保留原三裁判與完整 inventory，新增固定 SHA／單一 HTML／不改原裁判守衛；不是舊 Windows driver 或 W guard 生成器。'},", 'driver provenance claim')
replace("'schema': 'geo261-linux-architecture-refresh/1'", "'schema': 'geo261-linux-canonical-html-architecture-refresh/1'", 'distinct finite refresh schema')
replace("                   'allRawAndLfInputsUnchanged': True, 'manifest_byte_unchanged': (new / 'product-architecture.json').read_bytes() == manifest_raw,",
        "                   'allRawAndLfInputsUnchanged': True, 'manifest_byte_unchanged': (new / 'product-architecture.json').read_bytes() == manifest_raw,\n"
        "                   'canonical_html_only': True, 'policy_delta_empty': True, 'canonical_html_path': HTML_INPUT,", 'summary exact scope flags')
target_raw = text.encode()
if TARGET.exists():
    raise RuntimeError('refuse overwrite '+str(TARGET))
(OUT/'refresh_architecture_linux.original.py.txt').write_bytes(raw)
TARGET.write_bytes(target_raw)
(OUT/'refresh_architecture_canonical_html_linux.py.txt').write_bytes(target_raw)
(OUT/'ADAPTATION.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), text.splitlines(keepends=True), fromfile=str(SOURCE), tofile=str(TARGET))))
(OUT/'PREPARATION.json').write_text(json.dumps({'schema':'geo261-canonical-html-architecture-wrapper-preparation/1',
    'status':'prepared-only; not imported or executed; peer review pending',
    'basis':{'path':str(SOURCE),'raw_sha256':hashlib.sha256(raw).hexdigest()},
    'candidate':{'path':str(TARGET),'raw_sha256':hashlib.sha256(target_raw).hexdigest()},
    'adaptations':adaptations,'scope':{'only_existing_changed_input':'geometry-guide/公理層-閱讀器.html','inventory':601,'owned':333,'excluded':268,'guards_before':920,'guards_after':920,'manifest_byte_unchanged':True},
    'not_performed':['wrapper import','wrapper execution','scanner/lexer','three judges','compilation','product','native','browser','mock','fixtures','commit','push']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate':str(TARGET),'sha256':hashlib.sha256(target_raw).hexdigest(),'adaptations':len(adaptations)},ensure_ascii=False))
