# canonical HTML-only Linux 架構四檔重產（準備稿）

候選工具是 `/workspace/geo261-environment/refresh_architecture_canonical_html_linux.py`，從既有 `refresh_architecture_linux.py`（原 appjs-only 版）衍生，原文、精確 diff、逐 anchor 適配清單及 hash 在本目錄。這是 repo 外工具準備，沒有 import／執行候選工具、scanner、lexer、三裁判、編譯、native、Chrome 或 mock；不代表任何新的 SHA 已通過。

## 來源與 digest 範圍

目前已封存的 A manifest 將 `geometry-guide/公理層-閱讀器.html` 登記為 H／html owned source，entry 沒有 `sha256`；它不是 exclusion、vendor 或 trusted bundle，也沒有對應的 htmlScriptRoute／htmlEmbedRoute。原 scanner 只允許 vendor owned source 使用 immutable source digest；embed route 的額外 digest 是 driver／router，不是任意 HTML 目標 hash。因此同步 I11 trace 的 HTML 既有內容時，**不需且不准刷新 manifest digest 或政策欄位**。

本工具只接受相對上一份 receipt 恰好這一個既有 input 改變，完整 inventory 仍為 601＝333 owned＋268 excluded。新的 601 input closure 與 HTML input hash 必須由真 bytes 重算，不能沿用 P／L 的 `8ce86d3b...` closure。四份衍生檔照 schema 輸出，其中 `product-architecture.json` 必須與來源 manifest 原 bytes 相同；scan／report／receipt 更新。guard 維持 920，policy delta 恰空，不把上一輪 918→920 的兩名新增再當成本輪新生成。

除了要求 guard count＝920，工具還將現有 manifest、舊 scan／report 綁回上一份 receipt 的 digest，避免用相同數量偷換政策。舊四檔逐份保存，並讀回其最後產物 Git commit 的 blobs；來源 closure 不包括四份衍生產物，receipt 不雜湊自身。已固定的三裁判 LF hash 必須等前份 receipt；本工具不批准裁判、來源集合、分類、排除理由或 route/vendor digest 的改動。

## 三裁判與 provenance

政策不變，所以直接在乾淨固定來源執行原三條，每條各一次，不需要 W 版的新 manifest 外部驗證樹或新增 guard probes：

```text
python -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json
python -B tests/test_architecture_contract.py
python -B tests/test_product_architecture.py
```

真 argv 使用當次 `sys.executable`。工具先保存三條原始退出與完整 stdout／stderr，再判斷紅綠；scan JSON 錯誤或首條紅燈不會讓後兩條靜默不跑。每條後仍重算完整 601 raw／LF hashes、三裁判 bytes、manifest、HEAD 與 clean status，來源完整性失效時拒絕繼續宣稱同源。沒有更改三裁判的斷言、取樣、參數或測試計數。

所有命令保存來源 SHA、cwd、環境白名單、真退出碼、完整原串流與 hash。`--sha` 必填完整 40 字元，實際 HEAD 必須相等；第一個 Git 命令也綁該 SHA。外層流程必須先確認該 SHA 已正常 push、可由 GitHub 解析，才執行本工具；工具本身不提供網路發布或公開身分的證明。拒絕 optimized Python，子程序移除 `PYTHONOPTIMIZE`。輸出只在 source checkout 外，工具不 commit／push／merge／修改來源。

## 命令稿

`COMMAND_DRAFT.txt` 的 `<HTML_FIXED_PUBLIC_SHA40>` 要填入真已推送、clean clone 的產品 SHA；不填 A、P 或尚未發布的本地 SHA。這份工具不自行推產品，也不會重產 mutation ledger。HTML 修正完成後仍需由主流程以 `mutate.py --check` 實際判斷帳本是否有效，並依完整 census 規則處理 expected。

`RESULT.json` schema 為 `geo261-linux-canonical-html-architecture-refresh/1`，成功必須同時 `passed=true`、`canonical_html_only=true`、`policy_delta_empty=true`、`manifest_byte_unchanged=true`，並有原三裁判退出碼。內層四檔 receipt 延用 `geometry-product-architecture-receipt/1`，`sourceBaseHead` 永遠是實際受驗來源；後續只加入四檔／evidence 的提交不得改寫這個 execution SHA。

先前 L 的獨立稽核工具含八 changed paths、918→920、P closure、外部驗證樹等本輪不適用假設，不能原封不動套上 HTML-only 產物冒綠。新產物仍需獨立純讀核對：一個 HTML changed、全601新 closure、manifest bytes／政策完全不變、三條原 judge raw、四檔 hash、HEAD 及 clean state。下一輪 F 仍要完整正式驗收。

## 靜態互審狀態

已完成兩份獨立純讀覆核（next_work 與 node_hash_audit/raw_header_recorder），未見靜態阻擋。具體原文見 `/workspace/geo261-environment/architecture-canonical-html-peer-review-raw-header.md`，hash 記在 PREPARATION。這不是新架構收據或測試綠燈。沿原版 unittest parser 會接受 `OK (skipped=n)` 並如實記錄；若實跑有 skip，必須按原 raw 列未執行控制，不能只用 RESULT.passed 泛稱全部執行，沒有放寬或更改原斷言。模板產生器只做精確文字轉換與 diff，沒有 import 或執行輸出程式；原工具與舊 W wrapper 未改。這份工具只處理架構產物身分，不證明 I11 trace 的產品修正正確；trace 的唯一 exact bytes 變更與撤回自證屬產品修正／reader 裁判範圍。
