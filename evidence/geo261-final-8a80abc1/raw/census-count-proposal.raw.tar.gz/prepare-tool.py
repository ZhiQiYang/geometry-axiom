#!/usr/bin/env python3
"""純檔案的三個 count 比較提案；拒絕其餘 JSON 差異，不採用 registry、不重標舊紅。"""
from __future__ import annotations

import argparse
import copy
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
import traceback

COUNT_CHANGES=(('py:test_geo261_definition_sources',7,9),
               ('py:test_geo261_host_facts_authority',17,19),
               ('py:test_geo261_placement_definition',15,19))
UNIT_SUITE='py:test_rectangular_template'


class Rejected(ValueError):
    pass


def require(condition,message):
    if not condition:
        raise Rejected(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_json(raw):
    def object_pairs(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'duplicate JSON object key: '+key)
            result[key]=value
        return result
    def nonfinite(value):
        raise Rejected('nonfinite JSON constant: '+value)
    return json.loads(raw.decode('utf-8'),object_pairs_hook=object_pairs,parse_constant=nonfinite)


def typed_equal(left,right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left)==set(right) and all(typed_equal(left[key],right[key]) for key in left)
    if type(left) is list:
        return len(left)==len(right) and all(typed_equal(a,b) for a,b in zip(left,right))
    return left==right


def typed_differences(left,right,path=()):
    if type(left) is not type(right):
        return [{'path':list(path),'kind':'type','beforeType':type(left).__name__,'afterType':type(right).__name__,
                 'before':left,'after':right}]
    if type(left) is dict:
        rows=[]
        for key in sorted(set(left)|set(right)):
            if key not in left:rows.append({'path':list(path+(key,)),'kind':'added','after':right[key]})
            elif key not in right:rows.append({'path':list(path+(key,)),'kind':'removed','before':left[key]})
            else:rows.extend(typed_differences(left[key],right[key],path+(key,)))
        return rows
    if type(left) is list:
        if len(left)!=len(right):return [{'path':list(path),'kind':'array-length','before':left,'after':right}]
        return [row for i,(a,b) in enumerate(zip(left,right)) for row in typed_differences(a,b,path+(i,))]
    return [] if left==right else [{'path':list(path),'kind':'value','before':left,'after':right}]


def comparison_object(before,generated):
    require(type(before) is dict and type(generated) is dict,'top-level JSON 必須是 object')
    require(type(before.get('suites')) is dict and type(generated.get('suites')) is dict,'suites 必須是 object')
    proposal=copy.deepcopy(before)
    for name,old,new in COUNT_CHANGES:
        require(name in proposal['suites'],'missing original suite: '+name)
        entry=proposal['suites'][name]
        require(type(entry) is dict,'suite entry 必須是 object: '+name)
        require(entry.get('mode')=='count','original mode 必須是 count: '+name)
        require(type(entry.get('count')) is int and entry['count']==old,'original count 不符: '+name)
        require(type(entry.get('unit')) is str and entry['unit']=='test','original unit 不符: '+name)
        entry['count']=new
    require(UNIT_SUITE in proposal['suites'],'missing rectangular_template')
    legacy=proposal['suites'][UNIT_SUITE]
    require(type(legacy) is dict and legacy.get('mode')=='count','rectangular_template mode 不符')
    require(type(legacy.get('count')) is int and legacy['count']==11,'rectangular_template count 必須仍為 11')
    require(type(legacy.get('unit')) is str and legacy['unit']=='unittest','rectangular_template 原 unit 必須是 unittest')
    exact_generated=copy.deepcopy(proposal)
    exact_generated['suites'][UNIT_SUITE]['unit']='test'
    require(typed_equal(generated,exact_generated),
            'generated 必須逐 typed JSON 精確等於 old + 三個 count + 唯一已解釋 unit 正規化；其他差異均拒絕')
    require(len(typed_differences(before,generated))==4,'原 generated 差異欄位必須恰四個')
    require(len(typed_differences(before,proposal))==3,'comparison 差異欄位必須恰三個')
    return proposal


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before',type=Path,required=True)
    parser.add_argument('--generated',type=Path,required=True)
    parser.add_argument('--census-receipt',type=Path,required=True)
    parser.add_argument('--expected-source-sha',default='a12d184ec1865ad078700cea2387ac69e82ab62a')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    out=args.out.resolve()
    repo=Path('/workspace/geometry-axiom').resolve()
    require(out.is_relative_to(Path('/workspace')) or out.is_relative_to(Path('/tmp')),'out 須在可寫工作區')
    require(out!=repo and not out.is_relative_to(repo),'out 不得位於 repository，不能採用 registry')
    out.mkdir(parents=True,exist_ok=False)
    report={'schema':'geo261-three-counts-comparison-only/1','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'notCountAdoption':True,'notFinalAcceptance':True,'doesNotChangeOldReceiptOrExit':True,
            'toolSha256':sha(Path(__file__).read_bytes()),'comparisonGenerated':False}
    try:
        before_raw=args.before.read_bytes();generated_raw=args.generated.read_bytes();receipt_raw=args.census_receipt.read_bytes()
        (out/'ORIGINAL_BEFORE.json').write_bytes(before_raw)
        (out/'ORIGINAL_GENERATED.json').write_bytes(generated_raw)
        (out/'ORIGINAL_CENSUS_RECEIPT.json').write_bytes(receipt_raw)
        report['originalHashes']={'beforeSha256':sha(before_raw),'generatedSha256':sha(generated_raw),'censusReceiptSha256':sha(receipt_raw)}
        before=strict_json(before_raw);generated=strict_json(generated_raw);receipt=strict_json(receipt_raw)
        snapshots=args.census_receipt.resolve().parent
        require(before_raw==(snapshots/'before/tests/run_all.expected.json').read_bytes(),'before 不等於該原收據旁的原始 before snapshot')
        require(generated_raw==(snapshots/'after/tests/run_all.expected.json').read_bytes(),'generated 不等於該原收據旁的原始 after snapshot')
        require(type(before.get('suites')) is dict and len(before['suites'])==224,'原完整 census 必須有 224 個 suite')
        report['observedGeneratedDifferences']=typed_differences(before,generated)
        require(type(receipt) is dict and receipt.get('stage')=='census','原收據必須是 census')
        require(type(receipt.get('stage_execution_passed')) is bool and receipt['stage_execution_passed'] is False,
                '原 wrapper stage false 必須保留，不能藉比較檔重標')
        require(type(receipt.get('source_sha')) is str and re.fullmatch('[0-9a-f]{40}',receipt['source_sha']) is not None,'原 source SHA 不符')
        require(receipt['source_sha']==args.expected_source_sha,'原 source SHA 不等於指定的 A')
        rows=receipt.get('commands')
        require(type(rows) is list,'原 commands 必須是 array')
        native=[row for row in rows if type(row) is dict and row.get('label')=='full-census-update-expected']
        require(len(native)==1,'原完整 census command 必須恰一筆')
        native=native[0]
        require(native.get('command')==['python3','tests/run_all.py','--build','--update-expected'],'原 command scope 不符')
        require(type(native.get('actual_process_returncode')) is int and native['actual_process_returncode']==1,'原 native exit 1 必須保留')
        require(type(native.get('timeout_expired')) is bool and native['timeout_expired'] is False,'原 census 不可逾時')
        report.update(originalSourceSha=receipt['source_sha'],originalNativeExit=1,originalWrapperStagePassed=False)
        proposal=comparison_object(before,generated)
        comparison_raw=(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
        require(typed_equal(strict_json(comparison_raw),proposal),'comparison JSON roundtrip 型別改變')
        (out/'COMPARISON_ONLY.json').write_bytes(comparison_raw)
        (out/'generated-from-before.diff').write_text(''.join(difflib.unified_diff(before_raw.decode().splitlines(True),generated_raw.decode().splitlines(True),fromfile='original-before',tofile='original-generated')))
        (out/'comparison-from-before.diff').write_text(''.join(difflib.unified_diff(before_raw.decode().splitlines(True),comparison_raw.decode().splitlines(True),fromfile='original-before',tofile='comparison-only')))
        report.update(comparisonGenerated=True,comparisonSha256=sha(comparison_raw),
                      comparisonDifferences=typed_differences(before,proposal),
                      originalGeneratedStrictTypedEquation='generated == old + count7to9 + count17to19 + count15to19 + rectangular.unit(unittest->test), rectangular.count remains11',
                      comparisonStrictTypedEquation='comparison == old + exactly three reviewed count fields; all original units and other metadata preserved',
                      ignoredMetadataNormalization={'suite':UNIT_SUITE,'field':'unit','before':'unittest','observedGenerated':'test','comparisonRetained':'unittest','countBeforeGeneratedComparison':11},
                      reason="原 UNIT['unittest']='test' 造成既有 unit 正規化；比較提案保留舊值，不盲採任何其他 diff；mode/count 斷言與所有 tests 完全不修改。",
                      adoptionPreconditionsNotVerifiedByThisTool=['HTML-only 修復已由原同步器完成；原完整51-test target與sync --check全綠',
                        '所有 test source/registry/discovery/count parser 與 A 的 hashes 不變，除待提案的 expected data 外無其他測試變更',
                        'root 明確採用新決定並保留原 native exit1 / wrapper false / generated fullJSON 原證據',
                        '固定可解析最終 F 後原完整 native（無 --update-expected）、六 browser 與全部專項全綠'])
        code=0
    except Exception as error:
        report.update(rejected=True,errorType=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        print(report['traceback'],file=sys.stderr)
        code=1
    report['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['exitCode']=code
    (out/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'exitCode':code,'comparisonGenerated':report['comparisonGenerated'],
                      'notCountAdoption':True,'report':str(out/'REPORT.json')},ensure_ascii=False))
    return code


if __name__=='__main__':
    raise SystemExit(main())
