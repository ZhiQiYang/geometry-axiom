#!/usr/bin/env python3
"""完整 census 後只允許逐條明列的 count 差分；保留舊排版，不修改 repository。"""
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path
import re


def digest(data):
    return hashlib.sha256(data).hexdigest()


def same_json_types_and_values(before, after):
    # Python 的 9 == 9.0、1 == True 不是 JSON 身分相同；型別也必須保留。
    if type(before) is not type(after):
        return False
    if isinstance(before, dict):
        return set(before) == set(after) and all(same_json_types_and_values(before[key], after[key]) for key in before)
    if isinstance(before, list):
        return len(before) == len(after) and all(same_json_types_and_values(a, b) for a, b in zip(before, after))
    return before == after


def object_changes(before, after, *, kind):
    return [{kind: name, 'present_before': name in before, 'present_after': name in after,
             'before': before.get(name), 'after': after.get(name)}
            for name in sorted(set(before) | set(after))
            if name not in before or name not in after or not same_json_types_and_values(before[name], after[name])]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', type=Path, required=True)
    parser.add_argument('--after', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--allowed-count', action='append', required=True, metavar='SUITE=BEFORE:AFTER',
                        help='每條必須明列現有suite的具體正整數before→after；不得從census自動批准')
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise RuntimeError('拒絕覆蓋舊計數審查或提案')
    out.mkdir(parents=True)
    before_raw, after_raw = args.before.read_bytes(), args.after.read_bytes()
    before, after = json.loads(before_raw), json.loads(after_raw)
    if not isinstance(before, dict) or not isinstance(after, dict):
        raise RuntimeError('expected 檔必須是 JSON object')
    if not isinstance(before.get('suites'), dict) or not isinstance(after.get('suites'), dict):
        raise RuntimeError('expected 檔缺少 suites object')
    errors, allowed, seen = [], [], set()
    expected = copy.deepcopy(before)
    for value in args.allowed_count:
        match = re.fullmatch(r'([^=]+)=([1-9][0-9]*):([1-9][0-9]*)', value)
        if match is None:
            errors.append('無效的具體 count 引數：' + value)
            continue
        name, old, new = match.group(1), int(match.group(2)), int(match.group(3))
        if name in seen:
            errors.append('同一 suite 不可重複批准：' + name)
            continue
        seen.add(name)
        entry = before['suites'].get(name)
        if not isinstance(entry, dict) or entry.get('mode') != 'count' or type(entry.get('count')) is not int:
            errors.append('必須指定原檔中已存在的 count suite：' + name)
            continue
        if entry['count'] != old or old == new:
            errors.append('具體 before 不符原檔或未變更：' + value + '；原值=' + str(entry['count']))
            continue
        expected['suites'][name]['count'] = new
        allowed.append({'suite': name, 'before': old, 'after': new})
    observed_suite_changes = object_changes(before['suites'], after['suites'], kind='suite')
    observed_top_changes = object_changes({k: v for k, v in before.items() if k != 'suites'},
                                          {k: v for k, v in after.items() if k != 'suites'}, kind='field')
    only_declared = (not errors and len(allowed) == len(args.allowed_count) and
                     same_json_types_and_values(expected, after))
    report = {'purpose': '完整census後逐條批准count差分；此工具不執行或取代census，不修改repository',
              'before_sha256': digest(before_raw), 'generated_census_sha256': digest(after_raw),
              'tool_sha256': digest(Path(__file__).read_bytes()), 'command_line_allowed_counts': args.allowed_count,
              'validated_allowed_changes': allowed, 'suite_changes': observed_suite_changes,
              'top_level_changes': observed_top_changes, 'errors': errors,
              'only_declared_count_changes': only_declared, 'proposal_created': False,
              'repository_modified': False, 'native_or_census_executed_by_this_tool': False}
    if only_declared:
        proposal = before_raw.decode('utf-8')
        for change in allowed:
            marker = json.dumps(change['suite'])
            if proposal.count(marker) != 1:
                errors.append('suite key 在原 bytes 中不唯一：' + change['suite'])
                break
            start = proposal.index('{', proposal.index(marker) + len(marker))
            entry, length = json.JSONDecoder().raw_decode(proposal[start:])
            if not same_json_types_and_values(entry, before['suites'][change['suite']]):
                errors.append('原 bytes 的 suite entry 與 JSON 結構不同：' + change['suite'])
                break
            text = proposal[start:start + length]
            pattern = r'("count"\s*:\s*)' + str(change['before']) + r'\b'
            if len(re.findall(pattern, text)) != 1:
                errors.append('count 字面值不唯一：' + change['suite'])
                break
            replacement = re.sub(pattern, lambda match: match.group(1) + str(change['after']), text)
            proposal = proposal[:start] + replacement + proposal[start + length:]
        if not errors:
            if not same_json_types_and_values(json.loads(proposal), after):
                errors.append('保排版提案語意與完整 census JSON 不同')
            else:
                proposal_raw = proposal.encode('utf-8')
                patch = ''.join(difflib.unified_diff(before_raw.decode('utf-8').splitlines(keepends=True),
                                  proposal.splitlines(keepends=True), fromfile='a/tests/run_all.expected.json',
                                  tofile='b/tests/run_all.expected.json'))
                (out / 'expected-count-proposal.json').write_bytes(proposal_raw)
                (out / 'expected-count-proposal.patch').write_text(patch)
                report.update(proposal_created=True, proposal_sha256=digest(proposal_raw),
                              patch_sha256=digest(patch.encode('utf-8')),
                              proposal_semantically_equals_generated_census_json=True)
    if errors:
        report['only_declared_count_changes'] = False
    (out / 'review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0 if report['only_declared_count_changes'] and report['proposal_created'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
