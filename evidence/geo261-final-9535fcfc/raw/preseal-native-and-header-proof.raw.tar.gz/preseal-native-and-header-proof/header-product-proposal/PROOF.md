這是未編譯、未執行、未量測的 repository 外候選。root 工作樹未由本工具修改。實際基線為 metadata.json 中 2bfbfa58 的來源；三個原檔完整保存在 baseline/，候選 patch SHA256 為 `dc066143505dadba08f2bc06645484ed8bfc4ee8f5ab16a37f5425702b32fd7a`。

呼叫與輸出

新增 accessor 回傳 domain／region_id 兩個欄位。這個 ABI 下預期 8 bytes，但尚未以新 C binary 驗證 sizeof。H 只更換 reference_sp_host、reference_placement_binding、reference_host_read 的 local 型別與 accessor 名稱；原 current-values guards、來源呼叫位置及其先後順序不動。reference_eng_placement 和既有 static 契約保留 full accessor。

新 accessor 在相同位置呼叫同一個 geo_eval_source、同 provider、同 5-byte key、同 DEFINITION_REQUIRED。kind/schema/status/id 判準相同；不請求 FRAME／REGIONS、不儲存跨 consumer cache。canonical bytes 是每次即時驗證的 graph 實際回傳值；binding 的替換仍具權威性。NULL out 在任何 source request 前拒絕；所有失敗不寫 caller output，成功才一次賦值完整小結果。

完整 API 保留

準備器以嚴格 boundary 擷取並逐 byte 斷言原 geo_placement_definition_decode、geo_placement_sources_definition 全文未變。新增程式位於原函式之間，沒有改 full API、writer、provider、descriptor、decoded record、store 或依賴圖的生命週期。metadata.json 的三個 preserved 欄位為純文字靜態檢查，不能冒充動態通過。

完整 canonical 接受集合對照

| 格式部分 | 原 full reader | 新 header reader |
|---|---|---|
| content/out/size | NULL 或超過 MAX 拒絕 | 相同 |
| id | 完整 BE32，full accessor 最後比 requested id | 完整 BE32，新 helper 完整格式後比 requested id |
| frame | 12 個 unrestricted signed BE64，沒有 semantic 拒絕 | 剩餘 bytes ≥96 才 skip；同樣不新增 frame/座標驗證 |
| domain | BE8，僅 0/1/2 | 相同 |
| RECT | 四個 BE64 endpoints，沒有正長度等額外條件 | 剩餘 bytes ≥32 才 skip |
| REGION_REF | BE32 region_id | 相同，完整保留值包括 0/MAX |
| REGION_SET | BE32 component_count≤8 | 相同 |
| 每 component | BE32 id、outline、hole_count≤8、各 hole | 相同，不能只讀第一個 component |
| 每 loop | BE32 count≤32、完整 `16*count` bytes | 相同 bounds，乘數前已限制 count；保留零點 loop 接受行為 |
| inactive 欄位 | wire 省略、decoded 零值 | 非 REF 的 region_id 由小 local `{0}` 保持零 |
| trailing | reader 必須等於 end | 相同 |

因所有 frame／vertex／rect coordinate 的 64-bit bit pattern 都被原 reader 接受，bounded skip 不略過任何拒絕條件。這個等價性以 API 原有「content 指向 size bytes 可讀 buffer」合約為前提；不新增 OS page probing，也不把缺失 bytes 視為有效。所有 count、payload、exact tail 仍驗證，沒有因 H 只要 header 而接受 malformed nested loop。

容量：固定 prefix=101 bytes；RECT=133；REF=105；empty SET=105；最大 SET=37,321。所有活動 payload 都要被計入並確實在 declared size 內。

資料量證據與範圍

既有 O0 DWARF 實際證明 full definition=37,720 bytes。完整 accessor 明文路徑每次包含該尺寸的一次 memset、decoder 一次 memcpy、wrapper 一次 memcpy。LD_PRELOAD 診斷 `/tmp/g261memcalls/diagnostic/SUMMARY.json` 已定位每項各 85,556 次／3,227,172,320 bytes，合計 9,681,516,960 bytes；這是診斷工作樹的可見 bulk-call bytecount，沒有函式耗時百分比，也不是最終 P189 門檻通過。部分初始化 FRAME／REGIONS node 仍要原 full accessor，因此候選實際省量應以後續量測為準，不能先聲稱所有 9.68 GB 消失。

原始準備輸出

第一次純準備因把同名 prototype／definition 都當唯一 end boundary 而退出 1，保留於 `/workspace/geo261-environment/p189-placement-header-preparation-log/`。只修準備器的精確 prototype delimiter 後第二次退出 0，保留於相鄰 `p189-placement-header-preparation-log-r2/`。兩次都未編譯或執行候選；這不屬產品紅／綠。

下一步差分範圍見 ACCEPTANCE_PLAN.md。採用、套用、編譯、量測、永久測試及最終同 SHA 驗收均由 root 決定。
