本檔是具體差分設計，尚未產生或執行新 C binary。不能把本計畫列為通過收據。

原 oracle 與 fixture

沿 `tests/geo261_placement_definition_harness.c` 的現有 Fixture／Replacement／binding。這個 harness 已有獨立 BE Vector writer，沒有用 production encoder 產生 decoder oracle。保留原 full decoder/API，將它作為 header 的接受／拒絕 oracle；候選準備器已證原 full 函式逐 byte 不變。

每一個 wire fixture 透過真正的 registered replacement provider 返還 canonical bytes，並由真 K graph 快取。full accessor 與 header accessor 分別取得回傳結果；對成功 full result 只取 domain／region_id 比 header。失敗時兩側 output 先完整填 0xA5，各自逐 byte 檢查未變。不得將 raw placement 當 actual 替代，也不得 mock geo_eval_source。

可沿既有 reset(Fixture*,Replacement*) 在每次新的 wire size/schema/kind 前重建 graph generation；placement/region stores 保持原 fixture。呼叫順序交錯 full-first/header-first，避免只靠第一個 full read 的權威性掩蓋新 helper 繞過 source 的錯誤。

必跑案例

1. 原 fixed_vector 的 RECT／REF／SET，保留 INT64_MIN/MAX、非 cardinal frame、反向 rect、零點／一點 loop 等 staged-invalid 幾何接受行為。REF actual region_id=UINT32_MAX，且 store 初值仍 RECT，以證 canonical replacement 控制結果。
2. empty SET，以及原 maximal() 的完整 37,321-byte SET。三個 fixed vectors 與 maximal 的每一個 prefix truncation，逐點 full/header 必須同判且 out-on-error 不變；再各加一 byte trailing、超過 MAX、content=NULL 與 NULL output。
3. 完整而非僅缺 bytes 的 count 邊界向量：8／9 個 empty components；outline 32／33 點並提供全部 payload；8／9 個 empty holes；hole loop 32／33 點並提供全部 payload。另 UINT32_MAX counts。這使移除 count limit 的負控不會被另一個 truncation guard 偶然殺死。
4. 三個 domain byte 的完整 0..255 變異；所有 frame／rect／vertex coordinate 的 0、MIN、MAX、單一 sign bit；只改 canonical component id 不應改 header，但仍須成功驗完整格式。
5. schema=NULL／empty／其他有效非空 schema，wire requested id mismatch，GEO_SOURCE_FRAME wrong kind，upstream evaluate failure。真 K 本身可能先拒絕 NULL schema／wrong kind；記錄實際拒絕層與相同 graph，不把冗餘 guard 的負控假稱可獨立造成接受。
6. 同個已 VALID definition 的 borrowed bytes 在 owner 端變動，再次讀取應即時看到新 domain／region_id 或拒絕 malformed；不得以 first read header cache 掩蓋變化。若改 size/schema，要 reset generation 讓真 provider 回傳新 value，不能直接竄改 K 的 const node value。
7. reset、sealed、graph-first／handle-first destruction、兩個獨立 candidate，沿原 lifecycle case 加 header 對照；出錯不寫 caller output，不引入新的 MEMORY 路徑。

依賴與有序圖

新增一個測試 consumer provider（非 source mock），在 active evaluation 中依序 full+header，另 fresh fixture 反向 header+full，最後回 quantity witness。正向應只有三個 ordered nodes：consumer、placement DEFINITION、replacement DEFINITION；兩條 ordered edges 都為 DEFINITION_REQUIRED。用完整 provider/key bytes、descriptor/state/status、value schema/content、ordered consumer/source/kind 比較。若新 helper改用 FRAME／REGIONS、VALUE_REQUIRED、增加額外依賴，必須具名失敗。單在 top-level 看 edge_count 不足，因 active=SIZE_MAX 不記 edge。

負控（隔離副本；原 assert/oracle 不動）

- header wrapper 移除 schema compare → 非空錯 schema 向量具名 `header-schema-atomic`。
- header reader 移除 requested id compare → `header-id-atomic`。
- 移除 exact trailing check → 完整合法 wire 加一 byte，`header-trailing-atomic`。
- 分別移除 component／hole／loop count limit，使用已補齊全部超界 payload 的向量，具名 component／hole／outline／hole-loop limit。
- header REF region_id +1 → `header-returned-reference-id`。
- header wrapper DEFINITION_REQUIRED 改 VALUE_REQUIRED → active consumer 的完整 ordered graph 檢查。

每個負控要 baseline 0 → mutant 正常 exit 1 + 精確 ASSERT → restored 0，保存原 command/exit/stdout/stderr/環境/SHA。compile failure、signal、ASan abort 不算所需的正常語意 ASSERT；原始失敗仍完整保留。部分 bounds 與 exact trailing 是冗餘拒絕條件，不能為了讓每個 guard 都有正常 ASSERT 而放寬別的判準。所有 truncation 仍做接受集合比較，ASan/UBSan 另保留實際記憶體安全診斷。

採用後的正式範圍

外部差分不能取代原 placement definition、原 host facts／host placement／derived policy 等完整 suites。新增產品 API 應有永久回歸與具名負控，再按使用者規則整份重產帳本，重產架構收據並在同一最終 SHA 重跑完整 native、六個 browser、專項與 P189。P189 門檻與三方交錯／byte dump 不變；此計畫沒有先行宣稱收益或通過。
