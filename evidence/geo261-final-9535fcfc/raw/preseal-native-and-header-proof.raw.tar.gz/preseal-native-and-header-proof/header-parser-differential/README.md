# K placement canonical header 原始格式差分（已完成）

這是 repo 外候選診斷，不是最終 SHA 全套驗收。來源是 prepare 當時實際 dirty K placement_sources.c/.h；完整來源與 context hashes、HEAD、dirty diff、每個命令與真退出碼在 prepared.json 及三個 phase receipt。

Client 直接 include snapshots/kernel/placement_sources.c，使用其中未改的完整 decoder 作 oracle、新 private header reader 作被測對象。沒有 stub、沒有複製 parser。-ffunction-sections/-fdata-sections/--gc-sections 僅移除未用 provider API 的外部符號。獨立唯讀 audit 另確認 encoder／full decoder 共 14 個原始 primitive/函式的 exact bytes 全與 HEAD 來源相同。

prepare、O2、ASan+UBSan 全部真 exit 0；兩種模式各有 199,810 組比較、零差異，完整 stdout 逐 bytes 相同且 stderr 空。10 個完整 wire vectors涵蓋 RECT/REF/SET、空集合、零／最大 id、所有 signed64 極端座標位元、最大 8 components × 8 holes × 32 vertices（37,321 bytes）、不等長 loop。座標並不額外要求幾何合法，維持原完整 decoder 只驗格式／count/tag 的語意。

每個 vector 包含全部截短長度、每個 byte 分別 XOR 0x01/0x80/0xff、domain 的全部 256 tags、id 每個 bit 的匹配／不匹配、REF id 值、每個活動 count 欄位 0/cap-1/cap/cap+1/UINT32_MAX/高位值、tail、最大 size／SIZE_MAX、NULL content／output、未對齊 offset 0..15、輸出 canary 與失敗整段輸出 bytes 不變。『每個 byte 變異』是上述三種 XOR；沒有宣稱每個 byte 的所有 256 值都掃過。

每種模式 full decoder 接受 145,627 次；header 接受 145,187 次／拒絕 54,623 次。兩者接受數差 440，精確對應刻意 changed-id 且仍用原 requested-id 的案例（120 byte flips + 320 single-bit id flips）。C 裁判逐項要求 header_accept == (full_accept && decoded.id == requested_id)，成功時 domain/region_id 包括 inactive zero 與 full decoder 相同。另有每種模式 20 個 NULL-output 呼叫。

O2/SAN stdout 的真正 SHA256、byte count、wrapper/client/source SHA256 都在 SUMMARY.json 和 SHA256SUMS。21fc4cb449854029 只是 client 自己的摘要 digest，不是 SHA256。所有原始 stdout/stderr 在 commands，外層 subreaper／launch streams 已複製到 outer-control 與 round-launch.*。所有產品/context bytes 三 phase 前後一致；soft stack 16 MiB、hard infinity，未降低 hard limit。

封存時可明確排除下面兩個 ELF；它們的 SHA256 已保留在 SUMMARY.json、phase receipts 和 EXCLUDED_ELF.json，完整 build 命令與 raw streams、source/client/tool 快照仍必須保存：

- o2-record/client
- sanitized-record/client

此資料夾在 finalization 完成後凍結；接下來不再改寫它。沒有 commit／push，由 root 收集並按實際來源角色封存，不冒稱 moving evidence HEAD 已執行本輪完整驗收。
