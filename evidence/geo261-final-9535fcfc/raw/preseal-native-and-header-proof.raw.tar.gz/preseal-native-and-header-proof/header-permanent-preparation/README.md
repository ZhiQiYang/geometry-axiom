此候選只修改既有 placement definition C/Python 兩個測試檔；未改root、未編譯或執行，不能稱通過。

原geo_placement_sources_definition完整public accessor與原獨立BE fixed_vector/maximal是oracle；沒有複製新header parser或用產品encoder取代手工wire。每項在兩個fresh graph內，由真registered consumer分別呼full/header，驗consumer→placement DEFINITION及placement→binding upstream兩條DEFINITION_REQUIRED與順序、完整provider trace、typed graph、結果與各自完整output canary。成功後比domain/region_id投影；raw RECT↔bound SET/REF等替換不碰原store，且不強迫FRAME/REGIONS或解析未存在的REF region。

三個baseline case涵蓋三domain、empty SET、獨立INT64 extrema/不合法幾何、maximum37321bytes，所有小wire截斷與tail、maximal component/hole邊界截斷、供齊payload的9component/9hole/33vertices越界、所有未知domain3..255、U32_MAX count、錯schema/id/kind、NULLcontent、upstream fail、reset與candidate隔離。原full decoder接受0/1/2點loop與無效frame/RECT，header也保留。原15秒case timeout未改；近1000對fresh graph的malformed case耗時尚未驗證，若逾時必須保留真紅而不能擅自放寬。

原20controls原文完整保留；另獨立12個HEADER_CONTROLS。只在成功完整parse後破壞domain投影，避免改tag導致錯誤的提前拒絕marker。每個控制只改header helper/accessor、full oracle保持不動，要求baseline0→正常mutant1＋精確ASSERT→restored0，JSON逐次保存cmd/rc/fullstdoutstderr；compile/crash/timeout不能作kill。

新增4個Python test方法，原suite AST方法數15→19。原方法斷言保留，full-accessor結構檢查另延伸到header accessor；正式count仍須完整census核實。

獨立靜態review已確認12控制的預期首個marker、雙graph/canary/兩edge與opaque保存；未進行任何動態驗證。PREPARED.json保留source/product/test hashes與SHA；ASAN-O2-COMMANDS.json提供repo外診斷argv，僅備妥不執行。採用後任何tests/*.py變更仍要依完整新source流程重產ledger、架構與最終全輪。
