#!/usr/bin/env python3
"""只生成新公開placement header API永久測試候選，不編譯或執行測試。"""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,re,subprocess,pprint
R=Path('/workspace/geometry-axiom');O=Path(__file__).resolve().parent
H='tests/geo261_placement_definition_harness.c';P='tests/test_geo261_placement_definition.py'
def sha(b):return hashlib.sha256(b).hexdigest()
def once(t,a,b):
 assert t.count(a)==1,(a,t.count(a));return t.replace(a,b,1)
def code(t):return re.sub(r'/\*.*?\*/|//[^\n]*','',t,flags=re.S)
def function(t,name):
 t=code(t);m=re.search(r'^[\w *]+\b'+re.escape(name)+r'\s*\([^;]*?\)\s*\{',t,re.M|re.S);assert m,name
 at=m.end();depth=1
 while depth:depth+=(t[at]=='{')-(t[at]=='}');at+=1
 return t[m.start():at]
base={p:(R/p).read_bytes() for p in [H,P]};h=base[H].decode();p=base[P].decode();source=(R/'geometry-core/kernel/placement_sources.c').read_text()
assert 'geo_placement_sources_definition_header' in source
# Null content is injected through the same canonical replacement provider.
h=once(h,'bool bind_geometry,fail_geometry;','bool bind_geometry,fail_geometry,null_content;')
h=once(h,'{s->schema,s->wire.bytes,s->wire.size}', '{s->schema,s->null_content?NULL:s->wire.bytes,s->wire.size}')
add=(O/'header-additions.c.txt').read_text()
h=once(h,'int main(int argc,char **argv)\n',add+'\nint main(int argc,char **argv)\n')
h=once(h,'    if(argc!=2)return 2;\n','    if(argc!=2)return 2;\n    if(!strcmp(argv[1],"header-values"))return header_values_case();\n    if(!strcmp(argv[1],"header-malformed"))return header_malformed_case();\n    if(!strcmp(argv[1],"header-authority"))return header_authority_case();\n')
controls=(
 ('header-domain','geo_placement_sources_definition_header','*out=result;return true;','result.domain=(GeoPlacementDomain)(result.domain+1);*out=result;return true;','header-values','header-domain-matches-full-projection'),
 ('header-region','geo_pd_definition_header','next.region_id=(uint32_t)count;','next.region_id=(uint32_t)(count+1);','header-values','header-region-matches-full-projection'),
 ('header-tail','geo_pd_definition_header','r.p!=r.end||actual!=id','actual!=id','header-malformed','header-tail-matches-full'),
 ('header-id','geo_pd_definition_header','r.p!=r.end||actual!=id','r.p!=r.end','header-authority','header-id-rejection-matches-full'),
 ('header-domain-bound','geo_pd_definition_header','||domain>GEO_PLACEMENT_REGION_SET','||false','header-malformed','header-domain-bound-matches-full'),
 ('header-component-bound','geo_pd_definition_header','||count>GEO_PLACEMENT_COMPONENT_CAPACITY','||false','header-malformed','header-component-bound-matches-full'),
 ('header-hole-bound','geo_pd_definition_header','||count>GEO_REGION_MAX_HOLES','||false','header-malformed','header-hole-bound-matches-full'),
 ('header-vertex-bound','geo_pd_loop_skip','||count>GEO_LOOP_MAX_VERTICES','||false','header-malformed','header-vertex-bound-matches-full'),
 ('header-schema','geo_placement_sources_definition_header','strcmp(value.as.definition.schema,GEO_PLACEMENT_DEFINITION_SCHEMA)','false','header-authority','header-schema-rejection-matches-full'),
 ('header-atomic','geo_placement_sources_definition_header','if(!s||!out)return false;','if(!s||!out)return false;memset(out,0,sizeof *out);','header-authority','header-failure-preserves-all-output-bytes'),
 ('header-edge-kind','geo_placement_sources_definition_header','GEO_DEPENDENCY_DEFINITION_REQUIRED','GEO_DEPENDENCY_VALUE_REQUIRED','header-values','header-consumer-edge-requires-definition'),
 ('header-binding','geo_placement_sources_definition_header','*out=result;return true;','const GeoPlacementDefinition *raw=geo_placements_find(s->placements,id);if(!raw)return false;*out=(GeoPlacementDefinitionHeader){raw->domain,raw->region_id};return true;','header-values','header-domain-matches-full-projection'),
)
for name,fn,before,after,case,marker in controls:
 body=function(source,fn);assert body.count(before)==1,(name,body.count(before));assert '"'+marker+'"' in h;assert '"'+case+'"' in h
p=once(p,'from pathlib import Path\n','from pathlib import Path\nimport json\n')
p=once(p,'class PlacementDefinitionBoundary(unittest.TestCase):\n','HEADER_CONTROLS = '+pprint.pformat(controls,width=100)+'\n\n\nclass PlacementDefinitionBoundary(unittest.TestCase):\n')
# Original full API checks are retained and extended to the new API.
old='''        accessor = definition(source, "geo_placement_sources_definition")
        self.assertIn("GEO_DEPENDENCY_DEFINITION_REQUIRED", accessor)
        self.assertNotRegex(accessor, r"GEO_PLACEMENT_SOURCE_(?:FRAME|REGIONS)|geo_placements_find\\(")'''
new='''        for name in ("geo_placement_sources_definition", "geo_placement_sources_definition_header"):
            accessor = definition(source, name)
            self.assertIn("GEO_DEPENDENCY_DEFINITION_REQUIRED", accessor)
            self.assertNotRegex(accessor, r"GEO_PLACEMENT_SOURCE_(?:FRAME|REGIONS)|geo_placements_find\\(")'''
p=once(p,old,new)
# Existing assertions stay exact; optional execution rows preserve new 0/1/0 raw streams.
old='''    def case(self, name, exe=None, marker=None):
        run = subprocess.run([str(exe or self.exe), name], capture_output=True, text=True, encoding="utf-8", timeout=15)'''
new='''    def case(self, name, exe=None, marker=None, *, control=None, phase=None):
        command = [str(exe or self.exe), name]
        try:
            run = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=15)
        except subprocess.TimeoutExpired as error:
            if control is not None:
                def captured(value):
                    return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else value or ""
                print(json.dumps({"schema": "geometry-placement-header-control-execution/1",
                    "control": control, "phase": phase, "command": command, "exitCode": None,
                    "timedOut": True, "timeoutSeconds": 15, "stdout": captured(error.stdout),
                    "stderr": captured(error.stderr)}, ensure_ascii=False), flush=True)
            raise
        if control is not None:
            print(json.dumps({"schema": "geometry-placement-header-control-execution/1",
                "control": control, "phase": phase, "command": command, "exitCode": run.returncode,
                "timedOut": False, "stdout": run.stdout, "stderr": run.stderr}, ensure_ascii=False), flush=True)'''
p=once(p,old,new)
methods='''
    def test_header_projection_matches_full_public_api_for_all_canonical_domains_and_maximum(self):
        self.case("header-values")

    def test_header_full_wire_bounds_truncations_and_tail_match_original_decoder(self):
        self.case("header-malformed")

    def test_header_binding_values_active_dependencies_failures_reset_and_isolation(self):
        self.case("header-authority")

    def test_twelve_header_controls_fail_named_oracles_between_restored_baselines(self):
        build = kernel_only_native()
        original_path = build.kernel / "placement_sources.c"
        original_bytes = original_path.read_bytes()
        original = original_bytes.decode("utf-8")
        source = code(original)
        for name, function, before, after, case, marker in HEADER_CONTROLS:
            with self.subTest(control=name):
                self.case(case, control=name, phase="baseline")
                body = definition(original, function)
                self.assertEqual(1, body.count(before))
                self.assertEqual(1, source.count(body))
                path = build.kernel / ("placement-header-control-" + name + ".c")
                path.write_bytes(source.replace(body, body.replace(before, after, 1), 1).encode("utf-8"))
                try:
                    changed = build.compile(path, "placement-header-control-" + name)
                    objects = [changed if obj == build.placement_sources_object else obj for obj in self.objects]
                    exe = build.link("placement-header-control-" + name, objects)
                    self.case(case, exe, marker, control=name, phase="mutant")
                finally:
                    self.assertEqual(original_bytes, original_path.read_bytes())
                    self.case(case, control=name, phase="restored")
'''
p=once(p,'\n\nif __name__ == "__main__":','\n'+methods+'\n\nif __name__ == "__main__":')
ast.parse(p)
# Preserve original controls and every original runtime assertion.
oldcontrols=base[P].decode();a=oldcontrols.index('CONTROLS = (');b=oldcontrols.index('class PlacementDefinitionBoundary',a);assert oldcontrols[a:b] in p
for marker in re.findall(r',"([^"\n]+)"\)',base[H].decode()):assert '"'+marker+'"' in h
for rel,t in [(H,h),(P,p)]:f=O/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(t)
patch=''.join(''.join(difflib.unified_diff(base[r].decode().splitlines(keepends=True),t.splitlines(keepends=True),fromfile='a/'+r,tofile='b/'+r)) for r,t in [(H,h),(P,p)])
(O/'candidate.patch').write_text(patch)
def method_names(t):return [n.name for n in ast.walk(ast.parse(t)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
oldnames=method_names(base[P].decode());newnames=method_names(p)
meta={'schema':'geo261-placement-header-permanent-preparation/1','status':'prepared-not-compiled-not-executed','sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'preparedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'beforeSha256':{r:sha(b) for r,b in base.items()},'candidateSha256':{H:sha(h.encode()),P:sha(p.encode())},'productSha256':{r:sha((R/r).read_bytes()) for r in ['geometry-core/kernel/placement_sources.c','geometry-core/kernel/placement_sources.h','geometry-app/native/reference_sources.inc']},'patchSha256':sha(patch.encode()),'original20ControlsByteUnchanged':True,'newControls':len(controls),'newMethodCount':len(newnames)-len(oldnames),'oldStaticMethodCount':len(oldnames),'newStaticMethodCount':len(newnames),'newMethods':[n for n in newnames if n not in oldnames],'oracle':'Unchanged original full public accessor plus existing independently written BE vectors; no copied new parser','limits':'原15s case timeout保持；新方法數只是AST census預期，正式仍完整--update-expected核實','compiled':False,'executed':False,'repoModified':False}
(O/'PREPARED.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'out':str(O),'patchSha256':meta['patchSha256'],'newMethods':meta['newMethodCount'],'oldStaticMethods':len(oldnames),'newStaticMethods':len(newnames),'controls':len(controls),'compiled':False,'executed':False}))
