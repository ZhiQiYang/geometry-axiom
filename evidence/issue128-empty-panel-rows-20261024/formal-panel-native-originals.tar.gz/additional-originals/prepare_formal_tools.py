from pathlib import Path
import hashlib,json,difflib,ast
BASE=Path('/tmp/geo300-cut-list-storage-20261024/formal-tools')
OUT=Path('/workspace/issue128-p2-formal-tools-20261024');OUT.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
pins={'retain_report_streams.py':'1ac22c23067503b0379fff3e39aa91a5862ac5ee6394eecc36c9731fb47e2532','run_report_suite.py':'98da9fdf5bb548dddee52db659453ed09abfd2b74accb12276edab541bfee06a','launch_report_suite.py':'7a15af7d663b307abc128695ffc1205afb42eed6ca31154d394bb4d551498e13'}
original={name:(BASE/name).read_text()for name in pins}
for name,pin in pins.items():assert sha(original[name].encode())==pin
observer=original['retain_report_streams.py']
start=observer.index('def install_storage_header_snapshot(');stop=observer.index('def main():',start)
observer=observer[:start]+observer[stop:]
start=observer.index('    watched = ');stop=observer.index('    for path in watched:',start)
observer=observer[:start]+'''    watched = ['tests/test_geo261_panel_native.py','tests/test_geo261_native_kernel.py',
               'geometry-templates/woodworking/native/panel_layout.c',
               'tests/geo261_panel_harness.c','tests/geo261_panel_legacy_fixture.txt']
'''+observer[stop:]
observer=observer.replace('tests/test_geo261_wood_report_policy.py','tests/test_geo261_panel_native.py').replace('report-suite','panel-suite').replace('report suite','panel suite')
observer=observer.replace("    header_snapshots=install_storage_header_snapshot(out/'storage-header-snapshots',observation_errors)\n",'').replace("                 'storage_header_snapshots':header_snapshots,\n",'')
observer=observer.replace("        (folder/'result.json').write_text",'''        if positional and isinstance(positional[0], (list,tuple)) and positional[0]:
            executable=Path(positional[0][0])
            if executable.is_absolute() and executable.is_file() and executable.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve()):
                body=executable.read_bytes()
                row['actual_executable']={'path':str(executable),'bytes':len(body),'sha256':digest(body)}
        (folder/'result.json').write_text''')
(OUT/'retain_panel_streams.py').write_text(observer)
driver=original['run_report_suite.py']
start=driver.index('def control_proofs(');stop=driver.index('\ndef main():',start)
proof=r'''def control_proofs(observed):
    native=[];complete=True
    def stream(row,name):
        item=row[name]
        if not item.get('captured'):raise RuntimeError('missing original child stream')
        path=Path(item['path']).resolve()
        if not path.is_relative_to(OUT.resolve()):raise RuntimeError('stream outside private OUT')
        body=path.read_bytes()
        if len(body)!=item['bytes']or sha(body)!=item['sha256']:raise RuntimeError('original stream changed')
        return body
    names={'panel-native-client','empty-axis-work-fixed','empty-axis-work-withdrawn','empty-axis-work-restored',
           'clip-hole','clip-cut','clip-keep','clip-budget','layout-odd','layout-frame','support-hole-cuts','support-union','support-round','support-merge',
           'empty-axis-one-phase','empty-axis-drop-seams','empty-axis-reject-empty'}
    for row in observed['commands']:
        argv=row.get('args',[None])[0]
        if not isinstance(argv,list)or len(argv)!=2:continue
        name=Path(argv[0]).name.removesuffix('.exe')
        if name not in names:continue
        try:
            binary=row['actual_executable'];assert binary['bytes']>0 and len(binary['sha256'])==64
            native.append({'number':row['number'],'name':name,'case':argv[1],'exit':row['returncode'],'stdout':stream(row,'stdout'),'stderr':stream(row,'stderr'),'binary':binary})
        except Exception:complete=False
    originals=[('clip-hole','clip','clip-hole-area'),('clip-cut','clip','clip-point-touch-components'),('clip-keep','capacity','clip-keeps-subdivision'),('clip-budget','capacity','clip-cumulative-budget'),('layout-odd','layout','layout-negative-odd-shift'),('layout-frame','layout','layout-world-range'),('support-hole-cuts','support','support-fragment-vertices'),('support-union','support','support-touching-union'),('support-round','support','support-rational-not-rounded'),('support-merge','support','support-widths-not-colours')]
    fresh=[('empty-axis-one-phase','empty-axis','empty-first-phase-keeps-other-parity'),('empty-axis-drop-seams','empty-axis','empty-axis-zero-pieces-with-raw-seams'),('empty-axis-reject-empty','empty-axis','empty-axis-legal'),('empty-axis-work-withdrawn','empty-axis-work','empty-axis-work-independent-of-empty-row-count')]
    proofs=[]
    for name,case,marker in originals+fresh:
        mutants=[r for r in native if r['name']==name and r['case']==case]
        result={'control':name,'case':case,'expected_assertion':marker,'mutant_matches':len(mutants),'passed':False,'claim':'original control: separately recorded baseline and normal assertion rejection; no per-control restored execution claimed' if (name,case,marker)in originals else 'new control: actual baseline/withdrawal/restoration 0/1/0'}
        if len(mutants)==1:
            mutant=mutants[0];base='empty-axis-work-fixed'if name=='empty-axis-work-withdrawn'else'panel-native-client';restore='empty-axis-work-restored'if name=='empty-axis-work-withdrawn'else'panel-native-client'
            before=[r for r in native if r['name']==base and r['case']==case and r['number']<mutant['number']]
            after=[r for r in native if r['name']==restore and r['case']==case and r['number']>mutant['number']]
            baseline=max(before,key=lambda r:r['number'])if before else None
            restored=min(after,key=lambda r:r['number'])if after else None
            result.update(command_numbers=[None if baseline is None else baseline['number'],mutant['number'],None if restored is None else restored['number']],actual_exits=[None if baseline is None else baseline['exit'],mutant['exit'],None if restored is None else restored['exit']],variant_executable=mutant['binary'])
            result['passed']=baseline is not None and baseline['exit']==0 and not baseline['stderr'] and mutant['exit']==1 and mutant['stderr']==('ASSERT:'+marker+'\n').encode()
            if (name,case,marker)in fresh:result['passed']=result['passed']and restored is not None and restored['exit']==0 and not restored['stderr']
        proofs.append(result)
    return proofs,complete
'''
driver=driver[:start]+proof+driver[stop:]
replacements={
 '39273bc0229fbbb16565134e1f8fad3a0d598c31':'324034812bb6effca68e0413bc0468595337b317',
 '/workspace/geo300-contact-index-work':'/workspace/issue128-empty-panel-rows-work-20261024',
 '/workspace/geo300-cut-list-storage-39273bc0-formal':'/workspace/issue128-p2-32403481-formal',
 '/tmp/geo300-cut-list-storage-20261024/formal-tools/retain_report_streams.py':str(OUT/'retain_panel_streams.py'),
 "SUITES=[('wood-report','tests/test_geo261_wood_report_policy.py',11)]":"SUITES=[('panel-native','tests/test_geo261_panel_native.py',13)]",
 "'a5f1806fb3cad2dada1a56e79e01d54f9f86700f'":"'6d9d46e8d16af75351924c6d47a078d3eb647cc0'",
 pins['retain_report_streams.py']:sha(observer.encode()),
 "'geo300-cut-list-original-report-suite/1'":"'issue128-p2-original-panel-suite/1'",
 'plus original NativeBuild audit and two named compiler header snapshots':'plus original NativeBuild audit and hashes of actual executed native files',
 "'cost_or_performance_run':False":"'wall_clock_performance_run':False,'correctness_operation_count_witness':True",
 "'report-retain.py'":"'panel-retain.py'",
 "'suite':'wood-report'":"'suite':'panel-native'",
 "result['control_proofs'],result['native_streams_complete'],result['header_snapshots_complete']=control_proofs(observed)":"result['control_proofs'],result['native_streams_complete']=control_proofs(observed)",
 " and result['header_snapshots_complete']":"",
 "len(result['control_proofs'])==9":"len(result['control_proofs'])==14"
}
for before,after in replacements.items():assert before in driver,before;driver=driver.replace(before,after)
driver=driver.replace("        run(['df','-B1','/tmp','/workspace'])\n", "        run(['df','-B1','/tmp','/workspace'])\n        run(['uname','-a'])\n        run([sys.executable,'--version'])\n        run(['cc','--version'])\n",1)
(OUT/'run_panel_suite.py').write_text(driver)
launch=original['launch_report_suite.py']
for before,after in {
 '/workspace/geo300-cut-list-storage-39273bc0-formal-launch':'/workspace/issue128-p2-32403481-formal-launch',
 '/tmp/geo300-cut-list-storage-20261024/formal-tools/run_report_suite.py':str(OUT/'run_panel_suite.py'),
 '/tmp/geo300-cut-list-storage-20261024/formal-tools/retain_report_streams.py':str(OUT/'retain_panel_streams.py'),
 pins['run_report_suite.py']:sha(driver.encode()),pins['retain_report_streams.py']:sha(observer.encode()),
 '39273bc0229fbbb16565134e1f8fad3a0d598c31':'324034812bb6effca68e0413bc0468595337b317',
 '/workspace/geo300-contact-index-work':'/workspace/issue128-empty-panel-rows-work-20261024',
 'geo300-cut-list-top-launch/1':'issue128-p2-top-launch/1',
 'fixed GEO300 candidate':'fixed P2 candidate',
 'no ledger or performance':'no ledger or wall-clock performance; original operation-count correctness witness'
}.items():assert before in launch,before;launch=launch.replace(before,after)
(OUT/'launch_panel_suite.py').write_text(launch)
manifest={'source':'324034812bb6effca68e0413bc0468595337b317','formal_started':False,'tools':[]}
for old,new in [('retain_report_streams.py','retain_panel_streams.py'),('run_report_suite.py','run_panel_suite.py'),('launch_report_suite.py','launch_panel_suite.py')]:
    text=(OUT/new).read_text();ast.parse(text)
    (OUT/(old+'.original.txt')).write_text(original[old])
    (OUT/(new+'.diff')).write_text(''.join(difflib.unified_diff(original[old].splitlines(True),text.splitlines(True),fromfile=old,tofile=new)))
    manifest['tools'].append({'path':str(OUT/new),'sha256':sha(text.encode()),'original_sha256':pins[old]})
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
