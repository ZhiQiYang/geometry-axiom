import ast,copy,difflib,hashlib,json,subprocess
from pathlib import Path
B=Path('/workspace/issue128-p2-formal-tools-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;findings=[]
def ck(v,l):
 global checks
 checks+=1
 if not v:findings.append(l)
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(Path(p).read_bytes())
manifest=json.loads((B/'MANIFEST.json').read_text());S=manifest['source'];bodies={}
for item in manifest['tools']:
 p=Path(item['path']);ck(h(p)==item['sha256'],'exact fixed tool '+p.name);bodies[p.name]=p.read_text();ast.parse(bodies[p.name])
originals={'retain_panel_streams.py':'retain_report_streams.py','run_panel_suite.py':'run_report_suite.py','launch_panel_suite.py':'launch_report_suite.py'}
for name,old in originals.items():
 oldfile=B/(old+'.original.txt');item=next(x for x in manifest['tools'] if Path(x['path']).name==name);ck(h(oldfile)==item['original_sha256'],'original template pin '+old)
 ck((B/(name+'.diff')).read_text()==''.join(difflib.unified_diff(oldfile.read_text().splitlines(True),bodies[name].splitlines(True),fromfile=old,tofile=name)),'full recorded wrapper diff '+name)
driver=bodies['run_panel_suite.py'];observer=bodies['retain_panel_streams.py'];launcher=bodies['launch_panel_suite.py'];da=ast.parse(driver);oa=ast.parse(observer);oldoa=ast.parse((B/'retain_report_streams.py.original.txt').read_text())
def fun(a,name):return next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name==name)
ck(ast.dump(fun(oa,'install_native_retention'),include_attributes=False)==ast.dump(fun(oldoa,'install_native_retention'),include_attributes=False),'native cleanup retention function exactly unchanged')
ck('install_storage_header_snapshot' not in observer and "runpy.run_path('tests/test_geo261_panel_native.py', run_name='__main__')" in observer,'only target switch and removed report-specific hook')
ck('completed = original_run(*positional, **keyword)' in observer and 'return completed' in observer and 'subprocess.run = original_run' in observer,'original subprocess arguments/result identity and restoration')
ck("'original-text-encoded-utf8'" in observer and "'original-bytes'" in observer and 'observation_errors.append' in observer,'original text/bytes distinction and observer failures recorded')
ck("executable.resolve().is_relative_to(Path(os.environ['TMPDIR']).resolve())" in observer and "row['actual_executable']" in observer,'only actual private executed files hashed')
ck("SUITES=[('panel-native','tests/test_geo261_panel_native.py',13)]" in driver and 'timeout=None' in driver,'original13 entire methods and no added outer timeout')
ck("Path('/tmp/g261r3/secondary.lock')" in driver and 'fcntl.LOCK_EX|fcntl.LOCK_NB' in driver and "'R3_lock_taken':False" in driver,'root-granted secondary nonblocking lock only')
ck("OUT=Path('/workspace/issue128-p2-32403481-formal')" in driver and "TMP=Path('/workspace/issue128-p2-32403481-formal-tmp')" in driver and '/tmp/geometry-tests' not in driver+observer+launcher,'private work/output/temp and no global native cache reference')
ck("if OUT.exists() or TMP.exists() or TOOLS.exists()" in driver and "if status:raise RuntimeError('completed source not clean; preserve all data')" in driver and "run(['git','checkout','--detach',S]" in driver,'fresh outputs and guarded permitted private checkout only')
ck("result['actual_exit']==0" in driver and "len(result['control_proofs'])==14" in driver and "all(x['passed']for x in result['control_proofs'])" in driver,'no partial-success product acceptance')
ck("timeout=None,check=False" in launcher and "mapped!=row['actual_process_returncode']" in launcher and "launcher_exit=2 if problems else row['actual_process_returncode']" in launcher,'true reaper/primary status and no falsezero')
proc=subprocess.run(['git','-C','/workspace/issue128-empty-panel-rows-work-20261024','show',S+':tests/test_geo261_panel_native.py'],capture_output=True);ck(proc.returncode==0,'original fixed private GitS suite available');source=proc.stdout.decode();tree=ast.parse(source);methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];ck(len(methods)==13,'candidate13 method inventory exact');ck('capture_output=True, text=True, timeout=60' in source,'original child60s retained')
original_test=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='test_single_guard_mutations_fail_independent_assertions');original_controls=ast.literal_eval(next(n.value for n in original_test.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='controls' for x in n.targets)))
parser=fun(da,'control_proofs');decl={}
for n in parser.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('originals','fresh'):decl[n.targets[0].id]=ast.literal_eval(n.value)
ck(decl['originals']==[(x[0],x[4],x[5]) for x in original_controls] and len(decl['fresh'])==4,'ten original named markers unchanged plus four new controls')
# Pure parser adversarial fixtures; no subject/tool main/compiler is run.
fake=O/'issue128-p2-parser-fixtures';fake.mkdir(exist_ok=True);env={'Path':Path,'sha':sha,'OUT':fake};exec(compile(ast.Module(body=[parser],type_ignores=[]),'<original-parser-only>','exec'),env)
def make_observed():
 rows=[]
 def add(name,case,code=0,marker=None):
  number=len(rows)+1;folder=fake/str(number);folder.mkdir(exist_ok=True);row={'number':number,'args':[['/private/'+name,case]],'returncode':code,'actual_executable':{'bytes':1,'sha256':'0'*64}}
  for stream,data in [('stdout',b''),('stderr',b'' if marker is None else ('ASSERT:'+marker+'\n').encode())]:
   p=folder/(stream+'.bin');p.write_bytes(data);row[stream]={'captured':True,'path':str(p),'bytes':len(data),'sha256':sha(data)}
  rows.append(row)
 for name,case,marker in decl['originals']:add(name,case,1,marker)
 for case in ('clip','capacity','layout','support'):add('panel-native-client',case)
 for name,case,marker in decl['fresh']:
  add('empty-axis-work-fixed' if name=='empty-axis-work-withdrawn' else 'panel-native-client',case);add(name,case,1,marker);add('empty-axis-work-restored' if name=='empty-axis-work-withdrawn' else 'panel-native-client',case)
 return {'commands':rows}
observed=make_observed();proofs,complete=env['control_proofs'](observed);ck(complete and len(proofs)==14 and all(x['passed'] for x in proofs),'pure parser accepts original-late baseline and four exact chronological triplets')
ck(all(x['actual_exits']==[0,1,None] and x['command_numbers'][2] is None and not x['baseline_is_required_before_mutant'] for x in proofs[:10]),'original ten controls never claim per-control restored execution')
ck(all(x['actual_exits']==[0,1,0] and x['command_numbers'][0]<x['command_numbers'][1]<x['command_numbers'][2] for x in proofs[10:]),'new four require actual ordered0/1/0')
bad=copy.deepcopy(observed);bad['commands'][0]['returncode']=-11;proof,_=env['control_proofs'](bad);ck(not proof[0]['passed'],'negative: signal/crash is not mutation kill')
bad=copy.deepcopy(observed);bad['commands'][0]['stderr']['captured']=False;proof,complete=env['control_proofs'](bad);ck(not complete and not proof[0]['passed'],'negative: missing raw stream cannot pass')
bad=copy.deepcopy(observed);bad['commands'][-1]['number']=0;proof,_=env['control_proofs'](bad);ck(not proof[-1]['passed'],'negative: restored run before mutant cannot pass new control')
bad=copy.deepcopy(observed);bad['commands'][0]['stderr']=bad['commands'][1]['stderr'];proof,_=env['control_proofs'](bad);ck(not proof[0]['passed'],'negative: another named assertion cannot kill requested control')
report={'schema':'issue128-p2-original-wrapper-static-and-parser-peer/1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'source_sha':S,'tools':manifest['tools'],'original_methods':13,'original_controls':10,'new_chronological_controls':4,'pure_parser_negative_checks':4,'limits':['No product test, native compiler, original observer main or formal driver was run. Pure parser fixtures test only report acceptance logic.','Original10 controls have independent baseline and failure receipts; restored remains null. Only new4 controls claim strict chronological0/1/0.','User/root scheduler authorization and sufficient workspace are still required before launch. Static acceptance is not a formal gate pass.','Old copied driver docstring mentions report/cut-list; actual fixed suite target and execution scope is panel-native, explicitly checked.']};dst=O/'ISSUE128_P2_FORMAL_WRAPPERS_STATIC_PEER.json';dst.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':checks,'exit_code':report['exit_code'],'findings':findings,'path':str(dst),'sha256':h(dst)},ensure_ascii=False));raise SystemExit(report['exit_code'])
