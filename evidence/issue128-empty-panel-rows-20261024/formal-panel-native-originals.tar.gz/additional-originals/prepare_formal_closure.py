from pathlib import Path
import ast, hashlib, importlib.util, json, os, re, shutil, subprocess
ROOT=Path('/workspace/issue128-empty-panel-rows-work-20261024')
OUT=Path('/workspace/issue128-branch-publication-20261024/formal-closure')
S='324034812bb6effca68e0413bc0468595337b317'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
assert not OUT.exists();OUT.mkdir()
rec=cap.Recorder(OUT,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),S)
def run(argv):
    row,out,err=rec.run(argv,cwd=ROOT,timeout=120,check=False,source_variant='exact-original-source-closure-preparation-only')
    assert row['actual_process_returncode']==0,row['directory'];return out
run(['df','-B1','/workspace','/tmp'])
assert shutil.disk_usage('/workspace').free>100*1024*1024
assert run(['git','status','--porcelain'])==b''
helper=run(['git','show',S+':tests/test_geo261_native_kernel.py']).decode()
paths=set(re.findall(r'shutil.copy2\(ROOT / "([^"]+)"',helper))
# Only concrete NativeBuild constructor copy loops, not entire directories.
for match in re.finditer(r'for name in (\([^\n]+\)):\n\s+shutil.copy2\(ROOT / "([^"]+)" / name',helper):
    paths.discard(match[2]);paths.update(match[2]+'/'+name for name in ast.literal_eval(match[1]))
paths.update(['tests/__init__.py','tests/_bridge.py','tests/binaries.py','tests/test_engineering_json.py',
 'tests/test_geo261_native_kernel.py','tests/geo261_panel_legacy_fixture.txt','tests/pf3_algorithm.c',
 'geometry-core/panel_fill_layout.inc','geometry-core/panel_fill_support.inc'])
existing=(ROOT/'.git/info/sparse-checkout').read_text().splitlines()
records=[]
for path in sorted(paths):
    data=run(['git','show',S+':'+path]);records.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert sum(row['bytes'] for row in records)<4*1024*1024
patterns=existing+['/'+p for p in sorted(paths) if '/'+p not in existing]
(ROOT/'.git/info/sparse-checkout').write_text('\n'.join(patterns)+'\n')
run(['git','read-tree','-mu','HEAD'])
for row in records:assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256']
assert run(['git','status','--porcelain'])==b''
allocated=sum(p.lstat().st_blocks*512 for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink())
assert allocated<20*1024*1024
result={'source':S,'paths':records,'paths_count':len(records),'additional_original_bytes':sum(r['bytes']for r in records),'allocated_source_checkout_bytes':allocated,'source_budget_bytes':20*1024*1024,'compiled':False,'commands':rec.rows}
cap.dump(OUT/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items()if k not in ('paths','commands')}))
