from pathlib import Path
import hashlib, json, subprocess, tarfile, datetime
R=Path('/workspace/issue128-empty-panel-rows-work-20261024')
P=Path('/workspace/issue128-branch-publication-20261024')
OUT=Path(__file__).resolve().parent
E='6d9d46e8d16af75351924c6d47a078d3eb647cc0'
D='ca0784cc9f374164bfaf08f22d6bdcfd7489628c'
S='324034812bb6effca68e0413bc0468595337b317'
prefix='evidence/issue128-empty-panel-rows-20261024/'
checks=[]; reads=[]
def h(b): return hashlib.sha256(b).hexdigest()
def check(name,yes): checks.append({'name':name,'passed':bool(yes)})
def git(*args):
    p=subprocess.run(['git','--no-optional-locks',*args],cwd=R,capture_output=True)
    reads.append({'argv':list(args),'exit':p.returncode,'stdout_sha256':h(p.stdout),'stderr':p.stderr.decode()})
    assert p.returncode==0
    return p.stdout
idxraw=git('show',E+':'+prefix+'RAW_INDEX.json');idx=json.loads(idxraw)
check('source-binding',idx['product_sha']==S)
archive=R/prefix/idx['archive']; body=archive.read_bytes()
check('archive-pin',len(body)==376145 and h(body)==idx['archive_sha256']=='e1149775a43e15da5b7de1f887d6491248b12c0d3af5ba084c35346b38609cc1')
check('archive-public-bytes',git('show',E+':'+prefix+idx['archive'])==body)
with tarfile.open(archive,'r:gz') as tf:
    members=tf.getmembers(); expected={x['member']:x for x in idx['members']}
    check('322-members',len(members)==len(expected)==322)
    check('member-set',set(x.name for x in members)==set(expected))
    for member in members:
        check('regular:'+member.name,member.isfile())
        raw=tf.extractfile(member).read();row=expected[member.name]
        check('original-pin:'+member.name,len(raw)==row['bytes'] and h(raw)==row['sha256'])
check('E-source-parent',git('rev-parse',E+'^').decode().strip()==S)
changed=git('diff-tree','--no-commit-id','--name-only','-r',E).decode().splitlines()
check('E-evidence-only',bool(changed) and all(x.startswith(prefix) for x in changed))
body=P.joinpath('PR_BODY.md').read_bytes()
check('public-body-pin',h(body)=='375a7747bc06267bd90d4b73dea2aca3340bab2a67fdedea4ca58f362dcc7cf5' and git('show',D+':PR_BODY.md')==body)
request=json.loads(P.joinpath('PR_REQUEST.json').read_text())
check('request-exact-fivefields',set(request)=={'head','base','title','body_ref','body_path'})
check('request-own-head-base',request['head']=='codex/issue128-empty-panel-rows-20261024' and request['base']=='codex/geo300-cut-list-storage-20261024')
check('request-body-ref',request['body_ref']==request['head']+'-prbody' and request['body_path']=='PR_BODY.md')
text=body.decode()
check('unique-current-state',text.count('唯一 current-state')==1)
check('explicit-unrun-native-controls-ledger-architecture',all(x in text for x in ['原完整 panel suite | **UNRUN**','新成本撤回／恢復＋三 semantic controls | **UNRUN**','最終突變帳本／架構三裁判與收據 | **UNRUN**','**NOT READY**']))
check('preserved-preparation-failure',all(x in text for x in ['git add','退出 1','matcher']))
report={'evidence_sha':E,'body_sha':D,'product_sha':S,'checks_total':len(checks),'failed_checks':sum(not c['passed'] for c in checks),'checks':checks,'git_reads':reads,'scope':'Read-only static publication review; no source edits, C, unittest or formal runtime.','limitations':['Archive roundtrip and assertions in documentation are checked; pending C/performance results are not inferred.'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':report['failed_checks'],'sha256':h((OUT/'REVIEW.json').read_bytes())}))
raise SystemExit(bool(report['failed_checks']))
