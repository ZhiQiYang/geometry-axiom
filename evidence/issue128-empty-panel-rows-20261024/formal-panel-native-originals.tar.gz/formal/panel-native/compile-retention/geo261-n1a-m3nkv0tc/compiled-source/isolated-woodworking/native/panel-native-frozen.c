#include "panel_support.h"
#include "grid.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
typedef GeoCoord Coord;
typedef GeoPoint2 SurfacePoint2;
typedef GeoPoint3 Point3;
typedef GeoFrame SurfaceFrame;
typedef GeoLoop2View PolygonLoop2;
typedef struct {PolygonLoop2 outline,holes[GEO_REGION_MAX_HOLES];size_t hole_count;} SpaceBoundarySurface;
typedef struct {SurfaceFrame frame;uint32_t boundary_id,obstacle_count;} FinishSurface;
typedef struct {Coord rect[4];} FsObstacleView;
#define FS_OBSTACLE_MAX 1024
#define WORLD_MAX_TIMBERS 64
#define PF_TILE_MAX 1024
#define PF_AXIS_MAX 128
#define PF_EDGE_MAX 4096
#define PF_VERTEX_MAX 32768
#define PF_SUPPORT_MAX 32768
#define PF_SUPPORT_WORK_MAX 1048576
typedef WoodPanelLoop PfLoop;
typedef WoodPanelFragment PfFragment;
typedef WoodPanelTile PfTile;
typedef WoodPanelSeamLine PfSeamLine;
typedef struct {
    PfTile *tiles;size_t count,fragments,vertices,whole;
    PfSeamLine *seams;size_t seam_count;
    Coord size[2],gap,stagger,t;const FinishSurface *finish;
    FsObstacleView obstacles[FS_OBSTACLE_MAX];bool cuts[FS_OBSTACLE_MAX];bool keep_collinear;
} PfLayout;
typedef WoodPanelFootprint PfFootprint;
typedef WoodPanelEffectiveSeam PfEffectiveSeam;
typedef WoodPanelSupportPart PfSupportPart;
typedef struct {Coord lo,hi;} PfInterval;
typedef WoodPanelSupport PfSupport;
typedef struct {SpaceBoundarySurface boundary;FinishSurface finish;const WoodPanelLayoutInput *input;} World;
typedef struct {Coord origin[2];int stagger_axis;} PanelFill;
static char frozen_error[256];
static bool fs_error(const char *format,...)
{va_list args;va_start(args,format);vsnprintf(frozen_error,sizeof frozen_error,format,args);va_end(args);return false;}
#define fs_capacity_error fs_error
static Coord coord_min(Coord a,Coord b){return a<b?a:b;}
static Coord coord_max(Coord a,Coord b){return a>b?a:b;}
static bool coord_in_range(Coord a){return -INT64_C(100000000)<=a&&a<=INT64_C(100000000);}
static int sp_coord_compare(const void *a,const void *b){Coord x=*(const Coord*)a,y=*(const Coord*)b;return x<y?-1:x>y?1:0;}
#define grid_floor_div geo_floor_div
#define grid_ceil_div geo_ceil_div
#define panel_layout_pitch geo_period_pitch
#define panel_layout_body geo_period_body
#define panel_layout_center geo_period_center
#define panel_layout_shift geo_alternating_shift
static const SpaceBoundarySurface *world_find_boundary(const World *w,uint32_t id){(void)id;return &w->boundary;}
static bool pf_values(const World *w,const PanelFill *p,PfLayout *d)
{(void)p;d->finish=&w->finish;d->size[0]=w->input->size[0];d->size[1]=w->input->size[1];d->gap=w->input->gap;d->stagger=w->input->stagger;
 for(size_t i=0;i<w->input->cut_count;++i){GeoRect2 r=w->input->cuts[i];d->obstacles[i]=(FsObstacleView){{r.min_u,r.min_v,r.max_u,r.max_v}};d->cuts[i]=true;}return true;}
static void pf_free(PfLayout *d)
{ if(d->tiles)for(size_t i=0;i<d->count;++i){PfTile *t=&d->tiles[i];for(size_t k=0;k<t->count;++k){PfFragment *f=&t->fragments[k];for(size_t l=0;l<f->count;++l)free(f->loops[l].points);free(f->loops);}free(t->fragments);}free(d->tiles);free(d->seams);memset(d,0,sizeof *d); }
static bool pf_inside_loop(const PolygonLoop2 *p,Coord u2,Coord v2)
{ bool inside=false;for(size_t i=0;i<p->count;++i){SurfacePoint2 a=p->v[i],b=p->v[(i+1)%p->count];if(a.u==b.u&&2*a.u>u2&&2*coord_min(a.v,b.v)<v2&&v2<2*coord_max(a.v,b.v))inside=!inside;}return inside; }
static bool pf_inside(const SpaceBoundarySurface *b,const PfLayout *d,Coord u2,Coord v2)
{ if(!pf_inside_loop(&b->outline,u2,v2))return false;for(size_t h=0;h<b->hole_count;++h)if(pf_inside_loop(&b->holes[h],u2,v2))return false;
  for(uint32_t i=0;i<d->finish->obstacle_count;++i){const Coord *r=d->obstacles[i].rect;if(d->cuts[i]&&2*r[0]<u2&&u2<2*r[2]&&2*r[1]<v2&&v2<2*r[3])return false;}return true; }
static bool pf_cut_coord(Coord *xs,size_t *n,Coord v,Coord lo,Coord hi)
{ if(v<=lo||v>=hi)return true;for(size_t i=0;i<*n;++i)if(xs[i]==v)return true;if(*n==PF_AXIS_MAX)return fs_capacity_error("I33 CAPACITY: clipping axis limit is %d",PF_AXIS_MAX);xs[(*n)++]=v;return true; }
typedef struct { int x0,y0,x1,y1,dir;bool used; } PfEdge;
static int pf_point_order(SurfacePoint2 a,SurfacePoint2 b)
{return a.u!=b.u?(a.u<b.u?-1:1):a.v!=b.v?(a.v<b.v?-1:1):0;}
static int pf_loop_order(const void *a,const void *b)
{const PfLoop *x=a,*y=b;if(x->hole!=y->hole)return x->hole?1:-1;return pf_point_order(x->points[0],y->points[0]);}
static int pf_fragment_order(const void *a,const void *b)
{return pf_point_order(((const PfFragment*)a)->loops[0].points[0],((const PfFragment*)b)->loops[0].points[0]);}
static bool pf_clip(const World *w,PfLayout *d,PfTile *t)
{
    const SpaceBoundarySurface *b=world_find_boundary(w,d->finish->boundary_id);
    Coord xs[PF_AXIS_MAX]={t->body[0],t->body[2]},ys[PF_AXIS_MAX]={t->body[1],t->body[3]};size_t nx=2,ny=2;bool ok=true;
    for(size_t h=0;h<=b->hole_count&&ok;++h){const PolygonLoop2 *l=h?&b->holes[h-1]:&b->outline;for(size_t i=0;i<l->count&&ok;++i)ok=pf_cut_coord(xs,&nx,l->v[i].u,xs[0],xs[1])&&pf_cut_coord(ys,&ny,l->v[i].v,ys[0],ys[1]);}
    for(uint32_t i=0;i<d->finish->obstacle_count&&ok;++i)if(d->cuts[i])for(int k=0;k<4&&ok;++k)ok=k%2?pf_cut_coord(ys,&ny,d->obstacles[i].rect[k],ys[0],ys[1]):pf_cut_coord(xs,&nx,d->obstacles[i].rect[k],xs[0],xs[1]);
    if(!ok)return false;qsort(xs,nx,sizeof *xs,sp_coord_compare);qsort(ys,ny,sizeof *ys,sp_coord_compare);
    size_t width=nx-1,height=ny-1,n=width*height;int *labels=calloc(n,sizeof *labels),*queue=malloc(n*sizeof *queue);PfEdge *edges=malloc(PF_EDGE_MAX*sizeof *edges);
    if(!labels||!queue||!edges){free(labels);free(queue);free(edges);return fs_capacity_error("I33 CAPACITY: clipping workspace unavailable");}
    for(size_t y=0;y<height;++y)for(size_t x=0;x<width;++x)labels[y*width+x]=pf_inside(b,d,xs[x]+xs[x+1],ys[y]+ys[y+1])?-1:0;
    int component=0;
    for(size_t seed=0;seed<n&&ok;++seed)if(labels[seed]==-1){
        ++component;size_t head=0,tail=1;queue[0]=(int)seed;labels[seed]=component;Coord component_area=0;
        while(head<tail){int cell=queue[head++],x=cell%(int)width,y=cell/(int)width;component_area+=(xs[x+1]-xs[x])*(ys[y+1]-ys[y]);int neighbors[4]={x?cell-1:-1,x+1<(int)width?cell+1:-1,y?cell-(int)width:-1,y+1<(int)height?cell+(int)width:-1};
            for(int k=0;k<4;++k)if(neighbors[k]>=0&&labels[neighbors[k]]==-1){labels[neighbors[k]]=component;queue[tail++]=neighbors[k];}}
        PfFragment *grown=realloc(t->fragments,(t->count+1)*sizeof *grown);if(!grown){ok=fs_capacity_error("I33 CAPACITY: fragment workspace unavailable");break;}t->fragments=grown;PfFragment *f=&grown[t->count++];memset(f,0,sizeof *f);f->area=component_area;t->area+=component_area;
        size_t ne=0;
        for(size_t q=0;q<tail&&ok;++q){int cell=queue[q],x=cell%(int)width,y=cell/(int)width;
            bool boundary[4]={!y||labels[cell-width]!=component,x+1==(int)width||labels[cell+1]!=component,y+1==(int)height||labels[cell+width]!=component,!x||labels[cell-1]!=component};
            int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1},sx[4]={x,x+1,x+1,x},sy[4]={y,y,y+1,y+1};
            for(int k=0;k<4&&ok;++k)if(boundary[k]){if(ne==PF_EDGE_MAX){ok=fs_capacity_error("I33 CAPACITY: tile contour edge limit is %d",PF_EDGE_MAX);break;}edges[ne++]=(PfEdge){sx[k],sy[k],sx[k]+dx[k],sy[k]+dy[k],k,false};}}
        for(size_t start=0;start<ne&&ok;++start)if(!edges[start].used){
            SurfacePoint2 *points=malloc(ne*sizeof *points);if(!points){ok=fs_capacity_error("I33 CAPACITY: loop workspace unavailable");break;}
            size_t at=start,np=0;int firstx=edges[start].x0,firsty=edges[start].y0;
            while(ok){PfEdge *e=&edges[at];if(e->used||np==ne){ok=fs_error("R42: contour traversal did not close");break;}e->used=true;points[np++]=(SurfacePoint2){xs[e->x0],ys[e->y0]};if(e->x1==firstx&&e->y1==firsty)break;
                /* At a repeated vertex take the right branch first: this splits touching hole rings
                 * into simple clockwise loops, instead of one figure-eight. Components are already
                 * split by positive-length cell adjacency, so point-touching material is never joined. */
                int rank=-1;size_t next=ne;for(size_t k=0;k<ne;++k)if(!edges[k].used&&edges[k].x0==e->x1&&edges[k].y0==e->y1){int turn=(edges[k].dir-e->dir+4)%4,r=turn==3?3:turn==0?2:turn==1?1:0;if(r>rank){rank=r;next=k;}}
                if(next==ne){ok=fs_error("R42: open contour after clipping");break;}at=next;}
            if(!ok){free(points);break;}
            /* Remove collinear subdivision vertices, then rotate to the lexicographically smallest point. */
            SurfacePoint2 *corners=malloc(np*sizeof *corners);if(!corners){free(points);ok=fs_capacity_error("I33 CAPACITY: contour corners unavailable");break;}
            size_t count=0;for(size_t k=0;k<np;++k){SurfacePoint2 a=points[(k+np-1)%np],v=points[k],z=points[(k+1)%np];if(d->keep_collinear||!((a.u==v.u&&v.u==z.u)||(a.v==v.v&&v.v==z.v)))corners[count++]=v;}free(points);points=corners;
            size_t min=0;for(size_t k=1;k<count;++k)if(pf_point_order(points[k],points[min])<0)min=k;
            SurfacePoint2 *ordered=malloc(count*sizeof *ordered);if(!ordered){free(points);ok=fs_capacity_error("I33 CAPACITY: ordered loop unavailable");break;}for(size_t k=0;k<count;++k)ordered[k]=points[(min+k)%count];free(points);
            if(d->vertices+count>PF_VERTEX_MAX){free(ordered);ok=fs_capacity_error("I33 CAPACITY: layout vertex limit is %d",PF_VERTEX_MAX);break;}d->vertices+=count;
            PfLoop *loops=realloc(f->loops,(f->count+1)*sizeof *loops);if(!loops){free(ordered);ok=fs_capacity_error("I33 CAPACITY: loop collection unavailable");break;}f->loops=loops;
            bool hole=ordered[1].v>ordered[0].v;loops[f->count++]=(PfLoop){ordered,count,hole};
        }
        if(ok){qsort(f->loops,f->count,sizeof *f->loops,pf_loop_order);if(!f->count||f->loops[0].hole)ok=fs_error("R42: clipped component lacks an outer loop");}
    }
    free(labels);free(queue);free(edges);if(ok&&t->count)qsort(t->fragments,t->count,sizeof *t->fragments,pf_fragment_order);return ok;
}
static bool pf_build(const World *w,const PanelFill *p,PfLayout *d)
{
    memset(d,0,sizeof *d);if(!pf_values(w,p,d))return false;
    const SpaceBoundarySurface *b=world_find_boundary(w,d->finish->boundary_id);Coord lo[2]={b->outline.v[0].u,b->outline.v[0].v},hi[2]={lo[0],lo[1]};
    for(size_t i=1;i<b->outline.count;++i){lo[0]=coord_min(lo[0],b->outline.v[i].u);hi[0]=coord_max(hi[0],b->outline.v[i].u);lo[1]=coord_min(lo[1],b->outline.v[i].v);hi[1]=coord_max(hi[1],b->outline.v[i].v);}
    d->tiles=calloc(PF_TILE_MAX,sizeof *d->tiles);if(!d->tiles)return fs_capacity_error("I33 CAPACITY: layout workspace unavailable");
    int row=p->stagger_axis==0?1:0,along=1-row;Coord pitch[2]={panel_layout_pitch(d->size[0],d->gap),panel_layout_pitch(d->size[1],d->gap)};
    int64_t first=grid_floor_div(lo[row]-p->origin[row]-d->size[row],pitch[row])+1,last=grid_ceil_div(hi[row]-p->origin[row],pitch[row])-1;size_t enumerated=0;
    for(int64_t r=first;r<=last;++r){Coord shifted=p->origin[along]+panel_layout_shift(p->stagger_axis>=0,d->stagger,r);
        int64_t a=grid_floor_div(lo[along]-shifted-d->size[along],pitch[along])+1,z=grid_ceil_div(hi[along]-shifted,pitch[along])-1;
        if(z>=a&&(uint64_t)(z-a+1)>PF_TILE_MAX-enumerated){pf_free(d);return fs_capacity_error("I33 CAPACITY: full layout enumeration limit is %d tiles",PF_TILE_MAX);}
        for(int64_t k=a;k<=z;++k){++enumerated;PfTile *t=&d->tiles[d->count];t->i=row==0?r:k;t->j=row==1?r:k;
            t->body[row]=panel_layout_body(p->origin[row],d->size[row],d->gap,r);t->body[along]=panel_layout_body(shifted,d->size[along],d->gap,k);t->body[row+2]=t->body[row]+d->size[row];t->body[along+2]=t->body[along]+d->size[along];
            /* Non-visible sheet corners can be beyond D1; only returned geometry is checked below. */
            ++d->count;if(!pf_clip(w,d,t)){pf_free(d);return false;}
            if(!t->count){free(t->fragments);memset(t,0,sizeof *t);--d->count;continue;}
            d->fragments+=t->count;if(t->area==d->size[0]*d->size[1])++d->whole;
            for(int v=0;v<4;++v)if(!coord_in_range(t->body[v])){pf_free(d);return fs_capacity_error("I52/D1 CAPACITY: returned sheet corner outside D1");}
            for(size_t f=0;f<t->count;++f)for(size_t l=0;l<t->fragments[f].count;++l)for(size_t v=0;v<t->fragments[f].loops[l].count;++v){SurfacePoint2 point=t->fragments[f].loops[l].points[v];const SurfaceFrame *frame=&d->finish->frame;
                Coord u=point.u,z=point.v;Point3 world={frame->origin.x+u*frame->axis_u.x+z*frame->axis_v.x,frame->origin.y+u*frame->axis_u.y+z*frame->axis_v.y,frame->origin.z+u*frame->axis_u.z+z*frame->axis_v.z};
                if(!coord_in_range(u)||!coord_in_range(z)||!coord_in_range(world.x)||!coord_in_range(world.y)||!coord_in_range(world.z)){pf_free(d);return fs_capacity_error("I52/D1 CAPACITY: returned panel-fill vertex outside D1");}}
        }
    }
    d->seams=calloc(4*PF_TILE_MAX,sizeof *d->seams);if(!d->seams){pf_free(d);return fs_capacity_error("I33 CAPACITY: seam workspace unavailable");}
    for(int axis=0;axis<2;++axis){int other=1-axis;Coord step=pitch[axis],phase=panel_layout_center(p->origin[axis],d->size[axis],d->gap,0);
        /* D43: band r is [c_other(r-1),c_other(r)], including the half gaps.
         * Enumerate positive-length bbox intersections; body bounds omit those halves. */
        int64_t r0=0,r1=0;if(p->stagger_axis==axis){Coord center=panel_layout_center(p->origin[other],d->size[other],d->gap,0);r0=grid_floor_div(lo[other]-center,pitch[other])+1;r1=grid_ceil_div(hi[other]-center,pitch[other]);}
        for(int64_t r=r0;r<=r1;++r){Coord shift=p->stagger_axis==axis?panel_layout_shift(true,d->stagger,r):0;
            int64_t k0=grid_ceil_div(lo[axis]-phase-shift,step),k1=grid_floor_div(hi[axis]-phase-shift,step);
            for(int64_t k=k0;k<=k1;++k){if(d->seam_count==4*PF_TILE_MAX){pf_free(d);return fs_capacity_error("I33 CAPACITY: seam line limit is %d",4*PF_TILE_MAX);}
                PfSeamLine *s=&d->seams[d->seam_count++];s->axis=axis;s->k=k;s->band=r;s->staggered=p->stagger_axis==axis;s->coordinate=panel_layout_center(p->origin[axis]+shift,d->size[axis],d->gap,k);
                if(s->staggered){s->range[0]=panel_layout_center(p->origin[other],d->size[other],d->gap,r-1);s->range[1]=panel_layout_center(p->origin[other],d->size[other],d->gap,r);
                    if(!coord_in_range(s->range[0])||!coord_in_range(s->range[1])){pf_free(d);return fs_capacity_error("I52/D1 CAPACITY: returned seam band outside D1");}}
            }
        }
    }
    return true;
}
static void pf_support_free(PfSupport *s)
{free(s->seams);free(s->nonseams);free(s->parts);memset(s,0,sizeof *s);}
static Coord pf_component(SurfacePoint2 p,int axis) {return axis?p.v:p.u;}
static int pf_interval_compare(const void *a,const void *b)
{const PfInterval *x=a,*y=b;return x->lo!=y->lo?(x->lo<y->lo?-1:1):x->hi!=y->hi?(x->hi<y->hi?-1:1):0;}
/* Compare a nonnegative integer width to positive num/den without overflow. */
static bool pf_support_enough(Coord d,GeoQuantity x)
{return d>x.num/x.den||(d==x.num/x.den&&x.num%x.den==0);}
/* A cross section of one actual fragment, including every hole. The sample
 * cannot hit a polygon vertex; sorted crossings therefore alternate material. */
static size_t pf_support_section(const PfFragment *f,int axis,Coord y2,Coord *xs)
{
    size_t n=0;int other=1-axis;
    for(size_t l=0;l<f->count;++l){const PfLoop *loop=&f->loops[l];
        for(size_t v=0;v<loop->count;++v){SurfacePoint2 a=loop->points[v],b=loop->points[(v+1)%loop->count];
            Coord x=pf_component(a,axis),z=pf_component(b,axis),u=pf_component(a,other),q=pf_component(b,other);
            if(x==z&&2*coord_min(u,q)<y2&&y2<2*coord_max(u,q))xs[n++]=x;
        }
    }
    qsort(xs,n,sizeof *xs,sp_coord_compare);return n;
}
static size_t pf_support_union(const PfFootprint *rects,size_t nr,int axis,Coord y2,PfInterval *out)
{
    size_t n=0;int other=1-axis;
    for(size_t i=0;i<nr;++i)if(2*rects[i].lo[other]<y2&&y2<2*rects[i].hi[other])out[n++]=(PfInterval){rects[i].lo[axis],rects[i].hi[axis]};
    qsort(out,n,sizeof *out,pf_interval_compare);size_t used=0;
    for(size_t i=0;i<n;++i){
        if(used&&out[i].lo<=out[used-1].hi)out[used-1].hi=coord_max(out[used-1].hi,out[i].hi);
        else out[used++]=out[i];
    }
    return used;
}
static Coord pf_support_width(const PfInterval *un,size_t n,Coord edge,Coord stop,bool left)
{
    for(size_t i=0;i<n;++i){
        if(left&&un[i].lo<edge&&edge<=un[i].hi)return edge-coord_max(stop,un[i].lo);
        if(!left&&un[i].lo<=edge&&edge<un[i].hi)return coord_min(stop,un[i].hi)-edge;
    }
    return 0;
}
static bool pf_support_append_seam(PfEffectiveSeam *out,size_t *count,size_t line,Coord lo,Coord hi,Coord left,Coord right)
{
    if(*count&&out[*count-1].line==line&&out[*count-1].range[1]==lo){out[*count-1].range[1]=hi;return true;}
    if(*count==PF_SUPPORT_MAX)return fs_capacity_error("I33 CAPACITY: PF-3 effective/non-seam limit is %d",PF_SUPPORT_MAX);
    out[(*count)++]=(PfEffectiveSeam){line,{lo,hi},{left,right}};return true;
}
/* Pure evaluator shared with the algorithm-only P-103 harness. Production
 * callers can supply footprints only through the validated World above. */
static bool pf_support_evaluate(const PfLayout *d,const PfFootprint *rects,size_t nr,GeoQuantity threshold,PfSupport *s)
{
    memset(s,0,sizeof *s);bool ok=false;
    if(nr>WORLD_MAX_TIMBERS)return fs_capacity_error("I33 CAPACITY: PF-3 footprint limit is %d",WORLD_MAX_TIMBERS);
    size_t capacity=d->vertices+2*nr+2;
    Coord *cuts=malloc(capacity*sizeof *cuts),*crossings=malloc((d->vertices+1)*sizeof *crossings);
    PfInterval *un=malloc((nr+1)*sizeof *un);
    s->seams=calloc(PF_SUPPORT_MAX,sizeof *s->seams);s->nonseams=calloc(PF_SUPPORT_MAX,sizeof *s->nonseams);s->parts=calloc(PF_SUPPORT_MAX,sizeof *s->parts);
    if(!cuts||!crossings||!un||!s->seams||!s->nonseams||!s->parts){fs_capacity_error("I33 CAPACITY: PF-3 workspace unavailable");goto done;}
    size_t work=0;
    for(size_t line=0;line<d->seam_count;++line){const PfSeamLine *sl=&d->seams[line];int axis=sl->axis,other=1-axis;size_t nc=0;
        Coord edges[2]={sl->coordinate-d->gap/2,sl->coordinate+(d->gap-d->gap/2)};
        /* Board-fragment vertices are as important as footprint vertices (PF23). */
        for(size_t t=0;t<d->count;++t)for(size_t f=0;f<d->tiles[t].count;++f){const PfFragment *frag=&d->tiles[t].fragments[f];
            for(size_t l=0;l<frag->count;++l)for(size_t v=0;v<frag->loops[l].count;++v)cuts[nc++]=pf_component(frag->loops[l].points[v],other);}
        for(size_t r=0;r<nr;++r){cuts[nc++]=rects[r].lo[other];cuts[nc++]=rects[r].hi[other];}
        if(sl->staggered){cuts[nc++]=sl->range[0];cuts[nc++]=sl->range[1];}
        qsort(cuts,nc,sizeof *cuts,sp_coord_compare);size_t unique=0;
        for(size_t i=0;i<nc;++i)if(!unique||cuts[i]!=cuts[unique-1])cuts[unique++]=cuts[i];
        for(size_t y=1;y<unique;++y){Coord lo=cuts[y-1],hi=cuts[y],y2=lo+hi;
            if(sl->staggered&&(lo<sl->range[0]||hi>sl->range[1]))continue;
            if(++work>PF_SUPPORT_WORK_MAX){fs_capacity_error("I33 CAPACITY: PF-3 open-slab evaluation limit is %d",PF_SUPPORT_WORK_MAX);goto done;}
            bool present[2]={false,false};Coord stop[2]={0,0};
            for(size_t t=0;t<d->count;++t){const PfTile *tile=&d->tiles[t];
                if(y2<=2*tile->body[other]||y2>=2*tile->body[other+2])continue;
                if(tile->body[axis+2]!=edges[0]&&tile->body[axis]!=edges[1])continue;
                for(size_t f=0;f<tile->count;++f){size_t n=pf_support_section(&tile->fragments[f],axis,y2,crossings);
                    for(size_t k=1;k<n;k+=2){Coord a=crossings[k-1],b=crossings[k];
                        if(b==edges[0]&&a<b){present[0]=true;stop[0]=a;}
                        if(a==edges[1]&&a<b){present[1]=true;stop[1]=b;}
                    }
                }
            }
            if(!present[0]||!present[1]){
                if((present[0]||present[1])&&!pf_support_append_seam(s->nonseams,&s->non_count,line,lo,hi,edges[0],edges[1]))goto done;
                continue;
            }
            if(!pf_support_append_seam(s->seams,&s->count,line,lo,hi,edges[0],edges[1]))goto done;
            size_t seam=s->count-1,n=pf_support_union(rects,nr,axis,y2,un);
            Coord left=pf_support_width(un,n,edges[0],stop[0],true),right=pf_support_width(un,n,edges[1],stop[1],false);
            if(s->part_count){PfSupportPart *last=&s->parts[s->part_count-1];
                if(last->seam==seam&&last->range[1]==lo&&last->left==left&&last->right==right){last->range[1]=hi;continue;}}
            if(s->part_count==PF_SUPPORT_MAX){fs_capacity_error("I33 CAPACITY: PF-3 support subsegment limit is %d",PF_SUPPORT_MAX);goto done;}
            s->parts[s->part_count++]=(PfSupportPart){seam,{lo,hi},left,right,pf_support_enough(left,threshold)&&pf_support_enough(right,threshold)};
        }
    }
    ok=true;
done:free(cuts);free(crossings);free(un);if(!ok)pf_support_free(s);return ok;
}

static void frozen_world(const WoodPanelLayoutInput *p,World *w)
{memset(w,0,sizeof *w);w->input=p;w->boundary.outline=p->region.outline;w->boundary.hole_count=p->region.hole_count;
 for(size_t i=0;i<p->region.hole_count;++i)w->boundary.holes[i]=p->region.holes[i];w->finish.frame=p->frame;w->finish.obstacle_count=(uint32_t)p->cut_count;}
static void frozen_transfer(const PfLayout *d,WoodPanelLayout *out)
{*out=(WoodPanelLayout){d->tiles,d->count,d->fragments,d->vertices,d->whole,d->seams,d->seam_count,{d->size[0],d->size[1]},d->gap,d->stagger};}
bool frozen_panel_build(const WoodPanelLayoutInput *input,WoodPanelLayout *out)
{World w;frozen_world(input,&w);PanelFill p={{input->origin[0],input->origin[1]},input->stagger_axis};PfLayout d;
 frozen_error[0]=0;bool ok=pf_build(&w,&p,&d);frozen_transfer(&d,out);return ok;}
bool frozen_panel_clip(const GeoRegionView *region,const GeoRect2 *body,const GeoRect2 *cuts,size_t count,bool keep,size_t *vertices,GeoClipResult *out)
{WoodPanelLayoutInput input={0};input.region=*region;input.cuts=cuts;input.cut_count=count;World w;frozen_world(&input,&w);
 PfLayout d={0};PanelFill p={0};pf_values(&w,&p,&d);d.keep_collinear=keep;d.vertices=*vertices;PfTile t={0};
 t.body[0]=body->min_u;t.body[1]=body->min_v;t.body[2]=body->max_u;t.body[3]=body->max_v;
 frozen_error[0]=0;bool ok=pf_clip(&w,&d,&t);*vertices=d.vertices;*out=(GeoClipResult){t.fragments,t.count,t.area};return ok;}
bool frozen_panel_support(const WoodPanelLayout *layout,const WoodPanelFootprint *rects,size_t count,GeoQuantity x,WoodPanelSupport *out)
{PfLayout d={0};d.tiles=layout->tiles;d.count=layout->count;d.vertices=layout->vertices;d.seams=layout->seams;d.seam_count=layout->seam_count;d.gap=layout->gap;
 frozen_error[0]=0;return pf_support_evaluate(&d,rects,count,x,out);}
