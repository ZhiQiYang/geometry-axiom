from pathlib import Path
import ast,hashlib,importlib.util,json,os,shutil
WORK=Path('/workspace/issue128-empty-panel-rows-work-20261024')
OUT=Path('/workspace/issue128-branch-publication-20261024/source-finish')
BASE='a5f1806fb3cad2dada1a56e79e01d54f9f86700f';BRANCH='codex/issue128-empty-panel-rows-20261024'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
assert not OUT.exists();OUT.mkdir()
rec=c.Recorder(OUT,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),BASE)
def run(*args):
    row,so,se=rec.run(['git',*args],cwd=WORK,timeout=120,check=False,source_variant='resume-exact-already-staged-source-after-Git-add-advisory')
    assert row['actual_process_returncode']==0,row['directory'];return so
def usage():
    n=sum(p.lstat().st_blocks*512 for p in WORK.rglob('*') if p.is_file() and not p.is_symlink());assert n<20*1024*1024;return n
assert run('rev-parse','HEAD').decode().strip()==BASE
assert run('diff','--name-only')==b''
paths=['geometry-templates/woodworking/native/panel_layout.c','tests/geo261_panel_harness.c','tests/test_geo261_panel_native.py','tests/run_all.expected.json']
assert set(run('diff','--cached','--name-only').decode().splitlines())==set(paths)
for rel,expected in [
    (paths[0],Path('/workspace/issue128-p2-draft-20261024/after/panel_layout.c')),
    (paths[1],Path('/workspace/issue128-p2-companion-draft-20261024/candidate/tests/geo261_panel_harness.c')),
    (paths[2],Path('/workspace/issue128-p2-companion-draft-20261024/candidate/tests/test_geo261_panel_native.py'))]:
    assert run('show',':'+rel)==expected.read_bytes()==(WORK/rel).read_bytes()
old=json.loads(run('show',BASE+':'+paths[3]));new=json.loads(run('show',':'+paths[3]))
assert old['suites']['py:test_geo261_panel_native']['count']==10
assert new['suites']['py:test_geo261_panel_native']['count']==13
new['suites']['py:test_geo261_panel_native']['count']=10;assert new==old
methods=[n.name for n in ast.walk(ast.parse((WORK/paths[2]).read_text())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(methods)==13
run('diff','--cached','--check');run('diff','--cached','--',*paths);usage()
run('commit','-m','perf: skip empty panel body rows while retaining seam results')
sha=run('rev-parse','HEAD').decode().strip();assert run('status','--porcelain')==b''
result=dict(branch=BRANCH,base_sha=BASE,source_sha=sha,source_files=paths,published=False,
            expected_change=dict(suite='py:test_geo261_panel_native',before=10,after=13,basis='AST only; formal UNRUN'),
            original_add_exit=1,original_add_directory='/workspace/issue128-branch-publication-20261024/source/subcommands/000011',
            original_add_diagnosis='Git emitted ignored native directory advisory after staging all exact four tracked files; no force add or retry needed. Exact staged bytes independently verified before commit.',
            formal_native='UNRUN',mutations='UNRUN',ledger='UNRUN',architecture='UNRUN',allocated_bytes=usage())
c.dump(OUT/'RESULT.json',result)
try:
    run('push','origin','HEAD:refs/heads/'+BRANCH)
    remote=run('ls-remote','--heads','origin','refs/heads/'+BRANCH)
    assert remote.split()[0].decode()==sha;result['published']=True
finally:
    result['allocated_bytes']=usage();c.dump(OUT/'RESULT.json',result)
print(json.dumps(result,ensure_ascii=False))
