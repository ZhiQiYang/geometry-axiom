from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
from urllib.parse import urlparse

OWNER=Path('/workspace/geo300-contact-index-work')
WORK=Path('/workspace/issue128-empty-panel-rows-work-20261024')
OUT=Path('/workspace/issue128-branch-publication-20261024/checkout')
BASE='a5f1806fb3cad2dada1a56e79e01d54f9f86700f'
BRANCH='codex/issue128-empty-panel-rows-20261024'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
assert not WORK.exists() and not OUT.exists()
assert shutil.disk_usage('/workspace').free>=64*1024*1024
OUT.mkdir(parents=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
rec=c.Recorder(OUT,env,BASE)
def run(argv,cwd):
    row,stdout,stderr=rec.run(argv,cwd=cwd,timeout=120,check=False,source_variant='private-checkout-metadata-not-product-test')
    assert row['actual_process_returncode']==0, row['directory']
    return stdout
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def allocated():return sum(p.lstat().st_blocks*512 for p in WORK.rglob('*') if p.is_file() and not p.is_symlink()) if WORK.exists() else 0
def guard():assert allocated()<20*1024*1024,'Private checkout exceeds original 20 MiB storage budget'
before={name:sha(OWNER/'.git'/name) for name in ('index','config')}
before_head=run(['git','rev-parse','HEAD'],OWNER).decode().strip()
assert before_head==BASE
assert run(['git','status','--porcelain'],OWNER)==b''
obj=(OWNER/'.git/objects').resolve();assert obj.is_dir()
origin=subprocess.check_output(['git','config','--get','remote.origin.url'],cwd=OWNER).decode().strip()
parsed=urlparse(origin);assert not parsed.username and not parsed.password
assert parsed.scheme=='https' and parsed.path.endswith('/ZhiQiYang/geometry-axiom.git')
run(['git','init',str(WORK)],Path('/workspace'))
git=WORK/'.git'
(git/'objects/info/alternates').write_text(str(obj)+'\n')
run(['git','config','gc.auto','0'],WORK)
run(['git','config','maintenance.auto','false'],WORK)
run(['git','remote','add','origin',origin],WORK)
run(['git','config','user.name','Codex'],WORK)
run(['git','config','user.email','codex@openai.com'],WORK)
run(['git','config','core.sparseCheckout','true'],WORK)
run(['git','config','core.sparseCheckoutCone','false'],WORK)
paths=['AGENTS.md','geometry-templates/woodworking/native/panel_layout.c','tests/geo261_panel_harness.c',
       'tests/test_geo261_panel_native.py','tests/run_all.expected.json','tests/run_all.py']
(git/'info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in paths))
run(['git','checkout','-b',BRANCH,BASE],WORK);guard()
assert run(['git','status','--porcelain'],WORK)==b''
assert run(['git','rev-parse','HEAD'],WORK).decode().strip()==BASE
assert before_head==run(['git','rev-parse','HEAD'],OWNER).decode().strip()
assert before=={name:sha(OWNER/'.git'/name) for name in before}
assert run(['git','status','--porcelain'],OWNER)==b''
result=dict(branch=BRANCH,base_sha=BASE,worktree=str(WORK),private_git=True,
            alternates=str(obj),owner_head_index_config_unchanged=True,
            owner_hashes=before,source_patterns=paths,allocated_bytes=allocated(),budget_bytes=20*1024*1024,
            free_after={p:shutil.disk_usage(p).free for p in ('/workspace','/tmp')},compiled=False)
c.dump(OUT/'RESULT.json',result);print(json.dumps(result))
