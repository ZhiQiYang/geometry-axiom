from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import shutil

WORK=Path('/workspace/issue128-empty-panel-rows-work-20261024')
OUT=Path('/workspace/issue128-branch-publication-20261024/source')
BASE='a5f1806fb3cad2dada1a56e79e01d54f9f86700f'
BRANCH='codex/issue128-empty-panel-rows-20261024'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
assert not OUT.exists();OUT.mkdir(parents=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
rec=c.Recorder(OUT,env,BASE)
def run(*args,accepted=(0,)):
    row,so,se=rec.run(['git',*args],cwd=WORK,timeout=120,check=False,source_variant='issue128-source-and-test-only-no-runtime')
    assert row['actual_process_returncode'] in accepted,row['directory']
    return so,row
def guard():
    total=sum(p.lstat().st_blocks*512 for p in WORK.rglob('*') if p.is_file() and not p.is_symlink())
    assert total<20*1024*1024
    assert shutil.disk_usage('/workspace').free>=32*1024*1024
    return total
guard();assert run('status','--porcelain')[0]==b''
assert run('rev-parse','HEAD')[0].decode().strip()==BASE
remote,_=run('ls-remote','--heads','origin','refs/heads/codex/geo300-cut-list-storage-20261024')
assert remote.split()[0].decode()==BASE
peers=[
    (Path('/workspace/issue128-p2-independent-peer-20261024/REVIEW.json'),'14d022acda8083ed89e6ceedd8c54b95f649778e7388b89c0bc2d8852dd548e7'),
    (Path('/workspace/issue128-p2-companion-independent-peer-20261024/REVIEW.json'),'363d1c0f3ae32d2ce2ac4c2c243580340f260ffaf2e713f628621048305a3620')]
for path,pin in peers:assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
patches=[
    (Path('/workspace/issue128-p2-draft-20261024/PRODUCT_ONLY.patch'),'efe1a378aeb6551dbe16eafc124fa44985fa8c4e0244f2e8458dc52aba9726bc'),
    (Path('/workspace/issue128-p2-companion-draft-20261024/COMPANION.patch'),'1ac815720bb2f0db5ac06ec14d3dfe117ad203bb992588f9da012c622543747d')]
for path,pin in patches:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
    run('apply','--check',str(path));run('apply',str(path));guard()
expected=WORK/'tests/run_all.expected.json';before=expected.read_bytes()
old=json.loads(before);assert old['suites']['py:test_geo261_panel_native']['count']==10
text=(WORK/'tests/test_geo261_panel_native.py').read_text();tree=ast.parse(text)
methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(methods)==13
needle=b'"py:test_geo261_panel_native": {\n      "mode": "count",\n      "count": 10,'
assert before.count(needle)==1
after=before.replace(needle,needle.replace(b'"count": 10',b'"count": 13'))
updated=json.loads(after);normalized=json.loads(after);normalized['suites']['py:test_geo261_panel_native']['count']=10
assert normalized==old
expected.write_bytes(after)
paths=['geometry-templates/woodworking/native/panel_layout.c','tests/geo261_panel_harness.c',
       'tests/test_geo261_panel_native.py','tests/run_all.expected.json']
changed,_=run('diff','--name-only')
assert set(changed.decode().splitlines())==set(paths)
run('diff','--check');run('diff','--',*paths)
run('add','--',*paths);guard()
run('commit','-m','perf: skip empty panel body rows while retaining seam results')
sha=run('rev-parse','HEAD')[0].decode().strip()
assert run('status','--porcelain')[0]==b''
result=dict(branch=BRANCH,base_sha=BASE,source_sha=sha,source_files=paths,
            expected_change=dict(suite='py:test_geo261_panel_native',before=10,after=13,basis='AST methods; formal execution UNRUN'),
            static_methods=methods,product_peer_sha256=peers[0][1],companion_peer_sha256=peers[1][1],
            formal_native='UNRUN',mutations='UNRUN',ledger='UNRUN',architecture='UNRUN',
            published=False,allocated_bytes=guard())
c.dump(OUT/'RESULT.json',result)
try:
    run('push','origin','HEAD:refs/heads/'+BRANCH)
    actual,_=run('ls-remote','--heads','origin','refs/heads/'+BRANCH)
    assert actual.split()[0].decode()==sha
    result['published']=True
finally:
    result['allocated_bytes']=guard();c.dump(OUT/'RESULT.json',result)
print(json.dumps(result,ensure_ascii=False))
