# #128 P2 companion：尚未套用或執行

這份外部草稿在原 `geo261_panel_harness.c` 和 `test_geo261_panel_native.py` 上增加三個方法；原方法、十個 mutation anchor、60 秒子程序時限及原 NativeBuild 皆保留。依賴已靜審的單產品 leaf patch `efe1a378…`，沒有改 repository／branch／registry／expected。

新 C shim 只透過**隔離 layout 編譯單元**的巨集導向，原 K `geo_alternating_shift` 本體不改，harness 的 shim 再委派真 K 函式。原始／撤回／恢復各自編譯獨立物件與執行檔。撤回會刪掉整段 phase 預檢並回復原 body `for` 條件；不是只讓 guard 無效後仍把預檢成本算進舊版。成本關係只驗兩個原本同為 seam-capacity 拒絕的輸入，其真 shift 呼叫量與空 row 數無關，不新增 wall-time 上限或數值效能比率。

小對照含零片但六條 raw seams、轉置／負起點、第一奇偶相位空而另一相位有精確單片、負 row 及 frozen 原結果逐欄相同。另三個正常 assertion 控制抓只看第一相位、直接丟 raw seams、把零片誤判非法。大空軸仍須 `WOOD_PANEL_SEAM_LIMIT` 和全部結果釋放；沒有把容量紅換成空結果成功。

目前只有產生器的 Python AST 檢查與原件 hash，沒有 import subject、編譯、runtime、killed 或整合驗收。四個預期反證、stdout 中的 phase 計數與所有具名 assertion 仍須真 C 執行核實。獨立靜審通過後仍不能直接宣稱合併就緒；registry／expected、最終帳本與架構及受影響正式項由主代理排程。
