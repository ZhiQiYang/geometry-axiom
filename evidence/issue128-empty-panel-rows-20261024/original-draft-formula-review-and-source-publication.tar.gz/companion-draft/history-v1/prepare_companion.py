from pathlib import Path
import ast
import difflib
import hashlib
import json

BASE=Path('/workspace/issue128-p2-draft-20261024')
OUT=Path('/workspace/issue128-p2-companion-draft-20261024')
manifest=json.loads((BASE/'DRAFT.json').read_text())
L=manifest['source_sha']
new_c=r'''
/* The shim is linked only by the isolated work-count client. The product
 * layout translation unit alone renames its calls with -D; K stays original. */
static uint64_t empty_axis_phase_calls;
GeoCoord pf_probe_alternating_shift(bool set,GeoCoord delta,int64_t row)
{++empty_axis_phase_calls;return geo_alternating_shift(set,delta,row);}
static int empty_axis_cases(void)
{
    for(int transpose=0;transpose<2;++transpose)for(int shift=0;shift>=-9;shift-=9){
        GeoPoint2 outer[4];
        if(transpose)box(outer,shift+1,shift,shift+2,shift+10);
        else box(outer,shift,shift+1,shift+10,shift+2);
        WoodPanelLayoutInput input={0};input.region=(GeoRegionView){{outer,4},NULL,0};input.frame=identity();
        input.size[0]=input.size[1]=1;input.gap=1;input.origin[0]=input.origin[1]=shift;input.stagger_axis=-1;
        WoodPanelLayout actual,old;GeoClipStatus detail;
        CHECK("empty-axis-legal",wood_panel_layout_build(&input,&actual,&detail)==WOOD_PANEL_OK&&detail==GEO_CLIP_OK);
        CHECK("empty-axis-zero-pieces-with-raw-seams",actual.count==0&&actual.fragments==0&&actual.whole==0&&actual.seam_count==6);
        CHECK("empty-axis-frozen-ok",frozen_panel_build(&input,&old));
        CHECK("empty-axis-exact-frozen-layout",same_layout(&actual,&old));
        wood_panel_layout_free(&actual);wood_panel_layout_free(&old);
    }
    for(int axis=0;axis<2;++axis)for(int negative=0;negative<2;++negative){
        GeoCoord start=negative?-6:0;GeoPoint2 outer[4];
        if(axis==0)box(outer,1,start,2,start+9);else box(outer,start,1,start+9,2);
        WoodPanelLayoutInput input={0};input.region=(GeoRegionView){{outer,4},NULL,0};input.frame=identity();
        input.size[0]=input.size[1]=1;input.gap=2;input.stagger=1;input.stagger_axis=axis;
        WoodPanelLayout actual,old;GeoClipStatus detail;
        CHECK("empty-first-phase-layout-ok",wood_panel_layout_build(&input,&actual,&detail)==WOOD_PANEL_OK&&detail==GEO_CLIP_OK);
        CHECK("empty-first-phase-keeps-other-parity",actual.count==1&&actual.fragments==1&&actual.whole==1);
        const WoodPanelTile *tile=&actual.tiles[0];GeoCoord along=negative?-3:3;
        CHECK("empty-first-phase-exact-body",tile->body[axis]==1&&tile->body[axis+2]==2&&
            tile->body[1-axis]==along&&tile->body[3-axis]==along+1&&
            (axis==0?tile->j:tile->i)==(negative?-1:1));
        CHECK("empty-first-phase-frozen-ok",frozen_panel_build(&input,&old));
        CHECK("empty-first-phase-exact-frozen-layout",same_layout(&actual,&old));
        wood_panel_layout_free(&actual);wood_panel_layout_free(&old);
    }
    return 0;
}
static int empty_axis_work(void)
{
    const GeoCoord lengths[2]={10000,100000000};uint64_t calls[2];
    for(size_t sample=0;sample<2;++sample){
        GeoPoint2 outer[4];box(outer,0,1,lengths[sample],2);
        WoodPanelLayoutInput input={0};input.region=(GeoRegionView){{outer,4},NULL,0};input.frame=identity();
        input.size[0]=input.size[1]=1;input.gap=1;input.stagger_axis=-1;
        WoodPanelLayout actual;GeoClipStatus detail;empty_axis_phase_calls=0;
        WoodPanelStatus status=wood_panel_layout_build(&input,&actual,&detail);calls[sample]=empty_axis_phase_calls;
        printf("empty-axis length=%lld phase-calls=%llu status=%d clip-status=%d\n",
            (long long)lengths[sample],(unsigned long long)calls[sample],(int)status,(int)detail);
        CHECK("empty-axis-preserves-seam-capacity",status==WOOD_PANEL_SEAM_LIMIT&&detail==GEO_CLIP_OK);
        CHECK("empty-axis-capacity-discards-output",!actual.tiles&&!actual.seams&&!actual.count&&!actual.seam_count&&!actual.fragments&&!actual.vertices&&!actual.whole);
        wood_panel_layout_free(&actual);
    }
    CHECK("empty-axis-probe-observed",calls[0]>0&&calls[1]>0);
    CHECK("empty-axis-work-independent-of-empty-row-count",calls[0]==calls[1]);
    return 0;
}
'''
new_py=r'''
    def test_empty_body_axis_keeps_raw_seams_and_other_parity(self):
        self.assertEqual(0,self.case("empty-axis").returncode)

    def empty_axis_instrumented(self,source,name):
        build=native();path=build.woodworking/(name+".c")
        path.write_text(source,encoding="utf-8")
        obj=build.compile(path,name,["geo_alternating_shift=pf_probe_alternating_shift"])
        return build.link(name,self.objects("wood_panel_layout_object",obj))

    def test_empty_axis_work_withdrawal_and_restoration(self):
        source=(native().woodworking/"panel_layout.c").read_text(encoding="utf-8")
        begin="    /* The alternating lattice has at most two row phases."
        end="    for(int64_t r=first;body_axis_intersects&&r<=last;++r)"
        self.assertEqual(1,source.count(begin));self.assertEqual(1,source.count(end))
        # Withdraw the whole optimization, not merely a part of its guard.
        start=source.index(begin);stop=source.index(end,start)
        original=source[:start]+source[stop:].replace("body_axis_intersects&&","",1)
        fixed=self.empty_axis_instrumented(source,"empty-axis-work-fixed")
        self.assertEqual(0,self.case("empty-axis",fixed).returncode)
        self.assertEqual(0,self.case("empty-axis-work",fixed).returncode)
        withdrawn=self.empty_axis_instrumented(original,"empty-axis-work-withdrawn")
        self.assertEqual(0,self.case("empty-axis",withdrawn).returncode)
        result=self.case("empty-axis-work",withdrawn)
        self.assertEqual(1,result.returncode)
        self.assertEqual("ASSERT:empty-axis-work-independent-of-empty-row-count\n",result.stderr)
        # Compile the restored original candidate bytes, independently of the
        # first executable, and recheck semantic output plus operation counts.
        restored=self.empty_axis_instrumented(source,"empty-axis-work-restored")
        self.assertEqual(0,self.case("empty-axis",restored).returncode)
        self.assertEqual(0,self.case("empty-axis-work",restored).returncode)

    def test_empty_axis_semantic_controls_are_normal_assertion_failures(self):
        build=native();source=(build.woodworking/"panel_layout.c").read_text(encoding="utf-8")
        controls=(
            ("one-phase","phase<2","phase<1","empty-first-phase-keeps-other-parity"),
            ("drop-seams","    for(int64_t r=first;body_axis_intersects&&r<=last;++r)",
             "    if(!body_axis_intersects)return WOOD_PANEL_OK;\n    for(int64_t r=first;body_axis_intersects&&r<=last;++r)",
             "empty-axis-zero-pieces-with-raw-seams"),
            ("reject-empty","    for(int64_t r=first;body_axis_intersects&&r<=last;++r)",
             "    if(!body_axis_intersects){wood_panel_layout_free(d);return WOOD_PANEL_ENUM_LIMIT;}\n    for(int64_t r=first;body_axis_intersects&&r<=last;++r)",
             "empty-axis-legal"),
        )
        for name,before,after,marker in controls:
            with self.subTest(control=name):
                self.assertEqual(0,self.case("empty-axis").returncode)
                self.assertEqual(1,source.count(before))
                path=build.woodworking/("empty-axis-"+name+".c")
                path.write_text(source.replace(before,after),encoding="utf-8")
                obj=build.compile(path,"empty-axis-"+name)
                exe=build.link("empty-axis-"+name,self.objects("wood_panel_layout_object",obj))
                result=self.case("empty-axis",exe)
                self.assertEqual(1,result.returncode)
                self.assertEqual("ASSERT:"+marker+"\n",result.stderr)
                self.assertEqual(0,self.case("empty-axis").returncode)
'''
files=[];patch=[]
for rel in ['tests/geo261_panel_harness.c','tests/test_geo261_panel_native.py']:
    before=Path(manifest['source_inputs'][rel]['path']).read_bytes()
    text=before.decode()
    if rel.endswith('.c'):
        assert text.count('#include "panel_support.h"')==1
        text=text.replace('#include "panel_support.h"','#include "panel_support.h"\n#include "grid.h"',1)
        assert text.count('int main(int argc,char **argv)')==1
        text=text.replace('int main(int argc,char **argv)',new_c+'\nint main(int argc,char **argv)',1)
        anchor='if(argc!=2)return 2;'
        assert text.count(anchor)==1
        text=text.replace(anchor,anchor+'if(!strcmp(argv[1],"empty-axis"))return empty_axis_cases();if(!strcmp(argv[1],"empty-axis-work"))return empty_axis_work();',1)
    else:
        anchor='\n\nif __name__ == "__main__":'
        assert text.count(anchor)==1
        text=text.replace(anchor,'\n'+new_py+anchor,1)
        tree=ast.parse(text)
        methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
        oldmethods=[n.name for n in ast.walk(ast.parse(before.decode())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
        assert set(oldmethods).issubset(methods)
        assert len(methods)==len(oldmethods)+3
    after=text.encode();dst=OUT/'candidate'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(after)
    old=OUT/'before'/rel;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(before)
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    files.append(dict(path=rel,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest()))
raw=''.join(patch).encode();(OUT/'COMPANION.patch').write_bytes(raw)
data=dict(source_sha=L,product_patch_sha256=manifest['patch_sha256'],files=files,
          companion_patch_sha256=hashlib.sha256(raw).hexdigest(),new_test_methods=3,
          original_test_methods_preserved=True,controls='one exact optimization withdrawal plus three semantic guard controls',
          compiled=False,subject_imported=False,executed=False,branch_changed=False,
          required='Independent static review; actual baseline/withdraw/restored C receipts; registry/expected and architecture integration remain outstanding.')
(OUT/'MANIFEST.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(data,ensure_ascii=False))
