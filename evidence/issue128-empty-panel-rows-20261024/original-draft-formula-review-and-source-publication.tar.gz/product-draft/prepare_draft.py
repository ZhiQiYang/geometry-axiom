from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import os
import subprocess

ROOT = Path('/workspace/geometry-axiom')
OUT = Path('/workspace/issue128-p2-draft-20261024')
L = '7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAPTURE.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('capture', CAPTURE)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONOPTIMIZE', None)
rec = c.Recorder(OUT / 'capture', env, L)
paths = [
    'geometry-templates/woodworking/native/panel_layout.c',
    'geometry-templates/woodworking/native/panel_layout.h',
    'geometry-core/kernel/grid.c',
    'geometry-core/kernel/grid.h',
    'geometry-core/panel_fill_layout.inc',
    'geometry-templates/woodworking/native/finish.c',
    'geometry-web/panel_layout_bridge.inc',
    'tests/geo261_panel_harness.c',
    'tests/test_geo261_panel_native.py',
    'tests/test_panel_fill_layout.py',
    '公理層.md',
    '決策佇列.md',
    'geometry-templates/woodworking/FIELD-RULES.md',
]
sources = {}
for rel in paths:
    row, stdout, stderr = rec.run(['git', 'show', f'{L}:{rel}'], cwd=ROOT,
                                timeout=30, check=False,
                                source_variant='fixed-L-read-only-source')
    assert row['actual_process_returncode'] == 0
    raw = Path(row['directory']) / 'stdout.bin'
    data = raw.read_bytes()
    sources[rel] = dict(path=str(raw), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))

rel = paths[0]
before = Path(sources[rel]['path']).read_bytes()
needle = b'    for(int64_t r=first;r<=last;++r){GeoCoord shifted=p->origin[along]+geo_alternating_shift(p->stagger_axis>=0,d->stagger,r);\n'
assert before.count(needle) == 1
replacement = b'''    /* The alternating lattice has at most two row phases.  If neither
     * present phase intersects the along-axis bbox, no row has a body.
     * Raw seam lines still follow their original independent enumeration. */
    bool body_axis_intersects=false;
    if(first<=last)for(int phase=0;phase<2;++phase){
        int64_t sample=first;if(phase){if(first==last)break;++sample;}
        GeoCoord shifted=p->origin[along]+geo_alternating_shift(p->stagger_axis>=0,d->stagger,sample);
        int64_t a=geo_floor_div(lo[along]-shifted-d->size[along],pitch[along])+1,z=geo_ceil_div(hi[along]-shifted,pitch[along])-1;
        if(a<=z){body_axis_intersects=true;break;}
    }
    for(int64_t r=first;body_axis_intersects&&r<=last;++r){GeoCoord shifted=p->origin[along]+geo_alternating_shift(p->stagger_axis>=0,d->stagger,r);
'''
after = before.replace(needle, replacement)
(OUT / 'before').mkdir(exist_ok=True)
(OUT / 'after').mkdir(exist_ok=True)
(OUT / 'before/panel_layout.c').write_bytes(before)
(OUT / 'after/panel_layout.c').write_bytes(after)
patch = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                   fromfile='a/' + rel, tofile='b/' + rel))
(OUT / 'PRODUCT_ONLY.patch').write_text(patch, encoding='utf-8')
scratch = OUT / 'apply-check'
(scratch / Path(rel).parent).mkdir(parents=True, exist_ok=True)
(scratch / rel).write_bytes(before)
row, _, _ = rec.run(['git', 'apply', '--check', str(OUT / 'PRODUCT_ONLY.patch')], cwd=scratch,
                    timeout=30, check=False, source_variant='external-draft-apply-check-only')
assert row['actual_process_returncode'] == 0
issue_path = Path('/tmp/geo324-owner-20261024/open-issues-triage-r2/batch-04/issue-128.json')
issue = json.loads(issue_path.read_text())
comment = next(x for x in issue['comments'] if x['url'].endswith('6172907846'))
(OUT / 'R10-original-comment.md').write_text(comment['body'], encoding='utf-8')
manifest = dict(source_sha=L, product_source=rel, source_inputs=sources,
                issue_original_json=dict(path=str(issue_path), sha256=hashlib.sha256(issue_path.read_bytes()).hexdigest()),
                original_comment_url=comment['url'],
                patch_sha256=hashlib.sha256((OUT / 'PRODUCT_ONLY.patch').read_bytes()).hexdigest(),
                before_sha256=hashlib.sha256(before).hexdigest(), after_sha256=hashlib.sha256(after).hexdigest(),
                changed_repository=False, compiled=False, formal_execution=False,
                patch_apply_check_exit=row['actual_process_returncode'],
                limitation='External product-only draft. Companion tests and original formal/mutation receipts still required.')
c.dump(OUT / 'DRAFT.json', manifest)
print(json.dumps(dict(source_sha=L, patch_sha256=manifest['patch_sha256'], apply_check_exit=0,
                     compiled=False, formal_execution=False)))
