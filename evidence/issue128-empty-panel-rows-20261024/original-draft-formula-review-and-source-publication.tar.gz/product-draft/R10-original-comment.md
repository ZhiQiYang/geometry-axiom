【ChatGPT 研究】R10 完成：PF-2 合併後深度審查——原生厚度診斷反例、共同公式核對與後續測試清單

研究固定於 main `79412a858f712981fa0ba15a6b293c3e0bf06f21`，開工與發布前一致；研究看板 blob `389055199153d4eb88d8e1dee5cdaf8143eca2f1`。已讀 AGENTS、願景（不作擴權依據）、適用 SSOT、#225 正文／審查、P-105、後續 #234、PF-2 原生文件、核心／bridge／測試與定向突變工具。本文只讀研究，不修改公理、產品、測試或任何 PR 狀態。

**結論：一項可由現行原始碼直接推出的原生診斷錯誤、一組確定過時的 API 說明，以及五項分開列出的風險。本輪沒有找到新的、已實跑確認的板片座標或裁切錯誤。** 下列「確定」指完整程式路徑或文字對照已成立，不代表本輪執行了 C 核心。實際執行只有 repository 外的自製算術／JavaScript JSON 解碼見證，Node v22.16.0、Linux，父程序實際退出碼 0；沒有跑產品、HTTP、Chrome、WSL 或產品突變。

## 一、確定的錯誤

### E1｜中：合法整數厚度因字串緩衝區不一致，被誤報成 INVALID／I52

來源：[geometry-core/engineering.inc:119–147](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/engineering.inc#L119-L147)、[geometry-core/engineering_json.inc:285–291](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/engineering_json.inc#L285-L291)、[geometry-core/panel_fill_layout.inc:48–67](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_fill_layout.inc#L48-L67)、[geometry-web/panel_fill_bridge.inc:70–88](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/panel_fill_bridge.inc#L70-L88)。規格：[公理層.md:1217–1223](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/公理層.md#L1217-L1223)，容量／精度與非法輸入的分界見 [公理層.md:1093–1117](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/公理層.md#L1093-L1117)。

最小輸入沿用 `tests/test_panel_fill_layout.py` 的 seed：width=100、length=100、普通 250×250 完成面、無障礙、合法 dimension 門檻。只把材料 thickness 換成下列十進位字串：

- 對照：`"9." + "0"×61`，63 bytes，精確為 9 mm。
- 反例：`"9." + "0"×62`，64 bytes，也精確為 9 mm。

材料發布使用 `thickness[128]`，第二個字串符合其正十進位語法且可完整保存，沒有超出該材料讀取緩衝區；canonical JSON 也不會替字串刪掉尾端零。PF-2 的 `pf_values` 卻再以 `thickness[64]` 讀同一份已發布材料。`eng_json_string` 遇 `strlen >= capacity` 直接回 false，接著 PF-2 統一回 `I52: ... positive integer mm ... no rounding`；`fs_error` 將分類设為 INVALID，預覽因此報 `PANEL_FILL_INVALID`。

**錯誤不在精確十進位尾零本身，而在把較小緩衝区的限制當成幾何非法。** I52 要求十進位值為正整數 mm，這兩個值相同。即使實作者保留某個明示資源限制，依 I33 也不能把合法值的資源不足說成 INVALID。

最小修正方向（非 SSOT 改寫）：讓 PF 厚度求值接受 D26 已能完整保存的合法表示，或從已驗證的 JSON token 精確求值；真容量失敗須保留具型別的容量診斷。不可為了通過，偷偷改寫已發布材料字串／指紋或把非整數厚度取整。T1 附具名正反對照。本輪未實跑這份 native fixture。

### E2｜低：兩處 transport／診斷說明仍停在舊切片

1. [geometry-web/panel_layout_bridge.inc:16](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/panel_layout_bridge.inc#L16) 的 `pending` 仍回 `PF-5 timber layer and derived placement`。但 [geometry-core/panel-fill/PF2-NATIVE.md:89–96](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel-fill/PF2-NATIVE.md#L89-L96) 及 [P-098](https://github.com/ZhiQiYang/geometry-axiom/pull/226#issuecomment-6149027134) 已將最小衍生宿主前移到 PF-H。這會給 API 使用者錯的前置歸屬；不是說目前應已具有完整宿主。
2. [geometry-core/finish_surfaces.inc:233–252](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/finish_surfaces.inc#L233-L252) 已分派 `put-panel-fill`／`delete-panel-fill`，末尾拒絕未知 operation 的說明卻仍稱只接受 put/delete-finish-surface。

只需對齊能力範圍的說明；不藉此新增 operation、UI 或放寬來源／交易驗證。

## 二、可能的風險

### P1｜面積精確整數與 JavaScript 解碼精度沒有接合

[geometry-web/panel_layout_bridge.inc:7–9](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/panel_layout_bridge.inc#L7-L9) 用十進位 JSON number 輸出 `area`；原生面積累加在 [geometry-core/panel_fill_layout.inc:92–98](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_fill_layout.inc#L92-L98)。一般前端解碼是 [geometry-web/app.js:648–670](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/app.js#L648-L670) 的 `r.json()`。

幾何候選：F=[0,99999999]²，同樣尺寸的一片板，t=1、gap=0、起點 0、無障礙，全部座標與單邊尺寸都在 D1；只需一片，不以「板片很多」排除此例。精確面積為 `9999999800000001` mm²，仍可放入 int64。自製 Node 見證實際得到：

```js
const exact = 99999999n * 99999999n;
const value = JSON.parse('{"area":' + exact + '}').area;
String(exact);          // "9999999800000001"
String(BigInt(value));  // "9999999800000000"
```

**已確認的是這種 wire 格式經普通 JavaScript JSON 解碼損失 1 mm²；尚未確認正式 PF UI 的影響。** 上面 wire 是依原 serializer 格式構造，不是本輪 C bridge 抓包；目前 PF-2 明示沒有正式顯示／完整專案 UI。本項因此列為接入風險，不宣稱 C 面積算法算錯。T2 應在真正 C→HTTP→JS 路徑核對精確值，再決定無損整數欄位／解碼契約；不能只驗 `Number.isInteger`，因為失真的結果仍是整數。

### P2｜零板片時，外層列舉工作未被 1024 個本體候選上限限制

[geometry-core/panel_fill_layout.inc:129–163](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_fill_layout.inc#L129-L163)：`enumerated` 只在內層真的列出板本體時增加。這是公開的本體候選上限，不是外層 row 的工作上限。

反例取 Pu=Pv=1、g=1、a=(0,0)、直排、F=[0,100000000]×[1,2]，無障礙。整個 F 的 v 範圍恰在板縫內，沒有正面積板本體。代入現行公式：

- row=u：first=0、last=49,999,999，共 **50,000,000** 輪。
- 每輪 along=v：a=1、z=0，內層不執行，`enumerated` 一直為 0。
- 後面的 seamLines 才會遇到 4096 上限並回 CAPACITY；前面的空迴圈已發生。

這是可直接重算的工作量反例，不是已量到五千萬次迴圈耗時，也不能據此宣稱已找出 #209 的 15 秒根因。T3 先量 row 次數、候選數、CPU／wall time；可研究提早判定空軸及 seam 容量，但不得刪掉合法的零片定義或把 raw seamLines 與有效板縫混為一談。

### P3｜原生確認不能直接套上現有一般前端 API 流程就算完整接入

[geometry-web/app.js:615–703](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/app.js#L615-L703) 的變更守門、requestId 配發、definition-changed 通知名單有 engineering／assembly／section-profile-confirm，沒有 panel-fill-confirm。另一方面 [geometry-web/serve.py:167–203](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/serve.py#L167-L203) 在沒有 requestId 時直接送 bridge，不建立這次操作的結果回執。

**推測／條件式風險：**未來 PF UI 若直接用目前 `apiRequest('panel-fill-confirm ...')`，可能在結果遺失時沒有相同的回執恢復路徑，也缺乏對其他工作區的變更通知。原生 token、revision 與全量重驗仍有保護；本項不等於 native 可以任意重複提交。現在沒有正式 PF UI，因此不把它升格為已發生的畫面事故，也不要求本片提前做 UI。T7 在正式接入時驗收到、遺失、延遲、跨專案與重送拒絕。

### P4｜派生序列化再次求值失敗時，外層成功旗標與內層 error 的契約需補強

[geometry-web/panel_layout_bridge.inc:4–6](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/panel_layout_bridge.inc#L4-L6) 在 `pf_build` 失敗時只輸出 `derived:{error:...}`；[geometry-web/panel_fill_bridge.inc:70–99](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/panel_fill_bridge.inc#L70-L99) 的 read 外層仍是 ok:true，preview.valid 也來自先前的候選驗證。

**推測：**先前重驗成功、之後序列化重算才發生 malloc/realloc 失敗時，使用者可能拿到 valid:true 卻沒有完整 after 幾何的預覽。這裡保留 inner error，因此不是「完全隱藏錯誤」；尚未讀到完整接收端如何處理這種回覆，也沒有注入 allocator 失敗。T8 用精確一次性注入確認：不能把不完整預覽當成完整候選展示並直接確認；不得用舊 cache 假裝本次成功。

### P5｜突變工具有「assertion 失敗與測試 error 並存」仍可接受的驗核縫隙

[tests/evidence/pf2-b1-bands-20261014/run_panel_mutants.py.txt:31–45](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/tests/evidence/pf2-b1-bands-20261014/run_panel_mutants.py.txt#L31-L45) 只要求變異版 `result.failures` 非空；沒有同時要求 errors/skipped 為 0，也未在程式內釘住指定斷言的識別文字。若一個帶 subTest 的方法同時出現預期失敗與非預期 error，現行總閘仍可能接受該輪。

這是對未來證據生成器的風險，不推翻既有原件：[panel-mutants.stdout:1–12](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/tests/evidence/pf2-b1-bands-20261014/panel-mutants.stdout#L1-L12) 十個變異目前全部 errors=0，baseline/restored 各17項通過。另，工具在同一 Python 行程內跑 unittest，`test_exit` 是由 `wasSuccessful()` 換算的結果碼，**不是每個 test 的 OS 子程序退出碼**；compile_exit 才是編譯子程序 returncode。不得把兩種計數混稱。T8 可用合成「指定 failure＋額外 error」驗證工具會拒收，不改歷史收據。

## 三、建議補的測試（可直接交辦；均保留現有斷言／時限）

新增位置以 [tests/test_panel_fill_layout.py:34–55](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/tests/test_panel_fill_layout.py#L34-L55) 的 seed／preview／read 管線為主；HTTP、JSON 消費與回執測試接入對應現有測試，不新造第二個產品實作。

| 項目 | 精確輸入與應有結果 | 撤修／負控制要求 |
|---|---|---|
| T1 厚度表示邊界（先做） | 各自 fresh seed，thickness=`9.`後61／62／125個零（63／64／127 bytes），都仍為精確9mm；讀回 thickness=9，來源字串與材料指紋不被暗改。另保留9.5、12.5、未設厚度的拒絕。新增具名斷言 `PF2_THICKNESS_VALUE_9`。 | 舊64-byte二次讀取應讓64／127-byte案例因I52而紅；修後綠，再撤修紅。不能以改掉預期或裁短已發布材料通過。真容量限制若另行保留，須明示且驗UNSUPPORTED/CAPACITY，不准INVALID冒充。 |
| T2 精確大面積 | E1之外另建 F=[0,99999999]²、同尺寸一片板、t1、g0。核心輪廓／whole計數／十進位面積應為1片及9999999800000001；真HTTP到JS後仍能核回同一精確整數。 | 改回一般 Number 面積解碼後，精確值斷言必紅；不能用已被捨入的 Number 當預期值，也不能只驗isInteger。 |
| T3 零片＋工作量 | 小對照F=[100,103]×[0,250]、P100/g3為純縫區，tile/fragment/whole/cut均0；另一對照以面材層障礙完整遮F亦為0，保存／重開／移除障礙後重算均合法。再用P2極端輸入量row工作。 | 強迫零片非法、憑bbox回傳假板、截斷輸出，各須被抓到。極端案本來會超seam容量，允許及早正確CAPACITY；成本驗收用row次數／操作量，不能只靠提高timeout。raw seamLines仍可能非空。 |
| T4 一毫米裁切條 | F=[0,201]×[0,100]、P100×100、g0、origin0：3片、2整片、1裁切片；末片outer恰為[(200,0),(201,0),(201,100),(200,100)]，area100。 | 丟棄小於X／8mm／模板下限的條、把其補成整板或併到前一片，均須紅。不新增SSOT沒有定義的窄條警告門檻。 |
| T5 軸與来源語意 | width200/length100：lengthAlong=u時本體寬u100/v200，換v則u200/v100；正方形仍須明選軸。交丁兩軸、正負δ與負奇數band保留。X=17/2 dimension可合法保存，不改板片；有效count/ratio欄位不能當X；gap或δ的非整數參數則拒絕。 | 把length偷偷改成max(width,length)、把X送入整數幾何求值器、略過dimension檢查、δ改為累加或暗取整，各有獨立具名紅。現有scalar負例不是有效ratio/count對照。 |
| T6 已有試排的整包交易 | 已有D42時，同一panel候選修改finish＋fill，取消不變、確認一步Undo/Redo還原；有效預覽後改被用到的gap參數，再確認舊token必STALE且World／revision不變；同候選先解除試排再刪完成面合法，單刪被引用完成面拒絕。 | 移除revision／來源核對或改成逐項提交，各必紅。既有PF-1已有真正STALE測試，不把此補強說成系統完全沒測STALE。 |
| T7 正式UI／HTTP接入門檻 | 在未來PF UI接入時，查panel確認的editable守門、requestId、結果回執及變更事件；延遲／掉回覆、切專案、另一份預覽取代與cancel均保留同候選，不重送不確定的變更。 | 拿掉其中一項接線時對應測例紅；仍用既有回執機制，不另造平行提交層。本項不提前擴大PF-2為UI交付。 |
| T8 失敗誠實性 | 一次性讓「驗證成功後、after序列化」的分配失敗，核對具型別失敗／不完整標示與不可冒充完整預覽；另在突變工具合成指定assertion failure加額外error或skip，工具應拒收。 | 拿掉失敗檢查後各自紅；allocator恢復後正常原fixture綠。區分framework結果、編譯子程序與最外層OS退出碼；原始歷史證據不倒填。 |

## 四、逐條對照與已確認保留的實作

| SSOT | 本片現況與界線 |
|---|---|
| D41／I52首段 | FinishSurface 保留D3引用、frame、s與明選障礙，不以畫布或附近物件猜入。`finish_surfaces.inc:126–160` 做各軸投影、結構側及引用驗證；本輪未找到這些路徑的新幾何反例。 |
| D42 | `panel_fill_layout.inc:28–46` 嚴格欄位、明選lengthAlong、直接起點與單一gap／stagger來源；直排不能帶stagger，交丁僅一個錯開軸。不是D10b雙軸stagger，所以R9的雙軸cell語意疑點不能直接算成本片缺陷。 |
| D43／R42 | `panel_fill_layout.inc:129–172` 用signed列舉與中心到中心band；舊上下半縫漏列的B1修正仍在。`seamLines`是線身分，不是兩側都有板的有效縫；空片不等於raw縫線必空。 |
| D44 | `pf_values` 以 `parameter_value` 讀X，不是裸常數8，也不把X取整；型別檢查實際在 `parameters.inc:65–74`，不是漏掉dimension守門。測試仍可補正分數X及合法ratio/count反例。 |
| D45 | 建議角材不屬本片；目前null／pending及complete:false不能冒充已建議／已建立。E2僅更正前置說明。 |
| I52 | 材料width/length及t、gap、δ與被回傳座標均有守門；E1是合法厚度表示被讀取緩衝區誤分類。容量不足未以部分板片通過。 |
| I53／R41 | `pf_values:64–65` 以投影正面積及q0<t、q1>0判面材層；垂直面沿n，不只比世界z。角材層與板背宿主明列後續，沒有把面材層布林偷當兩層都完成。 |
| I54／R43 | 本片尚未求有效縫與承接，不能宣稱已通過紅色承接／逐段寬度；但也不能要求PF-2自行用一般placement假裝PF-H。門檻存在與合法性是本片已做的前置。 |
| I55 | `fs_rebuild:163–173` 呼叫全試排重建；共享batch候選與confirm再次重驗，參數預覽會帶before/after試排。沒有將取消或失敗寫入World。T6/T7分別補原生組合與未來前端接入。 |
| I56 | `pf_dump`只寫canonical D42定義；scene要求PF／工程／參數三能力。PF11已解碼hex驗白名單、比對精確來源、fresh load及derived/dump全等，不再只有assertNotIn那個弱檢查。完整專案瀏覽器流程仍非本片能力聲明。 |
| I57 | 真正共用 `panel_layout_math.h:4–10`；有限網格委派pitch/center，D29委派pitch/phase/最低位元shift。有限終止條件與PF的signed範圍各自保留，屬列舉差異，不是第二套公式。 |

實作連結：[finish_surfaces.inc:126–173](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/finish_surfaces.inc#L126-L173)、[parameters.inc:65–84](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/parameters.inc#L65-L84)、[panel_fill_layout.inc:174–198](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_fill_layout.inc#L174-L198)、[engineering_bridge.inc:88–145](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-web/engineering_bridge.inc#L88-L145)。

共同公式逐點核對：[panel_layout_math.h:4–10](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_layout_math.h#L4-L10)、[current_geometry.c:1446–1481](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/current_geometry.c#L1446-L1481)、[grid_lattice.inc:15–18](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/grid_lattice.inc#L15-L18)、[grid_lattice.inc:75–76](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/grid_lattice.inc#L75-L76)。本輪未找到PF-2另維護近似縫中心或另一套交丁奇偶的證據；這不是對全repository所有未讀路徑的形式證明。

裁切的BFS只沿正長度共邊連通，保留完整外環／孔／分片並排序，見 [panel_fill_layout.inc:68–127](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/geometry-core/panel_fill_layout.inc#L68-L127)。既有PF04確有孔、切開、材料點接觸與相接孔環的斷言；仍可增加複合退化案例，不將小樣本覆蓋宣稱為完整拓撲證明。

## 五、測試、突變與整合證據的時間界線

現行 [tests/test_panel_fill_layout.py:58–237](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/tests/test_panel_fill_layout.py#L58-L237) 的17個方法確實測了數值與形狀，不是只有「沒報錯」：g3中心101/204並直接比真有限網格及D29、負索引交丁、逐整數cell覆蓋、outer/holes/分片、取消與歷史、原生保存重開、材料／參數依賴及容量。上下半縫的兩個方法共有20個subcases，仍核對k/band/coordinate/range。

歷史定向工具的十種破壞為：移除PF接線、破壞floor中心、改為累加、忽略孔、接觸改閉區間、figure-eight轉向、略過正門檻、下半縫撤修、上半縫撤修、dump偷存cache。工具與原stdout顯示十種都有assertion failure且errors=0，baseline/restored各17綠；下／上半縫分別6／4個subcase失敗。**本輪只核對工具邏輯與可讀摘要，未解壓逐份原始stderr、未獨立重跑，所以不新增產品mutant killed聲明；它們也没有證明E1已被覆蓋。**

另排除一個表面疑點：`apply_panel_fill_line` 內先讀t[3]再查count，但 [current_geometry.c:12340–12352](https://github.com/ZhiQiYang/geometry-axiom/blob/79412a858f712981fa0ba15a6b293c3e0bf06f21/current_geometry.c#L12340-L12352) 的正式命令表已指定恰4欄。因此本輪不把該局部寫法直接宣稱成可達越界缺陷；未另做fuzz或sanitizer證明。

**P-105需要按時間讀，不能永久當成「從來沒有瀏覽器驗收」。** [P-105](https://github.com/ZhiQiYang/geometry-axiom/pull/231#issuecomment-6153965699) 的確接受#217與PF-2合流後只重跑native，原七項收據與新native並列。後來已合併的 [#234](https://github.com/ZhiQiYang/geometry-axiom/pull/234) 則報告base=`0eb447e00605f6df117711b03e6c98ccabbcd026`、受測train=`1bcee875150714e083d011f53a6c716c0b96e814` 的完整七項：native2775/0/1、canvas2207/0、full/completed/golden matched，其他五項亦列在正文。

本輪額外讀取該受測train的兩個檔案，其Git blob與固定main相同：`geometry-core/panel_fill_layout.inc`=`f1f5c4042c390872f2274cf1b6981ffb26f6be13`，`tests/test_panel_fill_layout.py`=`1f6219b50dd3fc2d170b897411cf3e76cc43284b`。這只核到兩個檔案的同源，不是全部產品／binary／runner的同源證明。#234原始完整原件仍指本機路徑，本輪沒有取得或重驗；正文仍保留canvas uncaughtBrowserExceptions=1及最外層launcher退出unknown，不能改寫成「全部exception零」或全部OS層已驗。

現行main最後一筆是#236的測試診斷合併，提交訊息說native＋grid，不能把#234較早的完整七項直接標成當下79412a8的完整七項。同時，原先「完全未補任何後續browser」的說法已不符合目前可讀時間線。本研究不撤销P-105既定政策，也不自行增加重跑整套七項的合併門檻。

## 六、可交辦的順序與完成界線

先由Codex用T1實跑E1，保留首紅／修後綠／撤修紅；同一個根因修正對齊D26與PF厚度求值，不更改材料定義或SSOT。E2作小型說明修正，不混入功能擴充。P1/P2先按T2/T3取得真實wire及成本資料；P3留在正式PF UI接入的收件要求；P4/P5按T8補失敗誠實性。T4–T6是本片原生邊界補強，不減既有17個方法、20個band子案例或原斷言，也不提高原時限來掩蓋問題。

**最大不確定性：P1在正式消費端的實際影響、P2在目標WSL負載下的實際耗時，以及P4記憶體失敗時完整接收端的處理。** 各項已有不依賴猜測的最小驗證輸入。E1的native路徑雖可由源码推出，仍需首輪真C／bridge回覆確認；本輪自製見證不能代替它。

R10在「適用條文核對、共同公式、原生／transport發現、已有測試及突變界線、具體補測清單」範圍完成。未改repo、SSOT、🔒、閱讀器、看板、測試或ledger；未開PR／合併／關閉，未啟動產品／HTTP／Chrome／WSL，也未聲稱有人已認領或排程。完成進度另留#232；下一項R11須先查train/20261014-13的PR是否存在，本輪尚未進行R11。