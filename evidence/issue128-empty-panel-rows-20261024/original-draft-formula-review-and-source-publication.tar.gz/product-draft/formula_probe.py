"""Pure Python arithmetic witness; not C, HTTP, or formal acceptance."""
import itertools
import json


def ceildiv(a, b):
    return -((-a) // b)


def phase_candidates(size, gap, origin, axis, delta, bounds):
    row = 1 if axis == 0 else 0
    along = 1 - row
    pitch = [v + gap for v in size]
    lo, hi = bounds[:2], bounds[2:]
    first = (lo[row] - origin[row] - size[row]) // pitch[row] + 1
    last = ceildiv(hi[row] - origin[row], pitch[row]) - 1
    phases = range(first, min(last, first + 1) + 1)
    possible = False
    for r in phases:
        shifted = origin[along] + (delta if axis >= 0 and r % 2 else 0)
        a = (lo[along] - shifted - size[along]) // pitch[along] + 1
        z = ceildiv(hi[along] - shifted, pitch[along]) - 1
        possible |= a <= z
    original = []
    for r in range(first, last + 1):
        shifted = origin[along] + (delta if axis >= 0 and r % 2 else 0)
        a = (lo[along] - shifted - size[along]) // pitch[along] + 1
        z = ceildiv(hi[along] - shifted, pitch[along]) - 1
        for k in range(a, z + 1):
            original.append((r, k))
    draft = original if possible else []
    return row, along, first, last, possible, original, draft


intervals = [(-4, -3), (-2, 2), (0, 1), (1, 2), (2, 3)]
cases = empty = empty_first_only = 0
for size, gap, origin, axis, delta, bx, by in itertools.product(
        [(1, 1), (2, 3)], [0, 1, 3], [(0, 0), (-3, 2)],
        [-1, 0, 1], [-2, 1], intervals, intervals):
    if axis < 0 and delta != 1:
        continue  # straight has one effective zero shift
    if axis >= 0 and delta % (size[axis] + gap) == 0:
        continue  # I52 rejects coincident alternating phases
    effective_delta = 0 if axis < 0 else delta
    bounds = (bx[0], by[0], bx[1], by[1])
    row, along, first, last, possible, original, draft = phase_candidates(
        size, gap, origin, axis, effective_delta, bounds)
    # Independent geometric membership: scan a fixed enclosing index box,
    # without using first/last/a/z or the draft phase predicate.
    independent = []
    for r in range(-16, 17):
        start_row = origin[row] + r * (size[row] + gap)
        if not (start_row < bounds[row + 2] and start_row + size[row] > bounds[row]):
            continue
        for k in range(-16, 17):
            start_along = origin[along] + k * (size[along] + gap)
            if axis >= 0 and abs(r) % 2:
                start_along += effective_delta
            if start_along < bounds[along + 2] and start_along + size[along] > bounds[along]:
                independent.append((r, k))
    assert original == independent, (size, gap, origin, axis, effective_delta, bounds)
    assert draft == independent, (size, gap, origin, axis, effective_delta, bounds)
    assert bool(independent) == possible
    cases += 1
    empty += not independent
    empty_first_only += bool(independent) and not any(r == first for r, _ in independent)

extreme = []
for length in [10000, 100000000]:
    # Closed form only: deliberately do not run 50 million Python iterations.
    first = (0 - 0 - 1) // 2 + 1
    last = ceildiv(length, 2) - 1
    a = (1 - 0 - 1) // 2 + 1
    z = ceildiv(2, 2) - 1
    assert (a, z) == (1, 0)
    seam_u = (length - 1) // 2 - ceildiv(-1, 2) + 1
    assert seam_u > 4 * 1024
    extreme.append(dict(length=length, original_row_iterations=last-first+1,
                        original_body_candidates=0, draft_body_row_iterations=0,
                        draft_phase_checks=2, unmodified_u_seam_lines_before_capacity=seam_u,
                        original_seam_capacity=4*1024,
                        expected_native_status='WOOD_PANEL_SEAM_LIMIT',
                        status_is_formula_expectation_not_actual_C=True))
print(json.dumps(dict(kind='pure-Python arithmetic witness only',
                     exhaustive_small_cases=cases, empty_cases=empty,
                     populated_cases_with_first_row_empty=empty_first_only,
                     all_candidate_sequences_identical=True, extreme_closed_form=extreme,
                     no_compilation=True, no_formal_execution=True), indent=2))
