from pathlib import Path
import ast,hashlib,json,difflib,datetime
BASE=Path('/workspace/issue128-p2-companion-draft-20261024')
OUT=Path(__file__).resolve().parent
checklist=[]
def h(x):return hashlib.sha256(x).hexdigest()
def check(name,passed):checklist.append({'name':name,'passed':bool(passed)})
m=json.loads((BASE/'MANIFEST.json').read_bytes());parts=[]
for row in m['files']:
    rel=row['path'];before=(BASE/'before'/rel).read_bytes();after=(BASE/'candidate'/rel).read_bytes()
    check('before:'+rel,h(before)==row['before_sha256']);check('after:'+rel,h(after)==row['after_sha256'])
    parts.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
patch=(BASE/'COMPANION.patch').read_bytes()
check('exact-patch',''.join(parts).encode()==patch)
check('v2-pin',h(patch)=='1ac815720bb2f0db5ac06ec14d3dfe117ad203bb992588f9da012c622543747d')
py=(BASE/'candidate/tests/test_geo261_panel_native.py').read_text();old=(BASE/'before/tests/test_geo261_panel_native.py').read_text()
a=ast.parse(py);b=ast.parse(old)
def methods(tree):return {c.name+'.'+f.name:ast.dump(f,include_attributes=False) for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef)}
ma,mb=methods(a),methods(b)
for name,body in mb.items():check('old-method-preserved:'+name,ma.get(name)==body)
check('exactly-three-new-tests',len([k for k in ma if k not in mb and '.test_' in k])==3)
c=(BASE/'candidate/tests/geo261_panel_harness.c').read_text();oc=(BASE/'before/tests/geo261_panel_harness.c').read_text()
check('old-C-prefix-preserved',c.replace('#include "grid.h"\n','',1).startswith(oc[:oc.index('\nint main(')]))
check('one-layout-only-define','["geo_alternating_shift=pf_probe_alternating_shift"]' in py)
check('shim-delegates-original-K','return geo_alternating_shift(set,delta,row);' in c)
check('unmodified-original-timeout','timeout=60' in py and py.count('timeout=')==old.count('timeout='))
check('normal-process-exit-contract','self.assertIn(result.returncode, (0, 1)' in py)
check('whole-withdrawal','original=source[:start]+source[stop:].replace("body_axis_intersects&&","",1)' in py)
check('independent-restoration-build','self.empty_axis_instrumented(source,"empty-axis-work-restored")' in py)
check('zero-pieces-do-not-delete-seams','actual.seam_count==6' in c and 'same_layout(&actual,&old)' in c)
check('negative-first-empty-other-phase','GeoCoord start=negative?-6:0;' in c and '(negative?-1:1)' in c)
check('big-work-never-frozen-50m','frozen_panel' not in c[c.index('static int empty_axis_work('):])
check('large-case-status-and-cleanup','status==WOOD_PANEL_SEAM_LIMIT&&detail==GEO_CLIP_OK' in c and '!actual.tiles&&!actual.seams&&!actual.count&&!actual.seam_count' in c)
check('no-arbitrary-work-threshold','calls[0]==calls[1]' in c and 'calls[0]>0&&calls[1]>0' in c)
check('three-normal-semantic-controls',all(x in py for x in ['"one-phase"','"drop-seams"','"reject-empty"']))
for phase in ('fixed','withdrawn','restored'):
    check('raw-cost-phase-labelled:'+phase,('phase='+phase) in py)
check('raw-cost-preserved-to-output','print(result.stdout,end="")' in py)
check('honest-unrun',not m['compiled'] and not m['executed'] and not m['subject_imported'] and not m['branch_changed'])
notes=[
 '獨立靜讀核對 geometry接口、frozen_panel_build/same_layout、objects替換、uint64 counter、loop邊界；無新增UB或錯誤首ASSERT。',
 'original layout-odd mutation anchor仍只命中r版本一處；新增預檢用sample，沒有破壞原十控制。',
 'v1 shim linked-only註解與成本stdout未轉送兩項意見已修；v1/history原件保留。',
 '大撤回仍需真C在原60秒時限內完成，不能把timeout或crash算kill；純靜審不能保證運行成本。',
 '新成本hook只導向一個layout translation unit；harness的shim委派原K。正常harness可link此函數但不呼叫，沒有全局K替換。',
]
bad=[x for x in checklist if not x['passed']]
report={'source_sha':m['source_sha'],'patch_sha256':h(patch),'scope':'Independent static companion review only; no C, subject import/execution, source or branch change',
 'checks_total':len(checklist),'failed_checks':len(bad),'checks':checklist,'notes':notes,'findings':bad,
 'verdict':'Static draft accepted; runtime and mutation outcomes remain UNRUN' if not bad else 'Findings require correction',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checklist),'failed':len(bad),'sha256':h((OUT/'REVIEW.json').read_bytes())}))
raise SystemExit(bool(bad))
