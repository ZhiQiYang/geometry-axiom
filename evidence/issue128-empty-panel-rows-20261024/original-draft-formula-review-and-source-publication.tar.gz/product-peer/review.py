from pathlib import Path
import ast,difflib,hashlib,json,subprocess,datetime
BASE=Path('/workspace/issue128-p2-draft-20261024')
OUT=Path(__file__).resolve().parent
REPO=Path('/workspace/geometry-axiom')
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
checks=[]
def h(data):return hashlib.sha256(data).hexdigest()
def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
draft=json.loads((BASE/'DRAFT.json').read_bytes())
index=json.loads((BASE/'INDEX.json').read_bytes())
check('fixed-source',draft['source_sha']==L)
check('input-index-pinned',h((BASE/'INDEX.json').read_bytes())=='2b488fefaa3dd960fdc4fe242e87a68374e58deed4f8ba392def0588fc816bff')
for item in index['files']:
    data=(BASE/item['path']).read_bytes()
    check('index-bytes:'+item['path'],len(data)==item['bytes'])
    check('index-sha:'+item['path'],h(data)==item['sha256'])
git_rows=[]
for path,item in draft['source_inputs'].items():
    run=subprocess.run(['git','--no-optional-locks','show',L+':'+path],cwd=REPO,capture_output=True)
    source=Path(item['path']).read_bytes()
    check('original-Git-exit:'+path,run.returncode==0)
    check('original-Git-bytes:'+path,run.stdout==source)
    check('original-size-sha:'+path,len(source)==item['bytes'] and h(source)==item['sha256'])
    git_rows.append({'argv':['git','--no-optional-locks','show',L+':'+path],'cwd':str(REPO),'exit':run.returncode,
        'stdout_bytes':len(run.stdout),'stdout_sha256':h(run.stdout),'stdout_equal_retained_file':item['path'],
        'stderr':run.stderr.decode(errors='replace')})
before=(BASE/'before/panel_layout.c').read_bytes();after=(BASE/'after/panel_layout.c').read_bytes()
patch=(BASE/'PRODUCT_ONLY.patch').read_bytes();plan=(BASE/'TEST_PLAN.md').read_text()
check('patch-pin',h(patch)=='efe1a378aeb6551dbe16eafc124fa44985fa8c4e0244f2e8458dc52aba9726bc')
check('before-pin',h(before)==draft['before_sha256'])
check('after-pin',h(after)==draft['after_sha256'])
generated=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
    fromfile='a/geometry-templates/woodworking/native/panel_layout.c',tofile='b/geometry-templates/woodworking/native/panel_layout.c')).encode()
check('one-file-diff-exact',patch==generated)
old=b'    for(int64_t r=first;r<=last;++r){GeoCoord shifted='
new=b'    for(int64_t r=first;body_axis_intersects&&r<=last;++r){GeoCoord shifted='
check('old-body-loop-unique',before.count(old)==1)
check('new-body-loop-unique',after.count(new)==1)
prefix=before[:before.index(old)]
suffix=before[before.index(old)+len(old):]
check('all-before-loop-original',after.startswith(prefix))
check('all-original-body-and-seams-exact',after[after.index(new)+len(new):]==suffix)
added=after[len(prefix):after.index(new)].decode()
check('present-row-guard','if(first<=last)' in added and 'if(first==last)break;++sample;' in added)
check('two-adjacent-phases','phase<2' in added and 'int64_t sample=first;' in added)
check('original-shared-formula','geo_alternating_shift(p->stagger_axis>=0,d->stagger,sample)' in added)
check('exact-positive-body-bounds','if(a<=z){body_axis_intersects=true;break;}' in added)
check('no-new-allocation-or-return',not any(token in added for token in ['malloc','calloc','free(','return ']))
check('no-policy-files-changed',patch.count(b'--- a/')==1)
formula=(BASE/'formula_probe.py').read_text();ast.parse(formula)
check('formula-independent-window','range(-16, 17)' in formula and 'assert original == independent' in formula and 'assert draft == independent' in formula)
result=json.loads((BASE/'formula-execution/RESULT.json').read_bytes());row=result['command']
check('formula-original-exit',result['actual_exit']==0 and row['actual_process_returncode']==0 and not row['timeout_expired'])
raw=Path(row['directory'])/'stdout.bin';err=Path(row['directory'])/'stderr.bin'
check('formula-original-stdout',h(raw.read_bytes())==row['stdout_sha256'] and len(raw.read_bytes())==row['stdout_bytes'])
check('formula-original-stderr',h(err.read_bytes())==row['stderr_sha256'] and len(err.read_bytes())==row['stderr_bytes'])
witness=json.loads(raw.read_bytes())
check('formula-results-1150-488-19',tuple(witness[k] for k in ['exhaustive_small_cases','empty_cases','populated_cases_with_first_row_empty'])==(1150,488,19))
check('formula-not-native',witness['no_compilation'] and witness['no_formal_execution'] and all(x['status_is_formula_expectation_not_actual_C'] for x in witness['extreme_closed_form']))
check('unrun-limitations-explicit',all(s in plan for s in ['沒有任何 C 紅／綠收據','不能單獨合入','staggered raw seam','timeout','原 suite 子程序時限維持 60 秒']))
check('safe-oracle-differential-retained','frozen judge differential' in plan and '18 方法' in plan)
check('nonconstant-first-phase-witness','一相位空、另一相位有板' in plan and '負 row' in plan and '再轉置驗 u stagger' in plan)
check('new-work-limit-not-time-waiver','不訂 wall-time 新門檻' in plan and '工作次數相等' in plan)
manual=[
 {'claim':'兩phase suffices','reason':'geo_alternating_shift 的唯一 row 依賴是 row&1。每個有效 r 的沿軸候選區間與 first 或 first+1 完全相同；first+1 僅在 first<last 時評估。'},
 {'claim':'空軸略過保持 geometry/error 次序','reason':'只有每個 present phase 都 a>z 才略過。原來這種情況不進 k body，無 enum 增量、clip、geometry error；原 prefix allocation 與完整 seam suffix 逐位元組不變。'},
 {'claim':'合法參數下未引入整數越界','reason':'first==last 先 break，新增 ++sample 僅 first<last；其他座標及除法都是原 loop 會評估的 first 或 first+1 同一式子，保留原 shared helper 前置條件。'},
 {'claim':'小場景 raw seam 六條','reason':'size1 gap1 的中心為 1+2k；u=[0,10] 五條，v=[1,2] 一條。這是原 raw seam 不等於有效板縫的契約，不可把零板片改成提前OK空回覆。'},
 {'claim':'奇偶負row與轉置反例安全','reason':'size1 gap2 delta1，v=[1,2] 只有奇數 row 平移後有正面積板。原C row&1 和 Python r%2 對負整數奇偶一致。'},
 {'claim':'計數 shim 規劃可區分空loop','reason':'只在 W panel_layout 單元改名K呼叫，shim委派真K；straight seam不呼叫shift。固定2phase與撤回5000/50000000應是正常測量後ASSERT差異；仍需真C實跑，不以timeout/crash算kill。'},
 {'claim':'不擴張政策','reason':'已讀 L I52/R42/I57 與 10/12-15、22-24 決策。補丁只避免確定無候選的 body 工作，不增容量、刪合法零片或變更裁切/接縫。'},
]
findings=[c for c in checks if not c['passed']]
report={'source_sha':L,'reviewed_patch_sha256':h(patch),'reviewed_test_plan_sha256':h((BASE/'TEST_PLAN.md').read_bytes()),
    'review_scope':'Independent static and retained-original review only. No C, subject execution, formula rerun, product edit or branch write.',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'checks_total':len(checks),'failed_checks':len(findings),
    'manual_semantic_review':manual,'findings':findings,'git_read_verifications':git_rows,
    'remaining':['Companion C tests and shim have not been implemented or run.','No runtime red/green, wall time, native, HTTP or browser proof.','Staggered seam empty outer-loop risk is explicitly out of scope.'],
    'verdict':'Static draft accepted; not ready-to-merge or runtime acceptance' if not findings else 'Static findings require correction'}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':len(findings),'review':str(OUT/'REVIEW.json'),'sha256':h((OUT/'REVIEW.json').read_bytes())}))
raise SystemExit(bool(findings))
