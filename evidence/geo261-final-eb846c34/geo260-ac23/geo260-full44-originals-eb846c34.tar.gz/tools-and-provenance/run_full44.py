from pathlib import Path
import ast,hashlib,importlib.util,json,os,resource,subprocess,sys,time
R=Path('/tmp/geo260-ac23-source-5b0ce47d');S='eb846c345881cc6fc73a53c457a291175365b88c';O=Path('/workspace/geo260-ac23-full44-eb846c34');assert not O.exists();O.mkdir();tmp=O/'tmp';tmp.mkdir();cache=O/'private-native';cache.mkdir()
resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
env=dict(os.environ)
for k in list(env):
 if k.startswith('GEOMETRY_') or k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','LD_PRELOAD'):env.pop(k,None)
env.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(R),GEOMETRY_MODEL_BASE=str(cache/'model-base'))
sp=importlib.util.spec_from_file_location('cap','/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py');cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);rec=cap.Recorder(O,env,S)
def run(args,**kw):return rec.run(args,cwd=R,timeout=None,**kw)
cap.dump(O/'REQUEST.json',{'source':S,'root':str(R),'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stackBytes':16*1024*1024,'lock':'original root-assigned slot2; caller flock EX|NB secondary.lock; heavy.lock untouched','freeBytesBefore':{p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ('/tmp','/workspace')},'compilerLimitSeconds':600,'childLimitSeconds':900,'modelAdapterLimitSeconds':900,'outerTimeout':None,'scope':'Original complete44 native+model, no --only/no --explore, jobs1. No repeated per-build C source retention; original compile JSON logs and binary/source tree hashes retained.','captureSHA256':hashlib.sha256(Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py').read_bytes()).hexdigest(),'workerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>120*1024*1024
_,b,_=run(['git','rev-parse','HEAD']);assert b.decode().strip()==S
_,b,_=run(['git','status','--porcelain']);assert not b
_,tree,_=run(['git','ls-tree','-rlz',S,'--','current_geometry.c','geometry-core','geometry-web','geometry-app','geometry-templates','tests','公理層.md'])
paths=[];rows=[];sizes={};dirs=('geometry-core/geometry_kernel/','geometry-app/geometry_app/','geometry-templates/woodworking/geometry_woodworking/','tests/fixtures/')
for item in tree.split(b'\0'):
 if not item:continue
 header,rawpath=item.split(b'\t',1);h=header.split();p=rawpath.decode();suffix=Path(p).suffix
 c=(suffix in ('.c','.h','.inc') and 'vendor' not in Path(p).parts and (p=='current_geometry.c' or p.startswith(('geometry-core/','geometry-web/','geometry-app/','geometry-templates/'))))
 py=(suffix=='.py' and ((p.startswith('tests/') and p.count('/')==1) or (p.startswith('geometry-core/') and p.count('/')==1) or p.startswith('geometry-core/modeling/') and p.count('/')==2 or p.startswith('geometry-web/') and p.count('/')==1))
 if c or py or p.startswith(dirs) or p=='公理層.md':
  assert h[1]==b'blob';paths.append(p);rows.append({'path':p,'blob':h[2].decode(),'bytes':int(h[3])});sizes[p]=int(h[3])
run(['git','sparse-checkout','add','--stdin'],data=''.join('/'+p+'\n' for p in paths).encode())
for row in rows:
 b=(R/row['path']).read_bytes();assert len(b)==row['bytes'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blob'];row['sha256']=hashlib.sha256(b).hexdigest()
cap.dump(O/'INPUTS_BEFORE.json',rows)
_,b,_=run(['git','status','--porcelain']);assert not b
_,b,_=run([sys.executable,'-B','tests/section_profile_mutation_check.py','--list']);listed=[l for l in b.decode().splitlines() if l.startswith('SPM')];assert len(listed)==44;print('Full44 source bound; groups:',{g:sum(l.split()[1]==g for l in listed) for g in ('native','model')},flush=True)
setup='from pathlib import Path; import sys; from tests import binaries; binaries.OUT_DIR=Path(sys.argv[1]); raise SystemExit(binaries.main(["build","model-base"]))'
build,_,_=run([sys.executable,'-B','-c',setup,str(cache)],check=False)
report={'source':S,'setupExit':build['actual_process_returncode'],'original44Exit':None,'errors':[],'privateNativeCache':str(cache),'startedUTC':json.loads((O/'REQUEST.json').read_text())['startedUTC']}
if build['actual_process_returncode']==0:
 print('Private original model-base build complete; launching all44 original gate',flush=True)
 row,_,_=run([sys.executable,'-B','tests/section_profile_mutation_check.py','--jobs','1','--receipt',str(O/'gate-receipt.json'),'--logs',str(O/'gate-logs')],check=False);report['original44Exit']=row['actual_process_returncode']
else:report['errors'].append('Original private model-base setup failed; no44 command started.')
_,b,_=run(['git','rev-parse','HEAD']);report['headAfter']=b.decode().strip();_,b,_=run(['git','status','--porcelain']);report['porcelainAfter']=b.decode();report['allInputBytesEqualAfter']=all(hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in rows)
report['sourceAfterClean']=report['headAfter']==S and not report['porcelainAfter'] and report['allInputBytesEqualAfter'];report['endedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());report['commands']=len(rec.rows);report['slot2ReleasedOnProcessExit']=True
if (O/'gate-receipt.json').is_file():
 gate=json.loads((O/'gate-receipt.json').read_text());report['originalSummary']=gate['summary'];report['originalResultCount']=len(gate['results']);report['baselines']={k:v['exit'] for k,v in gate['baselines'].items()}
report['driverExit']=0 if report['setupExit']==0 and report['original44Exit']==0 and report['sourceAfterClean'] else 1
cap.dump(O/'RESULT.json',report);print(json.dumps(report,ensure_ascii=False),flush=True);raise SystemExit(report['driverExit'])
