from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
B=Path('/tmp/geo260-ac23-publication');O=Path('/workspace/geo260-ac23-full44-eb846c34');P=B/'full44-publication';P.mkdir(exist_ok=False);S='eb846c345881cc6fc73a53c457a291175365b88c';result=json.loads((O/'RESULT.json').read_text());outer=json.loads((B/'full44-launch/RESULT.json').read_text());assert result['source']==outer['source']==S and result['sourceAfterClean']
assert result['driverExit']==outer['actualProcessExit'];sha=lambda b:hashlib.sha256(b).hexdigest();files=[];excluded=[]
roots={'original-full44':O,'original-launch':B/'full44-launch','forward-merge':B/'forward-merge-aa0e3938','forward-merge-continuation':B/'forward-merge-aa0e3938-continuation'}
for label,root in roots.items():
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise RuntimeError('Unexpected symlink: '+str(p))
  if not p.is_file():continue
  body=p.read_bytes();row={'member':label+'/'+p.relative_to(root).as_posix(),'original':str(p),'bytes':len(body),'sha256':sha(body)}
  if body[:4]==b'\x7fELF':excluded.append(dict(row,reason='Original private model-base ELF remains at original cloud path; archive excludes rebuildable ELF only.'))
  else:files.append((row,body))
for p in [Path(__file__),B/'run_full44.py',B/'merge_next_baton.py',B/'merge_next_baton_continue.py',B/'MERGE_PREFLIGHT_ENVIRONMENT_FAILURE.json',Path('/tmp/train337-adversarial/GEO260_EB846_MERGE_EXPECTED_STATIC_PEER.json')]:
 body=p.read_bytes();files.append(({'member':'tools-and-provenance/'+p.name,'original':str(p),'bytes':len(body),'sha256':sha(body)},body))
for rel in ['tests/section_profile_mutation_check.py','tests/section_profile_mutation_runner.py','tests/test_section_profile_native.py','tests/run_all.expected.json']:
 body=subprocess.check_output(['git','-C','/tmp/geo260-ac23-source-5b0ce47d','show',S+':'+rel]);files.append(({'member':'immutable-source/'+rel,'original':'git:'+S+':'+rel,'bytes':len(body),'sha256':sha(body)},body))
assert len(files)==len({r['member'] for r,b in files})
a=P/'geo260-full44-originals-eb846c34.tar.gz'
with a.open('xb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for row,body in files:
    info=tarfile.TarInfo(row['member']);info.size=len(body);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(body))
with tarfile.open(a,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member,(row,body) in zip(members,files):assert member.name==row['member'] and member.isfile() and tar.extractfile(member).read()==body
report={'source':S,'originalGateExit':result['original44Exit'],'driverExit':result['driverExit'],'archive':a.name,'archiveBytes':a.stat().st_size,'archiveSHA256':sha(a.read_bytes()),'members':len(files),'included':[r for r,b in files],'excludedELFOriginalsRetained':excluded,'originalsDeleted':False,'producerRoundtrip':True,'limits':['Original tool cleaned temporary C and native/mutant ELF; no claim that original compiler inputs or all transient ELF remain. Retain original text compile logs, hashes and explicit initial/final fixed Git source bindings.','Original compiler capture_output text and full exposed c387 pipes are preserved. Internal unexposed raw compiler pipes not invented.','Full44 is39native+5model and nativebaseline29 excludes the original source-index method, not aggregate30 or fullproject.','Optional environment observer google-chrome PATH FileNotFound is preserved separately from absolute Chromeversion0; no native/model environment changed.']};(P/'RAW_INVENTORY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('included','excludedELFOriginalsRetained','limits')},ensure_ascii=False,indent=2));print('PRODUCER_ROUNDTRIP_OK')
