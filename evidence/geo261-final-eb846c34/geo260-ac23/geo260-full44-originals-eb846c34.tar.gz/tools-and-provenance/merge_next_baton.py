from pathlib import Path
import ast,hashlib,importlib.util,json,os,re
B=Path('/tmp/geo260-ac23-publication');R=Path('/tmp/geo260-ac23-source-5b0ce47d');incoming='aa0e3938f17dc996ef5e7410db4844b31856d2a6';out=B/'forward-merge-aa0e3938';out.mkdir()
sp=importlib.util.spec_from_file_location('cap','/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py');cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);rec=cap.Recorder(out,os.environ.copy(),'af4fd36c17d05b5da2411b70266ed040e22a6561')
def run(a,**kw):return rec.run(a,cwd=R,timeout=None,**kw)
_,p,_=run(['git','rev-parse','HEAD']);before=p.decode().strip();_,b,_=run(['git','status','--porcelain']);assert not b
run(['git','fetch','--no-tags','origin','refs/heads/codex/geo300-prerequisites-20261024'])
run(['git','cat-file','-e',incoming+'^{commit}']);run(['git','merge','--no-ff','-m','Merge preceding prerequisite fixes before AC23 proof',incoming])
_,b,_=run(['git','rev-parse','HEAD']);merge=b.decode().strip();p=R/'tests/run_all.expected.json';original=p.read_bytes();old=json.loads(original);key='py:test_section_profile_native';assert old['suites'][key]['count']==28
new,count=re.subn(rb'("py:test_section_profile_native"\s*:\s*\{[^}]*?"count"\s*:\s*)28\b',lambda m:m.group(1)+b'30',original);assert count==1
expected=json.loads(original);expected['suites'][key]['count']=30;assert json.loads(new)==expected
assert old['suites']['py:test_rectangular_template']['count']==13 and old['suites']['py:test_geometry_host_sources']['count']==45 and old['suites']['py:test_geo261_wood_contact_world']['count']==10
unit=ast.parse((R/'tests/test_section_profile_native.py').read_bytes());methods=[n.name for n in ast.walk(unit) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(methods)==len(set(methods))==30
p.write_bytes(new);run(['git','diff','--check']);run(['git','add','--sparse','--','tests/run_all.expected.json']);run(['git','commit','-m','Register both dedicated AC23 native cases'])
_,b,_=run(['git','rev-parse','HEAD']);source=b.decode().strip();run(['git','push','origin','HEAD:refs/heads/codex/geo260-ac23-proof-20261024']);_,b,_=run(['git','ls-remote','origin','refs/heads/codex/geo260-ac23-proof-20261024']);assert b.decode().split()[0]==source
_,b,_=run(['git','status','--porcelain']);assert not b
result={'source':source,'sourceBefore':before,'incoming':incoming,'ordinaryMerge':merge,'parentTestExecutionStill':'af4fd36c17d05b5da2411b70266ed040e22a6561','expectedChangedOnly':{key:[28,30]},'preservedExpected':{'rectangular_template':13,'geometry_host_sources':45,'geo261_wood_contact_world':10},'methods':30,'public':True,'pushExit':0,'remote':source,'clean':True,'full44':'not started yet; will run at this source'};(B/'FORWARD_SOURCE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
