# P 帳本封存與待審閱出版指令

來源 P：`b6646d10751a0d85a2f03f5d24fbe1073cb78980`。本封存只驗證已完成收據與檔案，不執行測試或編譯；L、A、F 仍待後續工作，不能當成最終正式通過。

原三次 mutation 指令的退出為 `1/0/0`；第一個 `1` 是 75 stale/3 retired 的原始檢查。78 筆中 core57＋bridge18 共 75 execution 綁定 P，另有退休 M35/M51/M55。分類與 crashed 原始證據保留，不把 crashed 改寫成 killed。

`stage/` 保存整份 stage（排除清單見 EXCLUDED.json）；`launch/` 保存 stdout、stderr、subreaper；`independent-audit/` 保存獨立稽核與 launch streams；`tools/` 保存來源工具原碼為 .txt。每個已複製原檔的原路徑/bytes/hash 在 INCLUDED.json；SHA256SUMS 亦涵蓋排除清單本身。排除 tmp 不展開、ELF 不計完整 hash，沒有假稱已驗未讀 binary。

root 審閱 COLLECTION.json 與 publish-progress.command.json 後，才自行執行 PUBLISH_COMMAND.sh.txt 中的指令。publisher 會把原 stage receipt 複製到 `evidence/geo261-final-b6646d10/receipts/preseal-full-ledger.json`，並產生 raw archive/inventory，英文 evidence commit 與一般 push。此封存器沒有呼叫 publisher。

證據出版完成後，root 另行安裝 `stage/after/tests/mutants_results.json` 到整合分支的同名檔，重新核對 git scope，只以英文訊息單獨提交帳本並一般 push，該 artifact commit 才是 L。建議訊息：`test: regenerate GEO-261 mutation ledger at product P`。此工具不 copy 產品帳本、不 staging、不 commit、不 push，不處理 merge。

下一階段：於 L 執行 Linux 架構 refresh，架構 artifact 為 A；於 A 執行完整 census，之後固定正式來源 F 跑所有要求。證據提交為 E，避免將 P/L/A/F/E 混成同一種 SHA。
