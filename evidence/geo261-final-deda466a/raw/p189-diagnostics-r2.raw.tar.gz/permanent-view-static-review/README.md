# 永久 contact-view 回歸：純靜態獨立覆核

此報告沒有編譯或執行測試；root 的 Loader 已確認9方法，實際baseline／突變紅／restored綠仍待root串行執行。`static-review.json`保存原551b00f6完整SHA、兩測試檔hash與純AST／字串核對結果。

## 數量與原有裁判保留

- unittest：9方法＝舊7＋新2。原 boundary2、full codec、真 dependency、canonical isolation、failure、舊五負控方法全部保留。
- 負控制：12＝舊5＋新7；完整成功執行時輸出36筆JSON record＝每控制 baseline／mutant／restored各1。原五control tuple逐值未變；舊七方法AST去除新增logging kwargs後逐項與原版相同。
- C case：5＝原 codec／graph／canonical／failure＋contact-view。原harness在新增case以前的完整bytes相同；原CHECK、full decoder值檢查與錯誤判準未放寬。
- 新contact-view完整格式案例每次跑3277個prefix truncation＝180＋692＋692＋1713，另含三段各512／UINT32_MAX、trailing、schema/id/kind/null-content、內嵌NUL／高byte及error-out不變。

## 七控制的具體因果

各mutation只在NativeBuild的隔離W副本編譯；原production bytes必須不變。每個anchor目前在真W來源恰好出現一次。三欄的正例canonical bytes由已註冊production provider正常回傳後覆寫、成為同一K graph的cached值；host=UINT32_MAX、direction=99、order=UINT64_MAX，明確不同於authored document。full API未變，是獨立的原裁判。

| 控制 | 首個必紅條件與具名ASSERT |
|---|---|
| contact-host-offset | 原full host=UINT32_MAX；narrow的u32＋1回繞為0；兩API仍成功，只有field錯，首個field斷言 `contact-view-placement-id-value` 紅。 |
| contact-direction-offset | full direction=99；narrow=100，host先通過，`contact-view-direction-value` 紅；沒有signed overflow。 |
| contact-order-offset | full order=UINT64_MAX；narrow unsigned＋1回繞0，前兩欄先通過，`contact-view-order-value` 紅。 |
| contact-trailing | 第一個family是完整180-byte frame＋實際1 byte trailing；兩邊r.ok及id都有效，full拒絕、拿掉exact-size的narrow接受。`contact-view-trailing-rejected` 紅，並檢查error out不變，無其他格式缺陷可代替此判準。 |
| contact-text0-bound | 最大合法frame三段511，各段完整。只把第0段擴成實際512 bytes，搬移並保留後續order/metadata/兩段完整字串，wire size相應＋1。原full只因n>=512拒絕；缺該guard的narrow完整走到exact-size並接受，`contact-view-text0-capacity` 紅。 |
| contact-text1-bound | 只在between迴圈i==0拿掉capacity guard，第0段仍照原驗。第0段512反例先照常拒絕；輪到第1段的完整512-byte反例才被mutant接受，`contact-view-text1-capacity` 紅。 |
| contact-text2-bound | 同理只在i==1拿掉guard，前兩段反例均由原guard擋住；第2段實際512 bytes且其後正好結尾，mutant接受，`contact-view-text2-capacity` 紅。 |

後三控制刻意**插入第512byte並搬完整尾段**。若只把511的長度prefix改512卻不補payload，其他bounds／錯位／trailing也可能拒絕，無法證明capacity guard有牙齒；現有案例避開這種假負控。三段字串即使has_between=false仍全讀，正例長度0與511及embeddedNUL全部保留。

所有新負控要求原退出恰1、stderr恰為對應單行 `ASSERT:<marker>:<line>`、stdout空。crash／啟動失敗不在(0,1)會被原case斷言拒絕；timeout原樣raise，不算killed。baseline／restored仍要求0，未因新增輸出記錄改任何測試病因或數值期望。

## 原始執行輸出記錄

Python `case(...control=...,phase=...)`在檢查原退出碼**以前**列印可機讀JSON：

```json
{"schema":"geometry-definition-control-execution/1","control":"contact-order-offset","phase":"mutant","command":["<actual isolated executable>","contact-view"],"exitCode":1,"timedOut":false,"stdout":"","stderr":"ASSERT:contact-view-order-value:<actual line>\n"}
```

這只是schema範例，不是已跑結果。真正執行時command/path、returncode及stdout/stderr直接來自該次subprocess結果；baseline/restored也各自記。若timeout，exitCode為null、timedOut=true，保存捕獲的stdout/stderr後重拋原TimeoutExpired，沒有捏造process退出碼。編譯／link仍走原NativeBuild；沒有新平台限定compiler hack或產品source替身。
