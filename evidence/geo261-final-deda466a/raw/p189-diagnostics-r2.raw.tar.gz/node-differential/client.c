/* Public-API differential client. Compile this exact file with either source.c.
 * The oracle uses complete bytes and linear insertion order, never a hash. */
#include "source.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

#define REQUIRE(label,expression) do {if(!(expression)){ \
    fprintf(stderr,"ASSERT:%s line=%d expr=%s\n",label,__LINE__,#expression);return 1;}} while(0)
enum { MAX_NODES=2048, MAX_EDGES=8192, MAX_KEY=129 };
typedef struct {
    GeoProviderToken provider;size_t size;unsigned char key[MAX_KEY];
    GeoSourceState state;GeoSourceStatus status;int described;
    unsigned descriptions,evaluations;
} ExpectedNode;
static ExpectedNode nodes[MAX_NODES];
static GeoSourceEdge edges[MAX_EDGES];
static size_t node_count,edge_count,normal_count,operation;
static int callback_error;
static const unsigned char special_key[]={0xda,0x00,0xff,0x71,0x29};

static size_t linear_node(GeoSourceRef source)
{
    for(size_t i=0;i<node_count;++i)if(nodes[i].provider==source.provider&&nodes[i].size==source.key_size&&
        (!source.key_size||!memcmp(nodes[i].key,source.key,source.key_size)))return i;
    return SIZE_MAX;
}
static GeoSourceRef expected_ref(size_t i)
{return (GeoSourceRef){nodes[i].provider,nodes[i].key,nodes[i].size};}
static size_t touch(GeoSourceRef source)
{
    size_t i=linear_node(source);if(i!=SIZE_MAX)return i;
    if(node_count==MAX_NODES||source.key_size>MAX_KEY)return SIZE_MAX;
    i=node_count++;memset(&nodes[i],0,sizeof nodes[i]);nodes[i].provider=source.provider;nodes[i].size=source.key_size;
    if(source.key_size)memcpy(nodes[i].key,source.key,source.key_size);
    nodes[i].state=GEO_NODE_NEW;nodes[i].status=GEO_SOURCE_OK;return i;
}
static int expected_edge(size_t consumer,size_t source,GeoDependencyKind kind)
{
    for(size_t i=0;i<edge_count;++i)if(edges[i].consumer==consumer&&edges[i].source==source&&edges[i].kind==kind)return 0;
    if(edge_count==MAX_EDGES)return 1;
    edges[edge_count++]=(GeoSourceEdge){consumer,source,kind};return 0;
}
static int64_t quantity(GeoSourceRef source)
{
    uint64_t value=(uint64_t)source.provider+UINT64_C(1009)*source.key_size;
    const unsigned char *p=source.key;
    for(size_t i=0;i<source.key_size;++i)value=value*UINT64_C(131)+p[i];
    return (int64_t)(value&UINT64_C(1073741823));
}
static int value_equal(GeoSourceRef source,const GeoSourceValue *value)
{return value->kind==GEO_SOURCE_QUANTITY&&value->as.quantity.num==quantity(source)&&value->as.quantity.den==1&&value->as.quantity.unit==GEO_UNIT_SCALAR;}
static bool describe(void *user,const GeoSourceRef *ref,GeoSourceDescriptor *out)
{
    (void)user;size_t i=linear_node(*ref);if(i==SIZE_MAX){callback_error=1;return false;}++nodes[i].descriptions;
    if(ref->provider==59)return false;
    *out=(GeoSourceDescriptor){.kind=GEO_SOURCE_QUANTITY,.unit=GEO_UNIT_SCALAR,.context={false,0,-1}};
    if(ref->provider==71)out->context.axis=9;
    return true;
}
static bool evaluate(void *user,GeoEvalContext *ctx,const GeoSourceRef *ref,GeoSourceValue *out)
{
    (void)user;size_t self=linear_node(*ref);if(self==SIZE_MAX){callback_error=1;return false;}++nodes[self].evaluations;
    if(ref->provider==41){
        for(size_t i=0;i<normal_count;++i){GeoSourceRef source=expected_ref(i);
            for(int kind=0;kind<3;++kind){
                if(expected_edge(self,i,(GeoDependencyKind)kind)){callback_error=1;return false;}
                for(int repeat=0;repeat<2;++repeat)if(geo_eval_depend(ctx,source,(GeoDependencyKind)kind)!=GEO_SOURCE_OK){callback_error=1;return false;}
            }
            GeoSourceValue value;
            if(geo_eval_source(ctx,source,GEO_DEPENDENCY_VALUE_REQUIRED,&value)!=GEO_SOURCE_OK||!value_equal(source,&value)){callback_error=1;return false;}
        }
    }else if(ref->provider==53)return false;
    else if(ref->provider==61){
        GeoSourceValue value,before;memset(&value,0x5a,sizeof value);memcpy(&before,&value,sizeof before);
        if(expected_edge(self,self,GEO_DEPENDENCY_VALUE_REQUIRED)){callback_error=1;return false;}
        GeoSourceStatus status=geo_eval_source(ctx,*ref,GEO_DEPENDENCY_VALUE_REQUIRED,&value);
        int unchanged=!memcmp(&value,&before,sizeof value);
        printf("callback-cycle status=%d unchanged=%d\n",(int)status,unchanged);
        if(status!=GEO_SOURCE_CYCLE||!unchanged)callback_error=1;
        return false;
    }
    *out=(GeoSourceValue){.kind=GEO_SOURCE_QUANTITY,.as.quantity={quantity(*ref),1,GEO_UNIT_SCALAR}};
    if(ref->provider==67)out->as.quantity.den=0;
    return true;
}
static const GeoSourceProvider providers[]={
    {17,"diff.first","word-hash-diff/1",NULL,describe,evaluate},
    {29,"diff.second","word-hash-diff/1",NULL,describe,evaluate},
    {41,"diff.consumer","word-hash-diff/1",NULL,describe,evaluate},
    {53,"diff.failed","word-hash-diff/1",NULL,describe,evaluate},
    {59,"diff.missing","word-hash-diff/1",NULL,describe,evaluate},
    {61,"diff.cycle","word-hash-diff/1",NULL,describe,evaluate},
    {67,"diff.bad-value","word-hash-diff/1",NULL,describe,evaluate},
    {71,"diff.bad-descriptor","word-hash-diff/1",NULL,describe,evaluate}
};
static void print_key(const void *data,size_t size)
{const unsigned char *p=data;for(size_t i=0;i<size;++i)printf("%02x",(unsigned)p[i]);}
static int normal(GeoEvalContext *ctx,GeoProviderToken provider,const unsigned char *bytes,size_t size)
{
    _Alignas(uint64_t) unsigned char caller[MAX_KEY+8];size_t offset=1+operation%7;
    memset(caller,0x6b,sizeof caller);if(size)memcpy(caller+offset,bytes,size);
    GeoSourceRef source={provider,caller+offset,size};size_t before_count=node_count,index=touch(source);
    REQUIRE("oracle-room",index!=SIZE_MAX);ExpectedNode *expected=&nodes[index];
    unsigned descriptions=expected->descriptions,evaluations=expected->evaluations;
    GeoSourceValue value;GeoSourceStatus status=geo_eval_source(ctx,source,GEO_DEPENDENCY_VALUE_REQUIRED,&value);
    REQUIRE("normal-status",status==GEO_SOURCE_OK);REQUIRE("normal-value",value_equal(source,&value));
    REQUIRE("normal-callbacks",expected->descriptions==descriptions+(before_count!=node_count)&&expected->evaluations==evaluations+(before_count!=node_count));
    expected->state=GEO_NODE_VALID;expected->status=GEO_SOURCE_OK;expected->described=1;
    memset(caller,0x9d,sizeof caller);
    GeoSourceNodeView view;REQUIRE("ownership-readable",geo_eval_node_at(ctx,index,&view));
    REQUIRE("ownership-size",view.source.provider==provider&&view.source.key_size==size);
    REQUIRE("ownership-copy",size?(view.source.key&&view.source.key!=caller+offset&&!memcmp(view.source.key,expected->key,size)):view.source.key==NULL);
    GeoSourceRef again=expected_ref(index);
    REQUIRE("normal-repeat",geo_eval_source(ctx,again,GEO_DEPENDENCY_EVALUATE_BEFORE,&value)==GEO_SOURCE_OK&&value_equal(again,&value));
    REQUIRE("repeat-no-callback",expected->descriptions==descriptions+(before_count!=node_count)&&expected->evaluations==evaluations+(before_count!=node_count));
    REQUIRE("normal-count",geo_eval_node_count(ctx)==node_count&&geo_eval_edge_count(ctx)==edge_count);
    printf("normal op=%zu node=%zu new=%d provider=%u size=%zu offset=%zu key=",operation++,index,before_count!=node_count,(unsigned)provider,size,offset);print_key(expected->key,size);
    printf(" value=%" PRId64 " ownership=1 repeat=0 callbacks=%u/%u nodes=%zu edges=%zu\n",value.as.quantity.num,expected->descriptions,expected->evaluations,node_count,edge_count);
    return 0;
}
static int pattern_matrix(GeoEvalContext *ctx,int full)
{
    static const size_t lengths[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,63,64,65,127,128,129};
    unsigned char bytes[MAX_KEY],changed[MAX_KEY];
    for(size_t l=0;l<sizeof lengths/sizeof lengths[0];++l){size_t size=lengths[l];
        if(!full&&size!=0&&size!=8&&size!=64&&size!=129)continue;
        for(size_t i=0;i<size;++i)bytes[i]=(unsigned char)(0x80^(i*37+size));
        if(size>2){bytes[size/2]=0;bytes[size-1]=0xff;}
        REQUIRE("matrix-pattern",!normal(ctx,17,bytes,size));
        REQUIRE("matrix-provider",!normal(ctx,29,bytes,size));
        for(int variant=0;variant<2;++variant){memset(changed,variant?0xff:0,size);REQUIRE("matrix-zero-ff",!normal(ctx,17,changed,size));}
        for(size_t pos=0;pos<size;++pos){memcpy(changed,bytes,size);changed[pos]^=(unsigned char)(pos%2?0x80:1);REQUIRE("matrix-byte-position",!normal(ctx,17,changed,size));}
        if(size)REQUIRE("matrix-shorter-size",!normal(ctx,17,bytes,size-1));
    }
    GeoSourceValue value;size_t old=node_count;
    REQUIRE("null-zero-key",geo_eval_source(ctx,(GeoSourceRef){17,NULL,0},GEO_DEPENDENCY_VALUE_REQUIRED,&value)==GEO_SOURCE_OK&&value_equal((GeoSourceRef){17,NULL,0},&value)&&geo_eval_node_count(ctx)==old);
    printf("empty-key-null-alias status=0 nodes=%zu\n",old);return 0;
}
static int source_failure(GeoEvalContext *ctx,GeoSourceRef ref,GeoSourceStatus expected_status,const char *label)
{
    GeoSourceValue value,before;memset(&value,0xa5,sizeof value);memcpy(&before,&value,sizeof before);
    GeoSourceStatus status=geo_eval_source(ctx,ref,GEO_DEPENDENCY_VALUE_REQUIRED,&value);int unchanged=!memcmp(&value,&before,sizeof value);
    printf("failure %s status=%d expected=%d unchanged=%d nodes=%zu edges=%zu\n",label,(int)status,(int)expected_status,unchanged,geo_eval_node_count(ctx),geo_eval_edge_count(ctx));
    REQUIRE("failure-status",status==expected_status);REQUIRE("failure-output",unchanged);return 0;
}
static int special_sources(GeoEvalContext *ctx)
{
    normal_count=node_count;
    GeoSourceRef root={41,special_key,sizeof special_key};size_t i=touch(root);REQUIRE("root-room",i!=SIZE_MAX);
    GeoSourceValue value;REQUIRE("root-evaluates",geo_eval_source(ctx,root,GEO_DEPENDENCY_VALUE_REQUIRED,&value)==GEO_SOURCE_OK&&value_equal(root,&value));
    nodes[i].state=GEO_NODE_VALID;nodes[i].described=1;
    REQUIRE("root-edges",geo_eval_edge_count(ctx)==edge_count&&edge_count==normal_count*3);
    printf("consumer status=0 normal=%zu nodes=%zu edges=%zu\n",normal_count,node_count,edge_count);
    static const GeoProviderToken failing[]={53,59,61,67,71};
    static const GeoSourceStatus statuses[]={GEO_SOURCE_FAILED,GEO_SOURCE_MISSING,GEO_SOURCE_FAILED,GEO_SOURCE_INVALID,GEO_SOURCE_INVALID};
    for(size_t n=0;n<sizeof failing/sizeof failing[0];++n){
        GeoSourceRef ref={failing[n],special_key,sizeof special_key};i=touch(ref);REQUIRE("failure-room",i!=SIZE_MAX);
        REQUIRE("special-failure",!source_failure(ctx,ref,statuses[n],"provider-first"));
        nodes[i].state=GEO_NODE_FAILED;nodes[i].status=statuses[n];nodes[i].described=failing[n]!=59;
        unsigned calls=nodes[i].descriptions+nodes[i].evaluations;
        REQUIRE("special-failure-repeat",!source_failure(ctx,ref,statuses[n],"provider-repeat"));
        REQUIRE("failure-memoization",nodes[i].descriptions+nodes[i].evaluations==calls);
    }
    REQUIRE("unknown-provider",!source_failure(ctx,(GeoSourceRef){999,special_key,sizeof special_key},GEO_SOURCE_MISSING,"unknown-provider"));
    REQUIRE("invalid-key",!source_failure(ctx,(GeoSourceRef){17,NULL,1},GEO_SOURCE_INVALID,"null-nonzero-key"));
    REQUIRE("invalid-context",!source_failure(NULL,expected_ref(0),GEO_SOURCE_INVALID,"null-context"));
    GeoSourceValue sentinel,before;memset(&sentinel,0x7c,sizeof sentinel);memcpy(&before,&sentinel,sizeof before);
    REQUIRE("invalid-kind",geo_eval_source(ctx,expected_ref(0),(GeoDependencyKind)3,&sentinel)==GEO_SOURCE_INVALID&&!memcmp(&sentinel,&before,sizeof before));
    REQUIRE("null-output",geo_eval_source(ctx,expected_ref(0),GEO_DEPENDENCY_VALUE_REQUIRED,NULL)==GEO_SOURCE_INVALID);
    REQUIRE("callback-checks",!callback_error);return 0;
}
static int dump_graph(GeoEvalContext *ctx,const char *label)
{
    REQUIRE("graph-node-count",geo_eval_node_count(ctx)==node_count);REQUIRE("graph-edge-count",geo_eval_edge_count(ctx)==edge_count);
    printf("graph %s nodes=%zu edges=%zu\n",label,node_count,edge_count);
    for(size_t i=0;i<node_count;++i){GeoSourceNodeView view;ExpectedNode *expected=&nodes[i];
        REQUIRE("graph-node-readable",geo_eval_node_at(ctx,i,&view));
        REQUIRE("graph-node-order",view.source.provider==expected->provider&&view.source.key_size==expected->size&&(!expected->size||!memcmp(view.source.key,expected->key,expected->size)));
        REQUIRE("graph-key-owned",expected->size?view.source.key!=expected->key:view.source.key==NULL);
        REQUIRE("graph-node-state",view.state==expected->state&&view.status==expected->status&&view.described==(expected->described!=0));
        REQUIRE("graph-node-value-presence",(view.value!=NULL)==(expected->state==GEO_NODE_VALID));
        if(view.value)REQUIRE("graph-node-value",value_equal(expected_ref(i),view.value));
        printf("node %zu provider=%u size=%zu key=",i,(unsigned)expected->provider,expected->size);print_key(expected->key,expected->size);
        printf(" state=%d status=%d described=%d descriptor=%d/%d/%d callbacks=%u/%u",(int)view.state,(int)view.status,(int)view.described,(int)view.descriptor.kind,(int)view.descriptor.unit,view.descriptor.context.axis,expected->descriptions,expected->evaluations);
        if(view.value)printf(" value=%" PRId64,view.value->as.quantity.num);
        printf("\n");
    }
    for(size_t i=0;i<edge_count;++i){GeoSourceEdge edge;REQUIRE("graph-edge-readable",geo_eval_edge_at(ctx,i,&edge));
        REQUIRE("graph-edge-order",edge.consumer==edges[i].consumer&&edge.source==edges[i].source&&edge.kind==edges[i].kind);
        printf("edge %zu consumer=%zu source=%zu kind=%d\n",i,edge.consumer,edge.source,(int)edge.kind);
    }
    GeoSourceNodeView node,before;memset(&node,0x59,sizeof node);memcpy(&before,&node,sizeof before);
    REQUIRE("node-out-of-range",!geo_eval_node_at(ctx,node_count,&node)&&!memcmp(&node,&before,sizeof before));
    GeoSourceEdge edge,edge_before;memset(&edge,0x3d,sizeof edge);memcpy(&edge_before,&edge,sizeof edge_before);
    REQUIRE("edge-out-of-range",!geo_eval_edge_at(ctx,edge_count,&edge)&&!memcmp(&edge,&edge_before,sizeof edge));return 0;
}
static int sealed(GeoEvalContext *ctx)
{
    const unsigned char pending_key[]={0xda,0xed,0x45,0x01};GeoSourceRef pending={29,pending_key,sizeof pending_key};
    REQUIRE("pending-unique",linear_node(pending)==SIZE_MAX);size_t pending_i=touch(pending);REQUIRE("pending-room",pending_i!=SIZE_MAX);
    REQUIRE("pending-depend",geo_eval_depend(ctx,pending,GEO_DEPENDENCY_DEFINITION_REQUIRED)==GEO_SOURCE_OK);
    REQUIRE("seal",geo_eval_seal(ctx)&&geo_eval_is_sealed(ctx));
    unsigned before_calls=0;for(size_t i=0;i<node_count;++i)before_calls+=nodes[i].descriptions+nodes[i].evaluations;
    for(size_t i=0;i<node_count;++i){GeoSourceRef ref=expected_ref(i);GeoSourceValue value;
        if(nodes[i].state==GEO_NODE_VALID){GeoSourceDescriptor descriptor;
            REQUIRE("sealed-valid-read",geo_eval_source(ctx,ref,GEO_DEPENDENCY_EVALUATE_BEFORE,&value)==GEO_SOURCE_OK&&value_equal(ref,&value));
            REQUIRE("sealed-description",geo_eval_describe(ctx,ref,&descriptor)==GEO_SOURCE_OK&&descriptor.kind==GEO_SOURCE_QUANTITY&&descriptor.context.axis==-1);
        }else REQUIRE("sealed-rejected-read",!source_failure(ctx,ref,GEO_SOURCE_INVALID,"sealed-not-valid"));
    }
    GeoSourceDescriptor descriptor,before;memset(&descriptor,0x65,sizeof descriptor);memcpy(&before,&descriptor,sizeof before);
    REQUIRE("sealed-undescribed",geo_eval_describe(ctx,pending,&descriptor)==GEO_SOURCE_INVALID&&!memcmp(&descriptor,&before,sizeof before));
    const unsigned char unknown_key[]={0xd1,0xd2,0xd3};GeoSourceRef unknown={17,unknown_key,sizeof unknown_key};
    REQUIRE("sealed-unknown-precondition",linear_node(unknown)==SIZE_MAX);
    REQUIRE("sealed-unknown-source",!source_failure(ctx,unknown,GEO_SOURCE_INVALID,"sealed-unknown"));
    REQUIRE("sealed-unknown-description",geo_eval_describe(ctx,unknown,&descriptor)==GEO_SOURCE_INVALID&&!memcmp(&descriptor,&before,sizeof before));
    REQUIRE("sealed-depend-refused",geo_eval_depend(ctx,expected_ref(0),GEO_DEPENDENCY_VALUE_REQUIRED)==GEO_SOURCE_INVALID);
    REQUIRE("sealed-reset-refused",!geo_eval_reset(ctx));REQUIRE("sealed-registration-refused",!geo_eval_register(ctx,&providers[0]));
    unsigned after_calls=0;for(size_t i=0;i<node_count;++i)after_calls+=nodes[i].descriptions+nodes[i].evaluations;
    REQUIRE("sealed-no-callbacks",before_calls==after_calls);REQUIRE("sealed-unchanged-graph",!dump_graph(ctx,"sealed"));
    printf("sealed callback-total=%u reset=0 depend=4 registration=0\n",after_calls);return 0;
}
int main(void)
{
    GeoEvalContext *ctx=geo_eval_create(31,19);REQUIRE("create",ctx);
    REQUIRE("identity",geo_eval_candidate_id(ctx)==31&&geo_eval_base_revision(ctx)==19);
    for(int phase=0;phase<2;++phase){
        REQUIRE("register",geo_eval_register_many(ctx,providers,sizeof providers/sizeof providers[0]));
        REQUIRE("provider-count",geo_eval_provider_count(ctx)==sizeof providers/sizeof providers[0]);
        printf("phase=%d candidate=31 revision=19 providers=%zu\n",phase,geo_eval_provider_count(ctx));
        REQUIRE("matrix",!pattern_matrix(ctx,phase==0));REQUIRE("specials",!special_sources(ctx));
        REQUIRE("graph",!dump_graph(ctx,phase?"after-reset":"first"));
        if(!phase){
            REQUIRE("reset",geo_eval_reset(ctx));REQUIRE("reset-empty",!geo_eval_node_count(ctx)&&!geo_eval_edge_count(ctx)&&!geo_eval_provider_count(ctx)&&!geo_eval_is_sealed(ctx));
            REQUIRE("reset-identity",geo_eval_candidate_id(ctx)==31&&geo_eval_base_revision(ctx)==19);
            node_count=edge_count=normal_count=operation=0;callback_error=0;memset(nodes,0,sizeof nodes);memset(edges,0,sizeof edges);
            printf("reset=1 nodes=0 edges=0 providers=0 candidate=31 revision=19\n");
        }else REQUIRE("sealed",!sealed(ctx));
    }
    geo_eval_destroy(ctx);printf("PASS node-hash-public-api-differential\n");return 0;
}
