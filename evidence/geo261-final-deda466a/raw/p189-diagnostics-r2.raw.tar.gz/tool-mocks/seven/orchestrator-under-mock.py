#!/usr/bin/env python3
"""完整七項串行錄製；保留原退出碼、超時與基礎設施錯誤並繼續剩餘項目。"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback

ENV = Path('/tmp/g261-tool-mocks-20261022/seven/stub-tools')
INTEGRATION = Path('/tmp/g261-tool-mocks-20261022/seven/mock-integration')
ORDER = ('native', 'canvas', 'assembly', 'documents', 'grid', 'space', 'timber')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def validate_receipt(data, row, repo, sha, job, frozen):
    # workflow 收據沒有頂層 cwd/command；由 checkout 及原 driver 的 step result 核對。
    assert isinstance(data, dict) and data['schema'] == 'geo261-cloud-workflow/1'
    assert data['sha'] == sha and data['job'] == job
    assert type(data['exit_code']) is int and data['exit_code'] == row['exit_code']
    assert data['driver_sha256'] == frozen['run_workflow_round.py']
    assert type(data['over_ci_timeout']) is bool
    assert data['environment']['GITHUB_SHA'] == sha
    assert data['environment']['GITHUB_WORKSPACE'] == str(repo)
    for key in ('checkout_before', 'checkout_after'):
        state = data[key]
        assert state['head'] == sha and state['root'] == str(repo) and state['status'] == ''
    assert data['status'] in ('完成', '失敗', '中斷', '環境或 driver 受阻')
    assert isinstance(data['steps'], list)
    for step in data['steps']:
        if 'result' not in step:
            continue
        result = step['result']
        assert result['cwd'] == str(repo)
        script = Path(result['command'][-1])
        assert script == Path(row['receipt']).parent / 'steps' / f"{step['index']:02d}.executed.sh"
        expected = (['bash', '--noprofile', '--norc', '-eo', 'pipefail', str(script)]
                    if step['original_step'].get('shell') == 'bash' else ['bash', '-e', str(script)])
        assert result['command'] == expected
        assert digest(script) == step['script_sha256']
        expected_bytes = step['executed_run']
        if not expected_bytes.endswith('\n'):
            expected_bytes += '\n'
        assert script.read_bytes() == expected_bytes.encode('utf-8')
    assert 'source_integrity_error' not in data


def run_one(repo, sha, scratch, launch, job, frozen):
    stdout = launch / (job + '.stdout')
    stderr = launch / (job + '.stderr')
    events = launch / (job + '-reaper.jsonl')
    infrastructure = launch / (job + '.infrastructure.json')
    directory = scratch / 'seven-final' / job
    receipt = directory / 'receipt.json'
    command = ['python3', str(ENV / 'reap_children.py'), 'python3', str(ENV / 'run_workflow_round.py'),
               '--repo', str(repo), '--sha', sha, '--job', job, '--out-root', str(scratch / 'seven-final')]
    row = {'job': job, 'source_sha': sha, 'command': command, 'cwd': str(repo),
           'started_utc': now(), 'exit_code': None, 'infrastructure_errors': [],
           'receipt': str(receipt), 'receipt_validated': False, 'derived_pass': False,
           'stdout': str(stdout), 'stderr': str(stderr), 'reaper': str(events)}
    try:
        for name, wanted in frozen.items():
            assert digest(ENV / name) == wanted, '本輪封裝器執行中改變：' + name
        with stdout.open('xb') as out, stderr.open('xb') as err:
            done = subprocess.run(command, cwd=repo, env=dict(os.environ, GEO261_REAPER_LOG=str(events)),
                                  stdout=out, stderr=err)
        row['exit_code'] = done.returncode
    except Exception:
        row['infrastructure_errors'].append({'stage': 'launch', 'traceback': traceback.format_exc()})
    row['completed_utc'] = now()
    if receipt.is_file():
        try:
            data = json.loads(receipt.read_text())
            validate_receipt(data, row, repo, sha, job, frozen)
            row.update(receipt_validated=True, status=data['status'], seconds=data.get('seconds'),
                       over_ci_timeout=data['over_ci_timeout'], ci_timeout_minutes=data['ci_timeout_minutes'],
                       receipt_exit_code=data['exit_code'])
            # 保留原 rc；判定另列，不把 watchdog 內完成但超正式 CI 時限誤算通過。
            row['derived_pass'] = (row['exit_code'] == 0 and data['exit_code'] == 0 and
                                   data['status'] == '完成' and data['over_ci_timeout'] is False and
                                   not row['infrastructure_errors'])
        except Exception:
            row['infrastructure_errors'].append({'stage': 'receipt', 'traceback': traceback.format_exc()})
    else:
        row['infrastructure_errors'].append({'stage': 'receipt', 'error': '未留下完整收據，沒有冒稱已執行或通過'})
    write_json(infrastructure, row)
    publish = ['python3', str(ENV / 'publish_progress.py'), '--sha', sha, '--label', job,
               '--result', '原退出' + str(row['exit_code']) + '；收據完整=' + str(row['receipt_validated']) +
               '；超正式時限=' + str(row.get('over_ci_timeout')) + '；衍生通過=' + str(row['derived_pass']) +
               '；基礎設施錯誤=' + str(len(row['infrastructure_errors'])),
               '--next', '串行完成本輪其餘七項與全部專項；收齊紅燈後集中分類修正',
               '--input', 'infrastructure=' + str(infrastructure),
               '--input', 'orchestrator=' + str(launch / 'orchestrator.py.txt'),
               '--input', 'round-config=' + str(launch / 'round-config.json')]
    for name, path in [('launch-stdout', stdout), ('launch-stderr', stderr), ('reaper', events)]:
        if path.exists():
            publish += ['--input', name + '=' + str(path)]
    if directory.is_dir():
        publish += ['--input', 'job=' + str(directory)]
    if row['receipt_validated']:
        publish += ['--receipt', str(receipt)]
    tmp = scratch / 'tmp' / 'seven-final' / job
    if tmp.is_dir() and job != 'native':
        publish += ['--input', 'job-tmp=' + str(tmp)]
    row['publish_command'] = publish
    pstdout = launch / (job + '.publish.stdout')
    pstderr = launch / (job + '.publish.stderr')
    try:
        with pstdout.open('xb') as out, pstderr.open('xb') as err:
            published = subprocess.run(publish, cwd=INTEGRATION, stdout=out, stderr=err)
        row['progress_publish_exit'] = published.returncode
    except Exception:
        row['progress_publish_exit'] = None
        row['infrastructure_errors'].append({'stage': 'publish', 'traceback': traceback.format_exc()})
    row['publish_stdout'] = str(pstdout)
    row['publish_stderr'] = str(pstderr)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    args = parser.parse_args()
    repo, scratch = args.repo.resolve(), args.scratch.resolve()
    assert len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha)
    assert scratch.is_relative_to(Path('/tmp')) and not scratch.is_relative_to(repo)
    scratch.mkdir(parents=True, exist_ok=True)
    launch = scratch / 'launch'
    launch.mkdir(exist_ok=False)
    results_file = scratch / 'seven-round-results.json'
    assert not results_file.exists(), '拒絕覆蓋舊結果或自動挑選重跑'
    (launch / 'orchestrator.py.txt').write_bytes(Path(__file__).read_bytes())
    frozen = {name: digest(ENV / name) for name in ('run_workflow_round.py', 'reap_children.py')}
    write_json(launch / 'round-config.json', {'schema': 'geo261-seven-orchestrator/1',
               'repo': str(repo), 'source_sha': args.sha, 'scratch': str(scratch), 'order': ORDER,
               'orchestrator_sha256': digest(Path(__file__)), 'frozen_wrappers_sha256': frozen,
               'policy': '原退出碼獨立保留；原正式時限不變；超時不得通過；不自動重試；每紅繼續其餘項目'})
    rows = []
    write_json(results_file, rows)
    for job in ORDER:
        print('開始完整清單：' + job, flush=True)
        try:
            row = run_one(repo, args.sha, scratch, launch, job, frozen)
        except Exception:
            row = {'job': job, 'source_sha': args.sha, 'exit_code': None, 'derived_pass': False,
                   'progress_publish_exit': None, 'completed_utc': now(),
                   'infrastructure_errors': [{'stage': 'orchestrator', 'traceback': traceback.format_exc()}]}
            print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)
        write_json(results_file, rows)
        print('完成並記錄：' + job + '；原退出' + str(row['exit_code']) +
              '；衍生通過=' + str(row['derived_pass']) +
              '；進度推送退出' + str(row['progress_publish_exit']), flush=True)
    return 0 if len(rows) == 7 and all(row['derived_pass'] and row['progress_publish_exit'] == 0 and
                                      not row['infrastructure_errors'] for row in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())
