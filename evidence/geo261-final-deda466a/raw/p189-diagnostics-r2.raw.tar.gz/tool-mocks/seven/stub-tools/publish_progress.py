import json,os,sys
from pathlib import Path
label=sys.argv[sys.argv.index('--label')+1]
record={'mock_only':True,'label':label,'command':sys.argv[1:],'no_git_or_push_called':True}
with (Path(__file__).parent/('publish-'+os.environ['GEO261_MOCK_MODE']+'.jsonl')).open('a') as f:f.write(json.dumps(record)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(9 if os.environ['GEO261_MOCK_MODE']=='red' and label=='documents' else 0)
