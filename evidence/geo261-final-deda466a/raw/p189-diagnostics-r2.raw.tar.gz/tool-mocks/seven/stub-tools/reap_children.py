import json,os,subprocess,sys
from pathlib import Path
Path(os.environ['GEO261_REAPER_LOG']).write_text(json.dumps({'mock_only':True,'command':sys.argv[1:]})+'\n')
raise SystemExit(subprocess.run(sys.argv[1:]).returncode)
