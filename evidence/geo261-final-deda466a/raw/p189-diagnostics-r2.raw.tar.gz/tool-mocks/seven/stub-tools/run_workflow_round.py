import argparse,hashlib,json,os
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo');p.add_argument('--sha');p.add_argument('--job');p.add_argument('--out-root')
a=p.parse_args();out=Path(a.out_root)/a.job;out.mkdir(parents=True)
state={'head':a.sha,'root':a.repo,'status':''}
data={'schema':'geo261-cloud-workflow/1','sha':a.sha,'job':a.job,'exit_code':0,
      'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'over_ci_timeout':False,'environment':{'GITHUB_SHA':a.sha,'GITHUB_WORKSPACE':a.repo},
      'checkout_before':state,'checkout_after':state,'status':'完成','steps':[],
      'ci_timeout_minutes':35,'seconds':1.0}
if os.environ['GEO261_MOCK_MODE']=='red':
    if a.job=='canvas':data['sha']='0'*40
    if a.job=='assembly':data['over_ci_timeout']=True
with (out/'receipt.json').open('w') as f:
    f.write('{ deliberately broken JSON' if os.environ['GEO261_MOCK_MODE']=='red' and a.job=='native' else json.dumps(data))
print('MOCK EXECUTED '+a.job,flush=True)
