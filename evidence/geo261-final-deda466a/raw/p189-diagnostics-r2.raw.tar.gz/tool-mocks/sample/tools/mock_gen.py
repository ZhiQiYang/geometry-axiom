print("mock scene; no product engine is executed")
