#!/usr/bin/env python3
"""只準備下一輪工具與可核對的路徑差分；不編譯、不執行驗收、不改 repository。"""
import argparse
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ENV = Path('/workspace/geo261-environment')
ORIGINAL_TOOLS = Path('/tmp/g261r1/tools')
SOFT_STACK_Q38 = Path('/tmp/g261r1/q38-envfix-tools/q38_gate.sh')
NAMES = ('postfix_validate.py', 'p52_measure.py', 'p52_probe.cjs', 'p52_cases.cjs',
         'verify_postfix_receipt.py', 'p189_verify.py', 'gen_scene.py', 'scale_compare2.py',
         'q38_gate.sh', 'q38_controls.py', 'card_ref_mutations.sh', 'prepare_p52_main.py')
P189_RUN_ORIGINAL = '''def run(argv, *, cwd=None, data=None, timeout=1200):
    p = subprocess.run(argv, cwd=cwd, env=ENV, input=data, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f'指令失敗 {p.returncode}: {argv}\\n{p.stderr[-1000:]!r}')
    return p
'''
SCALE_ONE_LOAD_ORIGINAL = '''def one_load(bridge, scene):
    p = subprocess.Popen(["bash", "-c", 'ulimit -c 0; ulimit -S -s 16384 || exit 126; exec "$@"', "x", bridge],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    t0 = time.perf_counter()
    try:
        out, err = p.communicate(("loadfile " + scene + "\\n").encode(), timeout=a.timeout)
    except subprocess.TimeoutExpired:
        p.kill(); p.communicate()
        return "timeout", None, time.perf_counter() - t0, ""
    dt = time.perf_counter() - t0
    line = out.decode("utf-8", "replace").splitlines()[:1]
    if not line:
        return "eof rc=%s" % p.returncode, None, dt, err.decode("utf-8", "replace")[-200:]
    try:
        resp = json.loads(line[0])
    except ValueError:
        return "badjson", None, dt, line[0][:200]
    ok = resp.get("ok")
    return "ok", ok, dt, "" if ok else json.dumps(resp, ensure_ascii=False)[:300]
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def readgit(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def replace_exact(text, old, new, count, transformations):
    actual = text.count(old)
    assert actual == count, (old, actual, count)
    transformations.append({'before': old, 'after': new, 'count': count})
    return text.replace(old, new)


def adapt(name, original, repo, sha, scratch, tools):
    text = original.decode('utf-8')
    changes = []
    # 先處理完整路徑，避免把原 tools/gen 路徑誤轉成未要求的位置。
    if name == 'p189_verify.py':
        text = replace_exact(text, "Path('/tmp/g261r1/tools/gen_scene.py')", f"Path({str(tools / 'gen_scene.py')!r})", 1, changes)
        text = replace_exact(text, "Path('/tmp/g261r1/tools')", f"Path({str(tools)!r})", 1, changes)
    if name == 'scale_compare2.py':
        text = replace_exact(text, '/tmp/g261r1/tools/gen_scene.py', str(tools / 'gen_scene.py'), 1, changes)
    source_count = {'postfix_validate.py': 1, 'p52_measure.py': 1, 'p189_verify.py': 1,
                    'q38_gate.sh': 2, 'card_ref_mutations.sh': 1, 'prepare_p52_main.py': 0}.get(name, 0)
    if source_count:
        text = replace_exact(text, '/tmp/g261r1/source-final', str(repo), source_count, changes)
    remaining = {'postfix_validate.py': 1, 'p52_measure.py': 1, 'p189_verify.py': 1,
                 'q38_gate.sh': 2, 'card_ref_mutations.sh': 2, 'prepare_p52_main.py': 1}.get(name, 0)
    assert text.count('/tmp/g261r1') == remaining, (name, '非預期的舊路徑數量')
    if remaining:
        text = replace_exact(text, '/tmp/g261r1', str(scratch), remaining, changes)
    if name == 'prepare_p52_main.py':
        text = replace_exact(text, "str(root/'source-final')", repr(str(repo)), 1, changes)
    if name == 'p52_measure.py':
        text = replace_exact(text, '7dae5f21c7ca401e660450d437e60ba566218da8', sha, 1, changes)
    if name == 'p189_verify.py':
        capture = (ENV / 'p189_capture_run_fragment.py.txt').read_text()
        text = replace_exact(text, P189_RUN_ORIGINAL, 'RUN_CAPTURE_INDEX = 0\n\n\n' + capture, 1, changes)
        verify = (ENV / 'p189_samples_verification_fragment.py.txt').read_text()
        text = replace_exact(text, "    ratios = []\n", verify + "    ratios = []\n", 1, changes)
    if name == 'scale_compare2.py':
        text = replace_exact(text, 'import argparse, json, os, statistics, subprocess, sys, time',
                             'import argparse, hashlib, json, os, statistics, subprocess, sys, time', 1, changes)
        capture = (ENV / 'p189_loadfile_capture_fragment.py.txt').read_text()
        text = replace_exact(text, SCALE_ONE_LOAD_ORIGINAL, capture, 1, changes)
        text = replace_exact(text, 'one_load(os.path.join(src, "bridge"), scene)',
                             'one_load(os.path.join(src, "bridge"), scene, {"n": n, "round": r, "side": label})', 1, changes)
    assert '/tmp/g261r1' not in text
    if name.endswith('.py'):
        ast.parse(text, filename=name)  # 僅語法解析，不匯入或執行工具。
    return text.encode('utf-8'), changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    parser.add_argument('--tools', type=Path, required=True)
    args = parser.parse_args()
    repo, scratch, tools = args.repo.resolve(), args.scratch.resolve(), args.tools.resolve()
    assert len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha)
    # shell 原工具直接含字面路徑；只接受無需額外 shell quoting 的標準短隔離路徑。
    for path in (repo, scratch, tools):
        assert re.fullmatch(r'/[A-Za-z0-9_./-]+', str(path)), path
    assert scratch.is_relative_to(Path('/tmp')) and len(str(scratch)) <= 40
    assert tools.is_relative_to(scratch) and not tools.exists()
    assert not tools.is_relative_to(repo) and not repo.is_relative_to(tools)
    assert readgit(repo, 'rev-parse', 'HEAD').decode().strip() == args.sha
    assert readgit(repo, 'status', '--porcelain') == b'', '必須先固定乾淨來源，再準備正式工具'
    assert readgit(repo, 'rev-parse', args.sha + '^{commit}').decode().strip() == args.sha
    tools.mkdir(parents=True)
    original_dir = tools / 'round-original-source'
    original_dir.mkdir()
    rows = []
    for name in NAMES:
        source = (ENV / name) if name == 'prepare_p52_main.py' else (ORIGINAL_TOOLS / name)
        if name == 'q38_gate.sh':
            source = SOFT_STACK_Q38
        original = source.read_bytes()
        if name == 'q38_gate.sh':
            # 再確認使用的是已驗證的單一 soft-limit 環境修復，未改測試。
            prior = (ORIGINAL_TOOLS / name).read_bytes()
            assert original == prior.replace(b'ulimit -s 16384', b'ulimit -S -s 16384')
        adapted, changes = adapt(name, original, repo, args.sha, scratch, tools)
        (original_dir / name).write_bytes(original)
        (tools / name).write_bytes(adapted)
        (tools / name).chmod(source.stat().st_mode & 0o777)
        diff = ''.join(difflib.unified_diff(original.decode().splitlines(keepends=True),
                                          adapted.decode().splitlines(keepends=True),
                                          fromfile=str(source), tofile=str(tools / name)))
        (original_dir / (name + '.diff')).write_text(diff)
        rows.append({'name': name, 'source_path': str(source), 'original_sha256': digest(original),
                     'adapted_sha256': digest(adapted), 'transformations': changes,
                     'unchanged': adapted == original})
    for source, name in [(ORIGINAL_TOOLS / 'ADAPTATION.json', 'prior-cloud-ADAPTATION.json'),
                         (SOFT_STACK_Q38.parent / 'ADAPTATION.json', 'q38-softstack-ADAPTATION.json')]:
        shutil.copy2(source, original_dir / name)
    for name in ('run_acceptance_specials_configured.py', 'run_acceptance_seven_configured.py',
                 'prepare_acceptance_round.py', 'p189_capture_run_fragment.py.txt',
                 'p189_loadfile_capture_fragment.py.txt', 'p189_samples_verification_fragment.py.txt'):
        shutil.copy2(ENV / name, original_dir / (name + '.txt'))
    manifest = {'schema': 'geo261-configured-acceptance-tools/1',
                'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'source_sha': args.sha, 'repo': str(repo), 'scratch': str(scratch), 'tools': str(tools),
                'preparation_executed_tests': False, 'files': rows,
                'policy': '隔離路徑與固定SHA機械適配，沿用Q38已驗soft-only限制；另修P189完整子命令/樣本證據缺漏及忽略timing bridge非零退出的裁判缺陷；不改取樣、2x/P52門檻、既有負控或任何產品與測試。',
                'p189_capture_template_sha256': digest((ENV / 'p189_capture_run_fragment.py.txt').read_bytes()),
                'p189_loadfile_capture_template_sha256': digest((ENV / 'p189_loadfile_capture_fragment.py.txt').read_bytes()),
                'p189_samples_verification_template_sha256': digest((ENV / 'p189_samples_verification_fragment.py.txt').read_bytes()),
                'orchestrator_sha256': digest((ENV / 'run_acceptance_specials_configured.py').read_bytes()),
                'preparation_script_sha256': digest(Path(__file__).read_bytes())}
    (tools / 'ROUND_ADAPTATION.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'prepared_tools': str(tools), 'source_sha': args.sha, 'files': len(rows),
                      'tests_executed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
