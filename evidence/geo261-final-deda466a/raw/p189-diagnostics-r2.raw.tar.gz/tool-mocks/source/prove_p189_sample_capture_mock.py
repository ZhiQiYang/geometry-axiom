#!/usr/bin/env python3
"""repo 外 mock：正常綠、ok:true+rc7 必紅、撤回裁判修正則漏報、逾時保留 bytes。"""
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ENV = Path('/workspace/geo261-environment')
ORIGINAL = Path('/tmp/g261r1/tools/scale_compare2.py')
STDOUT = b'{"ok":true}\n' + b'mock-stdout-' * 400 + b'\x00\xff\n'
STDERR = b'mock-stderr-' * 500 + b'\x00\xff\n'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--execute', action='store_true', help='明確指定才執行小型 mock；不編譯、不跑產品效能')
    args = parser.parse_args()
    root = args.out.resolve()
    assert root.is_relative_to(Path('/tmp')) and not root.exists()
    root.mkdir()
    tools = root / 'tools'
    tools.mkdir()
    spec = importlib.util.spec_from_file_location('geo261_preparation_only', ENV / 'prepare_acceptance_round.py')
    preparation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preparation)  # 僅載入準備函式；main guard 不執行驗收。
    adapted, changes = preparation.adapt('scale_compare2.py', ORIGINAL.read_bytes(),
                                       root / 'not-a-product-checkout', '0' * 40, root, tools)
    (tools / 'scale-fixed.py').write_bytes(adapted)
    (tools / 'scale-original.py').write_bytes(ORIGINAL.read_bytes())
    generator = tools / 'mock_gen.py'
    generator.write_text('print("mock scene; no product engine is executed")\n')
    for name, code, pause in [('normal', 0, 0), ('nonzero', 7, 0), ('timeout', 0, 10)]:
        directory = root / name
        directory.mkdir()
        bridge = directory / 'bridge'
        source = ('#!/usr/bin/env python3\nimport sys,time\n'
                  'sys.stdin.buffer.readline()\n'
                  f'sys.stdout.buffer.write({STDOUT!r}); sys.stdout.buffer.flush()\n'
                  f'sys.stderr.buffer.write({STDERR!r}); sys.stderr.buffer.flush()\n'
                  f'time.sleep({pause})\nraise SystemExit({code})\n')
        bridge.write_text(source)
        bridge.chmod(0o755)
    plan = {'purpose': '小型 mock 裁判自證，不是產品驗收或 P-189 效能收據',
            'product_sha': None, 'source_original': str(ORIGINAL), 'original_sha256': digest(ORIGINAL.read_bytes()),
            'adapted_sha256': digest(adapted), 'adaptation': changes,
            'preparation_script_sha256': digest((ENV / 'prepare_acceptance_round.py').read_bytes()),
            'self_script_sha256': digest(Path(__file__).read_bytes()), 'mock_stdout_hex': STDOUT.hex(),
            'mock_stderr_hex': STDERR.hex(), 'executed': args.execute}
    write_json(root / 'PLAN.json', plan)
    if not args.execute:
        print('只準備 mock 工具；未執行任何子程序或產品測試。', flush=True)
        return 0
    records = []
    cases = [('normal-fixed', 'fixed', 'normal', 0), ('normal-reverted', 'original', 'normal', 0),
             ('nonzero-reverted', 'original', 'nonzero', 0), ('nonzero-fixed', 'fixed', 'nonzero', 1),
             ('nonzero-restored', 'fixed', 'nonzero', 1), ('timeout-fixed', 'fixed', 'timeout', 1)]
    for label, driver, mode, wanted in cases:
        out = root / label
        work = root / (label + '-work')
        work.mkdir()
        command = [sys.executable, '-B', '-u', str(tools / ('scale-' + driver + '.py')), str(work), str(out),
                   'mock=' + str(root / mode), '--ns', '16', '--reps', '1', '--timeout', '1', '--gen', str(generator)]
        started = time.time()
        result = subprocess.run(command, capture_output=True, timeout=30)
        (root / (label + '.stdout')).write_bytes(result.stdout)
        (root / (label + '.stderr')).write_bytes(result.stderr)
        assert result.returncode == 0, label  # scale 原工具只印樣本；是否通過由父裁判判。
        with (out / 'samples.tsv').open() as stream:
            rows = list(csv.DictReader(stream, delimiter='\t'))
        assert len(rows) == 1
        try:
            # 保留父 P-189 對 status 與 load_ok 的既有判定，縮成單一專項負控。
            assert all(row['status'] == 'ok' and row['ok'] == 'True' for row in rows), 'timing-sample-must-succeed'
            verdict = 0
        except AssertionError:
            verdict = 1
        record = {'label': label, 'command': command, 'started_epoch_utc': started,
                  'ended_epoch_utc': time.time(), 'driver_process_returncode': result.returncode,
                  'parent_verdict': verdict, 'expected_verdict': wanted, 'sample': rows[0],
                  'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr)}
        if driver == 'fixed':
            raw = json.loads((out / 'loadfile-samples.json').read_text())
            assert len(raw) == 1
            sample = raw[0]
            assert (out / sample['files']['stdout.bin']['path']).read_bytes() == STDOUT
            assert (out / sample['files']['stderr.bin']['path']).read_bytes() == STDERR
            for file in sample['files'].values():
                payload = (out / file['path']).read_bytes()
                assert len(payload) == file['bytes'] and digest(payload) == file['sha256']
            if mode == 'normal':
                assert sample['actual_process_returncode'] == 0 and sample['timeout_expired'] is False
            elif mode == 'nonzero':
                assert sample['actual_process_returncode'] == 7 and sample['load_ok'] is True
            else:
                assert sample['actual_process_returncode'] != 0 and sample['timeout_expired'] is True
                assert 'timeout-partial.stdout.bin' in sample['files'] and 'timeout-partial.stderr.bin' in sample['files']
            record['raw_sample'] = sample
        assert verdict == wanted, (label, verdict, wanted)
        records.append(record)
        write_json(root / 'RESULTS.json', records)
        print(label + '：原 driver rc=' + str(result.returncode) + '；父裁判=' + str(verdict), flush=True)
    write_json(root / 'SUMMARY.json', {'purpose': plan['purpose'], 'product_sha': None,
               'normal_passes': True, 'nonzero_true_response_rejected': True,
               'reverted_fix_loses_negative_control': True, 'restored_fix_rejects_nonzero': True,
               'timeout_raw_bytes_preserved': True, 'cases': len(records), 'pass': True})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
