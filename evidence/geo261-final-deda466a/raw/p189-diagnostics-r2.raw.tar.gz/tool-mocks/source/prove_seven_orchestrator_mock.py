#!/usr/bin/env python3
"""七項封裝器隔離 stub 自證；不啟動任何真實 job，不讀寫產品或呼叫 git/push。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ENV = Path('/workspace/geo261-environment')
ORDER = ['native', 'canvas', 'assembly', 'documents', 'grid', 'space', 'timber']

DRIVER = '''import argparse,hashlib,json,os
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo');p.add_argument('--sha');p.add_argument('--job');p.add_argument('--out-root')
a=p.parse_args();out=Path(a.out_root)/a.job;out.mkdir(parents=True)
state={'head':a.sha,'root':a.repo,'status':''}
data={'schema':'geo261-cloud-workflow/1','sha':a.sha,'job':a.job,'exit_code':0,
      'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'over_ci_timeout':False,'environment':{'GITHUB_SHA':a.sha,'GITHUB_WORKSPACE':a.repo},
      'checkout_before':state,'checkout_after':state,'status':'完成','steps':[],
      'ci_timeout_minutes':35,'seconds':1.0}
if os.environ['GEO261_MOCK_MODE']=='red':
    if a.job=='canvas':data['sha']='0'*40
    if a.job=='assembly':data['over_ci_timeout']=True
with (out/'receipt.json').open('w') as f:
    f.write('{ deliberately broken JSON' if os.environ['GEO261_MOCK_MODE']=='red' and a.job=='native' else json.dumps(data))
print('MOCK EXECUTED '+a.job,flush=True)
'''

REAPER = '''import json,os,subprocess,sys
from pathlib import Path
Path(os.environ['GEO261_REAPER_LOG']).write_text(json.dumps({'mock_only':True,'command':sys.argv[1:]})+'\\n')
raise SystemExit(subprocess.run(sys.argv[1:]).returncode)
'''

PUBLISHER = '''import json,os,sys
from pathlib import Path
label=sys.argv[sys.argv.index('--label')+1]
record={'mock_only':True,'label':label,'command':sys.argv[1:],'no_git_or_push_called':True}
with (Path(__file__).parent/('publish-'+os.environ['GEO261_MOCK_MODE']+'.jsonl')).open('a') as f:f.write(json.dumps(record)+'\\n')
print(json.dumps(record),flush=True)
raise SystemExit(9 if os.environ['GEO261_MOCK_MODE']=='red' and label=='documents' else 0)
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    root = args.out.resolve()
    assert root.is_relative_to(Path('/tmp')) and not root.exists()
    root.mkdir()
    stubs = root / 'stub-tools'
    stubs.mkdir()
    repo = root / 'mock-repo'
    repo.mkdir()
    integration = root / 'mock-integration'
    integration.mkdir()
    for name, source in [('run_workflow_round.py', DRIVER), ('reap_children.py', REAPER), ('publish_progress.py', PUBLISHER)]:
        (stubs / name).write_text(source)
    original = (ENV / 'run_acceptance_seven_configured.py').read_text()
    before_env = "ENV = Path('/workspace/geo261-environment')"
    before_repo = "INTEGRATION = Path('/workspace/geometry-axiom')"
    assert original.count(before_env) == original.count(before_repo) == 1
    adapted = original.replace(before_env, f'ENV = Path({str(stubs)!r})').replace(before_repo, f'INTEGRATION = Path({str(integration)!r})')
    runner = root / 'orchestrator-under-mock.py'
    runner.write_text(adapted)
    write_json(root / 'PROVENANCE.json', {'purpose': 'repo外stub封裝器自證，不是產品或workflow驗收',
               'product_sha': None, 'original_orchestrator_sha256': digest(original.encode()),
               'stubbed_orchestrator_sha256': digest(adapted.encode()),
               'replacement_scope': '只改ENV與INTEGRATION兩個隔離路徑，其餘原碼完整保留',
               'stubs_sha256': {f.name: digest(f.read_bytes()) for f in stubs.iterdir()},
               'proof_script_sha256': digest(Path(__file__).read_bytes()), 'no_real_job_or_push': True})
    results = []
    for mode, wanted in [('red', 1), ('green', 0)]:
        scratch = root / ('scratch-' + mode)
        command = [sys.executable, '-B', '-u', str(runner), '--repo', str(repo), '--sha', 'f' * 40, '--scratch', str(scratch)]
        started = time.time()
        result = subprocess.run(command, env=dict(os.environ, GEO261_MOCK_MODE=mode), capture_output=True, timeout=60)
        (root / (mode + '.stdout')).write_bytes(result.stdout)
        (root / (mode + '.stderr')).write_bytes(result.stderr)
        rows = json.loads((scratch / 'seven-round-results.json').read_text())
        assert len(rows) == 7 and [r['job'] for r in rows] == ORDER
        assert all(row['exit_code'] == 0 for row in rows), '不得竄改stub的原始rc0'
        publications = [json.loads(line) for line in (stubs / ('publish-' + mode + '.jsonl')).read_text().splitlines()]
        assert [row['label'] for row in publications] == ORDER
        if mode == 'red':
            assert [r['derived_pass'] for r in rows] == [False, False, False, True, True, True, True]
            assert rows[0]['infrastructure_errors'][0]['stage'] == 'receipt'
            assert rows[1]['infrastructure_errors'][0]['stage'] == 'receipt'
            assert rows[2]['over_ci_timeout'] is True and rows[2]['receipt_validated'] is True
            assert rows[3]['progress_publish_exit'] == 9
            assert all(row['progress_publish_exit'] == 0 for row in rows[4:])
        else:
            assert all(row['derived_pass'] and row['receipt_validated'] and row['progress_publish_exit'] == 0 for row in rows)
        assert result.returncode == wanted
        record = {'mode': mode, 'command': command, 'started_epoch_utc': started,
                  'ended_epoch_utc': time.time(), 'actual_process_returncode': result.returncode,
                  'expected_returncode': wanted, 'jobs_recorded': len(rows), 'publish_attempts': len(publications),
                  'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr), 'pass': True}
        results.append(record)
        write_json(root / 'RESULTS.json', results)
        print(json.dumps(record, ensure_ascii=False), flush=True)
    write_json(root / 'SUMMARY.json', {'purpose': 'repo外stub封裝器自證，不是產品驗收', 'product_sha': None,
               'malformed_json_and_wrong_sha_continue': True, 'over_ci_timeout_is_not_pass': True,
               'raw_returncodes_preserved': True, 'publisher_failure_continues': True,
               'all_green_baseline_passes': True, 'no_real_job_or_push': True, 'pass': True})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
