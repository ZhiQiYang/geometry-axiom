#!/usr/bin/env python3
"""只執行已授權的 repo 外小型 mock；不執行產品、編譯或真實 push。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ENV = Path('/workspace/geo261-environment')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = args.out.resolve()
    assert root.is_relative_to(Path('/tmp')) and not root.exists()
    root.mkdir()
    scripts = ['prove_p189_sample_capture_mock.py', 'prove_seven_orchestrator_mock.py',
               'execute_prepared_mock_proofs.py', 'prepare_acceptance_round.py',
               'run_acceptance_seven_configured.py', 'run_acceptance_specials_configured.py',
               'p189_capture_run_fragment.py.txt', 'p189_loadfile_capture_fragment.py.txt',
               'p189_samples_verification_fragment.py.txt']
    sources = root / 'source'
    sources.mkdir()
    for name in scripts:
        (sources / name).write_bytes((ENV / name).read_bytes())
    write_json(root / 'PROVENANCE.json', {'purpose': 'repo外mock工具自證，不是產品驗收或P189效能',
               'product_sha': None, 'command': sys.argv, 'cwd': os.getcwd(),
               'started_epoch_utc': time.time(), 'python': sys.version,
               'source_hashes': {name: digest((ENV / name).read_bytes()) for name in scripts}})
    records = []
    for label, argv in [('sample', [sys.executable, '-B', str(ENV / 'prove_p189_sample_capture_mock.py'), '--out', str(root / 'sample'), '--execute']),
                        ('seven', [sys.executable, '-B', str(ENV / 'prove_seven_orchestrator_mock.py'), '--out', str(root / 'seven')])]:
        started = time.time()
        result = subprocess.run(argv, capture_output=True, timeout=90)
        (root / (label + '.stdout')).write_bytes(result.stdout)
        (root / (label + '.stderr')).write_bytes(result.stderr)
        row = {'label': label, 'command': argv, 'cwd': os.getcwd(), 'started_epoch_utc': started,
               'ended_epoch_utc': time.time(), 'actual_process_returncode': result.returncode,
               'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr)}
        records.append(row)
        write_json(root / 'COMMANDS.json', records)
        assert result.returncode == 0, row
        print(label + ' 小mock退出0', flush=True)
    out = root / 'outer-capture'
    out.mkdir()
    namespace = {'OUT': out, 'RUN_CAPTURE_INDEX': 0, 'time': time, 'Path': Path, 'os': os,
                 'json': json, 'digest': digest, 'ENV': dict(os.environ), 'subprocess': subprocess}
    exec((ENV / 'p189_capture_run_fragment.py.txt').read_text(), namespace)
    payload = b'input-with-NUL\x00\xff\n'
    stdout = b'full-stdout-' * 400 + b'\x00\xff\n'
    stderr = b'full-stderr-' * 500 + b'\x00\xff\n'
    outer = []
    for index, (label, code, delay, error_type) in enumerate([
        ('normal', 0, 0, None), ('nonzero', 7, 0, RuntimeError), ('timeout', 0, 10, subprocess.TimeoutExpired)], 1):
        command = [sys.executable, '-c', 'import sys,time;sys.stdin.buffer.read();' +
                   f'sys.stdout.buffer.write({stdout!r});sys.stdout.buffer.flush();' +
                   f'sys.stderr.buffer.write({stderr!r});sys.stderr.buffer.flush();time.sleep({delay});raise SystemExit({code})']
        caught = None
        try:
            result = namespace['run'](command, data=payload, timeout=1)
            assert result.returncode == 0 and result.stdout == stdout and result.stderr == stderr
        except (RuntimeError, subprocess.TimeoutExpired) as error:
            caught = type(error)
        assert caught is error_type, (label, caught, error_type)
        directory = out / 'subcommands' / f'{index:06d}'
        assert (directory / 'stdin.bin').read_bytes() == payload
        assert (directory / 'stdout.bin').read_bytes() == stdout
        assert (directory / 'stderr.bin').read_bytes() == stderr
        report = json.loads((directory / 'result.json').read_text())
        if label == 'timeout':
            assert report['timeout_expired'] is True and report['actual_process_returncode'] is None
        else:
            assert report['actual_process_returncode'] == code and report['timeout_expired'] is False
        outer.append({'label': label, 'expected_exception': error_type.__name__ if error_type else None,
                      'actual_exception': caught.__name__ if caught else None, 'raw_bytes_match': True,
                      'report': str(directory / 'result.json')})
        write_json(root / 'OUTER_RESULTS.json', outer)
    write_json(root / 'SUMMARY.json', {'purpose': 'repo外小mock工具自證，不是產品驗收或P189效能',
               'product_sha': None, 'outer_cases': len(outer), 'sample_cases': 6, 'seven_modes': 2,
               'full_binary_streams_over_1000_bytes_with_NUL': True, 'pass': True})
    print('outer journal 小mock三案全符；沒有執行產品或push', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
