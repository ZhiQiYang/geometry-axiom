W codec 候選已撤回；未編譯、未執行診斷。

`PREPARATION.json` 與 `prepare.*.txt` 保存本次純檔案準備命令及完整拒絕輸出。準備器確認 HEAD／working 函式相同而以退出碼 1 拒絕偽造差分。規劃的 152,243 次比較從未執行，不能視為通過。第一次相同原因拒絕曾先出現在工具通道；此處是候選撤回後重新保存的同一純準備命令收據。

保留實際舊候選 snapshot 路徑與 SHA256，兩個 `.py.txt` 為準備器／未執行 runner 原碼。這些均不取代永久 full/narrow 回歸、native、mutation 或最終來源驗收。
