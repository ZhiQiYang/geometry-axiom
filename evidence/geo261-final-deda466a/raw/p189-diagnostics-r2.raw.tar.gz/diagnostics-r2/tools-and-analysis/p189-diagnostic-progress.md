# P-189 紅燈後的排他診斷

正式受驗來源仍為 f2c8837a；P-189 原 N48=2.076654×、N64=2.25× 紅燈不變。其他完整驗收收據與 Q38 環境修復結果均保留。下列試驗不能取代新最終來源的完整驗收。

1. 原交接 -O1/fno-inline/pg 方法對 f2 與 main 各做一次 profile，真實 load 退出 0。再用新獨立 -O2/pg 工具對 f2 做一次診斷，完整記原／新工具與 hash、diff、實際命令及原輸出。O2 profile 主要明確成本為 placement 定義讀取；support 符號歸因有疑慮，未據此修改 support。
2. 原非 pg O2 bridge 單次 fresh-helper rusage：wall 1.320507 秒，user 1.271229、sys 0.048556，RSS 60192 KiB，major faults 與 I/O blocks 均 0。GNU time 未安裝，沒有偽造 time -v 輸出；用 Python 標準 RUSAGE_CHILDREN，完整 helper／命令／原串流另存。此筆不足以豁免正式效能紅燈。
3. 固定寬度 wd_read 展開候選：正式 O2 build 退出 0，三方 main／原 f2／候選交錯 36 樣本；N64 candidate/old=0.96891、candidate/main=2.30458，未達標。已撤回全部產品改動，不採用。建置啟動第一試漏設 reaper log 而在啟動器 KeyError 退出，尚未編譯；原 stderr 保留，補環境變數後的實際 build 另存。
4. boundary 預先去重候選：完整 cap／成對收集後先去被邊界覆蓋的 member 面；三方交錯 36 樣本，N64 candidate/old=1.01869、candidate/main=2.40181，未見收益。已撤回全部產品改動，不採用。區間傳遞性分析保留；準備但未執行的差分診斷不宣稱通過。
5. raw footprint 省工與 node/key 合併配置只做靜態評估，未採用：前者收益估計低且延後補算可能改 raw snapshot；後者會破壞原具名必要配置失敗斷言。沒有放寬測試來套候選。

所有候選都保留原門檻與取樣，沒有挑綠重跑。未採用試驗的二進位只保存 hash，封存內容保留 source patch／來源與方法／完整 stdoutstderr／原退出／36 個樣本。

下一步是純 W canonical placement 窄讀取候選：保持一次同型來源請求，完整驗原 schema／kind／id／bounds／三個字串長度與 trailing bytes，只取 H 擋面所需 placement／direction／order，不新增快取。先做差分及排他量測；若成功再做撤回自證、帳本 freshness 判定及整份重產、架構四檔與新最終 SHA 完整輪。現在不宣稱修好或可合併。
