# 下一個純 K 省工候選：沿用 edge 查找空槽

此候選只產生在 repository 外；root未改、沒有編譯／執行／profile。完整exact diff位於 `p189-edge-probe-reuse-candidate/candidate.patch`，同目錄含source.c副本及baseline/candidate hashes。baseline含當時尚待量測的node-hint候選；diff本身只碰find_edge簽名、空槽輸出與edge append分支，可由root核對適用來源後決定。

## 1. 現有重複工作與新流程

現行新edge路徑先在 `geo_source_find_edge` 對三元組hash、probe，確認不重複且找到空槽；接著grow/append edge，再進 `geo_source_index_append(false)` 對同一個edge重新hash、重新probe同一張表。

提案讓find_edge多一個 `size_t *vacant` 參數。只有正常index probe遇到空槽才填它；caller預先設 `SIZE_MAX`。edge成功append後，若vacant有效且新edge_count仍≤原edge_index_capacity/2，就直接令該槽為新edge_count（原插入序號+1）；否則仍走完整原index_append，包括擴表、配置失敗、捨棄index改linear等全部行為。

這段時間只有edge資料陣列的realloc，不改edge_index、capacity或其他index槽，且沒有provider／使用者callback，所以剛找到的空槽不會失效。realloc可能搬移edge陣列不影響index所存的插入序號。仍然每次做完整三元組dedup，沒有略過source calls、邊或guard。

沒有新增context狀態、持久cache、配置、模型容量或API。vacant只是同一次內部函式呼叫的暫存結果。若grow失敗，仍在寫入edge/index前回原MEMORY；若需要擴表，新count與原threshold判斷一致，仍進原配置／fallback。原allocation nth順序不變，因被省略的index_append呼叫本來就不需配置。

## 2. 收益依據與限制

`/tmp/g261r1/profiles-o2/load-profile-f2c8837a-n64/flat.txt` 原O2 profile共有2,980,967次source/edge入口；callgraph將1,531,178次index_append歸於geo_source_edge、238,679次歸於node，總1,769,857次，index_append self約7.27%。所以這是大量新edge的實際重複工作，不是只改善稀有分支。

但7.27%包含擴表重hash全部舊entry的成本，新提案不省這一段，不能承諾把整個7.27%拿走，更不能直接宣稱足夠剩餘9%。它能省絕大多數非擴表新edge的第二次hash/probe及函式調用，實際收益仍需非pg原方法交錯量測。

## 3. 原8個source-index控制

- `geo_source_find_edge(` marker仍存在，控制函式可照原擷取body。
- `while(ctx->edge_index[slot]){` 與edge_equal原錨點逐字保留。
- never-edge在函首returnfalse，沒有寫vacant；caller的SIZE_MAX保證走原index_append，仍建立重複edge，由duplicate-edge具名斷言抓到，沒有讀未初始化值。
- edge-probe-miss在occupied槽提前returnfalse，同樣沒有填vacant，走原append，仍重複。
- edge-probe-hit與edge-kind-ignored錯誤返回true時仍直接跳過append，應保留原missing-edge紅。
- node四個控制與此次edge diff無關；若與node-hint合併，另外依node-hint風險表驗其遮蔽情況。

caller初始化不可搬到find_edge內，否則函首never-edge控制會使slot未初始化。也不能在正常miss後無條件直寫slot，因index可能空缺、容量可能需要成長、控制也可能提前false。

## 4. contact_world 的 stable upper_bound 評估

原穩定insertion sort用 `previous<=order` 決定停止，因此同order的兩側與宣告順序保持原樣。可改成upper_bound找第一個order>目前值的位置，再做單次memmove，不需額外order陣列；語意上可保留duplicate-ID的last-order、UINT64_MAX與boundary prefix。

但這個N64生成場景逐筆 `timber 1/place 1`、`timber 2/place 2` 至64，宣告與placement順序相同。原O2的 `contact_order` 2,729,508次除以12,942次collect約211次／collect，接近既有已排序路徑的sort約2F加dedup約F，估F約70。這支持「原sort大多不移動」而不是大量逆序移動。

因此無快速尾端檢查的binary insertion會將每個已排序face的一次previous hash變成logF次，反而更慢；加 `last_order<=order` 快速分支則正常場景與原路徑相同，幾乎不省hash。單次memmove只在少數逆序輸入受益，原contact_order self也僅約1.82%，不宜當成當前P189的優先候選。

另外現有placement-order／stable-ties負控只改唯一 `if(previous<=order)break;`；若新增獨立binary comparator，錯誤fast-path可能被正確upper_bound補救，讓stable-ties負控等價。真要採用需將所有排序位置決策共用一個比較原語、機械更新其負控注入點並保持具名紅，不得只把原控制留在已可被補救的分支後宣稱有驗。基於收益與測試風險，本次只提供edge probe reuse exact diff，沒有改contact sort。
