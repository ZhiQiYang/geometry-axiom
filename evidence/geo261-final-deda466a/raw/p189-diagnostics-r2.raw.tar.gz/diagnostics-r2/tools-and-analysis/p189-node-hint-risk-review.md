# K node 身分 hint 候選：等價範圍與控制遮蔽分析

本子代理只改 root 的 `geometry-core/kernel/source.c`，14行diff（12新增、2刪除）；其餘原有兩個dirty tests未碰。沒有編譯、測試、profile、commit或push。候選 SHA256 `900c89612d7d72dfe9a2f09d52ef9351ae2520446fe0bcf71cb5e1dc33967dc4`，完整diff與metadata在 `p189-node-hint-candidate.patch/.json`；它不是已通過收據。

## 1. 改動與等價理由

ctx新增固定 `size_t node_hint[256]`，每槽只存既有node插入序號+1。選槽為 `(provider ^ key_size ^ first_byte ^ last_byte) & 255`；空key不讀bytes。這個混合不被當成身份判斷，命中還須 `hint!=0 && hint<=node_count && geo_source_ref_equal(owned_source,request)`，最後完整比較provider、key_size與每個key byte。

只有原 `geo_source_node` 輸入合法且照舊設started之後才讀hint。命中只省原find_node，回傳相同index；miss仍走原hash index／linear fallback，found與新node完整append成功後更新hint。兩個必要node/key配置、grow、可選索引fallback、hash函式、插入／列舉順序原樣。

caller傳入key中段bytes變了，即使首末與slot相同，完整owned-key比較仍拒絕舊hint；對既有其他key能找到同一舊node，否則照舊新建node。hint不持有caller pointer，也不保留value或新的candidate資料。reset／destroy沿原clear清零整張hint；create原calloc自然全零。沒有新配置次數，但ctx配置大小增加256×sizeof(size_t)（LP64約2KiB），可能增加建立／清理成本。

edge/state/cycle/retry/provider求值流程在 `geo_source_node` 返回後原樣；hint不把ACTIVE／FAILED當VALID，也不跳過edge。sealed source／describe原本直接呼叫find_node，其路徑完全不動。range guard即使遇到過期或測試注入的索引也不解參考越界；reset清0仍必須有真實負控，不能只靠range guard聲稱已清。

256是內部輔助索引槽數，不改模型member64容量，不增加可接受物件或新的產品數值門檻。

## 2. slot 的成本與分布界線

選槽只需xor、兩個byte load與mask；不重算原FNV，也不加helper call。刻意讓first byte的映射是係數1：現有source-index harness的大量12-byte refs在LE雲端以首byte循環、末byte0xa5，因此遍歷256個值會覆蓋所有hint槽，能把最初32個強制FNV碰撞鍵逐出hint。若把first左移一位，末byte差異可能造成奇偶槽分離，反而把那32個鍵保護住，遮蔽舊hash probe控制。

首末xor在1-byte key會抵消，這一族只按provider與size選槽；完整比較仍正確，但hint命中率會差。5-byte W definition keys通常是kind+u32 id，首末各能參與選槽。17-byte contact keys若只在中段query id變化仍會同槽，這是允許的衝突，不得為提高命中而省完整比較。實際省時與ctx額外清零成本必須量測，不能先宣稱收益。

## 3. 舊8項控制的靜態評估

來源為 `tests/test_geo261_source_index.py:83–126`，控制程式／具名斷言均未改。

| 舊控制 | 可能被hint遮蔽嗎？ | 本候選靜態判斷 |
|---|---|---|
| never-node → duplicate-node | 部分重查可以被hint救回 | 原nodes案例有1536個大於256槽的不同身份，反序重查必有hint miss；find_node永遠miss仍會建立重複，應保留具名紅。 |
| node-key-bytes-ignored → merged-node | 不會形成救援 | 同一個ref_equal也被hint使用；錯誤判等只會更早誤合併。原32個同FNV槽不同key仍走舊誤合併路徑，預期同名紅。 |
| node-probe-miss → duplicate-node | **最需要防遮蔽** | LE雲端原MANY refs的首byte遍256、尾byte0xa5會先逐出所有強制碰撞鍵；反序掃到最初32個時，hint保留的仍是尾byte0xa5的其他ref，不可能完整比對成功，因此必重走原probe。除home第一鍵外的碰撞鍵仍重複。這是靜態推導，仍要實跑具名紅。 |
| node-probe-hit → merged-node | 不會形成救援 | 第一輪新不同身份的hint完整比對不會誤中；強制hash碰撞鍵必走原probe-hit錯誤並合併，原首輪merged-node斷言仍有牙齒。 |
| never-edge → duplicate-edge | node hint不改edge查找 | 每次仍經原geo_source_edge，原錯誤仍重複邊。 |
| edge-kind-ignored → missing-edge | 同上 | 原consumer/source/kind三元組查找原樣。 |
| edge-probe-miss → duplicate-edge | 同上 | 同槽邊的原probe原樣。 |
| edge-probe-hit → missing-edge | 同上 | 同槽邊與只差kind的pair原樣。 |

跨架構注意：harness使用 `memcpy(key,&i,sizeof i)` 產生首byte，其分布有host endian因素。上面的256槽逐出證明明確限定目前LE雲端與一般Windows x64；不能只憑此宣稱所有ABI的node-probe-miss永不被遮蔽。若需要portable強制覆蓋，應增加透過真實API製造hint衝突／逐出的fixture，保留原oracle與原具名斷言，不把「hash控制被輔助hint救回」當成控制已殺。

## 4. 正式採用前必驗的新增風險

- 相同provider/size/首末byte、只有中段不同的key不能誤合；完整u32 provider、key_size與zero-key身份也須獨立驗。
- caller buffer在首次請求後改動，同首末中段變更仍必新增或命中正確其他owned key；舊node key/value不受改動。
- 同槽不同身份來回切換只影響命中率，不改完整有序圖；hint hit仍新增適當dependency edge並照舊報ACTIVE cycle／FAILED retry。
- reset後同位置的新node、清空provider後重註冊、清0負控與out-of-range hint均不可誤用舊身份。
- 原allocation nth-failure與index fallback／exact-size grow測試仍須全過。沒有加malloc/calloc呼叫，所以ordinal應不變；ctx calloc元素大小變大不觸發既有 `n>=16 && s==sizeof(size_t)` 索引配置代理規則。
- 需要一個只撤hint（回原source.c）的效能對照，採原P189四點門檻、同main/base/final方法；語意對照仍是175 dump bytes、完整node/edge序列與五guard counts，不因hint是輔助就省掉。

如果效能不足，不應改模型容量、放寬身份完整比較、改hash碰撞oracle或將hint擴成H member value cache。先保留真實量測，再決定是否採用。
