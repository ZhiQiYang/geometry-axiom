# #288 f2c8837a 的 P-189 效能唯讀分析

> 後續決定（2026-10-22）：root 取得本輪 f2 N64 新 profile 後，`wd_read` self=18.82%、43,503,376 次；`app_contact_facts` children 只有約2–3.5%。以下 A 的 raw-footprint 候選因此**未採用**，root 優先試 B。A 曾按授權製成 43 insertions/6 deletions 的兩檔候選，未編譯或測試；已只將這兩檔逐 bytes 還原當前 HEAD，確認 `git diff`、`git status` 乾淨，CRLF 完整保留。完整未採用 patch 存 `/workspace/geo261-environment/p189-raw-footprint-unadopted.patch`。不應將本文初步排序讀成現行實作或通過結論。

> A 的額外風險：舊 helper 是在所有 typed member 請求**之前**算好 raw geometry；`reference_compute_timber` 會更新借用的 World timber cache。若把 excluded／foreign placement／invalid face／source failure 的 raw 欄位改成「需要時才補算」，補算可能讀到前一筆來源評估已更新的 timber geometry，與舊的初始快照不同。即便 W 最後跳過這些 facts，也不能宣稱 callback 全輸出或 partial-error bytes 無差異。要嚴格保留需前置辨認分支或另存原始 geometry，反而增大 diff 與成本。這支持停止 A，而不是只依低 profile 百分比下注。

受驗來源固定為 `f2c8837aeba3c49eacbd77b5161f07c819204263`，讀取 `/tmp/g261r1/source-final`。本次只讀現行原碼、既有 profile 與既有 P-189 收據；沒有編譯、profile、執行產品或測試，沒有更動 repository、分支或推送。

目前最有把握的改善方向是 **保留每一個既有來源請求與其順序，減少請求前後的重複純計算**。不建議在 #288 引入 #323 的 `member_reads` 或 contact collection cache，也不能直接刪掉看似重複的第二次來源掃描。可先合併下列 A、B 兩個小改動作一次候選；C 是較大但仍限單次函式呼叫的備案。30% 是本次希望取得的餘裕，現有資料不能當成已證實的加速；正式裁判仍是原定每個 N 的 fix/main ≤2。

## 1. 紅燈與證據的適用範圍

`/tmp/g261r1/tools/p189-f2c8837a/receipt.json` 記錄 GCC 14.2、`-std=c11 -O2`、stack 16384、main/base/fix 與反序交錯、3 輪共 36 筆；175 個 loadfile+dump 全部逐 bytes 相同。

| N | main 中位秒 | f2 中位秒 | f2/main |
|---|---:|---:|---:|
| 16 | 0.1723 | 0.1542 | 0.8949507 |
| 32 | 0.2299 | 0.3421 | 1.4880383 |
| 48 | 0.3431 | 0.7125 | **2.0766540** |
| 64 | 0.6256 | 1.4076 | **2.25** |

以這輪 main 為參考，N64 降到 1.2512 秒可剛好碰 2×（約減 11.12%），減 30% 則約 0.9853 秒，會有合理餘裕。但不能拿這個推算當新量測，不能只保留較快的樣本。

既有 N48 profile `tests/evidence/geo261-source-index-20261020/gprof-summary.log:7` 的符號計數包括 `wood_contact_collect_stops` 7,422、`contact_order` 1,166,356、`wd_read` 18,888,808、`timber_a0_footprint_uv` 624,994、`geo_frame_project_uv` 1,419,525、`geo_vector_dot` 5,462,805。其 self 只有總共 0.35 秒且 `_init` 20%，只能指出重複工作與候選，不能精確估算今日 f2 各函式百分比。

舊 #323 分支 `f3ea9c5232c043b3dca57b953577f5d22e9030e7` 的 `tests/evidence/geo261-load-residual-20261020/profile-counts.json` 另記 base N64 `wd_read` 43,503,376 次，帶完整 cache 後 370,680；這證明解碼次數有放大結構，但不是 f2 profile，也不授權移植那個 cache。

**已存在的改善不要重做：** f2 `geometry-templates/woodworking/native/contact_world.c:25–63` 已有查詢內的 `ContactOrderIndex`，保留重複 ID「排序看最後一筆、遮蓋看最小 order」兩種語意，member_count>64 走舊線性 fallback。`evidence/geo261-cloud-order-index-82e0db0b-r2-receipt.json.txt` 的歷史 N64 new/old=0.8377（約省16%）已是現行來源的一部分，不能再把其收益計入新候選。

## 2. A：移除 source 模式不會使用的 raw footprint 純計算

### A1：`reference_contact_facts` 的 raw footprint 建立後立即被來源值覆蓋

`geometry-app/native/reference_sources.inc:568–604`：

1. 574 以實際候選來源取得 host。
2. 575 呼叫 `app_contact_facts`。其 `current_geometry.c:5779–5782` 對全體 member 都跑 `timber_a0_footprint_uv`，依 raw anchor、raw timber 幾何建立 footprint。
3. 581 跳過未 placed 與 pointer-identical exclude。
4. 非 current 模式 583–587 仍從同一 graph 解碼實際 anchor、order、direction。
5. 588 排除實際其他 placement。
6. 唯一讀到 raw `footprint_valid` 的 589 有 `ctx->use_current_values` 前提；**非 current 模式完全不用第 2 步算出的 raw footprint**。
7. 590 仍請求實際 BOX；591–602 以其 frame/extent 重算 A0 四點與投影，寫回 footprint/valid。

這是可直接由控制流確認的冗工，不涉及公理語意或來源圖。建議抽出共同的 H facts 初始化，讓 source callback 使用「host/成員身份與 raw anchor metadata，但不算 raw footprint」路徑；current/fallback 路徑仍完整計算。可以加顯式 `bool` 初始化參數或分出 metadata initializer，但不要用隱藏全域狀態判斷，也不要為了消除小重複而改動多個無關生命期。保留原有 member pointer 身份，且 **583–602 的所有來源呼叫與錯誤順序原封不動**。

不需要也不應先按 raw anchor placement 篩掉成員：實際 provider 可以返回不同 placement，現有 host authority harness 就是在驗此點。source 模式也不能將 raw footprint 當 memo。

### A2：`app_reference_end_faces` 在 resolver 前不需要 raw members 幾何

`reference_sources.inc:663–675` 在 670 再做一次完整 `app_contact_facts`。但 W `contact_world.c:150–157` 的 resolver 前只做 `role_boundary` interval/span-extension 判斷，不讀 members；H resolver `reference_sources.inc:658–659` 會在 W 後續使用 members 前把 `target->members/member_count` 換成 source facts。

因此這條 **非 current 專用** 外層也能使用 host-only/metadata 初始化，省去一次全體 raw footprint 投影。要保留 672–673 所述原時機：span-extension 先於 source failure，不能把來源 callback 移到 W span 檢查前。

`collect_stop_faces`（`current_geometry.c:5857`）也有「raw facts 先算、source handled 後不用」問題；其重構牽涉共用 resolver 與三個 delegation 形狀，建議第一候選只做 A1/A2，避免不必要擴大 diff。

### 為何不能直接只保留一次 `reference_contact_facts`

同一次 end_faces 會在 H `app_reference_end_stops:658` 取得成員 facts，然後經 `app_contact_resolve_stops` → `wood_contact_sources_collect` → W collection evaluator `contact_sources.c:95` 再呼叫一次。前者為 W 端面 owner/extension 提供實際 facts；後者處在 collection consumer 的 active source stack 下，建立 **collection→anchor/BOX/frame** 的邊。刪第二次來源呼叫、直接把第一次 facts 塞給 callback，會改圖的依賴與有序輸出；不能只憑 dump 相同宣稱等價。

## 3. B：讓 W 的固定寬度解碼使用固定寬度操作

`geometry-templates/woodworking/native/definition_sources.c:17–18` 的 `wd_read(r,bytes)` 每次以 runtime `bytes` 逐 byte shift。`wd_placement_read:58–67` 解完整 member anchor，大量 1/4/8-byte 讀；`wood_definition_sources_placement:77–78` 每次已有 memoized definition 仍會重跑這個純 decoder。這與先前 profile 的數千萬 `wd_read` 一致。

最小候選是在原本 bounds/ok 檢查後，對 `bytes==4`、`bytes==8` 寫出明確的 big-endian unsigned load，再讓其他寬度走原 loop。使用逐 byte 的顯式 unsigned shift expression 可讓 GCC 將其辨認成 load+byte-swap；不要以未對齊的 `uint64_t*` cast 讀取，不要假設 host endian，也不用加 OS 專屬庫。保持下列行為：

- `!ok` 或剩餘長度不足時，`ok=false`、回0、`at` 不變。
- 成功只將 `at` 增加指定寬度一次；`bytes==0` 仍回0且不前進。
- unsigned 組合與 `wd_signed` 的負值語意不變。
- 不改 `wd_get`、`wd_reader` 的 graph 請求、schema、內容大小／實際 id 檢查。

這是 pure decoder 改善，不增加 cache、lifetime、provider/node/edge，也不減少驗證。不過 GCC 的實際 inlining/codegen 是否已消除部分成本，目前未檢查組譯、未編譯；真實收益必須量測。若 parent 另一來源分析發現 K 自身更高成本，可先選擇其更小候選。

## 4. C：contact 去重只掃同一個 fixed coordinate 的候選

`contact_world.c:106–115` 雖已有 order 索引，仍對每個 member face 掃全部 `count` face；只有 `fixed` 相同才可能進遮蓋判斷（109）。正常 N64 約128個 member face，並在每個 command/candidate 重驗下反覆執行。這是明確的局部 O(F²)；A/B 不足才建議做這個較大改動。

可在 **本次 `wood_contact_collect_stops`** 內，用 full signed 64-bit `fixed` 當 key 建 hash bucket，保留原始 faces 與一份 `alive` 狀態；每個 i 只走同 key 的仍存活 j，其餘原條件、`contact_earlier`、完整遮蓋判斷原封不動。處理 i 的順序仍照原 sorted order；判完才 stable compact。不能簡化成「只看 sorted i 之前」，因 duplicate ID 的 last-order/min-order 語意可以讓較後的 face 滿足 earlier。

重要細節：

- face 的產生、cap 截斷必須在 sort/dedup 前；member 兩側 cap 原子性不變。
- equal-order 保留、FREE boundary 仍可遮掉同線 member、partial overlap 保留 exposed face。
- 不能只保留每個 fixed 最長區間：多個不相容 earlier/order/id 與範圍會改語意。
- `alive` 必須逐 i 更新，不能讓已刪除 face 在後續當 blocker。尤其 duplicate-ID 非傳遞情況不宜假設「刪除 blocker 也一定有更早且更寬 blocker」。
- scratch 要界於原 `WOOD_CONTACT_FACE_CAPACITY=2432`，不改容量；超出可索引範圍保留舊 loop fallback，與現有 order-index 的策略一致。
- 不讀 out[count:]。若要連原 collector 對已刪除尾端的 bytes 也一併保留，舊 memmove 結果會把原最後一個 face 留在每個刪除尾位；可在 compact 後以保存的最後 face 填原 count 的尾段，而不碰原 count 之外。至少要明確驗證 API 原本要求的輸出範圍與 untouched-capacity tail。
- 新 helpers 都屬 W，需跟著更新架構 manifest 的 W identifier 禁入 K 清單，不能只刷新 hash。

現有語意控制錨點 `tests/test_geo261_wood_contact_world.py:68–90` 與 `tests/test_geo261_contact_sources.py` 的 order-index controls 不能被刪或放寬；若原碼形狀變了，應只機械調整唯一注入點並維持每個具名紅燈。

## 5. 候選的驗收與撤回自證

1. 優先一份候選做 A1/A2+B（沒有新跨函式 cache），保留 f2 原始來源與 binary 以便撤回比較；不修改固定 f2 evidence。
2. 局部正確性先跑既有 host-facts-authority、contact_sources、wood_contact_world、definition_sources、source-index 與 PF3 等對應 suites；新 decoder 可加一個獨立線性 byte oracle 驗 0/1/4/8 及一般 width、大小端極值、truncated reader、已失敗 reader，驗值/at/ok 三者。這個 oracle 是資料格式相容性的驗證，不是 assertion 改成新實作的鏡像。
3. 用現有 P-189 原門檻作修正撤回的可觀察差異：撤回到 f2 候選應重現具名 N48/N64 ratio 紅，套回後全四點綠；每態交錯 main/base/fix、保留所有36筆與原輸出。若 A/B 單獨撤回仍在2×內，應如實稱其等價省工，**不可發明新數值門檻或宣稱單獨有撤回紅**；可以對這份合併 perf fix 做整體撤回自證。
4. 175場景 bytes、完整有序 node/edge 與五個 P-177 守門計數應對照；尤其 A 的來源呼叫原封保留，預期圖也逐序一致。不能只驗邊集合。
5. 最終產品／測試 commit 後先 `tests/mutate.py --check` 決定整份帳本是否過期；H/W/code source 改動要重產 Linux 架構 manifest/scan/report/receipt，然後新固定 SHA 重跑完整清單。對帳本及架構收據的影響不可因本次效能 diff 小就省略。

## 6. 最不確定處與不建議做的事

最不確定處是 A/B 的合併效益能否達30%；手上沒有 f2 新 profile，歷史採樣短且 O2 gprof nearest-symbol 歸屬有誤差，無法保證。C 的複雜度收益較可推論，但實作與 mutation 控制形狀的風險高於 A/B，應由最小候選的真實量測決定是否需要。

不建議為效能改 P-177 candidate/create/validation/seal/publish 次數與時機、合併 query identity、略過集合／特徵來源請求、跨 candidate 留 memo、增加容量、改公理或門檻；也不要移植 #323 的未驗證 never-invalidate 等價突變當成自證。所有這些都超出上述純計算改善。
