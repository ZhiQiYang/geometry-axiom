這份清單只準備repo外小檔封存，不執行測試、壓縮、commit或push。六個候選現在均已完成36個有效樣本，六個diagnostic wrapper都exit1；不能將原scale driver0或build0寫成效能通過。來源是deda466a＋各當時dirty patch，不是fixed final SHA。

| 候選 | old側 | N16/main | N32/main | N48/main | N64/main | N64/old |
|---|---|---:|---:|---:|---:|---:|
|sourceview|551|1.029192|1.695824|1.997434|2.413152|1.015818|
|hint|551|1.019167|1.577627|2.063808|1.871964|0.885356|
|edge|dirty hint|1.108252|1.519774|1.798459|2.395140|1.070195|
|hashword|551|1.100076|1.533170|1.824624|2.203979|0.972753|
|hashhint|dirty hashword|0.786509|1.618033|1.921524|2.074731|0.927001|
|combinedcodec|dirty hashword＋hint|1.021486|1.676966|1.920969|2.202305|1.007026|

來源snapshot、patch、完整命令/原退出/原stdoutstderr/環境/版本與provenance均列入；candidate binaries與profile work不收，只記原執行hash，小gmon可收。原551正式三方preflight已在deda公開，本包不重收；其reference SHA/hash仍保留於各diagnosis。

collect_perf_diagnostics_r2.py只在root後續執行時複製列明小檔到指定新out，不壓縮、不執行外部命令、不改repo。輸出的publish-input.args.json可供root的publish helper讀取。publish_progress會跳過profile-*路徑，因此dirty profile在包內命名hint/o2pg。
