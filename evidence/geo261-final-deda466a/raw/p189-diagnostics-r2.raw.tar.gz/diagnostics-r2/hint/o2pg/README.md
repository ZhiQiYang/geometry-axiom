這是未commit的K node_hint候選之單次O2-pg N64診斷，不是最終驗收。來源基底551b00f6，快照時HEAD為deda466a818a5375a693c433cf4e030a36b4dc5a，唯一產品dirty路徑為source.c；source patch、每檔hash、實際source.c、bridge hash、完整命令與原輸出全部保存。SNAPSHOT_READY後root可繼續改自己的產品；受驗work在本次執行前後逐bytes穩定，沒有吃進後來edge候選。

原profile退出0、load ok=true；約51採樣。主要self項：geo_source_node15.69%、eval_source7.84%、rawfootprint7.84%、完整placement解碼7.84%、facts5.88%、edge3.92%、index_append3.92%。support_coord_compare5.88%仍有clone鄰近符號歸因疑慮，不能當support排序成本；本次保留pg bridge與gmon供必要核對。完整callgraph在raw/callgraph.stdout。

所有數字只定位成本，不能當正式P189綠燈。root可續做edge候選；本代理不再跑重型。
