# K node hash 分塊候選（僅唯讀準備，尚未編譯或量測）

候選差分是 `candidate.patch`，只更動 `geo_source_node_hash()`。來源快照與候選全檔都在本目錄的 `.c.txt`，沒有寫回 repository。

## 可行性

- `uint64_t word; memcpy(&word,key+i,sizeof word)` 沒有未對齊載入或 strict-aliasing 問題；所有 bit pattern 都是有效 unsigned integer。
- hash 只選本次 `GeoEvalContext` 記憶體表的起始 probe 槽，沒有公開／持久化 hash。host byte order 會改變槽位；它不改 provider/key-size/完整 bytes 相等判斷、不改公開節點或邊的插入序。
- 空 key 不讀記憶體。`key_size-i >= sizeof(uint64_t)` 保證每個 memcpy 範圍有效，也保證 `i += sizeof word` 不溢位；尾段逐 byte 讀取。長度已參與初始 hash，不用字串終止符、忽略 embedded NUL 或省略任何 key bytes。
- 8-byte 內部混合仍使用既有 `geo_source_hash_size` 的奇數 multiplier，但直接以 uint64 運算，不把 word 縮成 32-bit 平台的 size_t。`hash ^= hash >> 32` 讓每個 word 的高位參與低位槽位選擇。
- 這是普通索引 hash，不是密碼學 hash，也不保證不同 key 的 hash 不撞。完整 `geo_source_ref_equal()` 與原線性 probe 仍是正確性裁判。

## 省工根據與限制

| key 大小 | 原逐 byte multiply | 候選 multiply | 說明 |
|---|---:|---:|---|
| 5 | 5 | 5 | W definition key，僅多分塊條件，預期沒有收益 |
| 12 | 12 | 5 | source-index 行為夾具 |
| 17 | 17 | 3 | W contact query/feature key |
| 64 | 64 | 8 | W grid source key |

每 word 還多一個 shift-xor，CPU 也要 load；上表是靜態 dependency-chain 數，不是實測加速倍數。O2 原 profile 沒有獨立 node-hash sample/count，它可能 inline 在 find-node／index-append，不能把 `support_coord_compare` 的 10.91% 宣稱為本候選可省份額。原 `geo_source_index_append` 7.27% 混有 edge 與 node，也不能全算在這個候選。全程收益目前未知；只有固定編譯、原交錯量測能判定是否保留。若主要查找已命中 hint 或 5-byte definition key，本候選可能無收益甚至略慢。

## 原裁判與其他影響

- 原 source-index 6 個行為方法與 8 個負控都不需改錨點。Python 負控錨點在 equality/find-node/find-edge，候選一個也沒改。
- nodes 夾具用當下 `geo_source_node_hash()` 動態搜尋 32 個 `&4095 == 4095` 的 key，仍測相同主表碰撞目的，不需要重寫 key。搜尋分布與耗時必須實跑確認，不能把編譯失敗、搜尋逾時或 crash 算成負控被殺。
- `node-key-bytes-ignored` 與 `node-probe-hit` 仍預期在第二個同槽 key 報 `merged-node`；`node-probe-miss` 仍預期在逆序查詢被推後的主表碰撞 key 報 `duplicate-node`。hint 的普通 1536 key 覆蓋 256 提示槽前提沒有改。
- `never-node` 仍有超過 256 個 identity，逆序回讀必有 hint miss；原 missing/invalid/cycle/failed/sealed 流程沒有變。四個 edge 負控的 hash 與 probe 完全原樣。
- 沒有改 allocation、必要 node calloc/key malloc、index 成長容量或降級路徑；nth1/2 的 `MEMORY` 要求保留。資料分配與公開 insertion-order 不由 hash 決定。
- `tests/mutate.py` 原 literal 錨點沒有引用這個 hash 函式或 multiplier；但 source.c 在 unity closure，採用後整份帳本會 stale，需依規則整份重產。這不是免重產的證明。
- source.c 已登記 K 層；沒有新 include、外部 API 或 W/H identifier，所以不預期新增架構邊／政策名稱。檔案 bytes 變了，仍需重產 manifest/scan/report/receipt 並跑原三條架構裁判。

## 採用前最低驗證

1. 先固定候選 bytes/hash 編譯並原交錯四點診斷，原門檻與取樣不改。
2. 原 source-index 全 14 方法，含全部 8 個具名負控／恢復；不能刪、降級或改控制讓它過。
3. 新候選要與原 byte-hash source 以同一 provider/key sequence 跑 node/edge/status/value/列舉差分，含 0..17 長度、63/64/65、未對齊、embedded NUL、高位 bytes、只差最後一個 bytes、caller buffer 重寫、reset/sealed。
4. 恢復舊 hash 的效能紅與候選綠若未形成，不宣稱完成此修正的撤回自證。原完整 native／browser／專項與最終 SHA 綁定仍必須重新跑。
