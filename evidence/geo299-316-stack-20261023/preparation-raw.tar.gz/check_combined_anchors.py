"""Read the existing registry as syntax; never import or execute the ledger."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/tmp/g261-next299316')
OUT = Path('/workspace/geo299316-refresh-20261023/anchor-check')
OUT.mkdir(exist_ok=False)
registry = (REPO / 'tests/mutate.py').read_bytes()
tree = ast.parse(registry.decode('utf-8'))
rows = []
for node in ast.walk(tree):
    if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or node.func.id != 'dict':
        continue
    values = {}
    for field in node.keywords:
        try:
            values[field.arg] = ast.literal_eval(field.value)
        except (ValueError, TypeError):
            pass
    mid = values.get('id', '')
    if mid not in {f'M{i}' for i in range(89, 99)}:
        continue
    path = values.get('file', 'current_geometry.c')
    raw = (REPO / path).read_bytes()
    normalized = raw.replace(b'\r\n', b'\n')
    old = values['old'].encode('utf-8').replace(b'\r\n', b'\n')
    count = normalized.count(old)
    rows.append({'id': mid, 'file': path, 'source_sha256': hashlib.sha256(raw).hexdigest(),
                 'old_sha256': hashlib.sha256(old).hexdigest(), 'anchor_occurrences': count,
                 'line': node.lineno, 'compiled_or_executed': False})
    assert count == 1, (mid, path, count)
rows.sort(key=lambda row: int(row['id'][1:]))
assert [row['id'] for row in rows] == [f'M{i}' for i in range(89, 99)]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
result = {'schema': 'combined-299-316-static-anchors/1', 'head': head,
          'registry_sha256': hashlib.sha256(registry).hexdigest(),
          'rows': rows, 'all_ten_anchors_unique': True,
          'not_a_mutation_execution_or_freshness_check': True}
(OUT / 'ANCHORS.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'head': head, 'count': len(rows), 'unique': True,
                  'not_a_mutation_execution_or_freshness_check': True}, ensure_ascii=False))
