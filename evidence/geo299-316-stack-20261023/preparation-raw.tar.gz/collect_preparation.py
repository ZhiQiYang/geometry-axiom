"""Small read-only snapshots for the combined branch handoff and receipt review."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

REPO = Path('/tmp/g261-next299316')
OUT = Path('/workspace/geo299316-refresh-20261023/preparation-snapshot')
HANDOFF = 'ea2748248d47563f8559638ccb70ec0ed21910d9'
F = '13d02c1db7022145a52ee063286a558e595eb212'
OUT.mkdir(exist_ok=False)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', GIT_OPTIONAL_LOCKS='0')
rows = []

def h(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    result = subprocess.run(['git', *args], cwd=REPO, env=env, capture_output=True, check=False)
    stem = f'{len(rows):03d}'
    (OUT / (stem + '.stdout')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr')).write_bytes(result.stderr)
    rows.append({'argv': ['git', *args], 'cwd': str(REPO), 'rc': result.returncode,
                 'stdout': stem + '.stdout', 'stdout_sha256': h(result.stdout),
                 'stderr': stem + '.stderr', 'stderr_sha256': h(result.stderr)})
    if result.returncode:
        raise RuntimeError(rows[-1])
    return result.stdout

assert git('rev-parse', 'HEAD').decode().strip() == '139ab64ca5f88e89bb4e95921675b998457026aa'
assert git('status', '--porcelain=v1', '--untracked-files=all') == b''
assert git('rev-parse', HANDOFF + '^{commit}').decode().strip() == HANDOFF
paths = ['handoff/HANDOFF.md', 'handoff/drafts/combined/README.md',
         'handoff/drafts/combined/rebased-546e2eb2/patch.diff']
paths += ['handoff/drafts/_gen/' + name for name in (
    'build.py', 'checks.py', 'edits299.py', 'edits316.py', 'fetch_base.sh',
    'lib.py', 'reader_impact.py', 'verify_all.sh')]
snapshots = []
for path in paths:
    raw = git('show', HANDOFF + ':' + path)
    target = OUT / 'source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    snapshots.append({'path': path, 'sha256': h(raw), 'bytes': len(raw)})
reviews = git('ls-tree', '-r', '--name-only', HANDOFF, 'handoff/pr-reviews').decode().splitlines()
mutate = (REPO / 'tests/mutate.py').read_bytes()
ids = re.findall(rb'dict\(id="(M\d+)"', mutate)
combined_ids = [mid.decode() for mid in ids if 89 <= int(mid[1:]) <= 98]
assert combined_ids == ['M97', 'M98', 'M89', 'M90', 'M91', 'M92', 'M93', 'M94', 'M95', 'M96']
assert not any(int(mid[1:]) >= 99 for mid in ids)
receipt_summary = {}
for job in ('grid', 'timber'):
    path = Path('/tmp/g288s7/workflow') / job / 'receipt.json'
    raw = path.read_bytes()
    receipt = json.loads(raw)
    assert receipt['sha'] == F and receipt['job'] == job
    receipt_summary[job] = {
        'path': str(path), 'sha256': h(raw),
        'fields': {key: receipt.get(key) for key in (
            'sha', 'job', 'status', 'exit_code', 'seconds', 'ci_timeout_minutes',
            'over_ci_timeout', 'checkout_before', 'checkout_after')},
        'step_keys': [list(step) for step in receipt['steps']],
        'steps': receipt['steps'],
    }
result = {'schema': 'combined-299-316-readonly-preparation/1', 'handoff_sha': HANDOFF,
          'repo': str(REPO), 'source_head': '139ab64ca5f88e89bb4e95921675b998457026aa',
          'snapshots': snapshots, 'review_files': reviews,
          'missing_requested_reviews': [name for name in ('299.md', '316.md')
                                        if 'handoff/pr-reviews/' + name not in reviews],
          'combined_mutant_ids': combined_ids, 'all_ids_unique': len(ids) == len(set(ids)),
          'mutate_sha256': h(mutate), 'receipt_summary': receipt_summary,
          'commands': rows, 'tests_builds_benchmarks_executed': False}
(OUT / 'PREPARATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'out': str(OUT), 'combined_ids': combined_ids,
                  'missing_requested_reviews': result['missing_requested_reviews'],
                  'receipt_step_keys': {k: v['step_keys'] for k, v in receipt_summary.items()}}, ensure_ascii=False))
