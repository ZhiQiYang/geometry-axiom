"""Publish bounded read-only preparation; never read native caches or whole repos."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/geo299316-refresh-20261023')
DEST = Path('/tmp/g261-next299316/evidence/geo299-316-stack-20261023')
DEST.mkdir(parents=True, exist_ok=False)
chosen = []
for folder in ('fetch-handoff', 'preparation-snapshot', 'grid-timber-review', 'anchor-check'):
    chosen.extend(p for p in (ROOT / folder).rglob('*') if p.is_file())
chosen.extend(ROOT / name for name in ('collect_preparation.py', 'review_grid_timber.py',
                                      'check_combined_anchors.py', 'package_preparation.py'))
members = []
archive = DEST / 'preparation-raw.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for path in sorted(chosen):
        raw = path.read_bytes()
        assert len(raw) < 2_000_000, path
        name = path.relative_to(ROOT).as_posix()
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mtime = 0
        info.mode = 0o644
        tf.addfile(info, io.BytesIO(raw))
        members.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive, 'r:gz') as tf:
    assert tf.getnames() == [row['path'] for row in members]
    for row in members:
        raw = tf.extractfile(row['path']).read()
        assert len(raw) == row['bytes']
        assert hashlib.sha256(raw).hexdigest() == row['sha256']
for name in ('OWNERSHIP.md', 'REVIEW_314_INITIAL.md', 'PROGRESS.md'):
    (DEST / name).write_bytes((ROOT / name).read_bytes())
inventory = {'schema': 'combined-299-316-preparation-package/1',
             'kind': 'preparation-only-not-new-stack-acceptance',
             'archive': archive.name, 'archive_bytes': archive.stat().st_size,
             'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
             'members': members, 'member_count': len(members),
             'all_members_reopened_and_verified': True,
             'original_script_top_level_streams_not_separately_recorded': [
                 'collect_preparation.py', 'review_grid_timber.py', 'check_combined_anchors.py'],
             'underlying_git_and_original_job_streams_preserved_where_indexed': True}
(DEST / 'INVENTORY.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'destination': str(DEST), 'archive_bytes': inventory['archive_bytes'],
                  'members': len(members), 'sha256': inventory['archive_sha256']}, ensure_ascii=False))
