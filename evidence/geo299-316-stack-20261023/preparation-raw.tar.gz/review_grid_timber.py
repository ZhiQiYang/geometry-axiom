"""Read only the two completed receipts and their small original command streams."""
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path('/tmp/g288s7/workflow')
OUT = Path('/workspace/geo299316-refresh-20261023/grid-timber-review')
F = '13d02c1db7022145a52ee063286a558e595eb212'
OUT.mkdir(exist_ok=False)

def h(raw):
    return hashlib.sha256(raw).hexdigest()

workflow = subprocess.run(['git', 'show', F + ':.github/workflows/integration-tests.yml'],
                          cwd='/tmp/g288f-13d02c1d', capture_output=True, check=False)
(OUT / 'workflow.stdout').write_bytes(workflow.stdout)
(OUT / 'workflow.stderr').write_bytes(workflow.stderr)
assert workflow.returncode == 0
results = []
for job in ('grid', 'timber'):
    folder = BASE / job
    raw = (folder / 'receipt.json').read_bytes()
    receipt = json.loads(raw)
    assert receipt['sha'] == F and receipt['job'] == job
    assert receipt['status'] == '完成' and receipt['exit_code'] == 0
    assert not receipt['over_ci_timeout']
    assert receipt['seconds'] <= 60 * receipt['ci_timeout_minutes']
    for key in ('checkout_before', 'checkout_after'):
        assert receipt[key]['head'] == F and receipt[key]['status'] == ''
    assert h(workflow.stdout) == receipt['workflow_sha256']
    verified = []
    names = ['steps/01.stdout', 'steps/01.stderr', 'steps/03.stdout', 'steps/03.stderr',
             'steps/01.executed.sh', 'steps/01.original.sh.txt',
             'steps/03.executed.sh', 'steps/03.original.sh.txt']
    names += ['versions/' + str(i) + '.' + suffix for i in range(5) for suffix in ('stdout', 'stderr')]
    for name in names:
        data = (folder / name).read_bytes()
        original = receipt['files'][name]
        assert len(data) == original['bytes'] and h(data) == original['sha256'], name
        destination = OUT / job / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        verified.append({'path': str(folder / name), 'bytes': len(data), 'sha256': h(data)})
    original = (folder / 'steps/03.original.sh.txt').read_bytes()
    expected = original.replace(b'18839', str(receipt['server_port']).encode()).replace(
        b'/tmp/', (receipt['temporary_directory'] + '/').encode())
    assert expected == (folder / 'steps/03.executed.sh').read_bytes()
    for step in receipt['steps']:
        if 'result' in step:
            result = step['result']
            assert result['actual_process_returncode'] == 0 and not result['watchdog_expired']
    stdout = (folder / 'steps/03.stdout').read_text()
    rows = [(number, line) for number, line in enumerate(stdout.splitlines(), 1)
            if line.startswith(('CDP_RESULT ', 'SPACE_RESULT '))]
    assert len(rows) == 1
    line_number, line = rows[0]
    footer = json.loads(line.split(' ', 1)[1])
    assert footer['completed'] is True
    if job == 'grid':
        assert footer['passedAssertions'] == 356 and footer['failedAssertions'] == 0
        assert footer['scope']['mode'] == 'partial'
        assert footer['goldenCompare'] == 'not compared (partial mode)'
        assert footer['uncaughtBrowserExceptions'] == 0
    else:
        assert footer['passed'] == 79 and footer['failed'] == 0
        assert footer['scope']['mode'] == 'partial'
        assert footer['exceptions'] == [] and footer['consoleErrors'] == []
    versions = [(folder / ('versions/' + str(i) + '.stdout')).read_text().strip() for i in range(5)]
    (OUT / job / 'receipt.json').write_bytes(raw)
    results.append({'job': job, 'execution_sha': F, 'original_receipt_sha256': h(raw),
                    'original_exit': receipt['exit_code'], 'seconds': receipt['seconds'],
                    'ci_timeout_minutes': receipt['ci_timeout_minutes'], 'versions': versions,
                    'port': receipt['server_port'], 'tmp': receipt['temporary_directory'],
                    'source_root': receipt['checkout_before']['root'],
                    'footer_line_number': line_number, 'footer_raw': line, 'footer': footer,
                    'verified_small_files': verified,
                    'script_adaptation_only': '18839 port and /tmp path substitutions; original assertions and branch selection preserved'})
assert results[0]['port'] != results[1]['port'] and results[0]['tmp'] != results[1]['tmp']
report = {'schema': 'geo288-grid-timber-independent-receipt-review/1',
          'execution_sha': F, 'reviewer_ran_tests': False, 'reviewer_compiled': False,
          'reviewer_opened_browser': False, 'reviewer_unpacked_archives': False,
          'workflow_git_show_exit': workflow.returncode, 'workflow_sha256': h(workflow.stdout),
          'jobs': results,
          'limits': ['Original jobs were serial and used one clean source checkout, not newly rerun in parallel independent checkouts.',
                     'Partial scopes are exactly the original CI jobs; neither is full canvas golden evidence.',
                     'Only the named small original command files were rehashed; raw tar members and screenshots were not revalidated.',
                     'This metadata check does not replace original product exits or claim anything about canvas P88.']}
(OUT / 'REVIEW.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'metadata_review_exit': 0, 'jobs': [{'job': row['job'], 'original_exit': row['original_exit'],
                    'receipt_sha256': row['original_receipt_sha256']} for row in results], 'out': str(OUT)}, ensure_ascii=False))
