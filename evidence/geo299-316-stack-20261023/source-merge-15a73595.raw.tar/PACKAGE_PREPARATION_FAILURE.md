# 收集器前置失敗保留

`python3 -B /workspace/geo299316-refresh-20261023/package_source_merge.py` 第一版原退出1，在 `tarfile.open(..., 'w')` 前開啟檔案時報 `FileNotFoundError`：普通 merge 後 sparse checkout 沒有物化 `/tmp/g261-next299316/evidence/geo299-316-stack-20261023/`。未形成 archive，也未執行產品、測試或 ledger。

第一版工具 bytes 保存在 `package_source_merge.r1.py.txt`。原 traceback 在工具呼叫 transcript，沒有獨立擷取到檔案；本文是明示轉述，不冒原 stderr bytes。

第二版只加 `DEST.mkdir(parents=True, exist_ok=True)` 並把這份限制與r1工具列進輸入清單；後續原命令另以 recorder 捕獲。未改產品、tests、斷言或驗收門檻。
