"""Bounded syntax and literal checks; no test imports, scanner, compiler or execution."""
import ast
import hashlib
import json
from pathlib import Path

REPO = Path('/tmp/g261-next299316')
OUT = Path('/workspace/geo299316-refresh-20261023/merged-static')
OUT.mkdir(exist_ok=False)
registry_raw = (REPO / 'tests/mutate.py').read_bytes()
definitions = []
for node in ast.walk(ast.parse(registry_raw.decode())):
    if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or node.func.id != 'dict':
        continue
    values = {}
    for kw in node.keywords:
        try:
            values[kw.arg] = ast.literal_eval(kw.value)
        except (TypeError, ValueError):
            pass
    mid = values.get('id', '')
    if mid.startswith('M') and mid[1:].isdigit():
        definitions.append(values)
ids = [row['id'] for row in definitions]
assert len(ids) == len(set(ids)) == 111
assert {int(mid[1:]) for mid in ids} == set(range(1, 41)) | set(range(51, 122))
anchors = []
selected = {f'M{i}' for i in [*range(89, 99), 102, 103, 105, 121]}
for row in definitions:
    if row['id'] not in selected:
        continue
    path = row.get('file', 'current_geometry.c')
    raw = (REPO / path).read_bytes()
    old = row['old'].encode().replace(b'\r\n', b'\n')
    count = raw.replace(b'\r\n', b'\n').count(old)
    assert count == 1, (row['id'], path, count)
    anchors.append({'id': row['id'], 'file': path, 'occurrences': count,
                    'source_sha256': hashlib.sha256(raw).hexdigest(),
                    'old_sha256': hashlib.sha256(old).hexdigest()})
assert {row['id'] for row in anchors} == selected
expected_raw = (REPO / 'tests/run_all.expected.json').read_bytes()
expected = json.loads(expected_raw)
suites = expected['suites'] if 'suites' in expected else expected
counts = {}
for name, count in {'test_geo261_contact_sources': 15, 'test_geo261_host_facts_authority': 22,
                    'test_geo261_load_residual': 13, 'test_geo314_stagger_commit': 47,
                    'test_geo261_wood_contacts': 10, 'test_geo261_wood_contact_world': 9,
                    'test_geo261_wood_world_validation': 14, 'test_geo261_wood_grid_application': 23}.items():
    path = REPO / 'tests' / (name + '.py')
    tree = ast.parse(path.read_bytes().decode())
    methods = [n.name for cls in tree.body if isinstance(cls, ast.ClassDef)
               for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    assert len(methods) == count, (name, len(methods), count)
    assert suites['py:' + name]['count'] == count, (name, suites['py:' + name])
    counts[name] = {'static_methods': count, 'expected_count': suites['py:' + name]['count']}
ast.parse((REPO / 'tests/test_geo261_mutation_migration.py').read_bytes().decode())
result = {'schema': 'combined-299-316-merged-static/1', 'registry_count': len(ids),
          'ids_unique': True, 'numeric_ids': sorted(int(mid[1:]) for mid in ids),
          'selected_anchors': anchors, 'suite_literal_counts': counts,
          'registry_sha256': hashlib.sha256(registry_raw).hexdigest(),
          'expected_sha256': hashlib.sha256(expected_raw).hexdigest(),
          'not_a_test_or_freshness_check': True, 'no_imports_of_product_or_tests': True}
(OUT / 'MERGED_STATIC.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'registry_count': len(ids), 'unique_anchors': len(anchors),
                  'suite_counts_checked_statically': len(counts), 'not_a_test': True}))
