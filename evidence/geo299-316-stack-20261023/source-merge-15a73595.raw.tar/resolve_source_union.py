"""Resolve the combined branch merge without executing tests or generating a ledger."""
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/tmp/g261-next299316')
OUT = Path('/workspace/geo299316-refresh-20261023/source-union')
OURS = 'c940a6543029a94d443709ebdcbd63828fdfef1d'
THEIRS = '8033aa756c62f654333c24d1276d4b61beb31a45'
OUT.mkdir(exist_ok=False)
rows = []

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    result = subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=False)
    stem = f'{len(rows):03d}'
    (OUT / (stem + '.stdout')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr')).write_bytes(result.stderr)
    rows.append({'argv': ['git', *args], 'rc': result.returncode,
                 'stdout': stem + '.stdout', 'stdout_sha256': digest(result.stdout),
                 'stderr': stem + '.stderr', 'stderr_sha256': digest(result.stderr)})
    assert result.returncode == 0, rows[-1]
    return result.stdout

assert git('rev-parse', 'HEAD').decode().strip() == OURS
assert git('rev-parse', 'MERGE_HEAD').decode().strip() == THEIRS
unmerged = git('diff', '--name-only', '--diff-filter=U').decode().splitlines()
assert set(unmerged) == {'.gitignore', 'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',
    'geometry-core/domain-decoupling/product-architecture-receipt.json',
    'geometry-core/domain-decoupling/product-architecture-scan.json',
    'tests/mutants_results.json', 'tests/test_geo261_mutation_migration.py'}

before = {path: digest((REPO / path).read_bytes()) for path in unmerged}
ignore = REPO / '.gitignore'
raw = ignore.read_bytes()
conflict = ('<<<<<<< HEAD\n!/evidence/geo299-316-final-*/\n=======\n'
            '!/evidence/geo314-final-*/\n>>>>>>> ' + THEIRS + '\n').encode()
assert raw.count(conflict) == 1
raw = raw.replace(conflict, b'!/evidence/geo299-316-final-*/\n!/evidence/geo314-final-*/\n!/evidence/geo299-316-stack-*/\n')
ignore.write_bytes(raw)

path = 'tests/test_geo261_mutation_migration.py'
raw = (REPO / path).read_text()
opening, separator, closing = '<<<<<<< HEAD\n', '=======\n', '>>>>>>> ' + THEIRS + '\n'
assert raw.count(opening) == raw.count(separator) == raw.count(closing) == 1
start = raw.index(opening)
middle = raw.index(separator, start)
end = raw.index(closing, middle)
ours_map = raw[start + len(opening):middle]
theirs_map = raw[middle + len(separator):end]
assert theirs_map.startswith('        self.assertEqual(28, len(added))\n')
theirs_map = theirs_map.split('\n', 1)[1]
theirs_map = theirs_map.replace('        # #314 leaves M89-M98 for #299/#316, then registers the reviewed W/H\n',
                               '        # #314 follows the combined M89-M98 and registers the reviewed W/H\n')
assert theirs_map.endswith('        added.update(stagger)\n')
theirs_map = theirs_map.replace('        added.update(stagger)\n',
    '        self.assertEqual(23, len(stagger))\n        added.update(stagger)\n        self.assertEqual(61, len(added))\n')
raw = raw[:start] + ours_map + theirs_map + raw[end + len(closing):]
(REPO / path).write_text(raw)

old_records = json.loads(git('show', OURS + ':tests/mutants_results.json'))
prior_records = json.loads(git('show', THEIRS + ':tests/mutants_results.json'))
assert len(old_records) == 88 and len(prior_records) == 100
combined = dict(prior_records)
combined.update(old_records)
assert len(combined) == 110 and 'M121' not in combined
assert set(combined) == set(old_records) | set(prior_records)
assert all(combined[mid] == row for mid, row in old_records.items())
assert all(combined[mid] == row for mid, row in prior_records.items() if mid not in old_records)
(REPO / 'tests/mutants_results.json').write_text(json.dumps(combined, ensure_ascii=False, indent=2, sort_keys=True) + '\n')

historical = []
for suffix in ('product-architecture.json', 'product-architecture-scan.json',
               'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json'):
    path = 'geometry-core/domain-decoupling/' + suffix
    for role, ref in (('ours', OURS), ('theirs', THEIRS)):
        body = git('show', ref + ':' + path)
        historical.append({'role': role, 'source_commit': ref, 'path': path,
                           'bytes': len(body), 'sha256': digest(body),
                           'raw_stdout': rows[-1]['stdout']})
    # Keep the whole earlier combined scan/report/receipt as historical data.
    # The manifest is a real source union, and the old receipt is explicitly
    # pending regeneration against this new closure; it is never relabelled.
    if suffix != 'product-architecture.json':
        (REPO / path).write_bytes(git('show', OURS + ':' + path))

manifest = json.loads((REPO / 'geometry-core/domain-decoupling/product-architecture.json').read_bytes())
assert any(row['path'] == 'geometry-app/native/stagger_facts.inc' for row in manifest['sources'])
encoded_manifest = json.dumps(manifest, ensure_ascii=False)
assert 'wood_contact_boundary_edge' in encoded_manifest
assert 'wood_contact_footprint_collides' not in encoded_manifest
for path in ('公理層.md', '決策佇列.md'):
    assert (REPO / path).read_bytes().replace(b'\r\n', b'\n') == git('show', THEIRS + ':' + path).replace(b'\r\n', b'\n')
main = (REPO / 'current_geometry.c').read_bytes()
assert main.count(b'\n') == main.count(b'\r\n') and b'\x00' not in main
result = {'schema': 'combined-299-316-source-union/1', 'ours': OURS, 'theirs': THEIRS,
    'commands': rows, 'original_unmerged': unmerged, 'before_sha256': before,
    'after_sha256': {path: digest((REPO / path).read_bytes()) for path in unmerged},
    'ledger': {'kind': 'old-record-union-not-execution-or-regeneration', 'rows': len(combined),
               'ours_original_rows': len(old_records), 'theirs_original_rows': len(prior_records),
               'common_rows_prefer_earlier_combined': True, 'unrun_new_id': 'M121',
               'all_execution_fields_preserved': True, 'freshness_not_checked': True},
    'architecture': {'manifest_source_union': True,
                     'old_scan_report_receipt_preserved_from': OURS,
                     'current_closure_receipt_pending_root_regeneration': True,
                     'original_four_files_both_parents': historical},
    'ssot_and_decisions_equal_predecessor': True, 'current_geometry_crlf': True,
    'tests_compilers_scanners_executed': False}
(OUT / 'SOURCE_UNION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'resolved_files': len(unmerged), 'ledger_rows': len(combined),
                  'M121': 'unrun', 'architecture': 'pending-root-regeneration',
                  'tests_compilers_scanners_executed': False}, ensure_ascii=False))
