"""Freeze bounded original merge/implementation streams without compression."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/workspace/geo299316-refresh-20261023')
DEST = Path('/tmp/g261-next299316/evidence/geo299-316-stack-20261023')
DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'source-merge-15a73595.raw.tar'
assert not archive.exists()
folders = ('merge314-preflight', 'merge314-source', 'source-union',
           'resolve-source-union-command', 'reader-sync-merged-source',
           'merged-static', 'inspect-merged-source-command', 'source-merge-stage',
           'source-merge-diff-check', 'source-merge-commit', 'source-merge-push',
           'source-merge-push-verify', 'fetch-handoff-body-audit')
chosen = [p for name in folders for p in (ROOT / name).rglob('*') if p.is_file()]
chosen += [ROOT / name for name in ('resolve_source_union.py', 'inspect_merged_sources.py',
                                   'package_source_merge.py', 'package_source_merge.r1.py.txt',
                                   'PACKAGE_PREPARATION_FAILURE.md')]
inventory = []
with tarfile.open(archive, 'w') as tf:
    for path in sorted(chosen):
        raw = path.read_bytes()
        name = path.relative_to(ROOT).as_posix()
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        info.mtime = 0
        tf.addfile(info, io.BytesIO(raw))
        inventory.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive, 'r') as tf:
    assert tf.getnames() == [row['path'] for row in inventory]
    for row in inventory:
        raw = tf.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
for src, dst in (('PROGRESS.merged.md', 'PROGRESS.md'),
                 ('REVIEW_314_f614_STATIC.md', 'REVIEW_314_f614_STATIC.md')):
    shutil.copyfile(ROOT / src, DEST / dst)
result = {'schema': 'combined-299-316-source-merge-raw/1',
          'source_sha': '15a735951a36b6fe52e0291152f335139e6921ad',
          'kind': 'implementation-and-static-review-not-dynamic-acceptance',
          'archive': archive.name, 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'members': inventory, 'member_count': len(inventory),
          'all_members_reopened_and_verified': True,
          'compression': 'none-to-avoid-competing-with-root-canvas',
          'ledger_execution_or_regeneration': False, 'compiler_or_scanner_or_tests_run': False}
(DEST / 'SOURCE_MERGE_INVENTORY.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'bytes': result['bytes'], 'members': len(inventory),
                  'sha256': result['sha256']}, ensure_ascii=False))
