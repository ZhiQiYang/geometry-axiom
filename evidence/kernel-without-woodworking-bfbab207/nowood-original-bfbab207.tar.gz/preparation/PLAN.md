固定 `bfbab207a92a809fca50fefcefb3fa4b2af05ea9` 的 noWood 原正式入口已備好，未執行測試／C。

`REQUEST.json` 保存精確原 outer argv、七個原 child argv／case、11 個 Git raw 輸入 hash、13 個 AST 方法及所有原時限。`immutable-inputs/` 是這個 Git SHA 的薄原件安裝，85,068 bytes（4KiB 逐檔上取整 106,496 bytes），不是完整 checkout、不是新產品實作。`external-variant-previews/` 只預覽原 48e0 driver 會建立的相同 test variants／diff，不能充作正式執行；正式沒有 `--test-override`，仍從 Git 重新讀來源。

root 明示取得 C/R3 排程後，執行：

```
env -u PYTHONOPTIMIZE python3 -B /tmp/nowood-bfbab207-prepared-20261023/LAUNCH_AFTER_ROOT_BATON.py
```

launcher 先核 own worktree 原 SHA／clean、11 Git blobs、原 driver `48e0badb3e09cb16603af11ad04fe8d79a75055009868beabd02acf64b2ce6bc`、原 c387 capture，然後以 REQUEST 所列 **原 driver argv** 執行；沒有外加 R3 lock，原 child 自行 EX|NB，忙鎖沿原 exit 2，不重試、不卸鎖。外 recorder timeout=None，保原 driver 的各 capture 2100 秒、原 compile/link 120 秒、case 10 秒與 source-isolation 子程序120秒，stack16MiB，不修改斷言或時限。輸出 `/tmp/kernel-no-wood-final-bfbab207` 必須不存在；launcher 紀錄另在 `/tmp/nowood-bfbab207-original-launch`，本次準備沒有建立這兩目錄。

七個預期原退出依次 `0/1/0/1/0/1/0`；baseline 13 方法，其餘各 1 方法。原正文及帳本 gate 都不因準備而轉綠。原完整 baseline 還有真正 K divisibility mutation 的 0/1/0 與刻意拿掉 grid object 的 dependency link 拒絕；不要把那個預期 link 非零誤當無 compiler。quoted／angle 一行 W include 必先真 compile＋exact-cells 0，再由原 source isolation gate 真拒絕；import sentinel 也是真可供匯入，不靠缺套件假 kill。

磁碟：7 份 retained source 安裝合計 594,805 raw bytes，原測試每階段另有一份短暫 installation/copy；原 `TemporaryDirectory` 在每階段 test close 後清理，七階段序列跑，沒有跨階段 ELF cache。實際 object／ELF 尺寸尚未量測，不能冒稱精確峰值。32MiB 只是保守工作配置估算，並非原測試新門檻，也不會限制或截斷 output；root 在 C 時槽前依當時兩掛載點容量安排，若不足就先處理環境，不能默改來源／outpath或把未跑算通過。

編譯輸出沿原 `IsolatedNativeBuild.run`，每一 compile/link 都把完整 argv、exit、text stdout/stderr 加入 logs；close 先保存各 phase 的 `native-commands.json`，才做原 temporary cleanup。預期 missing-grid link 的原 stderr 也會保存。上層每原 Python child 的 stdout/stderr 是完整 c387 raw bytes；**內層 compiler 是原 text(errors=replace) capture，不冒稱另有 raw pipes**。launcher 只讀稽核每份 JSON 輸出欄與 hash、記真 command 數及 replacement character，原 tests/driver/capture 沒有 patch；若原件缺失或有無法確定的 decoding loss，不能當完整輸出已驗。

原實際 compiler TEMP 名稱由 `TemporaryDirectory` 產生，準備階段不捏造將來 argv 的絕對目錄。REQUEST 列原 flags/路徑模板，正式由原 native JSON 封全部真 argv。暫時 mutant C/ELF 沿原 cleanup；完整 Git 原件、test diff、原 compiler 輸出與 executable case 結果保留，不虛構已保存被原測試刪除的 ELF 或 TEMP C raw。

當前狀態：薄來源與 preview 真已準備；13 方法、7 phase、編譯與正式反證全 **UNRUN**。不產全帳本、不改 root train、不新建 147MB browser pool。
