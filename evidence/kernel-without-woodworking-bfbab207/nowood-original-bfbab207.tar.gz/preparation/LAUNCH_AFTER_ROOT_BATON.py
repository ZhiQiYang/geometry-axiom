"""Prepared only: root assigns C/R3 before invoking; original driver/test bytes unchanged."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,traceback
PREP=Path('/tmp/nowood-bfbab207-prepared-20261023')
REQ=json.loads((PREP/'REQUEST.json').read_bytes())
F=REQ['source_sha'];FORMAL=Path(REQ['formal_out'])
OUT=Path('/tmp/nowood-bfbab207-original-launch')
ROOT=Path('/workspace/kernel-no-wood-work')
META=Path('/workspace/kernel-no-wood-prep/metadata.git')
CAP=Path(REQ['original_capture_path']);DRIVER=Path(REQ['original_driver_path'])
H=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)==1,'No override flags: request must be revised and reviewed instead'
assert not FORMAL.exists() and not OUT.exists()
assert H(DRIVER.read_bytes())==REQ['driver_sha256'] and H(CAP.read_bytes())==REQ['capture_sha256']
OUT.mkdir()
(OUT/'LAUNCHER.py').write_bytes(Path(__file__).read_bytes());(OUT/'PREPARED_REQUEST.json').write_bytes((PREP/'REQUEST.json').read_bytes())
spec=importlib.util.spec_from_file_location('nowood_original_launch_capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ,LANG='C.UTF-8',LC_ALL='C.UTF-8',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONOPTIMIZE',None)
r=cap.Recorder(OUT,env,F)
def git(argv):return r.run(argv,cwd=OUT,timeout=120,source_variant='own-original-formal-preflight-no-C')[1]
report=dict(schema='nowood-original-seven-phase-outer-launch/1',source_sha=F,commands=r.rows,
 original_test_or_driver_modified=False,test_override=None,outer_timeout_seconds=None,
 resource_lock='Original child driver only: EX|NB R3; no new outer flock and no busy retry',
 inherited_source_tag_explicit_in_original_argv=True,formal_out=str(FORMAL),passed=False,errors=[],started_epoch=time.time())
code=2
try:
 assert git(['git','-C',str(ROOT),'rev-parse','HEAD']).decode().strip()==F
 assert git(['git','-C',str(ROOT),'status','--porcelain=v1','--untracked-files=all'])==b''
 for item in REQ['immutable_inputs']:
  raw=git(['git','--git-dir',str(META),'show',F+':'+item['path']])
  assert len(raw)==item['bytes'] and H(raw)==item['sha256']
 report['free_bytes_before_original']={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in (Path('/tmp'),Path('/workspace'))}
 original,_,_=r.run(REQ['exact_outer_argv'],cwd=OUT,timeout=None,check=False,source_variant='original-seven-phase-driver-no-override')
 code=original['actual_process_returncode'];report['original_result']=original
 receipt=json.loads((FORMAL/'receipt.json').read_bytes())
 report['original_driver_receipt_sha256']=H((FORMAL/'receipt.json').read_bytes())
 report['original_driver_passed']=receipt['passed'];report['original_phase_exits']=[p['original_command']['actual_process_returncode'] for p in receipt['phases']]
 output_audit=[]
 for phase in receipt['phases']:
  native=FORMAL/phase['label']/'native-commands.json'
  if not native.is_file():
   output_audit.append(dict(phase=phase['label'],present=False));continue
  raw=native.read_bytes();value=json.loads(raw);compilers=[x for x in value['commands'] if 'arguments' in x]
  output_audit.append(dict(phase=phase['label'],present=True,bytes=len(raw),sha256=H(raw),all_original_commands=len(value['commands']),compiler_link_commands=len(compilers),
   complete_original_text_output_fields=all(all(k in x for k in ('command','arguments','exit','stdout','stderr')) and isinstance(x['stdout'],str) and isinstance(x['stderr'],str) for x in compilers),
   replacement_character_seen=any('\ufffd' in x['stdout']+x['stderr'] for x in compilers),
   scope='Original compiler/link text capture from unchanged test; not a claim of separate raw compiler stdout/stderr pipes'))
 report['compiler_output_audit']=output_audit
 report['workspace_after_head']=git(['git','-C',str(ROOT),'rev-parse','HEAD']).decode().strip()
 report['workspace_after_clean']=git(['git','-C',str(ROOT),'status','--porcelain=v1','--untracked-files=all'])==b''
 report['passed']=(code==0 and receipt['source_sha']==F and receipt['passed'] and receipt['test_override'] is None
  and report['original_phase_exits']==[p['original_expected_exit'] for p in REQ['phases']]
  and report['workspace_after_head']==F and report['workspace_after_clean'])
 if report['passed']:
  report['passed']=len(output_audit)==7 and all(x['present'] and x['compiler_link_commands']>0 and x['complete_original_text_output_fields'] and not x['replacement_character_seen'] for x in output_audit)
 if not report['passed'] and code==0:code=2
except Exception:
 report['errors'].append(traceback.format_exc());code=2
finally:
 report.update(actual_exit=code,ended_epoch=time.time())
 (OUT/'RECEIPT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(actual_exit=code,passed=report['passed'],source_sha=F,formal_out=str(FORMAL)),ensure_ascii=False))
raise SystemExit(code)
