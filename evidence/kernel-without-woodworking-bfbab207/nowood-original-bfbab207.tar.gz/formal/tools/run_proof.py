"""Run only the K + rectangular-grid source installation and guard controls.

This is a targeted evidence collector, never a global mutation-ledger writer.
All compiler execution waits for the root's shared resource lock.
"""
from __future__ import annotations

import argparse
import ast
import datetime
import difflib
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import sys

SOURCE_FILES = tuple('geometry-core/kernel/' + name for name in (
    'types.h', 'exact.h', 'exact.c', 'geometry.h', 'geometry.c', 'grid.h', 'grid.c')) + (
    'geometry-templates/rectangular-grid/rectangular_grid.h',
    'geometry-templates/rectangular-grid/rectangular_grid.c',
    'tests/rectangular_template_harness.c', 'tests/test_rectangular_template.py')
REL = 'tests/test_rectangular_template.py'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_SHA = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
LAYER_GUARD = '''                    if relative.startswith("geometry-core/kernel/"):
                        self.assertTrue(all(target.resolve().is_relative_to(root / "geometry-core/kernel")
                                            for target in targets if target.is_file()),
                                        f"K source includes template dependency: {relative}: {include}")
'''
BLOCKER = 'if root in ("modeling", "geometry_app", "geometry_woodworking") or root.startswith("woodworking"):'
OLD_BLOCKER = 'if root in ("modeling", "geometry_app") or root.startswith("woodworking"):'
INCLUDE_PARSER = '''                for quoted, angled in re.findall(r'^\\s*#\\s*include\\s*(?:"([^"]+)"|<([^>]+)>)',
                                                  path.read_text(encoding="utf-8"), re.M):
                    include = quoted or angled
                    directories = (path.parent, *include_dirs) if quoted else include_dirs
                    targets = [directory / include for directory in directories]
                    if quoted or any(target.is_file() for target in targets):
                        self.assertTrue(any(target.is_file() and target.resolve().is_relative_to(root) for target in targets),
                                        f"non-isolated include: {relative}: {include}")
'''
OLD_INCLUDE_PARSER = '''                for include in re.findall(r'^\\s*#\\s*include\\s*"([^"]+)"', path.read_text(encoding="utf-8"), re.M):
                    targets = [directory / include for directory in (path.parent, *include_dirs)]
                    self.assertTrue(any(target.is_file() and target.resolve().is_relative_to(root) for target in targets),
                                    f"non-isolated include: {relative}: {include}")
'''
IMPORT_CASE = 'RectangularTemplateNative.test_application_and_woodworking_imports_are_rejected_when_available'
LAYER_CASE = 'RectangularTemplateNative.test_kernel_cannot_include_the_available_template_header'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git-dir', required=True, type=Path)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--heavy-lock', required=True, type=Path)
    parser.add_argument('--test-override', type=Path,
                        help='Only for explicitly labelled preflight; final proof must use the committed test bytes')
    args = parser.parse_args()
    out = args.out.resolve()
    git_dir = args.git_dir.resolve()
    require(len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha), 'Full SHA required')
    require(not out.exists() and out.parent.is_dir(), 'Output must be new and its parent must exist')
    require(git_dir.is_dir() and args.heavy_lock.is_file(), 'Existing metadata repository and root resource lock required')
    require(not out.is_relative_to(git_dir) and not git_dir.is_relative_to(out), 'Output must be outside Git metadata')
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0'), 'No optimized-away assertions')
    require(digest(CAPTURE.read_bytes()) == CAPTURE_SHA, 'Original capture changed')
    frozen_driver = Path(__file__).read_bytes()
    override_before = args.test_override.read_bytes() if args.test_override else None
    out.mkdir()
    (out / 'tools').mkdir()
    (out / 'tools/run_proof.py').write_bytes(frozen_driver)
    (out / 'tools/capture.py').write_bytes(CAPTURE.read_bytes())
    spec = importlib.util.spec_from_file_location('kernel_no_wood_proof_capture', out / 'tools/capture.py')
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    env = dict(os.environ)
    cleared = []
    for key in list(env):
        if key.startswith(('GEOMETRY_', 'GEO261_', 'MUTATE_')) or key in (
            'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONSTARTUP', 'LD_PRELOAD',
            'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CPATH', 'C_INCLUDE_PATH',
            'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH'):
            env.pop(key)
            cleared.append(key)
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    safe = ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE',
            'TMPDIR', 'GEO261_RECTANGULAR_EVIDENCE', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS',
            'CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH')
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    require(hard == resource.RLIM_INFINITY or hard >= 16384 * 1024, 'Stack hard limit below 16 MiB')
    resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
    recorder = capture.Recorder(out, env, args.sha)
    report = {'schema': 'kernel-no-wood-targeted-proof/1', 'source_sha': args.sha,
              'source_role': 'fixed Git tree source installation; no product worktree edited',
              'test_override': None if override_before is None else {
                  'path': str(args.test_override.resolve()), 'sha256': digest(override_before),
                  'scope': 'external preflight candidate, not committed final-SHA test execution'},
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'platform': platform.platform(), 'python': sys.version, 'python_executable': sys.executable,
              'environment': {key: env.get(key) for key in safe},
              'cleared_environment_names': sorted(cleared),
              'stack_before': [soft, hard], 'stack_during': [16384 * 1024, hard],
              'driver_sha256': digest(frozen_driver), 'capture_sha256': CAPTURE_SHA,
              'commands': recorder.rows, 'sources': [], 'phases': [], 'errors': [], 'passed': False,
              'global_mutation_ledger_generated': False}
    save(out / 'receipt.json', report)

    def run(argv, *, child_env=env, variant='fixed-tree-source-read', check=True, timeout=2100):
        previous = recorder.env
        recorder.env = child_env
        try:
            row, stdout, stderr = recorder.run(list(map(str, argv)), cwd=out, timeout=timeout, check=check,
                                              source_variant=variant)
            row['effective_environment'] = {key: child_env.get(key) for key in safe}
            return row, stdout, stderr
        finally:
            recorder.env = previous

    lock = args.heavy_lock.open('a+b')
    code = 2
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        resolved = run(['git', '--git-dir', git_dir, 'rev-parse', '--verify', args.sha + '^{commit}'])[1].decode().strip()
        require(resolved == args.sha, 'Source did not resolve to the exact commit')
        for command in ([sys.executable, '--version'], ['cc', '--version']):
            run(command, timeout=30)
        sources = {}
        for relative in SOURCE_FILES:
            raw = run(['git', '--git-dir', git_dir, 'show', args.sha + ':' + relative])[1]
            sources[relative] = raw
            report['sources'].append({'path': relative, 'bytes': len(raw), 'sha256': digest(raw)})
        fixed = sources[REL] if override_before is None else override_before
        tree = ast.parse(fixed.decode())
        require(fixed.count(BLOCKER.encode()) == 1 and fixed.count(LAYER_GUARD.encode()) == 1
                and fixed.count(INCLUDE_PARSER.encode()) == 1,
                'Candidate must retain the exact reviewed blocker and layer guards')
        full_count = sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_') for node in ast.walk(tree))
        require(full_count == 13, 'Expected the original eleven tests plus two explicit isolation controls')
        variants = (
            ('baseline', fixed, None, 0),
            ('woodworking-import-withdrawn', fixed.replace(BLOCKER.encode(), OLD_BLOCKER.encode(), 1), IMPORT_CASE, 1),
            ('woodworking-import-restored', fixed, IMPORT_CASE, 0),
            ('k-to-w-guard-withdrawn', fixed.replace(LAYER_GUARD.encode(), b'', 1), LAYER_CASE, 1),
            ('k-to-w-guard-restored', fixed, LAYER_CASE, 0),
            ('angle-include-parser-withdrawn', fixed.replace(INCLUDE_PARSER.encode(), OLD_INCLUDE_PARSER.encode(), 1), LAYER_CASE, 1),
            ('angle-include-parser-restored', fixed, LAYER_CASE, 0),
        )
        for label, test_bytes, case, wanted in variants:
            phase = out / label
            root = phase / 'source'
            root.mkdir(parents=True)
            tmp = phase / 'tmp'
            tmp.mkdir()
            for relative, raw in sources.items():
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(test_bytes if relative == REL else raw)
            patch = ''.join(difflib.unified_diff(fixed.decode().splitlines(keepends=True),
                                                test_bytes.decode().splitlines(keepends=True),
                                                fromfile='fixed/' + REL, tofile=label + '/' + REL)).encode()
            (phase / 'test-variant.patch').write_bytes(patch)
            child_env = dict(env, TMPDIR=str(tmp), GEO261_RECTANGULAR_EVIDENCE=str(phase / 'native-commands.json'))
            argv = [sys.executable, '-I', '-B', root / REL]
            if case:
                argv.append(case)
            row, stdout, stderr = run(argv, child_env=child_env, variant=label, check=False)
            text = stderr.decode('utf-8', 'replace')
            healthy = not row['timeout_expired'] and row['actual_process_returncode'] in (0, 1)
            expected = healthy and row['actual_process_returncode'] == wanted
            expected = expected and ('Ran 13 tests' if case is None else 'Ran 1 test') in text
            if wanted == 0:
                expected = expected and '\nOK\n' in text and 'skipped=' not in text
            else:
                failures = 2 if label == 'k-to-w-guard-withdrawn' else 1
                expected = expected and ('FAILED (failures=' + str(failures) + ')') in text and 'errors=' not in text
                expected = expected and ('AssertionError not raised' in text if 'import' in label else '1 != 0' in text)
            expected = expected and 'ImportError' not in text and 'SyntaxError' not in text
            native_path = phase / 'native-commands.json'
            native = json.loads(native_path.read_text()) if native_path.is_file() else None
            expected = expected and native is not None
            if native is not None and label in ('baseline', 'k-to-w-guard-restored', 'angle-include-parser-restored'):
                gate_rows = [(x['isolation_gate'], x['exit']) for x in native['commands'] if 'isolation_gate' in x]
                expected = expected and [x[1] for x in gate_rows] == [0, 1, 0, 0, 1, 0]
                include_runs = [x for x in native['commands'] if x.get('case') == 'exact-cells'
                                and 'template-include-control' in x.get('executable', '')]
                expected = expected and len(include_runs) == 2 and all(x['exit'] == 0 for x in include_runs)
            expected_inputs = dict(sources, **{REL: test_bytes})
            for relative, raw in expected_inputs.items():
                require((root / relative).read_bytes() == raw, label + ': source fixture changed')
            value = {'label': label, 'expected_exit': wanted, 'original_command': row,
                     'test_source_sha256': digest(test_bytes), 'test_patch_sha256': digest(patch),
                     'same_all_other_source_bytes': True, 'expectations_matched': bool(expected),
                     'native_commands': None if native is None else {'path': str(native_path),
                         'bytes': native_path.stat().st_size, 'sha256': digest(native_path.read_bytes())}}
            report['phases'].append(value)
            if not expected:
                report['errors'].append(label + ': original test result did not match the exact control expectation')
            save(out / 'receipt.json', report)
        report['passed'] = len(report['phases']) == 7 and not report['errors']
        code = 0 if report['passed'] else 1
    except BaseException as error:
        report['errors'].append(type(error).__name__ + ': ' + str(error))
        code = 2
    finally:
        if Path(__file__).read_bytes() != frozen_driver:
            report['errors'].append('proof driver changed during execution')
        if digest(CAPTURE.read_bytes()) != CAPTURE_SHA:
            report['errors'].append('original recorder changed during execution')
        if args.test_override and args.test_override.read_bytes() != override_before:
            report['errors'].append('external candidate changed during execution')
        if report['errors'] and code == 0:
            code = 2
        report['passed'] = report['passed'] and not report['errors']
        report['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        report['actual_driver_exit_code'] = code
        save(out / 'receipt.json', report)
        resource.setrlimit(resource.RLIMIT_STACK, (soft, hard))
        lock.close()
    print(json.dumps({'source_sha': args.sha, 'passed': report['passed'],
                      'exit_code': code, 'phases': [(x['label'], x['original_command']['actual_process_returncode'])
                                                  for x in report['phases']],
                      'errors': report['errors']}, ensure_ascii=False))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
