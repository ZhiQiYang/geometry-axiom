"""Package completed originals; never rerun tests or edit source/raw receipts."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile

F = 'bfbab207a92a809fca50fefcefb3fa4b2af05ea9'
OUT = Path('/tmp/nowood-bfbab207-original-package')
assert not OUT.exists()
OUT.mkdir()
roots = {
    'formal': Path('/tmp/kernel-no-wood-final-bfbab207'),
    'launch': Path('/tmp/nowood-bfbab207-original-launch'),
    'preparation': Path('/tmp/nowood-bfbab207-prepared-20261023'),
}
extras = {
    'tools/run_proof.py': Path('/workspace/kernel-no-wood-prep/run_proof.py'),
    'tools/capture.py': Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),
    'tools/package_original.py': Path(__file__),
    'peer/NOWOOD_BFB_LAUNCH_STATIC_PEER.json': Path('/tmp/train337-adversarial/NOWOOD_BFB_LAUNCH_STATIC_PEER.json'),
}
for name in ('NOWOOD_SLOT2_PARAMETER_PEER.json', 'NOWOOD_BFB_ACTUAL_PEER.json'):
    p = Path('/tmp/train337-adversarial') / name
    if p.exists():
        extras['peer/' + name] = p
H = lambda raw: hashlib.sha256(raw).hexdigest()
receipt = json.loads((roots['formal'] / 'receipt.json').read_bytes())
outer = json.loads((roots['launch'] / 'RECEIPT.json').read_bytes())
assert receipt['source_sha'] == F and receipt['passed'] and receipt['actual_driver_exit_code'] == 0
assert outer['source_sha'] == F and outer['passed'] and outer['actual_exit'] == 0
assert [x['original_command']['actual_process_returncode'] for x in receipt['phases']] == [0,1,0,1,0,1,0]
members = {}
for prefix, root in roots.items():
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), str(p)
        if p.is_file():
            members[prefix + '/' + p.relative_to(root).as_posix()] = p
members.update(extras)
manifest = []
for name, p in sorted(members.items()):
    raw = p.read_bytes()
    assert raw[:4] != b'\x7fELF', str(p)
    manifest.append(dict(path=name, source_path=str(p), bytes=len(raw), sha256=H(raw)))
(OUT / 'MEMBER_HASHES.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
archive = OUT / 'nowood-original-bfbab207.tar.gz'
with archive.open('wb') as stream, gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed, tarfile.open(mode='w|', fileobj=compressed) as tar:
    for item in manifest:
        raw = members[item['path']].read_bytes()
        assert len(raw) == item['bytes'] and H(raw) == item['sha256']
        ti = tarfile.TarInfo(item['path']); ti.size = len(raw); ti.mode = 0o644; ti.mtime = 0
        tar.addfile(ti, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    assert [x.name for x in actual] == [x['path'] for x in manifest]
    for item in manifest:
        raw = tar.extractfile(item['path']).read()
        assert len(raw) == item['bytes'] and H(raw) == item['sha256']
for item in manifest:
    raw = members[item['path']].read_bytes()
    assert len(raw) == item['bytes'] and H(raw) == item['sha256']
package = dict(schema='nowood-completed-original-package/1', product_sha=F,
    actual_driver_exit=0, outer_exit=0, baseline_test_methods=13,
    phase_exits=[0,1,0,1,0,1,0], expected_skips=[], archive=archive.name,
    archive_bytes=archive.stat().st_size, archive_sha256=H(archive.read_bytes()),
    members=len(manifest), uncompressed_bytes=sum(x['bytes'] for x in manifest),
    member_hashes_sha256=H((OUT/'MEMBER_HASHES.json').read_bytes()),
    full_original_python_pipe_bytes_retained=True,
    compiler_capture='Unchanged original native-commands.json retains complete text output/argv/exit; separate raw compiler pipes and removed temporary ELF/C scratch were not retained.',
    phase_source_bytes_and_precise_external_patches_retained=True,
    ledger_regenerated=False, project_wide_train_validation_claimed=False,
    source_sha_bound_to_original_parent_and_each_phase=True,
    archive_roundtrip_all_members_verified=True, all_inputs_unchanged_after_packaging=True,
    included_peer_paths=[x['path'] for x in manifest if x['path'].startswith('peer/')])
(OUT/'PACKAGE.json').write_text(json.dumps(package, ensure_ascii=False, indent=2)+'\n')
(OUT/'SHA256SUMS').write_text(''.join(H(p.read_bytes())+'  '+p.name+'\n' for p in [archive,OUT/'MEMBER_HASHES.json',OUT/'PACKAGE.json']))
print(json.dumps(package, ensure_ascii=False))
