"""Record one already-authorized stage without adding locks or timeouts."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,time
p=argparse.ArgumentParser();p.add_argument('stage');p.add_argument('--attempt');a=p.parse_args()
base=Path('/workspace/geo318-formal-ae74e51b-round1');tools=Path(__file__).resolve().parent;label=a.stage+('-'+a.attempt if a.attempt else '');out=base/(label+'-launch');out.mkdir()
argv=['python3','-B',str(tools/'run_stage.py'),'--root','/workspace/geo318-reading-a-work','--sha','ae74e51bba1efef48949c077635966273a9e8990','--output',str(base/label),'--stage',a.stage,'--scheduler-slot','2']
def disk():
 return {p:{'available_bytes':os.statvfs(p).f_bavail*os.statvfs(p).f_frsize,'total_bytes':os.statvfs(p).f_blocks*os.statvfs(p).f_frsize} for p in ('/workspace','/tmp')}
def h(b):return hashlib.sha256(b).hexdigest()
record={'schema':'geo318-stage-launch/1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':'/workspace','authorization':'root explicitly assigned scheduler slot2; no extra R3; original stage and internal timeouts unchanged','source_sha':'ae74e51bba1efef48949c077635966273a9e8990','disk_before':disk(),'tool_sha256':{str(x):h(x.read_bytes()) for x in (Path(__file__),tools/'run_stage.py',tools/'native_with_compile_log_retention.py')},'environment':{k:os.environ.get(k) for k in ('PATH','LANG','LC_ALL','TMPDIR','PYTHONPATH','PYTHONOPTIMIZE','PYTHONDONTWRITEBYTECODE','CC','CFLAGS','CPPFLAGS','LDFLAGS')},'actual_exit_code':None}
path=out/'receipt.json'
def save():path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
save();start=time.monotonic()
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
 process=subprocess.Popen(argv,cwd='/workspace',stdout=stdout,stderr=stderr);record['pid']=process.pid;save();record['actual_exit_code']=process.wait()
record.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=time.monotonic()-start,disk_after=disk())
record['streams']={name:{'bytes':(out/name).stat().st_size,'sha256':h((out/name).read_bytes())} for name in ('stdout.bin','stderr.bin')};save()
print(json.dumps(record,ensure_ascii=False));raise SystemExit(record['actual_exit_code'])
