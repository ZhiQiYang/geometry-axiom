# #318 原 native 七方法／十一反證：實際收據獨立審查

固定 source `ae74e51bba1efef48949c077635966273a9e8990`。本輪獨立唯讀核對真 exit0，325 項 metadata／原檔位元組核對全符，findings 為空。沒有重跑、import 或修改受審測試／工具／產品，沒有編譯或瀏覽器。本報告只接受 actual 原件，公開包另審。

原 stderr 確為 `Ran 7 tests`、無附帶條件的 `OK`，不是從方法宣告推成功。前後 HEAD／status／cached 都綁同S且乾淨；原 stage、原 subreaper primary 及外層均0。原工具1f10／5dfe與先前純靜審對象一致；root slot2明列，未對原無鎖入口另加R3。

38筆真正 native 執行逐筆有 source SHA、環境、argv、binary SHA256、原stdout/stderr及0/1退出碼。五個正例全0；原10個W控制加actual H collector控制共11組，逐一保 baseline／mutant／restored=`0/1/0`、同原case、原精準具名 `ASSERT:`、baseline/restored binary hash相同且mutant不同。沒有用compiler/import/crash失敗冒充反證。

原 NativeBuild 251,112-byte build log SHA256 `8742439c414e604d3866c0d43273785b43299342bdd5daf07f8a6a5e98cfd855` 核同；所有原compile/link退出0並保原文字stdout/stderr，未見解碼replacement字元。69個真正compiler argv的暫存 `.c` 全部留存，逐一核bytes/hash；沒有只核宣告source list。十個W mutant C又逐一對immutable S原module重建，只改原指定anchor一處，與實際留存的compiler輸入完全相同。

H四檔原raw與同S Git blob逐bytes相等，baseline/withdrawn原raw相同；實際derived檔逐一重建，只允許CRLF→LF與字面include relocation，唯一語義差異是references.inc共同W判官委派撤回。四檔semantic及正規化relocated hash都只有references.inc不同。真正頂層compiler輸入H harness與留存H artifact相同；其include-chain current_geometry/web_bridge/references原件也分別保留，不冒稱它們各自都是直接compiler argv。

最初peer自身曾把include-chain的current_geometry.c當作獨立compiler argv，導致KeyError，原exit1保留在 `review318-native-actual-ae74e51b/`。這是reviewer metadata假設錯誤，不是產品紅燈；r2改核實際頂層H harness加完整四檔允許變換，沒有改產品／測試／原斷言，也沒有重跑任何case。

限制：原NativeBuild/compiler與harness子程序使用既有text capture，完整原頂層Python stdout/stderr則由c387逐bytes保存；不補造不存在的內層raw byte streams。H witness明確是already-placed typed World，這11組不能證明真正CLI可達順序，也不外推528／1056、oracle掃描或整份ledger。公開Ec3c封存／oracle13另待獨立覆核。
