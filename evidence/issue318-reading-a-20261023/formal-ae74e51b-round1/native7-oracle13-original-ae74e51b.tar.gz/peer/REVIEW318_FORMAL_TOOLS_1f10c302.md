# #318 第一輪執行工具純靜態對抗審

受審固定來源為 `ae74e51bba1efef48949c077635966273a9e8990`，不反向合入 noWood 後棒。本審查沒有 import 或執行受審工具、產品、測試、編譯、瀏覽器，也沒有重產帳本。

已逐字讀取 `formal-tools/run_stage.py`（SHA256 `1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a`）與 `native_with_compile_log_retention.py`（`5dfe683e297514e0888db7b525053997b41142e6bb3509805fabee659f4fbc10`），並對照原 c387 Recorder、原 subreaper、原 native 七方法、其實際 NativeBuild 的建置與 cleanup 路徑，以及 CLI 診斷 helper。未見阻擋三條 reader 原入口的新靜態缺陷。這不是 reader 或其餘十二項的動態通過聲明。

兩個先前具體工具缺口已修正：

1. 原 c387 的 timeout 會 SIGKILL reaper 所在 process group；原 reaper 卻對真正 test child 呼叫 `setsid()`。原版工具加外層 timeout 時，逾時可留下仍執行的子孫並讓 scheduler 進入下一項。新版對真正 stage 使用 `timeout=None`，原 capture/reaper bytes 與原測試內部時限均不改；不再以此外 watchdog 殺 forwarder。小型 Git／版本命令仍有原錄製器的有限等待，沒有產品／編譯子孫。
2. CLI helper 的 transport exit0 本來不保證兩支都放置成功。新版分開保留 `diagnostic_completed`、逐序回覆、`construction_route_observed` 與 `both_orders_succeeded`；只有至少一個已觀察的合法順序兩次 placement 真 accepted，才讓此施工路徑項通過。不新要求兩種任意順序都必須成功。原 helper exit0 仍原樣保留，不覆寫成產品程序 exit1。

排程遵照 root 的最新明示授權：原本無鎖的 reader／語意入口不額外加 R3，只記 root 指定的 `--scheduler-slot`；原 golden proof 的原 R3 自鎖不移除、不雙包，其 exact lock path 與既存檔檢查保留。slot 參數是 root 排程紀錄，不是自動取得其它階段授權。原 argv、完整原 stdout/stderr、環境、固定 SHA、前後 HEAD/status/index 及工具 hash 都有獨立收據；環境／原程序 failure 不以準備或外層成功掩蓋。

native observer 只以 audit hook 在原 `shutil.rmtree` 前讀取已存在的 `build-log.json` 與實際 compiler argv 指向的暫存 `.c`，沒有替換 NativeBuild、產品／測試函式或返回值。原 NativeBuild 的 `atexit` cleanup 路徑會觸發該 hook；原 test 自己保留四個 H raw／LF／semantic／relocated 檔與 manifest。若保留紀錄失敗，不能把殘缺收據當成突變 kill。正式 native 終態仍須逐項核真 Ran7／無 skip、十一個具名正常 assertion 的 0/1/0、編譯／執行原 streams 與 source-variant 身份，不能僅看 wrapper exit0。

後續條件與限制：

- `reader-generate` 若改出 dirty，原 SHA 上的後續 stage 會被 before guard 擋下。須先封原 dirty／原紅，另行恢復同 SHA 的乾淨物化或建立受控固定來源，才能收其他項；不可悄悄把重產後 bytes 算舊 S 通過。
- `golden-generate` 與逐 bytes compare 是兩個 gate，不能只取 compare 成功。原 committed golden 不回寫。
- 執行 CLI-build/order 前仍須把 fresh bridge 的實際 SHA256 與該 build 的 source／編譯收據連起來；這不是目前三個 reader 的阻擋。
- 靜審時發現 STAGES 同時宣稱全部未執行及前三已啟動，已回報 owner 修正成 current／歷史分開；以實際終態原件和後續公開包為準。沒有把該 metadata 更正當產品修法或新裁判。
- 本報告只接受上述固定工具的有限靜態範圍。三 reader 的實際原結果、公開包完整性及其餘正式項，都須各自依原收據另審，不外推全綠。
