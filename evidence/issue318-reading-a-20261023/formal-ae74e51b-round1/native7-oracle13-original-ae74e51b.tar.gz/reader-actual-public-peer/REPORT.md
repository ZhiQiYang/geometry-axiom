# #318 三個 reader 原結果與公開封存獨立對抗審

固定產品來源 `ae74e51bba1efef48949c077635966273a9e8990`，公開證據 `c5445caf5d26592ee870f884e5c0441a2a7b640f`。原來源是前棒 #318，不反向合入 noWood。獨立唯讀核對真 exit0，875 項 metadata／位元組核對全符，findings 為空。這是證據核對數，不是新增產品裁判或重跑測試。

三個原入口真退出碼為 0／0／0，原 unit stderr 確有 `Ran 51 tests` 與無附帶條件的 `OK`，無 skip。不是從 AST 宣告數或 producer 摘要推得成功。generate 原 JSON 為 patches90、五完整性斷言／獨立 SSOT／source_sections 皆 pass；check 原 JSON 為 patches0，保住它與實際重產入口的區別。每項的原 reaper 都真終態、primary_returncode0。

三項各九個原 command 的 argv、request/result、stdin、完整 stdout/stderr、原退出碼與 hash 均核對；前後 HEAD／status／cached guard 固定同 S 且乾淨。原工具 hash 1f10c302／5dfe683e 與獨立靜審對象相同，root slot2 有明記，原本無鎖的 reader 沒有額外加 R3；原 capture/reaper 未改，原 stage 外 timeout=None，內部時限未改。

直接讀 immutable Git E 的四個 payload，並獨立 ls-remote 核公開 branch 可達 E。public E 對 S 的差異只在 root evidence。archive 是 43,802 bytes，SHA256 `81e6b884e0814b2a75e055129b3efa1dc573285eca587665301ae9956d00deb8`；173 個 regular member 全部逐 bytes/hash 對 producer index、公開 tar 解碼與實際原件核同。另獨立走訪三個原 stage／launcher／source-cutover 目錄，核清單完整，沒有只信任 producer inventory。無 symlink、絕對路徑或 `..` archive member。

current metadata 已修正：三 reader executed=true、其餘未跑，沒有同時宣稱全部未執行。summary 明列 native/oracle scans 未跑、ledger 未產；本審查不外推其餘十二項、native 十一反證、oracle13、CLI 可達性、架構或完整 #318 驗收。

本次沒有執行、import 或修改任何產品／受審工具／測試，沒有編譯、瀏覽器、Git mutation、反向 merge、帳本重產或大型封存 hash。完整 Git 唯讀 command/exit/stdout/stderr/環境與875核對細項在同目錄 CHECKS.json／subcommands。受審工具的純靜態範圍另見 `REVIEW318_FORMAL_TOOLS_1f10c302.md`，不以本輪三 reader 的動態結果冒 native observer 已跑。
