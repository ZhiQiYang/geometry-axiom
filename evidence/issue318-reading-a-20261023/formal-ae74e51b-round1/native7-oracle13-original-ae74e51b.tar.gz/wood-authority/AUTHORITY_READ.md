# 木工判定權威已讀收據

本 owner 已完整讀取 main 決策佇列 2026-10-12～15、2026-10-22、2026-10-23 的各節，以及 PR #333 的 FIELD-RULES.md；這是後續 #318 木工規則判定前的前置閱讀。原始全文、Git argv、退出碼、stdout/stderr、環境與選段來源行號均在本目錄保留。沒有變更 repository、SSOT、決策佇列或任何 refs。

| 來源 | 固定 Git SHA | 原始檔 SHA256 |
|---|---|---|
| main 決策佇列.md | feb502d7b3bade2334733a4349c87ff91b88621e | a9f14cdd3cf2846c65d0a7cc32f02bf3a12ba60e817cd9223c59e4da6f4734e5 |
| PR #333 FIELD-RULES.md | 3d9bd9476b5eda05e1cb92338ee741b90019dff2 | 3305d8000af9814b91c2646cfcbbc841e1ead813fe3390e482f8bfc2a71c0ab2 |

`required-main-sections.md` 共 610 行，來源範圍及其 hash 見 REQUIRED_SECTIONS.json。12 個匹配區段含歷史追溯段落，沒有只搜尋到標題就宣稱已讀。

後續判定遵循已核可的閱讀 A 第 3 版：只有 boundary、固定完整定位外輪廓邊的端點可用正長度的已放木料側面接觸；目標木料角色不限。RC 真實表面放得下料寬時必須先貼料；薄階剩餘 RC 不計木材接觸，不新增 h_max。維持 I5、I20/R18、I22、R19(d)，不以例外繞過碰撞或具名 between 來源選擇，不把角色規則移入 K。

FIELD-RULES 明示自己是決策原句的現場摘錄，引用較早 main 4ccced59315d…，不是公理 SSOT 或額外改公理授權。#318 仍僅有使用者明示的 D11 一句、I19 例外三、R6(d)(e) 四處條文授權；本次沒有再增字。#314 Q3/Q4、B1 及既有數值決策均照已鎖定內容。歷史 WSL／排程指示依本次使用者明示雲端與 root 排程辦理；不合併 PR、不改 queue。

本收據僅證閱讀與來源固定，不是任何 native／oracle／施工測試通過證據。
