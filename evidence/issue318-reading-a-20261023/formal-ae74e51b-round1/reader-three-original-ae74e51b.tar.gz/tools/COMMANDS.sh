#!/usr/bin/env bash
# CATALOG ONLY: no stage may run without its own root scheduler window.
# First3 reader currently authorized; native/oracle/other stages are NOT authorized yet.
GEO318_ANY_RED=0
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/reader-generate --stage reader-generate --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/reader-check --stage reader-check --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/reader-unit --stage reader-unit --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/native-7 --stage native-7 --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/oracle-13 --stage oracle-13 --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/golden-source-proof --stage golden-source-proof --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/golden-generate --stage golden-generate --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/golden-compare --stage golden-compare --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/oracle-mutants --stage oracle-mutants --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/oracle-quick --stage oracle-quick --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/cli-build --stage cli-build --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/cli-order --stage cli-order --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/architecture-contract --stage architecture-contract --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/architecture-unit --stage architecture-unit --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py --root /workspace/geo318-reading-a-work --sha ae74e51bba1efef48949c077635966273a9e8990 --output /workspace/geo318-formal-ae74e51b-round1/product-architecture --stage product-architecture --scheduler-slot 2
GEO318_STAGE_EXIT=$?
if [ "$GEO318_STAGE_EXIT" -ne 0 ]; then GEO318_ANY_RED=1; fi
exit "$GEO318_ANY_RED"
