# #318 第一輪原裁判序列（三reader已0，其餘未跑）

固定已公開 source **ae74e51bba1efef48949c077635966273a9e8990**，不是 evidence573fb、不帶後項 noWood。後續上游真正final依 #323→#314→combined→#318→noWood 正常merge，依closure重驗；本輪先收齊既定紅燈，不等上游才開始。#323 perf/profile已於14:10:37終態；root現明配slot1跑323語意、slot2暫授本owner只跑三reader，之後先交314。三reader已於14:32:17真終態0/0/0、slot2已釋放交314；其它native/oracle/大掃仍未授時槽。

實際source為 `/workspace/geo318-reading-a-work`。原HEAD是乾淨evidence573fb；本輪已在owner自有既存sparse worktree正常 `git switch --detach ae74e51bba1efef48949c077635966273a9e8990`，cutover原命令全部0/streams已保，當前乾淨detached同受驗S。沒有新clone或integration／他人工作樹變更。正式完才回本owner branch收據commit。

既存sparse checkout沒有 package.json／geometry-web Python/JS 檔，這是先前source準備的物化範圍，不能冒產品缺檔。放行窗口後補物化同SHA的 `/package.json`、`/geometry-web/*.py`、`/geometry-web/*.js`、`/geometry-web/*.json`，保原sparse patterns與其它已物化K/W/H/docs/tests；只新增這些明確tracked來源，不重算大樹hash、不帶歷史evidence。source HEAD／index blob不得因此改。reader已獨立核212個必要tracked檔全在（含172scene、31SVG），三reader實際新物化0bytes；此處web/package物化僅供後續CLI/native完整來源若需要，不能把未跑環境宣稱成完成。

| 次序 | 原正式入口 | 原入口自帶R3 | 執行鎖與範圍 |
|---|---|---|---|
| 1–3 | `python3 -B geometry-guide/sync_axiom_reader.py`；加`--check`；`python3 -B tests/test_axiom_reader.py` | 都沒有 | 原入口無R3且不新增，由root明配最多兩個語意slot；sourcegen若bytes漂移即保真dirty紅，不能把它偷偷算舊S通過 |
| 4 | `python3 -B tests/test_geo318_reading_a_native.py -v` | 沒有（其NativeBuild也沒有） | 原7方法／10W+H共11具名0/1/0，root明配slot、16MiB stack，GEO318_ARTIFACT_DIR保原H四檔與derived manifest，GEO299316_EXECUTION_LOG保原harness輸出 |
| 5 | `python3 -B tests/test_geo318_reading_a_oracle.py -v` | 沒有 | 原13方法，含builder/checker兩組各0/1/0與凍結ID／漏掃負控，原入口不新增R3，root明配slot |
| 6 | 原evidence工具`prove_golden_witness.py --root <root> --sha <S> --output <new> --heavy-lock /tmp/g261r3/heavy.lock` | **本來有非阻塞R3** | 不再外包同鎖；獨立四檔副本／原nonempty具名斷言0/1/0，不能冒完整64排法 |
| 7–8 | `python3 -B geometry-core/framing-template/oracle/make_golden.py <rooms> <repo外generated>`；逐bytes對同S oracle-golden.json | 沒有 | 原入口不新增R3，root明配slot；不回寫committed golden，不跑--write-expected |
| 9 | `python3 -B geometry-core/framing-template/oracle/selftest.py --mutants-only` | 沒有 | 原入口不新增R3，root明配slot，原既有負控／手算／64golden，不是掃描 |
| 10 | 同selftest加`--quick` | 沒有 | 原入口不新增R3，root明配slot；原矩形一維逐mm左上Y＋二維臨界帶8排法，579凹角／壁龕／獨立柱全8，step/step_mirror凍結528/1056逐筆要求observed且buildable，不用CI抽樣或--write-expected；明列不是--full一維全8排法 |
| 11–12 | `python3 -B geometry-web/start_local.py --build-only --binary-dir <repo外cli-runtime>`；原`probe_cli_order.py --bridge <fresh bridge> --sha <S> --output <new.json>` | 沒有 | 原入口不新增R3，root明配slot；實橋兩種放置順序／完整stdin與逐行回覆；transport0不等於施工成功；另列diagnostic_completed／各order／construction_route_observed，至少觀察到一種原合法順序才有施工通路，不新增任意順序都必通的要求；兩序皆拒絕則passed/aggregate紅而原helper0仍保留。若真有已placed互依障礙，寫QUESTIONS並持續其它項，不改公理語意 |
| 13–15 | architecture_contract.py原manifest命令、test_architecture_contract.py、test_product_architecture.py | 沒有 | 各原入口不新增R3，root明配slot，原判官；H來源變動使歷史receipt過期須如實保紅，global帳本／manifest/scan/report/receipt最終刷新仍由root一次處理 |

每項真argv已列 STAGES.json／COMMANDS.sh，output為 `/workspace/geo318-formal-ae74e51b-round1/<stage>/`。root給窗口後逐stage跑，紅燈不阻止其它不受影響stage收證；只有golden既有self-R3忙時原proof會75、記未啟動，不能當skip成功；其餘語意入口不因自加鎖串行。短reader／具名語意先於quick。reader1/2估各數秒；readerunit約分鐘級；native7估1–3分鐘；oracle13／golden約秒至數十秒；quick依原README約十多分鐘，為估計而非新門檻。perf/profile期間完全不啟它們。

run_stage.py只選原入口，使用原c387 Recorder與原subreaper保存command／原exit／完整stdin/stdout/stderr／環境／SHA，前後HEAD/clean檢查及工具hash；外層收據passed不改寫原child exit。原stage外層capture使用timeout=None，不用c387的SIGKILL watchdog殺subreaper；原測試自己的10/20/30/300秒等時限原樣保留，reaper要等原case及其子孫真正終態；若原入口持R3則由原入口釋放，無鎖語意項只向root歸還其scheduler slot。原生測試透過額外純觀測wrapper runpy執行原7方法，sys.addaudithook只在原TemporaryDirectory cleanup前複製原NativeBuild build-log／實際compiled C bytes，不patch測試／NativeBuild／產品函式或返回值。所有H的LF relocation明列derived variant，不能稱未改F raw編譯。

工具AST語法檢查0；三reader已依root明示slot2真跑0/0/0，unit51方法全OK無skip；未跑任何native/oracle/大掃。同儕先指出的outer watchdog與CLI假綠兩點已修，最新root slot/noextraR3版完整窄審仍待，不能冒peer accepted。此輪不重產突變帳本、不擴大SSOT／決策字句、不放寬assert／golden／數值門檻。
