"""Prepare original tool bindings with Git metadata only; never execute subjects."""
from pathlib import Path
import ast, difflib, hashlib, importlib.util, json, os, sys

B = Path('/tmp/geo339-final-F38da-original-revalidation-preparation')
OLD = Path('/tmp/geo324-owner-20261024')
SOURCE = Path('/tmp/geo324-predicate-source-57b68014')
REPO = Path('/tmp/geo324-faces-work-20261024')
F = '38da31bcac91db631e6325e40b228f8604810e82'
OLD_S = '57b680140da2c6b77ab0d362a72029d8d7c9334b'
M = '1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
C = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not B.exists()
assert H(C) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
B.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', C)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
for name in ('PYTHONOPTIMIZE', 'NODE_OPTIONS', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
    env.pop(name, None)
env.update(PYTHONDONTWRITEBYTECODE='1', LC_ALL='C.UTF-8')
rec = cap.Recorder(B / 'original-metadata', env, F)
rows = []
def git(argv):
    row, out, err = rec.run(['git', *argv], cwd=REPO, timeout=120, source_sha=F, source_variant='preparation-only Git metadata; no subject execution')
    rows.append(row)
    return out

assert git(['rev-parse', F]).decode().strip() == F
old_plan = json.loads((OLD / 'native43-preparation/INPUT_MATERIALIZATION_PLAN.json').read_bytes())
paths = [x['path'] for x in old_plan['inputs']]
assert len(paths) == len(set(paths)) == 493
tree = git(['ls-tree', '-r', '-l', '-z', F, '--', *paths])
entries = {}
for entry in tree.split(b'\0'):
    if not entry:
        continue
    meta, name = entry.split(b'\t', 1)
    mode, kind, blob, size = meta.decode().split()
    assert kind == 'blob' and mode in ('100644', '100755')
    entries[name.decode()] = {'path': name.decode(), 'mode': mode, 'kind': kind, 'gitBlob': blob, 'bytes': int(size)}
assert set(entries) == set(paths)
new_plan = dict(old_plan)
new_plan.update(sourceSHA=F, preparedOnly=True, newMaterializationNotPerformed=True, inputs=[entries[x] for x in paths], logicalBytes=sum(x['bytes'] for x in entries.values()))
changed_inputs = [{'path': x['path'], 'priorS': x, 'fixedF': entries[x['path']]} for x in old_plan['inputs'] if x != entries[x['path']]]
N = B / 'native43'
N.mkdir()
cap.dump(N / 'INPUT_MATERIALIZATION_PLAN.json', new_plan)
(N / 'build_private_native.py').write_bytes((OLD / 'native43-preparation/build_private_native.py').read_bytes())
assert H(N / 'build_private_native.py') == '7ce1df108c78a22622306c88d9b4231f6a88774d006ed92f83ae05f041e575ca'
adaptations = []
diffs = []
def bind(original, output, changes):
    raw = original.read_text()
    bound = raw
    for before, after in changes:
        assert bound.count(before) == 1, (str(original), before, bound.count(before))
        bound = bound.replace(before, after, 1)
    ast.parse(bound)
    output.write_text(bound)
    adaptations.append({'original': str(original), 'originalSHA256': H(original), 'bound': str(output), 'boundSHA256': H(output), 'literalEdits': [{'before': x, 'after': y} for x,y in changes], 'execution': 'UNRUN'})
    diffs.extend(difflib.unified_diff(raw.splitlines(True), bound.splitlines(True), fromfile=str(original), tofile=str(output)))

for name, old_out, new_out in [
    ('run_pure_importer_suites_r2.py', '/tmp/geo324-pure-suite-57b68014-r2', '/tmp/geo339-pure65-F38da31bc'),
    ('run_more_pure_importers.py', '/tmp/geo324-more-pure-57b68014-r1', '/tmp/geo339-pure18-F38da31bc'),
    ('run_domain_pins_pure_r2.py', '/tmp/geo324-domain-pins-57b68014-r2', '/tmp/geo339-domain16-F38da31bc'),
]:
    bind(OLD / name, B / name, [("S='"+OLD_S+"'", "S='"+F+"'"), (old_out, new_out)])

bind(OLD / 'native43-preparation/run_native_importers.py', N / 'run_native_importers.py', [
    ("S='"+OLD_S+"'", "S='"+F+"'"),
    ('/tmp/geo324-native43-57b68014-r1', '/tmp/geo339-native43-F38da31bc'),
    ("PLAN_PIN='b4ff17ba27b50e27810cae2f3ba778e7ff44aa835f461db23a245f2bf4eca682'", "PLAN_PIN='"+H(N / 'INPUT_MATERIALIZATION_PLAN.json')+"'"),
    ('at S57, private outputs', 'at F38da, private outputs'),
])
(N / 'README.md').write_text('''# #339 F 原 native43 binding（尚未執行）

只改原 source SHA、fresh output、同493路徑新Git blob metadata與對應plan hash。原30+13、原900compile/60fallback/30capture/1200suite/2100外build收集/5000外launcher、全部assert/0skip不改。build_private_native.py逐bytes同，call-time OUT_DIR私有。

必先等root槽位，將既有獨立SOURCE從乾淨M切固定F並精確物化493清單；不得使用root live SOURCE／cache，不能把尚未執行的準備資料填成PASS。原 indexEqualBefore 只是完整stage listing，不是index原檔bytes。原module/binaries capture_output內pipes只保原程序公開部分，不冒稱所有內部raw。
''', encoding='utf-8')
manifest = {'preparedOnly': True, 'files': {n: {'bytes': (N/n).stat().st_size, 'sha256': H(N/n)} for n in ['INPUT_MATERIALIZATION_PLAN.json', 'run_native_importers.py', 'build_private_native.py', 'README.md']}}
cap.dump(N / 'FROZEN_MANIFEST.json', manifest)
bind(OLD / 'native43-preparation/launch_native43.py', N / 'launch_native43.py', [
    ("S='"+OLD_S+"'", "S='"+F+"'"),
    ('/tmp/geo324-native43-launch-57b68014-r1', '/tmp/geo339-native43-launch-F38da31bc'),
    ("PIN='5b98988806f9ccf64ded7901b627674be074d6ee8913ed9fc57ceca4a7a41b56'", "PIN='"+H(N / 'FROZEN_MANIFEST.json')+"'"),
    ('fixed-S57-original-native-importer-43-partial', 'fixed-F38da-original-native-importer-43-partial'),
])
predicate = OLD / 'preparation/run_face_predicate_proofs_v2.py'
full_native = Path('/tmp/native-final-executable-preparation/run_full_native_workflow_v2.py')
requests = {
    'role': 'preparation only; no tests/compiler/browser, no checkout/materialization/source/index/ref change',
    'targetExecutionSHA': F, 'latestReviewMirror': '/tmp/geo339-review-and-actions-40032957675/LATEST_REVIEW_339.md',
    'prior142AndPredicateExecutionSHA': OLD_S, 'priorFourGateExecutionSHA': M,
    'rootLNotEquivalentFor339': True, 'originalCapture': {'path': str(C), 'sha256': H(C)},
    'existingIndependentSource': {'path': str(SOURCE), 'observedCleanHEAD': M, 'deferredUntilRootSlot': True,
        'preparePlanOnly': [['git','-C',str(SOURCE),'checkout','--detach',F], ['git','-C',str(SOURCE),'sparse-checkout','set','--no-cone','--stdin']],
        'sparseStdin': '493 exact paths from native43/INPUT_MATERIALIZATION_PLAN.json; source guards must recheck actual Git bytes/mode/HEAD/clean before execution',
        'noNewClone': True, 'noPreparationMutationPerformed': True,
        'estimate': 'existing physical M root can narrow tracked materialization only after owner/root slot; no removal of raw/receipts/fixtures. Budget native43 outputs original60MiB plus ~7MiB selected source, predicate copies ~1MiB. Full-native runtime/source budget is NOT established here and requires root preparation.'},
    'rows': [
      {'gate': 'predicate list/dict/feature original0/1/0', 'status':'UNRUN', 'driver': str(predicate), 'driverSHA256': H(predicate), 'argv': [sys.executable,'-B',str(predicate),'--repo',str(SOURCE),'--expected-head',F,'--out','/tmp/geo339-three-predicates-F38da31bc'], 'originalMethodTimeout':60, 'scope':'original three behavioral methods and original TypeError/AttributeError normal failure diagnostic; not45/aggregate/browser'},
      *[{'gate': name, 'status':'UNRUN', 'argv':[sys.executable,'-B',str(B/name)], 'originalSuiteTimeout':1200} for name in ['run_pure_importer_suites_r2.py','run_more_pure_importers.py','run_domain_pins_pure_r2.py']],
      {'gate':'native43', 'status':'UNRUN', 'argv':[sys.executable,'-B',str(N/'launch_native43.py')], 'resourceLock':'/tmp/g261r3/secondary.lock', 'privateBinaries':'/tmp/geo339-native43-F38da31bc/binaries', 'originalCounts':[30,13]},
      {'gate':'aggregate full native / expected', 'status':'UNRUN', 'originalCLI':'ulimit -s 16384; python3 tests/run_all.py --build', 'driver':str(full_native), 'driverSHA256':H(full_native), 'argvTemplate':['env','-u','PYTHONOPTIMIZE',sys.executable,'-B',str(full_native),'--repo','<ROOT_PREPARED_CLEAN_F38DA_FULL_NATIVE_SOURCE>','--sha',F,'--out','/tmp/geo339-full-native-F38da31bc','--resource-lock','/tmp/g261r3/heavy.lock','--root-cache-quiescent'], 'originalCIminutes':35, 'collectionWatchdogFactor':3, 'sourceMaterialization':'NOT PREPARED; no fake ready argv or missingfile run', 'globalCache':'/tmp/geometry-tests original writable cache; quiescent rename/preservation under reviewed original wrapper, never overlap root native/global writer'}
    ],
    'suiteCounts':[45,10,10,9,8,1,16,30,13], 'partialMethodTotal':142,
    'controlSeparation':'3 normal predicate0/1/0 supplementary; do not count those as additional importer methods or full aggregate',
    'scheduling':['Pure three wrappers mutate private source sparse patterns: strictly sequential on this source.','Predicate driver writes only repo-external isolated copies but source checkout must stay frozen while it runs.','Native43 uses private OUT_DIR and original secondary.lock; no source/cache shared with current root native/browser.','Full-native has hard-coded global cache/logs: only root explicit exclusive cache-quiescent lease; root native now running means NOT eligible.','No canvas/performance overlap; no auto retries, no changed assertions/timeouts/golden, preserve each red and proceed independent items per root schedule.'],
    'changed493MetadataFromPriorS':changed_inputs,
    'originalJudgesAndHelpersNotEdited':True,
}
cap.dump(B / 'REQUESTS.json', requests)
cap.dump(B / 'BINDING.json', {'role':'literal source/output/hash metadata binding, not acceptance', 'targetExecutionSHA':F,'adaptations':adaptations,'inputPlanOriginalPath':str(OLD/'native43-preparation/INPUT_MATERIALIZATION_PLAN.json'),'inputPlanOriginalSHA256':H(OLD/'native43-preparation/INPUT_MATERIALIZATION_PLAN.json'),'inputPlanBoundSHA256':H(N/'INPUT_MATERIALIZATION_PLAN.json'),'same493PathSet':True,'newLogicalBytes':new_plan['logicalBytes'],'changedInputs':changed_inputs,'subjectExecuted':False,'checkoutMaterializedOrMoved':False})
(B / 'ADAPTATION.diff').write_text(''.join(diffs))
(B / 'README.md').write_text('''# #339 最新審查 B1/B3 復驗準備（不執行）

固定正式受驗F=38da31bcac91db631e6325e40b228f8604810e82；原142和predicate舊實跑仍S57b，四原gate實跑M1f0，沒有把它們轉標F。REQUESTS逐列UNRUN。root L不含本件，不繼承root綠。

本目錄只有小工具與Git metadata，不建checkout、不變更現有HEAD/index/sparse、不編譯、不跑Python subject/Chrome/bench。三pure wrappers只是原S/output字面綁定；native43仍同493精確path，以真F ls-tree blob/mode/size更新plan及hash，原helper逐bytes不動。正反例原driver完全未改。ADAPTATION.diff記所有工具差異。

先root排槽與預算，再將既有獨立/tmp/geo324-predicate-source-57b68014（現乾淨M）切到真F；精確物化plan，不新clone、不碰rootlive source/cache。這是待執行方案，不宣稱source ready。每項要事前c387 outer REQUEST、完整原stdout/stderr/exit/env/SHA及前後clean/bytes。保原45+10+10+9+8+1+16+30+13=142個方法與三個正常0/1/0控制；聚合fullnative是另外正式列，142不代替它。

完整native source/runtime budget未準備，保原工具argv模板而非盲跑missingfile假紅。shared/tmp/geometry-tests不可並行，特別現在root L native正在使用。六browser同樣不能借rootL成果轉標F。#339唯一owner，本線取代凍結舊#324；不推grok、不操作關PR，handoff由root統一。
''',encoding='utf-8')
files = {str(p.relative_to(B)): {'bytes':p.stat().st_size,'sha256':H(p)} for p in sorted(B.rglob('*')) if p.is_file()}
cap.dump(B / 'FROZEN_INVENTORY.json', {'preparedOnly':True,'excludesSelf':True,'files':files})
print(json.dumps({'directory':str(B),'targetF':F,'inputCount':493,'logicalBytes':new_plan['logicalBytes'],'changedInputCount':len(changed_inputs),'newSubjectRuns':0,'requestsSHA256':H(B/'REQUESTS.json'),'bindingSHA256':H(B/'BINDING.json'),'frozenSHA256':H(B/'FROZEN_INVENTORY.json')}))
