"""Publish completed independent CI reads and frozen revalidation preparation."""
from pathlib import Path
import hashlib, importlib.util, io, json, os, tarfile

R = Path('/tmp/geo324-faces-work-20261024')
D = Path('/tmp/geo324-faces-prbody-work-20261024')
F = '38da31bcac91db631e6325e40b228f8604810e82'
E0 = '47fd6a79090be021e853ba5016cbf6f14016b9aa'
D0 = 'e2f4bc20648cb6d48d5536d5852a2d959e9254c9'
BR = 'codex/geo324-faces-20261024'
P = 'evidence/geo339-review-followup-F38da'
O = Path('/tmp/geo339-review-followup-F38da-publication')
C = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not O.exists()
assert H(C) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
O.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', C)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env.update(PYTHONDONTWRITEBYTECODE='1', LC_ALL='C.UTF-8')
rec = cap.Recorder(O, env, F)
def git(args, cwd=R):
    return rec.run(['git',*args], cwd=cwd, timeout=180, source_sha=F, source_variant='own339 review and preparation publication; no product gate execution')[1]
cap.dump(O/'REQUEST.json',{'productSHA':F,'priorEvidence':E0,'priorBody':D0,'branch':BR,'publicationOnly':True,'subjectExecutions':0,'driverSHA256':H(__file__)})
for root, head in [(R,E0),(D,D0)]:
    assert git(['rev-parse','HEAD'],root).decode().strip()==head
    assert git(['status','--porcelain=v1','--untracked-files=all'],root)==b''
old_body=git(['show',D0+':PR_BODY.md'])
(O/'PR_BODY_PREVIOUS_E47fd.md').write_bytes(old_body)
dest=R/P
assert not dest.exists()
(dest/'raw').mkdir(parents=True)
originals={}
for label,root in [('independent-CI40032957675',Path('/tmp/geo339-review-and-actions-40032957675')),('final-F-original-tool-preparation',Path('/tmp/geo339-final-F38da-original-revalidation-preparation'))]:
    for path in sorted(root.rglob('*')):
        if path.is_file(): originals[label+'/'+path.relative_to(root).as_posix()]=path
originals['tools/capture.py']=C
originals['tools/prepare_geo339_f38da_original_bindings.py']=Path('/tmp/prepare_geo339_f38da_original_bindings.py')
originals['tools/publish_geo339_review_followup_F38da.py']=Path(__file__)
originals['prior-current-body/PR_BODY_E47fd.md']=O/'PR_BODY_PREVIOUS_E47fd.md'
inventory=[{'member':n,'originalPath':str(p),'bytes':p.stat().st_size,'sha256':H(p)}for n,p in sorted(originals.items())]
archive=dest/'raw/CI-classification-and-original-F-revalidation-preparation.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
    for item in inventory:
        raw=Path(item['originalPath']).read_bytes();info=tarfile.TarInfo(item['member']);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tf:
    assert len(tf.getmembers())==len(inventory)
    for item in inventory:
        raw=tf.extractfile(item['member']).read();assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'] and raw==Path(item['originalPath']).read_bytes()
cap.dump(dest/'RAW_INVENTORY.json',inventory)
cap.dump(dest/'PACKAGE.json',{'productSHA':F,'archive':archive.relative_to(dest).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSHA256':H(archive),'members':len(inventory),'inventorySHA256':H(dest/'RAW_INVENTORY.json'),'roundtripAllOriginalBytes':True,'newProductExecutions':0})
cap.dump(dest/'CURRENT_STATE.json',{'productF':F,'priorEvidenceE':E0,'priorFourGateExecutionM':'1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599','prior142AndPredicateExecutionS':'57b680140da2c6b77ab0d362a72029d8d7c9334b','formal11OriginalRoleCounts':{'PASS':3,'RED':1,'UNRUN':7},'formal11RoleLimit':'arch3 originalM with previously proven unchanged judge/input closure toF; ledger originalM1; no formalF run added here','B1':'BLOCKED; original stale ledger and native6browser unrun','B2':{'actionsRun':40032957675,'executionHead':E0,'originalJobsFailure':7,'independentlyReadAnnotationCause':'payment failure OR spending limit before runner/steps; not distinguished further','CIRepaired':False,'productResult':'UNRUN, not PASS/skip'},'B3':{'newF142OriginalImporters':'UNRUN','newFPredicateThree0_1_0':'UNRUN','aggregateFullNativeExpected':'UNRUN','originalToolsPreparationOnly':True},'C1':'This Codex #339 line is sole owner and replaces frozen old#324; root owns handoff redirect, no grok branch or PR closure written here','C2':'base#340 draft not merged; no PR merge/rebase; root controls later ordinarymerge convergence','rootLResultsInherited':False,'newCheckoutOrSourceMutation':False,'newSubjectExecutions':0,'questionsNeededForTechnicalPrep':False})
(dest/'PROGRESS.md').write_text('''# #339 最新審查後續

產品固定F38da，原四gate仍executionM1f0，原142／三predicate仍executionS57b；本次沒有產品、測試、HEAD受驗checkout或裁判變更／實跑。11正式列保持3PASS／1RED／7UNRUN，不以新準備填綠。

已fresh fetch handoff bfa19d004c1461e6740c192697a6c54896a98791，讀339.md最後22:39:42／head47fd審查。B1正式清單仍阻擋；B3要求最終F重跑142、三predicate0/1/0與aggregate，原S收據不能直接解除。

獨立讀Actions40032957675：13個原Git／gh命令全0，七check-run各明載帳戶付款失敗或支出上限；七runner_id0、steps空。這是排程前環境原因分類，未修CI、未重跑，七failure仍保，產品未執行不能算pass或skip。不沿338 annotations猜339。

已綁原工具到真F：同493路徑Git metadata、四輸入blob變更；原99Python＋43C／三正常0-1-0保持原判官／時限。只有工具source/output/hash機械綁定，完整native仍原另列工具與35min，完整source/cache磁碟未ready；現root native占用global cache，不啟任何subject。root L不含本線，不能轉標綠。

#339是唯一owner替代線，舊#324凍結；不推Grok、操作關PR或改公理／決策。base#340仍draft，待root後續ordinarymerge收斂；不rebase／forcepush／合併PR。下一步按root時槽固定真正final339受驗head並執行原B1/B3清單，紅燈完整保留分類。
''',encoding='utf-8')
cap.dump(dest/'MANIFEST.json',{'selfExcluded':True,'files':[{'path':p.relative_to(dest).as_posix(),'bytes':p.stat().st_size,'sha256':H(p)}for p in sorted(dest.rglob('*'))if p.is_file()]})
git(['add','--force','--sparse','--',P])
staged=git(['diff','--cached','--name-only']).decode().splitlines();assert staged and all(n.startswith(P+'/')for n in staged)
git(['diff','--cached','--check']);git(['commit','-m','evidence: record latest faces review and final-source rerun preparation'])
E=git(['rev-parse','HEAD']).decode().strip();git(['push','origin','HEAD:refs/heads/'+BR]);assert git(['ls-remote','--exit-code','origin','refs/heads/'+BR]).decode().split()[0]==E
body=old_body.decode()
body=body.replace('本輪新增真 M 的架構三條與帳本 check 收據，並在 Linux 依原 schema 刷新四檔。','原 M 架構三條與帳本 check、Linux 四檔仍保實際身份；本次補最新339審查、獨立CI原因與最終F復驗準備，未新增產品實跑。',1)
body=body.replace('| 本輪 evidence E | `'+E0+'` |','| 本輪 evidence E | `'+E+'` |',1)
body=body.replace('| 前一公開 evidence E | `dcdf22655e0cf8ed47cd0b7f66d89f3a7beca694` |','| 前一公開 evidence E | `'+E0+'` |',1)
body=body.replace('指定9/9 module、142/142，非完整 native','歷史指定9/9 module、142/142；本F重跑仍UNRUN，非完整 native',1)
body=body.replace('原正常斷言撤回／恢復','歷史原正常斷言撤回／恢復；本F仍UNRUN')
body=body.replace('root 的 b6／未定 final L 帳本','root 的 b6／最終L7af帳本',1)
body=body.replace('root L 尚未含本線 faces 修正','root L7af尚未含本線 faces 修正',1)
old_authority='審查依據為fresh handoff `e9a1b4abfe8df2bf99b7166db451fc3b7629f41f` 的 `handoff/pr-reviews/324.md` 最後【ChatGPT 審查】與轉交；同ref的339.md僅同步標頭，沒有新留言。未修改公理／決策、未force push、未合併PR。'
assert old_authority in body
body=body.replace(old_authority,'''最新已讀審查為fresh handoff `bfa19d004c1461e6740c192697a6c54896a98791` 的 `handoff/pr-reviews/339.md`，2026-10-23 22:39:42 UTC／head47fd。B1仍是帳本與七正式列未完；B3要求最終F（或新固定等價head）重跑142 importer、三predicate正常0/1/0及aggregate。本F工具已按原493路徑真Git metadata綁定、同原判官／斷言／時限，全部只是準備／UNRUN，沒有用歷史S結果抵免新要求。

B2 Actions [40032957675](https://github.com/ZhiQiYang/geometry-axiom/actions/runs/40032957675) 的七required job仍failure。已獨立取得七份check-run annotations，各明載「recent account payments have failed **or** your spending limit needs to be increased」；runner_id0、steps空。13原Git／gh命令均0並完整封存，不沿#338猜測，不把notice的Ubuntu遷移當失敗原因，也不能區分付款與上限兩者。此輪只讀分類，沒有修帳戶／重跑CI；B2未解除，產品未跑不算pass或skip。

C1：本#339為唯一owner替代線，舊#324凍結；root統一handoff重導向，這裡不推Grok或操作關PR。C2：base#340仍未合draft，待root排普通merge新穩定base收斂，無rebase或forcepush。所有新的原件與原F工具binding在 `evidence/geo339-review-followup-F38da/`，未修改公理／決策，未合併PR。''',1)
(O/'PR_BODY.md').write_text(body,encoding='utf-8')
assert body.count('唯一 current-state 矩陣')==1 and '3 PASS／1 RED／7 UNRUN' in body
request={'head':BR,'base':'codex/kernel-without-woodworking-20261023','title':'fix(GEO-261): reject malformed native snapshot face catalogs','body_ref':BR+'-prbody','body_path':'PR_BODY.md'}
cap.dump(O/'PR_REQUEST.json',request)
git(['merge','--no-edit',E],D)
(D/'PR_BODY.md').write_bytes((O/'PR_BODY.md').read_bytes())
git(['add','--force','--sparse','--','PR_BODY.md'],D)
assert git(['diff','--cached','--name-only'],D).decode().splitlines()==['PR_BODY.md']
git(['diff','--cached','--check'],D);git(['commit','-m','docs: distinguish latest faces blockers and final-source reruns'],D)
DD=git(['rev-parse','HEAD'],D).decode().strip();git(['push','origin','HEAD:refs/heads/'+BR+'-prbody'],D);assert git(['ls-remote','--exit-code','origin','refs/heads/'+BR+'-prbody'],D).decode().split()[0]==DD
cap.dump(O/'RESULT.json',{'sourceF':F,'evidenceE':E,'bodyD':DD,'branch':BR,'prefix':P,'bodySHA256':H(O/'PR_BODY.md'),'request':str(O/'PR_REQUEST.json'),'normalBothPushExit':0,'bothRemoteEqual':True,'subjectExecutions':0,'archiveSHA256':H(archive),'members':len(inventory)})
print(json.dumps({'sourceF':F,'evidenceE':E,'bodyD':DD,'bodySHA256':H(O/'PR_BODY.md'),'members':len(inventory),'subjectExecutions':0}))
