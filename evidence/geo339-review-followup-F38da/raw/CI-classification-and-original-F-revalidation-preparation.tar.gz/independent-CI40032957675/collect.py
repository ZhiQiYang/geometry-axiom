from pathlib import Path
import hashlib,importlib.util,json,os
P=Path(__file__).parent;C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');SHA='47fd6a79090be021e853ba5016cbf6f14016b9aa'
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None);env.update(PYTHONDONTWRITEBYTECODE='1',GH_PAGER='cat',GH_PROMPT_DISABLED='1');rec=cap.Recorder(P/'original-metadata',env,SHA)
def run(argv):
 row,out,err=rec.run(argv,cwd='/tmp/geo324-faces-work-20261024',timeout=120,check=False,source_sha=SHA,source_variant='read-only339 review and independentCI run audit; not product execution')
 print(json.dumps({'argv':argv,'exit':row['actual_process_returncode'],'directory':row['directory'],'stdoutBytes':len(out),'stderrBytes':len(err)}),flush=True);return row,out
ref='refs/remotes/origin/geo339-final-review-handoff'
r,_=run(['git','fetch','--no-write-fetch-head','origin','refs/heads/handoff/codex-takeover-20261021:'+ref])
if r['actual_process_returncode']==0:
 r,out=run(['git','rev-parse',ref]);head=out.decode().strip();r,out=run(['git','show',head+':handoff/pr-reviews/339.md'])
 if r['actual_process_returncode']==0:(P/'LATEST_REVIEW_339.md').write_bytes(out)
 cap.dump(P/'HANDOFF_SOURCE.json',{'head':head,'path':'handoff/pr-reviews/339.md','readOnlyFetchOnlyOwnTrackingRef':True})
for suffix,argv in [('RUN.json',['gh','run','view','40032957675','--repo','ZhiQiYang/geometry-axiom','--json','conclusion,createdAt,databaseId,displayTitle,event,headBranch,headSha,jobs,name,number,startedAt,status,updatedAt,url,workflowDatabaseId,workflowName']),('RUN.txt',['gh','run','view','40032957675','--repo','ZhiQiYang/geometry-axiom']),('JOBS.json',['gh','api','repos/ZhiQiYang/geometry-axiom/actions/runs/40032957675/jobs','--paginate'])]:
 r,out=run(argv)
 if r['actual_process_returncode']==0:(P/suffix).write_bytes(out)
if(P/'JOBS.json').is_file():
 jobs=json.loads((P/'JOBS.json').read_bytes())['jobs'];data=[]
 for job in jobs:
  r,out=run(['gh','api','repos/ZhiQiYang/geometry-axiom/check-runs/'+str(job['id'])+'/annotations','--paginate'])
  if r['actual_process_returncode']==0:data.append({'job':job['name'],'jobID':job['id'],'originalCommand':r,'annotations':json.loads(out)})
 cap.dump(P/'ANNOTATIONS.json',data)
