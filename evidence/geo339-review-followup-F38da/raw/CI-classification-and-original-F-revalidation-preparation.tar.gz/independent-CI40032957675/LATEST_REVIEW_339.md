# #339 的全部留言(本機 Claude 以 gh 讀取,原文照錄)

- 同步時間:2026-10-24 06:42(台北)
- 標題:fix(GEO-261): reject malformed native snapshot face catalogs
- 狀態:open


---
### 2026-10-23T22:39:42Z ZhiQiYang

【ChatGPT 審查】PR #339 head 47fd6a7

### 阻擋
- B1｜`evidence/geo339-final-1f0ebd3e/PROGRESS.md:3` 與正文一致記載正式 11 列僅 3 PASS／1 RED／7 UNRUN；mutation check 為 exit 1（107 stale、13 unrun），完整 native/expected 與六 browser 未跑。最小修正：在固定最終產品來源重產完整帳本並跑完這七列，保存原命令、exit、來源 SHA 與輸出。
- B2｜同 head 的 Actions run [40032957675](https://github.com/ZhiQiYang/geometry-axiom/actions/runs/40032957675) 七個 required jobs 全為 failure，jobs 無 runner/steps；目前沒有同 head 的 CI 接受證據。須先排除 workflow/環境失敗並取得可審核終態。
- B3｜產品 importer 142 項與三組 predicate 0/1/0 的 execution 是 S=`57b68014`，其後才 merge #340 成 M=`1f0ebd3e` 並刷新 F=`38da31bc`。正文也承認未在 F 重跑；因此這些結果不能證明目前組合來源。最小修正：在最終 F（或等價固定 head）重跑受影響 importer、predicate 撤回/恢復及 aggregate native，不能只移標舊 S 收據。

### 須改
- C1｜#324 仍開啟且承載相同 faces 修正；本 PR 又自稱替代線。合併前須明確標記唯一 owner/接替關係並關閉或重新定向被取代線，避免兩條重疊修正各自累積收據。
- C2｜PR 目前以尚未合併的 draft #340 分支為 base；#340 未驗收前，本 PR 也無法形成可獨立接受的主線變更。請在 #340 定案後重基底/更新比較，再重跑 B3。

### 記錄
- `model_sources.py:73-89` 對缺失、非 list、非 dict、非字串 feature 統一轉成既有 I32 分類，定向測試與逐 predicate 撤回設計合理；本輪未見該葉補丁本身的新語意錯誤。

結論：目前不可合併；維持 draft。

