#!/usr/bin/env python3
"""Original unittest runner, three compiler-free suites, exact S and private outputs."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

B=Path('/tmp/geo324-owner-20261024');O=Path('/tmp/geo339-pure65-F38da31bc');R=Path('/tmp/geo324-predicate-source-57b68014')
S='38da31bcac91db631e6325e40b228f8604810e82'
HELPER=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
SUITES=('test_geometry_host_sources','test_geometry_source_runtime','test_geometry_kernel_runtime')
if O.exists():raise SystemExit('refuse overwrite')
if hashlib.sha256(HELPER.read_bytes()).hexdigest()!=PIN:raise SystemExit('capture pin mismatch')
O.mkdir();spec=importlib.util.spec_from_file_location('capture',str(HELPER));cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy();removed={k:None for k in env if k.startswith('GEOMETRY_')}
for key in [*removed,'PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS']:env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
rec=cap.Recorder(O,env,S)
request={'sourceSHA':S,'source':str(R),'suiteFiles':list(SUITES),'originalRunner':'tests/_unittest_runner.py','nativeCompilation':False,'browserPerf':False,'R3':'not taken; compiler-free original Python suites','originalAggregateTimeoutSeconds':1200,'selectedRegistryNeeds':{s:[] for s in SUITES},'removedGeometryVariableNames':list(removed),'explicitPythonOverrides':{k:env.get(k) for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP')},'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
cap.dump(O/'REQUEST.json',request);report={'request':request,'rows':[],'exitCode':None,'errors':[],'fullNativeOrWorkflow':False}
def run(a,check=True,timeout=180):return rec.run(a,cwd=R,timeout=timeout,check=check,source_sha=S,source_variant='original-compiler-free-python-importer-partial')
try:
    _,head,_=run(['git','rev-parse','HEAD']);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
    if head.decode().strip()!=S or clean:raise RuntimeError('subject not exact clean S')
    run(['git','sparse-checkout','add','/tests/_unittest_runner.py','/tests/binaries.py','/tests/__init__.py','/tests/run_all.expected.json'])
    packages=['geometry-core/geometry_kernel','geometry-core/modeling','geometry-app/geometry_app','geometry-templates/woodworking/geometry_woodworking']
    names=[*packages,'tests/_unittest_runner.py','tests/binaries.py','tests/__init__.py','tests/run_all.expected.json',*['tests/'+s+'.py' for s in SUITES]]
    _,tree,_=run(['git','ls-tree','-r','-z',S,'--',*names]);inputs=[]
    for entry in tree.split(b'\0'):
        if not entry:continue
        header,path=entry.split(b'\t',1);mode,kind,blob=header.decode().split();path=path.decode();_,raw,_=run(['git','show',S+':'+path])
        if kind!='blob' or mode not in ('100644','100755') or (R/path).read_bytes()!=raw or hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()!=blob:raise RuntimeError('exact input mismatch: '+path)
        inputs.append({'path':path,'mode':mode,'gitBlob':blob,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    cap.dump(O/'INPUTS.json',inputs)
    expected=json.loads((R/'tests/run_all.expected.json').read_text())['suites']
    for suite in SUITES:
        directory=O/suite;directory.mkdir();argv=[sys.executable,str(R/'tests/_unittest_runner.py'),str(R/'tests'/f'{suite}.py'),'--json-out',str(directory/'result.json'),'--log',str(directory/'unittest.log')]
        original,_,_=run(argv,check=False,timeout=1200)
        data=json.loads((directory/'result.json').read_text()) if (directory/'result.json').is_file() else None
        report['rows'].append({'suite':suite,'executionSHA':S,'originalCommand':argv,'originalProcessExit':original['actual_process_returncode'],'timeout':original['timeout_expired'],'originalResult':data,'expectedContract':expected['py:'+suite],'scope':'complete one original unittest module, PARTIAL project; native transport remains original synthetic fixture where used'})
    _,head,_=run(['git','rev-parse','HEAD']);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
    report['sourceAfter']={'head':head.decode().strip(),'porcelain':clean.decode()}
    report['exitCode']=0 if report['sourceAfter']=={'head':S,'porcelain':''} and all(r['originalProcessExit']==0 and not r['timeout'] and r['originalResult'] and r['originalResult']['total']==r['expectedContract']['count'] and r['originalResult']['failed']==0 and r['originalResult']['skipped']==0 for r in report['rows']) else 1
except BaseException as error:report['errors'].append(repr(error));report['exitCode']=2
finally:
    report['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['commandCount']=len(rec.rows);cap.dump(O/'receipt.json',report);print(json.dumps(report,ensure_ascii=False))
raise SystemExit(report['exitCode'])
