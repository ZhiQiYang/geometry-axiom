#!/usr/bin/env python3
"""Original host native30 and default native13 at F38da, private outputs, no global cache."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
S='38da31bcac91db631e6325e40b228f8604810e82'
D=Path(__file__).resolve().parent
R=Path('/tmp/geo324-predicate-source-57b68014')
O=Path('/tmp/geo339-native43-F38da31bc')
HELPER=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
HPIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
PLAN_PIN='ab0aeb4ffcc4003f2e644e89bb473ba00e6a172c4f6f3f028c3206f38543c04b'
BUILD_PIN='7ce1df108c78a22622306c88d9b4231f6a88774d006ed92f83ae05f041e575ca'
def sha(x):return hashlib.sha256(x).hexdigest()
if O.exists():raise SystemExit('refuse overwrite')
if sha(HELPER.read_bytes())!=HPIN or sha((D/'INPUT_MATERIALIZATION_PLAN.json').read_bytes())!=PLAN_PIN or sha((D/'build_private_native.py').read_bytes())!=BUILD_PIN:raise SystemExit('frozen tool/input plan mismatch')
plan=json.loads((D/'INPUT_MATERIALIZATION_PLAN.json').read_bytes())
if plan['sourceSHA']!=S:raise SystemExit('wrong source plan')
O.mkdir();(O/'tmp').mkdir()
spec=importlib.util.spec_from_file_location('capture',HELPER);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);removed=[k for k in env if k.startswith('GEOMETRY_')]
for k in [*removed,'PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS']:env.pop(k,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8',TMPDIR=str(O/'tmp'),GITHUB_SHA=S,GIT_OPTIONAL_LOCKS='0')
rec=cap.Recorder(O,env,S)
request={'sourceSHA':S,'source':str(R),'originalRunner':'tests/_unittest_runner.py','originalSuites':['test_geometry_host_native','test_geo261_default_native'],'expectedMethods':[30,13],'originalSuiteTimeoutSeconds':1200,'buildHelper':str(D/'build_private_native.py'),'buildHelperSha256':BUILD_PIN,'driverSha256':sha(Path(__file__).read_bytes()),'captureSha256':HPIN,'inputPlanSha256':PLAN_PIN,'privateBinaries':str(O/'binaries'),'phaseOverrides':{'host_native':{'GEOMETRY_MODEL_BASE':None,'GEOMETRY_TEST_BRIDGE':None},'default_native':{'GEOMETRY_MODEL_BASE':str(O/'binaries/model-base'),'GEOMETRY_TEST_BRIDGE':str(O/'binaries/bridge')}},'removedGeometryVariableNames':removed,'environment':{k:env.get(k) for k in ['PATH','TMPDIR','CC','CFLAGS','CPPFLAGS','LDFLAGS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONDONTWRITEBYTECODE','GITHUB_SHA']},'limits':'原compile900s/host fallback60s/default capture30s均不改；外層build兩目標總2100s只用於收集，不取代原限制。','scope':'兩原Python module與其真C transport；PARTIAL project，非完整native/browser/全importers。','startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
cap.dump(O/'REQUEST.json',request)
report={'request':request,'rows':[],'errors':[],'exitCode':None,'nativeProjectFull':False,'sourceModified':False,'internalPipeLimit':'原tests/binaries.py與module內部subprocess有capture_output；僅原程序實際公開的stdout/stderr完整封存，不另聲稱內部全部pipes均由外部逐筆公開。'}
def run(argv,check=True,timeout=180,data=None):return rec.run(argv,cwd=R,timeout=timeout,check=check,data=data,source_sha=S,source_variant='original-native-importer-two-module-partial')
def suite(name,env_for_suite):
 directory=O/name;directory.mkdir()
 argv=[sys.executable,str(R/'tests/_unittest_runner.py'),str(R/'tests'/(name+'.py')),'--json-out',str(directory/'result.json'),'--log',str(directory/'unittest.log')]
 previous=rec.env;rec.env=env_for_suite
 try:row,_,_=run(argv,check=False,timeout=1200)
 finally:rec.env=previous
 result=json.loads((directory/'result.json').read_bytes()) if (directory/'result.json').is_file() else None
 report['rows'].append({'suite':name,'executionSHA':S,'originalProcessExit':row['actual_process_returncode'],'timeout':row['timeout_expired'],'originalResult':result,'originalCommand':argv,'expectedContract':expected['py:'+name]})
try:
 _,head,_=run(['git','rev-parse','HEAD']);_,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
 if head.decode().strip()!=S or status:raise RuntimeError('initial source not exact clean S')
 _,index,_=run(['git','ls-files','--stage','-z'])
 paths=[x['path'] for x in plan['inputs']]
 for parent,dirs,files in os.walk(R):
  dirs[:]=[x for x in dirs if x not in ('.git','__pycache__')]
  for name in files:
   f=Path(parent)/name
   if f.suffix in ('.py','.json','.c','.h','.inc') and f.relative_to(R).as_posix() not in paths:raise RuntimeError('unlisted existing code/data input: '+str(f))
 run(['git','sparse-checkout','add','--stdin'],data=('\n'.join('/'+p for p in paths)+'\n').encode())
 _,batch,_=run(['git','cat-file','--batch'],data=''.join(S+':'+p+'\n' for p in paths).encode())
 cursor=0;inputs=[]
 for item in plan['inputs']:
  pos=batch.index(b'\n',cursor);header=batch[cursor:pos].split();length=int(header[2]);start=pos+1;raw=batch[start:start+length];cursor=start+length+1
  p=R/item['path']
  if header[0].decode()!=item['gitBlob'] or header[1]!=b'blob' or length!=item['bytes'] or batch[cursor-1:cursor]!=b'\n' or not p.is_file() or p.is_symlink() or p.read_bytes()!=raw:raise RuntimeError('tracked Git input mismatch: '+item['path'])
  inputs.append({**item,'rawSha256':sha(raw),'lfSha256':sha(raw.replace(b'\r\n',b'\n'))})
 if cursor!=len(batch):raise RuntimeError('Git batch surplus bytes')
 cap.dump(O/'INPUTS_BEFORE.json',inputs)
 expected=json.loads((R/'tests/run_all.expected.json').read_bytes())['suites']
 if [expected['py:'+n]['count'] for n in request['originalSuites']]!=[30,13]:raise RuntimeError('original expected contract differs')
 suite('test_geometry_host_native',env)
 original_build,_,_=run([sys.executable,'-B',str(D/'build_private_native.py'),str(R),str(O/'binaries'),next(x['rawSha256'] for x in inputs if x['path']=='tests/binaries.py')],check=False,timeout=2100)
 report['buildOriginalProcessExit']=original_build['actual_process_returncode'];report['buildTimeout']=original_build['timeout_expired']
 native_env=dict(env);native_env.update(GEOMETRY_MODEL_BASE=str(O/'binaries/model-base'),GEOMETRY_TEST_BRIDGE=str(O/'binaries/bridge'))
 suite('test_geo261_default_native',native_env)
 after=[]
 for item in inputs:
  p=R/item['path'];raw=p.read_bytes();after.append({**item,'rawSha256':sha(raw),'lfSha256':sha(raw.replace(b'\r\n',b'\n'))})
 cap.dump(O/'INPUTS_AFTER.json',after)
 _,head,_=run(['git','rev-parse','HEAD']);_,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);_,lastindex,_=run(['git','ls-files','--stage','-z'])
 report['sourceAfter']={'head':head.decode().strip(),'porcelain':status.decode(),'inputsEqualBefore':inputs==after,'indexEqualBefore':index==lastindex}
 binaries=[]
 for p in sorted((O/'binaries').glob('*')) if (O/'binaries').is_dir() else []:
  if p.is_file():binaries.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
 report['binaryArtifacts']=binaries
 report['exitCode']=0 if report['sourceAfter']=={'head':S,'porcelain':'','inputsEqualBefore':True,'indexEqualBefore':True} and report['buildOriginalProcessExit']==0 and not report['buildTimeout'] and all(x['originalProcessExit']==0 and not x['timeout'] and x['originalResult'] and x['originalResult']['total']==x['expectedContract']['count'] and x['originalResult']['run']==x['expectedContract']['count'] and x['originalResult']['failed']==0 and x['originalResult']['skipped']==0 for x in report['rows']) else 1
except BaseException as error:report['errors'].append(repr(error));report['exitCode']=2
finally:
 report['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['commandCount']=len(rec.rows);cap.dump(O/'receipt.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
raise SystemExit(report['exitCode'])
