# #339 F 原 native43 binding（尚未執行）

只改原 source SHA、fresh output、同493路徑新Git blob metadata與對應plan hash。原30+13、原900compile/60fallback/30capture/1200suite/2100外build收集/5000外launcher、全部assert/0skip不改。build_private_native.py逐bytes同，call-time OUT_DIR私有。

必先等root槽位，將既有獨立SOURCE從乾淨M切固定F並精確物化493清單；不得使用root live SOURCE／cache，不能把尚未執行的準備資料填成PASS。原 indexEqualBefore 只是完整stage listing，不是index原檔bytes。原module/binaries capture_output內pipes只保原程序公開部分，不冒稱所有內部raw。
