# #339 最新審查 B1/B3 復驗準備（不執行）

固定正式受驗F=38da31bcac91db631e6325e40b228f8604810e82；原142和predicate舊實跑仍S57b，四原gate實跑M1f0，沒有把它們轉標F。REQUESTS逐列UNRUN。root L不含本件，不繼承root綠。

本目錄只有小工具與Git metadata，不建checkout、不變更現有HEAD/index/sparse、不編譯、不跑Python subject/Chrome/bench。三pure wrappers只是原S/output字面綁定；native43仍同493精確path，以真F ls-tree blob/mode/size更新plan及hash，原helper逐bytes不動。正反例原driver完全未改。ADAPTATION.diff記所有工具差異。

先root排槽與預算，再將既有獨立/tmp/geo324-predicate-source-57b68014（現乾淨M）切到真F；精確物化plan，不新clone、不碰rootlive source/cache。這是待執行方案，不宣稱source ready。每項要事前c387 outer REQUEST、完整原stdout/stderr/exit/env/SHA及前後clean/bytes。保原45+10+10+9+8+1+16+30+13=142個方法與三個正常0/1/0控制；聚合fullnative是另外正式列，142不代替它。

完整native source/runtime budget未準備，保原工具argv模板而非盲跑missingfile假紅。shared/tmp/geometry-tests不可並行，特別現在root L native正在使用。六browser同樣不能借rootL成果轉標F。#339唯一owner，本線取代凍結舊#324；不推grok、不操作關PR，handoff由root統一。
