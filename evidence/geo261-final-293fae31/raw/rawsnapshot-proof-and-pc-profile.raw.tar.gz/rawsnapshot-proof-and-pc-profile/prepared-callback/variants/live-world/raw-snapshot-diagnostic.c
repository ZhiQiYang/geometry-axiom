/* Prepared diagnostic only. The old callback below is injected from a Git blob.
 * Provider hooks delegate to the actual registered evaluators before mutation.
 * No geo_eval_source macro or replacement exists in this translation unit. */
#include "/workspace/geo261-environment/raw-snapshot-callback-equivalence-v2-20261022/variants/live-world/geo261_host_facts_authority_harness.c"

static bool reference_contact_facts_before(void *opaque,GeoEvalContext *evaluation,
    const WoodContactSourceRequest *request,WoodContactSourceFacts *out)
{
    ReferenceEval *ctx=opaque;if(evaluation!=ctx->sources)return false;
    PlacementSurface placement;SpaceBoundarySurface boundary;
    const SpaceBoundarySurface *b;
    if(!reference_host_read(ctx,request->placement_id,&placement,&boundary,&b))return false;
    AppContactFacts facts;app_contact_facts(ctx->world,&placement,b,&facts);
    out->region_count=facts.world.region_count;
    for(size_t i=0;i<out->region_count;++i)out->regions[i]=*facts.world.regions[i];
    out->member_count=facts.world.member_count;
    for(size_t i=0;i<out->member_count;++i){
        WoodContactMemberFact *fact=&out->members[i];*fact=facts.members[i];
        if(!fact->member->placed||fact->member==request->exclude)continue;
        uint32_t id=fact->member->id;GeoSourceValue value;
        if(!ctx->use_current_values){WoodMemberPlacementContact anchor;
            if(!wood_definition_sources_placement_contact(ctx->definition_sources,id,&anchor))return false;
            fact->placement_id=anchor.placement_id;fact->order=anchor.order;
            fact->along_v=anchor.length_direction==GEO_DIRECTION_POS_V||anchor.length_direction==GEO_DIRECTION_NEG_V;
        }
        if(fact->placement_id!=request->placement_id){fact->footprint_valid=false;continue;}
        if(ctx->use_current_values&&!fact->footprint_valid)continue;
        if(geo_eval_source(ctx->sources,(GeoSourceRef){APP_SOURCE_MEMBER_POSE,&id,sizeof id},GEO_DEPENDENCY_VALUE_REQUIRED,&value)!=GEO_SOURCE_OK)return false;
        WoodMember geometry=*fact->member;geometry.origin=value.as.box.frame.origin;
        geometry.axis_length=value.as.box.frame.axis_u;geometry.axis_a=value.as.box.frame.axis_v;geometry.axis_b=value.as.box.frame.normal;
        geometry.length=value.as.box.extent[0];geometry.size_a=value.as.box.extent[1];geometry.size_b=value.as.box.extent[2];
        GeoQuad3 face;fact->footprint_valid=wood_member_face_room(&geometry,WOOD_MEMBER_FACE_A0,&face);
        if(fact->footprint_valid){
            GeoPoint2 first=geo_frame_project_uv(&placement.frame,face.vertices[0]);
            fact->footprint=(GeoRect2){first.u,first.v,first.u,first.v};
            for(size_t v=1;v<4;++v){GeoPoint2 point=geo_frame_project_uv(&placement.frame,face.vertices[v]);
                fact->footprint.min_u=coord_min(fact->footprint.min_u,point.u);fact->footprint.max_u=coord_max(fact->footprint.max_u,point.u);
                fact->footprint.min_v=coord_min(fact->footprint.min_v,point.v);fact->footprint.max_v=coord_max(fact->footprint.max_v,point.v);
            }
        }
    }
    return true;
}


static HostFacts *rs_hf_setup(HostFacts *f,unsigned mode)
{
    memset(f,0,sizeof *f);f->mode=mode;f->ctx.world=&f->world;
    SpaceBoundarySurface b={.id=7,.outline={.v={{0,0},{100,0},{100,100},{0,100}},.count=4}};
    if(mode==HF_END){b.outline=(PolygonLoop2){.v={{0,0},{100,0},{100,50},{50,50},{50,100},{0,100}},.count=6};
        for(size_t i=0;i<6;++i)b.outline.fixity[i]=EDGE_FIXED;}
    if(!app_boundary_stage(&f->world,&b))return NULL;b.id=8;
    for(size_t i=0;i<4;++i)b.outline.fixity[i]=EDGE_FIXED;
    if(mode==HF_RECT_REF){b.hole_count=1;b.holes[0]=(PolygonLoop2){.v={{40,40},{40,60},{60,60},{60,40}},.count=4};
        for(size_t i=0;i<4;++i)b.holes[0].fixity[i]=EDGE_FIXED;}
    if(!app_boundary_stage(&f->world,&b))return NULL;
    PlacementSurface p={.id=7,.frame={{0,0,0},{1,0,0},{0,1,0},{0,0,1}},.rect={0,0,100,100}};
    if(mode==HF_REF||mode==HF_REF_RECT||mode==HF_END)p.boundary_id=7;
    if(mode==HF_RAW_DERIVED)p.derived_fill_id=55;
    if(!app_placement_stage(&f->world,&p))return NULL;
    f->actual=*geo_placements_find(&f->world.geo.placement_data,7);
    if(mode==HF_REF||mode==HF_RECT_REF){f->actual.domain=GEO_PLACEMENT_REGION_REF;f->actual.region_id=8;}
    if(mode==HF_REF_RECT){f->actual.domain=GEO_PLACEMENT_RECT;f->actual.rect=(GeoRect2){10,20,90,80};}
    if(mode==HF_RAW_DERIVED){f->actual.domain=GEO_PLACEMENT_RECT;f->actual.rect=(GeoRect2){0,0,100,100};}
    if(mode==HF_ACTUAL_DERIVED){f->actual.domain=GEO_PLACEMENT_REGION_SET;f->actual.component_count=0;}
    f->placement_size=geo_placement_definition_encode(&f->actual,f->placement,sizeof f->placement);
    if(!f->placement_size)return NULL;
    if(mode==HF_MOVED||mode==HF_END){
        f->world.wood.timber_count=1;
        f->world.wood.timbers[0]=(WoodMember){.id=41,.length=100,.size_a=10,.size_b=5,.placed=true,.auto_length=true,
            .role=WOOD_MEMBER_ROLE_BOUNDARY,.cut_priority=1,.origin={0,mode==HF_END?45:20,0},.axis_length={1,0,0},.axis_a={0,1,0},.axis_b={0,0,1}};
        f->world.wood.anchors[0]=(WoodMemberPlacement){.placement_id=mode==HF_END?7:8,.uv={0,mode==HF_END?45:0},.order=1,.anchor_kind=WOOD_ANCHOR_AT,
            .length_direction=mode==HF_END?GEO_DIRECTION_POS_V:99,.depth_side=WOOD_DEPTH_POSITIVE_NORMAL};
    }
    if(mode==HF_RC){
        GeoEnclosure room={.id=1,.min={0,0,0},.max={50,50,50}};
        if(!geo_enclosures_stage(&f->world.geo.enclosures,&room))return NULL;
        room.id=2;for(size_t a=0;a<3;++a)room.max[a]=10;
        if(!geo_enclosures_stage(&f->world.geo.enclosures,&room))return NULL;
        f->world.wood.column_count=1;f->world.wood.columns[0]=(WoodColumn){.id=11,.space_id=1,.x_lo=20,.x_hi=40,.y_lo=20,.y_hi=40,.z_lo=0,.z_hi=50};
        f->world.wood.beam_count=1;f->world.wood.beams[0]=(WoodBeam){.id=12,.space_id=1,.axis=0,.x_lo=20,.x_hi=40,.y_lo=20,.y_hi=40,.z_lo=30,.z_hi=50};
    }
    memcpy(&f->before,&f->world,sizeof f->world);if(!hf_install(f))return NULL;return f;
}


enum {RS_BASE,RS_UNPLACED,RS_EXCLUDED,RS_FOREIGN,RS_MOVED,RS_LENGTH_ZERO,RS_LENGTH_NEG,
    RS_DIRECTION,RS_DIRECTION_MIN,RS_DEPTH,RS_DEPTH_MIN,RS_FUTURE_UV,RS_FUTURE_LENGTH,
    RS_FUTURE_PLACED,RS_ANCHOR_FAIL,RS_POSE_FAIL,RS_POSE_UNPLACES,RS_PHASE_TRUE,
    RS_PHASE_ROUNDTRIP,RS_ENTRY_TRUE_TO_FALSE};
static const char *const rs_names[]={"baseline","unplaced","excluded","foreign","moved",
    "length-zero","length-negative","direction-unknown","direction-min","depth-unknown",
    "depth-min","future-uv","future-length","future-placed","anchor-fail","pose-fail",
    "pose-unplaces","phase-false-to-true","phase-roundtrip","phase-entry-true-to-false"};
typedef struct {
    GeoProviderToken token;
    bool (*describe)(void *,const GeoSourceRef *,GeoSourceDescriptor *);
    HostFactsEvaluate evaluate;
} RSProvider;
typedef struct {
    HostFacts *fixture;unsigned scenario,phase,mutations,failures;
    unsigned pose_calls[4];bool phase_raw_invalid;
    RSProvider providers[64];size_t provider_count;
    unsigned char anchor_bytes[4][4096];FILE *calls;
} RSRun;
static RSRun *rs_active;
static void rs_hex(FILE *out,const void *data,size_t size)
{const unsigned char *p=data;if(!p&&size){fputs("NULL",out);return;}for(size_t i=0;i<size;++i)fprintf(out,"%02x",p[i]);}
static void rs_ref(FILE *out,const GeoSourceRef *ref)
{fprintf(out,"provider=%u key_size=%zu key=",ref->provider,ref->key_size);rs_hex(out,ref->key,ref->key_size);}
static RSProvider *rs_provider(GeoProviderToken token)
{for(size_t i=0;i<rs_active->provider_count;++i)if(rs_active->providers[i].token==token)return &rs_active->providers[i];return NULL;}
static bool rs_describe(void *state,const GeoSourceRef *ref,GeoSourceDescriptor *out)
{
    RSRun *r=rs_active;RSProvider *p=rs_provider(ref->provider);if(!p)return false;
    fputs("DESCRIBE_ENTER ",r->calls);rs_ref(r->calls,ref);fprintf(r->calls," current=%d\n",r->fixture->ctx.use_current_values);
    bool ok=p->describe(state,ref,out);
    fputs("DESCRIBE_RETURN ",r->calls);rs_ref(r->calls,ref);fprintf(r->calls," ok=%d current=%d\n",ok,r->fixture->ctx.use_current_values);return ok;
}
static int rs_member_index(const HostFacts *f,uint32_t id)
{for(size_t i=0;i<f->world.wood.timber_count;++i)if(f->world.wood.timbers[i].id==id)return (int)i;return -1;}
static bool rs_evaluate(void *state,GeoEvalContext *graph,const GeoSourceRef *ref,GeoSourceValue *out)
{
    RSRun *r=rs_active;HostFacts *f=r->fixture;RSProvider *p=rs_provider(ref->provider);if(!p)return false;
    fputs("EVALUATE_ENTER ",r->calls);rs_ref(r->calls,ref);fprintf(r->calls," current=%d phase=%u\n",f->ctx.use_current_values,r->phase);
    /* Same isolation as hf_prime_pose: obtain the real provider's snapshot BOX.
     * This local mode change is identical for old/new. It is not a full graph
     * reconstruction oracle; existing product authority cases remain required. */
    bool saved=f->ctx.use_current_values;
    if(ref->provider==APP_SOURCE_MEMBER_POSE)f->ctx.use_current_values=true;
    bool ok=p->evaluate(state,graph,ref,out);
    f->ctx.use_current_values=saved;
    uint32_t id=0;int index=-1;
    if(ref->provider==APP_SOURCE_MEMBER_POSE&&reference_source_id(ref,&id)){
        index=rs_member_index(f,id);if(index>=0)++r->pose_calls[index];
    }
    if(ok&&ref->provider==APP_SOURCE_WOOD_DEFINITION){WoodDefinitionKind kind;
        if(wood_definition_source_decode(ref,&kind,&id)&&kind==WOOD_DEFINITION_PLACEMENT){
            index=rs_member_index(f,id);
            if(index<0||out->kind!=GEO_SOURCE_DEFINITION||out->as.definition.content_size>sizeof r->anchor_bytes[0])return false;
            memcpy(r->anchor_bytes[index],out->as.definition.content,out->as.definition.content_size);
            out->as.definition.content=r->anchor_bytes[index];
            if(r->scenario==RS_FOREIGN&&index==1)hf_be(r->anchor_bytes[index],4,8,4);
            if(r->scenario==RS_MOVED&&index==0){hf_be(r->anchor_bytes[index],4,7,4);hf_be(r->anchor_bytes[index],16,GEO_DIRECTION_POS_U,4);}
            if(index==0){
                if(r->scenario==RS_FUTURE_UV){f->world.wood.anchors[2].uv=(GeoPoint2){777,-333};++r->mutations;}
                if(r->scenario==RS_FUTURE_LENGTH){f->world.wood.timbers[2].length=83;f->world.wood.timbers[2].size_a=-29;++r->mutations;}
                if(r->scenario==RS_FUTURE_PLACED){f->world.wood.timbers[2].placed=false;++r->mutations;}
                if(r->scenario==RS_PHASE_TRUE||r->scenario==RS_PHASE_ROUNDTRIP){f->ctx.use_current_values=true;++r->phase;}
            }
            if(r->scenario==RS_ANCHOR_FAIL&&index==1){out->as.definition.schema="diagnostic.invalid.placement/1";++r->failures;}
        }
    }
    if(ref->provider==APP_SOURCE_MEMBER_POSE&&index>=0){
        if(r->scenario==RS_POSE_FAIL&&index==1){ok=false;++r->failures;}
        if(ok&&r->scenario==RS_POSE_UNPLACES&&index==1){f->world.wood.timbers[index].placed=false;++r->mutations;}
        if(ok&&index==0&&(r->scenario==RS_PHASE_ROUNDTRIP||r->scenario==RS_ENTRY_TRUE_TO_FALSE)){
            f->ctx.use_current_values=false;++r->phase;
        }
    }
    fputs("EVALUATE_RETURN ",r->calls);rs_ref(r->calls,ref);
    fprintf(r->calls," ok=%d value_kind=%d current=%d phase=%u mutations=%u failures=%u\n",ok,ok?(int)out->kind:-1,f->ctx.use_current_values,r->phase,r->mutations,r->failures);
    return ok;
}
static bool rs_install(RSRun *r)
{
    GeoEvalContext *graph=r->fixture->ctx.sources;r->provider_count=geo_eval_provider_count(graph);
    if(r->provider_count>sizeof r->providers/sizeof *r->providers)return false;
    for(size_t i=0;i<r->provider_count;++i){GeoSourceProvider *p=(GeoSourceProvider *)geo_eval_provider_at(graph,i);
        r->providers[i]=(RSProvider){p->token,p->describe,p->evaluate};p->describe=rs_describe;p->evaluate=rs_evaluate;}
    return true;
}
static void rs_point(FILE *out,GeoPoint3 p)
{fprintf(out,"(%" PRId64 ",%" PRId64 ",%" PRId64 ")",p.x,p.y,p.z);}
static void rs_vector(FILE *out,GeoVector3 v)
{rs_point(out,(GeoPoint3){v.x,v.y,v.z});}
static void rs_frame(FILE *out,const GeoFrame *frame)
{rs_point(out,frame->origin);rs_vector(out,frame->axis_u);rs_vector(out,frame->axis_v);rs_vector(out,frame->normal);}
static void rs_loop(FILE *out,const GeoLoop2View *loop)
{fprintf(out,"loop=%zu:",loop->count);for(size_t i=0;i<loop->count;++i)fprintf(out,"(%" PRId64 ",%" PRId64 ")",loop->v[i].u,loop->v[i].v);}
static void rs_value(FILE *out,const GeoSourceValue *v)
{
    fprintf(out,"value_kind=%d ",v->kind);
    switch(v->kind){
    case GEO_SOURCE_QUANTITY:fprintf(out,"quantity=%" PRId64 "/%" PRId64 " unit=%d",v->as.quantity.num,v->as.quantity.den,v->as.quantity.unit);break;
    case GEO_SOURCE_AXIS_POSITION:fprintf(out,"position=%" PRId64 " context=%d/%u/%d",v->as.position.coordinate,v->as.position.context.has_placement,v->as.position.context.placement,v->as.position.context.axis);break;
    case GEO_SOURCE_FRAME:rs_frame(out,&v->as.frame);break;
    case GEO_SOURCE_BOX:rs_frame(out,&v->as.box.frame);fprintf(out," extent=%" PRId64 ",%" PRId64 ",%" PRId64,v->as.box.extent[0],v->as.box.extent[1],v->as.box.extent[2]);break;
    case GEO_SOURCE_REGION_SET:
        fprintf(out,"regions=%zu ",v->as.regions.count);for(size_t i=0;i<v->as.regions.count;++i){const GeoRegionView *r=&v->as.regions.regions[i];
            rs_loop(out,&r->outline);fprintf(out," holes=%zu ",r->hole_count);for(size_t h=0;h<r->hole_count;++h)rs_loop(out,&r->holes[h]);}break;
    case GEO_SOURCE_FEATURE:fprintf(out,"feature_key=%zu:",v->as.feature.key_size);rs_hex(out,v->as.feature.key,v->as.feature.key_size);rs_point(out,v->as.feature.segment.start);rs_point(out,v->as.feature.segment.end);break;
    case GEO_SOURCE_DEFINITION:fprintf(out,"schema=%s bytes=%zu:",v->as.definition.schema?v->as.definition.schema:"<NULL>",v->as.definition.content_size);rs_hex(out,v->as.definition.content,v->as.definition.content_size);break;
    default:fputs("INVALID_VALUE_KIND",out);break;
    }
}
static bool rs_graph(FILE *out,const GeoEvalContext *graph)
{
    fprintf(out,"nodes=%zu edges=%zu candidate=%" PRIu64 " revision=%" PRIu64 " sealed=%d\n",geo_eval_node_count(graph),geo_eval_edge_count(graph),geo_eval_candidate_id(graph),geo_eval_base_revision(graph),geo_eval_is_sealed(graph));
    for(size_t i=0;i<geo_eval_node_count(graph);++i){GeoSourceNodeView n;if(!geo_eval_node_at(graph,i,&n))return false;
        fprintf(out,"NODE %zu ",i);rs_ref(out,&n.source);
        fprintf(out," described=%d state=%d status=%d descriptor=%d/%d/%d/%u/%d/%d/%d has_value=%d ",n.described,n.state,n.status,n.descriptor.kind,n.descriptor.unit,n.descriptor.context.has_placement,n.descriptor.context.placement,n.descriptor.context.axis,n.descriptor.retry_failure,n.descriptor.context_from_value,n.value!=NULL);
        if(n.value)rs_value(out,n.value);fputc('\n',out);
    }
    for(size_t i=0;i<geo_eval_edge_count(graph);++i){GeoSourceEdge e;if(!geo_eval_edge_at(graph,i,&e))return false;
        fprintf(out,"EDGE %zu consumer=%zu source=%zu kind=%d\n",i,e.consumer,e.source,e.kind);}
    return !ferror(out);
}
static bool rs_setup(HostFacts *f,unsigned scenario)
{
    if(!rs_hf_setup(f,HF_MOVED))return false;
    f->world.wood.timber_count=4;
    const uint32_t ids[]={41,42,43,UINT32_MAX};
    for(size_t i=0;i<4;++i){
        f->world.wood.timbers[i]=(WoodMember){.id=ids[i],.length=11+(Coord)(2*i),.size_a=3+(Coord)i,.size_b=5,.placed=true,
            .role=WOOD_MEMBER_ROLE_PRIMARY,.cut_priority=2,.origin={(Coord)(5+10*i),(Coord)(10+15*i),0},.axis_length={1,0,0},.axis_a={0,1,0},.axis_b={0,0,1}};
        f->world.wood.anchors[i]=(WoodMemberPlacement){.placement_id=7,.uv={(Coord)(5+10*i),(Coord)(10+15*i)},.order=i+1,
            .anchor_kind=WOOD_ANCHOR_AT,.length_direction=(int)i,.depth_side=(int)(i%2)};
    }
    if(scenario==RS_UNPLACED)f->world.wood.timbers[0].placed=false;
    if(scenario==RS_MOVED){f->world.wood.anchors[0].placement_id=8;f->world.wood.anchors[0].length_direction=99;}
    if(scenario==RS_LENGTH_ZERO)f->world.wood.timbers[1].length=0;
    if(scenario==RS_LENGTH_NEG)f->world.wood.timbers[1].length=-13;
    if(scenario==RS_DIRECTION)f->world.wood.anchors[1].length_direction=99;
    if(scenario==RS_DIRECTION_MIN)f->world.wood.anchors[1].length_direction=INT_MIN;
    if(scenario==RS_DEPTH)f->world.wood.anchors[1].depth_side=99;
    if(scenario==RS_DEPTH_MIN)f->world.wood.anchors[1].depth_side=INT_MIN;
    if(scenario==RS_PHASE_TRUE)f->world.wood.anchors[1].length_direction=99;
    if(scenario==RS_ENTRY_TRUE_TO_FALSE)f->ctx.use_current_values=true;
    return true;
}
static FILE *rs_open(const char *directory,const char *side,const char *suffix,const char *mode)
{char path[4096];int n=snprintf(path,sizeof path,"%s/%s.%s",directory,side,suffix);if(n<0||(size_t)n>=sizeof path)return NULL;return fopen(path,mode);}
static bool rs_equal_file(const char *directory,const char *suffix)
{
    FILE *a=rs_open(directory,"old",suffix,"rb"),*b=rs_open(directory,"new",suffix,"rb");if(!a||!b){if(a)fclose(a);if(b)fclose(b);return false;}
    bool same=true;for(;;){int x=fgetc(a),y=fgetc(b);if(x!=y){same=false;break;}if(x==EOF)break;}
    if(ferror(a)||ferror(b))same=false;fclose(a);fclose(b);return same;
}
static bool rs_one(HostFacts *storage,unsigned scenario,bool before,WoodContactSourceFacts *out,const char *directory)
{
    if(!rs_setup(storage,scenario))return false;
    RSRun r={0};r.fixture=storage;r.scenario=scenario;r.calls=rs_open(directory,before?"old":"new","calls.txt","wb");
    if(scenario==RS_PHASE_TRUE){PlacementSurface placement;GeoRect2 untouched={11,22,33,44};
        if(!app_placement_read(&storage->world,7,&placement))return false;
        r.phase_raw_invalid=!timber_a0_footprint_uv(&placement,&storage->world.wood.timbers[1],&storage->world.wood.anchors[1],&untouched);
        if(!r.phase_raw_invalid)return false;
    }
    if(!r.calls)return false;rs_active=&r;if(!rs_install(&r))return false;
    memset(out,0xa5,sizeof *out);memset(g_reference_issues,0,sizeof g_reference_issues);g_reference_issue_count=0;g_reference_capturing=true;g_revalidate_error[0]=0;
    WoodContactSourceRequest request={.placement_id=7,.along_v=false};
    if(scenario==RS_EXCLUDED)request.exclude=&storage->world.wood.timbers[1];
    if(scenario==RS_FUTURE_UV||scenario==RS_FUTURE_LENGTH)request.exclude=&storage->world.wood.timbers[2];
    bool result=before?reference_contact_facts_before(&storage->ctx,storage->ctx.sources,&request,out):reference_contact_facts(&storage->ctx,storage->ctx.sources,&request,out);
    fclose(r.calls);r.calls=NULL;
    FILE *facts=rs_open(directory,before?"old":"new","facts.bin","wb");if(!facts)return false;
    bool saved=fwrite(out,1,sizeof *out,facts)==sizeof *out;fclose(facts);
    FILE *graph=rs_open(directory,before?"old":"new","graph.txt","wb");if(!graph)return false;saved=rs_graph(graph,storage->ctx.sources)&&saved;fclose(graph);
    FILE *status=rs_open(directory,before?"old":"new","result.txt","wb");if(!status)return false;
    fprintf(status,"return=%d current=%d source_failure=%d phases=%u mutations=%u failures=%u pose_calls=%u,%u,%u,%u phase_raw_invalid=%d issues=%zu error=%s\n",result,storage->ctx.use_current_values,storage->ctx.source_failure,r.phase,r.mutations,r.failures,r.pose_calls[0],r.pose_calls[1],r.pose_calls[2],r.pose_calls[3],r.phase_raw_invalid,g_reference_issue_count,g_revalidate_error);
    for(size_t i=0;i<g_reference_issue_count;++i)fprintf(status,"ISSUE %zu timber=%u clause=%s expected=%s actual=%s\n",i,g_reference_issues[i].timber,g_reference_issues[i].clause,g_reference_issues[i].expected,g_reference_issues[i].actual);
    fclose(status);
    bool expected=!(scenario==RS_ANCHOR_FAIL||scenario==RS_POSE_FAIL);
    if(result!=expected)saved=false;
    if((scenario==RS_FUTURE_UV||scenario==RS_FUTURE_LENGTH||scenario==RS_FUTURE_PLACED||scenario==RS_POSE_UNPLACES)&&r.mutations!=1)saved=false;
    if((scenario==RS_ANCHOR_FAIL||scenario==RS_POSE_FAIL)&&r.failures!=1)saved=false;
    if((scenario==RS_PHASE_TRUE||scenario==RS_ENTRY_TRUE_TO_FALSE)&&r.phase!=1)saved=false;
    if(scenario==RS_PHASE_TRUE&&(!r.phase_raw_invalid||r.pose_calls[0]!=1||r.pose_calls[1]!=0))saved=false;
    if(scenario==RS_PHASE_ROUNDTRIP&&r.phase!=2)saved=false;
    g_reference_capturing=false;g_reference_active=NULL;reference_sources_dispose(&storage->ctx);hf_active=NULL;rs_active=NULL;
    return saved;
}
int main(int argc,char **argv)
{
    if(argc!=3)return 70;unsigned scenario=0;
    for(;scenario<sizeof rs_names/sizeof *rs_names;++scenario)if(!strcmp(argv[1],rs_names[scenario]))break;
    if(scenario==sizeof rs_names/sizeof *rs_names)return 70;
    HostFacts *storage=calloc(1,sizeof *storage);WoodContactSourceFacts *old=malloc(sizeof *old),*current=malloc(sizeof *current);
    if(!storage||!old||!current)return 71;
#define RS_ASSERT(suffix,condition) do{if(!(condition)){fprintf(stderr,"ASSERT:rawsnapshot-%s-%s\n",rs_names[scenario],suffix);return 1;}}while(0)
    RS_ASSERT("old-exercised",rs_one(storage,scenario,true,old,argv[2]));
    RS_ASSERT("new-exercised",rs_one(storage,scenario,false,current,argv[2]));
    RS_ASSERT("out",!memcmp(old,current,sizeof *old));
    RS_ASSERT("calls",rs_equal_file(argv[2],"calls.txt"));
    RS_ASSERT("graph",rs_equal_file(argv[2],"graph.txt"));
    RS_ASSERT("result",rs_equal_file(argv[2],"result.txt"));
    printf("{\"case\":\"%s\",\"sameStorage\":true,\"fullOutBytes\":%zu,\"outEqual\":true,\"orderedCallsEqual\":true,\"orderedGraphEqual\":true,\"resultEqual\":true}\n",rs_names[scenario],sizeof *old);
    free(storage);free(old);free(current);return 0;
}
