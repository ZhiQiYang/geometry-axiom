此目錄已完成純檔案準備；未編譯、未執行任何 C 診斷或測試，也未修改 repository。

比較基線為 Git commit `21a966a8a0145c566a8ce06ba6c3b276c5dadb00` 中的 `reference_contact_facts` 真實 blob；`snapshots/before-reference_sources.git-blob.txt` 保留完整原檔，`before-callback.exact-lf.txt` 保留精確函式文字（僅 CRLF 正規化）。在每個診斷 translation unit 中只將舊函式名稱改為 `_before`；新版來自實際 dirty 產品 current_geometry.c / reference_sources.inc。原 raw snapshot candidate 的兩檔原始 SHA256 在 PREPARED.json，包含其餘產品建置輸入 hashes。

同一 HostFacts storage 依原 hf_fixture body 就地 setup、dispose、再 setup，僅機械地替換外層 calloc 與函式 signature。這保持 ctx 和每個 member 的 address 相同。兩個 out 各先填 0xA5；回傳後完整 memcmp（包含 padding、未訪問 tail）並分別保存 old/new facts.bin。callback 沒有 error string 參數，故另外逐位保存 return、source_failure、ctx mode、phase/mutation/failure counters、g_revalidate_error 與所有 ReferenceIssue。

20 案例包含 unplaced、excluded、canonical foreign/moved、0/負 length、未知/INT_MIN direction/depth、第一個來源改 future UV/length/placed、第二個 anchor/pose 失敗且尾部未訪問、pose 後 placed=false，以及三個獨立外層 ctx mode phase 案例。每個來源 hook 都先呼叫已註冊真 production evaluator，再改 canonical return 或測試情境的 World；真 K graph 快取該值。pose evaluator 內部依既有 hf_prime_pose 語意暫切 current mode、呼叫真 evaluator、立刻還原；此操作兩側完全相同。這是隔離 callback 的診斷，不取代原 H authority 全產品圖回歸。沒有 geo_eval_source macro 或 mock。

完整有序 provider describe/evaluate ENTER/RETURN transcript，以及全部 ordered node keys、descriptor、state/status、typed value 實際欄位/definition bytes、ordered edges，分別落盤 old/new calls.txt / graph.txt 並完整比較。graph 內的借用地址以實際值內容序列化；原始 out 則因 Fixture address 穩定可直接 fullmemcmp。provider transcript 不代表每個 cached geo_eval_source 內部請求都有 provider callback；原 source call sites 的保持仍須配合靜態 diff 與正式 authority suite。

三個隔離負控：live World 取代 t0 snapshot（future-uv）、省略兩個 failure flush（anchor-fail）、pending2 錯誤恢復 valid（foreign）。負控不改舊 Git oracle 或原斷言。runner 要求正常 exit 1、stdout 空、精確具名 ASSERT；各自 baseline 與 restored 要正常 exit 0。尚未執行，不能稱已殺死。

root 確認可獨占 CPU 後才可執行：

```bash
python3 -B /workspace/geo261-environment/run_raw_snapshot_callback_diagnostic.py \
  --prepared /workspace/geo261-environment/raw-snapshot-callback-equivalence-v2-20261022 \
  --out /tmp/geo261-rawsnapshot-callback-o0-run
```

加 `--sanitized` 可另外以 ASan+UBSan 建置，必須使用新 out。runner 不自行取得 heavy lock，呼叫者須先安排排他。每次 compiler/version/build/run 的原始 command/exit/stdout/stderr/safe env/SHA 全保存；編譯錯誤與 timeout 不會重標成負控成功。來源或準備 include 改變會拒絕執行。根據正式 source SHA 的 native/browser/mutation/架構/P189 驗收仍由 root 負責。


v2 說明：v1 保留不動。此目錄透過準備器從實際 root 重新產生四組 variant 的完整 include copies 與 C diagnostic，並重新讀所有來源 hash；沒有僅修改舊 sourceGuards。W contact_sources.c 的 BE 展開已撤回，這次保存 malloc-only 的完整原始 bytes（見 auxiliarySourceSnapshots）；舊 callback 仍取同一 Git 21a966a8 blob。

外層 `phase-false-to-true` 不是 pose delegate 的暫切：第一個 anchor provider 返回後永久將 ctx.current 設 true，member1 的 raw direction 事先設 99。診斷先以原 timber_a0_footprint_uv 確認該 raw 為 invalid，並要求 pose_calls[1] == 0，同時有效的 member0 要 pose_calls[0] == 1。這些計數與 phase_raw_invalid 逐側寫入 result.txt；沒有執行前不能聲稱已驗到零次。
