import json,os,resource,subprocess,sys,time
from pathlib import Path
e=os.environ.copy();e.update(LD_PRELOAD=sys.argv[2],GEO261_PC_EXE=sys.argv[1],GEO261_PC_OUT=sys.argv[3])
t0=time.perf_counter();p=subprocess.run([sys.argv[1]],input=Path(sys.argv[4]).read_bytes(),env=e);elapsed=time.perf_counter()-t0
Path(sys.argv[5]).write_text(json.dumps({'command':[sys.argv[1]],'exit_code':p.returncode,'wall_seconds_diagnostic_only':elapsed,'stack_limit_bytes':resource.getrlimit(resource.RLIMIT_STACK),'child_environment':{k:e[k] for k in ('LD_PRELOAD','GEO261_PC_EXE','GEO261_PC_OUT')}})+'\n')
raise SystemExit(p.returncode)
