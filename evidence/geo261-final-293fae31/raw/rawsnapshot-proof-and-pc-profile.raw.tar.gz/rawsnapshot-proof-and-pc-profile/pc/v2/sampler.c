#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <limits.h>
#include <link.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>

enum { SAMPLE_CAPACITY=65536 };
static uint64_t samples[SAMPLE_CAPACITY];
static volatile sig_atomic_t sample_count,overflow_count;
static uintptr_t main_base,main_low=UINTPTR_MAX,main_high;
static int active,error_code;
static char output_path[PATH_MAX];

static int main_image(struct dl_phdr_info *info,size_t size,void *user)
{
    (void)size;(void)user;
    if(info->dlpi_name&&info->dlpi_name[0])return 0;
    main_base=(uintptr_t)info->dlpi_addr;
    for(ElfW(Half) i=0;i<info->dlpi_phnum;++i){
        const ElfW(Phdr) *p=&info->dlpi_phdr[i];
        if(p->p_type==PT_LOAD){uintptr_t low=main_base+p->p_vaddr,high=low+p->p_memsz;
            if(low<main_low)main_low=low;if(high>main_high)main_high=high;}
    }
    return 1;
}
static void sample_pc(int signum,siginfo_t *info,void *opaque)
{
    (void)signum;(void)info;
    ucontext_t *context=opaque;
    uintptr_t pc=(uintptr_t)context->uc_mcontext.gregs[REG_RIP];
    sig_atomic_t at=sample_count;
    if(at<SAMPLE_CAPACITY){samples[at]=(uint64_t)(pc-main_base);sample_count=at+1;}
    else if(overflow_count<INT_MAX)++overflow_count;
}
__attribute__((constructor)) static void begin_sampling(void)
{
    const char *out=getenv("GEO261_PC_OUT"),*expected=getenv("GEO261_PC_EXE");
    char actual[PATH_MAX];ssize_t length=readlink("/proc/self/exe",actual,sizeof actual-1);
    if(!out||!expected||length<0||length>=(ssize_t)sizeof actual-1)return;
    actual[length]=0;if(strcmp(actual,expected))return;
    if(strncmp(out,"/tmp/g261sigprof/",17)||strlen(out)>=sizeof output_path)return;
    strcpy(output_path,out);active=1;
    dl_iterate_phdr(main_image,NULL);
    if(main_low==UINTPTR_MAX||main_high<=main_low){error_code=1;return;}
    struct sigaction action={0};action.sa_sigaction=sample_pc;action.sa_flags=SA_SIGINFO;
    sigemptyset(&action.sa_mask);
    if(sigaction(SIGPROF,&action,NULL)){error_code=2;return;}
    struct itimerval timer={{0,1000},{0,1000}};
    if(setitimer(ITIMER_PROF,&timer,NULL))error_code=3;
}
static int write_all(int fd,const void *opaque,size_t size)
{
    const unsigned char *bytes=opaque;
    while(size){ssize_t written=write(fd,bytes,size);if(written<=0)return -1;
        bytes+=written;size-=(size_t)written;}
    return 0;
}
__attribute__((destructor)) static void finish_sampling(void)
{
    if(!active)return;
    struct itimerval zero={{0,0},{0,0}};setitimer(ITIMER_PROF,&zero,NULL);
    sigset_t blocked;sigemptyset(&blocked);sigaddset(&blocked,SIGPROF);sigprocmask(SIG_BLOCK,&blocked,NULL);
    /* 計時器停止後才保存本次 ASLR module 映射，不加入 handler 的工作。 */
    char maps_path[PATH_MAX];int maps_ok=0;
    if(snprintf(maps_path,sizeof maps_path,"%s.maps",output_path)<(int)sizeof maps_path){
        int source=open("/proc/self/maps",O_RDONLY),target=open(maps_path,O_WRONLY|O_CREAT|O_EXCL,0600);
        if(source>=0&&target>=0){char chunk[4096];ssize_t size;maps_ok=1;
            while((size=read(source,chunk,sizeof chunk))>0)if(write_all(target,chunk,(size_t)size)){maps_ok=0;break;}
            if(size<0)maps_ok=0;
        }
        if(source>=0)close(source);if(target>=0)close(target);
    }
    if(!maps_ok&&!error_code)error_code=4;
    char symbols_path[PATH_MAX];
    if(snprintf(symbols_path,sizeof symbols_path,"%s.symbols",output_path)<(int)sizeof symbols_path){
        int symbols=open(symbols_path,O_WRONLY|O_CREAT|O_EXCL,0600);
        if(symbols>=0){const char *names[]={"memcpy","memmove","memset","memcmp","malloc","calloc","free","realloc","strcmp","strlen"};
            for(size_t i=0;i<sizeof names/sizeof names[0];++i){void *address=dlsym(RTLD_NEXT,names[i]);Dl_info info={0};
                if(address)dladdr(address,&info);
                dprintf(symbols,"{\"name\":\"%s\",\"address\":%llu,\"module\":\"%s\",\"module_base\":%llu}\n",
                    names[i],(unsigned long long)(uintptr_t)address,info.dli_fname?info.dli_fname:"",(unsigned long long)(uintptr_t)info.dli_fbase);
            }
            close(symbols);
        }
    }
    uint64_t header[6]={(uint64_t)main_base,(uint64_t)sample_count,(uint64_t)overflow_count,
        (uint64_t)main_low,(uint64_t)main_high,(uint64_t)error_code};
    int fd=open(output_path,O_WRONLY|O_CREAT|O_EXCL,0600);
    if(fd>=0){write_all(fd,"G261PCS1",8);write_all(fd,header,sizeof header);
        write_all(fd,samples,(size_t)sample_count*sizeof *samples);close(fd);}
    char metadata[PATH_MAX];
    if(snprintf(metadata,sizeof metadata,"%s.json",output_path)<(int)sizeof metadata){
        fd=open(metadata,O_WRONLY|O_CREAT|O_EXCL,0600);
        if(fd>=0){dprintf(fd,"{\"schema\":\"geo261-sigprof-pc/1\",\"pid\":%ld,\"base\":%llu,\"count\":%d,\"overflow\":%d,\"main_low\":%llu,\"main_high\":%llu,\"error\":%d,\"sample_interval_cpu_us\":1000,\"output\":\"%s\"}\n",
            (long)getpid(),(unsigned long long)main_base,(int)sample_count,(int)overflow_count,
            (unsigned long long)main_low,(unsigned long long)main_high,error_code,output_path);close(fd);}
    }
}
