本包是帶明確 dirty source hashes／patch 的診斷，不是293fae31乾淨來源的正式驗收。

O0與ASan+UBSan各20個差分案例及3組基線0／具名正常突變1／恢復0，共29個verdict，全符合。舊oracle為21a Git函式，完整來源/輸出/有序圖/回呼逐位元組比較，適用範圍見prepared README。

PC取樣第一輪298個，第二輪274個，兩輪只診斷。第一輪shared缺maps不能回推；第二輪保存maps、ELF身份、runtime入口、exact disassembly CFG witness，memcpy/memmove共入口92、memset61、memcmp14，未知3保留。沒有caller backtrace，不把libc樣本全部歸因任一H呼叫者，不外推通過P189。二進位未入包，其sha保留；凍結work由source-inputs清單＋Git21a＋dirty patch識別。
