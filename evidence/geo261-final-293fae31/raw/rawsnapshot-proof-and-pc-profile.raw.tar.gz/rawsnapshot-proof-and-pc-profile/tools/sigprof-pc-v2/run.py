#!/usr/bin/env python3
"""凍結 dirty 產品的一次 CPU instruction-PC 診斷；不是 P-189 驗收。"""
import collections,datetime,fcntl,hashlib,importlib.util,json,os,platform,re,resource,shutil,struct,sys,time
from pathlib import Path

TOOLROOT=Path('/workspace/geo261-environment')
OUT=Path('/tmp/g261sigprof/v2')
WORK=Path('/tmp/g261sigprof/diagnostic/work')
spec=importlib.util.spec_from_file_location('pc_profile_capture',TOOLROOT/'run_workflow_round.py')
capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    assert not OUT.exists(),'拒絕覆寫v2'
    OUT.mkdir()
    for name in ('SNAPSHOT_READY.json','source-inputs.json'):
        shutil.copy2(Path('/tmp/g261sigprof/diagnostic')/name,OUT/name)
    assert (OUT/'SNAPSHOT_READY.json').is_file()
    assert not (OUT/'receipt.json').exists(),'拒絕覆寫或重複本次診斷'
    env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','AXIOM_ONLY') and not k.startswith(('GEOMETRY_','GEO261_PC_'))}
    (OUT/'tmp').mkdir()
    env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'tmp'))
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
    rows=json.loads((OUT/'source-inputs.json').read_text())
    for row in rows:assert digest(WORK/row['path'])==row['sha256'],row['path']
    record={'schema':'geo261-sigprof-instruction-pc-diagnostic/1','diagnostic_only':True,'formal_acceptance':False,
        'status':'執行中','started_utc':now(),'source_snapshot':json.loads((OUT/'SNAPSHOT_READY.json').read_text()),
        'driver_sha256':digest(Path(__file__)),'sampler_source_sha256':digest(Path(__file__).parent/'sampler.c'),
        'capture_driver_sha256':digest(TOOLROOT/'run_workflow_round.py'),'platform':platform.platform(),
        'byteorder':sys.byteorder,'stack_limit_bytes':resource.getrlimit(resource.RLIMIT_STACK),
        'environment':{k:env[k] for k in ('PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','TMPDIR') if k in env},'commands':[]}
    dump(OUT/'receipt.json',record)
    def run(label,argv,cwd=WORK,timeout=600):
        row=capture.capture(argv,OUT/'raw'/label,cwd=cwd,env=env,timeout=timeout)
        record['commands'].append(row);dump(OUT/'receipt.json',record)
        assert row['actual_process_returncode']==0 and not row['watchdog_expired'],(label,row)
        return Path(row['stdout']).read_bytes()
    try:
        with Path('/tmp/g261r1/heavy.lock').open('a+b') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            (OUT/'sampler.c').write_bytes((Path(__file__).parent/'sampler.c').read_bytes())
            run('gcc-version',['gcc','--version']);run('addr2line-version',['addr2line','--version'])
            run('build-sampler',['gcc','-std=c11','-O2','-g','-fPIC','-shared',str(OUT/'sampler.c'),'-o',str(OUT/'sampler.so'),'-ldl'])
            shutil.copy2(WORK/'bridge',OUT/'bridge')
            record['reused_nonpg_O2_g_bridge_from']=str(WORK/'bridge')
            record['first_build_receipt_sha256']=digest(Path('/tmp/g261sigprof/diagnostic/receipt.json'))
            record['binary_sha256']=digest(OUT/'bridge');record['sampler_binary_sha256']=digest(OUT/'sampler.so')
            run('elf-header',['readelf','-h',str(OUT/'bridge')])
            gen=Path('/tmp/g261r1/tools/gen_scene.py');record['generator_sha256']=digest(gen)
            (OUT/'s64.scene').write_bytes(run('generate-scene',[sys.executable,'-B',str(gen),'64','--family','single']))
            record['scene_sha256']=digest(OUT/'s64.scene')
            (OUT/'load.stdin').write_text('loadfile '+str(OUT/'s64.scene')+'\n')
            launcher=OUT/'load_once.py'
            launcher.write_text("import json,os,resource,subprocess,sys,time\nfrom pathlib import Path\ne=os.environ.copy();e.update(LD_PRELOAD=sys.argv[2],GEO261_PC_EXE=sys.argv[1],GEO261_PC_OUT=sys.argv[3])\nt0=time.perf_counter();p=subprocess.run([sys.argv[1]],input=Path(sys.argv[4]).read_bytes(),env=e);elapsed=time.perf_counter()-t0\nPath(sys.argv[5]).write_text(json.dumps({'command':[sys.argv[1]],'exit_code':p.returncode,'wall_seconds_diagnostic_only':elapsed,'stack_limit_bytes':resource.getrlimit(resource.RLIMIT_STACK),'child_environment':{k:e[k] for k in ('LD_PRELOAD','GEO261_PC_EXE','GEO261_PC_OUT')}})+'\\n')\nraise SystemExit(p.returncode)\n")
            result=run('sample-load',[sys.executable,'-B',str(launcher),str(OUT/'bridge'),str(OUT/'sampler.so'),str(OUT/'pcs.bin'),str(OUT/'load.stdin'),str(OUT/'load-process.json')])
            lines=result.splitlines();assert len(lines)==1;response=json.loads(lines[0]);assert response.get('ok') is True
            record['load_response']=response;record['load_process']=json.loads((OUT/'load-process.json').read_text())
            raw=(OUT/'pcs.bin').read_bytes();assert raw[:8]==b'G261PCS1'
            byteorder='<' if sys.byteorder=='little' else '>';base,count,overflow,low,high,error=struct.unpack_from(byteorder+'6Q',raw,8)
            assert len(raw)==56+8*count and error==0 and count>0 and overflow==0
            relative=list(struct.unpack_from(byteorder+str(count)+'Q',raw,56));absolute=[(pc+base)&((1<<64)-1) for pc in relative]
            main_pcs=[rel for rel,pc in zip(relative,absolute) if low<=pc<high];outside_pcs=[pc for pc in absolute if not low<=pc<high]
            record.update(sample_count=count,main_sample_count=len(main_pcs),outside_main_sample_count=len(outside_pcs),overflow=overflow,main_base=base,sampler_error=error)
            counts=collections.Counter(main_pcs);unique=sorted(counts)
            dump(OUT/'pc-counts.json',{'main_base':base,'main_relative_pcs':[{'pc':hex(pc),'count':counts[pc]} for pc in unique],
                'outside_main_absolute_pcs':[{'pc':hex(pc),'count':n} for pc,n in collections.Counter(outside_pcs).most_common()]})
            # maps 是被採樣程序在停止timer後保存，不能借用本driver的ASLR映射。
            maps_text=(OUT/'pcs.bin.maps').read_text()
            mappings=[]
            for line in maps_text.splitlines():
                fields=line.split(maxsplit=5);start,end=(int(x,16) for x in fields[0].split('-'))
                mappings.append({'start':start,'end':end,'permissions':fields[1],'file_offset':int(fields[2],16),
                    'path':fields[5] if len(fields)==6 else None})
            shared=[];modules={};page=os.sysconf('SC_PAGE_SIZE')
            for pc,n in collections.Counter(outside_pcs).items():
                match=next((m for m in mappings if m['start']<=pc<m['end']),None)
                row={'absolute_pc':hex(pc),'samples':n,'mapping':match,'module_offset':None}
                if match and match['path'] and match['path'].startswith('/') and Path(match['path']).is_file():
                    path=Path(match['path']);raw_elf=path.read_bytes()
                    assert raw_elf[:6]==b'\x7fELF\x02\x01','僅解析已明示的64bit little-endian ELF'
                    phoff=struct.unpack_from('<Q',raw_elf,32)[0];phsize,phcount=struct.unpack_from('<HH',raw_elf,54)
                    loads=[struct.unpack_from('<IIQQQQQQ',raw_elf,phoff+i*phsize) for i in range(phcount)]
                    segment=next(ph for ph in loads if ph[0]==1 and ph[2]//page*page==match['file_offset'] and ('x' not in match['permissions'] or ph[1]&1))
                    load_bias=match['start']-(segment[3]-segment[2]%page);offset=pc-load_bias
                    row.update(module=str(path),module_offset=hex(offset),load_bias=load_bias)
                    if str(path) not in modules:
                        label='shared-'+str(len(modules));identity={'path':str(path),'bytes':len(raw_elf),'sha256':digest(path),'label':label}
                        run(label+'-build-id',['readelf','-n',str(path)])
                        run(label+'-program-headers',['readelf','-W','-l',str(path)])
                        symbols=run(label+'-dynsym',['nm','-D','-n','-S','--defined-only',str(path)]).decode('utf-8','replace')
                        identity['dynamic_symbols']=[]
                        for symbol in symbols.splitlines():
                            f=symbol.split()
                            if len(f)>=4 and re.fullmatch('[0-9a-fA-F]+',f[0]) and re.fullmatch('[0-9a-fA-F]+',f[1]):
                                identity['dynamic_symbols'].append({'address':int(f[0],16),'size':int(f[1],16),'kind':f[2],'name':f[3]})
                        modules[str(path)]=identity
                shared.append(row)
            for path,module in modules.items():
                selected=[r for r in shared if r.get('module')==path];offsets=sorted({int(r['module_offset'],16) for r in selected})
                result=run(module['label']+'-addr2line',['addr2line','-a','-f','-i','-e',path,*[hex(x) for x in offsets]])
                sections=re.split(rb'(?m)^(0x[0-9a-fA-F]+)\r?\n',result);frames={}
                for at in range(1,len(sections),2):
                    items=sections[at+1].decode('utf-8','replace').splitlines();assert len(items)%2==0
                    frames[int(sections[at],16)]=[{'function':items[i],'source_line':items[i+1]} for i in range(0,len(items),2)]
                for row in selected:
                    offset=int(row['module_offset'],16);chain=frames[offset];row['addr2line_raw_chain']=chain
                    exact=[s for s in module['dynamic_symbols'] if s['size'] and s['address']<=offset<s['address']+s['size'] and s['kind'] in ('T','t','i','I','W','w')]
                    row['exact_dynamic_symbol_ranges']=exact
                    if chain and not chain[0]['source_line'].startswith('??'):
                        row['verified_function']=chain[0]['function'];row['resolution']='DWARF'
                    elif exact:
                        row['verified_function']=exact[0]['name'];row['resolution']='exact dynamic symbol range; no inline inference'
                    else:
                        row['verified_function']='unknown';row['resolution']='no DWARF or exact dynamic function range; do not infer nearest symbol'
            dump(OUT/'shared-module-identities.json',list(modules.values()))
            dump(OUT/'resolved-shared-pcs.json',shared)
            shared_summary=collections.Counter()
            for row in shared:shared_summary[(row.get('module','unmapped'),row.get('verified_function','unknown'))]+=row['samples']
            dump(OUT/'SHARED_SUMMARY.json',[{'module':k[0],'verified_function':k[1],'samples':n,'percent_all':100*n/count} for k,n in shared_summary.most_common()])
            resolved={}
            for batch_start in range(0,len(unique),2000):
                batch=unique[batch_start:batch_start+2000]
                result=run('addr2line-'+str(batch_start//2000),['addr2line','-a','-f','-i','-e',str(OUT/'bridge'),*[hex(pc) for pc in batch]])
                sections=re.split(rb'(?m)^(0x[0-9a-fA-F]+)\r?\n',result)
                assert not sections[0].strip()
                for at in range(1,len(sections),2):
                    pc=int(sections[at],16);items=sections[at+1].decode('utf-8','replace').splitlines();assert len(items)%2==0
                    resolved[pc]=[{'function':items[i],'source_line':items[i+1]} for i in range(0,len(items),2)]
            assert set(resolved)==set(unique)
            functions=collections.Counter();locations=collections.Counter();detail=[]
            for pc,n in counts.items():
                frames=resolved[pc];assert frames;first=frames[0];functions[first['function']]+=n;locations[(first['function'],first['source_line'])]+=n
                detail.append({'relative_pc':hex(pc),'samples':n,'inline_callchain_innermost_first':frames})
            dump(OUT/'resolved-pcs.json',detail)
            summary={'diagnostic_only':True,'samples':count,'main_samples':len(main_pcs),'outside_main_samples':len(outside_pcs),
                'innermost_functions':[{'function':name,'samples':n,'percent_all':100*n/count,'percent_main':100*n/len(main_pcs)} for name,n in functions.most_common()],
                'innermost_locations':[{'function':key[0],'source_line':key[1],'samples':n,'percent_all':100*n/count} for key,n in locations.most_common()]}
            dump(OUT/'SUMMARY.json',summary)
            (OUT/'SUMMARY.txt').write_text('\n'.join(f"{100*n/count:6.2f}% {n:5d} {name}" for name,n in functions.most_common())+'\n')
            for row in rows:assert digest(WORK/row['path'])==row['sha256'],row['path']
            record.update(status='完成',exit_code=0,ended_utc=now(),snapshot_unchanged=True,
                pc_binary_sha256=digest(OUT/'pcs.bin'),pc_metadata=json.loads((OUT/'pcs.bin.json').read_text()),
                sampler_launcher_sha256=digest(launcher),summary_sha256=digest(OUT/'SUMMARY.json'),
                maps_sha256=digest(OUT/'pcs.bin.maps'),shared_module_count=len(modules))
            dump(OUT/'receipt.json',record)
            print(json.dumps({'status':'完成','diagnostic_only':True,'exit_code':0,'load_ok':True,'samples':count,'main_samples':len(main_pcs),'outside_main_samples':len(outside_pcs),'receipt':str(OUT/'receipt.json')},ensure_ascii=False),flush=True)
            print((OUT/'SUMMARY.txt').read_text(),flush=True)
    except BaseException as error:
        record.update(status='失敗',exit_code=1,error=repr(error),ended_utc=now());dump(OUT/'receipt.json',record);raise

if __name__=='__main__':main()
