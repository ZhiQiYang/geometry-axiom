#!/usr/bin/env python3
"""只讀已保存的 exact objdump；從 dlsym entry 追 direct CFG，不採 nearest symbol。"""
from pathlib import Path
import collections,json,re
p=Path('/tmp/g261sigprof/v2');out=p/'runtime-entry-disassembly'
entries=json.loads((out/'entries.json').read_text());graphs={}
for entry in entries:
 name=entry['name'];instructions={}
 for line in Path(entry['wide_capture']['stdout']).read_text().splitlines():
  m=re.match(r'^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{2}\s+)+)\s*(\S.*)$',line)
  if not m:continue
  address=int(m[1],16);opcode=m[2].split();asm=m[3].strip();mnemonic=asm.split()[0]
  instructions[address]={'address':address,'bytes':' '.join(opcode),'assembly':asm,'mnemonic':mnemonic,'next':address+len(opcode)}
 root=entry['entry_elf_offset'];pending=[root];parents={root:None};visited=set();unresolved=[]
 while pending:
  at=pending.pop()
  if at in visited:continue
  if at not in instructions:unresolved.append({'address':hex(at),'reason':'outside captured disassembly or not instruction boundary'});continue
  visited.add(at);row=instructions[at];mnemonic=row['mnemonic'];targets=[]
  if mnemonic.startswith('ret') or mnemonic in ('ud2','hlt','int3'):continue
  if mnemonic.startswith('j') or mnemonic.startswith('loop'):
   m=re.match(r'\S+\s+([0-9a-fA-F]+)(?:\s|$)',row['assembly'])
   if m:targets.append((int(m[1],16),'direct branch'))
   else:unresolved.append({'address':hex(at),'reason':'indirect/unparsed branch','assembly':row['assembly']})
   if mnemonic!='jmp':targets.append((row['next'],'conditional fallthrough'))
  else:targets.append((row['next'],'fallthrough'))
  for target,kind in targets:
   if target not in parents:parents[target]={'from':at,'kind':kind};pending.append(target)
 graphs[name]={'root':root,'visited':visited,'parents':parents,'instructions':instructions,'unresolved':unresolved}
shared=json.loads((p/'resolved-shared-pcs.json').read_text());evidence=[];counts=collections.Counter()
for row in shared:
 offset=int(row['module_offset'],16) if row['module_offset'] else None;matched=[];witnesses={}
 for name,graph in graphs.items():
  if offset not in graph['visited']:continue
  matched.append(name);path=[];at=offset
  while at is not None:
   parent=graph['parents'][at];path.append(at);at=parent['from'] if parent else None
  path.reverse();branches=[]
  for left,right in zip(path,path[1:]):
   ins=graph['instructions'][left]
   if ins['mnemonic'].startswith('j') or ins['mnemonic'].startswith('loop'):
    branches.append({'from':hex(left),'assembly':ins['assembly'],'taken_edge_to':hex(right)})
  witnesses[name]={'entry':hex(graph['root']),'sample_instruction':graph['instructions'][offset],
      'direct_cfg_path_length':len(path),'branch_witness':branches}
 if matched:
  category='/'.join('memcpy/memmove' if n=='memcpy' else n for n in matched)
 else:category=row.get('verified_function','unknown')
 counts[category]+=row['samples'];evidence.append({'absolute_pc':row['absolute_pc'],'module_offset':row['module_offset'],'samples':row['samples'],'runtime_cfg_entries_reaching_instruction':matched,'classification':category,'witnesses':witnesses})
record={'method':'dlsym exact runtime entry -> direct conditional/unconditional branches plus fallthrough; stop ret/trap; calls only fallthrough; no nearest dynsym','diagnostic_only':True,
 'cfg_summaries':[{ 'entry':name,'elf_offset':hex(g['root']),'reachable_instruction_count':len(g['visited']),'unresolved_targets':g['unresolved']} for name,g in graphs.items()],
 'sample_summary':[{'category':name,'samples':n,'percent_all':100*n/274} for name,n in counts.most_common()],'sample_evidence':evidence}
(out/'CFG_PROOF.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='sample_evidence'},indent=2))
