import collections, hashlib, importlib.util, json, pathlib, re, sys
root=pathlib.Path('/tmp/g261-next314'); out=pathlib.Path(__file__).parent
mp=root/'geometry-core/domain-decoupling/product-architecture.json'; raw=mp.read_bytes(); m=json.loads(raw)
(out/'manifest-before.json').write_bytes(raw)
spec=importlib.util.spec_from_file_location('geo314_original_scanner', root/'tests/architecture_contract.py'); mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
ids=collections.defaultdict(set);strings=collections.defaultdict(set);files=[]
for entry in m['sources']:
 if entry['layer']!='W' or entry['language']!='c':continue
 p=entry['path']; r=(root/p).read_bytes();files.append({'path':p,'rawSha256':hashlib.sha256(r).hexdigest(),'lfSha256':hashlib.sha256(r.replace(b'\r\n',b'\n').replace(b'\r',b'\n')).hexdigest()})
 _,_,tokens=mod.lex(r.decode('utf-8-sig'),p,c=True)
 for t in tokens:
  if t.kind=='identifier' and t.value.startswith(('Wood','WOOD_','wood_')):ids[t.value].add((p,t.line))
 i=0
 while i<len(tokens):
  if tokens[i].kind=='string':
   line,v=tokens[i].line,tokens[i].value;i+=1
   while i<len(tokens) and tokens[i].kind=='string':v+=tokens[i].value;i+=1
   if re.match(r'^(?:wood|woodworking)[./-]',v):strings[v].add((p,line))
  else:i+=1
oldi=set(m['policy']['forbiddenIdentifiers']);olds=set(m['policy']['forbiddenStrings'])
m['policy']['forbiddenIdentifiers']=sorted(oldi|set(ids));m['policy']['forbiddenStrings']=sorted(olds|set(strings))
new={'path':'geometry-app/native/stagger_facts.inc','layer':'H','language':'c','purpose':'Candidate-owned ordered source/value facts at application operation boundaries; binds preview and confirm evidence to the existing revision and operation seal without persisting facts in World or history'}
assert not any(x['path']==new['path'] for x in m['sources']);m['sources'].append(new);m['sources'].sort(key=lambda x:x['path'])
p='geometry-web/grid_inspector_rename_test.js'; e=next(x for x in m['exclusions'] if x['path']==p);oldsha=e['sha256'];assert e['hashMode']=='lf';e['sha256']=hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')).hexdigest()
manifest=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();mp.write_bytes(manifest)
inventory={'method':'original tests/architecture_contract.py lex(c=True), complete W C sources, full old union current W identifiers and adjacent namespaced literals','scannerSha256':hashlib.sha256((root/'tests/architecture_contract.py').read_bytes()).hexdigest(),'old':{'identifiers':len(oldi),'strings':len(olds)},'new':{'identifiers':len(m['policy']['forbiddenIdentifiers']),'strings':len(m['policy']['forbiddenStrings'])},'addedIdentifiers':sorted(set(ids)-oldi),'addedStrings':sorted(set(strings)-olds),'identifierOrigins':{k:sorted(v) for k,v in sorted(ids.items())},'stringOrigins':{k:sorted(v) for k,v in sorted(strings.items())},'files':files,'addedHSource':new,'exclusion':{'path':p,'old':oldsha,'new':e['sha256']},'otherPolicyFieldsUnchanged':True,'sourceRootsAndSearchRootsAndRoutesUnchanged':True}
(out/'inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n');(out/'manifest-after.json').write_bytes(manifest)
print(json.dumps({k:v for k,v in inventory.items() if k not in ('identifierOrigins','stringOrigins','files')},ensure_ascii=False,indent=2))
