#!/usr/bin/env python3
"""Run the original assembly mutation tool, its units and anchor inventory.

Use under the existing external subreaper. Each original script gets its own
TMPDIR and the canonical binaries module with only OUT_DIR adapted. No test,
mutation, compiler flag, timeout, assertion or result classification is patched.
"""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import runpy
import subprocess
import sys
import time
import traceback


HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def filtered_observer(helper, roots, out):
    class SourceMetadataObserver(helper.ObservedBuildArchive):
        """Keep source bytes, never object/assembly/ELF payloads."""
        SOURCE_SUFFIXES = {".c", ".h", ".inc", ".py", ".scene"}
        TOTAL_CAP, FILE_CAP = 128 << 20, 8 << 20

        def __init__(self):
            self.retained_bytes = 0
            self.retained_sources = 0
            self.capacity_misses = []
            super().__init__(roots, out)

        def observe(self, label, path, reason, force=False):
            key = label + "/" + str(path.relative_to(self.roots[label]))
            try:
                if path.is_symlink() or not path.is_file():
                    return
                before = path.stat()
                signature = [before.st_size, before.st_mtime_ns, before.st_ctime_ns, before.st_ino]
                if not force and self.latest.get(key, {}).get("signature") == signature:
                    return
                row = {"path": key, "bytes": before.st_size, "signature": signature,
                       "mode": before.st_mode, "reason": reason, "payload_policy": "metadata-only"}
                if path.suffix in self.SOURCE_SUFFIXES:
                    if before.st_size > self.FILE_CAP:
                        self.capacity_misses.append(dict(path=key, bytes=before.st_size, reason="source-file-cap"))
                        row["payload_policy"] = "source-file-cap-miss"
                    else:
                        raw = path.read_bytes()
                        after = path.stat()
                        if signature != [after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_ino]:
                            self.issue("changed-during-observation", path=key, reason=reason)
                            return
                        digest = hashlib.sha256(raw).hexdigest()
                        target = self.objects / digest
                        row["sha256"] = digest
                        if not target.exists() and self.retained_bytes + len(raw) > self.TOTAL_CAP:
                            self.capacity_misses.append(dict(path=key, bytes=len(raw), reason="total-source-cap"))
                            row["payload_policy"] = "total-source-cap-miss"
                        else:
                            if not target.exists():
                                target.write_bytes(raw)
                                self.retained_bytes += len(raw)
                                self.retained_sources += 1
                            row["payload_policy"] = "deduplicated-source-bytes"
                self.latest[key] = row
                self.log(dict(kind="filtered-file-version", **row))
            except OSError as exc:
                self.issue("observation-missing", path=key, reason=reason, error=repr(exc))

        def finish(self):
            super().finish()
            manifest = out / "observed-build-manifest.json"
            value = json.loads(manifest.read_text())
            value.update(coverage="filtered observed coverage only; no complete-temporary-artifact claim",
                source_suffixes=sorted(self.SOURCE_SUFFIXES), total_source_byte_cap=self.TOTAL_CAP,
                per_source_byte_cap=self.FILE_CAP, retained_source_bytes=self.retained_bytes,
                retained_source_versions=self.retained_sources, capacity_misses=self.capacity_misses,
                binary_object_and_assembly_policy="metadata only; no .o/.s/ELF payload or binary versions retained",
                original_logs="all original tool build/test stdout, stderr, argv, execution and record outputs remain uncapped in tool-output")
            write(manifest, value)

    return SourceMetadataObserver()


def source_binding(root, product, actual, out, label):
    ancestor = subprocess.run(["git", "merge-base", "--is-ancestor", product, actual], cwd=root, capture_output=True)
    assert ancestor.returncode == 0, "declared product is not an ancestor of the actual HEAD"
    result = subprocess.run(["git", "diff", "--name-only", "--no-renames", product, actual], cwd=root, capture_output=True, check=True)
    (out / f"{label}-product-to-actual-paths.stdout").write_bytes(result.stdout)
    paths = result.stdout.decode().splitlines()
    non_evidence = [path for path in paths if not path.startswith("evidence/")]
    assert not non_evidence, "actual HEAD differs from declared product outside evidence: " + repr(non_evidence)
    return {"declared_product_sha": product, "actual_head": actual, "changed_paths": paths,
            "only_evidence_diff": not non_evidence, "tracked_product_sources_identical": not non_evidence}


def inner(args):
    root, out = args.root.resolve(), args.out.resolve()
    os.chdir(root)
    sys.path.insert(0, str(root / "tests"))
    sys.path.insert(0, str(root))
    module = load(root / "tests/binaries.py", "binaries")
    helper = load(HERE / "run_native_diagnostic.py", "geo314_native_observer_for_assembly")
    before = helper.binary_contract(module)
    old_out = str(module.OUT_DIR)
    module.OUT_DIR = out / "private-cache"  # Sole adaptation of an original module.
    module.OUT_DIR.mkdir()
    after = helper.binary_contract(module)
    assert before == after, "OUT_DIR changed flags, command or fingerprint"
    script = root / args.script
    original_argv = sys.argv[:]
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    assert actual == args.sha, "HEAD moved before the stage entry"
    binding = source_binding(root, args.product_sha, actual, out, "entry")
    meta = {"schema": "geo314-assembly-original-entry/2", "source_sha": actual,
            "declaredProductSHA": args.product_sha, "product_to_actual_binding": binding,
            "original_script": args.script, "script_sha256": sha(script),
            "argv": [sys.executable, str(script), *args.arguments], "cwd": str(root),
            "binaries_OUT_DIR_before": old_out, "binaries_OUT_DIR_adapted": str(module.OUT_DIR),
            "only_original_module_adaptation": "binaries.OUT_DIR", "contract_before": before,
            "contract_after_OUT_DIR": after, "flags_commands_fingerprints_unchanged": before == after,
            "stack": resource.getrlimit(resource.RLIMIT_STACK),
            "environment": {key: os.environ.get(key) for key in ("PATH", "CC", "TMPDIR", "MUTATE_CACHE",
                "MUTATE_RESULTS", "LANG", "LC_ALL", "PYTHONOPTIMIZE", "PYTHONDONTWRITEBYTECODE")},
            "tool_hashes": {str(path): sha(path) for path in (Path(__file__), HERE / "run_native_diagnostic.py",
                root / "tests/binaries.py", script)}}
    write(out / "entry-receipt.json", meta)
    observer = filtered_observer(helper, {"native-tmp": Path(os.environ["TMPDIR"]),
        "private-cache": module.OUT_DIR}, out)
    observer.start()
    code = 0
    try:
        sys.argv = [str(script), *args.arguments]
        runpy.run_path(str(script), run_name="__main__")
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 0 if exc.code is None else 1
        if not isinstance(exc.code, (int, type(None))):
            print(exc.code, file=sys.stderr)
    except KeyboardInterrupt:
        code = 130
        traceback.print_exc()
    except BaseException:
        code = 1
        traceback.print_exc()
    finally:
        sys.argv = original_argv
        try:
            observer.finish()
            meta["contract_after_run"] = helper.binary_contract(module)
            meta["contract_unchanged_after_run"] = before == meta["contract_after_run"]
        except BaseException:
            meta["archive_error"] = traceback.format_exc()
            traceback.print_exc()
        meta.update(original_script_exit_code=code, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    temporary_build_coverage="filtered observed sources and metadata only; no .o/.s/ELF payloads; cap/misses explicit")
        write(out / "entry-receipt.json", meta)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--sha", help="optional expected actual HEAD; otherwise freeze the actual HEAD after acquiring the lock")
    parser.add_argument("--product-sha", required=True, help="declared P3 product SHA, separately verified against actual evidence HEAD")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--heavy-lock", type=Path)
    parser.add_argument("--inner", action="store_true")
    parser.add_argument("--script")
    parser.add_argument("--stop-file", type=Path, default=HERE / "STOP_REQUESTED")
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.arguments[:1] == ["--"]:
        args.arguments = args.arguments[1:]
    assert not sys.flags.optimize and os.environ.get("PYTHONOPTIMIZE") in (None, "", "0")
    if args.inner:
        return inner(args)
    if not args.heavy_lock:
        parser.error("outer driver requires --heavy-lock; do not take the same lock outside it")
    root, out = args.root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)  # The outer reaper may already have created only reaper.jsonl.
    if any(path.name != "reaper.jsonl" for path in out.iterdir()):
        parser.error("out must be new, except for its active outer reaper.jsonl")
    if out.is_relative_to(root):
        parser.error("out must be external to source")
    helper = load(HERE / "run_native_diagnostic.py", "geo314_assembly_archival_helpers")
    lock = args.heavy_lock.open("a+b")
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        before = helper.git_snapshot(root, out, "before")
        actual = before.get("sha")
        assert not args.sha or actual == args.sha, before
        initial_binding = source_binding(root, args.product_sha, actual, out, "before")
        assert not [line for line in (out / "before-git-status.stdout").read_text().splitlines()
                    if not line.startswith("# ")], "source is dirty"
        summary = {"schema": "geo314-assembly-anchor-repair/2", "source_sha": actual,
                   "declaredProductSHA": args.product_sha, "initial_product_to_actual_binding": initial_binding, "before_git": before,
                   "scope": "original full assembly fault tool; original assembly unit12; original mutation anchors3",
                   "not_in_scope": "ledger regeneration, full native rerun, browser or performance",
                   "source_inputs": helper.source_archive(root, out, "before"), "stages": [],
                   "tool_hashes": {str(path): sha(path) for path in (Path(__file__), HERE / "run_native_diagnostic.py")}}
        summary["stop_policy"] = {"file": str(args.stop_file), "boundary": "before each complete original stage",
            "active_stage": "allowed to finish normally; no compiler wrapper, signal, tool patch or forced interruption"}
        stages = (
            ("assembly-original-tool", "tests/assembly_mutation_check.py", ["--out", str(out / "assembly-original-tool/tool-output")]),
            ("assembly-unit12", "tests/_unittest_runner.py", [str(root / "tests/test_assembly_mutation_check.py"),
                "--json-out", str(out / "assembly-unit12/result.json"), "--log", str(out / "assembly-unit12/unittest.log")]),
            ("mutation-anchors3", "tests/_unittest_runner.py", [str(root / "tests/test_mutation_anchors.py"),
                "--json-out", str(out / "mutation-anchors3/result.json"), "--log", str(out / "mutation-anchors3/unittest.log")]),
        )
        for label, script, arguments in stages:
            if args.stop_file.exists() or (out / "STOP_REQUESTED").exists():
                summary.update(stopped_at_stage_boundary=label, remaining_stages_not_run=[name for name, _, _ in stages
                    if name not in {row["stage"] for row in summary["stages"]}], stop_requested=True)
                write(out / "summary.json", summary)
                print("STOP_REQUESTED before " + label + "; no later stage started", flush=True)
                break
            stage_actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
            stage_binding = source_binding(root, args.product_sha, stage_actual, out, label)
            directory = out / label
            directory.mkdir()
            tmp = directory / "native-tmp"
            tmp.mkdir()
            env = dict(os.environ, TMPDIR=str(tmp), MUTATE_CACHE=str(directory / "mutation-cache"),
                       PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
            argv = [sys.executable, "-B", str(Path(__file__)), "--inner", "--root", str(root), "--sha", stage_actual,
                    "--product-sha", args.product_sha,
                    "--out", str(directory), "--script", script, "--", *arguments]
            started = time.monotonic()
            print("START " + label, flush=True)
            with (directory / "stdout.raw").open("wb") as stdout, (directory / "stderr.raw").open("wb") as stderr:
                result = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr)
            row = {"stage": label, "argv": argv, "original_argv": [sys.executable, script, *arguments],
                   "actual_head": stage_actual, "declaredProductSHA": args.product_sha, "product_to_actual_binding": stage_binding,
                   "exit_code": result.returncode, "seconds": time.monotonic() - started,
                   "stdout_sha256": sha(directory / "stdout.raw"), "stderr_sha256": sha(directory / "stderr.raw")}
            if (directory / "result.json").is_file():
                row["original_result"] = json.loads((directory / "result.json").read_text())
            if (directory / "tool-output/summary.json").is_file():
                row["original_tool_summary"] = json.loads((directory / "tool-output/summary.json").read_text())
                # Check that read-only observation retained the actual bytes
                # whose hashes the original tool recorded after each patch.
                captured, missing = [], []
                for phase in [*row["original_tool_summary"].get("cases", []),
                              *row["original_tool_summary"].get("controls", [])]:
                    for relative, digests in phase.get("patchedFiles", {}).items():
                        expected = digests["after"]
                        blob = directory / "observed-build-objects" / expected
                        entry = {"phase": phase["id"], "source": relative, "sha256": expected,
                                 "object": str(blob.relative_to(out))}
                        (captured if blob.is_file() and sha(blob) == expected else missing).append(entry)
                row["actual_mutated_source_capture"] = {"captured": captured, "missing": missing,
                    "complete_for_original_recorded_patch_sources": not missing}
                row["original_tool_output_manifest"] = {str(path.relative_to(directory)): {
                    "bytes": path.stat().st_size, "sha256": sha(path)}
                    for path in sorted((directory / "tool-output").rglob("*")) if path.is_file()}
            summary["stages"].append(row)
            write(out / "summary.json", summary)
            print("END " + label + " exit=" + str(result.returncode), flush=True)
        summary["after_git"] = helper.git_snapshot(root, out, "after")
        summary["after_product_to_actual_binding"] = source_binding(root, args.product_sha, summary["after_git"].get("sha"), out, "after")
        summary["actual_head_unchanged"] = summary["after_git"].get("sha") == actual
        summary["source_unchanged"] = not [line for line in (out / "after-git-status.stdout").read_text().splitlines() if not line.startswith("# ")]
        summary["exit_code"] = 130 if summary.get("stop_requested") else int(any(row["exit_code"] or
            row.get("actual_mutated_source_capture", {}).get("missing") for row in summary["stages"]) or not summary["source_unchanged"])
        write(out / "summary.json", summary)
        return summary["exit_code"]
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()


if __name__ == "__main__":
    raise SystemExit(main())
