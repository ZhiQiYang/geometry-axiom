#!/usr/bin/env python3
"""Record original candidate26 plus isolated fixture-withdrawal 0/1/0; no Git writes."""
from __future__ import annotations
import argparse
import atexit
import contextlib
import datetime as dt
import fcntl
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import re
import resource
import runpy
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

SOURCE = 'tests/geo261_candidate_product_harness.c'
SUITE = 'tests.test_geo261_candidate_product'
REAPER = Path('/workspace/geo261-environment/reap_children.py')
REAPER_SHA = '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
DEFINES = ['GEOMETRY_KERNEL_EXTERNAL=1','GEOMETRY_WOODWORKING_EXTERNAL=1',
           'GEOMETRY_HOST_HISTORY_EXTERNAL=1','GEOMETRY_HOST_CANDIDATE_EXTERNAL=1']
INITIALIZERS = (
    '        frame.owner->operation.stagger_count=0;frame.owner->operation.stagger_steps=0;\n'
    '        memset(frame.owner->operation.stagger_seal,0,sizeof frame.owner->operation.stagger_seal);\n',
    '    owner->operation.stagger_count=0;owner->operation.stagger_steps=0;\n'
    '    memset(owner->operation.stagger_seal,0,sizeof owner->operation.stagger_seal);\n')
CASES = {'replay-operation':'file-replay-frame-final-seal',
         'default-cost':'default-evaluation-succeeded',
         'default-scratch-oom':'default-final-seal'}


def utc(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(root, *args): return subprocess.check_output(['git',*args],cwd=root).decode().strip()


def capture(argv, directory, root, timeout=30):
    directory.mkdir(parents=True,exist_ok=False)
    started=utc();clock=time.monotonic();launch_error=None
    try:
        result=subprocess.run(argv,cwd=root,capture_output=True,timeout=timeout)
        code=result.returncode;out=result.stdout;err=result.stderr;timed_out=False
    except subprocess.TimeoutExpired as exc:
        code=None;out=exc.stdout or b'';err=exc.stderr or b'';timed_out=True
    except OSError as exc:
        code=None;out=b'';err=(str(exc)+'\n').encode();timed_out=False;launch_error=str(exc)
    (directory/'stdout.raw').write_bytes(out);(directory/'stderr.raw').write_bytes(err)
    row={'argv':list(map(str,argv)),'cwd':str(root),'started_at':started,'ended_at':utc(),
         'seconds':round(time.monotonic()-clock,3),'exit_code':code,'timed_out':timed_out,'launch_error':launch_error,
         'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
    write(directory/'command.json',row);return row,out.decode(errors='replace'),err.decode(errors='replace')


def quoted_closure(root, initial):
    pending=list(initial);seen=set();include=re.compile(rb'^\s*#\s*include\s*"([^"\r\n]+)"',re.M)
    while pending:
        path=pending.pop().resolve()
        if path in seen or not path.is_file() or not path.is_relative_to(root): continue
        seen.add(path)
        for match in include.finditer(path.read_bytes()):
            token=match.group(1).decode('utf-8')
            for candidate in (path.parent/token,root/token,root/'geometry-core/kernel'/token):
                if candidate.is_file():pending.append(candidate);break
    return sorted(seen)


def archive_inputs(root,out):
    files=quoted_closure(root,[root/SOURCE,root/'geometry-web/web_bridge.c',root/'current_geometry.c'])
    files=sorted(set(files)|set((root/'tests').glob('*.py')))
    rows=[]
    with tarfile.open(out/'source-inputs.tar.gz','w:gz',compresslevel=1) as bundle:
        for path in files:
            raw=path.read_bytes();relative=path.relative_to(root).as_posix()
            rows.append({'path':relative,'bytes':len(raw),'sha256':sha(raw)})
            bundle.add(path,arcname=relative,recursive=False)
    write(out/'source-inputs.json',rows);return rows


def verify_product_inputs(root,out,product_sha,rows):
    argv=['git','cat-file','--batch']
    requests=''.join(product_sha+':'+row['path']+'\n' for row in rows).encode()
    result=subprocess.run(argv,cwd=root,input=requests,capture_output=True)
    (out/'product-inputs-cat-file.stdin.raw').write_bytes(requests)
    (out/'product-inputs-cat-file.stdout.raw').write_bytes(result.stdout)
    (out/'product-inputs-cat-file.stderr.raw').write_bytes(result.stderr)
    stream=io.BytesIO(result.stdout);observed=[];problems=[]
    for row in rows:
        header=stream.readline().rstrip(b'\n');parts=header.split()
        if len(parts)!=3 or parts[1]!=b'blob' or not parts[2].isdigit():
            problems.append({'path':row['path'],'header':header.decode(errors='replace')});continue
        raw=stream.read(int(parts[2]));newline=stream.read(1)
        digest=sha(raw);same=newline==b'\n' and digest==row['sha256']
        observed.append({'path':row['path'],'git_blob':parts[0].decode(),'bytes':len(raw),'sha256':digest,'same_live_bytes':same})
        if not same:problems.append({'path':row['path'],'reason':'live input differs from declared product blob'})
    if result.returncode:problems.append({'reason':'git cat-file failed','exit_code':result.returncode})
    record={'argv':argv,'cwd':str(root),'exit_code':result.returncode,'product_sha':product_sha,
            'stdin_sha256':sha(requests),'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),
            'inputs':observed,'problems':problems}
    write(out/'product-input-equivalence.json',record)
    if problems:raise RuntimeError('live source/judge inputs do not match declared product SHA')
    return {'input_count':len(observed),'all_live_bytes_equal_product':True,'record':'product-input-equivalence.json'}


class StopRequested(RuntimeError):
    pass


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--product-sha',required=True)
    parser.add_argument('--heavy-lock',type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve();out=args.out.resolve()
    if not all(re.fullmatch('[0-9a-f]{40}',value) for value in (args.sha,args.product_sha)):
        parser.error('--sha and --product-sha require fixed 40-digit SHAs')
    if out.is_relative_to(root):parser.error('--out must be external')
    if sha(REAPER.read_bytes())!=REAPER_SHA:raise RuntimeError('original reaper bytes changed')
    out.mkdir(parents=True,exist_ok=True)
    if (out/'receipt.json').exists():raise RuntimeError('refuse to overwrite a previous run')
    lock=args.heavy_lock.open('a+b')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        print('heavy lock busy; no build or tests launched',flush=True);return 78
    (out/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
    (out/'reap_children.py.txt').write_bytes(REAPER.read_bytes())
    head=git(root,'rev-parse','HEAD')
    if head!=args.sha:raise RuntimeError('actual checkout HEAD does not match --sha')
    changes=git(root,'diff','--name-only',args.product_sha,head).splitlines()
    if any(not path.startswith('evidence/') for path in changes):
        raise RuntimeError('checkout differs from declared product SHA outside evidence/')
    (out/'before.status').write_text(git(root,'status','--porcelain=v2','--branch')+'\n')
    (out/'before.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root))
    stack=resource.getrlimit(resource.RLIMIT_STACK)
    if stack[1]!=resource.RLIM_INFINITY and stack[1]<16*1024*1024:raise RuntimeError('hard stack limit below 16MiB')
    resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,stack[1]))
    tmp=out/'tmp';tmp.mkdir();private=out/'private-registry';private.mkdir()
    os.environ.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',
                      LANG='C.UTF-8',LC_ALL='C.UTF-8',GITHUB_SHA=args.sha,GITHUB_WORKSPACE=str(root))
    # Do this before importing tempfile/binaries/tests in the child runner.
    import tempfile
    tempfile.tempdir=str(tmp)
    os.chdir(root);sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
    import binaries
    original_registry=str(binaries.OUT_DIR);binaries.OUT_DIR=private
    record={'schema':'geo314-candidate-witness-repair/1','classification':'targeted diagnostic and withdrawal proof',
            'source_sha':head,'actual_checkout_sha':head,'declared_product_sha':args.product_sha,
            'checkout_changes_since_product':changes,'root':str(root),'started_at':utc(),'driver_sha256':sha(Path(__file__).read_bytes()),
            'reaper_sha256':REAPER_SHA,'reaper_log':os.environ.get('GEO261_REAPER_LOG'),
            'environment':{k:os.environ[k] for k in ('PATH','TMPDIR','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE',
                'PYTHONIOENCODING','GITHUB_SHA','GITHUB_WORKSPACE')},
            'python':sys.version,'platform':platform.platform(),'stack_before':stack,
            'stack_effective':resource.getrlimit(resource.RLIMIT_STACK),
            'registry_OUT_DIR_before':original_registry,'registry_OUT_DIR_effective':str(private),
            'original_suite_command':[sys.executable,'-B','-m','unittest','-v',SUITE],
            'suite':None,'controls':[],'errors':[],'stopped':False,'verdict':'running'}
    rows=archive_inputs(root,out)
    record['product_input_equivalence']=verify_product_inputs(root,out,args.product_sha,rows)
    write(out/'receipt.json',record)
    from tests import test_geo261_native_kernel as native_module
    stop_file=out/'STOP_REQUESTED'
    observed_build={}
    original_run_build=native_module.NativeBuild.run_build
    def check_stop():
        if stop_file.exists():raise StopRequested('external scheduler closed the next-command gate')
    def observed_run_build(build,argv):
        observed_build['build']=build;check_stop()
        write(out/'current-stage.json',{'kind':'compiler-or-linker','state':'running','argv':list(map(str,argv)),'utc':utc()})
        original_run_build(build,argv)
        write(out/'current-stage.json',{'kind':'compiler-or-linker','state':'completed','argv':list(map(str,argv)),'utc':utc()})
        check_stop()
    native_module.NativeBuild.run_build=observed_run_build
    try:
        check_stop()
        record['versions']=[]
        for name,argv in (('python',[sys.executable,'--version']),('cc',[shutil.which(os.environ.get('CC','cc')) or 'cc','--version']),
                          ('chrome',['google-chrome','--version']),('node',['node','--version'])):
            check_stop();row,_,_=capture(argv,out/'versions'/name,root,timeout=30)
            record['versions'].append(row)
            if row['exit_code']!=0:record['errors'].append({'type':'environment-version','name':name,'exit_code':row['exit_code']})
        write(out/'receipt.json',record)
        suite_dir=out/'suite';suite_dir.mkdir();started=utc();clock=time.monotonic();original_argv=sys.argv[:]
        code=0
        with (suite_dir/'stdout.raw').open('w',encoding='utf-8') as stdout,(suite_dir/'stderr.raw').open('w',encoding='utf-8') as stderr:
            try:
                with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                    sys.argv=['unittest','-v',SUITE]
                    runpy.run_module('unittest',run_name='__main__',alter_sys=True)
            except SystemExit as exc:code=exc.code if isinstance(exc.code,int) else (0 if exc.code is None else 1)
            except BaseException:
                code=1;traceback.print_exc(file=stderr)
            finally:sys.argv=original_argv
        text=(suite_dir/'stderr.raw').read_text();counts=re.findall(r'^Ran (\d+) tests? in ',text,re.M)
        suite={'argv':record['original_suite_command'],'execution_adapter':'unittest original __main__ via runpy; only private binaries.OUT_DIR',
               'exit_code':code,'started_at':started,'ended_at':utc(),'seconds':round(time.monotonic()-clock,3),
               'observed_count':int(counts[-1]) if counts else None,
               'stdout_sha256':sha((suite_dir/'stdout.raw').read_bytes()),'stderr_sha256':sha((suite_dir/'stderr.raw').read_bytes())}
        suite['passed']=code==0 and suite['observed_count']==26 and re.search(r'^OK\s*$',text,re.M) is not None
        record['suite']=suite;write(suite_dir/'command.json',suite);write(out/'receipt.json',record)
        print('candidate26 suite exit='+str(code)+' observed='+str(suite['observed_count']),flush=True)
        check_stop()
        build=native_module._BUILD
        from tests.test_geo261_candidate_product import CandidateProduct
        if not build or not hasattr(CandidateProduct,'exe'):raise RuntimeError('original candidate fixture did not build; controls blocked')
        proof=out/'proof-sources';proof.mkdir();fixed=(root/SOURCE).read_text(encoding='utf-8');withdrawn=fixed
        for initializer in INITIALIZERS:
            if withdrawn.count(initializer)!=1:raise RuntimeError('initializer control anchor not unique')
            withdrawn=withdrawn.replace(initializer,'',1)
        include='#include "../geometry-web/web_bridge.c"'
        if fixed.count(include)!=1:raise RuntimeError('witness bridge include not unique')
        relocation='#include "'+(root/'geometry-web/web_bridge.c').as_posix()+'"'
        (proof/'fixed.c').write_text(fixed.replace(include,relocation),encoding='utf-8')
        withdrawn_path=proof/'withdrawn.c';withdrawn_path.write_text(withdrawn.replace(include,relocation),encoding='utf-8')
        write(proof/'control.json',{'only_semantic_withdrawals':list(INITIALIZERS),
            'fixed_source_sha256':sha((proof/'fixed.c').read_bytes()),'withdrawn_source_sha256':sha(withdrawn_path.read_bytes()),
            'include_relocation':{'before':include,'after':relocation}})
        check_stop()
        changed_object=build.compile(withdrawn_path,'candidate-withdrawn-initializers',DEFINES)
        changed=build.link('candidate-withdrawn-initializers',[changed_object,*build.product_objects()])
        for name,marker in CASES.items():
            check_stop();phases=[]
            for phase,exe in (('baseline',CandidateProduct.exe),('withdrawn',changed),('restored',CandidateProduct.exe)):
                check_stop()
                write(out/'current-stage.json',{'kind':'case','case':name,'phase':phase,'state':'running','utc':utc()})
                row,stdout,stderr=capture([str(exe),name,str(CandidateProduct.scene)],out/'controls'/name/phase,root)
                row['assertions']=[line[7:] for line in stderr.splitlines() if line.startswith('ASSERT:')]
                phases.append(row)
                write(out/'current-stage.json',{'kind':'case','case':name,'phase':phase,'state':'completed','exit_code':row['exit_code'],'utc':utc()})
                check_stop()
            passed=(phases[0]['exit_code']==0 and not phases[0]['timed_out'] and
                    phases[1]['exit_code']==1 and not phases[1]['timed_out'] and phases[1]['assertions']==[marker] and
                    phases[2]['exit_code']==0 and not phases[2]['timed_out'])
            control={'case':name,'expected_assertion':marker,'phases':phases,'passed':passed}
            record['controls'].append(control);write(out/'receipt.json',record)
            print(name+' actual='+str([r['exit_code'] for r in phases])+' passed='+str(passed),flush=True)
    except BaseException as exc:
        if isinstance(exc,StopRequested):record['stopped']=True
        record['errors'].append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
        traceback.print_exc()
    finally:
        native_module.NativeBuild.run_build=original_run_build
        build=native_module._BUILD or observed_build.get('build')
        if stop_file.exists():record['stopped']=True
        if build:
            write(out/'build-commands.json',build.logs)
            (out/'native-build-path.txt').write_text(str(build.work)+'\n')
            if record['stopped']:
                # Keep the raw private inputs after process exit; do not start
                # compression while the performance scheduler has closed the gate.
                atexit.unregister(build.temp.cleanup)
                build.temp._finalizer.detach()
                record['preserved_uncompressed_build']=str(build.work)
            else:
                with tarfile.open(out/'native-build-inputs-objects-binaries.tar.gz','w:gz',compresslevel=1) as bundle:
                    bundle.add(build.work,arcname='native-build',recursive=True)
                record['native_build_archive_sha256']=sha((out/'native-build-inputs-objects-binaries.tar.gz').read_bytes())
        drift=[r['path'] for r in rows if not (root/r['path']).is_file() or sha((root/r['path']).read_bytes())!=r['sha256']]
        record['input_drift']=drift;record['head_after']=git(root,'rev-parse','HEAD')
        head_changes=git(root,'diff','--name-only',head,record['head_after']).splitlines()
        record['checkout_changes_during_run']=head_changes
        record['head_change_is_evidence_only']=all(path.startswith('evidence/') for path in head_changes)
        (out/'after.status').write_text(git(root,'status','--porcelain=v2','--branch')+'\n')
        record['ended_at']=utc()
        passed=(record['suite'] is not None and record['suite'].get('passed') and len(record['controls'])==3 and
                all(c['passed'] for c in record['controls']) and not record['errors'] and not drift and record['head_change_is_evidence_only'])
        record['verdict']='stopped' if record['stopped'] else ('pass' if passed else 'fail');write(out/'receipt.json',record)
        inventory=[]
        for path in ([] if record['stopped'] else sorted(out.rglob('*'))):
            if path.is_file() and path.name not in ('FILE_MANIFEST.json','reaper.jsonl'):
                inventory.append({'path':path.relative_to(out).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
        write(out/'FILE_MANIFEST.json',inventory)
    print('targeted candidate repair verdict='+record['verdict'],flush=True)
    return 75 if record['stopped'] else (0 if record['verdict']=='pass' else 1)

if __name__=='__main__': raise SystemExit(main())
