#!/usr/bin/env python3
"""Record original reader checks and a real old-canonical withdrawal; scheduling only."""
import argparse,datetime,fcntl,hashlib,json,os,pathlib,platform,resource,shutil,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--product-sha',required=True);p.add_argument('--sha',required=True);p.add_argument('--out',required=True);p.add_argument('--heavy-lock',required=True);a=p.parse_args()
root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
stop=out/'STOP_REQUESTED';receipt={'schema':'geo314-reader-repair/1','classification':'P3 affected diagnostic, not final-SHA acceptance','declared_product_sha':a.product_sha,'expected_checkout_sha':a.sha,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'environment':{k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','TMPDIR','GEO261_REAPER_LOG','PYTHONDONTWRITEBYTECODE','CODEX_PRIMARY_RUNTIME_NODE']},'python':sys.version,'platform':platform.platform(),'stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK),'commands':[]}
def digest(b):return hashlib.sha256(b).hexdigest()
def save(): (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
def gate():
 if stop.exists():raise InterruptedError('external scheduling STOP_REQUESTED; no next command')
def run(label,argv,expected=None):
 gate();start=time.time();r=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);row={'label':label,'argv':argv,'cwd':str(root),'exit_code':r.returncode,'elapsed_seconds':time.time()-start,'stdout_sha256':digest(r.stdout),'stderr_sha256':digest(r.stderr)};receipt['commands'].append(row);save()
 if expected is not None and r.returncode!=expected: raise AssertionError((label,r.returncode,expected))
 gate();return r
lock=open(a.heavy_lock,'a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
canonical=root/'geometry-guide/公理層-閱讀器.html';fixed=canonical.read_bytes();original=pathlib.Path('/workspace/geo314-work/reader-repair-001/reader-before.html').read_bytes()
unchanged=['公理層.md','geometry-guide/公理層-白話.md','決策佇列.md','BACKLOG.md'];protected={n:(root/n).read_bytes() for n in unchanged if (root/n).exists()}
try:
 head=run('before-head',['git','rev-parse','HEAD'],0).stdout.decode().strip();assert head==a.sha;receipt['actual_checkout_sha']=head
 assert run('before-tracked-status',['git','status','--porcelain','--untracked-files=no'],0).stdout==b''
 names=run('product-to-evidence-paths',['git','diff','--name-only',a.product_sha,head],0).stdout.decode().splitlines();assert all(x.startswith('evidence/') for x in names);receipt['evidence_only_descendant_paths']=names
 run('product-ancestor',['git','merge-base','--is-ancestor',a.product_sha,head],0)
 receipt['protected_before']={n:{'bytes':len(b),'sha256':digest(b)} for n,b in protected.items()}
 (out/'canonical-fixed.html').write_bytes(fixed);(out/'canonical-withdrawn.html').write_bytes(original)
 for n in ['geometry-guide/sync_axiom_reader.py','tests/test_axiom_reader.py',*protected]:
  q=out/'source-inputs'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((root/n).read_bytes())
 # Supplement sync's original paths using immutable P3 Git blobs for its guide plain text too.
 receipt['protected_match_product_sha']={}
 for n,b in protected.items():
  r=run('product-'+n.replace('/','_'),['git','show',a.product_sha+':'+n],0);receipt['protected_match_product_sha'][n]=r.stdout==b;assert r.stdout==b
 run('baseline-check',[sys.executable,'-B','geometry-guide/sync_axiom_reader.py','--check'],0)
 run('baseline-full51',[sys.executable,'-B','tests/test_axiom_reader.py'],0)
 method='CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews'
 run('baseline-idempotence',[sys.executable,'-B','tests/test_axiom_reader.py',method],0)
 gate();canonical.write_bytes(original)
 try:
  r=run('withdrawn-idempotence',[sys.executable,'-B','tests/test_axiom_reader.py',method],1);assert b'FAIL: test_rebuild_is_byte_idempotent_and_keeps_reviews' in r.stderr and b'AssertionError' in r.stderr
 finally:canonical.write_bytes(fixed)
 run('restored-idempotence',[sys.executable,'-B','tests/test_axiom_reader.py',method],0)
 run('restored-full51',[sys.executable,'-B','tests/test_axiom_reader.py'],0)
 run('restored-check',[sys.executable,'-B','geometry-guide/sync_axiom_reader.py','--check'],0)
 receipt['control_codes']=[0,1,0];receipt['status']='passed'
except InterruptedError as e:
 receipt['status']='infrastructure-stop';receipt['error']=str(e)
except BaseException as e:
 receipt['status']='failed';receipt['error']=repr(e);raise
finally:
 canonical.write_bytes(fixed);receipt['protected_after']={n:{'bytes':len((root/n).read_bytes()),'sha256':digest((root/n).read_bytes())} for n in protected};receipt['protected_unchanged']=all((root/n).read_bytes()==b for n,b in protected.items());receipt['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();fcntl.flock(lock.fileno(),fcntl.LOCK_UN);lock.close()
if receipt['status']=='infrastructure-stop':raise SystemExit(75)
assert receipt['protected_unchanged']
