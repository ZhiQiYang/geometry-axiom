import datetime,hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path('/tmp/g261-next314');out=pathlib.Path(__file__).parent
files=['geometry-guide/公理層-閱讀器.html','公理層.md','公理層-白話.md','決策佇列.md','BACKLOG.md']
files=[p for p in files if (root/p).exists()]
def inventory():return {p:{'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in files}
before=inventory();(out/'reader-before.html').write_bytes((root/files[0]).read_bytes())
(out/'before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
argv=[sys.executable,'-B','geometry-guide/sync_axiom_reader.py'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'sync.stdout').write_bytes(r.stdout);(out/'sync.stderr').write_bytes(r.stderr);after=inventory();(out/'after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n');(out/'reader-after.html').write_bytes((root/files[0]).read_bytes())
(out/'receipt.json').write_text(json.dumps({'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(root),'exit_code':r.returncode,'before':before,'after':after,'unchanged_other_files':all(before[p]==after[p] for p in files[1:])},ensure_ascii=False,indent=2)+'\n');print(r.stdout.decode(errors='replace'));print('rc',r.returncode);sys.exit(r.returncode)
