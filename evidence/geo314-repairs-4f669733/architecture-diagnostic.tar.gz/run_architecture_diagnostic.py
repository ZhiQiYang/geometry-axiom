#!/usr/bin/env python3
"""Run three original judges against the actual P manifest; never regenerate artifacts."""
import argparse,datetime,fcntl,hashlib,json,os,pathlib,platform,resource,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--product-sha',required=True);p.add_argument('--sha',required=True);p.add_argument('--out',required=True);p.add_argument('--heavy-lock',required=True);a=p.parse_args();root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True);assert all(q.name=='reaper.jsonl' for q in out.iterdir()), 'out must be new except outer reaper log';(out/'tmp').mkdir();lock=open(a.heavy_lock,'a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ,TMPDIR=str(out/'tmp'),PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8');report={'schema':'geo314-original-architecture-diagnostic/1','scope':'original three judges on actual new P manifest; not four-file refresh or final acceptance','product_sha':a.product_sha,'checkout_sha':a.sha,'root':str(root),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'environment':{k:env.get(k) for k in ['PATH','TMPDIR','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE','GEO261_REAPER_LOG']},'python':sys.version,'platform':platform.platform(),'stack_rlimit':resource.getrlimit(resource.RLIMIT_STACK)}
def sha(b):return hashlib.sha256(b).hexdigest()
def save(): (out/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
def run(label,argv):
 if (out/'STOP_REQUESTED').exists() or pathlib.Path('/workspace/geo314-work/STOP_REQUESTED').exists():raise InterruptedError('scheduler STOP_REQUESTED')
 start=time.monotonic();r=subprocess.run(argv,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);row={'label':label,'argv':argv,'cwd':str(root),'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)};report['steps'].append(row);save();return r
try:
 assert run('before-head',['git','rev-parse','HEAD']).stdout.decode().strip()==a.sha
 assert run('before-status',['git','status','--porcelain','--untracked-files=no']).stdout==b''
 paths=run('product-to-evidence-paths',['git','diff','--name-only',a.product_sha,a.sha]).stdout.decode().splitlines();assert all(n.startswith('evidence/') for n in paths);report['evidence_only_descendant_paths']=paths
 sources=['tests/architecture_contract.py','tests/test_architecture_contract.py','tests/test_product_architecture.py','geometry-core/domain-decoupling/product-architecture.json']
 report['inputs']={}
 for n in sources:
  raw=(root/n).read_bytes();q=out/'inputs'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);report['inputs'][n]={'bytes':len(raw),'sha256':sha(raw)}
 commands=[('architecture-contract',['python','-B','tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json']),('test-architecture-contract',['python','-B','tests/test_architecture_contract.py']),('test-product-architecture',['python','-B','tests/test_product_architecture.py'])]
 report['judge_exit_codes']=[run(label,argv).returncode for label,argv in commands]
 assert run('after-head',['git','rev-parse','HEAD']).stdout.decode().strip()==a.sha
 assert run('after-status',['git','status','--porcelain','--untracked-files=no']).stdout==b''
 report['input_bytes_unchanged']=all(sha((root/n).read_bytes())==v['sha256'] for n,v in report['inputs'].items());report['status']='passed' if report['judge_exit_codes']==[0,0,0] and report['input_bytes_unchanged'] else 'failed'
except BaseException as e:report['status']='infrastructure-stop' if isinstance(e,InterruptedError) else 'failed';report['error']=repr(e);raise
finally:report['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();fcntl.flock(lock.fileno(),fcntl.LOCK_UN);lock.close()
raise SystemExit(0 if report['status']=='passed' else 1)
