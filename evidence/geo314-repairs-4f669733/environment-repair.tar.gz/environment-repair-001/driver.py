#!/usr/bin/env python3
"""Restore four exact tracked fixtures in detached P2; retry two node files only."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path('/workspace/g314-native-diagnostic-p2')
OUT = Path('/workspace/geo314-work/environment-repair-001')
SOURCE = '291ce90abf9c3bfaf68bd61c4969f2ff9a1be6f6'
REAPER = Path('/workspace/geo261-environment/reap_children.py')
CACHE = Path('/workspace/geo314-work/native-p2-001/private-cache')
PATHS = [
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas',
    'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
    'tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene',
]
TESTS = ['tests/test_grid_drafts_lifecycle_capacity.js', 'tests/test_reference_workspace_races.js']

def sha(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)

def stamp(label):
    result = {}
    for name, args in [('head',['rev-parse','HEAD']), ('status',['status','--porcelain=v2','--branch']),
                       ('diff',['diff','--binary','HEAD']), ('cached-diff',['diff','--cached','--binary'])]:
        raw = git(*args); (OUT/(label+'-'+name+'.raw')).write_bytes(raw)
        result[name] = {'argv':['git',*args], 'exit_code':0, 'sha256':sha(raw)}
    return result

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT/'materialized').mkdir()
    before = stamp('before')
    if git('rev-parse','HEAD').decode().strip() != SOURCE:
        raise RuntimeError('detached source head is not P2')
    if git('diff','--binary','HEAD') or git('diff','--cached','--binary'):
        raise RuntimeError('detached source has tracked modifications')
    summary = {'schema':'geo314-environment-repair/1', 'classification':'diagnostic environment retry, not final-SHA acceptance',
        'started_utc':now(), 'source_sha':SOURCE, 'root':str(ROOT), 'driver_sha256':sha(Path(__file__).read_bytes()),
        'reaper':str(REAPER), 'reaper_sha256':sha(REAPER.read_bytes()), 'before':before, 'materialized':[]}
    shutil.copy2(__file__, OUT/'driver.py')
    shutil.copy2(REAPER, OUT/'reap_children.py')
    for index, relative in enumerate(PATHS):
        target = ROOT/relative
        existed = target.exists()
        argv = ['git','show',SOURCE+':'+relative]
        completed = subprocess.run(argv, cwd=ROOT, capture_output=True)
        (OUT/f'git-show-{index}.stdout.raw').write_bytes(completed.stdout)
        (OUT/f'git-show-{index}.stderr.raw').write_bytes(completed.stderr)
        if completed.returncode:
            raise RuntimeError(('git show failed', argv, completed.returncode))
        expected_blob = git('rev-parse',SOURCE+':'+relative).decode().strip()
        if existed and target.read_bytes() != completed.stdout:
            raise RuntimeError('refuse overwrite of non-exact existing file: '+relative)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(completed.stdout)
        frozen = OUT/'materialized'/relative
        frozen.parent.mkdir(parents=True,exist_ok=True); frozen.write_bytes(completed.stdout)
        actual_blob = subprocess.check_output(['git','hash-object','--stdin'],input=target.read_bytes(),cwd=ROOT).decode().strip()
        if actual_blob != expected_blob:
            raise RuntimeError('restored blob differs from P2: '+relative)
        summary['materialized'].append({'path':relative,'existed_before':existed,'argv':argv,'exit_code':completed.returncode,
            'blob':expected_blob,'sha256':sha(completed.stdout),'bytes':len(completed.stdout)})
    env=dict(os.environ)
    for key in list(env):
        if key.startswith('GEOMETRY_'): del env[key]
    binary_names={'GEOMETRY_TEST_BRIDGE':'bridge','GEOMETRY_ENGINEERING_BRIDGE':'bridge','GEOMETRY_MODEL_BASE':'model-base',
        'GEOMETRY_TEST_CORE':'core','GEOMETRY_TEST_ENGINEERING_JSON':'engineering-json-test','GEOMETRY_TEST_PF3_ALGORITHM':'pf3-algorithm'}
    identities={}
    for key,name in binary_names.items():
        path=CACHE/name; sidecar=Path(str(path)+'.fingerprint.json')
        env[key]=str(path)
        identities[key]={'path':str(path),'sha256':sha(path.read_bytes()),'sidecar':str(sidecar),'sidecar_sha256':sha(sidecar.read_bytes())}
        if name not in identities:
            shutil.copy2(sidecar,OUT/(name+'.fingerprint.json'))
    env['GEO261_REAPER_LOG']=str(OUT/'node-reaper.jsonl')
    env['LC_ALL']='C.UTF-8';env['LANG']='C.UTF-8'
    raw_tmp=OUT/'node-tmp';raw_tmp.mkdir();env['TMPDIR']=str(raw_tmp)
    summary['binary_identities']=identities
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
    node=shutil.which('node')
    if not node: raise RuntimeError('node is unavailable')
    version=subprocess.run([node,'--version'],capture_output=True)
    (OUT/'node-version.stdout.raw').write_bytes(version.stdout);(OUT/'node-version.stderr.raw').write_bytes(version.stderr)
    summary['node_version']={'argv':[node,'--version'],'exit_code':version.returncode,'stdout_sha256':sha(version.stdout)}
    inputs=sorted(relative for relative in git('ls-files','-z').decode().split('\0') if relative and
        ((relative.startswith('geometry-web/') and Path(relative).suffix in {'.js','.cjs','.mjs'}) or
         relative in TESTS+['tests/run_all.py','tests/test_geo261_graph_product.py','tests/_unittest_runner.py']))
    summary['inputs']={relative:{'sha256':sha((ROOT/relative).read_bytes()),'bytes':(ROOT/relative).stat().st_size} for relative in inputs}
    with tarfile.open(OUT/'node-inputs.tar.gz','w:gz') as archive:
        for relative in inputs: archive.add(ROOT/relative,arcname=relative,recursive=False)
    command=[node,'--test','--test-reporter=spec',*TESTS]
    outer=[sys.executable,str(REAPER),*command]
    summary['node_command']=command;summary['outer_command']=outer
    summary['environment']={key:env.get(key) for key in ['PATH','LANG','LC_ALL','TMPDIR','GEO261_REAPER_LOG',*binary_names]}
    summary['platform']=platform.platform();summary['python']=sys.version;summary['stack_rlimit']=resource.getrlimit(resource.RLIMIT_STACK)
    write(OUT/'receipt.json',summary)
    started=time.monotonic()
    with (OUT/'node.stdout.raw').open('wb') as stdout,(OUT/'node.stderr.raw').open('wb') as stderr:
        completed=subprocess.run(outer,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,timeout=900)
    summary['node_exit_code']=completed.returncode;summary['node_elapsed_seconds']=time.monotonic()-started
    summary['after']=stamp('after-node')
    summary['finished_node_utc']=now()
    summary['output_files']={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file() and p.name!='receipt.json'}
    write(OUT/'receipt.json',summary)
    print(json.dumps({'node_exit_code':completed.returncode,'outdir':str(OUT),'source_sha':SOURCE}))
    return completed.returncode

if __name__=='__main__': raise SystemExit(main())
