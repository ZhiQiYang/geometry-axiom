#!/usr/bin/env python3
"""P2 graph5 environment retry; run only after the coordinator releases heavy work.

The original five-test judge and NativeBuild compile flags are untouched.  The
only repository module configuration is binaries.OUT_DIR.  The outer process
owns the nonblocking heavy lock, STOP gates, original subreaper, and raw files.
The inner process runs the original file runner and archives NativeBuild before
its registered atexit cleanup can remove the actual compile inputs and logs.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

P2 = "291ce90abf9c3bfaf68bd61c4969f2ff9a1be6f6"
SUITE = "tests/test_geo261_graph_product.py"
FIXTURES = (
    "tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas",
    "tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas",
    "tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas",
    "tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene",
)


def utc(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def stop_check(paths):
    active = [str(path) for path in paths if path.exists()]
    if active:
        raise InterruptedError("coordinator STOP gate: " + ", ".join(active))


def metadata_command(root, out, label, command):
    result = subprocess.run(command, cwd=root, capture_output=True)
    (out / (label + ".stdout.raw")).write_bytes(result.stdout)
    (out / (label + ".stderr.raw")).write_bytes(result.stderr)
    receipt = {"argv": command, "cwd": str(root), "exit_code": result.returncode,
        "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)}
    if result.returncode:
        raise RuntimeError(("metadata command failed", receipt))
    return result.stdout, receipt


def snapshot(root, out, label):
    state = {}
    for name, arguments in (("head", ["rev-parse", "HEAD"]),
            ("status", ["status", "--porcelain=v2", "--branch"]),
            ("diff", ["diff", "--binary", "HEAD"]),
            ("cached-diff", ["diff", "--cached", "--binary"])):
        raw, receipt = metadata_command(root, out, label + "-" + name, ["git", *arguments])
        state[name] = receipt
        if name == "head": state["sha"] = raw.decode("ascii").strip()
        if name in ("diff", "cached-diff") and raw:
            raise RuntimeError("detached P2 has tracked edits: " + name)
    return state


def inventory_tree(directory):
    return {path.relative_to(directory).as_posix(): {"bytes": path.stat().st_size,
        "sha256": sha(path.read_bytes())} for path in sorted(directory.rglob("*")) if path.is_file()}


def archive_sources(root, out):
    """Freeze the declared source scope, plus the exact runtime scene input.

    Historical evidence trees are excluded from the general source snapshot;
    the four explicitly restored runtime fixtures are included separately.
    Actual copied NativeBuild inputs are additionally archived after the run.
    """
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=root).decode("utf-8").split("\0")
    extensions = {".c", ".h", ".inc", ".py", ".scene"}
    selected = sorted({name for name in names if name and Path(name).suffix in extensions and
        not any(part in {"evidence", "release-evidence", ".git"} for part in Path(name).parts)} | set(FIXTURES))
    rows, missing = {}, []
    # An uncompressed tar avoids an additional compression workload and retains
    # all exact bytes; the lock remains held until inventories are complete.
    path = out / "source-inputs.tar"
    with tarfile.open(path, "w", dereference=False) as archive:
        for relative in selected:
            source = root / relative
            if not source.is_file():
                missing.append(relative)
                continue
            raw = source.read_bytes()
            rows[relative] = {"bytes": len(raw), "sha256": sha(raw)}
            archive.add(source, arcname=relative, recursive=False)
    result = {"policy": "tracked C/H/INC/PY/SCENE outside historical evidence, plus four exact runtime fixtures",
        "archive": path.name, "archive_sha256": sha(path.read_bytes()), "files": rows,
        "missing_tracked_in_declared_scope": missing}
    write(out / "source-inputs.json", result)
    if missing:
        raise RuntimeError("missing tracked files in declared source scope")
    return result


def canonical_contract(module):
    return {name: {"command": binary.command_string(), "posix_flags": list(binary.posix_flags),
        "win_flags": list(binary.win_flags), "win_link": list(binary.win_link), "smoke": binary.smoke,
        "source": binary.source} for name, binary in module.BY_NAME.items()}


def inner(args):
    root, out = args.root.resolve(), args.outdir.resolve()
    # Set temp placement before repository modules import tempfile.  Do not
    # configure any NativeBuild method, cache, flags, or negative-control body.
    os.environ["TMPDIR"] = str(out / "native-tmp")
    os.chdir(root)
    sys.path.insert(0, str(root / "tests"))
    spec = importlib.util.spec_from_file_location("binaries", root / "tests/binaries.py")
    binaries = importlib.util.module_from_spec(spec)
    sys.modules["binaries"] = binaries
    spec.loader.exec_module(binaries)
    before_contract = canonical_contract(binaries)
    before_out = str(binaries.OUT_DIR)
    binaries.OUT_DIR = out / "private-cache"  # Only adapted original module attribute.
    adapted_contract = canonical_contract(binaries)
    if before_contract != adapted_contract:
        raise RuntimeError("OUT_DIR changed an original compilation contract")
    receipt = {"schema": "geo314-graph5-inner/1", "classification": "P2 environment retry, not P3/final acceptance",
        "started_utc": utc(), "source_sha": args.source_sha, "root": str(root),
        "original_command": [sys.executable, "tests/_unittest_runner.py", SUITE,
            "--json-out", str(out / "result.json"), "--log", str(out / "unittest.log")],
        "original_expected_test_count": 5, "only_module_adaptation": "binaries.OUT_DIR",
        "OUT_DIR_before": before_out, "OUT_DIR_after": str(binaries.OUT_DIR),
        "canonical_contract_before": before_contract, "canonical_contract_after_adaptation": adapted_contract,
        "binaries_module_sha256": sha((root / "tests/binaries.py").read_bytes()),
        "judge_sha256": sha((root / SUITE).read_bytes()), "runner_sha256": sha((root / "tests/_unittest_runner.py").read_bytes()),
        "native_builder_sha256": sha((root / "tests/test_geo261_native_kernel.py").read_bytes())}
    write(out / "inner-receipt.json", receipt)

    def interrupted(signum, frame):
        raise KeyboardInterrupt("external scheduler signal " + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    import runpy
    old_argv = sys.argv[:]
    exit_code = 1
    try:
        sys.argv = [str(root / "tests/_unittest_runner.py"), str(root / SUITE),
            "--json-out", str(out / "result.json"), "--log", str(out / "unittest.log")]
        runpy.run_path(sys.argv[0], run_name="__main__")
        exit_code = 0
    except SystemExit as error:
        exit_code = error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
    except KeyboardInterrupt:
        exit_code = 130
        traceback.print_exc()
    except BaseException:
        traceback.print_exc()
        exit_code = 1
    finally:
        sys.argv = old_argv
        # NativeBuild registers cleanup with atexit, so its exact objects,
        # source copies, intentional mutant, compiler argv/output and binaries
        # still exist here.  Nothing disables or replaces its real cleanup.
        native = sys.modules.get("tests.test_geo261_native_kernel")
        builds = {}
        if native:
            for attribute in ("_BUILD", "_KERNEL_ONLY_BUILD"):
                build = getattr(native, attribute, None)
                if build is not None:
                    builds[attribute] = {"work": str(build.work), "kernel_only": build.kernel_only,
                        "compile_link_log": list(build.logs)}
        receipt["actual_native_builds"] = builds
        trees = inventory_tree(out / "native-tmp")
        write(out / "native-build-files.json", trees)
        with tarfile.open(out / "native-build-inputs-and-binaries.tar", "w") as archive:
            for relative in trees:
                archive.add(out / "native-tmp" / relative, arcname=relative, recursive=False)
        receipt["native_archive_sha256"] = sha((out / "native-build-inputs-and-binaries.tar").read_bytes())
        receipt["native_build_log_files"] = []
        for index, path in enumerate(sorted((out / "native-tmp").rglob("build-log.json"))):
            saved = out / ("native-build-log-" + str(index) + ".json")
            saved.write_bytes(path.read_bytes())
            receipt["native_build_log_files"].append({"file": saved.name, "sha256": sha(saved.read_bytes())})
        receipt["canonical_contract_after_judge"] = canonical_contract(binaries)
        receipt["contract_unchanged"] = receipt["canonical_contract_after_judge"] == before_contract
        receipt["original_runner_exit_code"] = exit_code
        receipt["finished_utc"] = utc()
        if (out / "result.json").is_file():
            receipt["original_runner_result"] = json.loads((out / "result.json").read_text())
        write(out / "inner-receipt.json", receipt)
    return exit_code


def outer(args):
    root, out = args.root.resolve(), args.outdir.resolve()
    if not args.execute:
        raise RuntimeError("execution gate closed; coordinator must explicitly authorize --execute")
    if args.source_sha != P2:
        raise RuntimeError("this retry is exclusively for P2 graph5")
    if out.is_relative_to(root):
        raise RuntimeError("output must be outside the detached checkout")
    stops = [*map(Path, args.stop_file), out / "STOP_REQUESTED",
        Path("/workspace/geo314-work/STOP_REQUESTED")]
    stop_check(stops)
    args.lock.parent.mkdir(parents=True, exist_ok=True)
    with args.lock.open("a+b") as lock:
        # Refuse immediately; never queue a graph build behind formal profiling.
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        stop_check(stops)
        out.mkdir(parents=True, exist_ok=False)
        for name in ("native-tmp", "private-cache"):
            (out / name).mkdir()
        shutil.copy2(__file__, out / "driver.py")
        shutil.copy2(args.reaper, out / "reap_children.py")
        before = snapshot(root, out, "before")
        if before["sha"] != P2:
            raise RuntimeError("actual detached root is not exact P2")
        fixture_receipts = []
        for index, relative in enumerate(FIXTURES):
            raw, command = metadata_command(root, out, "fixture-" + str(index), ["git", "show", P2 + ":" + relative])
            if (root / relative).read_bytes() != raw:
                raise RuntimeError("materialized runtime fixture differs from exact P2: " + relative)
            fixture_receipts.append({"path": relative, "command": command, "bytes": len(raw), "sha256": sha(raw)})
        stop_check(stops)
        sources = archive_sources(root, out)
        ledger = root / "tests/mutants_results.json"
        ledger_before = sha(ledger.read_bytes())
        env = {key: value for key, value in os.environ.items() if not key.startswith("GEOMETRY_")}
        env.update(TMPDIR=str(out / "native-tmp"), GEO261_REAPER_LOG=str(out / "reaper.jsonl"),
            LANG="C.UTF-8", LC_ALL="C.UTF-8", PYTHONDONTWRITEBYTECODE="1")
        soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
        if hard != resource.RLIM_INFINITY and hard < 16777216:
            raise RuntimeError("hard stack is below 16384 KiB")
        resource.setrlimit(resource.RLIMIT_STACK, (16777216, hard))
        inner_command = [sys.executable, str(Path(__file__).resolve()), "--inner", "--root", str(root),
            "--outdir", str(out), "--source-sha", P2]
        command = [sys.executable, str(args.reaper.resolve()), *inner_command]
        receipt = {"schema": "geo314-graph5-environment-retry/1", "classification": "diagnostic P2, not formal final-SHA acceptance",
            "started_utc": utc(), "source_sha": P2, "root": str(root), "scope": SUITE,
            "original_expected_test_count": 5, "outer_command": command, "inner_command": inner_command,
            "driver_sha256": sha(Path(__file__).read_bytes()), "reaper_sha256": sha(args.reaper.read_bytes()),
            "before": before, "runtime_fixtures": fixture_receipts, "source_inputs": sources,
            "ledger_before_sha256": ledger_before, "heavy_lock": str(args.lock.resolve()),
            "lock_policy": "exclusive nonblocking, held across judge, subreaper and all inventories",
            "stop_files": [str(path) for path in stops], "environment": {key: env.get(key) for key in
                ("PATH", "TMPDIR", "LANG", "LC_ALL", "CC", "CFLAGS", "CXXFLAGS", "LDFLAGS", "PYTHONDONTWRITEBYTECODE", "GEO261_REAPER_LOG")},
            "platform": platform.platform(), "python": sys.version, "stack_rlimit": resource.getrlimit(resource.RLIMIT_STACK)}
        write(out / "receipt.json", receipt)
        stop_check(stops)
        started = time.monotonic()
        with (out / "stdout.raw").open("wb") as stdout, (out / "stderr.raw").open("wb") as stderr:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr,
                start_new_session=True)
            try:
                while process.poll() is None:
                    stop_check(stops)
                    if time.monotonic() - started > args.timeout:
                        raise TimeoutError("graph5 retry exceeded external timeout")
                    try: process.wait(timeout=0.5)
                    except subprocess.TimeoutExpired: pass
            except (InterruptedError, TimeoutError) as error:
                receipt["external_stop"] = repr(error)
                # The original reaper forwards SIGTERM to the native process
                # group and remains alive to record its real child exits.
                process.send_signal(signal.SIGTERM)
                try: process.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    receipt["reaper_stop_timeout"] = True
                    process.kill(); process.wait()
        receipt.update(exit_code=process.returncode, elapsed_seconds=time.monotonic() - started,
            finished_utc=utc(), after=snapshot(root, out, "after"),
            ledger_after_sha256=sha(ledger.read_bytes()))
        receipt["ledger_unchanged"] = ledger_before == receipt["ledger_after_sha256"]
        receipt["outputs"] = {path.name: {"bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
            for path in out.iterdir() if path.is_file() and path.name != "receipt.json"}
        write(out / "receipt.json", receipt)
        print(json.dumps({"exit_code": process.returncode, "source_sha": P2, "outdir": str(out)}))
        return process.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/g314-native-diagnostic-p2"))
    parser.add_argument("--outdir", type=Path, default=Path("/workspace/geo314-work/environment-repair-001/graph5"))
    parser.add_argument("--source-sha", default=P2)
    parser.add_argument("--reaper", type=Path, default=Path("/workspace/geo261-environment/reap_children.py"))
    parser.add_argument("--lock", type=Path, default=Path("/workspace/geo314-work/private-diagnostic.lock"))
    parser.add_argument("--stop-file", action="append", default=[])
    parser.add_argument("--timeout", type=int, default=1200)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--inner", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    return inner(args) if args.inner else outer(args)


if __name__ == "__main__":
    raise SystemExit(main())
