#!/usr/bin/env python3
"""Materialize only four existing tracked native fixtures from exact checkout SHA."""
import argparse,datetime,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--sha',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
paths=['tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas','tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas','tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas','tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene']
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==a.sha
before_status=git('status','--porcelain=v2','--branch');assert all(x.startswith(b'# ') for x in before_status.splitlines())
receipt={'schema':'geo314-native-fixture-materialization/1','classification':'environment preparation, no tests or product changes','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'sha':a.sha,'entries':[]}
for i,n in enumerate(paths):
 argv=['git','show',a.sha+':'+n];r=subprocess.run(argv,cwd=root,capture_output=True);(out/(str(i)+'.git-show.stdout')).write_bytes(r.stdout);(out/(str(i)+'.git-show.stderr')).write_bytes(r.stderr);assert r.returncode==0
 flag=git('ls-files','-t','--',n);target=root/n;existed=target.exists()
 if existed:assert target.read_bytes()==r.stdout, 'refuse to overwrite existing different bytes: '+n
 else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(r.stdout)
 assert git('ls-files','-t','--',n)==flag,'skip-worktree flag changed'
 receipt['entries'].append({'path':n,'argv':argv,'exit_code':r.returncode,'blob':git('rev-parse',a.sha+':'+n).decode().strip(),'sha256':hashlib.sha256(r.stdout).hexdigest(),'bytes':len(r.stdout),'existed_before':existed,'ls_files_flag':flag.decode().strip(),'bytes_equal_final_blob':target.read_bytes()==r.stdout})
after_status=git('status','--porcelain=v2','--branch');receipt['tracked_status_unchanged']=before_status==after_status;assert before_status==after_status
(out/'before.status').write_bytes(before_status);(out/'after.status').write_bytes(after_status);receipt['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
