# 單調已排序 suffix 快速路徑：獨立反例計畫

此檔只有靜態設計。未改產品／tests、未編譯、未執行任何場景。來源依目前 U `ca7838e0f4950452b9befcf40899d606db9b81fa` 的 `contact_world.c` 與原 contact-world harness。

輸入中的 N 指已收集的 member face suffix 長度，不是成員數。每個普通成員有兩個 side face；各 member 的座標分離，避免去重把排序錯誤掩掉。expected 次序須明列 fixture index 和 side 0、1，再用既有完整公開欄位比較 helper 核對，不能用產品 comparator 生成 oracle。

| 場景 | order 與明確預期 | 專找的錯誤 |
|---|---|---|
| 已排序 | 成員 `[10,20,30,40,50]`；所有 side 保原次序 | 必進 early return；identity index 初始化須保留。只計 sort 的 order query，N≥2 時應恰 N，不能把後續 face-index rebuild/query 混入成本 |
| 逆序 | `[50,40,30,20,10]` → fixture `[4,3,2,1,0]`，各自 side0、side1 | 撤掉逆序判斷或無條件 early return 必紅；原 merge/cycle 路徑照跑 |
| 同值與穩定性 | 純 ties `[7,7,7,7]` 保原；另 `[30,10,10,20]` → `[1,2,3,0]` | 純 ties 應可 fast return；混合逆序 ties 必進 merge，驗證原 `<=` 的 side/member 穩定性。只有全相等 fixture 會讓原 stable-ties 刀失去覆蓋 |
| RC prefix | 原兩個 boundary face＋member `[10,20]`；prefix 所有欄位原封不動；另 member `[20,10]` | early return 的掃描與 identity 初始化都限 `[first,count)`。原 `first=0` 刀把 RC 的 missing-id order `UINT64_MAX` 混入後必見逆序、進 merge 並觸發原 prefix marker |
| 沒有 member | `first==count`，含0 faces與非空RC-only兩種；tail canary不變 | 必在讀 `out[first]` 前返回；不讀未初始化 key，不將 unsigned `count-first-1` 下溢。若支援單一 suffix face，另列 N=1 保identity，不強迫查key |
| 最後／中段逆序 | `[10,20,30,40,35]` → `[0,1,2,4,3]`；另 `[10,30,20,40,50]` → `[0,2,1,3,4]` | 最後一項必掃到；cached previous 每步更新，不能一直與首項比。中段案例專殺漏更新 previous 的錯誤 |
| 完整 uint64 | 已排序 `[1,2^32,2^63,UINT64_MAX]` 保原；逆序 `[UINT64_MAX,2^63,2^32,1]` → `[3,2,1,0]` | scan 用無號64位 `<`/`>`，不能 int64 cast、uint32 truncation 或 subtraction overflow；原 merge full-order 控制仍可到達 |

## 原兩個控制的路徑核對

- `stable-ties` 原指定 `ordering`。其第一個實際 fixture order 是 `[30,10,10,20]`，所以正常 monotonic scan 不會 early return；原 `return left<=right;` → `<` 控制仍進 merge，應在 `placement-stable-equal-order-sides` 以原具名 assertion 轉紅。原前置 `placement-order-before-declaration` 有意允許42或43第一，不能改成會搶先截斷目標 marker 的較強比較。
- `sort-rc-prefix` 原指定 `indexed-sort`，把 `size_t members=count-first;` 改成 `first=0;size_t members=count-first;`。RC id0 的 `contact_order` 為 `UINT64_MAX`，後有10/20，因此錯誤 scan 仍會走 merge；`sort-rc-prefix-preserved` 原 assertion 應紅。不能把快速返回插在此 mutation seam 之前，否則該控制會存活。
- `contact_face_index_build` 在排序後自行重建 `sorted/maximum`；必保持原初始化，不得把 fast return 的 identity index 誤當已建好的 plane/rank/maximum。

## 整刀與工作量反證

固定同一個已排序、非零 N fixture，正常／整段撤回 monotonic scan＋early return／恢復各自使用真正編譯的程式，三段都先驗完整公開 face 次序與欄位相同。工作量只計被測 `contact_member_index_sort` 的 `contact_order` 查詢，不計建 index、dedup 或後續查詢；原函式外的 observer 不得改產品回傳或 fixture。

正常／恢復 N≥2 應恰 N 次查詢；整段撤回應進原 merge，選原已知 N=10 faces 等 fixture，使它的實際次數超過 N，讓同一個確切成本 assertion 正常失敗。這是演算法導出的局部工作量，不是新訂 wall/CPU/1.3 性能門檻。whole withdrawal 的紅必為具名框架 assertion，不能拿編譯／OS error 替代。

還須保留原 reverse、cycle、non-power、legacy duplicate/overflow、partial-capacity、full-uint64 控制；新增 early-return 不能讓既有控制變成 equivalent 而默默改帳。局部線性查詢量不代表 N64 load gate 已通過，後續仍按原36樣本與 fix/main≤1.3 驗證。
