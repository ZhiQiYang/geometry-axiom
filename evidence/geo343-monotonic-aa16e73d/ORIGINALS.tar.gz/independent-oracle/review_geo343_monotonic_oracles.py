#!/usr/bin/env python3
"""Static independent sequence/work oracle review; never import or execute subject."""
import ast,hashlib,json
from pathlib import Path
B=Path('/workspace/geo343-monotonic-sort-draft-20261024');P=Path('/workspace/train337-canvas-peer-resume')
checks=[]
def need(v,n):checks.append({'check':n,'passed':bool(v)})
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((B/'COMPANION_MANIFEST.json').read_text())
need(h(B/'FOUR_LEAF.patch')==m['four_leaf_patch_sha256']=='746a58a5f3b16182fad4e8c5338d56ad64472ae1178670e76cb6cb6c6aebd20d','frozen v2 four-leaf patch')
for f,pin in m['files'].items():need(h(B/'candidate'/f)==pin,'frozen candidate '+f)
hp=B/'candidate/tests/geo343_monotonic_sort_harness.c';s=hp.read_text()
need(h(hp)=='16f1cada5121b1a44b2112340bed31945a6de83a20b858278868f6822c560804','frozen harness with middle inversion')
t=(B/'candidate/tests/test_geo261_wood_contact_world.py').read_text();a=ast.parse(t)
product=(B/'candidate/geometry-templates/woodworking/native/contact_world.c').read_text()
fixtures={
 'sorted':([10,20,30,40,50,60,70,80],list(range(8))),
 'reverse':([80,70,60,50,40,30,20,10],list(range(7,-1,-1))),
 'ties':([30,10,20,10,30,20,10,20],[1,3,6,2,5,7,0,4]),
 'all-ties':([7]*8,list(range(8))),
 'prefix':([40,10,30,20],[1,3,2,0]),
 'no-member':([],[]),'one-member':([10],[0]),
 'last-inversion':([10,20,30,40,50,60,70,5],[7,0,1,2,3,4,5,6]),
 'middle-inversion':([10,30,20,40,50],[0,2,1,3,4]),
 'full-uint64':([2**64-1,2**63,2**32,1],[3,2,1,0]),
 'work':([10*(i//2+1) for i in range(128)],list(range(128)))
}
for name,(values,expected) in fixtures.items():need(sorted(range(len(values)),key=lambda i:values[i])==expected,'independent stable order '+name)
need('const uint64_t v[5]={10,30,20,40,50};const size_t e[5]={0,2,1,3,4};' in s,'middle inversion binds independent oracle')
need('const uint64_t v[8]={30,10,20,10,30,20,10,20};const size_t e[8]={1,3,6,2,5,7,0,4};' in s,'stable ties exact full permutation')
need('else if(work){first=2;member_count=64;face_count=128;}' in s and 'size_t id=work?i/2:i;' in s,'work reaches64 facts128 suffix faces plus2 RC')
need('members[i].id=(uint32_t)(i+1);members[i].placed=true;' in s and 'WoodContactWorld world={.placement_id=7,.members=facts,.member_count=member_count};' in s,'work facts unique valid ids and lifetimes remain in scope')
need('WoodMember members[64];WoodContactMemberFact facts[64];' in s and 'out[131],original[131]' in s and 'expected[128];uint64_t values[64]' in s,'fixed arrays cover maximum64 facts130 faces plus tail')
need('contact_order_index(&world,&orders);geo_test_sort_order_calls=0;' in s and 'size_t calls=geo_test_sort_order_calls;' in s and s.index('size_t calls=geo_test_sort_order_calls;')<s.index('contact_face_index_build(&index,out,count);'),'work interval excludes order-index build and face-index rebuild')
need('calls==face_count' in s and 'calls==0' in s,'sorted N lookup contract and zero/single no lookup')
need(product.index('if(members<2)return;')<product.index('uint64_t previous=contact_order'),'zero/single avoids uninitialized suffix reads')
fields=['kind','boundary_id','timber_id','hole_index','edge_index','fixity','fixed','lo','hi']
need(all('a->'+f+'==b->'+f in s for f in fields),'all nine semantic fields compared without padding UB')
need('monotonic-prefix-fields' in s and 'monotonic-uncollected-tail' in s,'RC prefix and uncollected tail preserved')
need('memset(&index,0xa5,sizeof index)' in s and 'index.sorted[i]<count&&index.rank[index.sorted[i]]==i&&index.maximum[i]==0' in s,'poisoned index then every rank/maximum initialized')
need('a->fixed<b->fixed||(a->fixed==b->fixed&&a->lo<=b->lo)' in s,'independent rebuilt plane ordering checked')
need('source,instrumented.replace(counted,anchor)' in t and '++geo_test_sort_order_calls;' in t,'actual product function instrumented and exact uninstrumented bytes checked')
method=next(n for n in ast.walk(a) if isinstance(n,ast.FunctionDef) and n.name=='test_monotonic_sort_preserves_full_fields_and_linear_sorted_lookup_work')
controls=ast.literal_eval(next(n.value for n in ast.walk(method) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='controls' for x in n.targets)))
need(len(controls)==4,'exact four new semantic controls')
def early(values,kind=None):
 if len(values)<2:return True
 prev=values[0] & ((1<<32)-1) if kind=='truncated-previous' else values[0]
 stop=len(values)-1 if kind=='missed-last-face' else len(values)
 for current in values[1:stop]:
  if prev>current:return kind=='missed-inversion'
  if kind!='missed-previous-update':prev=current & ((1<<32)-1) if kind=='truncated-previous' else current
 return True
for label,before,after,case,marker in controls:
 need(product.count(before)==1,'unique exact product mutation '+label)
 values,expected=fixtures[case]
 need(not early(values) and early(values,label) and expected!=list(range(len(values))),'independent mutant reaches wrong early return '+label)
 need('CHECK(marker,same_face' in s and marker in s,'normal named full-field failure '+label)
need('("fixed",source,0),("withdrawn",withdrawn,1),("restored",restored,0)' in t,'whole optimization exact0/1/0 required')
need('self.assertEqual(source,restored' in t and 'self.assertIn("ASSERT:monotonic-linear-order-lookups"' in t,'whole withdrawal restore bytes and exact work marker')
need('self.assertEqual(1,result.returncode,result.stderr);self.assertIn("ASSERT:"+marker,result.stderr)' in t,'four controls reject crash/compiler failures as kills')
need(128==len(fixtures['work'][0]) and 2*(128//2)*7==896,'independent128 sorted values versus896 old merge order lookups')
need('first=0;size_t members=count-first;' in t and product.index('size_t members=count-first;')<product.index('if(members<2)return;'),'old RC-prefix mutant remains before new fast path')
need(not early([30,30,10,10,10,10,20,20]),'old ordering/ties witness still reaches original merge')
need(not early([2**64-1,2**64-1,10,10,20,20]),'old prefix mutant still reaches original merge')
failed=[x['check'] for x in checks if not x['passed']]
o=P/'GEO343_MONOTONIC_HARNESS_ORACLE_STATIC_PEER.json';o.write_text(json.dumps({'scope':'Independent harness oracle and four controls only; source/AST broad review belongs to backlog','checks':len(checks),'exit_code':int(bool(failed)),'findings':failed,'patch_sha256':h(B/'FOUR_LEAF.patch'),'harness_sha256':h(hp),'fixture_oracles':{k:{'orders':v[0],'stable_expected_indices':v[1]} for k,v in fixtures.items()},'limitations':['No C compile, subject execution, performance claim or actual mutation result.','128 and896 are statically-derived contact_order counts within only the sort interval.','Direct private-function harness plus original public tests; it does not claim public collector coverage by itself.','Old RC/ties reachability statically checked, actual original controls still required.'],'check_details':checks},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(o),'sha256':h(o),'checks':len(checks),'exit_code':int(bool(failed)),'findings':failed}));raise SystemExit(bool(failed))
