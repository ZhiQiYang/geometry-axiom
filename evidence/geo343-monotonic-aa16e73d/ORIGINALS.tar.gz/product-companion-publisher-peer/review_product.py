from pathlib import Path
import hashlib, itertools, json

ROOT = Path('/workspace/geo343-monotonic-sort-draft-20261024')
OUT = Path(__file__).parent
LEAF = 'geometry-templates/woodworking/native/contact_world.c'
m = json.loads((ROOT / 'MANIFEST.json').read_text())
b = (ROOT / 'before' / LEAF).read_bytes()
c = (ROOT / 'candidate' / LEAF).read_bytes()
checks = []
def check(label, condition):
    checks.append({'check':label, 'passed':bool(condition)})
sha = lambda v: hashlib.sha256(v).hexdigest()
check('U source SHA fixed', m['source_sha'] == 'ca7838e0f4950452b9befcf40899d606db9b81fa')
check('before equals actual U source', b == (Path('/workspace/geo323-union-fixed-source-20261024') / LEAF).read_bytes())
check('before pin', sha(b) == m['before_sha256'])
check('candidate pin', sha(c) == m['candidate_sha256'])
check('patch pin', sha((ROOT/'PRODUCT_ONLY.patch').read_bytes()) == m['patch_sha256'])
block = m['whole_withdrawal']['after'].encode()
check('unique insertion', c.count(block)==1)
check('whole withdrawal exact U bytes', c.replace(block,b'',1)==b)
check('identity initialization precedes inserted block', b'index->sorted[i]=i;\n'+block in c)
check('member guard before first read', block.index(b'if(members<2)return;') < block.index(b'out[first]'))
check('strict descending detects inversion', b'if(previous>current)' in block)
check('uint64 preserves full order', b'uint64_t previous=' in block and b'uint64_t current=' in block)
check('original stable <= comparator', b'return left<=right;' in b)
check('no allocation in block', all(t not in block for t in [b'malloc',b'calloc',b'realloc',b'free(']))
# Reads of out[] are expected; ensure no assignment through an input pointer.
check('only locals assigned', all(t not in block for t in [b'out[first]=',b'out[i]=',b'world->',b'orders->',b'index->']))
check('face index rebuild still follows member sort', b'contact_member_index_sort(world,orders,out,count,first,&index);\n    contact_face_index_build(&index,out,count);' in c)
def old_sort(values):
    ix=list(range(len(values))); width=1; calls=0
    while width<len(ix):
        scratch=[]
        for start in range(0,len(ix),2*width):
            a=start; mid=min(start+width,len(ix)); end=min(mid+width,len(ix)); d=mid
            while a<mid and d<end:
                calls+=2
                if values[ix[a]] <= values[ix[d]]: scratch.append(ix[a]); a+=1
                else: scratch.append(ix[d]); d+=1
            scratch.extend(ix[a:mid]);scratch.extend(ix[d:end])
        ix=scratch;width*=2
    return ix,calls
def new_sort(values):
    if len(values)<2:return list(range(len(values))),0
    previous=values[0]; calls=1
    for current in values[1:]:
        calls+=1
        if previous>current:
            result,n=old_sort(values);return result,calls+n
        previous=current
    return list(range(len(values))),calls
cases=0
for n in range(7):
    for values in itertools.product([0,1,2**64-1],repeat=n):
        before,_=old_sort(values);after,_=new_sort(values)
        check('model stable order '+str(values),before==after)
        cases+=1
before,old_calls=old_sort(list(range(128)))
after,new_calls=new_sort(list(range(128)))
check('128 independent operation example', before==after and old_calls==896 and new_calls==128)
findings=[x['check'] for x in checks if not x['passed']]
report={'source_sha':m['source_sha'],'patch_sha256':m['patch_sha256'],'candidate_sha256':m['candidate_sha256'],'checks':len(checks),'failures':len(findings),'findings':findings,'pure_python_model_cases':cases,'model_128_contact_order_calls':{'original':old_calls,'candidate':new_calls},'scope':'Only static bytes and independent pure-Python stable-order arithmetic. No C, subject import, performance sample, or branch write. Models are not formal product receipts.','remaining':['C original suite and whole withdrawal normal assertion 0/1/0','inverted/late-inverted/full uint64 and zero/one/prefix cases','original final-SHA N64 wall gate; no savings guarantee from gprof']}
(OUT/'PRODUCT_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));raise SystemExit(bool(findings))
