from pathlib import Path
import ast,difflib,hashlib,json

ROOT=Path('/workspace/geo343-monotonic-sort-draft-20261024')
OUT=Path(__file__).parent
m=json.loads((ROOT/'COMPANION_MANIFEST.json').read_text())
checks=[]
def check(label,condition):checks.append({'check':label,'passed':bool(condition)})
sha=lambda b:hashlib.sha256(b).hexdigest()
leaves=['geometry-templates/woodworking/native/contact_world.c','tests/test_geo261_wood_contact_world.py','tests/geo343_monotonic_sort_harness.c','tests/run_all.expected.json']
generated=[]
for leaf in leaves:
    p=ROOT/'candidate'/leaf;data=p.read_bytes();before=ROOT/'before'/leaf
    check('candidate pin '+leaf,sha(data)==m['files'][leaf])
    old=before.read_text() if before.exists() else ''
    generated.extend(difflib.unified_diff(old.splitlines(True),data.decode().splitlines(True),fromfile='a/'+leaf if before.exists() else '/dev/null',tofile='b/'+leaf))
patch=(ROOT/'FOUR_LEAF.patch').read_bytes()
check('full patch reconstruction',''.join(generated).encode()==patch)
check('full patch pin',sha(patch)==m['four_leaf_patch_sha256'])
check('previously reviewed product pin',m['files'][leaves[0]]=='02473416994421585fbb05288af78c7bb598e23e8e3a768391af3720dfad9859')
old_py=(ROOT/'before'/leaves[1]).read_text();new_py=(ROOT/'candidate'/leaves[1]).read_text()
a=ast.parse(old_py);b=ast.parse(new_py)
def definitions(tree):
    result={}
    for item in tree.body:
        if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):result[item.name]=ast.dump(item,include_attributes=False)
        if isinstance(item,ast.ClassDef):
            for method in item.body:
                if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)):result[item.name+'.'+method.name]=ast.dump(method,include_attributes=False)
    return result
ad=definitions(a);bd=definitions(b)
for key,value in ad.items():check('original definition unchanged '+key,bd.get(key)==value)
def assignment(tree,name):
    return next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
check('original controls AST unchanged',ast.dump(assignment(a,'CONTROLS'))==ast.dump(assignment(b,'CONTROLS')))
check('original case timeout 20', 'timeout=20' in old_py and 'timeout=20' in new_py)
check('13 real test methods',sum(k.startswith('WoodContactWorld.test_') for k in bd)==13)
old_registry=(ROOT/'before'/leaves[3]).read_bytes();new_registry=(ROOT/'candidate'/leaves[3]).read_bytes()
before=b'"py:test_geo261_wood_contact_world": {\n      "mode": "count",\n      "count": 12,'
after=before.replace(b'12,',b'13,')
check('registry exact single row 12->13',old_registry.count(before)==1 and old_registry.replace(before,after)==new_registry)
product=(ROOT/'candidate'/leaves[0]).read_text()
block=ast.literal_eval(assignment(b,'MONOTONIC_SORT_BLOCK'));anchor=ast.literal_eval(assignment(b,'MONOTONIC_SORT_ANCHOR'))
check('whole block unique',product.count(block)==1)
check('whole restoration exact',product.replace(block,'').replace(anchor,anchor+block)==product)
check('whole withdrawal exact U',product.replace(block,'')==(ROOT/'before'/leaves[0]).read_text())
new_method=next(n for n in ast.walk(b) if isinstance(n,ast.FunctionDef) and n.name=='test_monotonic_sort_preserves_full_fields_and_linear_sorted_lookup_work')
controls=ast.literal_eval(next(n.value for n in new_method.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='controls' for t in n.targets)))
check('four semantic controls',len(controls)==4)
for label,before,after,case,marker in controls:
    check('control site unique '+label,product.count(before)==1)
    check('control actual change '+label,before!=after)
check('source/client/object/exe paths distinct',all(t in new_py for t in ['label+"-source.c"','label+"-client.c"','label+"-client"','label+"-exe"']))
h=(ROOT/'candidate'/leaves[2]).read_text()
for field in ['kind','boundary_id','timber_id','hole_index','edge_index','fixity','fixed','lo','hi']:
    check('independent full field comparison '+field,'a->'+field+'==b->'+field in h)
check('original product TU included once',h.count('#include "contact-monotonic-subject.c"')==1)
check('only sort interval counted',h.index('geo_test_sort_order_calls=0;')<h.index('contact_member_index_sort(')<h.index('size_t calls=geo_test_sort_order_calls;')<h.index('contact_face_index_build('))
check('normal work assertion marker', 'if(work)CHECK("monotonic-linear-order-lookups",calls==face_count);' in h)
check('normal primary process code', 'return argc==2?run_case(argv[1]):2;' in h)
check('whole phases strict 0/1/0','(("fixed",source,0),("withdrawn",withdrawn,1),("restored",restored,0))' in new_py)
check('new controls exact normal 1 and marker','self.assertEqual(1,result.returncode,result.stderr);self.assertIn("ASSERT:"+marker,result.stderr)' in new_py)
check('work extents in fixed storage','WoodStopFace out[131],original[131]' in h and 'member_count=64;face_count=128' in h)
check('middle inversion added','middle-inversion' in h and 'missed-previous' in new_py)
findings=[r['check'] for r in checks if not r['passed']]
report={'checks':len(checks),'failures':len(findings),'findings':findings,'patch_sha256':m['four_leaf_patch_sha256'],'files':m['files'],'scope':'Static bytes and AST only. No C, subject import, discovery, compilation, or wall timing. Original controls inspected for continued inverted/legacy paths; actual old/new normal assertion outcomes remain UNRUN.','manual_notes':['0/1 guard precedes out[first] read; work first2+128=130 within out131 and all 64 member slots initialized.','Last inversion reaches expected full-fields marker; uint32 previous makes full64 incorrectly early-return. Middle inversion must catch removed previous update before the final lookup-work assertion.','Original sort-cycle/full64 controls still enter merge on inverted inputs; duplicate/overflow controls retain legacy-path witnesses.','NativeBuild compile has original 300s; case has original20s. No C execution claimed.']}
(OUT/'COMPANION_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'COMPANION_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));raise SystemExit(bool(findings))
