from pathlib import Path
import hashlib,json,ast
R=Path('/workspace/geo343-monotonic-sort-draft-20261024');O=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(label,v):checks.append({'check':label,'passed':bool(v)})
old=(R/'publish_source.py').read_bytes();new=(R/'publish_source_r2.py').read_bytes();s=new.decode()
check('original publisher frozen',sha(old)=='94ab689850558cdf084de4454333a5a69fb2c5312397fc13501b9bd163aae4db')
check('R2 publisher frozen',sha(new)=='2fbfcb2e4fa3a158cde271bf7948786ba7dc1cb44f314cd588ac25faaf294f22')
ast.parse(old);ast.parse(new);check('both AST parse',True)
m=(R/'COMPANION_MANIFEST.json').read_bytes();check('reviewed companion manifest frozen',sha(m)=='fcd4fd328617fc40397dd76f5796cbf7b134fa47592b7a8e60e7b4ca7c9d6808')
report=json.loads((R/'source-publication/RESULT.json').read_bytes());last=report['commands'][-1]
check('original R1 true1 retained',report['exit']==1 and report['source_sha'] is None and report['pushed'] is False)
check('original command317 add exit1',len(report['commands'])==317 and last['exit']==1 and last['argv'][5:8]==['add','--sparse','--'])
for stream in ['stdout','stderr']:
    p=R/'source-publication/commands/317'/stream
    check('original final '+stream+' exact',sha(p.read_bytes())==last[stream]['sha256'])
check('ignored native parent diagnostic',b'ignored' in (R/'source-publication/commands/317/stderr').read_bytes())
for label,token in [
 ('distinct R2 result directory',"p.OUT=HERE/'source-publication-r2'"),
 ('fixed allowlist guard',"sorted(m['files'])==ALLOW"),
 ('manifest pin before work mutation',"p.sha((HERE/'COMPANION_MANIFEST.json').read_bytes())==MANIFEST"),
 ('patch original746a guard',"p.sha((HERE/'FOUR_LEAF.patch').read_bytes())==p.PATCH"),
 ('100MiB resource guard',">=100*1024*1024"),
 ('own U HEAD guard',"p.git('rev-parse','HEAD',cwd=p.WORK).decode().strip()==p.BASE"),
 ('own branch guard',"p.git('symbolic-ref','--short','HEAD',cwd=p.WORK).decode().strip()==p.BRANCH"),
 ('no index writer',"not p.private('index.lock').exists()"),
 ('remote absent',"p.git('ls-remote','--heads','origin','refs/heads/'+p.BRANCH)==b''"),
 ('no unstaged edits',"p.git('diff','--name-only',cwd=p.WORK)==b''"),
 ('exact staged allowlist',"sorted(p.git('diff','--cached','--name-only',cwd=p.WORK).decode().splitlines())==ALLOW"),
 ('private sparse original',"p.private('info/sparse-checkout').read_bytes()==(OLD/'SPARSE_STDIN.txt').read_bytes()"),
 ('each staged blob equals actual closure',"p.git('show',':'+name,cwd=p.WORK)==body"),
 ('candidate byte pin',"p.sha(body)==m['files'][name]"),
 ('ordinary parent',"decode().strip()==p.BASE,'normal U parent'"),
 ('ordinary push',"p.git('push','origin','HEAD:refs/heads/'+p.BRANCH,cwd=p.WORK)"),
 ('remote exact after push',"decode().split()[0]==source,'remote source resolves'"),
]:check(label,token in s)
check('all inherited GIT_ redirects cleared',"if not k.startswith('GIT_')" in old.decode())
check('no force rebase reset add in R2',all(t not in s for t in ["p.git('add'","--force", "p.git('reset'", "p.git('rebase'"]))
check('source manifest after normalcommit','SOURCE_MANIFEST.json' in s and s.index("p.git('commit'")<s.index("p.OUT/'SOURCE_MANIFEST.json'"))
check('no C invocation introduced',all(t not in s for t in ["gcc",'compile(',"ctypes",'native()']))
check('all runtime mutations after manifest guard',s.index("COMPANION_MANIFEST.json").__lt__(s.index("p.git('commit'")))
result={'checks':len(checks),'failures':sum(not x['passed'] for x in checks),'findings':[x['check'] for x in checks if not x['passed']],'publisher_sha256':sha(new),'scope':'Static tools and original R1 final-command inspection only. No execution of publisher, source writes, Git mutation, network, or C.','notes':['R1 actual git add1 after ignored native parent warning is retained; exact staging is rechecked by R2 before normal commit. This is tool failure, not a product mutation verdict.','Original imported94ab module has only definitions/constants at import and a __main__ guard; no import-time Git command. R2 later verifies its exact pin.']}
(O/'PUBLISHER_R2_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(O/'PUBLISHER_R2_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False));raise SystemExit(bool(result['failures']))
