"""Read-only fixture snapshots before the unchanged bridge call.

This is an external functional-test observer, not a performance observer.
It preserves the old byte collector and only adds loadfile references found in
an original command or original subprocess input. A snapshot is not a claim
that the child subsequently read these bytes, or even reached that command.
"""
from __future__ import annotations

import functools
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
from observe_bridge_bytes import Observer, error_record, sha


def stat_record(value):
    return {name: getattr(value, name) for name in
            ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


class FixtureObserver(Observer):
    def __init__(self, out, source_sha, root):
        super().__init__(out, source_sha, root)
        self.fixture_root = self.out / 'loadfile-inputs'
        self.fixture_root.mkdir()
        (self.fixture_root / 'bytes').mkdir()
        self.fixture_events = []
        self.fixture_private = Path(os.environ['TMPDIR']).resolve()

    def save_fixture_events(self):
        # ASCII escaping also preserves non-UTF8 POSIX filename surrogates.
        (self.fixture_root / 'SNAPSHOTS.json').write_text(
            json.dumps({'source_sha': self.source_sha,
                        'scope': 'before original call; not proof of child consumption',
                        'events': self.fixture_events}, ensure_ascii=True, indent=2) + '\n')

    def snapshot_path(self, path_bytes, cwd):
        path = Path(os.fsdecode(path_bytes))
        if not path.is_absolute():
            path = Path(cwd) / path
        path = Path(os.path.abspath(path))
        row = {'path_argument_hex': path_bytes.hex(), 'original_path': str(path),
               'captured': False, 'snapshot_before_original_call': True}
        # Resolve parent directories to reject links escaping the two allowed
        # roots, then refuse final-component links and special files entirely.
        resolved = path.resolve(strict=False)
        if not (resolved.is_relative_to(self.root) or resolved.is_relative_to(self.fixture_private)):
            raise ValueError('loadfile outside source/private TMPDIR: ' + str(path))
        try:
            before = path.lstat()
        except FileNotFoundError:
            row.update(status='absent-before-original-call', child_result_not_predicted=True)
            return row
        row['lstat_before'] = stat_record(before)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('loadfile snapshot requires an original regular file, not a link/device/FIFO')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            opened = os.fstat(fd)
            if not stat.S_ISREG(opened.st_mode) or stat_record(opened) != stat_record(before):
                raise OSError('loadfile changed before snapshot open')
            parts = []
            while True:
                block = os.read(fd, 65536)
                if not block:
                    break
                parts.append(block)
            after = os.fstat(fd)
        finally:
            os.close(fd)
        body = b''.join(parts)
        after_path = path.lstat()
        if stat_record(before) != stat_record(after) or stat_record(before) != stat_record(after_path) or len(body) != before.st_size:
            raise OSError('loadfile changed during snapshot')
        digest = sha(body)
        target = self.fixture_root / 'bytes' / digest
        if not target.exists():
            target.write_bytes(body)
        elif sha(target.read_bytes()) != digest:
            raise OSError('retained loadfile blob differs from digest')
        row.update(captured=True, status='original-bytes-snapshotted', bytes=len(body),
                   sha256=digest, retained=str(target), stat_after=stat_record(after),
                   child_consumption_not_proven=True)
        return row

    def capture_loadfiles(self, payload, cwd, event, correlation):
        if not isinstance(payload, (str, bytes)):
            return
        data = payload.encode('utf-8') if isinstance(payload, str) else payload
        row = {'event': event, 'correlation': correlation, 'started_epoch': time.time(),
               'cwd': os.fsdecode(cwd), 'input_sha256': sha(data),
               'input_representation': 'original-text-utf8' if isinstance(payload, str) else 'original-input-bytes',
               'references': [], 'complete': True}
        # Original bridge uses fgets(4096), strips trailing CR/LF and splits at
        # the first ASCII space. Do not strip/expand/quote the path argument.
        for line_number, original_line in enumerate(data.split(b'\n'), 1):
            line = original_line.rstrip(b'\r')
            if not line.startswith(b'loadfile '):
                continue
            if b'\0' in line or len(original_line) >= 4095:
                row['complete'] = False
                row['references'].append({'line': line_number, 'captured': False,
                    'status': 'unsupported-NUL-or-overlong-command', 'original_line_sha256': sha(original_line)})
                self.errors.append({'where': 'loadfile-command-snapshot', 'reason': 'NUL/overlong input needs original parser evidence'})
                continue
            try:
                reference = self.snapshot_path(line[len(b'loadfile '):], cwd)
                reference['line'] = line_number
                row['references'].append(reference)
            except Exception as exc:
                row['complete'] = False
                row['references'].append({'line': line_number, 'captured': False,
                                          'status': 'snapshot-failed', **error_record(exc)})
                self.errors.append({'where': 'loadfile-original-file-snapshot', **error_record(exc)})
        if row['references']:
            row['ended_epoch'] = time.time()
            self.fixture_events.append(row)
            self.save_fixture_events()

    def install_class(self, cls):
        if cls in self.classes:
            return
        super().install_class(cls)
        original_command = cls.command
        @functools.wraps(original_command)
        def command(session, *args, **kwargs):
            row = getattr(session, '_original_bytes_observation', None)
            payload = args[0] if args else kwargs.get('text')
            cwd = row['cwd'] if row is not None else os.getcwd()
            correlation = row['folder'] if row is not None else None
            self.safe(lambda: self.capture_loadfiles(payload, cwd,
                'before-original-BridgeSession.command', correlation), 'loadfile-before-command')
            return original_command(session, *args, **kwargs)
        self.patch(cls, 'command', command)
        self.patch(cls, 'send', command)

    def install_run(self):
        super().install_run()
        original_run = subprocess.run
        @functools.wraps(original_run)
        def run(*args, **kwargs):
            self.safe(lambda: self.capture_loadfiles(kwargs.get('input'),
                kwargs.get('cwd') or os.getcwd(), 'before-original-subprocess.run',
                'command-%06d' % (len(self.commands) + 1)), 'loadfile-before-run')
            return original_run(*args, **kwargs)
        self.patch(subprocess, 'run', run)

    def finish(self):
        self.safe(self.save_fixture_events, 'loadfile-final-snapshot-index')
        return super().finish()
