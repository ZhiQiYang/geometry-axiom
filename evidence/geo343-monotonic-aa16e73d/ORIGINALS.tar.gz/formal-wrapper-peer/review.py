from pathlib import Path
import ast,hashlib,json,re
B=Path('/workspace/geo343-monotonic-sort-draft-20261024');O=Path('/workspace/geo343-monotonic-formal-tools-20261024/observer');R=Path('/workspace/geo343-monotonic-work-20261024');OUT=Path(__file__).parent
checks=[]
def ck(v,label):
 checks.append({'check':label,'passed':bool(v)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={'run_formal.py':'ea1ad8a0c0bab9f39f56017bf52355a786be33a1ed7dd04f9852eeb710b942ef','launch_formal.py':'d3ab4469982943a77402abfc085cf633598f2c94139e952764369c83e02ba5a9','run_formal.before-fixed-source.py.txt':'74aa3e5d545a94ebc9b24cb50a3adf689001919908533e9bf67a1a25f133e182','launch_formal.before-fixed-source.py.txt':'076b41eca629fe782164653d12147c912d2de4ca3c4c9bc069236591241b1935'}
for n,h in pins.items():ck(sha(B/n)==h,'pin '+n)
d=(B/'run_formal.py').read_text();l=(B/'launch_formal.py').read_text();old=(B/'run_formal.before-fixed-source.py.txt').read_text()
extra=" need(S=='aa16e73d6e1f2965e0a911581e2a545aaaf66870','fixed reviewed public source')\n need(sha((PUB/'SOURCE_MANIFEST.json').read_bytes())=='1b2216ea8ab7bf123caf36bd36cec251100a3bb66bc45ee4324862455ba3b933','fixed reviewed source manifest')\n"
ck(d.count(extra)==1 and d.replace(extra,'')==old,'only two driver guards')
ck(l.replace(pins['run_formal.py'],pins['run_formal.before-fixed-source.py.txt'])==(B/'launch_formal.before-fixed-source.py.txt').read_text(),'launcher only driver pin')
for n in ['run_formal.py','launch_formal.py']:ast.parse((B/n).read_text());ck(True,'AST '+n)
ck(sha(O/'TOOL_PINS.json')=='5107e0020a8a35213a560e50c79a61e87d4e79254f0ef3078e72a9eafe8093f7','observer manifest')
p=json.loads((O/'TOOL_PINS.json').read_bytes())
for x in p['tools']:ck(sha(O/x['name'])==x['bound_sha256'],'observer exact '+x['name'])
m=B/'source-publication-r2/SOURCE_MANIFEST.json';ck(sha(m)=='1b2216ea8ab7bf123caf36bd36cec251100a3bb66bc45ee4324862455ba3b933','source manifest pin')
mf=json.loads(m.read_bytes());ck(len(mf['files'])==214,'214 frozen source inputs');ck(mf['source_sha']=='aa16e73d6e1f2965e0a911581e2a545aaaf66870','subject SHA')
pub=json.loads((B/'source-publication-r2/RESULT.json').read_bytes());ck(pub['exit']==0 and pub['pushed'] is True and pub['source_sha']==mf['source_sha'],'published source producer true0')
for needle in ["('wood-contact','tests/test_geo261_wood_contact_world.py',13)","('contact-sources','tests/test_geo261_contact_sources.py',15)","('reading-a','tests/test_geo318_reading_a_native.py',7)","100*1024*1024",'fcntl.LOCK_EX|fcntl.LOCK_NB',"'/tmp/g261r3/heavy.lock'",'16*1024*1024',"git('status','--porcelain=v1','--untracked-files=all')==b''","git('rev-parse','HEAD').decode().strip()==S",'manifest[\'files\'].items()',"'tests/_unittest_runner.py'".strip("'"),"timeout=None,check=False",'entry[\'observer_complete\'] is True and observation[\'observer_complete\'] is True',"entry['original_completed'] is True", "entry['original_exit']==row['actual_process_returncode']", "entry['source_sha']==observation['source_sha']==S", "entry['source_files_before']==entry['source_files_after']==manifest['files']", "detail['total']==detail['run']==detail['passed']==count", "['failed','skipped','extra_errors','blocked_by_error','expected_failed']", "detail['import_error'] is None", "len(report['suites'])==3", "fcntl.LOCK_UN"]:ck(needle in d,'driver '+needle)
for needle in ["timeout=None", "len(ends)!=1", "type(primary) is not int", "128-primary", "exit_code=2 if errors else row['actual_process_returncode']", "'PYTHONOPTIMIZE'", "k.startswith(('GIT_'"] :ck(needle in l,'launcher '+needle)
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py').read_text();ck('self.env=env' in cap and 'env=self.env' in cap,'per-suite environment updates reach actual child')
native=(O/'retain_native_inputs.py').read_text();test=(R/'tests/test_geo261_wood_contact_world.py').read_text()
ck("source.name.startswith('contact-monotonic-')" in native and "source.name.endswith('-client.c')" in native,'precise private client match')
ck("names=re.findall" in native and "len(names)!=1" in native and 'selected.add(source.parent/names[0])' in native,'one adjacent actual included product TU captured')
ck('subject.name' in test and 'contact-monotonic-' in test and '-client.c' in test and '-source.c' in test,'actual harness filenames match observer')
for phase in ['fixed','withdrawn','restored']:
 line='#include "contact-monotonic-'+phase+'-source.c"';ck(re.findall(r'^#include "(contact-monotonic-[^"/]+-source\.c)"$',line,re.M)==['contact-monotonic-'+phase+'-source.c'],'regex exact '+phase)
ck("observer.safe(lambda:compiler" in native,'audit error marks observer incomplete without altering compiler')
ck('timeout=300' in (R/'tests/test_geo261_native_kernel.py').read_text(),'original compiler300')
ck('timeout=20' in test,'original wood20')
ck('timeout=30' in (R/'tests/test_geo261_contact_sources.py').read_text(),'original source30')
ck('timeout=20' in (R/'tests/test_geo318_reading_a_native.py').read_text(),'original readingA20')
report={'scope':'Static exact wrapper and observer binding review; no subject or compiler execution','checks':checks,'passed':sum(x['passed']for x in checks),'failed':sum(not x['passed']for x in checks),'source_sha':mf['source_sha'],'pins':pins,'limitations':['Actual future OS exits, compile input snapshots, both observer completion fields and exact suite counts remain required.','Original contact-sources runtime timeout is30 seconds; wood and readingA are20, compiler300. No timeout changed.','Retained included-TU hook proves capture policy only; it does not assert a future compiler read or test pass.','Two exploratory rg reads referenced nonexistent native_build.py/_native_build.py; corrected to actual tests/test_geo261_native_kernel.py, no subject execution occurred.'],'exit':0 if all(x['passed']for x in checks) else 1}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':report['failed'],'exit':report['exit'],'sha256':sha(OUT/'REVIEW.json')}));raise SystemExit(report['exit'])
