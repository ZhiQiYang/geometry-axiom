"""Resume the exact staged four-leaf source after Git's ignored-parent warning."""
import importlib.util,json,shutil,sys,traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('original_source_publisher',HERE/'publish_source.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
OLD=p.OUT;p.OUT=HERE/'source-publication-r2'
ALLOW=['geometry-templates/woodworking/native/contact_world.c','tests/geo343_monotonic_sort_harness.c','tests/run_all.expected.json','tests/test_geo261_wood_contact_world.py']
MANIFEST='fcd4fd328617fc40397dd76f5796cbf7b134fa47592b7a8e60e7b4ca7c9d6808'
def main():
 p.OUT.mkdir(exist_ok=False)
 try:
  p.need(p.sha((HERE/'publish_source.py').read_bytes())=='94ab689850558cdf084de4454333a5a69fb2c5312397fc13501b9bd163aae4db','original frozen publisher')
  old=json.loads((OLD/'RESULT.json').read_bytes());p.need(old['exit']==1 and old['source_sha'] is None and old['pushed'] is False,'retained original publication failure')
  last=old['commands'][-1];p.need(last['exit']==1 and last['argv'][5:8]==['add','--sparse','--'],'only original ignored-parent add failure')
  p.need(p.sha((HERE/'COMPANION_MANIFEST.json').read_bytes())==MANIFEST,'reviewed manifest frozen')
  m=json.loads((HERE/'COMPANION_MANIFEST.json').read_bytes());p.need(sorted(m['files'])==ALLOW,'fixed four-leaf allowlist')
  p.need(p.sha((HERE/'FOUR_LEAF.patch').read_bytes())==p.PATCH,'reviewed whole patch frozen')
  p.report['free_before']=shutil.disk_usage('/workspace').free;p.need(p.report['free_before']>=100*1024*1024,'original100MiB guard')
  p.need(p.git('rev-parse','HEAD',cwd=p.WORK).decode().strip()==p.BASE,'exact uncommitted U HEAD')
  p.need(p.git('symbolic-ref','--short','HEAD',cwd=p.WORK).decode().strip()==p.BRANCH,'own dedicated branch')
  p.need(not p.private('index.lock').exists(),'no active index writer')
  p.need(p.git('ls-remote','--heads','origin','refs/heads/'+p.BRANCH)==b'','remote remains absent')
  p.need(p.git('diff','--name-only',cwd=p.WORK)==b'','all candidate changes already staged')
  p.need(sorted(p.git('diff','--cached','--name-only',cwd=p.WORK).decode().splitlines())==ALLOW,'exact staged four leaves')
  paths=[x[1:] for x in (OLD/'SPARSE_STDIN.txt').read_text().splitlines()]
  p.need(p.private('info/sparse-checkout').read_bytes()==(OLD/'SPARSE_STDIN.txt').read_bytes(),'original private sparse closure')
  files={}
  for name in paths:
   body=(p.WORK/name).read_bytes();expected=(HERE/'candidate'/name).read_bytes() if name in ALLOW else p.git('show',p.BASE+':'+name)
   p.need(body==expected,'closure bytes '+name)
   if name in ALLOW:p.need(p.sha(body)==m['files'][name],'accepted candidate pin '+name)
   p.need(p.git('show',':'+name,cwd=p.WORK)==body,'exact current index blob '+name);files[name]=p.sha(body)
  p.git('diff','--cached','--check',cwd=p.WORK)
  p.git('commit','-m','Skip redundant member sorting while preserving stable face order',cwd=p.WORK)
  source=p.git('rev-parse','HEAD',cwd=p.WORK).decode().strip();p.report['source_sha']=source
  p.need(p.git('show','-s','--format=%P',source,cwd=p.WORK).decode().strip()==p.BASE,'normal U parent');p.clean()
  p.dump(p.OUT/'SOURCE_MANIFEST.json',{'source_sha':source,'source_variant':'fixed','files':files,'closure_bytes':sum((p.WORK/n).stat().st_size for n in paths),'origin_preparation':str(OLD),'note':'Original tracked include closure and all reviewer-bound candidate leaves; original failed add preserved.'})
  p.git('push','origin','HEAD:refs/heads/'+p.BRANCH,cwd=p.WORK)
  p.need(p.git('ls-remote','--heads','origin','refs/heads/'+p.BRANCH,cwd=p.WORK).decode().split()[0]==source,'remote source resolves')
  p.report['pushed']=True;p.report['exit']=0;p.report['free_after']=shutil.disk_usage('/workspace').free
 except BaseException:p.report['error']=traceback.format_exc();p.report['exit']=1
 finally:p.dump(p.OUT/'RESULT.json',p.report);print(json.dumps({k:p.report.get(k)for k in ['source_sha','pushed','exit','error']}),flush=True)
 return p.report['exit']
if __name__=='__main__':sys.exit(main())
