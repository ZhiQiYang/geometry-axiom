"""Collect original terminal source/publication/tests without rewriting receipts."""
from pathlib import Path
import datetime,hashlib,io,json,shutil,tarfile
S='aa16e73d6e1f2965e0a911581e2a545aaaf66870';HERE=Path(__file__).resolve().parent
R=Path('/workspace/geo343-monotonic-formal-20261024');L=Path('/workspace/geo343-monotonic-formal-launch-20261024');O=Path('/workspace/geo343-monotonic-evidence-package-20261024')
roots={'formal':R,'outer':L,'source-and-tools':HERE,'bound-observer':Path('/workspace/geo343-monotonic-formal-tools-20261024/observer'),'product-companion-publisher-peer':Path('/workspace/geo343-monotonic-independent-peer-20261024'),'formal-wrapper-peer':Path('/workspace/geo343-formal-peer-specials-20261024')}
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def read(p):return json.loads(p.read_bytes())
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
 need(not O.exists(),'fresh original package');r=read(R/'RESULT.json');outer=read(L/'RESULT.json');actual=read(HERE/'ACTUAL_SUMMARY.json')
 need(r['source_sha']==outer['source_sha']==actual['source_sha']==S,'same actual source');need(r['exit']==outer['exit']==outer['primary_exit']==outer['reaper_exit']==0 and r['source_clean_after'],'real terminal primary/reaper/driver and clean source')
 need(shutil.disk_usage('/workspace').free>=50*1024*1024,'environment packaging guard');O.mkdir();items={}
 for prefix,root in roots.items():
  need(root.is_dir(),'all original roots')
  for p in sorted(root.rglob('*')):
   if p.is_file():
    need(not p.is_symlink(),'no source symlinks');name=prefix+'/'+str(p.relative_to(root));need(name not in items,'unique member');items[name]=p
 for name in ['GEO343_MONOTONIC_HARNESS_ORACLE_STATIC_PEER.json','review_geo343_monotonic_oracles.py','CONTACT_SORT_FASTPATH_ADVERSARIAL_PLAN.md']:
  p=Path('/workspace/train337-canvas-peer-resume')/name;need(p.is_file(),'independent oracle peer');items['independent-oracle/'+name]=p
 for name,path in [('capture.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),('reap_children.py','/workspace/geo261-environment/reap_children.py')]:items['original-tools/'+name]=Path(path)
 need(all(p.read_bytes()[:4]!=b'\x7fELF' for p in items.values()),'source/metadata/streams only; original NativeBuild cleanup unchanged')
 archive=O/'ORIGINALS.tar.gz';rows=[]
 with tarfile.open(archive,'w:gz',compresslevel=6)as tf:
  for name,p in sorted(items.items()):
   raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw));rows.append({'member':name,'source':str(p),'bytes':len(raw),'sha256':sha(raw)})
 with tarfile.open(archive,'r:gz')as tf:
  members=tf.getmembers();need(len(members)==len(rows),'roundtrip count')
  for row,member in zip(rows,members):
   raw=tf.extractfile(member).read();need(member.name==row['member'] and sha(raw)==row['sha256'] and raw==Path(row['source']).read_bytes(),'original byte roundtrip '+row['member'])
 index={'source_sha':S,'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'member_count':len(rows),'files':rows};dump(O/'RAW_INDEX.json',index)
 summary={k:v for k,v in index.items()if k!='files'};summary.update(original_exit=0,all_original_bytes_roundtrip=True,original_bytes=sum(x['bytes']for x in rows),actual=actual,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['Original35-method targeted acceptance, not final full native/browser/ledger/architecture or O2 wall performance.','Original native text-mode output is retained as decoded text; binary Bridge/run streams are labelled separately.','Whole and fine variants were actual compiler inputs retained before launch; original NativeBuild cleanup remains unchanged; ELF payloads are not archived.','Original publication R1 ignored-parent add exit1 is retained; R2 normal commit/push439 child commands exit0.'])
 dump(O/'SUMMARY.json',summary);print(json.dumps({k:summary[k]for k in ['source_sha','member_count','archive_bytes','archive_sha256']}))
if __name__=='__main__':main()
