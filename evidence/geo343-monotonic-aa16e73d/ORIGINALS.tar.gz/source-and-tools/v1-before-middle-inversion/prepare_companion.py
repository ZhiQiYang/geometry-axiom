from pathlib import Path
import ast,difflib,hashlib,json
O=Path('/workspace/geo343-monotonic-sort-draft-20261024')
m=json.loads((O/'MANIFEST.json').read_bytes());block=m['whole_withdrawal']['after']
leaf='tests/test_geo261_wood_contact_world.py';before=(O/'before'/leaf).read_bytes();s=before.decode()
anchor='    size_t members=count-first;\n    for(size_t i=first;i<count;++i)index->sorted[i]=i;\n'
constant='\nMONOTONIC_SORT_BLOCK = '+repr(block)+'\nMONOTONIC_SORT_ANCHOR = '+repr(anchor)+'\n\n'
assert s.count('\nclass WoodContactWorld(unittest.TestCase):')==1
s=s.replace('\nclass WoodContactWorld(unittest.TestCase):',constant+'class WoodContactWorld(unittest.TestCase):')
addition='''
    def monotonic_executable(self,source,label):
        build=native()
        anchor="static uint64_t contact_order(const WoodContactWorld *world,const ContactOrderIndex *index,uint32_t id)\\n{"
        counted="static size_t geo_test_sort_order_calls;\\n"+anchor+"\\n    ++geo_test_sort_order_calls;"
        self.assertEqual(1,source.count(anchor),"One original contact_order definition")
        instrumented=source.replace(anchor,counted)
        self.assertEqual(source,instrumented.replace(counted,anchor),"Counter removal preserves actual product bytes")
        subject=build.woodworking/("contact-monotonic-"+label+"-source.c")
        subject.write_text(instrumented,encoding="utf-8")
        harness=(ROOT/"tests/geo343_monotonic_sort_harness.c").read_text(encoding="utf-8")
        include='#include "contact-monotonic-subject.c"'
        self.assertEqual(1,harness.count(include))
        client=build.woodworking/("contact-monotonic-"+label+"-client.c")
        client.write_text(harness.replace(include,'#include "'+subject.name+'"'),encoding="utf-8")
        obj=build.compile(client,"contact-monotonic-"+label+"-client")
        return build.link("contact-monotonic-"+label+"-exe",
            [obj,build.wood_contacts_object,build.wood_supports_object,*build.kernel_objects()])

    def test_monotonic_sort_preserves_full_fields_and_linear_sorted_lookup_work(self):
        source=(native().woodworking/"contact_world.c").read_text(encoding="utf-8")
        self.assertEqual(1,source.count(MONOTONIC_SORT_BLOCK))
        self.assertEqual(1,source.count(MONOTONIC_SORT_ANCHOR))
        withdrawn=source.replace(MONOTONIC_SORT_BLOCK,"")
        restored=withdrawn.replace(MONOTONIC_SORT_ANCHOR,MONOTONIC_SORT_ANCHOR+MONOTONIC_SORT_BLOCK)
        self.assertEqual(source,restored,"Complete sort optimization restoration is exact")
        cases=("sorted","reverse","ties","all-ties","prefix","no-member","one-member","last-inversion","full-uint64")
        fixed=None
        for phase,variant,expected in (("fixed",source,0),("withdrawn",withdrawn,1),("restored",restored,0)):
            with self.subTest(whole_phase=phase):
                executable=self.monotonic_executable(variant,phase)
                if phase=="fixed":fixed=executable
                for case in cases:
                    result=self.case(case,executable,phase=phase,control="monotonic-whole")
                    self.assertEqual(0,result.returncode,result.stderr)
                result=self.case("work",executable,phase=phase,control="monotonic-whole",
                    assertion="monotonic-linear-order-lookups")
                print("monotonic-whole phase="+phase+" "+result.stdout,end="")
                self.assertEqual(expected,result.returncode,result.stderr)
                if expected:self.assertIn("ASSERT:monotonic-linear-order-lookups",result.stderr)
        self.assertIsNotNone(fixed)
        controls=(
            ("missed-inversion","if(previous>current){ordered=false;break;}","if(previous>current){ordered=true;break;}","last-inversion","monotonic-last-inversion-full-fields"),
            ("missed-last-face","for(size_t i=first+1;i<count;++i){","for(size_t i=first+1;i+1<count;++i){","last-inversion","monotonic-last-inversion-full-fields"),
            ("truncated-previous","uint64_t previous=contact_order(world,orders,out[first].timber_id);","uint32_t previous=contact_order(world,orders,out[first].timber_id);","full-uint64","monotonic-full-uint64-fields"),
        )
        for label,before,after,case,marker in controls:
            with self.subTest(monotonic_control=label):
                baseline=self.case(case,fixed,phase="baseline",control=label,assertion=marker)
                self.assertEqual(0,baseline.returncode,baseline.stderr)
                self.assertEqual(1,source.count(before),"One actual monotonic guard")
                executable=self.monotonic_executable(source.replace(before,after),label)
                result=self.case(case,executable,phase="mutant",control=label,assertion=marker)
                self.assertEqual(1,result.returncode,result.stderr);self.assertIn("ASSERT:"+marker,result.stderr)
                result=self.case(case,fixed,phase="restored",control=label,assertion=marker)
                self.assertEqual(0,result.returncode,result.stderr)
'''
target='    def extension_transaction(self, executable):'
assert s.count(target)==1;s=s.replace(target,addition+'\n'+target);ast.parse(s)
p=O/'candidate'/leaf;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
harness='tests/geo343_monotonic_sort_harness.c';(O/'candidate'/harness).write_bytes((O/'monotonic_harness.c').read_bytes())
e='tests/run_all.expected.json';old=(O/'before'/e).read_text();key='"py:test_geo261_wood_contact_world": {';a=old.index(key);b=old.index('    }',a);chunk=old[a:b];assert chunk.count('"count": 12')==1
new=old[:a]+chunk.replace('"count": 12','"count": 13')+old[b:];(O/'candidate'/e).write_text(new)
patches=[]
for path in [m['product_leaf'],leaf,harness,e]:
 before=(O/'before'/path).read_text() if (O/'before'/path).exists() else ''
 after=(O/'candidate'/path).read_text()
 patches.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path if before else '/dev/null',tofile='b/'+path)))
patch=''.join(patches);(O/'FOUR_LEAF.patch').write_text(patch)
old_ast=ast.parse((O/'before'/leaf).read_text());new_ast=ast.parse(s)
old_defs={n.name:ast.dump(n,include_attributes=False)for n in ast.walk(old_ast)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
new_defs={n.name:ast.dump(n,include_attributes=False)for n in ast.walk(new_ast)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert all(new_defs[k]==v for k,v in old_defs.items())
old_controls=next(n for n in old_ast.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='CONTROLS')
new_controls=next(n for n in new_ast.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='CONTROLS')
assert ast.dump(old_controls)==ast.dump(new_controls)
assert len([n for n in ast.walk(new_ast)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')])==13
sha=lambda b:hashlib.sha256(b).hexdigest()
summary={'source_sha':m['source_sha'],'four_leaf_patch_sha256':sha(patch.encode()),'C_executed':False,'original12_method_ASTs_preserved':True,'original_all_definitions_preserved':len(old_defs),'original_controls_AST_exact':True,'new_test_methods':1,'new_semantic_controls':3,'whole_optimization_expected_exits':[0,1,0],'original_case_timeout_seconds':20,'registry_only_change':'py:test_geo261_wood_contact_world count12->13','files':{str(p.relative_to(O/'candidate')):sha(p.read_bytes())for p in (O/'candidate').rglob('*')if p.is_file()}}
(O/'COMPANION_MANIFEST.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))

