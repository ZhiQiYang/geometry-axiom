"""Bind external audit tools to the three original contact suites; no C."""
from pathlib import Path
import hashlib,json,difflib
OLD=Path('/workspace/geo300-capacity512-h-pipe-capture-v2-20261024');NEW=Path('/workspace/geo343-monotonic-formal-tools-20261024/observer')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((OLD/'TOOL_PINS.json').read_bytes())=='c922d920d196103a4a308f4636c3df59da8954b6fd8777431262d4d181417b76'
pins=json.loads((OLD/'TOOL_PINS.json').read_bytes());NEW.mkdir(parents=True,exist_ok=False);changes=[]
for name in ['observe_bridge_bytes.py','retain_native_inputs.py','retain_loadfile_inputs.py','run_observed_original.py']:
 body=(OLD/name).read_bytes();assert sha(body)==pins['files'][name];s=body.decode()
 if name=='run_observed_original.py':
  before="'tests/test_geo261_timber_capacity.py','tests/test_geo261_timber_capacity_host.py'"
  after="'tests/test_geo261_wood_contact_world.py','tests/test_geo261_contact_sources.py','tests/test_geo318_reading_a_native.py'"
  assert s.count(before)==1;s=s.replace(before,after)
 elif name=='retain_native_inputs.py':
  before="        row={'event':'subprocess.Popen-before-launch','argv':serial(argv),'cwd':serial(cwd),"
  after='''        # Retain the actual counted/withdrawn TU included by each new client,
        # before the compiler reads it and before NativeBuild cleanup.
        for source in inputs:
            if source.is_relative_to(private_tmp) and source.name.startswith('contact-monotonic-') and source.name.endswith('-client.c'):
                import re
                names=re.findall(r'^#include "(contact-monotonic-[^"/]+-source\\.c)"$',source.read_text(),re.M)
                if len(names)!=1:raise ValueError('One actual monotonic included subject required')
                selected.add(source.parent/names[0]);roles.append('actual-monotonic-included-TU-at-compile')
'''+before
  assert s.count(before)==1;s=s.replace(before,after)
 (NEW/name).write_text(s)
 changes.append({'name':name,'original_sha256':sha(body),'bound_sha256':sha(s.encode())})
 if s.encode()!=body:(NEW/(name+'.diff')).write_text(''.join(difflib.unified_diff(body.decode().splitlines(True),s.splitlines(True),fromfile='original/'+name,tofile='bound/'+name)))
(NEW/'TOOL_PINS.json').write_text(json.dumps({'original_toolpins':sha((OLD/'TOOL_PINS.json').read_bytes()),'tools':changes},indent=2)+'\n')
print(json.dumps(changes))
