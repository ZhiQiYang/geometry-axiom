"""Read terminal original receipts; no test rerun or synthetic runtime claim."""
from pathlib import Path
import hashlib,json,re
HERE=Path(__file__).resolve().parent;OUT=Path('/workspace/geo343-monotonic-formal-20261024');S='aa16e73d6e1f2965e0a911581e2a545aaaf66870'
def read(p):return json.loads(p.read_bytes())
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
result=read(OUT/'RESULT.json');need(result['exit']==0 and result['source_sha']==S and result['source_clean_after'],'terminal fixed source')
outer=read(Path('/workspace/geo343-monotonic-formal-launch-20261024/RESULT.json'));need(outer['exit']==outer['primary_exit']==outer['reaper_exit']==0,'original outer exits')
summary={'source_sha':S,'original_outer_exit':0,'original_driver_exit':0,'suites':[],'work':[],'controls':[],'included_sources':[],'new_wall_measurement':False}
for suite in result['suites']:
 label=suite['label'];base=OUT/label;count=suite['expected_methods'];runner=read(base/'runner.json')
 need(suite['actual_exit']==0 and suite['passed'] and runner['total']==runner['run']==runner['passed']==count,'suite methods')
 need(all(runner.get(k,0)==0 for k in ['skipped','failed','extra_errors','blocked_by_error','expected_failed']),'no skipped/red methods')
 cleanups=read(base/'observed/native-inputs/cleanup-retention.json');logs=[]
 for c in cleanups:
  p=Path(c['build_log']['retained']);need(sha(p.read_bytes())==c['build_log']['sha256'],'original build log pin');logs+=read(p)
 need(logs and all(c['exit']==0 for c in logs),'every actual compile/link succeeded')
 summary['suites'].append({'label':label,'methods':count,'skip':0,'actual_exit':0,'compile_link_commands':len(logs),'compile_link_all_exit_0':True})
rows=[json.loads(line)for line in (OUT/'wood-contact/native-executions.jsonl').read_text().splitlines()]
rows=[r for r in rows if r['test'].endswith('test_monotonic_sort_preserves_full_fields_and_linear_sorted_lookup_work')]
need(len(rows)==45,'30 original sequence runs plus3work plus12controls')
for r in rows:need(r['source_sha']==S,'actual native source pin')
for phase,exit_code,calls in [('fixed',0,128),('withdrawn',1,896),('restored',0,128)]:
 found=[r for r in rows if r['control']=='monotonic-whole' and r['case']=='work' and r['phase']==phase];need(len(found)==1,'one original whole work phase');r=found[0]
 need(r['actual_exit']==exit_code and r['stdout']=='CASE work faces=128 first=2 order_calls='+str(calls)+'\n','actual integer call samples')
 need(r['stderr']==('ASSERT:monotonic-linear-order-lookups\n' if exit_code else ''),'normal exact whole assertion')
 summary['work'].append({k:r[k]for k in ['phase','actual_exit','stdout','stderr','executable_sha256','command']})
for label,marker in [('missed-inversion','monotonic-last-inversion-full-fields'),('missed-last-face','monotonic-last-inversion-full-fields'),('truncated-previous','monotonic-full-uint64-fields'),('missed-previous-update','monotonic-middle-inversion-full-fields')]:
 selected=[r for r in rows if r['control']==label];need([r['phase']for r in selected]==['baseline','mutant','restored'],'original control phase order')
 need([r['actual_exit']for r in selected]==[0,1,0],'normal native control exits');need(selected[1]['stderr']=='ASSERT:'+marker+'\n','exact named assertion, not compiler/crash/timeout')
 summary['controls'].append({'label':label,'assertion':marker,'phases':[{k:r[k]for k in ['phase','actual_exit','stdout','stderr','executable_sha256','command']}for r in selected]})
for r in rows:
 if r['control']=='monotonic-whole' and r['case']!='work':need(r['actual_exit']==0 and r['stderr']=='','original semantics still pass without optimization')
snapshots=read(OUT/'wood-contact/observed/native-inputs/compiler-input-snapshots.json')
included=[r for r in snapshots if 'actual-monotonic-included-TU-at-compile' in r['roles']];need(len(included)==7,'seven real independently compiled variant clients')
for row in included:
 sources=[x for x in row['inputs'] if x['original'].endswith('-source.c')];need(len(sources)==1,'one actual included variant')
 item=sources[0];need(sha(Path(item['retained']).read_bytes())==item['sha256'],'actual retained included source bytes')
 summary['included_sources'].append(item)
summary['total_methods']=sum(x['methods']for x in summary['suites']);summary['compile_link_total']=sum(x['compile_link_commands']for x in summary['suites']);summary['semantic_whole_cases']=30;summary['assessment_exit']=0
(HERE/'ACTUAL_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'methods':summary['total_methods'],'compile_link':summary['compile_link_total'],'work_calls':[128,896,128],'work_exits':[0,1,0],'fine_controls':4,'exit':0}))
