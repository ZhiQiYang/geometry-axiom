# #323 兩項反證修正 v1 靜態對抗審查

範圍為未套用候選 patch `bd56a01a90ab13a324467b79bc92f534522342c8d8bf1566a85021c0821b72b4`，基底 `b2445b5a270d60fdf48b07f6edddbe91266d8aa2`。未發現這個基底上的可確立靜態阻擋；尚未編譯、執行或證成修正有效。

原兩紅是失準的反證操作：舊 H 廣泛撤回會先觸 footprint 邊斷言；舊 footprint-order 注入把 header 指標傳給完整 definition API 而編譯失敗。候選保留原 placement 精確斷言，改在真第二 consumer 的 PLACEMENT/id3 typed getter，讀取同 provider／完整 key／VALID 原節點值並省略當前 consumer 邊，其餘路徑仍原讀取器。沒有構造假 payload 或改 memo／private graph active。Probe 保存舊旗標並在成功／普通失敗前恢復。

footprint-order 只把注入 API 改成符合現有 header 型別的 API，仍提前讀取同一 DEFINITION_REQUIRED source；原五個來源的順序、種類與每個 consumer 判定未變。13 方法及其餘 12 方法 AST 不變，原 H 三站 guard 保留，精確單 ASSERT 與逐 phase metadata 反而更明確。編譯失敗仍是失敗，不能當 killed。

採用前須實跑 baseline／mutant／restored，保留兩個原紅，確認負控是原具名斷言而非工具紅。若另套 contact memo v2，contact hit 轉走 H placement_depend，不經 W getter；因此本 v1 peer 不適用合併候選。撤同一邏輯邊的 W／H 兩條替代路徑可以另設控制，但不能宣稱各單站必要性已證，必須另列每個新 caller／key／edge kind／ordered-facts 的具名反證。

本審查未修改 owner 工作樹、產品或測試、未執行測試／效能量測，也不宣稱已達 ≤1.3 或已解除 source-call 比率紅燈。
