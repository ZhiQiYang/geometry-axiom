# #323 contact 三欄 memo v2 獨立對抗靜審

未找到可確立的靜態產品語意錯誤；目前只接受候選的靜態方向，不能稱動態驗收通過。候選尚未套用，未編譯、未跑任何原測試、profile 或 benchmark，也沒有修改 owner 的檔案、Git index 或分支。

受審 patch SHA256：`5a25dfe85440c0cee6dd44de3f3af6a38340e9fb9d98b88942583542de4ff152`。原基底 `5c29eba30a40f20ea5c7eb8dc139e5788235d3b6`；新同步來源 `b2445b5a270d60fdf48b07f6edddbe91266d8aa2`。兩個候選 C 檔及八個相關 context/test 檔在這兩個 SHA 逐位元組相同。完整原 Git blob、read-only argv／exit／stdout hash 已存 inputs 與 CHECKS.json。52 項機械檢查全部成立，工具本次退出碼 0；這些是靜態檢查數，不是專案測試通過數。

## 邊界逐項核對

- **逐 consumer 依賴與順序。** 新 contact hit 和原 full-anchor hit 都呼叫同一個 helper；原 APP_SOURCE_WOOD_DEFINITION／WOOD_DEFINITION_PLACEMENT／DEFINITION_REQUIRED 操作保留唯一原文字 site，執行於回傳 memo 之前。`geo_eval_source` 原先先登記 edge 再取已有效值；成功 decode 後使用 `geo_eval_depend` 保留同一 current consumer/source/kind 的登記。原 broad `if(geo_eval_depend(ctx->sources,` 仍恰三處，各個既有精確 mutation anchor 仍恰一處。v1 的重複 anchor 問題在 v2 已關閉。
- **有效期與失效。** 新 memo 的 `contact_id` 獨立於 full anchor 的 id。只有完整原 decoder 成功才寫值、id、valid；換 slot 的 canonical member 不會因 full anchor 曾 warm 而誤命中 contact。成功讀後，原 slot/id 改變時清 anchor、footprint 的路徑完全保留。新欄位位於原整體 `member_reads` 清零範圍；candidate evaluate／reopen／discard 及 reference_sources_begin_candidate 在重建 graph 前釋放舊 evaluation state。
- **不能忽略的有效期前提。** `geo_eval_depend` 本身不重驗 node 的 VALID／FAILED 狀態；此 memo 的正確性依賴同一不可變 evaluation generation 內曾成功解碼，及上述真實 owner 重建／dispose 邊界。沒有把「直接 reset K graph 卻私自保留並重註冊舊 H memo」冒成支援的生命週期，也沒有聲稱一個裸 depend 可以替代任意 reader。sealed 狀態及超容量 index 明確走原三欄 reader（仍驗整份序列化格式），沒有在 sealed graph 新登記 edge。
- **ordered facts 與 raw prefix。** 整個 reference_contact_facts 與原 bytes 比較，唯一差別是呼叫新 reader。每次原 placed/exclude 判斷、placement/order/length_direction 來源、host 不符、footprint invalidation、失敗前 raw prefix complete 與 pending 標誌、原 pose 讀取／依賴順序全部未變；沒有把整份 contact query 或排序結果 cache。
- **失敗讀取。** 首次 decoder 失敗不寫新 memo；命中後依賴失敗先 return false，不寫 caller 的 out，原 caller 仍 flush 已訪問 prefix。這只證源碼守門，尚未得到此候選的新具名錯誤反證。

## 採用前必補的動態證據

1. 原 `ANCHOR_ID_KEY` 控制只撤 full-anchor id，沒有撤新 `contact_id`。請用現有 `mr_swap_storage` 的真 canonical provider／自然 warm 場景，單獨撤新 contact key，保原 order／placement／footprint assertion，證明新守門有效。不要寫 memo bytes 製造測試狀態。
2. 原 anchor-edge／anchor-kind 控制只執行 cache-anchor。移到共用 helper 可保原控制仍可用，但不等於已證新 contact caller。應具名以原 cache-footprint 的五個 source/kind/order 順序，對新 caller 做省 edge 與錯 kind 的撤回／恢復；只數 unique anchor 不足。
3. 新 memo 的 failed-read、sealed bypass、dispose/reset 與 prefix flush 仍需候選實跑，既有 W contact_sources 的 reset 案不等於 H memo 已受同一反證。正反例若出現其他 assertion，保原結果再分類，不能算預期反證。
4. 先在同步來源 S 跑根代理已排的三套原裁判與原性能基準，再決定是否採用候選。舊 gprof 的 call count／樣本不能證明此 S 或候選已達 N64 fix/main ≤ 1.3。即使採用後三套綠，仍不取代最終 SHA 的完整 native、八套、PF3、A/B/C、性能／profile、帳本與架構清單。

`CHECKS.json` SHA256：`1fc9724b72a224396a89373564c688a030e72df224e2e341d54701701c3e2b2e`。原 v1、v2 候選都未改動，本審查只新增獨立證據檔。
