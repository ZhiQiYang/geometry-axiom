"""Build an unapplied four-file candidate; no compilation or subject execution."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/g261-next323')
PREP = Path('/tmp/geo323-merge-20261023')
OUT = PREP / 'combined-memo-controls-candidate-v1'
if OUT.exists():
    raise RuntimeError('Preserve immutable candidate')


def change(source, before, after):
    if source.count(before) != 1:
        raise RuntimeError('Expected one exact anchor: ' + repr(before))
    return source.replace(before, after)


paths = ('geometry-core/references.inc',
         'geometry-app/native/reference_sources.inc',
         'tests/test_geo261_load_residual.py',
         'tests/geo261_load_residual_harness.c')
original = {p: (ROOT / p).read_bytes() for p in paths}
candidate = {
    p: (PREP / 'contact-three-field-memo-candidate-v2/candidate' / p).read_bytes()
    for p in paths[:2]
}
py = (PREP / 'test-control-refresh-candidate-v1/candidate' / paths[2]).read_text()
c = (PREP / 'test-control-refresh-candidate-v1/candidate' / paths[3]).read_text()

# Withdraw one semantic edge at its two alternative source boundaries.  This
# deliberately broken consumer remains fully decoded; it never edits memo or
# graph state and never synthesizes a canonical source value.
py = change(py, '        if source_change:\n', '''        if not placement_dependency:
            assert sources.count(ANCHOR_DEPEND) == 1, "Placement hit boundary must hit exactly once"
            sources = sources.replace(ANCHOR_DEPEND,
                "(residual_second_consumer&&id==3?GEO_SOURCE_OK:" + ANCHOR_DEPEND + ")")
        if source_change:
''')
py = change(py, "H_CACHE_CONTROLS = (\n", '''CONTACT_HIT = '    if(ctx->member_reads[i].contact_valid&&ctx->member_reads[i].contact_id==id){'
H_CACHE_CONTROLS = (
    ('contact-edge', 'cache-contact', 'contact-cache-second-consumer-edge-and-order', ANCHOR_DEPEND,
     '(residual_second_consumer?GEO_SOURCE_OK:' + ANCHOR_DEPEND + ')'),
    ('contact-kind', 'cache-contact', 'contact-cache-second-consumer-edge-and-order', ANCHOR_DEPEND,
     ANCHOR_DEPEND.replace('GEO_DEPENDENCY_DEFINITION_REQUIRED', '(residual_second_consumer?GEO_DEPENDENCY_EVALUATE_BEFORE:GEO_DEPENDENCY_DEFINITION_REQUIRED)')),
    ('contact-order', 'cache-contact', 'contact-cache-second-consumer-edge-and-order', CONTACT_HIT,
     CONTACT_HIT + '\\n        if(residual_second_consumer){GeoSourceRef pose={APP_SOURCE_MEMBER_POSE,&id,sizeof id};'
     'if(geo_eval_depend(ctx->sources,pose,GEO_DEPENDENCY_VALUE_REQUIRED)!=GEO_SOURCE_OK)return false;}'),
''')
py = change(py, 'ANCHOR_ID_KEY = "&&ctx->member_reads[i].id==id"\n',
            'ANCHOR_ID_KEY = "&&ctx->member_reads[i].id==id"\nCONTACT_ID_KEY = "&&ctx->member_reads[i].contact_id==id"\n')
py = change(py,
            'for case in ("cache-definition", "cache-anchor", "cache-footprint", "cache-pose", "cache-pose-kind"):',
            'for case in ("cache-definition", "cache-anchor", "cache-contact", "cache-footprint", "cache-pose", "cache-pose-kind"):')
old = '''        print("Member cache control " + control + ": exit=1; " + result.stderr.strip(), flush=True)
        self.passes(case, phase="restored", control=control)

    def test_member_anchor_miss_invalidates_naturally_warmed_footprint(self):
'''
new = '''        print("Member cache control " + control + ": exit=1; " + result.stderr.strip(), flush=True)
        self.passes(case, phase="restored", control=control)

        # A separate contact cache key must protect the same natural slot
        # permutation.  This is not inferred from the full-anchor guard above.
        case, control, marker = "member-anchor-miss", "contact-id-key", "member-anchor-miss-invalidates-footprint"
        self.passes(case, phase="baseline", control=control)
        exe = self.compile(control, source_change=(CONTACT_ID_KEY, ""))
        result = self.case(case, exe, phase="mutant", control=control, expected_assertion=marker)
        self.assertEqual(1, result.returncode, result.stdout + result.stderr)
        self.assertIn("ASSERT:" + marker + " ", result.stderr)
        self.assertEqual(1, result.stderr.count("ASSERT:"), result.stderr)
        print("Member cache control " + control + ": exit=1; " + result.stderr.strip(), flush=True)
        self.passes(case, phase="restored", control=control)

    def test_member_anchor_miss_invalidates_naturally_warmed_footprint(self):
'''
py = change(py, old, new)
py = change(py, 'control, marker = "placement-source-second-consumer-edge", "cross-consumer-placement-edge-missing"',
            'control, marker = "placement-second-consumer-reader-and-hit-edge", "cross-consumer-placement-edge-missing"')

# The new case uses the original mode-3 facts, ordered five-source oracle,
# prefix/node/world preservation, repeats and sealed-read checks.  Only the
# label and explicit natural contact-memo precondition are new.
c = change(c,
    '(!strcmp(name,"cache-footprint")||!strcmp(name,"cache-footprint-source"))?3:4;',
    '(!strcmp(name,"cache-contact")||!strcmp(name,"cache-footprint")||!strcmp(name,"cache-footprint-source"))?3:4;')
c = change(c, '    /* The graph already owns the canonical definition and BOX.',
'''    if(!strcmp(name,"cache-contact"))
        REQUIRE("contact-cache-naturally-warmed",ctx->member_reads[0].contact_valid&&ctx->member_reads[0].contact_id==41);
    /* The graph already owns the canonical definition and BOX.''')
c = change(c,
    'mode==3?"footprint-cache-second-consumer-edge-and-order":!strcmp(name,"cache-pose-kind")?',
    'mode==3?(!strcmp(name,"cache-contact")?"contact-cache-second-consumer-edge-and-order":"footprint-cache-second-consumer-edge-and-order"):!strcmp(name,"cache-pose-kind")?')

candidate[paths[2]] = py.encode()
candidate[paths[3]] = c.encode()
ast.parse(py)
methods = lambda raw: [n.name for n in ast.walk(ast.parse(raw))
                       if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
assert len(methods(py)) == 13 and methods(py) == methods(original[paths[2]])
assert candidate[paths[1]].count(b'if(geo_eval_depend(ctx->sources,') == 3
assert candidate[paths[1]].count(b'&&ctx->member_reads[i].contact_id==id') == 1

OUT.mkdir()
patch = ''
files = []
for rel, raw in candidate.items():
    p = OUT / 'candidate' / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)
    patch += ''.join(difflib.unified_diff(original[rel].decode().splitlines(keepends=True),
        raw.decode().splitlines(keepends=True), fromfile='a/' + rel, tofile='b/' + rel))
    files.append({'path': rel, 'original_sha256': hashlib.sha256(original[rel]).hexdigest(),
                  'candidate_sha256': hashlib.sha256(raw).hexdigest()})
(OUT / 'candidate.patch').write_text(patch)
manifest = {
    'schema': 'geo323-external-unapplied-combined-memo-controls/1',
    'base_sha': 'b2445b5a270d60fdf48b07f6edddbe91266d8aa2',
    'applied': False, 'compiled': False, 'tested': False, 'benchmarked': False,
    'product_candidate_v2_bytes_unchanged': True,
    'performance_gain_claimed': False,
    'reason': 'Current original profile source64/source32 = 6.154996228372071 > 4.5; each lightweight contact read takes one geo_eval_source. Cold miss/hit savings and N32 time are not yet measured.',
    'thresholds_expected_ledger_architecture_or_axiom_changed': False,
    'original_test_method_list_preserved': methods(py) == methods(original[paths[2]]),
    'original_test_methods': methods(py),
    'new_independent_controls': ['contact-edge', 'contact-kind', 'contact-order', 'contact-id-key'],
    'calibrated_existing_controls': {
        'footprint-order': 'Use typed definition_header injection, same original early-read fault and exact ordered-edge oracle.',
        'cross-consumer': 'Same exact placement ASSERT; withdraw placement id3/second-consumer edge at both W miss and H hit alternative routes. This joint semantic-boundary test does not prove each site individually necessary.'},
    'original_reds_retained': ['/tmp/geo323-baseline-b2445b5a-three', '/tmp/geo323-baseline-b2445b5a-v3-r1'],
    'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(), 'files': files,
    'dynamic_pending': ['All four new named controls require native normal assertion 0/1/0',
        'Original load13/host22/contact15 including lifecycle/failed/sealed cases',
        'Original v3 full protocol on adopted final source; no resampling or threshold changes'],
}
(OUT / 'CANDIDATE.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'out': str(OUT), 'patch_sha256': manifest['patch_sha256'], 'method_count': len(methods(py))}))
