"""Append a truthful baseline handoff; never change or rerun original judges."""
import datetime
import hashlib
import json
import re
from pathlib import Path

PREP = Path('/tmp/geo323-merge-20261023')
ROOT = Path('/tmp/geo323-baseline-b2445b5a-v3-r1')
S = 'b2445b5a270d60fdf48b07f6edddbe91266d8aa2'
record = json.loads((ROOT / 'receipt.json').read_text())
assert record['source_sha'] == S
names = ('prepare', 'build', 'compare', 'perf', 'profile', 'required-eight', 'pf3', 'native')
assert set(record['stages']) == set(names)
assert all(record['stages'][n]['ended_utc'] and record['stages'][n]['execution_exit'] is not None for n in names)
assert all(record['stages'][n]['source_before'] == record['stages'][n]['source_after'] == {'head': S, 'status': ''} for n in names)
native = ROOT / 'invocations/2026-10-23T143038.6637150000/commands/000003'
command = json.loads((native / 'result.json').read_text())
raw = (native / 'stdout.bin').read_bytes()
assert command['stdout_sha256'] == hashlib.sha256(raw).hexdigest()
assert command['stdout_bytes'] == len(raw)
assert command['source_sha'] == command['acceptance_sha'] == S
assert command['command'][-3:] == ['-B', 'tests/run_all.py', '--build']
assert '--only' not in command['command']
text = raw.decode('utf-8')
totals, failed_rows, skipped_rows = [], [], []
for line in text.splitlines():
    if line.startswith('合計'):
        totals.append(line)
    fields = line.split()
    if len(fields) >= 6 and re.match(r'^[a-z-]+:[A-Za-z0-9_-]+$', fields[0]):
        if fields[3] == 'FAIL' or (fields[3].isdigit() and int(fields[3])):
            failed_rows.append(line)
        if fields[4].isdigit() and int(fields[4]):
            skipped_rows.append(line)
assert len(totals) == 1
pf3 = json.loads((ROOT / 'evidence/pf3/summary.json').read_text())
three = json.loads(Path('/tmp/geo323-baseline-b2445b5a-three/receipt.json').read_text())
remaining = json.loads(Path('/tmp/geo323-baseline-b2445b5a-v3-remaining-launch/PROGRESS.json').read_text())
assert [r['stage'] for r in remaining['completed_stages']] == ['required-eight', 'pf3', 'native']
summary = {
    'schema': 'geo323-completed-baseline-handoff/1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_sha': S, 'base': record['base'], 'main': record['main'],
    'kind': '原收據的逐項索引；不取代原判官，也不改判原紅燈',
    'product_or_tests_changed_after_baseline': False,
    'candidate_applied': False, 'new_test_or_benchmark_started': False,
    'user_stage_stop_obeyed': True,
    'stage_matrix': {n: record['stages'][n] for n in names},
    'original_quantitative_targets': record['quantitative_targets'],
    'all_required_stages_completed': record['all_required_stages_completed'],
    'original_wrapper_exit': record['wrapper_exit'],
    'original_full_acceptance_passed': record['full_acceptance_passed'],
    'native_original_command': command,
    'native_total_line': totals[0],
    'native_failed_rows': failed_rows,
    'native_allowed_skip_rows': skipped_rows,
    'pf3': {'baseline': pf3['baseline'], 'mutations': [{k:r[k] for k in ('id','verdict','exit','counts','requiredMarker')} for r in pf3['mutations']],
            'restored': pf3['restored'], 'originalSourcesUnchanged': pf3['originalSourcesUnchanged']},
    'three_suite_diagnostic': {'source_sha': three['source_sha'], 'original_run_exit': three['original_run_exit'],
        'reaper_process_exit': three['reaper_process_exit'], 'outer_exit': three['outer_exit'],
        'scope': '原三個 --only，48pass/2fail/0skip；不是完整 native／v3 正式 stage'},
    'remaining_recorded_wrapper_exits': remaining['completed_stages'],
    'unique_red_classification': [
        {'item':'N32/base 1.0008656473515014 >1.0', 'class':'原量化 gate 真紅；保留，不重抽、不加容差'},
        {'item':'source64/source32 6.154996228372071 >4.5', 'class':'原量化 gate 真紅；保留，熱路徑候選未套未測'},
        {'item':'cross-consumer expected placement vs actual footprint ASSERT', 'class':'既有負控制未涵蓋新版 W reader 邊界；保原 exact assertion 的校準候選未套'},
        {'item':'footprint-order generated native type error', 'class':'既有負控注入 API／型別失準；不是正常 mutation kill；校準候選未套'},
        {'item':'mutation:check closure stale', 'class':'原帳本過期；本輪不重產，依 root 最終 stack 統一重產規則交接'},
    ],
    'original_sources': ['/tmp/geo323-baseline-b2445b5a-three', str(ROOT),
        '/tmp/geo323-baseline-b2445b5a-v3-first-five-launch', '/tmp/geo323-baseline-b2445b5a-v3-remaining-launch'],
    'unapplied_candidate': str(PREP / 'combined-memo-controls-candidate-v1'),
    'unapplied_patch_sha256': 'a44018ad1e3455af89dc9fbc19ea4ec3d9b0e4dfec56f9ddab5d2893d91871b0',
    'unexecuted_fixed_three_launcher': str(PREP / 'fixed-three-driver-preparation'),
    'original_receipt_sha256': hashlib.sha256((ROOT / 'receipt.json').read_bytes()).hexdigest(),
    'scope_limitations': ['新 memo／四個具名反證、修後三套及新 final v3 都未執行',
        '最終帳本、架構三條與四檔收據未刷新；本輪不宣稱它們 fresh',
        '本輪未啟動 #323 六個 browser jobs；不是本環境無 Chrome',
        'UI transport 失效後 scheduler 缺 TOP RESULT，另見 RECOVERY；原八 stage 判決及 streams 已完整保留'],
}
path = PREP / 'BASELINE_CURRENT_SUMMARY.json'
if path.exists():
    raise RuntimeError('Preserve immutable summary')
path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
recovery = {
    'schema':'geo323-append-only-transport-recovery/1', 'source_sha':S,
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_unified_session_handle':18009,
    'observation_file':str(PREP / 'PLATFORM_TRANSPORT_OBSERVATION_20261023T1500.json'),
    'observed_pid':1305238, 'observed_pid_status_at_150348':'Z (zombie), PPid1',
    'observed_pid_kernel_wait_status':0,
    'kernel_status_not_used_as_a_gate':True,
    'exact_scheduler_script_processes_at_1504':[],
    'original_scheduler_TOP_RESULT_present':False,
    'original_scheduler_final_console_exit':'unknown after unified session loss; not inferred from other PID or judges',
    'actual_recorded_stage_wrapper_exits':remaining['completed_stages'],
    'native_original_process_exit':command['actual_process_returncode'],
    'native_execution_ended_utc':record['stages']['native']['ended_utc'],
    'source_after':record['stages']['native']['source_after'],
    'no_original_raw_or_receipt_rewritten':True, 'no_stage_reopened':True, 'no_resampling':True,
    'interpretation':'只補封裝／傳輸觀測。排程器最後 JSON 缺口照實保留；正式 stage 原 exit、完整 stdout/stderr 與 SHA 已由原內層 recorder 封存，不補造成功出口。',
    'role_metadata_scope':'原 v3 role heuristic 遇包含 --base SHA 的 orchestration argv 會標 base；acceptance_sha 仍是 S。真正 run_all／PF3 程序由內層 source_sha、cwd 與前後 clean Git state 綁 S，不把 orchestration role 當受驗產品。',
}
(PREP / 'RECOVERY.json').write_text(json.dumps(recovery, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'summary':str(path),'native_total':totals[0], 'stage_count':len(names), 'full_acceptance_passed':record['full_acceptance_passed']},ensure_ascii=False))
