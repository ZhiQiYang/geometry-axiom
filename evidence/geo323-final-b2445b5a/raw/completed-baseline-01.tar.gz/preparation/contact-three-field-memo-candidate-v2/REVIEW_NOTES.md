# 可審候選 v2：只 memo 已成功的 contact 三欄解碼

**未套用、未編譯、未測、未量測，沒有宣稱性能收益或 ≤1.3 達標。** patch SHA-256：`5a25dfe85440c0cee6dd44de3f3af6a38340e9fb9d98b88942583542de4ff152`。依原不可變產品 S=`5c29eba30a40f20ea5c7eb8dc139e5788235d3b6` 的兩個 Git blob 產生，原件與命令存 v1 的 `originals/`／`subcommands/`。目前已公開同步基線 S=`b2445b5a270d60fdf48b07f6edddbe91266d8aa2`；這兩個 C blob 與舊 S 完全相同，候選仍在 repo 外。

## 原因與證據界線

歷史 f43 的 N64 fix/main=1.7457212386，原 36 個交錯樣本與四份 gprof 已保留。fix-N64 的舊 profile 有 full `reference_member_anchor_read` 908,057 次、full placement decode 2,157 次；原 self sample 只有 0.01 秒分辨率，不能把百分比直接當預期收益。

同步後 S 的 contact callback 已改為每個 consumer 呼叫 #288 的 `wood_definition_sources_placement_contact`：它先由 `wd_reader` 經 `geo_eval_source`／schema／type 檢查，再讀三欄並驗全部原可變字串格式。成功的 canonical placement source 在同一 ReferenceEval 生命期內保持；每個 contact consumer 仍重走這段解碼。v2 對這個具體重複工作提出只存 `{placement_id,length_direction,order}` 的 memo，hit 時仍作同一條原 dependency。

但新 S 同時已合入 #288 的 deferred raw：f43 的 `app_contact_facts` 每 query／member 立即算 `timber_a0_footprint_uv`；新 S 的 `app_contact_facts_prepare(...,raw)` 先只保存原 raw facts，source／footprint hit 成功時把 pending 清為 0／2。舊 gprof 的 `a0_rect_uv` 1,209,964 次、`timber_a0_footprint_uv` 1,449,274 次因此不能外推到新 S。先跑新 S 原三套，再用原 protocol 量新 S 實際性能；若新 S 已過原 gate，不能僅因 f43 歷史紅而盲套候選。

## 實際改動

只有 `geometry-core/references.inc` 與 `geometry-app/native/reference_sources.inc`：

- `ReferenceEval.member_reads` 增加獨立 `contact_valid`／`contact_id`／小型 contact value；不把 full anchor 視為已解碼，不讓兩種 memo 共用成功 flag 或 id key。
- 原 placement `geo_eval_depend` 操作完整移入 `reference_member_placement_depend`，full-anchor hit 與 contact hit 共用這個原 site。每次 hit 仍在當前 consumer、原順序、原 `GEO_DEPENDENCY_DEFINITION_REQUIRED` kind 登記，失敗立即回 false。
- contact miss 仍走原輕量 parser，只有其全部成功才存值。sealed／index 超界仍走原 parser；沒有跳過原 source 驗證／負值診斷，也不缓存失敗。
- callback 原成功後 canonical slot 換人時的 full-anchor／footprint invalidation、placement gate、原 raw prefix flush、source-footprint pending 清理都保持原 bytes。
- 既有 `reference_sources_dispose` 的整份 member_reads memset 自然清掉新 memo；candidate evaluate／reopen／discard 原先先 dispose old ReferenceEval 的次序不改。不以 World 地址／只靠 full-anchor miss 判 freshness。

沒有改 K／W provider 格式、對外 API、排序、guard 計數邏輯、tests、expected、mutation registry／ledger、公理或決策。full／contact 各自的值快取只是解碼儲存；original source graph 已快取 VALID node 的前提與目前 full-anchor memo 相同，不跨 graph reset。

## 原裁判錨點與待證缺口

v1 的新 helper 複製了原 ANCHOR_DEPEND 字串，會令現有「唯一 site」的 mutation selector 變成兩處；原件保留但不應採用。v2 改共用原 dependency site，靜態核原完整 ANCHOR_DEPEND 字串仍恰 1、廣義 `if(geo_eval_depend(ctx->sources,` site 原 3／新 3，不改 test 的數字斷言或 selector。

這仍不是動態反證已過。原 anchor-edge／kind 控制執行的是 `cache-anchor`，不能拿它冒稱新 contact caller 已自證；原 `ANCHOR_ID_KEY` 控制也只刪 full-anchor key。若性能證據支持採用，至少須給兩項具名真 provider 反證：新 `contact_id==id` 在自然 `mr_swap_storage` 後的 order／placement 控制，以及 warmed contact caller 省 edge／錯 kind／錯 order 的有序 graph 控制。每項保 baseline0／正常具名 Assertion mutant1／restore0，不能用 compiler／loader／crash 充當 kill。

原移除整個 memo 只會退回正確的原解碼路徑；不宣稱這是產品正確性 bug 或保證有 assertion kill。性能必要性須由同環境原 gate 的實測／withdrawal 說明，不能為了製造紅燈新增門檻、強加 cache-hit 次數或任意 sleep。

下一次正式診斷需具體釐清：新 S 的 deferred `raw_restore`／`a0_rect_uv` 是否仍佔成本、contact 輕量 reader 的真呼叫量、full-anchor／footprint 自然 hit、`geo_eval_source`／depend 與 source64/32 原 gate。原比較點與 N64 ≤1.3 不變。沒有新的 profile 前，不宣稱任何分支已是主因或候選可解全數差額。

準備工具曾有一個未使用的非 ASCII bytes literal 造成 Python SyntaxError（未進 main、未寫 source／candidate）；已保原 `prepare_contact_memo_candidate_v2.syntax-error.py.txt`，刪掉該未使用 literal、改讀不可變原 block 後產生本候選。這是 repo 外準備腳本修正，不是產品／原 test 失敗或重測。
