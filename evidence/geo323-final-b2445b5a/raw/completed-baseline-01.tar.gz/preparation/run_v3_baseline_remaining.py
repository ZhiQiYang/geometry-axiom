"""Complete the same baseline once with untouched original v3 formal stages."""
import datetime,importlib.util,json,os
from pathlib import Path
S='b2445b5a270d60fdf48b07f6edddbe91266d8aa2';BASE='b74f9a2ae7ade1555b9be45283adecc097fb76e3';MAIN='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
REPO=Path('/tmp/g261-next323');TOOLS=Path('/tmp/geo323-merge-20261023/acceptance-tools-v3');RESULT=Path('/tmp/geo323-baseline-b2445b5a-v3-r1');OUT=Path('/tmp/geo323-baseline-b2445b5a-v3-remaining-launch')
if OUT.exists():raise RuntimeError('Never overwrite original remaining-stage launch')
existing=json.loads((RESULT/'receipt.json').read_text())
if existing['source_sha']!=S or any(name in existing['stages'] for name in ('required-eight','pf3','native')):raise RuntimeError('Original stages must not be replayed')
OUT.mkdir();spec=importlib.util.spec_from_file_location('capture','/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('NODE_OPTIONS',None);env.pop('PYTHONOPTIMIZE',None);rec=m.Recorder(OUT,env,S)
rows=[];report={'source_sha':S,'base':BASE,'main':MAIN,'stages':['required-eight','pf3','native'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_applied':False,'test_controls_fixed':False,'ledger_or_architecture_regenerated':False,'scope':'Complete all original baseline stages; prior quantitative reds persist in wrapper_exit and do not relabel a later original stage process','original_R3_unchanged':True,'completed_stages':rows,'commands':rec.rows}
m.dump(OUT/'TOP_REQUEST.json',report)
for stage in report['stages']:
 argv=['python3','-B',str(TOOLS/'run.py'),'--repo',str(REPO),'--sha',S,'--base',BASE,'--main',MAIN,'--out',str(RESULT),'--heavy-lock','/tmp/g261r3/heavy.lock','--stage',stage]
 row,stdout,stderr=rec.run(argv,cwd=REPO,timeout=None,check=False);rows.append({'stage':stage,'actual_wrapper_exit':row['actual_process_returncode'],'directory':row['directory']});m.dump(OUT/'PROGRESS.json',report);print(json.dumps(rows[-1]),flush=True)
report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.dump(OUT/'RESULT.json',report)
raise SystemExit(1 if any(r['actual_wrapper_exit'] for r in rows) else 0)
