# P52 新 F 正式量測／原 verifier 對抗審

唯讀原件審查完成，845 checks、0 findings，220 個唯一原命令／服務／launcher stream 路徑逐 bytes/hash 核同。JSON：`P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.json`，SHA-256 `8b4f71ad0294acfd61c5c63914ec9b7b4ca6c9cda014dfc2f26eeb5f4dc42a42`。沒有執行測試、編譯、瀏覽器或效能重抽。

產品 F=`3d681636902371ecc528b20f51eea33e272581c9`，原 main 比較點 M=`adbaebf9c73ea6801d7b4d5214e4b846b132923b`，角色與逐 Node 的 source SHA 保持不同。四個原 block 為 main／fix／fix／main，各 8 個試次，全部 exit 0；原試次順序、16＋16 個樣本與原 median 重算一致。main=243.1667135 ms、fix=216.36882 ms、fix/main=0.889796209710257。五項 controls 原退出為 0／0／1／1／1，原 `expected_behavior_proved` 皆 true；負控 1 未被改標為程序 0。

原 verifier 完整 bytes SHA `5a109def7794ebc1e34048afe500fd97758f98781ff90597fedec0dc214f1e04` 與 AST 保持，九條原 assert 全在；真 verifier process、adapter、launcher／外錄皆 0，原 verified result 為 9 Node／pass true。derived launch schema 明載為機械投影，沒有冒成原 launch stdout。

正式完整 runtime inventory：fix 731／731、main 466／466。前後 JSON bytes/hash、source version、完整 index hash 與乾淨 SHA 均一致。這次核已封 inventory 與原完整 streams，沒有另掃或 hash 無關產品整樹。

root 已確認兩個獨立 publication 的原 input 根：formal 包含 `/tmp/g288pff`、formal outer／launch／execution；verifier 包含獨立 verifier output、verifier outer／launch／execution。按既有 publisher 的 cache／ELF 排除規則逐一核所有 recorded command stdin/stdout/stderr、服務 log／reaper、launcher streams，均被這兩組根涵蓋且不落在排除項。沒有以「可重建 cache」吞掉原 stdout。實際公開 Git 封包逐 member roundtrip 仍需在 runtime 專項終態後獨立核，不能把這份 planned-coverage 審查當成已審公開封包。

透明保留一項 peer 摘錄更正：初稿把原 `node --version` 當成第十個 probe。原 `P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.preliminary-counted-version.json` 保留；修正只從 probe 計數排除精確 `['node','--version']`，再核九個 probe directory 與原 `node_commands` 完全相同。這是 peer metadata 的分類更正，不是產品或原 gate 紅燈，不曾修改、重跑或挑選正式樣本。

目前只關閉 P52 formal＋獨立 verifier 的原件／planned stream coverage。新 F runtime 撤回／恢復仍由 root 原序列執行，不能提前宣稱其 0／1／0 或整項最終完成。
