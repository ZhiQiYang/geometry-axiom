"""Run the same three diagnostic suites on a future clean committed fixed SHA; no R3/perf stage."""
import argparse,datetime,hashlib,importlib.util,json,os,resource,shutil,sys,traceback
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True,type=Path);parser.add_argument('--sha',required=True);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
S=args.sha;REPO=args.repo.resolve();OUT=args.out.resolve()
TOOLS=Path('/workspace/geo288-main-merge-20261023/native-final-tools')
if OUT.exists():raise RuntimeError('Fresh diagnostic output required, never retry or overwrite')
OUT.mkdir();(OUT/'tmp').mkdir();(OUT/'inputs').mkdir();(OUT/'tools').mkdir();(OUT/'executions').mkdir()
for name,want in [('capture.py','c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'),('reap_children.py','7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760')]:
 raw=(TOOLS/name).read_bytes()
 if hashlib.sha256(raw).hexdigest()!=want:raise RuntimeError('Original tool changed')
 (OUT/'tools'/name).write_bytes(raw)
shutil.copy2(__file__,OUT/'tools/diagnostic_driver.py.txt')
spec=importlib.util.spec_from_file_location('original_capture',TOOLS/'capture.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);removed=[]
for name in list(env):
 if name.startswith('GEOMETRY_') or name in ('NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','LD_PRELOAD'):
  removed.append(name);env.pop(name)
env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TMPDIR=str(OUT/'tmp'),GITHUB_SHA=S,GITHUB_WORKSPACE=str(REPO),GEO261_REAPER_LOG=str(OUT/'reaper.jsonl'),GEO261_LOAD_RESIDUAL_EXECUTION_LOG=str(OUT/'executions/load-residual.jsonl'),GEO261_HOST_FACTS_EXECUTION_LOG=str(OUT/'executions/host-facts.jsonl'),GEO261_CONTACT_SOURCES_EXECUTION_LOG=str(OUT/'executions/contact-sources.jsonl'))
rec=cap.Recorder(OUT,env,S)
report={'schema':'geo323-original-three-suite-fixed-diagnostic/1','source_sha':S,'repo':str(REPO),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Original run_all.py --build with three --only selectors; PARTIAL diagnostic, not v3 formal stage or full native; candidate committed at specified source SHA; full v3 acceptance remains separate','candidate_applied':True,'performance_or_profile_executed':False,'regeneration_executed':False,'source_before':None,'source_after':None,'original_run':None,'original_run_exit':None,'reaper_process_exit':None,'metadata_errors':[],'environment':{k:env.get(k) for k in ('PATH','LANG','LC_ALL','NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','TMPDIR','GITHUB_SHA','GITHUB_WORKSPACE','GEO261_REAPER_LOG','GEO261_LOAD_RESIDUAL_EXECUTION_LOG','GEO261_HOST_FACTS_EXECUTION_LOG','GEO261_CONTACT_SOURCES_EXECUTION_LOG','CC','CFLAGS','CPPFLAGS','LDFLAGS')},'removed_environment_names':removed,'original_timeouts':'Original run_all.py unittest suite timeout 1200s; original inner case timeouts unchanged; outer capture timeout=None','commands':rec.rows,'original_expected_counts':{'py:test_geo261_load_residual':13,'py:test_geo261_host_facts_authority':22,'py:test_geo261_contact_sources':15}}
def run(argv,check=True,timeout=120):return rec.run(argv,cwd=REPO,check=check,timeout=timeout)
def git(*parts):return run(['git',*parts])[1]
def guard():
 d={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode(),'index_sha256':cap.digest(git('ls-files','--stage','-z'))}
 if d['head']!=S or d['status']:raise RuntimeError('Fixed source must remain clean exact specified SHA')
 return d
names=[key.replace(':','_')+suffix for key in report['original_expected_counts'] for suffix in ('.log','.json','.unittest.log')]
def snapshot_logs(label):
 rows={};directory=OUT/('selected-logs-'+label);directory.mkdir(exist_ok=True)
 for name in names:
  p=Path('/tmp/geometry-tests/run_all-logs')/name
  if p.is_file():
   raw=p.read_bytes();(directory/name).write_bytes(raw);st=p.stat();rows[name]={'bytes':len(raw),'sha256':cap.digest(raw),'mtime_ns':st.st_mtime_ns}
  else:rows[name]=None
 return rows
before=resource.getrlimit(resource.RLIMIT_STACK);report['stack_before']=list(before)
try:
 if before[1]!=resource.RLIM_INFINITY and before[1]<16777216:raise RuntimeError('Original stack16MiB unavailable')
 resource.setrlimit(resource.RLIMIT_STACK,(16777216,before[1]));report['stack_during']=list(resource.getrlimit(resource.RLIMIT_STACK))
 report['source_before']=guard();run(['df','-B1','/tmp','/workspace'])
 source=(REPO/'tests/run_all.py').read_text()
 if '/tmp/g261r3/heavy.lock' in source or 'flock' in source or 'R3' in source:raise RuntimeError('Original three-suite CLI unexpectedly has R3 policy; do not remove it')
 report['original_cli_has_no_R3']=True
 for relative in ('tests/run_all.py','tests/run_all.expected.json','tests/test_geo261_load_residual.py','tests/test_geo261_host_facts_authority.py','tests/test_geo261_contact_sources.py','tests/geo261_load_residual_harness.c','tests/geo261_member_reads_cases.inc','tests/test_geo261_native_kernel.py','current_geometry.c','geometry-core/references.inc','geometry-app/native/reference_sources.inc','geometry-app/native/world_validation.inc','geometry-templates/woodworking/native/contact_sources.c','geometry-templates/woodworking/native/definition_sources.c'):
  raw=git('show',S+':'+relative)
  if raw!=(REPO/relative).read_bytes():raise RuntimeError('Input bytes differ '+relative)
  path=OUT/'inputs'/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
 expected=json.loads((REPO/'tests/run_all.expected.json').read_text())['suites']
 for name,count in report['original_expected_counts'].items():
  if expected[name]['count']!=count:raise RuntimeError('Original selected expected count changed '+name)
 report['logs_before']=snapshot_logs('before')
 command=[sys.executable,'-B',str(OUT/'tools/reap_children.py'),'python3','-B','tests/run_all.py','--build','--only','py:test_geo261_load_residual','--only','py:test_geo261_host_facts_authority','--only','py:test_geo261_contact_sources']
 cap.dump(OUT/'TOP_REQUEST.json',{'source_sha':S,'argv':command,'environment':report['environment'],'scope':report['scope'],'R3':'Original CLI has none; not added or removed; root explicitly authorized second non-performance slot'})
 report['original_run']=run(command,False,None)[0]
except BaseException:report['metadata_errors'].append(traceback.format_exc())
finally:
 try:
  if report['original_run'] is not None:
   events=[json.loads(line) for line in (OUT/'reaper.jsonl').read_text().splitlines()];terminal=[e for e in events if e.get('event')=='完成']
   if len(terminal)!=1:raise RuntimeError('Unique original reaper terminal required')
   report['original_run_exit']=terminal[0]['primary_returncode'];report['reaper_process_exit']=report['original_run']['actual_process_returncode']
   if report['reaper_process_exit']!=(report['original_run_exit'] if report['original_run_exit']>=0 else 128-report['original_run_exit']):raise RuntimeError('Original reaper process mapping differs')
 except BaseException:report['metadata_errors'].append(traceback.format_exc())
 try:report['source_after']=guard()
 except BaseException:report['metadata_errors'].append(traceback.format_exc())
 try:report['logs_after']=snapshot_logs('after')
 except BaseException:report['metadata_errors'].append(traceback.format_exc())
 report['metadata_complete']=not report['metadata_errors'] and report['original_run'] is not None
 report['outer_exit']=report['reaper_process_exit'] if report['metadata_complete'] else 2
 report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();resource.setrlimit(resource.RLIMIT_STACK,before);cap.dump(OUT/'receipt.json',report)
print(json.dumps({k:report.get(k) for k in ('source_sha','original_run_exit','reaper_process_exit','outer_exit','metadata_complete','metadata_errors')},ensure_ascii=False))
raise SystemExit(report['outer_exit'])
