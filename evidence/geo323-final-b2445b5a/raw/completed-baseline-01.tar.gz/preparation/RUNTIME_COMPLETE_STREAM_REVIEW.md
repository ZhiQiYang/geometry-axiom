# Runtime 補包的小型獨立核對

原受驗 SHA：`13d02c1db7022145a52ee063286a558e595eb212`。核對 `/tmp/g288pr` 原件、`/tmp/g288pr-publication-complete` staging 與補正發布 `fbdde3de95f82b3c5d3b5bbe8754187512473899` 的 inventory／excluded metadata。沒有重測、編譯、啟動瀏覽器、解包 tar 或重算 ELF／大檔 hash。

**已記錄的 runtime 命令 streams 在補包中齊全，沒有發現遺漏或不符。** 主 recorder 95 筆、withdrawn／restored 各14筆，共123個終態 command 的246份 stdout／stderr，加 receipt 指向的26份其他 logs／streams，全數存在 staging 和公開 archive inventory，沒有落入 excluded；recorded／manifest hash 與 bytes 均相合。所有272路徑都與原件具有同一 device／inode，未覆寫原檔；其中252份小檔另核實際 SHA256，20份較大 stream 不重讀 hash，靠原 recorded hash、manifest、bytes 與 hardlink identity 核合。

三份原 command metadata 及三份原 receipt bytes 與 staging 完全相同。runtime 原 receipt 的 SHA256 為 `fa4af1c7a83355cf3fa9bd1f9575bd562c73cfedc008fe904f9bc9a8c48e71a4`，與 PACKAGING 綁定相符；正式 baseline receipt 的 SHA256 也與原 baseline 引用相符。原 runtime `passed=true`、errors 空、ended=`2026-10-23T06:48:02.469205+00:00`。withdrawn 原 gate1、restored 原 gate0，兩phase各4個 Node實際均0、completed=true，不能把計時gate的預期1當程序崩潰。

發布 metadata 的精確數量需分清：PACKAGING 宣告1633個 staged files，其中713份檔案 bytes 在 archive，920份被 publisher 明列為可重建 cache（兩phase各16份 `geometry-runtime`／444份 `node-compile-cache`）。1633筆全數可由 archived 或 excluded metadata對應，無未交代路徑；不能把「1633筆逐hash列冊」寫成「1633份原bytes全裝入tar」。八個 Chrome profiles／八個 `com.google.Chrome.*` symlink 在 staging 階段已列排除。這些排除沒有碰到上述272份原命令 streams／logs。

首包 `c3fec08f` 的 staging socket 錯誤及不完整 raw 仍是歷史事實；本核對只支持新補包，不回溯改稱首包完整。正式 baseline 的原 command streams 仍由其已發布正式 P52 raw 提供，本 runtime 包保存的是精確 baseline receipt 引用，沒有冒稱重新執行五 controls。

限制：沒有對原 source 全目錄重新做 filesystem census，也未重開公開 tar members／screenshots。這是指定 command stream 路徑、已列冊檔案及小 metadata 的覆蓋核對；不是新的產品 gate。逐路徑明細見同目錄 `RUNTIME_COMPLETE_STREAM_REVIEW.json`。
