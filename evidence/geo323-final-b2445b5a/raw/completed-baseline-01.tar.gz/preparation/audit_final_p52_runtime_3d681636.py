"""Read terminal actual runtime receipts; never execute the product or original judge."""
import ast,hashlib,json,statistics
from pathlib import Path
B=Path('/workspace/geo288-main-merge-20261023');R=Path('/tmp/g288prf');F='3d681636902371ecc528b20f51eea33e272581c9';M='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
OUT=Path('/tmp/geo323-merge-20261023/P52_FINAL_RUNTIME_ACTUAL_PEER_REVIEW.json')
checks=[];streams=[];coverage=[]
roots=[R,B/'p52-final-runtime-launch',B/'p52-final-runtime-execution',B/'p52-final-outers/p88-final-p52-runtime']
def h(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
def hf(p,want=None,size=None):
 p=Path(p);raw=p.read_bytes();ck('file:'+str(p),(want is None or h(raw)==want) and (size is None or len(raw)==size),{'bytes':len(raw),'sha256':h(raw)});return raw
def cover(p,role):
 p=Path(p);matches=[root for root in roots if p.is_relative_to(root)];reason=None
 if not matches:reason='outside-proposed-inputs'
 else:
  rel=p.relative_to(matches[0])
  if any(s in ('.git','__pycache__','node_modules','geometry-runtime','profile','chrome-profile','node-compile-cache') or s.startswith(('geometry-cdp-','geometry-documents-chrome-','com.google.Chrome.')) for s in rel.parts):reason='cache-path'
  elif p.is_symlink() or not p.is_file():reason='non-regular'
  else:
   with p.open('rb') as handle:
    if handle.read(4)==b'\x7fELF':reason='ELF'
 ck('publisher:'+str(p),reason is None);coverage.append({'path':str(p),'role':role,'covered':reason is None,'excluded_reason':reason})
def cmd(row):
 d=Path(row['directory']);actual=load(d/'result.json');ck('command:'+str(d),actual['actual_process_returncode']==row['actual_process_returncode'] and not actual['timeout_expired'])
 for stem,key in (('stdout','stdout_sha256'),('stderr','stderr_sha256'),('stdin','stdin_sha256')):
  p=d/(stem+'.bin');hf(p,row[key],row.get(stem+'_bytes'));cover(p,'command-'+stem);streams.append(str(p))
 for name in ('request.json','result.json'):cover(d/name,'command-metadata')
d=load(R/'receipt.json');launch=load(B/'p52-final-runtime-launch/exit.json')
if not d.get('ended_utc') or not launch.get('ended_utc'):raise RuntimeError('Only review genuine terminal receipts')
ck('runtime-complete-zero',d['passed'] is True and not d['errors'] and d['sha']==F and d['main']==M and launch['actual_process_returncode']==launch['launcher_exit_code']==0)
ck('runtime-stack',d['stack_during'][0]==16777216)
baseline=(R/'formal-baseline-receipt.json').read_bytes();formal=Path('/tmp/g288pff/receipt.json').read_bytes()
ck('same-formal-baseline-exact-bytes',baseline==formal and h(baseline)==d['baseline']['sha256']);f=json.loads(formal)
ck('formal-original-baseline-zero',f['sha']==F and f['timing']['no_regression'] is True and all(r['exit']==0 for r in f['records']) and len(f['controls'])==5 and all(r['expected_behavior_proved'] is True for r in f['controls']))
protocol=(R/'tools/protocol/postfix_validate.py').read_text();tree=ast.parse(protocol);fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
start=next(i for i,n in enumerate(fun.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='samples' for t in n.targets));stop=next(i for i,n in enumerate(fun.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='timing' for t in n.targets));nodes=fun.body[start:stop+1]
gate=''.join(protocol.splitlines(keepends=True)[nodes[0].lineno-1:nodes[-1].end_lineno]).encode()
ck('original-timing-gate-exact-four-statements',len(nodes)==4 and "medians['fix']<=medians['main']" in gate.decode())
ck('exact-one-withdrawn-and-restored',[p['phase'] for p in d['phases']]==['withdrawn','restored'])
for p in d['phases']:
 name=p['phase'];directory=R/name;a=load(directory/'receipt.json');ck('phase-raw-receipt:'+name,a==p['receipt'])
 expected=1 if name=='withdrawn' else 0
 ck('original-gate-terminal:'+name,p['passed'] is True and p['command_result']['actual_process_returncode']==a['gate_exit']==expected and a['completed'] is True and not a['errors'])
 ck('original-node-exits:'+name,len(a['records'])==len(a['node_commands'])==4 and all(r['exit']==0 for r in a['records']) and all(r['actual_process_returncode']==0 for r in a['node_commands']))
 ck('original-order-source:'+name,[r['label'] for r in a['records']]==['0-main','1-fix','2-fix','3-main'] and [r['sha'] for r in a['records']]==[M,F,F,M])
 ck('original-gate-bytes:'+name,hf(directory/'original-gate-source.txt',a['original_gate_source_sha256'])==gate)
 samples={'main':[],'fix':[]}
 for i,r in enumerate(a['records']):
  trial=r['result']['samples'];ck('eight-original-trials:'+name+r['label'],len(trial)==8 and [s['trial'] for s in trial]==list(range(8)) and r['result']['failed']==r['result']['exceptions']==0)
  samples['main' if r['sha']==M else 'fix'] += [s['appearedMs'] for s in trial]
  n=a['node_commands'][i];ck('node-source-preserved:'+name+r['label'],n['source_sha']==r['sha'] and n['effective_environment']['P52_SHA']==r['sha'])
  cover(r['log'],'original-probe-log')
 for key,values in samples.items():ck('original-median:'+name+key,len(values)==16 and statistics.median(values)==a['timing']['medians_ms'][key])
 ck('original-ratio:'+name,a['timing']['ratio']==statistics.median(samples['fix'])/statistics.median(samples['main']) and a['timing']['no_regression']==(expected==0))
 phasecmds=load(directory/'subcommands.json');ck('only-four-probes-no-resampling:'+name,len([r for r in phasecmds if r['command'][0]=='node'])==4 and len({n['directory'] for n in a['node_commands']})==4)
 for row in phasecmds:cmd(row)
 for row in a['servers']:
  hf(row['log'],row['log_sha256'],row['log_bytes']);cover(row['log'],'service-stdout');streams.append(row['log'])
  reaper=Path(row['environment']['GEO261_REAPER_LOG']);cover(reaper,'service-reaper');events=[json.loads(line) for line in reaper.read_text().splitlines()];ck('service-reaped:'+str(reaper),events[-1]['event']=='完成')
 reaper=directory/'phase-reaper.jsonl';events=[json.loads(line) for line in reaper.read_text().splitlines()];ck('phase-primary-exit:'+name,events[-1]['event']=='完成' and events[-1]['primary_returncode']==expected);cover(reaper,'phase-reaper')
for row in load(R/'subcommands.json'):cmd(row)
for path,wanted in d['tool_hashes'].items():hf(path,wanted)
for path,wanted in d['tool_snapshot_hashes'].items():hf(path,wanted)
hashes={'fixed':'1cafc0868554e9f4028de3c6851d12cb8d9716fec18a6fe379afbbd2e3b14274','withdrawn':'5b7261519e70e51f952264c56d0a7cf18e7d4fdeeb8bb033fc391f08339468ea'}
hf(R/'runtime-F2.py.txt',hashes['fixed']);hf(R/'runtime-old-F.py.txt',hashes['withdrawn'])
for g in d['guards']:
 main=g['label'].startswith('main') or '-main-' in g['label'];withdrawn=g['label'].startswith('withdrawn') and not main
 ck('guard:'+g['label'],g['head']==(M if main else F) and g['status']==(' M geometry-web/runtime_version.py\n' if withdrawn else '') and (main or g['runtime_sha256']==hashes['withdrawn' if withdrawn else 'fixed']))
 patch=(R/(g['label']+'.patch')).read_bytes();ck('patch-hash:'+g['label'],h(patch)==g['diff_sha256'])
 if withdrawn:ck('only-runtime-patch:'+g['label'],[l for l in patch.decode().splitlines() if l.startswith('diff --git ')]==['diff --git a/geometry-web/runtime_version.py b/geometry-web/runtime_version.py'])
 elif not main:ck('clean-patch:'+g['label'],not patch)
def identity(j):return j['source_sha'],j['source_version'],[(x['path'],x['runtime_identity_sha256']) for x in j['inputs']]
inventories={name:load(R/(name+'-runtime-inputs.json')) for name in ('source','clone','source-after','main','main-after')}
for name,j in inventories.items():ck('complete-runtime-inventory:'+name,j['source_set_complete'] is True and j['expected_count']==j['actual_count']==len(j['inputs']) and j['source_sha']==(M if name.startswith('main') else F))
ck('source-clone-after-runtime-identical',identity(inventories['source'])==identity(inventories['clone'])==identity(inventories['source-after']))
ck('main-runtime-identical',identity(inventories['main'])==identity(inventories['main-after']))
for stem in ('stdout','stderr'):hf(B/'p52-final-runtime-launch'/stem,launch[stem+'_sha256']);cover(B/'p52-final-runtime-launch'/stem,'launcher-'+stem)
for root in (B/'p52-final-runtime-execution',B/'p52-final-outers/p88-final-p52-runtime'):
 for row in load(root/'receipt.json').get('commands',[]):cmd(row)
report={'schema':'geo288-final-p52-runtime-actual-peer/1','source_sha':F,'main_source_sha':M,'runtime_source_scope':'Only isolated runtime_version.py withdrawal of exact P3; no claim each performance component individually necessary','original_gate_results':[0,*[p['command_result']['actual_process_returncode'] for p in d['phases']]],'ratios':[f['timing']['ratio'],*[p['receipt']['timing']['ratio'] for p in d['phases']]],'checks':checks,'check_count':len(checks),'failures':[r for r in checks if not r['passed']],'unique_stream_paths_checked':len(set(streams)),'required_stream_publication_coverage':coverage,'runtime_receipt_sha256':h((R/'receipt.json').read_bytes()),'actual_public_archive_roundtrip':'pending separate published inventory/member peer; source/raw judged here only','method':'Read-only original terminal JSON/streams and original gate AST; no product execution, test, compilation, resampling or unrelated whole-tree hash'}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(OUT),'sha256':h(OUT.read_bytes()),'checks':len(checks),'failures':report['failures'],'streams':report['unique_stream_paths_checked'],'original_gate_results':report['original_gate_results'],'ratios':report['ratios']},ensure_ascii=False))
