import importlib.util,json,os
from pathlib import Path
E='b74f9a2ae7ade1555b9be45283adecc097fb76e3';OLD='307a18ec5972619161a59df82dcb7e765d137c90';REPO=Path('/tmp/g261-next323');OUT=Path('/tmp/geo323-merge-20261023/sync-b74f9a2a-commit')
if OUT.exists():raise RuntimeError('Fresh commit record required')
OUT.mkdir();s=importlib.util.spec_from_file_location('capture','/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.Recorder(OUT,dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1'),OLD)
def git(*argv):return r.run(['git',*argv],cwd=REPO,timeout=600)[1]
if git('rev-parse','HEAD').decode().strip()!=OLD or git('rev-parse','MERGE_HEAD').decode().strip()!=E or git('ls-files','-u','-z'):raise RuntimeError('Expected conflict-free ordinary merge state required')
for rel in ('公理層.md','決策佇列.md'):
 if git('show',':'+rel)!=git('show',E+':'+rel):raise RuntimeError('Protected source must equal incoming integration bytes: '+rel)
for rel in ('current_geometry.c','geometry-core/references.inc','geometry-app/native/reference_sources.inc','tests/test_geo261_load_residual.py','tests/test_geo261_host_facts_authority.py','tests/test_geo261_contact_sources.py','tests/mutate.py','tests/run_all.expected.json'):
 if git('show',':'+rel)!=git('show',OLD+':'+rel):raise RuntimeError('Unexpected source/control change while synchronizing: '+rel)
git('diff','--cached','--check');git('commit','-m','Merge final GEO-261 integration into load residual branch')
S=git('rev-parse','HEAD').decode().strip();parents=git('show','-s','--format=%P',S).decode().strip().split()
if parents!=[OLD,E]:raise RuntimeError('Ordinary merge parents differ')
git('push','origin','HEAD:refs/heads/codex/geo261-load-residual-20261020')
remote=git('ls-remote','--exit-code','--heads','origin','refs/heads/codex/geo261-load-residual-20261020').decode().strip().split()[0]
if remote!=S:raise RuntimeError('Normal push remote mismatch')
status=git('status','--porcelain=v1','--untracked-files=all').decode()
if status:raise RuntimeError('Synchronized source not clean')
result={'old_evidence_head':OLD,'integration_evidence_head':E,'integration_product_sha':'3d681636902371ecc528b20f51eea33e272581c9','new_source_sha':S,'remote_head':remote,'parents':parents,'merge_conflicts':[],'candidate_applied':False,'tests_or_compile_or_ledger_or_architecture_regeneration_executed':False,'source_c_and_original_three_suite_blobs_unchanged':True,'protected_files_exact_incoming_bytes':True,'commands':r.rows}
m.dump(OUT/'SOURCE_SYNC_RESULT.json',result);print(json.dumps({k:result[k] for k in ('new_source_sha','remote_head','parents','candidate_applied')},ensure_ascii=False))
