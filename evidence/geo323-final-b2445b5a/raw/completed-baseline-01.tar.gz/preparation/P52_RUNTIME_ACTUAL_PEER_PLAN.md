# 新 F P52 runtime 撤回／恢復：原件審查準備

尚未讀取或判定本輪 live phase 原件，也沒有測試、編譯、Chrome、掃樹、hash 封包或重新量測。root 已啟動唯一原序列，輸出為 `/tmp/g288prf`；只在總 `receipt.json` 有真 `ended_utc`，外層 runtime launcher／execution 真終態後才做總核。

固定受驗來源 F=`3d681636902371ecc528b20f51eea33e272581c9`；main 比較點仍為 `adbaebf9c73ea6801d7b4d5214e4b846b132923b`。原 tool 的 scope 是正式 baseline 引用＋兩個追加 timing phase，不重新跑五個 controls，也不證每一個純效能組件個別必要。

正式 baseline 應逐 bytes 等於 `/tmp/g288pff/receipt.json`，即已核原 4 block／32 samples 與 5 controls。runtime 的 `formal-baseline-receipt.json` 不能重新改標成另一來源或另抽 baseline。

預列檢查如下，全部是既有原判官與原工具守門，不設新門檻：

- 原 source／main clean F／M、原完整 runtime inventory 的 source／clone／after 同一性與前後 index／patch；隔離 fix 工作樹的撤回僅 `geometry-web/runtime_version.py`，來源 blob SHA 分固定版 `1cafc086...` 與舊版 `5b726151...`，其餘來源／index保持。dirty mutant 須明載 variant，不冒 clean Git SHA。
- 原 P3 `55b9fb6479485361d9e2283a95e4355f5fca76db` 的單檔 diff 與其 parent 舊 runtime blob 已由原工具守門；看真原輸出／hash，不能以工具 exit 0 代替此事。
- `withdrawn`／`restored` 各只一次，每 phase 原 main／fix／fix／main 四個 block、每 block 8 個試次、main16／fix16、4個 Node 實際全 0、無 crash／timeout／infrastructure error。
- 原 timing AST 的判官為 `medians['fix'] <= medians['main']`。先核原 `original-gate-source.txt` bytes/hash及兩 phase相同，再依原全部 appearedMs 重算原 median／ratio，確認 withdrawal 真 gate 1、restore 真 gate 0；不將四個 Node 正常程序 0 誤當 timing gate 0。
- 原外層 subreaper terminal primary_returncode 須各等 phase 真 gate exit；兩 phase `passed` 及總 `passed` 不能只有 initialized／null。baseline0／withdraw1／restore0 必須由真程序原件連起，不憑預期值判通過。
- 原 c387、phase、run、runtime inventory、四個 protocol 與 reaper frozen hashes 原件／snapshot相符；沒有放寬原斷言、原樣本數或 timeout，沒有 retry／挑樣本。
- 完整 command stdin／stdout／stderr／request／result、phase原 probe／service logs與 reaper、launcher／outer／execution streams要保留；按實際 publication input roots逐路徑核 cache／ELF排除，不能吞原 command stream。

所有 phase 真終態後再一次完成原件審；公開 tar／Git member roundtrip 待 root 開放其結束後的小窗口。任何紅都保原件與 scope，不自動重試。
