# #323 計畫補記：#288 native 槽已完成

這是純文字／唯讀準備補記，沒有跑 #323 測試、編譯、profile 或效能量測，沒有改已交出的共享 source。

已再讀 root fresh-fetch 的 handoff `acd1289228d490c68a139cf17e02fdc1f3cb247c` 中 `handoff/pr-reviews/323.md`；最新仍為 2026-10-23 08:37:05 UTC、head `307a18e`，與前份計畫相同，沒有以後續 #288 審查冒充 #323 最新審查。完整 Git show 命令、exit 0、原文字與 hash 保存在 `/tmp/geo323-review-refresh-acd12892/`。

本代理已完成優先的 #288 新 F `3d681636902371ecc528b20f51eea33e272581c9` 四套原 native 補驗：17／3／51／737，808 pass、0 fail、0 skip，原 aggregate／reaper／outer／launch 均 0。公開元件證據 E=`c7214307d5ffc6a867089c8d832fef4bc94ae27c`，正文 D=`9329e1105a4f5bec3383e2bb5405a3cbbc7bd692`。這些是 #288 來源的四套 PARTIAL，不能拿來關閉 #323 source `5c29eba3` 的完整 native 或三套 controls。

#323 的 source／evidence／正文身分仍為 `5c29eba30a40f20ea5c7eb8dc139e5788235d3b6`／`307a18ec5972619161a59df82dcb7e765d137c90`／`187fb27f456193ebff4649e392db77905f68a093`，本補記沒有移動它們。root 尚在 #288 P52 專項獨占；先前計畫的正式清單、原 1.3 紅燈與比較基準、source 棒權限全部維持。

最快的三套診斷仍須等 root 指定精確執行 SHA／來源與正式槽，再原樣執行，不自動排在 #288 P52 之間。`run_all.py` 原 node-test 分支直接呼叫原 Node argv；#288 四套中精確物化的三個 legacy fixture 與 #323 cache 專項沒有混算。未來 #323 完整 native 若採稀疏 checkout，必須按其完整原 suite 所需 fixtures 判斷，不能照抄本次四套的三檔白名單。

新 pending 控制已再次靜態核實：`test_cached_source_footprint_is_not_overwritten_by_deferred_raw_snapshot` 真跑 `cache-footprint-source`，撤唯一 `if(deferred)raw[i].pending=fact->footprint_valid?0:2;`，要求正常 exit 1、唯一 `ASSERT:footprint-cache-hit-preserves-source-out`，再恢復 baseline。這段目前只核原工具內容，仍未取得 S5c 的 0／1／0，不能寫綠。

三套原 subprocess log 的環境名稱為 `GEO261_LOAD_RESIDUAL_EXECUTION_LOG`、`GEO261_HOST_FACTS_EXECUTION_LOG`、`GEO261_CONTACT_SOURCES_EXECUTION_LOG`；需給 fresh 外部路徑，同時設實際 `GITHUB_SHA`／`GITHUB_WORKSPACE`。舊 v3 正式 native／required-eight stage 已原樣支援這些逐站輸出，不需要另改產品或放寬原判官。原 H controls 及 footprint source pending 控制各自 baseline／mutant／restored，不以 Python aggregate 單綠取代逐站原件。
