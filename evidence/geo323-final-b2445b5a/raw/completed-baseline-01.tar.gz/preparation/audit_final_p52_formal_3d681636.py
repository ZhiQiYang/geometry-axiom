"""Read-only actual-receipt peer; never executes any product or judge."""
import ast,hashlib,json,statistics
from pathlib import Path
B=Path('/workspace/geo288-main-merge-20261023');F='3d681636902371ecc528b20f51eea33e272581c9';M='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
R=Path('/tmp/g288pff');OUT=Path('/tmp/geo323-merge-20261023/P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.json')
checks=[];streams=[];coverage=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def ck(name,condition,detail=None):checks.append({'name':name,'passed':bool(condition),'detail':detail})
def hashfile(p,wanted=None,size=None):
 p=Path(p);raw=p.read_bytes();h=digest(raw)
 ck('raw-file:'+str(p), (wanted is None or h==wanted) and (size is None or len(raw)==size),{'bytes':len(raw),'sha256':h})
 return raw
def excluded(p,root):
 rel=p.relative_to(root)
 if any(part in ('.git','__pycache__','node_modules','geometry-runtime','profile','chrome-profile','node-compile-cache') or part.startswith(('geometry-cdp-','geometry-documents-chrome-','com.google.Chrome.')) for part in rel.parts):return 'cache-path'
 if p.is_symlink() or not p.is_file():return 'non-regular'
 with p.open('rb') as f:
  if f.read(4)==b'\x7fELF':return 'ELF'
 return None
roots=[R,B/'p52-verifier-3d681636',*[B/('p52-final-'+x+'-'+kind) for x in ('formal','verifier') for kind in ('launch','execution')],*[B/'p52-final-outers'/('p88-final-p52-'+x) for x in ('formal','verifier')]]
def cover(p,role):
 p=Path(p);matched=[r for r in roots if p.is_relative_to(r)]
 reason=excluded(p,matched[0]) if matched else 'outside-proposed-inputs'
 coverage.append({'path':str(p),'role':role,'covered':bool(matched) and reason is None,'excluded_reason':reason})
 ck('publisher-covers-'+role+':'+str(p),bool(matched) and reason is None)
def command(row):
 d=Path(row['directory']);actual=load(d/'result.json')
 ck('original-command-exit:'+str(d),actual['actual_process_returncode']==row['actual_process_returncode'] and not actual['timeout_expired'])
 for stem,key in [('stdout','stdout_sha256'),('stderr','stderr_sha256'),('stdin','stdin_sha256')]:
  p=d/(stem+'.bin');hashfile(p,row[key],row.get(stem+'_bytes'));cover(p,'command-'+stem);streams.append(str(p))
 for name in ('request.json','result.json'):cover(d/name,'command-metadata')
receipt=load(R/'receipt.json');execution=load(R/'execution-receipt.json');ver=load(B/'p52-verifier-3d681636/receipt.json')
ck('formal-terminal-source',receipt['sha']==execution['sha']==ver['sha']==F and execution['main']==M)
ck('formal-original-terminal-zero',execution['passed'] is True and execution['actual_driver_exit_code']==0 and execution['original_body_completed'] is True and not execution['errors'])
ck('formal-stack-16MiB',execution['stack_during'][0]==16777216)
orig=(B/'verifier-tools-3d681636/original/verify_postfix_receipt.py').read_bytes()
ck('original-verifier-fullbytes',digest(orig)=='5a109def7794ebc1e34048afe500fd97758f98781ff90597fedec0dc214f1e04')
ck('original-verifier-nine-assertions',sum(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(orig)))==9 and ver['original_assertions_unchanged'] is True)
ck('original-verifier-terminal-zero',ver['passed'] is True and ver['original_verifier_process_exit']==0 and ver['actual_driver_exit_code']==0 and not ver['errors'])
ck('original-verified-result',ver['original_verified_result']['pass'] is True and ver['original_verified_result']['nodes']==9)
records=receipt['records'];controls=receipt['controls'];nodes=execution['node_commands']
ck('exact-original-blocks-and-controls',len(records)==4 and len(controls)==5 and len(nodes)==9)
node_processes=[r for r in execution['commands'] if r['command'][0]=='node']
probe_processes=[r for r in node_processes if r['command'][1:]!=['--version']]
ck('original-order-no-retry',[r['label'] for r in records]==['0-main','1-fix','2-fix','3-main'] and len({r['directory'] for r in nodes})==9 and len(probe_processes)==9 and {r['directory'] for r in probe_processes}=={r['directory'] for r in nodes}, {'total_node_processes':len(node_processes),'version_only_processes':len(node_processes)-len(probe_processes),'actual_probe_processes':len(probe_processes)})
ck('original-block-shas-exits',[r['sha'] for r in records]==[M,F,F,M] and [r['exit'] for r in records]==[0,0,0,0])
ck('original-five-control-exits',[r['exit'] for r in controls]==[0,0,1,1,1] and all(r['expected_behavior_proved'] is True for r in controls))
samples={'main':[],'fix':[]}
for i,r in enumerate(records):
 s=r['result']['samples'];ck('original-eight-trials:'+r['label'],len(s)==8 and [x['trial'] for x in s]==list(range(8)))
 samples['main' if r['sha']==M else 'fix'] += [smp['appearedMs'] for smp in s]
 ck('original-node-source:'+r['label'],nodes[i]['source_sha']==r['sha'] and nodes[i]['effective_environment']['P52_SHA']==r['sha'])
for name,s in samples.items():ck('raw-median:'+name,len(s)==16 and statistics.median(s)==receipt['timing']['medians_ms'][name])
ck('raw-original-ratio',receipt['timing']['ratio']==statistics.median(samples['fix'])/statistics.median(samples['main']) and receipt['timing']['no_regression'] is True)
guards=execution['guards']
for g in guards:
 inv=g['runtime_inputs'];p=Path(inv['path']);raw=hashfile(p,inv['sha256']);j=json.loads(raw)
 ck('complete-inventory:'+g['label'],inv['source_set_complete'] is True and j['source_set_complete'] is True and j['actual_count']==j['expected_count']==inv['actual_count']==inv['expected_count'] and j['source_sha']==g['head'] and j['tracked_index_sha256']==g['tree_index_sha256'])
 ck('clean-sha-guard:'+g['label'],not g['status'] and g['head']==(M if g['label'].startswith('main') else F))
 cover(p,'complete-runtime-inventory')
for label in ('main','fix'):
 before=next(g for g in guards if g['label']==label+'-before');after=next(g for g in guards if g['label']==label+'-after')
 ck('before-after-identical:'+label,before['head']==after['head'] and before['tree_index_sha256']==after['tree_index_sha256'] and before['runtime_inputs']==after['runtime_inputs'] | {'path':before['runtime_inputs']['path']})
for row in execution['commands']:command(row)
for row in ver['commands']:command(row)
for row in execution['servers']:
 hashfile(row['stdout'],row['stdout_sha256'],row['stdout_bytes']);cover(row['stdout'],'service-stdout');streams.append(row['stdout'])
 hashfile(row['reaper_log']['path'],row['reaper_log']['sha256']);cover(row['reaper_log']['path'],'service-reaper')
for row in nodes:
 if row.get('legacy_probe_log'):
  p=row['legacy_probe_log'];p=p['path'] if isinstance(p,dict) else p;cover(p,'original-probe-log')
for item in ver['source_files']:hashfile(item['path'],item['sha256'],item['bytes'])
for phase in ('formal','verifier'):
 launch=B/('p52-final-'+phase+'-launch');l=load(launch/'exit.json')
 ck('launcher-zero:'+phase,l['sha']==F and l['actual_process_returncode']==l['launcher_exit_code']==0 and l['tools_unchanged'] is True)
 for stem in ('stdout','stderr'):hashfile(launch/stem,l[stem+'_sha256']);cover(launch/stem,'launcher-'+stem);streams.append(str(launch/stem))
 for item in l['frozen_tools']:hashfile(item['frozen'],item['sha256'],item['bytes'])
 for group in ('execution','outers'):
  d=B/('p52-final-'+phase+'-execution') if group=='execution' else B/'p52-final-outers'/('p88-final-p52-'+phase)
  j=load(d/'receipt.json');rows=j.get('commands',[])
  for row in rows:command(row)
  if group=='execution':ck('top-execution-zero:'+phase,j['sha']==F and j['exit_code']==0)
report={'schema':'geo288-final-p52-original-formal-peer/1','source_sha':F,'main_source_sha':M,'scope':'Read-only original formal+independent verifier receipts and full recorded streams; no test or benchmark executed','checks':checks,'check_count':len(checks),'failures':[x for x in checks if not x['passed']],'timing_original':receipt['timing'],'records':[{k:r[k] for k in ('label','sha','mode','exit')} for r in records+controls],'proposed_separate_publication_input_roots':[str(r) for r in roots],'required_stream_publication_coverage':coverage,'unique_stream_paths_checked':len(set(streams)),'publisher_policy':'Mirrored current generic publisher path/cache/ELF exclusion for every recorded command/service/launcher stdout/stderr/stdin. Formal and verifier are separate publication inputs. No cache/file tree blanket exclusion may swallow these streams.','publication_limit':'This checks original files and planned input coverage; actual final Git archives require their own inventory/roundtrip. Full runtime inventory JSON bytes/hash and before/after equality checked; no unrelated source whole-tree rehash.','source_receipts':{str(p):digest(p.read_bytes()) for p in (R/'receipt.json',R/'execution-receipt.json',B/'p52-verifier-3d681636/receipt.json')}}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(OUT),'sha256':digest(OUT.read_bytes()),'checks':len(checks),'failures':report['failures'],'streams':len(set(streams))},ensure_ascii=False))
