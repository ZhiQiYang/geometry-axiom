"""Bind the already recorded three-suite launcher to a future clean fixed SHA."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

base = Path('/tmp/geo323-merge-20261023')
old = (base / 'run_three_baseline.py').read_text()
new = old


def replace(before, after):
    global new
    if new.count(before) != 1:
        raise RuntimeError('Expected unique launcher binding: ' + repr(before))
    new = new.replace(before, after)


replace('Run the unchanged three original diagnostic suites on clean public S; no R3/perf stage.',
        'Run the same three diagnostic suites on a future clean committed fixed SHA; no R3/perf stage.')
replace('import datetime,hashlib,importlib.util,json,os,resource,shutil,sys,traceback',
        'import argparse,datetime,hashlib,importlib.util,json,os,resource,shutil,sys,traceback')
replace("S='b2445b5a270d60fdf48b07f6edddbe91266d8aa2';REPO=Path('/tmp/g261-next323');OUT=Path('/tmp/geo323-baseline-b2445b5a-three')",
        "parser=argparse.ArgumentParser();parser.add_argument('--repo',required=True,type=Path);parser.add_argument('--sha',required=True);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()\nS=args.sha;REPO=args.repo.resolve();OUT=args.out.resolve()")
replace('geo323-original-three-suite-baseline-diagnostic/1', 'geo323-original-three-suite-fixed-diagnostic/1')
replace('candidate not applied', 'candidate committed at specified source SHA; full v3 acceptance remains separate')
replace("'candidate_applied':False", "'candidate_applied':True")
replace('Baseline must remain clean exact public S', 'Fixed source must remain clean exact specified SHA')
ast.parse(new)
out = base / 'fixed-three-driver-preparation'
out.mkdir(exist_ok=False)
(out / 'run_three_fixed.py').write_text(new)
diff = ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                 fromfile='run_three_baseline.py', tofile='run_three_fixed.py'))
(out / 'launcher-binding.diff').write_text(diff)
(out / 'PREPARATION.json').write_text(json.dumps({
    'source_driver_sha256': hashlib.sha256(old.encode()).hexdigest(),
    'bound_driver_sha256': hashlib.sha256(new.encode()).hexdigest(),
    'diff_sha256': hashlib.sha256(diff.encode()).hexdigest(),
    'prepared_only': True, 'executed': False, 'compiled': False,
    'candidate_source_still_unapplied': True,
    'scope': 'Only configurable repo/sha/fresh out and truthful receipt labels. The original three run_all selectors, expected 13/22/15, original capture/reaper, input registry, env clearing, stack, timeouts, exits and log snapshots are unchanged.'
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'out': str(out), 'bound_driver_sha256': hashlib.sha256(new.encode()).hexdigest()}))
