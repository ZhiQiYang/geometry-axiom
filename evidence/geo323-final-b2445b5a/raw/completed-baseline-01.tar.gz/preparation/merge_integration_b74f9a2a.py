"""Record authorized ordinary integration merge; stop before commit for review/resolution."""
import importlib.util,json,os
from pathlib import Path
E='b74f9a2ae7ade1555b9be45283adecc097fb76e3';OLD='307a18ec5972619161a59df82dcb7e765d137c90'
REPO=Path('/tmp/g261-next323');OUT=Path('/tmp/geo323-merge-20261023/sync-b74f9a2a')
if OUT.exists():raise RuntimeError('Use fresh merge record, never overwrite')
OUT.mkdir();spec=importlib.util.spec_from_file_location('capture','/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
rec=cap.Recorder(OUT,dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1'),OLD)
def run(argv,check=True):return rec.run(argv,cwd=REPO,timeout=600,check=check)
head=run(['git','rev-parse','HEAD'])[1].decode().strip();status=run(['git','status','--porcelain=v1','--untracked-files=all'])[1]
if head!=OLD or status:raise RuntimeError('Preserve unexpected current source/user changes')
run(['git','branch','--show-current']);run(['git','ls-files','--stage','-z']);run(['df','-B1','/tmp','/workspace'])
run(['git','fetch','--no-tags','origin',E])
fetched=run(['git','rev-parse','FETCH_HEAD'])[1].decode().strip()
if fetched!=E:raise RuntimeError('Fetched immutable target differs')
row,stdout,stderr=run(['git','merge','--no-ff','--no-commit',E],False)
if row['actual_process_returncode'] not in (0,1):raise RuntimeError('Ordinary merge failed before resolvable state')
run(['git','status','--porcelain=v1','--untracked-files=all']);unmerged=run(['git','ls-files','-u','-z'])[1];run(['git','diff','--name-only','--diff-filter=U']);run(['git','diff','--binary','--full-index']);run(['git','diff','--cached','--binary','--full-index'],False)
cap.dump(OUT/'MERGE_RESULT.json',{'old_head':OLD,'target_integration_evidence_head':E,'target_product_sha':'3d681636902371ecc528b20f51eea33e272581c9','merge_exit':row['actual_process_returncode'],'unmerged_index_bytes':len(unmerged),'candidate_applied':False,'tests_or_compile_or_regeneration_executed':False,'commands':rec.rows})
print(json.dumps({'merge_exit':row['actual_process_returncode'],'unmerged_index_bytes':len(unmerged),'record':str(OUT),'stdout':stdout.decode(),'stderr':stderr.decode()},ensure_ascii=False))
