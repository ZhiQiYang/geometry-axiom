"""Record unchanged v3 individual stages once; retain every original return code."""
import datetime,importlib.util,json,os
from pathlib import Path
S='b2445b5a270d60fdf48b07f6edddbe91266d8aa2';BASE='b74f9a2ae7ade1555b9be45283adecc097fb76e3';MAIN='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
REPO=Path('/tmp/g261-next323');TOOLS=Path('/tmp/geo323-merge-20261023/acceptance-tools-v3');OUT=Path('/tmp/geo323-baseline-b2445b5a-v3-first-five-launch');RESULT=Path('/tmp/geo323-baseline-b2445b5a-v3-r1')
if OUT.exists() or RESULT.exists():raise RuntimeError('Fresh originals only, no resampling')
OUT.mkdir();s=importlib.util.spec_from_file_location('capture','/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('NODE_OPTIONS',None);env.pop('PYTHONOPTIMIZE',None)
r=m.Recorder(OUT,env,S);rows=[]
request={'sha':S,'base':BASE,'main':MAIN,'stages':['prepare','build','compare','perf','profile'],'candidate_applied':False,'source_fixes_applied':False,'scope':'Original v3 first-five stages on synchronized baseline, not full acceptance; original 3suite red retained separately','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:env.get(k) for k in ('PATH','NODE_OPTIONS','PYTHONOPTIMIZE','CC','CFLAGS','CPPFLAGS','LDFLAGS','LANG','LC_ALL')},'commands':r.rows,'stages_completed':rows}
m.dump(OUT/'TOP_REQUEST.json',request)
for stage in request['stages']:
 argv=['python3','-B',str(TOOLS/'run.py'),'--repo',str(REPO),'--sha',S,'--base',BASE,'--main',MAIN,'--out',str(RESULT),'--heavy-lock','/tmp/g261r3/heavy.lock','--stage',stage]
 row,stdout,stderr=r.run(argv,cwd=REPO,check=False,timeout=None)
 rows.append({'stage':stage,'actual_wrapper_exit':row['actual_process_returncode'],'directory':row['directory']})
 m.dump(OUT/'PROGRESS.json',request)
 print(json.dumps(rows[-1]),flush=True)
request['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.dump(OUT/'RESULT.json',request)
raise SystemExit(1 if any(row['actual_wrapper_exit'] for row in rows) else 0)
