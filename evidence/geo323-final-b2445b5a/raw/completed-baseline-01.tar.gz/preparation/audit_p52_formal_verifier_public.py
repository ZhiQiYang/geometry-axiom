"""Read two immutable published Git packages, without extraction or subject execution."""
import hashlib,importlib.util,io,json,os,tarfile
from pathlib import Path
B=Path('/workspace/geo288-main-merge-20261023');REPO=Path('/workspace/geometry-axiom');F='3d681636902371ecc528b20f51eea33e272581c9'
OUT=Path('/tmp/geo323-merge-20261023/P52_FINAL_PUBLIC_ROUNDTRIP')
if OUT.exists():raise RuntimeError('Keep previous publication peers immutable')
OUT.mkdir();checks=[];files=[];archs=[]
spec=importlib.util.spec_from_file_location('original_capture',B/'native-final-tools/capture.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
rec=cap.Recorder(OUT,dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1'),F)
def run(argv,check=True):return rec.run(argv,cwd=REPO,timeout=120,check=check)[1]
def h(raw):return hashlib.sha256(raw).hexdigest()
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
prefix='evidence/geo261-final-3d681636/'
allcovered=set()
groups=[('formal','9df1bd614dc6caf534b102331b6b54ee2678818d',{'original_formal':Path('/tmp/g288pff'),'outer':B/'p52-final-outers/p88-final-p52-formal','launch':B/'p52-final-formal-launch','parent_execution':B/'p52-final-formal-execution'}),('verifier','d8cd2a3bdaa35b5be82af3d0d25df52ccaa6119e',{'original_verifier':B/'p52-verifier-3d681636','outer':B/'p52-final-outers/p88-final-p52-verifier','launch':B/'p52-final-verifier-launch','parent_execution':B/'p52-final-verifier-execution'})]
for kind,E,mapping in groups:
 label='p88-final-p52-'+kind;invpath=prefix+'raw/'+label+'-01.tar.gz.inventory.json';invraw=run(['git','show',E+':'+invpath]);inv=json.loads(invraw)
 archivepath=prefix+'raw/'+inv['archive'];archive=run(['git','show',E+':'+archivepath]);ck('Git-archive-byte-hash:'+kind,len(archive)==inv['bytes'] and h(archive)==inv['sha256'])
 rawdir=OUT/kind;rawdir.mkdir();(rawdir/'inventory.json').write_bytes(invraw);(rawdir/'archive.git.bin').write_bytes(archive)
 sums=run(['git','show',E+':'+prefix+'SHA256SUMS']).decode();wanted=dict((line.split('  ',1)[1],line.split('  ',1)[0]) for line in sums.splitlines())
 ck('Git-SHA256SUMS-archive:'+kind,wanted[archivepath[len(prefix):]]==h(archive));ck('Git-SHA256SUMS-inventory:'+kind,wanted[invpath[len(prefix):]]==h(invraw))
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  members=tar.getmembers();ck('unique-member-paths:'+kind,len({m.name for m in members})==len(members)==len(inv['members']))
  for member,row in zip(members,inv['members']):
   raw=tar.extractfile(member).read() if member.isfile() else b''
   ck('published-member:'+kind+':'+member.name,member.isfile() and member.name==row['path'] and len(raw)==row['bytes'] and h(raw)==row['sha256'])
   top,relative=member.name.split('/',1);p=mapping[top]/relative
   ck('producer-original-bytes:'+kind+':'+member.name,p.is_file() and raw==p.read_bytes())
   allcovered.add(str(p));files.append({'kind':kind,'archive':archivepath,'member':member.name,'producer_path':str(p),'bytes':len(raw),'sha256':h(raw)})
 receiptpath=prefix+'receipts/'+label+'.json';published=run(['git','show',E+':'+receiptpath]);original=(Path('/tmp/g288pff') if kind=='formal' else B/'p52-verifier-3d681636')/'receipt.json'
 ck('published-original-receipt-exact:'+kind,published==original.read_bytes())
 excluded=run(['git','show',E+':'+prefix+'raw/'+label+'-excluded.json']);(rawdir/'excluded.git.json').write_bytes(excluded)
 run(['git','merge-base','--is-ancestor',F,E])
 archs.append({'kind':kind,'evidence_head':E,'archive':archivepath,'bytes':len(archive),'sha256':h(archive),'member_count':len(members),'excluded_count':len(json.loads(excluded))})
actual=json.loads(Path('/tmp/geo323-merge-20261023/P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.json').read_text())
for item in actual['required_stream_publication_coverage']:ck('actual-original-stream-in-public-Git:'+item['path'],item['path'] in allcovered)
remote=run(['git','ls-remote','--exit-code','--heads','origin','refs/heads/architecture/geo261-integration-20261016']).decode().strip().split()[0]
for _,E,_ in groups:run(['git','merge-base','--is-ancestor',E,remote])
report={'schema':'geo288-final-p52-formal-verifier-public-peer/1','source_sha':F,'remote_evidence_head_at_read':remote,'archives':archs,'checks':checks,'check_count':len(checks),'failures':[x for x in checks if not x['passed']],'member_count_total':len(files),'members':files,'commands':rec.rows,'runtime_package':'Outside this report; root assigned a different peer','method':'Original c387 records immutable git show full stdout; in-memory tar member bytes/hash versus Git inventory/SHA256SUMS and completed producer originals; no source/index changes or subject execution'}
p=OUT/'PUBLIC_P52_CHECKS.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'failures':report['failures'],'members':len(files),'archives':archs,'remote_head':remote},ensure_ascii=False))
