"""Create external, unapplied C candidate from immutable Git blobs; no build/test."""
import difflib,hashlib,importlib.util,json,os
from pathlib import Path
S='5c29eba30a40f20ea5c7eb8dc139e5788235d3b6';HIST='f43e8d8b876f587c11778fa74a80b205b51396b6'
ROOT=Path('/tmp/g261-next323');OUT=Path('/tmp/geo323-merge-20261023/contact-three-field-memo-candidate-v1')
if OUT.exists():raise RuntimeError('Preserve prior candidate; use fresh path')
OUT.mkdir()
spec=importlib.util.spec_from_file_location('original_capture','/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
rec=cap.Recorder(OUT,dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1'),S)
files=('geometry-core/references.inc','geometry-app/native/reference_sources.inc','geometry-templates/woodworking/native/definition_sources.c')
blobs={}
for sha in (S,HIST):
 for rel in files:
  row,raw,stderr=rec.run(['git','show',sha+':'+rel],cwd=ROOT,source_sha=sha,source_variant='immutable-candidate-input-only')
  p=OUT/'originals'/sha/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);blobs[sha,rel]=raw
def change_once(raw,before,after):
 if raw.count(before)!=1:raise RuntimeError('Candidate anchor must hit once: '+repr(before))
 return raw.replace(before,after)
rel=files[0];before=blobs[S,rel]
after=change_once(before,b'        WoodMemberPlacement anchor;\n',b'        /* Contact keeps only its successful three-field decode; its key is independent of the full anchor. */\n        bool contact_valid;uint32_t contact_id;\n        WoodMemberPlacementContact contact;\n        WoodMemberPlacement anchor;\n')
candidates={rel:after}
rel=files[1];before=blobs[S,rel]
helper=b'''static bool reference_member_contact_read(ReferenceEval *ctx,size_t i,uint32_t id,WoodMemberPlacementContact *out)
{
    if(i>=WORLD_MAX_TIMBERS||geo_eval_is_sealed(ctx->sources))
        return wood_definition_sources_placement_contact(ctx->definition_sources,id,out);
    if(ctx->member_reads[i].contact_valid&&ctx->member_reads[i].contact_id==id){
        WoodDefinitionKey key;
        /* Every consumer retains the original placement-definition edge before using cached fields. */
        if(geo_eval_depend(ctx->sources,wood_definition_source_ref(APP_SOURCE_WOOD_DEFINITION,WOOD_DEFINITION_PLACEMENT,id,&key),
            GEO_DEPENDENCY_DEFINITION_REQUIRED)!=GEO_SOURCE_OK)return false;
        *out=ctx->member_reads[i].contact;return true;
    }
    if(!wood_definition_sources_placement_contact(ctx->definition_sources,id,out))return false;
    ctx->member_reads[i].contact=*out;ctx->member_reads[i].contact_id=id;
    ctx->member_reads[i].contact_valid=true;return true;
}
'''
after=change_once(before,b'static void reference_member_footprint_invalidate(ReferenceEval *ctx,size_t i)\n',helper+b'static void reference_member_footprint_invalidate(ReferenceEval *ctx,size_t i)\n')
after=change_once(after,b'            if(!wood_definition_sources_placement_contact(ctx->definition_sources,id,&anchor)){\n',b'            if(!reference_member_contact_read(ctx,i,id,&anchor)){\n')
candidates[rel]=after
diff=''
for rel,raw in candidates.items():
 p=OUT/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 diff+=''.join(difflib.unified_diff(blobs[S,rel].decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
(OUT/'candidate.patch').write_text(diff)
rows=[{'path':rel,'original_sha256':hashlib.sha256(blobs[S,rel]).hexdigest(),'candidate_sha256':hashlib.sha256(raw).hexdigest(),'before_bytes':len(blobs[S,rel]),'after_bytes':len(raw)} for rel,raw in candidates.items()]
manifest={'schema':'geo323-external-unapplied-contact-memo-candidate/1','base_sha':S,'historical_profile_sha':HIST,'applied':False,'compiled':False,'tested':False,'benchmarked':False,'performance_gain_claimed':False,'changed_files':rows,'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),'source_or_index_or_head_mutated':False,'no_tests_or_gates_or_threshold_or_ledger_changes':True,'original_1_3_failure_retained':True,'commands':rec.rows}
cap.dump(OUT/'CANDIDATE.json',manifest)
print(json.dumps({'out':str(OUT),'patch_sha256':manifest['patch_sha256'],'candidate_files':rows},ensure_ascii=False))
