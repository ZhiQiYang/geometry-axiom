"""Unapplied two-file refresh of existing mutation controls; no judge relaxation."""
import ast,difflib,hashlib,json
from pathlib import Path
ROOT=Path('/tmp/g261-next323');OUT=Path('/tmp/geo323-merge-20261023/test-control-refresh-candidate-v1')
if OUT.exists():raise RuntimeError('Preserve candidates')
OUT.mkdir()
def change(source,before,after):
 if source.count(before)!=1:raise RuntimeError('Unique exact old text required: '+repr(before))
 return source.replace(before,after)
files=('tests/test_geo261_load_residual.py','tests/geo261_load_residual_harness.c');original={p:(ROOT/p).read_bytes() for p in files}
py=original[files[0]].decode()
py=change(py,'if(residual_second_consumer&&!geo_placement_sources_definition(ctx->placement_sources,id,&definition))return false;', 'if(residual_second_consumer&&!geo_placement_sources_definition_header(ctx->placement_sources,id,&definition))return false;')
py=change(py,'def compile(cls, name, invalidate=True, dependencies=True, collection_state=True, source_change=None):','def compile(cls, name, invalidate=True, dependencies=True, collection_state=True, source_change=None, placement_dependency=True):')
insertion='''        definition_copy = None
        if not placement_dependency:
            definition_path = ROOT / "geometry-templates/woodworking/native/definition_sources.c"
            definition = includes(definition_path.read_text(encoding="utf-8"), definition_path)
            call = "geo_eval_source(s->graph,wood_definition_source_ref(s->token,kind,id,&key),relation,out)"
            assert definition.count(call) == 1, "Placement source control must hit exactly once"
            replacement = ("(kind==WOOD_DEFINITION_PLACEMENT&&id==3?"
                           "residual_placement_source_without_edge(s->graph,wood_definition_source_ref(s->token,kind,id,&key),relation,out):"
                           + call + ")")
            definition = definition.replace(call, replacement)
            helper = """static GeoSourceStatus residual_placement_source_without_edge(GeoEvalContext *graph,GeoSourceRef source,
    GeoDependencyKind relation,GeoSourceValue *out)
{
    /* A deliberately broken typed getter reuses a real VALID source but omits only the current consumer edge. */
    if(residual_second_consumer){
        for(size_t i=0;i<geo_eval_node_count(graph);++i){GeoSourceNodeView node;
            if(geo_eval_node_at(graph,i,&node)&&node.source.provider==source.provider&&
               node.source.key_size==source.key_size&&(!source.key_size||!memcmp(node.source.key,source.key,source.key_size))&&
               node.state==GEO_NODE_VALID&&node.value){*out=*node.value;return GEO_SOURCE_OK;}
        }
    }
    return geo_eval_source(graph,source,relation,out);
}
"""
            insertion = "static bool wd_get(WoodDefinitionSources *s,WoodDefinitionKind kind,uint32_t id,GeoDependencyKind relation,GeoSourceValue *out)"
            assert definition.count(insertion) == 1
            definition = definition.replace(insertion, helper + insertion)
            definition_copy = build.work / (name + "-definition.c")
            definition_copy.write_text(definition, encoding="utf-8")
'''
py=change(py,'        contact_path = ROOT / "geometry-templates/woodworking/native/contact_sources.c"\n',insertion+'        contact_path = ROOT / "geometry-templates/woodworking/native/contact_sources.c"\n')
py=change(py,'        unity = unity.replace(contact_path.as_posix(), contact_copy.as_posix())\n','        unity = unity.replace(contact_path.as_posix(), contact_copy.as_posix())\n        if definition_copy is not None:\n            assert unity.count(definition_path.as_posix()) == 1\n            unity = unity.replace(definition_path.as_posix(), definition_copy.as_posix())\n')
old='''        self.passes("consumers")
        exe = self.compile("cross-consumer", dependencies=False)
        result = self.case("consumers", exe)
        self.assertEqual(1, result.returncode, result.stdout + result.stderr)
        self.assertIn("ASSERT:cross-consumer-placement-edge-missing ", result.stderr)
        print("跨 consumer 共用突變：exit=1；" + next(s for s in result.stderr.splitlines() if "ASSERT:cross-" in s), flush=True)
        self.passes("consumers")
'''
new='''        control, marker = "placement-source-second-consumer-edge", "cross-consumer-placement-edge-missing"
        self.passes("consumers", phase="baseline", control=control)
        exe = self.compile("cross-consumer", placement_dependency=False)
        result = self.case("consumers", exe, phase="mutant", control=control, expected_assertion=marker)
        self.assertEqual(1, result.returncode, result.stdout + result.stderr)
        self.assertIn("ASSERT:cross-consumer-placement-edge-missing ", result.stderr)
        self.assertEqual(1, result.stderr.count("ASSERT:"), result.stderr)
        print("跨 consumer 共用突變：exit=1；" + next(s for s in result.stderr.splitlines() if "ASSERT:cross-" in s), flush=True)
        self.passes("consumers", phase="restored", control=control)
'''
py=change(py,old,new);ast.parse(py)
c=original[files[1]].decode()
old='''    (void)ref;Probe *probe=user;WoodContactSourceFacts facts;WoodContactSourceRequest request={1,false,NULL};
    if(!reference_contact_facts(probe->evaluation,graph,&request,&facts))return false;
'''
new='''    Probe *probe=user;uint32_t consumer;WoodContactSourceFacts facts;WoodContactSourceRequest request={1,false,NULL};
    if(ref->key_size!=sizeof consumer)return false;memcpy(&consumer,ref->key,sizeof consumer);
    bool previous=residual_second_consumer;residual_second_consumer=consumer==2;
    bool ok=reference_contact_facts(probe->evaluation,graph,&request,&facts);
    residual_second_consumer=previous;
    if(!ok)return false;
'''
c=change(c,old,new)
candidate={files[0]:py.encode(),files[1]:c.encode()};diff='';rows=[]
for rel,data in candidate.items():
 p=OUT/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 diff+=''.join(difflib.unified_diff(original[rel].decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 rows.append({'path':rel,'original_sha256':hashlib.sha256(original[rel]).hexdigest(),'candidate_sha256':hashlib.sha256(data).hexdigest()})
(OUT/'candidate.patch').write_text(diff)
methods=lambda raw:[n.name for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
manifest={'schema':'geo323-unapplied-control-refresh/1','base_sha':'b2445b5a270d60fdf48b07f6edddbe91266d8aa2','applied':False,'compiled':False,'tested':False,'product_source_changed':False,'test_methods_before':methods(original[files[0]]),'test_methods_after':methods(py),'same_13_test_methods':methods(original[files[0]])==methods(py),'original_exact_placement_assertion_preserved':new is not None and 'self.assertIn("ASSERT:cross-consumer-placement-edge-missing ", result.stderr)' in py,'original_H_three_site_counterfactual_implementation_preserved': 'assert sources.count(anchor) == 3' in py,'new_counterfactual':'only second true consumer, actual typed PLACEMENT/id3, existing complete-key VALID node value; no private active/graph writes, no memo editing or synthetic values; original decoder remains','original_failures_retained':'/tmp/geo323-baseline-b2445b5a-three','patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),'files':rows,'thresholds_expected_ledger_or_axiom_changed':False}
(OUT/'CANDIDATE.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'out':str(OUT),'patch_sha256':manifest['patch_sha256'],'same_13_test_methods':manifest['same_13_test_methods']},ensure_ascii=False))
