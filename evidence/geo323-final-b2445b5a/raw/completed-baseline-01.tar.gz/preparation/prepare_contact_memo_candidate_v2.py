"""Prepare unapplied v2; retain the original unique placement-dependency judge site."""
import difflib,hashlib,json
from pathlib import Path
S='5c29eba30a40f20ea5c7eb8dc139e5788235d3b6'
V1=Path('/tmp/geo323-merge-20261023/contact-three-field-memo-candidate-v1')
OUT=V1.with_name('contact-three-field-memo-candidate-v2')
if OUT.exists():raise RuntimeError('Preserve old preparation outputs')
OUT.mkdir()
def change(raw,before,after):
 if raw.count(before)!=1:raise RuntimeError('Unique anchor required: '+repr(before))
 return raw.replace(before,after)
files=('geometry-core/references.inc','geometry-app/native/reference_sources.inc')
original={rel:(V1/'originals'/S/rel).read_bytes() for rel in files}
candidates={files[0]:(V1/'candidate'/files[0]).read_bytes()}
depend=b'''static bool reference_member_placement_depend(ReferenceEval *ctx,uint32_t id)
{
    WoodDefinitionKey key;
    if(geo_eval_depend(ctx->sources,wood_definition_source_ref(APP_SOURCE_WOOD_DEFINITION,WOOD_DEFINITION_PLACEMENT,id,&key),
            GEO_DEPENDENCY_DEFINITION_REQUIRED)!=GEO_SOURCE_OK)return false;
    return true;
}
static bool reference_member_contact_read(ReferenceEval *ctx,size_t i,uint32_t id,WoodMemberPlacementContact *out)
{
    if(i>=WORLD_MAX_TIMBERS||geo_eval_is_sealed(ctx->sources))
        return wood_definition_sources_placement_contact(ctx->definition_sources,id,out);
    if(ctx->member_reads[i].contact_valid&&ctx->member_reads[i].contact_id==id){
        /* Use the original shared edge site for every current consumer. */
        if(!reference_member_placement_depend(ctx,id))return false;
        *out=ctx->member_reads[i].contact;return true;
    }
    if(!wood_definition_sources_placement_contact(ctx->definition_sources,id,out))return false;
    ctx->member_reads[i].contact=*out;ctx->member_reads[i].contact_id=id;
    ctx->member_reads[i].contact_valid=true;return true;
}
'''
before=original[files[1]]
after=change(before,b'static void reference_member_footprint_invalidate(ReferenceEval *ctx,size_t i)\n',depend+b'static void reference_member_footprint_invalidate(ReferenceEval *ctx,size_t i)\n')
# Read the exact original block rather than relying on an escaped Chinese literal.
start=before.index(b'        WoodDefinitionKey key;\n',before.index(b'static bool reference_member_anchor_read('))
end=before.index(b'        *out=ctx->member_reads[i].anchor;',start)
old=before[start:end]
after=change(after,old,b'        if(!reference_member_placement_depend(ctx,id))return false;\n')
after=change(after,b'            if(!wood_definition_sources_placement_contact(ctx->definition_sources,id,&anchor)){\n',b'            if(!reference_member_contact_read(ctx,i,id,&anchor)){\n')
candidates[files[1]]=after
anchor=b'geo_eval_depend(ctx->sources,wood_definition_source_ref(APP_SOURCE_WOOD_DEFINITION,WOOD_DEFINITION_PLACEMENT,id,&key),\n            GEO_DEPENDENCY_DEFINITION_REQUIRED)'
if after.count(anchor)!=1 or after.count(b'if(geo_eval_depend(ctx->sources,')!=before.count(b'if(geo_eval_depend(ctx->sources,'):raise RuntimeError('Do not duplicate or retire original mutation judge sites')
diff='';rows=[]
for rel,raw in candidates.items():
 p=OUT/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 diff+=''.join(difflib.unified_diff(original[rel].decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 rows.append({'path':rel,'original_sha256':hashlib.sha256(original[rel]).hexdigest(),'candidate_sha256':hashlib.sha256(raw).hexdigest(),'before_bytes':len(original[rel]),'after_bytes':len(raw)})
(OUT/'candidate.patch').write_text(diff)
manifest={'schema':'geo323-external-unapplied-contact-memo-candidate/2','base_sha':S,'applied':False,'compiled':False,'tested':False,'benchmarked':False,'performance_gain_claimed':False,'changed_files':rows,'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),'original_placement_dependency_single_anchor_count':after.count(anchor),'broad_existing_if_depend_anchor_count_before':before.count(b'if(geo_eval_depend(ctx->sources,'),'broad_existing_if_depend_anchor_count_after':after.count(b'if(geo_eval_depend(ctx->sources,'),'common_dependency_helper':'Original exact kind/source/order operation moved intact and called by both full-anchor and contact memo hits, rather than adding an unprotected duplicate site','v1_known_static_limitation':'v1 added a second literal placement-depend site, breaking old unique mutation anchors. Kept v1 unmodified; v2 preserves a single shared original site.','source_or_index_or_head_mutated':False,'no_tests_or_gates_or_threshold_or_ledger_changes':True,'original_1_3_failure_retained':True}
(OUT/'CANDIDATE.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'out':str(OUT),'patch_sha256':manifest['patch_sha256'],'files':rows,'original_unique_anchor':after.count(anchor)},ensure_ascii=False))
