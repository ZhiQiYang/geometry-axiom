# #323 下一輪量測前的靜態準備

本文件沒有執行 compiler、profile、Chrome 或 benchmark；沒有改 source、shared files、index 或 HEAD，也沒有宣稱新性能結果。產品仍是 5c29eba30a40f20ea5c7eb8dc139e5788235d3b6，原 N64 1.7457212386 > 1.3 紅燈與 source64/source32 4.4704 ≤ 4.5 原樣保留。

目前 contact facts 保留 #288 的輕量 `wood_definition_sources_placement_contact`，每次仍經 `wd_reader` → `geo_eval_source` 取 typed definition，再驗 schema、encoded id、完整格式尾端與三個字串邊界。#323 的 full-anchor memo 沒有取代這條路；不能憑原 full-reader 的收益推論這個新合流已達 1.3。footprint memo 可以省 BOX-to-UV 投影，仍逐 consumer 登記 value dependency；contact definition 的解碼與 source 呼叫仍在每個 facts 收集迴圈中。這只是具名候選成本，未由新 profile 證明主因。

先以主代理排程的 13／22／15 原 suite 證正確性與原反證，再用 v3 原量測規格固定 base/main/final 量 175 dumps、36 timings、四 profiles。不可因先看到紅就自行重抽，不能挑綠樣本，也不先改共享產品碼。

若新 profile 確認 contact decoder／graph lookup 為殘餘熱點，下一個可以單獨審查的候選是同一 ReferenceEval 中獨立儲存成功 contact 三欄，而非把 full anchor reader 再放回 contact path。hit 仍逐 consumer 呼叫相同 `geo_eval_depend`，kind 必為 DEFINITION_REQUIRED、順序與當前 consumer error context 不變；sealed path 繼續原 reader。錯誤不得 cache；slot-id 更換成功後仍要統一失效舊 anchor／footprint；contact 自己的 key 不可污染 definition.id 或 pose_id。必須先釘同 id 刪除重建、typed kind／owner/version、同 World 位址重用、graph reset/re-register 與多 consumer diagnostics，再用各自精準撤回 0／1／0 證明，不能靠複合故障遮掉單站漏邊。

上述候選尚未實作。共同檔目前已交 #314／combined／#318，任何新增 shared 變更須依主代理棒序，不能在已交棒分支悄悄另寫。
