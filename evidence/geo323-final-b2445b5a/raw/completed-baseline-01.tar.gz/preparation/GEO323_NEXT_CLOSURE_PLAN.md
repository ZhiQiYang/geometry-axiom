# #323 新來源的最短驗證計畫（只讀準備）

本計畫沒有執行測試、編譯、scan、profile、benchmark、clone、fetch 或任何來源／index 寫入。讀的是 root 已 fresh-fetch 的 handoff `7bd61a43210bbad0abf95709e1a0205cd8760cac`；最新 #323 審查是 2026-10-23 08:37:05 UTC、head `307a18e`。不是先前 head239040f。審查已承認 base22ad28f/head307a 可合併；仍阻擋的是實際同步樹未驗與 N64 1.3 要求未達，不能再稱「仍有 base 衝突」。

## 已測與未測的身分

| 身分 | 真實可採範圍 |
|---|---|
| 歷史 F `f43e8d8b876f587c11778fa74a80b205b51396b6` | 在舊 base546e2eb/mainadbaebf9 已有完整 native 5192 pass/0 fail/1原允許skip、必要八套674、PF3 20/19/20、175 A/B/C、36 timings、4 gprof、三條架構與既有帳本資料。wrapper1是量化目標未全達，不能稱整體綠。 |
| 目前產品／測試 S `5c29eba30a40f20ea5c7eb8dc139e5788235d3b6` | 普通 merge 239040fd+22ad28f；只有靜態核與 #318 靜審。新 raw pending 控制、13/22/15 三套、完整native、八套、PF3、A/B/C、性能/profile、mutate freshness／架構，**全未在此 S 執行**。 |
| evidence E `307a18ec5972619161a59df82dcb7e765d137c90` | 只增 postmerge 進度與操作觀察；不是新受驗來源。 |
| prbody D `187fb27f456193ebff4649e392db77905f68a093` | 已有本輪P/E/未跑表，與 live PR 舊正文不同；最新審查引用仍待從239040f更新為307a18e。未宣稱live正文已套用。 |
| 未來 final F323 | 尚未固定。須由 root 決定 final288/base與 source 棒同步後，完成帳本／架構衍生資料再固定；不能把祖先相容當成同SHA動態驗收。 |

最新審查要求重跑完整 native、必要八套、PF3、A/B/C、性能／profile、架構與帳本。先跑三套是找錯的最快前置，不能取代這份正式清單。下游 #314／combined／#318 已持共享 source 棒，不可因這份舊 profile 就在 #323 分支另改 current_geometry.c／reference_sources.inc／mutate／expected。

## 最短執行順序（現在全部待排程）

1. root 先完成 #288；本代理下一個已指定正式槽是 **#288 新F四項native partial**，不是 #323。P88 formal三輪及其一次rAF反證仍獨占heavy，這些都不可搶跑。#323 的 run_all 也不可與 #288 native4 同時開，兩者共用 `/tmp/geometry-tests` 原 run_all/build 鎖；grid則有自己的TMP/runtime輸出。
2. 到 #323 槽時先由 root 決定同步後精確 source/base，普通 merge，唯讀核所有 closure 差異。現S對22ad的非evidence差異包含 current_geometry.c、reference_sources.inc、world_validation.inc、references.inc、contact_sources.c、三套harness及PF3/run_all/expected；不是單一純metadata變更。新F288相對22ad的P88 JS及架構 metadata可以分開界定，但不能藉此跳過S自己的C語意合流重驗。
3. 最快診斷用原 `python3 -B tests/run_all.py --build --only py:test_geo261_load_residual --only py:test_geo261_host_facts_authority --only py:test_geo261_contact_sources`，stack16MiB、原c387/reaper與既有三個 `GEO261_*_EXECUTION_LOG` 指向fresh外部目錄；靜態登錄13/22/15不是實跑數。保每站baseline/mutant/restored原stdout/stderr/rc，不能只交Python總綠。
4. 核新 `cache-footprint-source` 的精確 `footprint-hit-raw-snapshot`：真provider warm、撤唯一 `if(deferred)raw[i].pending=fact->footprint_valid?0:2;`、原 `ASSERT:footprint-cache-hit-preserves-source-out` exit1、恢復0。其他H四站的逐consumer省邊／錯kind／order與W collection逐feature控制照原工具，不以首個assertion掩蓋後站。placement-key單刪維持equivalent 0/0/0，配對控制仍只證第二防線。
5. 集中修完真缺陷後才由root跑原 `python3 tests/mutate.py --check`；未知是否stale，不能預判。stale才整份重產，最後source棒統一一次。架構依原四檔schema刷新，跑原三裁判。這些完畢後固定並正常push可解析F323，不把出版E當產品F。
6. 在同一final F323，沿既有v3一次跑正式八stage：prepare→build→compare→perf→profile→required-eight→pf3→native，紅燈全部保留且收完，不重抽。**不需要另外發明一份175場景或36樣本工具**；v3只把base/main顯式綁定，原verify/profile/門檻不改。再封同F三條原architecture及mutation check的命令/原exit/完整streams/hash。
7. 原formal清單完成後才做資料封包／逐member bytes-hash核、正常push自己source/evidence與-prbody。三套早期診斷若跑在未來F之前，保其原S，不轉標F。#318第二階段審查需取得真正execution F及全部原控制輸出，靜審5c不能直接當動態審過。

既有v3的未執行命令樣式：

```sh
python3 -B /tmp/geo323-merge-20261023/acceptance-tools-v3/run.py \
  --repo <root指定乾淨repo> --sha <完整F323> \
  --base <root指定final288原比較基底> --main <明載的原main比較SHA> \
  --out <fresh外部out> --heavy-lock /tmp/g261r3/heavy.lock --stage all
```

這是佔位說明，未執行。v3 README開頭保留v2舊範例，實際入口應依 `V3-ADAPTATION.md`，不得誤用舊run.py或默默退回base546e2eb。原 PROMPT-B 的main性能比較點是adbaebf9；若 #288 之後入main，不可把它靜默改成含GEO的main而改變1.3意義。需顯式記原比較點與目前main角色；任何改比較定義先由root依原授權決定，不能靠新分母把紅變綠。

三條架構原命令仍是：

```sh
python3 -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json
python3 -B tests/test_architecture_contract.py
python3 -B tests/test_product_architecture.py
```

## 原性能／profile能說與不能說的事

已唯讀核原 `receipt.json`、`performance.json` 36筆及四份gprof：profile bytes/hash均與原profile-counts一致，36原程序都0，中位數重算一致。完整摘錄在 `GEO323_HISTORICAL_PERFORMANCE_EXTRACT.json`，沒有重新量測。

| 原N | fix/main | fix/base |
|---|---:|---:|
|16|1.3160608154|0.9873384860|
|32|1.1959167105|0.8331570113|
|48|1.3876558651|0.7329361402|
|64|**1.7457212386 >1.3**|0.6832603901|

原fix的geo_eval_source N32=80273、N64=358854，4.4704196928≤4.5；base同項為450098／2980967。N64原fix還有geo_eval_depend1968612、contact_order2729508、geo_source_find_node2327466、geo_source_find_edge1638811；舊gprof樣本總約0.50s、每樣本0.01s，百分比不能當精確因果。

原fix `wd_read` N64=370680、full placement decoder只2157次，但 `reference_member_anchor_read` 908057次。這是舊full-anchor memo結構的結果，**不能套到S5c**：S5c已保留 #288 `wood_definition_sources_placement_contact` 輕量解碼，每次contact consumer仍走原source並逐consumer depend；舊讀取減量並不證新路徑已達1.3。反過來，也不能憑舊1.745就斷定新S仍同值。

contact_order已含既有per-query id index（保duplicate earliest/last語意與超容量原fallback），不是還沒做的優化。不要只因呼叫數多，再重做相同index或改D11排序。下一次profile若證contact解碼／source graph查找確有剩餘成本，再討論獨立成功contact三欄memo或其餘限定成本；錯誤不cache、逐consumer kind/order/error context、slot/version/owner/reset邊界都須先有真控制。**本計畫不授權或實作這個候選。**

## 仍需留意的缺口

- 新pending撤回0/1/0尚未跑；成功contact decode換slot時的新增invalidator路徑，以及cache-hit depend失敗時prefix flush，現有靜審只證碼有保留，不能冒稱各新增分支都有獨立動態反證。先用原三套實際coverage與streams判斷是否還缺具名站，不憑猜測再改shared。
- 新final base的graph/value/loader closure與新native／PF3／架構／ledger目前都未受驗。full原native不能縮成三套；必要八套是原source_index、candidate_cache、graph_product、assembly_graph_product、bridge_integrity、c:integrity、core:run_tests加load_residual，不是13/22/15三套的別名。
- N64≤1.3繼續是紅門檻；本代理不自行移交 #300 或宣稱交付完成。若正式新量測仍未達，保原紅並在QUESTIONS/正文列具名scope選項交root依使用者指示處理，其他項照跑。
- 原PROMPT有維護者WSL重測之描述；目前使用者已明確要求全在雲端，不能把驗收推回使用者電腦作卡點。Linux原結果、MSVC未跑及原GDI允許skip應分欄照實列。
- 原S/final/baseline與完整streams的角色不可混：帳本實跑SHA、架構實跑SHA、產品F、evidenceE與prbodyD各自列，不轉標祖先。

舊完整輪耗時只供排程參考：build約83s、A/B/C約120s、36timings約20s、4profile約24s、必要八套約185s、PF3約780s、native約1973s；合計約53分鐘。這是舊F原紀錄，不是新S預估通過或新timeout。所有效能樣本／profile期間仍需root獨占時槽，封包與其他測試不要並跑。
