#!/usr/bin/env python3
"""One immutable publication package; original directories remain untouched."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
ROOT=Path('/tmp/pr338-b3-p189');DEST=ROOT/'delivery/evidence/geo337-b3-p189-20261029'
DEST.mkdir(parents=True,exist_ok=False)
def digest(data):return hashlib.sha256(data).hexdigest()
files=[]
for directory in ('formal','formal-v2','controls','build-environment','preflight','tools'):
    files += [p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += list(ROOT.glob('*.stdout'))+list(ROOT.glob('*.stderr'))
manifest=[]
for path in sorted(files):
    body=path.read_bytes();manifest.append({'path':str(path.relative_to(ROOT)),'bytes':len(body),'sha256':digest(body),'mode':oct(path.stat().st_mode&0o777)})
(DEST/'RAW_MANIFEST.json').write_text(json.dumps({'schema':'pr338-b3-raw/1','files':manifest},indent=2)+'\n')
archive=DEST/'B3_ORIGINAL_STREAMS.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(mode='w|',fileobj=compressed) as tar:
            for path in sorted(files):tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    actual={member.name:tar.extractfile(member).read() for member in tar.getmembers() if member.isfile()}
assert set(actual)=={x['path'] for x in manifest}
for item in manifest:assert len(actual[item['path']])==item['bytes'] and digest(actual[item['path']])==item['sha256']
for name in ('exact_p189.py','run_p189.py','run_timing.py','replay_exact.py','run_controls.py','p189_verify.original.py','scale_compare2.py','gen_scene.py','ORIGINAL_TOOLS.json','verify_build_environment.py'):
    dest=DEST/'tools'/name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(ROOT/'tools'/name,dest)
for source,name in [('formal-v2/receipt.json','P189_TIMING.json'),('formal-v2/exact-result.json','P189_EXACT.json'),
        ('formal-v2/build-closure.json','BUILD_CLOSURE.json'),('formal-v2/archive-closure.json','SOURCE_MANIFEST.json'),
        ('formal-v2/scene-inventory.json','SCENE_MANIFEST.json'),('formal-v2/strict-original-policy-red.json','STRICT_RED.json'),
        ('formal-v2/L-to-M-actual-build-input.diff','L_TO_M_INPUT.diff'),('controls/RESULT.json','CONTROLS.json'),
        ('build-environment/RESULT.json','BUILD_ENVIRONMENT.json'),('formal-v2/provenance.json','PROVENANCE.json'),
        ('formal-v2/samples.tsv','SAMPLES.tsv'),('formal-v2/timing-outer-result.json','TIMING_OUTER.json')]:
    shutil.copyfile(ROOT/source,DEST/name)
receipt=json.loads((ROOT/'formal-v2/receipt.json').read_bytes())
timing=json.loads((ROOT/'formal-v2/timing-outer-result.json').read_bytes())
exact=json.loads((ROOT/'formal-v2/exact-result.json').read_bytes())
controls=json.loads((ROOT/'controls/RESULT.json').read_bytes())
assert receipt['pass'] and exact['exit']==0 and controls['exit']==0 and timing['actual_process_returncode']==0
table='\n'.join(f"| {r['n']} | {r['medians']['main']:.4f} | {r['medians']['base']:.4f} | {r['medians']['fix']:.4f} | {r['fix_main']:.15f} | 0 |" for r in receipt['ratios'])
report=f'''# B3：P-189 已實跑通過（2026-10-29 台北）

本輪只處理 PR #338 B3；沒有修改產品、測試、公理或決策佇列，沒有重抽 R8 performance。B1 缺失的三個原 R8 ELF 仍是另一件事，本輪 P189 新建的 fix bridge 不得用來頂替。

## 來源與終態

- 實際 execution SHA：`0ae1728c2309e1d670369289a6b8da059fa63a50`（M）。
- 已採入產品 F：`cbf0fb621888596aa14ad5f2349b503e23b1b72d`；M 與 F 除 evidence 外差異為空，證據記在 BUILD_CLOSURE.json。
- 固定 main：`adbaebf9c73ea6801d7b4d5214e4b846b132923b`；固定歷史 base：`3e600772076465fc65a26ac09055028301c0fb0b`。
- 精確比較：175 場景（原工具的 171 個固定 base 根目錄場景＋N16/32/48/64 生成場景）、main/base/fix 共 525 個原生程序。main→M 175 對及額外 base→M 175 對皆 exit 0；只有三個指定場景允許唯一指定位置的新增文字，其餘 172 場景逐 byte 相同。
- 比較編譯及執行 outer：exit 0，90.285674 秒。原生程序每次 timeout 900 秒，stack 16384 KiB，原參數不變。
- 計時 outer：exit 0；UTC 2026-10-28T19:08:30Z 起，78.557281 秒。36/36 個樣本 returncode 0、load_ok true、timeout false；原每樣本 600 秒及 driver 1800 秒時限不變。
- 獨立 subprocess 反證：3 baseline exit 0、27 個指定負例 exit 1、3 restored exit 0。這是對本輪真原生輸出副本的比較器反證，沒有假稱重新執行 33 次原生產品。

## 精確三差政策

依 [決策佇列 887–891、900–914](https://github.com/ZhiQiYang/geometry-axiom/blob/0ae1728c2309e1d670369289a6b8da059fa63a50/決策佇列.md#L887) 與使用者本輪直接指示；不再列待批准。

| 場景 | error 既有行號／料件 | 唯一可新增 UTF-8 文字 |
|---|---|---|
| `_role_priority_mutant.scene` | line 8／角材 1 | `——定位邊 e2 [2000,4000] mm，低端超出 [0,2000] mm` |
| `_s1_p8_l_room_primary_through_reflex_extension.scene` | line 15／角材 3 | `——定位邊 e3 [3000,4800] mm，低端超出 [27,3000] mm` |
| `_s1_p8b_l_room_primary_through_reflex_extension_hi.scene` | line 12／角材 3 | `——定位邊 e1 [0,1800] mm，高端超出 [1800,4773] mm` |

比較器釘住場景原 bytes 的 SHA256、舊 stdout 首個完整 error response、line/member、固定 JSON 欄位次序及下一個完整 dump 原 bytes。新增文字只可接在 `footprint 超出定位邊範圍` 後、error 字串結束前。stderr 同樣釘住本輪共用場景路徑、行號、舊診斷與唯一結尾位置；新增字串以外 stdout/stderr 全部 bytes 與 returncode 均須相同。沒有 regex 正規化、JSON 重序列化或整類訊息忽略。

每個場景都用真 subprocess 檢查：wrong_text、wrong_position、fourth_difference、other_dump_byte、returncode、stderr_wrong_text、stderr_wrong_position、scene_input_changed、fourth_unlisted_scene，各具名 exit 1；恢復原輸出 exit 0。CONTROLS.json 與原包保留完整命令、stdout/stderr、exit。

## 為何本次需要新 P189 timing

已公開 timing 原件實際 execution 是 L=`7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`，不是 F9。原 F9 庫存只記準備，沒有可採入的 F9 P189 計時終態。L→M 的 compiler 實際輸入有三檔變化：`geometry-core/kernel/source.c`（來源索引 probe／hint）、`geometry-core/references.inc`（candidate 初始化路徑）、`geometry-templates/woodworking/native/contact_world.c`（排序／去重索引）。完整 diff 在 L_TO_M_INPUT.diff；這些直接影響載入計算，不能以「F9→F 兩檔不相關」概括沿用 L。

因此本次只重跑受影響的 P189，一次 36 樣本；不是重抽 R8，也不把 L timing-only 綠升格為 F。generator／timing script／原 driver SHA256 全與 L 原 provenance 相同。計時直接執行原 driver 的未修改 AST tail，保持 N 順序 16/32/48/64、3 rounds、main/base/fix → fix/base/main → main/base/fix，原 samples.tsv 四位小數的 median 判定不變；沒有丟樣本或選最好輪。

| N | main median 秒 | base median 秒 | fix median 秒 | fix/main（門檻 ≤2） | exit |
|---|---:|---:|---:|---:|---:|
{table}

## 完整輸入／裁判／建置閉包

- SOURCE_MANIFEST.json：185 個實際產品 include 檔，2,142,456 bytes，逐檔 Git blob／SHA256／mode 綁定 M；私有副本及 donor 的 `gcc -std=c11 -O2 -E geometry-web/web_bridge.c` 完整 stdout 相同。
- BUILD_CLOSURE.json：gcc `-MM` 的全部直接／間接 user includes、上述三檔 L→M 真變動，以及 F→M 非 evidence 空差。`tests/test_geo314_commit_paths.py`、`決策佇列.md` 均不在編譯、生成器或計時執行輸入。
- BUILD_ENVIRONMENT.json：完整預處理原流、系統 headers、gcc／cc1／動態 loader／libc／libm hashes。編譯原命令 `gcc -std=c11 -O2 geometry-web/web_bridge.c -o bridge -lm` 不變；gcc Debian 14.2.0-19。
- SCENE_MANIFEST.json：固定 base 的完整 171 個根場景與4生成場景逐檔 hash；生成器 `gen_scene.py` hash `347142beb7aa06c39969cd5bce35bacddc0734046eb7853e84d96f1ff9ef7c91`。
- PROVENANCE.json：main/base 原 ELF bytes、0700 mode、source SHA 和原建置 command/archive streams 雜湊均核對；只 copy，不重新編譯。fix 是本輪 M 的新 build；它不是 B1 的 R8 原件。
- 原 timing script hash `086805189dc5596853c0c52ca05dd2cbf5c3a605792023366004426ab61a4dd1`；原 driver hash `efafef38357088710ab69ab198931fc845350bfe72201b5eaec52da5681c63f4`。新精確 comparator 與執行器的 hashes 在 PROVENANCE.json／TIMING_OUTER.json。
- 所有實際 command/cwd/env/完整 stdin/stdout/stderr/exit/source、36 未四捨五入原始樣本、script source 均在 B3_ORIGINAL_STREAMS.tar.gz，RAW_MANIFEST.json 逐檔核 hash；外層摘要不取代原件。

## 原紅及環境失敗保留

- [歷史 L 完整 P189 原件](https://github.com/ZhiQiYang/geometry-axiom/tree/0ae1728c2309e1d670369289a6b8da059fa63a50/evidence/geo337-train-20261024/final-L-performance-complete/p189)：driver=1、passed=false；[L timing-only](https://github.com/ZhiQiYang/geometry-axiom/tree/0ae1728c2309e1d670369289a6b8da059fa63a50/evidence/geo337-train-20261024/final-L-performance-complete/p189-timing) 仍是 overall_P189_passed=false。原件不改、不移標。
- 本輪 STRICT_RED.json 也保留未套政策的 exact strict exit 1：三個唯一場景的 stdout/stderr 差，main/base 各一組（6 pair records，非新增六場景）。精確政策結果另記 P189_EXACT.json。
- 準備 attempt1 原 git archive 因 promisor fetch 的 pack 寫入 ENOSPC，command exit128、outer1、98.414488秒；當時未編譯／未計時、0樣本。Git 自行清掉其失敗臨時 pack 後可用空間回復；我們未刪任何既有 Git objects／舊收據。全部原錯誤保留 formal/ 和 formal.stderr。attempt2 改從已 materialize 的 M 私有複製編譯 closure，逐 blob及完整預處理驗同，不改任何容量／時限門檻。

## 實際指令

```text
GEO_P189_COMPARE_ONLY=1 python3 -B /tmp/pr338-b3-p189/tools/run_p189.py
# exit 0（編譯＋175場景三方比較；formal-v2/）
python3 -B /tmp/pr338-b3-p189/tools/run_timing.py
# exit 0（原計時尾段，36樣本；formal-v2/）
python3 -B /tmp/pr338-b3-p189/tools/run_controls.py
# exit 0（33 真 process；各負例 exit1，controls/）
python3 -B /tmp/pr338-b3-p189/tools/verify_build_environment.py
# exit 0（預處理／系統建置閉包，build-environment/）
```

範圍：B3 可採入通過；B1 whole-memo 未於本輪執行，B2 沿用閉包由另一工作線交付。七項正式 gate 不因新增 evidence 重跑；不宣稱本輪完成全部 PR #338 合併條件，不合併 PR。
'''
(DEST/'B3.md').write_text(report)
summary={'schema':'pr338-b3-delivery/1','execution_sha':'0ae1728c2309e1d670369289a6b8da059fa63a50',
    'exact_exit':0,'timing_exit':0,'controls_exit':0,'build_environment_exit':0,
    'strict_original_policy_exit':1,'scene_count':175,'native_executions':525,'samples':36,'ratios':receipt['ratios'],
    'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'raw_file_count':len(manifest),'all_members_verified':True}}
(DEST/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
checks=[f'{digest(p.read_bytes())}  {p.relative_to(DEST)}' for p in sorted(DEST.rglob('*')) if p.is_file()]
(DEST/'SHA256SUMS').write_text('\n'.join(checks)+'\n')
print(json.dumps(summary,indent=2))
