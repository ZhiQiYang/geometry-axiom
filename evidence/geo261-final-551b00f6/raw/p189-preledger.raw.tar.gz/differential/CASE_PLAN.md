# W placement contact 窄 view：唯讀 layout 與差分診斷計畫

只讀原 `definition_sources.c/.h`、`member_placement.h`、`member_reference.h` 與既有 harness；未改產品／原 full decoder 測試，未編譯／執行。待候選 ready 後再擷取真實新函式，不先猜測其實作或宣稱通過。

## Wire layout：從原 writer/read 逐項相加

所有整數都是 writer 明寫的 big-endian 寬度，並非 C struct offset。下表 offset 為 0 起、區間含首不含尾。L0/L1/L2 是三段 wire 長度，不是 strlen。

| offset | bytes | 原欄位 |
|---:|---:|---|
| 0 | 4 | id |
| 4 | 4 | placement_id |
| 8 | 4 | anchor_kind |
| 12 | 4 | span_mode |
| 16 | 4 | length_direction；讀完 at=20 |
| 20 | 4 | depth_side |
| 24 | 16 | uv.u / uv.v |
| 40 | 4 | ref_grid |
| 44 | 4 | ref_grid_axis |
| 48 | 8 | ref_grid_index |
| 56 | 1 | ref_grid_has_band |
| 57 | 8 | ref_grid_band |
| 65 | 36 | ref_rule：grid_id4＋system_id4＋rule_key4＋cell[2]16＋axis4＋inner_index4 |
| 101 | 4 | ref_hole |
| 105 | 4 | ref_edge |
| 109 | 1 | has_through |
| 110 | 8 | through |
| 118 | 4 | ref_guide |
| 122 | 4 | ref_timber |
| 126 | 1 | ref_is_timber |
| 127 | 4 | ref_derived_key 長度 L0；所以從 at20 bounded skip107 正確 |
| 131 | L0 | ref_derived_key 原 bytes |
| 131＋L0 | 8 | order |
| 139＋L0 | 1 | has_between |
| 140＋L0 | 16 | between[0] kind/hole/edge/timber，各4 |
| 156＋L0 | 4 | between[0].key 長度 L1 |
| 160＋L0 | L1 | between[0].key 原 bytes |
| 160＋L0＋L1 | 16 | between[1] kind/hole/edge/timber，各4 |
| 176＋L0＋L1 | 4 | between[1].key 長度 L2 |
| 180＋L0＋L1 | L2 | between[1].key 原 bytes |

空字串的 exact size 是 **180**；正常最大三段各511時是 **1713**。`has_between=false` 仍編碼／解碼兩段 between 固定欄與文字；不能因 inactive 省掉驗證。

## 原 full API 真正的接受集合

`wood_definition_sources_placement` 先以相同 `wd_reader(...WOOD_DEFINITION_PLACEMENT,id,...)` 取得一次 returned definition：同 graph、provider token、5-byte kind＋u32 id source key、`GEO_DEPENDENCY_DEFINITION_REQUIRED`。`wd_reader` 要求 source成功、value.kind=DEFINITION、非NULL且精確相符的 schema `wood.member.placement/1`，以及 content_size非0時 content非NULL。

full decoder 在 local 零值 `WoodMemberPlacement` 讀完所有欄位，最後只檢查 reader.ok、reader.at==reader.size、wire id==requested id，成功才賦給 out。三段 text 都各自檢查長度 `n<512`、`n<=remaining` 並 consume恰好n bytes。

**沒有其他 semantic admission**：

- 任何 u32 host/id/order bits 都可被 codec讀取；requested id一致即可，不另禁0或UINT32_MAX。
- enum/int欄沒有範圍驗證；`length_direction` 必須沿用 `(int32_t)wd_read(...4)` 的值，而不是新增 enum拒絕。
- bool讀到任意非0 byte都為true，不要求 canonical 0/1；窄view忽略它時也不能加0/1限制。
- embedded NUL、非UTF-8、高bit byte均未拒絕。reader按prefix n複製，最後另補NUL；新skip只能按n消耗，不能用strlen、UTF-8或無內嵌NUL規則。
- n=0與511可接受；512與UINT32_MAX必拒絕。三段分別檢查，不能只驗第一段。
- trailing任何1byte必拒絕；缺少任一固定或文字byte必拒絕。

新窄view可把不用的固定值 bounded skip，不需解出1700-byte struct；只要上述接受集合及 placement_id／length_direction／order完全一致。失敗的內部reader.at不對外公開，無需複製full decoder在失敗後繼續回傳0的無效內部計算；但不得新增 source request或改首個typed source失敗。

「可讀」以原API共同前提為限：宣告content_size內的backing bytes必須有效。C API無法驗證任意失效pointer的可存取性；診斷會用有效malloc/static buffers並誠實設定truncation size，配合可選ASan/UBSan查越界，不把原本UB輸入發明成新契約。

## 等patch ready後的差分生成方案

1. 保存固定base的原full來源及候選原碼／header／diff、完整SHA、raw/LF SHA256、生成器hash。純文字擷取原`wd_write/read/signed/read_text/rule_read/placement_read`、原full public API，及候選narrow API與其skip helper。原full函式bytes必須與base完全相同；只改診斷入口名字，不能手抄一個「類似full」裁判。
2. 使用真實產品header型別；保留真實`wd_reader/wd_get/source_ref`。以repo外診斷stub提供returned `GeoSourceValue`，逐次記錄`geo_eval_source`的graph/token/kind/key id/relation/呼叫數，給full與narrow相同原bytes。這是純codec差分，不冒充真graph/native驗收；實際source graph仍由原正式suite驗證。
3. 每案比較兩API的bool；若成功，只逐字段比三個值，不比C padding。若失敗，兩種out各自與其原sentinel bytes完全相同（可用memcmp檢查自己的error preservation）；out=NULL時都應false且零source request。非NULL out時兩API都必須恰一次同樣typed request。
4. 由原writer產生空、一般非空、各段511的合法frame；另直接構造embeddedNUL/高bit文字frame，以涵蓋reader接受但writer通常不會產生的bytes。所有字段的極值/unknown enum都直接改wire bits，不擅自標不合法。
5. 測試所有prefix truncation（每個size從0到完整size−1），完整case與加1/多byte trailing；普通frame的每一byte逐一改為0..255，其餘不動；長frame至少逐byte bit-flip並逐一truncation。每個case輸出完全相同raw length，不以成功結果倒填判準。
6. 三段長度各測0/1/510/511/512/UINT32_MAX及互相組合，並區分「prefix宣稱過長但payload缺少」與「payload足夠卻n>=512」；每一個prefix4byte的截斷都要覆蓋。長度prefix變異後，後續order與第二/三文字的錯位解析仍由原full裁判決定，不用手工分類猜答案。
7. requested/wire id各測0、1、UINT32_MAX、0x80000000、相等/不等；host同值域；direction測0/±1、INT32_MIN/MAX、0x80000000/UINT32_MAX wire bits及普通未知值99；order測0/1/INT64_MAX/1<<63/UINT64_MAX。schema測正確/NULL/空/其他kind schema、source value錯kind、source status失敗、NULL content size0/非0。
8. 每命令另存full stdout/stderr/原exit、工具版本、安全環境白名單、來源SHA及所有hash。先不編譯執行，root排他效能量測結束後才授權小診斷；正式全native、ledger、架構與七項另循新固定SHA完成。

## 窄view接入H的獨立diff覆核點

只替換`reference_contact_facts`的`!use_current_values`原placement讀取，仍在raw placed/exclude之後、actual placement_id比較之前，並保持原order/along_v賦值。raw/current-values分支與原raw footprint失效guard不動；W span-before-resolver、owner-extension延後refresh、typed pose/frame請求順序、完整member表與P-177流量不動。不加cache、不改原fulldecoder，不修改原測試或放寬任何斷言。
