#include "/workspace/geometry-axiom/geometry-templates/woodworking/native/definition_sources.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
typedef struct WoodDefinitionResult {
    WoodDefinitionKey key; struct WoodDefinitionResult *next;
    unsigned char *bytes; size_t size;
} WoodDefinitionResult;
struct WoodDefinitionSources {
    GeoEvalContext *graph; GeoProviderToken token; WoodDefinitionContext context;
    WoodDefinitionResult *results;
};
typedef struct {unsigned char *bytes;size_t at,capacity;bool ok;} WoodDefinitionWriter;
typedef struct {const unsigned char *bytes;size_t at,size;bool ok;} WoodDefinitionReader;
static void wd_write(WoodDefinitionWriter *w,uint64_t n,size_t bytes)
{if(!w->ok||bytes>w->capacity-w->at){w->ok=false;return;}for(size_t i=0;i<bytes;++i)w->bytes[w->at++]=(unsigned char)(n>>(8*(bytes-i-1)));}
static uint64_t wd_read(WoodDefinitionReader *r,size_t bytes)
{uint64_t n=0;if(!r->ok||bytes>r->size-r->at){r->ok=false;return 0;}for(size_t i=0;i<bytes;++i)n=(n<<8)|r->bytes[r->at++];return n;}
static int64_t wd_signed(uint64_t n)
{return n<=INT64_MAX?(int64_t)n:-1-(int64_t)(UINT64_MAX-n);}
static void wd_text(WoodDefinitionWriter *w,const char *s,size_t capacity)
{size_t n=0;while(n<capacity&&s[n])++n;if(n==capacity){w->ok=false;return;}wd_write(w,n,4);for(size_t i=0;i<n;++i)wd_write(w,(unsigned char)s[i],1);}
static void wd_read_text(WoodDefinitionReader *r,char *s,size_t capacity)
{uint64_t n=wd_read(r,4);if(!r->ok||n>=capacity||n>r->size-r->at){r->ok=false;return;}memcpy(s,r->bytes+r->at,(size_t)n);s[n]=0;r->at+=(size_t)n;}
GeoSourceRef wood_definition_source_ref(GeoProviderToken token,WoodDefinitionKind kind,uint32_t id,WoodDefinitionKey *key)
{if(!key)return (GeoSourceRef){token,NULL,0};WoodDefinitionWriter w={key->bytes,0,sizeof key->bytes,true};wd_write(&w,kind,1);wd_write(&w,id,4);return (GeoSourceRef){token,key->bytes,sizeof key->bytes};}
static void wd_rule_write(WoodDefinitionWriter *w,const GeoGridRuleLineRef *a)
{wd_write(w,a->grid_id,4);wd_write(w,a->system_id,4);wd_write(w,a->rule_key,4);for(int i=0;i<2;++i)wd_write(w,(uint64_t)a->cell[i],8);wd_write(w,(uint32_t)a->axis,4);wd_write(w,a->inner_index,4);}
static void wd_rule_read(WoodDefinitionReader *r,GeoGridRuleLineRef *a)
{a->grid_id=(uint32_t)wd_read(r,4);a->system_id=(uint32_t)wd_read(r,4);a->rule_key=(uint32_t)wd_read(r,4);for(int i=0;i<2;++i)a->cell[i]=wd_signed(wd_read(r,8));a->axis=(int32_t)wd_read(r,4);a->inner_index=(uint32_t)wd_read(r,4);}
static void wd_placement_write(WoodDefinitionWriter *w,uint32_t id,const WoodMemberPlacement *a)
{
    wd_write(w,id,4);wd_write(w,a->placement_id,4);wd_write(w,(uint32_t)a->anchor_kind,4);wd_write(w,(uint32_t)a->span_mode,4);
    wd_write(w,(uint32_t)a->length_direction,4);wd_write(w,(uint32_t)a->depth_side,4);
    /* uv is only an authored input in the two legacy explicit-anchor forms. */
    bool input_uv=a->anchor_kind==WOOD_ANCHOR_AT||a->anchor_kind==WOOD_ANCHOR_AT_GUIDES;
    wd_write(w,(uint64_t)(input_uv?a->uv.u:0),8);wd_write(w,(uint64_t)(input_uv?a->uv.v:0),8);
    wd_write(w,a->ref_grid,4);wd_write(w,(uint32_t)a->ref_grid_axis,4);wd_write(w,(uint64_t)a->ref_grid_index,8);
    wd_write(w,a->ref_grid_has_band,1);wd_write(w,(uint64_t)a->ref_grid_band,8);wd_rule_write(w,&a->ref_rule);
    wd_write(w,(uint32_t)a->ref_hole,4);wd_write(w,(uint32_t)a->ref_edge,4);wd_write(w,a->has_through,1);wd_write(w,(uint64_t)a->through,8);
    wd_write(w,a->ref_guide,4);wd_write(w,a->ref_timber,4);wd_write(w,a->ref_is_timber,1);wd_text(w,a->ref_derived_key,sizeof a->ref_derived_key);
    wd_write(w,a->order,8);wd_write(w,a->has_between,1);
    for(int i=0;i<2;++i){const WoodMemberReferenceFace *f=&a->between[i];wd_write(w,(uint32_t)f->kind,4);wd_write(w,(uint32_t)f->hole,4);wd_write(w,(uint32_t)f->edge,4);wd_write(w,f->timber,4);wd_text(w,f->key,sizeof f->key);}
}
static uint32_t wd_placement_read(WoodDefinitionReader *r,WoodMemberPlacement *a)
{
    uint32_t id=(uint32_t)wd_read(r,4);a->placement_id=(uint32_t)wd_read(r,4);a->anchor_kind=(int32_t)wd_read(r,4);a->span_mode=(int32_t)wd_read(r,4);
    a->length_direction=(int32_t)wd_read(r,4);a->depth_side=(int32_t)wd_read(r,4);a->uv.u=wd_signed(wd_read(r,8));a->uv.v=wd_signed(wd_read(r,8));
    a->ref_grid=(uint32_t)wd_read(r,4);a->ref_grid_axis=(int32_t)wd_read(r,4);a->ref_grid_index=wd_signed(wd_read(r,8));
    a->ref_grid_has_band=wd_read(r,1)!=0;a->ref_grid_band=wd_signed(wd_read(r,8));wd_rule_read(r,&a->ref_rule);
    a->ref_hole=(int32_t)wd_read(r,4);a->ref_edge=(int32_t)wd_read(r,4);a->has_through=wd_read(r,1)!=0;a->through=wd_signed(wd_read(r,8));
    a->ref_guide=(uint32_t)wd_read(r,4);a->ref_timber=(uint32_t)wd_read(r,4);a->ref_is_timber=wd_read(r,1)!=0;wd_read_text(r,a->ref_derived_key,sizeof a->ref_derived_key);
    a->order=wd_read(r,8);a->has_between=wd_read(r,1)!=0;
    for(int i=0;i<2;++i){WoodMemberReferenceFace *f=&a->between[i];f->kind=(int32_t)wd_read(r,4);f->hole=(int32_t)wd_read(r,4);f->edge=(int32_t)wd_read(r,4);f->timber=(uint32_t)wd_read(r,4);wd_read_text(r,f->key,sizeof f->key);}return id;
}
static const char *wd_schema(WoodDefinitionKind kind)
{switch(kind){case WOOD_DEFINITION_MEMBER:return "wood.member.declaration/1";case WOOD_DEFINITION_PLACEMENT:return "wood.member.placement/1";case WOOD_DEFINITION_COLUMN:return "wood.rc-column/1";case WOOD_DEFINITION_BEAM:return "wood.rc-beam/1";case WOOD_DEFINITION_BOUNDARY:return "wood.boundary-policy/1";default:return NULL;}}
static bool wd_get(WoodDefinitionSources *s,WoodDefinitionKind kind,uint32_t id,GeoDependencyKind relation,GeoSourceValue *out)
{if(!s)return false;WoodDefinitionKey key;return geo_eval_source(s->graph,wood_definition_source_ref(s->token,kind,id,&key),relation,out)==GEO_SOURCE_OK;}
static bool wd_reader(WoodDefinitionSources *s,WoodDefinitionKind kind,uint32_t id,WoodDefinitionReader *out)
{GeoSourceValue value;if(!wd_get(s,kind,id,GEO_DEPENDENCY_DEFINITION_REQUIRED,&value)||value.kind!=GEO_SOURCE_DEFINITION||!value.as.definition.schema||strcmp(value.as.definition.schema,wd_schema(kind))||(!value.as.definition.content&&value.as.definition.content_size))return false;*out=(WoodDefinitionReader){value.as.definition.content,0,value.as.definition.content_size,true};return true;}
static void wd_skip(WoodDefinitionReader *r,size_t bytes)
{if(!r->ok||bytes>r->size-r->at){r->ok=false;return;}r->at+=bytes;}
static void wd_skip_text(WoodDefinitionReader *r,size_t capacity)
{uint64_t n=wd_read(r,4);if(!r->ok||n>=capacity||n>r->size-r->at){r->ok=false;return;}r->at+=(size_t)n;}
bool diagnostic_full(WoodDefinitionSources *s,uint32_t id,WoodMemberPlacement *out)
{if(!out)return false;WoodDefinitionReader r;WoodMemberPlacement a={0};if(!wd_reader(s,WOOD_DEFINITION_PLACEMENT,id,&r))return false;uint32_t actual=wd_placement_read(&r,&a);if(!r.ok||r.at!=r.size||actual!=id)return false;*out=a;return true;}
bool diagnostic_narrow(WoodDefinitionSources *s,uint32_t id,WoodMemberPlacementContact *out)
{
    if(!out)return false;WoodDefinitionReader r;WoodMemberPlacementContact contact={0};
    if(!wd_reader(s,WOOD_DEFINITION_PLACEMENT,id,&r))return false;
    uint32_t actual=(uint32_t)wd_read(&r,4);contact.placement_id=(uint32_t)wd_read(&r,4);
    wd_skip(&r,8);contact.length_direction=(int32_t)wd_read(&r,4);
    /* offset 20 起的 107 個固定位元組後，三個字串仍依完整格式逐一驗證。 */
    wd_skip(&r,107);wd_skip_text(&r,sizeof ((WoodMemberPlacement *)0)->ref_derived_key);
    contact.order=wd_read(&r,8);wd_skip(&r,1);
    for(int i=0;i<2;++i){wd_skip(&r,16);wd_skip_text(&r,sizeof ((WoodMemberReferenceFace *)0)->key);}
    if(!r.ok||r.at!=r.size||actual!=id)return false;*out=contact;return true;
}

static GeoSourceValue injected;
static GeoSourceStatus injected_status=GEO_SOURCE_OK;
static unsigned calls,bad_request;
static uint32_t requested_id;
static max_align_t graph_identity;
GeoSourceStatus geo_eval_source(GeoEvalContext *graph,GeoSourceRef source,GeoDependencyKind relation,GeoSourceValue *out)
{
    ++calls;const unsigned char *key=source.key;
    if(graph!=(GeoEvalContext *)&graph_identity||source.provider!=17||source.key_size!=5||!key||relation!=GEO_DEPENDENCY_DEFINITION_REQUIRED)bad_request=1;
    else if(key[0]!=WOOD_DEFINITION_PLACEMENT||(((uint32_t)key[1]<<24)|((uint32_t)key[2]<<16)|((uint32_t)key[3]<<8)|key[4])!=requested_id)bad_request=1;
    if(injected_status!=GEO_SOURCE_OK)return injected_status;
    *out=injected;return GEO_SOURCE_OK;
}
static uint64_t comparisons,accepted,rejected,truncations,byte_mutations,length_cases,envelope_cases,value_cases;
static int failed;
typedef struct {unsigned char data[4096];size_t size,lengths[3];} Wire;
static Wire wire,basewire;
static WoodDefinitionSources sources;

static void be(unsigned char *out,uint64_t value,size_t n)
{for(size_t i=0;i<n;++i)out[i]=(unsigned char)(value>>(8*(n-i-1)));}
static bool check(const char *label,uint32_t id,GeoSourceValue value,GeoSourceStatus status,bool null_out)
{
    WoodMemberPlacement full;WoodMemberPlacementContact narrow;
    unsigned char full_before[sizeof full],narrow_before[sizeof narrow];
    memset(&full,0xa5,sizeof full);memset(&narrow,0x5a,sizeof narrow);
    memcpy(full_before,&full,sizeof full);memcpy(narrow_before,&narrow,sizeof narrow);
    injected=value;injected_status=status;requested_id=id;calls=bad_request=0;
    bool a=diagnostic_full(&sources,id,null_out?NULL:&full);unsigned full_calls=calls,full_bad=bad_request;
    calls=bad_request=0;bool b=diagnostic_narrow(&sources,id,null_out?NULL:&narrow);
    ++comparisons;
    bool ok=a==b&&full_calls==(null_out?0u:1u)&&calls==full_calls&&!full_bad&&!bad_request;
    if(a&&b){ok=ok&&full.placement_id==narrow.placement_id&&full.length_direction==narrow.length_direction&&full.order==narrow.order;++accepted;}
    else{ok=ok&&!memcmp(&full,full_before,sizeof full)&&!memcmp(&narrow,narrow_before,sizeof narrow);++rejected;}
    if(!ok){
        printf("MISMATCH label=%s case=%" PRIu64 " requested=%" PRIu32 " size=%zu full=%d narrow=%d full_calls=%u narrow_calls=%u bad=%u/%u\n",label,comparisons,id,value.as.definition.content_size,(int)a,(int)b,full_calls,calls,full_bad,bad_request);
        if(a)printf("FULL host=%" PRIu32 " direction=%d order=%" PRIu64 "\n",full.placement_id,full.length_direction,full.order);
        if(b)printf("NARROW host=%" PRIu32 " direction=%d order=%" PRIu64 "\n",narrow.placement_id,narrow.length_direction,narrow.order);
        const unsigned char *p=value.as.definition.content;
        if(p){printf("INPUT_HEX ");for(size_t i=0;i<value.as.definition.content_size;++i)printf("%02x",p[i]);putchar('\n');}
        failed=1;return false;
    }
    return true;
}
static GeoSourceValue envelope(const Wire *w)
{return (GeoSourceValue){.kind=GEO_SOURCE_DEFINITION,.as.definition={"wood.member.placement/1",w->data,w->size}};}
static bool build(Wire *w,uint32_t id,size_t l0,size_t l1,size_t l2,bool inactive)
{
    WoodMemberPlacement a={0};a.placement_id=UINT32_MAX;a.anchor_kind=WOOD_ANCHOR_AT;a.span_mode=99;a.length_direction=-99;a.depth_side=-7;
    a.uv=(GeoPoint2){INT64_MIN,INT64_MAX};a.ref_grid=UINT32_MAX;a.ref_grid_axis=-1;a.ref_grid_index=INT64_MIN;
    a.ref_grid_has_band=true;a.ref_grid_band=INT64_MAX;a.ref_rule=(GeoGridRuleLineRef){.grid_id=UINT32_MAX,.system_id=7,.rule_key=8,.cell={INT64_MIN,INT64_MAX},.axis=-17,.inner_index=UINT32_MAX};
    a.ref_hole=-13;a.ref_edge=99;a.has_through=true;a.through=INT64_MIN;a.ref_guide=UINT32_MAX;a.ref_timber=UINT32_MAX;a.ref_is_timber=true;a.order=UINT64_MAX;a.has_between=!inactive;
    const size_t lengths[]={l0,l1,l2};char *texts[]={a.ref_derived_key,a.between[0].key,a.between[1].key};
    for(size_t t=0;t<3;++t){if(lengths[t]>=512)return false;for(size_t i=0;i<lengths[t];++i)texts[t][i]=(char)('a'+(i+t)%26);texts[t][lengths[t]]=0;w->lengths[t]=lengths[t];}
    a.between[0].kind=-91;a.between[0].hole=-92;a.between[0].edge=-93;a.between[0].timber=UINT32_MAX;
    a.between[1].kind=91;a.between[1].hole=92;a.between[1].edge=93;a.between[1].timber=0;
    WoodDefinitionWriter writer={w->data,0,sizeof w->data,true};wd_placement_write(&writer,id,&a);w->size=writer.at;
    if(!writer.ok||w->size!=180+l0+l1+l2){puts("HARNESS_ERROR writer-layout");return false;}return true;
}
static bool prefixes_and_values(void)
{
    const size_t lengths[][3]={{0,0,0},{17,5,9},{511,511,511},{0,511,1}};
    for(size_t l=0;l<sizeof lengths/sizeof *lengths;++l){
        if(!build(&wire,11,lengths[l][0],lengths[l][1],lengths[l][2],true))return false;
        GeoSourceValue v=envelope(&wire);
        if(!check("writer-complete",11,v,GEO_SOURCE_OK,false))return false;
        for(size_t size=0;size<wire.size;++size){v.as.definition.content_size=size;if(!check("every-truncation",11,v,GEO_SOURCE_OK,false))return false;++truncations;}
        v=envelope(&wire);wire.data[wire.size]=0x6b;v.as.definition.content_size=wire.size+1;
        if(!check("one-byte-trailing",11,v,GEO_SOURCE_OK,false))return false;
        wire.data[wire.size+1]=0x83;v.as.definition.content_size=wire.size+2;if(!check("two-byte-trailing",11,v,GEO_SOURCE_OK,false))return false;
    }
    const uint32_t ids[]={0,1,UINT32_MAX,UINT32_C(0x80000000),UINT32_C(0x01020304)};
    const uint32_t directions[]={0,1,2,3,99,UINT32_C(0x7fffffff),UINT32_C(0x80000000),UINT32_MAX};
    const uint64_t orders[]={0,1,INT64_MAX,UINT64_C(0x8000000000000000),UINT64_MAX};
    for(size_t i=0;i<5;++i)for(size_t h=0;h<5;++h)for(size_t d=0;d<8;++d)for(size_t o=0;o<5;++o){
        if(!build(&wire,ids[i],3,2,1,false))return false;be(wire.data+4,ids[h],4);be(wire.data+16,directions[d],4);be(wire.data+131+3,orders[o],8);
        if(!check("u32-id-host-direction-u64-order",ids[i],envelope(&wire),GEO_SOURCE_OK,false))return false;++value_cases;
        if(!check("mismatched-requested-id",ids[(i+1)%5],envelope(&wire),GEO_SOURCE_OK,false))return false;++value_cases;
    }
    return true;
}
static bool every_byte(void)
{
    if(!build(&basewire,11,17,5,9,true))return false;
    for(size_t at=0;at<basewire.size;++at)for(unsigned replacement=0;replacement<256;++replacement){
        wire=basewire;wire.data[at]=(unsigned char)replacement;
        if(!check("every-byte-every-value",11,envelope(&wire),GEO_SOURCE_OK,false))return false;++byte_mutations;
    }
    if(!build(&basewire,11,511,511,511,true))return false;
    for(size_t at=0;at<basewire.size;++at)for(unsigned bit=0;bit<8;++bit){
        wire=basewire;wire.data[at]^=(unsigned char)(1u<<bit);
        if(!check("maximum-frame-every-byte-bit",11,envelope(&wire),GEO_SOURCE_OK,false))return false;++byte_mutations;
    }
    return true;
}
static bool text_boundaries(void)
{
    const size_t valid_lengths[]={0,1,510,511};
    for(size_t a=0;a<4;++a)for(size_t b=0;b<4;++b)for(size_t c=0;c<4;++c){
        if(!build(&wire,11,valid_lengths[a],valid_lengths[b],valid_lengths[c],true))return false;
        if(!check("all-valid-length-combinations-inactive-between",11,envelope(&wire),GEO_SOURCE_OK,false))return false;++length_cases;
    }
    if(!build(&basewire,11,511,511,511,true))return false;
    const size_t prefix[]={127,156+511,176+511+511};
    const uint32_t changes[]={0,1,510,511,512,UINT32_MAX};
    for(size_t text=0;text<3;++text)for(size_t n=0;n<6;++n){
        wire=basewire;be(wire.data+prefix[text],changes[n],4);
        wire.data[wire.size++]=0x7c; /* n=512 has enough readable payload even in last text. */
        if(!check("each-text-length-zero-511-512-u32max",11,envelope(&wire),GEO_SOURCE_OK,false))return false;++length_cases;
    }
    wire=basewire;
    const size_t content[]={131,160+511,180+511+511};
    for(size_t t=0;t<3;++t){wire=basewire;wire.data[content[t]]=0;wire.data[content[t]+1]=0xff;wire.data[content[t]+255]=0x80;
        if(!check("embedded-NUL-and-nonUTF8-still-consume-full-length",11,envelope(&wire),GEO_SOURCE_OK,false))return false;++length_cases;}
    return true;
}
static bool envelopes(void)
{
    if(!build(&wire,11,3,2,1,false))return false;
    const char *schemas[]={"wood.member.placement/1",NULL,"","wood.rc-column/1","wood.member.placement/2"};
    for(size_t i=0;i<5;++i){GeoSourceValue v=envelope(&wire);v.as.definition.schema=schemas[i];if(!check("schema",11,v,GEO_SOURCE_OK,false))return false;++envelope_cases;}
    for(int kind=GEO_SOURCE_QUANTITY;kind<=GEO_SOURCE_DEFINITION;++kind){GeoSourceValue v=envelope(&wire);v.kind=(GeoSourceKind)kind;if(!check("value-kind",11,v,GEO_SOURCE_OK,false))return false;++envelope_cases;}
    for(int status=GEO_SOURCE_OK;status<=GEO_SOURCE_MEMORY;++status){if(!check("source-status",11,envelope(&wire),(GeoSourceStatus)status,false))return false;++envelope_cases;}
    GeoSourceValue v=envelope(&wire);v.as.definition.content=NULL;v.as.definition.content_size=0;if(!check("null-content-size-zero",11,v,GEO_SOURCE_OK,false))return false;++envelope_cases;
    v.as.definition.content_size=wire.size;if(!check("null-content-nonzero",11,v,GEO_SOURCE_OK,false))return false;++envelope_cases;
    if(!check("null-out-no-source-request",11,envelope(&wire),GEO_SOURCE_OK,true))return false;++envelope_cases;
    return true;
}
int main(void)
{
    memset(&sources,0,sizeof sources);sources.graph=(GeoEvalContext *)&graph_identity;sources.token=17;
    bool ok=prefixes_and_values()&&every_byte()&&text_boundaries()&&envelopes();
    printf("{\"schema\":\"geo261-placement-contact-codec-equivalence/1\",\"completed\":%s,\"comparisons\":%" PRIu64 ",\"accepted\":%" PRIu64 ",\"rejected\":%" PRIu64 ",\"mismatches\":%d,\"truncations\":%" PRIu64 ",\"byteMutations\":%" PRIu64 ",\"lengthCases\":%" PRIu64 ",\"envelopeCases\":%" PRIu64 ",\"valueCases\":%" PRIu64 "}\n",ok?"true":"false",comparisons,accepted,rejected,failed,truncations,byte_mutations,length_cases,envelope_cases,value_cases);
    return ok?0:1;
}
