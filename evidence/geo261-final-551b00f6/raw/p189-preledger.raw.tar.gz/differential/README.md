# W placement contact 窄 view：純 codec 差分診斷

本目錄不是最終來源驗收。base 為 `be7fe2b3dd608bfce7adb11078065f749002159b` 加當時 dirty 三檔候選；完整 raw SHA256 在 `SUMMARY.json`。所有實際命令均保存原 argv、cwd、exit、完整 stdout/stderr、時間、安全環境與前後來源 hash，未改產品或測試。

原 full API 與原共用 codec helpers 逐字確認 base 未變，再擷取真實原碼；候選 narrow API 使用相同真實 wd_reader/wd_get/source_ref。repo 外 stub 只提供相同 returned typed value，逐次檢查 graph/provider/5-byte kind+id key/relation/callcount，沒有 cache。不是用 stub 取代正式 source graph 驗收。

O2 與 ASan+UBSan 各自 compile/run 原退出均0；各72,634比較，64,586接受、8,048拒絕、0 mismatch。成功按三個field比，不比padding；失敗兩個out各自與原sentinel bytes相同。涵蓋全部2,796 prefix truncations、67,720逐byte變異、85文字長度邊界、21schema/kind/status/null envelope、2,000u32/direction/u64極值；原writer empty size180、三段511總1713及inactive between仍完整驗。ASan/UBSan run stderr空。

初次 `003-o2-compile` 原退出1，不改寫為PASS；診斷infra用了錯誤typedef `GeoSourceKind`，當時未執行binary。`prepared/`保留失敗原碼及原準備收據；v2只改成產品真實 `GeoSourceValueKind`，`prepared-v2/`與007–011保留修正後原碼與原輸出。編譯器的misleading-indentation warnings原樣保留，沒有壓掉。

讀法：`SUMMARY.json`看結果與每命令索引；`commands/NNN-*/receipt.json`核對命令/原exit/full stdout/stderr；`prepared-v2/diagnostic.c`是實際C；`source/`保存三檔dirty候選與diff。`CASE_PLAN.md`保存完整wire layout、接受集合與案例方案。`*.py.txt`是repo外診斷生成器/收據封裝器原碼，不作新增產品executable。先執行 `sha256sum -c SHA256SUMS`驗檔。

P-189本次N64候選/main仍2.175，未達既定≤2倍；此等價診斷不能把效能紅燈改成綠燈。後續真圖回歸、帳本、架構與完整最終SHA驗收由root另行執行。
