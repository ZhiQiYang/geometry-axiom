'use strict';
/* Repo 外的 P88 診斷 preload；不改寫原模組文字、斷言、wait 或 click。 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Module = require('module');

const mode = process.env.P88_PROOF_MODE;
if (!['natural', 'controlled'].includes(mode)) throw Error('P88_PROOF_MODE must be natural or controlled');
if (!process.env.P88_SOURCE_REPO || !path.isAbsolute(process.env.P88_SOURCE_REPO))
  throw Error('P88_SOURCE_REPO must be an absolute existing checkout path');
if (!process.env.P88_TRACE_OUT || !path.isAbsolute(process.env.P88_TRACE_OUT))
  throw Error('P88_TRACE_OUT must be an absolute fresh file path');
const repo = fs.realpathSync(process.env.P88_SOURCE_REPO);
const source = path.join(repo, 'geometry-web', 'grid_rule_lines_test.js');
const tracePath = path.resolve(process.env.P88_TRACE_OUT);
if (tracePath === repo || tracePath.startsWith(repo + path.sep)) throw Error('P88_TRACE_OUT must be outside the source checkout');
const hash = raw => crypto.createHash('sha256').update(raw).digest('hex');
const sourceBytes = fs.readFileSync(source);
const sourceHash = hash(sourceBytes);
const querySource=path.join(repo,'geometry-web','grid-rule-lines.js'),queryBytes=fs.readFileSync(querySource);
const queryAfterLines=queryBytes.toString('utf8').split(/\r?\n/).map((line,i)=>line.includes("const after=await apiRequest('source-inspect')")?i+1:null).filter(Boolean);
if(queryAfterLines.length!==1)throw Error('Expected unique original query after-inspect callsite');
const queryAfterLine=queryAfterLines[0];
if (process.env.P88_SOURCE_SHA256 && process.env.P88_SOURCE_SHA256 !== sourceHash)
  throw Error('P88 original module SHA256 mismatch');
// NODE_OPTIONS 也會載入 npm 等非 CDP Node；只有真 P88 invocation 可占用 trace 檔。
let traceFd = null;
const report = {
  schema: 'geo288-p88-readonly-trace-and-controlled-query/1', mode,
  started_utc: new Date().toISOString(), pid: process.pid,
  argv: process.argv.slice(), exec_argv: process.execArgv.slice(),
  source_repo: repo, source_path: source, source_sha256: sourceHash,
  query_source:querySource,query_source_sha256:hash(queryBytes),query_after_callsite_line:queryAfterLine,
  expected_source_sha256: process.env.P88_SOURCE_SHA256 || null,
  preload_path: __filename, preload_sha256: hash(fs.readFileSync(__filename)),
  instrumentation_scope: 'P88 exports dependency wrapper; original source bytes and assertions unchanged; no helper patch',
  natural_observation_overhead: 'MutationObserver/event capture/synchronous snapshots and trace append have nonzero timing overhead; natural means no injected layout, idle, waits, input, focus or values, not zero instrumentation cost',
  requested_budgets_changed: false, original_return_values_preserved: true,
  target_loaded: false, target_invocations: 0, completed: false,
  source_bytes_unchanged: null, events: [],
  injection:{attempted:false,applied:false,count:0,name:'P88-original-query-release-after-mode-measure',before:null,after:null},
  finalSnapshot:null, node_events: [], browser_trace: null, errors: [],
};
let written = false;
let browserWrapperActive = false;
const pendingMouse = new Map();
function nodeEvent(kind, extra = {}) {
  report.node_events.push({kind, utc: new Date().toISOString(), monotonic_ns: process.hrtime.bigint().toString(), ...extra});
}
/* 唯讀觀測真 transport，原 deps.click 及每個原 send 完整保留，沒有額外 CDP evaluate。 */
report.websocket_observation = {enabled:false,scope:'P88 active interval; real Input.dispatchMouseEvent request/ack only; no added browser evaluations',error:null};
try {
  const prototype = globalThis.WebSocket?.prototype;
  if (!prototype || typeof prototype.send !== 'function') throw Error('Node global WebSocket.prototype.send is unavailable');
  const oldSend = prototype.send, sockets = new WeakMap();
  let socketSerial = 0;
  prototype.send = function(data, ...args) {
    let observed = null;
    if (browserWrapperActive && typeof data === 'string') {
      let message;
      try { message = JSON.parse(data); } catch (_) {}
      if (message?.method === 'Input.dispatchMouseEvent' && ['mousePressed','mouseReleased'].includes(message.params?.type)) {
        if (!sockets.has(this)) {
          const socketId = ++socketSerial;
          sockets.set(this,socketId);
          this.addEventListener('message', event => {
            if (typeof event.data !== 'string') return;
            let reply;
            try { reply = JSON.parse(event.data); } catch (_) { return; }
            const key = socketId + ':' + reply?.id;
            if (!pendingMouse.has(key)) return;
            const request = pendingMouse.get(key);
            pendingMouse.delete(key);
            nodeEvent('cdp-mouse-ack',{socket_id:socketId,request,reply});
          });
        }
        const socketId = sockets.get(this), key = socketId + ':' + message.id;
        observed = {socket_id:socketId,id:message.id,method:message.method,params:message.params,
          session_id:message.sessionId || null,browser_snapshot:null,
          browser_snapshot_note:'Real browser processing before/after is recorded by DOM capture/bubble events; no added CDP evaluation.'};
        pendingMouse.set(key,observed);
        nodeEvent('cdp-mouse-request',observed);
      }
    }
    try {
      return oldSend.call(this,data,...args);
    } catch (error) {
      if (observed) nodeEvent('cdp-mouse-send-threw',{request:observed,error:String(error.stack || error)});
      throw error;
    }
  };
  report.websocket_observation.enabled = true;
} catch (error) {
  report.websocket_observation.error = String(error.stack || error);
}
function finish() {
  if (written || traceFd === null) return;
  written = true;
  report.ended_utc = new Date().toISOString();
  report.websocket_observation.pending_mouse_acknowledgements = Array.from(pendingMouse.values());
  try {
    report.source_bytes_unchanged = fs.readFileSync(source).equals(sourceBytes);
    if (!report.source_bytes_unchanged) report.errors.push('Original P88 source bytes changed during run');
  } catch (error) { report.errors.push(String(error.stack || error)); }
  fs.writeFileSync(traceFd, JSON.stringify(report, null, 2) + '\n');
  fs.fsyncSync(traceFd);
  fs.closeSync(traceFd);
}
process.once('exit', () => {
  if (!written && traceFd !== null) {
    report.errors.push('Node exited before the P88 wrapper finally completed; browser trace may be unavailable');
    finish();
  }
});

/* 此函數只作字串送進既有 eval_；preload 本身不啟瀏覽器。 */
function installBrowserTrace(proofMode, queryAfterLine) {
  const KEY = '__geo288P88PassiveTrace_v1';
  if (window[KEY] || window.__p88Trace) throw Error('P88 trace already installed');
  const rows = [], errors = [], tokens = new WeakMap();
  let nextToken = 1, serial = 0, stopped = false, controlled = null;
  let heldQuery=null,originalApi=null,queryWrapper=null,armedContext=null,armedToken=null,armSerial=0;
  let originalRender=null,renderWrapper=null,renderSerial=0;
  const token = node => {
    if (!node || (typeof node !== 'object' && typeof node !== 'function')) return null;
    if (!tokens.has(node)) tokens.set(node, nextToken++);
    return tokens.get(node);
  };
  const rect = node => {
    if (!node?.getBoundingClientRect) return null;
    const r = node.getBoundingClientRect();
    return {x:r.x, y:r.y, width:r.width, height:r.height, top:r.top, right:r.right, bottom:r.bottom, left:r.left};
  };
  const desc = node => {
    if (!node) return null;
    return {token:token(node), tag:node.tagName || node.nodeName, id:node.id || '',
      classes:typeof node.className === 'string' ? node.className : '',
      parent_id:node.parentElement?.id || '', text:(node.textContent || '').trim().slice(0, 100)};
  };
  const pane = () => document.getElementById('faceInspectorContent');
  const state = () => {
    const p = pane(), parent = p?.parentElement;
    const modeNode = document.getElementById('refGuideMode'), ratio = document.getElementById('refGuideRatio');
    return {inner_width:innerWidth, pane:desc(p), parent:desc(parent),
      pane_scroll_top:p?.scrollTop ?? null, parent_scroll_top:parent?.scrollTop ?? null,
      pane_scroll_height:p?.scrollHeight ?? null, parent_scroll_height:parent?.scrollHeight ?? null,
      grid_preview_seq:typeof fe === 'undefined' ? null : fe.gridPreviewSeq,
      active:desc(document.activeElement),
      mode_node:{node:desc(modeNode), rect:rect(modeNode)},
      ratio_node:{node:desc(ratio), rect:rect(ratio), label:desc(ratio?.closest('label')), label_rect:rect(ratio?.closest('label'))}};
  };
  const append = (kind, extra = {}) => {
    if (stopped) return;
    rows.push({serial:++serial, kind, epoch_ms:Date.now(), monotonic_ms:performance.now(), ...extra});
  };
  const compact = (selector, p) => {
    const node = document.querySelector(selector), inspector = pane(), parent = inspector?.parentElement;
    return {selector,nodeToken:token(node),rect:rect(node),paneScroll:inspector?.scrollTop ?? null,
      parentScroll:parent?.scrollTop ?? null,gridPreviewSeq:typeof fe === 'undefined' ? null : fe.gridPreviewSeq,
      active:desc(document.activeElement),hit:desc(document.elementFromPoint(p.x,p.y))};
  };
  const onEvent = event => {
    const x = Number.isFinite(event.clientX) ? event.clientX : null;
    const y = Number.isFinite(event.clientY) ? event.clientY : null;
    append('dom-' + event.type, {phase:'capture',trusted:event.isTrusted, target:desc(event.target),
      related_target:desc(event.relatedTarget), x, y,
      button:event.button ?? null, buttons:event.buttons ?? null,
      hit:x === null || y === null ? null : desc(document.elementFromPoint(x,y)), state:state()});
  };
  const onBubbleEvent = event => {
    append('dom-' + event.type, {phase:'bubble',trusted:event.isTrusted,target:desc(event.target),
      x:event.clientX,y:event.clientY,state:state()});
  };
  const eventNames = ['pointerdown','pointerup','mousedown','mouseup','click','focusin','focusout','scroll'];
  for (const name of eventNames) document.addEventListener(name, onEvent, {capture:true, passive:true});
  for (const name of ['mousedown','mouseup']) document.addEventListener(name,onBubbleEvent,{passive:true});
  const observer = new MutationObserver(changes => {
    const p = pane();
    const relevant = changes.filter(change => change.target === p || p?.contains(change.target));
    if (!relevant.length) return;
    append('renderObserver', {count:relevant.length,
      mutations:relevant.map(change => ({type:change.type, target:desc(change.target), attribute:change.attributeName,
        added:Array.from(change.addedNodes || []).map(desc), removed:Array.from(change.removedNodes || []).map(desc)})),
      state:state()});
  });
  observer.observe(pane() || document.documentElement,
    {childList:true, subtree:true, attributes:true, attributeFilter:['hidden','class','style','open']});

  // Synchronous observation only: preserve original this, arguments, return
  // identity, thrown value, and scheduling. Observer failures are separate.
  const observeRender=(kind,extra)=>{
    try{append(kind,{...extra,state:state()});}
    catch(error){errors.push('Renderer observation failed: '+String(error?.stack||error));}
  };
  originalRender=renderFaceInspector;
  if(typeof originalRender!=='function')throw Error('Original renderer unavailable');
  renderWrapper=function(...args){
    const invocation=++renderSerial;
    let stack=null;
    try{stack=String(new Error('P88 renderer callsite observation').stack||'');}
    catch(error){errors.push('Renderer stack observation failed: '+String(error?.stack||error));}
    observeRender('renderFaceInspector-enter',{invocation,stack});
    let result;
    try{result=Reflect.apply(originalRender,this,args);}
    catch(error){observeRender('renderFaceInspector-throw',{invocation,stack});throw error;}
    observeRender('renderFaceInspector-return',{invocation,stack});
    return result;
  };
  renderFaceInspector=renderWrapper;
  append('renderer-observer-installed',{synchronous:true,return_identity_preserved:true,
    scheduling_changed:false,observation_overhead:'Nonzero synchronous stack/snapshot/append cost; not zero-overhead natural execution.'});

  if(proofMode==='controlled'){
    originalApi=apiRequest;
    queryWrapper=async function(cmd,...args){
      const stack=String(new Error('P88 query callsite observation').stack||'');
      const callContext=ReferenceWorkspace.context(),callWidth=innerWidth,armAtCall=armedToken;
      const result=await originalApi.call(this,cmd,...args);
      const guides=typeof fe==='undefined'?[]:fe.guides||[];
      if(!heldQuery&&armAtCall&&armAtCall===armedToken&&callContext===armAtCall.context&&ReferenceWorkspace.context()===armAtCall.context&&callWidth===390&&cmd==='source-inspect'&&stack.includes('/grid-rule-lines.js:'+queryAfterLine+':')&&innerWidth===390&&guides.some(g=>typeof g.expression==='string'&&g.expression.startsWith('gridrule:'))){
        let release;
        const pending=new Promise(resolve=>{release=resolve;});
        heldQuery={command:cmd,context:callContext,arm_token:armAtCall,callsite_stack:stack,result,result_json:JSON.stringify(result),release,released:false,held_state:state()};
        append('query-response-held',{command:cmd,callsite_stack:stack,result_json:heldQuery.result_json,state:state()});
        await pending;
        if(JSON.stringify(result)!==heldQuery.result_json)throw Error('Held query response bytes changed');
        append('query-response-returned',{command:cmd,result_json:JSON.stringify(result),state:state()});
      }
      return result;
    };
    apiRequest=queryWrapper;
  }
  async function injectQueryRelease(selector,p){
    if(proofMode!=='controlled'||controlled||selector!=='#refGuideMode'||!p?.hit||innerWidth!==390)return;
    const guides=typeof fe==='undefined'?[]:fe.guides||[];
    if(!guides.some(g=>typeof g.expression==='string'&&g.expression.startsWith('gridrule:')))return;
    controlled={name:'P88-original-query-release-after-mode-measure',attempted:true,applied:false,valid:false,count:0,
      before:compact(selector,p),before_state:state(),after:null,original_measure:p,old_center:{x:p.x,y:p.y},
      restored:false,restoration:null};
    if(!heldQuery||heldQuery.released||heldQuery.context!==ReferenceWorkspace.context()||heldQuery.arm_token!==armedToken){
      controlled.error='No held original after-inspect query response at the first eligible measurement';
      trace.gate=publicControl();throw Error('P88 query schedule precondition: '+controlled.error);
    }
    controlled.original_response_json=heldQuery.result_json;
    controlled.query_callsite_stack=heldQuery.callsite_stack;
    controlled.held_state=heldQuery.held_state;
    heldQuery.released=true;controlled.count=1;
    append('query-response-release',{state:state(),original_measure:p});
    heldQuery.release();
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    const ratio=document.getElementById('refGuideRatio'),label=ratio?.closest('label'),hit=document.elementFromPoint(p.x,p.y);
    controlled.target_label=desc(label);
    controlled.after_hit=desc(hit);controlled.after_state=state();
    controlled.after={...compact(selector,p),hitAtOldPoint:desc(hit)};
    controlled.returned_response_json=JSON.stringify(heldQuery.result);
    controlled.parsed_json_unchanged=controlled.returned_response_json===controlled.original_response_json;
    controlled.response_scope='Same original apiRequest return object and its serialized parsed JSON; original HTTP wire bytes are not captured here.';
    controlled.valid=!!label&&(hit===label||hit===ratio)&&controlled.parsed_json_unchanged;
    controlled.applied=controlled.valid;
    if(!controlled.valid)controlled.error='The actual original query repaint did not move the old point onto the real ratio label/select';
    trace.gate=publicControl();
    append('controlled-query-release',{control:publicControl(),state:state()});
    if(!controlled.valid)throw Error('P88 original query schedule did not reproduce the original wrong-target displacement; this is not valid counterevidence');
  }
  function publicControl() {
    if (!controlled) return null;
    const {restore, ...value} = controlled;
    return value;
  }
  const trace = {
    gate:{attempted:false,applied:false,count:0,name:'P88-original-query-release-after-mode-measure',before:null,after:null},
    afterMeasure(selector, p) {
      append('measure', {selector, original_measure:p,
        hit_at_return:desc(document.elementFromPoint(p.x,p.y)), state:state()});
      if(proofMode==='controlled'&&!heldQuery&&selector==='#refGuideCreate'&&p?.hit&&innerWidth===390){
        armedContext=ReferenceWorkspace.context();
        armedToken={context:armedContext,serial:++armSerial};
        append('query-schedule-armed',{selector,original_measure:p,context_id:armedContext.id,arm_serial:armSerial,state:state()});
      }
      return injectQueryRelease(selector,p);
    },
    stop() {
      const finalSnapshot = state();
      for (const name of eventNames) document.removeEventListener(name,onEvent,{capture:true});
      for (const name of ['mousedown','mouseup']) document.removeEventListener(name,onBubbleEvent);
      observer.disconnect();
      if(heldQuery&&!heldQuery.released){heldQuery.released=true;heldQuery.release();errors.push('Held query was released only during diagnostic cleanup; no valid causal proof');}
      if(queryWrapper&&apiRequest===queryWrapper)apiRequest=originalApi;
      if(renderFaceInspector===renderWrapper){renderFaceInspector=originalRender;append('renderer-observer-restored',{restored:true});}
      else{errors.push('Renderer wrapper no longer owns the global binding; original binding was not forcibly restored');append('renderer-observer-restored',{restored:false});}
      append('stop', {state:state(), control:publicControl()});
      stopped = true;
      const result = {mode:proofMode,events:rows,errors,injection:publicControl() || trace.gate,finalSnapshot,stopped:true};
      delete window[KEY];
      delete window.__p88Trace;
      return result;
    },
  };
  window[KEY] = trace;
  window.__p88Trace = trace;
  append('install', {state:state()});
  return {installed:true, mode:proofMode};
}

const measurement = /^\(\(\)=>\{const e=document\.querySelector\(("(?:[^"\\]|\\.)*")\);if\(!e\)throw Error\(/;
const originalExtension = Module._extensions['.js'];
Module._extensions['.js'] = function(module, filename) {
  originalExtension.call(this, module, filename);
  if (path.resolve(filename) !== source) return;
  if (report.target_loaded) throw Error('P88 original module was compiled more than once');
  if (typeof module.exports !== 'function') throw Error('Original P88 module exports must be a function');
  if (!fs.readFileSync(source).equals(sourceBytes)) throw Error('Original P88 bytes changed while loading');
  report.target_loaded = true;
  nodeEvent('target-loaded', {filename});
  const original = module.exports;
  module.exports = async function tracedP88(deps) {
    if (++report.target_invocations !== 1) throw Error('P88 wrapper is one invocation per process');
    if (typeof deps.eval_ !== 'function' || typeof deps.send !== 'function') throw Error('Missing original P88 dependencies');
    traceFd = fs.openSync(tracePath, 'wx', 0o600);
    let originalError = null, instrumentationError = null;
    const eval_ = async function(expression, ...args) {
      const match = typeof expression === 'string' && measurement.exec(expression);
      if (!match || !expression.includes('const r=e.getBoundingClientRect(),x=') || !expression.includes('hit:e.contains(h)'))
        return deps.eval_(expression, ...args);
      const selector = JSON.parse(match[1]);
      nodeEvent('measure-request', {selector});
      // 原 measure 僅求值一次；natural 只追加觀測，controlled 在同次求值後回傳原舊 p。
      const wrapped = mode==='controlled' ? `(async()=>{const p=(${expression});const t=window.__geo288P88PassiveTrace_v1;if(!t)throw Error('P88 trace missing');await t.afterMeasure(${JSON.stringify(selector)},p);return p;})()` : `(()=>{const p=(${expression});const t=window.__geo288P88PassiveTrace_v1;if(!t)throw Error('P88 trace missing');t.afterMeasure(${JSON.stringify(selector)},p);return p;})()`;
      const value = await deps.eval_(wrapped, ...args);
      nodeEvent('measure-return', {selector, original_measure:value});
      return value;
    };
    const send = async function(method, params, ...args) {
      if (typeof method === 'string' && method.startsWith('Input.')) nodeEvent('passed-send-request', {method,params});
      return deps.send(method,params,...args);
    };
    try {
      browserWrapperActive = true;
      await deps.eval_(`(${installBrowserTrace.toString()})(${JSON.stringify(mode)},${JSON.stringify(queryAfterLine)})`);
      nodeEvent('browser-trace-installed');
      const result = await original.call(this,{...deps,eval_,send});
      report.completed = true;
      return result;
    } catch (error) {
      originalError = error;
      report.original_error = String(error.stack || error);
      throw error;
    } finally {
      try {
        report.browser_trace = await deps.eval_(`(()=>{const t=window.__geo288P88PassiveTrace_v1;if(!t)throw Error('P88 trace missing at finally');return t.stop();})()`);
        report.events = report.browser_trace.events;
        report.injection = report.browser_trace.injection;
        report.finalSnapshot = report.browser_trace.finalSnapshot;
      } catch (error) {
        instrumentationError = error;
        report.errors.push('Browser trace collection failed: ' + String(error.stack || error));
      }
      browserWrapperActive = false;
      nodeEvent('wrapper-finally', {original_failed:!!originalError});
      finish();
      if (!originalError && (instrumentationError || report.errors.length))
        throw instrumentationError || Error('P88 trace integrity failure; inspect the original trace JSON');
    }
  };
};
