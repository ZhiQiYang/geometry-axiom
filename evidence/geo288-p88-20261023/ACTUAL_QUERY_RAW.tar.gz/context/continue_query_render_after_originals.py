"""Run the frozen diagnostic only after all three original canvas jobs end."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
F = '13d02c1db7022145a52ee063286a558e595eb212'
REPO = Path('/tmp/g288f-13d02c1d')
TOOLS = HERE / 'p88-only-query-tools-render-trace'
PREP = '1163f930a4aa90b4346372a8f576704cef281eda1f07ff02bd7986d4922c29b6'
CANDIDATE = HERE / 'candidate-local-v5/PROOF_MANIFEST.json'
CANDIDATE_HASH = '5993efeaee71047c9d6f4e1ba0ded3f39a5ba47329d5dc70142dbf37c34676e6'
OUT = Path('/tmp/g288p88q')
PREFIX = HERE / 'actual-query-render-controlled-launch'

def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

print('Waiting for all three original canvas terminal receipts; no heavy process started.', flush=True)
while True:
    try:
        sequence = json.loads((HERE / 'sequence-receipt.json').read_text())
        if sequence.get('all_three_completed') is True and len(sequence['runs']) == 3:
            break
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    time.sleep(10)
if sequence['sha'] != F or {row['index'] for row in sequence['runs']} != {1, 2, 3}:
    raise RuntimeError('Original sequence identity is not the required F13 three runs')
for row in sequence['runs']:
    receipt = Path(row['receipt'])
    if h(receipt) != row['receipt_sha256'] or row['sha'] != F:
        raise RuntimeError('Original terminal receipt identity changed')
if h(TOOLS / 'PREPARATION.json') != PREP or h(CANDIDATE) != CANDIDATE_HASH:
    raise RuntimeError('Peer-reviewed diagnostic preparation or candidate changed')
preparation = json.loads((TOOLS / 'PREPARATION.json').read_text())
for relative, expected in preparation['files'].items():
    if h(TOOLS / relative) != expected:
        raise RuntimeError('Frozen diagnostic file changed: ' + relative)
if OUT.exists():
    raise RuntimeError('Diagnostic output must be fresh')
command = ['env', '-u', 'NODE_OPTIONS', '-u', 'PYTHONOPTIMIZE', 'python3', '-B',
    '/workspace/geo261-environment/execute_f_extra.py',
    '--label', 'p88-actual-query-render-controlled-v5', '--sha', F, '--repo', str(REPO),
    '--outer-root', str(HERE / 'outers'), '--', 'python3', '-B', str(TOOLS / 'run_proof.py'),
    '--repo', str(REPO), '--sha', F, '--out', str(OUT), '--heavy-lock', '/tmp/g261r3/heavy.lock',
    '--mode', 'controlled', '--job', 'grid', '--candidate', str(CANDIDATE)]
request = {'sha': F, 'command': command, 'cwd': str(REPO),
    'scope': 'Diagnostic only; P88 module on original grid bootstrap; two other modules explicitly omitted. Not a formal grid/canvas gate.',
    'original_sequence_sha256': h(HERE / 'sequence-receipt.json'), 'original_runs': sequence['runs'],
    'preparation_sha256': PREP, 'candidate_manifest_sha256': CANDIDATE_HASH,
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment_input': {k: os.environ.get(k) for k in ('PATH', 'LANG', 'LC_ALL', 'NODE_OPTIONS', 'PYTHONOPTIMIZE')},
    'environment_removals': ['NODE_OPTIONS', 'PYTHONOPTIMIZE']}
PREFIX.with_suffix('.request.json').write_text(json.dumps(request, ensure_ascii=False, indent=2) + '\n')
print('Original three completed; starting frozen P88 actual-query diagnostic.', flush=True)
with PREFIX.with_suffix('.stdout').open('xb') as stdout, PREFIX.with_suffix('.stderr').open('xb') as stderr:
    result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr)
terminal = {'actual_process_returncode': result.returncode,
    'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stdout_sha256': h(PREFIX.with_suffix('.stdout')), 'stderr_sha256': h(PREFIX.with_suffix('.stderr'))}
PREFIX.with_suffix('.exit.json').write_text(json.dumps(terminal, indent=2) + '\n')
print(json.dumps(terminal), flush=True)
raise SystemExit(result.returncode)
