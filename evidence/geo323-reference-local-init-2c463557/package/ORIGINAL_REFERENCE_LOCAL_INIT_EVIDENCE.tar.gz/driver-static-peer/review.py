from pathlib import Path
import ast,hashlib,json,os,tempfile
B=Path('/tmp/geo337-reference-local-init-draft-20261024');O=Path('/workspace/geo343-plane-range-draft-20261024');OBS=Path('/workspace/geo343-plane-ranges-formal-tools-20261024/observer');OUT=Path(__file__).parent
checks=[]
def check(v,label):
 checks.append({'check':label,'passed':bool(v)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [B/'run_formal.template.py',B/'launch_formal.template.py',*sorted((B/'observer').glob('*.py')),B/'observer/TOOL_PINS.json']}
run=(B/'run_formal.template.py').read_text();launch=(B/'launch_formal.template.py').read_text()
for p in [B/'run_formal.template.py',B/'launch_formal.template.py',*sorted((B/'observer').glob('*.py'))]:
 ast.parse(p.read_text());check(True,'AST '+p.name)
for item in json.loads((B/'observer/TOOL_PINS.json').read_bytes())['tools']:check(sha(B/'observer'/item['name'])==item['bound_sha256'],'observer exact '+item['name'])
for name in ['observe_bridge_bytes.py','retain_loadfile_inputs.py']:check((B/'observer'/name).read_bytes()==(OBS/name).read_bytes(),'unchanged accepted '+name)
old=(OBS/'retain_native_inputs.py').read_text();new=(B/'observer/retain_native_inputs.py').read_text();start=new.index('        # Each residual client');end=new.index("        row={'event':'subprocess.Popen-before-launch'",start)
check(new[:start]+new[end:]==old,'native observer only additive private closure block')
entry=(B/'observer/run_observed_original.py').read_text();oldentry=(OBS/'run_observed_original.py').read_text()
a="'tests/test_geo261_wood_contact_world.py','tests/test_geo261_contact_sources.py','tests/test_geo318_reading_a_native.py'";b="'tests/test_geo261_load_residual.py','tests/geo337_reference_local_init_harness.c'"
check(oldentry.replace(a,b)==entry,'entry only exact mandatory set changes')
for token in ["SUITES=[('load-residual','tests/test_geo261_load_residual.py',14)]","need(S=='UNBOUND_SOURCE'","=='UNBOUND_SOURCE_MANIFEST'","/tmp/g261r3/heavy.lock","fcntl.LOCK_EX|fcntl.LOCK_NB","16*1024*1024","shutil.disk_usage('/tmp').free>=100*1024*1024","shutil.disk_usage('/tmp').free<100*1024*1024","GEO261_LOAD_RESIDUAL_EXECUTION_LOG=str(where/'native-executions.jsonl')","timeout=None,check=False","detail['total']==detail['run']==detail['passed']==count","entry['source_files_before']==entry['source_files_after']==manifest['files']","entry['observer_complete'] is True and observation['observer_complete'] is True","git('status','--porcelain=v1','--untracked-files=all')==b''","'full_native':False,'ledger_regenerated':False,'performance':False"]:check(token in run,'driver retains '+token)
for token in ["'UNBOUND_DRIVER'","check=False,timeout=None","7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760","c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762"]:check(token.replace(" ","") in launch.replace(" ",""),'outer retains '+token)
# Exercise only the extracted snapshot compiler function, never install an audit hook or run a compiler.
node=next(n for n in ast.walk(ast.parse(new)) if isinstance(n,ast.FunctionDef) and n.name=='compiler')
module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
with tempfile.TemporaryDirectory(prefix='quoted-closure-peer-',dir='/tmp') as d:
 root=Path(d);private=root/'private';private.mkdir();outside=root/'immutable.inc';outside.write_text('outside original dependency\n');client=private/'client.c';h=private/'h.c';inc=private/'x.inc'
 client.write_text('#include "h.c"\n#include "missing.inc"\n#include "../immutable.inc"\n');h.write_text('#include "x.inc"\n');inc.write_text('#include "h.c"\n')
 selected=[];rows=[];ns={'Path':Path,'os':os,'private_tmp':private,'serial':lambda x:x,'retain':lambda p:selected.append(p.resolve()) or {'path':str(p.resolve()),'bytes':p.read_bytes().hex()},'compiles':rows,'out':root,'write_json':lambda p,v:None}
 exec(compile(module,'<extracted actual compiler snapshot>','exec'),ns)
 argv=['cc','-c',str(client),'-o','x.o'];before=argv[:];ns['compiler'](argv,str(private))
 check(set(selected)=={client,h,inc},'actual recursive snapshot captures all three private leaves with cycle')
 check(outside not in selected,'actual recursion excludes external immutable dependency')
 check(argv==before,'actual compiler audit leaves caller argv unchanged')
 check(len(rows)==1 and 'actual-private-quoted-closure-at-compile' in rows[0]['roles'],'actual cycle terminates and records exact role')
 check(all(x['bytes']==Path(x['path']).read_bytes().hex() for x in rows[0]['inputs']),'actual snapshot retains unmodified input bytes')
 ns['compiler'](['cc',str(client),'-o','x'],str(private));check(len(rows)==1,'noncompile invocation produces no fabricated snapshot')
summary={'reviewer_history':'Initial reader expected outer timeout/check keyword ordering to match driver; two failed reader reports/helpers retained, corrected to actual check=False,timeout=None ordering; subject untouched.', 'scope':'Static template/observer delta review plus extracted pure snapshot function fixtures; no C, no formal launch, no source publication.', 'subject_pins':pins,'checks':len(checks),'failed':sum(not x['passed'] for x in checks),'findings':[], 'limitations':['Templates deliberately UNBOUND: public SHA, exact source manifest and resulting driver hash still must be bound before launch.','Actual final source must contain original 13 methods plus one new method; this template review does not certify unmaterialized final suite count.','Quoted-include scan captures readable private literal include bytes; it is not a C-preprocessor dependency claim or proof the child read each file. Immutable-root dependencies remain source-manifest governed.','No new full-native, ledger, browser, architecture or formal performance result.'],'details':checks}
if summary['failed']:summary['findings']=[x['check'] for x in checks if not x['passed']]
(OUT/'REVIEW.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':summary['checks'],'failed':summary['failed'],'sha256':sha(OUT/'REVIEW.json'),'findings':summary['findings']}));raise SystemExit(bool(summary['failed']))
