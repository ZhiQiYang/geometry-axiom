from pathlib import Path
import difflib,hashlib,json,os,subprocess
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/geometry-axiom')
F='6df0264f75e84f03adb70746b6ac3db07a9910fc'
LEAF='geometry-core/references.inc'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
before={}
for i,name in enumerate((LEAF,'tests/test_geo261_load_residual.py','tests/geo261_load_residual_harness.c','tests/geo261_member_reads_cases.inc','tests/run_all.expected.json')):
    d=HERE/'source-reads'/str(i);d.mkdir(parents=True,exist_ok=False)
    command=['git','show',F+':'+name]
    p=subprocess.run(command,cwd=REPO,capture_output=True,env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')})
    (d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr)
    dump(d/'result.json',{'command':command,'cwd':str(REPO),'exit':p.returncode})
    assert p.returncode==0;before[name]=p.stdout
    target=HERE/'before'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.stdout)
old=before[LEAF].decode()
edits=(
 ('    ReferenceEval local={0},*ctx=&local;bool persistent=false;','    ReferenceEval local,*ctx;bool persistent=false;'),
 ('        if(!ctx)return false;persistent=true;\n    }\n    ctx->world=w;bool ok=true;',
  '        if(!ctx)return false;persistent=true;\n    }else{\n        local=(ReferenceEval){0};ctx=&local;\n    }\n    ctx->world=w;bool ok=true;'))
candidate=old
for a,b in edits:
    assert candidate.count(a)==1;candidate=candidate.replace(a,b)
restored=candidate
for a,b in reversed(edits):assert restored.count(b)==1;restored=restored.replace(b,a)
assert restored==old
p=HERE/'candidate'/LEAF;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(candidate)
patch=''.join(difflib.unified_diff(old.splitlines(True),candidate.splitlines(True),fromfile='a/'+LEAF,tofile='b/'+LEAF))
(HERE/'PRODUCT_ONLY.patch').write_text(patch)
dump(HERE/'PRODUCT_MANIFEST.json',{'source_sha':F,'path':LEAF,'before_sha256':sha(old.encode()),'after_sha256':sha(candidate.encode()),'patch_sha256':sha(patch.encode()),'edits':edits,'entire_withdrawal_exact':True,'C_executed':False})
print(json.dumps({'patch_sha256':sha(patch.encode()),'product_sha256':sha(candidate.encode())}))
