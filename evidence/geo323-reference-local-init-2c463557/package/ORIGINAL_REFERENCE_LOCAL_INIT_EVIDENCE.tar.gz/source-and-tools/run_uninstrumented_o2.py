"""Compile unchanged product closure in three phases; inspect, never execute, ELF."""
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,resource,shutil,sys,traceback
HERE=Path(__file__).resolve().parent
ROOT=Path('/tmp/geo337-reference-local-init-work-20261024')
OUT=Path('/tmp/geo337-reference-local-init-uninstrumented-o2-20261024')
S='2c4635577a8fcb11e88b346547f7bb1c7b739fb7'
MANIFEST='31853a33c588b1eec51c9bc4f1256a9a4a859c454593f8344849ddf6e2964d99'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
 need(not OUT.exists(),'fresh original output')
 need(shutil.disk_usage('/tmp').free>=100*1024*1024,'100MiB diagnostic admission')
 body=(HERE/'source-publication/SOURCE_MANIFEST.json').read_bytes();need(sha(body)==MANIFEST,'fixed source closure manifest')
 manifest=json.loads(body);need(manifest['source_sha']==S,'source pin')
 need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original recorder')
 lock=Path('/tmp/g261r3/heavy.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 OUT.mkdir();oldstack=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,oldstack[1]))
 strip={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
 env={k:v for k,v in os.environ.items()if k not in strip and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO261_','GEO318_'))}
 env.update(TMPDIR=str(OUT),LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1')
 spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT,env,S)
 report={'source_sha':S,'phases':[],'errors':[],'exit':None,'product_executed':False,'performance_samples':0,'purpose':'uninstrumented original O2 bridge assembly only; no formal wall or hooked work substitution','source_manifest_sha256':MANIFEST}
 try:
  def run(argv,cwd=ROOT,timeout=None):return rec.run(argv,cwd=cwd,timeout=timeout)
  need(run(['git','rev-parse','HEAD'])[1].decode().strip()==S,'original source HEAD')
  need(run(['git','status','--porcelain=v1','--untracked-files=all'])[1]==b'','original source clean')
  run(['df','-B1','/workspace','/tmp']);run(['gcc','--version']);run(['objdump','--version'])
  originals={}
  for name,pin in manifest['files'].items():
   originals[name]=(ROOT/name).read_bytes();need(sha(originals[name])==pin,'original closure '+name)
  fixed=originals['geometry-core/references.inc'];withdrawn=(HERE/'before/geometry-core/references.inc').read_bytes()
  need(sha(fixed)=='2f915779b14272a3cd9d2014d02d9476b05841145885e3d4b0717657e0a0378c','fixed product bytes')
  need(sha(withdrawn)=='1c77919f801bb639c5b42f621759fd940b0a3b9e3d90aa6be8e98dd4c952b751','withdrawn F7 product bytes')
  for phase,references in [('fixed',fixed),('withdrawn',withdrawn),('restored',fixed)]:
   where=OUT/phase;tree=where/'source';tree.mkdir(parents=True)
   files={}
   for name,original in originals.items():
    data=references if name=='geometry-core/references.inc'else original
    path=tree/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);files[name]=sha(data)
   dump(where/'SOURCE_MANIFEST.json',{'source_sha':S,'source_variant':phase,'files':files,'instrumentation':'none'})
   exe=where/'bridge'
   argv=['gcc','-std=c11','-O2',str(tree/'geometry-web/web_bridge.c'),'-o',str(exe),'-lm']
   row,stdout,stderr=run(argv,cwd=tree,timeout=300)
   for name,pin in files.items():need(sha((tree/name).read_bytes())==pin,'compile input unchanged '+phase+':'+name)
   _,disassembly,_=run(['objdump','-d','--disassemble=reference_rebuild',str(exe)],cwd=tree)
   (where/'reference_rebuild.objdump').write_bytes(disassembly)
   _,symbols,_=run(['nm','-S','--defined-only',str(exe)],cwd=tree);(where/'symbols.txt').write_bytes(symbols)
   need(b'<reference_rebuild>:'in disassembly,'reference_rebuild symbol available for independent branch inspection')
   report['phases'].append({'phase':phase,'compile_argv':argv,'compile_exit':row['actual_process_returncode'],'binary':str(exe),'binary_bytes':exe.stat().st_size,'binary_sha256':sha(exe.read_bytes()),'disassembly_sha256':sha(disassembly),'reference_source_sha256':sha(references),'instrumentation':'none','executed':False})
   dump(OUT/'PROGRESS.json',report)
  need(run(['git','rev-parse','HEAD'])[1].decode().strip()==S,'original source HEAD after')
  need(run(['git','status','--porcelain=v1','--untracked-files=all'])[1]==b'','original source clean after')
  for name,pin in manifest['files'].items():need(sha((ROOT/name).read_bytes())==pin,'original source unchanged '+name)
  report['exit']=0
 except BaseException:report['errors'].append(traceback.format_exc());report['exit']=1
 finally:
  report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dump(OUT/'RESULT.json',report);fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
 print(json.dumps({'exit':report['exit'],'phases':len(report['phases']),'errors':report['errors']}),flush=True)
 return report['exit']
if __name__=='__main__':sys.exit(main())
