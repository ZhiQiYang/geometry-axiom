本候選只修正 `reference_rebuild()` 選用持續存在的候選求值狀態時，仍初始化一份未使用的區域狀態。它不宣稱已解決 N16 的正式耗時紅燈。

正式 R7 固定來源為 `6df0264f75e84f03adb70746b6ac3db07a9910fc`。原 N16 中位數 base 0.1141533259942662 秒、fix 0.12007854899275117 秒，fix/base 1.05190582882169，仍紅；原 36 樣本不重抽、不調門檻。N64/main 1.2292230778583162 已符合原 1.3 門檻。

獨立靜查 `/tmp/geo323-N16-fixed-cost-static-peer-20261024/REVIEW.json` 保存 14 條 size/nm/readelf/objdump 原流：base/fix 的大 BSS 都是 328,915,720 bytes，World/history 容量沒有變大。ReferenceEval 的配置尺寸從 base 的 608 bytes 增至 fix 的 127,584 bytes；真 F7 O2 指令在選擇 persistent 分支之前先執行 127,584 bytes 的 memset。因此問題有可定位的無用工作，而非靠低解析度 gprof 的取樣秒數推定。

額外 N16 原 pg ELF 各一次原因診斷保存在 `/tmp/geo323-r7-n16-profile-diagnostic-20261024/`，四條 load/gprof 子命令都為 0，並保 ELF、fixture、stdin、完整 stdout/stderr 與工具完成原回傳。兩邊 reference_rebuild 都被呼叫 26 次；這個總呼叫數不代表每次都走 persistent 分支，不能直接把 26×127,584 當已量到的多餘清零總量。K 的 find_node、eval_source 等次數下降，W 新索引有額外查詢，但並未證明它們是原 5.925 ms 中位數差的原因。

兩處修正保留原 candidate ctx 取得、必要時建立、分配失敗立即返回與既有 dispose 順序，僅把區域 aggregate 零初始化移到非 persistent 的 else。反證必須在同一來源精確撤回兩處，證明實際持續狀態路徑的清零工作恢復，再還原歸零。語法 note 計數與 Linux 真 memset 呼叫須分欄；原耗時門檻只由後續正式裁判判定。

W rank-bound 外稿留作未採用工作，不混入本候選。
