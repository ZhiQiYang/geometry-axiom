from pathlib import Path
import ast,difflib,hashlib,json
HERE=Path(__file__).resolve().parent
PRODUCT='geometry-core/references.inc';PY='tests/test_geo261_load_residual.py';REG='tests/run_all.expected.json'
C='tests/geo337_reference_local_init_harness.c'
HARNESS=Path('/tmp/geo337-reference-local-init-harness-backlog-20261024/geo337_reference_local_init_harness.c')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((HERE/'PRODUCT_MANIFEST.json').read_bytes())
before={p:(HERE/'before'/p).read_bytes()for p in (PRODUCT,PY,REG)}
product=(HERE/'candidate'/PRODUCT).read_bytes()
assert sha(product)==manifest['after_sha256']
old=before[PY].decode()
anchor='class LoadResidual(unittest.TestCase):';assert old.count(anchor)==1
new=old.replace(anchor,'REFERENCE_LOCAL_INIT_EDITS = '+repr(tuple(tuple(x)for x in manifest['edits']))+'\n\n'+anchor)
anchor='    def test_cached_reads_preserve_each_consumer_exact_source_kind_and_order(self):'
assert new.count(anchor)==1
new=new.replace(anchor,(HERE/'companion_methods.py.txt').read_text()+anchor)
olddefs={n.name:ast.dump(n,include_attributes=False)for n in ast.walk(ast.parse(old))if isinstance(n,ast.FunctionDef)}
newdefs={n.name:ast.dump(n,include_attributes=False)for n in ast.walk(ast.parse(new))if isinstance(n,ast.FunctionDef)}
assert all(newdefs[n]==body for n,body in olddefs.items()),'all old methods and controls unchanged'
assert len([n for n in newdefs if n.startswith('test_')])==14
regold=before[REG].decode();anchor='"py:test_geo261_load_residual": {\n      "mode": "count",\n      "count": 13,'
assert regold.count(anchor)==1
regnew=regold.replace(anchor,anchor.replace('13,','14,'))
candidate={PRODUCT:product,PY:new.encode(),REG:regnew.encode(),C:HARNESS.read_bytes()}
patch=''
for name,body in candidate.items():
 p=HERE/'candidate'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 patch+=''.join(difflib.unified_diff(before.get(name,b'').decode().splitlines(True),body.decode().splitlines(True),fromfile='a/'+name if name in before else '/dev/null',tofile='b/'+name))
(HERE/'FOUR_LEAF.patch').write_text(patch)
value={'source_sha':manifest['source_sha'],'files':{n:sha(b)for n,b in candidate.items()},'before':{n:sha(b)for n,b in before.items()},
 'patch_sha256':sha(patch.encode()),'old_methods_unchanged':len(olddefs),'old_test_methods':13,'new_test_methods':14,
 'registry_change':'load-residual13->14 only; all other entries byte/order unchanged','harness_author':'/root/backlog_resume',
 'formal_compile_seconds':300,'formal_case_seconds':90,'C_executed':False,'new_performance_threshold':False}
dump(HERE/'COMPANION_MANIFEST.json',value)
publisher=(HERE/'publish_source.template.py').read_text().replace('UNBOUND_PATCH',value['patch_sha256']).replace('UNBOUND_MANIFEST',sha((HERE/'COMPANION_MANIFEST.json').read_bytes()))
assert 'UNBOUND'not in publisher
(HERE/'publish_source.py').write_text(publisher)
print(json.dumps(value))
