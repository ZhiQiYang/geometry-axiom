新來源以 F7 為基底，只採 `geometry-core/references.inc` 的兩處 local 初始化移動，並在既有 LoadResidual 13 方法上增一方法與私有 C harness；原13的具名斷言、controls、case90秒、compiler300秒不改。

需驗語意：

- 活躍候選且 world 相符，保已存在的 evaluation state 身份；必要時建立 ctx，重複 rebuild 不丟 ordered graph。
- 活躍候選不相符或沒有活躍候選，區域 fallback 仍完整 aggregate 初始化；只能在非 persistent 路徑 dispose。
- 候選 ctx 配置失敗時原樣 false 返回，不使用未賦值的 local，不進入後續 probe／求值。
- 現有 cached read 之 consumer、來源種類、edge/node 順序與重複/回滾負控制仍完整執行。

完整撤回兩處產品改動，逐 byte 回到 F7；恢復兩處逐 byte 回新 source。三階段各跑相同語意正例。工作反證分兩欄：aggregate 初始化的語法 note 計數僅證分支；Linux `--wrap=memset` 捕捉真實清零呼叫並委派原函式，在受控 persistent 工作視窗記 calls 與 bytes。後者才能當這次 Linux 成本反證；不能以語法 note 冒稱實際 memset，也不把 gprof 0.01秒粒度歸因於原6ms差。Windows 沿原 MSVC 編譯與語意/分支契約，不宣稱跑過 GNU 連結攔截。

原候選／source 私有副本、每次 compiler 輸入（包含真正納入的私有 .inc）、完整 stdin/stdout/stderr、回碼、ELF hash、source SHA 都獨立保全。原 LoadResidual 完整14方法單次收齊紅燈，先分類後修；未跑的原 native/browser/帳本/架構不借此標綠。

若原 compiler 把初始化內聯為其他真實 store 而不是可包裝的 memset，成本收據應明列未觀測到預期入口，不能假綠；保留原失敗，再以實際 O2 指令／明確 store 工作量補證。
