from pathlib import Path
import hashlib,json,subprocess,datetime,re
D=Path('/tmp/geo337-reference-local-init-draft-20261024');O=Path(__file__).resolve().parent;checks=[]
H=lambda b:hashlib.sha256(b).hexdigest()
def ck(name,value):
 checks.append({'check':name,'passed':bool(value)})
 assert value,name
m=json.loads((D/'PRODUCT_MANIFEST.json').read_bytes());before=(D/'before/geometry-core/references.inc').read_bytes();after=(D/'candidate/geometry-core/references.inc').read_bytes();patch=(D/'PRODUCT_ONLY.patch').read_bytes()
ck('fixed public F7 source',m['source_sha']=='6df0264f75e84f03adb70746b6ac3db07a9910fc')
for name,raw,key in [('before',before,'before_sha256'),('after',after,'after_sha256'),('patch',patch,'patch_sha256')]:ck('exact '+name+' pin',H(raw)==m[key])
argv=['git','-c','gc.auto=0','-c','maintenance.auto=false','-C','/workspace/geometry-axiom','show',m['source_sha']+':geometry-core/references.inc'];r=subprocess.run(argv,capture_output=True)
(O/'F7_GIT_READ.stdout.bin').write_bytes(r.stdout);(O/'F7_GIT_READ.stderr.bin').write_bytes(r.stderr)
(O/'F7_GIT_READ.COMMAND.json').write_text(json.dumps({'argv':argv,'actual_exit':r.returncode,'stdout_sha256':H(r.stdout),'stderr_sha256':H(r.stderr)},indent=2)+'\n')
ck('original Git read actual0',r.returncode==0);ck('before exact F7 original Git bytes',before==r.stdout)
ck('only two exact text edits',len(m['edits'])==2)
s=before.decode()
for i,(a,b) in enumerate(m['edits']):ck('unique before anchor '+str(i),s.count(a)==1);s=s.replace(a,b,1)
ck('candidate equals complete two-edit application',s.encode()==after)
for i,(a,b) in reversed(list(enumerate(m['edits']))):ck('unique withdrawal anchor '+str(i),s.count(b)==1);s=s.replace(b,a,1)
ck('whole withdrawal exact original Git bytes',s.encode()==before)
start='static bool reference_rebuild(World *w)\n{';end='\nstatic bool reference_checked('
b0=before.decode().index(start);b1=before.decode().index(end,b0);a0=after.decode().index(start);a1=after.decode().index(end,a0)
bf=before.decode()[b0:b1];af=after.decode()[a0:a1]
ck('all bytes before affected function unchanged',before[:b0]==after[:a0]);ck('all bytes after affected function unchanged',before[b1:]==after[a1:])
ck('large ReferenceEval type and dispose exact unchanged',before[:b0]==after[:a0] and 'static void reference_sources_dispose(ReferenceEval *ctx)'in before[:b0].decode())
ck('candidate persistence condition unchanged','if(g_active_app_candidate&&w==&g_active_app_candidate->after){'in bf and 'if(g_active_app_candidate&&w==&g_active_app_candidate->after){'in af)
persistent="""    if(g_active_app_candidate&&w==&g_active_app_candidate->after){
        ctx=app_candidate_evaluation_state(g_active_app_candidate->control);
        if(!ctx||ctx->world!=w)ctx=reference_sources_begin_candidate(w);
        if(!ctx)return false;persistent=true;
"""
ck('persistent lookup/recreate/failed return byte unchanged',bf.count(persistent)==af.count(persistent)==1)
ck('persistent branch assigns ctx before all reads',persistent.index('ctx=app_candidate_evaluation_state')<persistent.index('if(!ctx||ctx->world'))
ck('failed candidate returns before post-branch access',persistent.index('if(!ctx)return false;')<persistent.index('persistent=true;'))
fallback='    }else{\n        local=(ReferenceEval){0};ctx=&local;\n    }\n    ctx->world=w;bool ok=true;'
ck('exhaustive else zero initializes local before binding',af.count(fallback)==1)
ck('no local reference in persistent branch','local' not in persistent)
ck('local variable has exactly declaration/init/address references',len(re.findall(r'\blocal\b',af))==3)
ck('ctx declaration uninitialized but exclusive assignments exhaustive','ReferenceEval local,*ctx;bool persistent=false;'in af and af.count('}else{')==1)
body='    ctx->world=w;bool ok=true;'
ck('entire evaluation/reset/return/disposal tail unchanged',bf[bf.index(body):]==af[af.index(body):])
ck('fallback error disposal retained','if(!persistent)reference_sources_dispose(ctx); return false;'in af)
ck('fallback normal disposal retained','if(!persistent)reference_sources_dispose(ctx);return ok;'in af)
ck('world state mutation follows ctx binding',af.index('ctx->world=w')>af.index('local=(ReferenceEval){0};ctx=&local;'))
ck('no new goto/longjmp/memcpy branch',not any(x in af for x in ['goto ','longjmp','memcpy(']))
ck('no product threshold/capacity/SSOT change',all(x not in patch.decode() for x in ['#define','公理層','決策佇列','WORLD_MAX_TIMBERS +','timeout']))
analysis=[
 'All paths reaching ctx->world assign ctx: persistent branch assigns the candidate state, optionally recreates it, and returns on NULL; the exhaustive else initializes the local value then binds its address.',
 'The unused local may remain indeterminate only in the persistent branch, where no reference to local escapes or is read. This is defined C behavior for an ordinary automatic non-VLA object.',
 'For fallback, struct assignment from (ReferenceEval){0} initializes every member with the same semantic zero/null values as the old aggregate initializer. No new representation/memcmp assumption is introduced; untouched ReferenceEval consumers remain unchanged.',
 'Persistent ownership, failure handling and fallback cleanup are identical. Both failed-datum and normal exits keep !persistent disposal; candidate-owned state is never redirected to the automatic local.',
 'No frame-size reduction or O2 improvement is proved by this review. A compound literal may affect code generation; original compile/runtime and causal work proof remain necessary. Any padding representation differences are not a newly observable interface in the unchanged code.'
]
coverage=['no active candidate -> initialized fallback + disposal','active candidate with another World -> initialized fallback + disposal','matching candidate with existing matching context -> persistent context, unused local','matching candidate with missing/mismatched context -> unchanged recreation','candidate recreation failure -> unchanged false return before ctx dereference/disposal','datum error and successful final exit -> original ownership-specific disposal']
report={'review_scope':'Independent source/static lifetime and exact-byte review only; no C/compiler/runtime/performance test','source_sha':m['source_sha'],'subject':{k:m[k]for k in ['path','before_sha256','after_sha256','patch_sha256']},'checks':checks,'passed':len(checks),'failed':0,'findings':[],'analysis':analysis,'runtime_cases_recommended_to_owner':coverage,'remaining_unverified':['actual C compile and run','zero-work causal proof under original compiler','unaltered output/diagnostics/graph under original affected suites','new final N16 performance result'],'C_run':False,'source_modified':False,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':len(checks),'failed':0,'review':str(O/'REVIEW.json'),'sha256':H((O/'REVIEW.json').read_bytes())}))
