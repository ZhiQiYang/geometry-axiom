from pathlib import Path
import datetime,hashlib,json
P=Path('/tmp/geo300-member-sort-current-prbody');O=Path('/tmp/geo300-member-sort-current-body-peer');O.mkdir(exist_ok=True)
b=(P/'PR_BODY.md').read_bytes();text=b.decode();request=json.loads((P/'PR_REQUEST.json').read_text());binding=json.loads((P/'BINDING.json').read_text());checks=[]
h=lambda raw:hashlib.sha256(raw).hexdigest()
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
ck('pinned body hash',h(b)==binding['body_sha256']=='b23073c2c6154c36f9163800612667f15f4d6dab8d000c762e014f0cba545375')
ck('pinned request hash',h((P/'PR_REQUEST.json').read_bytes())==binding['request_sha256']=='98248b1774f566a7df30d38c6a01b48765deb218d2a2fea8a47c3a279e183b6d')
ck('exact five-field request',set(request)=={'head','base','title','body_ref','body_path'} and request['head']=='codex/geo300-contact-index-20261024' and request['base']=='codex/geo260-ac23-proof-20261024' and request['body_ref']==request['head']+'-prbody' and request['body_path']=='PR_BODY.md')
ck('fixed new product/evidence in text',binding['source']=='cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041' and binding['evidence']=='17e74d3233a76b1967cd132ccb69769e7f9a41a3' and binding['source']in text and binding['evidence']in text)
ck('one matrix',text.count('| 唯一 current-state 矩陣 |')==1 and text.count('| --- | --- |')==1)
ck('new34and64unrun','**UNRUN：34 方法／64 控制**'in text and binding['current_subject']=='UNRUN34/64')
ck('three exact current original suites unrun',all(v in text for v in ['12 方法／41 具名控制','15 方法／11 控制','7 方法／12 控制']))
ck('historical S1ee result identity',binding['historical_subject']=='S1ee33/56/302 only' and '僅 `1ee4e830399b124ebd63c5ff51064d87e53f38d9`'in text and '沒有改標新排序來源'in text)
ck('wholeoptwithdraw notkill','**UNRUN**；本 S 另規劃 8 原正例'in text and '不計 killed、不冒完整 12 方法 suite'in text)
ck('stack and512 notclaimed','新 S **UNRUN**'in text and 'compiler frame／完整場景上限未另量'in text and '**UNMEASURED／UNRUN／未完成未驗**'in text)
ck('fullnative browser ledger arch unrun','| 完整 native、browser、全帳本、架構 | 新 S **UNRUN**'in text)
ck('notready',binding['READY']is False and '**NOT READY**'in text)
ck('original env failures and limits retained','apply-check exit1'in text and 'r2 只從同 HEAD 精確 restore 該原檔'in text and '非解碼前OS bytes'in text and '沒有獨立host OS capture'in text)
ck('no new threshold axiom','N128/256/512的提議數值沒有採為門檻，不改公理或決策佇列'in text)
report={'schema':'geo300-member-sort-current-body-static-peer/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Pinned small prepared body/request/binding only; no algorithm/package/actual proof repeated and no subject run.','bodySHA256':h(b),'requestSHA256':h((P/'PR_REQUEST.json').read_bytes()),'checkCount':len(checks),'checks':checks,'findings':[r['label']for r in checks if not r['passed']],'limits':['Source/evidence normal-push identities and historical actual counts are owner-provided context here; this prose peer does not repeat those original Git/actual reviews.','All new S subject cases remain UNRUN; static283/12 checks are never counted as C methods.']}
report['exitCode']=int(bool(report['findings']));p=O/'REVIEW.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'findings':report['findings'],'exitCode':report['exitCode']}));raise SystemExit(report['exitCode'])
