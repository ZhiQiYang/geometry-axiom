from pathlib import Path
import datetime,hashlib,json
P=Path('/tmp/geo300-contact-source-anchor-current-prbody');O=Path('/tmp/geo300-anchor-current-body-peer');O.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest();body=(P/'PR_BODY.md').read_bytes();text=body.decode();request=json.loads((P/'PR_REQUEST.json').read_text());binding=json.loads((P/'BINDING.json').read_text());checks=[]
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
ck('final frozen body hash',h(body)==binding['body_sha256']=='ab16ac3c7ccc1acaca443e746782a6bc5bfb604b4540681124a185168c6531d7')
ck('same fivefieldrequest hash',h((P/'PR_REQUEST.json').read_bytes())==binding['request_sha256']=='98248b1774f566a7df30d38c6a01b48765deb218d2a2fea8a47c3a279e183b6d')
ck('exact branch/base/body fields',set(request)=={'head','base','title','body_ref','body_path'} and request['head']=='codex/geo300-contact-index-20261024' and request['base']=='codex/geo260-ac23-proof-20261024' and request['body_ref']==request['head']+'-prbody' and request['body_path']=='PR_BODY.md')
ck('new source and evidence identified',binding['source']=='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec' and binding['evidence']=='03c8b4a203323d49b7f42a1775271c79021c08bf' and binding['source']in text and binding['evidence']in text)
ck('unique currentmatrix',text.count('| 唯一 current-state 矩陣 |')==1)
ck('new34and64UNRUN','**UNRUN：34 方法／64 控制**'in text and binding['current_subject']=='UNRUN34/64 and tuple0/1/0')
ck('priorcc2redpreserved','wood12/41 exit0、contact-sources15 exit1、ReadingA7/12 exit0；318 builds全0、0skip'in text and 'outer／primary／reaper／launcher皆1'in text and binding['prior_cc2_trial']=='wood0/contact-sources1/readingA0 retained;318build0')
ck('newtupleproofunrun','新S的綠燈尚未跑'in text and '0/1/0（8原controls，非完整15方法或11控制）'in text)
ck('fivescopeleaveswithoutproductrewrite','產品與 `cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041` 同 bytes'in text and '共五leaf'in text and 'tests/test_geo261_contact_sources.py'in text)
ck('priorhistoricalidentity','僅 `1ee4e830399b124ebd63c5ff51064d87e53f38d9`'in text and '302 builds'in text)
ck('currentnotready',binding['READY']is False and '**NOT READY**'in text)
ck('rawstillpendingpublicationhonest','不宣稱已公開全raw'in text and '完整封包與actual/public peer待下一實際批次'in text)
ck('stderrwhitespaceoriginalretained','git diff --check` 原exit2'in text and '沒有修改原stdout／stderr'in text)
ck('conservativefirstdynamicsentencecorrected','本 S 動態尚未跑'in text and '首次動態尚未跑'not in text)
ck('wholeoptandperformanceunrun','8 原正例'in text and '不計 killed'in text and '**UNMEASURED／UNRUN／未完成未驗**'in text)
report={'schema':'geo300-anchor-current-body-static-peer/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only pinned prepared body/request/binding precision, preserving actual old red and new-source UNRUN. No source/algorithm/actual/package/remote checks repeated.','bodySHA256':h(body),'requestSHA256':h((P/'PR_REQUEST.json').read_bytes()),'checkCount':len(checks),'checks':checks,'findings':[x['label']for x in checks if not x['passed']],'limits':['Owner-provided source/evidence push identity and prior actual counts are context, not independently re-proven in this prose-only peer.','The earlier producer-saved collaboration acceptance is distinct from this later formal report.']}
report['exitCode']=int(bool(report['findings']));p=O/'REVIEW.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'findings':report['findings'],'exitCode':report['exitCode']}));raise SystemExit(report['exitCode'])
