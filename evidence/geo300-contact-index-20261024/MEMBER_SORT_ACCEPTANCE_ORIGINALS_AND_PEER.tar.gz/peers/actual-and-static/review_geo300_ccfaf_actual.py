from pathlib import Path
import json,hashlib,ast,subprocess,re
D=Path('/tmp/train337-adversarial');P=Path('/workspace/geo300-member-sort-three-suites-r2');DEL=Path('/tmp');R='/workspace/geo300-contact-index-work';F='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec';OLD=F;checks=[];reads=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,v):checks.append({'name':n,'pass':bool(v)})
def j(p):return json.loads(Path(p).read_text())
def git(path):
 r=subprocess.run(['git','-C',R,'show',F+':'+path],capture_output=True);assert r.returncode==0;reads.append({'path':path,'sha256':sha(r.stdout),'exit':r.returncode});return r.stdout
indexpath=Path('/tmp/geo300-member-sort-r2-RAW_INDEX.json');rawindex=j(indexpath)
index={'source':rawindex['source'],'count':rawindex['original_raw_files'],'bytes':rawindex['original_raw_bytes'],'entries':[dict(path=x['path'],archive_path=x['label'],bytes=x['bytes'],sha256=x['sha256']) for x in rawindex['raw_index']]}
r=j(P/'receipt.json');launch=j('/workspace/geo300-member-sort-three-suites-r2-launch/receipt.json');summary={'suites':[]}
for suite in r['suites']:
 events=[json.loads(line) for line in (P/suite['suite']/'native-executions.jsonl').read_text().splitlines()];groups={}
 for number,event in enumerate(events,1):
  if event.get('phase') in ('baseline','mutant','restored') and event.get('control'):
   groups.setdefault(event['control'],[]).append((number,event))
 proofs=[{'control':name,'case':pairs[0][1]['case'],'expected_assertion':next(event['expected_assertion'] for number,event in pairs if event['phase']=='mutant'),'native_row_numbers':[number for number,event in pairs]} for name,pairs in groups.items()]
 summary['suites'].append({'suite':suite['suite'],'events':len(events),'control_proofs':proofs})
ck('rawindex immutable',sha(indexpath.read_bytes())=='b3a19d8bf1be0c9096b1e7dcb3ed3c96eb00e4b020ab5778a736c18953dcbabe');ck('365 fullrawbytes',index['source']==F and index['count']==len(index['entries'])==365 and index['bytes']==sum(x['bytes'] for x in index['entries'])==21299303)
for x in index['entries']:b=Path(x['path']).read_bytes();ck('raw '+x['archive_path'],len(b)==x['bytes'] and sha(b)==x['sha256'])
ck('same source HEAD/tree and clean',r['source']==F and r['accepted'] and r['actual_source_identity']==r['source_after_identity'] and r['actual_source_identity'][0]==F and r['source_after_clean']);ck('private slot2 /16MiB /no perfledger',r['stack_after'][0]==16777216 and r['secondary_lock']=='/tmp/g261r3/secondary.lock' and r['R3_lock_taken'] is False and r['global_ledger_written'] is False and r['cost_or_performance_run'] is False and r['outer_subject_timeout'] is None and r['original_child_limits_unchanged']);ck('reaper original0',launch['reaper_process_exit']==launch['primary_returncode']==launch['launcher_exit']==0 and launch['reaper_complete_events']==1 and launch['metadata_problems']==[])
commands=r['commands']+launch['commands']
for i,c in enumerate(commands):
 ck('c387 original0 '+str(i),c['actual_process_returncode']==0 and not c['timeout_expired'])
 for stream in ['stdin','stdout','stderr']:
  b=(Path(c['directory'])/(stream+'.bin')).read_bytes();ck('c387 stream '+str(i)+' '+stream,sha(b)==c[stream+'_sha256'])
ck('pretransition SHA honest',all(c['source_sha']==OLD for c in r['commands'][:5]) and all(c['source_sha']==F for c in r['commands'][5:]));ck('S index beforeafter exact',(Path(r['commands'][7]['directory'])/'stdout.bin').read_bytes()==(Path(r['commands'][13]['directory'])/'stdout.bin').read_bytes());ck('source clean original beforeafter',(Path(r['commands'][6]['directory'])/'stdout.bin').read_bytes()==(Path(r['commands'][12]['directory'])/'stdout.bin').read_bytes()==b'')
original_observer=Path('/tmp/free-end-retain-original-suite.py').read_bytes();ck('observer original pin',sha(original_observer)=='875213bbe26941626cadb844ad3ac4ff35f5540a317045435d7782d3c4ed9762');bindings=[row['binding'] for row in r['suites']]
for bind in bindings:
 b=Path(bind['path']).read_bytes();ck('observer literal only '+bind['suite'],b==original_observer.replace(b'tests/test_geo261_wood_contact_world.py',bind['target'].encode()) and sha(b)==bind['bound_sha256'])
def constants(src):
 env={}
 def val(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,(ast.Tuple,ast.List)):return tuple(val(x) for x in n.elts)
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):return val(n.left)+val(n.right)
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='replace':return val(n.func.value).replace(*[val(x) for x in n.args])
  raise ValueError(type(n).__name__)
 for n in ast.parse(src).body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:env[n.targets[0].id]=val(n.value)
   except (ValueError,KeyError,TypeError,AttributeError):pass
 return env
allcounts=[];summaries=[]
for row,wantedbuilds,wantedmethods,wantedcontrols,cs in zip(r['suites'],[147,85,86],[12,15,7],[41,11,12],summary['suites']):
 name=row['suite'];source=git(row['target']);env=constants(source);methods=[n.name for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];ck(name+' original methods count',len(methods)==wantedmethods)
 c=row['command'];txt=(Path(c['directory'])/'stderr.bin').read_text();ck(name+' exact original unittest allpass',row['source']==F and row['actual_exit']==0 and 'Ran '+str(wantedmethods)+' tests' in txt and txt.rstrip().endswith('OK') and 'skipped' not in txt and 'FAIL:' not in txt and 'ERROR:' not in txt and all(m in txt for m in methods))
 events=[json.loads(l) for l in (P/name/'native-executions.jsonl').read_text().splitlines()];ck(name+' control summary exact count',cs['suite']==name and cs['events']==len(events) and len(cs['control_proofs'])==wantedcontrols)
 for x in cs['control_proofs']:
  es=[events[i-1] for i in x['native_row_numbers']];ck(name+' control phase raw '+x['control'],[e['phase'] for e in es]==['baseline','mutant','restored'] and [e['actual_exit'] for e in es]==[0,1,0] and all(e['control']==x['control'] and e['case']==x['case'] for e in es) and all(e.get('timeout_expired') is not True for e in es));ck(name+' precise normal assertion '+x['control'],es[1]['stderr']=='ASSERT:'+x['expected_assertion']+'\n' and es[1]['stdout']=='' and es[1]['expected_assertion']==x['expected_assertion']);ck(name+' baseline restored same exe '+x['control'],es[0]['executable_sha256']==es[2]['executable_sha256'] and es[1]['executable_sha256']!=es[0]['executable_sha256'])
 for i,e in enumerate(events):ck(name+' event binding/env '+str(i),e['source_sha']==F and e['environment']['TMPDIR']=='/workspace/geo300-member-sort-three-suites-r2-tmp' and e['environment']['PYTHONOPTIMIZE'] is None and e.get('timeout_expired') is not True)
 ret=j(P/name/'compile-retention/retention.json');sources={};builds=[]
 for entry in ret:
  b=Path(entry['retained']).read_bytes();ck(name+' build log pin',sha(b)==entry['sha256'] and len(b)==entry['bytes']);builds+=json.loads(b)
  for x in entry['compiled_sources']:
   b=Path(x['retained']).read_bytes();ck(name+' retained C '+x['original'],len(b)==x['bytes'] and sha(b)==x['sha256']);sources.setdefault(Path(x['original']).name,[]).append(b)
 ck(name+' original build count exits',len(builds)==row['compile_commands']==wantedbuilds and all(x['exit']==0 and isinstance(x['stdout'],str) and isinstance(x['stderr'],str) and '\ufffd' not in x['stdout']+x['stderr'] for x in builds));allcounts.append(len(builds))
 if name=='wood-contact':
  product=git('geometry-templates/woodworking/native/contact_world.c').decode().replace('\r\n','\n');ck('W baseline exact product',sources['contact_world.c']==[product.encode()]);controls=env['CONTROLS'];ck('W41 exact registry',len(controls)==41 and {x[0] for x in controls}=={x['control'] for x in cs['control_proofs']})
  for control,before,after,case,assertion in controls:
   ck('W exact mutation '+control,product.count(before)==1 and sources['contact-world-'+control+'.c']==[product.replace(before,after).encode()])
   proof=next(x for x in cs['control_proofs'] if x['control']==control);ck('W original assertion and case '+control,proof['case']==case and proof['expected_assertion']==assertion)
  extra=[e for e in events if e.get('phase')=='product-mutant-client'];ck('W extra atomic separate normalassert',len(extra)==1 and extra[0]['control']=='owner-extension' and extra[0]['actual_exit']==1 and extra[0]['stderr']=='ASSERT:owner-extension-outside-fixed-part\n')
 elif name=='contact-sources':
  src=git('geometry-templates/woodworking/native/contact_sources.c').decode().replace('\r\n','\n');instrument=env['HOOK_DECLARATION']+src.replace(env['FEATURE_RETURN'],env['FEATURE_HOOK']);ck('contact instrumentation exact original',sources['contact-sources-instrumented.c']==[instrument.encode()] and src.count(env['FEATURE_RETURN'])==1)
  for control,module,case,marker,before,after in env['CONTROLS']:
   product=instrument if module=='contact_sources' else git('geometry-templates/woodworking/native/'+module+'.c').decode().replace('\r\n','\n');ck('contact exact mutation '+control,product.count(before)==1 and sources['contact-source-control-'+control+'.c']==[product.replace(before,after).encode()])
  for control,before,after in env['COLLECTION_CACHE_CONTROLS']:ck('contact collection exact '+control,instrument.count(before)==1 and sources['contact-collection-control-'+control+'.c']==[instrument.replace(before,after).encode()])
 else:
  for control,module,before,after,case,assertion in env['CONTROLS']:
   product=git('geometry-templates/woodworking/native/'+module+'.c').decode().replace('\r\n','\n');ck('readingA exact mutation '+control,product.count(before)==1 and sources['geo318-'+control+'.c']==[product.replace(before,after).encode()])
  manifests=[]
  for role in ['host-baseline','host-withdrawn']:
   d=P/name/'host-source-artifacts'/role;m=j(d/'source-manifest.json');manifests.append(m);ck(role+' sourcebinding four',m['source_git_sha']==F and len(m['files'])==4)
   for x in m['files']:
    raw=(d/'original'/x['path']).read_bytes();derived=(d/'relocated'/x['path']).read_bytes();lf=raw.decode().replace('\r\n','\n');variant=lf
    if role=='host-withdrawn' and x['path']=='geometry-core/references.inc':variant=lf.replace('if(!wood_contact_end_support_check(admission,hits,a->has_between,detail,sizeof detail))','if(!hits || (!a->has_between && hits!=1))')
    ck(role+' original Git and derived '+x['path'],raw==git(x['path']) and sha(raw)==x['source_raw_sha256'] and sha(lf.encode())==x['source_lf_sha256'] and sha(variant.encode())==x['semantic_variant_sha256'] and sha(derived)==x['relocated_raw_sha256'])
  b,w=({x['path']:x for x in m['files']} for m in manifests);ck('host only exact delegated predicate semantic',{p for p in b if b[p]['semantic_variant_sha256']!=w[p]['semantic_variant_sha256']}=={'geometry-core/references.inc'} and {p for p in b if b[p]['relocated_directory_normalized_sha256']!=w[p]['relocated_directory_normalized_sha256']}=={'geometry-core/references.inc'})
 summaries.append({'suite':name,'methods':wantedmethods,'controls':wantedcontrols,'events':len(events),'compile_commands':len(builds),'exit':row['actual_exit']})
ck('34methods64controls318build',sum(x['methods'] for x in summaries)==34 and sum(x['controls'] for x in summaries)==64 and sum(allcounts)==318)
report={'schema':'geo300-ccfaf-three-original-suites-actual-peer/1','source_sha':F,'summary':summaries,'check_count':len(checks),'findings':[x for x in checks if not x['pass']],'exit_code':int(any(not x['pass'] for x in checks)),'git_reads':reads,'scope':'365原件逐bytes/hash；三原suite34methods、64control精確ASSERT0/1/0、318原編譯/連結exit0；source/observer/每mutation與host4files核對。','limitations':['固定ccfaf原三suite，不是L或其他SHA/fullnative/browser/完整ledger/performance/容量512。','NativeBuild原text stdout/stderr非predecode OS pipes；原temporary ELF正常cleanup，exe hashes保。','原cc2三suite0/1/0與placement-order control失敗永久保留，不回填。','新tuple撤回反證另外核，不能由三suite綠冒已證。','無新增產品執行；只是讀immutable Git與已終態原件。']};o=D/'GEO300_CCFAF_THREE_SUITES_ACTUAL_PEER.json';o.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(o),'sha256':sha(o.read_bytes()),'checks':len(checks),'exit':report['exit_code'],'findings':report['findings']},ensure_ascii=False));raise SystemExit(report['exit_code'])
