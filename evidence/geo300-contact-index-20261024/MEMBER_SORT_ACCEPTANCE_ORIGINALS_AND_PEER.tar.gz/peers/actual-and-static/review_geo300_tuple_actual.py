from pathlib import Path
import ast,json,hashlib,subprocess
P=Path('/workspace/geo300-contact-source-tuple-control');S='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec';R='/workspace/geo300-contact-index-work';D=Path('/tmp/train337-adversarial');n=0;bad=[]
def ck(k,v):
 global n
 n+=1
 if not v:bad.append(k)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_bytes())
def git(p):return subprocess.check_output(['git','-C',R,'show',S+':'+p])
idxpath=Path('/tmp/geo300-contact-source-tuple-RAW_INDEX.json');idx=j(idxpath);r=j(P/'receipt.json');launch=j('/workspace/geo300-contact-source-tuple-control-launch/receipt.json')
ck('exact full index pin',sha(idxpath)=='0f5140722dd078b8a97642c141898f0ada35b71f3ab342bcb7543640a7f87322');ck('exact289 raw count',idx['original_raw_files']==len(idx['raw_index'])==289 and idx['original_raw_bytes']==sum(x['bytes'] for x in idx['raw_index'])==12881417)
for x in idx['raw_index']:p=Path(x['path']);ck('raw '+x['label'],p.stat().st_size==x['bytes'] and sha(p)==x['sha256'])
ck('fixed source accepted terminal',r['source']==S and r['accepted'] and r['ended_utc'] and r['source_restored_clean']);ck('exact phases0/1/0',[p['actual_exit'] for p in r['phases']]==[0,1,0] and [p['phase'] for p in r['phases']]==['fixed','withdrawn','restored']);ck('outer/reaper/primary0',launch['reaper_process_exit']==launch['primary_returncode']==launch['launcher_exit']==0 and launch['reaper_complete_events']==1 and not launch['metadata_problems']);ck('original resource scope',r['stack_after'][0]==16777216 and r['secondary_lock']=='/tmp/g261r3/secondary.lock' and not r['R3_lock_taken'] and r['outer_subject_timeout'] is None and not r['global_ledger_written'] and r['original_child_limits_unchanged'])
for i,c in enumerate(r['commands']+launch['commands'],1):
 ck('original command terminal '+str(i),c['ended_epoch'] and not c['timeout_expired'])
 for k in ['stdin','stdout','stderr']:ck('original command '+str(i)+k,sha(Path(c['directory'])/(k+'.bin'))==c[k+'_sha256'])
def out(i):return (Path(r['commands'][i-1]['directory'])/'stdout.bin').read_bytes()
ck('original clean+HEAD tree source firstlast',out(1)==out(11) and out(1).decode().splitlines()==r['source_after_identity'] and r['source_after_identity'][0]==S and out(2)==out(12)==b'');ck('original index firstlast bytes',out(3)==out(13));ck('only changed judge in withdraw',out(5)==out(9)==b'' and out(7)==b'tests/test_geo261_contact_sources.py\n')
fixed=git('tests/test_geo261_contact_sources.py');before=Path('/tmp/geo300-contact-source-anchor-cc2/before.py').read_bytes();product=git('geometry-templates/woodworking/native/contact_world.c').decode().replace('\r\n','\n');ck('fixed judge leaf original pin',hashlib.sha256(fixed).hexdigest()=='8fe6a68c93770ba6cf0521f829ed1f9faf9f3b3d5891b96a76575fd9e31b4694');ck('original product Git bytes',out(4).decode().replace('\r\n','\n')==product)
observer=Path('/tmp/free-end-retain-original-suite.py').read_bytes();method='NativeContactSources.test_eight_negative_controls_fail_only_the_named_semantic_assertion';expected=observer.replace(b"target='tests/test_geo261_wood_contact_world.py'",b"target='tests/test_geo261_contact_sources.py'").replace(b'sys.argv=[target]',('sys.argv=[target,'+repr(method)+']').encode());ck('original observer body onlytarget+method',expected==(P/'retain-original-method.py').read_bytes());controls={}
for node in ast.parse(fixed).body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in node.targets):controls={ast.literal_eval(x.elts[0]):(ast.literal_eval(x.elts[2]),ast.literal_eval(x.elts[3])) for x in node.value.elts}
ck('original exact8 controls',len(controls)==8)
for phase,want,judge in [('fixed',0,fixed),('withdrawn',1,before),('restored',0,fixed)]:
 pr=next(x for x in r['phases'] if x['phase']==phase);txt=(Path(pr['command']['directory'])/'stderr.bin').read_text();ck(phase+' one method/no skip/exactexit',pr['actual_exit']==want and 'Ran 1 test' in txt and 'skipped' not in txt and pr['judge_sha256']==hashlib.sha256(judge).hexdigest());ck(phase+' exact unittest outcome',('FAILED (failures=1)' in txt and '1 != 0 : Control did not fail a normal assertion: PASS ordering' in txt) if want else txt.rstrip().endswith('OK'))
 es=[json.loads(l) for l in (P/phase/'native-executions.jsonl').read_text().splitlines()];groups={}
 for e in es:
  if e.get('control'):groups.setdefault(e['control'],[]).append(e)
 ck(phase+' exact original8 groups',set(groups)==set(controls))
 for control,(case,marker) in controls.items():
  events=groups[control];special=phase=='withdrawn' and control=='placement-order';ck(phase+control+' phases', [e['phase'] for e in events]==(['baseline','mutant'] if special else ['baseline','mutant','restored']));ck(phase+control+' exits',[e['actual_exit'] for e in events]==([0,0] if special else [0,1,0]));ck(phase+control+' case/source',all(e['case']==case and e['source_sha']==S for e in events))
  mutant=events[1];ck(phase+control+' normal exact assertion',mutant['stdout']=='PASS ordering\n' and mutant['stderr']=='' if special else mutant['stdout']=='' and mutant['stderr']=='ASSERT:'+marker+'\n')
  if not special:ck(phase+control+' restored baseline exe',events[0]['executable_sha256']==events[2]['executable_sha256'])
 logs=j(P/phase/'compile-retention/retention.json');build=[];sources={}
 for z in logs:
  ck(phase+' original buildlog',sha(z['retained'])==z['sha256']);build+=j(z['retained'])
  for x in z['compiled_sources']:
   ck(phase+' retained C '+x['original'],sha(x['retained'])==x['sha256']);sources[Path(x['original']).name]=Path(x['retained']).read_bytes()
 ck(phase+'77originalbuilds0',len(build)==pr['compile_commands']==77 and all(x['exit']==0 for x in build))
 anchor=('if(previous<=order)break;','if(true)break;') if want else ('return left<=right;','return true;');ck(phase+' exact placement mutant compiled',product.count(anchor[0])==1 and sources['contact-source-control-placement-order.c']==product.replace(*anchor).encode())
report={'schema':'geo300-original-eight-control-tuple-proof-actual-peer/1','source':S,'check_count':n,'findings':bad,'exit_code':int(bool(bad)),'scope':'原一method八controls三phase0/1/0，231原build0，289完整raw；只撤回/恢復已審tuple，產品不改。','limits':['非full15methods/all11controls，不是whole-optimization withdrawal或性能反證。','withdraw原placement mutant正常PASS ordering0使原meta唯一assert1；沒有把crash當kill。','source_sha為固定Git HEAD；withdraw受控test變異另列，不冒該phaseclean來源。','compiler原text streams非predecode OS pipes；沒有重新執行subject。']};p=D/'GEO300_CCFAF_TUPLE_ACTUAL_PEER.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),'checks':n,'exit_code':report['exit_code'],'findings':bad},ensure_ascii=False));raise SystemExit(report['exit_code'])
