import ast,collections,hashlib,json,pathlib,re,subprocess,sys
B=pathlib.Path('/tmp/geo300-member-sort-1ee4-20261024');R=pathlib.Path('/workspace/geo300-contact-index-work');M=json.loads((B/'DRAFT_MANIFEST.json').read_bytes());C=json.loads((B/'CURRENT.json').read_bytes());S=M['product_base'];checks=0;findings=[];H=lambda b:hashlib.sha256(b).hexdigest()
def ck(v,label):
 global checks
 checks+=1
 if not v:findings.append(label)
ck(S=='1ee4e830399b124ebd63c5ff51064d87e53f38d9','fixed base')
ck(H((B/'DRAFT.patch').read_bytes())=='03466cd53c88b8eaa380d374c1073f689d871256585d8c257180fd41e45eb5a9','patch pin')
ck(H((B/'DRAFT_MANIFEST.json').read_bytes())=='692c9c478d0d54ade2bb29dfc66e52ab5ebd5322a060caa76ac933ea061be9f5','manifest pin')
for name,entry in C['files'].items():
 b=(B/name).read_bytes();ck(len(b)==entry['bytes'] and H(b)==entry['sha256'],'fixed '+name)
old={};new={}
for x in M['files']:
 name=x['path'];p=subprocess.run(['git','-C',str(R),'show',S+':'+name],capture_output=True);ck(p.returncode==0,'Git read '+name);old[name]=p.stdout;new[name]=(B/'candidate'/name).read_bytes();ck(H(p.stdout)==x['before_sha256'],'original '+name);ck(H(new[name])==x['candidate_sha256'],'candidate '+name)
ck(set(old)=={'geometry-templates/woodworking/native/contact_world.c','tests/geo261_contact_world_harness.c','tests/test_geo261_wood_contact_world.py','tests/run_all.expected.json'},'four paths only')
P='tests/test_geo261_wood_contact_world.py';ot=ast.parse(old[P]);nt=ast.parse(new[P]);of={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ot) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};nf={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(nt) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
for name,value in of.items():ck(nf.get(name)==value,'old function AST '+name)
ck(len([n for n in of if n.startswith('test_')])==11 and len([n for n in nf if n.startswith('test_')])==12,'actual 11 to12 test methods')
def constants(tree):
 env={}
 def ev(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,(ast.Tuple,ast.List)):return tuple(ev(x) for x in n.elts)
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='replace':return ev(n.func.value).replace(*(ev(x) for x in n.args))
  raise ValueError(ast.dump(n))
 for n in tree.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['STOP_FILTER','CONTROLS'] for t in n.targets):
   for t in n.targets:env[t.id]=ev(n.value)
 return env['CONTROLS']
a=constants(ot);b=constants(nt);ck(len(a)==33 and len(b)==41 and len({x[0] for x in b})==41,'33 to41 unique controls')
co=new['geometry-templates/woodworking/native/contact_world.c'].decode();ho=new['tests/geo261_contact_world_harness.c'].decode()
for control in b:
 name,before,after,case,assertion=control;ck(co.count(before)==1,'single control anchor '+name);ck(before!=after,'nonnoop '+name);ck('CHECK("'+assertion+'"' in ho,'original named C assertion '+name)
 ck('"'+case+'"' in ho,'C dispatch case '+name)
for oldcontrol in a:
 current=next(x for x in b if x[0]==oldcontrol[0]);ck(current[3:]==oldcontrol[3:],'old case/assertion preserved '+oldcontrol[0]);ck(current==oldcontrol or current[0] in ['placement-order','stable-ties'],'onlytwo reanchors '+oldcontrol[0])
ch='tests/geo261_contact_world_harness.c';oldcheck=collections.Counter(x for x in old[ch].decode().splitlines() if 'CHECK(' in x);newcheck=collections.Counter(x for x in ho.splitlines() if 'CHECK(' in x)
ck(not(oldcheck-newcheck),'all old CHECK lines retained')
cp='geometry-templates/woodworking/native/contact_world.c';before=old[cp].decode();begin=before.index('    for(size_t i=1;i<count;++i){');end=before.index('    /* Keep the original live-set deletion order',begin);loop=before[begin:end];ck(co.count(loop)==1,'legacy insertion exact original bytes')
# Exact products outside the two helper insertion/call/guard changes are checked from the patch.
patch=(B/'DRAFT.patch').read_text();ck('公理層.md' not in patch and '決策佇列.md' not in patch,'no SSOT/queue edit')
bo=json.loads(old['tests/run_all.expected.json']);bn=json.loads(new['tests/run_all.expected.json']);changed=[k for k in bo['suites'] if bo['suites'][k]!=bn['suites'][k]];ck(set(bo)==set(bn) and bo['_說明']==bn['_說明'] and set(bo['suites'])==set(bn['suites']) and changed==['py:test_geo261_wood_contact_world'],'one expected key')
ck(bo['suites'][changed[0]]==dict(mode='count',count=11,unit='test') and bn['suites'][changed[0]]==dict(mode='count',count=12,unit='test'),'expected true method count')
rc=json.loads((B/'patch-roundtrip/RECEIPT.json').read_bytes());ck(len(rc['commands'])==4 and all(x['exit']==0 for x in rc['commands']) and rc['all_candidate_and_restored_bytes_equal'] and not rc['subject_executed'],'mechanical apply/reverse original receipt')
manual=[
 'Normal skip-insertion guard equals indexed-dedup eligibility except the latter harmlessly avoids an empty member suffix; duplicate facts and over-capacity retain original insertion and dedup.',
 'Merge stores global indices only in [first,count); bounds use count-start/min and width>=members-width, stable uint64 <= avoids subtraction and truncation. Out remains unchanged during comparator/merge.',
 'Destination-to-source permutation cycles preserve one WoodStopFace then mark each visited mapping identity; disjoint cycles cannot read a previously processed cycle. RC prefix never enters the permutation.',
 'All active bits are true before sorting; count/remaining/first unchanged. The original plane build resets sorted/maximum/rank and overwrites all scratch read during merging, so metadata reuse does not carry stale members into queries.',
 'Literal fixture orders cover RC FREE prefix, 3-cycle/non-power-of-two suffix, equal order/side stability, full uint64, zero/odd cap tail, duplicate last-order and member overflow. Existing reversed/zero spans, filtered duplicates and oversized public buffer remain.',
 'New controls have plausible precise first assertion failures by source inspection: legacy ties preserve ID check but fail side fields; cycle omissions first fail the 3-cycle fields; guard omissions leave duplicate/overflow declaration order. These predictions require real C execution.'
]
r={'schema':'geo300.member-sort-static-peer/1','source_base':S,'patch_sha256':H((B/'DRAFT.patch').read_bytes()),'manifest_sha256':H((B/'DRAFT_MANIFEST.json').read_bytes()),'checks':checks,'exit_code':int(bool(findings)),'findings':findings,'manual_reasoning':manual,'scope':{'old_methods':11,'candidate_methods':12,'controls':41,'three_suite_methods':34,'three_suite_controls':64},'reviewer_correction':{'initial_report':'GEO300_MEMBER_SORT_INITIAL_EXPECTED_SCHEMA.json','initial_exit':1,'reason':'Reviewer treated nested expected suites/count as flat; corrected reviewer only, no candidate edits or subject runs.'},'limits':['Static source/AST/Git/manifest only; no imports, compilation, subject execution, algorithm simulation or performance test.','No accepted dynamic verdict for candidate; 16MiB compiler frame, all 64 real control assertions, whole-fast-path withdrawal and performance remain UNRUN.','Only normal bounded/unique member ordering improves complexity; no claim that the entire collector/load is O(NlogN).']}
o=pathlib.Path('/tmp/train337-adversarial/GEO300_MEMBER_SORT_STATIC_PEER.json');o.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='manual_reasoning'},ensure_ascii=False));print('report_sha256',H(o.read_bytes()));sys.exit(bool(findings))
