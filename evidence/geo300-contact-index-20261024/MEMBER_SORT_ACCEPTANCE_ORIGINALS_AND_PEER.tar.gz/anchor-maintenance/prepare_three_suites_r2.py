#!/usr/bin/env python3
"""Bind the already accepted workspace recorder to the new fixed source only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import sys

BEFORE=Path('/workspace/geo300-contact-index-three-suite-tools')
OUT=Path('/workspace/geo300-member-sort-three-suite-tools-r2')
OLD='1ee4e830399b124ebd63c5ff51064d87e53f38d9'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    source=sys.argv[1]
    if len(source)!=40 or any(c not in '0123456789abcdef' for c in source):raise RuntimeError('full SHA required')
    old_driver=(BEFORE/'run_three_suites.py').read_bytes()
    old_top=(BEFORE/'launch_three_suites.py').read_bytes()
    if sha(old_driver)!='e30754446067a74a64d04d5ad621137a35a18c3bad60a5996cbb18c11f1ac342':raise RuntimeError('original driver drift')
    if sha(old_top)!='4d12e8f2e0ed0b08e316f8cdc27947b1bbb8db185e54302d598d1c3cf28cb9d7':raise RuntimeError('original top drift')
    replacements=[(OLD.encode(),source.encode(),2),
      (b'/workspace/geo300-contact-index-three-suites',b'/workspace/geo300-member-sort-three-suites-r2',3),
      (b"'tests/test_geo261_wood_contact_world.py',11",b"'tests/test_geo261_wood_contact_world.py',12",1)]
    driver=old_driver
    for before,after,hits in replacements:
        if driver.count(before)!=hits:raise RuntimeError('driver binding count drift')
        driver=driver.replace(before,after)
    top=old_top
    for before,after in [(OLD.encode(),source.encode()),
      (b'/workspace/geo300-contact-index-three-suites-launch',b'/workspace/geo300-member-sort-three-suites-r2-launch'),
      (str(BEFORE/'run_three_suites.py').encode(),str(OUT/'run_three_suites.py').encode()),
      (sha(old_driver).encode(),sha(driver).encode())]:
        if top.count(before)!=1:raise RuntimeError('top binding count drift')
        top=top.replace(before,after)
    ast.parse(driver);ast.parse(top)
    OUT.mkdir(exist_ok=False)
    (OUT/'run_three_suites.py').write_bytes(driver)
    (OUT/'launch_three_suites.py').write_bytes(top)
    (OUT/'run_three_suites.before.py.txt').write_bytes(old_driver)
    (OUT/'launch_three_suites.before.py.txt').write_bytes(old_top)
    patch=''
    for name,before,after in [('run_three_suites.py',old_driver,driver),('launch_three_suites.py',old_top,top)]:
        patch+=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=name+'.before',tofile=name))
    (OUT/'ADAPTATION.diff').write_text(patch)
    declaration=dict(source=source,root='/workspace/geo300-contact-index-work',subject_executed=False,
      original_driver_sha256=sha(old_driver),original_launcher_sha256=sha(old_top),
      driver_sha256=sha(driver),launcher_sha256=sha(top),adaptation_sha256=sha(patch.encode()),
      original_child_limits_unchanged=True,original_outer_timeout=None,stack_bytes=16777216,
      disk_preflight_bytes=100*1024*1024,disk_preflight_path='/workspace',new_checkout=False,
      out='/workspace/geo300-member-sort-three-suites-r2',tmp='/workspace/geo300-member-sort-three-suites-r2-tmp',
      runtime_tools='/workspace/geo300-member-sort-three-suites-r2-tools',
      secondary_lock='/tmp/g261r3/secondary.lock',R3_lock_taken=False,
      logical_original_commands=[['python3','-B',p] for p in ['tests/test_geo261_wood_contact_world.py','tests/test_geo261_contact_sources.py','tests/test_geo318_reading_a_native.py']],
      expected_methods=[12,15,7],expected_total_methods=34,expected_controls=[41,11,12],expected_total_controls=64,
      cost_or_performance_run=False,global_ledger_written=False,
      prior_actual_source=OLD,prior_actual_methods=33,prior_actual_controls=56,prior_actual_builds=302)
    (OUT/'PREPARATION.json').write_text(json.dumps(declaration,ensure_ascii=False,indent=2)+'\n')
    (OUT/'README.md').write_text('沿原已審 workspace 版只機械綁定新 SHA、wood-contact 真方法 11→12、獨立新 OUT/TMP/工具路徑及上層 driver hash。保原100MiB workspace守門、16MiB stack、secondary鎖、reaper、完整原streams、原child limits與正常ASSERT。沒有新checkout、沒有全帳本、沒有性能測量。前版33/56/302實證留原S1ee，新34/64在本準備時尚未執行。\n')
    print(json.dumps(declaration,ensure_ascii=False))
if __name__=='__main__':main()
