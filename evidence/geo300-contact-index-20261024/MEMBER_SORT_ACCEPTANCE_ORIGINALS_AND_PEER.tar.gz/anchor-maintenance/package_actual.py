from pathlib import Path
import hashlib,io,json,tarfile
OUT=Path('/tmp/geo300-member-sort-final-delivery')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);files={}
    for label,path in [('r1',Path('/tmp/geo300-member-sort-r1-RAW_INDEX.json')),('r2',Path('/tmp/geo300-member-sort-r2-RAW_INDEX.json')),('tuple',Path('/tmp/geo300-contact-source-tuple-RAW_INDEX.json'))]:
        rows=json.loads(path.read_bytes())['raw_index']
        for row in rows:
            p=Path(row['path']);raw=p.read_bytes()
            if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise RuntimeError('frozen actual input drift '+str(p))
            files[label+'/'+row['label']]=p
        files[label+'/RAW_INDEX.json']=path
    roots=[('stable-sort-draft',Path('/tmp/geo300-member-sort-1ee4-20261024')),
      ('anchor-maintenance',Path('/tmp/geo300-contact-source-anchor-cc2')),
      ('publication/source-first-sparse-failure',Path('/workspace/geo300-member-sort-source-publication')),
      ('publication/source-r2',Path('/workspace/geo300-member-sort-source-publication-r2')),
      ('publication/static-evidence',Path('/tmp/geo300-member-sort-static-publication')),
      ('publication/pretrial-body',Path('/tmp/geo300-member-sort-prbody-publication')),
      ('publication/anchor-source',Path('/workspace/geo300-contact-source-anchor-publication')),
      ('publication/red-progress-original-whitespace-failure',Path('/tmp/geo300-contact-source-anchor-evidence-publication')),
      ('publication/red-progress-resume',Path('/tmp/geo300-contact-source-anchor-evidence-publication-resume')),
      ('publication/anchor-body',Path('/tmp/geo300-contact-source-anchor-prbody-publication')),
      ('pretrial-body',Path('/tmp/geo300-member-sort-current-prbody')),
      ('pretrial-anchor-body',Path('/tmp/geo300-contact-source-anchor-current-prbody')),
      ('peers/runner-r1',Path('/tmp/geo300-member-sort-runner-binding-peer')),
      ('peers/runner-r2',Path('/tmp/geo300-member-sort-runner-r2-binding-peer')),
      ('peers/pretrial-body',Path('/tmp/geo300-member-sort-current-body-peer')),
      ('peers/pretrial-anchor-body',Path('/tmp/geo300-anchor-current-body-peer'))]
    for label,root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file() and not p.is_symlink():files[label+'/'+p.relative_to(root).as_posix()]=p
    names=['GEO300_MEMBER_SORT_STATIC_PEER.json','GEO300_MEMBER_SORT_INITIAL_EXPECTED_SCHEMA.json','review_geo300_member_sort_static.py','review_geo300_member_sort_initial_expected_schema.py.txt',
      'GEO300_CONTACT_SOURCES_ANCHOR_LEAF_PEER.json','GEO300_CONTACT_SOURCES_ANCHOR_INITIAL_COUNT_ASSUMPTION.json','GEO300_CONTACT_SOURCES_TUPLE_TOOL_PEER.json','GEO300_MEMBER_SORT_CC2_ORIGINAL_RED_PEER.json',
      'GEO300_CCFAF_THREE_SUITES_ACTUAL_PEER.json','review_geo300_ccfaf_actual.py','GEO300_CCFAF_TUPLE_ACTUAL_PEER.json','review_geo300_tuple_actual.py']
    for name in names:files['peers/actual-and-static/'+name]=Path('/tmp/train337-adversarial')/name
    for name,path in [('capture.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),('reap_children.py','/workspace/geo261-environment/reap_children.py'),('original-retainer.py','/tmp/free-end-retain-original-suite.py')]:files['shared-tools/'+name]=Path(path)
    files['HOST_TOOL_METADATA.json']=Path('/tmp/geo300-member-sort-HOST_TOOL_METADATA.json')
    pins={'peers/actual-and-static/GEO300_CCFAF_THREE_SUITES_ACTUAL_PEER.json':'1549f3a5ab0b44a19f7f55ac1cd67a5b54f9dbd3bbeae12666613b6b6cfd8668','peers/actual-and-static/GEO300_CCFAF_TUPLE_ACTUAL_PEER.json':'554153ca1a0d5a1b23e62d918e3db03f002758fc4d5120d961ad06d947d96c7e'}
    for name,pin in pins.items():
        if sha(files[name].read_bytes())!=pin:raise RuntimeError('peer drift')
    if any(name.startswith('/') or '..' in Path(name).parts for name in files):raise RuntimeError('unsafe archive name')
    index={name:dict(original_path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for name,p in sorted(files.items())}
    raw_index=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode();(OUT/'PACKAGE_INDEX.json').write_bytes(raw_index)
    archive=OUT/'ORIGINALS_AND_PEER.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for name,p in sorted(files.items()):
            raw=p.read_bytes()
            if len(raw)!=index[name]['bytes'] or sha(raw)!=index[name]['sha256']:raise RuntimeError('input changed while writing')
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;tf.addfile(info,io.BytesIO(raw))
        info=tarfile.TarInfo('PACKAGE_INDEX.json');info.size=len(raw_index);info.mode=0o600;tf.addfile(info,io.BytesIO(raw_index))
    with tarfile.open(archive,'r:gz') as tf:
        members=tf.getmembers()
        if len(members)!=len(files)+1 or len(set(m.name for m in members))!=len(members):raise RuntimeError('duplicate/missing archive member')
        for m in members:
            raw=tf.extractfile(m).read()
            expected=raw_index if m.name=='PACKAGE_INDEX.json' else files[m.name].read_bytes()
            if raw!=expected:raise RuntimeError('roundtrip bytes differ '+m.name)
    summary=dict(source='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec',archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),index_sha256=sha(raw_index),original_files=len(files),original_bytes=sum(x['bytes'] for x in index.values()),regular_members=len(files)+1,roundtrip_all_members=True,r1_red_source='cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041',r1_suite_exits=[0,1,0],r1_builds=[147,85,86],r2_suite_exits=[0,0,0],r2_methods=34,r2_controls=64,r2_builds=318,tuple_scope='one original method/eight controls per phase; not full15/all11 or whole optimization',tuple_exits=[0,1,0],tuple_builds=[77,77,77],three_suite_actual_peer_checks=1222,tuple_actual_peer_checks=693,performance='UNMEASURED',whole_fast_path_equivalence='UNRUN eight-positive subset; not killed',capacity512='UNIMPLEMENTED/UNRUN',full_native_browser_ledger_architecture='UNRUN',READY=False)
    (OUT/'PACKAGE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary))
if __name__=='__main__':main()
