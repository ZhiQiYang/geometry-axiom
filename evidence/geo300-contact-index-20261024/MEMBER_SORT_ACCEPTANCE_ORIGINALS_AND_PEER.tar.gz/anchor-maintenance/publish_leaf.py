#!/usr/bin/env python3
from pathlib import Path
import datetime as dt
import hashlib,json,subprocess
ROOT=Path('/workspace/geo300-contact-index-work')
PUB=Path('/workspace/geo300-contact-index-publication-work')
OUT=Path('/workspace/geo300-contact-source-anchor-publication')
FIX=Path('/tmp/geo300-contact-source-anchor-cc2')
E='17e74d3233a76b1967cd132ccb69769e7f9a41a3'
OLD='cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041'
TARGET='tests/test_geo261_contact_sources.py'
BRANCH='codex/geo300-contact-index-20261024'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    peer=Path('/tmp/train337-adversarial/GEO300_CONTACT_SOURCES_ANCHOR_LEAF_PEER.json')
    if sha(peer.read_bytes())!='c985cdda4211863ded856635acc10c17f0d4adf79fc35dcd1bcee425c1f32c7e':raise RuntimeError('peer drift')
    if sha((FIX/'ANCHOR_ONLY.patch').read_bytes())!='1dec787f8a10604166b7ea420226d27da6cd84dce58dd1bfb17b717d8d3a5c06':raise RuntimeError('patch drift')
    OUT.mkdir(exist_ok=False);rows=[]
    def run(argv):
        d=OUT/f'{len(rows)+1:03d}';d.mkdir();start=dt.datetime.now(dt.timezone.utc).isoformat()
        c=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=180)
        (d/'stdout.bin').write_bytes(c.stdout);(d/'stderr.bin').write_bytes(c.stderr)
        row=dict(number=len(rows)+1,argv=argv,cwd=str(ROOT),exit=c.returncode,started_utc=start,ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),stdout=dict(path=str(d/'stdout.bin'),bytes=len(c.stdout),sha256=sha(c.stdout)),stderr=dict(path=str(d/'stderr.bin'),bytes=len(c.stderr),sha256=sha(c.stderr)))
        rows.append(row);save(d/'receipt.json',row);save(OUT/'COMMANDS.json',rows)
        if c.returncode:raise RuntimeError('Git-only command failed '+str(len(rows)))
        return c.stdout
    if run(['git','rev-parse','HEAD']).decode().strip()!=OLD:raise RuntimeError('old fixed source changed')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('source not clean')
    run(['git','switch',BRANCH]);run(['git','fetch','--no-write-fetch-head','--no-tags',str(PUB),E]);run(['git','merge','--ff-only',E])
    if run(['git','show','HEAD:'+TARGET])!=(FIX/'before.py').read_bytes():raise RuntimeError('leaf before differs')
    run(['git','apply','--check',str(FIX/'ANCHOR_ONLY.patch')]);run(['git','apply',str(FIX/'ANCHOR_ONLY.patch')])
    if (ROOT/TARGET).read_bytes()!=(FIX/'after.py').read_bytes():raise RuntimeError('leaf after differs')
    run(['git','add','--sparse','-f','--',TARGET]);run(['git','diff','--cached','--check'])
    if run(['git','diff','--cached','--name-only']).decode().splitlines()!=[TARGET]:raise RuntimeError('leaf scope differs')
    run(['git','commit','-m','test(GEO-300): target the active contact order comparator'])
    identity=run(['git','rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('source not clean after leaf')
    if run(['git','diff','--name-only',E,identity[0]]).decode().splitlines()!=[TARGET]:raise RuntimeError('source diff escaped')
    run(['git','push','origin',BRANCH])
    if run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()!=[identity[0],'refs/heads/'+BRANCH]:raise RuntimeError('remote differs')
    save(OUT/'PUBLICATION.json',dict(source_sha=identity[0],tree=identity[1],parent=E,branch=BRANCH,changed_paths=[TARGET],product_bytes_same_as=OLD,original_red_source=OLD,original_red_receipt='/workspace/geo300-member-sort-three-suites/receipt.json',peer_sha256=sha(peer.read_bytes()),normal_push_verified=True,new_subject='UNRUN',original_commands='COMMANDS.json'))
    print(json.dumps(dict(source_sha=identity[0],tree=identity[1],publication=str(OUT/'PUBLICATION.json'))))
if __name__=='__main__':main()
