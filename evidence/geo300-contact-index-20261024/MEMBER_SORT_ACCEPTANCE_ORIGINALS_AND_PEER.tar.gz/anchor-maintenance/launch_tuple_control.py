import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

OUT=Path('/workspace/geo300-contact-source-tuple-control-launch')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
REAPER=Path('/workspace/geo261-environment/reap_children.py')
DRIVER=Path('/tmp/geo300-contact-source-anchor-cc2/run_tuple_control.py')
OBSERVER=Path('/tmp/free-end-retain-original-suite.py')
def main():
    if OUT.exists():raise RuntimeError('fresh launch directory required')
    OUT.mkdir()
    tools={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in (CAP,REAPER,DRIVER,OBSERVER)}
    if tools[str(CAP)]!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise RuntimeError('capture changed')
    if tools[str(REAPER)]!='7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760':raise RuntimeError('reaper changed')
    if tools[str(DRIVER)]!='1cbc06221875ceb08c8bf630c93c3de90251ddb6f5be0c8708114137d86d1433':raise RuntimeError('driver changed')
    if tools[str(OBSERVER)]!='875213bbe26941626cadb844ad3ac4ff35f5540a317045435d7782d3c4ed9762':raise RuntimeError('observer changed')
    spec=importlib.util.spec_from_file_location('free_end_top_capture',CAP)
    cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    strip={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD',
           'LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH',
           'COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
    env={k:v for k,v in os.environ.items() if k not in strip and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_'))}
    env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GEO261_REAPER_LOG=str(OUT/'reaper.jsonl'))
    command=[sys.executable,'-B',str(REAPER),sys.executable,'-B',str(DRIVER)]
    request={'schema':'geo300-three-suite-top-launch/1','source':'ccfaf057088a80c7aad4049f1c67e5eedfc2fdec',
             'command':command,'cwd':'/workspace/geo300-contact-index-work','timeout':None,'tools':tools,
             'reaper_log':env['GEO261_REAPER_LOG'],'scope':'root required one original affected method fixed/old-tuple-withdrawn/restored0/1/0; no full suite or performance',
             'environment':{k:env.get(k) for k in ['PYTHONOPTIMIZE','PYTHONDONTWRITEBYTECODE','GEO261_REAPER_LOG','PATH','TMPDIR']}}
    (OUT/'request.json').write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
    rec=cap.Recorder(OUT,env,request['source'])
    row,stdout,stderr=rec.run(command,cwd=request['cwd'],timeout=None,check=False)
    problems=[];ends=[];primary=None
    try:
        events=[json.loads(line) for line in (OUT/'reaper.jsonl').read_text().splitlines()]
        ends=[e for e in events if e.get('event')=='完成']
        if len(ends)!=1:raise RuntimeError('unique completed reaper event required')
        primary=ends[0].get('primary_returncode')
        if type(primary) is not int:raise RuntimeError('integer original primary exit required')
        mapped=primary if primary>=0 else 128-primary
        if mapped!=row['actual_process_returncode']:raise RuntimeError('original primary/reaper exit mapping mismatch')
    except Exception as exc:problems.append(repr(exc))
    request.update(reaper_process_exit=row['actual_process_returncode'],primary_returncode=primary,
                   reaper_complete_events=len(ends),commands=rec.rows,metadata_problems=problems,
                   launcher_exit=2 if problems else row['actual_process_returncode'])
    (OUT/'receipt.json').write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'reaper_exit':row['actual_process_returncode'],'primary_exit':request['primary_returncode'],'stdout':stdout.decode('utf-8',errors='replace'),'stderr':stderr.decode('utf-8',errors='replace')}),flush=True)
    return request['launcher_exit']
if __name__=='__main__':raise SystemExit(main())
