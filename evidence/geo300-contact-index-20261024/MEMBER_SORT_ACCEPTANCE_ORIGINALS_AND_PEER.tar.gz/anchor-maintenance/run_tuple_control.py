"""Original affected unittest method with one reviewed tuple withdrawal.

Uses the existing recorder and unchanged audit-hook body. No product edits,
subprocess interception, test replacement, assertion or timeout changes.
"""
from pathlib import Path
import ast,datetime,fcntl,hashlib,importlib.util,json,os,resource,sys

S='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
ROOT=Path('/workspace/geo300-contact-index-work')
OUT=Path('/workspace/geo300-contact-source-tuple-control')
TMP=Path('/workspace/geo300-contact-source-tuple-control-tmp')
FIX=Path('/tmp/geo300-contact-source-anchor-cc2')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
OBS=Path('/tmp/free-end-retain-original-suite.py')
TARGET='tests/test_geo261_contact_sources.py'
METHOD='NativeContactSources.test_eight_negative_controls_fail_only_the_named_semantic_assertion'
STRIP={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
def sha(b):return hashlib.sha256(b).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    if OUT.exists() or TMP.exists():raise RuntimeError('fresh original proof output/temp required')
    space=os.statvfs('/workspace');available=space.f_bavail*space.f_frsize
    if available<100*1024*1024:
        print(json.dumps(dict(environment_blocked='original100MiB workspace budget unavailable',available_bytes=available,subject_started=False)),flush=True);return 75
    pins={CAP:'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',OBS:'875213bbe26941626cadb844ad3ac4ff35f5540a317045435d7782d3c4ed9762',FIX/'before.py':'b12b36e967feb08be661f39e7f39b450c3f04dc59e91c647e6d4bad6e2a0e94a',FIX/'after.py':'8fe6a68c93770ba6cf0521f829ed1f9faf9f3b3d5891b96a76575fd9e31b4694'}
    for path,pin in pins.items():
        if sha(path.read_bytes())!=pin:raise RuntimeError('fixed input drift '+str(path))
    old=(FIX/'before.py').read_bytes();fixed=(FIX/'after.py').read_bytes()
    if (ROOT/TARGET).read_bytes()!=fixed:raise RuntimeError('fixed source judge not restored before launch')
    OUT.mkdir();TMP.mkdir()
    lock_path=Path('/tmp/g261r3/secondary.lock');lock=lock_path.open('a+b')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return 75
    stack_before=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,stack_before[1]))
    env={k:v for k,v in os.environ.items() if k not in STRIP and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))}
    env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LC_ALL='C.UTF-8',LANG='C.UTF-8')
    spec=importlib.util.spec_from_file_location('tuple_control_capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    rec=cap.Recorder(OUT,env,S)
    receipt=dict(schema='geo300-original-contact-source-method-tuple-control/1',source=S,root=str(ROOT),started_utc=utc(),phases=[],accepted=False,expected_phase_exits=[0,1,0],scope='one original affected method; eight original controls; not full15method suite or all11controls',logical_original_argv=['python3','-B',TARGET,METHOD],secondary_lock=str(lock_path),R3_lock_taken=False,stack_before=stack_before,stack_after=resource.getrlimit(resource.RLIMIT_STACK),original_child_limits_unchanged=True,outer_subject_timeout=None,global_ledger_written=False,source_variant_semantics='withdrawn changes only the old judge tuple; base HEAD SHA is not an exact clean-source claim for that phase')
    save(OUT/'launch-request.json',receipt)
    def run(argv,check=True,phase=None):return rec.run(argv,cwd=ROOT,timeout=None,check=check,source_sha=S,source_variant=phase)
    original_product=None;identity=None;stage=None
    try:
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}']);identity=head.decode().splitlines()
        if identity[0]!=S:raise RuntimeError('wrong source HEAD')
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('source not initially clean')
        _,stage,_=run(['git','ls-files','--stage'])
        _,original_product,_=run(['git','show','HEAD:geometry-templates/woodworking/native/contact_world.c'])
        if (ROOT/'geometry-templates/woodworking/native/contact_world.c').read_bytes()!=original_product:raise RuntimeError('product source differs')
        raw=OBS.read_bytes();before=b"target='tests/test_geo261_wood_contact_world.py'";after=("target='"+TARGET+"'").encode()
        if raw.count(before)!=1 or raw.count(b'sys.argv=[target]')!=1:raise RuntimeError('original observer anchors drift')
        observer_body=raw.replace(before,after).replace(b'sys.argv=[target]',('sys.argv=[target,'+repr(METHOD)+']').encode())
        observer=OUT/'retain-original-method.py';observer.write_bytes(observer_body)
        save(OUT/'OBSERVER_BINDING.json',dict(original_sha256=sha(raw),bound_sha256=sha(observer_body),changes=['target literal','original unittest argv method selection'],audit_hook_body_unchanged=True))
        node=next(n.value for n in ast.parse(fixed).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
        controls={ast.literal_eval(row.elts[0]):ast.literal_eval(row.elts[3]) for row in node.elts}
        if len(controls)!=8 or controls['placement-order']!='contact-placement-order-and-stable-ties':raise RuntimeError('original affected controls differ')
        for phase,body,expected in [('fixed',fixed,0),('withdrawn',old,1),('restored',fixed,0)]:
            where=OUT/phase;where.mkdir();(ROOT/TARGET).write_bytes(body)
            _,diff,_=run(['git','diff','--name-only'],phase=phase)
            if diff.decode().splitlines()!=([TARGET] if phase=='withdrawn' else []):raise RuntimeError('unrelated source change')
            if (ROOT/'geometry-templates/woodworking/native/contact_world.c').read_bytes()!=original_product:raise RuntimeError('product changed')
            env.update(GEO261_CONTACT_SOURCES_EXECUTION_LOG=str(where/'native-executions.jsonl'))
            row,stdout,stderr=run([sys.executable,'-B',str(observer),'--root',str(ROOT),'--artifacts',str(where/'compile-retention')],check=False,phase=phase)
            text=stderr.decode('utf-8',errors='replace')
            events=[json.loads(line) for line in (where/'native-executions.jsonl').read_text().splitlines()]
            proofs=[]
            for name,assertion in controls.items():
                required={'baseline':0,'mutant':1,'restored':0}
                if phase=='withdrawn' and name=='placement-order':required={'baseline':0,'mutant':0}
                for child,exit_code in required.items():
                    matches=[e for e in events if e.get('control')==name and e.get('phase')==child]
                    good=len(matches)==1 and matches[0]['actual_exit']==exit_code
                    if good and child=='mutant' and exit_code==1:good='ASSERT:'+assertion in matches[0]['stderr']
                    if good and phase=='withdrawn' and name=='placement-order' and child=='mutant':good=matches[0]['stdout']=='PASS ordering\n' and not matches[0]['stderr']
                    proofs.append(dict(control=name,phase=child,expected_exit=exit_code,matches=len(matches),passed=good))
            retained=json.loads((where/'compile-retention/retention.json').read_bytes());builds=[]
            for item in retained:
                raw_log=Path(item['retained']).read_bytes()
                if sha(raw_log)!=item['sha256']:raise RuntimeError('retained log changed')
                builds.extend(json.loads(raw_log))
            reason=expected==0 or ('FAILED (failures=1)' in text and '1 != 0 : Control did not fail a normal assertion: PASS ordering' in text)
            result=dict(phase=phase,expected_exit=expected,actual_exit=row['actual_process_returncode'],command=row,judge_sha256=sha(body),one_original_method_reported='Ran 1 test' in text,zero_skips='skipped' not in text,expected_red_reason=reason,control_proofs=proofs,compile_commands=len(builds),all_build_exits_zero=bool(builds) and all(b['exit']==0 for b in builds))
            result['passed']=result['actual_exit']==expected and result['one_original_method_reported'] and result['zero_skips'] and reason and all(p['passed'] for p in proofs) and result['all_build_exits_zero']
            receipt['phases'].append(result);save(where/'receipt.json',result)
            print(json.dumps(dict(phase=phase,exit=result['actual_exit'],expected=expected,passed=result['passed'])),flush=True)
        receipt['accepted']=len(receipt['phases'])==3 and all(p['passed'] for p in receipt['phases'])
    except BaseException as exc:
        receipt['exception']=repr(exc);raise
    finally:
        current=(ROOT/TARGET).read_bytes()
        if current in (old,fixed):(ROOT/TARGET).write_bytes(fixed)
        else:receipt['unknown_judge_bytes_preserved']=True;receipt['accepted']=False
        try:
            _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}']);_,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);_,after_stage,_=run(['git','ls-files','--stage'])
            receipt['source_after_identity']=head.decode().splitlines();receipt['source_restored_clean']=not status and receipt['source_after_identity']==identity and after_stage==stage and (ROOT/TARGET).read_bytes()==fixed
            receipt['accepted']=receipt['accepted'] and receipt['source_restored_clean']
        except BaseException as exc:receipt['post_guard_exception']=repr(exc);receipt['accepted']=False
        receipt['ended_utc']=utc();receipt['commands']=rec.rows;save(OUT/'receipt.json',receipt)
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    return 0 if receipt['accepted'] else 1
if __name__=='__main__':raise SystemExit(main())
