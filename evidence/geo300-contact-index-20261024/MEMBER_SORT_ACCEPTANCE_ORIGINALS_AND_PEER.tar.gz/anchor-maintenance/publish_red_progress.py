from pathlib import Path
import datetime as dt,hashlib,json,subprocess
ROOT=Path('/workspace/geo300-contact-index-publication-work');SOURCE=Path('/workspace/geo300-contact-index-work')
OUT=Path('/tmp/geo300-contact-source-anchor-evidence-publication')
PREFIX='evidence/geo300-contact-index-20261024/';BRANCH='codex/geo300-contact-index-20261024'
S='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec';OLD_E='17e74d3233a76b1967cd132ccb69769e7f9a41a3'
R1=Path('/workspace/geo300-member-sort-three-suites');FIX=Path('/tmp/geo300-contact-source-anchor-cc2')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    OUT.mkdir(exist_ok=False);rows=[]
    def run(argv):
        d=OUT/f'{len(rows)+1:03d}';d.mkdir();start=dt.datetime.now(dt.timezone.utc).isoformat();c=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=180)
        (d/'stdout.bin').write_bytes(c.stdout);(d/'stderr.bin').write_bytes(c.stderr)
        row=dict(number=len(rows)+1,argv=argv,cwd=str(ROOT),exit=c.returncode,started_utc=start,ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),stdout=dict(path=str(d/'stdout.bin'),bytes=len(c.stdout),sha256=sha(c.stdout)),stderr=dict(path=str(d/'stderr.bin'),bytes=len(c.stderr),sha256=sha(c.stderr)))
        rows.append(row);save(d/'receipt.json',row);save(OUT/'COMMANDS.json',rows)
        if c.returncode:raise RuntimeError('publication command failed '+str(len(rows)))
        return c.stdout
    trial=json.loads((R1/'receipt.json').read_bytes())
    if [s['actual_exit'] for s in trial['suites']]!=[0,1,0] or trial['accepted'] or not trial['source_after_clean']:raise RuntimeError('original r1 red facts differ')
    if [s['compile_commands'] for s in trial['suites']]!=[147,85,86] or not all(s['all_build_exits_zero'] and s['zero_skips'] for s in trial['suites']):raise RuntimeError('build/skip facts differ')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('dirty publication')
    run(['git','switch',BRANCH])
    if run(['git','rev-parse','HEAD']).decode().strip()!=OLD_E:raise RuntimeError('old evidence changed')
    run(['git','fetch','--no-write-fetch-head','--no-tags',str(SOURCE),S]);run(['git','merge','--ff-only',S])
    dest=ROOT/PREFIX
    payload={
      'MEMBER_SORT_R1_RED_RECEIPT.json':R1/'receipt.json',
      'MEMBER_SORT_R1_RED_CONTACT_SOURCES.stderr.txt':R1/'subcommands/000010/stderr.bin',
      'MEMBER_SORT_R1_RED_TOP_RECEIPT.json':Path('/workspace/geo300-member-sort-three-suites-launch/receipt.json'),
      'CONTACT_SOURCE_ANCHOR_ONLY.patch':FIX/'ANCHOR_ONLY.patch',
      'CONTACT_SOURCE_ANCHOR_MANIFEST.json':FIX/'MANIFEST.json',
      'CONTACT_SOURCE_ANCHOR_LEAF_PEER.json':Path('/tmp/train337-adversarial/GEO300_CONTACT_SOURCES_ANCHOR_LEAF_PEER.json'),
      'CONTACT_SOURCE_ANCHOR_PUBLICATION.json':Path('/workspace/geo300-contact-source-anchor-publication/PUBLICATION.json')}
    for name,path in payload.items():(dest/name).write_bytes(path.read_bytes())
    previous=json.loads((dest/'BINDING.json').read_bytes())
    binding=dict(schema='geo300-member-sort-anchor-maintenance-current/1',source_sha=S,product_bytes_same_as='cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041',base_branch='codex/geo260-ac23-proof-20261024',formal_methods=34,wood_methods=12,wood_controls=41,all_three_controls=64,subject='UNRUN on repaired judge source',tuple_withdraw_restore='UNRUN original single affected method0/1/0',performance='UNMEASURED',global_ledger_written=False,READY=False,historical_previous_binding=previous,
      prior_trial=dict(source=trial['source'],started_utc=trial['started_utc'],ended_utc=trial['ended_utc'],suite_exits=[0,1,0],suite_builds=[147,85,86],all_build_exits_zero=True,zero_skips=True,outer_exit=1,accepted=False,source_clean=True,red_reason='contact-sources placement-order control changed bypassed insertion fallback; native PASS ordering0 made original meta-test fail',full_originals_state='preserved at original private paths; complete archive/public peer pending next batch',receipt_sha256=sha((R1/'receipt.json').read_bytes())))
    save(dest/'BINDING.json',binding)
    (dest/'PROGRESS.md').write_text('''# GEO-300 排序與跨 suite 反證錨點進度

目前 S `ccfaf057088a80c7aad4049f1c67e5eedfc2fdec`，產品 bytes／expected 與 `cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041` 完全相同，只有 contact-sources placement-order tuple 從舊 insertion break 移到正常 comparator。原 case／具名 ASSERT／15 methods／11 controls／timeout不變；單leaf靜審15／0。

| 目前 S 的項目 | 結果 |
| --- | --- |
| 原三套34 methods／64 controls | UNRUN，等待root原100MiB／secondary槽授權 |
| tuple回撤／恢復 | UNRUN；另用原受影響一方法／8控制 fixed0→舊tuple紅1→restore0，不能冒完整15方法或全部11控制 |
| 16MiB／效能／512／完整native/browser/ledger/arch | 新S未跑／UNMEASURED／NOT READY |

前輪 Scc2 三套已22:47:26.381006～22:47:48.756991 UTC真終態：wood12/41 exit0，contact-sources15 exit1，ReadingA7/12 exit0；147＋85＋86＝318 builds全0，三套0skip，outer／primary／reaper／launcher全1，source HEAD/tree clean。唯一紅為舊placement-order反證還撤已被快路旁路的fallback，原native輸出 PASS ordering／exit0，故原meta-test正常失敗1；不是compile／crash／環境紅。原正常排序行為測項通過。

本批公開完整紅stderr、原inner/top receipts與單leaf patch／manifest／peer／正常push證據。其餘完整原streams／compiled C／logs仍原路徑保全，完整壓縮封包與actual/public peer待後續真正測試批次一併收，不宣稱已公開全raw。沒有覆寫本輪1。

歷史S1ee的33/56/302全0仍只屬原SHA；舊靜態172成員包與原實際366成員包全保。新S不繼承整體綠燈。正常unique bounded排序只改善該排序，duplicate/overflow平方後備、cut-list及call-growth仍在；無新容量／性能門檻。下一步修復後原三套一次重跑，另外留明確tuple撤回原meta紅／恢復綠證據，仍不改產品、公理、決策或全帳本。
''')
    names=list(payload)+['BINDING.json','PROGRESS.md'];sums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (dest/'SHA256SUMS').read_text().splitlines() if line}
    for name in names:sums[name]=sha((dest/name).read_bytes())
    (dest/'SHA256SUMS').write_text(''.join(sums[n]+'  '+n+'\n' for n in sorted(sums)));names.append('SHA256SUMS')
    paths=[PREFIX+n for n in names];run(['git','add','--sparse','-f','--',*paths])
    if sorted(run(['git','diff','--cached','--name-only']).decode().splitlines())!=sorted(paths):raise RuntimeError('staged scope escaped')
    run(['git','diff','--cached','--check']);run(['git','commit','-m','docs(GEO-300): retain the stale contact control failure'])
    evidence=run(['git','rev-parse','HEAD']).decode().strip()
    if any(not p.startswith(PREFIX) for p in run(['git','diff','--name-only',S,evidence]).decode().splitlines()):raise RuntimeError('product changed')
    run(['git','push','origin',BRANCH])
    if run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()!=[evidence,'refs/heads/'+BRANCH]:raise RuntimeError('remote mismatch')
    save(OUT/'PUBLICATION.json',dict(source_sha=S,evidence_head=evidence,parent=S,normal_push_verified=True,new_subject='UNRUN',r1_red_retained=True,original_commands='COMMANDS.json'));print(json.dumps(dict(source_sha=S,evidence_head=evidence)))
if __name__=='__main__':main()
