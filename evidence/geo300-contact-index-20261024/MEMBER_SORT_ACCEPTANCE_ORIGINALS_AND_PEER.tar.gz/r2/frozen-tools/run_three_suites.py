"""Run three unchanged suite entries on the fixed GEO-300 candidate.

Uses the existing c387 recorder and audit-only NativeBuild retention. No
compiler, product, test, timeout, subprocess return, or oracle interception.
"""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import datetime

S='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
ROOT=Path('/workspace/geo300-contact-index-work')
OUT=Path('/workspace/geo300-member-sort-three-suites-r2')
TMP=Path('/workspace/geo300-member-sort-three-suites-r2-tmp')
TOOLS=Path('/workspace/geo300-member-sort-three-suites-r2-tools')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
ORIGINAL_OBSERVER=Path('/tmp/train337-free-end-f4f-proof/tools/free-end-retain-original-suite.py')
SUITES=[('wood-contact','tests/test_geo261_wood_contact_world.py',12),
        ('contact-sources','tests/test_geo261_contact_sources.py',15),
        ('reading-a-native','tests/test_geo318_reading_a_native.py',7)]
STRIP={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD',
       'LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH',
       'COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    if OUT.exists() or TMP.exists() or TOOLS.exists():raise RuntimeError('fresh output/temp/tools required')
    space=os.statvfs('/workspace');available=space.f_bavail*space.f_frsize
    if available<100*1024*1024:
        print(json.dumps({'environment_blocked':'root-planned 100 MiB disk budget unavailable','workspace_available_bytes':available,'subject_started':False}),flush=True)
        return 75
    raw=ORIGINAL_OBSERVER.read_bytes()
    if sha(raw)!='875213bbe26941626cadb844ad3ac4ff35f5540a317045435d7782d3c4ed9762':raise RuntimeError('observer drift')
    if sha(CAP.read_bytes())!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise RuntimeError('c387 drift')
    OUT.mkdir();TMP.mkdir();TOOLS.mkdir()
    lock_path=Path('/tmp/g261r3/secondary.lock');lock_path.parent.mkdir(parents=True,exist_ok=True)
    lock=lock_path.open('a+b')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return 75
    old_stack=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,old_stack[1]))
    spec=importlib.util.spec_from_file_location('geo300_three_capture',CAP)
    cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    env={k:v for k,v in os.environ.items() if k not in STRIP and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))}
    env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LC_ALL='C.UTF-8',LANG='C.UTF-8')
    rec=cap.Recorder(OUT,env,S)
    receipt={'schema':'geo300-fixed-three-original-suites/1','source':S,'root':str(ROOT),'started_utc':utc(),
             'secondary_lock':str(lock_path),'R3_lock_taken':False,'stack_before':old_stack,'stack_after':resource.getrlimit(resource.RLIMIT_STACK),
             'logical_original_argv':[['python3','-B',target] for _,target,_ in SUITES],
             'observer_scope':'original audit hook, only subject constant mechanically rebound; runpy shell exposed',
             'outer_subject_timeout':None,'original_child_limits_unchanged':True,'cost_or_performance_run':False,
             'global_ledger_written':False,'suites':[],'accepted':False}
    (OUT/'launch-request.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    current_head='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
    def run(argv,check=True,source_variant=None):
        return rec.run(argv,cwd=ROOT,timeout=None,check=check,source_sha=current_head,source_variant=source_variant)
    try:
        run(['df','-B1','/tmp','/workspace'])
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        receipt['completed_checkout_previous_identity']=head.decode().splitlines()
        if receipt['completed_checkout_previous_identity'][0]!=current_head:raise RuntimeError('unexpected completed checkout HEAD')
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('completed source not clean; preserve all data')
        run(['git','ls-files','--stage'])
        run(['git','checkout','--detach',S],source_variant='checkout-from-'+current_head+'-to-'+S)
        current_head=S
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        if head.decode().splitlines()[0]!=S:raise RuntimeError('wrong candidate HEAD')
        receipt['actual_source_identity']=head.decode().splitlines()
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('candidate checkout not clean')
        run(['git','ls-files','--stage'])
        bindings=[]
        for name,target,expected in SUITES:
            before=b"target='tests/test_geo261_wood_contact_world.py'"
            after=("target='"+target+"'").encode()
            if raw.count(before)!=1:raise RuntimeError('observer binding must hit one literal')
            body=raw.replace(before,after)
            observer=TOOLS/(name+'-retain.py');observer.write_bytes(body)
            bindings.append({'suite':name,'original_sha256':sha(raw),'bound_sha256':sha(body),'target':target,'path':str(observer),'only_subject_literal_changed':body.replace(after,before)==raw})
        (TOOLS/'BINDINGS.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n')
        for (name,target,expected),binding in zip(SUITES,bindings):
            where=OUT/name;where.mkdir()
            env.update(GEO299316_EXECUTION_LOG=str(where/'native-executions.jsonl'),
                       GEO261_CONTACT_SOURCES_EXECUTION_LOG=str(where/'native-executions.jsonl'),
                       GEO318_ARTIFACT_DIR=str(where/'host-source-artifacts'))
            row,stdout,stderr=run([sys.executable,'-B',binding['path'],'--root',str(ROOT),'--artifacts',str(where/'compile-retention')],check=False)
            text=stderr.decode('utf-8',errors='replace')
            retained=where/'compile-retention/retention.json'
            logs=json.loads(retained.read_text()) if retained.is_file() else []
            builds=[]
            for entry in logs:
                data=Path(entry['retained']).read_bytes()
                if sha(data)!=entry['sha256']:raise RuntimeError('retained original compile log changed')
                builds.extend(json.loads(data))
            result={'suite':name,'target':target,'source':S,'original_expected_methods':expected,
                    'actual_exit':row['actual_process_returncode'],'methods_reported':('Ran '+str(expected)+' tests') in text,
                    'zero_skips':'skipped' not in text,'compile_commands':len(builds),'all_build_exits_zero':bool(builds) and all(b['exit']==0 for b in builds),
                    'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'command':row,'binding':binding,
                    'native_execution_log':str(where/'native-executions.jsonl')}
            result['passed']=result['actual_exit']==0 and result['methods_reported'] and result['zero_skips'] and result['all_build_exits_zero']
            receipt['suites'].append(result)
            (where/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps({'suite':name,'exit':result['actual_exit'],'methods':expected,'passed':result['passed']}),flush=True)
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        run(['git','ls-files','--stage'])
        receipt['source_after_identity']=head.decode().splitlines()
        receipt['source_after_clean']=status==b'' and receipt['source_after_identity']==receipt['actual_source_identity']
        run(['df','-B1','/tmp','/workspace'])
        receipt['accepted']=receipt['source_after_clean'] and len(receipt['suites'])==3 and all(s['passed'] for s in receipt['suites'])
    except BaseException as exc:
        receipt['exception']=repr(exc)
        raise
    finally:
        receipt['ended_utc']=utc();receipt['commands']=rec.rows
        (OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    return 0 if receipt['accepted'] else 1
if __name__=='__main__':raise SystemExit(main())
