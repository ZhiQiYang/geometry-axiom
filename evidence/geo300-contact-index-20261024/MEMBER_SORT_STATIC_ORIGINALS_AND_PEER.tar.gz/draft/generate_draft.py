from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parent
PATHS=['geometry-templates/woodworking/native/contact_world.c','tests/geo261_contact_world_harness.c','tests/test_geo261_wood_contact_world.py','tests/run_all.expected.json']
def sha(b):return hashlib.sha256(b).hexdigest()
def exactly(text,before,after):
    if text.count(before)!=1:raise RuntimeError('unique source anchor required: '+before[:70])
    return text.replace(before,after)
def literal(node,env):
    if isinstance(node,ast.Constant):return node.value
    if isinstance(node,(ast.Tuple,ast.List)):return tuple(literal(x,env) for x in node.elts)
    if isinstance(node,ast.Name):return env[node.id]
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='replace' and not node.keywords:
        return literal(node.func.value,env).replace(*[literal(x,env) for x in node.args])
    raise RuntimeError('unsupported literal AST '+ast.dump(node))
def controls(text):
    env={}
    for item in ast.parse(text).body:
        if isinstance(item,ast.Assign) and len(item.targets)==1 and isinstance(item.targets[0],ast.Name) and item.targets[0].id in ('STOP_FILTER','CONTROLS'):
            env[item.targets[0].id]=literal(item.value,env)
    return env['CONTROLS']
def main():
    before={p:(ROOT/'before'/p).read_text() for p in PATHS};candidate=dict(before)
    c=before[PATHS[0]]
    c=exactly(c,'/* Query only already admitted earlier-order faces. Metadata never reorders\n * the public output; a prefix value is one real face, never an interval union. */',
        '/* Coverage-query metadata never reorders the placement-ordered public output.\n * Query only already admitted earlier-order faces; a prefix value is one real\n * face, never an interval union. */')
    helper=(ROOT/'member_sort_helpers.inc').read_text()
    c=exactly(c,'} ContactFaceIndex;\n','} ContactFaceIndex;\n'+helper)
    c=exactly(c,'ContactFaceIndex index;contact_face_index_build(&index,out,count);',
        'ContactFaceIndex index;contact_member_index_sort(world,orders,out,count,first,&index);\n    contact_face_index_build(&index,out,count);')
    start=c.index('    for(size_t i=1;i<count;++i){',c.index('ContactOrderIndex orders;contact_order_index(world,&orders);'))
    end=c.index('    /* Keep the original live-set deletion order',start)
    legacy=c[start:end]
    c=c[:start]+'    if(!(count<=WOOD_CONTACT_FACE_CAPACITY&&orders.indexed&&orders.unique)){\n'+legacy+'    }\n'+c[end:]
    candidate[PATHS[0]]=c
    harness=before[PATHS[1]]
    harness=exactly(harness,'int main(int argc,char **argv)',(ROOT/'member_sort_harness.inc').read_text()+'\nint main(int argc,char **argv)')
    harness=exactly(harness,'if(!strcmp(argv[1],"indexed-dedup"))return indexed_dedup();','if(!strcmp(argv[1],"indexed-dedup"))return indexed_dedup();if(!strcmp(argv[1],"indexed-sort"))return indexed_sort();')
    candidate[PATHS[1]]=harness
    py=before[PATHS[2]]
    py=exactly(py,'("placement-order", "if(previous<=order)break;", "if(true)break;", "ordering", "placement-order-before-declaration"),',
        '("placement-order", "return left<=right;", "return true;", "ordering", "placement-order-before-declaration"),')
    py=exactly(py,'("stable-ties", "if(previous<=order)break;", "if(previous<order)break;", "ordering", "placement-stable-equal-order-sides"),',
        '("stable-ties", "return left<=right;", "return left<right;", "ordering", "placement-stable-equal-order-sides"),')
    new_controls=[
        ('legacy-placement-order','if(previous<=order)break;','if(true)break;','indexed-sort','sort-legacy-last-order'),
        ('legacy-stable-ties','if(previous<=order)break;','if(previous<order)break;','indexed-sort','sort-legacy-stable-fields'),
        ('sort-rc-prefix','size_t members=count-first;','first=0;size_t members=count-first;','indexed-sort','sort-rc-prefix-preserved'),
        ('sort-cycle-close','out[at]=value;index->sorted[at]=at;','(void)value;index->sorted[at]=at;','indexed-sort','sort-cycle-every-field'),
        ('sort-cycle-step','out[at]=out[from];index->sorted[at]=at;at=from;','out[at]=out[at];index->sorted[at]=at;at=from;','indexed-sort','sort-cycle-every-field'),
        ('sort-full-order','return left<=right;','return (uint32_t)left<=(uint32_t)right;','indexed-sort','sort-full-uint64-order'),
        ('sort-duplicate-sort-guard','if(!(count<=WOOD_CONTACT_FACE_CAPACITY&&orders.indexed&&orders.unique)){','if(!(count<=WOOD_CONTACT_FACE_CAPACITY&&orders.indexed)){','indexed-sort','sort-legacy-last-order'),
        ('sort-overflow-sort-guard','if(!(count<=WOOD_CONTACT_FACE_CAPACITY&&orders.indexed&&orders.unique)){','if(!(count<=WOOD_CONTACT_FACE_CAPACITY&&orders.unique)){','indexed-sort','sort-overflow-linear-last-order'),
    ]
    insert=''.join('    '+repr(x)+',\n' for x in new_controls)
    py=exactly(py,'\n)\n\n\nclass WoodContactWorld','\n'+insert+')\n\n\nclass WoodContactWorld')
    method='    def test_stable_index_merge_preserves_complete_sequence_and_fallback(self):\n        self.assertEqual(0, self.case("indexed-sort").returncode)\n\n'
    py=exactly(py,'    def extension_transaction(self, executable):',method+'    def extension_transaction(self, executable):')
    candidate[PATHS[2]]=py
    exp=before[PATHS[3]]
    exp,n=re.subn(r'("py:test_geo261_wood_contact_world": \{\s*"mode": "count",\s*"count": )11(,\s*"unit": "test"\s*\})',lambda m:m[1]+'12'+m[2],exp)
    if n!=1:raise RuntimeError('expected count anchor')
    old_expected=json.loads(before[PATHS[3]]);new_expected=json.loads(exp);new_expected['suites']['py:test_geo261_wood_contact_world']['count']=11
    if old_expected!=new_expected:raise RuntimeError('another expected value changed')
    candidate[PATHS[3]]=exp
    old_funcs={f.name:ast.dump(f,include_attributes=False) for f in ast.walk(ast.parse(before[PATHS[2]])) if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef))}
    new_funcs={f.name:ast.dump(f,include_attributes=False) for f in ast.walk(ast.parse(py)) if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef))}
    if any(new_funcs.get(n)!=body for n,body in old_funcs.items()):raise RuntimeError('an existing Python function changed')
    old_controls=controls(before[PATHS[2]]);new_all=controls(py)
    if len(old_controls)!=33 or len(new_all)!=41:raise RuntimeError('control count mismatch')
    changed=[n[0] for o,n in zip(old_controls,new_all) if o!=n]
    if changed!=['placement-order','stable-ties']:raise RuntimeError('unexpected old control change')
    for o,n in zip(old_controls,new_all):
        if o[0]!=n[0] or o[3:]!=n[3:]:raise RuntimeError('original case/assertion changed')
    for row in new_all:
        if c.count(row[1])!=1:raise RuntimeError('control anchor not unique: '+row[0])
    old_checks=[line for line in before[PATHS[1]].splitlines() if 'CHECK(' in line]
    if any(line not in harness.splitlines() for line in old_checks):raise RuntimeError('an old CHECK line changed')
    if c.count(legacy)!=1:raise RuntimeError('original insertion loop not preserved exactly')
    methods=[node.name for cl in ast.parse(py).body if isinstance(cl,ast.ClassDef) for node in cl.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')]
    if len(methods)!=12:raise RuntimeError('actual method count mismatch')
    filepins=[];patch=b'';commands=[]
    for i,path in enumerate(PATHS,1):
        target=ROOT/'candidate'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(candidate[path])
        args=['git','diff','--no-index','--binary','--','before/'+path,'candidate/'+path]
        cp=subprocess.run(args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if cp.returncode!=1:raise RuntimeError('nonempty patch expected')
        d=ROOT/'diff-commands'/str(i);d.mkdir(parents=True,exist_ok=True);(d/'stdout.bin').write_bytes(cp.stdout);(d/'stderr.bin').write_bytes(cp.stderr)
        lines=[]
        for line in cp.stdout.splitlines(keepends=True):
            if line.startswith((b'diff --git ',b'--- ',b'+++ ')):line=line.replace(b'a/before/',b'a/').replace(b'b/candidate/',b'b/')
            lines.append(line)
        patch+=b''.join(lines)
        filepins.append({'path':path,'before_sha256':sha((ROOT/'before'/path).read_bytes()),'candidate_sha256':sha(target.read_bytes())})
        commands.append({'argv':args,'exit':cp.returncode,'meaning':'nonempty no-index diff; not subject failure','stdout_sha256':sha(cp.stdout),'stderr_sha256':sha(cp.stderr)})
    (ROOT/'DRAFT.patch').write_bytes(patch)
    manifest={'schema':'geo300-stable-member-index-sort-external-draft/1','product_base':'1ee4e830399b124ebd63c5ff51064d87e53f38d9','parent_evidence':'4f456effd0a53ec45e575c2ce3596825b8dc937a','files':filepins,'patch_sha256':sha(patch),'old_methods':11,'methods':12,'old_controls':33,'controls':41,'other_original_suite_methods':[15,7],'other_original_suite_controls':[11,12],'expected_total_methods':34,'expected_total_controls':64,'old_python_function_AST_preserved':True,'old_CHECK_lines_preserved':True,'legacy_insertion_loop_preserved_exactly':True,'old_control_reanchors':changed,'controls_detail':[{'name':r[0],'case':r[3],'assertion':r[4],'before_hits':c.count(r[1])} for r in new_all],'extra_large_arrays':0,'arrays_reused':'same ContactFaceIndex local in existing indexed_dedup; sorted/scratch first stable member sort, all fields rebuilt for plane query','single_face_permutation_temporary':True,'index_array_stack_placement_changed':False,'full_optimization_withdrawal':'planned unique initialization true->false; semantic positive subset0/0/0, not killed','source_branch_written':False,'compile':'UNRUN','subject':'UNRUN','performance':'UNMEASURED','global_ledger_written':False,'new_numeric_threshold':False,'commands':commands}
    (ROOT/'DRAFT_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'patch_sha256':sha(patch),'manifest_sha256':sha((ROOT/'DRAFT_MANIFEST.json').read_bytes()),'methods':12,'controls':41,'total_methods':34,'total_controls':64,'source_written':False,'subject':'UNRUN'}))
if __name__=='__main__':main()
