# GEO-300 穩定 member 排序：外部候選，尚未編譯或執行

基底產品 `1ee4e830399b124ebd63c5ff51064d87e53f38d9`，公開 E `4f456effd0a53ec45e575c2ce3596825b8dc937a`／D `d2de865d9f68cab087d0794b7e962dd1913ada8e`。該 S 的三套 33 方法／56 反證／302 builds 是原 S 的實證。本候選新增排序，不能繼承為新來源實跑。

已讀 318 的固定來源分析（a259662…）、同 hash 的 SSOT／指定決策／FIELD-RULES 與原實作／controls。D11 來源及幾何、I33 精確與容量、既有放置 order／tie 契約保持。沒有改公理、依賴、Reading A、容量或數值門檻。

## 最小接線與記憶體

只有 `count<=WOOD_CONTACT_FACE_CAPACITY && orders.indexed && orders.unique` 的正常路徑略過原 insertion sort；duplicate／超 member capacity／超 face capacity 保留原迴圈逐字完整。全 facts 的 unique 判定維持，不能只看收集到的面。

原 `contact_indexed_dedup` 的同一個區域 `ContactFaceIndex` 先呼叫 member 排序，再呼叫既有 plane-index build。沒有新增或加大任何陣列，也不把 4 陣列上移到 fallback frame；既有 sorted/scratch/rank/maximum 原地共用。member 階段只使用 sorted／scratch，其後原 build 重設全部會讀的內容。額外 permutation 暫存只有一個 WoodStopFace；實際 compiler frame 尚未量，仍以原 16MiB 測試。

collector 進入 helper 前 active 全部為 true、remaining=count。新排序只重排同一 member suffix，first／count／RC prefix 不變，所以不用同步重排 active，也沒有先前刪除狀態。稍後的 dedup 仍按相同的穩定放置序跑。

## 比較與 permutation

metadata 的 stable bottom-up merge 只比較原 `contact_order` 回傳的完整 uint64；其 duplicate-last／missing UINT64_MAX 實作不改。相等取左邊，精確保原宣告 member 順序及每 member 的兩側先後。沒有 ID 排序、32位截斷、相減或浮點。

sorted[dest] 是原 source index，僅在 [first,count) 上構成 permutation。每個非固定 cycle 先保留 out[start]，沿 dest←source 移值，將已完成 mapping 設成 identity，最後以保留值封回 cycle；後續 start 跳過 identity。只有一個面暫存，沒有第二個 face buffer。RC／孔前綴完全不進 merge 或 cycle。

正常 bounded/unique 的 member 排序由 Θ(F²) 比較／搬移改成 O(F log F) 比較＋O(F) 重排。duplicate／overflow 的排序與配對仍平方，cut-list 也未完成；不宣稱整體 collector 或 load 已 O(N log N)。實際收益未量。

## 原斷言與具名反證

舊全部 11 Python 方法 AST、C CHECK 行、原 case／ASSERT／child timeout 保留。只將 placement-order／stable-ties 從 legacy break 重錨到正常路徑真 comparator；原兩個失效原因仍分別是「不排序」與「相等取右造成不穩定」，仍要求原 ordering case 的同名 ASSERT 紅。legacy-placement-order／legacy-stable-ties 新專刀保原 break 牙齒，在 duplicate 路徑檢驗 last-order 與完整 side fields。

新增原 harness 的 indexed-sort case 與一方法，合 12 方法／41 controls；三套共 34 方法／64 controls，expected 只真 count 11→12。新增八刀：上述兩個 legacy；錯把 RC 前綴納入排序；cycle 封口漏值；cycle 搬移漏值；截32位 order；duplicate guard 漏 unique；overflow guard 漏 indexed。預期每刀 baseline0／原具名正常 ASSERT1／restored0，不能用 compile/crash/timeout/skip 當偵測。首個 ASSERT 的預測尚未經 C 實證。

正例逐欄比較 kind／boundary_id／timber_id／hole_index／edge_index／fixity／fixed／lo／hi，預期來源是明列的 fixture 排列，不用實作 comparator 排一份 actual。涵蓋 FREE RC 前綴、3-cycle、非2冪 merge、等 order、UINT64_MAX／2^63／2^32、零／奇數 cap 及未收集 tail、duplicate 的 last-order 與 stable side、member capacity+1 的原線性 lookup／排序後備。原 zero/reversed span、filtered duplicate、face-capacity 大 buffer 等舊案例仍全保。

## 撤回與未跑

整條快路可另以 unique 初始化 true→false 單點強制回原排序＋原去重，原 order hash 不受影響。只在原正例子集預期 fixed/withdrawn/restored 0/0/0；不能跑被旁路的 controls meta-test 然後冒語意差異或 killed。舊 S1ee 的七正例撤回仍維持其原 SHA／UNRUN；此新候選需自己的八正例計畫。

本候選只有外部 patch、AST／單一 anchor／檔案 hash 檢查與機械 patch roundtrip。C 編譯、34 方法／64 反證、16MiB 新 frame、性能、P-189、容量512、架構及全帳本均未跑。root 授新 heavy 槽前不執行；不拿舊 S 的綠移標。所有新數值門檻皆不採用。
