#!/usr/bin/env python3
from pathlib import Path
import datetime as dt
import hashlib
import io
import json
import subprocess
import tarfile

ROOT=Path('/workspace/geo300-contact-index-publication-work')
SOURCE=Path('/workspace/geo300-contact-index-work')
OUT=Path('/tmp/geo300-member-sort-static-publication')
DELIVERY=Path('/tmp/geo300-member-sort-static-delivery')
DRAFT=Path('/tmp/geo300-member-sort-1ee4-20261024')
PREFIX='evidence/geo300-contact-index-20261024/'
BRANCH='codex/geo300-contact-index-20261024'
S='cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041'
OLD_E='4f456effd0a53ec45e575c2ce3596825b8dc937a'
ARCHIVE='MEMBER_SORT_STATIC_ORIGINALS_AND_PEER.tar.gz'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    DELIVERY.mkdir(exist_ok=False);OUT.mkdir(exist_ok=False);rows=[]
    mapping={}
    for label,base in [('draft',DRAFT),('source-publication-original',Path('/workspace/geo300-member-sort-source-publication')),('source-publication-r2',Path('/workspace/geo300-member-sort-source-publication-r2')),('runner-binding',Path('/workspace/geo300-member-sort-three-suite-tools'))]:
        for path in sorted(base.rglob('*')):
            if path.is_file() and not path.is_symlink():mapping[label+'/'+path.relative_to(base).as_posix()]=path
    for name in ['GEO300_MEMBER_SORT_STATIC_PEER.json','GEO300_MEMBER_SORT_INITIAL_EXPECTED_SCHEMA.json','review_geo300_member_sort_static.py','review_geo300_member_sort_initial_expected_schema.py.txt']:
        mapping['static-peer/'+name]=Path('/tmp/train337-adversarial')/name
    if sha(mapping['static-peer/GEO300_MEMBER_SORT_STATIC_PEER.json'].read_bytes())!='393ffee226d0c65f39f4b1df756d897e45ff2963a49c117b29cc89955e9ffa28':raise RuntimeError('peer drift')
    index={name:dict(original_path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes())) for name,path in mapping.items()}
    index_raw=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
    (DELIVERY/'PACKAGE_INDEX.json').write_bytes(index_raw)
    archive=DELIVERY/'ORIGINALS_AND_PEER.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for name,path in mapping.items():
            raw=path.read_bytes()
            if sha(raw)!=index[name]['sha256']:raise RuntimeError('input changed during pack')
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;tf.addfile(info,io.BytesIO(raw))
        info=tarfile.TarInfo('PACKAGE_INDEX.json');info.size=len(index_raw);info.mode=0o600;tf.addfile(info,io.BytesIO(index_raw))
    with tarfile.open(archive,'r:gz') as tf:
        members=tf.getmembers()
        if len(members)!=len(index)+1 or len({m.name for m in members})!=len(members):raise RuntimeError('archive membership differs')
        for member in members:
            raw=tf.extractfile(member).read()
            expected=index_raw if member.name=='PACKAGE_INDEX.json' else mapping[member.name].read_bytes()
            if raw!=expected:raise RuntimeError('roundtrip changed original')
    package=dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),raw_files=len(index),raw_bytes=sum(v['bytes'] for v in index.values()),regular_members=len(index)+1,all_members_roundtrip=True,subject_executed=False)
    save(DELIVERY/'PACKAGE.json',package)
    def run(argv):
        folder=OUT/f'{len(rows)+1:03d}';folder.mkdir();start=dt.datetime.now(dt.timezone.utc).isoformat()
        c=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
        (folder/'stdout.bin').write_bytes(c.stdout);(folder/'stderr.bin').write_bytes(c.stderr)
        row=dict(number=len(rows)+1,argv=argv,cwd=str(ROOT),exit=c.returncode,started_utc=start,ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),stdout=dict(path=str(folder/'stdout.bin'),bytes=len(c.stdout),sha256=sha(c.stdout)),stderr=dict(path=str(folder/'stderr.bin'),bytes=len(c.stderr),sha256=sha(c.stderr)))
        rows.append(row);save(folder/'receipt.json',row);save(OUT/'COMMANDS.json',rows)
        if c.returncode:raise RuntimeError('publication command failed: '+str(len(rows)))
        return c.stdout
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('publication repo dirty')
    run(['git','switch',BRANCH])
    if run(['git','rev-parse','HEAD']).decode().strip()!=OLD_E:raise RuntimeError('old evidence branch changed')
    run(['git','fetch','--no-write-fetch-head','--no-tags',str(SOURCE),S])
    run(['git','merge','--ff-only',S])
    dest=ROOT/PREFIX
    (dest/'MEMBER_SORT_STATIC_PACKAGE.json').write_bytes((DELIVERY/'PACKAGE.json').read_bytes())
    (dest/'MEMBER_SORT_STATIC_INDEX.json').write_bytes(index_raw)
    (dest/'MEMBER_SORT_STATIC_PEER.json').write_bytes(mapping['static-peer/GEO300_MEMBER_SORT_STATIC_PEER.json'].read_bytes())
    previous=json.loads((dest/'BINDING.json').read_bytes())
    binding=dict(schema='geo300-contact-index-and-member-sort-binding/1',source_sha=S,product_commit=S,
      base_evidence=previous['base_evidence'],base_source=previous['base_source'],base_branch=previous['base_branch'],branch=BRANCH,
      formal_methods=34,wood_methods=12,wood_controls=41,all_three_controls=64,global_ledger_written=False,
      historical_S1ee_binding=previous)
    binding.update(source=S,subject='UNRUN: new stable-sort source34methods64controls',compile='UNRUN on new source',
      formal=None,previous_actual=dict(source='1ee4e830399b124ebd63c5ff51064d87e53f38d9',suite_methods=[11,15,7],suite_controls=[33,11,12],suite_builds=[131,85,86],suite_exits=[0,0,0],scope='historical source only; not relabeled'),
      member_sort=dict(patch_sha256='03466cd53c88b8eaa380d374c1073f689d871256585d8c257180fd41e45eb5a9',static_checks=283,static_findings=0,expected_methods=[12,15,7],expected_controls=[41,11,12],original_sparse_apply_check_exit=1,r2_publication_exit=0,package=package),
      stack='UNRUN on new sort source; same four arrays reused plus one face temporary; compiler frame unmeasured',whole_fast_path_withdrawal='UNRUN; planned eight-positive semantic0/0/0, not killed',performance='UNMEASURED',READY=False)
    save(dest/'BINDING.json',binding)
    (dest/'PROGRESS.md').write_text('''# GEO-300 唯一 ID 遮蓋查詢與穩定 member 排序進度

目前 product SHA `cc2ea1b3b42291f6ebb0ead6bd1c2180920d7041`，父 E `4f456effd0a53ec45e575c2ce3596825b8dc937a`。只改 contact_world.c、原 harness、原 Python suite 與 expected 的 wood-contact 11→12；其餘 registry、SSOT、決策與容量未改。正常 bounded/unique 路徑共用既有四陣列做穩定 index merge 與單 face permutation；duplicate／overflow 保原 insertion loop。

| 目前 SHA 的項目 | 結果 |
| --- | --- |
| 排序草案獨立靜審 | 283 checks／0 findings；只有靜態，不是 C 實證 |
| 原三套 | UNRUN；預期 12＋15＋7＝34 方法、41＋11＋12＝64 controls |
| 既定 16MiB／compiler frame | 新來源 UNRUN／未另量，未新增或加大索引陣列 |
| 整條快路撤回 | UNRUN；另規劃 8 原正例語意等價 0/0/0，不計 killed |
| 性能、P-189、容量512、全 native/browser/ledger/architecture | UNMEASURED／UNRUN／NOT READY |

歷史 S `1ee4e830399b124ebd63c5ff51064d87e53f38d9` 已實跑 33 方法／56 正常0/1/0／302 builds，全0、0skip；這些結果只屬原 SHA。原 1140/0 actual peer 與 1571/0 public peer、366 成員原件包完整保留，不能標為新排序實跑。#341／Sc493 的32／46／282也保原SHA。

本次 Git-only 出版第一輪 apply-check exit1：薄 checkout 未物化原 tracked tests/run_all.expected.json，原 stderr／退出碼全保。沒有產品 patch 或 C 執行；r2 只從同 HEAD 精確 restore 該原檔，再套完全相同的凍結 patch，一般 commit/push0且遠端同 SHA。未重寫失敗原件。reviewer 的初始 expected-schema checker 錯誤也與修正版一起保存，不是 subject 紅燈。

MEMBER_SORT_STATIC_ORIGINALS_AND_PEER.tar.gz 保存四leaf前後、patch／設計／純AST、原機械 roundtrip、兩輪 Git-only 指令與完整 streams／exit、runner綁定及靜審；全部成員逐byte回讀。此封包尚無34／64動態結果。

下一步：root ReadingA 專項真終態後取得 secondary 槽，在新固定 SHA 跑原三套與全部具名正常 ASSERT0/1/0；OUT／TMPDIR 用新的 workspace 私有路徑，仍守原100MiB、16MiB與子時限。成本性能不與 root 全帳本並跑。duplicate／overflow平方後備、cut-list平方儲存與呼叫量問題仍在，不宣稱整體collector/load已O(FlogF)。
''')
    blob=run(['git','hash-object','-w',str(archive)]).decode().strip()
    run(['git','update-index','--add','--cacheinfo',f'100644,{blob},{PREFIX+ARCHIVE}'])
    run(['git','update-index','--skip-worktree','--',PREFIX+ARCHIVE])
    sums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (dest/'SHA256SUMS').read_text().splitlines() if line}
    names=['MEMBER_SORT_STATIC_PACKAGE.json','MEMBER_SORT_STATIC_INDEX.json','MEMBER_SORT_STATIC_PEER.json','BINDING.json','PROGRESS.md']
    for name in names:sums[name]=sha((dest/name).read_bytes())
    sums[ARCHIVE]=package['sha256']
    (dest/'SHA256SUMS').write_text(''.join(sums[n]+'  '+n+'\n' for n in sorted(sums)))
    small=[PREFIX+n for n in names+['SHA256SUMS']]
    run(['git','add','--sparse','-f','--',*small])
    staged=run(['git','diff','--cached','--name-only']).decode().splitlines()
    if sorted(staged)!=sorted(small+[PREFIX+ARCHIVE]):raise RuntimeError('evidence scope escaped')
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','docs(GEO-300): publish stable sort progress'])
    evidence=run(['git','rev-parse','HEAD']).decode().strip()
    if any(not p.startswith(PREFIX) for p in run(['git','diff','--name-only',S,evidence]).decode().splitlines()):raise RuntimeError('evidence changed product')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('publication not clean')
    run(['git','push','origin',BRANCH])
    remote=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()
    if remote!=[evidence,'refs/heads/'+BRANCH]:raise RuntimeError('remote mismatch')
    save(OUT/'PUBLICATION.json',dict(source_sha=S,evidence_head=evidence,branch=BRANCH,parent=S,archive_git_blob=blob,archive=package,normal_push_verified=True,subject='UNRUN',original_commands='COMMANDS.json'))
    print(json.dumps(dict(source_sha=S,evidence_head=evidence,package=package)))
if __name__=='__main__':main()
