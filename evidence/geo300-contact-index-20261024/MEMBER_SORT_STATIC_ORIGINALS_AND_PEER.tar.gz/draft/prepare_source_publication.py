#!/usr/bin/env python3
"""Publish only the independently reviewed four-leaf stable-sort candidate.

This is a Git-only operation. It does not execute product, tests or the ledger.
"""
from pathlib import Path
import ast
import datetime as dt
import hashlib
import json
import subprocess
import sys

ROOT=Path('/workspace/geo300-contact-index-work')
PUB=Path('/workspace/geo300-contact-index-publication-work')
DRAFT=Path('/tmp/geo300-member-sort-1ee4-20261024')
OUT=Path('/workspace/geo300-member-sort-source-publication')
OLD='1ee4e830399b124ebd63c5ff51064d87e53f38d9'
E='4f456effd0a53ec45e575c2ce3596825b8dc937a'
BRANCH='codex/geo300-contact-index-20261024'
PATHS=['geometry-templates/woodworking/native/contact_world.c',
       'tests/geo261_contact_world_harness.c',
       'tests/test_geo261_wood_contact_world.py',
       'tests/run_all.expected.json']
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    peer=Path(sys.argv[1]);peer_hash=sys.argv[2]
    if sha(peer.read_bytes())!=peer_hash:raise RuntimeError('review bytes drift')
    if sha((DRAFT/'DRAFT.patch').read_bytes())!='03466cd53c88b8eaa380d374c1073f689d871256585d8c257180fd41e45eb5a9':raise RuntimeError('patch drift')
    if sha((DRAFT/'DRAFT_MANIFEST.json').read_bytes())!='692c9c478d0d54ade2bb29dfc66e52ab5ebd5322a060caa76ac933ea061be9f5':raise RuntimeError('manifest drift')
    OUT.mkdir(exist_ok=False);rows=[]
    (OUT/'STATIC_PEER.json').write_bytes(peer.read_bytes())
    def run(argv,check=True):
        folder=OUT/f'{len(rows)+1:03d}';folder.mkdir()
        start=dt.datetime.now(dt.timezone.utc).isoformat()
        result=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
        (folder/'stdout.bin').write_bytes(result.stdout);(folder/'stderr.bin').write_bytes(result.stderr)
        row=dict(number=len(rows)+1,argv=argv,cwd=str(ROOT),started_utc=start,
                 ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),exit=result.returncode,
                 stdout=dict(path=str(folder/'stdout.bin'),bytes=len(result.stdout),sha256=sha(result.stdout)),
                 stderr=dict(path=str(folder/'stderr.bin'),bytes=len(result.stderr),sha256=sha(result.stderr)))
        rows.append(row);save(folder/'receipt.json',row);save(OUT/'COMMANDS.json',rows)
        if check and result.returncode:raise RuntimeError(f'command {len(rows)} exit {result.returncode}')
        return result.stdout
    if run(['git','rev-parse','HEAD']).decode().strip()!=OLD:raise RuntimeError('private completed source changed')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('source not clean')
    run(['git','switch',BRANCH])
    run(['git','fetch','--no-write-fetch-head','--no-tags',str(PUB),E])
    run(['git','merge','--ff-only',E])
    if run(['git','rev-parse','HEAD']).decode().strip()!=E:raise RuntimeError('evidence ancestor not preserved')
    if run(['git','diff',OLD,E,'--',*PATHS]):raise RuntimeError('candidate base source differs')
    for path in PATHS:
        before=(DRAFT/'before'/path).read_bytes()
        if run(['git','show','HEAD:'+path])!=before:raise RuntimeError('candidate input differs: '+path)
    run(['git','apply','--check',str(DRAFT/'DRAFT.patch')])
    run(['git','apply',str(DRAFT/'DRAFT.patch')])
    for path in PATHS:
        if (ROOT/path).read_bytes()!=(DRAFT/'candidate'/path).read_bytes():raise RuntimeError('applied candidate differs')
    before=json.loads((DRAFT/'before/tests/run_all.expected.json').read_bytes())
    after=json.loads((ROOT/'tests/run_all.expected.json').read_bytes())
    if before['suites']['py:test_geo261_wood_contact_world']['count']!=11 or after['suites']['py:test_geo261_wood_contact_world']['count']!=12:raise RuntimeError('count differs')
    after['suites']['py:test_geo261_wood_contact_world']['count']=11
    if before!=after:raise RuntimeError('other registry entry changed')
    tree=ast.parse((ROOT/'tests/test_geo261_wood_contact_world.py').read_bytes())
    methods=[n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    if len(methods)!=12:raise RuntimeError('method census differs')
    run(['git','add','--sparse','-f','--',*PATHS])
    names=run(['git','diff','--cached','--name-only']).decode().splitlines()
    if sorted(names)!=sorted(PATHS):raise RuntimeError('unexpected staged scope')
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','perf(GEO-300): stably merge member face indices'])
    identity=run(['git','rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('committed source not clean')
    run(['git','diff','--name-only',E,identity[0]])
    run(['git','push','origin',BRANCH])
    remote=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()
    if remote!=[identity[0],'refs/heads/'+BRANCH]:raise RuntimeError('published remote mismatch')
    save(OUT/'PUBLICATION.json',dict(branch=BRANCH,source_sha=identity[0],tree=identity[1],parent=E,
         product_base=OLD,changed_paths=PATHS,patch_sha256=sha((DRAFT/'DRAFT.patch').read_bytes()),
         peer=dict(path=str(peer),sha256=peer_hash),methods=methods,subject='UNRUN',controls='UNRUN',
         performance='UNMEASURED',global_ledger_written=False,normal_push_verified=True,
         original_commands='COMMANDS.json'))
    print(json.dumps(dict(source_sha=identity[0],tree=identity[1],publication=str(OUT/'PUBLICATION.json'))))
if __name__=='__main__':main()
