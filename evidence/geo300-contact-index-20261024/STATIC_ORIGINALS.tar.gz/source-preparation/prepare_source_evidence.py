#!/usr/bin/env python3
"""Make a small, byte-verifiable source/static-review package only."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

OUT=Path('/workspace/geo300-contact-index-source-delivery')
DRAFT=Path('/tmp/geo300-next-eb846-20261024')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    entries={}
    def add(label,path):
        if label in entries:raise RuntimeError('duplicate archive label')
        data=path.read_bytes();entries[label]=dict(original=str(path),bytes=len(data),sha256=sha(data))
    for label,base in [
        ('source-preparation',Path('/workspace/geo300-contact-index-source-preparation')),
        ('source-publication',Path('/workspace/geo300-contact-index-source-publication')),
        ('expected-publication',Path('/workspace/geo300-contact-index-expected-publication')),
    ]:
        for path in sorted(base.rglob('*')):
            if path.is_file():add(label+'/'+path.relative_to(base).as_posix(),path)
    for name in ['CURRENT.json','DRAFT.patch','DRAFT_MANIFEST.json','DRAFT_DESIGN.md','SOURCE.json','QUESTIONS.md','face_index_helpers.inc','indexed_harness.inc','generate_draft.py','GENERATOR_INITIAL_ERROR.json','patch-roundtrip/RECEIPT.json']:
        add('frozen-draft/'+name,DRAFT/name)
    for name in ['candidate','commands']:
        for path in sorted((DRAFT/name).rglob('*')):
            if path.is_file():add('frozen-draft/'+path.relative_to(DRAFT).as_posix(),path)
    for label,path in [
        ('peer/full-draft.json',Path('/tmp/train337-adversarial/GEO300_FENWICK_DRAFT_V3_STATIC_PEER.json')),
        ('peer/full-draft-initial-constant-reference-error.json',Path('/tmp/train337-adversarial/GEO300_FENWICK_INITIAL_CONSTANT_REFERENCE_ERROR.json')),
        ('peer/core.json',Path('/workspace/issue320-20261024/geo300-prefix-core-static-peer/REVIEW.json')),
    ]:add(label,path)
    index=dict(schema='geo300-contact-index-static-originals/1',
        source='1ee4e830399b124ebd63c5ff51064d87e53f38d9',
        product_parent='9ee7f98144f81f11385f392e13cc067f1b9d063c',
        base='df230da57619e437c30527dbede8c67fd0ec6b50',
        frozen_draft_state='historical external-only state before source publication; not overwritten',
        dynamic_tests='UNRUN',performance='UNMEASURED',files=entries)
    raw=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
    (OUT/'RAW_INDEX.json').write_bytes(raw)
    archive=OUT/'STATIC_ORIGINALS.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for label,item in entries.items():
            data=Path(item['original']).read_bytes()
            if sha(data)!=item['sha256']:raise RuntimeError('input changed during packing')
            info=tarfile.TarInfo(label);info.size=len(data);info.mode=0o644;info.mtime=0
            tf.addfile(info,io.BytesIO(data))
        info=tarfile.TarInfo('RAW_INDEX.json');info.size=len(raw);info.mode=0o644;info.mtime=0
        tf.addfile(info,io.BytesIO(raw))
    with tarfile.open(archive,'r:gz') as tf:
        members=tf.getmembers()
        if len(members)!=len(entries)+1:raise RuntimeError('archive member mismatch')
        for member in members:
            data=tf.extractfile(member).read()
            expected=dict(bytes=len(raw),sha256=sha(raw)) if member.name=='RAW_INDEX.json' else entries[member.name]
            if len(data)!=expected['bytes'] or sha(data)!=expected['sha256']:raise RuntimeError('archive roundtrip mismatch')
    receipt=dict(source=index['source'],archive=str(archive),bytes=archive.stat().st_size,
        sha256=sha(archive.read_bytes()),raw_files=len(entries),raw_bytes=sum(x['bytes'] for x in entries.values()),
        tar_members=len(entries)+1,roundtrip_all_members=True,index_sha256=sha(raw),
        scope='source publication and static review only; no compilation, controls, or performance')
    (OUT/'PACKAGE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(receipt))
if __name__=='__main__':main()
