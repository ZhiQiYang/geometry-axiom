#!/usr/bin/env python3
"""Publish only the independently reviewed, still unexecuted GEO-300 source."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess

ROOT = Path('/workspace/geo300-contact-index-work')
DRAFT = Path('/tmp/geo300-next-eb846-20261024')
OUT = Path('/workspace/geo300-contact-index-source-publication')
BASE = 'df230da57619e437c30527dbede8c67fd0ec6b50'
BRANCH = 'codex/geo300-contact-index-20261024'
PATCH_SHA = '4619721b4e0cfd93a097ae68c6d8c72c83bf8d15f1c8aa6560e39b4d7538a41a'
PEERS = {
    '/tmp/train337-adversarial/GEO300_FENWICK_DRAFT_V3_STATIC_PEER.json':
        '2c4fd148d9dd58987ad86276676950251eb91ec1091ebee5c13ebc91b11ecc41',
    '/workspace/issue320-20261024/geo300-prefix-core-static-peer/REVIEW.json':
        '33e46d28398b065bd864967f2faff8eaef1708fd637fd69ee333eb7910c3b1ce',
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def main():
    OUT.mkdir(exist_ok=False)
    commands = []
    def run(argv, *, require=0):
        number = len(commands) + 1
        folder = OUT / f'{number:03d}'
        folder.mkdir()
        started = dt.datetime.now(dt.timezone.utc).isoformat()
        cp = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=180)
        (folder / 'stdout.bin').write_bytes(cp.stdout)
        (folder / 'stderr.bin').write_bytes(cp.stderr)
        record = dict(number=number, argv=argv, cwd=str(ROOT),
                      started_utc=started,
                      ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                      exit=cp.returncode,
                      stdout=dict(path=str(folder/'stdout.bin'), bytes=len(cp.stdout), sha256=sha(cp.stdout)),
                      stderr=dict(path=str(folder/'stderr.bin'), bytes=len(cp.stderr), sha256=sha(cp.stderr)))
        commands.append(record)
        save(folder/'receipt.json', record)
        save(OUT/'COMMANDS.json', commands)
        if require is not None and cp.returncode != require:
            raise RuntimeError(f'command {number}: expected {require}, got {cp.returncode}')
        return cp.stdout

    for name, expected in PEERS.items():
        data = Path(name).read_bytes()
        if sha(data) != expected:
            raise RuntimeError(f'peer changed: {name}')
    patch = (DRAFT/'DRAFT.patch').read_bytes()
    if sha(patch) != PATCH_SHA:
        raise RuntimeError('draft patch changed')
    manifest = json.loads((DRAFT/'DRAFT_MANIFEST.json').read_text())
    head = run(['git','rev-parse','HEAD']).decode().strip()
    if head != BASE:
        raise RuntimeError('unexpected source base')
    if run(['git','branch','--show-current']).decode().strip() != BRANCH:
        raise RuntimeError('unexpected source branch')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):
        raise RuntimeError('source is not clean')
    for item in manifest['files']:
        if sha((ROOT/item['path']).read_bytes()) != item['before_sha256']:
            raise RuntimeError(f"baseline bytes differ: {item['path']}")
    run(['git','apply','--check',str(DRAFT/'DRAFT.patch')])
    run(['git','apply',str(DRAFT/'DRAFT.patch')])
    for item in manifest['files']:
        if sha((ROOT/item['path']).read_bytes()) != item['candidate_sha256']:
            raise RuntimeError(f"candidate bytes differ: {item['path']}")
    names = run(['git','diff','--name-only','-z']).decode().rstrip('\0').split('\0')
    expected_names = sorted(item['path'] for item in manifest['files'])
    if sorted(names) != expected_names:
        raise RuntimeError('change escaped reviewed three leaves')
    run(['git','diff','--check'])
    diff = run(['git','diff','--binary','--',*expected_names])
    (OUT/'SOURCE.patch').write_bytes(diff)
    run(['git','add','--',*expected_names])
    run(['git','commit','-m','perf(GEO-300): index unique-ID stop-face coverage'])
    source = run(['git','rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
    if run(['git','status','--porcelain=v1','--untracked-files=all']):
        raise RuntimeError('source not clean after commit')
    run(['git','push','--set-upstream','origin',BRANCH])
    remote = run(['git','ls-remote','--heads','origin',f'refs/heads/{BRANCH}']).decode().split()
    if remote != [source[0], f'refs/heads/{BRANCH}']:
        raise RuntimeError('remote source head differs')
    save(OUT/'PUBLICATION.json', dict(
        branch=BRANCH, source_sha=source[0], tree=source[1], base_evidence=BASE,
        base_source='eb846c345881cc6fc73a53c457a291175365b88c',
        changed_paths=expected_names, source_patch_sha256=sha(diff),
        frozen_draft_patch_sha256=PATCH_SHA, peers=PEERS,
        original_commands='COMMANDS.json', normal_push_verified=True,
        compile='UNRUN', subject='UNRUN', controls='UNRUN', performance='UNMEASURED',
        whole_optimization_withdrawal='semantic equivalence expected; not a killed mutant',
        expected_count_registration='root baton pending: wood_contact_world 10 to 11',
        source_environment={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ},
        shared_source_or_global_ledger_written=False))
    print(json.dumps(dict(source_sha=source[0], tree=source[1], publication=str(OUT/'PUBLICATION.json'))))

if __name__ == '__main__':
    main()
