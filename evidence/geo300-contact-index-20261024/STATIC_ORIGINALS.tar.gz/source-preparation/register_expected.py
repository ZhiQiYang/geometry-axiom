#!/usr/bin/env python3
"""Register the new real unittest method without altering any other entry."""
from pathlib import Path
import ast
import datetime as dt
import hashlib
import json
import re
import subprocess

ROOT=Path('/workspace/geo300-contact-index-work')
OUT=Path('/workspace/geo300-contact-index-expected-publication')
BASE='9ee7f98144f81f11385f392e13cc067f1b9d063c'
BRANCH='codex/geo300-contact-index-20261024'
TARGET='tests/run_all.expected.json'
KEY='py:test_geo261_wood_contact_world'

def sha(b): return hashlib.sha256(b).hexdigest()
def save(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    OUT.mkdir(exist_ok=False); rows=[]
    def run(argv):
        folder=OUT/f'{len(rows)+1:03d}';folder.mkdir()
        start=dt.datetime.now(dt.timezone.utc).isoformat()
        c=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
        (folder/'stdout.bin').write_bytes(c.stdout);(folder/'stderr.bin').write_bytes(c.stderr)
        row=dict(number=len(rows)+1,argv=argv,cwd=str(ROOT),started_utc=start,
                 ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),exit=c.returncode,
                 stdout=dict(path=str(folder/'stdout.bin'),bytes=len(c.stdout),sha256=sha(c.stdout)),
                 stderr=dict(path=str(folder/'stderr.bin'),bytes=len(c.stderr),sha256=sha(c.stderr)))
        rows.append(row);save(folder/'receipt.json',row);save(OUT/'COMMANDS.json',rows)
        if c.returncode: raise RuntimeError(f'command {len(rows)} exit {c.returncode}')
        return c.stdout
    if run(['git','rev-parse','HEAD']).decode().strip()!=BASE:raise RuntimeError('unexpected base')
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('not clean')
    before=run(['git','show','HEAD:'+TARGET]);a=json.loads(before)
    if a['suites'][KEY]['count']!=10:raise RuntimeError('unexpected previous count')
    pattern=rb'("py:test_geo261_wood_contact_world": \{\s*"mode": "count",\s*"count": )10(,\s*"unit": "test"\s*\})'
    after,hits=re.subn(pattern,lambda m:m.group(1)+b'11'+m.group(2),before)
    if hits!=1:raise RuntimeError('expected count anchor must be unique')
    b=json.loads(after);b['suites'][KEY]['count']=10
    if a!=b:raise RuntimeError('another registry value changed')
    tree=ast.parse((ROOT/'tests/test_geo261_wood_contact_world.py').read_text())
    methods=[node.name for cls in tree.body if isinstance(cls,ast.ClassDef)
             for node in cls.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith('test_')]
    if len(methods)!=11:raise RuntimeError('registered method count differs from original class AST')
    (ROOT/TARGET).write_bytes(after)
    (OUT/'EXPECTED.before.json').write_bytes(before);(OUT/'EXPECTED.after.json').write_bytes(after)
    save(OUT/'REGISTRY_STATIC.json',dict(original_count=10,new_count=11,test_methods=methods,
         other_entries_exactly_equal=True,subject_executed=False,
         unchanged_known_counts={key:a['suites'][key] for key in ['py:test_geometry_host_native','py:test_geometry_host_sources','py:test_geo261_native_kernel']}))
    run(['git','add','--sparse','-f','--',TARGET])
    names=run(['git','diff','--cached','--name-only']).decode().splitlines()
    if names!=[TARGET]:raise RuntimeError('unexpected staged scope')
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','test(GEO-300): register indexed contact coverage case'])
    identity=run(['git','rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
    if run(['git','status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('source not clean')
    run(['git','push','origin',BRANCH])
    remote=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()
    if remote!=[identity[0],'refs/heads/'+BRANCH]:raise RuntimeError('remote mismatch')
    save(OUT/'PUBLICATION.json',dict(branch=BRANCH,source_sha=identity[0],tree=identity[1],parent=BASE,
         changed_paths=[TARGET],before_sha256=sha(before),after_sha256=sha(after),normal_push_verified=True,
         original_commands='COMMANDS.json',subject='UNRUN',controls='UNRUN',performance='UNMEASURED',
         root_authorized_shared_count_only=True,global_ledger_written=False))
    print(json.dumps(dict(source_sha=identity[0],tree=identity[1],publication=str(OUT/'PUBLICATION.json'))))

if __name__=='__main__':main()
