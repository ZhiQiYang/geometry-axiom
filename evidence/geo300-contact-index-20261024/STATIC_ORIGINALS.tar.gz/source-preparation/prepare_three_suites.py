#!/usr/bin/env python3
"""Mechanically bind the existing three-suite recorder; do not execute it."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

OUT=Path('/workspace/geo300-contact-index-three-suite-tools')
S='1ee4e830399b124ebd63c5ff51064d87e53f38d9'
ROOT='/workspace/geo300-contact-index-work'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    old_driver=Path('/tmp/geo300-run-three-suites.py').read_bytes()
    old_top=Path('/tmp/geo300-launch-three-suites.py').read_bytes()
    if sha(old_driver)!='c81e3f79ebee49a37ef255837f675837e31c3f8a7360f591d4e2ee2f35c023f5':raise RuntimeError('old driver drift')
    if sha(old_top)!='4eb3644c7ecd77f20ac60e94e1fdf7382484bddc8519b31406e2c5709562dddd':raise RuntimeError('old launcher drift')
    driver=old_driver
    for before,after in [
        (b'c493b7315d0cd3b16014add96af969c49ebf4660',S.encode()),
        (b'/tmp/train337-free-end-f4f-source',ROOT.encode()),
        (b'/workspace/geo300-c493-three-suites',b'/workspace/geo300-contact-index-three-suites'),
        (b"'tests/test_geo261_wood_contact_world.py',10",b"'tests/test_geo261_wood_contact_world.py',11"),
        (b"current_head='4f4a24d76e816274bfae06868b4dbf31f0860299'",("current_head='"+S+"'").encode()),
    ]:
        if driver.count(before)!=1 and before!=b'/workspace/geo300-c493-three-suites':raise RuntimeError('driver anchor count')
        driver=driver.replace(before,after)
    ast.parse(driver)
    (OUT/'run_three_suites.py').write_bytes(driver)
    top=old_top
    for before,after in [
        (b'/workspace/geo300-c493-three-suites-launch',b'/workspace/geo300-contact-index-three-suites-launch'),
        (b'/tmp/geo300-run-three-suites.py',str(OUT/'run_three_suites.py').encode()),
        (b'c81e3f79ebee49a37ef255837f675837e31c3f8a7360f591d4e2ee2f35c023f5',sha(driver).encode()),
        (b'c493b7315d0cd3b16014add96af969c49ebf4660',S.encode()),
        (b'/tmp/geo300-prerequisites-20261024',ROOT.encode()),
    ]:
        if top.count(before)!=1:raise RuntimeError('launcher anchor count')
        top=top.replace(before,after)
    ast.parse(top)
    (OUT/'launch_three_suites.py').write_bytes(top)
    (OUT/'run_three_suites.before.py.txt').write_bytes(old_driver)
    (OUT/'launch_three_suites.before.py.txt').write_bytes(old_top)
    patch=''
    for name,before,after in [('run_three_suites.py',old_driver,driver),('launch_three_suites.py',old_top,top)]:
        patch+=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=name+'.before',tofile=name))
    (OUT/'ADAPTATION.diff').write_text(patch)
    declaration=dict(source=S,root=ROOT,subject_executed=False,heavy_authorization_pending=True,
        original_driver_sha256=sha(old_driver),original_launcher_sha256=sha(old_top),
        driver_sha256=sha(driver),launcher_sha256=sha(top),
        original_child_limits_unchanged=True,original_outer_timeout=None,stack_bytes=16777216,
        external_output_and_temp=True,secondary_lock='/tmp/g261r3/secondary.lock',
        logical_original_commands=[['python3','-B',p] for p in [
            'tests/test_geo261_wood_contact_world.py','tests/test_geo261_contact_sources.py','tests/test_geo318_reading_a_native.py']],
        expected_methods=[11,15,7],expected_total_methods=33,
        expected_controls=[33,11,12],expected_total_controls=56,
        performance='UNMEASURED',whole_fast_path_withdrawal='semantic-equivalent control, not a killed mutation')
    (OUT/'PREPARATION.json').write_text(json.dumps(declaration,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(declaration))
if __name__=='__main__':main()
