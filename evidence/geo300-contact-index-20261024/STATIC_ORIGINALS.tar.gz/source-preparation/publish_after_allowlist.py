#!/usr/bin/env python3
"""Recover exact tracked-file staging after the recorded allowlist rejection."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess

ROOT = Path('/workspace/geo300-contact-index-work')
OUT = Path('/workspace/geo300-contact-index-source-publication')
DRAFT = Path('/tmp/geo300-next-eb846-20261024')
BRANCH = 'codex/geo300-contact-index-20261024'
BASE = 'df230da57619e437c30527dbede8c67fd0ec6b50'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def main():
    commands = json.loads((OUT/'COMMANDS.json').read_text())
    if len(commands)!=9 or commands[-1]['exit']!=1:
        raise RuntimeError('unexpected recovery history')
    def run(argv):
        number = len(commands)+1
        folder=OUT/f'{number:03d}'
        folder.mkdir(exist_ok=False)
        started=dt.datetime.now(dt.timezone.utc).isoformat()
        cp=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
        (folder/'stdout.bin').write_bytes(cp.stdout)
        (folder/'stderr.bin').write_bytes(cp.stderr)
        r=dict(number=number,argv=argv,cwd=str(ROOT),started_utc=started,
               ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),exit=cp.returncode,
               stdout=dict(path=str(folder/'stdout.bin'),bytes=len(cp.stdout),sha256=sha(cp.stdout)),
               stderr=dict(path=str(folder/'stderr.bin'),bytes=len(cp.stderr),sha256=sha(cp.stderr)))
        commands.append(r); save(folder/'receipt.json',r);save(OUT/'COMMANDS.json',commands)
        if cp.returncode: raise RuntimeError(f'command {number}: {cp.returncode}')
        return cp.stdout
    if run(['git','rev-parse','HEAD']).decode().strip()!=BASE:
        raise RuntimeError('base drift')
    manifest=json.loads((DRAFT/'DRAFT_MANIFEST.json').read_text())
    files=sorted(x['path'] for x in manifest['files'])
    tracked=run(['git','ls-files','--stage','-z','--',*files]).decode().rstrip('\0').split('\0')
    if sorted(x.split('\t')[1] for x in tracked)!=files or any(not x.startswith('100644 ') for x in tracked):
        raise RuntimeError('not the exact reviewed tracked leaves')
    for item in manifest['files']:
        if sha((ROOT/item['path']).read_bytes())!=item['candidate_sha256']:
            raise RuntimeError('candidate drift')
    # -f here bypasses the directory allowlist for these three already tracked paths.
    # It is not a Git push option and no path outside the immutable manifest is staged.
    run(['git','add','--sparse','-f','--',*files])
    staged=run(['git','diff','--cached','--name-only','-z']).decode().rstrip('\0').split('\0')
    if sorted(staged)!=files: raise RuntimeError('staged scope escaped')
    for item in manifest['files']:
        data=run(['git','show',':'+item['path']])
        if sha(data)!=item['candidate_sha256']: raise RuntimeError('staged candidate differs')
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','perf(GEO-300): index unique-ID stop-face coverage'])
    source=run(['git','rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
    if run(['git','status','--porcelain=v1','--untracked-files=all']): raise RuntimeError('not clean')
    run(['git','push','--set-upstream','origin',BRANCH])
    remote=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()
    if remote!=[source[0],'refs/heads/'+BRANCH]: raise RuntimeError('remote mismatch')
    save(OUT/'PUBLICATION.json',dict(
        branch=BRANCH,source_sha=source[0],tree=source[1],base_evidence=BASE,
        base_source='eb846c345881cc6fc73a53c457a291175365b88c',changed_paths=files,
        frozen_draft_patch_sha256=manifest['patch_sha256'],
        original_allowlist_add_exit=1,exact_tracked_force_add_exit=0,
        original_commands='COMMANDS.json',normal_push_verified=True,
        compile='UNRUN',subject='UNRUN',controls='UNRUN',performance='UNMEASURED',
        whole_optimization_withdrawal='semantic equivalence expected; not a killed mutant',
        expected_count_registration='root baton pending: wood_contact_world 10 to 11',
        source_environment={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ},
        shared_source_or_global_ledger_written=False))
    print(json.dumps(dict(source_sha=source[0],tree=source[1],publication=str(OUT/'PUBLICATION.json'))))

if __name__=='__main__': main()
