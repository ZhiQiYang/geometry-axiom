# GEO-300 剩餘前置外部草案（未實作驗收）

固定讀取來源：`eb846c345881cc6fc73a53c457a291175365b88c`；只從 `/tmp/geo260-ac23-source-5b0ce47d` 的指定 Git blobs 讀取，沒有讀取正在突變的 working files，也沒有 fetch、改 refs 或寫 source。`contact_world.c` SHA-256 仍為 `f29c84d01792428abd1c81e5cb1eefc5870c3d013a4698dd2cf64471c6dce8b5`，與 AA/C493 已測版本完全相同。SSOT／決策／FIELD-RULES 三 hash 與先前已讀完整權威相同。

本文件與後續 candidate/ 只在外部目錄；不改 AA 共檔、不提交列車、不編譯、不測試、不量效能。成本／性能仍等專屬時槽。現行 Sc493 的32方法／46反證不屬於這個新草案。

## 已做與未解

- ContactOrderIndex 已在現行 W：正常容量內 ID hash，排序保最後一筆 order、遮蓋保最小 order，超容量保原線性後備。這不是尚待重做的線性查找。
- K source.c 已有 node/edge hash、node hints 與配置失敗的原線性後備。geo_eval_depend 每次仍需驗 kind／sealed、確認 node、登記當前 consumer dependency；不以少呼叫它或少記邊換取綠燈。
- #323 已在同候選 memo 成功的 pose／footprint，每個 consumer 命中仍 geo_eval_depend。不重做 memo、不跨候選快取。
- AA bitmap 只消逐次 memmove；member insertion sort、兩兩遮蓋掃描、call-growth、cut-list 平方儲存仍在。以下只先改善正常唯一 ID 路徑的遮蓋查詢；不稱整個 collector 已 O(F log F)。排序須另案改穩定排序並保持既有正常／後備控制。

## 最小遮蓋查詢草案

1. 在既有 contact_order_index 的同一次全 facts 建表中記 unique：只要任何 fact ID 重複就 false，包括未放置、exclude、其他 placement、無效 footprint 或容量截斷以外的 facts。不得只檢查已收集面。
2. 僅當 `orders.indexed && orders.unique && count <= WOOD_CONTACT_FACE_CAPACITY` 使用新查詢；其餘保 AA 完整 active live-set／超容量 memmove 後備。沒有新拒絕、heap 配置失敗或新容量門檻。
3. 原收集、截斷、RC 前綴、member 穩定排序及最後 stable compaction 均不動。索引只排序 face 序號，從不改 out 的順序。
4. RC 前綴（包含 free fixity）先插入。已排序的 member 逐一查詢；待插入游標只在原 `contact_earlier()` 證明嚴格較早 order 時前進，只插入當下 active 的前批面。這等價於整個 same-order 批查完才插入，保原同 order 不互遮。將原 contact_earlier 用於新路徑，原 `<`→`<=` control 仍能碰到真正的批次門檻。
5. 以完整 GeoCoord fixed 分組，按完整 lo 穩定 merge-sort face 序號；每 plane 是獨立 Fenwick prefix-max，保存單一實際 face index+1（0 僅表示空），不是合併區間或虛構坐標 sentinel。
6. lo prefix 的上界同時要求 `j.lo <= i.lo && j.lo < i.hi`；從該 prefix 取得單一最大 hi 見證後，同時要求 `j.hi >= i.hi && j.hi > i.lo`。所有比較直接使用完整值，沒有端點加減或坐標相減。這同時保正長、零長、反向 i 與 INT64 邊界。
7. 函式只按結果停用目前 i／遞減 remaining，最後仍用 AA 原穩定壓緊輸出。多個半面聯集不算單一覆蓋。

唯一 ID 下，last order=min order，原可用 member coverer 一定嚴格早於當前 order，故不會有重複 ID 的「未來面刪前面」循環。較早面若被另一個更早面刪除，完整涵蓋與兩條 strict-overlap 條件可傳遞；索引只插存活面也不漏掉遮蓋能力。RC 永不由 member 去重刪除，故可先全入。索引每次重建，不跨候選／呼叫快取。

## 控制與正反例

原全部10方法／23 controls及具名 ASSERT 保留；只有既有 partial-shadow control 的產品錨點需機械改到新 normal-path 的 lo/hi full-cover helper，保持原 numeric assertion／編譯／退出碼／timeout，不把它改成只測舊後備。

新增具名案例：唯一 ID 完整64位不同 plane；兩半面不能聯集遮蓋；零長 i 的嚴格下／上端點相等不可遮蓋、嚴格包含則可刪；反向 i 嚴格包含可刪而等端點不能；所有facts重複但輸出過濾的五種路徑仍走原 min/last 後備；原 capacity-before-dedup、tail、same-order、pointer identity 照留。

草案目前11方法／33 controls，全部 UNRUN；原10方法 AST 全保。既有 partial-shadow 的 normal-path 重新錨定之外，另保舊 fallback 的專屬具名 partial-shadow 反證。預計控制：撤 eligibility／RC前綴、放寬 strict lo／hi、截32位 plane、拿錯 Fenwick plane offset、只因有prefix見證就刪、撤新路徑 remaining 遞減。每個都要 baseline0／原具名ASSERT1／restored0；build／crash／timeout／skip均非偵測。整條新快路撤回預期仍語意等價（0/0/0），不能冒作 killed。

## 操作觀測與政策邊界

待專屬時槽才做原算法、AA、草案的等價對照與操作計數。分列 member sort 比較／搬移、dedup j visits／active skips／完整比較、memmove calls與requested bytes、stable compaction assignments、prefix build/query/update。不能只因 memmove0 就宣稱更快，因 AA 活集合掃描可能增加 loop visits。

`geo_eval_depend` 僅先量原 node-hint／hash probes、edge hash probes、distinct consumer/source/kind 與重複次數；沒有證據前不加另一個 K 索引或刪 dependency calls。任何將來 edge hint 必須在原 kind/active/sealed 路徑內、完整比對 consumer/source/kind、reset 後有效、保列舉順序與原 MEMORY/失敗路徑；本批不提供 K 產品修改。

容量常數收斂、cut-list 的 groups[N]×ids[N]、N/N+1 與容量512仍為後續工作。live issue300 的 N128/256/512≤2×只是留言提議，不是本批核可新門檻；不改 P-189 的分母／16MiB／原子時限。未決數值只寫 QUESTIONS，不向使用者重問已鎖政策。
