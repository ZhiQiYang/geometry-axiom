"""Prepare an external, uncompiled candidate; never edit the active train."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parent
SOURCE='eb846c345881cc6fc73a53c457a291175365b88c'
FILES=['geometry-templates/woodworking/native/contact_world.c',
       'tests/geo261_contact_world_harness.c',
       'tests/test_geo261_wood_contact_world.py']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def replace_once(text,before,after):
    if text.count(before)!=1:raise RuntimeError('unique draft anchor missing: '+before[:100])
    return text.replace(before,after)

def constant(node,names):
    if isinstance(node,ast.Constant):return node.value
    if isinstance(node,ast.Name):return names[node.id]
    if isinstance(node,(ast.List,ast.Tuple)):
        values=[constant(n,names) for n in node.elts]
        return tuple(values) if isinstance(node,ast.Tuple) else values
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='replace' and not node.keywords:
        value=constant(node.func.value,names);args=[constant(n,names) for n in node.args]
        if not isinstance(value,str) or len(args)!=2 or not all(isinstance(a,str) for a in args):raise RuntimeError('unsupported constant replace')
        return value.replace(*args)
    raise RuntimeError('unsupported constant node: '+ast.dump(node))

def main():
    candidate=ROOT/'candidate'
    if candidate.exists():raise RuntimeError('fresh draft output required')
    original=(ROOT/'before'/FILES[0]).read_text()
    helpers=(ROOT/'face_index_helpers.inc').read_text()
    source=replace_once(original,'    bool indexed;','    bool indexed,unique;')
    source=replace_once(source,'    index->indexed=world->member_count<=WOOD_CONTACT_MEMBER_CAPACITY;',
        '    index->indexed=world->member_count<=WOOD_CONTACT_MEMBER_CAPACITY;index->unique=true;')
    source=replace_once(source,'        index->last[slot]=i+1;',
        '        if(index->last[slot])index->unique=false;\n        index->last[slot]=i+1;')
    source=replace_once(source,'size_t wood_contact_collect_stops(',helpers+'\nsize_t wood_contact_collect_stops(')
    begin=source.index('    for(size_t i=0;i<count;){bool duplicate=false;')
    end=source.index('    if(compact){size_t write=0;',begin)
    legacy=source[begin:end]
    prefix=('    size_t first=0;while(first<count&&out[first].kind!=WOOD_STOP_MEMBER_SIDE)++first;\n'
            '    if(compact&&orders.indexed&&orders.unique&&first<count)\n'
            '        contact_indexed_dedup(world,&orders,out,count,first,active,&remaining);\n'
            '    else{\n')
    source=source[:begin]+prefix+legacy+'    }\n'+source[end:]
    harness=(ROOT/'before'/FILES[1]).read_text()
    harness=replace_once(harness,'static int intervals(void)',(ROOT/'indexed_harness.inc').read_text()+'\nstatic int intervals(void)')
    harness=replace_once(harness,'if(!strcmp(argv[1],"active-dedup"))return active_dedup();',
        'if(!strcmp(argv[1],"active-dedup"))return active_dedup();if(!strcmp(argv[1],"indexed-dedup"))return indexed_dedup();')
    old_python=(ROOT/'before'/FILES[2]).read_text()
    old_tree=ast.parse(old_python)
    assignment=next(n for n in old_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
    names={t.id:n.value.value for n in old_tree.body if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant) for t in n.targets if isinstance(t,ast.Name)}
    controls=list(constant(assignment.value,names));old_controls=list(controls)
    full=('static bool contact_prefix_lo(GeoCoord a,const WoodStopFace *face)\n'
          '{return a<=face->lo&&a<face->hi;}\n'
          'static bool contact_prefix_hi(GeoCoord a,const WoodStopFace *face)\n'
          '{return a>=face->hi&&a>face->lo;}')
    partial=full.replace('a<=face->lo&&','').replace('a>=face->hi&&','')
    for i,control in enumerate(controls):
        if control[0]=='partial-shadow':controls[i]=(control[0],full,partial,*control[3:])
    controls.extend([
        ('indexed-unique-facts','if(index->last[slot])index->unique=false;','if(false)index->unique=false;','indexed-dedup','indexed-filtered-duplicate-order'),
        ('indexed-rc-free-prefix','for(size_t i=0;i<first;++i)contact_face_index_insert(&index,out,count,i);','for(size_t i=0;i<first;++i)if(out[i].fixity!=WOOD_STOP_FREE)contact_face_index_insert(&index,out,count,i);','ordering','boundary-even-free-owns-coincident-face'),
        ('indexed-strict-lo','return a<=face->lo&&a<face->hi;','return a<=face->lo;','indexed-dedup','indexed-zero-lower-strict'),
        ('indexed-strict-hi','return a>=face->hi&&a>face->lo;','return a>=face->hi;','indexed-dedup','indexed-zero-upper-strict'),
        ('indexed-plane-coordinate','return (a>b)-(a<b);','return ((int32_t)a>(int32_t)b)-((int32_t)a<(int32_t)b);','indexed-dedup','indexed-full-coordinate-plane'),
        ('indexed-plane-offset','size_t value=index->maximum[begin+at-1];','size_t value=index->maximum[at-1];','indexed-dedup','indexed-full-coordinate-plane'),
        ('indexed-single-witness','return witness&&contact_prefix_hi(out[witness-1].hi,face);','return witness!=0;','indexed-dedup','indexed-two-halves-not-one-cover'),
        ('indexed-survivor-count','active[i]=false;--*remaining;','active[i]=false;','ordering','earlier-full-cover-deduplicates'),
        ('indexed-reversed-skip','size_t begin,end;contact_face_plane_range(index,out,count,face->fixed,&begin,&end);','if(face->hi<face->lo)return false;size_t begin,end;contact_face_plane_range(index,out,count,face->fixed,&begin,&end);','indexed-dedup','indexed-enclosed-reversed-span'),
        ('legacy-partial-shadow','if(earlier&&out[j].lo<=out[i].lo&&out[j].hi>=out[i].hi)duplicate=true;','if(earlier)duplicate=true;','indexed-dedup','indexed-duplicate-fallback-keeps-partial-shadow'),
    ])
    lines=old_python.splitlines(True)
    segment=lines[assignment.lineno-1:assignment.end_lineno]
    partial_node=next(node for node,control in zip(assignment.value.elts,old_controls) if control[0]=='partial-shadow')
    partial_control=next(c for c in controls if c[0]=='partial-shadow')
    segment[partial_node.lineno-assignment.lineno:partial_node.end_lineno-assignment.lineno+1]=['    '+repr(partial_control)+',\n']
    segment[-1]=''.join('    '+repr(c)+',\n' for c in controls[len(old_controls):])+segment[-1]
    python=''.join(lines[:assignment.lineno-1])+''.join(segment)+''.join(lines[assignment.end_lineno:])
    python=replace_once(python,'    def extension_transaction(self, executable):',
        '    def test_unique_id_prefix_query_keeps_public_degenerate_and_filtered_facts(self):\n'
        '        self.assertEqual(0, self.case("indexed-dedup").returncode)\n\n'
        '    def extension_transaction(self, executable):')
    values=[source,harness,python]
    for path,value in zip(FILES,values):
        dest=candidate/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(value)
    new_tree=ast.parse(python)
    new_assignment=next(n for n in new_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
    for old_node,new_node,control in zip(assignment.value.elts,new_assignment.value.elts,old_controls):
        if control[0]!='partial-shadow' and ast.dump(old_node,include_attributes=False)!=ast.dump(new_node,include_attributes=False):raise RuntimeError('old control AST changed')
    old_functions={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(old_tree) if isinstance(n,ast.FunctionDef)}
    new_functions={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(new_tree) if isinstance(n,ast.FunctionDef)}
    if any(new_functions.get(name)!=value for name,value in old_functions.items()):raise RuntimeError('old Python function changed')
    for old,new in zip(old_controls,controls):
        if old[0]!='partial-shadow' and old!=new:raise RuntimeError('old control changed')
        if old[0]=='partial-shadow' and (old[0],*old[3:])!=(new[0],*new[3:]):raise RuntimeError('old assertion/case changed')
    anchors=[{'name':c[0],'before_hits':source.count(c[1]),'expected_assertion':c[4]} for c in controls]
    if any(c['before_hits']!=1 for c in anchors):raise RuntimeError('draft controls not unique: '+repr(anchors))
    parts=[];commands=[]
    for path in FILES:
        argv=['git','diff','--no-index','--binary','--','before/'+path,'candidate/'+path]
        p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if p.returncode!=1:raise RuntimeError('expected a nonempty draft diff')
        output=b''.join(line.replace(b'a/before/',b'a/').replace(b'b/candidate/',b'b/') if line.startswith((b'diff --git ',b'--- ',b'+++ ')) else line for line in p.stdout.splitlines(True))
        parts.append(output);commands.append({'argv':argv,'exit':p.returncode,'meaning':'nonempty no-index diff, not subject failure','original_stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
    patch=b''.join(parts);(ROOT/'DRAFT.patch').write_bytes(patch)
    manifest={'schema':'geo300-unique-id-prefix-query-external-draft/1','base':SOURCE,'shared_branch_or_source_written':False,'new_product_or_test_commit':False,'files':[{'path':p,'before_sha256':sha((ROOT/'before'/p).read_bytes()),'candidate_sha256':sha((candidate/p).read_bytes())} for p in FILES],'patch_sha256':sha(patch),'old_python_function_AST_preserved':True,'old_test_methods':sum(n.startswith('test_') for n in old_functions),'candidate_test_methods':sum(n.startswith('test_') for n in new_functions),'old_controls':len(old_controls),'candidate_controls':len(controls),'only_existing_control_reanchor':'partial-shadow: same case/assertion/timeout, new normal-path full-cover helper','legacy_live_set_loop_preserved_exactly':source.count(legacy)==1,'controls':anchors,'original_C_CHECK_lines_preserved':all(line in harness.splitlines() for line in (ROOT/'before'/FILES[1]).read_text().splitlines() if 'CHECK(' in line),'capacity_and_public_header_changed':False,'stack_storage_unmeasured':'ContactFaceIndex four size_t[WOOD_CONTACT_FACE_CAPACITY] fixed local arrays; no heap, additional stack must be measured under existing16MiB contract','sort_scope':'metadata merge sort only; original member insertion sort remains unchanged, so collector not claimed O(F log F)','subject':'UNRUN','compile':'UNRUN','performance':'UNMEASURED','global_mutation_registry_or_ledger_written':False,'commands':commands}
    (ROOT/'DRAFT_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:manifest[k] for k in ['base','patch_sha256','old_test_methods','candidate_test_methods','old_controls','candidate_controls','legacy_live_set_loop_preserved_exactly','original_C_CHECK_lines_preserved','subject']},indent=2))
if __name__=='__main__':main()
