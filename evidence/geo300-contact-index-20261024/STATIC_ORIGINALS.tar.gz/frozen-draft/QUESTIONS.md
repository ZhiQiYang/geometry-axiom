# 尚未採用的政策／量測界線

- N128/256/512 每點≤2×只是 live issue300 留言提議，尚未採作新 gate。這批只準備原語意／具名反證與操作觀測，保原 P-189 分母、16MiB與原時限；不向使用者重問舊已鎖決策。
- 新固定 stack 索引只在原 face capacity 內運作，額外四個 size_t[capacity] 尚未編譯／量 stack；若既定16MiB不容許，採另一種可逆資料布局，不放寬契約。
- 繼承的 member insertion sort 仍平方，故本草案只稱正常路徑遮蓋查詢 O(F log F)，不把 collector/call-growth 或容量512視為完成。
- 不移除 geo_eval_depend／來源邊，不新增跨候選快取。K edge hints 是否值得做須先有 probes 真證據，目前不提供 K 產品改動。
- cut-list public POD／容量收斂為後續獨立工作，本批不改其 representation。
