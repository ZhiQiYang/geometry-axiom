#!/usr/bin/env python3
"""唯讀三棵固定 Git tree 的 fixture evidence 身分；不產生沿用或 gate 判決。"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback


KNOWN_FIXTURE_PREFIXES = (
    'tests/evidence',
    'geometry-web/docs/evidence',
    'geometry-core/domain-decoupling/evidence',
)
FRAMING_PREFIXES = (
    'geometry-core/framing-template/oracle',
    'geometry-core/framing-template/core-probe',
)
# No known decision-input fixture is inside the root publication families.
# Add an exact repository-relative path here only after a separate review.
PUBLICATION_READ_FIXTURE_EXCEPTIONS = frozenset()
REPO_REDIRECT_ENV = (
    'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_PREFIX',
    'GIT_CEILING_DIRECTORIES', 'GIT_DISCOVERY_ACROSS_FILESYSTEM',
)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    # Escaping also preserves a non-UTF-8 Git pathname decoded with surrogateescape.
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')


def file_info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw)}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def below(path, prefix):
    return path.startswith(prefix + '/')


def classify(path):
    parts = path.split('/')
    if 'evidence' not in parts:
        return None
    if path in PUBLICATION_READ_FIXTURE_EXCEPTIONS:
        return 'required_fixture_identity'
    if len(parts) >= 2 and parts[0] == 'evidence' and parts[1].startswith('geo261-final-'):
        return 'root_publication_evidence_separately_collected'
    if any(below(path, prefix) for prefix in FRAMING_PREFIXES):
        return 'changed_framing_evidence_not_inherited'
    return 'required_fixture_identity'


def parse_tree(raw):
    require(not raw or raw.endswith(b'\0'), 'ls-tree 缺 NUL 結尾')
    entries = {}
    for record in raw.split(b'\0')[:-1]:
        header, path_bytes = record.split(b'\t', 1)
        fields = header.split(b' ')
        require(len(fields) == 3, 'ls-tree header 格式不同')
        mode, kind, oid = (part.decode('ascii') for part in fields)
        path = path_bytes.decode('utf-8', 'surrogateescape')
        require(path and not any(p in ('', '.', '..') for p in path.split('/')), 'Git path 非正規相對路徑')
        require(path not in entries, 'ls-tree 路徑重複')
        require(re.fullmatch('[0-9a-f]{40}', oid) is not None, '只接受完整 SHA-1 Git object 身分')
        entries[path] = {'mode': mode, 'objectType': kind, 'oid': oid}
    return entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--old-sha', required=True)
    parser.add_argument('--new-sha', required=True)
    parser.add_argument('--evidence-base-sha', required=True)
    parser.add_argument('--out-dir', required=True, type=Path)
    args = parser.parse_args()
    commits = {'old': args.old_sha, 'new': args.new_sha, 'evidenceBase': args.evidence_base_sha}
    require(all(re.fullmatch('[0-9a-f]{40}', value) for value in commits.values()), '三個 SHA 都須明填完整40碼，不接受 HEAD 或縮寫')
    repo, out = args.repo.resolve(), args.out_dir.resolve()
    require(repo.is_dir() and (repo / '.git').exists(), '--repo 須為既有 checkout 根目錄')
    require(not out.exists(), 'out-dir 須全新，不覆寫原證據')
    require(not out.is_relative_to(repo) and not repo.is_relative_to(out), 'out-dir 須在 repo 外，且不得為 repo 祖先')
    self_path = Path(__file__).resolve()
    driver_before = file_info(self_path)
    out.mkdir(parents=True, exist_ok=False)
    (out / 'commands').mkdir()
    env = dict(os.environ)
    cleared = [name for name in REPO_REDIRECT_ENV if name in env]
    for name in cleared:
        env.pop(name)
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1', GIT_TERMINAL_PROMPT='0')
    safe_env = {name: env.get(name) for name in (
        'PATH', 'LANG', 'LC_ALL', 'GIT_OPTIONAL_LOCKS', 'GIT_NO_REPLACE_OBJECTS', 'GIT_TERMINAL_PROMPT',
    )}
    result = {
        'schema': 'geo288-fixture-evidence-tree-identity/1',
        'purpose': 'metadata only; no inherited-acceptance or gate decision',
        'repo': str(repo), 'requestedCommits': commits, 'verifiedCommits': {},
        'startedUtc': now(), 'argv': [sys.executable, *sys.argv],
        'driverBefore': driver_before,
        'environment': {'system': platform.system(), 'release': platform.release(), 'machine': platform.machine(),
                        'python': sys.version, 'pythonExecutable': sys.executable, 'safeVariables': safe_env,
                        'clearedRepositoryRedirectNames': cleared,
                        'inheritedGitConfigAndAuthValuesNotLogged': True},
        'scope': {
            'selection': 'exact path component evidence, in the union of three complete fixed Git trees',
            'requiredFixturePrefixes': list(KNOWN_FIXTURE_PREFIXES),
            'rootPublicationExclusion': 'only first two path components evidence/geo261-final-*',
            'publicationReadFixtureExceptions': sorted(PUBLICATION_READ_FIXTURE_EXCEPTIONS),
            'publicationEvidenceRole': 'not compared as required fixtures; old F2 publication is covered separately by the public collector 110 entries, not verified by this tool',
            'framingEvidenceNotInheritedPrefixes': list(FRAMING_PREFIXES),
            'identityBasis': 'tracked path set, Git mode, object type and full object ID; no checkout content, HEAD, test execution or untracked-file claim',
        },
        'commands': [], 'errors': [], 'metadataComplete': False, 'exitCode': 1,
    }
    save(out / 'result.json', result)

    def git(label, *arguments):
        folder = out / 'commands' / f'{len(result["commands"]):03d}-{label}'
        folder.mkdir()
        argv = ['git', '--no-pager', '--no-optional-locks', '--no-replace-objects', '-C', str(repo), *arguments]
        row = {'label': label, 'argv': argv, 'cwd': str(repo), 'startedUtc': now(),
               'environment': safe_env, 'actualReturncode': None, 'timeoutExpired': False}
        save(folder / 'request.json', row)
        started = time.monotonic()
        stdout = stderr = b''
        try:
            completed = subprocess.run(argv, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120, check=False)
            stdout, stderr = completed.stdout, completed.stderr
            row['actualReturncode'] = completed.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr = error.stdout or b'', error.stderr or b''
            row['timeoutExpired'] = True
            row['exception'] = type(error).__name__
        except OSError as error:
            row['exception'] = type(error).__name__ + ': ' + str(error)
        finally:
            (folder / 'stdout.bin').write_bytes(stdout)
            (folder / 'stderr.bin').write_bytes(stderr)
            row.update(finishedUtc=now(), seconds=time.monotonic() - started,
                       stdout=file_info(folder / 'stdout.bin'), stderr=file_info(folder / 'stderr.bin'))
            result['commands'].append(row)
            save(folder / 'result.json', row)
            save(out / 'result.json', result)
        require(row['actualReturncode'] == 0 and not row['timeoutExpired'], 'Git 唯讀命令未完成：' + label)
        return stdout

    try:
        top = Path(os.fsdecode(git('repository-root', 'rev-parse', '--show-toplevel')).strip()).resolve()
        require(top == repo, '--repo 不是 Git 回報的 checkout 根目錄')
        trees = {}
        for role, expected in commits.items():
            actual = git('verify-' + role, 'rev-parse', '--verify', expected + '^{commit}').decode('ascii').strip()
            require(actual == expected, role + ' 未解析成指定的完整 commit SHA')
            result['verifiedCommits'][role] = actual
            trees[role] = parse_tree(git('tree-' + role, 'ls-tree', '-rz', '--full-tree', actual))
        union = sorted(set().union(*(tree.keys() for tree in trees.values())))
        inventory = []
        for path in union:
            category = classify(path)
            if category is None:
                continue
            identities = {role: tree.get(path) for role, tree in trees.items()}
            old, new, base = (identities[role] for role in ('old', 'new', 'evidenceBase'))
            inventory.append({'path': path, 'classification': category,
                              'requiredIdentity': category == 'required_fixture_identity',
                              'before': old, 'after': new, 'evidenceBase': base,
                              'oldEqualsNew': old == new, 'oldEqualsEvidenceBase': old == base,
                              'newEqualsEvidenceBase': new == base, 'threeWayEqual': old == new == base})
        save(out / 'evidence-inventory.json', inventory)
        coverage = {prefix: {role: sum(below(path, prefix) for path in tree) for role, tree in trees.items()}
                    for prefix in KNOWN_FIXTURE_PREFIXES}
        required = [row for row in inventory if row['requiredIdentity']]
        framing = [row for row in inventory if row['classification'] == 'changed_framing_evidence_not_inherited']
        publication = [row for row in inventory if row['classification'] == 'root_publication_evidence_separately_collected']
        differences = [row['path'] for row in required if not row['threeWayEqual']]
        unsupported = [{'path': row['path'], 'role': role, **identity}
                       for row in required for role, identity in (
                           ('old', row['before']), ('new', row['after']), ('evidenceBase', row['evidenceBase']))
                       if identity is not None and identity['objectType'] != 'blob']
        empty = [{'prefix': prefix, 'role': role} for prefix, roles in coverage.items() for role, count in roles.items() if not count]
        result.update(
            treeEntryCounts={role: len(tree) for role, tree in trees.items()},
            inventory=file_info(out / 'evidence-inventory.json'),
            requiredFixturePrefixCoverage=coverage,
            requiredFixtureIdentity={'pathCount': len(required), 'threeWayEqual': not differences,
                                     'differencePaths': differences, 'unsupportedObjects': unsupported, 'missingRequiredPrefixes': empty},
            changedFramingEvidenceNotInherited={'pathCount': len(framing),
                                               'differentPaths': [row['path'] for row in framing if not row['threeWayEqual']],
                                               'entries': framing},
            rootPublicationEvidenceExcluded={'pathCount': len(publication), 'entries': publication},
            metadataComplete=True,
        )
        result['exitCode'] = 1 if differences or unsupported or empty else 0
    except BaseException as error:
        result['errors'].append({'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
        result['exitCode'] = 1
    finally:
        try:
            result['driverAfter'] = file_info(self_path)
            result['driverUnchanged'] = result['driverAfter'] == driver_before
            if not result['driverUnchanged']:
                result['errors'].append({'type': 'DriverChanged', 'message': 'collector source changed during collection'})
                result['exitCode'] = 1
        except OSError as error:
            result['errors'].append({'type': type(error).__name__, 'message': str(error)})
            result['exitCode'] = 1
        result['finishedUtc'] = now()
        save(out / 'result.json', result)
    print(json.dumps({'result': str(out / 'result.json'), 'metadataComplete': result['metadataComplete'],
                      'exitCode': result['exitCode']}, ensure_ascii=True), flush=True)
    return result['exitCode']


if __name__ == '__main__':
    raise SystemExit(main())
