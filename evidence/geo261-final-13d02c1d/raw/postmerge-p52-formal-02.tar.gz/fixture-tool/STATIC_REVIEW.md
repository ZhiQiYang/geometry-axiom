# 唯讀 fixture addendum 工具靜態複核

2026-10-23 UTC。根代理委託的 repo 外工具，沒有執行 collector、測試或編譯；只有 AST parse、精讀與 Git 唯讀小核。

- `collect_fixture_identity.py` SHA256：`0fc8a1957e56bc5a54325bb90e6e2f419fa1d53d8d5740ca24cd3e79f469ec8a`。
- `README.md` SHA256：`88fff59691ece08c675516b924d3174809b11a78f074f0fcbfa465d951307ba8`。
- 準備代理、獨立子審查員與父審查員都完成純靜態精讀；父審查員另一次 `ast.parse` 成功，未 import／執行工具。

Git argv 限於固定 commit `rev-parse`、checkout 根目錄查詢及 `ls-tree`；不使用 HEAD 當 source，不呼叫 checkout／status／commit／push。輸出全新且須在 repo 外；清掉 repo/object-store 重導環境，停用 replace objects、optional locks 與互動認證。固定 SHA 解析、NUL tree 解析、三方 union 對新增／刪除、mode／kind／OID 比較與 unsupported gitlink 判定都有保守失敗。

所有命令保存完整 stdout／stderr、真 exit、環境安全欄位、argv、cwd、時間與 hash；不列出認證環境。工具前後自身 hash 不同會退出 1。沒有刪除、寫 source 或 Git mutation 分支。

分類覆蓋所有精確路徑元件 `evidence`：required fixtures；根 `evidence/geo261-final-*` publication；已另行實跑的 framing oracle／probe evidence。後兩類完整保留三方名冊及差異但不冒稱相同。三個明列 fixture prefixes 在 F 的唯讀 `git ls-tree -d` 均存在；正式執行仍逐三棵 tree 核非空及逐檔身分。

這是 metadata 收集工具，其 exit 0 不等於九項在新 F 實跑。原 F2 110 筆 publication、外部原 raw archive 與 toolchain 仍由其原收據守住。未發現阻擋執行的靜態缺陷；執行結果須由根代理另行封存，不能用本檔取代。
