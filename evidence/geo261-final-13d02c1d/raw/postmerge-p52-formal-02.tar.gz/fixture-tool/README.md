# Fixture evidence Git identity metadata

此工具只讀三個明填的完整 commit SHA，以 `git ls-tree -rz --full-tree` 記錄 tracked path、mode、object type 與完整 object ID。不讀工作樹產品 bytes，不查或切換 HEAD，不執行測試、編譯或其他 collector，不產生「可沿用」或 gate 判決。舊 F2 仍是 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6` 的原證據，不因 metadata 相等而改標成新 F 實跑。

```bash
python3 -B /workspace/geo288-main-merge-20261023/closure-addendum-tools/collect_fixture_identity.py \
  --repo /workspace/geometry-axiom \
  --old-sha OLD_FULL_40_HEX_COMMIT \
  --new-sha NEW_FULL_40_HEX_COMMIT \
  --evidence-base-sha EVIDENCE_BASE_FULL_40_HEX_COMMIT \
  --out-dir /tmp/geo288-fixture-identity-UNIQUE
```

上面是執行格式；此準備步驟未執行 collector。三個 SHA 都須為小寫完整 40 碼，並逐一驗證其解出的 commit 正是傳入值；不接受 HEAD、縮寫、tag 物件或 fallback。`out-dir` 須全新，位於 repo 外且不是 repo 的祖先。`--repo` 須指向 checkout 根目錄，不能傳子目錄。

## 精確範圍

工具以三棵完整 tree 的 path 聯集分類，判斷的是精確路徑元件 `evidence`，不把新增或刪除漏出比較。

- 所有其他含 `evidence` 元件的 nonpublication 路徑都要求三方身分相等。已知讀取 fixtures 的 `tests/evidence/`、`geometry-web/docs/evidence/`、`geometry-core/domain-decoupling/evidence/` 明列為 required prefixes，三棵樹各自須非空；它們不受 publication 排除。Symlink 的 mode `120000` 與 blob 也照列，不追 symlink 到工作樹；required fixture 若為非 blob（例如 gitlink），會明列為 unsupported，退出 1。
- 僅當前兩個 path 元件是根層 `evidence/geo261-final-*`，才分類為 `root_publication_evidence_separately_collected`，逐檔保留三方 before／after／evidenceBase，但不要求 fixture identity。巢狀同名目錄不會被排除。原 F2 publication evidence 由另一份公開 collector 的 110 entries 涵蓋，本工具不驗證或擴張那個主張。目前沒有已知直接讀取 fixture 位於這些根層 publication families；`PUBLICATION_READ_FIXTURE_EXCEPTIONS` 明列為空。若後續發現，須另外審閱後填入精確檔案路徑，不能默認 publication 都是未讀輸入。
- `geometry-core/framing-template/oracle/` 與 `geometry-core/framing-template/core-probe/` 中帶 `evidence` 元件的路徑分類為 `changed_framing_evidence_not_inherited`。它們也完整列出三方存在性、mode、object type、OID 與差異，包含主線新增的 round22 evidence；這兩族不沿用，須另行實跑，因此其差異不導致本 metadata 工具退出 1。不把非 evidence 的 framing 檔混入這份名冊。

`evidence-inventory.json` 是全部三類 evidence 路徑的逐檔名冊。每列的 `before`、`after`、`evidenceBase` 對應 old／new／evidence-base commit；不存在時為 `null`。`result.json` 明列 required fixture 差異，以及兩類不要求 fixture identity 的完整排除名冊，沒有全 repo evidence 都相等的主張。

## 紀錄與退出碼

每條 Git 命令都有精確 argv、cwd、真正 return code、時間、raw `stdout.bin`／`stderr.bin`、byte count、SHA-256 與 request／result JSON。`ls-tree` 按 NUL 切記錄，再依第一個 TAB 分隔 header 與 path；不用空白或換行拆檔名，非 UTF-8 path 以 surrogateescape 保留並用 JSON escape 保存。工具另記 OS／Python、安全環境欄位、自身前後 SHA-256；不輸出繼承環境中的認證值。

只清除會重導 repo／object store 的具名 `GIT_*` 環境變數，保留 Git config／authheaders 的繼承值但不記其內容；明確停用 replace objects、optional locks 與互動認證。Git 操作僅有固定 commit 驗證、repo 根目錄查詢與 tree 讀取，沒有 checkout、clone、status、update 或任何寫入 repo 的操作。

- `0`：required fixture 三方 path／mode／type／OID 相等、required prefixes 非空、沒有 unsupported required object，且 metadata 收集完整。這只是身分 metadata 的退出碼。
- `1`：required fixture 新增、刪除或任一三方差異，或缺 required prefix、非 blob required object、Git／解析／工具身分錯誤。framing／publication 差異僅列出，不觸發此碼。

建立輸出目錄後的失敗會盡量保全已完成命令與錯誤。collector 不計入 untracked 檔案，不證明外部 toolchain、原反證 raw 資產或其他 collector 結果；那些仍保留各自原收據及身分範圍。
