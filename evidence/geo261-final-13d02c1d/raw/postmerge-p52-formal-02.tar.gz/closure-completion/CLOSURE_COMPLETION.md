# #288 fixture evidence 身分補證完成

本檔另記實際收集結果；原 `CLOSURE_PEER_REVIEW.md` 保持凍結，SHA256 仍為 `2c21d7f887ca2eac346720f2a95b7f1ffd9853708baaed87d1d5a2f94d4c3a6b`。此補證是 metadata 身分核查，沒有重新執行九項原 gate，也沒有將原 F2 結果改標為新 F 實跑。

- old F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。
- evidence base：`4b665fae21ab63aaffb7d84f6a32d5a469ba1675`。
- new F：`13d02c1db7022145a52ee063286a558e595eb212`。
- 實際收集時間：2026-10-23 05:44:20.505500 至 05:44:21.144119 UTC。
- root 原始 outer receipt exit `0`；collector 原 process return code `0`、無 timeout；inner `exitCode=0`、`metadataComplete=true`、`errors=[]`。七條原 Git 唯讀命令全部 exit `0`。

實際指令已由 outer 原收據完整保存：

```bash
python3 -B /workspace/geo288-main-merge-20261023/closure-addendum-tools/collect_fixture_identity.py \
  --repo /workspace/geometry-axiom \
  --old-sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 \
  --new-sha 13d02c1db7022145a52ee063286a558e595eb212 \
  --evidence-base-sha 4b665fae21ab63aaffb7d84f6a32d5a469ba1675 \
  --out-dir /workspace/geo288-main-merge-20261023/closure-fixture-13d02c1d
```

三個 commit 均解析成指定完整 SHA。required fixture 共 **18461** 筆，三方 tracked path／mode／object type／OID 全同；沒有差異、unsupported object 或缺漏 prefix。已知 prefix 的 old／new／evidenceBase 數量分別都相同：

| Prefix | 每棵 tree 筆數 |
| --- | ---: |
| `tests/evidence/` | 12272 |
| `geometry-web/docs/evidence/` | 596 |
| `geometry-core/domain-decoupling/evidence/` | 882 |

framing oracle／probe evidence 分類共 8 筆，8 筆存在差異，完整名冊保留為本輪不沿用；root `evidence/geo261-final-*` publication 分類共 467 筆，完整三方名冊另列而不要求相等。這不聲稱全 repository evidence 均相同。原 F2 publication 的 110 筆守恆仍引用原 closure collector。

collector driver 前後與目前檔案 SHA256 均為 `0fc8a1957e56bc5a54325bb90e6e2f419fa1d53d8d5740ca24cd3e79f469ec8a`，`driverUnchanged=true`。原收據保存 Linux／Python、安全環境欄位、完整命令 streams、時間與 hash；outer stdout／stderr 的實際小檔亦與原收據 hash 相符。

| 產物 | Bytes | SHA256 |
| --- | ---: | --- |
| `closure-fixture-outer/receipt.json` | 4731 | `f4b9435f95dabc86e46feb2425e51ab9c89ce9c85307789d5a593885ddd4608f` |
| `closure-fixture-outer/subcommands/000001/result.json` | 2151 | `541a47ae6a57c1fed79d4cb9b092ecdfe5629236a7f16285f014594c7ca2841e` |
| `closure-fixture-13d02c1d/result.json` | 382078 | `07bc1aa0d9675d5be3fd5afa7783614bd55c4dc7708c71996c4fb54d249554d5` |
| `closure-fixture-13d02c1d/evidence-inventory.json` | 14090811 | `040f19e65e44c3f2cecad823cfb757c6c3e30a9e645414aa0dd1eb88c08f72c0` |

前三個 hash 由本次唯讀小 metadata 複核重新計算；inventory 的 bytes 已核檔案 stat、hash 引用原 collector 收據，未為此重新掃讀 14 MB inventory 或解壓 raw archive。沒有重新跑 collector、測試、編譯或 Git mutation，沒有改原 peer review、原 collector 或其 JSON。

原 peer review 所指出的「evidence fixtures 尚待機械補證」已由本次實際收集補齊。九項仍維持原 F2 執行與原外部資產／環境身分；完整七項與本輪其他不沿用項目的新 F 實跑，另由各自原收據記錄。
