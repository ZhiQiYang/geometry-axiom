# #288 merge 後沿用證據的靜態複核

2026-10-23 UTC。這是 metadata／依賴範圍複核，不是新的 acceptance gate；本複核沒有執行測試、編譯、突變、效能量測或 closure collector，沒有修改 repository。

- 原執行 F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。
- 原公開 evidence head：`4b665fae21ab63aaffb7d84f6a32d5a469ba1675`。
- 新產品 F：`13d02c1db7022145a52ee063286a558e595eb212`。
- 複核對象：repo 外 `closure_identity.py` 與已產 `closure-final-13d02c1d/CLOSURE_IDENTITY.json`；沒有改寫它們。

## 身分證據與缺口

原 collector 的 5108 筆廣泛 source／asset／fixture superset，F2→F 的 Git blob 與 mode 全同；舊 `evidence/geo261-final-8f76f2b7/` 的 110 筆 E→F 也全同。9 筆原 metrics 保留 F2 執行 SHA、原指令、原 exit 與原時間；不能改寫成 F 實跑。

collector 把任何路徑組件恰為 `evidence` 的檔案整族排除，因此單靠 5108 筆不能涵蓋 `tests/evidence` 等 fixture。唯讀 `git diff --raw F2 F -- tests/evidence geometry-web/docs/evidence geometry-core/domain-decoupling/evidence` 為空（exit 0）。應另封存 `closure-addendum-tools/collect_fixture_identity.py` 的精確 blob＋mode 清單，不能把這個小讀取當成正式 addendum 已完成。

新增的非 root publication evidence 恰為 `geometry-core/framing-template/oracle/evidence/round22/` 八檔；這族與 framing oracle／probe 本輪不沿用，需在 addendum 明列排除。root `evidence/geo261-final-*` publication 可以前進；原 F2 的 110 筆由原 collector 另守。其餘非 publication、非 framing 的 evidence 應整族比較，避免漏掉間接 fixture。

補充唯讀 Git 核查：F2→F 全 repository `*.c`、`*.h`、`*.inc` 的 `git diff --raw` 為空（exit 0）；兩版 manifest 的 `sources` 完整 333 筆 array 全同，不只 path 集合相同。

## 九項的間接讀取

| 原結果 | 實際輸入邊界與判斷 |
| --- | --- |
| Q38 | `section_profile_mutation_check.py` 的隔離複製只有 flat tests/core/modeling/web Python、四個 model／fixture roots、SSOT，以及 native C/H/INC。framing 六份 Python 不在複製集合。driver 原本明列排除 source-graph 顯示身分測項；保守追讀該測項仍可閉合：`scenario_verify._validator_pins()` 間接使用 `geometry_app.source_closure`，只收四個 package 的 `.py/.json` 與 core/app/templates 的 C/H/INC，不讀 queue、四架構衍生檔或 framing Python。既有 fixture 如 Q38 JSON／gcanvas 在 superset；廣掃 C 的 evidence 路徑由全 C/H/INC 不變與 addendum 補足。 |
| §7 card-reference（含 axiom mutations） | 兩 driver 直接編譯 native、執行具名 Python unittest；讀 `tests/run_all.expected.json`、card mutation／confirmation probe、modeling target、modeling-cases、SSOT 與 tests/fixtures。間接 modeling host 的 `source_closure` 同上一列。沒有啟動 web server／RuntimeSnapshot，也沒有發現 queue、framing Python、四架構衍生檔輸入。 |
| P-189 | 原固定 main `adbaebf9`、base `3e600772`、F2；外部 `gen_scene.py` 的 single 家族生成 N=16/32/48/64；其他 root scenes 取固定 base。直接編譯 C bridge，直接送 CLI loadfile／dump。tar 雖複製 framing 目錄，其 Python／JSON 未被執行或當輸入；沒有啟動 web runtime。舊 timing／dump 樣本可按相同 source 邊界沿用，不能稱新 F 重新量測。 |
| reader | `test_axiom_reader` → `sync_axiom_reader` → `axiom_matrix`：讀 SSOT、白話、canonical HTML、current_geometry、根 `*.scene`、tests/mutate、witness manifest／SVG。scene 只掃文字條號；manifest 的 scene 欄只作圖說，沒有追讀引用。未讀排除族。 |
| checker | 指定 assertion 方法只讀 current_geometry；匯入閉包另含 tests/_bridge、binaries、test_geo261_native_kernel、test_engineering_json，但該方法不呼叫 native()。工具另守 contact_world.c/h。未讀排除族。 |
| parser prepare | 明列七份 placement/kernel C/header 與 14 筆 INPUTS＋CONTEXT；CONTEXT 只雜湊，不追 includes。vectors 在工具記憶體生成，不讀 fixture。未讀排除族。 |
| parser O2 | 讀舊 repo 外 prepared.json、client.c、七份 snapshots/kernel 並核原 hash；不是重新讀新 repository evidence。沿用原 F2 phase 與其外部資產身分。 |
| parser sanitized | 同 O2；原 compiler／sanitizer／外部 snapshots 仍屬舊 F2 原執行環境，不由 source identity 產生新執行。 |
| Cperf | 有讀架構 manifest：`bundle/run.py:116–118` 只比 `sources[].path` 集合與 design 的 owned_product_hashes，之後逐 owned source 核 hash；本輪此投影及完整 333 筆 sources 都未變。沒有把六個 exclusions digest／sourceBaseHead 當量測輸入。另讀舊 repo 外重綁審查、frozen tools／counterfactual、P-189 receipt、timing raw，保留其原資產與原 F2 身分。原 attempt1 ENOSPC 的 exit 1 與 retry1 的 exit 0 都要保留，不能抹成一次全綠。 |

依賴複核另外由子審查員精讀 reader／checker／parser 工具及呼叫鏈；不是僅用 import 名稱或字串不存在判定。Q38／§7 的 source_closure 會監看較廣的目錄 stat 以失效 process-local cache；這不把新 framing Python 或 queue 內容加入其 source inventory。

## 可沿用的範圍與未知事項

在 addendum 確認其餘 fixture evidence 身分相同後，未發現九項有尚未閉合的 repository 輸入變更；保留為「F2 原實跑＋F2→F 輸入身分相同」。addendum 尚未實跑前，不能宣稱排除的 evidence fixtures 已有完整機械證據。

外部舊 proof 資產不能由 5108 清單替代。本次只小讀原 inventory，不解壓 raw archive：三份 parser inventory 都明列 prepared.json、client.c、七份 snapshots/kernel；Cperf retry inventory 明列重綁審查、frozen design／工具、timing raw。這些 inventory 和 raw tar 的 Git blob 都在原 110 筆守恆集合；本複核沒有重新驗證 archive 內每個 member 或重新執行原裁判。原 archive 的完整性判斷仍引用其原收據，不能新增「本次重新檢驗通過」宣稱。

完整七項、ledger、架構三原裁判、P52、P73、Chrome 154 subset、framing oracle／probe 與其反證均已由 collector 明列不沿用；尤其 RuntimeSnapshot 會包含變更的 framing Python，故這些項目需保留新 F 的原始實跑。
