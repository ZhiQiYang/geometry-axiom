# 新 final SHA 的 P52 正式 protocol 綁定工具

`p52-formal.py` 目前只完成工具準備與靜態核對，沒有執行產品、建置、瀏覽器或效能量測。

它保持四個原 protocol 檔案的 bytes／SHA-256 不變：`postfix_validate.py`、`p52_measure.py`、`p52_probe.cjs`、`p52_cases.cjs`。原 `postfix_validate.one` 原樣載入；原 `main` 從唯一 `records=[]` 到最後 `raise SystemExit(...)` 的所有 AST 節點原樣執行，包含完整 main／fix／fix／main、每塊八筆、兩組各十六筆中位數比較與五個原控制。

原 `main` 前綴的硬編碼 clone 路徑不執行。呼叫端先提供獨立的乾淨 final checkout 及 main `adbaebf9c73ea6801d7b4d5214e4b846b132923b` checkout；main 目錄名稱必須是 `main`，用以保留原 `shared.WORK/'main'` 表達式。工具只綁定原 `OUT`、`WORK`、`ENV`、`SHA` 與 `repo`，先補執行原 main 準備流程的 `npm run build`，再執行原 fix `npm run build`，兩樹皆在任何 timing block 前預建。main 建置的 `GITHUB_SHA`／`GITHUB_WORKSPACE`／`P52_SHA` 綁定 main，`TMPDIR` 仍沿用同一正式環境；原 `one` 之後仍透過原 `start_local.py` 啟動／驗證二進位，不把首次編譯塞入原 90 秒 readiness 預算。

判準仍是原 `medians['fix'] <= medians['main']`。五個控制仍為 `normal`、`delay`、`revert-delay`、`wrong`、`missing`，具名足跡、900ms 注入、5000ms 等待上限、樣本數、順序及原 timeout 不變。不挑樣本、不自動重跑、不覆寫既有 out、不重產 golden、不修改產品／原測試／來源 checkout。

工具以原 c387 recorder 保存建置、版本、runtime probe 及九個 Node 命令的完整 argv、實際退出碼、stdout、stderr、來源 SHA、variant 與實際安全環境欄位。原 `one` 的 server 呼叫本來指定 `stderr=STDOUT`，因此保留原合流 server.log，明列 `stderr_redirected_to_stdout=true`，不把它冒稱兩份分離串流。原 server 另由既有 subreaper 包覆，事件與 stdout hash 一併保存。

原 `receipt.json` 由原 AST 自己寫入，不改 schema；可作新 F runtime 撤回工具所需的正式 baseline。額外 `execution-receipt.json` 保存 binding、原 AST 來源及 hash、來源前後完整 status／index／patch、所有命令原紀錄、wrapper 真退出與錯誤。九個 Node 真退出碼另核為 measure／normal／delay 的 0 與三個具名負控的 1；crash、timeout、結果缺件不能充成有效控制或 timing 紅。這些完整性守門沒有放寬原判準。

固定來源與 main 各自的 before／after 守門，另使用同目錄凍結的 `runtime_inventory.py`：由原 `RuntimeSnapshot` 的 `source_files`／`static_files` 與 Git 全 tracked 候選集合核對輸入完整性，逐檔保存 raw 與 runtime identity hash。每份完整清單寫入 `<label>-runtime-inputs.json`；守門列另存清單 hash、sourceVersion、數量與 identity rows 的 hash，最後逐列核對 before／after 的 identity 與 sourceVersion 相同。因此不能只靠 sparse checkout 的 HEAD 名稱宣稱輸入完整。

退出碼：原正式 body 完整執行時沿用原 `SystemExit` 0／1；正常原斷言失敗保持非零。基礎設施、輸入綁定、原件完整性或回收問題為工具非零，並與 `original_body_system_exit` 分欄，不冒成產品 gate 0。它不設新的總效能門檻；原 readiness 90 秒迴圈、原無 timeout 的 probe 呼叫，以及每個原 Node 1200 秒 timeout 都保留。外層應沿用既有 `execute_f_extra.py`／reaper；不要在外層再持同一把 heavy lock。

本輪已固定且公開 F 的全新短路徑 out CLI；完整各項 argv 也存於 `COMMANDS_FINAL_F.json`：

```bash
python3 -B /workspace/geo261-environment/execute_f_extra.py \
  --label postmerge-p52-formal --sha 13d02c1db7022145a52ee063286a558e595eb212 \
  --repo /tmp/g288f-13d02c1d \
  --outer-root /workspace/geo288-main-merge-20261023/extras-outer -- \
  python3 -B /workspace/geo288-main-merge-20261023/bound-13d02c1d/p52-formal.py \
    --repo /tmp/g288f-13d02c1d --sha 13d02c1db7022145a52ee063286a558e595eb212 \
    --main-repo /workspace/geo288-main-merge-20261023/reference/main \
    --out /tmp/g288pf --heavy-lock /tmp/g261r3/heavy.lock
```

原準備工具預設 protocol 位於 `/workspace/geo261-environment/final-f2-p52-runtime-proof-tools/protocol`；`prepare_bindings.py` 把 bound 工具預設改成同層 `protocol/`。執行時先逐檔核原 hash，再複製到新 out 的 frozen `tools/protocol/`，只從 frozen snapshot 載入。不要將本檔或工具的 AST 檢查成功當成 P52 已通過。
