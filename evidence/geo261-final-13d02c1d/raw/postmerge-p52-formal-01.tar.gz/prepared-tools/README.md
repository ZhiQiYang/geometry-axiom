# #288 合入 main 後的 runtime 受影響項工具

這裡只準備工具，沒有執行測試、建置、瀏覽器或量測。舊 F2 的結果不會改標為新來源。

root 現已固定並公開新 F：`13d02c1db7022145a52ee063286a558e595eb212`，正式 detached 受驗樹是 `/tmp/g288f-13d02c1d`。唯一歷史 main 樹已由 root 準備完成：`/workspace/geo288-main-merge-20261023/reference/main`，原準備退出 0、466 個 runtime 輸入；這只是準備，不是 P52 測量結果。root 尚未執行這裡的物化綁定或額外測試；`COMMANDS_FINAL_F.json` 只列待排程原 argv。

本輪仍使用原 P52 protocol 四檔，bytes／SHA-256 完全不動；`postfix_validate.py` 中舊 `SHAS['final']` 常數沒有參與本次執行的 `one`／正式 main tail，實際 fix 來源由新 `--sha` 與 `P52_SHA` 綁定，執行時再守門。正式判準仍是四區塊 main／fix／fix／main、每區塊八筆、兩邊各十六筆中位數 fix ≤ main，並跑完原五個等待 controls。沒有換門檻、挑樣本、改斷言或自動重抽。

「合入的目前 main」與「原 P52 比較 main」是不同角色：前者由 root merge 紀錄固定；這些量測沿用原協定固定比較 SHA `adbaebf9c73ea6801d7b4d5214e4b846b132923b`。

## 先準備唯一 main 比較樹

這一步已由 root 完成，不必重複。以下只記錄原準備 CLI：它只有 clone／checkout、Git 與 runtime 輸入身分讀取，沒有 build 或 test。source 的 HEAD 必須等於 `--acceptance-sha`，全程乾淨且不移動。

```sh
python3 -B /workspace/geo288-main-merge-20261023/runtime-proof-tools/prepare_main.py \
  --source /workspace/geometry-axiom \
  --acceptance-sha <source執行時乾淨HEAD的完整SHA> \
  --dest /workspace/geo288-main-merge-20261023/reference/main \
  --out /workspace/geo288-main-merge-20261023/main-preparation
```

`main` 目錄名稱必須是 `main`，供原 `one` 的 binding 使用。全部輸出必須全新。舊 `/tmp/g261r3/work/p52-main/main` 已回收，不能當成存在的比較樹。

只讀 Git tree 的容量估算：adba 完整 checkout 948,370,623 bytes，排除 root `evidence/` 與 `tests/evidence/` 後 280,504,594 bytes。只有這兩個目錄可 sparse 排除；它們不在 RuntimeSnapshot 的 source roots，也不是它的靜態路由。`runtime_inventory.py` 會用原 `source_files`／`static_files` 與 Git 全 tracked 候選集合核對沒有遺失來源，再記每個 raw／runtime-identity hash；缺一檔即不繼續。它不是替代效能判官。

## 綁定新 F（只有工具寫檔）

```sh
python3 -B /workspace/geo288-main-merge-20261023/runtime-proof-tools/prepare_bindings.py \
  --sha <新F完整SHA> \
  --out /workspace/geo288-main-merge-20261023/bound-<新Fsha8>
```

產生 `BINDING.json` 與每份原工具對新工具的 `.binding.patch`，包括原／新 bytes、hash 與適配說明。全部 Python 只做 AST 語法核，不 import 或執行產品。以下以 `<bound>` 指這個新目錄，所有 scratch 都要 fresh、短且在 `/tmp`。

## 正式 P52（先跑，供 runtime proof 引用）

```sh
python3 -B <bound>/p52-formal.py \
  --repo <新F detached受驗repo> --sha <新F完整SHA> \
  --main-repo /workspace/geo288-main-merge-20261023/reference/main \
  --out /tmp/g288pf --heavy-lock /tmp/g261r3/heavy.lock
```

原 `receipt.json` 由未改判官 AST 產生；完整執行與守門另在 `execution-receipt.json`。這一項自行持 R3 鎖，外層若使用 `execute_f_extra.py` 不可再持同鎖。細節見 `README-P52-FORMAL.md`。

## P52 runtime 單檔撤回／恢復

```sh
python3 -B <bound>/p52-runtime/run.py \
  --repo <新F detached受驗repo> \
  --scratch /tmp/g288pr --heavy-lock /tmp/g261r3/heavy.lock \
  --baseline-receipt /tmp/g288pf/receipt.json \
  --main-repo /workspace/geo288-main-merge-20261023/reference/main \
  --fix-clone /workspace/geo288-main-merge-20261023/runtime-isolation/fix
```

正式 baseline 必須是同新 F、四 blocks／五 controls 完整綠、原 protocol hashes 一致。正式工具先依原準備步驟在同一正式 TMPDIR 建置 main 與 fix；main 前面完成的 clone/hash 準備不會冒稱已建置。只重用唯一乾淨固定 main；另建立一份 sparse fix 隔離樹。每個 withdraw／restored phase 都用原完整 timing AST 與原 phase.py bytes；withdraw 換回原 `fe863b03…` 的 runtime blob，restored 精確還原新 F 的原 blob。保留 P3 `55b9fb64…` 當年只動一檔的歷史 guard，且執行時確認新 F runtime bytes 仍為同一份修正。若 baseline 或原守門不符就如實失敗，不沿用 F2 數字。

此工具自行持 R3 鎖。新工具沿用歷史 proof schema 名稱與部分 `F2` 變數名稱，真正來源是新綁定的 `sha` 欄；不是把 F2 收據換標。

## P73 controlled callback 三態

```sh
python3 -B <bound>/p73/run.py \
  --repo <新F detached受驗repo> --sha <新F完整SHA> \
  --scratch /tmp/g288p73 --heavy-lock /tmp/g261r3/heavy.lock \
  --clone-dir /workspace/geo288-main-merge-20261023/p73-isolation/checkout
```

只有 clone 路徑／sparse 環境與 F binding 適配，原 `probe.cjs`、原測試 predicate、正常 ASSERT 與單次真 callback 保持原 bytes。fixed／withdrawn／restored 須真 0／1／0；前 predicate true、callback 一次、後 predicate true／false／true、原具名 AssertionError 及例外 0 都保原守門。不能稱為完整 P73 workflow。clone 可放 workspace 節省 `/tmp`，Chrome profile／feedback／native-runtime 仍用短專用 `/tmp`。

## Chromium 154 固定 P73 子集

```sh
flock -n /tmp/g261r3/heavy.lock \
  python3 -B <bound>/legacy/run_p73_subset_chromium154.py \
  --repo <新F detached受驗repo> --sha <新F完整SHA> \
  --scratch /tmp/g288l --label c154-fixed --port 19940 --cdp-port 9580 \
  --expected-exit 0
```

只跑固定版，原 `GEOMETRY_UIUX_FIX_ONLY`／P73 expected count／partial scope／原 golden 不比較保持。這不是完整 canvas、不是正式 Chrome156 job，也不證明舊版原產品曾綠。這個 driver 只有本地 scratch lock，**外層必須如上使用唯一 R3 flock**；它會自行 exec 原 subreaper，不要省去。需要 `/usr/bin/chromium` 真 154 及 Node24，兩者原版本守門不改。

## 封存與時限

每項由 root 的原外錄製器包覆，保存原 caller stdout／stderr／exit 與前後 F guard。各工具保原 Node、server、probe、build、reaper 命令與完整原串流，安全環境欄位及 SHA/hash；不 dump 憑證。Node 真 crash／timeout 不能冒成正常負控斷言紅。P52 原 phase infra watchdog 1800／outer2400 秒只防環境卡死，不是新產品門檻；正式協定的等待及 Node 時限保持原值。

workspace 的 reference main、兩個隔離 clone 都是可重建來源，不能當原始輸出刪掉；若之後容量需回收，先由 root 依公開／逐 hash 守門另作維護。這些準備工具不自行清理任何既有來源或證據。
