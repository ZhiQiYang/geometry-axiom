"""Materialize a pinned new-SHA tool binding; never run product/test/build code."""
from __future__ import annotations

import argparse
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil

OLD_F = '8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
ENV_ROOT = Path('/workspace/geo261-environment')
HERE = Path(__file__).resolve().parent
ORIGINAL_P73 = ENV_ROOT / 'final-f2-p73-controlled-tools'
ORIGINAL_P52 = ENV_ROOT / 'final-f2-p52-runtime-proof-tools'
ORIGINAL_LEGACY = ENV_ROOT / 'F2-legacy-browser-preparation'
PROTOCOL_HASHES = {
    'postfix_validate.py': 'b9fbcca0eb12e2e25fb5d84eda01038bf8406d1c3a533fa5dfd842e330cf8c5f',
    'p52_measure.py': '738a36b0417e7f5cfa1dcf57fc0d14664650b8285484f866b8ceb0d3a2c8f1a4',
    'p52_probe.cjs': '8c3b4b14ad35082679e4faf229bd66d65a500bd53669c13d8f41e0603e066970',
    'p52_cases.cjs': '6ca75996223e94be0a503e646d58ed928b046854eb0102af309482dc4ac60f66',
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def change_once(text, before, after):
    if text.count(before) != 1:
        raise RuntimeError('原綁定錨點必須唯一：' + repr(before))
    return text.replace(before, after, 1)


def p73_source(sha):
    text = (ORIGINAL_P73 / 'run.py').read_text()
    text = change_once(text, "F='" + OLD_F + "'", "F='" + sha + "'")
    text = change_once(text, 'import capture\n', 'import capture\nfrom runtime_inventory import complete_runtime_inventory, same_runtime_identity\n')
    text = change_once(text, " p.add_argument('--sha',required=True);p.add_argument('--heavy-lock',required=True,type=Path)\n",
                       " p.add_argument('--sha',required=True);p.add_argument('--heavy-lock',required=True,type=Path)\n p.add_argument('--clone-dir',type=Path)\n")
    text = change_once(text, " for path in [base/'run.py',base/'probe.cjs',base/'capture.py',a.reaper]:",
                       " for path in [base/'run.py',base/'probe.cjs',base/'capture.py',base/'runtime_inventory.py',a.reaper]:")
    text = change_once(text, " recorder=capture.Recorder(out,env,F);clone=out/'checkout';fixed=None\n",
                       " recorder=capture.Recorder(out,env,F);clone=a.clone_dir.resolve() if a.clone_dir else out/'checkout';fixed=None\n need(not clone.exists() and not clone.is_relative_to(repo) and not repo.is_relative_to(clone),'隔離clone必須全新且在來源外')\n need(clone.is_relative_to(Path('/workspace')) or clone.is_relative_to(Path('/tmp')),'隔離clone只用workspace/tmp')\n")
    text = change_once(text, "  guard(repo,'original-before');original.update({rel:h((repo/rel).read_bytes()) for rel in INPUTS})\n",
                       "  guard(repo,'original-before');original.update({rel:h((repo/rel).read_bytes()) for rel in INPUTS})\n  source_runtime=complete_runtime_inventory(repo,F,lambda *v:git(repo,*v));save(out/'source-runtime-inputs.json',source_runtime)\n")
    text = change_once(text, "  git(clone,'checkout','--detach',F);guard(clone,'clone-created')\n",
                       "  git(clone,'sparse-checkout','init','--no-cone')\n  git(clone,'sparse-checkout','set','--no-cone','/*','!/evidence/','!/tests/evidence/')\n  git(clone,'checkout','--detach',F);guard(clone,'clone-created')\n  clone_runtime=complete_runtime_inventory(clone,F,lambda *v:git(clone,*v));save(out/'clone-runtime-inputs.json',clone_runtime)\n  need(same_runtime_identity(source_runtime,clone_runtime),'稀疏clone不得遺失或改變任一RuntimeSnapshot輸入')\n")
    text = change_once(text, "  cmd(['git','clone','--shared','--no-hardlinks','--no-checkout',repo,clone],out)\n",
                       "  clone.parent.mkdir(parents=True,exist_ok=True)\n  cmd(['git','clone','--shared','--no-hardlinks','--no-checkout',repo,clone],out)\n")
    text = change_once(text, "  try:guard(repo,'original-after')\n",
                       "  try:\n   guard(repo,'original-after')\n   final_runtime=complete_runtime_inventory(repo,F,lambda *v:git(repo,*v));save(out/'source-after-runtime-inputs.json',final_runtime)\n   need(same_runtime_identity(source_runtime,final_runtime),'來源RuntimeSnapshot輸入在執行中改變')\n")
    return text


def p52_source(sha):
    text = (ORIGINAL_P52 / 'run.py').read_text()
    text = change_once(text, "F2='" + OLD_F + "'", "F2='" + sha + "'")
    text = change_once(text, 'import capture\n', 'import capture\nfrom runtime_inventory import complete_runtime_inventory, same_runtime_identity\n')
    text = change_once(text, " parser.add_argument('--protocol-dir',type=Path,default=Path('/tmp/g261r3/tools'))\n",
                       " parser.add_argument('--protocol-dir',type=Path,default=Path(__file__).resolve().parent/'protocol')\n parser.add_argument('--main-repo',type=Path,required=True)\n parser.add_argument('--fix-clone',type=Path)\n")
    text = change_once(text, " for path in [base/'run.py',base/'phase.py',base/'capture.py',a.reaper,*[base/'protocol'/n for n in PROTOCOL]]:",
                       " for path in [base/'run.py',base/'phase.py',base/'capture.py',base/'runtime_inventory.py',a.reaper,*[base/'protocol'/n for n in PROTOCOL]]:")
    text = change_once(text, " fix=out/'fix';mainrepo=out/'main';fixed=None;phases=[];errors=[];guards=[]\n",
                       " fix=a.fix_clone.resolve() if a.fix_clone else out/'fix';mainrepo=a.main_repo.resolve();fixed=None;phases=[];errors=[];guards=[]\n need(mainrepo.is_dir() and not fix.exists(),'main必須已預備，fix clone必須全新')\n need(fix.is_relative_to(Path('/workspace')) or fix.is_relative_to(Path('/tmp')),'隔離clone只用workspace/tmp')\n need(not fix.is_relative_to(repo) and not repo.is_relative_to(fix) and not fix.is_relative_to(mainrepo) and not mainrepo.is_relative_to(fix),'clone與兩來源不可互相包含')\n")
    text = change_once(text, "  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);guard(repo,'source-before',F2)\n",
                       "  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);guard(repo,'source-before',F2)\n  source_runtime=complete_runtime_inventory(repo,F2,lambda *v:git(repo,*v));save(out/'source-runtime-inputs.json',source_runtime)\n")
    text = change_once(text, "  for name,sha,path in (('fix',F2,fix),('main',MAIN,mainrepo)):\n",
                       "  fix.parent.mkdir(parents=True,exist_ok=True)\n  for name,sha,path in (('fix',F2,fix),):\n")
    text = change_once(text, "   git(path,'-c','core.autocrlf=false','checkout','--detach',sha);guard(path,name+'-created',sha)\n",
                       "   git(path,'sparse-checkout','init','--no-cone')\n   git(path,'sparse-checkout','set','--no-cone','/*','!/evidence/','!/tests/evidence/')\n   git(path,'-c','core.autocrlf=false','checkout','--detach',sha);guard(path,name+'-created',sha)\n  guard(mainrepo,'main-created',MAIN)\n  clone_runtime=complete_runtime_inventory(fix,F2,lambda *v:git(fix,*v));save(out/'clone-runtime-inputs.json',clone_runtime)\n  main_runtime=complete_runtime_inventory(mainrepo,MAIN,lambda *v:git(mainrepo,*v));save(out/'main-runtime-inputs.json',main_runtime)\n  need(same_runtime_identity(source_runtime,clone_runtime),'稀疏fix clone不得遺失或改變任一RuntimeSnapshot輸入')\n")
    text = change_once(text, "  try:guard(repo,'source-after',F2)\n",
                       "  try:\n   guard(repo,'source-after',F2)\n   final_runtime=complete_runtime_inventory(repo,F2,lambda *v:git(repo,*v));save(out/'source-after-runtime-inputs.json',final_runtime)\n   need(same_runtime_identity(source_runtime,final_runtime),'來源RuntimeSnapshot輸入在執行中改變')\n   main_after=complete_runtime_inventory(mainrepo,MAIN,lambda *v:git(mainrepo,*v));save(out/'main-after-runtime-inputs.json',main_after)\n   need(same_runtime_identity(main_runtime,main_after),'固定main輸入在執行中改變')\n")
    return text


def legacy_source():
    text = (ORIGINAL_LEGACY / 'run_p73_subset_chromium154.py').read_text()
    text = change_once(text, 'import run_workflow as workflow_tools\n',
                       'import run_workflow as workflow_tools\nfrom runtime_inventory import complete_runtime_inventory\n')
    text = change_once(text, "        'head': git(repo, 'rev-parse', 'HEAD').decode().strip(),\n",
                       "        'head': git(repo, 'rev-parse', 'HEAD').decode().strip(),\n        'runtime_complete_inputs': complete_runtime_inventory(repo, git(repo, 'rev-parse', 'HEAD').decode().strip(), lambda *v: git(repo, *v)),\n")
    text = change_once(text, "固定F2原P73完整子集", "固定受驗SHA原P73完整子集")
    text = change_once(text, "        'reaper_driver_sha256': workflow_tools.sha256(REAPER.read_bytes()),\n",
                       "        'reaper_driver_sha256': workflow_tools.sha256(REAPER.read_bytes()),\n        'runtime_inventory_driver_sha256': workflow_tools.sha256((Path(__file__).resolve().parent / 'runtime_inventory.py').read_bytes()),\n")
    text = change_once(text, "                       ('reaper.py.txt', REAPER)]:\n",
                       "                       ('reaper.py.txt', REAPER), ('runtime-inventory.py.txt', Path(__file__).resolve().parent / 'runtime_inventory.py')]:\n")
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    a = parser.parse_args()
    if re.fullmatch('[0-9a-f]{40}', a.sha) is None or a.sha == OLD_F:
        parser.error('必須提供新受驗來源的完整 SHA，不能重標舊F2')
    out = a.out.resolve()
    if out.exists():
        parser.error('工具綁定輸出必須全新，不覆寫歷史工具')
    out.mkdir(parents=True)
    records = []

    def put(relative, body, original=None, adaptation=None):
        target = out / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        if target.suffix == '.py':
            ast.parse(body.decode('utf-8'))
        row = {'path': relative, 'bytes': len(body), 'sha256': digest(body), 'original': str(original) if original else None}
        if original:
            raw = original.read_bytes()
            row['original_sha256'] = digest(raw)
            row['unchanged'] = raw == body
            if raw != body:
                patch = target.with_suffix(target.suffix + '.binding.patch')
                patch.write_text(''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), body.decode().splitlines(keepends=True),
                                                          fromfile=str(original), tofile=str(target))))
                row['binding_diff'] = patch.relative_to(out).as_posix()
        row['adaptation'] = adaptation
        records.append(row)

    for directory in ('p73', 'p52-runtime', 'legacy'):
        put(directory + '/runtime_inventory.py', (HERE / 'runtime_inventory.py').read_bytes(), HERE / 'runtime_inventory.py')
    put('p73/run.py', p73_source(a.sha).encode(), ORIGINAL_P73 / 'run.py', 'pin new SHA; sparse isolation only; original app predicate/probe and phase assertions unchanged; add read-only complete runtime input checks')
    for name in ('probe.cjs', 'capture.py'):
        put('p73/' + name, (ORIGINAL_P73 / name).read_bytes(), ORIGINAL_P73 / name)
    put('p52-runtime/run.py', p52_source(a.sha).encode(), ORIGINAL_P52 / 'run.py', 'pin new SHA; reuse fixed main; sparse fix clone only; original phase.py/protocol/threshold/counts/controls unchanged; add read-only complete runtime input checks')
    for name in ('phase.py', 'capture.py'):
        put('p52-runtime/' + name, (ORIGINAL_P52 / name).read_bytes(), ORIGINAL_P52 / name)
    for name, expected in PROTOCOL_HASHES.items():
        source = ORIGINAL_P52 / 'protocol' / name
        raw = source.read_bytes()
        if digest(raw) != expected:
            raise RuntimeError('原protocol bytes變動：' + name)
        put('p52-runtime/protocol/' + name, raw, source)
        put('protocol/' + name, raw, source)
    put('legacy/run_p73_subset_chromium154.py', legacy_source().encode(), ORIGINAL_LEGACY / 'run_p73_subset_chromium154.py', 'only current-SHA scope wording, read-only runtime complete input identity; original workflow/Chrome154/P73/golden checks unchanged')
    for name in ('run_workflow.py', 'reap_children.py'):
        put('legacy/' + name, (ORIGINAL_LEGACY / name).read_bytes(), ORIGINAL_LEGACY / name)
    for name in ('p52-formal.py', 'runtime_inventory.py', 'prepare_main.py'):
        source = HERE / name
        body = source.read_text()
        if name == 'p52-formal.py':
            body = change_once(body,
                "default=Path('/workspace/geo261-environment/final-f2-p52-runtime-proof-tools/protocol'))",
                "default=Path(__file__).resolve().parent / 'protocol')")
        put(name, body.encode(), source, 'relative frozen protocol binding only' if name == 'p52-formal.py' else None)
    record = {'schema': 'geo288-main-merge-runtime-tool-binding/1', 'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'sha': a.sha, 'old_reference_sha': OLD_F, 'tools_only': True,
              'product_or_test_executed': False, 'build_or_benchmark_executed': False,
              'original_protocol_four_files_unchanged': PROTOCOL_HASHES,
              'historical_schema_names': 'F2 tokens retained in original proof schema/variable names are historical schema names; every actual sha value is newly pinned and guarded.',
              'sparse_policy': 'exclude only evidence/ and tests/evidence/ outside actual RuntimeSnapshot roots; compare complete runtime input set and every identity hash against fixed source',
              'files': records}
    (out / 'BINDING.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'sha': a.sha, 'out': str(out), 'files': len(records), 'product_or_test_executed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
