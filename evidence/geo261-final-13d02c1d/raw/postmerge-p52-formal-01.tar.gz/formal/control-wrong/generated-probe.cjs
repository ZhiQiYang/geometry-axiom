/* CDP 驅動 headless Chrome 實測物件畫布互動 */
const { spawn } = require("child_process");
const fs = require('fs'), path = require('path'), os = require('os');
const net = require('net');
const floor = require('./cdp_floor.js');
const cdp = require('./cdp_helpers.js');
const {createRetainedEvaluator} = require('./cdp_evaluation.js');
const {waitForExpectedNavigation} = require('./cdp_navigation.js');
const {createTransportFailureTrace,installClientTransportTrace} = require('./transport_failure_trace.js');
let transportFailureTrace;
const SCOPE_FLAGS = ['GEOMETRY_ROOM_OUTLINE_ONLY','GEOMETRY_TIMBER_SCHEDULE_ONLY','GEOMETRY_ASSEMBLY_ONLY','GEOMETRY_PARAMETERS_ONLY','GEOMETRY_SELECTION_CURSOR_ONLY','GEOMETRY_UX_REFINEMENT_ONLY','GEOMETRY_UIUX_FIX_ONLY','GEOMETRY_MARQUEE_ONLY','GEOMETRY_PROJECT_AUDIT_ONLY','GEOMETRY_ENGINEERING_WORKFLOW_ONLY','GEOMETRY_GRID_SYSTEM_ONLY','GEOMETRY_INFINITE_FACE_ONLY','GEOMETRY_COMPOSITION_ONLY','GEOMETRY_UI_REVIEW_ONLY','GEOMETRY_REPAIR_ONLY','GEOMETRY_FLOW_REPAIR_ONLY','GEOMETRY_REFERENCE_ONLY','GEOMETRY_CDP_FROM_P31'];
const ENGINEERING_MODIFIERS=['GEOMETRY_ENGINEERING_EXAMPLE_ONLY','GEOMETRY_ENGINEERING_NAVIGATION_ONLY','GEOMETRY_ENGINEERING_SUBGRID_ONLY'];
function runConfiguration(env = process.env) {
  if (!env.GEOMETRY_TEST_URL) throw Error('GEOMETRY_TEST_URL is required: use an explicitly isolated test service. No browser or reset was started.');
  const url = new URL(env.GEOMETRY_TEST_URL);
  if (!['http:','https:'].includes(url.protocol)) throw Error('GEOMETRY_TEST_URL must be an HTTP(S) test service');
  if(env.GEOMETRY_CDP_PORT && (!/^\d+$/.test(env.GEOMETRY_CDP_PORT) || Number(env.GEOMETRY_CDP_PORT)<1 || Number(env.GEOMETRY_CDP_PORT)>65535))throw Error('GEOMETRY_CDP_PORT must be an integer from 1 to 65535');
  if (!env.GEOMETRY_FEEDBACK_DIR || !path.isAbsolute(env.GEOMETRY_FEEDBACK_DIR)) throw Error('GEOMETRY_FEEDBACK_DIR must name the isolated server feedback directory under TEMP');
  const relative = path.relative(os.tmpdir(),path.resolve(env.GEOMETRY_FEEDBACK_DIR));
  if (!relative || relative==='..' || relative.startsWith('..'+path.sep) || path.isAbsolute(relative)) throw Error('GEOMETRY_FEEDBACK_DIR must be a dedicated directory under TEMP');
  const filters=SCOPE_FLAGS.filter(name=>env[name]);
  const modifiers=ENGINEERING_MODIFIERS.filter(name=>env[name]);
  if([...filters,...modifiers].some(name=>env[name]!=='1'))throw Error('Scope flags accept only 1; remove a flag to disable it');
  if(filters.length>1)throw Error('Choose only one CDP scope flag; combined filters can silently omit every suite');
  if(modifiers.length>1)throw Error('Choose only one engineering workflow modifier');
  if(modifiers.length && env.GEOMETRY_ENGINEERING_WORKFLOW_ONLY!=='1')throw Error('Engineering modifiers require GEOMETRY_ENGINEERING_WORKFLOW_ONLY=1');
  return {mode:filters.length?'partial':'full',filters,modifiers,url:url.href,feedbackDirectory:path.resolve(env.GEOMETRY_FEEDBACK_DIR)};
}
// Legacy checks log a verdict as a separate argument. Never scan arbitrary
// diagnostics or page console strings for checkmark characters.
const EXPLICIT_VERDICT=Symbol('explicit-test-verdict');
function explicitVerdict(text) {
  if(typeof text!=='string' || !/[✓✗]/.test(text))throw Error('Explicit test verdict must contain a success/failure marker');
  return {[EXPLICIT_VERDICT]:text.includes('✗')?false:true,text};
}
/* 本體各段的 check 共用 cdp_helpers.makeCheck:只把判定值換成 explicitVerdict,讓 harness 只計受控斷言。
   通過判定一律 value===true;選項見 cdp_helpers.js。 */
const bodyCheck=(options={})=>cdp.makeCheck({...options,mark:ok=>explicitVerdict(ok?'✓':'✗')});
function assertionVerdicts(args) {
  if(typeof args[0]==='string' && /^\[(?:console|EXCEPTION)\]/.test(args[0]))return [];
  return args.flatMap(value=>value && typeof value==='object' && EXPLICIT_VERDICT in value?[value[EXPLICIT_VERDICT]]:value==='✓'?[true]:value==='✗'?[false]:[]);
}
function evaluationValue(message, expression) {
  if(message.error)throw Error('CDP Runtime.evaluate failed: '+JSON.stringify(message.error));
  if(!message.result?.result)throw Error('CDP Runtime.evaluate returned no result');
  const error=message.result.exceptionDetails;
  if(error)throw Error('Browser evaluation failed: '+(error.exception?.description || error.text || JSON.stringify(error))+'; expression='+expression.slice(0,180));
  return message.result.result.value;
}
/* 預設為 Windows 的 Chrome；下列環境變數可覆寫，用於在 WSL/Linux 內整條跑：
     GEOMETRY_CHROME         chrome 執行檔路徑（Linux 下通常是 google-chrome）
     GEOMETRY_CHROME_PROFILE --user-data-dir 的位置
     GEOMETRY_CHROME_FLAGS   追加旗標，空白分隔（在 WSL 內以 root 跑需要 --no-sandbox）
     GEOMETRY_TEST_SERVER_PATH_STYLE=wsl  Windows harness 對 WSL 服務傳送 /mnt/<drive>/ 路徑
   不設時行為與先前完全相同。 */
const CHROME = process.env.GEOMETRY_CHROME || "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const PROFILE = process.env.GEOMETRY_CHROME_PROFILE || null;
const EXTRA_FLAGS = (process.env.GEOMETRY_CHROME_FLAGS || "").split(" ").filter(Boolean);
const PORT = +(process.env.GEOMETRY_CDP_PORT || 9333);
function serverFixturePath(localPath) {
  const style=process.env.GEOMETRY_TEST_SERVER_PATH_STYLE || 'native';
  if(style==='native')return localPath;
  if(style==='wsl'&&/^[A-Za-z]:[\\/]/.test(localPath))return '/mnt/'+localPath[0].toLowerCase()+'/'+localPath.slice(3).replace(/\\/g,'/');
  throw Error('Unsupported test server path style or fixture path: '+style+' '+localPath);
}

let chrome, browserEndpoint=null, browserStartupOutput='';
async function assertPortAvailable(port,network=net) {
  await new Promise((resolve,reject)=>{
    const probe=network.createServer();
    probe.once('error',error=>reject(Error('CDP port '+port+' is unavailable; refusing to attach to another browser: '+error.message)));
    probe.listen({host:'127.0.0.1',port,exclusive:true},()=>probe.close(error=>error?reject(error):resolve()));
  });
}
function verifyBrowserOwnership(version,endpoint,port) {
  const actual=new URL(version.webSocketDebuggerUrl),expected=new URL(endpoint);
  if(!['127.0.0.1','localhost','[::1]'].includes(actual.hostname) || actual.protocol!=='ws:' || Number(actual.port)!==port || Number(expected.port)!==port || !/^\/devtools\/browser\/[a-zA-Z0-9-]+$/.test(expected.pathname) || actual.pathname!==expected.pathname){
    const error=Error('CDP browser ownership mismatch: endpoint does not belong to the Chrome process started by this test');error.code='BROWSER_OWNERSHIP';throw error;
  }
}
function startBrowser() {
  const profile=PROFILE || fs.mkdtempSync(path.join(os.tmpdir(),'geometry-cdp-'));
  scope.browserProfile=path.resolve(profile);scope.cdpPort=PORT;
  const child=spawn(CHROME, [
  "--headless=new", "--disable-gpu", "--no-first-run", `--remote-debugging-port=${PORT}`,
  "--window-size=1400,900", `--user-data-dir=${profile}`, ...EXTRA_FLAGS, "about:blank"
  ]);
  child.stderr.on('data',chunk=>{
    _log('CHROME_STARTUP_STDERR '+JSON.stringify({utc:new Date().toISOString(),monotonicNs:process.hrtime.bigint().toString(),pid:child.pid,text:chunk.toString()}));
    browserStartupOutput=(browserStartupOutput+chunk.toString()).slice(-8192);
    const match=browserStartupOutput.match(/DevTools listening on (ws:\/\/\S+)/);
    if(match)browserEndpoint=match[1];
  });
  scope.browserPid=child.pid;
  return child;
}

const delay = ms => new Promise(r => setTimeout(r, ms));
const sleep = async ms => {
  await delay(ms);
  if(ms>=200 && ws?.readyState===1)
    await eval_('window.__cdpSettleUI?.(0)');
};
let ws, mid = 0, pending = {};

/* ✓/✗ 計數：所有印出的判定一律計入，exit code 依此決定。 */
let passN = 0, failN = 0;
let excN = 0;            /* Runtime.exceptionThrown 計數(BF2 驗收用) */
let currentTestStep='connecting to isolated test browser';
/* 每段斷言數(cdp_floor.js 的 sectionOf 由 `=== ` 標頭取主編號);CDP_RESULT.sections 與 golden 比對都用它。 */
let currentSection=floor.NO_SECTION;
const sectionPass={}, sectionFail={};
let expectedBeforeUnloadUntil=0;
let expectedNativeDialog=null;
let expectedException=null, scope, skipped=[];
const assetRequests=new Map(), assetFailures=[];
const _log = console.log;
function observeAssetNetwork(message) {
  if (!transportFailureTrace) transportFailureTrace = createTransportFailureTrace(new URL(scope.url).origin);
  transportFailureTrace.observe(message, currentTestStep);
  const p=message.params,key=(message.sessionId||'main')+':'+p.requestId;
  if(message.method==='Network.requestWillBeSent'){
    let url;try {url=new URL(p.request.url);}catch{return;}
    if(url.origin!==new URL(scope.url).origin || (!['Script','Stylesheet'].includes(p.type)&&! /\.(?:js|css)$/i.test(url.pathname)))return;
    assetRequests.set(key,{url:url.href,type:p.type,requestId:p.requestId,sessionId:message.sessionId||null,step:currentTestStep,requestedAt:new Date().toISOString()});
    return;
  }
  const request=assetRequests.get(key);if(!request)return;
  let failure=null;
  if(message.method==='Network.responseReceived'&&p.response.status>=400)
    failure={...request,event:message.method,status:p.response.status,errorText:p.response.statusText,type:p.type||request.type};
  else if(message.method==='Network.loadingFailed')
    failure={...request,event:message.method,errorText:p.errorText,type:p.type||request.type,canceled:!!p.canceled,blockedReason:p.blockedReason||null};
  if(failure){assetFailures.push(failure);if(assetFailures.length>60)assetFailures.shift();_log('[NETWORK ASSET FAILURE]',JSON.stringify(failure));}
  if(message.method==='Network.loadingFinished'||message.method==='Network.loadingFailed')assetRequests.delete(key);
}
function recordLog(...args) {
  const s = args.join(" ");
  if(s.startsWith('===')){
    currentTestStep=s;
    currentSection=floor.sectionOf(s)||currentSection;
    sectionPass[currentSection]=sectionPass[currentSection]||0;
  }
  for(const passed of assertionVerdicts(args)){
    if(passed){passN++;sectionPass[currentSection]=(sectionPass[currentSection]||0)+1;}
    else{failN++;sectionFail[currentSection]=(sectionFail[currentSection]||0)+1;}
  }
  _log(...args.map(value=>value && typeof value==='object' && EXPLICIT_VERDICT in value?value.text:value));
}

async function connect() {
  // A fresh isolated Chrome profile can need longer than ten seconds on Windows.
  for (let i = 0; i < 120; ++i) {
    if(chrome.exitCode!==null)throw Error('Test Chrome exited before CDP ownership was established: '+browserStartupOutput);
    if(!browserEndpoint){await delay(250);continue;}
    try {
      const version=await fetch(`http://127.0.0.1:${PORT}/json/version`,{signal:AbortSignal.timeout(3000)}).then(r=>r.json());
      verifyBrowserOwnership(version,browserEndpoint,PORT);
      const list = await fetch(`http://127.0.0.1:${PORT}/json`,{signal:AbortSignal.timeout(3000)}).then(r => r.json());
      const page = list.find(t => t.type === "page" && t.url==='about:blank') || list.find(t => t.type === "page");
      if (page) {
        ws = new WebSocket(page.webSocketDebuggerUrl);
        await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
        ws.onmessage = ev => {
          const m = JSON.parse(ev.data);
          if (m.id && pending[m.id]) { pending[m.id](m); delete pending[m.id]; }
          else if (['Network.requestWillBeSent','Network.responseReceived','Network.loadingFailed','Network.loadingFinished'].includes(m.method))observeAssetNetwork(m);
          else if (m.method === 'Runtime.bindingCalled' && m.params.name === '__geometryCdpTransportFailure') {
            try {
              if (!transportFailureTrace) transportFailureTrace = createTransportFailureTrace(new URL(scope.url).origin);
              transportFailureTrace.observeApiFailure({...JSON.parse(m.params.payload),sessionId:m.sessionId||null,step:currentTestStep});
              _log('[API TRANSPORT FAILURE]',JSON.stringify(transportFailureTrace.apiFirst()));
            } catch(error) {_log('[TRANSPORT DIAGNOSTIC ERROR]',error.message);}
          }
          else if (m.method === "Runtime.consoleAPICalled")
            console.log("[console]", m.params.args.map(a => a.value ?? a.description).join(" "));
          else if (m.method === "Runtime.exceptionThrown") {
            excN++;
            const description=m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text || '';
            const expected=expectedException && Date.now()<expectedException.until && description.split('\n')[0]===expectedException.message;
            if(expected){expectedException=null;_log('[EXPECTED EXCEPTION]',description);}
            else {failN++;_log('[UNEXPECTED EXCEPTION]',currentTestStep,description);}
          }
          else if (m.method === 'Page.javascriptDialogOpening' && expectedNativeDialog && m.params.type===expectedNativeDialog.type && m.params.message===expectedNativeDialog.message) {
            const expectation=expectedNativeDialog;expectedNativeDialog=null;expectation.seen=true;
            _log('[EXPECTED NATIVE DIALOG]',m.params.message,'accept='+expectation.accept);
            send('Page.handleJavaScriptDialog',{accept:expectation.accept},m.sessionId);
          }
          else if (m.method === 'Page.javascriptDialogOpening' && m.params.type==='confirm' &&
              /目前專案有尚未保存的變更|只能在本次工作階段修改數字的形狀特徵/.test(m.params.message)) {
            // This isolated acceptance run is authorized to leave its own test project.
            console.log('[TEST PROJECT DIALOG]',m.params.message);
            send('Page.handleJavaScriptDialog',{accept:true},m.sessionId);
          }
          else if (m.method==='Page.javascriptDialogOpening' && m.params.type==='beforeunload' && Date.now()<expectedBeforeUnloadUntil) {
            expectedBeforeUnloadUntil=0;
            console.log('[TEST PAGE LEAVE]',currentTestStep,m.params.message);
            send('Page.handleJavaScriptDialog',{accept:true},m.sessionId);
          }
          else if (m.method==='Page.javascriptDialogOpening') {
            const message='Unexpected native dialog at '+currentTestStep+': '+m.params.type+' '+m.params.message;
            console.log(explicitVerdict('✗ '+message),JSON.stringify(m.params));
            // Reject the unexpected action and terminate this run. Leaving a
            // native modal open would hang Runtime.evaluate indefinitely.
            send('Page.handleJavaScriptDialog',{accept:false},m.sessionId).then(()=>fatal(Error(message))).catch(fatal);
          }
          else if (m.method==='Inspector.targetCrashed')console.log(explicitVerdict('✗ Browser target crashed at '+currentTestStep));
        };
        return;
      }
    } catch(error) {if(error.code==='BROWSER_OWNERSHIP')throw error;}
    await sleep(250);
  }
  throw new Error("no CDP; Chrome startup output: " + browserStartupOutput);
}
function send(method, params = {}, sessionId = null) {
  const navigation=method==='Page.reload'||method==='Page.navigate';
  if(navigation)expectedBeforeUnloadUntil=Date.now()+15000;
  return new Promise((res,rej) => {
    const id=++mid,timer=setTimeout(()=>{delete pending[id];rej(Error('CDP timed out: '+method+' at '+currentTestStep+(params.expression?' expression='+params.expression.slice(0,160):'')));},120000);
    pending[id]=message=>{clearTimeout(timer);if(navigation)_log('CDP_NAVIGATION '+JSON.stringify({phase:'reply',utc:new Date().toISOString(),monotonicNs:process.hrtime.bigint().toString(),id,method,message}));if(message.error)rej(Error('CDP '+method+' failed: '+JSON.stringify(message.error)));else res(message);};
    if(navigation)_log('CDP_NAVIGATION '+JSON.stringify({phase:'send',utc:new Date().toISOString(),monotonicNs:process.hrtime.bigint().toString(),id,method,params,sessionId}));
    ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));
  });
}
const eval_ = createRetainedEvaluator(send, evaluationValue);
async function waitForUI(expr, timeout=5000) {
  const end=Date.now()+timeout;
  while(Date.now()<end){if(await eval_(expr)===true)return;await sleep(50);}
  throw Error('UI condition timed out at '+currentTestStep+': '+expr);
}
async function expectNativeDialog(action,{message,accept,type='confirm'}) {
  if(expectedNativeDialog)throw Error('A native dialog expectation is already pending');
  const expected={message,accept,type,seen:false};expectedNativeDialog=expected;
  try {await action();if(!expected.seen)throw Error('Expected native dialog did not appear: '+message);}
  finally {if(expectedNativeDialog===expected)expectedNativeDialog=null;}
}
// Observe actual, newly appended DOM toasts during one action. Never read an
// earlier toast or replace toast()/its timers; retain evidence after expiry.
async function captureNewToasts(action, visibleState = 'null') {
  await eval_(`(()=>{
    if(window.__cdpActionToastProbe)throw Error('A toast observation is already active');
    const region=document.getElementById('toastRegion');if(!region)throw Error('Missing toastRegion');
    const seen=new WeakSet(region.querySelectorAll('.toast'));
    const probe=window.__cdpActionToastProbe={rows:[],frames:new Set(),active:true};
    probe.collect=records=>{for(const record of records)for(const node of record.addedNodes){
      if(node.nodeType!==1||!node.matches('.toast')||seen.has(node))continue;seen.add(node);
      const row={text:node.textContent,classes:[...node.classList],visible:false};probe.rows.push(row);
      const sample=()=>{const s=getComputedStyle(node),r=node.getBoundingClientRect();
        row.visible=row.visible||(node.isConnected&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>0&&r.width>0&&r.height>0&&r.right>0&&r.bottom>0&&r.left<innerWidth&&r.top<innerHeight);
        if(row.visible&&!row.bounds){row.bounds={left:r.left,top:r.top,right:r.right,bottom:r.bottom};row.state=(${visibleState});}
        if(!row.visible&&node.isConnected&&probe.active){const id=requestAnimationFrame(()=>{probe.frames.delete(id);sample()});probe.frames.add(id);}};
      const id=requestAnimationFrame(()=>{probe.frames.delete(id);sample()});probe.frames.add(id);
    }};
    probe.observer=new MutationObserver(probe.collect);probe.observer.observe(region,{childList:true});return true;
  })()`);
  let observed;
  try {
    await action();
    // Synchronous actions also get a real paint opportunity. The bounded wait
    // only observes this probe's pending samples; it cannot invent a toast.
    await eval_(`(async()=>{const p=window.__cdpActionToastProbe;p.collect(p.observer.takeRecords());
      if(p.frames.size)await new Promise(resolve=>{let done=false,waitFrame=null;const finish=()=>{if(done)return;done=true;clearTimeout(timer);if(waitFrame!==null)cancelAnimationFrame(waitFrame);resolve()};
        const timer=setTimeout(finish,1000);const tick=()=>{waitFrame=null;if(done)return;if(!p.active||!p.frames.size)finish();else waitFrame=requestAnimationFrame(tick)};waitFrame=requestAnimationFrame(tick);});return true;})()`);
  }
  finally {
    observed=await eval_(`(()=>{const p=window.__cdpActionToastProbe;if(!p)throw Error('Toast observation was lost');
      p.collect(p.observer.takeRecords());p.observer.disconnect();p.active=false;for(const id of p.frames)cancelAnimationFrame(id);
      delete window.__cdpActionToastProbe;return p.rows;})()`);
  }
  return observed;
}
const toastText=(rows,type)=>rows.filter(t=>t.visible&&t.classes.includes(type)).map(t=>t.text).join(' | ');
async function click(x, y) {
  for (const [type, btn] of [["mousePressed", "left"], ["mouseReleased", "left"]])
    await send("Input.dispatchMouseEvent", { type, x, y, button: btn, clickCount: 1 });
}
// Persistent entries and relocated creation commands are exercised through the
// same visible menu a user opens, never by clicking a hidden DOM button.
async function clickControl(selector) {
  const menu=await eval_(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});return e?.closest('#exampleMenuPop')?.hidden?'examples':e?.closest('#fileMenuPop')?.hidden?'file':e?.closest('#createObjectPop')?.hidden?'create':e?.closest('#filterDisclosure')&&!e.matches('summary')&&!e.closest('#filterDisclosure').open?'filter':null;})()`);
  if(menu==='create'){
    const trigger=await eval_(`(()=>{const visible=['mobileCreateObject','btnCreateObject'].filter(id=>{const e=document.getElementById(id),r=e?.getBoundingClientRect();return r&&r.width>0&&r.height>0;});if(visible.length!==1)throw Error('Expected one visible create-object opener: '+visible.join(','));return '#'+visible[0];})()`);
    await clickControl(trigger);
  }else if(menu==='examples')await clickControl('#exampleMenuBtn');
  else if(menu==='file')await clickControl('#fileMenuBtn');
  else if(menu==='filter')await clickControl('#filterDisclosure > summary');
  await eval_(`document.querySelector(${JSON.stringify(selector)})?.scrollIntoView({block:'nearest',inline:'nearest'});void 0`);
  let p;
  for(let n=0;n<12;n++){
    await sleep(70);
    p=await eval_(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw Error('Missing control '+${JSON.stringify(selector)});const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;return {x,y,w:r.width,h:r.height,hit:e.contains(document.elementFromPoint(x,y)),disabled:!!e.disabled};})()`);
    if(p.w&&p.h&&p.hit&&!p.disabled)break;
  }
  if(!p.w||!p.h||!p.hit||p.disabled)throw Error('Unreachable control '+selector+' '+JSON.stringify(p));
  await click(p.x,p.y);await sleep(150);
}
async function dblclick(x, y) {
  // Preserve event order without making CDP acknowledgement latency part of
  // the gesture: awaiting each reply can exceed the app's 450 ms window.
  const events = [];
  for (const n of [1, 2])
    for (const type of ["mousePressed", "mouseReleased"])
      events.push(send("Input.dispatchMouseEvent", { type, x, y, button: "left", clickCount: n }));
  await Promise.all(events);
}
async function drag(x0, y0, x1, y1, steps = 6) {
  await send("Input.dispatchMouseEvent", { type: "mousePressed", x: x0, y: y0, button: "left", clickCount: 1 });
  for (let i = 1; i <= steps; ++i)
    await send("Input.dispatchMouseEvent", { type: "mouseMoved", x: x0 + (x1 - x0) * i / steps, y: y0 + (y1 - y0) * i / steps, button: "left" });
  await send("Input.dispatchMouseEvent", { type: "mouseReleased", x: x1, y: y1, button: "left", clickCount: 1 });
}
/* GEO-192:帶 modifiers 的拖曳(CDP bitmask 同 pressKey:Alt=1、Ctrl=2、Meta=4、Shift=8),
   §P44-1/2/3 Alt+拖頂點捏缺口、§P44-4 拖預覽矩形邊都要用。 */
async function dragMod(x0, y0, x1, y1, steps = 6, modifiers = 0) {
  await send("Input.dispatchMouseEvent", { type: "mousePressed", x: x0, y: y0, button: "left", clickCount: 1, modifiers });
  for (let i = 1; i <= steps; ++i)
    await send("Input.dispatchMouseEvent", { type: "mouseMoved", x: x0 + (x1 - x0) * i / steps, y: y0 + (y1 - y0) * i / steps, button: "left", modifiers });
  await send("Input.dispatchMouseEvent", { type: "mouseReleased", x: x1, y: y1, button: "left", clickCount: 1, modifiers });
}
/* GEO-192:放開拖曳但不放開按鍵(給 §P44-3 拖到一半按 Esc 用)。 */
async function pressDownMod(x0, y0, modifiers = 0) {
  await send("Input.dispatchMouseEvent", { type: "mousePressed", x: x0, y: y0, button: "left", clickCount: 1, modifiers });
}
async function moveMod(x, y, modifiers = 0) {
  await send("Input.dispatchMouseEvent", { type: "mouseMoved", x, y, button: "left", modifiers });
}
async function rightClick(x, y) {
  for (const type of ["mousePressed", "mouseReleased"])
    await send("Input.dispatchMouseEvent", { type, x, y, button: "right", clickCount: 1 });
}

/* 每段斷言數地板:完整模式與 golden 嚴格比對(差異 → failN 增加);部分模式只印不比。
   GEOMETRY_CDP_UPDATE_GOLDEN=1 才會重寫 golden(僅完整模式、且本次零失敗)。 */
const GOLDEN_PATH=path.join(__dirname,'cdp_sections.golden.json');
function evaluateSections() {
  const actual={sections:{...sectionPass}};
  const total=Object.values(actual.sections).reduce((a,b)=>a+b,0);
  const wantUpdate=process.env.GEOMETRY_CDP_UPDATE_GOLDEN;
  _log('CDP_SECTIONS '+Object.keys(actual.sections).length+' 段,合計 '+total+' 通過斷言');
  if(wantUpdate!==undefined && wantUpdate!=='1'){failN++;_log('[CDP FLOOR] GEOMETRY_CDP_UPDATE_GOLDEN 只接受 1');}
  if(scope.mode!=='full'){
    if(wantUpdate){failN++;_log('[CDP FLOOR] 部分模式不可更新 golden(golden 只記完整模式)');return 'update-refused (partial mode)';}
    _log('[CDP FLOOR] 部分模式,未比對 golden。各段通過數:'+JSON.stringify(actual.sections));
    return 'not compared (partial mode)';
  }
  if(wantUpdate==='1'){
    if(failN>0){_log('[CDP FLOOR] 本次有失敗斷言,不更新 golden');return 'update-refused (failures)';}
    fs.writeFileSync(GOLDEN_PATH,JSON.stringify(floor.buildGolden(actual.sections),null,2)+'\n');
    _log('[CDP FLOOR] 已重寫 '+GOLDEN_PATH+'(請檢視 git diff 後再提交)');
    return 'golden updated';
  }
  let golden;
  try {golden=JSON.parse(fs.readFileSync(GOLDEN_PATH,'utf8'));}
  catch(error){failN++;_log('[CDP FLOOR] 讀不到 golden '+GOLDEN_PATH+':'+error.message+'(以 GEOMETRY_CDP_UPDATE_GOLDEN=1 建立)');return 'golden unreadable';}
  const problems=floor.validateGolden(golden);
  if(problems.length){failN++;for(const problem of problems)_log('[CDP FLOOR] golden 格式錯誤:'+problem);return 'golden invalid';}
  const diffs=floor.compare(golden,actual);
  for(const diff of diffs){failN++;_log('[CDP FLOOR]',diff.message);}
  if(diffs.length)return 'mismatch ('+diffs.length+')';
  _log('[CDP FLOOR] 與 golden 逐段相符('+Object.keys(golden.sections).length+' 段)');
  return 'matched';
}

async function main() {
  await connect();
  await send("Runtime.enable");
  await send("Page.enable");
  await send("Network.enable");
  await send('Runtime.addBinding',{name:'__geometryCdpTransportFailure'});
  await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
    const install=${installClientTransportTrace.toString()};
    const start=()=>install(window,record=>window.__geometryCdpTransportFailure(JSON.stringify(record)));
    if(typeof window.apiRequest==='function')start();
    else document.addEventListener('DOMContentLoaded',start,{once:true});
  })()`});
  // A reused Chrome profile can restore a narrow window. Pin the desktop
  // baseline explicitly; responsive cases restore this same viewport.
  await send('Emulation.setDeviceMetricsOverride',{width:1400,height:900,deviceScaleFactor:1,mobile:false});
  // Observe async UI completion without changing application behavior. A fixed 300–400 ms
  // pause was reading between a committed command and its subsequent inspector refresh.
  await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{
    let pending=0,last=performance.now();const original=window.fetch.bind(window);
    window.fetch=(...args)=>{pending++;last=performance.now();return original(...args).finally(()=>{pending--;last=performance.now();});};
    const observer=new MutationObserver(()=>{last=performance.now();});
    document.addEventListener('DOMContentLoaded',()=>observer.observe(document.body,{subtree:true,childList:true,attributes:true,characterData:true}));
    window.__cdpSettleUI=async ms=>{
      await new Promise(r=>setTimeout(r,ms));const end=performance.now()+5000;
      while(performance.now()<end){if(pending===0&&performance.now()-last>=150)return;await new Promise(r=>setTimeout(r,50));}
      // Opportunistic settling only: some race tests deliberately keep a fetch
      // pending. Their explicit waitForUI predicate/assertion is authoritative.
    };
  })()`});
  await send("Page.navigate", { url: process.env.GEOMETRY_TEST_URL || "http://localhost:8765/" });
  await waitForUI(`typeof api==='function' && typeof oc==='object' && connection.phase==='ready'`,30000);
  if (!await eval_(`typeof api==='function' && typeof oc==='object' && connection.phase==='ready'`))
    throw Error('Application did not finish loading: '+JSON.stringify(await eval_(`({state:document.readyState,url:location.href,api:typeof api,message:document.querySelector('#connectionMessage')?.textContent})`)));

  const check=bodyCheck(),samples=[];let pt48;
  await send('Emulation.setDeviceMetricsOverride',{width:5400,height:3800,deviceScaleFactor:1,mobile:false});
  try {
  const waitForFaceViewport = async () => {
    await eval_(`new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))`);
    await waitForUI(`(()=>{const r=$('faceEditorViewport').getBoundingClientRect(),v=fe.viewportSize,i=feViewportInsets(r);
      return !!v&&Math.abs(v.width-r.width)<.5&&Math.abs(v.height-r.height)<.5&&v.top===i.top&&v.bottom===i.bottom;})()`);
  };
  const feOrigin = async () => {
    await waitForFaceViewport();
    const origin=await eval_(`(()=>{const r=$('faceEditorSvg').getBoundingClientRect(),m=$('faceEditorRoot').getScreenCTM();
      return {x:r.left,y:r.top,matrix:{a:m.a,b:m.b,c:m.c,d:m.d,e:m.e,f:m.f}};})()`);
    // Existing callers add their own camera offsets to x/y; retain that contract.
    const m=origin.matrix;
    return {...origin,point:(u,v)=>({x:m.a*u+m.c*v+m.e,y:m.b*u+m.d*v+m.f})};
  };
  const openFace48 = async () => {
    await eval_(`(()=>{ fe.zoom = 1; fe.panX = 0; fe.panY = 0; feApply(); })()`);
    await sleep(100);
    const org = await feOrigin();
    return (mx, my) => ({ x: org.x + mx, y: org.y + my });
  };
  const clearToasts48 = () => eval_(`document.getElementById('toastRegion').innerHTML = ''`);

  const setupLinesG196 = async (lines) => eval_(`(async()=>{
    const out = [];
    const r0 = await apiRequest('reset');
    out.push({ line: 'reset', ok: r0.ok === true, error: r0.error || null, preview: !!r0.preview });
    if (r0.ok !== true) return out;
    for (const l of ${"__LINES__"}) {
      const r = await apiRequest('line ' + l);
      out.push({ line: l, ok: r.ok === true, error: r.error || null, preview: !!r.preview });
      if (r.ok !== true || r.preview) break;
    }
    return out;
  })()`.replace('__LINES__', JSON.stringify(lines)));

  const F_SUPPORT = [
    'surface 1 origin 0 0 2500 u +x v +y outline 0,0 4000,0 4000,3000 0,3000',
    'timber 1 27 33 role boundary',
    'place 1 on 1 at-face e0 +u +n',
    'timber 2 27 33 role boundary',
    'place 2 on 1 at-face e2 +u +n',
    'spec 測試中線 2000',
    'guide 2 1 v spec:測試中線'];

  console.log('=== P52. 預示帶橫向幾何符合 at-line/at-face 語意(G196-R05) ===');
  /* 預示帶(.fe-anchor-band)的 cross 範圍用 feAnchorCrossRange 直接算,再與
     真實放置後的核心 footprint 對照——兩邊是不同實作(前端示意 vs 引擎求解),
     交叉驗證不是共用同一個 helper 當裁判。 */
  {
    const rs = await setupLinesG196(F_SUPPORT);
    check('P52 setup 全過', Array.isArray(rs) && rs.every(r => r.ok && !r.preview), rs);
    await eval_(`(async()=>{ resetSceneFocus(); await renderObjects(); await enterFocus('face', 1);
      fe.zoom = 1; fe.panX = 0; fe.panY = 0; feApply();
      const t = document.getElementById('faceSnapToggle'); if (t) t.checked = false;
      await feLoadGuides(); renderFaceInspector(); fiShowTab('timber');
      feSetTool('timber'); })()`);
    await sleep(150);
    /* at-line u=2000, A=27 → [1987,2014];A=28 → [1986,2014](I13 多的 1mm 在 +cross) */
    const c27 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-line guide 2', 27)`);
    const c28 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-line guide 2', 28)`);
    check('P52-1 at-line 置中:A27 → u 1987..2014,A28 → 1986..2014',
      c27 && c27.constAxis === 'u' && c27.lo === 1987 && c27.hi === 2014 &&
      c28 && c28.lo === 1986 && c28.hi === 2014, { c27, c28 });
    /* at-face 四邊 × 兩軸:e1(u=4000,材料 -u)→ [3973,4000];e3(u=0,+u)→ [0,27];
       e0(v=0,材料 +v)→ [0,27];e2(v=3000,-v)→ [2973,3000] */
    const cE1 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-face e1', 27)`);
    const cE3 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-face e3', 27)`);
    const cE0 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-face e0', 27)`);
    const cE2 = await eval_(`feAnchorCrossRange(oc.edit.bid, 'at-face e2', 27)`);
    check('P52-2 at-face 貼材料側:e1 3973..4000、e3 0..27、e0 v0..27、e2 v2973..3000',
      cE1 && cE1.constAxis === 'u' && cE1.lo === 3973 && cE1.hi === 4000 &&
      cE3 && cE3.lo === 0 && cE3.hi === 27 &&
      cE0 && cE0.constAxis === 'v' && cE0.lo === 0 && cE0.hi === 27 &&
      cE2 && cE2.lo === 2973 && cE2.hi === 3000, { cE1, cE3, cE0, cE2 });
    for(let trial=0;trial<1;trial++){
    /* P52-3 矩陣把世界留在最後一個情境;P52-4/5 沿用本區塊開頭的假設
       (F_SUPPORT 場景 + 角材工具 + 表單 v 向/+n/A27)——在這裡還原,
       不讓矩陣的殘留狀態污染後面的既有檢查。 */
    {
      const rs53r = await setupLinesG196(F_SUPPORT);
      if (!(Array.isArray(rs53r) && rs53r.every(r => r.ok && !r.preview)))
        throw new Error('P52-3 收尾回 F_SUPPORT 失敗: ' + JSON.stringify(rs53r));
      await eval_(`(async()=>{ resetSceneFocus(); await renderObjects(); await enterFocus('face', 1);
        await feLoadGuides(); renderFaceInspector(); fiShowTab('timber');
        feSetTool('timber');
        const d = document.getElementById('tbDir'); d.value = '+v'; d.dispatchEvent(new Event('change'));
        const s = document.getElementById('tbSide'); s.value = '+n'; s.dispatchEvent(new Event('change'));
        const av = document.getElementById('tbA'); av.value = '27'; av.dispatchEvent(new Event('input')); })()`);
    }
    /* 畫出的 DOM 帶 = 計算範圍,且套 face-material-clip */
    await eval_(`(()=>{ const a = document.getElementById('tbAnchor');
      a.value = 'at-line guide 2'; a.dispatchEvent(new Event('change'));
      const av = document.getElementById('tbA'); av.value = '27'; av.dispatchEvent(new Event('change')); })()`);
    await sleep(200);
    const dom = await eval_(`(()=>{ const b = document.querySelector('#faceEditorRoot .fe-anchor-band');
      return b ? { x: +b.getAttribute('x'), w: +b.getAttribute('width'),
        clip: b.parentElement.getAttribute('clip-path') } : null; })()`);
    check('P52-4 DOM 帶畫 u 1987..2014 且套材料區裁切',
      dom && dom.x === 1987 && dom.w === 27 && dom.clip === 'url(#face-material-clip)', dom);
    /* 真實放置後核心 footprint 的 cross 範圍 = 帶的範圍 */
    pt48 = await openFace48();
    await eval_(`(()=>{const raw=apiRequest;window.__p52CaseRaw=raw;window.__p52CaseEvents=[];
 apiRequest=async(command,...rest)=>{const original=command;let injected=null;
 if(command.startsWith('line place 3 on 1 ')&&"wrong"==='delay'){injected='place-before-send-900ms';__p52CaseEvents.push({original,injected,ms:performance.now()});await new Promise(r=>setTimeout(r,900));}
 if(command.startsWith('line place 3 on 1 ')&&"wrong"==='missing'){__p52CaseEvents.push({original,injected:'omit-place',ms:performance.now()});return {ok:true};}
 if(command.startsWith('line timber 3 27 33 ')&&"wrong"==='wrong'){command=command.replace('timber 3 27 33 ','timber 3 28 33 ');injected='A28';}
 const r=await raw(command,...rest);__p52CaseEvents.push({original,command,injected,ok:r?.ok,ms:performance.now()});return r;};return true;})()`);
    await click(pt48(2000, 1500).x, pt48(2000, 1500).y);
    /* 放置包含多筆非同步指令；畫面靜穩不能代替核心完成，足跡仍按原值驗。 */
    await cdp.makeSettle({waitForUI,eval_},{tag:'P52-5',timeoutMs:5000})(
      '角材 3 放置交易已收尾且核心 references 已回傳幾何',
      `(async()=>{const refs=await apiRequest('references');
        if(refs.ok!==true)throw Error('P52-5 references 失敗: '+JSON.stringify(refs));
        return !oc.busy&&!ReferenceWorkspace.history.group&&
          (refs.timbers||[]).some(t=>t.id===3&&!!t.geometry);})()`);
    const g = await eval_(`(async()=>{ const refs = await apiRequest('references');
      const t = (refs.timbers || []).find(x => x.id === 3); return t && t.geometry; })()`);
    const fxLo = g && Math.min(g.origin[0], g.origin[0] + g.axes[1][0] * g.A);
    const fxHi = g && Math.max(g.origin[0], g.origin[0] + g.axes[1][0] * g.A);
    check('P52-5 真實放置的 cross 足跡(核心) = 預示帶範圍 1987..2014',
      fxLo === 1987 && fxHi === 2014, { g });
    }
  }
    const events=await eval_('window.__p52CaseEvents||[]');
    const result={mode:"wrong",sha:process.env.P52_SHA,passed:passN,failed:failN,exceptions:excN,samples,events};
    fs.writeFileSync(path.join(process.env.P52_OUT,'result.json'),JSON.stringify(result,null,2));
    const shot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(process.env.P52_OUT,'placement.png'),Buffer.from(shot.result.data,'base64'));
    _log('P52_CASE_RESULT '+JSON.stringify(result));
  }catch(error){
    const events=await eval_('window.__p52CaseEvents||[]');
    fs.writeFileSync(path.join(process.env.P52_OUT,'result.json'),JSON.stringify({mode:"wrong",sha:process.env.P52_SHA,passed:passN,failed:failN,exceptions:excN,fatal:error.message,events},null,2));throw error;
  }
  chrome?.kill();process.exit(failN||excN?1:0);
}
async function fatal(e) {
  _log("FATAL:", e.message);
  _log('FATAL_NETWORK:',JSON.stringify({failures:assetFailures,pendingAssets:[...assetRequests.values()]}));
  try {
    if(ws?.readyState===1){
      const state=await Promise.race([eval_(`({ready:document.readyState,focus:typeof oc==='object'?oc.focus:null,connection:typeof connection==='object'?{phase:connection.phase,error:connection.error}:null,events:window.geometryFeedback?.events?.slice(-10),dialogs:[...document.querySelectorAll('dialog[open]')].map(d=>({id:d.id,classes:d.className,text:d.textContent.slice(0,1200)})),active:document.activeElement?.id,feedback:document.querySelector('#fbPanel')?.hidden,status:document.querySelector('#status')?.textContent})`),delay(1500).then(()=>null)]);
      _log('FATAL_UI:',JSON.stringify(state));
      const capture=await Promise.race([send('Page.captureScreenshot',{format:'png'}),delay(1500).then(()=>null)]);
      if(capture?.result?.data&&process.env.GEOMETRY_REPAIR_SCREENSHOT_DIR){
        fs.mkdirSync(process.env.GEOMETRY_REPAIR_SCREENSHOT_DIR,{recursive:true});
        fs.writeFileSync(path.join(process.env.GEOMETRY_REPAIR_SCREENSHOT_DIR,'fatal-state.png'),Buffer.from(capture.result.data,'base64'));
      }
    }
  } catch(captureError) {_log('FATAL_CAPTURE_FAILED:',captureError.message);}
  finally {
    _log('CDP_RESULT '+JSON.stringify({schema:'geometry-cdp-result/1',scope,firstTransportFailure:transportFailureTrace?.apiFirst()||null,firstNetworkFailure:transportFailureTrace?.first()||null,completed:false,passedAssertions:passN,failedAssertions:failN,fatal:e.message,skipped,sections:sectionPass,...(Object.keys(sectionFail).length?{sectionsFailed:sectionFail}:{}),currentSection,goldenCompare:'not compared (run did not complete)'}));
    chrome?.kill();process.exit(1);
  }
}
if(require.main===module){
  try {scope=runConfiguration();console.log=recordLog;(async()=>{await assertPortAvailable(PORT);chrome=startBrowser();chrome.on('error',fatal);_log('CDP_SCOPE '+JSON.stringify(scope));await main();})().catch(fatal);}
  catch(error){_log('CDP preflight failed:',error.message);process.exitCode=1;}
} else module.exports={runConfiguration,assertionVerdicts,evaluationValue,explicitVerdict,assertPortAvailable,verifyBrowserOwnership};
