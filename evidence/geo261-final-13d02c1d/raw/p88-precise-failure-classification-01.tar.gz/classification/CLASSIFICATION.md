# P88 原始失敗與待驗分類

產品 F=`13d02c1db7022145a52ee063286a558e595eb212`；最新審查為 head `22ad28f`（完整同步快照與 SHA 見 JSON）。

原 canvas job 退出 **1**。精確 fatal predicate：

```js
document.activeElement===document.querySelector("#refGuideMode")
```

在 P88、390px 情境逾時，原 active 是 `refGuideRatio`。最後 click 記為 `label < div#refGuideSourceFields`，「來源比例原值一半兩倍」，座標 `(293.75, 627.5)`。先前 1502 assertions 通過，但 completed=false；golden 原文為 `not compared (run did not complete)`，不是完整綠燈。此輪 canvas 尚未執行到 P73。

目前分類：**UI 焦點／點擊落點紅燈，產品版面時序與測試定位的根因尚待確認**。原輸出沒有 pointer-down 的 target、rect 或 scroll 追蹤，不把最後 click 猜成 pointer-down 原證據。既有同 F grid job 綠與舊 F2 canvas 綠只是診斷線索。

已派 P88 專責子代理，在乾淨固定 F 上依原 workflow 單獨連跑 canvas 三次；每次獨立暫存／埠、保留完整輸出及退出碼、原正式時限與斷言。其他分支只做實作及靜態審，暫停重測以保 canvas 獨占。未預填任何重跑結果。

四組反證：runtime 同 F baseline／撤回／恢復已取得 0／1／0，正在封存；P73、Chromium 154、oracle 尚未在本輪執行，不列通過。先保留原輪紅燈，再依三次重跑結果修正及做因果自證，固定新 F 後重跑受影響項。
