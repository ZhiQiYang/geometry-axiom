# 新 F 的原獨立 P52 verifier 綁定

本目錄只完成工具準備、原 bytes 複製及 AST 靜態核，沒有執行 verifier、產品、測試、build、browser、benchmark 或 Git。既有 frozen formal／binder 沒有改動。

原獨立工具 `/tmp/g261r3/tools/verify_postfix_receipt.py` 共 1,627 bytes，已逐 bytes 保存於 `original/verify_postfix_receipt.py`：

- 原 SHA-256：`5a109def7794ebc1e34048afe500fd97758f98781ff90597fedec0dc214f1e04`。
- 完整原 AST SHA-256：`af6a262bc9b906b65d2d8d5483d2ba508d7681655ac2db4b1aae82e2b34b5e1a`。
- 原九個 `assert` 全部保留。原程式沒有任何修改，不以 formal helper 的成功替代它的獨立執行。

它原本只接受 SHA 參數，從自身目錄找 `postfix-<sha8>/receipt.json`、`postfix-<sha8>-launch.log` 與四個 protocol 檔案。舊 launch log 的 JSON 行是 `command`／`rc`／`log`；新 formal 則完整保存真 c387 row。適配只準備新的隔離檔案配置與明列的資料投影：

1. 原正式 `receipt.json` 一字不改複製到全新 `layout/postfix-13d02c1d/receipt.json`；不寫回 `/tmp/g288pf`。
2. 原 verifier 全 bytes 及 formal frozen 四個 protocol 全 bytes 複製到 `layout/`。逐檔核原固定 hash；formal driver snapshot 另外固定為既有 bound driver hash `af5cfe9f895f0fdf41f8a13f96494f9be37c20de30c8cd06b459b5967cd46d13`。
3. 每個 receipt record／control 與真 Node row 一對一。嚴格核九個獨立 log／c387 result 目錄、完整 command rows 的唯一 row、原 argv／cwd／source SHA／variant、實際 P52 SHA／mode／reps，以及每份原 `result.json`。只排除 c387 擷取完成後才由 frozen formal 添加的 `effective_environment`、`legacy_probe_log` 兩欄，再核 raw result 精確相等。
4. 每份 Node stdin／stdout／stderr 的原 hash、長度與完整 bytes 留存。要求真 timeout_expired=false、無 capture exception，並核原 `probe.log` 正是原 stdout bytes 後接 stderr bytes。原 rc 直接來自 `actual_process_returncode`，不由 expected exit 或 receipt 的 exit 反推。
5. 逐真 row 機械投影成原 verifier 的 `command`／`rc`／`log`，寫入 fresh layout 的 `postfix-13d02c1d-launch.log`。這份檔案清楚標為 **DERIVED，並非原 launch stdout**；`projection-index.json` 保存每行與原 result／streams／log 的對應及 hash。原正式 receipt 的絕對 log key 保持原字面值。
6. 以獨立 `python -B layout/verify_postfix_receipt.py <F>` 子程序執行未修改的原 verifier。它仍自行核 Node 真退出碼與 receipt 相符、退出碼限 0／1、原正常／具名負控、四原 driver hash、原 timing 綠、四 records／五 controls，並自行寫 `verified.json`。原 stdout／stderr／真退出碼由原 c387 保存；adapter 的退出另列，不把輸入適配錯誤冒稱 verifier gate 綠。
7. 所有被讀取的原正式檔案及 frozen 適配件都核前後 bytes 相同。原件、完整 Node 串流、副本、投影、原 verifier 執行收據與命令都保留，不自動回收。

正式 P52 完成後由 root 串行執行；輸出父目錄須存在、輸出目錄須全新：

```sh
python3 -B /workspace/geo261-environment/execute_f_extra.py \
  --label postmerge-p52-verifier \
  --sha 13d02c1db7022145a52ee063286a558e595eb212 \
  --repo /tmp/g288f-13d02c1d \
  --outer-root /workspace/geo288-main-merge-20261023/extras-outer -- \
  python3 -B /workspace/geo288-main-merge-20261023/verifier-tools/run.py \
    --sha 13d02c1db7022145a52ee063286a558e595eb212 \
    --formal-out /tmp/g288pf \
    --out /workspace/geo288-main-merge-20261023/p52-verifier-final
```

這項只有讀收據及執行原 verifier，沒有新的產品執行。它安排在正式 P52 後；不另改原七項或並跑 benchmark。原 verifier 外層既有 watchdog 是 14,400 秒，本 adapter 沿用作子程序 timeout；不是新的產品數值門檻。九個 Node 的原 1,200 秒 budget 由既有 frozen formal／protocol 原 source 佐證；c387 原 row 沒有 requested-timeout 秒數欄位，因此不宣稱 raw row 本身記有該秒數。

輸出 `receipt.json` 分列 adapter 真退出、原獨立 verifier 真退出、原 `verified.json` 與 hash、完整命令、環境、實際 SHA、來源前後 hash、所有 DERIVED 對應及錯誤。原 assert 或 verifier 子程序非零仍保存真退出；適配／缺件／timeout 為非零，不能當成有效產品反證。AST 檢查通過與本工具準備成功均不是原 verifier 已通過。
