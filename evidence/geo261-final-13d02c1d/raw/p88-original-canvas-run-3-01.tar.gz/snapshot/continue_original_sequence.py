"""Finish all three requested original canvas runs; retain every outcome."""
import datetime, hashlib, json, os, subprocess, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
F = '13d02c1db7022145a52ee063286a558e595eb212'
REPO = Path('/tmp/g288f-13d02c1d')
DRIVER = ROOT / 'run_canvas_workflow.py'
EXPECTED = json.loads((ROOT / 'BINDING.json').read_text())['bound_sha256']
OUTER = ROOT / 'outers'
report = {'schema': 'geo288-p88-original-three-sequence/1', 'sha': F,
          'source': str(REPO), 'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'policy': 'Three requested full original canvas jobs, independently isolated, all results retained; no automatic replacement or product edit.',
          'runs': [], 'first_run_environment_limit': 'Run 1 original launcher did not include NODE_OPTIONS in its environment whitelist. No preload was configured; subsequent current-shell absence is not asserted as a launch-time process observation.'}
def save():
    p = ROOT / 'sequence-receipt.json.tmp'
    p.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    p.replace(ROOT / 'sequence-receipt.json')
def record(index, outer):
    raw = json.loads((Path('/tmp') / f'g288p88o{index}/workflow/canvas/receipt.json').read_text())
    assert raw['sha'] == F and raw['job'] == 'canvas'
    assert raw['checkout_before']['head'] == raw['checkout_after']['head'] == F
    assert raw['checkout_before']['status'] == raw['checkout_after']['status'] == ''
    r = {'index': index, 'sha': F, 'original_workflow_exit': raw['exit_code'],
         'outer_exit': outer['outer_process']['actual_process_returncode'],
         'over_ci_timeout': raw['over_ci_timeout'], 'seconds': raw['seconds'],
         'receipt': str(Path('/tmp') / f'g288p88o{index}/workflow/canvas/receipt.json'),
         'receipt_sha256': hashlib.sha256((Path('/tmp') / f'g288p88o{index}/workflow/canvas/receipt.json').read_bytes()).hexdigest()}
    report['runs'].append(r)
    save()
    print(json.dumps(r, ensure_ascii=False), flush=True)
save()
first = OUTER / 'p88-original-canvas-1/receipt.json'
while True:
    if first.exists():
        try:
            current = json.loads(first.read_text())
            if current.get('outer_process') is not None:
                break
        except json.JSONDecodeError:
            pass
    time.sleep(10)
record(1, current)
for index in (2, 3):
    assert hashlib.sha256(DRIVER.read_bytes()).hexdigest() == EXPECTED
    assert not (Path('/tmp') / f'g288p88o{index}').exists()
    command = ['env', '-u', 'NODE_OPTIONS', '-u', 'PYTHONOPTIMIZE', 'python3', '-B',
               '/workspace/geo261-environment/execute_f_extra.py', '--label', f'p88-original-canvas-{index}',
               '--sha', F, '--repo', str(REPO), '--outer-root', str(OUTER), '--',
               'flock', '-n', '/tmp/g261r3/heavy.lock', 'python3', '-B', str(DRIVER),
               '--repo', str(REPO), '--sha', F, '--job', 'canvas', '--out-root', f'/tmp/g288p88o{index}/workflow',
               '--port', str(19880+index), '--cdp-port', str(9680+index)]
    prefix = ROOT / f'original-{index}-launch'
    (prefix.with_suffix('.request.json')).write_text(json.dumps({'sha': F, 'command': command, 'cwd': str(REPO),
        'environment_input': {k: os.environ.get(k) for k in ('NODE_OPTIONS', 'PYTHONOPTIMIZE', 'PATH')},
        'environment_removals': ['NODE_OPTIONS', 'PYTHONOPTIMIZE']}, indent=2)+'\n')
    with prefix.with_suffix('.stdout').open('xb') as stdout, prefix.with_suffix('.stderr').open('xb') as stderr:
        result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr)
    (prefix.with_suffix('.exit.json')).write_text(json.dumps({'actual_process_returncode': result.returncode,
        'ended': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2)+'\n')
    record(index, json.loads((OUTER / f'p88-original-canvas-{index}/receipt.json').read_text()))
report['ended'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report['all_three_completed'] = len(report['runs']) == 3
save()
print('All requested original canvas runs completed; individual exits retained.', flush=True)
