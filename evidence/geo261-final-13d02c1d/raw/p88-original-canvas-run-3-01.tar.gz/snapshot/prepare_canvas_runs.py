"""Bind unchanged workflow execution to distinct canvas ports; no test edits."""
from pathlib import Path
import ast, difflib, hashlib, json

root = Path(__file__).resolve().parent
source = Path('/workspace/geo261-environment/run_workflow_round.py')
raw = source.read_text()
changes = [
    ('    port = 19080 + ORDER.index(args.job)', '    port = args.port'),
    ("        env['GEOMETRY_CHROME'] = str(CHROME)", "        env['GEOMETRY_CHROME'] = str(CHROME)\n        env['GEOMETRY_CDP_PORT'] = str(args.cdp_port)\n        env['GEOMETRY_CHROME_PROFILE'] = str(tmp / 'chrome-profile')"),
    ("                  'XDG_DATA_HOME', 'XDG_CACHE_HOME', *original_env}", "                  'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'GEOMETRY_CDP_PORT', 'GEOMETRY_CHROME_PROFILE', *original_env}"),
    ("    parser.add_argument('--repo', type=Path, required=True)", "    parser.add_argument('--repo', type=Path, required=True)\n    parser.add_argument('--port', type=int, required=True)\n    parser.add_argument('--cdp-port', type=int, required=True)"),
]
bound = raw
for before, after in changes:
    assert bound.count(before) == 1, before
    bound = bound.replace(before, after)
ast.parse(bound)
target = root / 'run_canvas_workflow.py'
assert not target.exists()
target.write_text(bound)
(root / 'original_run_workflow_round.py.txt').write_bytes(source.read_bytes())
(root / 'driver-binding.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True), bound.splitlines(True), fromfile=str(source), tofile=str(target))))
(root / 'BINDING.json').write_text(json.dumps({'original_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'bound_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'changes': 'Only explicit HTTP/CDP ports and isolated Chrome profile; workflow/assertions/golden/CI limits unchanged.', 'product_sha': '13d02c1db7022145a52ee063286a558e595eb212'}, indent=2)+'\n')
print(target)
