# Runtime 原收據封存補正

第一個 staging script 讀取 Chrome `SingletonSocket` 時出現 `OSError: [Errno 6] No such device or address`，因此中止。其後 shell 的下一行 publisher 仍執行，產生 `c3fec08f` 的不完整 raw 封包；原 runtime gate 0／1／0 與原 receipt 未改，但該提交的「原 streams 已封存」敘述過早。

本次使用全新 staging 目錄，保留第一包及原始測試檔。僅排除原 receipt 指明的八個 Chrome profiles、`com.google.Chrome.*` 暫存 socket 目錄、非一般檔；逐檔清單與 SHA-256 見 PACKAGING.json。只有本次完整補包才用於完整 raw 的查驗。這是封存工具修正，沒有重跑或修改產品／測試結果。
