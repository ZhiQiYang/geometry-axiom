#!/usr/bin/env python3
"""只調用凍結的原 one 與原 timing AST；本程序真 rc 是原 timing gate。"""
import ast,hashlib,importlib.util,json,math,os,signal,statistics,subprocess,sys,time,types
from pathlib import Path
import capture

SAFE=('PATH','LANG','LC_ALL','TMPDIR','GITHUB_SHA','GITHUB_WORKSPACE','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING',
      'GEOMETRY_FEEDBACK_DIR','GEOMETRY_TEST_URL','GEOMETRY_CHROME','GEOMETRY_CHROME_FLAGS','GEOMETRY_CDP_PORT',
      'GEOMETRY_CDP_FROM_P31','GEOMETRY_CHROME_PROFILE','P52_OUT','P52_SHA','P52_CASE_MODE','P52_REPS','GEO261_REAPER_LOG')
def h(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def main():
 request=json.loads(Path(sys.argv[1]).read_text());out=Path(request['out']);protocol=Path(request['protocol'])
 sys.path.insert(0,str(protocol));sys.argv=[str(protocol/'postfix_validate.py'),request['sha']]
 spec=importlib.util.spec_from_file_location('p52_original_postfix',protocol/'postfix_validate.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 original=(protocol/'postfix_validate.py').read_text();tree=ast.parse(original)
 function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
 start=next(i for i,n in enumerate(function.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='samples' for t in n.targets))
 stop=next(i for i,n in enumerate(function.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='timing' for t in n.targets))
 nodes=function.body[start:stop+1];need(len(nodes)==4,'原 gate AST 範圍改變')
 gate=ast.Module(body=nodes,type_ignores=[]);gate_text=ast.get_source_segment(original,function.body[stop])
 need("medians['fix']<=medians['main']" in gate_text,'原 <=1.0 gate 改變')
 (out/'original-gate-source.txt').write_text(''.join(original.splitlines(keepends=True)[nodes[0].lineno-1:nodes[-1].end_lineno]))
 env=dict(module.shared.ENV,TMPDIR=request['tmp']);Path(request['tmp']).mkdir(parents=True)
 module.OUT=out;module.WORK=Path(request['tmp']).parent
 module.ENV=env;module.SHA=request['sha']
 recorder=capture.Recorder(out,env,request['sha']);servers=[];node_commands=[];records=[]
 result={'sha':request['sha'],'variant':request['variant'],'source_sha':request['sha'],
         'scope':'additional original 4-block timing only; official baseline supplies unchanged five controls',
         'records':records,'servers':servers,'node_commands':node_commands,'completed':False,'errors':[]}
 def run(argv,*,cwd=None,env=env,timeout=1200,check=True,source_sha=None):
  old=recorder.env;recorder.env=env
  actual_sha=source_sha or env.get('P52_SHA',request['sha'])
  try:return recorder.run(list(map(str,argv)),cwd=cwd,timeout=timeout,check=check,source_sha=actual_sha,
                         source_variant='main-reference' if actual_sha==module.shared.SHAS['main'] else request['variant'])
  finally:recorder.env=old
 def recorded_command(argv,log,*,cwd=None,env=env,timeout=1200):
  # Node 是 capture 直接啟動的 session leader，watchdog killpg 可殺同組 Chrome；
  # 整個 phase 外層的原 subreaper 負責回收孤兒，不再隔一層 setsid reaper。
  child=dict(env)
  row,stdout,stderr=run(argv,cwd=cwd,env=child,timeout=timeout,check=False)
  row['effective_environment']={k:child.get(k) for k in SAFE}
  Path(log).write_bytes(stdout+stderr);node_commands.append(row)
  if row['actual_process_returncode']!=0:raise RuntimeError('原 Node 真退出碼非零；不得當 timing gate 紅')
 def ready(argv,*,cwd,env,capture_output):
  row,stdout,stderr=run(argv,cwd=cwd,env=env,timeout=15,check=False)
  return subprocess.CompletedProcess(argv,row['actual_process_returncode'],stdout,stderr)
 def server(argv,*,cwd,env,stdout,stderr,start_new_session):
  child=dict(env,GEO261_REAPER_LOG=str(Path(stdout.name).with_suffix('.reaper.jsonl')))
  actual=list(map(str,[sys.executable,'-B',request['reaper'],*argv]))
  row={'original_command':argv,'command':actual,'cwd':str(cwd),'source_sha':child['P52_SHA'],'acceptance_sha':request['sha'],
       'source_variant':'main-reference' if child['P52_SHA']==module.shared.SHAS['main'] else request['variant'],
       'environment':{k:child.get(k) for k in SAFE},'started_epoch':time.time()}
  process=subprocess.Popen(actual,cwd=cwd,env=child,stdout=stdout,stderr=stderr,start_new_session=start_new_session)
  row['_process']=process;row['log']=stdout.name;servers.append(row);return process
 module.shared.command=recorded_command
 module.subprocess=types.SimpleNamespace(Popen=server,run=ready,STDOUT=subprocess.STDOUT,TimeoutExpired=subprocess.TimeoutExpired)
 def watchdog(signum,frame):raise TimeoutError('僅工具 watchdog；不作產品／gate 裁判')
 signal.signal(signal.SIGALRM,watchdog);signal.alarm(1800)
 result['infrastructure_watchdog_seconds']=1800
 try:
  result['build_commands']=[]
  for key,sha in (('main_repo',module.shared.SHAS['main']),('fix_repo',request['sha'])):
   row,stdout,stderr=run(['npm','run','build'],cwd=Path(request[key]),source_sha=sha)
   result['build_commands'].append(row)
  for index,label in enumerate(('main','fix','fix','main')):
   repo=Path(request['main_repo'] if label=='main' else request['fix_repo'])
   sha=module.shared.SHAS['main'] if label=='main' else request['sha']
   row=module.one(repo,f'{index}-{label}',sha,'measure',index,'p52_probe.cjs' if label=='main' else 'p52_cases.cjs')
   records.append(row)
   need(row['label']==f'{index}-{label}' and row['sha']==sha and row['mode']=='measure','原順序／來源／mode 改變')
   need(node_commands[-1]['actual_process_returncode']==0 and row['exit']==0 and row['result']['failed']==0 and row['result']['exceptions']==0 and not row['result'].get('fatal'),'原完整 Node 必須真 rc0、無額外紅')
   samples=row['result']['samples'];need(len(samples)==8 and [s['trial'] for s in samples]==list(range(8)),'每 block 必須原八筆，不可挑樣本')
   need(all(isinstance(s.get('appearedMs'),(int,float)) and math.isfinite(s['appearedMs']) and s['appearedMs']>=0 for s in samples),'樣本不完整或非有限數')
  for row in servers:
   reaped=[json.loads(s) for s in Path(row['environment']['GEO261_REAPER_LOG']).read_text().splitlines()]
   need(reaped[-1].get('event')=='完成','server reaper 未完整回收')
  namespace={'records':records,'shared':module.shared,'statistics':statistics,'SHA':request['sha']}
  exec(compile(gate,str(protocol/'postfix_validate.py'),'exec'),namespace)
  timing=namespace['timing'];need(timing['count']=={'main':16,'fix':16},'原 main/fix 各十六筆')
  result.update(timing=timing,completed=True,gate_exit=0 if timing['no_regression'] else 1)
 except BaseException:
  import traceback
  result['errors'].append(traceback.format_exc());result['gate_exit']=None
 finally:
  signal.alarm(0)
  for row in servers:
   process=row.pop('_process');row['actual_process_returncode']=process.poll();row['ended_epoch']=time.time()
   raw=Path(row['log']).read_bytes();row['log_sha256']=h(raw);row['log_bytes']=len(raw)
  result['original_gate_source_sha256']=h((out/'original-gate-source.txt').read_bytes())
  save(out/'receipt.json',result)
 print(json.dumps(result,ensure_ascii=False))
 return result['gate_exit'] if result['completed'] and not result['errors'] else 2
if __name__=='__main__':raise SystemExit(main())
