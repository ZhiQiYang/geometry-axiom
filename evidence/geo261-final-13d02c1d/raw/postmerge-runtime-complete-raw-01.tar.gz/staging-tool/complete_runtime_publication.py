"""Complete failed staging without deleting or rewriting original streams."""
from pathlib import Path

source = Path('/workspace/geo288-main-merge-20261023/stage_runtime_publication.py')
text = source.read_text()
text = text.replace("target = Path('/tmp/g288pr-publication')", "target = Path('/tmp/g288pr-publication-complete')")
text = text.replace("if child in profile_paths or child.is_symlink():", "if child in profile_paths or child.is_symlink() or child.name.startswith('com.google.Chrome.'):")
text = text.replace("if child.is_symlink():\n            excluded", "if child.is_symlink() or not child.is_file():\n            excluded")
exec(compile(text, str(source) + ':complete-staging', 'exec'))
target = Path('/tmp/g288pr-publication-complete')
(target / 'STAGING_CORRECTION.md').write_text('''# Runtime 原收據封存補正

第一個 staging script 讀取 Chrome `SingletonSocket` 時出現 `OSError: [Errno 6] No such device or address`，因此中止。其後 shell 的下一行 publisher 仍執行，產生 `c3fec08f` 的不完整 raw 封包；原 runtime gate 0／1／0 與原 receipt 未改，但該提交的「原 streams 已封存」敘述過早。

本次使用全新 staging 目錄，保留第一包及原始測試檔。僅排除原 receipt 指明的八個 Chrome profiles、`com.google.Chrome.*` 暫存 socket 目錄、非一般檔；逐檔清單與 SHA-256 見 PACKAGING.json。只有本次完整補包才用於完整 raw 的查驗。這是封存工具修正，沒有重跑或修改產品／測試結果。
''')
