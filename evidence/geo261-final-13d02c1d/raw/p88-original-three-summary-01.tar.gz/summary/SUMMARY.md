# P88 固定來源三次原樣重跑

受驗 F：`13d02c1db7022145a52ee063286a558e595eb212`。

間歇紅：相同F上同一焦點斷言有紅，另有原P88全段143 checks完成；產品／測試時序根因仍待真trace。

| 次數 | 原 exit | 秒數 | completed | P88 checks | goldenCompare |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | 1071.906 | False | 99 | not compared (run did not complete) |
| 2 | 0 | 1754.826 | True | 143 | matched |
| 3 | 0 | 1739.477 | True | 143 | matched |

精確焦點 predicate：`document.activeElement===document.querySelector("#refGuideMode")`。段綠不冒完整 job 綠，第一輪環境觀測限制及所有原footer保留在SUMMARY.json。
