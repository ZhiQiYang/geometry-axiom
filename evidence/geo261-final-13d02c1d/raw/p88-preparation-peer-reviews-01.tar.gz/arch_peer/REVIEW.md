# P88 單檔 architecture adapter：獨立對抗靜審

審查者為 `own_299_316_combined`。直接讀取 run/core、README、SOURCE_IMPACT_STATIC、STATIC_REVIEW、ADAPTATION 與兩份 patch；另讀 F13 原 workflow／cdp dispatch／runtime identity 的小型原件。沒有 import 或執行受審工具、scanner、裁判、compiler、Chrome或bench。

在這個有限差分範圍，未找到可確立的靜態阻擋。獨立從 frozen 兩檔版按 ADAPTATION 的逐項文字變更重建，完整 bytes 恰等新工具；不是只信既有審查文字。run require 呼叫數保11，core保57。

- run SHA256：`8a30a2765d75825368457e7bc941a0dba0b5efdffa0086fb257f652302d47998`。
- core SHA256：`04c4fac6310b1adf96c80bfa6e34331601cd863d891845d238f4d75c519875d1`。
- frozen hashes 與新 hashes 都逐 bytes 重核；純 AST／字串核對見同目錄 `CHECKS.json`。

實質 adaptation 只移除 ALLOWED 的 `cdp_helpers.js` 並把兩個集合基數2改1；剩下唯一允許檔為 `geometry-web/grid_rule_lines_test.js`。changed inputs 與 stale exclusions 都必須精確等此 singleton；manifest僅原字串替換唯一舊LF digest，還原該欄後整份 deep equality，policy equality 也保留。source／layer／reason／roots／routes／vendor／W guard 都不放寬，沒有新增exclusion。

原三條 argv 保留：`python -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json`、`python -B tests/test_architecture_contract.py`、`python -B tests/test_product_architecture.py`。外層只以真sys.executable綁定，原c387與subreaper均驗hash、保既有heavy lock與16MiB stack。主 receipt schema 仍 `geometry-product-architecture-receipt/1`，`sourceBaseHead` 為真指定／核同的當次clean HEAD；沒有重標F13。

完整601 inputs＝333 owned＋268 excluded及920／55 guard不改；source set須同物理inventory／固定Git tree，逐blob LF核。舊manifest／scan／report先對sealed receipt，再對previous-commit與本次HEAD四檔原Git blobs；原三preflight必須為1／0／5，且只接受該path的EXCLUSION_DIGEST，最後5明列setUpClass／Ran0，不能改稱產品18方法已跑。新三裁判只在repo外同bytes驗證樹改衍生manifest後全0，counts與原receipt全等才封四檔；每階段守原來源與外部樹raw／LF／工具／HEAD／clean，未知紅燈保FAILED。

執行範圍獨立核到 `cdp_test.js:7133–7134`：只有 full canvas 或 `GEOMETRY_GRID_SYSTEM_ONLY` 真 require／呼叫P88。workflow也正是這兩個入口；assembly filter不滿足，documents把cdp當module時 `require.main===module` 為false，space／timber另一個driver。native的 `test_grid_rule_lines.js` 實際匯入產品 hyphen `grid-rule-lines.js`，不是本次underscore test-driver。

runtime仍會讀所有web根JS raw bytes產生資產身分，故其他server／P52／P73路徑的identity確實變，不能聲稱整個runtime closure同一。SOURCE_IMPACT把真執行與身分讀取分列是必要的；P189 archive本身含此JS，封裝bytes會變，不能沿用舊superset identical=true。若保留其他舊結果，必須逐項精確closure addendum、保原execution SHA，不能把F13綠改標新F。本審不替root決定是否繼承，也沒獨立重證所有判斷閉包。

仍待動態：候選真正修復P88的反證、新source的canvas連續／grid／ledger check／架構三條與列定四組反證，以及四檔實際產物／原streams。此工具只能在F13後僅此一JS input改變的來源使用；不能套到本代理含#323／#314的combined stack（其owned／輸入已有多項變動），更不能為額外改動擴白名單。
