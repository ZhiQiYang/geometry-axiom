# 新 F 的 P73 兩項收尾：僅準備，尚未執行

本目錄只凍結原工具 bytes／hash、命令模板與 scope。未建立產品 checkout、未產新 F binding、未啟動 driver／產品／編譯／Chrome。舊 bound-13d02c1d 只保存適配原件作比對，不當新 F 執行工具或新結果。

專屬驗收分支為 codex/geo288-p73-final-20261023；正文分支為同名 -prbody。整合分支只由 root 寫。root 提供新 F 完整可解析 SHA、該 SHA 的乾淨 detached 來源、新 bound 目錄、隔離 clone 的容量位置與 R3 時槽後，才逐項代入 COMMAND_TEMPLATES.json。模板中的 <...> 不能原樣執行。此刻沒有 push／驗收成功的聲明。

P73 controlled 使用原 execute_f_extra／c387／原 reaper／16MiB，P73 driver 自持 R3，不在外層再鎖一次。新短 scratch /tmp/gp7-<F8>；三態服務19960–19962、CDP9600–9602。clone 必須全新且由 root 配空間，不自行 clone 大型樹。原 probe.cjs、抽出的原 P73 predicate、單次真 callback 與具名斷言保持；fixed／withdrawn／restored 必真0／1／0，三階段 before predicate 都 true、callbackInvocations都1，after true／false／true、uncaughtBrowserExceptions都0、callback原碼不變；withdrawn 必是原具名 AssertionError，不能用 crash／timeout／setuperror 冒紅。此項只證受控 callback，不證完整 P73 自然 workflow。

Chromium154 只跑固定版原 P73 子集，以唯一 R3 外層 flock -n 包住原 legacy driver；它自己的 scratch lock 不替代 R3，原 self-exec subreaper保留。新短 scratch /tmp/gl7-<F8>；服務19964、CDP9604。模板清 NODE_OPTIONS、PYTHONOPTIMIZE 和 GEO261_P73_UNDER_REAPER，讓每輪確實進原self-reaper，無新 shim 或 Node 環境。原版本必為 /usr/bin/chromium 154、Node24，原 workflow／fonts檢查／原expected P73 69／partial scope／完整golden不比較都保留。這不是 Chrome156正式job、不是完整canvas，也不證明舊原產品曾綠。

legacy 原工具保真原退出碼：即使 proof_expectation_matches=false，原產品code仍可能0。因此接受時必逐項同核 outer／原exit、proof_expectation_matches=true、source_before==source_after、版本、唯一CDP_RESULT completed=true／failed0／P73=原golden69／partial且filter只GEOMETRY_UIUX_FIX_ONLY，以及原golden未比較。不能只看outer0就冒綠。整個命令終態後再保存 outer／legacy兩層reaper最終事件bytes/hash；不能在完成事件尚未寫入時提早封包。

root 綁定工具應保原 prepare_bindings、原p73 probe/capture、legacy run_workflow/reaper bytes，並產每份 binding patch／BINDING.json。新 SHA 的 run.py 與舊版差分只能按已審 binding機械適配。執行前後保存完整SHA、來源clean/index、工具hash、所有argv/exit/環境/原stdout/stderr、runtime source/clone前後identity。新架構或帳本由root最終處理，本代理不重產。

兩項均由原外錄製器各自保存；第一項紅也保原輸出，繼續收第二項，依user規則分類後修，不弱化原斷言。完工後在專屬驗收分支一般commit/push evidence/geo261-final-<F8>/，PR_BODY.md 推專屬-prbody；由另一代理對抗審後交root整合。此README只是待做規劃，不是執行收據。
