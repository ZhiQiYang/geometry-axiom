#!/usr/bin/env python3
"""僅重核 P88 採用後一個既有 test-driver exclusion digest；輸出四檔，不寫來源 checkout。"""
from __future__ import annotations

import argparse
import collections
import copy
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import sys
import traceback

ARTIFACT_DIR = 'geometry-core/domain-decoupling'
ARTIFACTS = ('product-architecture.json', 'product-architecture-scan.json',
             'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json')
ROOTS = ('geometry-core', 'geometry-app', 'geometry-templates', 'geometry-web', 'geometry-guide')
STANDALONE = ('current_geometry.c', 'tests/__init__.py', 'tests/binaries.py')
TOOLS = ('tests/architecture_contract.py', 'tests/test_architecture_contract.py', 'tests/test_product_architecture.py')
SUFFIXES = {'.c', '.cc', '.cjs', '.cpp', '.cxx', '.h', '.hh', '.hpp', '.htm', '.html', '.inc', '.js', '.jsx', '.mjs', '.py', '.ts', '.tsx'}
ALLOWED = frozenset((
    'geometry-web/grid_rule_lines_test.js',
))
HELPER = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
HELPER_SHA256 = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
SERIALIZATION = 'SHA-256 of UTF-8 JSON for the path-sorted inputs array, with ensure_ascii=false and separators=(comma,colon); each entry has path then sha256, and no trailing newline.'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalized(data):
    return data.replace(b'\r\n', b'\n')


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def info(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'rawSha256': digest(raw), 'lfSha256': digest(normalized(raw))}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--sha', '--expected-head', dest='sha', required=True)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0'), '拒絕最佳化 Python；保留原裁判 assertions')
    require(re.fullmatch('[0-9a-f]{40}', args.sha) is not None, '須明填實際固定來源完整40碼SHA')
    repo, out = args.repo.resolve(), args.out.resolve()
    require(repo.is_dir() and not out.exists(), 'repo須存在，out必須全新；不得覆蓋原收據')
    require(not out.is_relative_to(repo) and not repo.is_relative_to(out), 'out須在repo外且不得是repo祖先')
    require(digest(HELPER.read_bytes()) == HELPER_SHA256, '原c387錄製器hash不同')
    out.mkdir(parents=True)
    previous, new, validation_root = out / 'previous', out / 'new', out / 'validation-tree'
    previous.mkdir(); new.mkdir()
    (out / 'tmp').mkdir()
    spec = importlib.util.spec_from_file_location('geo288_original_capture', HELPER)
    cap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cap)
    env = dict(os.environ)
    cleared = []
    for name in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
        if name in env:
            env.pop(name); cleared.append(name)
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(out / 'tmp'), GITHUB_SHA=args.sha, GITHUB_WORKSPACE=str(repo), GIT_OPTIONAL_LOCKS='0')
    safe_env = {name: env.get(name) for name in ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE',
                'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'TMPDIR', 'GITHUB_SHA', 'GITHUB_WORKSPACE', 'GIT_OPTIONAL_LOCKS')}
    recorder = cap.Recorder(out, env, args.sha)
    started, script_before = now(), info(Path(__file__).resolve())
    head, baseline, validation_ready = None, None, False
    tool_hashes, old_artifacts = {}, {}
    manifest_raw = policy_manifest_raw = None

    def command(label, argv, *, cwd=repo, input_bytes=None):
        row, stdout, stderr = recorder.run(argv, cwd=cwd, data=input_bytes, timeout=None, check=False,
                                          source_sha=args.sha, source_variant='fixed-source-original-architecture-command')
        row['label'] = label
        save(out / 'commands.json', recorder.rows)
        return row, stdout, stderr

    def git(label, *parts, input_bytes=None):
        row, stdout, stderr = command(label, ['git', *parts], input_bytes=input_bytes)
        require(row['actual_process_returncode'] == 0, 'Git讀取非零：' + label)
        return stdout

    def inventory(at_root):
        paths = set(STANDALONE)
        def walk_error(error):
            raise error
        for relative in ROOTS:
            directory = at_root / relative
            require(directory.is_dir() and not directory.is_symlink(), '完整root不存在或是symlink：' + relative)
            for parent, directories, files in os.walk(directory, followlinks=False, onerror=walk_error):
                for name in directories:
                    require(not (Path(parent) / name).is_symlink(), '拒絕目錄symlink：' + str(Path(parent) / name))
                for name in files:
                    path = Path(parent) / name
                    if path.suffix.lower() in SUFFIXES:
                        require(path.is_file() and not path.is_symlink(), '拒絕來源別名或非一般檔：' + str(path))
                        paths.add(path.relative_to(at_root).as_posix())
        require(len({p.casefold() for p in paths}) == len(paths), '來源路徑有大小寫衝突')
        return sorted(paths)

    def snapshot(at_root):
        rows = []
        for relative in inventory(at_root):
            raw = (at_root / relative).read_bytes()
            rows.append({'path': relative, 'bytes': len(raw), 'rawSha256': digest(raw), 'sha256': digest(normalized(raw))})
        return rows

    def unchanged(label):
        require(snapshot(repo) == baseline, '來源完整raw/LF inventory變動：' + label)
        require(all(info(repo / p) == before for p, before in tool_hashes.items()), '原三裁判bytes變動：' + label)
        require(all((repo / ARTIFACT_DIR / name).read_bytes() == raw for name, raw in old_artifacts.items()), '來源四衍生檔被修改：' + label)
        require(git('head-' + label, 'rev-parse', 'HEAD').decode().strip() == head, '來源HEAD變動：' + label)
        require(git('status-' + label, 'status', '--porcelain=v1', '--untracked-files=all') == b'', '來源工作樹不再乾淨：' + label)
        if validation_ready:
            require(snapshot(validation_root) == baseline, '外部完整驗證樹產品inputs變動：' + label)
            require(all((validation_root / p).read_bytes() == (repo / p).read_bytes() for p in TOOLS), '外部原裁判bytes不同：' + label)
            require((validation_root / ARTIFACT_DIR / ARTIFACTS[0]).read_bytes() == policy_manifest_raw, '外部新manifest變動：' + label)

    def schema_record(row, human_command=None):
        folder = Path(row['directory'])
        return {'label': row['label'], 'argv': row['command'], 'command': human_command or row['command'],
                'cwd': row['cwd'], 'sourceBaseHead': args.sha, 'exitCode': row['actual_process_returncode'],
                'complete': not row['timeout_expired'] and row.get('exception') is None,
                'startedEpoch': row['started_epoch'], 'endedEpoch': row['ended_epoch'],
                'seconds': row['ended_epoch'] - row['started_epoch'], 'environment': row['environment'],
                'stdout': info(folder / 'stdout.bin'), 'stderr': info(folder / 'stderr.bin'),
                'stdoutRawPath': str(folder / 'stdout.bin'), 'stderrRawPath': str(folder / 'stderr.bin'),
                'originalCommandResult': row}

    try:
        head = git('head-before', 'rev-parse', '--verify', 'HEAD^{commit}').decode().strip()
        require(head == args.sha, '來源HEAD不等指定實際固定SHA')
        require(git('status-before', 'status', '--porcelain=v1', '--untracked-files=all') == b'', '來源必須乾淨')
        for name in ARTIFACTS:
            raw = (repo / ARTIFACT_DIR / name).read_bytes()
            old_artifacts[name] = raw
            (previous / name).write_bytes(raw)
        previous_hashes = {name: info(previous / name) for name in ARTIFACTS}
        manifest_raw = old_artifacts[ARTIFACTS[0]]
        manifest = json.loads(manifest_raw)
        original_manifest = copy.deepcopy(manifest)
        old_receipt = json.loads(old_artifacts['product-architecture-receipt.json'])
        require(old_receipt['schema'] == 'geometry-product-architecture-receipt/1', '未知舊receipt schema')
        require(set(manifest['sourceRoots']) == set(ROOTS) and set(manifest['sourceFiles']) == set(STANDALONE), '完整roots／standalone契約不同')
        require(len(manifest['sources']) == 333 and len(manifest['exclusions']) == 268, '只接受既有333+268完整inventory')
        require(len(manifest['policy']['forbiddenIdentifiers']) == 920 and len(manifest['policy']['forbiddenStrings']) == 55, '本輪不得改920/55既有W guard')
        require(previous_hashes[ARTIFACTS[0]]['lfSha256'] == old_receipt['manifestSha256'], '原manifest不符上份sealed receipt')
        require(previous_hashes['product-architecture-scan.json']['lfSha256'] == old_receipt['scanSha256'], '原scan不符上份sealed receipt')
        require(previous_hashes['PRODUCT-ARCHITECTURE.md']['lfSha256'] == old_receipt['reportSha256'], '原report不符上份sealed receipt')
        baseline = snapshot(repo)
        before_paths = [row['path'] for row in baseline]
        declared = sorted(row['path'] for row in manifest['sources'] + manifest['exclusions'])
        require(before_paths == declared and len(before_paths) == 601, '完整物理inventory與manifest不同')
        tracked = git('tracked-inputs', 'ls-tree', '-r', '-z', '--name-only', head, '--', *ROOTS, *STANDALONE)
        tracked_paths = sorted(p for p in tracked.decode().split('\0') if p and Path(p).suffix.lower() in SUFFIXES)
        require(before_paths == tracked_paths, '完整物理inventory與固定Git tree不同')
        refs = ''.join(head + ':' + p + '\n' for p in before_paths).encode()
        blobs = git('frozen-input-blobs', 'cat-file', '--batch', input_bytes=refs)
        input_evidence, cursor = [], 0
        for row in baseline:
            end = blobs.index(b'\n', cursor); header = blobs[cursor:end].split()
            require(len(header) == 3 and header[1] == b'blob', '固定input不是Git blob：' + row['path'])
            size, begin = int(header[2]), end + 1
            body = blobs[begin:begin + size]
            require(len(body) == size and blobs[begin + size:begin + size + 1] == b'\n', 'Git batch blob不完整')
            require(digest(normalized(body)) == row['sha256'], '來源input與固定Git blob不符：' + row['path'])
            input_evidence.append(dict(row, gitBlobOid=header[0].decode(), gitBlobRawSha256=digest(body)))
            cursor = begin + size + 1
        require(cursor == len(blobs), 'Git batch有未預期尾資料')
        save(out / 'source-inputs.json', input_evidence)
        inputs = [{'path': row['path'], 'sha256': row['sha256']} for row in baseline]
        raw_inputs = [{'path': row['path'], 'sha256': row['rawSha256']} for row in baseline]
        closure = digest(json.dumps(inputs, ensure_ascii=False, separators=(',', ':')).encode())
        raw_closure = digest(json.dumps(raw_inputs, ensure_ascii=False, separators=(',', ':')).encode())
        tool_hashes = {p: info(repo / p) for p in TOOLS}
        old_tool_hashes = old_receipt.get('completeInventoryVerification', {}).get('toolHashesAfter', {})
        require(all(old_tool_hashes.get(p) == x['lfSha256'] for p, x in tool_hashes.items()), '本輪不能改原三裁判')
        old_inputs = {row['path']: row['sha256'] for row in old_receipt['inputs']}
        require(set(old_inputs) == set(before_paths), '不得新增或移除來源')
        changed = [{'path': row['path'], 'previousSha256': old_inputs[row['path']], 'sha256': row['sha256']}
                   for row in inputs if row['sha256'] != old_inputs[row['path']]]
        require({row['path'] for row in changed} == ALLOWED and len(changed) == 1, '相對sealed receipt必須恰一個已審P88 test-driver inputs改動')
        before_by_path = {row['path']: row for row in input_evidence}
        excluded = {row['path']: row for row in manifest['exclusions']}
        require(ALLOWED <= excluded.keys(), '一個input都必須是既有具名exclusions')
        stale_before = []
        for entry in manifest['exclusions']:
            require(entry.get('hashMode') == 'lf', '既有exclusion必須保LF模式：' + entry['path'])
            actual = before_by_path[entry['path']]['sha256']
            if entry['sha256'] != actual:
                stale_before.append({'path': entry['path'], 'previousSha256': entry['sha256'], 'sha256': actual})
        require({row['path'] for row in stale_before} == ALLOWED and len(stale_before) == 1, '過期exclusions必須恰一個已審路徑')
        previous_commit = git('previous-receipt-commit', 'log', '-1', '--format=%H', '--', ARTIFACT_DIR + '/product-architecture-receipt.json').decode().strip()
        git('previous-source-ancestor', 'merge-base', '--is-ancestor', old_receipt['sourceBaseHead'], head)
        git('previous-receipt-ancestor', 'merge-base', '--is-ancestor', previous_commit, head)
        previous_from_git = out / 'previous-from-git'; previous_from_git.mkdir()
        previous_git_hashes = {}
        for name in ARTIFACTS:
            frozen = git('previous-output-' + name, 'show', previous_commit + ':' + ARTIFACT_DIR + '/' + name)
            (previous_from_git / name).write_bytes(frozen)
            previous_git_hashes[name] = info(previous_from_git / name)
            require(normalized(frozen) == normalized(old_artifacts[name]), '目前舊四檔與上份產物Git blob不同：' + name)
            current_blob = git('head-output-' + name, 'show', head + ':' + ARTIFACT_DIR + '/' + name)
            require(normalized(current_blob) == normalized(old_artifacts[name]), '目前舊四檔不符本次固定HEAD：' + name)
        versions = []
        for name, argv in [('python', [sys.executable, '--version']), ('git', ['git', '--version'])]:
            row, stdout, stderr = command('version-' + name, argv)
            require(row['actual_process_returncode'] == 0, '版本查詢非零：' + name)
            versions.append(schema_record(row))
        original_commands = [('original-scan', [sys.executable, '-B', TOOLS[0], '--root', '.', '--manifest', ARTIFACT_DIR + '/' + ARTIFACTS[0]]),
                             ('original-generic-tests', [sys.executable, '-B', TOOLS[1]]),
                             ('original-product-tests', [sys.executable, '-B', TOOLS[2]])]
        preflight, preflight_streams = [], []
        for label, argv in original_commands:
            row, stdout, stderr = command(label, argv)
            preflight.append(schema_record(row)); preflight_streams.append((stdout, stderr)); unchanged(label)
        # 此雲端Python在setUpClass拒絕、Ran 0 tests時實際回5；保原值，不冒稱已執行18方法。
        require([row['exitCode'] for row in preflight] == [1, 0, 5], '舊manifest原三裁判須重現實錄1/0/5；真raw已全保，不用新綠覆原')
        old_scan_result = json.loads(preflight_streams[0][0])
        require(old_scan_result.get('ok') is False and old_scan_result.get('diagnostics')
                and all(x.get('code') == 'EXCLUSION_DIGEST' and x.get('path') in ALLOWED for x in old_scan_result['diagnostics']), '舊scanner紅燈不只來自已審單exclusion digest')
        old_product_error = preflight_streams[2][1].decode('utf-8', 'replace')
        require('EXCLUSION_DIGEST' in old_product_error and re.search(r'^Ran 0 tests in ', old_product_error, re.M)
                and old_product_error.rstrip().endswith('FAILED (errors=1)'), '舊product測試須明確為原setUpClass digest error，不接受crash或其他未知非零')
        proposed_raw = manifest_raw
        updated_exclusions = []
        for path in sorted(ALLOWED):
            old_sha = excluded[path]['sha256']; new_sha = before_by_path[path]['sha256']
            require(proposed_raw.count(old_sha.encode()) == 1, '原digest在manifest須唯一，拒絕模糊替換：' + path)
            proposed_raw = proposed_raw.replace(old_sha.encode(), new_sha.encode(), 1)
            excluded[path]['sha256'] = new_sha
            updated_exclusions.append({'path': path, 'previousSha256': old_sha, 'sha256': new_sha,
                                       'hashMode': 'lf', 'reason': excluded[path]['reason'],
                                       'rawSha256': before_by_path[path]['rawSha256'], 'gitBlobOid': before_by_path[path]['gitBlobOid']})
        require(json.loads(proposed_raw) == manifest, '一個digest的raw替換與新manifest語意不同')
        restored_manifest = copy.deepcopy(manifest)
        for entry in restored_manifest['exclusions']:
            if entry['path'] in ALLOWED:
                entry['sha256'] = next(old['sha256'] for old in original_manifest['exclusions'] if old['path'] == entry['path'])
        require(restored_manifest == original_manifest, '除了一個exclusion sha256不得改任何manifest欄位')
        require(manifest['policy'] == original_manifest['policy'], 'W guard或政策被修改')
        policy_manifest_raw = proposed_raw
        (new / ARTIFACTS[0]).write_bytes(policy_manifest_raw)
        delta = {'updatedExclusions': updated_exclusions, 'addedSources': [], 'addedExclusions': [],
                 'allOtherManifestFieldsEqual': True, 'allPolicyFieldsEqual': True, 'byteChangeMethod': 'replace exactly one unique existing digest strings; preserve all other manifest bytes',
                 'beforeManifestSha256': digest(normalized(manifest_raw)), 'afterManifestSha256': digest(normalized(policy_manifest_raw))}
        save(out / 'manifest-delta.json', delta)
        validation_root.mkdir()
        for relative in sorted(set(before_paths) | set(TOOLS)):
            target = validation_root / relative; target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((repo / relative).read_bytes())
        for name in ARTIFACTS:
            target = validation_root / ARTIFACT_DIR / name; target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(policy_manifest_raw if name == ARTIFACTS[0] else old_artifacts[name])
        validation_ready = True
        unchanged('validation-tree-created')
        binding = {'sourceBaseHead': head, 'sourceRepository': str(repo), 'validationCwd': str(validation_root),
                   'hasIndependentGitCheckout': False, 'productInputCount': len(inputs),
                   'productInputsByteIdenticalToFrozenCheckout': True, 'architectureToolsByteIdentical': True,
                   'gitIdentityCheckedWithLfNormalization': True, 'derivedManifestOnlyDelta': delta,
                   'note': '新三裁判cwd是外部完整驗證樹；不冒稱該樹有獨立Git SHA。固定來源checkout前後不變，只有衍生manifest一hash不同。'}
        save(out / 'validation-tree-binding.json', binding)
        final_runs = []
        for label, argv in [('final-scan', original_commands[0][1]), ('final-generic-tests', original_commands[1][1]), ('final-product-tests', original_commands[2][1])]:
            row, stdout, stderr = command(label, argv, cwd=validation_root)
            final_runs.append((row, stdout, stderr)); unchanged(label)
        require(all(row['actual_process_returncode'] == 0 for row, _, _ in final_runs), '新manifest原三裁判非全0；真raw全保，不產生通過receipt')
        scan_row, scan_raw, scan_stderr = final_runs[0]
        scan = json.loads(scan_raw)
        require(scan.get('ok') is True and scan.get('diagnostics') == [], '原scanner有diagnostics')
        require(set(scan['sources']) == {row['path'] for row in manifest['sources']}, '原scanner owned來源與原登記不同')
        (new / 'product-architecture-scan.json').write_bytes(scan_raw)
        validations = []
        for index, (row, stdout, stderr) in enumerate(final_runs[1:]):
            text = (stdout + b'\n' + stderr).decode('utf-8', 'replace')
            matches = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s\s*$', text, re.M)
            require(len(matches) == 1 and int(matches[0][0]) > 0, '原test數缺少、零或不唯一')
            outcome = re.fullmatch(r'OK(?: \(skipped=(\d+)\))?', text.rstrip().splitlines()[-1])
            require(outcome is not None, '原test未以OK結束')
            total, skipped = int(matches[0][0]), int(outcome[1] or 0)
            require(total == old_receipt['validation'][index]['tests'] and skipped == old_receipt['validation'][index]['skipped'], '原test方法數或skip與原同bytes裁判不同')
            converted = schema_record(row, 'python -B ' + TOOLS[index + 1])
            converted.update(tests=total, passed=total - skipped, failed=0, skipped=skipped, unittestSeconds=float(matches[0][1]))
            validations.append(converted)
        counts = {'executableFiles': len(inputs), 'ownedSources': len(manifest['sources']), 'exclusions': len(manifest['exclusions']),
                  'edges': len(scan['edges']), 'diagnostics': len(scan['diagnostics']),
                  'layers': dict(sorted(collections.Counter(row['layer'] for row in manifest['sources']).items())),
                  'languages': dict(sorted(collections.Counter(row['language'] for row in manifest['sources']).items())),
                  'forbiddenIdentifiers': len(manifest['policy']['forbiddenIdentifiers']), 'forbiddenStrings': len(manifest['policy']['forbiddenStrings'])}
        require(counts == old_receipt['counts'], '只改一excluded digest，原owned graph與完整counts必須保持上份原scanner結果；不以手填新數值掩掉差異')
        report = normalized(old_artifacts['PRODUCT-ARCHITECTURE.md']).decode().rstrip() + '\n\n## 雲端 Linux 有限重產：P88 一個 test-driver exclusion digest\n\n'
        report += f'固定實際來源為 `{head}`，上份架構產物提交為 `{previous_commit}`。原manifest的三裁判依原值記錄1／0／5；最後的5是setUpClass因digest拒絕且Ran 0 tests，不能算已跑產品18方法。只在repo外完整驗證樹更新下列一個既有exclusion的LF digest，原來源checkout與三裁判bytes保持不變。\n\n'
        report += '、'.join('`' + path + '`' for path in sorted(ALLOWED)) + '。所有source登記、root、layer、排除理由、router/vendor digest、W guard與其他政策都保持原值；未新增exclusion或目錄豁免。\n\n'
        report += f'獨立物理與Git tree inventory為{counts["executableFiles"]} executable、{counts["ownedSources"]} owned、{counts["exclusions"]} excluded；原scanner記{counts["edges"]} edges、{counts["diagnostics"]} diagnostics。LF input closure：`{closure}`。\n\n'
        for row in validations:
            report += f'- `{row["command"]}`：原退出{row["exitCode"]}，{row["tests"]} tests／{row["passed"]} passed／{row["failed"]} failed／{row["skipped"]} skipped；完整原命令、cwd、stdout／stderr另存。\n'
        report += '\n本輪只證靜態架構契約；不代表native、帳本、瀏覽器、P52、Q38、§7或P-189已重跑。舊Windows supplemental未執行；既有歷史來源與結果保持原角色。四檔為衍生產物，receipt不雜湊自身。\n'
        (new / 'PRODUCT-ARCHITECTURE.md').write_text(report, encoding='utf-8')
        unchanged('before-seal')
        require(info(Path(__file__).resolve()) == script_before and digest(HELPER.read_bytes()) == HELPER_SHA256, 'driver或原c387 helper在執行期間改變')
        policy_delta = {'addedIdentifiers': [], 'removedIdentifiers': [], 'addedStrings': [], 'removedStrings': [],
                        'identifiersBefore': 920, 'identifiersAfter': 920, 'stringsBefore': 55, 'stringsAfter': 55,
                        'allOtherManifestFieldsEqual': True, 'allPolicyFieldsEqual': True, 'manifestByteUnchanged': False,
                        'onlyOneExistingExclusionSha256Changed': True}
        receipt = {'schema': 'geometry-product-architecture-receipt/1',
            'headBinding': '四份衍生產物排除於來源closure；原來源HEAD／完整inputs／原裁判前後不變。新三裁判在外部同bytes完整驗證樹執行，cwd如實記錄，不冒稱該樹獨立Git SHA。',
            'hashMode': 'sha256 after CRLF-to-LF normalization', 'inputClosureHashSerialization': SERIALIZATION,
            'inputClosureExcludes': [ARTIFACT_DIR + '/' + name for name in ARTIFACTS],
            'inputClosureExclusionReason': '四份非執行性衍生稽核產物不屬產品來源；manifest、scan、report分別雜湊，receipt不雜湊自身。',
            'notClaimed': ['native編譯或執行', 'runtime import blocker', '完整JavaScript dataflow證明', 'vendor internals', 'mutation帳本新鮮度或重產', '瀏覽器與所有專項驗收', 'Windows supplemental probes', '未來來源'],
            'createdUtc': now(), 'basis': '乾淨固定HEAD、獨立完整inventory、原三preflight與只更新一digest的外部完整驗證樹三原裁判。',
            'sourceBaseHead': head, 'headObservedBefore': head, 'headObservedAfter': head,
            'manifestSha256': digest(normalized(policy_manifest_raw)), 'scannerSha256': tool_hashes[TOOLS[0]]['lfSha256'],
            'scanSha256': digest(normalized(scan_raw)), 'reportSha256': digest(normalized((new / 'PRODUCT-ARCHITECTURE.md').read_bytes())),
            'inputClosureSha256': closure, 'counts': counts,
            'manifestRefresh': {'previousManifestSha256': previous_hashes[ARTIFACTS[0]]['lfSha256'],
                'previousReceiptSha256': previous_hashes['product-architecture-receipt.json']['lfSha256'],
                'previousScanSha256': previous_hashes['product-architecture-scan.json']['lfSha256'],
                'previousReportSha256': previous_hashes['PRODUCT-ARCHITECTURE.md']['lfSha256'],
                'previousReceiptCreatedUtc': old_receipt.get('createdUtc'), 'previousSourceBaseHead': old_receipt['sourceBaseHead'],
                'previousReceiptCommit': previous_commit, 'firstObservedHead': head,
                'previousOutputsPreserved': {'directory': str(previous), 'hashes': previous_hashes},
                'lastSealedOutputsReadFromGit': {'commit': previous_commit, 'directory': str(previous_from_git), 'hashes': previous_git_hashes,
                    'note': '先驗目前舊四檔等原sealed receipt，再逐一從上份產物Git commit取blob比LF hash；本次HEAD四檔blob也比同，不以新manifest偷換舊guard。'},
                'headManifestSha256Before': digest(normalized(manifest_raw)), 'addedSources': [], 'addedExclusions': [],
                'updatedExclusions': updated_exclusions, 'newInputs': [], 'changedPreviouslySealedInputs': changed,
                'allowedChangedInputs': sorted(ALLOWED), 'staleExcludedVendorOrEmbedDigestsBefore': stale_before,
                'staleExcludedVendorOrEmbedDigestsAfter': [], 'digestEvidence': delta, 'policyDelta': policy_delta,
                'originalManifestPreflight': preflight, 'validationTree': binding,
                'classificationNote': '只更新一個既有LF exclusion digest；source/layer/reason/policy/root/route/vendor/W guard皆不改。', 'toolChanges': []},
            'scanPassed': True,
            'actualCliScan': schema_record(scan_row, 'python -B tests/architecture_contract.py --root . --manifest ' + ARTIFACT_DIR + '/' + ARTIFACTS[0]),
            'validation': validations,
            'supplementalStaticGuardProbes': {'executedAtCurrentHead': False, 'legacyWindowsSupplementalExecuted': False,
                'reason': '政策與W guard全不變；本輪只執行原三架構裁判，未借用或冒稱Windows supplemental。'},
            'nativeAcceptance': '此driver不執行native、帳本、瀏覽器或其他專項；必須另有實際來源與結果。',
            'inputs': inputs,
            'completeInventoryVerification': {'method': '獨立os.walk五roots與三standalone，對manifest集合與固定Git tree逐一驗同、逐blob LF核；每個原裁判後重盤原來源與外部樹raw/LF inputs、工具、四檔、HEAD與clean。',
                'sourceRoots': list(ROOTS), 'sourceFiles': list(STANDALONE), 'executableSuffixes': sorted(SUFFIXES),
                'filesBefore': len(inputs), 'filesAfter': len(inputs), 'unregisteredBeforeRefresh': [], 'unregisteredAfter': [],
                'missingAfter': [], 'changedInputs': [], 'inputClosureSha256Before': closure, 'inputClosureSha256After': closure,
                'rawInputClosureSha256Before': raw_closure, 'rawInputClosureSha256After': raw_closure,
                'rawHashBasis': 'Linux checkout raw bytes；portable身份另以LF與固定Git blob比較。',
                'toolHashesBefore': {p: x['lfSha256'] for p, x in tool_hashes.items()}, 'toolHashesAfter': {p: x['lfSha256'] for p, x in tool_hashes.items()},
                'rawToolHashesBefore': {p: x['rawSha256'] for p, x in tool_hashes.items()}, 'rawToolHashesAfter': {p: x['rawSha256'] for p, x in tool_hashes.items()},
                'allRawAndLfInputsUnchanged': True, 'headObservedAfterIndependentAudit': head, 'checkedUtc': now()},
            'refreshDriver': {**script_before, 'runDirectory': str(out), 'argv': [sys.executable, *sys.argv],
                'recorder': {'path': str(HELPER), 'sha256': HELPER_SHA256},
                'note': '沿既有Linux external-validation-tree／完整inventory／old-blob guards；將W政策生成窄化成一個exclusion digest-only；不移植其W guard新增或supplemental claims。'},
            'environment': {'system': platform.system(), 'release': platform.release(), 'machine': platform.machine(),
                'python': sys.version, 'safeVariables': safe_env, 'clearedInheritedEnvironmentNames': cleared, 'versions': versions},
            'uncertainties': ['未執行Windows supplemental probes；不外推native或動態產品行為。', '只輸出out/new四檔，來源repo未寫；尚未提交的產物不是已發布。', '後續final SHA須另跑受影響正式門檻。']}
        save(new / 'product-architecture-receipt.json', receipt)
        unchanged('after-receipt')
        result = {'schema': 'geo288-p88-linux-one-exclusion-architecture-refresh/1', 'source_sha': head, 'startedUtc': started, 'finishedUtc': now(),
                  'passed': True, 'scan_exit_code': 0, 'validation_exit_codes': [x['exitCode'] for x in validations],
                  'originalManifestPreflightExitCodes': [x['exitCode'] for x in preflight], 'counts': counts,
                  'changedPreviouslySealedInputs': changed, 'updatedExclusions': updated_exclusions,
                  'inputClosureSha256': closure, 'allRawAndLfInputsUnchanged': True, 'allOtherManifestFieldsEqual': True,
                  'allPolicyFieldsEqual': True, 'previous_outputs': previous_hashes,
                  'outputs': {name: info(new / name) for name in ARTIFACTS}, 'checkout_modified': False,
                  'note': '只證本輪架構四檔與原三裁判；不表示其他final gates已跑。'}
        save(out / 'RESULT.json', result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
        return 0
    except BaseException as error:
        guard_error = None
        if head is not None and baseline is not None and manifest_raw is not None:
            try:
                unchanged('failure-final')
            except BaseException:
                guard_error = traceback.format_exc()
        save(out / 'FAILED.json', {'startedUtc': started, 'finishedUtc': now(), 'passed': False, 'source_sha': head,
             'error_type': type(error).__name__, 'error': str(error), 'postFailureGuardError': guard_error,
             'commands': recorder.rows, 'note': '原raw／非零與部分產物保留，不能稱作完成。'})
        traceback.print_exc()
        return 130 if isinstance(error, KeyboardInterrupt) else 1


if __name__ == '__main__':
    raise SystemExit(main())
