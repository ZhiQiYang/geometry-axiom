# 單檔 grid_rule_lines_test.js：執行與身分讀取的差別

純小型文字靜態審查；未執行候選、collector、裁判、編譯、Chrome或bench，未改repo。候選仍需真動態自證與普通提交。舊F2=`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`、F13=`13d02c1db7022145a52ee063286a558e595eb212`的原收據、退出碼與scope全部保原executionSHA，不改標新F。

## 真執行此driver的正式範圍

原 `.github/workflows/integration-tests.yml:121–126` 分派：canvas無filter執行cdp_test；grid加`GEOMETRY_GRID_SYSTEM_ONLY=1`執行cdp_test；assembly加`GEOMETRY_ASSEMBLY_ONLY=1`；documents用documents_browser_test；space／timber用space_model_test。

`geometry-web/cdp_test.js:7133–7134` 只有 `scope.mode==='full' || GEOMETRY_GRID_SYSTEM_ONLY` 才 `await require('./grid_rule_lines_test.js')` 並呼叫匯出的P88方法。因此 **canvas與grid確實執行變更driver**，必須在新F重跑；P88修正另需真撤回／恢復反證。assembly的filter不滿足此條件，連動態require都不執行。

documents雖在 `documents_browser_test.js:4` require cdp_test作共用harness，`cdp_test.js:7185–7188` 明確以 `require.main===module` 守住main，作為module只export工具，不啟動main／P88。space／timber使用另一driver，沒有此P88 require。不要只因檔名出現在被引用的cdp_test文字裡，就說documents執行了P88。

native註冊的 `tests/test_grid_rule_lines.js:2/:27` require／讀的是產品 **`grid-rule-lines.js`（hyphen）**，不是本次 **`grid_rule_lines_test.js`（underscore）**。原頂層tests與web driver的精確路徑搜尋未見另一處實際匯入或直接斷言本檔內容；歷史release-evidence來源快照／mapping不當作現行native gate入口。此結論限本次單檔差分，不能套用到cdp_helpers若也變更的情況。

## 其餘 runtime 身分確實改變

`runtime_version.py:48–55` 把web根所有JS加入static routes；`:77–107`建source集合；`:110–118`對公開JS保留rawbytes；`RuntimeSnapshot:141–144`讀bytes算version。此test-driver雖是架構exclusion，仍在runtime identity內。server `serve.py:31`建立此snapshot；native `tests/test_serve.py:27–31`載入真serve時也走它。其內容在這些路徑作公開資產／身分hash資料，不是JavaScript行為執行。

| 原項 | 此單檔在判斷路徑的角色 | 本輪該如何記錄 |
|---|---|---|
| canvas／grid | 真require並執行P88 | 新F實跑原job，另保存P88反證 |
| assembly／documents／space／timber | server RuntimeSnapshot讀rawbytes／新version；不執行P88driver | 如引用舊F13原結果，保舊executionSHA，附精確closure差異與runtime身分變更；不能稱新F實跑 |
| native test_serve | 原server RuntimeSnapshot讀rawbytes；grid-rule-lines unit測另一個產品模組 | 同上；不能把只讀bytes誤稱P88行為依賴，也不能宣稱舊runtime hash等於新runtime hash |
| P52 formal／runtime proof | server snapshot與完整runtime inventory包含本檔；Node probe從cdp_test擷取bootstrap與P52段，沒有包含P88的require段 | 保留原計時、反證executionSHA；若沿用須明示runtime identity單檔差異。不可無新實跑就產新F計時結果 |
| P73 controlled | server snapshot包含本檔；probe只從cdp_test擷取bootstrap，執行原P73predicate與callback，不執行P88 | 保原F13及三態；closure addendum明列新增身分差異，不冒新F三態 |
| Chromium154 P73 subset | server snapshot包含本檔；`GEOMETRY_UIUX_FIX_ONLY=1`不滿足P88require條件 | 保原executionSHA與subset scope；沒有擴成canvas |
| P52 receipt verifier | 核原formal收據／工具／Node原件及hash | 原formal內容不改就仍是原來源的驗證，不能把old sourceVersion換成新version |

「讀bytes」本身是真輸入差異，必須留下新／舊blob、mode、rawhash與runtime-version角色；但它與「執行P88或依其斷言作判斷」不同。依使用者最新只重跑受影響項，由root決定是否引用以上範圍的舊原證據；此文件不另發明總gate或允許skip。

## 非runtime專項與封裝

原reader／checker／parser prepare、O2、sanitized／Q38／card-reference／純Cperf／P189的實際判斷依賴不執行此driver；先前具名閉包原件仍需用新單檔例外addendum核對，不能照抄舊5108superset identical=true。reader原trace掃current_geometry／SSOT／root scenes／mutate，不因web根這個testdriver變更而讀其語意。

P189的Git archive包含整個geometry-web，所以封裝**包含且bytes會變**；之後編譯web_bridge.c、CLI loadfile+dump／計時不執行此JS。Cperf固定main archive不因本次fix變更；F側clone機械含全樹同樣要區分封裝身分與C編譯／計時依賴。不能說P189完全沒讀本檔、或整個archive逐bytes不變；只能在精確addendum後保其原executionSHA與原判定範圍。

原mutate來源閉包是current_geometry／web_bridge的quoted C include closure，bridge oracle是tests/*.py、tests/*.c、fixtures scenes、root scenes；此單檔不進該閉包。仍應按原`mutate.py --check`實跑決定新鮮度，而非本文件代判。架構manifest明列本檔exclusion LFhash，因此必須重產四檔與三原裁判；這正是同目錄adapter的唯一允許變更。
