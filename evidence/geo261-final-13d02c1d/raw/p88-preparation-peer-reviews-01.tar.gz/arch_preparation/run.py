#!/usr/bin/env python3
"""以既有Linux subreaper及heavy lock執行單exclusion有限架構重產，不提交或改來源。"""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import signal
import subprocess
import sys
import traceback

BASE = Path(__file__).resolve().parent
REAPER = Path('/workspace/geo261-environment/reap_children.py')
REAPER_SHA256 = '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_SHA256 = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'


def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(raw): return hashlib.sha256(raw).hexdigest()
def save(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def require(ok, message):
    if not ok: raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--sha', '--expected-head', dest='sha', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--heavy-lock', required=True, type=Path)
    args = parser.parse_args()
    require(platform.system() == 'Linux', '本driver使用既有Linux subreaper')
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None, '', '0'), '不准關閉原assertions')
    require(re.fullmatch('[0-9a-f]{40}', args.sha) is not None, '須提供實際固定來源完整40碼SHA')
    repo, out, lock_path = args.repo.resolve(), args.out.resolve(), args.heavy_lock.resolve()
    require(repo.is_dir() and not out.exists(), 'repo須存在，out必須全新')
    require(not out.is_relative_to(repo) and not repo.is_relative_to(out), 'out須在repo外且不得為repo祖先')
    require(lock_path.is_file() and not lock_path.is_relative_to(out), '須用既有排程heavy lock，不另建')
    require(digest(REAPER.read_bytes()) == REAPER_SHA256 and digest(CAPTURE.read_bytes()) == CAPTURE_SHA256, '既有subreaper或原c387錄製器hash不同')
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    require(hard == resource.RLIM_INFINITY or hard >= 16384 * 1024, 'hard stack不足16MiB')
    out.mkdir(parents=True); (out / 'tools').mkdir(); (out / 'outer').mkdir()
    sources = {}
    for path in (Path(__file__).resolve(), BASE / 'refresh_exclusions.py', REAPER, CAPTURE):
        raw = path.read_bytes(); sources[str(path)] = {'bytes': len(raw), 'sha256': digest(raw)}
        (out / 'tools' / path.name).write_bytes(raw)
    cleared, env = [], dict(os.environ)
    for name in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
        if name in env: env.pop(name); cleared.append(name)
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               GITHUB_SHA=args.sha, GITHUB_WORKSPACE=str(repo), GIT_OPTIONAL_LOCKS='0', GEO261_REAPER_LOG=str(out / 'outer/reaper.jsonl'))
    safe = {key: env.get(key) for key in ('PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE',
             'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'GITHUB_SHA', 'GITHUB_WORKSPACE', 'GIT_OPTIONAL_LOCKS', 'GEO261_REAPER_LOG')}
    command = [sys.executable, '-B', str(out / 'tools/reap_children.py'), sys.executable, '-B',
               str(out / 'tools/refresh_exclusions.py'), '--repo', str(repo), '--sha', args.sha, '--out', str(out / 'refresh')]
    receipt = {'schema': 'geo288-p88-one-exclusion-linux-refresh-outer/1', 'source_sha': args.sha, 'repo': str(repo),
               'out': str(out), 'heavy_lock': str(lock_path), 'argv': [sys.executable, *sys.argv], 'command': command,
               'cwd': str(repo), 'environment': safe, 'clearedInheritedEnvironmentNames': cleared,
               'startedUtc': now(), 'toolSources': sources, 'stackBefore': [soft, hard], 'stackDuring': [16384 * 1024, hard],
               'python': sys.version, 'pythonExecutable': sys.executable, 'platform': platform.platform(),
               'actual_process_returncode': None, 'passed': False, 'errors': [], 'receivedSignals': [],
               'outputsDirectory': str(out / 'refresh/new'), 'sourceCheckoutModifiedByDriver': False, 'publicationPerformed': False}
    save(out / 'receipt.json', receipt)
    process = None; old_handlers = {}; lock = None
    def forward(signum, frame):
        receipt['receivedSignals'].append({'signal': signum, 'utc': now()})
        if process is not None and process.poll() is None: process.send_signal(signum)
    try:
        lock = lock_path.open('a+b'); fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
        for signum in (signal.SIGINT, signal.SIGTERM): old_handlers[signum] = signal.signal(signum, forward)
        save(out / 'outer/request.json', receipt)
        with (out / 'outer/stdout.bin').open('wb') as stdout, (out / 'outer/stderr.bin').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=repo, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
            process.wait()
        receipt['actual_process_returncode'] = process.returncode
        receipt['stdout'] = {'path': str(out / 'outer/stdout.bin'), 'bytes': (out / 'outer/stdout.bin').stat().st_size, 'sha256': digest((out / 'outer/stdout.bin').read_bytes())}
        receipt['stderr'] = {'path': str(out / 'outer/stderr.bin'), 'bytes': (out / 'outer/stderr.bin').stat().st_size, 'sha256': digest((out / 'outer/stderr.bin').read_bytes())}
        reaper = [json.loads(line) for line in (out / 'outer/reaper.jsonl').read_text().splitlines()]
        require(reaper and reaper[-1].get('event') == '完成', '原subreaper缺完整回收終態')
        primary = reaper[-1]['primary_returncode']; mapped = primary if primary >= 0 else 128 - primary
        require(mapped == process.returncode, '原subreaper真primary／outer退出碼不符')
        receipt['reaperCompletion'] = reaper[-1]
        result_path = out / 'refresh/RESULT.json'
        if result_path.is_file(): receipt['refreshResult'] = json.loads(result_path.read_text())
        require(process.returncode == 0 and receipt.get('refreshResult', {}).get('passed') is True, '架構重產未完成；保留原非零、raw、FAILED與部分產物')
        receipt['passed'] = True
    except BaseException:
        receipt['errors'].append(traceback.format_exc())
    finally:
        for signum, handler in old_handlers.items(): signal.signal(signum, handler)
        if process is not None and process.poll() is None:
            process.send_signal(signal.SIGTERM)
            try: process.wait(timeout=30)
            except subprocess.TimeoutExpired: process.kill(); process.wait()
        if process is not None: receipt['actual_process_returncode'] = process.returncode
        for path, before in sources.items():
            if digest(Path(path).read_bytes()) != before['sha256']: receipt['errors'].append('driver source changed during execution: ' + path)
        receipt['passed'] = receipt['passed'] and not receipt['errors']
        receipt['finishedUtc'] = now(); receipt['exit_code'] = 0 if receipt['passed'] else 1
        save(out / 'receipt.json', receipt)
        resource.setrlimit(resource.RLIMIT_STACK, (soft, hard))
        if lock is not None: fcntl.flock(lock, fcntl.LOCK_UN); lock.close()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'source_sha': args.sha,
                     'actual_process_returncode': receipt['actual_process_returncode'], 'passed': receipt['passed'],
                     'outputs': receipt['outputsDirectory']}, ensure_ascii=False), flush=True)
    return receipt['exit_code']


if __name__ == '__main__': raise SystemExit(main())
