# 單檔 adapter 靜態核

已直接讀取兩份 adaptation patch、AST parse兩個新工具，未執行工具或任何裁判。原兩檔版 frozen hashes先核同；`ADAPTATION.json`精確列新hash與每個替換。require呼叫數量原樣保留，原三裁判argv、三preflight病因、601／333／268與920／55、oldreceipt封值／上份產物Gitblob／真HEADblobguard、owned全同、完整raw與LFinventory、前後source／external tree守門都未改。

程式邏輯只刪ALLOWED中的cdp_helpers，changed與stale數量2改1。manifest仍原位替換唯一舊hash，還原該欄後深等原manifest。主schema不變，sourceBaseHead仍動態真HEAD；附屬one-exclusion schema與描述只避免錯標兩檔輪。未出現放寬原assert、刪除測試、放寬policy/root/layer/reason或新增exclusion。

此結論是靜態準備完成，不代表候選已採用、P88已修復、三preflight或重產已執行，也不授予把舊F13證據改標新F的權利。實際新source若不只該檔，工具應拒絕並重新評估範圍。
