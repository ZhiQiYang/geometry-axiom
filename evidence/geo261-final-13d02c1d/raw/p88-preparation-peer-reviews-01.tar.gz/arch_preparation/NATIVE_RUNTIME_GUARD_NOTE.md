# 原 native 的 runtime 單元收據角色

本輪不建立「5 freshness cases」名稱，不把P52的五項等待控制混為runtime freshness。F13原native stdout429行為 `py:test_runtime_version 31/31`、435行為 `py:test_serve 51/51`；replay原321行6/6。它們保F13原executionSHA，不稱新F實跑。

`tests/test_runtime_version.py` 的31方法import原 `geometry-web/runtime_version.py`；setUp在全新TEMP產生公理文字、index、app與原static_catalog/application_assets各route fixtures，資料bytes寫在原test source內，測試沒有讀實際repo的grid_rule_lines_test.js。涵蓋新增／刪除、same-size/mtime、併發及列舉等原方法，沒有另發明rename方法或縮成五案。

`collect_runtime_native_guard_identity.py` 是待root在固定新F後實跑的純Git唯讀小addendum。它保存原命令／exit／完整blob bytes／hash／mode，逐一比較F13與新F的兩檔guard及generated-fixture source，列原31個方法；不import、執行或新增任何測試，不改repo／帳本。完整metadata成功的exit0不代表新驗收gate0；結果明寫inherited、currentSHAWasExecuted=false。

```bash
python3 -B /workspace/geo288-main-merge-20261023/p88-architecture-one-file-tools/collect_runtime_native_guard_identity.py \
  --repo /workspace/geometry-axiom \
  --final-sha ACTUAL_NEW_FINAL_FULL_SHA \
  --out /tmp/g288-native-runtime-guard-UNIQUE
```

此兩檔addendum只補31方法的guard／fixture來源身分，不能自稱覆蓋整個native、51個test_serve或6個replay。test_serve初始化真repo server會capture所有runtimebytes，單檔新P88driver的version不同仍須在大closure明列；它不執行driver。replay依原C／harness／scene／archivefixtures的已核大closure另保真同一，不能拿兩檔addendum取代。
