# P88 單一 test-driver exclusion 的 Linux 四檔重產準備

本工具只準備、只做 AST／diff 靜態核對，尚未執行任何裁判、scan、編譯或重產。root 確認單檔候選採用、來源已普通提交為乾淨實際 S 後才可執行；候選不採用就不執行。原 `p88-architecture-tools/` 兩檔版與更早工具全部保留不改。

```bash
python3 -B /workspace/geo288-main-merge-20261023/p88-architecture-one-file-tools/run.py \
  --repo /workspace/geometry-axiom \
  --expected-head ACTUAL_CLEAN_SOURCE_S_FULL_40_HEX_SHA \
  --out /tmp/g288p88arch-one-UNIQUE \
  --heavy-lock /tmp/g261r3/heavy.lock
```

`--sha` 同義；若 source 後已有 evidence publication，就填當時真乾淨 HEAD，不能冒用 F13。out 必須全新且 repo 外。成功後四檔在 `<out>/refresh/new/`；工具不安裝、不改來源、不 commit／push。

## 唯一變更 binding

只容許既有 exclusion `geometry-web/grid_rule_lines_test.js` 的 LF sha256 更新。相對上份 sealed receipt 的完整 changed inputs 集合與 stale exclusions 集合都必須恰為這一條、數量恰1。`cdp_helpers.js`、前輪六個 framing Python、其餘267 exclusions與333 owned來源都不准一起變；有其他變更即拒絕，不能擴白名單。

原 601 executable＝333 owned＋268 excluded、W policy920 identifiers／55 strings、完整roots、standalone、layer、reason、routes、vendor／embed digest保持原契約。manifest只替換唯一舊digest字串，其餘bytes保留；還原此一欄後必須深等原manifest。真正 graph／edges／diagnostics／suite counts仍由原scanner取得，並與前份sealed receipt全同，不手填新通過。

`ADAPTATION.json` 與兩份 `.adaptation.patch` 保存 frozen兩檔版hash、精確替換與新hash。邏輯差分只有ALLOWED移除cdp_helpers、兩個數量2→1；其餘為一檔描述／附屬schema與`onlyOneExistingExclusionSha256Changed`名稱，主receipt仍為原 `geometry-product-architecture-receipt/1`。原require數量、原三裁判argv、old-blob guard、full inventory、sourceBaseHead動態真SHA與所有前後身分守門保留。

## 原三裁判與封印

先在真S保存舊四檔、驗原receipt封值，再讀上份產物commit與當次HEAD的四份Git blob驗同；不能先換manifest偷過blobguard。原三條preflight完整保存原命令、實際退出、stdout／stderr、環境與S。本環境原driver嚴守1／0／5與指定path的EXCLUSION_DIGEST病因；5是setUpClass digest error、Ran0tests，不能說跑過產品18方法。此單檔輪尚未實跑。

再建立repo外完整601inputs與三個原裁判同bytes驗證樹，只換衍生manifest，完整跑原三條，保真cwd／exit；全0且原counts一致才產四檔。來源四檔／原裁判／HEAD／clean／全部raw與LF inputs每階段守同。任何未知紅燈保存FAILED、原red與部分產物，不放寬斷言。

內外層沿原c387錄製器、subreaper、既有heavy lock與16MiB stack，保存真command/stdin/stdout/stderr/returncode/hash/環境/SHA。此工具只證架構契約；正式項受影響範圍見 `SOURCE_IMPACT_STATIC.md`，不能把四檔刷新成功當成P88或其他gate通過。
