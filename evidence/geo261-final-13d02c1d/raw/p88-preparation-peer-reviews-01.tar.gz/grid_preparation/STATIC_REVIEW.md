# Grid 準備的自核範圍

只執行本目錄建立與AST解析，沒有執行新driver、collector、原validator、tests、compiler、Chrome、scan、checkout或clone。新F未知，所以PREPARATION的sourceSHA=null；尚無原job結果。

實際讀取原F13 grid收據schema／原steps與原CDP footer：partial、filter GRID_SYSTEM_ONLY、golden未比較；原356 assertions只是F13歷史事實，不當新F數值門檻。新結果按新footer原值索引。

bound workflow driver只有兩處機械port改動；原三倍診斷watchdog、15分鐘正式時限／over_ci判準、source HEAD/clean守門、Node24/Chrome/font驗證、原workflow完整steps、原filter/golden、shell options與cleanup均原樣。新/原receipt validator完全相同；`index_grid_result.py`沒有造新總裁判。16檔input collector是窄的身分記錄，不冒稱完整runtime／native／fixture closure。

真正global R3資源鎖在精確argv中由flock -n持有；原driver自身鎖為專屬scratch/heavy.lock，不會重複持同一把鎖。埠19784/9634須root確認配給；全新output/TMP由原driver拒絕重用，原profile由原harness生成。工具只接受同真F的clean驗收分支，預備流程不碰integration。

依323代理第一輪建議補外層／proof argv明列解除NODE_OPTIONS與PYTHONOPTIMIZE、before metadata必須完整、解析stdout前比原inventory bytes/hash；這些只封存身分守門，不改產品／原測試判準。尚待323代理完成新版獨立靜審與root提供F／時槽。原core與工具沒有因這份準備而取得任何動態綠燈。
