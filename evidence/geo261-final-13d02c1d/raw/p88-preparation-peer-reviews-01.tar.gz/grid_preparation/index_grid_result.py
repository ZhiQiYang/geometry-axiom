#!/usr/bin/env python3
"""Index original grid facts with the original receipt validator; never run a job."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--job-root', type=Path, required=True)
    parser.add_argument('--outer-receipt', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise RuntimeError('Do not overwrite an original index')
    original = args.job_root / 'receipt.json'
    data = json.loads(original.read_text(encoding='utf-8'))
    outer = json.loads(args.outer_receipt.read_text(encoding='utf-8'))
    result = {'scope': 'original raw receipt/footer indexing only; no new acceptance criterion',
              'sourceSHA': args.sha, 'originalJobExit': data.get('exit_code'),
              'originalOuterExit': outer['outer_process']['actual_process_returncode'],
              'receiptPath': str(original), 'receiptSha256': hashlib.sha256(original.read_bytes()).hexdigest(),
              'ciTimeoutMinutes': data.get('ci_timeout_minutes'), 'seconds': data.get('seconds'),
              'overCiTimeout': data.get('over_ci_timeout'), 'status': data.get('status'),
              'originalReceiptValidated': False, 'originalCDPFooter': None, 'unknown': [], 'errors': []}
    try:
        if outer.get('sha') != args.sha or outer.get('cwd') != str(args.repo.resolve()):
            raise RuntimeError('Outer receipt is not bound to the same actual F and checkout')
        spec = importlib.util.spec_from_file_location('original_grid_receipt_validator', BASE / 'run_acceptance_seven_configured.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        frozen = {'run_workflow_round.py': hashlib.sha256((BASE / 'run_workflow_round.py').read_bytes()).hexdigest()}
        module.validate_receipt(data, {'exit_code': result['originalOuterExit'], 'receipt': str(original)},
                                args.repo.resolve(), args.sha, 'grid', frozen)
        result['originalReceiptValidated'] = True
        browser = next(row['result'] for row in data['steps'] if row['index'] == 3 and 'result' in row)
        stdout_path = Path(browser['stdout'])
        if stdout_path.resolve() != (args.job_root / 'steps/03.stdout').resolve():
            raise RuntimeError('Browser stdout path is not the original grid step output')
        raw = stdout_path.read_bytes()
        saved = data['files']['steps/03.stdout']
        if saved['bytes'] != len(raw) or saved['sha256'] != hashlib.sha256(raw).hexdigest():
            raise RuntimeError('Browser stdout bytes/hash differ from the original receipt inventory')
        footers = [line.removeprefix('CDP_RESULT ') for line in raw.decode('utf-8', 'replace').splitlines()
                   if line.startswith('CDP_RESULT ')]
        result['browserOriginalExit'] = browser['actual_process_returncode']
        result['browserWatchdogExpired'] = browser['watchdog_expired']
        result['browserStdoutSha256'] = hashlib.sha256(raw).hexdigest()
        if len(footers) == 1:
            result['originalCDPFooter'] = json.loads(footers[0])
        else:
            result['unknown'].append('Expected exactly one original CDP_RESULT footer; do not infer full/completed or golden')
    except BaseException as error:
        result['errors'].append(type(error).__name__ + ': ' + str(error))
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'index': str(args.out), 'originalJobExit': result['originalJobExit'],
                      'originalOuterExit': result['originalOuterExit'], 'errors': result['errors']}))
    return 2 if result['errors'] else 0

if __name__ == '__main__':
    raise SystemExit(main())
