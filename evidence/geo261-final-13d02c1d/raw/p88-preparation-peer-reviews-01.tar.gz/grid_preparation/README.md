# 新 final SHA 的獨立 grid 正式 job（準備，未執行）

專屬驗收分支：`codex/geo288-p88-final-grid-20261023`。正文分支：`codex/geo288-p88-final-grid-20261023-prbody`。root尚未提供新F／執行時槽，沒有建立大checkout、沒有執行下面任一driver／collector，也未建置、開Chrome或跑測試。只有本目錄file preparation與AST／diff核對完成。

收到真正已推送、GitHub可解析的新F後，才建立自己的clean checkout，分支HEAD精確等F；只省略根`evidence/`及`tests/evidence/`等不屬runtime roots的出版資料，保留所有geometry-*產品／fixtures／vendor／公開資產。runtime完整性由root的新F大closure另外約束；這裡的16檔collector不冒稱完整runtime inventory。任何source/index修改只准在自己的驗收repo，不碰integration或產品/tests。

## 原步驟與唯一 binding

`original_run_workflow_round.py.txt`是原工具bytes，SHA256 `6a3e3c327687ee6fdafb1044e4c4036f4d2f881a75498af97bd1e1af861e1310`。bound `run_workflow_round.py`的完整差分見`PORT_BINDING.patch`：

1. 本job服務埠固定19784，避免其他job；
2. 原workflow內inline grid CDP9334機械改9634。沒有改browser filter、等待、測試、golden或產品。

`--job grid`會從真F的原workflow讀完整browser/grid矩陣並逐步執行：固定乾淨checkout、`npm run build`、CJK字型實際dpkg安裝狀態檢查、原stack16MiB／Chrome可執行檢查、原start_local與runtime probe、原`GEOMETRY_GRID_SYSTEM_ONLY=1 node geometry-web/cdp_test.js`、原cleanup與適用的grid截圖artifact保存。必要套件已安裝時沿原driver明記「未重複apt、已實際查安裝狀態」，不是假稱apt實跑。所有原run及機械executed run同存。

原正式grid時限仍15分鐘。原driver保留3倍診斷watchdog，但`over_ci_timeout`必須如實列出；原receipt衍生通過規則不接受超正式15分鐘。不能因45分鐘watchdog內exit0就稱CI綠，也不改閾值。原receipt schema仍`geo261-cloud-workflow/1`，原validator的每條assert不變。

grid是partial，原filter為`GEOMETRY_GRID_SYSTEM_ONLY`。它執行P70/P71/P78/P87/P88，不執行完整canvas；原footer的`goldenCompare`應保持其partial真值，不能補稱golden已比對，也不能為grid另加full/golden skip flag。P88新candidate本次被真正require及執行；正式canvas及P88三態由其他專責原件另管。

## 待root填真F後的精確 argv

以下`ACTUAL_NEW_F_FULL_SHA`、`F8`及`ACTUAL_GRID_CHECKOUT`都是待綁定佔位，**不是已執行收據**。用完整新F，不填F13或publication E。出入口目錄全新；不得覆蓋原red／挑選重抽。先確認root配給19784／9634與原R3 heavy lock，slot未到不執行。

先綁定同F重要來源、workflow／golden原bytes：

```bash
env -u NODE_OPTIONS -u PYTHONOPTIMIZE \
python3 -B /workspace/geo288-main-merge-20261023/grid-final-tools/record_grid_inputs.py \
  --repo ACTUAL_GRID_CHECKOUT --sha ACTUAL_NEW_F_FULL_SHA \
  --out /tmp/g288-final-grid-F8/inputs-before
```

原外錄製器及subreaper包覆原job；global R3與job自身scratch鎖是不同鎖，不重複持同一把鎖：

```bash
env -u NODE_OPTIONS -u PYTHONOPTIMIZE \
python3 -B /workspace/geo288-main-merge-20261023/grid-final-tools/execute_f_extra.py \
  --label p88-final-grid-F8 --sha ACTUAL_NEW_F_FULL_SHA --repo ACTUAL_GRID_CHECKOUT \
  --outer-root /workspace/geo288-main-merge-20261023/grid-final-outer -- \
  env -u NODE_OPTIONS -u PYTHONOPTIMIZE flock -n /tmp/g261r3/heavy.lock \
  python3 -B /workspace/geo288-main-merge-20261023/grid-final-tools/run_workflow_round.py \
    --repo ACTUAL_GRID_CHECKOUT --sha ACTUAL_NEW_F_FULL_SHA --job grid \
    --out-root /tmp/g288-final-grid-F8/workflow
```

不要把flock／outer成功當產品成功。原inner收據在`/tmp/g288-final-grid-F8/workflow/grid/receipt.json`；outer與原subcommand streams在`grid-final-outer/p88-final-grid-F8/`。job獨立TMP在`/tmp/g288-final-grid-F8/tmp/workflow/grid/`，profile由原harness在該TMP建立並在原CDP footer留下實際path／pid／cdpPort。環境版本會真查`google-chrome --version`、Node24、Python、cc與fonts-noto-cjk，完整輸出及exit都保存。

無論原job紅或綠，結束後先保存同F的after metadata與原判決索引，才可出版：

```bash
env -u NODE_OPTIONS -u PYTHONOPTIMIZE \
python3 -B /workspace/geo288-main-merge-20261023/grid-final-tools/record_grid_inputs.py \
  --repo ACTUAL_GRID_CHECKOUT --sha ACTUAL_NEW_F_FULL_SHA \
  --out /tmp/g288-final-grid-F8/inputs-after \
  --before /tmp/g288-final-grid-F8/inputs-before/receipt.json
```

```bash
env -u NODE_OPTIONS -u PYTHONOPTIMIZE \
python3 -B /workspace/geo288-main-merge-20261023/grid-final-tools/index_grid_result.py \
  --repo ACTUAL_GRID_CHECKOUT --sha ACTUAL_NEW_F_FULL_SHA \
  --job-root /tmp/g288-final-grid-F8/workflow/grid \
  --outer-receipt /workspace/geo288-main-merge-20261023/grid-final-outer/p88-final-grid-F8/receipt.json \
  --out /tmp/g288-final-grid-F8/ORIGINAL_GRID_INDEX.json
```

index只呼叫byte-identical的原receipt validator與解析原唯一CDP_RESULT；解析前先核stdout仍等原receipt inventory的bytes/hash。原inner/outer/browser exit、時限、scope、sections、failures、skipped、exceptions與golden欄全部按原值保存。它的metadata exit0不是另一個產品gate，也不寫一個新的總綠燈。缺件／未知欄位不能補成通過。current-state矩陣仍依原workflow／outer／browser真exit、原status完成、over_ci_timeout=false與原footer列結果；保partial/filter/golden真值，不用index0代判。

外層及proof argv都明列`env -u NODE_OPTIONS -u PYTHONOPTIMIZE`：前者確保外錄製Python本身不繼承最佳化，後者在原外錄製器的command陣列中留明確解除紀錄，避免harness受外殼注入。input metadata另記兩環境欄的實際值。F綁定檔也保存完整外層argv，不能只口頭稱「環境乾淨」。

## 新F應保存的身分與出版

- 真F：before/after HEAD與clean、branch、Git可解析完整SHA；原workflow bytes/hash；實際source與publication E分欄。
- 本輪P88 testdriver的Gitblob/mode/raw/LFhash；其餘原cdp harness/helpers/floor/golden、grid編輯／system／產品模組、project-store／fflate、start_local／serve／runtime_version與build入口的bytes/hash。`record_grid_inputs.py`明列16檔，前後必須同一F同bytes；這個窄清單不替代root完整source/runtime closure。
- bound driver、原driver、精確port patch、原validator、c387、execute wrapper、subreaper的原bytes/hash；每個原命令、退出、完整stdout/stderr、環境、實際SHA及版本。root提供F後另存新`BINDING_FINAL_F.json`，不覆寫本輪PREPARATION的sourceSHA=null歷史角色。
- 原screenshots／server log／正式ZIP fixtures／命令sidecars照原TMP保存。編譯ELF及Chrome暫存如沿既有publisher排除，必須保原排除理由與hash，不能把原輸出當暫存刪掉。

終態後用既有`publish_followup_progress.py`，指定**自己的repo與分支**、`--issue 288 --sha 真F --label grid-final`，輸入job、job-temp、outer、input-before/after、工具與index，並用`--receipt`保inner原件；先驗逐member bytes/hash後正常commit/push至自己分支`evidence/geo288-final-F8/`。不讓publisher寫integration。正文檔只寫上述`-prbody`分支，列真F／evidence E／原exit與partial scope；root整合證據另處理。不force push、不合併PR。

影響表補充：root最新決定新F另外實跑原`tests/test_serve.py`51方法，保原F13 native收據與31個runtime_version方法的原身份。這不改寫先前frozen靜審文字；本grid流程不代跑或代判那些項目。
