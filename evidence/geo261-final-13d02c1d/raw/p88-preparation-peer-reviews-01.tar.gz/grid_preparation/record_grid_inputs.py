#!/usr/bin/env python3
"""Small explicit file/hash binding, not a complete runtime inventory or gate."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys

FILES = ('.github/workflows/integration-tests.yml', 'package.json', 'tests/binaries.py',
         'geometry-web/cdp_test.js', 'geometry-web/cdp_helpers.js', 'geometry-web/cdp_floor.js',
         'geometry-web/cdp_sections.golden.json', 'geometry-web/grid_rule_lines_test.js',
         'geometry-web/grid_system_test.js', 'geometry-web/grid_rule_editor_test.js',
         'geometry-web/grid-rule-lines.js', 'geometry-web/project-store.js',
         'geometry-web/vendor/fflate/umd/index.js', 'geometry-web/start_local.py',
         'geometry-web/serve.py', 'geometry-web/runtime_version.py')
BRANCH = 'codex/geo288-p88-final-grid-20261023'
BASE = Path(__file__).resolve().parent
CAPTURE = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--before', type=Path)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    if out.exists() or out.is_relative_to(repo):
        raise RuntimeError('Use a fresh external output directory')
    out.mkdir(parents=True)
    digest = lambda raw: hashlib.sha256(raw).hexdigest()
    if digest((BASE / 'capture.py').read_bytes()) != CAPTURE:
        raise RuntimeError('Original recorder hash changed')
    spec = importlib.util.spec_from_file_location('grid_original_capture', BASE / 'capture.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    recorder = module.Recorder(out, env, args.sha)
    result = {'scope': 'explicit grid/workflow/golden file binding only; not a whole runtime closure or new acceptance gate',
              'sha': args.sha, 'repo': str(repo), 'branch': BRANCH, 'commands': recorder.rows,
              'environment': {'platform': platform.platform(), 'python': sys.version, 'PATH': env.get('PATH'),
                              'NODE_OPTIONS': env.get('NODE_OPTIONS'), 'PYTHONOPTIMIZE': env.get('PYTHONOPTIMIZE')},
              'files': [], 'metadataComplete': False, 'errors': []}
    def git(*parts):
        return recorder.run(['git', *parts], cwd=repo, timeout=30)[1]
    try:
        if (len(args.sha) != 40 or git('rev-parse', 'HEAD').decode().strip() != args.sha
                or git('branch', '--show-current').decode().strip() != BRANCH
                or git('status', '--porcelain=v1', '--untracked-files=all')):
            raise RuntimeError('Require the dedicated clean branch at the actual full F')
        for relative in FILES:
            frozen = git('show', args.sha + ':' + relative)
            actual = (repo / relative).read_bytes()
            if frozen != actual:
                raise RuntimeError('Explicit input differs from the fixed Git bytes: ' + relative)
            tree = git('ls-tree', '-z', args.sha, '--', relative)
            result['files'].append({'path': relative, 'bytes': len(actual), 'sha256': digest(actual),
                                    'lfSha256': digest(actual.replace(b'\r\n', b'\n')),
                                    'gitTreeRow': tree.decode().rstrip('\0')})
        if result['files'][0]['sha256'] != 'b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d':
            raise RuntimeError('Workflow bytes changed; review the new workflow before execution')
        if args.before:
            before = json.loads(args.before.read_text(encoding='utf-8'))
            if before.get('metadataComplete') is not True:
                raise RuntimeError('Before metadata did not complete; do not infer its input identity')
            result['beforeReceiptSha256'] = digest(args.before.read_bytes())
            result['sameExplicitInputsBeforeAfter'] = before['sha'] == args.sha and before['files'] == result['files']
            if not result['sameExplicitInputsBeforeAfter']:
                raise RuntimeError('Explicit fixed grid inputs changed during execution')
        result['metadataComplete'] = True
    except BaseException as error:
        result['errors'].append(type(error).__name__ + ': ' + str(error))
    (out / 'receipt.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'metadataComplete': result['metadataComplete']}))
    return 0 if result['metadataComplete'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
