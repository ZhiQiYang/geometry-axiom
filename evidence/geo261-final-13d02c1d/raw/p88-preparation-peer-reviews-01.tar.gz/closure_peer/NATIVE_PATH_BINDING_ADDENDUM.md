# partial native PATH 綁定補審

只核 b8cbbb1e 已審 driver 到 `83d3eedf438ff25fa3cbc7ab7707f1594e031206dd52e23f0125f6f64d8f12f4` 的窄差分；PREPARATION.json 為 `2fb9e203a486a589603e8d582e1e4b06109f06e9c05ec497bcb558e1b53dd9a2`。沒有執行受審工具、版本命令、產品、編譯或測試，也沒有改 live 環境。

未見這次補正的新阻擋。保存的舊 driver SHA256 精確為已審 b8cbbb1e，舊 README hash 亦同；PATH_BINDING.patch 與兩組凍結前後 bytes 獨立重建的 diff 完全相同。差分只加既有環境 bin、繼承 Node parent、原 PATH 依序去重，以及 inherited/actual PATH 說明與記錄；符合原 workflow driver 第229–234行的排序。沒有增加 preload、shim、apt 或其他命令。

原四 selectors／17/3/51/737、14 inputs、原 helper hashes、R3分工、reaper真 primary exit、16MiB、skip／expected／退出判準均不變；頂層可literal解析政策逐欄同。新 PATH 的實際二進位版本仍須由原執行版本命令與原串流確證，本補審不把排序等同於已量得版本。

此結論僅接受準備差分，不是新 F native gate 通過。細項見 NATIVE_PATH_BINDING_CHECKS.json；先前 NATIVE_PARTIAL_PREPARATION_REVIEW.md 的未執行與窄綁定限制全部繼續適用。
