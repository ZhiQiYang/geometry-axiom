# 第二次原樣 canvas 綠燈正文靜審

限定受審正文 SHA256：`b829449ed8a4558e698b1fc369d12e1a107f479bd77104a8e610ffac661ce132`。對比已推 b37cd992，只核本次差分與原收據、streams hash、CDP footer；沒有執行任何產品或測試。

未發現本次差分的錯誤綠標或 SHA／scope 阻擋。矩陣仍唯一，產品 F13 與出版 E1999cbc4 分列；E 相對 F 只有指定 evidence 路徑。除 canvas 一列外，其他矩陣列在 E 連結替換後逐字相同，包含 F2 九項及未跑反證。

原第1次收據 exit1、1071.906340999s，CDP full、completed=false、1502/0、P88 同 predicate fatal、golden 未比較；原第2次 exit0、1754.826396868s，CDP full、completed=true、2267/0、skipped 空、golden matched。兩者 SHA 都是完整 F13、前後 clean、無 watchdog／超 CI 時限；本次只讀原 stdout／stderr bytes 均與 E 上收據 hash 相同。第2次 CDP 原 footer 另有 uncaughtBrowserExceptions=1，保原紀錄；原裁判判決仍是 exit0，此靜審沒有重定義其門檻。

正文保留原紅及重跑1／0，明說一次綠不取代修復、第3次在該快照時尚執行中；沒有把新 F 四套 partial native 等計畫寫成已執行，也沒有冒稱 live PR 正文已更新。根因仍待確證的描述與現有證據範圍一致。

這是快照靜審，不核第3次之後狀態、不重新解包 raw、不重證舊 F2 繼承閉包，也不是對新 F 的驗收。細項見 BODY_AFTER_TWO_RUNS_CHECKS.json。
