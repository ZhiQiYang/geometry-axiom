# P88 單檔差分：runtime／native 繼承閉包獨立對抗審

本審查固定讀取 F13 `13d02c1db7022145a52ee063286a558e595eb212` 的原引用與原 native 輸出、小型 collector 原件。沒有執行兩個受審 collector、產品、測試、scanner、compiler、Chrome或benchmark，沒有修改 source/shared。

結論：找到並已由 root 接受修補的真閉包缺口。P88雖只在 canvas／grid 執行，但不能把原native全部說成 fixture不變；其中三個Python suites與Node正式整組會啟動真repository服務、讀到改變的runtime資產身分。保留F13原native結果，另在新F用原runner實跑下面四個正式分組，是目前已核入口的完整有限補強。

```text
ulimit -s 16384
python3 tests/run_all.py --build --only test_serve --only test_modeling_transport --only test_local_launcher --only node:tests-js
```

這是 **partial native**，不是完整224 suites的新F執行；原expected與原環境／binary guard保留，不自組Node subrunner、不允許缺bridge／model-base後skip當通過。四個原分組的靜態登錄／F13原計數為51／3／17／737。這裡只核選擇與計數，沒有實跑、沒有新增數值門檻。

## 真實缺口與必要新項

| 原suite／入口 | 真引用與判斷 | 處理 |
|---|---|---|
| `py:test_serve`，51 | `tests/test_serve.py:24–31` 每次setUp import真 `serve.py`；`serve.py:25,31` 以真repo根建立RuntimeSnapshot。`test_serve.py:217–227` 比較真 `/runtime`、X-Geometry-Version與根頁meta | 新F跑原51；只有該檔420–453的特定方法另換temproot，不能外推整組 |
| `py:test_modeling_transport`，3 | `tests/test_modeling_transport.py:38–39` 以真ROOT啟動serve；`:94`等真POST走server freshness守門；temp目錄只存log／模型輸出 | 新F跑原3 |
| `py:test_local_launcher`，17 | `tests/test_local_launcher.py:158–220` 的真Linux案例經 `start_local.py` 啟動serve；`:185,197` 真子程序；`:210–211` 明斷runtime.root==真ROOT及fresh，`:214–217` 真mutation/dump。temp只存binary／log | 新F跑原17，不把其餘mocked方法混成全fixture自造 |
| `node:tests-js`，737 | `test_engineering_project_store.js:159`、`test_subdivision_project_store.js:127`、`test_reference_workspace_races.js:853` 都以真ROOT啟動serve。subdivision`:135`斷runtime.fresh；其他真POST仍經server guard | 新F沿原Node整組跑，保原native依賴環境 |

三個Node檔已在 `run_all.py:255,273–274` 原registry，正式suite於`:525–526`要求bridge與model-base。F13原stdout `:397/:401/:435/:446` 分別為 launcher17／transport3／serve51／Node737，全0fail/0skip；所以這些不是僅找到未執行的standalone檔。原runner `:1050–1051` 依suite name substring挑選，四個selectors恰對這四個expected keys。

## 31個 runtime unit tests 的 fixture 確實獨立

已讀 `tests/test_runtime_version.py` 全檔。`:18–30` 每次以TemporaryDirectory建立 `self.root`、自寫index/app／正典／範例與模板fixture；module import只載入原runtime程式，沒有在import時capture真ROOT。

純AST另外列出全部63個 `RuntimeSnapshot/source_version/source_files/static_catalog/application_assets/probe` 呼叫，對資料根的參數全為 `self.root`；31個test methods沒有零參數／預設真ROOT呼叫。callback內的 `root` 是由此snapshot傳入的fixture根。symlink測項的target也在fixture根。據已讀程式，未找到realroot資料例外。

`collect_runtime_native_guard_identity.py` 正確把scope限為這兩個source檔的31方法，明說不取代native／serve／replay閉包。它的`metadataComplete`只代表收集完成，不等於`allGuardAndFixtureSourceBytesIdentical`，也不證明31個tests新跑；消費端必須讀這些分開欄位、method count與原F13收據。不能只看工具exit0或metadataComplete就給新F native綠燈。

## runtime version 的真消費鏈

`runtime_version.py:48–55,136–162` 將web根每個JS的raw bytes納入capture與version，即使檔案是architecture exclusion；`:171–193` freshness每次重讀，`:196–205` 把version注入index／probe比對。

version不只是log：

- `serve.py:364,394–395` 輸出header／runtime；`:414–419` 用fresh守首頁。
- `app.js:496,504,651` 讀meta作 `X-Geometry-Version`；`serve.py:534–538` 對不一致的寫入回409。故新舊version會改變跨服務／舊頁的授權結果，不能宣稱其bytes完全無判斷影響。
- `serve.py:335` 將version與fresh傳進RuleCaseHost；`rule_case_host.py:67,70–74,100–102` 將其納入binding及續用判斷。它是opaque identity／equality守門，未見按P88原始JS的語意、內容片段或hash位元分派公理／幾何。

對同一乾淨新server／新profile，其meta／header／binding會一致採新identity；這不會讓其他job執行P88，但仍是真資料依賴差分。新F重跑canvas／grid之外，沿用assembly／documents／space／timber四個browser的原F13結果，必須保原execution SHA、scope／omitted與上述identity差異，不能聲稱新F實跑或整個runtime closure逐bytes相同。root已決定新F另跑P52與列定四組反證；本審沒有替未執行項判綠。

`cdp_test.js:7133–7134` 的實際P88 require仍只在full canvas／grid filter；documents import該harness時不進require.main，space／timber另一driver。native產品unit讀的是hyphen `grid-rule-lines.js`。未發現另一個原native入口執行underscore P88測試碼。

## standalone 與本次證據界線

`run_all.py` 明列 real-browser gates不在native aggregate，例如issue77／issue116、rule-case／scenario、room-outline各standalone browser，以及 `geometry-web/feedback_resize_observer_test.js`。這些未因本審被執行或認證。它們若啟動serve／跑source-version probe，同樣有opaque identity資料依賴；但不是本次F13 native已跑項，不能把單純在repo找到檔案當成新增正式gate，也不能宣稱本審證明它們全不受影響。

另核 `tests/test_release_gate.py:207–232` 在相關preflight測項用fake module／source1／mock runtime；`test_recorded_api_receipts.py`只AST擷取serve特定函式，不啟動全module。launcher其餘mocked測項與真Linux案例已分列。原 `npm run build` 只是 `start_local.py --build-only`，沒有發現把全部web測試JS當程式執行的新增build入口。

## Collector補正核對與剩餘限制

已核 root 第一份補正：原 `76cff1de4fd6a4a5d93bcbefd83412bb2565653215dc2ef838e5b608a25ef741` bytes保在 `input-delta-serve-correction/`，r2為 `178eb3f3ab797398b9edcc1b14694bd324054b7f759a58448e9e3d24098abfda`。diff只修掉「test_serve全用temporary fixtures」的不真說明並加51 target，沒有改Git identity斷言或冒已執行。上述新增transport／launcher／Node補強應在下一版本required execution與說明一併列入；本審沒有改該工具，沒有碰既有收據。

主collector的Git delta、原receipt/footer來源與manual_dependency_review應一起看；它本身 `tests_executed=false/not_acceptance_gate=true`，不能把passed_identity_guards當受影響gates完成。F2九項繼承仍要精確新例外addendum、保原SHA；P189 source archive確含變更JS，封裝bytes不相同不等於C判斷執行P88。

無法由本次靜態審查證明：實際新F完整Git delta／產物、原raw tar每member、舊服務／profile混用、動態race／負載時序、全部未執行standalone browser，以及任何新F測試退出碼。初步精確search曾誤給不存在的scenario_contexts.py／geometry-web/package.json，原查詢非零不作產品紅燈；後續直接讀真native_context／root package完成釐清。沒有全repo重跑或掃描。

依據與檔案hash、63個fixture-root呼叫、四個正式subset counts見 `CHECKS.json`。結論只覆蓋這次有界source review；根因／修復P88仍須真動態反證與原full-canvas結果。
