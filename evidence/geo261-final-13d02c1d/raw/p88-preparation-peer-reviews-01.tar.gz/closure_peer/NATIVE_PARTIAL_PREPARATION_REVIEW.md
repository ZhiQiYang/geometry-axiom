# 新 F 四套原 native 準備工具對抗靜審

受審 driver SHA256：`b8cbbb1ee9bc62370453b2402bd2a66979068dadace5d204893c0d368738d268`；PREPARATION.json：`282a4d439c287aacbbfe58976aaaccfba4ceb9d7e67c475771d08e7f61c7291d`。只讀 AST／文字／hash；沒有 import 或執行本工具、run_all、編譯、掃描或 Chrome。真新 F 尚未提供。

初審確立一項執行阻擋：原工具沒設定 GEO261_REAPER_LOG，原 reaper 直接讀 os.environ，因此乾淨環境會在 run_all 之前 KeyError，繼承值也可能混入舊輪。owner 已補正；最終版第69–72行強制設定 fresh out/reaper.jsonl，第180–193行保存 bytes/hash、要求唯一 terminal primary_returncode 並核對原信號映射；原 c387 capture 與原 reaper bytes/hash 均未改。第224–227行分列真 primary exit、reaper 程序 exit、metadata／outer exit，沒有把 reaper 信號映射值冒充原測試退出。

最終限定範圍未見剩餘阻擋。原 argv 保 run_all --build 四個 --only；原 F13 registry 對應17／3／51／737逐欄相符。無 --allow-skip、更新 expected 或自組 Node 環境，仍由原 runner 建 binaries／選 suite／清 GEOMETRY／檢查 expected，PARTIAL 與完整 native 範圍分明。固定14具名 inputs、專屬 branch、clean HEAD/root/index 與輸入前後一致的 guard 都有保存；這是窄綁定，README 沒有把14檔稱完整 closure。

stack 為原16MiB；工具拒絕 optimize，清 NODE_OPTIONS/PYTHONOPTIMIZE 並在 receipt 記錄。原 runner 的三個 Python suite 各三個 logs 加 Node 一個，共10個具名 logs，檔名與原 runner 邏輯相符；before/after identity 與 prior_same_identity 保留舊檔可能性，不靠殘留檔推定本輪通過。core／bridge／model-base sidecar 路徑亦與原 registry 相符。reaper、logs、source-after、tools 各段 finally 分開嘗試，紅燈不自動重跑。

本次不核 GitHub 真 F 可解析性、不核尚未產生的輸出／suite摘要／封包／push，不宣告任何 native gate 通過。執行前仍需 root 指定真 F、專屬乾淨 checkout 與資源時槽；執行後須按原 stdout／logs 審四 suite 終態與允許 skip，並核出版包。初版只保留了 PREPARATION.initial.json 的原hash，本報告不宣稱對初版舊 driver 原bytes做過可重建diff。靜審細項見 NATIVE_PARTIAL_PREPARATION_CHECKS.json。
