"""Validate only the supplied two diffs and frozen metadata; never run collectors."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/geo288-main-merge-20261023')
OUT = Path(__file__).resolve().parent
live = BASE / 'input-delta-live-native-correction'
optimize = BASE / 'input-delta-optimize-guard'
live_meta = json.loads((live / 'CORRECTION.json').read_bytes())
opt_meta = json.loads((optimize / 'CORRECTION.json').read_bytes())
before = (live / 'collect_p88_input_delta.py.before').read_bytes()
middle = (optimize / 'collect_p88_input_delta.py.before').read_bytes()
after = (BASE / 'collect_p88_input_delta.py').read_bytes()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(before) == live_meta['old_sha256'] == '178eb3f3ab797398b9edcc1b14694bd324054b7f759a58448e9e3d24098abfda'
assert sha(middle) == live_meta['new_sha256'] == opt_meta['old_sha256']
assert sha(after) == opt_meta['new_sha256'] == 'ca2628c092f32c43363fde75340d840dcacf18e5037db9d50d5a6103e0f849a8'
for old, new, folder in ((before, middle, live), (middle, after, optimize)):
    patch = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True),
                                       fromfile='collect_p88_input_delta.py.before', tofile='collect_p88_input_delta.py'))
    assert patch.encode() == (folder / 'correction.diff').read_bytes()
review = (OUT / 'REVIEW.md').read_bytes()
assert sha(review) == live_meta['basis_review_sha256'] == 'a2bcfaa7898214cbb5a8ae0d1a1d41fe3f0f42b43b3ade7e70773057f1bd3d2e'
tree = ast.parse(after.decode())
fields = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Assign) and len(node.targets) == 1:
        target = node.targets[0]
        if (isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name)
                and target.value.id == 'report' and isinstance(target.slice, ast.Constant)):
            fields[target.slice.value] = node.value
argv = ast.literal_eval(fields['native_partial_argv'])
counts = ast.literal_eval(fields['native_partial_original_counts_by_selector'])
assert argv == ['python3', 'tests/run_all.py', '--build', '--only', 'test_local_launcher',
                '--only', 'test_modeling_transport', '--only', 'test_serve', '--only', 'node:tests-js']
assert counts == {'test_local_launcher': 17, 'test_modeling_transport': 3, 'test_serve': 51, 'node:tests-js': 737}
guard = next(node for node in tree.body if isinstance(node, ast.If))
assert 'sys.flags.optimize' in ast.unparse(guard.test)
assert 'PYTHONOPTIMIZE' in ast.unparse(guard.test)
assert any(isinstance(node, ast.Raise) for node in ast.walk(guard))
assert not any(isinstance(node, ast.Assert) for node in ast.walk(guard))
assert guard.lineno < next(node.lineno for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(target, ast.Name) and target.id == 'parser' for target in node.targets))
old_asserts = sum(isinstance(node, ast.Assert) for node in ast.walk(ast.parse(before.decode())))
new_asserts = sum(isinstance(node, ast.Assert) for node in ast.walk(tree))
assert old_asserts == new_asserts
result = {'schema': 'geo288-p88-final-collector-small-diff-review/1',
          'before_sha256': sha(before), 'intermediate_sha256': sha(middle), 'final_sha256': sha(after),
          'review_sha256': sha(review), 'both_patch_bytes_exact': True,
          'native_partial_argv': argv, 'counts': counts,
          'existing_assert_count_before': old_asserts, 'existing_assert_count_after': new_asserts,
          'explicit_no_optimize_if_raise_before_parser': True,
          'subject_or_tests_or_scanners_executed': False}
(OUT / 'FINAL_COLLECTOR_DIFF_CHECKS.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
