# P88 輸入閉包 collector 最後補正靜審

本次只核對兩步保存的差分、hash 與常值；沒有執行受審 collector、產品、裁判、掃描、編譯或瀏覽器。

- 最終 collector SHA256：`ca2628c092f32c43363fde75340d840dcacf18e5037db9d50d5a6103e0f849a8`。保存版本鏈為 `178eb3f3ab797398b9edcc1b14694bd324054b7f759a58448e9e3d24098abfda` → `ef0609166d4995d5ed8f77b2a8aa00d2ff7fe391e9a2b08eed3a8545bfbed0d8` → 最終版；兩份 correction.diff 均與各自凍結前後 bytes 獨立重建的差分完全相同。
- 原 17 個 assert 均保留；新增 no-optimize 防護是 parser／輸出之前的頂層 `if` 加 `raise RuntimeError`，不依賴 assert，會拒絕 Python optimize 或非空、非 0 的 PYTHONOPTIMIZE。
- 原生補跑 argv 是原 `python3 tests/run_all.py --build` 加四個 `--only`：test_local_launcher、test_modeling_transport、test_serve、node:tests-js；原計數依序為 17／3／51／737。這是部分補跑，沒有把原 F13 全 native 收據改標新 SHA。
- live_snapshot_dependency_review 綁定的原獨立報告 SHA256 `a2bcfaa7898214cbb5a8ae0d1a1d41fe3f0f42b43b3ade7e70773057f1bd3d2e` 與實檔相符；補正明列真實 identity／freshness 依賴，沒有稱為只影響日誌。

本次限定差分未見新阻擋。僅自己的 AST／diff 檢查程式 `check_final_collector_diff.py` 執行退出碼 0；詳見 FINAL_COLLECTOR_DIFF_CHECKS.json。這是 metadata 靜審，不是任何新產品 gate 的通過收據；collector 與四套 native 仍需按固定的新 F 真實執行。
