"""Record an exact F13-to-final input delta, retaining original gate provenance."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE') not in (None, '', '0'):
    raise RuntimeError('Input identity assertions must remain enabled; optimized Python is unsupported')

F13 = '13d02c1db7022145a52ee063286a558e595eb212'
F2 = '8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
P88 = 'geometry-web/grid_rule_lines_test.js'
DERIVED = {
    'geometry-core/domain-decoupling/product-architecture.json',
    'geometry-core/domain-decoupling/product-architecture-scan.json',
    'geometry-core/domain-decoupling/product-architecture-receipt.json',
    'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',
}
BASE = Path('/workspace/geo288-main-merge-20261023')
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_HASH = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--new-sha', required=True)
parser.add_argument('--evidence-head', required=True)
parser.add_argument('--out', required=True, type=Path)
a = parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}', a.new_sha) and a.new_sha != F13
assert re.fullmatch('[0-9a-f]{40}', a.evidence_head)
repo, out = a.repo.resolve(), a.out.resolve()
assert not out.exists() and not out.is_relative_to(repo) and not repo.is_relative_to(out)
assert digest(CAPTURE) == CAPTURE_HASH
spec = importlib.util.spec_from_file_location('p88_delta_original_capture', CAPTURE)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
out.mkdir(parents=True)
environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1', PYTHONDONTWRITEBYTECODE='1', LANG='C.UTF-8', LC_ALL='C.UTF-8')
r = capture.Recorder(out, environment, a.new_sha)
report = {'schema': 'geo288-p88-input-delta/1', 'new_product_sha': a.new_sha,
          'prior_actual_execution_sha': F13, 'evidence_head': a.evidence_head,
          'not_acceptance_gate': True, 'tests_executed': False,
          'tool_sha256': digest(__file__), 'errors': [], 'passed_identity_guards': False,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
def git(*args):
    row, stdout, stderr = r.run(['git', *args], cwd=repo, timeout=120, check=True, source_variant='read-only-git-input-identity')
    return stdout
def inventory(sha):
    result = {}
    for item in git('ls-tree', '-rz', '--full-tree', sha).split(b'\0'):
        if not item:
            continue
        header, path = item.split(b'\t', 1)
        mode, kind, oid = header.decode('ascii').split()
        result[path.decode('utf-8', 'surrogateescape')] = {'mode': mode, 'type': kind, 'oid': oid}
    return result
try:
    for sha in (F13, a.new_sha, a.evidence_head):
        assert git('rev-parse', sha + '^{commit}').decode().strip() == sha
    git('merge-base', '--is-ancestor', F13, a.new_sha)
    git('merge-base', '--is-ancestor', a.new_sha, a.evidence_head)
    report['ancestry'] = {'F13_is_ancestor_of_new_product': True, 'new_product_is_ancestor_of_evidence_head': True}
    before, after, evidence = inventory(F13), inventory(a.new_sha), inventory(a.evidence_head)
    changed = [{'path': path, 'before': before.get(path), 'after': after.get(path)} for path in sorted(before.keys() | after.keys()) if before.get(path) != after.get(path)]
    publication_prefix = 'evidence/geo261-final-13d02c1d/'
    source_changes = [row for row in changed if not row['path'].startswith(publication_prefix)]
    report['all_changed_paths'] = changed
    report['nonpublication_changed_paths'] = source_changes
    assert {row['path'] for row in source_changes} == DERIVED | {P88}, 'unexpected source, test, policy, fixture, or receipt change'
    assert before[P88]['mode'] == after[P88]['mode'] == '100644'
    assert before[P88]['type'] == after[P88]['type'] == 'blob'
    assert before[P88]['oid'] != after[P88]['oid']
    for path in before:
        if path.startswith(publication_prefix):
            assert before[path] == after.get(path), ('prior published evidence changed', path)
    evidence_delta = [path for path in sorted(after.keys() | evidence.keys()) if after.get(path) != evidence.get(path)]
    assert all(path.startswith('evidence/geo261-final-' + a.new_sha[:8] + '/') for path in evidence_delta), 'new evidence head changes product or prior evidence'
    report['evidence_only_delta'] = evidence_delta
    report['runtime_identity_change'] = {
        'path': P88, 'old_git_blob': before[P88]['oid'], 'new_git_blob': after[P88]['oid'],
        'old_sha256': hashlib.sha256(git('show', F13 + ':' + P88)).hexdigest(),
        'new_sha256': hashlib.sha256(git('show', a.new_sha + ':' + P88)).hexdigest(),
        'meaning': 'RuntimeSnapshot includes raw bytes, so version changes. This is not a claim of identical runtime identity or a new execution.',
    }
    report['inherited_F13_original_results'] = []
    for job in ('native', 'assembly', 'documents', 'space', 'timber'):
        path = Path('/tmp/g288s7/workflow') / job / 'receipt.json'
        original = json.loads(path.read_bytes())
        assert original['sha'] == F13 and original['exit_code'] == 0 and not original['over_ci_timeout']
        assert original['checkout_before']['head'] == original['checkout_after']['head'] == F13
        assert original['checkout_before']['status'] == original['checkout_after']['status'] == ''
        report['inherited_F13_original_results'].append({'job': job, 'execution_sha_unchanged': F13,
            'original_receipt_path': str(path), 'original_receipt_sha256': digest(path),
            'original_exit': original['exit_code'], 'original_seconds': original['seconds'],
            'scope': 'Original job scope and omissions remain exactly those in its footer; no P88 execution is inferred.'})
    chain = BASE / 'closure-final-13d02c1d/CLOSURE_IDENTITY.json'
    original_chain = json.loads(chain.read_bytes())
    assert original_chain['new_source_sha'] == F13 and original_chain['old_actual_test_source_sha'] == F2
    assert original_chain['repository_superset']['identical'] and original_chain['old_evidence_preserved']['identical']
    assert len(original_chain['inherited_original_results']) == 9
    report['F2_inheritance_chain'] = {'original_metadata_path': str(chain), 'original_metadata_sha256': digest(chain),
        'new_exception': P88, 'original_results_unmodified': original_chain['inherited_original_results'],
        'scope': 'The one JS delta is not executed by these nine judgments; original F2 execution identities remain. P189 source archive contains the JS and is explicitly not byte-identical.'}
    report['manual_dependency_review'] = {'path': str(BASE / 'p88-architecture-one-file-tools/SOURCE_IMPACT_STATIC.md'),
        'sha256': digest(BASE / 'p88-architecture-one-file-tools/SOURCE_IMPACT_STATIC.md')}
    report['required_new_execution'] = ['canvas', 'grid', 'original run_all.py partial: test_local_launcher, test_modeling_transport, test_serve, node:tests-js (real repository RuntimeSnapshot input changes)', 'mutation check', 'architecture three original judges', 'four listed counterproof groups']
    report['limitations'] = ['Git identity proves tracked byte identity only; this collector does not execute tests.',
        'New F canvas/grid and architecture results must be supplied separately.',
        'Native test_runtime_version 31 original tests use temporary fixtures; its original execution retains F13. Real-repository RuntimeSnapshot consumers test_local_launcher (17), test_modeling_transport (3), test_serve (51), and node:tests-js (737) must be rerun through the original runner on new F. The original whole-native F13 result is retained with these four affected suites and architecture targets separately re-executed, never relabelled as a full new native run.',
        'External proof tools, original command streams and source-version records stay bound to their original receipts.']
    live_review = Path('/workspace/geo299316-refresh-20261023/p88-input-closure-review/REVIEW.md')
    report['live_snapshot_dependency_review'] = {'path': str(live_review), 'sha256': digest(live_review),
        'meaning': 'The changed JS bytes affect real runtime identity and freshness/version checks; P88 JavaScript is executed by canvas/grid only among the six original browser jobs. No claim that identity is merely a log field.'}
    report['native_partial_argv'] = ['python3', 'tests/run_all.py', '--build', '--only', 'test_local_launcher', '--only', 'test_modeling_transport', '--only', 'test_serve', '--only', 'node:tests-js']
    report['native_partial_original_counts_by_selector'] = {'test_local_launcher': 17, 'test_modeling_transport': 3, 'test_serve': 51, 'node:tests-js': 737}
    report['passed_identity_guards'] = True
except Exception as error:
    import traceback
    report['errors'].append(traceback.format_exc())
finally:
    report['commands'] = r.rows
    report['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    capture.dump(out / 'receipt.json', report)
print(json.dumps({'passed_identity_guards': report['passed_identity_guards'], 'not_acceptance_gate': True, 'errors': report['errors']}, ensure_ascii=False))
raise SystemExit(0 if report['passed_identity_guards'] else 1)
