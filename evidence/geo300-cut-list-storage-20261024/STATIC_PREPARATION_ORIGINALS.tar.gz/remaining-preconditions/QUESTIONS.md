# 待政策或實測決定（本輪不中斷其他工作）

1. 10/20 的 N128/256/512≤2×留言為提案；在容量source與main相同容量實作未完成前，不能冒正式已採gate。保守作法：先執既有P189 N16/32/48/64；額外點只報觀測，root依已鎖authority處理，不自定新ratio。
2. 舊草稿2MiB餘裕只是估算，保持16MiB原契約；不採新stack門檻，不砍controls或延長限時。
3. cut-list公開C結構的外部consumer未知。保守以自有ID pool＋offset維持按值self-contained，原repo consumers全同步且CLI逐bytes等價；不宣稱ABI完全不變。

全部為計畫，沒有新的產品/效能結果。
