# GEO-300 前置核對與下一步（僅靜態）

固定產品 S `ccfaf057088a80c7aad4049f1c67e5eedfc2fdec`；#343 已交 E `a934a554ae58f16f124f1b264523947f170b3f0b`／D `56ed8d0090449e09938e9c63c54aec7fda789380`。本輪沒有改 source、expected、帳本、架構、分支或執行 subject。`COMMANDS.json` 保存 fresh issue 與 Git blobs 原命令/退出/完整 streams；純 Python AST/文件生成另為 host 工具觀測，不冒正式測試。

## 來源與適用界線

- Fresh GitHub issue #300 正文及唯一留言：4775 bytes，SHA256 `9e44a6d2fa5f82e72b41e981d642441c898cf15851fb185d4ee9d743cdc81d13`，updatedAt 2026-10-20T09:27:09Z。留言的 6.6×／7.3× 呼叫成長為 10/20 舊 profile，不是本 S 數據。
- 本輪 main 觀測為 `425c092eaf16f90256d76433243baebde45163ac`；S 的 queue/SSOT 與 main 不同，分存並釘 hash於 SOURCE_INDEX，不聲稱本 S 已採 main 的全部條文。兩邊 FIELD-RULES 完整 bytes 同（SHA256 `3305d8000af9814b91c2646cfcbbc841e1ead813fe3390e482f8bfc2a71c0ab2`）；不得改公理/決策或依文件推論新政策。
- 已讀指定 10/12–15、10/22–24 決策與 FIELD 規則的既有 authority；本輪又保存完整 queue/SSOT，針對具名容量/前置規則核對。沒有聲稱把整份 238KB queue 每句重新逐字審核。
- handoff 固定 `48e82e72c2ee62d83edb9a8777acad2326ccace6`。舊 DESIGN/TESTS 明載基底 09ab、bench 基底603e；不能盲套。首次本地缺 object 的 Git128 原件保留；後來 fetch --no-write-fetch-head 同固定 commit 成功，只補 object DB、不改 refs/FETCH_HEAD/source/index。
- 318 的只讀熱點報告 SHA256 `11a0bdd40e97b9820c41baf8dd4c768d0f9a119bee368328e2112651eef7094a` 是本輪起點；本輪另核 immutable K/W/H blobs，不重造其分析。

## 不另做 geo_eval_depend 索引

`geometry-core/kernel/source.c:35–118,185–216,264–283` 已有節點完整身分 hash（provider、key_size、全部 key bytes）、edge 三元組 hash（consumer/source/kind）、256 hint、倍增陣列與 index rehash。陣列仍按首次出現次序 append，hash 只挑槽，不是身分。

可選 index 配置失敗會退回原線性 lookup；倍增 realloc 失敗再嘗試舊 count+1 尺寸，不擴大 MEMORY 條件。這些 OOM fallback 理論仍可平方，但不能因追求界限改失敗語意。provider register_many 有逐對重複檢查與整表copy，新 node 有 token 線性 lookup；目前 H provider 是固定來源家族，未證 P 隨角材 N 成長，不能當成本輪 load 主瓶頸。

`geo_eval_source` 在有效快取返回前仍建立當下 consumer 的依賴邊。H `reference_sources.inc:648–659` 已對同候選的 successful footprint memo 呼叫 geo_eval_depend 再複用幾何；不可刪成「已算過就直接回傳」，否則不同 consumer/kind 會遺失有序邊。呼叫次數本身不被 hash 消除，需要本 S 新 profile 才能判其剩餘成本。

W `contact_world.c` 的 bounded ContactOrderIndex 保 duplicate last/min；正常 unique/bounded 排序與覆蓋已是 #343 索引。duplicate/overflow 原 insertion/face-pair fallback 仍平方，保留其原語意。#341 只移除重複 memmove，不代表整個 collector 全情況 O(F log F)。本輪沒有足夠新證據支持開 `geo300-eval-depend` 產品分支。

## 待執行的同 S 八正例等價撤回

本輪只準備 `WHOLE_FAST_PATH_WITHDRAW.patch`／`WHOLE_FAST_PATH_PREPARATION.json`，沒有 apply。唯一替換 contact_order_index 初始化 `index->unique=true` → false，使原 insertion sort 與原 dedup fallback 同時運作；保 hash last/min、#341 active compaction、#323 memo。

不可沿舊 S1ee 的 dedup eligibility → if(false)：新 S 的 sort 已在 indexed_dedup 內，單撤 dedup 會同時略過必要排序。八個原 WoodContactWorld 正例的精確 argv 見 JSON，baseline/withdrawn/restored 預期 0/0/0，排除 controls meta-test；不是 killed、不是完整12方法/64controls。保持原16MiB、所有 case timeout、完整 native/compile streams、source/index 還原。須 root 授槽與乾淨 snapshot 才執行。

## 同 S 效能與容量512

既有正式 P-189 保持：main adbaebf9c73ea6801d7b4d5214e4b846b132923b／base3e600772／本 S 三方交錯，N16/32/48/64，各點 fix/main≤2且 loadfile+dump 逐 bytes 同。需要 root 已受審三方正式 driver 綁本 S；本輪只讀 handoff 原 scale_compare.sh/scale_compare2.py/load_profile.sh，沒有執行或改限時。原 scale_compare2 只量 loadfile、不比 dump、也不因 ratio>2 exit非0，不能單獨稱完整 P-189。原 gprof 採 -O1 -fno-inline -pg，不能拿 profile 時間代 O2 正式量測。三方完整 argv 由既有正式工具供給後再釘，不自製替代裁判。

N128/256/512≤2× 是 10/20 留言提案，不自採為新正式門檻。現五產品常數皆64，512 功能不能在本 S 上宣稱通過。後續容量實作須統一 W 容量來源及 alias/binding、N正邊界/N+1負邊界、#297 原探針與原16MiB。參考線16/空間4維持另單。

舊草稿未核可的 2MiB margin/`3S−2MiB` 自造 stack gate、因耗時砍 HOST_CONTROLS、延長 timeout/BENCH_BUDGET，均不採。原控制/判準全留。

## 最小下一產品 leaf 建議：cut-list 線性儲存

只提案，未實作/建 branch。`cut_list.h` 的 N groups 各自再含 ids[N]，H print_cut_list 把整份報表放 stack，確有 O(N²)儲存。針對 C/H/Python（排原 evidence）不可變 Git 搜尋，本 repo 已見 consumers 是 W header/C、H print_cut_list、原 report-policy harness/Python；不能據此宣稱沒有外部 API consumer。

建議 group 存 first/count，WoodCutList 自有總 N 個 ID pool；不放指向 transient 原members/外部buffer的指標，保按值複製 self-contained。group規格排序仍原 length降、a升、b升、role升；群內ID按原宣告次序；unplaced忽略；所有invalid在改out前拒絕。可用先分群/排序metadata，再分配每群連續offset並以原members次序填池；不新增大陣列。這只解 storage O(N²)，原group查找/排序時間仍 O(N²)，不冒已解所有超線性。

預計檔案：W cut_list.{c,h}、H current_geometry.c::print_cut_list、原 tests/geo261_report_policy_harness.c／test_geo261_wood_report_policy.py。容量常數、K、SSOT不動；expected若新增真方法，由 root 排共享棒才登記。另開自有新分支/固定新 S，不能把新產品改動混成 #343 原實跑。

需保原8方法與4控制（participation/role/fixity/CLI sorting），所有既有 CHECK/原 CLI 精確中文 report。新增正例：零/全相同群/全部不同群/交錯同規格非單調ID/同a,b交換及role排序/按值copy自含/原64滿容量。新增負例：pool offset重疊→精確ID斷言；群內逆序→原ID順序斷言；移除N+1guard需不做越界寫才拒→原out atomic斷言；恢復每group N array只以既有結構/資源契約驗證，不捏造語意紅。容量512階段另保legacy64正例並加真512/513，不能只把64literal替換成cap鏡像。

## 狀態

本輪只有讀取、AST及外部準備；無新 C/Node/browser/perf/ledger/架構/512/whole-opt 實跑。原 #343 Sccfaf 的34方法/64controls/318 builds與tuple局部0/1/0保原SHA，不能換貼新來源。root native/documents 期間不做 heavy；待 root 選下一 leaf 或授既有驗收槽。全部未核可新數字寫 QUESTIONS，不向使用者重問鎖定決策。
