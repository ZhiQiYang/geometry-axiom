"""Resume only the already-staged exact candidate after the repository allowlist exit."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os

HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/geo300-contact-index-work')
OUT=HERE/'source-publication'
BASE='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
BRANCH='codex/geo300-cut-list-storage-20261024'
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,message):
    if not ok:raise RuntimeError(message)
manifest=json.loads((HERE/'MANIFEST.json').read_bytes())
need(h((HERE/'MANIFEST.json').read_bytes())=='09c97c1e6bcc8235c1a1135e6f2afd01048dd0b1c2e858fb41d59220842ee988','frozen candidate')
spec=importlib.util.spec_from_file_location('resume_c387','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
r=c.Recorder(OUT,dict(os.environ),BASE)
r.rows=json.loads((OUT/'COMMANDS.json').read_bytes())
report=json.loads((OUT/'PUBLICATION.initial-add-ignored.json').read_bytes())
report['commands']=r.rows
report['metadata_failure_retained']={'command_directory':str(OUT/'subcommands/000015'),'original_exit':1,'classification':'existing repository ignore allowlist; exact five tracked candidate files retained; no subject execution'}
current=BASE
def run(argv):return r.run(argv,cwd=ROOT,timeout=120,source_sha=current,source_variant='source-publication-after-allowlist-exit')
try:
    _,head,_=run(['git','rev-parse','HEAD']);need(head.decode().strip()==BASE,'original parent required')
    _,branch,_=run(['git','branch','--show-current']);need(branch.decode().strip()==BRANCH,'exact new owner branch required')
    _,names,_=run(['git','diff','--cached','--name-only','-z'])
    need(set(names.decode().rstrip('\0').split('\0'))=={x['path']for x in manifest['files']},'exact staged file set')
    _,unstaged,_=run(['git','diff','--name-only','-z']);need(unstaged==b'','no unstaged source mutation')
    for item in manifest['files']:
        _,blob,_=run(['git','show',':'+item['path']]);need(h(blob)==item['after_sha256'],'exact staged candidate '+item['path'])
    run(['git','add','-f','--',*[x['path']for x in manifest['files']]])
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','perf(GEO-300): store cut-list IDs once per report'])
    _,head,_=run(['git','rev-parse','HEAD']);current=head.decode().strip();report['source_sha']=current
    _,parent,_=run(['git','rev-parse','HEAD^']);need(parent.decode().strip()==BASE,'exact single parent')
    _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);need(status==b'','clean committed source')
    run(['git','push','origin','HEAD:refs/heads/'+BRANCH])
    _,remote,_=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]);need(remote.decode().split()==[current,'refs/heads/'+BRANCH],'exact public full SHA')
    report['exit_code']=0
finally:
    (OUT/'PUBLICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'COMMANDS.json').write_text(json.dumps(r.rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'branch':BRANCH,'source_sha':current,'normal_push':True,'exit_code':0,'subject':'UNRUN'},ensure_ascii=False))
