"""Prepare immutable cut-list storage candidates without touching the Git checkout."""
from pathlib import Path
import ast
import difflib
import hashlib
import importlib.util
import json
import os

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/geo300-contact-index-work')
SOURCE = 'ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
FILES = [
    'geometry-templates/woodworking/native/cut_list.h',
    'geometry-templates/woodworking/native/cut_list.c',
    'current_geometry.c',
    'tests/geo261_report_policy_harness.c',
    'tests/test_geo261_wood_report_policy.py',
]

def sha(data): return hashlib.sha256(data).hexdigest()
def replace_once(data, before, after):
    assert data.count(before) == 1, (before, data.count(before))
    return data.replace(before, after)

spec = importlib.util.spec_from_file_location('cut_list_c387', CAPTURE)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
rec = cap.Recorder(HERE, dict(os.environ), SOURCE)
before = {}
for name in FILES:
    row, data, stderr = rec.run(['git', 'show', SOURCE + ':' + name], cwd=ROOT, timeout=30)
    before[name] = data
    path = HERE / 'before' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
after = dict(before)

name = FILES[0]
after[name] = replace_once(after[name], b'    size_t count;\n    uint32_t ids[WOOD_CUT_LIST_MEMBER_CAPACITY];',
    b'    size_t first,count;')
after[name] = replace_once(after[name], b'    WoodCutGroup groups[WOOD_CUT_LIST_MEMBER_CAPACITY];\n',
    b'    WoodCutGroup groups[WOOD_CUT_LIST_MEMBER_CAPACITY];\n'
    b'    /* Owned once per report; offsets remain valid when the report is copied. */\n'
    b'    uint32_t ids[WOOD_CUT_LIST_MEMBER_CAPACITY];\n')

name = FILES[1]
after[name] = replace_once(after[name], b'        out->groups[g].ids[out->groups[g].count++]=member->id;',
    b'        ++out->groups[g].count;')
after[name] = replace_once(after[name], b'    return true;\n}', b'''    /* The sorted groups own disjoint slices of one report-local ID pool.
     * Revisit declarations to fill every slice in the original ID order. */
    size_t first=0;
    for(size_t g=0;g<out->group_count;++g){WoodCutGroup *group=&out->groups[g];
        group->first=first;first+=group->count;group->count=0;
    }
    for(size_t i=0;i<count;++i){const WoodMember *member=&members[i];
        if(member->placed){
            for(size_t g=0;g<out->group_count;++g){WoodCutGroup *group=&out->groups[g];
                if(group->length!=member->length||group->size_a!=member->size_a||
                    group->size_b!=member->size_b||group->role!=member->role)continue;
                out->ids[group->first+group->count++]=member->id;break;
            }
        }
    }
    return true;
}''')

name = FILES[2]
after[name] = replace_once(after[name], b'groups[g].ids[k]', b'report.ids[groups[g].first+k]')

name = FILES[3]
changes = {
    b'result.groups[0].ids[0]': b'result.ids[result.groups[0].first+0]',
    b'result.groups[0].ids[1]': b'result.ids[result.groups[0].first+1]',
    b'result.groups[i].ids[0]': b'result.ids[result.groups[i].first]',
    b'result.groups[0].ids[63]': b'result.ids[result.groups[0].first+63]',
}
for old, new in changes.items():
    after[name] = replace_once(after[name], old, new)
pool = b'''static int pool(void)
{
    WoodMember values[]={member(900,30,20,30,WOOD_MEMBER_ROLE_PRIMARY,true),
        member(3,100,20,30,WOOD_MEMBER_ROLE_PRIMARY,true),
        member(700,30,20,30,WOOD_MEMBER_ROLE_PRIMARY,true),
        member(2,100,20,30,WOOD_MEMBER_ROLE_PRIMARY,true),
        member(41,60,20,30,WOOD_MEMBER_ROLE_SECONDARY,true),
        member(88,30,20,30,WOOD_MEMBER_ROLE_PRIMARY,false)};
    WoodCutList result;CHECK(wood_cut_list_collect(values,6,&result),"report-pool-collect");
    CHECK(result.group_count==3&&result.placed==5&&result.total_length==320,"report-pool-groups");
    CHECK(result.groups[0].first==0&&result.groups[0].count==2&&
        result.groups[1].first==2&&result.groups[1].count==1&&
        result.groups[2].first==3&&result.groups[2].count==2,"report-pool-offsets");
    const uint32_t expected[]={3,2,41,900,700};
    for(size_t i=0;i<5;++i)CHECK(result.ids[i]==expected[i],"report-pool-id-order");
    WoodCutList copy=result;memset(&result,0,sizeof result);memset(values,0,sizeof values);
    CHECK(copy.groups[2].first==3&&copy.groups[2].count==2&&copy.placed==5,"report-copy-metadata");
    for(size_t i=0;i<5;++i)CHECK(copy.ids[i]==expected[i],"report-copy-owned-ids");
    CHECK(sizeof(WoodCutGroup)<=3*sizeof(GeoCoord)+sizeof(WoodMemberRole)+
        2*sizeof(size_t)+sizeof(GeoCoord)+sizeof(size_t),"report-group-linear-storage");
    CHECK(sizeof(WoodCutList)<=sizeof(copy.groups)+sizeof(copy.ids)+
        2*sizeof(size_t)+sizeof(GeoCoord)+sizeof(GeoCoord)+sizeof(size_t),"report-total-linear-storage");
    WoodMember distinct[WOOD_CUT_LIST_MEMBER_CAPACITY];
    for(size_t i=0;i<WOOD_CUT_LIST_MEMBER_CAPACITY;++i)
        distinct[i]=member((uint32_t)(WOOD_CUT_LIST_MEMBER_CAPACITY-i),(GeoCoord)(i+1),20,30,WOOD_MEMBER_ROLE_PRIMARY,true);
    CHECK(wood_cut_list_collect(distinct,WOOD_CUT_LIST_MEMBER_CAPACITY,&result)&&
        result.group_count==WOOD_CUT_LIST_MEMBER_CAPACITY&&result.placed==WOOD_CUT_LIST_MEMBER_CAPACITY,"report-pool-all-groups");
    for(size_t i=0;i<WOOD_CUT_LIST_MEMBER_CAPACITY;++i){
        CHECK(result.groups[i].first==i&&result.groups[i].count==1,"report-pool-full-offsets");
        CHECK(result.ids[i]==(uint32_t)(i+1),"report-pool-full-id-order");
    }
    return 0;
}
'''
after[name] = replace_once(after[name], b'static int fixity(void)\n', pool + b'static int fixity(void)\n')
after[name] = replace_once(after[name], b'if(!strcmp(argv[1],"fixity"))return fixity();return 2;',
    b'if(!strcmp(argv[1],"fixity"))return fixity();if(!strcmp(argv[1],"pool"))return pool();return 2;')

name = FILES[4]
methods = '''    def test_owned_id_pool_preserves_interleaved_groups_full_capacity_and_value_copy(self):
        self.case("pool")

    def test_pool_offsets_values_declaration_order_and_exact_capacity_controls_fail_named_assertions(self):
        controls=[
            ("report-pool-offset", "group->first=first;first+=group->count;group->count=0;",
                "group->first=0;first+=group->count;group->count=0;", "pool", "report-pool-offsets"),
            ("report-pool-value", "out->ids[group->first+group->count++]=member->id;",
                "out->ids[group->first+group->count++]=0;", "pool", "report-pool-id-order"),
            ("report-pool-reverse", "for(size_t i=0;i<count;++i){const WoodMember *member=&members[i];\\n        if(member->placed){",
                "for(size_t remaining=count;remaining;--remaining){const WoodMember *member=&members[remaining-1];\\n        if(member->placed){", "pool", "report-pool-id-order"),
            ("report-exact-capacity", "count>WOOD_CUT_LIST_MEMBER_CAPACITY)return false;",
                "count>=WOOD_CUT_LIST_MEMBER_CAPACITY)return false;", "limits", "report-capacity"),
        ]
        for name,before,after,case,marker in controls:
            with self.subTest(control=name):
                self.case(case);exe,_=self.mutant("cut_list",name,before,after)
                self.case(case,exe,marker);self.case(case)

    def test_group_quadratic_id_storage_control_fails_without_changing_report_values(self):
        build=native();header=build.woodworking/"cut_list.h";original=header.read_bytes()
        before=b"    size_t first,count;";after=before+b"\\n    uint32_t legacy_ids[WOOD_CUT_LIST_MEMBER_CAPACITY];"
        self.assertEqual(1,original.count(before),"Control must replace exactly one production expression")
        self.case("pool")
        try:
            header.write_bytes(original.replace(before,after))
            source=build.woodworking/"report-storage-client.c"
            shutil.copy2(ROOT/"tests/geo261_report_policy_harness.c",source)
            client=build.compile(source,"report-storage-client")
            cut=build.compile(build.woodworking/"cut_list.c","report-storage-cut")
            exe=build.link("report-storage-control",[client,cut,build.wood_boundary_policy_object])
            self.case("pool",exe,"report-group-linear-storage")
        finally:
            header.write_bytes(original)
        self.assertEqual(original,header.read_bytes())
        self.case("pool")

'''
after[name] = replace_once(after[name], b'    def cli_report(self,exe):\n', methods.encode() + b'    def cli_report(self,exe):\n')

rows = []
patch = bytearray()
for name in FILES:
    data = after[name]
    path = HERE / 'candidate' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    patch.extend(''.join(difflib.unified_diff(before[name].decode().splitlines(True), data.decode().splitlines(True),
        fromfile='a/'+name, tofile='b/'+name)).encode())
    rows.append({'path':name,'before_bytes':len(before[name]),'before_sha256':sha(before[name]),
        'after_bytes':len(data),'after_sha256':sha(data)})
(HERE/'CUT_LIST_STORAGE.patch').write_bytes(patch)
tree = ast.parse(after[FILES[4]])
test_methods = [n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(test_methods)==11, test_methods
manifest = {'schema':'geo300-cut-list-storage-candidate/1','base_source_sha':SOURCE,
    'branch':'codex/geo300-cut-list-storage-20261024','files':rows,'patch_sha256':sha(patch),
    'methods':11,'new_methods':3,'controls':9,'new_controls':5,'capacity':64,
    'expected_file_changed':False,'global_ledger_changed':False,'source_branch_modified':False,
    'subject_execution':'UNRUN','performance':'UNMEASURED','asymptotic_scope':'O(N) ID storage; existing O(N²) grouping and sorting time retained',
    'test_methods':test_methods}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(HERE/'COMMANDS.json').write_text(json.dumps(rec.rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha((HERE/'MANIFEST.json').read_bytes()),'patch_sha256':sha(patch),'files':len(rows),'methods':len(test_methods),'subject':'UNRUN'},ensure_ascii=False))
