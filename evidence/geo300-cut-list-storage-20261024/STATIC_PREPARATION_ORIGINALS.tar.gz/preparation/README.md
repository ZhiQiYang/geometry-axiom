# GEO-300 cut-list 線性儲存候選

基底 Sccfaf057088a80c7aad4049f1c67e5eedfc2fdec。這是新獨立 leaf，沒有套回已驗 #343；唯一候選 branch codex/geo300-cut-list-storage-20261024。

只解 WoodCutList 的 N×N ID 儲存。group first/count 指向報表自有總 N ID pool；group 規格排序與每群宣告次序不變，按值 copy 不含 alias pointer。first pass 保原分群/placed/total與排序；counts→offset 後清 cursor，再以原 members 次序填各群。原 O(N²) 分群/排序時間仍保留，沒有宣稱整體 collector/load 成本消失。

五個完整候選／before 在 MANIFEST。保容量64、所有原8方法/4controls/具名CHECK/CLI逐字報表及原10s/30s；僅機械改舊harness的ID存取。新增3方法：interleaved/full-distinct/copy；4個pool正反 controls（offset/value/reverse/N誤拒）；一個 header 回復每群N陣列的storage control，共11methods/9controls。

header mutant 同時以變異header重編原 client 與 cut_list.c，不將不同 WoodCutList layout 混連。boundary_policy object 不用此報表型別。try/finally恢復header後再走原baseline。新size CHECK的預算由既有scalar欄位/必要padding推導，限制group不得內含N陣列；不是新performance/stack數值門檻。未新增大localarray、heap ownership或新容量。

原全report suite命令：python3 -B tests/test_geo261_wood_report_policy.py。原 compiler/NativeBuild 入口、所有timeouts/16MiB契約保持，將以隔離 TMPDIR/native outputs + 原audit compile-log retainer封完整原streams。需 root 後續授heavy與fresh disk，不在本準備階段跑。expected仍parent的8，新增真方法11待root共享登記；不拿預期過期的run_all count說全native通過。全ledger只root最後一次。

狀態：純候選/AST，沒有 C/subject/控制0-1-0/CLI/perf/stack512/帳本/架構實跑。未改SSOT/queue/K/任何門檻。整體pool撤回是representation變更，不能用舊ABI編譯失敗冒kill；精準五刀須真正常ASSERT0/1/0。原report CLI、儲存復發與新自含copy各要保真封存。
