"""Apply an independently reviewed immutable candidate and ordinarily push its own branch."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/geo300-contact-index-work')
BASE='ccfaf057088a80c7aad4049f1c67e5eedfc2fdec'
BRANCH='codex/geo300-cut-list-storage-20261024'
MANIFEST_SHA='09c97c1e6bcc8235c1a1135e6f2afd01048dd0b1c2e858fb41d59220842ee988'
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def h(data):return hashlib.sha256(data).hexdigest()
def need(ok,message):
    if not ok:raise RuntimeError(message)

if len(sys.argv)!=3:raise SystemExit('usage: publish_source.py <peer-json> <exact-peer-sha256>')
peer=Path(sys.argv[1]);peer_raw=peer.read_bytes()
need(h(peer_raw)==sys.argv[2],'independent review pin')
raw=(HERE/'MANIFEST.json').read_bytes();need(h(raw)==MANIFEST_SHA,'fixed candidate manifest')
manifest=json.loads(raw);need(manifest['base_source_sha']==BASE,'exact fixed parent')
need(h((HERE/'CUT_LIST_STORAGE.patch').read_bytes())==manifest['patch_sha256'],'patch pin')
need(h(CAPTURE.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original recorder')
out=HERE/'source-publication';need(not out.exists(),'fresh publication output');out.mkdir()
spec=importlib.util.spec_from_file_location('cut_list_publish_c387',CAPTURE)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
r=cap.Recorder(out,dict(os.environ),BASE)
current=BASE
report={'schema':'geo300-cut-list-source-publication/1','parent':BASE,'branch':BRANCH,'manifest_sha256':MANIFEST_SHA,'peer':str(peer),'peer_sha256':h(peer_raw),'subject_execution':'UNRUN','commands':r.rows}
def run(argv,check=True):return r.run(argv,cwd=ROOT,timeout=120,check=check,source_sha=current,source_variant='source-publication-only')
try:
    _,head,_=run(['git','rev-parse','HEAD']);need(head.decode().strip()==BASE,'exact clean source parent')
    _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);need(status==b'','dirty source refused')
    _,branches,_=run(['git','branch','--list',BRANCH]);need(branches==b'','do not overwrite an existing branch')
    _,remote_before,_=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]);need(remote_before==b'','new branch must be absent remotely')
    for item in manifest['files']:
        name=item['path'];candidate=(HERE/'candidate'/name).read_bytes()
        need(h(candidate)==item['after_sha256'],'candidate drift '+name)
        _,blob,_=run(['git','show',BASE+':'+name]);need(h(blob)==item['before_sha256'],'parent blob drift '+name)
    run(['git','switch','-c',BRANCH,BASE])
    run(['git','apply','--check',str(HERE/'CUT_LIST_STORAGE.patch')])
    run(['git','apply',str(HERE/'CUT_LIST_STORAGE.patch')])
    for item in manifest['files']:need(h((ROOT/item['path']).read_bytes())==item['after_sha256'],'applied bytes '+item['path'])
    _,names,_=run(['git','diff','--name-only','-z'])
    need(set(names.decode().rstrip('\0').split('\0'))=={x['path']for x in manifest['files']},'exact five-file closure')
    run(['git','diff','--check'])
    run(['git','add','--',*[x['path']for x in manifest['files']]])
    run(['git','commit','-m','perf(GEO-300): store cut-list IDs once per report'])
    _,head,_=run(['git','rev-parse','HEAD']);current=head.decode().strip();report['source_sha']=current
    _,parent,_=run(['git','rev-parse','HEAD^']);need(parent.decode().strip()==BASE,'single exact parent')
    _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);need(status==b'','postcommit source clean')
    run(['git','push','origin','HEAD:refs/heads/'+BRANCH])
    _,remote,_=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]);need(remote.decode().split()==[current,'refs/heads/'+BRANCH],'remote exact full SHA')
    report['exit_code']=0
finally:
    (out/'PUBLICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (out/'COMMANDS.json').write_text(json.dumps(r.rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_sha':current,'branch':BRANCH,'exit_code':0,'subject_execution':'UNRUN'},ensure_ascii=False))
