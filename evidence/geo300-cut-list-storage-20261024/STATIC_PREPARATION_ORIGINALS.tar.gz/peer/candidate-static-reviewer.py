from pathlib import Path
import ast,json,hashlib,re,subprocess,sys
B=Path('/tmp/geo300-cut-list-storage-20261024');checks=0;findings=[]
def ck(v,s):
 global checks
 checks+=1
 if not v:findings.append(s)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((B/'MANIFEST.json').read_text());ck(h(B/'MANIFEST.json')=='09c97c1e6bcc8235c1a1135e6f2afd01048dd0b1c2e858fb41d59220842ee988','manifest pin');ck(h(B/'CUT_LIST_STORAGE.patch')==m['patch_sha256']=='ad64d4c7aec90fc31128ffd36b47a0574661760c96d2cdf01d5f535ca6383066','patch pin');ck(len(m['files'])==5 and not m['expected_file_changed'] and not m['global_ledger_changed'] and m['subject_execution']=='UNRUN','scope no aggregate claim')
for x in m['files']:
 for role,key in [('before','before'),('candidate','after')]:
  p=B/role/x['path'];ck(p.stat().st_size==x[key+'_bytes'] and h(p)==x[key+'_sha256'],role+' '+x['path'])
before=B/'before';after=B/'candidate';py='tests/test_geo261_wood_report_policy.py';old=ast.parse((before/py).read_text());new=ast.parse((after/py).read_text());of={x.name:ast.dump(x,include_attributes=False) for x in ast.walk(old) if isinstance(x,ast.FunctionDef)};nf={x.name:ast.dump(x,include_attributes=False) for x in ast.walk(new) if isinstance(x,ast.FunctionDef)}
for name,value in of.items():ck(nf.get(name)==value,'existing Python method/helper unchanged '+name)
ck(len([x for x in nf if x.startswith('test_')])==11 and len([x for x in of if x.startswith('test_')])==8,'11methods original8 preserved')
head=(after/'geometry-templates/woodworking/native/cut_list.h').read_text();c=(after/'geometry-templates/woodworking/native/cut_list.c').read_text();oldc=(before/'geometry-templates/woodworking/native/cut_list.c').read_text();har=(after/'tests/geo261_report_policy_harness.c').read_text();oldhar=(before/'tests/geo261_report_policy_harness.c').read_text()
ck('#define WOOD_CUT_LIST_MEMBER_CAPACITY 64' in head and head.count('uint32_t ids[WOOD_CUT_LIST_MEMBER_CAPACITY]')==1,'same64 one reportowned pool')
ck('size_t first,count;' in head and 'uint32_t ids' not in head.split('} WoodCutGroup;')[0],'group has offsets noN-sized IDarray')
ck(c[:c.index('memset(out,0,sizeof *out);')]==oldc[:oldc.index('memset(out,0,sizeof *out);')],'capacity/null rejection before outputwrite unchanged')
for label in re.findall(r'"(report-[a-z-]+|fixity-[a-z-]+)"',oldhar):ck('"'+label+'"' in har,'old harness named assertion '+label)
# Only old-harness accesses adapted, plus new pool function and dispatch.
for token in ['result.groups[0].ids[0]','result.groups[0].ids[1]','result.groups[i].ids[0]','result.groups[0].ids[63]']:ck(token not in har,'old groupID storage consumer removed '+token)
oldhost=(before/'current_geometry.c').read_bytes();newhost=(after/'current_geometry.c').read_bytes();ck(oldhost.count(b'groups[g].ids[k]')==1 and oldhost.replace(b'groups[g].ids[k]',b'report.ids[groups[g].first+k]')==newhost,'host exact sole owned-pool access adaptation')
controls=[]
for node in ast.walk(new):
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='controls' for t in node.targets):controls.extend(ast.literal_eval(node.value))
ck(len(controls)==7,'existing3 plus4tuple controls')
for row in controls:
 if len(row)==6:module,name,anchor,replacement,case,marker=row;source=(after/f'geometry-templates/woodworking/native/{module}.c').read_text() if (after/f'geometry-templates/woodworking/native/{module}.c').exists() else None
 else:name,anchor,replacement,case,marker=row;source=c
 if source is not None:ck(source.count(anchor)==1,'unique control '+name)
ck(head.count('    size_t first,count;')==1,'header storage anchor unique')
ck('sizeof(WoodCutGroup)<=3*sizeof(GeoCoord)+sizeof(WoodMemberRole)+' in har and '2*sizeof(size_t)+sizeof(GeoCoord)+sizeof(size_t)' in har,'structural size bound no new timing threshold')
ck('WoodCutList copy=result;memset(&result,0,sizeof result);memset(values,0,sizeof values);' in har and '"report-copy-owned-ids"' in har,'copy after original/memberzero independent')
ck('WOOD_CUT_LIST_MEMBER_CAPACITY&&result.placed==WOOD_CUT_LIST_MEMBER_CAPACITY' in har and 'result.groups[i].first==i&&result.groups[i].count==1' in har,'max distinctgroup offsets fixture')
pys=(after/py).read_text();ck('client=build.compile(source,"report-storage-client")' in pys and 'cut=build.compile(build.woodworking/"cut_list.c","report-storage-cut")' in pys and '[client,cut,build.wood_boundary_policy_object]' in pys,'same-mutant-header both clients/C ABI')
ck('finally:\n            header.write_bytes(original)' in pys and 'self.assertEqual(original,header.read_bytes())' in pys,'header finally restored and bytesguard')
q=subprocess.run(['git','-C','/workspace/geo300-contact-index-work','grep','-n','-e','WoodCutGroup','-e','WoodCutList','-e','wood_cut_list_collect',m['base_source_sha'],'--','*.c','*.h','*.inc','*.py',':!evidence',':!handoff'],capture_output=True)
paths={line.split(':',2)[1] for line in q.stdout.decode().splitlines()};ck(q.returncode==0 and paths=={x['path'] for x in m['files']},'all named struct/API repository consumers covered')
# Review proof: for <=64 inputs, grouping partitions placed inputs, sorted counts sum to placed <=64;
# prefixes define disjoint half-open intervals; second pass visits the same keys and preserves input order.
report={'schema':'independent-cut-list-owned-pool-static-peer/1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'base_source_sha':m['base_source_sha'],'patch_sha256':m['patch_sha256'],'candidate_files':m['files'],'scope':'Five immutable candidate leaves only. No compiler, import, test, performance run or branch mutation. Existing eight test method/helper AST unchanged, all named report consumers accounted for.','reasoning':['Placed grouping partitions at most64 entries; sum of sorted group counts is placed<=count<=64. Prefix offsets therefore partition a bounded report-owned ID pool. Second pass repeats exact length/section/role keys and visits original declaration order; each placed member fills exactly one slot.','Zero/unplaced/empty groups do not access pool; rejected count>64/null-input conditions still return before memset. Uint32 IDs are copied without numeric comparison; duplicate IDs retain original semantics/order.','Group sorting logic/order and O(N²) grouping/sorting time remain unchanged; only storage becomes linear. No pointer alias escapes report, so value-copy survives original input/report erasure.','Structural size assertions derive from field sizes and retained capacity; they are not new performance thresholds. Header mutant recompiles client and cut module against the same changed header; unrelated boundary object does not use WoodCutList.','Old unplaced/role/reverse-length controls still have their original first named failures; new offset/value/reverse/capacity controls are predicted normal assertion kills, but these and storage control await actual C verification.'],'pending':['11methods/9controls actual and precise withdrawn/restored proof','Shared expected count8→11 only after root assigns registration order','Affected native/CLI/integration, ledger/architecture after real source adoption','No performance measurement or capacity512 qualification']}
out=Path('/tmp/train337-adversarial/CUT_LIST_STORAGE_CANDIDATE_STATIC_PEER.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':checks,'exit_code':report['exit_code'],'findings':findings,'path':str(out),'sha256':h(out)}));sys.exit(report['exit_code'])
