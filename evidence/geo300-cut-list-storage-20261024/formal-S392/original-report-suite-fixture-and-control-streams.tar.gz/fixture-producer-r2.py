from pathlib import Path
import hashlib,importlib.util,json,os,shutil
ROOT=Path('/workspace/geo300-contact-index-work')
OUT=Path('/workspace/geo300-cut-list-storage-fixture-materialization-20261024-r2')
E='a5f1806fb3cad2dada1a56e79e01d54f9f86700f'
S='39273bc0229fbbb16565134e1f8fad3a0d598c31'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert shutil.disk_usage('/workspace').free>=100*1024*1024
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
rec=cap.Recorder(OUT,env,S)
def run(argv):return rec.run(argv,cwd=ROOT,timeout=None,check=True,source_sha=E,source_variant='original-fixture-environment-only')[1]
assert run(['git','rev-parse','HEAD']).decode().strip()==E
assert not run(['git','status','--porcelain=v1','--untracked-files=all'])
patterns=run(['git','sparse-checkout','list'])
original=run(['git','show',S+':room_a.scene'])
assert len(original)==370 and hashlib.sha256(original).hexdigest()=='c3c0ba589285ef5ecd835b89a38174ebe050c85c4b8814510e139f72550f1f7c'
assert not (ROOT/'room_a.scene').exists()
assert run(['git','config','--get','core.sparseCheckoutCone']).strip()==b'false'
run(['git','sparse-checkout','add','/room_a.scene'])
after=run(['git','sparse-checkout','list'])
assert set(patterns.splitlines())<=set(after.splitlines())
assert set(after.splitlines())-set(patterns.splitlines())=={b'/room_a.scene'}
assert (ROOT/'room_a.scene').read_bytes()==original
assert run(['git','rev-parse','HEAD']).decode().strip()==E
assert not run(['git','status','--porcelain=v1','--untracked-files=all'])
report={'actual_exit':0,'product_sha':S,'head_before_after':E,'fixture':'room_a.scene','bytes':len(original),'sha256':hashlib.sha256(original).hexdigest(),
    'all_original_sparse_patterns_preserved':True,'only_added_pattern':'/room_a.scene','source_clean':True,'commands':rec.rows,
    'scope':'Environment materialization of exact original committed fixture; no product, test, threshold, ledger or source commit change.'}
(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='commands'}))
