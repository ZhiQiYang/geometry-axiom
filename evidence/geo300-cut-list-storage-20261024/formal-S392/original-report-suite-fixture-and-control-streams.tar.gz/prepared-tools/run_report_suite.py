"""Run the original report suite on the fixed cut-list candidate.

Uses the existing c387 recorder and audit-only NativeBuild retention. No
compiler, product, test, timeout, subprocess return, or oracle interception.
"""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import datetime

S='39273bc0229fbbb16565134e1f8fad3a0d598c31'
ROOT=Path('/workspace/geo300-contact-index-work')
OUT=Path('/workspace/geo300-cut-list-storage-39273bc0-formal')
TMP=Path('/workspace/geo300-cut-list-storage-39273bc0-formal-tmp')
TOOLS=Path('/workspace/geo300-cut-list-storage-39273bc0-formal-tools')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
ORIGINAL_OBSERVER=Path('/tmp/geo300-cut-list-storage-20261024/formal-tools/retain_report_streams.py')
SUITES=[('wood-report','tests/test_geo261_wood_report_policy.py',11)]
STRIP={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD',
       'LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH',
       'COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def control_proofs(observed):
    commands=observed['commands'];native=[];complete=True
    def stream(row,name):
        item=row[name]
        if not item.get('captured'):raise RuntimeError('missing original child stream')
        path=Path(item['path']).resolve()
        if not path.is_relative_to(OUT.resolve()):raise RuntimeError('stream outside private OUT')
        body=path.read_bytes()
        if len(body)!=item['bytes'] or sha(body)!=item['sha256']:raise RuntimeError('original stream changed')
        return body
    for row in commands:
        argv=row.get('args',[None])[0]
        if not isinstance(argv,list)or len(argv)!=2:continue
        name=Path(argv[0]).name.removesuffix('.exe')
        if not name.startswith('report-'):continue
        try:native.append({'number':row['number'],'name':name,'case':argv[1],'exit':row['returncode'],'stdout':stream(row,'stdout'),'stderr':stream(row,'stderr')})
        except Exception:complete=False
    controls=[('report-unplaced','grouping','report-placed-only'),('report-role','grouping','report-exact-spec-identity'),
              ('report-free','fixity','fixity-default-fixed'),('report-reverse-length','ordering','report-length-order'),
              ('report-pool-offset','pool','report-pool-offsets'),('report-pool-value','pool','report-pool-id-order'),
              ('report-pool-reverse','pool','report-pool-id-order'),('report-exact-capacity','limits','report-capacity'),
              ('report-storage-control','pool','report-group-linear-storage')]
    proofs=[]
    for name,case,marker in controls:
        mutants=[x for x in native if x['name']==name and x['case']==case]
        result={'control':name,'case':case,'expected_assertion':marker,'mutant_matches':len(mutants),'passed':False}
        if len(mutants)==1:
            mutant=mutants[0]
            before=[x for x in native if x['name']=='report-policy-client'and x['case']==case and x['number']<mutant['number']]
            after=[x for x in native if x['name']=='report-policy-client'and x['case']==case and x['number']>mutant['number']]
            baseline=max(before,key=lambda x:x['number'])if before else None;restored=min(after,key=lambda x:x['number'])if after else None
            result.update(command_numbers=[None if baseline is None else baseline['number'],mutant['number'],None if restored is None else restored['number']],actual_exits=[None if baseline is None else baseline['exit'],mutant['exit'],None if restored is None else restored['exit']])
            result['passed']=baseline is not None and restored is not None and baseline['exit']==0 and restored['exit']==0 and not baseline['stderr'] and not restored['stderr'] and mutant['exit']==1 and mutant['stderr']==('ASSERT:'+marker+'\n').encode()
        proofs.append(result)
    header=(ROOT/'geometry-templates/woodworking/native/cut_list.h').read_bytes()
    needle=b'    size_t first,count;'
    if header.count(needle)!=1:raise RuntimeError('source header anchor drift')
    mutated=header.replace(needle,needle+b'\n    uint32_t legacy_ids[WOOD_CUT_LIST_MEMBER_CAPACITY];')
    snapshots=observed.get('storage_header_snapshots',[])
    header_ok=len(snapshots)==2 and sorted(x['role']for x in snapshots)==['client','cut']
    for item in snapshots:
        path=Path(item['retained']).resolve()
        if not path.is_relative_to(OUT.resolve()):raise RuntimeError('header snapshot outside private OUT')
        body=path.read_bytes();header_ok=header_ok and body==mutated and len(body)==item['bytes']and sha(body)==item['sha256']
    return proofs,complete,header_ok

def main():
    if OUT.exists() or TMP.exists() or TOOLS.exists():raise RuntimeError('fresh output/temp/tools required')
    space=os.statvfs('/workspace');available=space.f_bavail*space.f_frsize
    if available<100*1024*1024:
        print(json.dumps({'environment_blocked':'root-planned 100 MiB disk budget unavailable','workspace_available_bytes':available,'subject_started':False}),flush=True)
        return 75
    raw=ORIGINAL_OBSERVER.read_bytes()
    if sha(raw)!='1ac22c23067503b0379fff3e39aa91a5862ac5ee6394eecc36c9731fb47e2532':raise RuntimeError('observer drift')
    if sha(CAP.read_bytes())!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise RuntimeError('c387 drift')
    OUT.mkdir();TMP.mkdir();TOOLS.mkdir()
    lock_path=Path('/tmp/g261r3/secondary.lock');lock_path.parent.mkdir(parents=True,exist_ok=True)
    lock=lock_path.open('a+b')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return 75
    old_stack=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,old_stack[1]))
    spec=importlib.util.spec_from_file_location('geo300_three_capture',CAP)
    cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    env={k:v for k,v in os.environ.items() if k not in STRIP and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))}
    env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LC_ALL='C.UTF-8',LANG='C.UTF-8')
    rec=cap.Recorder(OUT,env,S)
    receipt={'schema':'geo300-cut-list-original-report-suite/1','source':S,'root':str(ROOT),'started_utc':utc(),
             'secondary_lock':str(lock_path),'R3_lock_taken':False,'stack_before':old_stack,'stack_after':resource.getrlimit(resource.RLIMIT_STACK),
             'logical_original_argv':[['python3','-B',target] for _,target,_ in SUITES],
             'observer_scope':'reviewed passive subprocess.run retainer plus original NativeBuild audit and two named compiler header snapshots; runpy shell exposed',
             'outer_subject_timeout':None,'original_child_limits_unchanged':True,'cost_or_performance_run':False,
             'global_ledger_written':False,'suites':[],'accepted':False}
    (OUT/'launch-request.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    current_head='a5f1806fb3cad2dada1a56e79e01d54f9f86700f'
    def run(argv,check=True,source_variant=None):
        return rec.run(argv,cwd=ROOT,timeout=None,check=check,source_sha=current_head,source_variant=source_variant)
    try:
        run(['df','-B1','/tmp','/workspace'])
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        receipt['completed_checkout_previous_identity']=head.decode().splitlines()
        if receipt['completed_checkout_previous_identity'][0]!=current_head:raise RuntimeError('unexpected completed checkout HEAD')
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('completed source not clean; preserve all data')
        run(['git','ls-files','--stage'])
        run(['git','checkout','--detach',S],source_variant='checkout-from-'+current_head+'-to-'+S)
        current_head=S
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        if head.decode().splitlines()[0]!=S:raise RuntimeError('wrong candidate HEAD')
        receipt['actual_source_identity']=head.decode().splitlines()
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('candidate checkout not clean')
        run(['git','ls-files','--stage'])
        observer=TOOLS/'report-retain.py';observer.write_bytes(raw)
        bindings=[{'suite':'wood-report','bound_sha256':sha(raw),'target':SUITES[0][1],'path':str(observer),'body_exact_reviewed_copy':True}]
        (TOOLS/'BINDINGS.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n')
        for (name,target,expected),binding in zip(SUITES,bindings):
            where=OUT/name;where.mkdir()
            env.update(GEO299316_EXECUTION_LOG=str(where/'native-executions.jsonl'),
                       GEO261_CONTACT_SOURCES_EXECUTION_LOG=str(where/'native-executions.jsonl'),
                       GEO318_ARTIFACT_DIR=str(where/'host-source-artifacts'))
            row,stdout,stderr=run([sys.executable,'-B',binding['path'],'--root',str(ROOT),'--sha',S,'--out',str(where/'observed'),'--artifacts',str(where/'compile-retention')],check=False)
            text=stderr.decode('utf-8',errors='replace')
            retained=where/'compile-retention/retention.json'
            logs=json.loads(retained.read_text()) if retained.is_file() else []
            builds=[]
            for entry in logs:
                data=Path(entry['retained']).read_bytes()
                if sha(data)!=entry['sha256']:raise RuntimeError('retained original compile log changed')
                builds.extend(json.loads(data))
            result={'suite':name,'target':target,'source':S,'original_expected_methods':expected,
                    'actual_exit':row['actual_process_returncode'],'methods_reported':('Ran '+str(expected)+' tests') in text,
                    'zero_skips':'skipped' not in text,'compile_commands':len(builds),'all_build_exits_zero':bool(builds) and all(b['exit']==0 for b in builds),
                    'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'command':row,'binding':binding,
                    'native_execution_log':str(where/'native-executions.jsonl')}
            observed=json.loads((where/'observed/receipt.json').read_bytes())
            result['observer_complete']=observed.get('observer_complete')is True and not observed.get('observation_errors') and observed.get('source_sha')==S and observed.get('original_completed')is True and observed.get('original_exit')==0 and observed.get('source_tool_bytes_unchanged')is True
            result['control_proofs'],result['native_streams_complete'],result['header_snapshots_complete']=control_proofs(observed)
            result['passed']=result['actual_exit']==0 and result['methods_reported'] and result['zero_skips'] and result['all_build_exits_zero'] and result['observer_complete'] and result['native_streams_complete'] and result['header_snapshots_complete'] and len(result['control_proofs'])==9 and all(x['passed']for x in result['control_proofs'])
            receipt['suites'].append(result)
            (where/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps({'suite':name,'exit':result['actual_exit'],'methods':expected,'passed':result['passed']}),flush=True)
        _,head,_=run(['git','rev-parse','HEAD','HEAD^{tree}'])
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        run(['git','ls-files','--stage'])
        receipt['source_after_identity']=head.decode().splitlines()
        receipt['source_after_clean']=status==b'' and receipt['source_after_identity']==receipt['actual_source_identity']
        run(['df','-B1','/tmp','/workspace'])
        receipt['accepted']=receipt['source_after_clean'] and len(receipt['suites'])==1 and all(s['passed'] for s in receipt['suites'])
    except BaseException as exc:
        receipt['exception']=repr(exc)
        raise
    finally:
        receipt['ended_utc']=utc();receipt['commands']=rec.rows
        (OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    return 0 if receipt['accepted'] else 1
if __name__=='__main__':raise SystemExit(main())
