from pathlib import Path
import hashlib,json
B=Path('/workspace/geo323-runtime-static-analysis-20261024');C=[]
def h(b):return hashlib.sha256(b).hexdigest()
def ck(n,b):C.append({'name':n,'pass':bool(b)})
for attempt,expected,parent in [('source-publication','9430bae568feb98805072930c92f9a03a1250d4e','b621a4fbc3cdea359b3676fb22dc8ef566968b8a'),('source-publication-r2','a543eef67b81f8d8800f32d5dc4a5641840d2943','9430bae568feb98805072930c92f9a03a1250d4e')]:
 O=B/attempt;R=json.loads((O/'RESULT.json').read_text());ck(attempt+' result0',R['exit']==0 and R['pushed'] and R['source']==expected and not R['formal_run']);a=R['commands']
 for i,x in enumerate(a,1):
  d=O/'commands'/f'{i:03d}';ck(f'{attempt} child{i}0',x.get('exit',x.get('actual_process_exit'))==0)
  for n in ['stdout','stderr']:
   b=(d/n).read_bytes();pin=x[n]['sha256'] if n in x else x[n+'_sha256'];ck(f'{attempt} child{i} {n}',h(b)==pin)
  if 'stdin' in x:ck(f'{attempt} child{i} stdin',h((d/'stdin').read_bytes())==x['stdin']['sha256'])
  cmd=x['command'][5:];out=(d/'stdout').read_bytes()
  if cmd==['show','-s','--format=%P',expected]:ck(attempt+' ordinary parent',out.decode().strip()==parent)
  if cmd[:1]==['status']:ck(attempt+' original status clean',out==b'')
  if cmd[:1]==['push']:ck(attempt+' ordinary push',cmd==['push','origin','HEAD:refs/heads/codex/train337-edge-probe-20261024'])
  if cmd[:1]==['show'] and len(cmd)==2 and cmd[1].startswith(expected+':'):
   leaf=cmd[1].split(':',1)[1]
   if leaf!='tests/run_all.expected.json':
    source=B/('edge-probe-companion-v2-draft' if attempt=='source-publication' else 'edge-probe-companion-draft')/'candidate'/leaf
    ck(attempt+' exactcandidate '+leaf,out==source.read_bytes())
   else:ck('registry17',json.loads(out)['suites']['py:test_geo261_source_index']=={'mode':'count','count':17,'unit':'test'})
 remote=[(O/'commands'/f'{i:03d}'/'stdout').read_bytes() for i,x in enumerate(a,1) if x['command'][5:]==['ls-remote','--heads','origin','refs/heads/codex/train337-edge-probe-20261024']]
 ck(attempt+' final remote exact',remote[-1].decode().split()==[expected,'refs/heads/codex/train337-edge-probe-20261024'])
r={'checks_total':len(C),'failed_checks':sum(not x['pass'] for x in C),'checks':C,'findings':[],'limits':['Original small Git metadata/streams only; no network, source mutation, C, formal retest.','S9430 source0 is separate from formal R1 linker red; new Sa543 exact directory fix product K unchanged.','Formal C17 evidence is reviewed separately by specials; this report gives no performance or ledger/architecture acceptance.']};Path(__file__).with_name('SOURCE_PUBLICATIONS_ACTUAL_PEER.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['checks_total'],r['failed_checks']);raise SystemExit(bool(r['failed_checks']))
