import hashlib,json,re
from pathlib import Path
B=Path("/workspace/geo323-runtime-static-analysis-20261024/edge-probe-draft")
m=json.loads((B/"MANIFEST.json").read_text()); before=(B/"before"/m["path"]).read_bytes(); after=(B/"candidate"/m["path"]).read_bytes();checks=[]
def ck(name,ok):checks.append({"name":name,"pass":bool(ok)})
ck("before SHA",hashlib.sha256(before).hexdigest()==m["before_sha256"])
ck("after SHA",hashlib.sha256(after).hexdigest()==m["after_sha256"])
ck("patch SHA",hashlib.sha256((B/"EDGE_PROBE_ONLY.patch").read_bytes()).hexdigest()==m["patch_sha256"])
ck("actual L source bytes",before==(Path(m["source_root"])/m["path"]).read_bytes())
s=before.decode()
for i,e in enumerate(m["edits"]):
 ck(f"unique forward edit {i}",s.count(e["before"])==1);s=s.replace(e["before"],e["after"],1)
ck("eight edits exact full product",s.encode()==after)
for i,e in reversed(list(enumerate(m["edits"]))):
 ck(f"unique reverse edit {i}",s.count(e["after"])==1);s=s.replace(e["after"],e["before"],1)
ck("withdrawal exact L bytes",s.encode()==before)
a=after.decode();b=before.decode()
ck("allocation call sequence identical",re.findall(r"\b(?:malloc|calloc|realloc|free)\([^;\n]+",a)==re.findall(r"\b(?:malloc|calloc|realloc|free)\([^;\n]+",b))
ck("only private edge finder and append signatures",a.count("geo_source_find_edge(")==2 and a.count("geo_source_index_append(")==3)
ck("node always sentinel", "geo_source_index_append(ctx,true,SIZE_MAX)" in a)
ck("resize invalidates hint", "first=0;empty_slot=SIZE_MAX;" in a)
ck("bounds before dereference", "if(empty_slot<*capacity&&!(*table)[empty_slot])" in a)
ck("insertion remains ordinal plus one", "(*table)[empty_slot]=count;return;" in a)
ck("hint initialized on every edge", "size_t empty_slot=SIZE_MAX;\n    if(geo_source_find_edge(ctx,edge,&empty_slot))" in a)
ck("fallback unchanged", a[a.index("fallback:"):a.index("static void *geo_source_grow")]==b[b.index("fallback:"):b.index("static void *geo_source_grow")])
ck("all after source descriptor unchanged",a[a.index("static bool geo_source_descriptor_valid"):]==b[b.index("static bool geo_source_descriptor_valid"):])
report={"subject_sha256":m["patch_sha256"],"checks_total":len(checks),"failed_checks":sum(not x["pass"] for x in checks),"checks":checks,"manual_review":["miss and append separated only by edges storage growth; index entries hold ordinal so realloc cannot invalidate slot","on duplicate finder returns before hint is consumed; no-index miss leaves SIZE_MAX; failed index allocation returns linear fallback","growth invalidates old slot before rebuild; empty slot guard reads index only after bounds short circuit","node find/hash/hint strategy untouched; public API, kinds, active validation and MEMORY ordering preserved","original source-index mutation anchors remain present and semantically target same private loops; no old tests removed"],"findings":[],"limits":["Static only, no C, no formal speed or mutation execution claim","Companion v1 was withdrawn by owner pending v2; no acceptance of its control yet","Root-cause timings/profile are reported source facts, no independent raw full-count reconstruction in this review","175/350 graph and original runtime gates still required at new public SHA"]}
Path(__file__).with_name("PRODUCT_REVIEW.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"checks":len(checks),"failed":report["failed_checks"]}));raise SystemExit(bool(report["failed_checks"]))
