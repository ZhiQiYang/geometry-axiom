from pathlib import Path
import hashlib,json,ast,re
B=Path('/workspace/geo323-runtime-static-analysis-20261024/edge-probe-companion-draft');M=json.loads((B/'MANIFEST.json').read_text());C=[]
def ck(n,b):C.append({'name':n,'pass':bool(b)})
def h(b):return hashlib.sha256(b).hexdigest()
ck('patch pin',h((B/'THREE_LEAF.patch').read_bytes())==M['patch_sha256']=='b512899e05b161067dd9fc68b66ad92d52c119a01d333963345f6cf5ded41aaa')
for n,p in M['files'].items():
 ck('before '+n,h((B/'before'/n).read_bytes())==p['before_sha256']);ck('after '+n,h((B/'candidate'/n).read_bytes())==p['after_sha256'])
 ck('realL '+n,(B/'before'/n).read_bytes()==(Path('/tmp/train337-323-f64d638f-source')/n).read_bytes())
# Reconstruct the independent unified patch using its original context lines.
lines=(B/'THREE_LEAF.patch').read_text().splitlines(True);i=0;products={}
while i<len(lines):
 if not lines[i].startswith('--- a/'):i+=1;continue
 name=lines[i][6:].strip();i+=2;old=(B/'before'/name).read_text().splitlines(True);out=[];cursor=0
 while i<len(lines) and not lines[i].startswith('--- a/'):
  if not lines[i].startswith('@@'):i+=1;continue
  mt=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);start=int(mt.group(1))-1;out+=old[cursor:start];cursor=start;i+=1
  while i<len(lines) and not lines[i].startswith(('@@','--- a/')):
   x=lines[i];i+=1
   if x[0] in ' -':ck('patch context '+name,old[cursor]==x[1:]);cursor+=1
   if x[0] in ' +':out.append(x[1:])
 out+=old[cursor:];ck('patch reconstructed '+name,''.join(out)==(B/'candidate'/name).read_text())
n='tests/test_geo261_source_index.py';old=ast.parse((B/'before'/n).read_text());new=ast.parse((B/'candidate'/n).read_text());funcs=lambda t:{x.name:ast.dump(x,include_attributes=False) for x in ast.walk(t) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))};of,nf=funcs(old),funcs(new)
for k,v in of.items():ck('original method/helper AST '+k,nf.get(k)==v)
ck('original14 new17',len([x for x in of if x.startswith('test_')])==14 and len([x for x in nf if x.startswith('test_')])==17)
assign=next(x for x in new.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EDGE_PROBE_REUSE_EDITS' for t in x.targets));edits=ast.literal_eval(assign.value);src=(B/'candidate/geometry-core/kernel/source.c').read_text()
for before,after in reversed(edits):ck('unique whole reversal',src.count(after)==1);src=src.replace(after,before)
ck('whole exact L',src==(B/'before/geometry-core/kernel/source.c').read_text())
c=(B/'candidate/tests/geo261_source_index_harness.c').read_text();oldc=(B/'before/tests/geo261_source_index_harness.c').read_text();a=c.index('static int probe_seed_nodes');z=c.index('int main(',a);rest=c[:a]+c[z:];rest=rest.replace('static uint64_t edge_probe_hash_calls;\n','',1).replace('    if(!strcmp(argv[1],"edge-probe"))result=probe_edges();\n    else if(!strcmp(argv[1],"edge-probe-cost"))result=probe_cost();\n    else if(!strcmp(argv[1],"nodes"))result=nodes_and_seal();','    if(!strcmp(argv[1],"nodes"))result=nodes_and_seal();',1);ck('all old C exact after removing additions',rest==oldc)
# Independent tiny integer model; no candidate imports, C or generator execution.
mask64=(1<<64)-1
def mix(h,v):h=((h^v)*11400714785074694791)&mask64;return h^(h>>32)
def hh(e):
 h=14695981039346656037
 for v in e:h=mix(h,v)
 return h
seq=[]
for i in range(1,34):
 seq.append((0,i,0))
 if i==9:seq.extend([(0,9,0),(0,1,0)])
seq.extend([(1,1,0),(1,1,1),(1,1,2),(0,1,1),(0,1,1),(1,1,2),(1,1,1),(1,1,0)])
seq.extend((0,i,0) for i in range(33,0,-1))
def model(mode,faults=False,cost=False):
 edges=[];tab=[];oracle=[];calls=0;failedalloc=0
 stream=[(0,i,0) for i in range(1,13)] if cost else seq
 for op,e in enumerate(stream,1):
  if e not in oracle:oracle.append(e)
  slot=None;exists=False
  if tab:
   calls+=1;slot=hh(e)&(len(tab)-1)
   while tab[slot]:
    if edges[tab[slot]-1]==e:exists=True;break
    slot=(slot+1)&(len(tab)-1)
  else:exists=e in edges
  if not exists:
   if mode=='wrong' and slot is not None:slot=(slot+1)&(len(tab)-1)
   edges.append(e);count=len(edges)
   if count>len(tab)//2:
    size=len(tab) or 16
    while count>size//2:size*=2
    if faults and e==(0,e[1],0) and e[1] in (1,9,17):
     tab=[];failedalloc+=1
    else:
     tab=[0]*size
     if mode!='stale':slot=None
     if slot is not None and not tab[slot]:tab[slot]=count
     else:
      for j,v in enumerate(edges):
       calls+=1;q=hh(v)&(size-1)
       while tab[q]:q=(q+1)&(size-1)
       tab[q]=j+1
   elif mode in ('fixed','wrong','stale') and slot is not None and not tab[slot]:tab[slot]=count
   else:
    calls+=1;q=hh(e)&(len(tab)-1)
    while tab[q]:q=(q+1)&(len(tab)-1)
    tab[q]=count
  if edges!=oracle:return {'op':op,'edge_count':len(edges),'expected':len(oracle),'cause':'duplicate-edge'}
 return {'edges':len(edges),'calls':calls,'allocation_failures':failedalloc}
fixed=model('fixed');fallback=model('fixed',True);stale=model('stale');wrong=model('wrong')
ck('ordered37 exact model',fixed['edges']==37);ck('fallback3 exact model',fallback['edges']==37 and fallback['allocation_failures']==3)
ck('stale exact normal mismatch',stale=={'op':10,'edge_count':10,'expected':9,'cause':'duplicate-edge'})
ck('wrong exact normal mismatch',wrong=={'op':40,'edge_count':38,'expected':37,'cause':'duplicate-edge'})
ck('whole cost21/31/21 model',[model(m,cost=True)['calls'] for m in ['fixed','withdrawn','fixed']]==[21,31,21])
report={'subject_sha256':M['patch_sha256'],'checks_total':len(C),'failed_checks':sum(not x['pass'] for x in C),'checks':C,'model':{'fixed':fixed,'fallback':fallback,'stale':stale,'wrong':wrong},'findings':[],'manual_review':['40 seed nodes within MAX_REFS and 37 edges within MAX_EDGES; mutable active restores SIZE_MAX after depend','old-slot9/new25 precondition runs only baseline before allocation; mutant first duplicate is graph_equal normal assertion, not UB/compiler','post9 immediate reads and final4 reverse reads prevent later rebuild masking either mutant','new whole control truly compiles fixed/withdrawn/restored independently; semantic graph must remain0 and cost failure precise normal1; original timeout30 retained','calloc fallback injections only after all nodes seeded; linear fallback ordinal graph and subsequent recovery preserved','all old14 test methods/helpers and old C body exact preserved; eight old controls unchanged'], 'limits':['Static plus independent Python integer model only; no C/compiler/runtime/discovery/kill','Expected registry14→17 remains planned/unapplied; final root ledger/architecture required','Full175/350 graph, guards and original N64 timing thresholds still UNRUN at future source']}
Path(__file__).with_name('COMPANION_V2_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['checks_total'],report['failed_checks']);raise SystemExit(bool(report['failed_checks']))
