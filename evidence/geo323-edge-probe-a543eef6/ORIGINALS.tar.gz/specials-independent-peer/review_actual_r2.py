"""Independent, read-only check of original C17 R1/R2 outcomes; no C execution."""
from pathlib import Path
import hashlib
import json
import re

O = Path('/workspace/geo323-source-index-peer-specials-20261024')
R = Path('/workspace/geo323-edge-probe-formal-r2-20261024')
OLD = Path('/workspace/geo323-edge-probe-formal-20261024')
S = 'a543eef67b81f8d8800f32d5dc4a5641840d2943'
checks = []

def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})

def digest(b):
    return hashlib.sha256(b).hexdigest()

def read(p):
    return json.loads(p.read_text())

def stream(meta):
    check('stream is captured', meta.get('captured') is True)
    p = Path(meta['path'])
    check('stream remains in original R2', p.is_relative_to(R))
    b = p.read_bytes()
    check('stream complete byte count/hash', len(b) == meta['bytes'] and digest(b) == meta['sha256'])
    check('stream representation truthful', meta['representation'] in ('original-bytes', 'original-text-encoded-utf8'))
    return b

result = read(R / 'RESULT.json')
request = read(R / 'observed/request.json')
observed = read(R / 'observed/receipt.json')
check('exact new published execution SHA', result['source_sha'] == request['source_sha'] == observed['source_sha'] == S)
check('original suite true0 and no observation errors', result['exit'] == result['original_suite_process_exit'] == observed['original_exit'] == 0 and observed['observer_complete'] and not observed['observation_errors'])
check('original observer fixed65dac', request['observer_sha256'] == '65dac15dfbb5268c0471996dc10de8377bdafbe8c5d40cf5c1bd21af694e236b')
check('no optimize and original verbose argv', request['environment'].get('PYTHONOPTIMIZE') in (None, '', '0') and request['original_argv'] == ['tests/test_geo261_source_index.py', '-v'])
check('primary lock and original80MiB guard', result['exclusive_heavy_slot'] == '/tmp/g261r3/heavy.lock' and result['free_bytes_before'] >= 80 * 1024 * 1024)
for row in result['commands']:
    check('outer original child true0', row['actual_process_exit'] == 0)
    for key in ('stdout', 'stderr'):
        b = Path(row[key]).read_bytes()
        check('outer raw complete', len(b) == row[key + '_bytes'] and digest(b) == row[key + '_sha256'])
suite_stderr = Path(result['commands'][-1]['stderr']).read_bytes()
check('original17 zero skips true terminal', bool(re.search(rb'Ran 17 tests in [^\n]+\n\nOK\s*$', suite_stderr)) and b'skipped=' not in suite_stderr)
for row in request['source_preflights']:
    check('original source preflight true0', row['exit_code'] == 0)
    raw = bytes.fromhex(row['stdout_hex'])
    if row['argv'][1] == 'show':
        path = row['argv'][2].split(':', 1)[1]
        check('original watched Git bytes match initial hash', digest(raw) == request['source_tool_sha256_before'][path])
for row in observed['source_postflights']:
    expected = (S + '\n').encode() if row['argv'][1] == 'rev-parse' else b''
    check('original after HEAD clean actual', row['exit_code'] == 0 and bytes.fromhex(row['stdout_hex']) == expected)
check('all six original watched source bytes unchanged', request['source_tool_sha256_before'] == observed['source_tool_sha256_after'] and observed['source_tool_bytes_unchanged'])

rows = observed['commands']
check('99 original subprocess commands contiguous', [r['number'] for r in rows] == list(range(1, 100)))
native = []
compiled = []
for row in rows:
    check('original CompletedProcess not exception', row['completed_process_returned'] and row['exception'] is None)
    stdout, stderr = stream(row['stdout']), stream(row['stderr'])
    check('original command normal returncode', row['returncode'] in (0, 1))
    args = row['args'][0]
    if 'actual_executable' in row:
        m = row['actual_executable']
        b = Path(m['retained']).read_bytes()
        check('actual executable complete retained ELF', b.startswith(b'\x7fELF') and len(b) == m['bytes'] and digest(b) == m['sha256'])
        check('original native case timeout30', row['keyword_arguments_except_env']['timeout'] == 30)
        native.append({'number':row['number'], 'argv':args, 'exit':row['returncode'], 'stdout':stdout, 'stderr':stderr, 'binary':m['sha256']})
    else:
        check('actual compile/link is cc exit0 timeout300', Path(args[0]).name in ('cc', 'gcc') and row['returncode'] == 0 and row['keyword_arguments_except_env']['timeout'] == 300)
        compiled.append(row)
check('actual43 native plus56 compiler/link', len(native) == 43 and len(compiled) == 56)
check('native normal negatives exactly11', sum(r['exit'] == 1 for r in native) == 11)

controls = [
    ('never-node','nodes','duplicate-node'), ('never-edge','edges','duplicate-edge'),
    ('node-key-bytes-ignored','nodes','merged-node'), ('node-probe-miss','nodes','duplicate-node'),
    ('node-probe-hit','nodes','merged-node'), ('edge-kind-ignored','edge-collisions','missing-edge'),
    ('edge-probe-miss','edge-collisions','duplicate-edge'), ('edge-probe-hit','edge-collisions','missing-edge'),
    ('edge-reuse-old-slot-after-resize','edge-probe','duplicate-edge'),
    ('edge-reuse-wrong-empty-slot','edge-probe','duplicate-edge')]
for name, case, marker in controls:
    matches = [i for i,r in enumerate(native) if Path(r['argv'][0]).name == 'source-index-' + name and r['argv'][1] == case]
    check('one original named semantic control ' + name, len(matches) == 1)
    i = matches[0]
    before, mutant, after = native[i-1:i+2]
    check('own adjacent baseline/restore name and case ' + name, all(Path(r['argv'][0]).name == 'source-index-client' and r['argv'][1] == case for r in (before,after)))
    check('normal semantic0/1/0 ' + name, [r['exit'] for r in (before,mutant,after)] == [0,1,0])
    check('precise AssertionError marker ' + name, mutant['stdout'] == b'' and bool(re.fullmatch(rb'ASSERT:' + marker.encode() + rb' line=\d+ expr=[^\n]+\n', mutant['stderr'])))
    check('baseline/restore original streams and same real binary ' + name, all(r['stdout'] == ('PASS ' + case + '\n').encode() and r['stderr'] == b'' for r in (before,after)) and before['binary'] == after['binary'])

whole = []
for phase, code, count in [('fixed',0,21), ('withdrawn',1,31), ('restored',0,21)]:
    pair = [r for r in native if Path(r['argv'][0]).name == 'edge-probe-cost-' + phase]
    check('one whole semantic/cost pair ' + phase, len(pair) == 2)
    semantic, cost = pair
    check('whole exact same executed binary each phase ' + phase, semantic['binary'] == cost['binary'])
    check('whole exact graph first ' + phase, semantic['argv'][1] == 'edge-probe' and semantic['exit'] == 0 and semantic['stdout'] == b'PASS edge-probe\n' and semantic['stderr'] == b'')
    check('whole precise count stdout/exit ' + phase, cost['argv'][1] == 'edge-probe-cost' and cost['exit'] == code and cost['stdout'] == (f'PROBE_HASH_CALLS={count}\n' + ('PASS edge-probe-cost\n' if code == 0 else '')).encode())
    check('whole exact normal assertion/no extra stderr ' + phase, bool(re.fullmatch(rb'ASSERT:edge-probe-reuses-lookup-hash line=\d+ expr=[^\n]+\n', cost['stderr'])) if code else cost['stderr'] == b'')
    whole.extend(pair)
check('all six actual whole phase executions ordered', [r['number'] for r in whole] == sorted(r['number'] for r in whole))
check('restored actual ELF byte identity fixed', whole[0]['binary'] == whole[-1]['binary'])

retention = read(R / 'native-retention/retention.json')
check('one original cleanup audit', len(retention) == 1)
for entry in retention:
    b = Path(entry['retained']).read_bytes()
    check('complete original buildlog hash', len(b) == entry['bytes'] and digest(b) == entry['sha256'])
    log = json.loads(b)
    check('56 original buildlog commands all0', len(log) == 56 and all(x['exit'] == 0 for x in log))
    for x in entry['compiled_sources']:
        b = Path(x['retained']).read_bytes()
        check('actual compiled C retained complete', len(b) == x['bytes'] and digest(b) == x['sha256'])
snapshots = read(R / 'native-retention/all-c-header-inputs/source-snapshots.json')
check('one full source/header snapshot', len(snapshots) == 1)
inputs = {}
for x in snapshots[0]['files']:
    b = Path(x['retained']).read_bytes()
    check('every original C/header complete hash', len(b) == x['bytes'] and digest(b) == x['sha256'])
    inputs[x['original']] = b
for row in compiled:
    for value in row['args'][0]:
        if value.endswith('.c'):
            check('each actual compiler C input present in snapshot', value in inputs)
current_c_hash = 'b5e6c4825c7c729c489a1bcd34a03c0b4b5a085de2c209ad7572e1b0849a6ddf'
before_c_hash = '678877fab2d5acac05d7a1400c9068210beb7844c60c4b8fb30bda693e4f1e2a'
for phase in ('fixed','withdrawn','restored'):
    filename = snapshots[0]['original_build_directory'] + '/edge-probe-source-' + phase + '/source.c'
    raw = inputs[filename]
    check('exact one source counter instrumentation ' + phase, raw.count(b'{++edge_probe_hash_calls;') == 1)
    uninstrumented = raw.replace(b'{++edge_probe_hash_calls;', b'{')
    check('actual compiled whole source pin ' + phase, digest(uninstrumented) == (before_c_hash if phase == 'withdrawn' else current_c_hash))
    header_dir = snapshots[0]['original_build_directory'] + '/isolated-kernel'
    phase_compiles = [r for r in compiled if filename.replace('/source.c', '/client.c') in r['args'][0]]
    check('quoted phase source header retained via original include path ' + phase,
          header_dir + '/source.h' in inputs and len(phase_compiles) == 1
          and any(phase_compiles[0]['args'][0][i:i+2] == ['-I', header_dir]
                  for i in range(len(phase_compiles[0]['args'][0]) - 1)))

r1 = read(OLD / 'RESULT.json')
check('R1 original true1 preserved', r1['exit'] == r1['original_suite_process_exit'] == 1)
r1err = Path(r1['commands'][-1]['stderr']).read_bytes()
check('R1 all17 exposed and Linux collision exact', b'Ran 17 tests in ' in r1err and b'FAILED (failures=3)' in r1err and b'Is a directory' in r1err)
r1obs = read(OLD / 'observed/receipt.json')
failed_links = [r for r in r1obs['commands'] if r['returncode'] == 1 and Path(r['args'][0][0]).name == 'cc']
check('R1 exactly3 failed links not mutation kills', len(failed_links) == 3)
for row in failed_links:
    b = Path(row['stderr']['path']).read_bytes()
    check('R1 exact complete collision stderr', len(b) == row['stderr']['bytes'] and digest(b) == row['stderr']['sha256'] and b'Is a directory' in b)

report = {'scope':'C17 independent actual raw review only; no test, compiler or subject execution',
          'source':S, 'subjectResultSha256':digest((R/'RESULT.json').read_bytes()),
          'checks':checks, 'checkCount':len(checks), 'failures':[c for c in checks if not c['passed']],
          'peerPreparationHistory':'Initial peer guessed per-phase source.h, then guessed combined -I argument. Original argv uses separate -I and private isolated-kernel directory. Both initial reports/helpers retained; only peer lookups corrected, original subject unchanged.',
          'limitations':['Only the17-method source-index suite, not full aggregate/ledger/architecture/performance or seven jobs.',
            'Original compiler/native text streams are preserved decoded text, not newly reconstructed raw OS bytes.',
            'R1 linker path collision is retained as a test defect, never a semantic mutation kill.',
            'Package/publication completeness is a separate later check; this review reads the terminal original trees.']}
(O/'ACTUAL_R2_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failures':report['failures'],'report':str(O/'ACTUAL_R2_REVIEW.json')}))
raise SystemExit(bool(report['failures']))
