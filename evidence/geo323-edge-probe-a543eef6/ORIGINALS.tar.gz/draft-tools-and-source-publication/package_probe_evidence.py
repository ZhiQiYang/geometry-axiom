"""Freeze original small probe receipts, including the failed first round."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

HERE=Path(__file__).resolve().parent
OUT=HERE/'evidence-package'
ROOTS={
 'draft-tools-and-source-publication':HERE,
 'formal-r1':Path('/workspace/geo323-edge-probe-formal-20261024'),
 'formal-r2':Path('/workspace/geo323-edge-probe-formal-r2-20261024'),
 'combined-independent-peer':Path('/workspace/geo323-edge-probe-independent-peer-20261024'),
 'specials-independent-peer':Path('/workspace/geo323-source-index-peer-specials-20261024'),
}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
    assert not OUT.exists()
    rows=[]
    for label,root in ROOTS.items():
        assert root.is_dir()
        for path in sorted(root.rglob('*')):
            if not path.is_file():continue
            assert not path.is_symlink()
            relative=path.relative_to(root)
            if root==HERE and (relative.parts[0]=='evidence-package' or relative.parts[0].startswith('evidence-publication')):continue
            name=label+'/'+relative.as_posix()
            assert not name.startswith('/') and '..' not in Path(name).parts
            raw=path.read_bytes()
            rows.append({'archive_path':name,'local':str(path),'bytes':len(raw),'sha256':sha(raw)})
    assert len({row['archive_path'] for row in rows})==len(rows)
    OUT.mkdir()
    archive=OUT/'ORIGINALS.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz, tarfile.open(fileobj=gz,mode='w') as tar:
        for row in rows:
            data=Path(row['local']).read_bytes()
            assert sha(data)==row['sha256']
            info=tarfile.TarInfo(row['archive_path']);info.size=len(data);info.mode=0o644;info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();assert len(members)==len(rows)
        for member,row in zip(members,rows):
            assert member.name==row['archive_path'] and member.isfile()
            data=tar.extractfile(member).read()
            assert len(data)==row['bytes'] and sha(data)==row['sha256'] and data==Path(row['local']).read_bytes()
    index={'schema':'geo323-probe-originals/1','source_sha':'a543eef67b81f8d8800f32d5dc4a5641840d2943',
           'product_sha':'9430bae568feb98805072930c92f9a03a1250d4e','files':rows}
    (OUT/'RAW_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    result={'source_sha':index['source_sha'],'product_sha':index['product_sha'],'member_count':len(rows),
            'original_bytes':sum(row['bytes']for row in rows),'archive_bytes':archive.stat().st_size,
            'archive_sha256':sha(archive.read_bytes()),'raw_index_sha256':sha((OUT/'RAW_INDEX.json').read_bytes()),
            'roundtrip_all_bytes_equal':True,'r1_preserved':True,'formal_r2_actual_exit':0,
            'native_methods':17,'skips':0,'compile_link_commands':56,'native_commands':43,
            'scope':'Probe unit correctness and original counterexamples only; performance/full train acceptance remains UNRUN on the new union.',
            'exit':0}
    (OUT/'SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
