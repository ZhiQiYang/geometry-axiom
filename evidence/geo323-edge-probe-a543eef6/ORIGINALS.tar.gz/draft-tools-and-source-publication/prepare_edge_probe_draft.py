"""Build only a small external source text candidate; no compilation/import."""
import difflib,hashlib,json
from pathlib import Path
ROOT=Path('/tmp/train337-323-f64d638f-source')
OUT=Path(__file__).resolve().parent/'edge-probe-draft'
REL='geometry-core/kernel/source.c'
old=(ROOT/REL).read_bytes();text=old.decode()
edits=[
('static bool geo_source_find_edge(const GeoEvalContext *ctx,GeoSourceEdge edge)',
 'static bool geo_source_find_edge(const GeoEvalContext *ctx,GeoSourceEdge edge,size_t *empty_slot)'),
('''            slot=(slot+1)&mask;
        }
    }else for(size_t i=0;i<ctx->edge_count;++i)''',
 '''            slot=(slot+1)&mask;
        }
        *empty_slot=slot;
    }else for(size_t i=0;i<ctx->edge_count;++i)'''),
('static void geo_source_index_append(GeoEvalContext *ctx,bool nodes)',
 'static void geo_source_index_append(GeoEvalContext *ctx,bool nodes,size_t empty_slot)'),
('free(*table);*table=fresh;*capacity=next;first=0;',
 'free(*table);*table=fresh;*capacity=next;first=0;empty_slot=SIZE_MAX;'),
('''    for(size_t i=first;i<count;++i){
        uint64_t hash=nodes?geo_source_node_hash''',
 '''    /* A missing edge already probed this unchanged index to an empty slot.
     * Rebuilding discards that slot; allocation fallback stays linear. */
    if(empty_slot<*capacity&&!(*table)[empty_slot]){(*table)[empty_slot]=count;return;}
    for(size_t i=first;i<count;++i){
        uint64_t hash=nodes?geo_source_node_hash'''),
('geo_source_index_append(ctx,true);ctx->node_hint[slot]=*index+1;',
 'geo_source_index_append(ctx,true,SIZE_MAX);ctx->node_hint[slot]=*index+1;'),
('''    if(geo_source_find_edge(ctx,edge))return GEO_SOURCE_OK;''',
 '''    size_t empty_slot=SIZE_MAX;
    if(geo_source_find_edge(ctx,edge,&empty_slot))return GEO_SOURCE_OK;'''),
('geo_source_index_append(ctx,false);return GEO_SOURCE_OK;',
 'geo_source_index_append(ctx,false,empty_slot);return GEO_SOURCE_OK;'),
]
for before,after in edits:
    assert text.count(before)==1,before
    text=text.replace(before,after)
new=text.encode()
reverse=text
for before,after in reversed(edits):
    assert reverse.count(after)==1,after
    reverse=reverse.replace(after,before)
assert reverse.encode()==old
for name,data in [('before',old),('candidate',new)]:
    p=OUT/name/REL;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
patch=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+REL,tofile='b/'+REL)).encode()
(OUT/'EDGE_PROBE_ONLY.patch').write_bytes(patch)
sha=lambda x:hashlib.sha256(x).hexdigest()
m={'source_sha':'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db','source_root':str(ROOT),'scope':'External one-leaf edge-only text candidate; no C, branch, source/index or registry changes','path':REL,'before_bytes':len(old),'before_sha256':sha(old),'after_bytes':len(new),'after_sha256':sha(new),'patch_sha256':sha(patch),'edits':[{'before':a,'after':b} for a,b in edits],'whole_withdrawal_exact':True,'unchanged':['node hint strategy and node hash','all hash/equality algorithms','public source.h','nodes/edges arrays and insertion order','all malloc/calloc/realloc calls and fallback bodies','kind validation and active-consumer checks'],'formal':'UNRUN; no speedup/kill or ABI claim'}
(OUT/'MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(m,ensure_ascii=False))
