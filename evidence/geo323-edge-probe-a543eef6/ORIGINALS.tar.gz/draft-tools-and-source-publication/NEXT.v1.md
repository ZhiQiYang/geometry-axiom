# #323 runtime 靜態分析交接

owner：backlog_resume；只准外部草稿，不另開 #323 分支、不改root／其他owner來源；無C時槽。root目前跑memo／效能驗收，重I/O/C獨占。

- 受驗L `7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`，來源 `/tmp/train337-323-f64d638f-source`；原件 `/workspace/g337323L`。perf原36樣本N64/main **1.4282954375紅**，小N/base綠；profile已terminal0，sourcecalls64/32 **4.4076184255綠**。
- `ROOT_CAUSE.md`：確切profile／熱路徑／#341已在L、#343尚未在L、#346/#347非該load熱路徑，不能預告#343足以達1.3。
- `EDGE_PROBE_PLAN.md`：L→S343產品差異僅contact_world.c＋Python model_sources.py（後者#339 faces）；native closure只有contact_world.c。完整原175scene／350trace＋guards、A/B/C及既定性能門檻不變。
- 最小一leaf產品draft `edge-probe-draft/EDGE_PROBE_ONLY.patch` SHA `c7bd55eebd0d7d3f602865a652fb7b0fc5a928db6e04367bb6bbb07db5ade8c3`。只重用edge miss空slot；resize丟棄slot、callocfallback原樣。nodehint/hash/publicAPI沒動；8替換完整撤回精確原L。root親審檔 `edge-probe-draft/ROOT_REVIEW.md`，未見靜態問題，仍要第二審與正式。
- 獨立純Python `edge_probe_algorithm_witness.py` 已exit0，`EDGE_PROBE_ALGORITHM_WITNESS.json`：12edges hash21／31／21；37edge有序線性oracle；9/17/33擴容與indexfailure1/9/17恢復；兩negative模型拒絕。這不是C／正式／mutation已殺。對照第9條的oldslot=9、newslot=25，舊槽在新32表仍空。
- 三leaf產品＋測試外稿 `edge-probe-companion-draft/THREE_LEAF.patch` SHA `906d0df14fb18f44a1893590aadba1f84c69787dbe1d6ae2bf4ead4b690e3db7`；`MANIFEST.json`釘before/candidate。原14 unittest方法與helpers AST、C原body逐byte保留，新3方法AST總17，registry未改／discovery未跑。
- companion來源新增稿 `PROBE_C_ADDITION.txt`／`PROBE_PY_ADDITION.txt`；組裝器 `assemble_probe_companion.py`只讀文本+AST，已exit0，沒有importsubject或C。
- 新controls設計：漏清resize slot、回傳錯empty slot各以完整有序圖duplicate-edge正常斷言紅；整段patch撤回三版獨立compile且語意皆綠，診斷hash成本21／31／21、正常0／1／0。原30秒case與原NativeBuild保持；原source-index8controls全保留。
- 已請combined_resume對產品draft、完整3leaf、報告做獨立對抗審；尚未收到最終peer，不得算已審完或READY。

下一步：收peer找錯，若改草稿保原版本並重新釘pin；root一般merge前置到同列車後才決定套用與固定公開F。無新branch／C直到root授時槽；帳本與架構只由root最終統一處理。
