# #323：L 的 N64 載入紅燈，靜態根因與最小下一步

本報告只讀，未編譯／跑 C、沒有網路請求、沒有改 branch、產品、測試、SSOT、帳本或收據。受驗 L=`7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`，來源 `/tmp/train337-323-f64d638f-source`；原件 `/workspace/g337323L/`。base=`b74f9a2ae7ade1555b9be45283adecc097fb76e3`，main=`adbaebf9c73ea6801d7b4d5214e4b846b132923b`。

已讀該來源 AGENTS 與封存的 PROMPT-B/C：保持原 A 輸出 bytes、B 每次 seal 完整圖序列、C 五個守門流量、D 候選內失效、E 公開 API／C11／K-W-H 邊界。沒有授權刪依賴邊、合併不同 consumer、跳驗證或改任何閾值。本分析處理資料結構成本，不推導新的木工規則。

## 真正仍紅的是時間，來源呼叫數已綠

`evidence/performance.json` 是 36 個原交錯樣本。原中位數：

| N | base 秒 | fix 秒 | main 秒 | fix/base | fix/main |
|---|---:|---:|---:|---:|---:|
| 16 | 0.1171500230 | 0.1170308940 | 0.1670502830 | 0.9989831074 | 0.7005728568 |
| 32 | 0.2679129940 | 0.2175132490 | 0.2174041140 | 0.8118801771 | 1.0005019915 |
| 48 | 0.5190765260 | 0.4186803110 | 0.3185865020 | 0.8065868712 | 1.3141809472 |
| 64 | 0.9212350850 | 0.6696321320 | 0.4688330680 | 0.7268851815 | **1.4282954375** |

原時間門檻只指定 N64 fix/main≤1.3，N16/32/48 不得比原 base 變慢，所以本表不可把 N48/main>1.3 擅自另列新紅燈。N64 要在本輪 main 中位數下達標，需從 fix 減約 0.060149144 秒；這是算術差額，不是新增門檻。

profile 已真終態，其執行 exit0；CLI outer1 包含先前累積紅燈，不能把 outer1 誤稱 gprof 執行失敗。`evidence/profile-counts.json`：geo_eval_source 32→64 為 82,668→364,369，**4.4076184255≤4.5**。不要再以舊 source-calls 紅燈描述 L。

## 主要剩餘成本是保留依賴圖時的通用索引工作

原 `evidence/gprof-fix-64.stdout` 使用 `-O1 -fno-inline -pg`，每 sample 0.01 秒，不等於正式 O2 wall time；以下不能相加成保證可節省的時間。

| 函式 | N32 calls | N64 calls | N64 self 秒 | 說明 |
|---|---:|---:|---:|---|
| geo_source_node | 367,633 | 2,364,478 | 0.05 | 仍為每次 source/depend 找同一節點身分 |
| geo_source_find_node | 241,996 | 1,737,765 | 0.06 | node_hint miss 後完整 hash 查找 |
| geo_source_find_edge | 248,946 | 1,640,207 | 0.08 | 目前最大 self 桶 |
| geo_eval_depend | 284,965 | 2,000,109 | 0.01 | N64/N32=7.0187882722，不能當已求值次數 |
| wood_contact_collect_stops | 3,438 | 12,942 | 0.02 | N64/N32=3.7644，含子函式約0.05秒 |
| contact_order | 354,308 | 2,729,508 | 0.01 | 已有本次查詢 index，仍被插排／遮蓋雙圈大量呼叫 |
| contact_order_slot | 567,678 | 4,611,374 | 0.02 | lookup本身不再掃全部members，但呼叫量仍大 |
| app_contact_facts_prepare | — | 34,035 | 0.03 | raw facts 準備仍存在，非 #346 切料表路徑 |

call graph（同一原 gprof 檔）把工作來源說得更精確：

- `reference_contact_facts`→`geo_eval_depend` 700,246 次；`reference_member_placement_depend`→同函式 920,571 次；`reference_eval_timber_relation` 49,735 次，另有 W collection 等依賴來源。
- `geo_source_edge` 2,364,478 次中，active consumer 路徑做 1,640,207 次 find_edge；其中 **1,531,178 次新邊 append**。因此真正重複邊查找只有109,029次（約6.65%）。不能期待只加「重複邊 cache」就消除主要成本，更不能把新邊因多而省掉。
- `geo_source_node` 共有238,679次新節點 append，其餘既有節點仍須按 provider/key/key_size 身分核對。依賴邊必須同時保留 consumer/source/kind；跨 consumer 共用快取而漏邊正是原 B 禁止的事。

## 與現有前置切片逐函式對照

| 切片 | 具體實作 | 對這次 L 紅燈的意義 |
|---|---|---|
| #341 S `aa0e3938f17dc996ef5e7410db4844b31856d2a6` | contact_order_slot/index/order/earlier；重複 ID 的排序 last 與遮蓋 minimum 保留 | **L 已有這組函式**，不能當成尚待帶入的新改善；新 profile也有4,611,374次slot呼叫。 |
| #343 S `ccfaf057088a80c7aad4049f1c67e5eedfc2fdec` | contact_member_index_sort 穩定 merge-sort；contact_face_index_build/plane_range/index_insert/index_covered/contact_indexed_dedup，以 metadata plane coverage 取代插排與全雙圈 | L 仍是舊插排及 `for i/for j` 遮蓋去重，**此項尚未反映在 L**。是第一個應一般 merge、定向重測的現成修正，但不可預告足以跨過1.3。 |
| #346 S `39273bc0229fbbb16565134e1f8fad3a0d598c31` | WoodCutGroup.first/count＋WoodCutList.ids 單池；排序後 prefix offsets，第二遍填ID | 主要降切料表儲存；分群/排序仍O(N²)。這次原 gprof 無 wood_cut_list 的執行記錄，loadfile 命令未要求切料表，不當作 source graph 熱點修正。 |
| #347 S `324034812bb6effca68e0413bc0468595337b317` | panel_layout 的空 body 軸兩 phase 預檢 | 本次木構 scene 沒有面材填充；gprof 無 panel_layout/pf_build 執行記錄，不會直接改善這次 N64 載入。 |
| #348 F `0f695866c0ba12d2c70dfd7d40628d0fda0f905f` | 容量512與測試契約修正；沿用 #343/#346/#347 | 不是 geo_eval_depend 修正。擴大 World／固定 scratch 可能增加清零／複製與 stack 成本，正式尚未驗，不能拿容量提升冒充速度改善。 |

已對照 #348 的 source.c：geo_eval_depend 仍是 sealed guard→geo_source_node→geo_source_edge，通用查找／插入結構沒有因這些前置而改變。contact_world.c 則明確已有 #343 的新函式；所以「全部前置都會解掉」不成立，應隔離 #343 的效益再判斷。

## 最保守的執行次序與反證

1. **先一般 merge #343 的既有64容量版本**，保持原 A/B/C、原時間與 source-call 門檻；看同36樣本、同3輪、同程序的 N64 與小N結果。#341已在L；#346/#347沒有這條熱路徑；不要先用512結構膨脹混淆判讀。#343原方法／撤修控制與它影響的圖／守門／runtime項須在新F驗，不借其他SHA的綠。
2. 若仍紅，下一個可保守研究的小切片是 **K內部重用查找得到的空 hash slot／hash 值，在 append 不觸發 resize 時不再 hash、重走相同 probe chain**。現在 find_edge 完成查找後，geo_source_index_append 又 hash+probe 新邊；93.35% 的 find 是新邊路徑，這比只 cache duplicate 更對準原數據。node path也可獨立評估，但不一起大改。
3. 該研究不改 source.h 或公開 API，不少任何 node/edge，不動 callback 次數、不跳 seal/validation，不改 insertion order。resize、index配置失敗、線性fallback、node/edge grow精確大小重試、MEMORY/INVALID先後、sealed/reset 行為都必須沿原契約。不要為快而提前驗kind：原 node建立與後續kind拒絕的順序也有可觀察圖狀態。
4. 定向正反例必須涵蓋同 consumer/source 不同 kind、不同consumer同source、hash碰撞／wraparound、空鍵／未對齊鍵、索引容量跨半載入點而resize、index calloc失敗後線性fallback、node/edge realloc失敗與精確大小重試、reset後舊slot失效、sealed拒絕。既有 source_index_harness 已有碰撞、allocation、duplicate-no-allocation 等具名裁判，應保留並加對準新probe重用的控制。
5. 新probe控制可把「resize後棄舊slot重算」撤回、把kind/consumer比對撤回，對具名完整圖順序斷言正常exit1；再恢復0。也需整段優化撤回，保持語意case全綠而獨立操作量證據變紅。操作量基準沿真lookup/probe事件，不新增未知倍率門檻；正式速度仍由原≤1.3裁判決定。沒有任何新控制已跑或已殺的聲明。

## 量測不確定性與禁止的捷徑

原36樣本大量出現約50ms間隔；目前 Recorder 把stdout/stderr直接導檔，再用 `Popen.communicate(timeout=600)` 等待，CPython POSIX 的 timeout wait 可能採漸增輪詢。它是量測粒度的次要疑點，不是把紅燈判成環境通過的理由，也不與 #345 的其他 polling 修正混稱同一入口。本輪不改原工具、不扣除任何樣本時間、不重抽中位數。若要研究必用另一診斷並保留這份紅燈，經獨審後才決定是否需要新的正式收據。

gprof fix32僅0.05秒、fix64約0.46秒且每sample0.01秒，self桶粗；無main profile，本報告不冒稱已精確量出main與fix的CPU差額。可信結論是：來源重求值已大幅下降且達門檻，剩餘熱點轉到保持原依賴圖的查找／插入，以及 L 尚未套用的擋面排序／去重。#343是否足以達原1.3，必須等同新F正式交錯量測。
