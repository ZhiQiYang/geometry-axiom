"""Publish the one-line Linux directory/executable separation; no tests here."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
H=Path(__file__).resolve().parent
R=Path('/workspace/geo323-edge-probe-work-20261024')
OUT=H/'source-publication-r2'
OLD='9430bae568feb98805072930c92f9a03a1250d4e'
BR='codex/train337-edge-probe-20261024'
LEAF='tests/test_geo261_source_index.py'
report={'parent':OLD,'branch':BR,'source':None,'pushed':False,'formal_run':False,'commands':[],'exit':None}
def need(value,label):
    if not value:raise RuntimeError(label)
def sha(value):return hashlib.sha256(value).hexdigest()
def git(*args):
    env=os.environ.copy()
    for name in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_NAMESPACE'):env.pop(name,None)
    cmd=['git','-c','gc.auto=0','-c','maintenance.auto=false',*args]
    proc=subprocess.run(cmd,cwd=R,env=env,capture_output=True)
    folder=OUT/'commands'/f'{len(report["commands"])+1:03d}';folder.mkdir(parents=True)
    (folder/'stdout').write_bytes(proc.stdout);(folder/'stderr').write_bytes(proc.stderr)
    row={'command':cmd,'cwd':str(R),'actual_process_exit':proc.returncode,'stdout_sha256':sha(proc.stdout),'stderr_sha256':sha(proc.stderr)}
    (folder/'result.json').write_text(json.dumps(row,indent=2)+'\n');report['commands'].append(row)
    need(proc.returncode==0,'Git failure; original streams retained '+str(folder))
    return proc.stdout
def main():
    OUT.mkdir(exist_ok=False)
    try:
        fs=os.statvfs('/workspace');report['free_bytes_before']=fs.f_bavail*fs.f_frsize
        need(report['free_bytes_before']>=12*1024*1024,'source/index publication budget')
        need(git('rev-parse','HEAD').decode().strip()==OLD,'exact old owned source')
        need(git('symbolic-ref','--short','HEAD').decode().strip()==BR,'owned branch')
        need(git('status','--porcelain=v1','--untracked-files=all')==b'','owned source clean')
        need(git('ls-remote','--heads','origin','refs/heads/'+BR).decode().split()==[OLD,'refs/heads/'+BR],'remote old source exact')
        old=(H/'edge-probe-companion-v2-draft/candidate'/LEAF).read_bytes()
        new=(H/'edge-probe-companion-draft/candidate'/LEAF).read_bytes()
        need(sha(new)=='afa8e3b352e347065a4022857ff2583c67b6e90b70bbafb5d9ace145d37f1d1b','reviewed candidate pin')
        anchor=b'work=self.build.work/("edge-probe-cost-"+phase);work.mkdir()'
        replacement=b'work=self.build.work/("edge-probe-source-"+phase);work.mkdir()'
        need(old.count(anchor)==1 and new==old.replace(anchor,replacement),'only directory prefix changed')
        need(git('show',OLD+':'+LEAF)==old and (R/LEAF).read_bytes()==old,'exact public old bytes')
        (R/LEAF).write_bytes(new)
        need(git('diff','--name-only').decode().splitlines()==[LEAF],'single test leaf scope')
        git('diff','--check');git('add','--',LEAF)
        need(git('diff','--cached','--name-only').decode().splitlines()==[LEAF],'single staged test leaf')
        git('commit','-m','Separate probe source directories from Linux executable paths')
        source=git('rev-parse','HEAD').decode().strip();report['source']=source
        need(git('show','-s','--format=%P',source).decode().strip()==OLD,'ordinary source parent')
        need(git('diff','--name-only',OLD,source).decode().splitlines()==[LEAF],'only test path fix committed')
        need(git('show',source+':'+LEAF)==new,'committed exact candidate')
        need(git('status','--porcelain=v1','--untracked-files=all')==b'','clean source after commit')
        git('push','origin','HEAD:refs/heads/'+BR)
        need(git('ls-remote','--heads','origin','refs/heads/'+BR).decode().split()==[source,'refs/heads/'+BR],'public new source exact')
        report['pushed']=True;report['exit']=0
    except BaseException as exc:
        report['error']=repr(exc);report['exit']=1
    finally:
        (OUT/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({k:report.get(k)for k in ('source','pushed','exit','error')}))
    return report['exit']
if __name__=='__main__':sys.exit(main())
