"""Independent small integer/table model, NOT C/runtime/subject execution."""
import json
from pathlib import Path
MASK=(1<<64)-1
def mix(h,v):
    h=((h^v)*11400714785074694791)&MASK
    return h^(h>>32)
def edge_hash(edge):
    h=14695981039346656037
    for value in edge:h=mix(h,value)
    return h
class Table:
    def __init__(self,reuse,retain_resize=False,wrong_slot=False,fail_counts=()):
        self.reuse=reuse;self.retain_resize=retain_resize;self.wrong_slot=wrong_slot
        self.fail_counts=set(fail_counts);self.edges=[];self.table=[];self.hash_calls=0;self.resizes=[];self.fallbacks=[]
    def hashed(self,edge):self.hash_calls+=1;return edge_hash(edge)
    def find(self,edge):
        if not self.table:
            return (self.edges.index(edge),None) if edge in self.edges else (None,None)
        mask=len(self.table)-1;slot=self.hashed(edge)&mask
        while self.table[slot]:
            if self.edges[self.table[slot]-1]==edge:return self.table[slot]-1,None
            slot=(slot+1)&mask
        return None,((slot+1)&mask if self.wrong_slot else slot)
    def add(self,edge):
        found,empty=self.find(edge)
        if found is not None:return
        self.edges.append(edge);count=len(self.edges);first=count-1
        if count>len(self.table)//2:
            nxt=len(self.table) or 16
            while count>nxt//2:nxt*=2
            if count in self.fail_counts:
                self.table=[];self.fallbacks.append(count);return
            self.resizes.append((count,len(self.table),nxt))
            self.table=[0]*nxt;first=0
            if not self.retain_resize:empty=None
        if self.reuse and empty is not None and empty<len(self.table) and not self.table[empty]:
            self.table[empty]=count;return
        for i in range(first,count):
            mask=len(self.table)-1;slot=self.hashed(self.edges[i])&mask
            while self.table[slot]:slot=(slot+1)&mask
            self.table[slot]=i+1
def semantic_case(label,edges,**kwargs):
    return semantic_stream(label,edges+list(reversed(edges))+edges,**kwargs)
def semantic_stream(label,stream,**kwargs):
    table=Table(**kwargs);oracle=[]
    for position,edge in enumerate(stream,1):
        if edge not in oracle:oracle.append(edge)
        table.add(edge)
        if table.edges!=oracle:
            return {'label':label,'model_verdict':False,'first_position':position,'first_edge':edge,'actual_count':len(table.edges),'expected_count':len(oracle),'resizes':table.resizes,'fallbacks':table.fallbacks}
    return {'label':label,'model_verdict':True,'edges':len(oracle),'resizes':table.resizes,'fallbacks':table.fallbacks}
def main():
    edges=[(0,i,0) for i in range(1,13)]
    costs=[]
    for name,reuse in [('fixed',True),('whole-withdrawn',False),('restored',True)]:
        t=Table(reuse)
        for e in edges:t.add(e)
        costs.append({'phase':name,'insertions':12,'hash_calls':t.hash_calls,'oracle_equal':t.edges==edges,'resizes':t.resizes})
    assert [x['hash_calls'] for x in costs]==[21,31,21]
    boundary=[(0,i,0) for i in range(1,34)]+[(1,1,0),(1,1,1),(1,1,2),(0,1,1)]
    cases=[semantic_case('normal-multiple-double-capacity',boundary,reuse=True),
           semantic_case('original-whole-withdrawal-same-ordered-graph',boundary,reuse=False),
           semantic_case('index-allocation-fallback-at-initial-9-and-17',boundary,reuse=True,fail_counts=(1,9,17)),
           semantic_case('negative-retain-pre-resize-slot',boundary,reuse=True,retain_resize=True),
           semantic_case('negative-reuse-next-empty-slot',boundary,reuse=True,wrong_slot=True)]
    assert [x['model_verdict'] for x in cases]==[True,True,True,False,False]
    c_stream=[]
    for i in range(1,34):
        c_stream.append((0,i,0))
        if i==9:c_stream.extend([(0,9,0),(0,1,0)])
    extras=[(1,1,0),(1,1,1),(1,1,2),(0,1,1)]
    c_stream.extend(extras+list(reversed(extras))+[(0,i,0) for i in range(33,0,-1)])
    exact=[semantic_stream('exact-v2-C-sequence-fixed',c_stream,reuse=True),
           semantic_stream('exact-v2-C-sequence-withdrawn',c_stream,reuse=False),
           semantic_stream('exact-v2-C-sequence-index-fallback',c_stream,reuse=True,fail_counts=(1,9,17)),
           semantic_stream('exact-v2-C-sequence-retain-resize-slot',c_stream,reuse=True,retain_resize=True),
           semantic_stream('exact-v2-C-sequence-wrong-slot',c_stream,reuse=True,wrong_slot=True)]
    assert [x['model_verdict'] for x in exact]==[True,True,True,False,False]
    assert exact[3]['first_position']==10 and exact[3]['first_edge']==(0,9,0)
    assert exact[3]['actual_count']==10 and exact[3]['expected_count']==9
    assert exact[4]['first_position']==40 and exact[4]['first_edge']==(0,1,1)
    assert exact[4]['actual_count']==38 and exact[4]['expected_count']==37
    out={'scope':'Pure Python independent finite open-addressing arithmetic model; NOT C, formal test, mutation kill or performance acceptance','cost_derivation':'12 distinct edges: initial insert 1 hash; inserts 2..8 7 fixed vs14 old; insert9 resize32 costs1+9 in both; inserts10..12 3 fixed vs6 old =>21/31/21','costs':costs,'cases':cases,'exact_v2_c_sequence_model':exact,'limits':['Does not model C pointers/realloc or certify allocation safety.','Actual C old/new/restored compiler and normal 0/1/0 receipts remain UNRUN.','Formal original 1.3 wall target and 175/350 ordered graph+guards are unchanged.']}
    p=Path(__file__).with_name('EDGE_PROBE_ALGORITHM_WITNESS.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()
