"""Pure receipt-parser adverse inputs; does not import or run subject/C."""
from pathlib import Path
import ast
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
RUNNER=HERE/'run_source_index_suite.py'
OUT=HERE/'parser-synthetic-audit-v2'
OUT.mkdir(exist_ok=False)
tree=ast.parse(RUNNER.read_text())
wanted={'sha','need','stream','verify_binary','control_proofs'}
module=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted],type_ignores=[])
ns={'Path':Path,'hashlib':hashlib,'re':re,'OUT':OUT}
exec(compile(module,'extracted-pure-receipt-parser','exec'),ns)
controls=[('never-node','nodes','duplicate-node'),('never-edge','edges','duplicate-edge'),
 ('node-key-bytes-ignored','nodes','merged-node'),('node-probe-miss','nodes','duplicate-node'),
 ('node-probe-hit','nodes','merged-node'),('edge-kind-ignored','edge-collisions','missing-edge'),
 ('edge-probe-miss','edge-collisions','duplicate-edge'),('edge-probe-hit','edge-collisions','missing-edge'),
 ('edge-reuse-old-slot-after-resize','edge-probe','duplicate-edge'),('edge-reuse-wrong-empty-slot','edge-probe','duplicate-edge')]
binary=OUT/'synthetic-binary'
binary.write_bytes(b'SYNTHETIC PARSER INPUT; NOT EXECUTABLE\n')
meta={'retained':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
rows=[]
def add(name,case,code,stdout,stderr):
    number=len(rows)+1
    row={'number':number,'args':[[name,case]],'returncode':code,'actual_executable':meta.copy()}
    for label,body in [('stdout',stdout),('stderr',stderr)]:
        dest=OUT/f'{number:03d}-{label}';dest.write_bytes(body)
        row[label]={'captured':True,'path':str(dest),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    rows.append(row)
for name,case,marker in controls:
    add('source-index-client',case,0,f'PASS {case}\n'.encode(),b'')
    add('source-index-'+name,case,1,b'',f'ASSERT:{marker} line=123 expr=example\n'.encode())
    add('source-index-client',case,0,f'PASS {case}\n'.encode(),b'')
for phase,code,count in [('fixed',0,21),('withdrawn',1,31),('restored',0,21)]:
    add('edge-probe-cost-'+phase,'edge-probe',0,b'PASS edge-probe\n',b'')
    add('edge-probe-cost-'+phase,'edge-probe-cost',code,(f'PROBE_HASH_CALLS={count}\n'+('PASS edge-probe-cost\n' if not code else '')).encode(),b'ASSERT:edge-probe-reuses-lookup-hash line=44 expr=observed==21\n' if code else b'')
proofs,total=ns['control_proofs']({'commands':rows})
assert len(proofs)==11 and total==36
checks=[{'case':'synthetic-normal-complete','accepted':True,'proofs':len(proofs)}]
for name,change in [
 ('signal-is-not-valid-assertion',lambda r:r[1].update(returncode=-11)),
 ('missing-original-stream',lambda r:r[1]['stderr'].update(captured=False)),
 ('restoration-before-withdrawal',lambda r:r[2].update(number=0)),
 ('missing-own-restoration',lambda r:r.pop(2)),
 ('phase-order-reversed',lambda r:r[-1].update(number=1)),
 ('wrong-whole-operation-count-exit',lambda r:r[-3].update(returncode=0))]:
    copied=json.loads(json.dumps(rows));change(copied)
    try:ns['control_proofs']({'commands':copied})
    except (RuntimeError,AssertionError) as exc:
        checks.append({'case':name,'rejected':True,'reason':str(exc)})
    else:raise AssertionError(name+' incorrectly accepted')
result={'scope':'Pure extracted receipt-parser checks; explicitly nonexecutable synthetic bytes; NOT C/subject/runtime evidence',
 'runner_sha256':hashlib.sha256(RUNNER.read_bytes()).hexdigest(),'checks':checks,'exit':0,
 'initial_failure':'../parser-synthetic-audit/INITIAL_FAILURE.txt; v1 parser borrowed a later same-case baseline; original runner retained'}
(OUT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
