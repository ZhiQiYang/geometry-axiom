# 最小 edge probe 重用外稿：安全範圍與正式反證

產品外稿只有 `geometry-core/kernel/source.c`，基於 L `7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`。
完整 diff：`edge-probe-draft/EDGE_PROBE_ONLY.patch`，SHA `c7bd55eebd0d7d3f602865a652fb7b0fc5a928db6e04367bb6bbb07db5ade8c3`。原16890 bytes／新17276 bytes；八個替換反向還原逐 byte 相同。沒有套入任何 repository、branch 或 tests，沒有 C 編譯。

## 精確的 L → S343 closure

唯讀比較 S343=`ccfaf057088a80c7aad4049f1c67e5eedfc2fdec`：排除 evidence／fixtures 後，產品 C/H/inc/Python/JS 差異只有：

1. `geometry-templates/woodworking/native/contact_world.c`：擋面 member 穩定排序與 plane coverage index。
2. `geometry-templates/woodworking/geometry_woodworking/model_sources.py`：#339 對缺少／未分類 faces 改成原具條號的 ValueError 診斷，不是 C loadfile 路徑。

native C closure 只有 contact_world.c 改動，沒有 source.c／contact headers／app native 的另一項差異。所以隔離 #343 的原生效益可只用該 source leaf 替換、保 L 的其餘編譯 closure 與 flags；這種診斷變體必須明標非正式 F。正式仍由 root 一般 merge #343／前置進同列車，保留 Python 修正及 L 已有工作，不能拿 S343 整樹覆寫 L。

非 evidence／fixture 的 tests 差異有八個路徑：`geo261_contact_world_harness.c`、`run_all.expected.json`、`section_profile_mutation_check.py`、`test_geo261_contact_sources.py`、`test_geo261_wood_contact_world.py`、`test_geometry_host_sources.py`、`test_rectangular_template.py`、`test_section_profile_native.py`。這是雙端 tree 差異，不代表它們全屬 #343 新功能；normal merge 要保留 L 的 Q38 等修正。兩端 merge-base 為 `9a05ae785846446ce8982379b4cb66f4ffde6e5c`。

## 這一刀只消除 edge 新插入的第二次 probe

- `geo_source_find_edge` 只有一個正式 caller；增加私有 out 參數。indexed miss 時回傳已走到的空槽，hit 或無 index 時不賦值，caller 預設 `SIZE_MAX`。
- `geo_source_edge` 原 kind guard、active guard、重複判斷、edge_count 上限、array realloc及失敗結果順序保持原樣。只有成功 append 後把空槽傳到私有 `geo_source_index_append`。
- index容量不變、原空槽仍空時，寫 `edge_count`（即剛新增序號+1）到相同槽；不改 edge array，不改公開列舉順序。
- 任何 rebuild 成功都立即把空槽標為 `SIZE_MAX`，走原完整rehash。rebuild calloc失敗走原 fallback，free舊index、capacity=0，之後線性搜尋；沒有新增 MEMORY 條件。
- node caller固定傳 `SIZE_MAX`；node lookup、hint 256槽選法、node hash完全沒有改。私有函式簽名變動不是 source.h 公開 API 變更。
- 從 find 到 append 之間沒有provider callback或其它graph mutation；只有原edge array grow。其realloc不動edge index，所以同容量時空槽仍適用。不新增對並行／reentrant allocator 的承諾。

原source_index控制的函式名／first definition位置、`while(ctx->node_index[slot]){`、`while(ctx->edge_index[slot]){`、完整kind等號仍保留。never-find控制若提早return，空槽仍為caller的SIZE_MAX，不能令控制因新out參數變成未初始化UB；應仍走原插入路徑並正常抓重複。

## 確定性算法 witness，與正式性能門檻分欄

`edge_probe_algorithm_witness.py` 是獨立的小型 Python 整數／開放定址表模型，**不是執行 C 或 candidate**。它沿原64-bit edge hash、初始16槽、半滿擴表；來源列 `(consumer=0, source=1..12, kind=0)`：

| 段 | 原hash次數 | 重用後hash次數 |
|---|---:|---:|
| 第一條，index初建16 | 1 | 1 |
| 第2～8條，同容量 | 14 | 7 |
| 第9條，16→32：查找1＋rehash9 | 10 | 10 |
| 第10～12條，同容量 | 6 | 3 |
| 合計 | **31** | **21** |

已執行這個純模型，輸出 `EDGE_PROBE_ALGORITHM_WITNESS.json`：固定／完整撤回／恢復為21／31／21，完整37-edge序列一致；count9、17、33分別經16→32、32→64、64→128；index分配在count1/9/17故障後仍與線性序列一致。故意保留resize前slot、或回傳下一個空slot的兩個模型反例都造成重複edge而被精確序列oracle抓到。**模型未模擬C指標／realloc，不證明C配置安全、編譯通過或突變已殺。**

正式新增小C witness應沿既有 NativeBuild 與 source_index_harness 的 allocator shim，只在診斷TU的原 `geo_source_edge_hash` 入口加可觀測計數，不改函式回傳或其它邏輯。先以公開describe建立必要nodes，才把計數歸零；真執行12個不同edge依賴。語意全序列在固定／整段撤回／恢復都須綠；具名精確算法斷言在21／31／21下呈正常0／1／0。這是已明確推導的unit操作次數，不是另設專案速度倍率。

## 定向撤回／恢復與原裁判

- **整段edge優化撤回**：compiled source逐 byte還原L（同輪其它已整合closure不變）。語意case照過，操作數具名斷言應紅；恢復版本重新編譯為候選bytes再綠。
- **resize遺留slot**：只撤掉成功rebuild後的 `empty_slot=SIZE_MAX`。新index不可只留下新edge而丟掉舊index項。37-edge固定資料包含9/17/33邊界，之後倒序與原序再讀，完整edge數與順序必正常斷言紅。
- **碰撞鏈錯槽**：miss回傳真正空槽的下一槽，不能誤把未經probe的另一空槽當有效插入點；倒序再次查找會因原空槽提早終止而重複edge。小型C fixture須確認具名precondition，不以崩潰／timeout當kill。
- **配置降級**：沿原 `test_allocation_failure_falls_back_without_changing_existing_state` 與 `test_array_growth_retries_exact_size_and_preserves_state_on_memory`。index calloc失敗仍可用線性圖；array grow兩種分配都失敗才沿原 MEMORY，既有edge／node序列不變。不得把index失敗改成早回 MEMORY 或保留不完整舊index。
- **原全部source-index控制**：碰撞／wraparound、provider/key-size/key bytes、空鍵、各kind、cross-consumer、sealed、reset、missing/failed/cycle、精確大小realloc重試全保留；原30秒case／NativeBuild限制不改。

原A/B/C裁判必保留原固定171個scene＋N16/32/48/64＝**175 scenes**，base/fix trace共**350**次（另外同scope的非tracestdout對照照原工具執行）。每個seal的node與edge內容及順序須逐 byte比，五個guard計數逐項比，並核stdout、stderr與trace不改可觀察結果；不能只比總node/edge數或hash摘要。root工具額外命名的新I11scene另列，不混換原175。

對新probe候選，應有兩種清楚命名的比較：原指定base→新F（合併裁判）；同整合closure、只撤回probe的版本→新F（定位這一刀是否改圖）。後者不能取代前者，也不能拿它洗掉本輪L已留下的原compare紅燈。若原base比較仍因其他產品語意差異紅，保留精確scene／firstdiff，不能偷偷改base。

定向故意漏kind／跨consumer／resize丟邊等控制，要使**完整圖序列**比較器正常拒絕，不能改守門流量或用崩潰冒充；故意少一個守門事件則原guard比較器必拒絕。所有compiler/link exit、child exit、原stderr、source variant與binary hash分開封存，不能用self-test布林值假扮OS退出碼。

## node hint 目前只有線索，沒有偷修

L profile顯示node呼叫2,364,478、find_node1,737,765、新node238,679：扣除新增後仍約1,499,086次完整查找既有節點。這支持研究hint命中率，**不能證明某種key末byte分布就是根因**。例如W authored definition key是kind+32bit id（5bytes），末byte是低位ID，並非總為0；contact collection key末byte確是feature index0，但活躍query切換頻率仍需診斷。首輪不改hash策略；未量到provider/key-family/hint碰撞分類前，不把「fullhash hint一定更快」寫成結論。

目前只有外稿與純模型。新F、正常merge、正式C／175/350／perf／帳本與架構都由root排程；本線不開另一條#323分支。
