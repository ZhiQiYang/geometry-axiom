"""External AST/text assembly, not subject import/discovery/C execution."""
import ast,difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/tmp/train337-323-f64d638f-source')
OUT=HERE/'edge-probe-companion-draft'
product=HERE/'edge-probe-draft';m=json.loads((product/'MANIFEST.json').read_text())
paths=['geometry-core/kernel/source.c','tests/geo261_source_index_harness.c','tests/test_geo261_source_index.py']
before={p:(ROOT/p).read_bytes() for p in paths};after={paths[0]:(product/'candidate'/paths[0]).read_bytes()}
c=before[paths[1]].decode();anchor='#include "source.c"';assert c.count(anchor)==1
c=c.replace(anchor,'static uint64_t edge_probe_hash_calls;\n'+anchor)
anchor='int main(int argc,char **argv)\n';assert c.count(anchor)==1
addition=(HERE/'PROBE_C_ADDITION.txt').read_text()+'\n';c=c.replace(anchor,addition+anchor)
anchor='    if(!strcmp(argv[1],"nodes"))result=nodes_and_seal();';assert c.count(anchor)==1
route='    if(!strcmp(argv[1],"edge-probe"))result=probe_edges();\n    else if(!strcmp(argv[1],"edge-probe-cost"))result=probe_cost();\n    else if(!strcmp(argv[1],"nodes"))result=nodes_and_seal();'
c=c.replace(anchor,route);after[paths[1]]=c.encode()
p=before[paths[2]].decode();anchor='class SourceIndex(unittest.TestCase):';assert p.count(anchor)==1
edits=[(r['before'],r['after']) for r in m['edits']]
constant='EDGE_PROBE_REUSE_EDITS = '+repr(edits)+'\n\n\n'
p=p.replace(anchor,constant+anchor);anchor='\n\nif __name__ == "__main__":';assert p.count(anchor)==1
p=p.replace(anchor,'\n'+(HERE/'PROBE_PY_ADDITION.txt').read_text()+anchor);after[paths[2]]=p.encode()
def methods(data):
 tree=ast.parse(data);cl=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='SourceIndex')
 return {x.name:ast.dump(x,include_attributes=False) for x in cl.body if isinstance(x,ast.FunctionDef)}
old=methods(before[paths[2]]);new=methods(after[paths[2]])
assert all(new[name]==body for name,body in old.items())
oldtests=[name for name in old if name.startswith('test_')];newtests=[name for name in new if name.startswith('test_')]
assert len(oldtests)==14 and len(newtests)==17
assert c.replace(route,'    if(!strcmp(argv[1],"nodes"))result=nodes_and_seal();').replace(addition,'').replace('static uint64_t edge_probe_hash_calls;\n','')==before[paths[1]].decode()
sha=lambda data:hashlib.sha256(data).hexdigest()
patch=''
for path in paths:
 for side,data in [('before',before[path]),('candidate',after[path])]:
  dest=OUT/side/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 patch+=''.join(difflib.unified_diff(before[path].decode().splitlines(keepends=True),after[path].decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
(OUT/'THREE_LEAF.patch').write_text(patch)
r={'source_sha':m['source_sha'],'scope':'External text/AST only; no C/import/discovery/branch/registry writes','patch_sha256':sha(patch.encode()),'methods_before':oldtests,'methods_after':newtests,'original_all_helpers_ast_identical':True,'original_c_restores_exact':True,'product_patch_sha256':m['patch_sha256'],'files':{path:{'before_sha256':sha(before[path]),'after_sha256':sha(after[path]),'after_bytes':len(after[path])} for path in paths},'expected_plan':{'suite':'py:test_geo261_source_index','before':14,'after':17,'status':'UNAPPLIED; runtime discovery remains UNRUN'},'formal':'ALL UNRUN: original 14 plus3 methods, original 8 controls plus2 new semantic and whole-work withdrawal/restoration'}
(OUT/'MANIFEST.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
