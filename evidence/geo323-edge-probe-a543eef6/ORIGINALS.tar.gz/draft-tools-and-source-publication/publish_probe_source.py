"""Publish only the reviewed probe source; no C, ledger, or architecture runs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/geometry-axiom')
PLAN = json.loads((HERE / 'WORKTREE_PLAN.json').read_text())
WORK = Path(PLAN['worktree'])
BASE = PLAN['base']
BRANCH = PLAN['branch']
CANDIDATE = HERE / 'edge-probe-companion-draft'
OUT = HERE / 'source-publication'
ALLOW = PLAN['source_change_allowlist']
EXPECTED_PATCH = 'b512899e05b161067dd9fc68b66ad92d52c119a01d333963345f6cf5ded41aaa'
report = {'base': BASE, 'branch': BRANCH, 'worktree': str(WORK),
          'source': None, 'pushed': False, 'formal_run': False,
          'ledger_regenerated': False, 'architecture_regenerated': False,
          'commands': [], 'space': [], 'exit': None}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def need(condition, label):
    if not condition:
        raise RuntimeError(label)

def run(args, cwd=ROOT, data=None, allowed=(0,)):
    number = len(report['commands']) + 1
    command = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *args]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = os.environ.copy()
    redirected = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
                  'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_NAMESPACE')
    removed = [name for name in redirected if name in env]
    for name in redirected:
        env.pop(name, None)
    result = subprocess.run(command, cwd=cwd, input=data, capture_output=True, env=env)
    folder = OUT / 'commands' / f'{number:03d}'
    folder.mkdir(parents=True)
    (folder / 'stdout').write_bytes(result.stdout)
    (folder / 'stderr').write_bytes(result.stderr)
    row = {'command': command, 'cwd': str(cwd), 'started_utc': start, 'removed_git_redirect_keys': removed,
           'exit': result.returncode,
           'stdout': {'bytes': len(result.stdout), 'sha256': sha(result.stdout)},
           'stderr': {'bytes': len(result.stderr), 'sha256': sha(result.stderr)}}
    if data is not None:
        (folder / 'stdin').write_bytes(data)
        row['stdin'] = {'bytes': len(data), 'sha256': sha(data)}
    (folder / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
    report['commands'].append(row)
    need(result.returncode in allowed, 'Git failed; preserve original command streams: ' + str(folder))
    return result.stdout

def git(*args, cwd=ROOT):
    return run(list(args), cwd=cwd)

def space(label, minimum):
    fs = os.statvfs('/workspace')
    free = fs.f_bavail * fs.f_frsize
    report['space'].append({'label': label, 'free_bytes': free, 'minimum_bytes': minimum})
    need(free >= minimum, 'Insufficient private source publication budget')

def private_git_path(name):
    p = Path(git('rev-parse', '--git-path', name, cwd=WORK).decode().strip())
    return p if p.is_absolute() else WORK / p

def clean():
    need(git('status', '--porcelain=v1', '--untracked-files=all', cwd=WORK) == b'', 'own worktree dirty')
    need(git('diff', '--cached', 'HEAD', '--name-only', cwd=WORK) == b'', 'own index differs from HEAD')
    need(git('diff', '--name-only', cwd=WORK) == b'', 'own tracked files differ from index')

def main():
    OUT.mkdir(exist_ok=False)
    try:
        space('before-first-Git-write', 12 * 1024 * 1024)
        need(not WORK.exists(), 'new dedicated path must not exist')
        need(git('config', '--get', 'extensions.worktreeConfig').strip() == b'true', 'existing worktree-specific config required')
        need(git('rev-parse', BASE + '^{commit}').decode().strip() == BASE, 'base object missing')
        need(git('for-each-ref', '--format=%(refname)', 'refs/heads/' + BRANCH) == b'', 'dedicated branch already exists')
        need(git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH) == b'', 'remote branch already exists')
        manifest = json.loads((CANDIDATE / 'MANIFEST.json').read_text())
        need(sha((CANDIDATE / 'THREE_LEAF.patch').read_bytes()) == EXPECTED_PATCH, 'reviewed companion pin changed')
        for path, pins in manifest['files'].items():
            need(git('show', BASE + ':' + path) == (CANDIDATE / 'before' / path).read_bytes(), 'base source differs from reviewed before: ' + path)
            need(sha((CANDIDATE / 'candidate' / path).read_bytes()) == pins['after_sha256'], 'candidate changed: ' + path)
        paths = sorted({x['path'] for x in PLAN['paths']} | {'.gitattributes', '.gitignore'})
        for path in paths:
            git('cat-file', '-e', BASE + ':' + path)
        patterns = ''.join('/' + path + '\n' for path in paths).encode()
        (OUT / 'SPARSE_STDIN.txt').write_bytes(patterns)
        git('worktree', 'add', '--no-checkout', '-b', BRANCH, str(WORK), BASE)
        need(sorted(p.name for p in WORK.iterdir()) == ['.git'], 'fresh no-checkout path must only contain .git')
        need(git('rev-parse', 'HEAD', cwd=WORK).decode().strip() == BASE, 'wrong new HEAD')
        need(git('symbolic-ref', '--short', 'HEAD', cwd=WORK).decode().strip() == BRANCH, 'wrong new branch')
        need(not private_git_path('index').exists(), 'fresh index unexpectedly exists')
        run(['sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=WORK, data=patterns)
        need(not private_git_path('index').exists(), 'expected recorded no-checkout bootstrap without index')
        need(not private_git_path('index.lock').exists(), 'fresh index lock exists')
        need(private_git_path('info/sparse-checkout').read_bytes() == patterns, 'sparse patterns mismatch')
        git('read-tree', '--dry-run', '-m', '-u', BASE, cwd=WORK)
        git('read-tree', '-m', '-u', BASE, cwd=WORK)
        clean()
        for path in manifest['files']:
            need((WORK / path).read_bytes() == (CANDIDATE / 'before' / path).read_bytes(), 'working before bytes changed')
            (WORK / path).write_bytes((CANDIDATE / 'candidate' / path).read_bytes())
        registry = WORK / 'tests/run_all.expected.json'
        old = registry.read_bytes()
        obj = json.loads(old)
        need(obj['suites']['py:test_geo261_source_index'] == {'mode': 'count', 'count': 14, 'unit': 'test'}, 'unexpected original source-index registry row')
        before = b'"py:test_geo261_source_index": {\n      "mode": "count",\n      "count": 14,\n      "unit": "test"\n    }'
        after = before.replace(b'"count": 14', b'"count": 17')
        need(old.count(before) == 1, 'registry literal must be unique')
        updated = old.replace(before, after)
        obj['suites']['py:test_geo261_source_index']['count'] = 17
        need(json.loads(updated) == obj, 'registry scope differs')
        registry.write_bytes(updated)
        need(sorted(git('diff', '--name-only', cwd=WORK).decode().splitlines()) == sorted(ALLOW), 'unexpected source edits')
        git('diff', '--check', cwd=WORK)
        git('add', '--sparse', '--', *ALLOW, cwd=WORK)
        need(sorted(git('diff', '--cached', '--name-only', cwd=WORK).decode().splitlines()) == sorted(ALLOW), 'unexpected staged paths')
        git('commit', '-m', 'Reuse empty edge-index slots without changing graph order', cwd=WORK)
        source = git('rev-parse', 'HEAD', cwd=WORK).decode().strip()
        report['source'] = source
        need(git('show', '-s', '--format=%P', source, cwd=WORK).decode().strip() == BASE, 'source must be normal single-parent commit')
        clean()
        for path, pins in manifest['files'].items():
            need(sha(git('show', source + ':' + path, cwd=WORK)) == pins['after_sha256'], 'committed source changed')
        need(git('show', source + ':tests/run_all.expected.json', cwd=WORK) == updated, 'committed registry changed')
        git('push', 'origin', 'HEAD:refs/heads/' + BRANCH, cwd=WORK)
        need(git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH, cwd=WORK).decode().split()[0] == source, 'remote does not resolve source')
        report['pushed'] = True
        space('after-normal-push', 0)
        report['exit'] = 0
    except BaseException as exc:
        report['exit'] = 1
        report['error'] = repr(exc)
    finally:
        (OUT / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k: report.get(k) for k in ('source', 'pushed', 'exit', 'error')}))
    return report['exit']

if __name__ == '__main__':
    sys.exit(main())
