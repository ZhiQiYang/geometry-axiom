#!/usr/bin/env python3
"""僅由既有 WSL 鎖派生；停止旗標只終止本次啟動並可證明歸屬的子行程。"""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import uuid


def process(pid):
    try:
        tail=Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()
        return {'pid':int(pid),'parent':int(tail[1]),'start':int(tail[19]),'state':tail[0]}
    except (OSError,ValueError,IndexError):return None


def ancestors(pid):
    result=set()
    while pid>1 and pid not in result:
        result.add(pid);row=process(pid)
        if not row:break
        pid=row['parent']
    return result


def owned(root,token):
    rows={}
    selected=set()
    needle=b'GEOMETRY_CODEX_OWNER='+token.encode()
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():continue
        row=process(int(entry.name))
        if not row:continue
        rows[row['pid']]=row
        try:
            if needle in (entry/'environ').read_bytes().split(b'\0'):selected.add(row['pid'])
        except OSError:pass
    if root['pid'] in rows and rows[root['pid']]['start']==root['start']:selected.add(root['pid'])
    while True:
        extra={pid for pid,row in rows.items() if row['parent'] in selected}-selected
        if not extra:break
        selected.update(extra)
    selected.discard(os.getpid())
    return [rows[pid] for pid in selected if rows[pid]['state']!='Z']


def stop_owned(root,token):
    recorded={}
    for sig in (signal.SIGTERM,signal.SIGKILL):
        rows=owned(root,token)
        for row in sorted(rows,key=lambda r:r['pid'],reverse=True):
            now=process(row['pid'])
            if not now or now['start']!=row['start'] or now['state']=='Z':continue
            try:os.kill(row['pid'],sig)
            except ProcessLookupError:continue
            recorded.setdefault(row['pid'],{'pid':row['pid'],'parent':row['parent'],'start':row['start'],'signals':[]})['signals'].append(sig.name)
        time.sleep(.2)
    return {'signalled':list(recorded.values()),'remaining':owned(root,token)}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stop',required=True,type=Path)
    parser.add_argument('--receipt',required=True,type=Path)
    parser.add_argument('command',nargs=argparse.REMAINDER)
    a=parser.parse_args();command=a.command[1:] if a.command[:1]==['--'] else a.command
    if not command:parser.error('缺少子指令')
    holder=Path('/run/lock/ga-wsl-v3.holder').read_text()
    match=re.search(r'\bpid=(\d+)',holder)
    if not match or int(match[1]) not in ancestors(os.getpid()):raise RuntimeError('必須由 wsl_locked3.sh 的目前鎖持有者派生')
    if a.receipt.exists():raise RuntimeError('拒絕覆蓋監督收據')
    a.receipt.parent.mkdir(parents=True,exist_ok=True)
    result={'schema':'geometry-owned-process-supervisor/1','holder':holder.strip(),'command':command,'stop_file':str(a.stop),'started':time.time()}
    if a.stop.exists():
        result.update(status='cancelled-before-start',exit_code=130)
        a.receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');return 130
    token=uuid.uuid4().hex
    child=subprocess.Popen(command,env=dict(os.environ,GEOMETRY_CODEX_OWNER=token),start_new_session=True)
    root=process(child.pid)
    if root is None:raise RuntimeError('無法取得新子行程的出生時間')
    result.update(root=root,owner=token)
    cancelled=False
    while child.poll() is None:
        if a.stop.exists():cancelled=True;break
        try:child.wait(timeout=.25)
        except subprocess.TimeoutExpired:pass
    if cancelled:
        result['cleanup']=stop_owned(root,token)
        child.wait(timeout=5)
        code=130
    else:
        result['cleanup']=stop_owned(root,token)
        code=child.returncode if child.returncode>=0 else 128-child.returncode
    result.update(status='cancelled' if cancelled else 'completed',child_exit=child.returncode,exit_code=code,ended=time.time())
    a.receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('WSL 本次工作監督 '+json.dumps({k:result[k] for k in ['status','child_exit','exit_code','cleanup']},ensure_ascii=False),flush=True)
    return code


if __name__=='__main__':raise SystemExit(main())
