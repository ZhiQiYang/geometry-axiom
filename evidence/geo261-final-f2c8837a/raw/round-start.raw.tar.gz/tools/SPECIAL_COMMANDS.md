# 新一輪專項工具：僅已準備，尚未執行

工具來源為 `/tmp/geo261-cloud-0da1f08c-20261022T0827/tools` 的 14 個來源檔，沒有複製舊驗收結果。`ADAPTATION.json` 記錄逐檔原始／執行版 SHA256、byte 數及每次機械路徑替換；`original-source/` 保留原 bytes。未改斷言、取樣數、負控制、比較門檻或逾時。`COMMANDS.json` 列實際 argv 與外部檔相依。

目標來源尚待根 agent 凍結於：

```
/tmp/g261r1/source-final
```

以下 `<FINAL_SHA>` 必須換成該 checkout 的完整 HEAD；不可把舊交接 SHA 填進新結果。新 round runner 持有本 scratch 的 `heavy.lock`，每個專項自己沒有重取該鎖。不要呼叫舊 `ci_run.py`、`ci_job.py`、`cancel_supervisor.py` 或舊 `run_special.py` 來執行本輪；它們的 WSL namespace／HOME／舊輪次成功前提不適用。

## 未執行的 P52 main 準備命令

```bash
mkdir -p /tmp/g261r1/work/p52-main/tmp
git clone -q --no-checkout /tmp/g261r1/source-final /tmp/g261r1/work/p52-main/main
git -C /tmp/g261r1/work/p52-main/main -c core.autocrlf=false checkout -q --detach adbaebf9c73ea6801d7b4d5214e4b846b132923b
cd /tmp/g261r1/work/p52-main/main
TMPDIR=/tmp/g261r1/work/p52-main/tmp npm run build
```

原 `postfix_validate.py` 在自己的 `work/codex-geo261-<SHA8>/tmp` 啟動服務，故正式量測第一次啟動仍可能再編譯；90 秒 readiness 上限保持原值。**不要預先建立 `work/codex-geo261-<SHA8>`**：原工具拒絕覆蓋既有工作目錄。`p52_measure.py` 保留歷史 `final=7dae…` 主入口，只作正式 postfix 工具的共用函式；本輪不可直接執行其主入口。

## 正式專項 argv

從凍結的 `source-final` 作為 cwd，依序執行並保存實際退出碼；若某項紅燈，依使用者新規則繼續下一項，原工具內部的停止行為不改。

```bash
python3 -B -u /tmp/g261r1/tools/postfix_validate.py <FINAL_SHA>
python3 -B /tmp/g261r1/tools/verify_postfix_receipt.py <FINAL_SHA>
bash /tmp/g261r1/tools/q38_gate.sh <FINAL_SHA> cloud-resume - gate
bash /tmp/g261r1/tools/card_ref_mutations.sh <FINAL_SHA> cloud-resume
python3 -B -u /tmp/g261r1/tools/p189_verify.py <FINAL_SHA>
```

P52 第一條結束後，必須將它的**完整原 stdout bytes**另存為 `tools/postfix-<SHA8>-launch.log`，再跑第二條。獨立 verifier 從此檔核對每次 Node 真實退出碼；不能只給摘要、stderr 或新的空檔。原 stdout 的捕捉路徑可以不同，但這份必要別名須 byte-identical 並入收據。

共同環境需要 Python 3.12 以上、Git、cc/GCC、Bash、Node 24、Google Chrome、CJK 字型，以及 `sha256sum`、`tar`、`mktemp`。Chrome 在 `/workspace/geo261-environment/bin/google-chrome`；工具內部 PATH 已機械適配 Node 24。保留：

```
XDG_DATA_HOME=/workspace/geo261-environment/xdg-data
XDG_CACHE_HOME=/workspace/geo261-environment/xdg-cache
LANG=C.UTF-8
LC_ALL=C.UTF-8
PYTHONDONTWRITEBYTECODE=1
```

不要改 HOME；清除繼承的 `GEOMETRY_*` 子集／故障注入旗標及 `AXIOM_ONLY`，再由工具設自己的正式環境。§7 不得使用 `AXIOM_ONLY`。P189 固定 main `adbaebf9c73ea6801d7b4d5214e4b846b132923b`、base `3e600772076465fc65a26ac09055028301c0fb0b`，沿原 driver 三方交錯 N16/32/48/64 各三輪，不挑點重跑。

正式產物將分別位於 `tools/postfix-<SHA8>/`、`q38-cloud-resume-<SHA8>/`、`cardref-cloud-resume-<SHA8>/`、`tools/p189-<SHA8>/`。目前這些結果尚未產生；現有工具來源不代表關卡已完成。
