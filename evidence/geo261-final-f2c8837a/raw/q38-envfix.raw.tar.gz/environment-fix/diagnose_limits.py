#!/usr/bin/env python3
"""只示範 shell/Python limits；不載入 repository、不編譯、不執行 Q38。"""
import datetime
import hashlib
import json
from pathlib import Path
import resource
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16 * 1024 * 1024, hard))
parent = resource.getrlimit(resource.RLIMIT_STACK)
payload = '''import json,resource
print(json.dumps({"event":"設定前","limits":resource.getrlimit(resource.RLIMIT_STACK)}),flush=True)
resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,resource.RLIM_INFINITY))
print(json.dumps({"event":"設定後","limits":resource.getrlimit(resource.RLIMIT_STACK)}),flush=True)
'''
rows = []
for label, shell_line in [('original-hard-and-soft', 'ulimit -s 16384'),
                          ('corrected-soft-only', 'ulimit -S -s 16384')]:
    command = ['bash', '-c', shell_line + '; exec ' + shlex.quote(sys.executable) + ' -c ' + shlex.quote(payload)]
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=15)
    stdout, stderr = ROOT / (label + '.stdout'), ROOT / (label + '.stderr')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    rows.append({'label': label, 'command': command, 'exit_code': result.returncode,
                 'seconds': time.monotonic() - start, 'stdout': str(stdout), 'stderr': str(stderr),
                 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
record = {'schema': 'geo261-q38-stack-limits-diagnosis/1',
          'generated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'python': sys.version, 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'inherited_limits': [soft, hard], 'emulated_special_wrapper_parent_limits': parent,
          'commands': rows, 'formal_gate_executed': False,
          'notes': ['每個 shell 只改自己的子程序 limits，不更改執行中專項或父程序。',
                    '原 child 退出 1 與 ValueError 原文保留；soft-only child 退出 0 不代表 Q38 已通過。']}
(ROOT / 'LIMITS_DIAGNOSIS.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record, ensure_ascii=False))
