#!/usr/bin/env python3
"""新鮮程序只執行一次原非pg bridge，記錄真退出與RUSAGE_CHILDREN。"""
import datetime, hashlib, json, os
from pathlib import Path
import resource, subprocess, time
ROOT = Path('/tmp/g261r1')
SHA = 'f2c8837aeba3c49eacbd77b5161f07c819204263'
OUT = ROOT / 'nonpg-O2-resource'
OUT.mkdir(exist_ok=False)
provenance = json.loads((ROOT/'tools/p189-f2c8837a/provenance.json').read_text())
bridge = ROOT/'work/p189-f2c8837a/fix/bridge'
scene = ROOT/'work/p189-f2c8837a/s64.scene'
bridge_hash = hashlib.sha256(bridge.read_bytes()).hexdigest()
assert bridge_hash == provenance['binaries_sha256']['fix']
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
env = dict(os.environ, PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
command = [str(bridge)]
data = ('loadfile '+str(scene)+'\n').encode()
(OUT/'stdin.txt').write_bytes(data)
before = resource.getrusage(resource.RUSAGE_CHILDREN)
assert before.ru_utime == before.ru_stime == 0 and before.ru_maxrss == 0
record = {'schema':'geo261-nonpg-o2-resource-diagnostic/1','diagnostic_only':True,'source_sha':SHA,'command':command,'cwd':str(ROOT/'work/p189-f2c8837a'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdin_sha256':hashlib.sha256(data).hexdigest(),'bridge_sha256':bridge_hash,'original_p189_fix_binary_hash_matches':True,'scene_sha256':hashlib.sha256(scene.read_bytes()).hexdigest(),'environment':{k:env[k] for k in ['PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','TMPDIR'] if k in env},'stack_limit':resource.getrlimit(resource.RLIMIT_STACK),'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'before_child_usage':{'user_seconds':before.ru_utime,'system_seconds':before.ru_stime,'maxrss_kib':before.ru_maxrss},'child_process_count':1,'timeout_seconds':1200,'replacement_reason':'GNU /usr/bin/time不存在；新鮮Python程序沒有其他child，只用RUSAGE_CHILDREN記錄原bridge。'}
(OUT/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
t0 = time.perf_counter()
p = subprocess.run(command,cwd=record['cwd'],env=env,input=data,capture_output=True,timeout=1200)
wall = time.perf_counter()-t0
after = resource.getrusage(resource.RUSAGE_CHILDREN)
(OUT/'stdout').write_bytes(p.stdout)
(OUT/'stderr').write_bytes(p.stderr)
lines = p.stdout.splitlines()
load = json.loads(lines[0]) if len(lines)==1 else None
record.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_process_returncode=p.returncode,wall_seconds=wall,resources={'user_seconds':after.ru_utime-before.ru_utime,'system_seconds':after.ru_stime-before.ru_stime,'maxrss_kib':after.ru_maxrss,'minor_page_faults':after.ru_minflt-before.ru_minflt,'major_page_faults':after.ru_majflt-before.ru_majflt,'input_blocks':after.ru_inblock-before.ru_inblock,'output_blocks':after.ru_oublock-before.ru_oublock,'voluntary_context_switches':after.ru_nvcsw-before.ru_nvcsw,'involuntary_context_switches':after.ru_nivcsw-before.ru_nivcsw},stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest(),load_response=load,load_ok=isinstance(load,dict) and load.get('ok') is True)
(OUT/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'diagnostic_only':True,'actual_process_returncode':p.returncode,'load_ok':record['load_ok'],'wall_seconds':wall,'resources':record['resources'],'receipt':str(OUT/'receipt.json')},ensure_ascii=False),flush=True)
raise SystemExit(p.returncode if p.returncode else 0 if record['load_ok'] else 72)
