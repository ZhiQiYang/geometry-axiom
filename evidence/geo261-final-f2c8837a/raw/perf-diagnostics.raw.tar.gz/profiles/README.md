這是固定 f2 與 main 的 N64 診斷 profile，不是正式效能驗收。兩次串行執行，原 load rc 都是 0，load.out 都 ok=true；完整 stdout/stderr、環境、SHA、subreaper、flat 與 callgraph 都已保存。原腳本最後 wrapper exit 來自 rm，故已另核對 run.txt 與 load.out。

f2 flat 約 0.85 CPU秒／85 samples，main約 0.18 CPU秒／18 samples；採樣旗標為 -O1 -fno-inline -pg，時間不能替代正式 -O2 三方36樣本。f2熱點為 wd_read 18.82%、collect_stops 8.24%、find_node8.24%、find_edge7.06%。

callgraph 的全部 app_contact_facts children 約 0.03秒（3.5%），reference_contact_facts 觸發部分約 0.02秒（2.4%）。只省未用 raw footprint 是合理小候選，但估計低於正式 N64 至少 11.1%的必要下降，不能承諾30%或單修達標。recursive cycle 的 children歸因不可直接相加。完整值與檔案 hash見 SUMMARY.json。
