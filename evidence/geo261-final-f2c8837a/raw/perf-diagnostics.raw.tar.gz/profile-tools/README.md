僅準備路徑適配，尚未執行。正式執行須在 Q38 與其他重型工作退出後，經 /tmp/g261r1/heavy.lock 排他執行 ADAPTATION.json 的兩個指令。

只改四個絕對路徑；編譯旗標、stack、timeout、生成器、採樣方法與原程式判斷均保留。原 script 的 load 真退出碼在 run.txt；wrapper 最後退出碼不等於 load 原退出碼。
