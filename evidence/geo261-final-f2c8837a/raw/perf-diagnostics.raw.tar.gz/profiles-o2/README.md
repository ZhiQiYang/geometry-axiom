這是一個新的診斷方法：固定 f2 N64，單次 gcc -O2 -pg，允許正常 inline。它與原 -O1 -fno-inline -fno-omit-frame-pointer -pg 分開保存，原正式三方36樣本與≤2倍判準沒有變動。

profile load真rc=0、ok=true；完整工具差異、原新hash、命令、環境、stdout/stderr、subreaper與callgraph均保存。這份profile約55個samples：placement解碼23.64%、source-index append7.27%、source-edge/facts/collect各5.45%。gprof另把10.91%列為support_coord_compare，但唯一caller是geo_source_node，且原O2 binary相鄰為geo_source_find_node.isra.0，故標示符號歸因疑慮，不當support排序成本。

GNU time不存在，另以全新Python helper只執行一次原非pg O2 bridge。binary hash與原P189fix相同，事前child usage全0；rc=0、ok=true、wall1.320507秒，user1.271229秒、sys0.048556秒、maxRSS60192KiB、minor faults33382、major faults0、I/O blocks0。該筆主要消耗CPU，不能以環境問題豁免正式P189失敗。

只省未用rawfootprint的粗估profile份額約3.6–5.5%，不能承諾30%或達到N64至少11.1%的必要下降。所有診斷時間均不能取代原正式效能結果。詳細數值與原件hash見SUMMARY.json。
