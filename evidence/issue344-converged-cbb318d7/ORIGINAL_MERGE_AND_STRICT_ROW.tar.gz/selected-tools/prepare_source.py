from pathlib import Path
import ast,hashlib,importlib.util,json,os,shutil,stat,traceback
B=Path('/tmp/geo344-cbb-selected-20261024');R=Path('/tmp/geo344-cbb-source-20261024');OWN=Path('/workspace/geometry-axiom');S='cbb318d76d7d242ae0db760ae15d57ef1cad4aa0';C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');H=lambda b:hashlib.sha256(b).hexdigest();assert H(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762';assert not B.exists()and not R.exists();B.mkdir();O=B/'preparation';O.mkdir();(B/'tmp').mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')and k not in ['PYTHONPATH','PYTHONOPTIMIZE','NODE_OPTIONS']};env['PYTHONDONTWRITEBYTECODE']='1';sp=importlib.util.spec_from_file_location('cap',C);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);rec=cap.Recorder(O,env,S);result={'source_sha':S,'root':str(R),'exit':1,'formal_executed':False}
def need(v,m):
 if not v:raise RuntimeError(m)
def g(*args,cwd=OWN,data=None):
 row,out,err=rec.run(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=cwd,data=data,timeout=None,check=False,source_variant='private fixedS VM/selected-row source materialization; no C');need(row['actual_process_returncode']==0,'Git original failure '+row['directory']);return out
try:
 need(shutil.disk_usage('/tmp').free>=32*1024*1024,'private TMP metadata/source32MiB guard');need(g('rev-parse',S+'^{commit}').decode().strip()==S,'exact public source object')
 raw=g('ls-tree','-r','-z',S);entries={}
 for part in raw.rstrip(b'\0').split(b'\0'):
  meta,path=part.split(b'\t');mode,kind,oid=meta.decode().split();entries[path.decode()]=(mode,kind,oid)
 runner=g('show',S+':tests/run_all.py');tree=ast.parse(runner);req={}
 for n in tree.body:
  if isinstance(n,ast.Assign):
   for target in n.targets:
    if isinstance(target,ast.Name)and target.id in ['REQUIRED_OWNER_GATES','REQUIRED_BROWSER_GATES','NODE_PURE_TEST_FILES']:req[target.id]=ast.literal_eval(n.value)
 need(req['NODE_PURE_TEST_FILES']['node:connection_recovery']=='tests/test_connection_recovery.js','original Node pure mapping')
 selected={'geometry-web/app.js','geometry-web/cdp_test.js','tests/run_all.expected.json','current_geometry.c'}|set(req['REQUIRED_OWNER_GATES'])|set(req['REQUIRED_BROWSER_GATES'])
 for name in entries:
  p=Path(name)
  if len(p.parts)==2 and p.parts[0]=='tests'and p.suffix in ['.py','.js','.cjs','.mjs','.c','.h','.inc']:selected.add(name)
  if len(p.parts)==1 and p.suffix in ['.h','.inc']:selected.add(name)
  if p.parts[0] in ['geometry-core','geometry-web','geometry-app','geometry-templates']and p.suffix in ['.c','.h','.inc']and not any(q in ['vendor','node_modules','__pycache__','.git']for q in p.parts):selected.add(name)
 need(all(p in entries and entries[p][:2]==('100644','blob')for p in selected),'all exact ordinary Git inputs');patterns=''.join('/'+p+'\n'for p in sorted(selected)).encode();(O/'SPARSE_STDIN.txt').write_bytes(patterns)
 g('clone','--shared','--no-checkout','--no-hardlinks',str(OWN),str(R));g('sparse-checkout','set','--no-cone','--stdin',cwd=R,data=patterns);g('checkout','--detach',S,cwd=R);need(g('rev-parse','HEAD',cwd=R).decode().strip()==S,'real detachedS');need(g('status','--porcelain=v1','--untracked-files=all',cwd=R)==b'','clean source');need(g('diff','--cached','--name-status',cwd=R)==b'','no staged omissions')
 rows=[]
 for name in sorted(selected):
  p=R/name;st=p.lstat();data=p.read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();need(stat.S_ISREG(st.st_mode)and st.st_nlink==1 and oid==entries[name][2],'private exactsource '+name);rows.append({'path':name,'blob':oid,'bytes':len(data),'sha256':H(data)})
 cap.dump(O/'SOURCE_MANIFEST.json',{'source_sha':S,'root':str(R),'entries':rows});result.update(exit=0,files=len(rows),bytes=sum(x['bytes']for x in rows),source_clean=True,full_registry_view=True,original_selected_needs=[],original_selected_timeout_seconds=300)
except BaseException:result['error']=traceback.format_exc()
finally:cap.dump(O/'RESULT.json',result);print(json.dumps(result,ensure_ascii=False))
raise SystemExit(result['exit'])
