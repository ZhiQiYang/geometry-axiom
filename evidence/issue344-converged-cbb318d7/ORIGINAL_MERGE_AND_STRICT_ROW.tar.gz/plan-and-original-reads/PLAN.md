# #344 接上下一個 F7 的正常合流準備

這是未執行的分支計畫；不改主列車、不重產帳本，不啟 C／Node／canvas。本人唯一寫入 `codex/issue320-connection-recovery-20261024` 與其 `-prbody`。

當前產品 S540=`5402765c795769a77a7b249de1e3db80045a41de`；最新公開 E=`c5a9d099863afdf030a5262a6aa26be16f094dbf`、D=`d637822cefed33e76c36ddabe2d5a6506e622bda`。S540 的 VM9 是原 0／1／0（9／6／9、三個原斷言），原 `run_all --only node:connection_recovery` 為 strict 9／9、exit 0。這兩項實際執行仍綁 S540。新來源尚未產生，完整 canvas 三階段未跑。

本次只讀原 Git 收據已保存於同目錄。E 與目前 root M=`e321026fb9bc9bc19c54b8034af6e6eaec2857f9` 的實際共同祖先為 F2bbe=`2bbe54f19b2d19e8a816530f0c4edca950629a34`。F2bbe→M 的非 evidence 差異精確為 `geometry-core/kernel/source.c`、新增 `tests/geo323_provider_hint_harness.c`、`tests/test_geo261_source_index.py`、`tests/run_all.expected.json`。本線 E→共同祖先的非 evidence 差異仍為 app.js、cdp_test.js、run_all.py、run_all.expected.json、test_connection_recovery.js 五檔。唯一交疊是 expected JSON；M 僅把 `py:test_geo261_source_index` 原 17 改成 18，本線僅新增 `node:connection_recovery` 原 count 9。不能以本線舊 JSON 覆蓋 root 新 18。

F7 尚待 root 採用本次架構四檔後公布，故 REQUEST 的 target 保持 null。這不是等待許可：既有任務授權仍有效；一旦 root 給可解析 F7 且性能排程允許，先讀 F7 真 commit 與 M→F7 差異，再綁定同一份 exact argv。若只加入這次四檔／原證據，沿本計畫；若另有產品／裁判變更，先把實際差異與 closure 更新到新 binding。不能把 M 當 F7，也不能用架構實跑 M 的 gate 冒稱 F7 實跑。

執行前 fresh df，保原 metadata 出版 guard 20 MiB WS／16 MiB TMP；固定 owned source worktree HEAD=E、branch 正確、porcelain 與 cached diff 均空，遠端 head 仍 E。先 fetch 真來源；沒有 force/rebase/reset。正常命令如下（`F7_BOUND` 必須由原公開 receipt 的完整 SHA 代入後凍於 argv，不是 shell 未定變數）：

```text
git -C /workspace/issue320-work-20261024 merge --no-ff --no-commit F7_BOUND
git -C /workspace/issue320-work-20261024 ls-files -u
git -C /workspace/issue320-work-20261024 diff --cached --name-status
git -C /workspace/issue320-work-20261024 diff --cached --check
git -C /workspace/issue320-work-20261024 commit -m "Merge provider hint train into connection recovery fix"
git -C /workspace/issue320-work-20261024 push origin HEAD:refs/heads/codex/issue320-connection-recovery-20261024
```

先保真 merge exit、MERGE_HEAD、unmerged stages 與完整 raw；若 registry 衝突，合成 F7 全 entries 加原 count9，其他原 18／所有 counts 逐物件相等。原 staged diff--check 若遇歷史 evidence patch 空 context 的 whitespace 2，完整保其原退出碼與 diagnostics；像上一輪一樣僅在每個具名 evidence blob 逐 Git blob 相同且產品／測試 scope 的 check 真 0 後分類歷史收據，不刪改原 evidence 來製造 0。若是新 source 問題則正常修，不放寬判準。

新 S7 的 parents 必為 E、F7；S7 相對 F7 精確只有原五個 recovery source 路徑。app／cdp／原 node test／run_all.py 必 byte 等 S540；registry 除新增 node9 外全等 F7。C/H/inc、原 golden/workflow、公理層／決策佇列與 root 的架構四檔完整 path/mode/blob 全等 F7；所有原 evidence 必仍在。保來源閉包原 exit/hash；正常 push 後 exact ls-remote S7 可解析。後續 E/D 仍正常後繼，唯一 current-state matrix 列清 source、evidence、每項實跑 SHA 與 UNRUN。

局部重驗決策：原 VM9 的 executable closure 是 app.js 與 test_connection_recovery.js，若 S7 逐 byte 等 S540，保 S540 原實跑與 S7 精確 byte-closure，不能改 execution SHA。selected row 的 full registry 已含 K 18，故若本輪要宣稱 S7 strict row 通過，仍用原 `python3 -B tests/run_all.py --only node:connection_recovery`、needs=[]、300 秒及前次全域 rowlog/locks/cache 保全流程真正執行。它不代完整 native、Chrome 或帳本。

完整 canvas 待 exclusive 資源時，從公開 S7 開乾淨 control V7，只把 app 唯一 `connection.phase = "ready"; connection.known = true; connection.error = "";` 撤成 `connection.phase = "ready"; connection.known = true;`。V7 全 tree 僅 app blob 一處變，逆替換原 bytes 等 S7；控制分支正常 push、禁止合入列車。三相為 S7→V7→S7，原完整 `node geometry-web/cdp_test.js`、每相 35 分鐘，HTTP 19681/19682/19683、CDP 9731/9732/9733，profile/TMP/原輸出各自 fresh。原 P53-3/P61-10/P61-11 的三具名語意失敗才算正常反證，timeout/crash/build/environment 不是 kill，不能以 VM9 冒 Chrome。因 K/source.c 改動，bridge/native binary 必依 S7 closure 真重建；不可借 S540 或 root 原 binary 假側車。source pool/三相完整輸出／編譯 peak 另以實測估算，不用本小 merge 預算代替。

完整帳本與最終七 job 仍由 root 統一 final 執行；本線保新來源 freshness 未跑狀態，合流時不各自重產。同時原 #344 fix 仍未合入 root，任何 root final 綠都不自動替 #344 fullcanvas 作證。
