from pathlib import Path
import copy,hashlib,importlib.util,json,os,re,shutil,sys,traceback
B=Path('/tmp/geo344-F7-normal-merge-20261024');W=Path('/workspace/issue320-work-20261024');F='6df0264f75e84f03adb70746b6ac3db07a9910fc';E='c5a9d099863afdf030a5262a6aa26be16f094dbf';BR='codex/issue320-connection-recovery-20261024';TRAIN='codex/train-337-continue-20261024';CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762';sp=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);B.mkdir(exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')};rec=c.Recorder(B,env,F);r={'old_branch_head':E,'train_product':F,'branch':BR,'source_sha':None,'source_pushed':False,'merge_executed':False,'ledger_regenerated':False,'C_or_browser_executed':False,'exit':None};leaves=['geometry-web/app.js','geometry-web/cdp_test.js','tests/run_all.py','tests/run_all.expected.json','tests/test_connection_recovery.js']
def need(v,m):
 if not v:raise RuntimeError(m)
def g(*args,check=True):return rec.run(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=W,check=check,timeout=None,source_variant='ordinary owned #344 merge preparation; not formal execution')
def out(*args):return g(*args)[1]
def pairs(kv):
 d={}
 for k,v in kv:need(k not in d,'duplicate JSON key '+k);d[k]=v
 return d
try:
 r['free_before']={'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free};need(r['free_before']['workspace']>=20*1024*1024 and r['free_before']['tmp']>=16*1024*1024,'small Git merge temporary budget20/16MiB; not test threshold');g('fetch','origin','refs/heads/'+BR+':refs/remotes/origin/'+BR,'refs/heads/'+TRAIN+':refs/remotes/origin/'+TRAIN)
 need(out('rev-parse','HEAD').decode().strip()==E,'originalE head');need(out('rev-parse','refs/remotes/origin/'+BR).decode().strip()==E,'freshremote unchanged');need(out('symbolic-ref','--short','HEAD').decode().strip()==BR,'only owned branch');need(out('status','--porcelain=v1','--untracked-files=all')==b'','true empty status');g('diff','--cached','--quiet');g('merge-base','--is-ancestor',F,'refs/remotes/origin/'+TRAIN)
 root_raw=out('show',F+':tests/run_all.expected.json');ours_raw=out('show',E+':tests/run_all.expected.json');rootj=json.loads(root_raw,object_pairs_hook=pairs);need(rootj['suites']['py:test_geo261_source_index']['count']==18,'keep original provider source-index18');oursj=json.loads(ours_raw,object_pairs_hook=pairs);row=oursj['suites']['node:connection_recovery'];need(row=={'mode':'count','count':9,'unit':'node test'}and'node:connection_recovery'not in rootj['suites'],'original count9 new only');expected=copy.deepcopy(rootj);expected['suites']['node:connection_recovery']=row;(B/'F-registry-original.json').write_bytes(root_raw);(B/'E0-registry-original.json').write_bytes(ours_raw)
 merge,stdout,stderr=g('merge','--no-ff','--no-commit',F,check=False);r['merge_executed']=True;r['merge_actual_exit']=merge['actual_process_returncode'];r['merge_command']=merge;need(r['merge_actual_exit']in [0,1],'normal merge exit0 or conflict1 only');unmerged=out('diff','--name-only','--diff-filter=U').decode().splitlines();r['unmerged_paths']=unmerged;g('ls-files','-u');need(set(unmerged)<= {'tests/run_all.expected.json'},'only predicted registry conflict may be resolved');need(out('rev-parse','MERGE_HEAD').decode().strip()==F,'exact merge target parent')
 if unmerged:
  token=b'    "node:context_operations": {';insert=b'    "node:connection_recovery": {\n      "mode": "count",\n      "count": 9,\n      "unit": "node test"\n    },\n';need(root_raw.count(token)==1,'unique originalF insertion anchor');resolved=root_raw.replace(token,insert+token,1);need(json.loads(resolved,object_pairs_hook=pairs)==expected,'only count9 appended to allF registry');(W/'tests/run_all.expected.json').write_bytes(resolved);g('add','--sparse','--','tests/run_all.expected.json');r['registry_resolution']='exactF bytes plus original node9 row; no other train count changed'
 else:r['registry_resolution']='Git auto-merged; exact semantic expected mapping verified'
 need(out('ls-files','-u')==b'','no unmerged index');actual=(W/'tests/run_all.expected.json').read_bytes();need(json.loads(actual,object_pairs_hook=pairs)==expected,'final registry allF+original9');(B/'merged-registry.json').write_bytes(actual)
 for path in leaves:
  if path!='tests/run_all.expected.json':need(out('rev-parse',':'+path).strip()==out('rev-parse',E+':'+path).strip(),'original#344 source exact '+path)
 full,stdout,stderr=g('diff','--cached','--check',check=False);r['full_merge_whitespace_exit']=full['actual_process_returncode'];r['full_merge_whitespace_command']=full
 g('diff','--cached','--check','--','.',':(exclude)evidence/**')
 if r['full_merge_whitespace_exit']!=0:
  need(r['full_merge_whitespace_exit']==2,'only original whitespace exit2 classification')
  paths=sorted(set(re.findall(rb'^(.+):[0-9]+: ',stdout,re.M)));need(paths,'original whitespace paths present')
  original_blobs=[]
  for rawpath in paths:
   path=rawpath.decode();need(path.startswith('evidence/'),'whitespace only inherited evidence');index_oid=out('rev-parse',':'+path).strip();parent_oid=out('rev-parse',F+':'+path).strip();need(index_oid==parent_oid,'preserve exact parent receipt '+path);original_blobs.append({'path':path,'index_blob':index_oid.decode(),'parent_blob':parent_oid.decode()})
  r['historical_whitespace_parent_blob_proof']=original_blobs
 # Raw receipts imported from an existing immutable parent are never edited to remove whitespace.
 staged=out('diff','--cached','--name-status');(B/'STAGED_NAME_STATUS.txt').write_bytes(staged)
 g('commit','-m','Merge provider hint train into connection recovery fix');S=out('rev-parse','HEAD').decode().strip();r['source_sha']=S;need(out('show','-s','--format=%P',S).decode().split()==[E,F],'ordinary exact two parents');raw=out('diff-tree','--no-commit-id','--raw','--no-abbrev','-r',F,S);(B/'FINAL_VS_TRAIN.raw').write_bytes(raw);changed=out('diff-tree','--no-commit-id','--name-only','-r',F,S).decode().splitlines();non=[p for p in changed if not p.startswith('evidence/')];need(sorted(non)==sorted(leaves),'exact five non-evidence changes only');need(all(p in leaves or p.startswith(('evidence/issue320-','evidence/issue344-'))for p in changed),'only ownhistorical receipts imported');r['relative_to_train_changed_paths']=changed
 for p in ['公理層.md','決策佇列.md','.github/workflows/integration-tests.yml','geometry-web/cdp_sections.golden.json']:
  need(out('rev-parse',S+':'+p).strip()==out('rev-parse',F+':'+p).strip(),'protected/golden unchanged '+p)
 need(out('status','--porcelain=v1','--untracked-files=all')==b'','finalsource clean');r['registry_count_added']=9;r['source_clean']=True;r['new_formal_status']='UNRUN';r['free_after']={'workspace':shutil.disk_usage('/workspace').free,'tmp':shutil.disk_usage('/tmp').free};r['exit']=0
except BaseException:r['error']=traceback.format_exc();r['exit']=1
finally:c.dump(B/'RESULT.json',r);print(json.dumps({k:r.get(k)for k in ['exit','source_sha','merge_actual_exit','unmerged_paths','registry_resolution','full_merge_whitespace_exit','error']},ensure_ascii=False),flush=True)
raise SystemExit(r['exit'])
