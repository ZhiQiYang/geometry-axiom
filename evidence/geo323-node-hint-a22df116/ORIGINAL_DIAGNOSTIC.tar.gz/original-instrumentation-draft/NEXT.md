截至本稿，root 的 U 原五階段已終態，沒有重抽樣；`/workspace/geo323-union-stage-tools-20261024/TERMINAL_SUMMARY.json` SHA `cc1a5ed2d2b0d4513f5e1f2c836f3029e477c3f1b508c1713a1b0839ff9d6588` 是修正八階段數後的小摘要。原 metadata peer 1728/0；階段名稱更正追加 14/0。原 native／PF3／required-eight 三階段尚未在這個 U 流程執行，完整驗收仍是 null。

此診斷資料夾尚未建立分支、沒有 C 實跑。`MANIFEST.json` SHA `d39843c917839dcda8cab4a707e26d4e4b6cd1f3d3a4504a105cf8e70343aa10` 固定 U 原碼、22 個可逆儀表編輯、診斷 include、entry wrapper 和命令方案。獨立靜審在 `/workspace/geo323-node-hint-peer-specials-20261024/REVIEW.json`，74/0，SHA `50ae5b8dd80dcc8c5423a45557eb3dce987e96b6b419e7d270a6fa2c5213e834`。這是靜態接受，不是 C 通過或新策略有效的證明。

`U_L_PROFILE_CALL_DIFF.json` SHA `0b779054dfb356edcbf1cc40bfcf800e5d127bb05346f967cd9805fe65d445b0` 僅讀既有 U/L gprof。edge hash 少 1,530,361 次；contact order 多 4,566,324 次。這個差分沒有新增性能樣本，也不能推導正式 N64 wall 改善幅度。

下一步由 root 排程：先收斂 combined 所有的 monotonic sort 分支與必要正式測試；K 診斷若獲時槽，沿 PLAN 建私有副本只跑原 N64 一次、封存正常 exit／原 stdout parity／儀表 counters。尚未授權修改 node hint 策略；不得改其他人的分支或共享 registry。若結果顯示確切瓶頸，再提一刀可撤回修正與具名反證，原正式性能門檻仍保持。
