from pathlib import Path
import hashlib,json,difflib

HERE=Path(__file__).parent
SOURCE=Path('/workspace/geo323-union-fixed-source-20261024/geometry-core/kernel/source.c')
b=SOURCE.read_bytes();s=b;edits=[]
def replace(before,after):
    global s
    before=before.encode();after=after.encode()
    assert s.count(before)==1,(before,s.count(before))
    edits.append({'before':before.decode(),'after':after.decode()});s=s.replace(before,after,1)
replace('#include <string.h>\n','#include <string.h>\n#include "geo323_node_diagnostic.inc"\n')
replace('static uint64_t geo_source_node_hash(GeoSourceRef source)\n{','static uint64_t geo_source_node_hash(GeoSourceRef source)\n{\n    geo323_diag_add(geo323_diag_family(source),GD_HASH);')
replace('static size_t geo_source_find_node(const GeoEvalContext *ctx,GeoSourceRef source)\n{','static size_t geo_source_find_node(const GeoEvalContext *ctx,GeoSourceRef source)\n{\n    Geo323NodeDiagnostic *diag=geo323_diag_family(source);\n    if(ctx->sealed)geo323_diag_add(diag,GD_FIND_SEALED);')
replace('    if(ctx->node_index_capacity){\n        size_t mask=', '    if(ctx->node_index_capacity){\n        geo323_diag_add(diag,GD_FIND_INDEXED);\n        size_t mask=')
replace('        while(ctx->node_index[slot]){\n            size_t i=', '        while(ctx->node_index[slot]){\n            geo323_diag_add(diag,GD_FIND_OCCUPIED);\n            size_t i=')
replace('            if(geo_source_ref_equal(ctx->nodes[i]->source,source))return i;', '            if(geo_source_ref_equal(ctx->nodes[i]->source,source)){geo323_diag_add(diag,GD_FIND_EXISTING);return i;}')
replace('    }else for(size_t i=0;i<ctx->node_count;++i)\n        if(geo_source_ref_equal(ctx->nodes[i]->source,source))return i;\n    return SIZE_MAX;', '        geo323_diag_add(diag,GD_FIND_VACANT);\n    }else{\n        geo323_diag_add(diag,GD_FIND_LINEAR);\n        for(size_t i=0;i<ctx->node_count;++i){\n            geo323_diag_add(diag,GD_FIND_LINEAR_COMPARE);\n            if(geo_source_ref_equal(ctx->nodes[i]->source,source)){geo323_diag_add(diag,GD_FIND_EXISTING);return i;}\n        }\n    }\n    geo323_diag_add(diag,GD_FIND_MISSING);return SIZE_MAX;')
replace('    size_t count=nodes?ctx->node_count:ctx->edge_count,first=count-1;','    size_t count=nodes?ctx->node_count:ctx->edge_count,first=count-1;\n    bool diag_rehashed=false;\n    if(nodes)geo323_diag_add(geo323_diag_family(ctx->nodes[count-1]->source),GD_APPEND);')
replace('    if(count>*capacity/2){\n        size_t next=', '    if(count>*capacity/2){\n        if(nodes)geo323_diag_inc(&geo323_diag_rebuild_attempt);\n        size_t next=')
replace('        free(*table);*table=fresh;*capacity=next;first=0;empty_slot=SIZE_MAX;', '        free(*table);*table=fresh;*capacity=next;first=0;empty_slot=SIZE_MAX;\n        if(nodes){diag_rehashed=true;geo323_diag_inc(&geo323_diag_rebuild_success);}')
replace('    for(size_t i=first;i<count;++i){\n        uint64_t hash=', '    for(size_t i=first;i<count;++i){\n        if(nodes){Geo323NodeDiagnostic *diag=geo323_diag_family(ctx->nodes[i]->source);\n            geo323_diag_add(diag,GD_INDEX_INSERT);if(diag_rehashed)geo323_diag_add(diag,GD_REHASH_INSERT);}\n        uint64_t hash=')
replace('fallback:\n    free(*table);*table=NULL;*capacity=0;', 'fallback:\n    if(nodes)geo323_diag_inc(&geo323_diag_fallback);\n    free(*table);*table=NULL;*capacity=0;')
replace('    if(!ctx||!index||(source.key_size&&!source.key))return GEO_SOURCE_INVALID;\n    ctx->started=true;', '    if(!ctx||!index||(source.key_size&&!source.key)){geo323_diag_inc(&geo323_diag_node_invalid);return GEO_SOURCE_INVALID;}\n    ctx->started=true;\n    Geo323NodeDiagnostic *diag=geo323_diag_family(source);geo323_diag_add(diag,GD_NODE_CALL);\n    if(!source.key_size)geo323_diag_add(diag,GD_KEY_EMPTY);\n    else{const unsigned char *key=source.key;if(!key[0])geo323_diag_add(diag,GD_FIRST_ZERO);if(!key[source.key_size-1])geo323_diag_add(diag,GD_LAST_ZERO);}')
replace('    size_t hint=ctx->node_hint[slot];', '    size_t hint=ctx->node_hint[slot];\n    if(diag)geo323_diag_inc(&diag->hint_slots[slot]);')
replace('        *index=hint-1;return GEO_SOURCE_OK;', '        geo323_diag_add(diag,GD_HINT_HIT);*index=hint-1;return GEO_SOURCE_OK;')
replace('    size_t found=geo_source_find_node(ctx,source);', '    geo323_diag_add(diag,!hint?GD_HINT_EMPTY:(hint>ctx->node_count?GD_HINT_INVALID:GD_HINT_CONFLICT));\n    size_t found=geo_source_find_node(ctx,source);')
replace('    if(provider==ctx->provider_count)return GEO_SOURCE_MISSING;', '    if(provider==ctx->provider_count){geo323_diag_add(diag,GD_NODE_PROVIDER_MISSING);return GEO_SOURCE_MISSING;}')
replace('    if(ctx->node_count==SIZE_MAX/sizeof *ctx->nodes)return GEO_SOURCE_MEMORY;', '    if(ctx->node_count==SIZE_MAX/sizeof *ctx->nodes){geo323_diag_add(diag,GD_NODE_MEMORY);return GEO_SOURCE_MEMORY;}')
replace('    if(!node)return GEO_SOURCE_MEMORY;', '    if(!node){geo323_diag_add(diag,GD_NODE_MEMORY);return GEO_SOURCE_MEMORY;}')
replace('if(!key){free(node);return GEO_SOURCE_MEMORY;}', 'if(!key){geo323_diag_add(diag,GD_NODE_MEMORY);free(node);return GEO_SOURCE_MEMORY;}')
replace('    if(!next){free((void *)source.key);free(node);return GEO_SOURCE_MEMORY;}', '    if(!next){geo323_diag_add(diag,GD_NODE_MEMORY);free((void *)source.key);free(node);return GEO_SOURCE_MEMORY;}')
replace('    *index=ctx->node_count;next[ctx->node_count++]=node;', '    *index=ctx->node_count;next[ctx->node_count++]=node;geo323_diag_add(diag,GD_NODE_NEW);')
r=s
for e in reversed(edits):
    a=e['after'].encode();assert r.count(a)==1;r=r.replace(a,e['before'].encode(),1)
assert r==b
(HERE/'before.c').write_bytes(b);(HERE/'candidate.c').write_bytes(s)
(HERE/'INSTRUMENT_ONLY.patch').write_text(''.join(difflib.unified_diff(b.decode().splitlines(True),s.decode().splitlines(True),fromfile='a/geometry-core/kernel/source.c',tofile='b/geometry-core/kernel/source.c')))
(HERE/'EXACT_EDITS.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
manifest={'source_sha':'ca7838e0f4950452b9befcf40899d606db9b81fa','source':str(SOURCE),'instrumentation_only':True,'C_executed':False,'branch_written':False,'whole_withdrawal_equals_source':r==b,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [HERE/'before.c',HERE/'candidate.c',HERE/'diagnostic.inc',HERE/'INSTRUMENT_ONLY.patch',HERE/'EXACT_EDITS.json']}}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps(manifest,ensure_ascii=False))
