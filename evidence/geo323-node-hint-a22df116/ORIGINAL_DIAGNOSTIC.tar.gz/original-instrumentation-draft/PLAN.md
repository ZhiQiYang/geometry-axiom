此稿只量測 U=`ca7838e0f4950452b9befcf40899d606db9b81fa` 的 K node hint 行為；尚未編譯、執行、套到任何分支。沒有新的快取策略或產品修改。`combined_resume` 仍是 `contact_world.c` 修正的唯一負責人。

原始資料在 `/workspace/g337323U/evidence/gprof-fix-64.stdout`。其呼叫圖已記錄：`geo_source_node` 2,364,478 次、`geo_source_find_node` 1,737,765 次（在這份 profile 全部由前者呼叫）、`geo_source_node` 內 `geo_source_ref_equal` 2,360,398 次、find 內相同比較 1,777,944 次、find 內 hash 1,737,693 次、append 內 node hash 562,911 次、node append 238,679 次。這些是原 gprof 呼叫數，不是新的實跑。

由兩個入口呼叫差可得 hint 命中 626,713 次。若 hint 的 ordinal 不越界（原 append 單調、clear/reset 同時清 hint），其餘可推導 empty 4,080 次、conflict 1,733,685 次。這份推導尚未按 provider/key_size 實測，因此不把「長鍵末位元組為零」寫成既證病因。find 內總 equality 次數約為 indexed find 的 1.023 倍，也不支持先假定完整索引存在嚴重長探測鏈。該比率包含命中／未命中與小量 linear calls，不能當每次 miss 的平均探測數。

儀表將依 `(provider token, key_size)` 分組：hint empty/hit/conflict/invalid、256 槽分布、首／末零位元組、indexed/linear/sealed lookup、occupied/vacant 探測、existing/missing、成功建立／provider missing／MEMORY、hash、append/index insert/rehash insert。重建嘗試、成功與 fallback 另有總數。這是 process 累計，不跨 process；不是每個 context 的分布。相同 provider token 跨 context 的註冊若不同，必須另核實命名對照，不能擅自當同語意 provider。

儀表用固定 128 個家族的獨立靜態儲存，不在產品執行中加入 malloc、註冊回呼或檔案 I/O。空間不足或 unsigned counter 飽和會明確標記，分析必須判為分類不完整，不能丟失後仍宣稱完整。這個上限只限制診斷覆蓋，不能作為產品容量或新驗收門檻。單執行緒診斷專用，不適用並行呼叫。`diagnostic_entry.c` 使用既有 `GEOMETRY_BRIDGE_ENTRYPOINT` 接口，原 bridge 返回後才把一行帶前綴 JSON 寫到 stderr；原 bridge return code 不改。

命令方案（待排程與同行靜審，現在不執行）：

1. 取得 root 授權的獨占或非效能 C 時槽；保存 fresh df、預估 source/ELF/raw 預算與原 U checkout clean 狀態。另建私有 `/workspace/geo323-node-hint-diagnostic-run-20261024`，不可寫 U 的唯讀檔，也不可重用其 OUT 或 native global cache。只複製原 web_bridge quoted closure 的私有正常檔；禁止可寫 hardlink。
2. 核對 MANIFEST 的 U source byte hash，套 `INSTRUMENT_ONLY.patch` 到私有 `geometry-core/kernel/source.c`，將 `diagnostic.inc` 原件放到同目錄的 `geo323_node_diagnostic.inc`，私有 root 放 `diagnostic_entry.c`。核 `EXACT_EDITS.json` 全撤回逐 byte 等 U。不修改其他 K、W、H leaf。
3. 依原 profile flags 編譯：`gcc -std=c11 -O1 -fno-inline -pg <private-root>/diagnostic_entry.c -o <private-output>/bridge -lm`。保存命令、環境、exit、完整 stdout/stderr、實際 C/header 與 ELF hash。不得把編譯失敗當反證 kill。
4. 只跑一次原 N64 input：`loadfile /workspace/g337323U/evidence/scenes/s64.scene\n`，stack 16 MiB；原 profile 沒有總 timeout，本診斷不新增或放寬正式裁判時限。新的執行目錄保存 `gmon.out` 與完整 stdin/stdout/stderr/exit。不得把儀表時間用於 N64≤1.3 正式效能 gate，不重抽原 U 樣本。標示此執行是「U + 外部儀表」，不是 clean U 的正式收據。
5. stdout 逐 byte 對比原 `/workspace/g337323U/evidence/checks/profile-fix-64-load.stdout`。stderr 分開保存原原件與儀表 JSON；先精確核僅多一行 `GEO323_NODE_DIAG `，餘下 stderr 必須等原 `profile-fix-64-load.stderr`。exit 必須正常 0；缺 JSON、overflow、額外診斷或輸出漂移則分類為診斷失敗，先查原因。
6. 檢查每家族 `node_call = hint_empty + hint_hit + hint_conflict + hint_invalid`、256 hint 槽總數等 node_call、`find_indexed + find_linear = find_existing + find_missing`。在相同 U/N64 call graph 沒新增 sealed 入口時，再核總 `node_call=2364478`、`find total=1737765`、`node_new=238679`、`hash=2300604`。若不同先揭露，不調整原預期以過關。existing/missing 不等於既有／新 node 的唯一數量，語意須分清。
7. 解析家族分布與實際 first/last zero 比例後，才提出下一個最小產品修法。原完整 ordered graph、guards、memory/fallback/collision、撤回／恢復以及正式 N64 gate仍需要在真正改碼的最終 SHA 跑；這份診斷不能替代那些驗收。

這份稿未加入 run_all registry、未產帳本與架構、未推分支。所有原 comparison 紅、N64 紅與過往原件保持不變。
