"""One root-authorized instrumented N64 observation; never a formal timing sample."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,posixpath,re,resource,shutil,subprocess,sys,traceback
HERE=Path(__file__).resolve().parent;R='a22df116c7e9f6b7d074451f1c8052d59e7e4f3e'
SOURCE=Path('/workspace/geo323-final-r5-source-20261024');DRAFT=Path('/workspace/geo323-node-hint-diagnostic-draft-20261024');PROFILE=Path('/workspace/g337323R5/evidence');RUNROOT=Path('/tmp/geo323-node-hint-R-diagnostic-20261024');OUT=RUNROOT/'execution';PRIVATE=RUNROOT/'source'
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def clean_env():
 e=os.environ.copy()
 for k in list(e):
  if k.startswith(('GIT_','GEOMETRY_','GEO323_','MUTATE_'))or k in('PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'):del e[k]
 e.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TMPDIR=str(RUNROOT/'tmp'));return e
report={'source_sha':R,'variant':'R + external observation only','formal_performance_sample':False,'product_strategy_changed':False,'branch_written':False,'commands':[],'exit':None,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def run(argv,cwd,data=None):
 q=OUT/'commands'/f'{len(report["commands"])+1:03d}';q.mkdir(parents=True)
 if data is not None:(q/'stdin').write_bytes(data)
 row={'argv':argv,'cwd':str(cwd),'source_sha':R,'variant':report['variant'],'environment':{k:ENV.get(k)for k in('PATH','TMPDIR','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE')},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdin_sha256':None if data is None else sha(data)}
 r=subprocess.run(argv,cwd=cwd,input=data,capture_output=True,env=ENV)
 (q/'stdout').write_bytes(r.stdout);(q/'stderr').write_bytes(r.stderr)
 row.update(exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(q/'result.json').write_text(json.dumps(row,indent=2)+'\n');report['commands'].append(row)
 need(r.returncode==0,'original diagnostic command failed '+str(q));return r
ENV=clean_env()
def main():
 lock=Path('/tmp/g261r3/heavy.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  need(not OUT.exists()and not PRIVATE.exists(),'fresh output and private independent source only');OUT.mkdir(parents=True);(RUNROOT/'tmp').mkdir(exist_ok=False)
  fs=os.statvfs('/tmp');report['free_before']=fs.f_bavail*fs.f_frsize;need(report['free_before']>=32*1024*1024,'source/ELF/receipt storage admission only')
  terminal=json.loads(Path('/workspace/geo323-final-r5-stage-tools-20261024/launch-five/RESULT.json').read_text());need(terminal['source_sha']==R and len(terminal['commands'])==5 and type(terminal['exit'])is int,'R5 true five-stage terminal before diagnostic')
  original_manifest=(DRAFT/'MANIFEST.json').read_bytes();need(sha(original_manifest)=='d39843c917839dcda8cab4a707e26d4e4b6cd1f3d3a4504a105cf8e70343aa10','original static-reviewed diagnostic manifest')
  m=json.loads(original_manifest)
  for name,pin in m['files'].items():
   raw=(DRAFT/name).read_bytes();need(sha(raw)==pin['sha256']and len(raw)==pin['bytes'],'original diagnostic pin '+name)
  git=lambda *args:run(['git','--no-optional-locks','-C',str(SOURCE),*args],HERE).stdout
  need(git('rev-parse','HEAD').decode().strip()==R and git('status','--porcelain','--untracked-files=all')==b'','clean exact fixed R source')
  prep=json.loads(Path('/workspace/geo323-final-r5-stage-tools-20261024/preparation/RESULT.json').read_text());entries={r['path']:r for r in prep['entries']}
  selected={};pending=['geometry-web/web_bridge.c'];unresolved=[]
  while pending:
   name=pending.pop()
   if name in selected:continue
   p=SOURCE/name;raw=p.read_bytes();need(name in entries and sha(raw)==entries[name]['sha256'],'original R frozen compile closure '+name);selected[name]=raw
   for inc in re.findall(rb'^\s*#\s*include\s*"([^"\r\n]+)"',raw,re.M):
    child=posixpath.normpath(posixpath.join(posixpath.dirname(name),os.fsdecode(inc)));need(not child.startswith('../')and not child.startswith('/'),'include escapes root')
    if (SOURCE/child).is_file():pending.append(child)
    else:unresolved.append({'source':name,'include':os.fsdecode(inc),'relative':child})
  need(not unresolved,'actual web bridge quoted includes complete')
  need(sum(map(len,selected.values()))<8*1024*1024,'private closure source budget only')
  core='geometry-core/kernel/source.c';before=(DRAFT/'before.c').read_bytes();need(selected[core]==before,'K source identical at new R; do not retarget old diagnostic to changed K')
  edits=json.loads((DRAFT/'EXACT_EDITS.json').read_text());candidate=before
  for edit in edits:
   a,b=edit['before'].encode(),edit['after'].encode();need(candidate.count(a)==1,'unique forward instrumentation edit');candidate=candidate.replace(a,b,1)
  need(candidate==(DRAFT/'candidate.c').read_bytes(),'exact original 22-edit candidate')
  restored=candidate
  for edit in reversed(edits):
   a,b=edit['before'].encode(),edit['after'].encode();need(restored.count(b)==1,'unique full withdrawal edit');restored=restored.replace(b,a,1)
  need(restored==before,'entire instrumentation withdrawal restores R byte-for-byte')
  PRIVATE.mkdir();source_manifest=[]
  for name,raw in sorted(selected.items()):
   p=PRIVATE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(candidate if name==core else raw)
   need(p.stat().st_nlink==1 and (p.stat().st_dev,p.stat().st_ino)!=((SOURCE/name).stat().st_dev,(SOURCE/name).stat().st_ino),'private file cannot alias original')
   p.chmod(0o444);source_manifest.append({'path':name,'R_sha256':sha(raw),'instrumented_sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'nlink':p.stat().st_nlink})
  inc=PRIVATE/'geometry-core/kernel/geo323_node_diagnostic.inc';inc.write_bytes((DRAFT/'diagnostic.inc').read_bytes());inc.chmod(0o444)
  entry=PRIVATE/'diagnostic_entry.c';entry.write_bytes((DRAFT/'diagnostic_entry.c').read_bytes());entry.chmod(0o444)
  source_manifest.extend({'path':p.relative_to(PRIVATE).as_posix(),'external_only':True,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'nlink':p.stat().st_nlink}for p in(inc,entry))
  (OUT/'SOURCE_MANIFEST.json').write_text(json.dumps(source_manifest,indent=2)+'\n');report['source_files']=len(source_manifest);report['source_bytes']=sum(r['bytes']for r in source_manifest)
  profraw=(PROFILE/'gprof-fix-64.stdout').read_bytes();(OUT/'original-R-gprof-fix-64.stdout').write_bytes(profraw)
  flat={}
  for line in profraw.decode().splitlines():
   if '['in line:continue
   columns=line.split()
   if len(columns)==7 and columns[3].isdigit():flat[columns[-1]]=int(columns[3])
  need(all(n in flat for n in('geo_source_node','geo_source_find_node','geo_source_node_hash')),'original R gprof actual source counters available')
  (OUT/'ORIGINAL_R_PROFILE_COUNTS.json').write_text(json.dumps({n:flat[n]for n in('geo_source_node','geo_source_find_node','geo_source_node_hash')},indent=2)+'\n')
  run(['gcc','--version'],HERE);binary=OUT/'bridge';build=run(['gcc','-std=c11','-O1','-fno-inline','-pg',str(entry),'-o',str(binary),'-lm'],PRIVATE)
  report['binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary.read_bytes())}
  soft,hard=resource.getrlimit(resource.RLIMIT_STACK);need(hard==resource.RLIM_INFINITY or hard>=16777216,'original16MiB stack available');resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard));report['stack_bytes']=16777216
  original_load=json.loads((PROFILE/'checks/profile-fix-64-load.json').read_text());need(original_load['exit']==0 and original_load['stack_bytes']==16777216,'original R load capture')
  stdin=original_load['stdin'].encode();need(stdin==b'loadfile /workspace/g337323R5/evidence/scenes/s64.scene\n','one exact original N64 input')
  scene=PROFILE/'scenes/s64.scene';report['scene']={'path':str(scene),'bytes':scene.stat().st_size,'sha256':sha(scene.read_bytes())}
  work=OUT/'run';work.mkdir();observed=run([str(binary)],work,stdin)
  original_stdout=(PROFILE/'checks/profile-fix-64-load.stdout').read_bytes();original_stderr=(PROFILE/'checks/profile-fix-64-load.stderr').read_bytes();(OUT/'original-R-load.stdout').write_bytes(original_stdout);(OUT/'original-R-load.stderr').write_bytes(original_stderr)
  need(observed.stdout==original_stdout,'instrumented stdout must equal original R byte-for-byte')
  lines=observed.stderr.splitlines(keepends=True);diags=[line for line in lines if line.startswith(b'GEO323_NODE_DIAG ')];need(len(diags)==1,'one diagnostic JSON line');need(b''.join(line for line in lines if not line.startswith(b'GEO323_NODE_DIAG '))==original_stderr,'non-diagnostic stderr equals original R')
  diag=json.loads(diags[0][len(b'GEO323_NODE_DIAG '):]);need(diag['family_overflow']==0 and diag['counter_overflow']==0,'diagnostic classification fully covered')
  totals={}
  for family in diag['families']:
   need(family['node_call']==sum(family[k]for k in('hint_empty','hint_hit','hint_conflict','hint_invalid')),'complete per-family hint classification')
   need(sum(family['hint_slots'])==family['node_call'],'per-family hint slot counts')
   need(family['find_indexed']+family['find_linear']==family['find_existing']+family['find_missing'],'per-family lookup outcomes')
   for k,v in family.items():
    if isinstance(v,int)and k not in('provider','key_size'):totals[k]=totals.get(k,0)+v
  need(totals['node_call']+diag['node_invalid']==flat['geo_source_node'],'actual R node calls including invalid entry')
  need(totals['find_indexed']+totals['find_linear']==flat['geo_source_find_node'],'actual R original find count')
  need(totals['hash']==flat['geo_source_node_hash'],'actual R original full node hash count')
  (OUT/'DIAGNOSTIC.json').write_text(json.dumps(diag,indent=2)+'\n');(OUT/'TOTALS.json').write_text(json.dumps(totals,indent=2)+'\n')
  need(git('rev-parse','HEAD').decode().strip()==R and git('status','--porcelain','--untracked-files=all')==b'','original R source untouched after diagnostic')
  for name,raw in selected.items():need(sha((SOURCE/name).read_bytes())==sha(raw),'original R closure unchanged after diagnostic')
  report.update(exit=0,diagnostic_families=len(diag['families']),diagnostic_totals=totals,stdout_byte_equal=True,non_diagnostic_stderr_byte_equal=True,formal_timing_remeasured=False,source_clean_after=True)
 except BaseException:report.update(exit=1,error=traceback.format_exc())
 finally:
  report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  if OUT.exists():(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  fcntl.flock(lock,fcntl.LOCK_UN);lock.close();print(json.dumps({k:report.get(k)for k in('source_sha','exit','diagnostic_families','error')}),flush=True)
 return report['exit']
if __name__=='__main__':sys.exit(main())
