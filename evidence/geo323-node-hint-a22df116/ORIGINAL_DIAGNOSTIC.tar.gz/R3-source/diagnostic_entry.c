/* Place at the private source root; no writes to original U source. */
#define GEOMETRY_BRIDGE_ENTRYPOINT geo323_diagnostic_bridge_main
#include "geometry-web/web_bridge.c"
int main(void)
{
    int result=geo323_diagnostic_bridge_main();
    geo323_diag_dump(stderr);
    return result;
}
