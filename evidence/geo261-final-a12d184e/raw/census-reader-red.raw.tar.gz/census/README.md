完整census真退出1：224suites，5185=5178pass/6fail/1GDI skip；唯一紅suite reader冪等，生成expected僅封存不採用。本包不是正式F驗收。stage/tmp與ELF排除，不動原產物。
