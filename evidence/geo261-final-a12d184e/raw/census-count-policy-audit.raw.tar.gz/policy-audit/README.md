# A census 數量能否供最終 F 使用：獨立純讀稽核

結論是有條件可用，不需因為同一次完整 census 只有 counted assertion fail 而額外先跑第二次完整 census；這不是採用 count，也不是把 A 驗收改綠。現在的 A native 原 exit 1、wrapper stage_execution_passed=false、45/51 reader／6 紅全部保持原樣。

## 原工具有明確設計依據

原 A 的 tests/run_all.py 與稽核時 root bytes 相同。906–950 的 update_expected 只在完整／可採信發現數時寫 manifest：拒絕未跑、環境／crash／timeout、exit-code-only fail、0 tests、非允許 skip 及 registry error；特別未以 counted assertion fail 阻擋。949–952 更明寫「注意：下列 suite 目前有 fail，但仍照實記下『發現到的數量』（fail 與數量無關）」。這不是靠缺少 guard 推論：程式有明確警語。1163+ 仍以任何 failed/crashed 判 overall exit 1，故量到數量與整體通過是兩件原本就分開的判定。

1040 的 partial guard 禁止 --only/extra/simulate 配 --update-expected；此次真 argv 恰 python3 tests/run_all.py --build --update-expected，沒有 partial/allow-skip。run_suite 對 unittest 在開始前 unlink 舊 JSON，沒有重用舊 JSON 的正常路徑。

## 此次 measurement 的實證

完整 224/224 marker、224/224 表列與 expected suite key 相同；224 份主 log 的 fresh mtime 都在實際 15:35:43.386779–16:05:02.893872 UTC 區間。合計 5185=5178 pass+6 fail+1 已允許 GDI skip；唯一 failed suite 為 test_axiom_reader，JSON total=run=51、45 pass、6 個普通 AssertionError，全部差 facts/facts_prepare，無 import/setup-blocked/error/skip。

三個待增 count suite 的 JSON 是當輪 fresh 結果：definition_sources 9/9（15:44:31.895139Z）、host_facts_authority 19/19（15:47:04.891491Z）、placement_definition 19/19（15:50:15.606129Z）。其輸出中 12/8/12 組具名控制分別有真 baseline/mutant/restored=0/1/0，非編譯／啟動／逾時紅。三者都無 import/setup-blocked/skip。前後 mutation:check 真 exit 0，clone 最後只 dirty expected.json，原 before expected 逐 bytes 等 A 的 Git blob。source A 到稽核時 root 的整個 tests tree 與未提交 tests diff 都為空。

## 全部 JSON 差異都列出，不盲採 formatter

generated typed JSON 精確等於 old 加以下三個 count，以及一個已解釋的 metadata 正規化：

- py:test_geo261_definition_sources：7 → 9。
- py:test_geo261_host_facts_authority：17 → 19。
- py:test_geo261_placement_definition：15 → 19。
- py:test_rectangular_template：unit "unittest" → "test"；count 仍為 11。

原 UNIT['unittest']='test' 的 blame 是 17bd4323f（2026-10-01）；rect entry 的舊 unit 來自 58c7824fe（2026-10-17），並非這輪 suite.kind/discovery 改變。原 build_suites 對該 Python module 仍建立 kind=unittest；compare_expected 實際只比較 mode/count，不檢查 unit。另有 geo261_adoption_mutations 對它自己的 domain_decoupling_adoption entry 比較完整 unit，不能因此泛稱整份 manifest 的 unit 永遠不參與判定；本建議保留所有原 unit，所以也不影響其他這類消費者。

嚴格最小提案應為 old + 恰三個 count，rect legacy unit 保留，不採這個 formatter 正規化。沒有減少 expected 數量、改 mode／assertion／skip／測試內容，也沒有改 reader 的 51 count 來掩蓋 6 紅。原 generated fullJSON 仍以原位置與 SHA 保存，不重寫成比較提案。

## 之後採用前必須完成

1. 先把 A 這輪六 browser 與專項收齊；保持原失敗記錄。
2. 僅透過原同步器修 canonical HTML；原 sync --check、原完整 51-test reader target 全綠，仍精確發現 51。任何 test/registry/discovery/count parser 來源變更都要重新評估 census，不能拿此條件當空白授權。
3. 比對到固定 F 前的全部 test source/discovery hashes，仍等 A；另作明確採用決定，引用原 A exit1／wrapper false，勿改原 receipt 或其 raw hash。
4. 只採三個已量到的 count，其他 metadata／unit 保留。完成應有的帳本與架構 freshness，再固定可解析 F。
5. 在 F 跑原完整 native --build（不帶 --update-expected）、六 browser 與所有專項一次；最後以 strict expected 比對與原 assertion exit 判全綠。F 有任何 count drift／紅仍拒絕，不能四捨五入或放寬。

這樣仍保留完整的紅→修→全套重跑鏈，符合使用者每輪收齊紅再重跑一次；額外第二輪 census 不會增加新的 discovery 證據，因 F 的完整 strict native 本身就會重新量數並檢查完全相等。若 HTML 修復牽涉測試來源／registry／動態發現、51 target count 不同、結果有 setup/environment/timeout/import ambiguity，或 raw/source hash 不可驗，此建議不成立，需新完整 census／重新判定。

## 未執行的純檔案提案工具

tools/prepare_census_three_counts_comparison.py.txt 的原檔在 /workspace/geo261-environment。它未被執行；不是現成 count artifact，也沒有改既有 typed reviewer。根據 caller 指定 A、原 before/generated/receipt snapshots，先強型別與 duplicate-key/NaN guards，僅接受 generated=old+三個指定 count+唯一 rect unit(unittest→test)且 count11 不變。任何其他 field/count/type 差異都拒絕，不產 comparison。成功才輸出 comparison=old+三個 count、保留全部原 unit，以及原始／comparison SHA、完整 diff、理由與「不採用 count」標記，供既有 reviewer 另外讀取。原 overall exit1／stage false 也必須仍為原值。

純 JSON fixture 草稿 census_comparison_fixture_draft.py 也未執行：準備 1 個正向、14 個 typed 負向與 duplicate/NaN/Infinity 拒絕情形。此包只實際執行了原始檔／JSON／Git 的純讀 audit；EXECUTION 在 execution，沒有執行產品測試、scanner、提案工具、fixture 或修改 registry。
