# 三個 census count 比較工具：純讀 peer review

審查對象：

- `prepare_census_three_counts_comparison.py`：`1cb38bce25125b1c1acc9d68cf399ebd1541c0774cf7f2a78bca18d4804387d5`
- `census_comparison_fixture_draft.py`：`dcbd2d3fd7bc85ed1c424f2c176062bb3cce5a92794fd3129255f4c1c5ba0904`

只讀取檔案並計算檔案 SHA256；沒有 import、AST、執行 fixture／工具、編譯、測試或修改 repository／工具／既有 r4。未發現會阻擋既定純 JSON fixture 或比較提案的具體缺陷。本報告不是 fixture 已通過或 count 已採用的證據。

## 強型別與差異範圍

`strict_json()` 以 object_pairs_hook 拒絕任何層級 duplicate object key，parse_constant 拒絕 NaN、Infinity（也拒絕 -Infinity）。`typed_equal()` 先比 `type(...) is`，因此 bool/int、float/int 不會因 Python 的 `True == 1` 或 `9.0 == 9` 被混過；dict key 集合、list 長度／順序及每個值都遞迴精確相等。

比較物件從 before deep-copy，只改三個明列 count：7→9、17→19、15→19。原 entries 必須為 object、mode=count、count 為精確 int 舊值、unit 為 str/test。rectangular_template 的 count 必須為 int/11、unit 必須為 str/unittest。Generated 必須精確等於這個 proposal 再加唯一 rectangular unit unittest→test；其他 suite、mode、count、unit、說明或額外欄位變動都無法通過 typed_equal。

因此 generated 與 before 會恰有四個 typed leaf differences，comparison 與 before 只會有三個 count differences；comparison 保留 legacy rectangular unit、全部其他 metadata 和 source objects。comparison JSON 另經 strict roundtrip 再比型別，沒有把整份 generated registry 直接採用。

## 原始證據與退出狀態

原 before、generated、census receipt 的完整 raw bytes 先另存 ORIGINAL_*，並記 SHA256；before／generated 還必須分別等於原 receipt 相鄰的 before/after snapshot，before suite 集合必須有 224 個 entries。

原 receipt 必須是 census，wrapper stage flag 必須是精確 bool/false；source SHA 必須為精確 str/40 hex，且等明填 A；full-census-update-expected command 恰一筆且 argv 必須是原完整 scope。actual_process_returncode 必須為精確 int/1，timeout_expired 必須為精確 bool/false。工具只新增比較檔與 report，沒有寫回原 receipt、原 registry 或原 before/generated。Report 明標 notCountAdoption、notFinalAcceptance，保留 originalNativeExit=1、originalWrapperStagePassed=false，不把本工具 exit0 當 native 綠。

## Fixture 靜態逐項核對

一個 positive 會呼叫真正 comparison_object，再驗 rectangular unit 保留與三個 typed differences。14 個 negative lambdas 各自重建 fixture，只有期望的 module.Rejected 才算拒絕：extra-suite、missing-suite、other-count、other-unit、mode-change、bool-count、float-count、wrong-new-count、wrong-old-count、rect-count、rect-unit-retained-in-generated、rect-unit-wrong、description-change、extra-field。每一個都會撞明列 require 或精確 typed generated equation；不是用 crash／compile error 冒拒絕。

另有三個 raw JSON 拒絕案例：duplicate suites key、NaN、Infinity；實際跑時若任何一個意外被接受，都會顯式 raise AssertionError，不能印 PASS。Fixture 只 import 這個外部純 JSON helper，模組的 __main__ guard 不會啟動 CLI/main、產品或原生測試。

## 限制

Synthetic fixture 直接測 comparison_object／strict_json；它不測 CLI 的原 receipt/sibling snapshot/224-suite/source SHA guards。這些 guard 本次已純讀核對，但真正原檔的比較 CLI 仍需另有真命令、退出碼與 raw outputs；也不能代替原完整 census 的病因審計、後續正式 expected 採用或新最終 SHA 的全部驗收。

Positive 的兩個 fixture 檢查使用 Python assert，實跑應沿既定正常 Python（不要 -O）；核心比較工具的拒絕均使用 require，不依賴可被最佳化拿掉的 assert。此項不是本輪阻擋，亦未要求改工具或改既有 r4。
