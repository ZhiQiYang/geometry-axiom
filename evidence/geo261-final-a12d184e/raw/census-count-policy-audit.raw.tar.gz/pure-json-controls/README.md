# 三 count 比較提案：純 JSON fixture 實際執行

本包只記錄一次合成 JSON fixture。實際指令為 `python3 -B census_comparison_fixture_draft.py`，cwd `/workspace/geo261-environment`，退出碼 **0**。完整原 stdout 為 `stdout`（93 bytes），stderr 為空；時間、環境、argv、Python executable 與來源前後 SHA256 在 `EXECUTION.json`。fixture 透過 import 呼叫 repo 外比較工具的純 JSON helpers，沒有執行比較工具 CLI，沒有讀取實際 before/generated/receipt 生成 comparison，也沒有採用任何 count 或執行產品／native／browser 測試。

fixture 真正走完 1 個正向、14 個 typed/結構負向，以及 duplicate-key／NaN／Infinity 拒絕。只有所有檢查成功才輸出最後 PASS 行；任一接受非法差異會拋出 AssertionError，留下非零退出碼。正向確認 comparison 保留 rect 舊 unit `unittest` 且只改三個 count；負向逐項檢查多／少 suite、其他 count／unit、mode、bool／float count、錯誤新／舊 count、rect count／unit、說明文字、額外 field。定義的 exact source 複本在 `tools/`。

`associatedOriginalCensusSourceSha` 為 `a12d184ec1865ad078700cea2387ac69e82ab62a`，只關聯原 census，並非宣稱合成 JSON 在產品 SHA A 上執行。原 A native exit **1**、原 wrapper `stage_execution_passed=false` 仍不變；本包不是 count 採用、原 native 翻綠或最終產品驗收。

先前 `census-count-policy-audit-20261022-r4` 是當時 prepared-only 的歷史紀錄，原檔沒有修改。本次前後其 SHA256SUMS 的 SHA256 相同；本包獨立保存實際執行，沒有回寫歷史 STATUS。比較工具與 fixture 的前後 SHA256 也完全相同。正式 comparison CLI 與既有 typed reviewer 仍未由本次執行，HTML-only 修復／51 target 全綠／test-discovery hashes 不變／後續完整 F 驗收的採用前提仍由 root 另行判定。

環境只保存與 Python 執行有關的白名單變數 exact 值及缺席鍵；其餘繼承值不變且不列可能含憑證的無關環境。純讀 peer 結果另附，不能取代本包的實際退出碼與 raw streams。
