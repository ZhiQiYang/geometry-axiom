# 固定 F 的原 §7 axiom 正式執行

這是正式原裁判，沒有 codegen 微量診斷或新產品測試。固定 F `cbf0fb621888596aa14ad5f2349b503e23b1b72d`；使用現有獨立 source `OWN/a6-architecture-source-20261026`，既有已審 closure 為 262 葉。它足供此入口，不冒充 native 的 6997 葉。

原命令：`python3 -B -u geometry-core/card-reference/run_axiom_mutations.py --output <fresh>/subject`。外層只使用原 c387 完整收件器與原 reaper。baseline 全 44、五次具名紅各 1、五次還原全 44，共 11 順序子程序／269 單測；原 compiler 60 秒、scene 20 秒、unittest 180 秒不變，outer 無新增 timeout。保留原 16 MiB stack。

唯一由原裁判暫改的 `geometry-core/modeling/__init__.py` 已讀回 regular inode/nlink1/0600，內容 hash `92e2b2205518e96b590cd3625b0645f88d906f87da0199353423cdc0855d43fb`。工具在取 heavy+secondary 原 locks 後，重新核 F HEAD、clean、index、refs、262 實體葉 bytes；終態再核同一性，不執行 reset/clean，不覆寫未知改動。五份原 fixtures 在該 closure 保全。

新 output 與 compiler/adapter/scene TMPDIR 都在新 OWN child。獨立 axiom adapter 原本用 TemporaryDirectory 並尊重 TMPDIR；不改 tests/binaries.py 的 `/tmp/geometry-tests`、不把 SHM free 抵 native 准入。原正常 TemporaryDirectory/atexit 生命週期照原裁判，異常留下的本輪 tmp 全保留並列 hash。

父端撤回自己自訂的 2 GiB 限制後，本輪共同工作規劃上限為 4 GiB，沒有改 mount/quota/權限。整鏈預留 1536 MiB：runtime/原流/失敗暫存估 256 MiB；完整無損 archive 先不計壓縮收益、另留 256 MiB；原 publisher 的 `3P` 留 768 MiB，再保原 64 MiB reserve，剩餘約 192 MiB 涵蓋 archive padding、metadata、公式 leaf/manifest 與誤差。此為一次正式工作排程估算，不是產品 cap 或已證最大值；比前次原 160 MiB 局部估算完整，且小於 fresh 4 GiB 餘裕 2,215,124,992 bytes。

每 5 秒只觀測兩 OWN 去重配置量與實體 SHM free；不是無遺漏的瞬時峰值。若實測超 4 GiB 或真正 free 小於原 64 MiB reserve，外層請原 reaper 終止這次新執行，保全部原流並標環境紅；不放寬任何裁判、時限或截斷輸出。任何 source 還原異常另標紅，不自動覆寫未知來源。

本輪無新增168檔清理授權，工具也沒有清理邏輯。根執行前仍需 fresh 原規劃＋實體free、原 scheduler lease。工具未自行開始正式驗收；peer 完成後由 root 指定唯一 OUT 執行，真正結果以該 OUT/RESULT.json、原 subject/report.json、reaper 與全部 subcommands 原流為準。正常正式約數分鐘，依原時限執行，不預告通過。
