# F axiom 正式終態核收

只在 root 回收真正工具退出碼後讀已結束原件；不重跑、不以尚未填的 primary exit 當通過。原來源固定 F=`cbf0fb621888596aa14ad5f2349b503e23b1b72d`。源、工具及輸出與本目錄 README/PEER 一致。

1. 原 RESULT、c387 最後正式命令與 reaper 終態三方核對：一個主命令終態、主/outer exit 對應正確，實際執行原未改 CLI、原 16 MiB stack／60、180、20 秒設定。工具真退出由 root 提供，不用 receipt 自說取代。
2. BEFORE/AFTER SOURCE 全等（F/tree/refs/index/target inode/hash/clean），兩份 262 葉 closure 清單全等並對原 CLOSURE.tsv OID/size；五 fixtures 各保原內容。只有原 runner 暫改 modeling/__init__.py，復原後不可剩變更；禁止以 reset/clean 掩蓋未知改動。
3. subject/report.json 的 source_head、source/test hashes 精確對 F；baseline=44、exit0、0 failure/error/skip；五組依序 V01–V05，red 每組 Ran1/exit1/有具名正常 failure/0 error或skip，restored 每組 Ran44/exit0/0 failure/error/skip，共 11 命令／269 單測。編譯錯、超時、crash 不是 kill。
4. 精確 expected labels：V01/V02 CARD_AXIOM_MANIFEST；V03 CARD_AXIOM_SOURCE；V04 CARD_AXIOM_SYNTAX；V05 CARD_AXIOM_ERA。red 原 stderr 必含原 named_test 的 FAIL 段與 label；還原原 stderr 必為完整44測試。比對 report 的 mutant_sha256 與原 SOURCE 指定唯一字串替換結果，確保不是另一 mutant。
5. 11 個 receipt 的 command/returncode/counts/完整 stdout/stderr bytes hashes 與 report 逐欄一致；22 log 都保存。所有 c387 request/result/aggregate 與 stdin/stdout/stderr hash 一致；原 runner stdout 應列五 killed，無遺漏命令。scope 是原 gate 提供的 11 子程序 log 與完整外層流，不假稱另有每個內部 compiler/scene 的獨立錄製。
6. sampler 原 JSONL 逐列有效，沒有 sampling_error／budget_abort；4 GiB 是任務規劃，採樣非原子且不證瞬時最高峰。比對已觀測的最大值、實體 free、終態保留暫存與完整原件大小；原正常 tempfile/atexit 清理由裁判執行，外層不刪舊資料。
7. OOM 只比對資源代理啟動前既有 memory.events 原件與終態一次唯讀值；共享 cgroup 不能把增量直接歸因此 gate，也不能把沒有獨占RSS樣本包裝成完整記憶體峰值。

既有記憶體 baseline：`/tmp/geo-resume0027-resource-observation-20261027/MEMORY.json`，1048 bytes，SHA256 `ef8414c12b42f19fe0f56f42c6f49a62f3476970ee6a65a1a8b4c3873e52c64b`，00:59:04.586148 UTC。原 `/sys/fs/cgroup/memory.events`：low/high/oom/oom_kill/oom_group_kill 均0，max=298165，membership `0::/`。它比01:11正式啟動早12分鐘，故完整時間窗要如實列，不宣稱gate獨占baseline。

gate結果與證據核收結果分欄：原正式紅燈仍紅，即使原件完整可核收；只有上述真實原件支持才判正式通過。全部既有 F9 結果僅背景，不重抽或移綁。結果以小型 ACTUAL_PEER.json 封存，不再複製原log或重封大包。
