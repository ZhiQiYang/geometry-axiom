"""Read terminal original records; never execute a subject command."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import stat

OUT=Path('/dev/shm/geometry-axiom-geo337-20261025/axiom-F-cbf0fb62-formal-20261027')
SOURCE=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026')
DEST=Path('/tmp/geo-axiom-F-formal-20261027')
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
checks=[]
def check(ok,name):
    checks.append(name)
    if not ok:raise AssertionError(name)
def h(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
result=read(OUT/'RESULT.json')
check(result['source_sha']==F and result['exit_code']==result['formal_primary_exit']==0 and result['passed'],'actual gate receipt true zero')
check(result['source_restored'] is True and not result['errors'] and not result['budget_abort'] and not result['sampling_errors'],'no hidden environment/source error')
check(result['stack_during']==[16777216,-1] and result['original_limits']=={'unittest_seconds':180,'adapter_compile_seconds':60,'scene_seconds':20,'outer_seconds':None},'original stack and limits')
check(h((OUT/'EXECUTOR.py').read_bytes())=='97098b4b948c39c3eaae8733268e02306ad7ebb2b743c9891dadf01fa89d6830','actual frozen executor')
before=read(OUT/'BEFORE-SOURCE.json');after=read(OUT/'AFTER-SOURCE.json')
check(before==after and before['head']==F and before['clean'],'source/index/refs/inode identity exactly restored')
closure=read(OUT/'BEFORE-CLOSURE.json')
check(closure==read(OUT/'AFTER-CLOSURE.json') and len(closure)==262,'262 closure rows before/after equal')
check(h(json.dumps(closure,sort_keys=True).encode())==before['closure_sha256'],'closure aggregate digest')
rows=[x.split('\t') for x in (OUT/'CLOSURE.tsv').read_text().splitlines()[1:]]
check(h((OUT/'CLOSURE.tsv').read_bytes())=='05a70b7b6b524de91972f723d835d4f9ef476686b8feb267d444bc9e859d9d6d','accepted full closure TSV')
check([(x['path'],x['oid'],str(x['bytes'])) for x in closure]==[tuple(x) for x in rows],'closure rows match accepted source identities')
fixtures=[]
for row in closure:
    p=SOURCE/row['path'];b=p.read_bytes()
    check(not p.is_symlink() and len(b)==row['bytes'] and h(b)==row['sha256'],'current restored closure bytes '+row['path'])
    check(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['oid'],'Git object identity '+row['path'])
    if row['path'].startswith('tests/fixtures/'):fixtures.append(row['path'])
check(h((SOURCE/'.git/index').read_bytes())==before['index_sha256'],'physical original index preserved')
original=(SOURCE/'geometry-core/modeling/__init__.py').read_bytes()
check(h(original)==before['target_sha256'] and (SOURCE/'geometry-core/modeling/__init__.py').stat().st_nlink==1,'private mutation target restored')
commands=read(OUT/'subcommands.json')
check(len(commands)==12,'12 complete outer commands')
formal=[]
for number,row in enumerate(commands,1):
    directory=OUT/'subcommands'/f'{number:06d}'
    request=read(directory/'request.json');stored=read(directory/'result.json')
    check(stored==row and row['actual_process_returncode']==0 and not row['timeout_expired'],'outer terminal/aggregate '+str(number))
    for key in ('command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','stdin_provided','stdin_sha256','directory'):
        check(request[key]==row[key],'request identity '+str(number)+'/'+key)
    check(row['source_sha']==row['acceptance_sha']==F,'outer source SHA '+str(number))
    for stream in ('stdin','stdout','stderr'):
        b=(directory/(stream+'.bin')).read_bytes();check(h(b)==row[stream+'_sha256'],'outer complete raw '+str(number)+'/'+stream)
        if stream!='stdin':check(len(b)==row[stream+'_bytes'],'outer raw size '+str(number)+'/'+stream)
    if 'geometry-core/card-reference/run_axiom_mutations.py' in row['command']:formal.append((row,directory))
check(len(formal)==1,'single original formal command')
frow,fdir=formal[0]
check(frow['command'][3:]==result['original_command'],'reaper wraps unchanged original argv')
events=[json.loads(x) for x in (OUT/'reaper.jsonl').read_text().splitlines()]
end=[x for x in events if x.get('event')=='完成']
check(len(end)==1 and events[-1]==end[0] and end[0]['primary_returncode']==0,'one real reaper terminal zero')
check(events[0]['command']==result['original_command'],'reaper original argv')
report=read(OUT/'subject/report.json')
check(h((OUT/'subject/report.json').read_bytes())==result['report_sha256'],'full report hash')
check(report['source_head']==F and report['source_sha256']==h(original),'report exact F source')
check(report['test_sha256']==h((SOURCE/'tests/test_engineering_model_compatibility.py').read_bytes()),'report exact judge hash')
ids=['V01-remove-gate','V02-ignore-manifest','V03-ignore-source','V04-exempt-latest-pre-adoption','V05-card-adoption-treated-as-pre']
labels=['CARD_AXIOM_MANIFEST','CARD_AXIOM_MANIFEST','CARD_AXIOM_SOURCE','CARD_AXIOM_SYNTAX','CARD_AXIOM_ERA']
check([x['id'] for x in report['mutants']]==ids,'exact five original mutants/order')
stages=[('baseline',report['baseline'],0,44,None,None)]
for row,label in zip(report['mutants'],labels):
    check(row['verdict']=='killed','original verdict '+row['id'])
    text=original.decode();check(text.count(row['old'])==1,'unique mutation target '+row['id'])
    check(h(text.replace(row['old'],row['new'],1).encode())==row['mutant_sha256'],'exact mutation bytes '+row['id'])
    stages += [(row['id']+'/red',row['red'],1,1,row['named_test'],label),(row['id']+'/restored',row['restored'],0,44,None,None)]
for name,row,expected_exit,count,method,label in stages:
    p=OUT/'subject'/name;check(read(p/'receipt.json')==row,'original per-stage receipt '+name)
    out=(p/'stdout.log').read_bytes();err=(p/'stderr.log').read_bytes();text=err.decode()
    check(h(out)==row['stdout_sha256'] and h(err)==row['stderr_sha256'],'complete original stdout/stderr '+name)
    ran=re.search(r'Ran (\d+) tests? in',text);check(ran and int(ran[1])==row['tests']==count,'original Ran count '+name)
    check(row['exit_code']==expected_exit and row['errors']==row['skips']==0,'original expected exit/no errors/no skip '+name)
    for key,pattern in [('failures',r'failures=(\d+)'),('errors',r'errors=(\d+)'),('skips',r'skipped=(\d+)')]:
        m=re.search(pattern,text);check(row[key]==(int(m[1]) if m else 0),'parsed '+key+' '+name)
    check(row['command'][1:3]==['-m','unittest'],'original unittest argv '+name)
    if method:
        check(row['failures']>0 and 'FAIL: '+method in text and label in text,'named ordinary assertion red '+name)
        check(row['command'][3]=='tests.test_engineering_model_compatibility.EngineeringModelCompatibility.'+method,'selected original red method '+name)
    else:
        check(row['failures']==0 and re.search(r'\nOK\s*$',text) is not None and row['command'][3]=='tests.test_engineering_model_compatibility','full restored/baseline OK '+name)
check(len(stages)==11 and sum(row['tests'] for _,row,*_ in stages)==269,'11 processes total 269 tests')
check((fdir/'stdout.bin').read_text()==''.join(x+' killed\n' for x in ids),'outer stdout all five actual killed')
samples=[json.loads(x) for x in (OUT/'RESOURCE_SAMPLES.jsonl').read_text().splitlines()]
check(samples and all('sampling_error' not in x and x['combined_allocated_bytes']<=4*1024**3 and x['actual_free_bytes']>=64*1024**2 for x in samples),'valid sampled original resource envelope')
check(result['retained_tmp_files']==[] and not list((OUT/'tmp').iterdir()),'original normal tempfile lifecycle left no retained tmp')
baseline_path=Path('/tmp/geo-resume0027-resource-observation-20261027/MEMORY.json')
check(h(baseline_path.read_bytes())=='ef8414c12b42f19fe0f56f42c6f49a62f3476970ee6a65a1a8b4c3873e52c64b','existing memory baseline pin')
terminal=read(DEST/'TERMINAL_MEMORY.json');memory=dict(line.split() for line in terminal['raw'].splitlines())
check(memory['oom']==memory['oom_kill']==memory['oom_group_kill']=='0' and memory['max']=='298165','shared memory event counters unchanged from baseline')
files=[];dirs=[];other=[];seen=set();allocated_bytes=0
for p in [OUT,*OUT.rglob('*')]:
    s=p.lstat();key=s.st_dev,s.st_ino
    if key not in seen:seen.add(key);allocated_bytes+=s.st_blocks*512
    if stat.S_ISREG(s.st_mode):files.append(p)
    elif stat.S_ISDIR(s.st_mode):dirs.append(p)
    else:other.append(str(p))
check(not other,'only ordinary files/directories in complete output')
summary={'schema':'F-axiom-actual-peer/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'blocking':[],'checks':len(checks),'source_sha':F,'formal_result':{'primary_exit':0,'outer_receipt_exit':0,'root_tool_observation':{'source':'root message, session15457, chunkdfc3ac','exit_code':0,'not_polled_by_this_reviewer':True},'processes':11,'tests':269,'baseline':{'exit':0,'tests':44,'skip':0},'mutants':[{'id':x,'red_exit':1,'red_tests':1,'restored_exit':0,'restored_tests':44,'verdict':'killed'}for x in ids]},'source_preserved':before,'fixture_count':len(fixtures),'fixtures':fixtures,'outer_command_count':len(commands),'outer_complete_streams':len(commands)*3,'subject_complete_logs':len(stages)*2,'original_result_sha256':h((OUT/'RESULT.json').read_bytes()),'original_report_sha256':result['report_sha256'],'elapsed_seconds':(datetime.datetime.fromisoformat(result['ended_utc'])-datetime.datetime.fromisoformat(result['started_utc'])).total_seconds(),'resource_samples':{'count':len(samples),'largest_combined_allocated_bytes':max(x['combined_allocated_bytes']for x in samples),'minimum_actual_free_bytes':min(x['actual_free_bytes']for x in samples),'sampled_not_exact_peak':True},'shared_oom':{'baseline_utc':'2026-10-27T00:59:04.586148+00:00','terminal_utc':terminal['utc'],'oom_delta':0,'oom_kill_delta':0,'oom_group_kill_delta':0,'memory_max_events_delta':0,'not_exclusive_gate_interval':True},'complete_original_selection':{'root':str(OUT),'rule':'All descendants, no exclusion; ordinary files and directories including empty tmp; do not follow symlinks','regular_files':len(files),'directories_including_root':len(dirs),'logical_bytes':sum(p.stat().st_size for p in files),'allocated_bytes_including_directories':allocated_bytes,'nonregular':other},'limits':['Original gate exposes 11 unittest logs; no additional independent interception of internal compiler/scene subprocess streams was added.','Resource samples are non-atomic, not an exact peak or exclusive memory measurement.','Root tool terminal came from the root observation above, not a fabricated child wait call.','No rerun, API call, cleanup, source edit or archive reproduction occurred during this review.']}
data=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode();check(len(data)<=5120,'small actual receipt <=5KiB')
(DEST/'ACTUAL_PEER.json').write_bytes(data)
print(json.dumps({'exit_code':0,'checks':len(checks),'bytes':len(data),'sha256':h(data),'selection':summary['complete_original_selection'],'sample':summary['resource_samples'],'seconds':summary['elapsed_seconds']},ensure_ascii=False))
