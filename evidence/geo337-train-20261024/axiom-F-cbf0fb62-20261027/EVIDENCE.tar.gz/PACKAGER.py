"""Preserve closed receipts once; never execute product tests or publish refs."""
from pathlib import Path
import gzip, hashlib, io, json, os, stat, tarfile

ROOT = Path('/tmp/geo-axiom-F-delivery-20261027')
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
SOURCES = {
    'axiom-original': Path('/dev/shm/geometry-axiom-geo337-20261025/axiom-F-cbf0fb62-formal-20261027'),
    'axiom-review': Path('/tmp/geo-axiom-F-formal-20261027'),
    'resource-observation': Path('/tmp/geo-resume0027-resource-observation-20261027'),
    'issue347-progress': Path('/tmp/geo347-progress-c1-20261027'),
    'issue347-body': Path('/tmp/geo347-c1-body-sync-20261027'),
}

def h(b): return hashlib.sha256(b).hexdigest()
def js(x): return (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
def meta(p):
    s=p.lstat()
    return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]

def main():
    assert not (ROOT/'EVIDENCE.tar.gz').exists(), 'single archive; refuse overwrite'
    entries=[]; payload={}; snapshots={}; selections={}
    for alias, src in SOURCES.items():
        assert src.resolve()==src and src.is_dir() and not src.is_symlink()
        files=dirs=size=0
        for p in [src]+sorted(src.rglob('*')):
            m=meta(p); name=alias+('/'+p.relative_to(src).as_posix() if p!=src else '')
            row={'member':name,'source':str(p),'original_mode':stat.S_IMODE(m[2])}
            snapshots[str(p)]=m
            if stat.S_ISDIR(m[2]):
                row['type']='directory'; dirs+=1
            else:
                assert stat.S_ISREG(m[2]) and m[3]==1, (p,m)
                b=p.read_bytes(); assert meta(p)==m
                row.update(type='file',bytes=len(b),sha256=h(b));payload[name]=b
                files+=1;size+=len(b)
            entries.append(row)
        selections[alias]={'source':str(src),'regular_files':files,'directories_including_root':dirs,'logical_bytes':size,'exclusions':[]}
    assert selections['axiom-original']['regular_files']==105
    assert selections['axiom-original']['directories_including_root']==32
    assert selections['axiom-original']['logical_bytes']==302421
    assert json.loads(payload['axiom-original/RESULT.json'])['source_sha']==F
    assert json.loads(payload['axiom-original/RESULT.json'])['formal_primary_exit']==0
    assert json.loads(payload['axiom-review/ACTUAL_PEER.json'])['exit_code']==0
    index={'schema':'closed-receipts-delivery/1','execution_source':{'axiom':F,'issue347_formal':'324034812bb6effca68e0413bc0468595337b317'},
           'identity_notes':['issue347 formal execution is historical and not re-executed by these document publications.',
                             'axiom ROOT_TERMINAL.json is root tool observation, not reviewer polling.',
                             'new train Fprime a4bd77e8090f5a82f0c8934c30c5335782293922 is not the axiom execution source.'],
           'selection_rule':'All descendants of each source, including empty directories. No exclusions; all ordinary leaves byte-exact.',
           'source_selection':selections,'entries':entries,
           'original_commands':'axiom-original/subcommands.json and per-command receipts; axiom-original/subject/report.json and logs; issue347 publication command receipts; axiom-review/ROOT_TERMINAL.json',
           'limits':['No rerun or remote writes during packaging. Original product claims are limited to the individual recorded source SHA.',
                     'Original internal compiler/scene streams are not independently intercepted beyond existing gate output.',
                     'Resource samples are non-atomic; shared cgroup is not exclusive to this gate.']}
    payload['INDEX.json']=js(index)
    payload['PACKAGER.py']=Path(__file__).read_bytes()
    payload['CURRENT_PROGRESS.md']=(ROOT/'PROGRESS.md').read_bytes()
    tarbuf=io.BytesIO()
    with tarfile.open(fileobj=tarbuf,mode='w',format=tarfile.PAX_FORMAT) as t:
        for row in entries:
            if row['type']!='directory': continue
            ti=tarfile.TarInfo(row['member']);ti.type=tarfile.DIRTYPE;ti.mode=0o755;ti.mtime=0;t.addfile(ti)
        for name,b in sorted(payload.items()):
            ti=tarfile.TarInfo(name);ti.mode=0o644;ti.mtime=0;ti.size=len(b);t.addfile(ti,io.BytesIO(b))
    compressed=gzip.compress(tarbuf.getvalue(),compresslevel=9,mtime=0)
    with (ROOT/'EVIDENCE.tar.gz').open('xb') as f:f.write(compressed)
    with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as t:
        ms=t.getmembers(); assert len(ms)==len(entries)+3
        assert len({x.name for x in ms})==len(ms)
        for member in ms:
            assert not member.name.startswith('/') and '..' not in Path(member.name).parts
            if member.isfile():assert t.extractfile(member).read()==payload[member.name]
            else:assert member.isdir()
    for p,m in snapshots.items():assert meta(Path(p))==m, 'original changed: '+p
    for row in entries:
        if row['type']=='file':assert h(Path(row['source']).read_bytes())==row['sha256']
    prefix='evidence/geo337-train-20261024/'
    manifest={'files':[]}
    for local,dst in [('EVIDENCE.tar.gz',prefix+'axiom-F-cbf0fb62-20261027/EVIDENCE.tar.gz'),('PROGRESS.md',prefix+'resume-20261026/PROGRESS.md')]:
        b=(ROOT/local).read_bytes();manifest['files'].append({'source_path':str(ROOT/local),'destination':dst,'bytes':len(b),'sha256':h(b)})
    (ROOT/'MANIFEST.json').write_bytes(js(manifest))
    result={'exit_code':0,'archive_bytes':len(compressed),'archive_sha256':h(compressed),'source_selections':selections,
            'members':len(entries)+3,'regular_members':len(payload),'roundtrip_verified':True,'original_metadata_and_hashes_preserved':True,
            'manifest_sha256':h((ROOT/'MANIFEST.json').read_bytes())}
    (ROOT/'PACKAGE_RESULT.json').write_bytes(js(result));print(json.dumps(result))

if __name__=='__main__':main()
