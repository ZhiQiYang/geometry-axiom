"""Run the unchanged F axiom mutation gate once with source and resource receipts."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import sys
import threading
import time
import traceback

F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
OWN = Path('/dev/shm/geometry-axiom-geo337-20261025')
OTHER = Path('/dev/shm/geo337-F9-browsers-20261025')
SOURCE = OWN/'a6-architecture-source-20261026'
TARGET = SOURCE/'geometry-core/modeling/__init__.py'
PLAN = Path('/tmp/geo-resume1758-axiom-resource-plan-20261026')
CLOSURE_HASH = '05a70b7b6b524de91972f723d835d4f9ef476686b8feb267d444bc9e859d9d6d'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
REAPER = Path('/workspace/geo261-environment/reap_children.py')
LOCKS = [Path('/tmp/g261r3/heavy.lock'), Path('/tmp/g261r3/secondary.lock')]
CEILING = 4*1024**3  # revised task planning only; no mount/quota/product change
CHAIN_ALLOWANCE = 1536*1024**2
PUBLICATION_RESERVE = 64*1024**2

def need(value, message):
    if not value:
        raise RuntimeError(message)

def h(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def allocated(roots):
    seen=set(); total=0
    for root in roots:
        need(root.is_dir() and not root.is_symlink(), 'missing or aliased resource root')
        for p in (root,*root.rglob('*')):
            try:s=p.lstat()
            except FileNotFoundError:continue  # live temporary lifecycle; sample is non-atomic
            key=s.st_dev,s.st_ino
            if key not in seen:
                seen.add(key); total+=s.st_blocks*512
    return total

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--execute',action='store_true')
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--peer',type=Path,required=True)
    ap.add_argument('--peer-sha256',required=True)
    a=ap.parse_args()
    if not a.execute:
        print(json.dumps({'execute':False,'sha':F,'original_command':'python3 -B -u geometry-core/card-reference/run_axiom_mutations.py --output <out>/subject','planning_ceiling':CEILING,'complete_chain_allowance':CHAIN_ALLOWANCE}))
        return 0
    need(not sys.flags.optimize and sys.dont_write_bytecode, 'use unoptimized python -B')
    peer_raw=a.peer.read_bytes(); peer=json.loads(peer_raw)
    need(h(peer_raw)==a.peer_sha256 and peer['exit_code']==0 and not peer['blocking'], 'peer pin or verdict')
    need(peer['tool_sha256']==h(Path(__file__).read_bytes()), 'peer must cover this exact executor')
    need(h(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'original capture pin')
    need(h(REAPER.read_bytes())=='7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760', 'original reaper pin')
    closure_raw=(PLAN/'CLOSURE.tsv').read_bytes()
    need(h(closure_raw)==CLOSURE_HASH, 'accepted F closure pin')
    rows=[line.split('\t') for line in closure_raw.decode().splitlines()[1:]]
    need(len(rows)==262 and len({x[0] for x in rows})==262, 'complete accepted axiom closure')
    out=a.out
    need(out.parent==OWN and out.name.startswith('axiom-F-cbf0fb62-formal-') and not out.exists() and not out.is_symlink(), 'fresh direct OWN output only')
    need(SOURCE.is_dir() and not SOURCE.is_symlink() and (SOURCE/'.git').is_dir() and not (SOURCE/'.git').is_symlink(), 'private F source required')
    for lock in LOCKS:
        need(lock.is_file() and not lock.is_symlink(), 'existing scheduler locks required')
    used=allocated([OWN,OTHER]); free=shutil.disk_usage(OWN).free
    need(used+CHAIN_ALLOWANCE<=CEILING and free>=CHAIN_ALLOWANCE, 'complete chain planning/actual mount admission')
    out.mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700)
    (out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
    (out/'PEER.json').write_bytes(peer_raw);(out/'CLOSURE.tsv').write_bytes(closure_raw)
    env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO261_','GEO323_'))}
    for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD','AXIOM_ONLY','FRAMING_QUOTE_QUEUE'):
        env.pop(key,None)
    env.update(TMPDIR=str(out/'tmp'),LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GIT_OPTIONAL_LOCKS='0',GITHUB_SHA=F,GITHUB_WORKSPACE=str(SOURCE),GEO261_REAPER_LOG=str(out/'reaper.jsonl'))
    spec=importlib.util.spec_from_file_location('original_capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    rec=cap.Recorder(out,env,F)
    result={'schema':'F-original-axiom-formal/1','source_sha':F,'source_root':str(SOURCE),'exit_code':1,'formal_started':False,'formal_primary_exit':None,'passed':False,'original_judge_modified':False,'original_limits':{'unittest_seconds':180,'adapter_compile_seconds':60,'scene_seconds':20,'outer_seconds':None},'resource_planning':{'ceiling_bytes':CEILING,'used_before':used,'incremental_chain_allowance_bytes':CHAIN_ALLOWANCE,'actual_mount_free_before':free,'publication_reserve_bytes':PUBLICATION_RESERVE,'estimate_not_product_limit':True,'proven_worst_case':False},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':[],'environment':{k:env.get(k) for k in ('PATH','LANG','LC_ALL','TMPDIR','CC','CFLAGS','CPPFLAGS','LDFLAGS','PYTHONDONTWRITEBYTECODE','GITHUB_SHA','GITHUB_WORKSPACE')},'python':sys.version}
    save(out/'RESULT.json',result)
    def run(argv):
        row,b,e=rec.run(argv,cwd=SOURCE,timeout=None,check=False,source_sha=F,source_variant='unchanged original F axiom gate')
        return row,b,e
    def git(*args):
        row,b,e=run(['git',*args]);need(row['actual_process_returncode']==0,'Git identity command failed');return b
    def identity(label):
        head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
        status=git('status','--porcelain=v1','--untracked-files=all'); staged=git('diff','--cached','--name-only')
        need(head==F and not status and not staged,'exact clean F required')
        refs=git('for-each-ref','--format=%(refname) %(objectname)')
        actual=[]
        for name,oid,size in rows:
            p=SOURCE/name;need(p.is_file() and not p.is_symlink(),'closure leaf missing or aliased: '+name)
            b=p.read_bytes();actual_oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
            need(len(b)==int(size) and actual_oid==oid,'closure byte drift: '+name)
            actual.append({'path':name,'bytes':len(b),'oid':oid,'sha256':h(b)})
        st=TARGET.stat();need(st.st_nlink==1 and TARGET.is_file() and not TARGET.is_symlink(),'mutation target must be private regular inode')
        v={'head':head,'tree':tree,'refs_sha256':h(refs),'index_sha256':h((SOURCE/'.git/index').read_bytes()),'closure_sha256':h(json.dumps(actual,sort_keys=True).encode()),'closure_count':len(actual),'target_inode':[st.st_dev,st.st_ino],'target_sha256':h(TARGET.read_bytes()),'clean':True}
        save(out/(label+'-SOURCE.json'),v);save(out/(label+'-CLOSURE.json'),actual);return v
    stop=threading.Event(); leases=[]; before=None; original=None; code=1; budget_abort=[]; sampling_errors=[]
    result['source_restored']=None
    def sample():
        with (out/'RESOURCE_SAMPLES.jsonl').open('x') as stream:
            while not stop.is_set():
                try:
                    n=allocated([OWN,OTHER]);f=shutil.disk_usage(OWN).free
                    row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'combined_allocated_bytes':n,'actual_free_bytes':f,'sampled_not_exact_peak':True}
                    stream.write(json.dumps(row)+'\n');stream.flush()
                    if n>CEILING or f<PUBLICATION_RESERVE:
                        budget_abort.append(row)
                        log=out/'reaper.jsonl'
                        if log.exists():
                            first=json.loads(log.read_text().splitlines()[0])
                            if first.get('event')=='啟用子程序回收':
                                try:os.kill(first['pid'],signal.SIGTERM)
                                except ProcessLookupError:pass
                        break
                except BaseException as exc:
                    sampling_errors.append(repr(exc))
                    stream.write(json.dumps({'sampling_error':repr(exc)})+'\n');stream.flush()
                stop.wait(5)
    old_stack=resource.getrlimit(resource.RLIMIT_STACK); thread=None
    try:
        for p in LOCKS:
            lease=p.open('rb');leases.append(lease);fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        before=identity('BEFORE');original=TARGET.read_bytes()
        need(old_stack[1]==resource.RLIM_INFINITY or old_stack[1]>=16777216,'original 16MiB stack required')
        resource.setrlimit(resource.RLIMIT_STACK,(16777216,old_stack[1]));result['stack_during']=list(resource.getrlimit(resource.RLIMIT_STACK))
        cc=shutil.which('cc',path=env.get('PATH'));need(cc is not None,'original compiler absent')
        result['compiler']={'path':str(Path(cc).resolve()),'sha256':h(Path(cc).resolve().read_bytes())}
        need(result['compiler']['sha256']=='a23ecab8ff08f09ad8c80602c2c5df7f49e09c25905cb8975902e101bf72635f','reviewed compiler changed')
        if env.get('CC') not in (None,'cc','/usr/bin/cc'):raise RuntimeError('unexpected CC override')
        run([cc,'--version'])
        command=[sys.executable,'-B','-u','geometry-core/card-reference/run_axiom_mutations.py','--output',str(out/'subject')]
        result.update(formal_started=True,original_command=command);save(out/'RESULT.json',result)
        thread=threading.Thread(target=sample,daemon=True);thread.start()
        row,_,_=run([sys.executable,'-B',str(REAPER),*command])
        events=[json.loads(line) for line in (out/'reaper.jsonl').read_text().splitlines()]
        terminal=[x for x in events if x.get('event')=='完成']
        need(len(terminal)==1 and events[-1]==terminal[0],'one original reaper terminal required')
        primary=terminal[0]['primary_returncode'];result['formal_primary_exit']=primary
        need(type(primary) is int and row['actual_process_returncode']==(primary if primary>=0 else 128-primary),'reaper exit mismatch')
        need(not budget_abort,'resource environment aborted; never a product pass')
        need(primary==0,'original axiom gate nonzero; preserve failure')
        report=json.loads((out/'subject/report.json').read_bytes())
        need(report['source_head']==F and len(report['mutants'])==5,'complete F five-mutant report required')
        need(report['baseline']['exit_code']==0 and report['baseline']['tests']==44 and report['baseline']['skips']==0,'original full baseline required')
        for item in report['mutants']:
            need(item['verdict']=='killed' and item['red']['exit_code']==1 and item['red']['tests']==1 and item['red']['failures']>0 and item['red']['errors']==item['red']['skips']==0 and item['restored']['exit_code']==0 and item['restored']['tests']==44 and item['restored']['failures']==item['restored']['errors']==item['restored']['skips']==0,'original red/restored evidence incomplete')
        result['report_sha256']=h((out/'subject/report.json').read_bytes());code=0
    except BaseException:
        result['errors'].append(traceback.format_exc())
    finally:
        stop.set()
        if thread is not None:thread.join()
        resource.setrlimit(resource.RLIMIT_STACK,old_stack)
        try:
            after=identity('AFTER');need(before is not None and after==before,'source/index/refs were not restored')
            result['source_restored']=True
        except BaseException:
            result['errors'].append(traceback.format_exc());result['source_restored']=False;code=1
            result['recovery_required']='Source/index/refs restoration not verified; no reset or overwrite attempted.'
        result['budget_abort']=budget_abort
        result['sampling_errors']=sampling_errors
        if sampling_errors:code=1;result['errors'].append('Resource observation incomplete; environment receipt remains nonzero')
        result['retained_tmp_files']=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in sorted((out/'tmp').rglob('*')) if p.is_file() and not p.is_symlink()]
        result['own_used_after']=allocated([OWN,OTHER]);result['out_allocated_after']=allocated([out])
        if result['own_used_after']>CEILING:code=1;result['errors'].append('4GiB planning ceiling exceeded')
        result.update(exit_code=code,passed=code==0,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save(out/'RESULT.json',result)
        for lease in reversed(leases):lease.close()
    print(json.dumps({'exit_code':code,'source_sha':F,'formal_primary_exit':result['formal_primary_exit'],'passed':result['passed'],'out':str(out)}))
    return code

if __name__=='__main__':
    raise SystemExit(main())
