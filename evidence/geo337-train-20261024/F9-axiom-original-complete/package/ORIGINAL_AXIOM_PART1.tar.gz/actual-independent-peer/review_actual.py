import ast
import hashlib
import json
import re
from pathlib import Path
from datetime import datetime, timezone

B = Path('/tmp/geo337-F9-axiom-original-20261025')
O = Path('/workspace/geo337-F9-axiom-actual-peer-20261025')
F = '4f8a794f4167c3562eb182045102e86e9e37cca9'
F8 = '75a1e93811a52b69385cbdaf6a09d773ed9052ad'
PREP = Path('/tmp/geo337-F9-nonperf-original-tools-v2-20261025/PREPARATION.json')
TOOL = PREP.parent / 'run_original_specials.py'
HOST = Path('/workspace/geo337-F9-axiom-original-EXEC_FINAL-20261025.json')
bindings, checks, failures = {}, [], []

def read(path):
    path = Path(path)
    raw = path.read_bytes()
    bindings[str(path)] = hashlib.sha256(raw).hexdigest()
    return raw

def J(path):
    return json.loads(read(path))

def check(ok, label):
    checks.append(label)
    if not ok:
        failures.append(label)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

r = J(B / 'receipt.json')
host = J(HOST)
summary = json.loads(host['output'])
check(host['exit_code'] == 0 and not host.get('session_id'), 'original host true terminal 0, no running session')
check(summary == dict(source_sha=F, gates=[dict(gate='axiom', passed=True)], launcher_exit_code=0, receipt=str(B/'receipt.json')), 'host output binds exact F9 gate and receipt')
prep = J(PREP)
check(bindings[str(PREP)] == '593ab353216e0cd50d49c92dd48d1b532bc43154ba46e494daf65cf11d8be72c', 'reviewed v2 preparation pin')
check(digest(read(TOOL)) == '993ee0102107e13e3391e31ffbc84ae88e6c6979673ebc1c42ca794ef6c1b8e9', 'reviewed v2 original wrapper pin')
check(r['source_sha'] == F and r['passed'] is True and r['launcher_exit_code'] == 0 and not r['errors'], 'wrapper F9 formal result 0 without errors')
check(r['preparation_sha256'] == bindings[str(PREP)] and r['outer_timeout'] is None and r['original_judges_counts_limits_changed'] is False, 'original preparation and no modified criteria or timeout')
check(r['stack_during'] == [16777216, -1], '16 MiB stack with original hard limit')
for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','NODE_OPTIONS','LD_PRELOAD','AXIOM_ONLY','FRAMING_QUOTE_QUEUE','CC','CFLAGS','CPPFLAGS','LDFLAGS'):
    check(r['environment'][key] is None, 'no injected modifier '+key)
check(r['environment']['GITHUB_SHA'] == F and r['environment']['GITHUB_WORKSPACE'] == r['repo'], 'source environment identity')
commands = J(B/'subcommands.json')
check(commands == r['commands'] and len(commands) == 30, 'all 30 original command records preserved')
streams = {}
for i, c in enumerate(commands, 1):
    directory = B/'subcommands'/f'{i:06d}'
    check(c['directory'] == str(directory), f'command {i} directory identity')
    check(J(directory/'result.json') == c, f'command {i} embedded/original result exact')
    req = J(directory/'request.json')
    check(req['command'] == c['command'] and req['cwd'] == c['cwd'], f'command {i} original argv/cwd')
    check(c['acceptance_sha'] == c['source_sha'] == F and c['cwd'] == r['repo'], f'command {i} source F9')
    check(c['actual_process_returncode'] == 0 and c['timeout_expired'] is False, f'command {i} actual exit 0/no timeout')
    check(c['started_epoch'] <= c['ended_epoch'], f'command {i} ordered original timestamps')
    for name in ('stdout','stderr'):
        raw = read(directory/(name+'.bin'))
        streams[i,name] = raw
        check(len(raw) == c[name+'_bytes'] and digest(raw) == c[name+'_sha256'], f'command {i} full {name} bytes and SHA256')

before, after = J(B/'axiom/before-source.json'), J(B/'axiom/after-source.json')
check(before == after, 'before/after full source records exact equal')
check(before['head'] == F and before['status'] == '', 'F9 source remains clean')
closure = before['ledger_only_closure']
check(closure['fixed_product_source'] == F8 and closure['execution_source'] == F, 'F8 product / F9 execution distinction')
check([p for p in closure['changed_paths'] if not p.startswith('evidence/')] == ['tests/mutants_results.json'], 'only ledger outside evidence changed from F8')
for a,z in ((1,23),(2,24),(3,25),(4,26),(5,27),(6,28),(7,29),(8,30)):
    check(commands[a-1]['command'] == commands[z-1]['command'] and streams[a,'stdout'] == streams[z,'stdout'] and streams[a,'stderr'] == streams[z,'stderr'], f'original source identity commands {a}/{z} exact streams')
check(streams[1,'stdout'].decode().strip() == F and streams[2,'stdout'].decode().strip() == before['tree'], 'HEAD and tree source evidence')
check(streams[3,'stdout'] == streams[4,'stdout'] == b'', 'original clean status and diff empty')
check(digest(streams[5,'stdout']) == before['index_sha256'] and digest(streams[6,'stdout']) == before['refs_sha256'], 'full original index and refs hashes')
check(commands[7]['command'][0:4] == ['git','diff','--no-renames','--name-only'] and streams[8,'stdout'].decode().split('\0')[:-1] == closure['changed_paths'], 'no-rename closure command and exact path list')
for i in range(9,22):
    path = commands[i-1]['command'][2].split(':',1)[1]
    check(commands[i-1]['command'] == ['git','show',F+':'+path] and digest(streams[i,'stdout']) == prep['original_judges_sha256'][path], 'original F9 judge bytes '+path)

gate = r['gates'][0]
check(len(r['gates']) == 1 and gate['gate'] == 'axiom' and gate['passed'] and not gate['errors'], 'one formal axiom gate green')
g = gate['commands'][0]
check(g['capture'] == commands[21] and g['primary_command_exit'] == g['outer_process_exit'] == 0, 'primary/outer/capture all true 0')
check(commands[21]['command'][3:] == g['original_argv'] and commands[21]['command'][2] == '/workspace/geo261-environment/reap_children.py', 'original judge argv preserved behind child reaper')
check(g['original_argv'][1:] == ['-B','-u','geometry-core/card-reference/run_axiom_mutations.py','--output',str(B/'axiom/subject')], 'exact formal axiom argv')
reaper_raw = read(g['reaper_log'])
reaper = [json.loads(s) for s in reaper_raw.splitlines()]
check(digest(reaper_raw) == g['reaper_sha256'] == '9a4a5bc1a0094fdfd561b30aa2433bcf4b91c39b9447aab9c51a24717266ef01', 'full original reaper pin')
check(len(reaper)==3 and reaper[0]['pr_get_child_subreaper']==1 and reaper[0]['command']==g['original_argv'] and reaper[1]['primary'] is True and reaper[1]['returncode']==reaper[2]['primary_returncode']==0, 'reaper primary exit and terminal completion')
check(commands[21]['started_epoch'] <= reaper[0]['utc_epoch'] <= reaper[1]['utc_epoch'] <= reaper[2]['utc_epoch'] <= commands[21]['ended_epoch'], 'reaper events lie inside original capture interval')

judge = streams[12,'stdout'].decode()
tree = ast.parse(judge)
calls = [n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess' and n.func.attr=='run']
check(len(calls)==1 and {k.arg:ast.literal_eval(k.value) for k in calls[0].keywords if k.arg in ('timeout','capture_output')} == {'capture_output':True,'timeout':180}, 'original per-subprocess timeout 180 and full capture preserved')
check('SUITE_TESTS = 44' in judge and 'finally:\n        TARGET.write_bytes(original)\n        assert TARGET.read_bytes() == original' in judge, 'original 44-suite and outer unconditional exact restoration')
report = J(B/'axiom/subject/report.json')
check(report['source_head']==F and len(report['mutants'])==5, 'subject F9 and exactly five mutants')
check(report['test_sha256']==digest(streams[16,'stdout']), 'report test source equals F9 original Git blob')
target = Path(r['repo'])/'geometry-core/modeling/__init__.py'
original = read(target)
check(digest(original)==report['source_sha256'], 'small restored modeling target equals recorded original source bytes')
source = original.decode()
labels=['CARD_AXIOM_MANIFEST','CARD_AXIOM_MANIFEST','CARD_AXIOM_SOURCE','CARD_AXIOM_SYNTAX','CARD_AXIOM_ERA']
expected_failures=[19,19,19,1,1]
ids=['V01-remove-gate','V02-ignore-manifest','V03-ignore-source','V04-exempt-latest-pre-adoption','V05-card-adoption-treated-as-pre']
rows=[]
all_seconds=[]

def subject_check(directory, rec, red=False, method=None, label=None):
    check(J(directory/'receipt.json') == rec, str(directory.relative_to(B))+': report and original receipt exact')
    raw = {}
    for channel in ('stdout','stderr'):
        raw[channel]=read(directory/(channel+'.log'))
        check(digest(raw[channel])==rec[channel+'_sha256'], str(directory.relative_to(B))+': full '+channel+' SHA256')
    text=raw['stderr'].decode()
    count=re.search(r'Ran (\d+) tests? in',text)
    check(count is not None and int(count[1])==rec['tests'], str(directory.relative_to(B))+': parse original run count')
    for field,term in (('failures','failures'),('errors','errors'),('skips','skipped')):
        match=re.search(term+r'=(\d+)',text)
        check((int(match[1]) if match else 0)==rec[field], str(directory.relative_to(B))+': parse '+field)
    check(rec['errors']==rec['skips']==0 and 0<rec['seconds']<180, str(directory.relative_to(B))+': no error/skip; original per-child 180s respected')
    selected='tests.test_engineering_model_compatibility'+('.EngineeringModelCompatibility.'+method if red else '')
    check(rec['command']==[g['original_argv'][0],'-m','unittest',selected], str(directory.relative_to(B))+': exact selected original argv')
    all_seconds.append(rec['seconds'])
    if red:
        check(rec['exit_code']==1 and rec['tests']==1 and rec['failures']>0 and 'FAIL: '+method in text and label in text and 'AssertionError:' in text and 'FAILED (' in text, str(directory.relative_to(B))+': named assertion truly red, not infrastructure error')
        check(len(re.findall(r'^FAIL: ',text,re.M))==rec['failures'], str(directory.relative_to(B))+': exact failing subcase count')
    else:
        check(rec['exit_code']==0 and rec['tests']==44 and rec['failures']==0 and text.rstrip().endswith('OK'), str(directory.relative_to(B))+': full 44 original restored green')
    return text

subject_check(B/'axiom/subject/baseline',report['baseline'])
for i,m in enumerate(report['mutants']):
    check(m['id']==ids[i] and m['verdict']=='killed' and m['red']['failures']==expected_failures[i], m['id']+': exact ordered mutant and subcase count')
    check(source.count(m['old'])==1 and digest(source.replace(m['old'],m['new'],1).encode())==m['mutant_sha256'], m['id']+': original exact single replacement hashes to mutant')
    text=subject_check(B/'axiom/subject'/m['id']/'red',m['red'],True,m['named_test'],labels[i])
    subject_check(B/'axiom/subject'/m['id']/'restored',m['restored'])
    rows.append(dict(id=m['id'],named_test=m['named_test'],label=labels[i],red_exit=1,red_tests=1,failed_subcases=m['red']['failures'],representative_assertion=next(s for s in text.splitlines() if s.startswith('AssertionError:')),restored_exit=0,restored_tests=44,skips=0,mutant_sha256=m['mutant_sha256']))
check(streams[22,'stdout'].decode().splitlines()==[i+' killed' for i in ids] and streams[22,'stderr']==b'', 'complete original outer stdout lists all five kills; stderr empty')
check(read(target)==original, 'peer small target read before/after unchanged')
result=dict(schema='geo337-F9-axiom-original-actual-peer/1',reviewed_utc=datetime.now(timezone.utc).isoformat(),exit_code=0 if not failures else 1,blocking_findings=failures,checks=len(checks),source_sha=F,formal_gate_exit=0,original_started_utc=r['started_utc'],original_ended_utc=r['ended_utc'],baseline_tests=44,mutants=rows,original_subprocess_timeout_seconds=180,maximum_subject_seconds=max(all_seconds),original_subject_invocations=11,all_subject_skips=0,source_restored_exact=True if before==after and digest(original)==report['source_sha256'] else False,bindings=bindings,review_command=['python3','-B',str(O/'review_actual.py')],limitations=['唯讀核對原始正式流；未重跑產品、測試或突變。','180 秒是每個 subject 子程序的原時限，並非整個 5 突變裁判的總時限。','前三個具名測試各失敗 19 個子案例，後兩個各 1 個；不能把它們誤寫成每次只有 1 個失敗子案例。','此實績只接受 F9 的 §7 axiom gate，不代表其他未完成 gate 已通過。'])
(O/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(exit_code=result['exit_code'],checks=len(checks),blocking_findings=failures,review_sha256=digest((O/'REVIEW.json').read_bytes())),ensure_ascii=False))
raise SystemExit(result['exit_code'])
