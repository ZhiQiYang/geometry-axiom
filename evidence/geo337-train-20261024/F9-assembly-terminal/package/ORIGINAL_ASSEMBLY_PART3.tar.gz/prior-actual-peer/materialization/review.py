from pathlib import Path
import json,hashlib,stat,os,datetime
B=Path('/dev/shm/geo337-F9-browsers-20261025');P=B/'plans/assembly';L=P/'layout';S=B/'sources/assembly';O=Path('/workspace/geo337-F9-assembly-SHM-materialize-actual-peer-20261025');F='4f8a794f4167c3562eb182045102e86e9e37cca9';PP='29e3248c3d09dac2977e0f85e5814f15aede0cbbfe743b7bad573f547dd188f7';checks=0;bindings={}
def H(raw):return hashlib.sha256(raw).hexdigest()
def ck(v,label):
 global checks
 checks+=1
 if not v:raise AssertionError(label)
def R(path):
 path=Path(path);raw=path.read_bytes();bindings[str(path)]=H(raw);return raw
def J(path):return json.loads(R(path))
preparations={}
for phase in ['plan','materialize']:
 wrapper=J(B/'host'/('assembly-'+phase)/'RESULT.json');host=J('/workspace/geo337-F9-assembly-SHM-'+phase+'-EXEC_FINAL-20261025.json');c=wrapper['capture_result'];d=Path(c['directory'])
 ck(host['exit_code']==wrapper['original_exit']==c['actual_process_returncode']==0 and not host.get('session_id') and not c['timeout_expired'],'true host/wrapper/original exit0 '+phase)
 ck(wrapper['source_sha']==c['source_sha']==F and wrapper['job']=='assembly' and not wrapper['subject_test_run'],'F9 original preparation only '+phase)
 ck(J(d/'result.json')==c,'original c387 receipt '+phase);request=J(d/'request.json');ck(request['command']==c['command'] and request['cwd']==c['cwd'],'original request argv/cwd '+phase)
 for channel in ['stdin','stdout','stderr']:
  raw=R(d/(channel+'.bin'));ck(H(raw)==c[channel+'_sha256'],'full raw hash '+phase+channel)
  if channel!='stdin':ck(len(raw)==c[channel+'_bytes'],'full raw length '+phase+channel)
 ck('/workspace/geo337-F9-five-browser-shm-preparation-20261025/browser_readonly_pool_preparer_single_job_shm_v2.py' in c['command'],'accepted exact v2 preparer '+phase)
 preparations[phase]=dict(path=str(d/'result.json'),sha256=bindings[str(d/'result.json')],command=c['command'])
 if phase=='materialize':
  ck('--materialize-authorized' in c['command'] and '--seed-freeze-authorized' in c['command'],'authorized original materialization flags')
  ck(wrapper['seed_peer_sha256']=='ec6b4988550a4652ff9c37f8f358e24a5eaf1d760f4b069ce2f5a8a7f283758f' and H(R(wrapper['seed_peer']))==wrapper['seed_peer_sha256'],'prior full3759 copied seed actual accepted')
plan=J(P/'PLAN.json');ck(bindings[str(P/'PLAN.json')]=='99b8b854486994b0d6e6c239d1c7e33150f46b6cff458c18eadcf081ba098f1c','exact actual plan pin')
original=J('/tmp/geo337-F9-canvas-sourceplan-20261025/PLAN.json');ck(plan['sha']==F and plan['suites']==['assembly'] and plan['source_layout']==str(S) and plan['items']==original['items'] and plan['omitted_new_checkout_paths']==original['omitted_new_checkout_paths'],'same F9 complete original3759 scope/omissions')
ck(H(R(P/'PREPARER.py'))==H(R(L/'MATERIALIZER.py'))==PP,'actual archived preparer/materializer source pin')
ck(R(P/'TREE.stdout.bin')==R('/tmp/geo337-F9-canvas-sourceplan-20261025/TREE.stdout.bin'),'complete immutable F9 TREE bytes')
mat=J(L/'MATERIALIZED.json');guard=J(L/'GUARD_LATEST.json');before=J(L/'SEED_FREEZE_BEFORE.json');after=J(L/'SEED_FREEZE_AFTER.json');items=J(L/'POOL_INPUTS.json');events=[json.loads(x) for x in R(L/'SEED_FREEZE_EVENTS.jsonl').splitlines()]
ck(mat['source_sha']==F and mat['original_tests_unrun'] and mat['reserve_bytes']==67108864,'materialization F9/reserve/original tests unrun')
ck(guard==dict(sha=F,passed=True,checks=[dict(suite='assembly',sha=F,inputs=3759,private_gitdir=str(L/'jobs/assembly/gitdir'),tree_clean=True)],original_test_or_browser_executed=False),'recorded original full3759 source guard passed')
ck(before['seed']==str(B/'seed/source') and before['native_root']=='/tmp/train337-323-f64d638f-source' and before['source']==after['source'] and after['source']['head']==F and after['source']['status']=='','actual source identity before/after exact')
ck(all(after[k] is True for k in ['all_raw_bytes_same','all_original_git_modes_preserved','payload_allocation_reused']) and after['new_payload_bytes']==0,'no repeat product payload copy')
ck(len(items)==len(events)==len(before['files'])==len(plan['items'])==3759,'all3759 complete original records')
prior=J(B/'seed-copy-original/ORIGINAL_INPUTS.json');ck([x['item'] for x in prior]==plan['items'],'prior accepted seed original manifest scope')
source=S/'jobs/assembly/source';gd=L/'jobs/assembly/gitdir';private=0
for p,i,f,e,a in zip(plan['items'],items,before['files'],events,prior):
 rel=p['path'];ck(all(i[k]==p[k] for k in p) and i['sha256']==f['sha256']==a['sha256'] and f['path']==e['path']==rel and e['linked'],'item/freeze/hash/event/prior chain '+rel)
 ck((f['device'],f['inode'])!=(f['native_device'],f['native_inode'])==(a['native_device'],a['native_inode']),'native original inode independence '+rel)
 seed=B/'seed/source'/rel;pool=S/'pool'/rel;leaf=source/rel;ss=seed.lstat();ps=pool.lstat();ls=leaf.lstat()
 ck(all(stat.S_ISREG(s.st_mode) for s in [ss,ps,ls]) and not any(x.is_symlink() for x in [seed,pool,leaf]),'actual ordinary source nodes '+rel)
 ck((ss.st_dev,ss.st_ino)==(ps.st_dev,ps.st_ino)==(f['device'],f['inode']) and not ss.st_mode&0o222 and not ps.st_mode&0o222,'existing seed and job pool readonly identity '+rel)
 if p['private_copy']:
  private+=1;ck((ls.st_dev,ls.st_ino)!=(ps.st_dev,ps.st_ino) and H(R(leaf))==i['sha256'],'private writable golden physical independence and original bytes')
 else:ck((ls.st_dev,ls.st_ino)==(ps.st_dev,ps.st_ino) and not ls.st_mode&0o222,'ordinary job source readonly same exact pool inode '+rel)
 ck(bool(ls.st_mode&0o111)==(p['mode']=='100755') and ls.st_size==p['bytes'],'all original Git modes/sizes '+rel)
ck(private==1 and not plan['default_svg_tracked'],'one original private golden and independent generated-SVG parent')
ck(R(source/'.git')==('gitdir: '+str(gd)+'\n').encode() and R(gd/'HEAD')==(F+'\n').encode() and R(gd/'objects/info/alternates')==(plan['objects']+'\n').encode(),'private Git path/HEAD/readonly original object alternate')
idx=gd/'index';seedindex=B/'seed/gitdir/index';ck(stat.S_ISREG(idx.lstat().st_mode) and idx.lstat().st_nlink==1 and (idx.stat().st_dev,idx.stat().st_ino)!=(seedindex.stat().st_dev,seedindex.stat().st_ino),'job private Git index independent of seed index')
cli=0
for filename,prefix,formatkind in [('GIT_COMMANDS.json','git-command-',3),('SEED_GIT_COMMANDS.json','seed-git-',2)]:
 cmds=J(L/filename)
 for n,c in enumerate(cmds,1):
  cli+=1;stem=prefix+str(n).zfill(formatkind);req=J(L/(stem+'.request.json'));ck(req['command']==c['command'] and c['actual_exit']==0,'original materializer Git actual0 '+stem)
  for stream in ['stdout','stderr']:
   raw=R(L/(stem+'.'+stream+'.bin'));ck(H(raw)==c[stream+'_sha256'],'complete original stream '+stem+stream)
  if c.get('stdin_bytes',0):raw=R(L/(stem+'.stdin.bin'));ck(len(raw)==c['stdin_bytes'] and H(raw)==c['stdin_sha256'],'full original update-index stdin')
  if 'update-index' in c['command']:ck(raw==b''.join(x.encode()+b'\0' for x in plan['omitted_new_checkout_paths']),'only original evidence paths skip-worktree')
gdirs=list((L/'guard-logs').iterdir());ck(len(gdirs)==1,'only original automatic guard was run')
for directory in gdirs:
 cmds=J(directory/'COMMANDS.json');ck(len(cmds)==4,'original guard four Git identities')
 for n,c in enumerate(cmds,1):
  cli+=1;stem=str(n).zfill(3);ck(c['actual_exit']==0 and J(directory/(stem+'.request.json'))['command']==c['command'],'guard actual original argv/exit0')
  for stream in ['stdout','stderr']:
   raw=R(directory/(stem+'.'+stream+'.bin'));ck(H(raw)==c[stream+'_sha256'],'guard full original stream')
   if stream=='stdout':ck(raw==(F+'\n').encode() if 'rev-parse' in c['command'] else raw==b'','guard exact F9 HEAD/empty clean status')
admit=J(P/'SPLIT_DEVICE_ADMISSION.json');ck(len(admit['groups'])==1 and admit['groups'][0]['required_additional_bytes']==108798775 and admit['groups'][0]['free_bytes']>=108798775 and admit['reserve_per_device_bytes']==67108864,'same actual SHM device keeps one64MiB reserve')
report=dict(schema='F9-assembly-SHM-materialize-actual-peer/1',exit_code=0,blocking_findings=[],checks=checks,source_sha=F,job='assembly',materialize_actual_exit=0,original_guard_actual_exit=0,original_git_commands=cli,plan=dict(path=str(P/'PLAN.json'),sha256=bindings[str(P/'PLAN.json')]),source_preparation=preparations['materialize'],plan_preparation=preparations['plan'],full_inputs=3759,private_golden_leaves=private,payload_recopied=False,formal_browser_executed=False,source_or_Git_mutated_by_peer=False,guard_rerun_by_peer=False,read_namespace='formally require_escalated read-only',bindings=bindings,reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['核原3759 fullguard與來源bytehash鏈、各葉實體inode/mode/size；未重讀139MB payload，只有private golden1322B另hash。','未重跑原guard或任何產品；launcher仍須按原流程自行跑before/afterguard。','此結果只接受assembly來源準備，不是assembly browser已通過。'])
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(exit_code=0,checks=checks,review_sha256=H((O/'REVIEW.json').read_bytes()),plan=report['plan'],source_preparation=dict(path=report['source_preparation']['path'],sha256=report['source_preparation']['sha256']))))
