from pathlib import Path
import hashlib,importlib.util,json,os,sys
OWN=Path('/dev/shm/geometry-axiom-geo337-20261025');OTHER=Path('/dev/shm/geo337-F9-browsers-20261025')
PREP=Path('/workspace/geo337-F10-full123-resource-anchor-preparation-20261025')
PEER=Path('/workspace/geo337-F10-full123-resource-anchor-static-peer-20261025/REVIEW.json')
SAMPLER=Path('/workspace/geo337-F9-browser-sampler-preparation-20261025/sample_original_browser_v2.py')
SOURCE='82c922a3941525d3a094ac0158bdc7dea57ea360'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert h(PREP/'run_full_ledger.py')=='7af6f3d7efe4987ed32ea0f356541630181fa6435684e72d83f7e3e7018148ef'
assert h(PREP/'launch_full_ledger.py')=='c51a309136e70167d66b45b468cb6b36d13426d01a22c9513bbbdc403fa772e0'
assert h(PEER)=='781bd4cc23c7e58360a1aed90c267c2b2c9080fefccd1b3a1b54857cc75d034a'
assert h(SAMPLER)=='919eafb54f20454ee44a27754ce04f6f63f05f6e1c9b32a5b51652058735af30'
prepared=OWN/'F10-source-preparation-reserve-anchor/RESULT.json';assert h(prepared)=='f1e689eb26653609943e7e899aaf6d6e8430b9d0b2291d8e1ee94ebb7c14fdf9'
pj=json.loads(prepared.read_bytes());assert pj['source_sha']==SOURCE and pj['exit']==0 and pj['materialized'] and pj['original_metadata_closure_equal']
checks=json.loads((OWN/'S10-preledger-checks-original-20261025/RESULT.json').read_bytes());assert checks['wrapper_exit']==0 and checks['source_unchanged'] and checks['source_sha']==SOURCE
assert all(x['exit_code']==0 for x in checks['gates']if x['gate']!='tracked-ledger-check')
sp=importlib.util.spec_from_file_location('shared_inventory',SAMPLER);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
inv=m.inventory([OWN,OTHER]);additional=1073741824;assert inv['unique_allocated_bytes']+additional<=2147483648
paths={'root':str(OWN/'F10-pool'),'cache':str(OWN/'F10-cache'),'job':str(OWN/'F10-ledger-job'),'tmp':str(OWN/'F10-ledger-tmp'),'resource_anchor':str(OWN/'F10-cache')}
for name in ['job','tmp']:assert not Path(paths[name]).exists()
outer=OWN/'F10-ledger-launch';assert not outer.exists()
dev=Path(paths['cache']).stat().st_dev;assert Path(paths['root']).stat().st_dev==dev and OWN.stat().st_dev==dev
fs=os.statvfs(paths['cache']);free=fs.f_bavail*fs.f_frsize;assert free>=additional and free>=285212672
admission={'schema':'full123-filesystem-admission/1','source_sha':SOURCE,'paths':paths,'filesystems':[{'labels':list(paths),'device':dev,'additional_bytes':{'binaries_additional':335544320,'raw_ledger_additional':100663296,'compiler_peak_additional':402653184,'metadata_additional':100663296,'reserve_additional':134217728},'minimum_free_bytes':additional,'basis':'Explicit actual-cache mount. Original 272MiB guard retained on actual data mount, with 1GiB additional filesystem plan covering original aggregate 512MiB and conservative transient allowance. Existing pool/seed/archives excluded from additional count. This is a planning estimate, not measured peak; no product, timeout or oracle change.'}]}
ap=OWN/'S10-full123-filesystem-admission-20261025.json';assert not ap.exists();ap.write_text(json.dumps(admission,ensure_ascii=False,indent=2)+'\n')
argv=[sys.executable,'-B',str(PREP/'launch_full_ledger.py'),'--outer',str(outer),'--sha',SOURCE,'--driver-sha256',h(PREP/'run_full_ledger.py'),'--','--root',paths['root'],'--job',paths['job'],'--cache',paths['cache'],'--tmp',paths['tmp'],'--prepared',str(prepared),'--sha',SOURCE,'--prepared-sha256',h(prepared),'--min-free-workspace-bytes','285212672','--resource-anchor',paths['cache'],'--filesystem-admission',str(ap),'--filesystem-admission-sha256',h(ap),'--root-execution-lease']
rp=OWN/'S10-full123-root-admission-20261025.json';assert not rp.exists()
request={'source_sha':SOURCE,'argv':argv,'root_execution_lease':True,'root_and_seed_no_other_consumers':True,'peer_sha256':h(PEER),'prepared_sha256':h(prepared),'admission_sha256':h(ap),'shared_allocated_before':inv['unique_allocated_bytes'],'additional_planning_bytes':additional,'shared_planning_ceiling_bytes':2147483648,'fresh_actual_work_mount_free':free,'unchanged_guard_bytes':285212672,'actual_resource_anchor':paths['cache'],'readonly_workspace_free_observation':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'memory_before':{n:(Path('/sys/fs/cgroup')/n).read_text()for n in ['memory.current','memory.max','memory.events','memory.stat']},'meminfo_before':Path('/proc/meminfo').read_text(),'no_index_removed':True,'no_product_tests_or_thresholds_changed':True,'prior_tracked_check_exit':checks['gates'][0]['exit_code']}
rp.write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in request.items()if k not in ['argv','memory_before','meminfo_before']}),flush=True)
os.execv(sys.executable,argv)
