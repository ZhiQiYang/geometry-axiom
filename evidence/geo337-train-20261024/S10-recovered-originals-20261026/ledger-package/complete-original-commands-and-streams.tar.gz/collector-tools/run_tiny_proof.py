from pathlib import Path
import hashlib,importlib.util,json,os,sys
D=Path(__file__).resolve().parent
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('original_capture',CAP);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out=D/'tiny-proof';out.mkdir();env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1');rec=m.Recorder(out,env,'synthetic-metadata-not-product-S10');rows=[]
for tool in ['check_terminal_metadata.py','check_small_adaptation.py']:
 for phase,expected in [('fixed',0),('withdrawn',1),('restored',0)]:
  row,stdout,stderr=rec.run([sys.executable,'-B',str(D/tool),'--phase',phase],cwd=str(D),timeout=30,check=False,source_sha='synthetic-metadata-not-product-S10',source_variant='pure-metadata-only')
  assert row['actual_process_returncode']==expected,(tool,phase,row)
  if expected:assert b'AssertionError' in stderr and not row.get('timeout_expired')
  rows.append({'tool':tool,'phase':phase,'expected_exit':expected,'command':row})
result={'exit_code':0,'formal_execution':False,'source_cache_or_SHM_read':False,'groups':2,'rows':rows}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'exit_code':0,'groups':2,'original_exits':[r['command']['actual_process_returncode'] for r in rows]}))
