from pathlib import Path
import ast,difflib,hashlib,json
OLD=Path('/tmp/geo337-F8-full123-terminal-preparation-v3-20261025')
NEW=Path('/tmp/geo337-S10-full123-terminal-preparation-20261025')
CURRENT=Path('/workspace/geo337-F10-full123-resource-anchor-preparation-20261025')
OWN='/dev/shm/geometry-axiom-geo337-20261025'
S='82c922a3941525d3a094ac0158bdc7dea57ea360'
H=lambda b:hashlib.sha256(b).hexdigest()
NEW.mkdir(exist_ok=False)
replacements={"F8":'S10','75a1e93811a52b69385cbdaf6a09d773ed9052ad':S,'/tmp/geo337-full123-F8-job-20261025':OWN+'/F10-ledger-job','/tmp/geo337-full123-F8-launch-20261025':OWN+'/F10-ledger-launch','/workspace/geo337-full123-F8-cache-20261025':OWN+'/F10-cache','/tmp/train337-323-f64d638f-source':OWN+'/F10-pool','/tmp/geo337-full123-F8-tmp-20261025':OWN+'/F10-ledger-tmp'}
# Replace exact old paths before replacing the display/source symbol F8.
def rebind(t):
 for a,b in list(replacements.items())[1:]:t=t.replace(a,b)
 return t.replace('F8','S10')
helper="""
OWN=Path('/dev/shm/geometry-axiom-geo337-20261025')
CONTROL_PATHS={
 'root_admission':OWN/'S10-full123-root-admission-20261025.json',
 'filesystem_admission':OWN/'S10-full123-filesystem-admission-20261025.json',
 'source_preparation_result':OWN/'F10-source-preparation-reserve-anchor/RESULT.json',
}
def private_path(p):
    return p.is_absolute() and (p.is_relative_to(Path('/tmp')) or p.is_relative_to(Path('/workspace')) or (p!=OWN and p.is_relative_to(OWN)))
def additional_controls(request):
    r=strict_json(read_regular(request));items=r.get('additional_originals',{})
    need(set(items)==set(CONTROL_PATHS),'all three immutable S10 original admission/preparation controls required')
    answer={}
    for name,p in CONTROL_PATHS.items():
        item=items[name];need(item.get('path')==str(p),'wrong original control path '+name)
        b=read_regular(p);need(digest(b)==item.get('sha256'),'original control pin mismatch '+name)
        answer[name]={'path':str(p),'sha256':digest(b),'bytes':len(b)}
    return answer
"""
base_guard=rebind((OLD/'terminal_guard.py').read_text())
guard=base_guard.replace("LOCKS=('/tmp/g261r3/heavy.lock','/tmp/g261r3/secondary.lock')", "LOCKS=('/tmp/g261r3/heavy.lock','/tmp/g261r3/secondary.lock')\n"+helper)
guard=guard.replace("p.is_absolute() and (p.is_relative_to(Path('/tmp')) or p.is_relative_to(Path('/workspace')))","private_path(p)")
# The helper text must retain its complete predicate, not recursively call itself.
guard=guard.replace("return private_path(p) or (p!=OWN and p.is_relative_to(OWN)))", "return p.is_absolute() and (p.is_relative_to(Path('/tmp')) or p.is_relative_to(Path('/workspace')) or (p!=OWN and p.is_relative_to(OWN)))")
needle="facts.update(terminal_capture_ready=True,terminal_bindings=bindings,terminal_files=terminal_files,missing_terminal_files=missing,request_sha256=digest(raw),adoption_requires_independent_actual_and_package_peers=True)"
assert needle in guard
guard=guard.replace(needle,needle+"\n    facts['additional_originals']=additional_controls(request)")
(NEW/'terminal_guard.py').write_text(guard)
verify=rebind((OLD/'verify_terminal.py').read_text()).replace('bound_terminal,need','bound_terminal,need,private_path').replace("a.out.is_relative_to(Path('/tmp')) or a.out.is_relative_to(Path('/workspace'))","private_path(a.out)")
(NEW/'verify_terminal.py').write_text(verify)
collect=rebind((OLD/'collect_terminal.py').read_text()).replace('terminal_lease,bound_terminal','terminal_lease,bound_terminal,private_path,additional_controls')
collect=collect.replace("out.is_relative_to(Path('/tmp')) or out.is_relative_to(Path('/workspace'))","private_path(out)")
needle="names=[n for n,p in files];need(len(names)==len(set(names)),'duplicate archive paths')"
assert needle in collect
collect=collect.replace(needle,"files += [('terminal-control/'+name+'.json',Path(item['path'])) for name,item in additional_controls(request).items()]\n    "+needle)
collect=collect.replace("'No extra ELF or source tree payload archived; original inline source preflight bytes inside raw remain intact. ELF/source/Git/cache objects remain at original paths.'", "'No extra ELF or source tree payload archived; original inline source preflight bytes inside raw remain intact. ELF/source/Git/cache objects remain at original paths and remain protected; exclusion is not deletion permission.'")
(NEW/'collect_terminal.py').write_text(collect)
(NEW/'check_terminal_metadata.py').write_text(rebind((OLD/'check_terminal_metadata.py').read_text()))
diff=''.join(''.join(difflib.unified_diff((OLD/n).read_text().splitlines(True),(NEW/n).read_text().splitlines(True),fromfile='accepted-F8/'+n,tofile='S10/'+n)) for n in ['terminal_guard.py','verify_terminal.py','collect_terminal.py','check_terminal_metadata.py'])
(NEW/'F8_TO_S10.diff').write_text(diff)
# Compare existing behavior by AST after only the explicit source/path rebinding.
oldnodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(base_guard).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
newnodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(guard).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
unchanged=[n for n in oldnodes if n!='bound_terminal'];assert all(oldnodes[n]==newnodes[n] for n in unchanged)
(NEW/'UNCHANGED_CORE.json').write_text(json.dumps({'normalized_only':'Exact source SHA/F8 symbol and five source/output paths','unchanged_original_functions':unchanged,'unchanged_formal_classifier':oldnodes['classify']==newnodes['classify'],'bound_terminal_delta':'OWN path admission plus three root/source preparation immutable controls; original root/outer/FINAL/123/restoration predicates remain','scope_functions_unchanged':['state','walk'],'archive_algorithm_changed':False},indent=2)+'\n')
q={'schema':'S10-full123-original-terminal-binding/1','binding_status':'UNBOUND_DO_NOT_EXECUTE','source_sha':S,'terminal_bindings':{'job_receipt':{'path':OWN+'/F10-ledger-job/receipt.json','sha256':None},'outer_result':{'path':OWN+'/F10-ledger-launch/RESULT.json','sha256':None},'original_tool_final':{'path':None,'sha256':None}},'additional_originals':{n:{'path':str(p),'sha256':None}for n,p in {'root_admission':OWN+'/S10-full123-root-admission-20261025.json','filesystem_admission':OWN+'/S10-full123-filesystem-admission-20261025.json','source_preparation_result':OWN+'/F10-source-preparation-reserve-anchor/RESULT.json'}.items()},'root_rule':'Only root binds actual original terminal files after true exec termination. If host FINAL schema differs, retain raw and peer exact adapter before execution; never manufacture success fields.'}
(NEW/'REQUEST.unbound.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
originals=[]
for n in ['run_full_ledger.py','launch_full_ledger.py','resource_admission.py','retain_mutation_streams.py','verify_observed_core_raw.py','source_closure_facts.py','PINS.json','PREPARATION.json']:
 p=CURRENT/n;b=p.read_bytes();originals.append({'path':str(p),'archive_name':'current-full123/'+n,'bytes':len(b),'sha256':H(b)})
for p,n in [(Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),'capture.py'),(Path('/workspace/geo261-environment/reap_children.py'),'reap_children.py'),(Path('/workspace/launch_geo337_S10_full123_root_20261025.py'),'root-launcher.py')]:
 b=p.read_bytes();originals.append({'path':str(p),'archive_name':n,'bytes':len(b),'sha256':H(b)})
assert next(x for x in originals if x['archive_name'].endswith('/run_full_ledger.py'))['sha256']=='7af6f3d7efe4987ed32ea0f356541630181fa6435684e72d83f7e3e7018148ef'
(NEW/'ORIGINAL_TOOLS.json').write_text(json.dumps(originals,indent=2)+'\n')
print(NEW)
print('draft Python parsed; preserved classifier AST; not executed against source')
for n in ['terminal_guard.py','verify_terminal.py','collect_terminal.py']:print(n,H((NEW/n).read_bytes()))
