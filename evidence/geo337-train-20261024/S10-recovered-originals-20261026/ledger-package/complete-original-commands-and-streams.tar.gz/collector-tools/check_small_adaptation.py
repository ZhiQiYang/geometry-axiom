"""Pure-path and tiny OWN temp metadata only. No real task roots or locks."""
from pathlib import Path
import argparse,json,tempfile
import terminal_guard as g
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['fixed','withdrawn','restored'],required=True);a=p.parse_args()
assert g.private_path(Path('/tmp/tiny')) and g.private_path(g.OWN/'terminal')
assert not g.private_path(g.OWN) and not g.private_path(Path('/dev/shm/another-owner/item'))
assert not g.private_path(Path('/dev/shm/geometry-axiom-geo337-20261025-evil/item'))
assert not g.private_path(Path('relative'))
with tempfile.TemporaryDirectory(prefix='S10-terminal-control-tiny-',dir='/tmp') as tmp:
 t=Path(tmp);old=g.CONTROL_PATHS;g.CONTROL_PATHS={k:t/(k+'.json') for k in old}
 try:
  controls={}
  for n,path in g.CONTROL_PATHS.items():
   raw=json.dumps({'synthetic':True,'name':n}).encode();path.write_bytes(raw);controls[n]={'path':str(path),'sha256':g.digest(raw)}
  q=t/'request.json';q.write_text(json.dumps({'additional_originals':controls}));assert len(g.additional_controls(q))==3
  target=next(iter(g.CONTROL_PATHS.values()));target.write_bytes(b'{"synthetic":"changed"}')
  if a.phase=='withdrawn':
   original=g.need
   def badneed(ok,message):
    if message.startswith('original control pin mismatch'):return
    original(ok,message)
   g.need=badneed
  rejected=False
  try:g.additional_controls(q)
  except RuntimeError as exc:rejected='original control pin mismatch' in str(exc)
  assert rejected,'original-control-drift-must-be-rejected'
 finally:g.CONTROL_PATHS=old
print(json.dumps({'pure_metadata_only':True,'phase':a.phase,'control_hash_drift_rejected':True,'actual_source_or_SHM_accessed':False}))
