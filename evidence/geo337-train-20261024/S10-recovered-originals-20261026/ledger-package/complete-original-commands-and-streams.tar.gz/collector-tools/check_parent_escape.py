from pathlib import Path
import argparse,json
import terminal_guard as g
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['fixed','withdrawn','restored'],required=True);a=p.parse_args()
fn=g.private_path
if a.phase=='withdrawn':
 def fn(p):return p.is_absolute() and (p.is_relative_to(Path('/tmp')) or p.is_relative_to(Path('/workspace')) or (p!=g.OWN and p.is_relative_to(g.OWN)))
assert fn(g.OWN/'terminal') and fn(Path('/tmp/terminal'))
assert not fn(g.OWN/'..'/'foreign-task'/'FINAL.json'),'OWN-parent-escape-must-be-rejected'
assert not fn(Path('/tmp/../dev/shm/foreign-task/FINAL.json')),'legacy-parent-escape-must-be-rejected'
print(json.dumps({'pure_path_only':True,'phase':a.phase,'parent_escape_rejected':True,'actual_filesystem_accessed':False}))
