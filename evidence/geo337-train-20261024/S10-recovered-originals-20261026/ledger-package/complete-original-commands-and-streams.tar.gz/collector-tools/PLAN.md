這份稿只準備 S10 真終態後的完整帳本收件。現在 UNBOUND、未驗證終態、未封包、未採用，沒有列出或讀取活動 F10-pool/cache/job/tmp/outer。原 F8 包與工具保持原樣。

固定來源：82c922a3941525d3a094ac0158bdc7dea57ea360。沿已審 F8 v3 三工具，只改來源、五路徑、既有 OWN SHM 放置及本輪三份原准入／來源準備控制檔的保全。classify 正規化來源後 AST 完全相同；123 列、120 個自然 S10 execution、3 retired、CLI/map/new-check 0、source_before/after/final 相等皆不變。原 equivalent/crashed 的允許判定仍歸原 mutate.py/--check，不加新白名單也不重判原 verdict。

起始 tracked 帳本是 F8 產生，原 SHA256 為 0123548b29bf8adbaf3cf896bfffb212134452f2574eaf8ae1d1b663104ead1b；S10 precheck 原 1、53 bridge stale。53 是 stale 數，120 是本輪應有自然 execution 數，不能互換。收件器保留起始 check 的真 exit，不要求它為 0；新生成帳本的最後 check 仍必須 0。此段只引用已封 metadata，未讀活動帳本。

完整封包範圍：

- F10-ledger-job 全部 regular 葉，包括 receipt.json、四 phase 的 c387 request/result/stdin/stdout/stderr、全 source head/tree/status/index 原流、mutants_results.json、observer 全 request/receipt/commands 原流、CORE_RAW_MAPPING.json、BRIDGE_RAW_INVENTORY.json、full-ledger-reaper.jsonl、原 generated SVG before/after snapshot。失敗或例外原流也全收；不因沒映射到正式 attempt 而刪除 observer row。
- F10-ledger-launch 全部 regular 葉，包括 REQUEST、RESULT、完整原 driver stdout/stderr 及環境／argv／真 exit。
- F10-cache 的每個 M*、_baseline、_bridge-baseline 子樹，全部 .stdout/.stderr/.json。包含 bridge baseline/mutant/restored/build/attempt 的兩原 stream，按原 ledger 與 BRIDGE_RAW_INVENTORY/CORE_RAW_MAPPING 逐項核，不能只看總 passed。原 matcher 與 oracle 不重跑。
- 本輪完整原 driver/launcher/resource admission/observer/core mapper/closure helper，原 c387 capture/reaper，root 啟動器，以及既有 PINS/PREPARATION；只從原工具位置取已釘 bytes，不複製 F8 原包。
- 真終態 BOUND request、原 host FINAL、root admission、filesystem admission、source preparation RESULT 原 bytes。後三者為精確既有路徑且逐 hash late-bind，終態前後再次核對。
- INDEX 包含每葉原路徑、bytes/hash/dev/inode/mode/nlink/mtime，tar 全回讀 hash／完整 regular member scope，PROCESS_SCOPE 顯式保留外 UID cwd 不可見限制。原檔不搬、不刪、不改，不把 atime 當 bytes 保全。

明確排除但持續保護：

- 不把 pool/seed 工作樹、private .git/index/objects、alternate stores 整份再拷入帳本包；以可解析 S10、原 source preparation manifest/closure 與已封 18,498/0 實績、此次全部 source state 原流引用。這不是允許稀疏不完整來源：full123 的 3763 pool／2738 seed 已由原准入與 source preparation 閉包約束；也不能宣稱它足夠代替完整 native 的 6997 葉。
- 不新增 ELF payload 或整個 compiler TMP；map/ledger 已記的 ELF hash、compile argv/env/output 原樣保留。沒有原 hash 的產物不能推定身份；hash-only 不是 byte artifact，沒有重建／刪除原 ELF 的授權。cache/seed/TMP/私有 Git 全保在原處。
- 原 source preparation 的 342 Git streams／完整 manifest 包是獨立原件，這個包只額外保 RESULT 與 immutable 引用，不稱已全部包含或已發布。root 要確保該包與本包均有公開可讀來源鏈。
- root launcher 在 execv 前的 admission print 不在 inner outer.stdout；root 應提供已保存的 host INITIAL／各中途工具回應。若存在，終態時只追加原件引用到 original_tools 清單並另封 PREPARATION 新 pin，不改程式、不重建 API 回應。若原件未保存，明列 host 早期回應缺口；不能藉 admission JSON 重建聲稱原 stdout 已封存。

終態後由 root 操作：

1. 保存原 host FINAL 的真實回應並給原件 path/hash、host actual exit、root exclusive lease。保持原 top-level exit/no-running-session 判定；若 FINAL 是 wrapped schema，先針對真原件做精確 adapter 小審，不能填假 exit 或挑出成功子件。
2. 給 job receipt／outer RESULT／三份 control 原件 pins，另存 BOUND_REQUEST；原 UNBOUND 模板保留。它們都必須來自同 S10。先保存失敗也可以收件，collection0 與 formal0 是不同欄位。
3. source/cache/job/TMP/outer 無 consumer、原 heavy＋secondary NB 雙鎖可取，才能 verify。兩工具會自行取鎖，outer 不得預先鎖相同 flock。原同 UID 不可見拒絕、foreign UID 明確 unknown 規則保留。所有真 SHM 讀取都用官方 require_escalated；不透過 sandbox namespace／symlink 繞過。
4. 在同一 OWN root 的全新 metadata/package OUT 跑原 verify，再 collect。collector 原公式不變：完整 logical + logical//1000 + 每葉 512 padding/2048 header + 4 MiB index + root 指定 reserve；fresh statvfs 檢查實際工作 mount，不能挪用 WS/TMP free。建議沿既有 root reserve 64 MiB，若 root 新規定更大照大者；不推測壓縮率或執行中大小。
5. 完成後交另一代理獨核每列／兩流／mapping／source restoration 與 tar member；再正常公開完整 raw、INDEX/TERMINAL/PROCESS_SCOPE、工具與 peer，遠端 archive bytes/hash/readable SHA 全核。SHM 非永久交付，未遠端驗證不得標已持久化。
6. 只有真完整驗收成立且獨審通過後，root 才做逐 byte 帳本採入、新 final SHA 與其 tracked check；收件器不寫任何 Git／source／ledger，不宣稱 future final 已執行 S10 全帳本。

根命令模板（不可現在執行）：

python3 -B <HERE>/verify_terminal.py --request <REAL_BOUND> --request-sha256 <REAL_BOUND_SHA> --preparation-sha256 <REVIEWED_PREP_SHA> --out <OWN>/S10-ledger-terminal-verify --root-terminal-lease
python3 -B <HERE>/collect_terminal.py --request <SAME_BOUND> --request-sha256 <SAME_BOUND_SHA> --preparation-sha256 <SAME_REVIEWED_PREP_SHA> --out <OWN>/S10-ledger-complete-package --reserve-bytes 67108864 --root-terminal-lease

兩命令均沿原 c387 outer 保存 argv/env/exit/full stdout/stderr。任何 metadata 收件成功只表示忠實收到了終態。原 classified formal_accepted=true 是採用前的必要條件，仍不替代另一代理實績審查。

已補保存的 host 起始／兩次 poll 原物件：initial SHA ecfefb08fd6ab7737c6f3c3bd91abc7cf653c9a6f69e56c97572f7a9c00a989a，兩 poll 原 stdout 為空，三件均 session26296 且沒有 exit_code。它們已列 original_tools 的 host-history 範圍，總 1263B；真正 FINAL 尚無，不將起始 admission 的 1KiB 回應當終態或驗收。後續更多 host 回應若有，終態時逐件釘原 bytes 納入同範圍即可，需另封 manifest pin，三工具不用變。
