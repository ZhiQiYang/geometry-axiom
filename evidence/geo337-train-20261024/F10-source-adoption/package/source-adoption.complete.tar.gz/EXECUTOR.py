from pathlib import Path
import hashlib,importlib.util,json,os,sys
PUB=Path('/dev/shm/geometry-axiom-geo337-20261025/publisher-source')
OUT=PUB.parent/'F10-source-adoption-original-20261025'
E='249a05ed4c8a085bdf3353ac781638f2a9b3d460'
MAIN='405f8c5e1a637a16cbe47470faf5ae1fa02b8676'
F9='4f8a794f4167c3562eb182045102e86e9e37cca9'
BASE='425c092eaf16f90256d76433243baebde45163ac'
BRANCH='codex/train-337-continue-20261024'
TEST='tests/test_geo314_commit_paths.py';DEC='決策佇列.md'
PROGRESS='evidence/geo337-train-20261024/PROGRESS.md'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
PATCH=Path('/tmp/geo314-F9-kernel-scope-rootcause-20261025/PROPOSED.patch')
REVIEW=Path('/workspace/geo337-main405-merge-readonly-wqsdn6mu')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','capture pin')
need(sha(PATCH.read_bytes())=='233de5a153ad7d27d8caad56575c1545488987a6766d8075d7cf5f34216e78af','patch pin')
need(not OUT.exists(),'fresh output required')
OUT.mkdir(mode=0o700)
sp=importlib.util.spec_from_file_location('original_capture',CAP);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env['GIT_OPTIONAL_LOCKS']='0'
rec=cap.Recorder(OUT,env,F9)
result={'exit_code':1,'previous_evidence_head':E,'main':MAIN,'prior_source':F9,'source_sha':None,'published':False,'merged_PR_or_main':False}
def save():cap.dump(OUT/'RESULT.json',result)
def git(*args,data=None,accepted=(0,)):
    row,b,e=rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=PUB,data=data,check=False,timeout=None,source_variant='root normal main-to-train merge and exact reviewed I24 test fix')
    need(row['actual_process_returncode'] in accepted,'unexpected Git exit: '+row['directory'])
    return row['actual_process_returncode'],b
def g(*args,**kw):return git(*args,**kw)[1]
def remote(branch):
    b=g('ls-remote','--heads','origin','refs/heads/'+branch).splitlines();need(len(b)==1,'exact remote branch required')
    oid,ref=b[0].split(b'\t');need(ref.decode()=='refs/heads/'+branch,'wrong remote ref');return oid.decode()
save();(OUT/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(OUT/'PROPOSED.patch').write_bytes(PATCH.read_bytes())
try:
    need(g('rev-parse','HEAD').decode().strip()==E,'publisher HEAD changed')
    need(g('branch','--show-current').decode().strip()==BRANCH,'wrong branch')
    need(not g('status','--porcelain=v1','--untracked-files=all'),'dirty publisher')
    need(remote(BRANCH)==E and remote('main')==MAIN,'remote head changed')
    need(not g('diff','--name-only','--no-renames',F9,E,'--','.',':(exclude)evidence'),'unreviewed source changes')
    progress=g('show',E+':'+PROGRESS);test=g('show',E+':'+TEST)
    need(sha(test)=='f4f4fed9677b093bf0d16be185717a1e1959e5f1e887470523eb4c8333ee85cc','original test hash')
    before_dec=g('show',E+':'+DEC);need(sha(before_dec)=='cfad2b7ad5181a97a0d87e0791f96548cb0838f6222a01fabdf06d987b5211e0','original decision hash')
    for name in ['HEAD','index','info/sparse-checkout']:
        p=PUB/'.git'/name
        if p.exists():(OUT/('before-'+name.replace('/','-')+'.bin')).write_bytes(p.read_bytes())
    fs=os.statvfs(PUB);need(fs.f_bavail*fs.f_frsize>67108864+2*(PUB/'.git/index').stat().st_size,'source merge storage reserve')
    g('sparse-checkout','set','--no-cone','--stdin',data=(''.join('/'+x+'\n' for x in [PROGRESS,DEC,TEST])).encode())
    need(not g('status','--porcelain=v1','--untracked-files=all'),'sparse materialization dirty')
    need((PUB/TEST).read_bytes()==test and (PUB/DEC).read_bytes()==before_dec and (PUB/PROGRESS).read_bytes()==progress,'materialization bytes changed')
    rc,_=git('merge','--no-commit','--no-ff',MAIN,accepted=(0,1));result['normal_merge_exit']=rc;save()
    unmerged=g('diff','--name-only','--diff-filter=U','-z').split(b'\0');unmerged=[x.decode() for x in unmerged if x]
    need(unmerged==[DEC] if rc==1 else not unmerged,'unexpected merge conflict')
    need((PUB/'.git/MERGE_HEAD').read_text().strip()==MAIN,'not normal merge state')
    base=g('show',BASE+':'+DEC);need(sha(base)=='a9f14cdd3cf2846c65d0a7cc32f02bf3a12ba60e817cd9223c59e4da6f4734e5','base decision drift')
    train=(REVIEW/'TRAIN_INSERTION.exact.bin').read_bytes();main=(REVIEW/'MAIN_INSERTION.exact.bin').read_bytes()
    need(sha(train)=='855c00c9769d3f8f11b9a872f59c047de74f3fc89bec58bf8d2cf14df1367da3','train insertion drift')
    need(sha(main)=='37ed6c03d84a80a9d3c7c6a920eff083be8f3239d3c4c044c0ecdcc7e3b31edb','main insertion drift')
    lines=base.splitlines(keepends=True);merged=b''.join(lines[:839])+train+main+b''.join(lines[839:])
    need(len(merged)==241596 and sha(merged)=='fe822051b5413fb79490b333e23f3c9d6b96959c01f937c274d3246772c15e14','decision resolution differs')
    (PUB/DEC).write_bytes(merged);g('add','--',DEC)
    need(not g('diff','--name-only','--diff-filter=U'),'unresolved conflicts')
    g('apply','--check','--index',str(PATCH));g('apply','--index',str(PATCH))
    need(sha((PUB/TEST).read_bytes())=='3ace33248d6ce39b869bf09319315544610311c2ddb8434ad8a57d6a90a9f032','new test hash')
    need(g('show',':'+TEST)==(PUB/TEST).read_bytes() and g('show',':'+DEC)==merged,'index/working bytes differ')
    staged_modes={}
    for row in g('ls-files','--stage','-z','--',TEST,DEC).split(b'\0'):
        if row:
            meta,name=row.split(b'\t',1);mode,oid,stage=meta.split(b' ')
            need(stage==b'0','unmerged staged leaf');staged_modes[name.decode()]=mode.decode()
    need(staged_modes=={TEST:'100644',DEC:'100644'},'staged leaf mode changed')
    g('diff','--cached','--check')
    need(set(g('diff','--cached','--name-only','--no-renames','-z',E).split(b'\0'))=={TEST.encode(),DEC.encode(),b''},'staged scope changed')
    need(g('rev-parse','HEAD').decode().strip()==E and remote(BRANCH)==E,'parent changed before commit')
    g('commit','-m','Merge main decisions and scope I24 kernel contract to reviewed train')
    source=g('rev-parse','HEAD').decode().strip();result['source_sha']=source;save()
    need(g('rev-list','--parents','-n','1','HEAD').decode().strip().split()==[source,E,MAIN],'merge parents differ')
    need(not g('status','--porcelain=v1','--untracked-files=all'),'post-merge dirty')
    need(set(g('diff','--name-only','--no-renames','-z',E,source).split(b'\0'))=={TEST.encode(),DEC.encode(),b''},'final source scope changed')
    need(g('ls-tree',source,'geometry-core/kernel')==g('ls-tree',F9,'geometry-core/kernel'),'K changed')
    need(g('show',source+':'+PROGRESS)==progress,'old progress was rewritten')
    g('push','origin','HEAD:refs/heads/'+BRANCH);need(remote(BRANCH)==source,'remote source differs')
    for path in [TEST,DEC]:
        oid=g('rev-parse',source+':'+path).decode().strip()
        row,raw,err=rec.run(['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json','repos/ZhiQiYang/geometry-axiom/git/blobs/'+oid],cwd=OUT,check=False,timeout=None,source_sha=source,source_variant='remote complete source blob verification')
        need(row['actual_process_returncode']==0 and raw==(PUB/path).read_bytes(),'remote source payload differs: '+path)
    result.update(exit_code=0,published=True,changed_paths=[TEST,DEC],decision_sha256=sha(merged),test_sha256=sha((PUB/TEST).read_bytes()),remote_blobs_verified=2,source_gate_results='UNRUN; old F9 receipts retain original SHA')
except BaseException as exc:
    result['error']=repr(exc);raise
finally:save()
print(json.dumps(result,ensure_ascii=False))
