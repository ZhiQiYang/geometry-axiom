"""Reread complete saved observations; never trust a front-end pass assertion."""
import gzip
import hashlib
import json
from pathlib import Path
from q323_exact_policy import (APPROVAL_SHA, AUTHORITY_BINDING_SHA256, BASE_SHA, GUARDS,
                              SCOPE, compare_pair, require_corpus, require_verified_authority)


def must(value, reason):
    if not value:
        raise RuntimeError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact_int(value, expected):
    return type(value) is int and value == expected


def audit_saved(evidence, repo, *, source_sha, base_sha):
    require_verified_authority()
    evidence, repo = Path(evidence), Path(repo)
    must(base_sha == BASE_SHA, 'Wrong fixed historical base')
    must(isinstance(source_sha, str) and len(source_sha) == 40 and all(c in '0123456789abcdef' for c in source_sha),
         'Exact source SHA required')
    inventory_raw = (evidence / 'scene-inventory.json').read_bytes()
    inventory = json.loads(inventory_raw)
    must(exact_int(inventory.get('root_count'), 171) and exact_int(inventory.get('generated_count'), 4)
         and exact_int(inventory.get('total'), 175), 'Original 171+4 inventory counts required')
    entries = inventory.get('scenes')
    must(isinstance(entries, list) and len(entries) == 175, 'Inventory must contain exactly 175 entries')
    names = [row.get('name') for row in entries]
    must(all(isinstance(name, str) and name.endswith('.scene') and Path(name).name == name and '\\' not in name for name in names),
         'Exact root scene names only')
    require_corpus(names)
    fixed = sorted(row['name'] for row in entries if 'generated_n' not in row)
    generated = sorted(row['name'] for row in entries if 'generated_n' in row)
    must(len(fixed) == 171 and generated == ['s16.scene', 's32.scene', 's48.scene', 's64.scene'],
         'Original fixed/generated inventory set required')
    source_paths = {}
    for entry in entries:
        name = entry['name']
        if 'generated_n' in entry:
            must(type(entry['generated_n']) is int and name == 's%d.scene' % entry['generated_n']
                 and entry['generated_n'] in (16, 32, 48, 64), 'Generated fixture identity mismatch')
            path = evidence / 'scenes' / name
        else:
            path = repo / name
        raw = path.read_bytes()
        must(exact_int(entry.get('bytes'), len(raw)) and entry.get('sha256') == sha(raw), 'Fixture raw/hash changed: ' + name)
        source_paths[name] = path
    raw_equivalence = (evidence / 'equivalence.json').read_bytes()
    declared = json.loads(raw_equivalence)
    must(exact_int(declared.get('scenes'), 175) and isinstance(declared.get('runs'), list)
         and len(declared['runs']) == 350, 'Original audit requires 175 scenes / 350 rows')
    must(declared.get('policy_scope') == SCOPE and declared.get('approval_sha') == APPROVAL_SHA,
         'Front comparison policy identity mismatch')
    names_in_order = fixed + generated
    wanted_roles = [(name, version) for name in names_in_order for version in ('base', 'fix')]
    seen = set()
    pairs = {}
    observations = []
    for index, row in enumerate(declared['runs']):
        role = (row.get('scene'), row.get('version'))
        must(role == wanted_roles[index] and role not in seen, 'Missing, duplicate, unknown or reordered scene/version row')
        seen.add(role)
        name, version = role
        path = source_paths[name]
        must(row.get('path') == str(path) and row.get('command') == 'loadfile ' + str(path) + '\ndump\n',
             'Original loadfile+dump command/path identity mismatch: ' + name)
        streams = {}
        for stream in ('stdout', 'stderr'):
            raw = (evidence / 'stdout' / version / (name + '.' + stream)).read_bytes()
            must(exact_int(row.get(stream + '_bytes'), len(raw)) and row.get(stream + '_sha256') == sha(raw),
                 'Full ' + stream + ' raw/hash mismatch: ' + name)
            streams[stream] = raw
        compressed = (evidence / 'graphs' / version / (name + '.bin.gz')).read_bytes()
        graph = gzip.decompress(compressed)
        must(exact_int(row.get('graph_bytes'), len(graph)) and row.get('graph_sha256') == sha(graph),
             'Full graph raw/hash mismatch: ' + name)
        snapshot = dict(streams, graph=graph, guards=row.get('guards'), exit=row.get('exit'), trace_exit=row.get('trace_exit'))
        pairs.setdefault(name, {})[version] = snapshot
        observations.append({'scene': name, 'version': version,
            'stdout_sha256': sha(streams['stdout']), 'stderr_sha256': sha(streams['stderr']),
            'graph_sha256': sha(graph), 'compressed_graph_sha256': sha(compressed)})
    must(len(pairs) == 175 and all(set(pair) == {'base', 'fix'} for pair in pairs.values()),
         'Exact one base/fix pair per scene required')
    failures, insertions = [], []
    strict_tuple_equal = True
    for name in names_in_order:
        pair = pairs[name]
        result = compare_pair(name, str(source_paths[name]), pair['base'], pair['fix'], scope=SCOPE, base_sha=base_sha)
        failures.extend([name, label] for label in result['failures'])
        insertions.extend(result['authorized_insertions'])
        strict_tuple_equal = strict_tuple_equal and pair['base'] == pair['fix']
    must(not failures, 'Raw audit rejected unapproved differences: ' + repr(failures))  # AUDIT_RAW_GUARD
    must(declared.get('failures') == failures and declared.get('authorized_insertions') == insertions,
         'Front report differs from independently recomputed raw audit')  # AUDIT_DECLARATION_GUARD
    return {'schema': 'geo323-owner-exact-audit/1', 'audit_exit': 0,
        'execution_source_sha': source_sha, 'historical_base_sha': base_sha,
        'scenes': 175, 'runs': 350, 'policy_scope': SCOPE, 'approval_sha': APPROVAL_SHA,
        'authority_binding_sha256': AUTHORITY_BINDING_SHA256,
        'equivalence_raw_sha256': sha(raw_equivalence), 'inventory_raw_sha256': sha(inventory_raw),
        'strict_tuple_equal_without_exceptions': strict_tuple_equal,
        'authorized_insertions_recomputed': insertions, 'failures': failures,
        'source_graph_and_five_guards_equal': True, 'process_and_trace_exits_zero': True,
        'observations': observations, 'original_R8_rewritten': False}
