"""Owner-authorized Q-323-ABC external candidate; not yet adopted into a formal run.

Verified connected-owner comment points to main 405f8c5e1a637a16cbe47470faf5ae1fa02b8676,
決策佇列.md, 2026-10-25 #338 列車. This is not P-189 policy.
No normalization, decoding/reserialization, regex, or message-class exception.
"""
from dataclasses import dataclass
import hashlib, json
from pathlib import Path

APPROVAL_SHA = '405f8c5e1a637a16cbe47470faf5ae1fa02b8676'
BASE_SHA = 'b74f9a2ae7ade1555b9be45283adecc097fb76e3'
SCOPE = 'Q-323-ABC-175-scenes'
AUTHORIZATION_VERIFIED = True
ADOPTED = False
AUTHORITY_BINDING_SHA256 = '2c67f64b5fad8281ec57c3ff92566fd6aa61c43ff65ca5094d1701a9dfcbf3a5'

def require_verified_authority():
    root = Path(__file__).resolve().parent
    raw = (root / 'VERIFIED_AUTHORITY.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != AUTHORITY_BINDING_SHA256:
        raise RuntimeError('Verified owner authority binding changed')
    binding = json.loads(raw)
    if (binding.get('status') != 'VERIFIED_CONNECTED_OWNER_COMMENT'
        or binding.get('scope') != SCOPE or binding.get('approval_sha') != APPROVAL_SHA
        or binding.get('historical_base_sha') != BASE_SHA
        or binding.get('comment_id') != 6396611849 or binding.get('account_identity_equal') is not True):
        raise RuntimeError('Verified owner authority scope mismatch')
    for item in binding['pinned_inputs']:
        path = root / item['relative_path']
        data = path.read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise RuntimeError('Verified owner authority input changed: ' + item['relative_path'])

GUARDS = ('app_world_candidate_create', 'app_world_candidate_seal',
          'app_world_candidate_publish', 'app_world_candidate_revalidate', 'reference_check_all')


@dataclass(frozen=True)
class ExceptionSpec:
    line: int
    timber: int
    suffix: bytes

    @property
    def error(self):
        return ('V_EXTENSION：非 boundary 角材（%d）的 footprint 超出定位邊範圍' % self.timber).encode('utf-8')

    @property
    def stdout_prefix(self):
        return b'{"ok":false,"error":"line ' + str(self.line).encode() + b': ' + self.error


APPROVED = {
    '_role_priority_mutant.scene': ExceptionSpec(8, 1, '——定位邊 e2 [2000,4000] mm，低端超出 [0,2000] mm'.encode('utf-8')),
    '_s1_p8_l_room_primary_through_reflex_extension.scene': ExceptionSpec(15, 3, '——定位邊 e3 [3000,4800] mm，低端超出 [27,3000] mm'.encode('utf-8')),
    '_s1_p8b_l_room_primary_through_reflex_extension_hi.scene': ExceptionSpec(12, 3, '——定位邊 e1 [0,1800] mm，高端超出 [1800,4773] mm'.encode('utf-8')),
}
STDOUT_TAIL = b'","status":"INVALID","code":"SCENE_INVALID"}\n'
STDERR_TAIL = b'\n'  # Raw historical stderr ends in one LF byte 0a.


def authorized_insertion(scene, channel, before, after, scene_path):
    """Return exact insertion metadata or None; identical bytes need no exception."""
    spec = APPROVED.get(scene)
    if spec is None or not isinstance(before, bytes) or not isinstance(after, bytes):
        return None
    if not isinstance(scene_path, str) or '\n' in scene_path or '\r' in scene_path:
        return None
    if scene_path.rsplit('/', 1)[-1] != scene:
        return None
    if channel == 'stdout':
        prefix, tail = spec.stdout_prefix, STDOUT_TAIL
        anchor = prefix + tail
        if not before.startswith(anchor):
            return None
    elif channel == 'stderr':
        prefix = scene_path.encode('utf-8') + b':' + str(spec.line).encode() + b': ' + spec.error
        tail = STDERR_TAIL
        anchor = prefix + tail
        if before != anchor:
            return None
    else:
        return None
    offset = len(prefix)
    # Require a single original diagnostic and a single new suffix in this stream.
    if before.count(anchor) != 1 or spec.suffix in before:
        return None
    expected = before[:offset] + spec.suffix + before[offset:]
    if after != expected or after.count(spec.suffix) != 1:  # EXACT_INSERTION_GUARD
        return None
    return {'scene': scene, 'channel': channel, 'offset': offset,
            'suffix_utf8': spec.suffix.decode('utf-8'), 'suffix_hex': spec.suffix.hex(),
            'inserted_bytes': len(spec.suffix), 'approval_sha': APPROVAL_SHA}


def compare_pair(scene, scene_path, base, fix, *, scope, base_sha):
    """Compare raw observable snapshots. Receipt/source attestation belongs to the caller."""
    if scope != SCOPE or base_sha != BASE_SHA:
        raise ValueError('Q-323-ABC exact policy requires its fixed scope and historical base SHA.')
    failures, accepted = [], []
    keys = {'stdout', 'stderr', 'graph', 'guards', 'exit', 'trace_exit'}
    if not isinstance(scene, str) or not isinstance(base, dict) or not isinstance(fix, dict) or set(base) != keys or set(fix) != keys:
        raise ValueError('Exact snapshot fields required.')
    for version, snapshot in [('base', base), ('fix', fix)]:
        for field in ('exit', 'trace_exit'):
            if type(snapshot[field]) is not int or snapshot[field] != 0:
                failures.append(version + ':' + field)
        guards = snapshot['guards']
        if not isinstance(guards, dict) or set(guards) != set(GUARDS) or any(type(v) is not int or v < 0 for v in guards.values()):
            failures.append(version + ':five guards shape')
        for field in ('stdout', 'stderr', 'graph'):
            if not isinstance(snapshot[field], bytes):
                failures.append(version + ':' + field + ' bytes type')
    for channel in ('stdout', 'stderr'):
        if base[channel] == fix[channel]:
            continue
        insertion = authorized_insertion(scene, channel, base[channel], fix[channel], scene_path)
        if insertion is None:
            failures.append(channel)
        else:
            accepted.append(insertion)
    if base['graph'] != fix['graph']:
        failures.append('source graph (possible cross-consumer dependency loss)')
    if base['guards'] != fix['guards']:
        failures.append('guard traffic')
    return {'ok': not failures, 'failures': failures, 'authorized_insertions': accepted,
            'policy_scope': SCOPE, 'approval_sha': APPROVAL_SHA,
            'authorization_verified': True, 'adopted': False, 'product_gate_verdict': None}


def require_corpus(scenes):
    """Original inventory is 171 fixed + 4 generated; never silently drop or duplicate a pair."""
    if len(scenes) != 175 or len(set(scenes)) != 175:
        raise ValueError('Q-323-ABC requires exactly 175 unique scene names, each with one base/fix pair.')
