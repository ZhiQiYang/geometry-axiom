#!/usr/bin/env python3
"""One new Q-323 comparison stage; pinned historical binaries, fresh output only."""
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import sys
import traceback

import geo323_record as capture
import run as original_runner
from q323_exact_policy import BASE_SHA, require_verified_authority

HERE = Path(__file__).resolve().parent
ORIGINAL_RECEIPT_SHA = '979680e78a381d28a6d1c6825b7b1b8af850bebec381ec3cee3ef42e9e46ea15'
ORIGINAL_SOURCE_SHA = '75a1e93811a52b69385cbdaf6a09d773ed9052ad'
ORIGINAL_MAIN_SHA = 'adbaebf9c73ea6801d7b4d5214e4b846b132923b'
INVENTORY_SHA = 'f70496207d882e4a52ab9d5ebc888ff4359569b1bd35c36e2bade3f377783e8c'
LABELS = ('base', 'fix', 'base-trace', 'fix-trace')


class ReuseRecorder(capture.Recorder):
    """Separate execution source identity from the historical binary build identity."""
    def __init__(self, *args, reuse, old_repo, **kwargs):
        super().__init__(*args, **kwargs)
        self.reuse, self.old_repo = Path(reuse).resolve(), Path(old_repo).resolve()

    def role(self, command, cwd):
        if command and command[0] == 'git' and '-C' in command:
            target = Path(command[command.index('-C') + 1]).resolve()
            if target == self.old_repo:
                return {'label': 'historical-F8-source-identity-read', 'sha': ORIGINAL_SOURCE_SHA}
        if command:
            executable = Path(command[0]).resolve()
            for label in LABELS:
                if executable == (self.reuse / 'work' / label / 'bridge').resolve():
                    base = label.startswith('base')
                    return {'label': label + '-execution-with-pinned-reused-binary',
                            'sha': BASE_SHA if base else self.sha,
                            'binary_build_sha': BASE_SHA if base else ORIGINAL_SOURCE_SHA,
                            'fix_execution_closure_verified_equal_to_F8': not base}
        return super().role(command, cwd)


class ReadOnlySession(original_runner.Session):
    def git(self, *args):
        result = self.r.run(['git', '--no-optional-locks', '-C', str(self.a.repo), *args], cwd=self.a.repo)
        must(result.returncode == 0, 'Read-only source Git command failed')
        return result.stdout


def must(value, message):
    if not value:
        raise RuntimeError(message)


def file_record(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def closure(root):
    """Read the same recursive quoted-include closure used by the original build."""
    root = root.resolve()
    files = {}
    def read(path):
        path = path.resolve()
        relative = path.relative_to(root).as_posix()
        if relative in files:
            return
        data = path.read_bytes()
        files[relative] = {'bytes': len(data), 'sha256': capture.sha(data)}
        for operand in re.findall(rb'^\s*#\s*include\s+([^\r\n]+)', data, re.M):
            must(operand.lstrip().startswith((b'"', b'<')),
                 'Unresolved macro include prevents a complete reuse closure: ' + relative)
        for inc in re.findall(rb'^\s*#\s*include\s*"([^"\r\n]+)"', data, re.M):
            child = path.parent / os.fsdecode(inc)
            if child.is_file():
                read(child)
    read(root / 'geometry-web/web_bridge.c')
    return files


def git_state(repo, recorder):
    values = []
    for argv in [('rev-parse', 'HEAD'), ('status', '--porcelain=v1', '--untracked-files=all')]:
        result = recorder.run(['git', '--no-optional-locks', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                               '-C', str(repo), *argv], cwd=repo)
        must(result.returncode == 0, 'Source identity Git read failed')
        values.append(result.stdout.decode().strip() if argv[0] == 'rev-parse' else result.stdout.decode())
    return {'head': values[0], 'status': values[1]}


def git_index_record(repo):
    marker = repo / '.git'
    if marker.is_dir():
        directory = marker
    else:
        line = marker.read_text().strip()
        must(line.startswith('gitdir: '), 'Unsupported Git metadata marker')
        directory = Path(line[len('gitdir: '):])
        if not directory.is_absolute():
            directory = repo / directory
    return file_record(directory.resolve() / 'index')


def bind_reuse(args, recorder):
    require_verified_authority()
    origin_path = args.reuse / 'receipt.json'
    must(file_record(origin_path)['sha256'] == ORIGINAL_RECEIPT_SHA, 'Historical R8 receipt changed')
    original = json.loads(origin_path.read_bytes())
    must(original['source_sha'] == ORIGINAL_SOURCE_SHA and original['base'] == BASE_SHA
         and original['main'] == ORIGINAL_MAIN_SHA and original['wrapper_exit'] == 1,
         'Historical R8 identity/red state mismatch')
    must(original['stages']['prepare']['execution_exit'] == 0 and original['stages']['build']['execution_exit'] == 0,
         'Original prerequisites were not successful')
    old_repo = Path(original['source_repo']).resolve()
    must(git_state(old_repo, recorder) == {'head': ORIGINAL_SOURCE_SHA, 'status': ''}, 'Historical F8 source is not exact/clean')
    must(git_state(args.repo, recorder) == {'head': args.sha, 'status': ''}, 'Requested execution source is not exact/clean')
    old_closure, new_closure = closure(old_repo), closure(args.repo)
    must(old_closure == new_closure, 'Current source C closure differs from F8 binary source; rebuild required, no relabelling')
    inventory_path = args.reuse / 'evidence/scene-inventory.json'
    must(file_record(inventory_path)['sha256'] == INVENTORY_SHA, 'Original 175-scene inventory changed')
    inventory = json.loads(inventory_path.read_bytes())
    must(inventory['total'] == 175 and len(inventory['scenes']) == 175, 'Original inventory incomplete')
    fixture_bindings = []
    for entry in inventory['scenes']:
        path = args.reuse / 'evidence/scenes' / entry['name'] if 'generated_n' in entry else args.repo / entry['name']
        item = file_record(path)
        must(item['bytes'] == entry['bytes'] and item['sha256'] == entry['sha256'], 'Fixture differs from original fixed bytes: ' + entry['name'])
        fixture_bindings.append(item)
    builds = {row['label']: row for row in original['builds']}
    binaries = {}
    for label in LABELS:
        row = builds[label]
        path = args.reuse / 'work' / label / 'bridge'
        item = file_record(path)
        must(row['execution_exit'] == 0 and item['sha256'] == row['binary_sha256']
             and path.read_bytes().startswith(b'\x7fELF'), 'Original ELF payload/hash unavailable: ' + label)
        binaries[label] = item
    return {'schema': 'geo323-comparison-reuse-identity/1', 'execution_source_sha': args.sha,
            'execution_source_repo': str(args.repo), 'historical_binary_fix_source_sha': ORIGINAL_SOURCE_SHA,
            'historical_binary_base_source_sha': BASE_SHA, 'main_comparison_sha_retained_not_rerun': ORIGINAL_MAIN_SHA,
            'original_R8_receipt': file_record(origin_path), 'original_R8_exit_unchanged': 1,
            'old_git_index': git_index_record(old_repo), 'execution_git_index': git_index_record(args.repo),
            'source_closure_equal': True, 'old_closure': old_closure, 'execution_closure': new_closure,
            'inventory': file_record(inventory_path), 'fixtures': fixture_bindings, 'binaries': binaries,
            'compiler_rerun': False, 'performance_rerun': False, 'new_comparison_stage_only': True}


def inner(args):
    must(args.exclusive_slot_confirmed, 'Root must schedule an exclusive slot before product execution')
    must(not sys.flags.optimize, 'Optimized Python disables original assertions')
    for key in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'CPATH', 'C_INCLUDE_PATH', 'LIBRARY_PATH', 'GCC_EXEC_PREFIX', 'COMPILER_PATH'):
        must(not os.environ.get(key), 'Unexpected runtime/include injection: ' + key)
    args.heavy_lock.parent.mkdir(parents=True, exist_ok=True)
    with args.heavy_lock.open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        must(shutil.disk_usage(args.out).free >= args.min_free_bytes, 'Insufficient planned free bytes; no comparison started')
        (args.out / 'tmp').mkdir()
        env, removed = original_runner.clean_environment(args)
        for name in list(env):
            if name.startswith('MUTATE'):
                removed.append(name)
                del env[name]
        os.environ.clear();os.environ.update(env)
        before_stack = resource.getrlimit(resource.RLIMIT_STACK)
        must(before_stack[1] == resource.RLIM_INFINITY or before_stack[1] >= 16777216, 'Original 16MiB stack unavailable')
        resource.setrlimit(resource.RLIMIT_STACK, (16777216, before_stack[1]))
        invocation = args.out / 'invocation'
        invocation.mkdir()
        original = json.loads((args.reuse / 'receipt.json').read_bytes())
        recorder = ReuseRecorder(invocation / 'commands', args.repo, args.sha, env,
                                 reuse=args.reuse, old_repo=original['source_repo'])
        capture.ACTIVE = recorder
        with (invocation/'driver.stdout').open('w') as stdout, (invocation/'driver.stderr').open('w') as stderr, \
             contextlib.redirect_stdout(original_runner.Tee(sys.stdout,stdout)), \
             contextlib.redirect_stderr(original_runner.Tee(sys.stderr,stderr)):
            binding = bind_reuse(args, recorder)
            capture.dump(args.out / 'REUSE_BEFORE.json', binding)
            session = ReadOnlySession(args, recorder)
            for label, item in binding['binaries'].items():
                target = session.work / label;target.mkdir()
                (target/'bridge').symlink_to(Path(item['path']).resolve())
            shutil.copyfile(args.reuse/'evidence/scene-inventory.json', session.evidence/'scene-inventory.json')
            (session.evidence/'scenes').mkdir()
            for item in json.loads((session.evidence/'scene-inventory.json').read_bytes())['scenes']:
                if 'generated_n' in item:
                    shutil.copyfile(args.reuse/'evidence/scenes'/item['name'],session.evidence/'scenes'/item['name'])
            session.record.update(environment=capture.safe_env(env),cleared_environment_names=removed,
                stack_before=before_stack,stack_during=resource.getrlimit(resource.RLIMIT_STACK),
                reused_binary_identity=binding,
                builds=[{'label':label,'execution_exit':0,'execution_in_this_run':False,
                         'historical_receipt':binding['original_R8_receipt'], 'binary_sha256':item['sha256']}
                        for label,item in binding['binaries'].items()])
            session.save()
            session.stage('compare')
            try:
                after = bind_reuse(args, recorder)
                capture.dump(args.out / 'REUSE_AFTER.json', after)
                must(after == binding, 'Reuse/source/input identity changed during comparison')
                must(not recorder.recording_errors, 'Recorder failed; cannot accept incomplete evidence')
            except BaseException:
                session.record['stages']['compare']['execution_exit'] = 1
                session.record['stages']['compare']['errors'].append(traceback.format_exc())
                traceback.print_exc()
            code = int(session.record['stages']['compare']['execution_exit'] != 0)
            session.record.update(wrapper_exit=code,all_required_stages_completed=False,full_acceptance_passed=None,
                status='只完成本輪comparison；原R8與性能樣本保持歷史身份，其他gate未由本輪執行')
            session.save()
            return code


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--exclusive-slot-confirmed',action='store_true')
    for name in ('repo','reuse','out','heavy-lock'):
        parser.add_argument('--'+name,type=lambda value:Path(value).resolve(),required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--min-free-bytes',type=int,default=33554432,help='Operational reserve, not a product threshold')
    parser.add_argument('--inside-reaper',action='store_true',help=argparse.SUPPRESS)
    args=parser.parse_args()
    if not args.execute:parser.error('Explicit root scheduling and --execute are required; no product is run by default')
    if not re.fullmatch('[0-9a-f]{40}',args.sha):parser.error('Full execution source SHA required')
    if args.out==args.repo or args.out.is_relative_to(args.repo) or args.out==args.reuse or args.out.is_relative_to(args.reuse):
        parser.error('Fresh output must be outside both source and historical R8')
    if args.out==HERE or args.out.is_relative_to(HERE):
        parser.error('Output must be outside the frozen toolkit')
    for protected in (args.repo,args.reuse,HERE):
        if args.heavy_lock==protected or args.heavy_lock.is_relative_to(protected):
            parser.error('Lock writes must remain outside source, historical R8 and toolkit')
    if args.min_free_bytes<33554432:parser.error('Do not reduce the operational reserve in this prepared entry')
    args.base,args.main=BASE_SHA,ORIGINAL_MAIN_SHA
    if args.inside_reaper:return inner(args)
    if args.out.exists():parser.error('Fresh output required; never overwrite/retry an existing comparison')
    args.out.mkdir(parents=True)
    env=dict(os.environ,GEO261_REAPER_LOG=str(args.out/'control/reaper.jsonl'),
             GEO323_BASE_SHA=BASE_SHA,GEO323_MAIN_SHA=ORIGINAL_MAIN_SHA)
    recorder=capture.Recorder(args.out/'control/outer-command',args.repo,args.sha,env)
    argv=[sys.executable,'-B',str(HERE/'reap_children.py'),sys.executable,'-B',str(Path(__file__).resolve()),
          '--execute','--inside-reaper','--repo',str(args.repo),'--sha',args.sha,'--reuse',str(args.reuse),
          '--out',str(args.out),'--heavy-lock',str(args.heavy_lock),'--min-free-bytes',str(args.min_free_bytes)]
    if args.exclusive_slot_confirmed:argv.append('--exclusive-slot-confirmed')
    result=recorder.run(argv,cwd=args.repo,read_output=False)
    capture.dump(args.out/'control/receipt.json',{'execution_source_sha':args.sha,'stage':'compare-only',
        'outer_actual_exit':result.returncode,'command':recorder.rows[0],
        'reaper_log':env['GEO261_REAPER_LOG'],'original_R8_rewritten':False,'performance_rerun':False})
    print('New comparison-only outer exit:',result.returncode,flush=True)
    return result.returncode


if __name__=='__main__':
    raise SystemExit(main())
