"""Read completed original comparison evidence only; never launch products or Git."""
from pathlib import Path
import collections
import datetime
import gzip
import hashlib
import json
import sys
import traceback

ROOT = Path('/workspace/geo323-F9-owner-compare-once-20261025-r1')
HERE = Path(__file__).resolve().parent
TOOLKIT = Path('/workspace/geo323-owner-audit-r2-20261025')
F9 = '4f8a794f4167c3562eb182045102e86e9e37cca9'
F8 = '75a1e93811a52b69385cbdaf6a09d773ed9052ad'
BASE = 'b74f9a2ae7ade1555b9be45283adecc097fb76e3'
APPROVAL = '405f8c5e1a637a16cbe47470faf5ae1fa02b8676'
GUARDS = {'app_world_candidate_create', 'app_world_candidate_seal',
          'app_world_candidate_publish', 'app_world_candidate_revalidate', 'reference_check_all'}
EXCEPTIONS = {
    '_role_priority_mutant.scene': (8, 1, '——定位邊 e2 [2000,4000] mm，低端超出 [0,2000] mm'),
    '_s1_p8_l_room_primary_through_reflex_extension.scene': (15, 3, '——定位邊 e3 [3000,4800] mm，低端超出 [27,3000] mm'),
    '_s1_p8b_l_room_primary_through_reflex_extension_hi.scene': (12, 3, '——定位邊 e1 [0,1800] mm，高端超出 [1800,4773] mm'),
}
REPORT = {'schema': 'geo323-owner-comparison-actual-review/1',
          'scope': 'Read only actual completed new comparison, no C/compile/performance rerun',
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'root': str(ROOT), 'execution_source_sha': F9, 'historical_binary_source_sha': F8,
          'host_session_reported_by_root': 97789, 'host_session_independently_polled': False,
          'checks': 0, 'failures': [], 'pins': [], 'new_product_execution_by_reviewer': False}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def must(value, label):
    REPORT['checks'] += 1
    if not value:
        raise RuntimeError(label)


def raw(path):
    return Path(path).read_bytes()


def value(path):
    return json.loads(raw(path))


def pin(path):
    body = raw(path)
    item = {'path': str(path), 'bytes': len(body), 'sha256': sha(body)}
    REPORT['pins'].append(item)
    return item


def check_command(row):
    directory = Path(row['directory'])
    must(directory.is_relative_to(ROOT), 'Command record outside this invocation')
    result = value(directory/'result.json')
    request = value(directory/'request.json')
    must(result == row, 'commands.json and per-command actual result differ')
    must(all(row.get(k) == v for k, v in request.items()), 'Original request/result changed')
    must(type(row['actual_process_returncode']) is int and row['actual_process_returncode'] == 0,
         'Original command actual exit is not zero')
    must(row['recording_complete'] is True and row['original_process_completed'] is True
         and row['timeout_expired'] is False and row['original_exception_type'] is None,
         'Incomplete/timeout/exception original command')
    streams = {}
    for channel in ('stdout', 'stderr'):
        body = raw(directory/(channel+'.bin'))
        must(row[channel+'_available_from_original'] is True
             and row[channel+'_representation'] == 'original-exposed-bytes', 'Non-original command stream')
        must(len(body) == row[channel+'_bytes'] and sha(body) == row[channel+'_sha256'],
             'Original command raw stream/hash mismatch')
        streams[channel] = body
    stdin = raw(directory/'stdin.bin') if row['stdin_provided'] else b''
    must(sha(stdin) == row['stdin_sha256'], 'Original command stdin hash mismatch')
    return stdin, streams


def verify_insertion(name, path, channel, before, after):
    must(name in EXCEPTIONS, 'Fourth unapproved actual differing scene: '+name)
    line, timber, suffix_text = EXCEPTIONS[name]
    error = ('V_EXTENSION：非 boundary 角材（%d）的 footprint 超出定位邊範圍' % timber).encode()
    suffix = suffix_text.encode()
    if channel == 'stdout':
        prefix = b'{"ok":false,"error":"line '+str(line).encode()+b': '+error
        anchor = prefix + b'","status":"INVALID","code":"SCENE_INVALID"}\n'
        must(before.startswith(anchor), 'Exact raw stdout original first line changed')
    else:
        prefix = path.encode()+b':'+str(line).encode()+b': '+error
        anchor = prefix+b'\n'
        must(before == anchor, 'Exact raw stderr original anchor/LF changed')
    must(before.count(anchor) == 1 and suffix not in before, 'Original diagnostic not unique')
    offset = len(prefix)
    must(after == before[:offset]+suffix+before[offset:] and after.count(suffix) == 1,
         'Insertion changed other bytes/offset/count')
    return {'scene': name, 'channel': channel, 'offset': offset, 'suffix_utf8': suffix_text,
            'suffix_hex': suffix.hex(), 'inserted_bytes': len(suffix), 'approval_sha': APPROVAL}


def run():
    # This refuses incomplete evidence; no waiting or retry loop and no product invocation.
    control = value(ROOT/'control/receipt.json')
    receipt = value(ROOT/'receipt.json')
    eq = value(ROOT/'evidence/equivalence.json')
    audit = value(ROOT/'evidence/owner-exact-audit.json')
    before, after = value(ROOT/'REUSE_BEFORE.json'), value(ROOT/'REUSE_AFTER.json')
    must(control['outer_actual_exit'] == 0 and receipt['wrapper_exit'] == 0, 'Original new outer not zero')
    must(control['execution_source_sha'] == F9 and receipt['source_sha'] == F9, 'Execution SHA mismatch')
    must(set(receipt['stages']) == {'compare'}, 'Unexpected stage/performance rerun')
    stage = receipt['stages']['compare']
    must(stage['execution_exit'] == 0 and stage['errors'] == [] and stage['ended_utc'], 'Compare stage not terminal zero')
    expected_state = {'head': F9, 'status': ''}
    must(stage['source_before'] == stage['source_after'] == expected_state, 'Source HEAD/clean changed')
    must(receipt['original_judges_modified'] is True, 'Judge change hidden')
    must(receipt['all_required_stages_completed'] is False and receipt['full_acceptance_passed'] is None,
         'Single comparison misrepresented as full acceptance')
    must(receipt['quantitative_targets'] == {}, 'New performance targets unexpectedly populated')
    must(control['performance_rerun'] is False and control['original_R8_rewritten'] is False,
         'Scope metadata wrong')
    must(before == after == receipt['reused_binary_identity'], 'Reuse identities changed in before/after/receipt')
    must(before['execution_source_sha'] == F9 and before['historical_binary_fix_source_sha'] == F8,
         'Execution source and old binary build source conflated')
    must(before['source_closure_equal'] is True and before['old_closure'] == before['execution_closure'],
         'C source closure mismatch')
    must(len(before['old_closure']) == 185 and sum(x['bytes'] for x in before['old_closure'].values()) == 2142456,
         'Unexpected pinned quoted-include closure')
    for key in ['old_git_index', 'execution_git_index']:
        item=before[key];body=raw(item['path'])
        must(len(body)==item['bytes'] and sha(body)==item['sha256'], 'Current Git index differs from execution before/after')
    for label,item in before['binaries'].items():
        body=raw(item['path'])
        must(body.startswith(b'\x7fELF') and len(body)==item['bytes'] and sha(body)==item['sha256'], 'Reused ELF changed')
        must((ROOT/'work'/label/'bridge').is_symlink()
             and (ROOT/'work'/label/'bridge').resolve()==Path(item['path']).resolve(), 'ELF link identity mismatch')
    must(set(before['binaries']) == {'base','fix','base-trace','fix-trace'}, 'Wrong four ELF roles')
    for item in before['fixtures']:
        body=raw(item['path'])
        must(len(body)==item['bytes'] and sha(body)==item['sha256'], 'Actual source fixture changed')
    must(len(before['fixtures']) == 175, 'Wrong fixture count')
    original_summary=Path('/tmp/geo323-r8-terminal-summary-20261025/SUMMARY.json')
    must(pin(original_summary)['sha256']=='23c0b08133a48285bb7fd75192a9b05a2fb190fa04ca5dc5cadfb28e28a4e5dd',
         'Historical R8 terminal summary changed')
    old=value(original_summary)
    for item in old['original_file_bindings'].values():
        body=raw(item['path'])
        must(len(body)==item['bytes'] and sha(body)==item['sha256'], 'Original R8 receipt/performance/profile/equivalence/terminal changed')
    old_receipt=value('/tmp/g337323R8/receipt.json')
    must(old_receipt['wrapper_exit']==1 and 'ABC_result' not in old_receipt, 'Original R8 red/absent ABC result rewritten')
    must(not any((ROOT/'evidence'/p).exists() for p in ['performance.json','profile-counts.json','performance-stdout']),
         'New performance artifacts appeared')
    for name,expected in receipt['tool_hashes'].items():
        must(sha(raw(ROOT/'tools-frozen'/name))==expected==sha(raw(TOOLKIT/'tools'/name)), 'Frozen toolkit mismatch: '+name)
    must(receipt['tool_hashes']['run_compare_once.py']=='f83911aa796a83bc1d6de00b9811af2cf63ed51d72f76f79a9c99f8b3243101c',
         'Actual entry is not independently reviewed candidate')

    inventory=value(ROOT/'evidence/scene-inventory.json')
    must(sha(raw(ROOT/'evidence/scene-inventory.json'))=='f70496207d882e4a52ab9d5ebc888ff4359569b1bd35c36e2bade3f377783e8c',
         'Original 171+4 inventory changed')
    entries=inventory['scenes']
    names=sorted(x['name'] for x in entries if 'generated_n' not in x)+sorted(x['name'] for x in entries if 'generated_n' in x)
    must(len(names)==len(set(names))==175 and inventory['root_count']==171 and inventory['generated_count']==4,
         'Inventory not 175 unique original scenes')
    must(eq['scenes']==175 and len(eq['runs'])==350 and eq['failures']==[], 'Incomplete/red front comparison')
    must(eq['policy_scope']=='Q-323-ABC-175-scenes' and eq['approval_sha']==APPROVAL, 'Wrong policy approval/scope')
    wanted=[(name,role) for name in names for role in ('base','fix')]
    must([(x['scene'],x['version']) for x in eq['runs']]==wanted, 'Missing/duplicate/reordered scene/version role')
    observations=[]; pairs={}; row_map={}; raw_totals=collections.Counter()
    repo=Path(receipt['source_repo'])
    for row in eq['runs']:
        name,role=row['scene'],row['version'];generated=name in ['s16.scene','s32.scene','s48.scene','s64.scene']
        path=ROOT/'evidence/scenes'/name if generated else repo/name
        must(row['path']==str(path) and row['command']=='loadfile '+str(path)+'\ndump\n', 'Loadfile/dump command changed')
        fixture=next(x for x in entries if x['name']==name);body=raw(path)
        must(len(body)==fixture['bytes'] and sha(body)==fixture['sha256'], 'Executed fixture bytes changed')
        streams={}
        for channel in ('stdout','stderr'):
            body=raw(ROOT/'evidence/stdout'/role/(name+'.'+channel))
            must(len(body)==row[channel+'_bytes'] and sha(body)==row[channel+'_sha256'], 'Full comparison stream/hash mismatch')
            streams[channel]=body;raw_totals[channel]+=len(body)
        zipped=raw(ROOT/'evidence/graphs'/role/(name+'.bin.gz'));graph=gzip.decompress(zipped)
        must(len(graph)==row['graph_bytes'] and sha(graph)==row['graph_sha256'], 'Full decompressed ordered graph/hash mismatch')
        raw_totals['graph']+=len(graph);raw_totals['compressed_graph']+=len(zipped)
        must(set(row['guards'])==GUARDS and all(type(v) is int and v>=0 for v in row['guards'].values()), 'Guard shape/types changed')
        must(type(row['exit']) is int and row['exit']==0 and type(row['trace_exit']) is int and row['trace_exit']==0, 'Nonzero process/trace rc')
        pairs.setdefault(name,{})[role]={**streams,'graph':graph,'guards':row['guards']}
        row_map[(name,role)]=row
        observations.append({'scene':name,'version':role,'stdout_sha256':sha(streams['stdout']),
                             'stderr_sha256':sha(streams['stderr']),'graph_sha256':sha(graph),
                             'compressed_graph_sha256':sha(zipped)})
    insertions=[];differing_scenes=[]
    for name in names:
        b,f=pairs[name]['base'],pairs[name]['fix']
        must(b['graph']==f['graph'], 'Full base/fix ordered graph differs: '+name)
        must(b['guards']==f['guards'], 'Five guard values differ: '+name)
        different=False
        for channel in ('stdout','stderr'):
            if b[channel]!=f[channel]:
                different=True
                insertions.append(verify_insertion(name,row_map[(name,'base')]['path'],channel,b[channel],f[channel]))
        if different:differing_scenes.append(name)
    must(set(differing_scenes)==set(EXCEPTIONS) and len(insertions)==6, 'Actual differing corpus does not match exactly three names/six channel insertions')
    must(insertions==eq['authorized_insertions']==audit['authorized_insertions_recomputed'], 'Front/independent/post-audit insertion lists differ')
    must(audit['observations']==observations and audit['audit_exit']==0 and audit['failures']==[], 'Post-audit raw observations/result mismatch')
    must(audit['scenes']==175 and audit['runs']==350 and audit['execution_source_sha']==F9
         and audit['historical_base_sha']==BASE, 'Post-audit scope/source mismatch')
    must(audit['equivalence_raw_sha256']==sha(raw(ROOT/'evidence/equivalence.json'))
         and audit['inventory_raw_sha256']==sha(raw(ROOT/'evidence/scene-inventory.json')), 'Post-audit file pins mismatch')
    must(audit['strict_tuple_equal_without_exceptions'] is False
         and audit['source_graph_and_five_guards_equal'] is True and audit['process_and_trace_exits_zero'] is True,
         'Strict difference or graph/guard/rc result hidden')
    abc=receipt['ABC_result']
    must(abc['comparison_execution_exit']==0 and abc['audit_execution_exit']==0 and abc['scenes']==175 and abc['runs']==350,
         'ABC result not actual comparison and audit zero')
    must(abc['authorized_insertions_recomputed']==insertions and abc['strict_tuple_equal_without_exceptions'] is False,
         'ABC result hides original tuple inequality')

    commands=value(ROOT/'invocation/commands/commands.json')
    product=[];git=[];command_streams={}
    for row in commands:
        stdin,streams=check_command(row)
        must(row['acceptance_sha']==F9, 'Command acceptance SHA mismatch')
        if row['command'][0]=='git':
            must(row['command'][1]=='--no-optional-locks', 'Git may write index')
            git.append(row);continue
        executable=Path(row['command'][0]);label=executable.parent.name
        must(row['command']==[str(ROOT/'work'/label/'bridge')] and label in before['binaries'], 'Unexpected compiler/perf/other command')
        must(row['timeout_seconds']==600, 'Original comparison timeout changed')
        must(row['cwd']==str(repo), 'Product cwd changed')
        base=label.startswith('base');role='base' if base else 'fix';trace=label.endswith('-trace')
        must(row['source_sha']==(BASE if base else F9)
             and row['source_role']['binary_build_sha']==(BASE if base else F8), 'ELF execution/build SHA conflated')
        env=row['environment']
        must(env['PYTHONOPTIMIZE'] is None and env['PYTHONPATH'] is None and env['GITHUB_SHA']==F9
             and env['GEO323_BASE_SHA']==BASE and env['GEO323_MAIN_SHA']=='adbaebf9c73ea6801d7b4d5214e4b846b132923b', 'Unexpected actual environment identity')
        must(env['GEO261_GRAPH']==(str(ROOT/'work'/(role+'-graph.bin')) if trace else None)
             and env['GEO261_GUARDS']==(str(ROOT/'work'/(role+'-guards.txt')) if trace else None),
             'Trace graph/guard output binding changed')
        name=Path(stdin.decode().split('\n')[0][len('loadfile '):]).name
        expected=row_map[(name,role)]
        must(stdin==expected['command'].encode(), 'Actual ELF stdin not full original loadfile+dump')
        must(streams['stdout']==pairs[name][role]['stdout'] and streams['stderr']==pairs[name][role]['stderr'], 'Actual ELF/O2/trace raw output differs from saved observation')
        key=(name,role,trace)
        must(key not in command_streams,'Duplicate actual product invocation')
        command_streams[key]=row['directory'];product.append(row)
    must(len(product)==700 and len(command_streams)==700 and len(git)==12 and len(commands)==712,
         'Expected exactly 350 ordinary plus 350 trace and 12 readonly Git commands')
    must(set(command_streams)=={(n,r,t) for n in names for r in ('base','fix') for t in (False,True)}, 'Actual invocation role coverage incomplete')
    outer_rows=value(ROOT/'control/outer-command/commands.json')
    must(len(outer_rows)==1 and outer_rows[0]==control['command'], 'Outer actual command binding mismatch')
    _,outer_streams=check_command(outer_rows[0])
    must(b'PASS A/B/C: 175 scenes' in outer_streams['stdout'], 'Original outer stdout missing completed comparison')
    reaper=[json.loads(line) for line in (ROOT/'control/reaper.jsonl').read_text().splitlines()]
    REPORT['reaper_actual_events']=reaper
    must(reaper[0]['event']=='啟用子程序回收' and reaper[0]['pr_get_child_subreaper']==1
         and reaper[-1]['event']=='完成' and reaper[-1]['primary_returncode']==0,
         'Original subreaper lacks actual terminal zero')
    must(sum(x.get('primary') is True and x.get('returncode')==0 for x in reaper)==1,
         'Original primary child did not have exactly one reaped zero terminal')
    must(not list(ROOT.rglob('RECORDING_ERRORS.json')), 'Recorder error artifact exists')
    for p in ['receipt.json','control/receipt.json','control/outer-command/commands.json',
              'invocation/commands/commands.json','evidence/equivalence.json','evidence/owner-exact-audit.json',
              'evidence/scene-inventory.json','REUSE_BEFORE.json','REUSE_AFTER.json','control/reaper.jsonl']:
        pin(ROOT/p)
    REPORT.update(actual_new_outer_exit=0,actual_compare_stage_exit=0,actual_post_audit_exit=0,
                  actual_product_invocations=len(product),ordinary_observations=350,trace_observations=350,
                  scene_count=175,readonly_git_commands=len(git),actual_insertions=insertions,
                  observed_raw_bytes=dict(raw_totals),original_R8_outer_exit_unchanged=1,
                  historical_performance_and_profile_hashes_unchanged=True,new_performance_run=False,
                  index_hashes_unchanged={k:before[k] for k in ('old_git_index','execution_git_index')},
                  whole_project_or_full_train_pass_claim=False,
                  limits=['Read-only actual evidence verification, not another product run.',
                          'Connected-account approval is reused from the reviewed pinned toolkit; API not called again.',
                          'Host session 97789 terminal is owned by root; this report verifies captured original inner/reaper outer actual process terminal.',
                          'Trace graph/guard raw observation is retained by original compare; command terminals independently establish trace exit and matching observable streams.',
                          'Original R8 historical outer remains 1; P-189 and performance are outside this new comparison.'])


if __name__=='__main__':
    try:
        run()
    except BaseException as exc:
        REPORT['failures'].append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
        traceback.print_exc()
    REPORT['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    REPORT['exit']=int(bool(REPORT['failures']))
    REPORT['checker_sha256']=sha(raw(__file__))
    dest=HERE/'RESULT.json'
    if dest.exists():
        raise RuntimeError('Never overwrite an existing actual verification result')
    dest.write_text(json.dumps(REPORT,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'exit':REPORT['exit'],'checks':REPORT['checks'],'failures':REPORT['failures'],
                      'result_path':str(dest),'result_sha256':sha(raw(dest))},ensure_ascii=False))
    raise SystemExit(REPORT['exit'])
