本輪新 comparison 收件核對通過：17,231 項檢查／0 錯誤。原 host、wrapper、compare stage、後段 audit 均為 0；主代理 host 原件也已另核，並非由進度推測終態。

F9 執行來源為 `4f8a794f4167c3562eb182045102e86e9e37cca9`；沿用 ELF 的歷史建置來源仍為 F8 `75a1e93811a52b69385cbdaf6a09d773ed9052ad`。前後 reuse binding、185 檔 source closure map、兩份 Git index、4 ELF 與175 fixtures 一致。

175 個唯一場景、350 組 base/fix rows 完整；另獨立讀齊700個實際 O2／trace CLI 的 request、result、stdin、完整 stdout/stderr 與 hash，全部原 rc 0，12個唯讀 Git 命令亦為0。每個 trace 的原 stdout/stderr 與未插樁輸出逐 byte 相同。350 份完整解壓 graph 共47,295,490 bytes，base/fix逐 byte相同；五 guards 的完整 keys／types／values均相同。guards歷史逐次值來自原comparison rows，並不宣稱另保存了每次被覆寫的原 guards.txt。

只有三個已核可完整場景名各有 stdout／stderr 一處精確suffix，共六處；其他bytes均相同。以本次原path重建stderr anchor，保留LF、唯一offset、唯一插入，沒有通用訊息正規化。獨立raw重算名單與前段及後audit完全一致。strict tuple equality仍為false，精確授權差異另列；後audit完成才有新ABC_result。

原R8 receipt、equivalence、36樣本performance、profile及原終態檔均符合既有pin；R8 outer仍是1且原ABC_result缺席。此次沒有性能／profile／編譯／P-189或其他stage重跑，也不宣稱整條列車全綠；`all_required_stages_completed=false`、`full_acceptance_passed=null`。

原完整資料4,645個regular files，19,437,320 bytes（filesystem allocation29,257,728 bytes），另4個指向原ELF的symlink；沒有製作大副本。建議14個出版分包，最大3,518,895 bytes／最多700 leaves，詳見HOST_AND_PACKAGING.json。兩份last graph原raw各3,518,895 bytes、所有350 gzip graph、700 saved streams、712命令收據均保留。分包只是出版安排，不改任何驗收門檻。

本報告為唯讀實際收件驗證，沒有再啟C或產品。獨立對抗審查另行提供；不可用原歷史UNVERIFIED／puretools報告取代本輪actual收據。
