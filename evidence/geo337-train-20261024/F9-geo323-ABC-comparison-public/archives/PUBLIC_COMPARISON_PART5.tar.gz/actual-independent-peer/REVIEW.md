本次已終態 comparison 小型對抗審查：10,144 個核對／0 個阻擋。host、wrapper、compare、後段 audit 原退出碼均為0。175場景（171+4）、350 base/fix列及700個原CLI＋12個唯讀Git收據完整；所有原CLI退出碼與原stdout/stderr/hash已獨立重讀。

六個差異僅為三個具名場景在stdout/stderr各一處核可UTF-8插入，其餘bytes相同；當次stderr path較歷史不同，依當次完整anchor重算offset為140／166／170，不能搬用歷史143／169／173。stderr最後byte為0a。strict tuple equality仍false。

執行來源F9 `4f8a794f4167c3562eb182045102e86e9e37cca9` 與ELF歷史建置來源F8 `75a1e93811a52b69385cbdaf6a09d773ed9052ad` 明列；185檔閉包before/after map與兩份index記錄相同，原12Git輸出確認F8/F9皆clean。第一核對器已全量解壓350graphs並核完整bytes；本peer只核其程式、原結果及graph/audit metadata，沒有再解壓47.3MB或重掃source／ELF／index。五guards是每scene/process總數。

原R8 outer1保留；此次不重跑編譯、性能、profile、P189或其他stage，`all_required_stages_completed=false`、`full_acceptance_passed=null`。本peer亦未執行產品或Git，無大副本。
