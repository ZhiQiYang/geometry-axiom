# 凍結列車計畫的增補與目前真實進度

原計畫 `/tmp/geo337-reading-a-plan-20261024/PLAN.md`，SHA256 `cc3c69a2b7ce344de25703ab56564481f3694530951c113a15c455e30f3b7d77` 保留未覆寫。原獨立靜審181 checks／0 findings，只接受計畫，不代稱 final已跑。本增補保原數值門檻與 #335核可缺口，加入 root 新合流候選與已執行進度；未形成完整列車已全綠的宣稱。

| gate | 真受驗來源／結果 | 限制 |
|---|---|---|
| 三reader | F64；0／0／0，unit Ran51／OK 159.705s；SSOT／generator／HTML／unit原raw hash前後同 | actual peer待；不是後續final整份綠 |
| readingA native | F64；Ran7／OK 7.078s；12組真0／1／0、5positive，baseline/restored binary一致 | 原41子row source_sha=null（本次漏設GITHUB_SHA），原件不填回；parent c387／Git前後F64clean與 sidecar明確綁定，請peer如實審 |
| readingA oracle | F64；Ran14／OK 0.416s，原builder/checker控制保原輸出 | full selftest／quick／528+1056全掃尚未在此新closure跑 |
| F64原architecture | 1／0／5；唯一run_axiom_mutations.py exclusion digest；generic205／product Ran0 | 原紅保留，不能冒已跑18 |
| P17 architecture | 三原0；generic205／product18／0skip；原manifest參數0／1／0；source前後P17clean | seal四檔0、output獨立peer686checks／0；不是全ledger或其餘產品gate |
| 整份123ledger | 純AST123唯一IDs；原 --check及完整重產尚未執行 | root最後唯一writer，不計equivalent為killed |

目前完整證據路徑及四檔 hashes在 `LINUX_LEDGER_ORIGINAL_TOOL_PLAN.md`。native首次準備誤填retainer完整hash，preflight1且未啟test，原工具exec transcript provenance保 `/tmp/train337-reading-a-native-f64d638f/PREPARATION_FAILURE.json`；r2核真5dfe原bytes後7方法通過，未覆原失敗。正式 final 入口必須明設GITHUB_SHA／GITHUB_WORKSPACE。

## #324 closure 必須加回原全清單

owner新公開S=`f1217b0fa5e933e14906833bf4981dad97061b04`，ordinary merge train F64後，相對train仍恰3檔：W `geometry_woodworking/model_sources.py`、`tests/test_geometry_host_sources.py`、expected該key39→45。根據owner回報，產品與host test保原Grokbytes，其他JSON／SSOT／queue保train原件。root是否採納及最後來源另定；不能把舊3cb／F64 native綠套在改過的W Python closure。

必跑原完整 `ulimit -s 16384` 後 `python3 tests/run_all.py --build`（含 full compare_expected／registry）；`run_all.py --list`只是登記清點，不替代真45方法執行。原六browser workflow／deadline保留。importer前置候選 host_sources／source_runtime／default_native／kernel_runtime／rectangular_python、host_native／host_world／kernel_compatibility／domain_source_pins需依最後來源核定，不能拿此候選名單當全部已閉合。

三個新增 predicate各用原method做0／1／0：owner凍結外部 v2 `/tmp/geo324-owner-20261024/preparation-v2/FROZEN_MANIFEST.json`，SHA256 `d38dd52fe3f343ac90dae883c2efbf195409bdf7c42c25e03cb5b06dbbc4ffb6`，schema `geo324.original-predicate-proofs.v2`。sourceSHA／tools／trackedInputs／各phase commandResult／originalExitCodes／byteRestored必須綁 root最後採納來源。v2目前僅靜審／AST，不是實跑；原argv按其README，保原閾值與assert，不自行複製較舊source。

## 無木工模板閉包與原七phase

noWood原S=`9b201164ed31069843a2b9f3787ea8ae8e22e231`，尚未合 root337／newmain；原13methods與7phase全未跑。不能逆向merge後項進318或提前冒採納。原request `/workspace/kernel-no-wood-prep/NO_WOOD_FORMAL_REQUEST.json`；原入口形狀：

```text
env -u PYTHONOPTIMIZE python3 -B /workspace/kernel-no-wood-prep/run_proof.py --git-dir /workspace/kernel-no-wood-prep/metadata.git --sha ACTUAL_ADOPTED_FINAL_SHA --out FRESH_OUTPUT --heavy-lock /tmp/g261r3/heavy.lock
```

務必重綁 actual採納SHA與精確11source／expected13，不直接跑舊S冒新final。原collector自帶R3 EX／NB，忙75保原，不拔鎖。七phase預期0／1／0／1／0／1／0：baseline全13、import撤回／還原、K→template guard撤回／還原、angle parser撤回／還原。核心K＋矩形模板真的編譯執行，禁止W及H import；K加一行真W include要紅，原parser角括號負控也保留。

## 排程與尚未執行

本代理slot1已released給323，source snapshot唯一owner交還323；不再動其HEAD。323 perf/profile獨占期間僅小文字／metadata，不開quick、Q38、fullledger、新clone、browser或大型hash。舊deadline／P189≤2基底3e6／323≤1.3基底b74均原樣。最後 native＋六browser＋P52／P189／Q38／§7／quick／528+1056／ledger／所有必要新closure仍由root在正式final統排，不能用本增補或source靜核補成綠。
