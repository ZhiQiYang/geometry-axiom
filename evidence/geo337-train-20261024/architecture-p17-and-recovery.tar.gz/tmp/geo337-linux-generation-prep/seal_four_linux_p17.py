#!/usr/bin/env python3
"""封存 P17 真原裁判為 Linux 架構四檔；不寫產品、不重測原裁判。"""
from __future__ import annotations
import argparse
import collections
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import traceback

P = '17b3576434ffd0833056668898e1fd1a8cc2d560'
ART = 'geometry-core/domain-decoupling'
FILES = ('product-architecture.json', 'product-architecture-scan.json', 'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json')
TOOLS = ('tests/architecture_contract.py', 'tests/test_architecture_contract.py', 'tests/test_product_architecture.py')
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_HASH = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
MANIFEST_HASH = '80f44b8c870e097413e395d30ba029199ba66b7302985c0f325d4f446d0ce525'
WITHDRAWN_HASH = 'd787df610824282c305a616731759d900f81619b68419c04d63e66bf04402499'
SUFFIXES = {'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def lf(raw): return raw.replace(b'\r\n', b'\n')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path, data): path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def require(ok, text):
    if not ok: raise RuntimeError(text)
def info(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'rawSha256':sha(raw),'lfSha256':sha(lf(raw))}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    require(args.sha==P, '此工具只接受已採納 manifest 的 P17，不能重標來源')
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0'), '原 assertions 必須開啟')
    repo, evidence, out=args.repo.resolve(),args.evidence.resolve(),args.out.resolve()
    require(repo.is_dir() and evidence.is_dir() and not out.exists(), 'repo/evidence 必須存在，out 必須全新')
    require(not out.is_relative_to(repo) and not repo.is_relative_to(out) and not out.is_relative_to(evidence), 'out 只能在 source/evidence 外')
    require(sha(CAPTURE.read_bytes())==CAPTURE_HASH, '原 c387 recorder bytes 不符')
    out.mkdir(parents=True); (out/'new').mkdir(); (out/'previous').mkdir(); (out/'tools').mkdir()
    tool=Path(__file__).resolve(); tool_before=info(tool)
    (out/'tools'/tool.name).write_bytes(tool.read_bytes()); (out/'tools'/'capture.py').write_bytes(CAPTURE.read_bytes())
    spec=importlib.util.spec_from_file_location('original_c387',CAPTURE); cap=importlib.util.module_from_spec(spec); spec.loader.exec_module(cap)
    env=dict(os.environ); cleared=[k for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP') if k in env]
    for key in cleared: env.pop(key)
    env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONIOENCODING='utf-8')
    rec=cap.Recorder(out,env,P)
    def git(*argv,data=None):
        row,stdout,stderr=rec.run(['git',*argv],cwd=repo,data=data,timeout=None,check=False,source_variant='P17-four-artifact-source-identity')
        require(row['actual_process_returncode']==0,'Git failed: '+str(argv))
        return stdout
    started=now(); initial_index=None; original_four={}; initial_inputs=None
    try:
        require(git('rev-parse','HEAD').decode().strip()==P,'source HEAD不是P17')
        require(git('status','--porcelain=v1','--untracked-files=all')==b'','source必須clean')
        initial_index=git('ls-files','--stage','-z')
        source_summary=json.loads((evidence/'SUMMARY.json').read_bytes())
        require(source_summary['sha']==P and [x['exit'] for x in source_summary['gates']]==[0,0,0], '原三判官必須真P17／三0')
        require([x['exit'] for x in source_summary['manifestProof']]==[0,1,0], 'manifest原反證必須0/1/0')
        all_rows=json.loads((evidence/'subcommands.json').read_bytes()); by_dir={x['directory']:x for x in all_rows}
        preserved=[]
        def checked_row(reference):
            directory=Path(reference['directory']).resolve()
            require(directory.is_relative_to(evidence/'subcommands'),'只接受同份原capture目錄')
            row=json.loads((directory/'result.json').read_bytes())
            require(row==by_dir[str(directory)] and row['actual_process_returncode']==reference['exit'] and row['source_sha']==P,'原row／來源／exit不符')
            require(not row.get('timeout_expired') and 'exception' not in row,'不能以timeout/exception當真裁判')
            for stream in ('stdin','stdout','stderr'):
                require(sha((directory/(stream+'.bin')).read_bytes())==row[stream+'_sha256'],'原stream hash不符')
            preserved.append({'directory':str(directory),'resultSha256':sha((directory/'result.json').read_bytes()),'command':row['command'],'actualExit':row['actual_process_returncode']})
            return row,(directory/'stdout.bin').read_bytes(),(directory/'stderr.bin').read_bytes()
        results=[checked_row(x) for x in source_summary['gates']]
        expected_suffixes=[['-B',TOOLS[0],'--root','.','--manifest',ART+'/'+FILES[0]],['-B',TOOLS[1]],['-B',TOOLS[2]]]
        for result,suffix in zip(results,expected_suffixes):
            require(result[0]['command'][1:]==suffix and Path(result[0]['cwd']).resolve()==repo,'原裁判argv/cwd有改')
        baseline,withdrawn,restored=[checked_row(x) for x in source_summary['manifestProof']]
        require(baseline[0]==results[0][0] and restored[0]['command']==baseline[0]['command'],'0/1/0原判官身份不同')
        old_manifest=evidence/'withdrawn-product-architecture.json'
        require(sha(old_manifest.read_bytes())==WITHDRAWN_HASH and source_summary['withdrawnManifestRawSha256']==WITHDRAWN_HASH,'撤回manifest不是原F64 bytes')
        require(withdrawn[0]['command'][1:]==['-B',TOOLS[0],'--root','.','--manifest',str(old_manifest)],'撤回只准改manifest參數')
        require(restored[1]==baseline[1], '還原scanner完整stdout與baseline不同')
        diagnostics=json.loads(withdrawn[1])['diagnostics']
        require(len(diagnostics)==1 and diagnostics[0]['code']=='EXCLUSION_DIGEST' and diagnostics[0]['path']=='geometry-core/card-reference/run_axiom_mutations.py','撤回紅不是唯一指定digest')
        scan=json.loads(results[0][1]); require(scan['ok'] is True and scan['diagnostics']==[],'原scan未通過')
        for name in FILES:
            original_four[name]=(repo/ART/name).read_bytes(); (out/'previous'/name).write_bytes(original_four[name])
        require(sha(original_four[FILES[0]])==MANIFEST_HASH,'P17原manifest hash不符')
        manifest=json.loads(original_four[FILES[0]])
        require((len(manifest['sources']),len(manifest['exclusions']))==(334,270),'完整分類數不同')
        require((len(manifest['policy']['forbiddenIdentifiers']),len(manifest['policy']['forbiddenStrings']))==(928,55),'原政策不同')
        declared=sorted(x['path'] for x in manifest['sources']+manifest['exclusions'])
        roots=manifest['sourceRoots']; standalone=manifest['sourceFiles']
        require(roots==['geometry-core','geometry-app','geometry-templates','geometry-web','geometry-guide'] and standalone==['current_geometry.c','tests/__init__.py','tests/binaries.py'],'完整範圍不同')
        def snapshot():
            paths=set(standalone)
            for relative in roots:
                directory=repo/relative; require(directory.is_dir() and not directory.is_symlink(),'source root缺失/別名')
                for parent,dirs,files in os.walk(directory,followlinks=False):
                    require(all(not (Path(parent)/name).is_symlink() for name in dirs),'source directory symlink')
                    for name in files:
                        path=Path(parent)/name
                        if path.suffix.lower() in SUFFIXES:
                            require(path.is_file() and not path.is_symlink(),'非一般source')
                            paths.add(path.relative_to(repo).as_posix())
            require(sorted(paths)==declared and len(paths)==604 and len({p.casefold() for p in paths})==604,'完整inventory不符')
            return [{'path':p,**info(repo/p)} for p in declared]
        initial_inputs=snapshot()
        tracked=git('ls-tree','-r','-z','--name-only',P,'--',*roots,*standalone)
        require(sorted(p for p in tracked.decode().split('\0') if p and Path(p).suffix.lower() in SUFFIXES)==declared,'完整Git tree inventory不符')
        raw=git('cat-file','--batch',data=b''.join((P+':'+p+'\n').encode() for p in declared)); cursor=0
        frozen=[]
        for item in initial_inputs:
            end=raw.index(b'\n',cursor); header=raw[cursor:end].split(); size=int(header[2]); begin=end+1
            require(header[1]==b'blob' and raw[begin+size:begin+size+1]==b'\n' and sha(lf(raw[begin:begin+size]))==item['lfSha256'],'source不是精確Git blob：'+item['path'])
            frozen.append({**item,'gitBlobOid':header[0].decode()}); cursor=begin+size+1
        require(cursor==len(raw),'Git batch多餘尾bytes')
        tools={p:info(repo/p) for p in TOOLS}
        for p in TOOLS: require((repo/p).read_bytes()==git('show',P+':'+p),'原裁判bytes不符Git')
        validations=[]
        for index,(row,stdout,stderr) in enumerate(results[1:]):
            text=(stdout+b'\n'+stderr).decode('utf-8','replace'); found=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M)
            require(len(found)==1 and int(found[0][0])==[205,18][index] and text.rstrip().endswith('OK'),'原方法數/無skip/OK不符')
            validations.append({**row,'command':'python -B '+TOOLS[index+1],'exitCode':0,'tests':int(found[0][0]),'passed':int(found[0][0]),'failed':0,'skipped':0,'unittestSeconds':float(found[0][1])})
        inputs=[{'path':x['path'],'sha256':x['lfSha256']} for x in initial_inputs]
        closure=sha(json.dumps(inputs,ensure_ascii=False,separators=(',',':')).encode())
        counts={'executableFiles':604,'ownedSources':334,'exclusions':270,'edges':len(scan['edges']),'diagnostics':0,'layers':dict(sorted(collections.Counter(x['layer'] for x in manifest['sources']).items())),'languages':dict(sorted(collections.Counter(x['language'] for x in manifest['sources']).items())),'forbiddenIdentifiers':928,'forbiddenStrings':55}
        (out/'new'/FILES[0]).write_bytes(original_four[FILES[0]]); (out/'new'/FILES[1]).write_bytes(results[0][1])
        report=f'# Product architecture — Linux 固定來源重產\n\n真原三裁判均在乾淨 Git HEAD `{P}` 執行，退出0/0/0；generic205與product18方法，無skip。原manifest逐bytes不變，928/55政策保留。完整604inputs、334owned／270excluded，原scanner記{counts["edges"]}edges、0diagnostics。LF closure `{closure}`。\n\n具名digest反證：同一P產品及原scanner，正常manifest0、repo外F64舊manifest1、現P manifest恢復0；唯一紅是run_axiom_mutations.py的EXCLUSION_DIGEST。未暫改原source或judge，不冒為產品語意突變。\n\n四檔是非執行性衍生產物，receipt不hash自己。F64舊1/0/5另留歷史原件；本輪不冒native、ledger、browser、readingA或Windows supplemental已驗。先前報告保留如下歷史角色。\n\n'+lf(original_four[FILES[2]]).decode()
        (out/'new'/FILES[2]).write_text(report,encoding='utf-8')
        receipt={'schema':'geometry-product-architecture-receipt/1','headBinding':'三原裁判實際在P17乾淨Git source執行；本工具只讀來源，四產物寫repo外；HEAD/index/604raw-LF inputs前後不變。','hashMode':'sha256 after CRLF-to-LF normalization','inputClosureHashSerialization':'SHA-256 of UTF-8 JSON for the path-sorted inputs array, with ensure_ascii=false and separators=(comma,colon); each entry has path then sha256, and no trailing newline.','inputClosureExcludes':[ART+'/'+n for n in FILES],'inputClosureExclusionReason':'非執行性衍生產物；receipt不hash自身。','notClaimed':['native','ledger','browser','readingA dynamic','Windows supplemental probes','new W lexicon completeness audit'],'createdUtc':now(),'basis':'同P17真三裁判raw、原manifest、完整物理/Git/blob inventory，具名manifest0/1/0。','sourceBaseHead':P,'headObservedBefore':P,'headObservedAfter':P,'manifestSha256':sha(lf(original_four[FILES[0]])),'scannerSha256':tools[TOOLS[0]]['lfSha256'],'scanSha256':sha(lf(results[0][1])),'reportSha256':sha(lf((out/'new'/FILES[2]).read_bytes())),'inputClosureSha256':closure,'counts':counts,'scanPassed':True,'actualCliScan':{**results[0][0],'exitCode':0},'validation':validations,'inputs':inputs,'manifestRefresh':{'manifestByteUnchanged':True,'allPolicyFieldsEqual':True,'sourceClassificationsUnchanged':True,'previousOutputs':{n:info(out/'previous'/n) for n in FILES},'sourceReceiptEvidenceDirectory':str(evidence),'originalThreeGateExits':[0,0,0],'manifestProof':source_summary['manifestProof'],'originalReceiptRawRows':preserved,'note':'current P17 manifest已由root採納；舊F64stale1/0/5不是本P前置判決。'},'completeInventoryVerification':{'sourceRoots':roots,'sourceFiles':standalone,'filesBefore':604,'filesAfter':604,'allRawAndLfInputsUnchanged':True,'toolHashesBefore':{p:x['lfSha256'] for p,x in tools.items()},'toolHashesAfter':{p:x['lfSha256'] for p,x in tools.items()},'inputClosureSha256Before':closure,'inputClosureSha256After':closure},'supplementalStaticGuardProbes':{'executedAtCurrentHead':False,'legacyWindowsSupplementalExecuted':False},'nativeAcceptance':'另取原收據，本四檔不代稱產品native綠。','refreshDriver':{**tool_before,'path':str(tool),'argv':sys.argv,'recorderSha256':CAPTURE_HASH,'runDirectory':str(out)},'environment':{'safeVariables':{k:env.get(k) for k in ('PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','PYTHONOPTIMIZE','TMPDIR')},'clearedInheritedEnvironmentNames':cleared,'python':sys.version},'uncertainties':['本輪不以manifest digest修復代稱928/55新W詞彙盤點。','未由root提交推送前，本四檔不是已發布驗收；後續正式final要重新綁定。']}
        save(out/'new'/FILES[3],receipt); save(out/'source-inputs.json',frozen)
        require(snapshot()==initial_inputs,'raw/LF input在seal期間變動')
        require(all(info(repo/p)==tools[p] for p in TOOLS),'judge在seal期間改變')
        require(all((repo/ART/n).read_bytes()==original_four[n] for n in FILES),'原四檔在seal期間改變')
        require(git('rev-parse','HEAD').decode().strip()==P and git('status','--porcelain=v1','--untracked-files=all')==b'' and git('ls-files','--stage','-z')==initial_index,'source HEAD/clean/index變動')
        require(info(tool)==tool_before and sha(CAPTURE.read_bytes())==CAPTURE_HASH,'工具在seal期間改變')
        result={'schema':'geo337.linux-architecture-four-artifacts/1','sourceSha':P,'startedUtc':started,'endedUtc':now(),'passed':True,'originalGateExits':[0,0,0],'manifestProofExits':[0,1,0],'outputs':{n:info(out/'new'/n) for n in FILES},'counts':counts,'inputClosureSha256':closure,'sourceCheckoutModified':False}
        save(out/'RESULT.json',result); print(json.dumps(result,ensure_ascii=False),flush=True); return 0
    except BaseException as error:
        guards=[]
        for name,args2 in [('head',['rev-parse','HEAD']),('status',['status','--porcelain=v1','--untracked-files=all']),('index',['ls-files','--stage','-z'])]:
            try:
                data=git(*args2); expected=P.encode()+b'\n' if name=='head' else (b'' if name=='status' else initial_index)
                guards.append({'name':name,'matchesBefore':expected is not None and data==expected})
            except BaseException as guard_error: guards.append({'name':name,'error':str(guard_error)})
        save(out/'FAILED.json',{'sourceSha':P,'passed':False,'startedUtc':started,'endedUtc':now(),'errorType':type(error).__name__,'error':str(error),'postFailureGuards':guards,'sourceCheckoutWrittenByTool':False})
        traceback.print_exc(); return 130 if isinstance(error,KeyboardInterrupt) else 1

if __name__=='__main__': raise SystemExit(main())
