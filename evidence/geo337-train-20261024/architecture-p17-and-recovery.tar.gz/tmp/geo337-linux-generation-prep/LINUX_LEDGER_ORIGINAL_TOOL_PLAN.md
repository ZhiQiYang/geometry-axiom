# Linux 架構與原 123 帳本執行方案

此文件是執行／交接方案，不是全帳本通過收據。原來源 F64 為 `f64d638f15c48d2b9723b7ae9d230fb5dacb82d9`；root 採用具名 digest 修復的 P17 為 `17b3576434ffd0833056668898e1fd1a8cc2d560`。P17 相對 F64 只有 manifest 與 evidence；C／產品測試原 bytes 未變。之後 root 若合入 #324 等，以下所有來源身份、輸入清單與原裁判需綁實際新 closure，不能用本文件固定 P17 冒新 F。

## 本輪已完成的 Linux 四檔

F64 三原裁判真退出 1／0／5，唯一 `EXCLUSION_DIGEST` 是 `geometry-core/card-reference/run_axiom_mutations.py`。通用判官 Ran205／OK；產品判官 setUpClass 拒絕，Ran0，不能計作已跑18。完整原件 `/tmp/train337-architecture-original-f64d638f/` 保留。

root 採納一個精確既有 hash 更新後，本代理在同一乾淨 checkout 普通切到 P17，再跑三條原命令，真退出 0／0／0（generic205、product18、皆無 skip）。沒有新 checkout 或外部非 Git 產品樹。具名反證只用 repo 外舊 manifest 作 `--manifest` 參數：原 P17 0 → 舊 manifest 1 → P17 0。唯一紅同上，baseline/restored 原 scanner stdout 逐 bytes 相等。來源與原裁判未暫改。

原命令與全 raw：`/workspace/train337-architecture-original-17b35764/`。四檔候選：`/workspace/train337-architecture-four-17b35764/new/`；outer 原命令／exit／streams：`/workspace/train337-architecture-four-17b35764-outer/`。seal 真退出0，只讀604個 input，無重測。

| 產物 | SHA256（raw＝LF） |
|---|---|
| product-architecture.json | `80f44b8c870e097413e395d30ba029199ba66b7302985c0f325d4f446d0ce525` |
| product-architecture-scan.json | `18f24f186445928e79159bbd49dc10b586a42ab17ded1cf15f2608de4354a728` |
| PRODUCT-ARCHITECTURE.md | `032df92c593226e2777c3f079a1710424e67f79fce108e483acc06059b65a32e` |
| product-architecture-receipt.json | `753b7af3948ec29c878d8291f1527bdc0fd7281522cec7a2d6b976a50577fbb8` |

完整五 roots＋三 standalone 為604 input／334 owned／270具名 excluded，798 edges、0 diagnostics；H192／K69／W67／vendor6。現有928 identifiers／55 strings guards全部保留。LF input closure `6e1a994abaddec0ee851b96184a173548ac81b54ea37f7f7725e3066c7a6f338`。原 manifest逐 bytes不變；receipt不 hash自己，四檔不進 executable closure。本輪未把單一 digest 修復稱為全新 W 詞彙盤點，也沒有 Windows supplemental 宣稱。

seal 原工具 `/tmp/geo337-linux-generation-prep/seal_four_linux_p17.py`，SHA256 `0b0aed4ad4a7316606730fa455ac96196f2a22ad67a3e09d3c053e4b1fb659be`；靜審56 checks／0 findings（`/tmp/train337-adversarial/ARCHITECTURE_P17_SEAL_STATIC_PEER.json`）。實物 output peer 686 checks／exit0，報告 `/tmp/train337-adversarial/ARCHITECTURE_P17_FOUR_ACTUAL_PEER.json`，SHA256 `64d42a3e8df83c129fbfc2c98ef982f32ed545401cdc624462494adf3f91ee21`。root 是唯一採納／提交／發布者。舊 F64 外部 validation tree driver 是未執行草稿，`DRAFT_ROLE.json` 明列，不能當本輪執行工具。

## 原 123 帳本 CLI 與執行方式

本次對 F64 的 `tests/mutate.py` 只作 AST census：123個唯一 ID，沒有執行或產新 verdict。已登記 equivalent 有 M09／M23／M56／M36／M110；equivalent不能計 killed。最後 actual census／verdict一律以原工具為準，不能按這個準備摘要手填。

先在 root 固定、已提交來源 checkout 執行原檢查，保 exit／完整 raw：

```text
python3 -B tests/mutate.py --check
```

root 統一最後完整重產一次的原入口是沒有 mutant ID／沒有額外旗標的：

```text
python3 -B tests/mutate.py
```

沒有 `--all` 或 `--force` 這類自創 CLI。`MUTATE_CACHE` 指全新或原工具合法 fingerprint cache；`MUTATE_RESULTS` 指 repo 外獨立 results JSON，保存舊 ledger bytes，產物採納由 root 做。若要檢查 repo 外新檔，使用同一個 `MUTATE_RESULTS` 環境再跑原 `--check`。不關 assertions、不改 RUN_RETRIES／timeout／killed判準，不刪 equivalent或既有 records。

每次正式命令明填 `GITHUB_SHA=<actual committed source>`、`GITHUB_WORKSPACE=<source checkout>`，保 PATH、TMPDIR、CC／compiler flags、Python／cc版本、工具 hash、source closure、binary／fingerprint sidecars、原 compile/run stdin/stdout/stderr。原 child 僅存 hash 的地方，由指定 ledger observer owner加被動原 stream保全；本代理不另寫或併行執行 observer／帳本。

core 與 bridge 原工具可能共用 cache，不開第二個 writer。已編譯 cache只有原 fingerprint／exe hash一致才可命中；不把 cache sidecar存在當實際 assertion已執行。blocked／crashed／survived原分類保留，不把異常結束碼當 assertion killed。

## 防止 bridge 自動簽出歷史 GiB

原 `tests/mutation_bridge.py::run_pass` 先看 `MUTATE_CACHE/_bridge-work/<source SHA>/repo` 是否已存在。只有不存在才自動 clone，且原內建 sparse只省 `tests/evidence` 與 `tests/release-evidence`，會把 root `evidence/` 也物化。不要為儲存修改原測試工具。

允許的準備方式是 root 在原預期路徑**預建獨立乾淨 exact SHA 薄 checkout**。預備命令形狀如下（本代理未執行；由 root 統一指定真路徑及來源）：

```text
git clone --shared --no-checkout SOURCE_CHECKOUT CACHE/_bridge-work/SHA/repo
git -C CACHE/_bridge-work/SHA/repo sparse-checkout set --no-cone <reviewed exact patterns>
git -C CACHE/_bridge-work/SHA/repo -c core.autocrlf=false checkout --detach SHA
```

不能把準備變成跳裁判。排除清單必須先與下列原 judge inputs交集為空；任何未證明的歷史路徑先保留：

- 原 `Sources` 從 current_geometry.c 與 geometry-web/web_bridge.c 遞迴 literal include得到的完整 C closure；source text/hash與主 checkout全部相同。
- core `run_tests.py`、TESTS 所引用的全部 scene、編譯工具及原 oracle hash所需資料。
- bridge `oracle_hash` 的 `tests/*.py`、`tests/*.c`、`tests/fixtures/**/*.scene`、root `*.scene`；以及原 RESTORED／mutant選定方法實際讀的額外 fixture／PROPOSAL／規範資料。
- 正常 build registry與原橋接 runtime所需全部產品／tests／fixtures。

root `evidence/` 只有通過上述精確交集及 runtime fixture前置核對才可列排除；其他幾何 roots下的歷史 evidence不能一刀排除，架構604 inventory與部分規範檢查實際需要。任一缺檔屬環境紅，補同 SHA 原檔後只重跑受影響項，不能製造綠燈skip。

原 bridge 自己仍會驗 HEAD相同、`Sources(work).closure == Sources(root).closure`、無工作樹 diff、每個 mutant舊anchor唯一、oracle hash相同及 byte restoration；任何 guard非0照實保，不繞過或改成新閾值。每個 clone自己的index／工作樹，只共用唯讀 Git objects；root cache路徑與來源在正式前後不得被回收工具碰。

## 後續身份

四檔與 ledger都是衍生產物，root 採納提交後會出新的 SHA。正式全清單要在 root 最後可解析來源上重綁執行；PR 唯一矩陣分開產品 F、evidence E、ledger／architecture input closure與各自 source SHA。F64 的讀者與 readingA結果只能以其真 F64 身份引用，不能改原收據字串來冒最後 final 綠。
