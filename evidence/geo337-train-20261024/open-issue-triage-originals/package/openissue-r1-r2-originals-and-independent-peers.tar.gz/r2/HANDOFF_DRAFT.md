# Open issue／PR 接續草稿

本稿只更新交接，不開關 issue、PR 或分支，不發留言、不跑產品，也不碰 Grok 線。範圍是原 captured 38 件 issue 加 #338–#345 與 cut-list；沒有重新做完整 API 分頁，因此目前 GitHub open/closed 狀態與未收錄 issue 均待查。原全文／hash 在舊 CATALOG.json；本稿逐件映射在 TRIAGE.json。

固定資料：handoff `1bffddde1279c60b2e0b946960df08504eb98b8a`；root 公開進度快照 `f05e7cfd373c9a77a366f7b2ddafd9401f261cf4`（其 current-state 為 00:08 UTC）；唯一正式來源 L=`7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`。後續執行可能已推進；本稿不從 live 進度推論終態。owner 最新回報與正文副本分開保存，targeted 通過從未改成 issue closed。

## 已有 PR 涵蓋，但仍不能關總工單

| 原需求／關聯 PR | 已有的有限結果 | 精確剩餘與關閉邊界 |
|---|---|---|
| #320 → #344 | S7b45013d 的 stale connection.error 修正；VM9/6/9 真 0/1/0，撤回 V082feb 已公開 | 真完整 canvas S/V/S、native／ledger／architecture 未跑。這是明確「驗收與審查接受、正常合併後再關 issue」候選，目前不關；不把 VM 當 CDP。 |
| #214 A4 → #345 | S2199cda8 一 leaf／helper 靜審14/20、準備出版719；834檔只是物化 | 原完整19方法／1200秒、CPU／wall 組件與原/fixed/withdrawn/restored等價對照全 UNRUN。單 fixture 合併也不關整件214；不訂新性能門檻、不把等價撤回算 kill。 |
| #300 → #341 | Sc493 原三套32方法／46controls／282build全0；目前來源Saa0分欄 | whole-opt等價撤回、成本／性能、完整 native／browser／架構／最終帳本未跑；不稱所有平方項已解。 |
| #300 → #343 | Sccfaf 原34方法／64controls／318build全0；tuple單方法8controls真0/1/0 | 整條快路八正例等價、完整場景stack/frame、性能／P189／512及完整 native／browser／ledger／architecture均未驗；既有Scc2紅仍保。 |
| #300 → cut-list | S39273bc0／Ea5f1806f／D4e6fa184；PR號在捕獲handoff未知 | 原report-policy11方法／9controls、五新刀、報表逐bytes、16MiB、aggregate／ledger／架構／性能均 UNRUN。只改 O(N) ID儲存，group/sort時間仍O(N²)、capacity仍64；不是 #47 廣義裁切／餘料功能完成。 |
| GEO-260 → #342 | Seb846 原完整44 exit0，43killed／SPM24 equivalent，539inputs同 | 完整 native30 aggregate／六browser／原123／架構未跑。L的Q38也仍UNRUN；代碼GEO-260不自動等於已取得GitHub issue260全文／全部關閉條件。 |
| 不帶木工模板需求 → #340 | 實跑bfb原13方法0／七phase 0/1/0/1/0/1/0；current S4d3與execution分欄 | 沒有可憑空close的原issue號。Git L的leaf為d4c6e370，原AST／expected都11，尚未納bfb e948／13方法leaf；bfb13／七phase與S4d保持獨立，整合仍待。不能把bfb收據移標L或宣稱全專案READY。 |

## 主列車與被取代 PR

#338 是 #337 的接續列車；既有 #314／#318／#299+#316／#323 工作已納其來源範圍，不代表這些編號的所有歷史總目標均完成。#338 最新審查仍為 22:39:41 UTC／head c6c0b0d，B1、B2、B3 尚未解除：

- L 原全123、三架構、ReadingA／reader／RC及 documents／assembly／grid／space／timber已真完成；canvas在本稿快照仍 RUNNING。
- 完整native r1仍exit1（230列，5304pass／4 ENOENT／1原允許Windows GDI skip）；三個同L fixture補齊0只證環境修復，完整r2未跑。r1內 #314六suite103／Node13、ReadingA7/14及323固定三套13/22/15的原切片已122/0獨立對照，但不洗掉 aggregate1；Node13沒有獨立OS退出碼。
- §7 compiled／axiom兩原完整CLI已0；P52／Q38／P189，以及L的323 required-eight／PF3／timing／profile／memo仍UNRUN。
- B2跨版本175/350 exact仍原exit1；不能以同列車memo反證取代。B3七required GitHub jobs仍failure，原annotation只支持「付款失敗或支出上限」的帳戶環境分類，不能改寫CI綠。

#339 接替重疊的 #324。固定F38da／Ee9ee／De1b5，11formal列3PASS／1RED／7UNRUN；mutationcheck1、107stale／13unrun；142 importers及3predicate原execution是S57，架構等4gate原execution是M1f0。新F142／三反證／aggregate與其餘正式項未跑，不借root L結果。22:39:42 UTC review要求完成B1–B3、接受#340基底並明確redirect/close舊#324。此處只列「待owner／本機服務辦理的重疊PR接替」，不稱它是已關閉issue，更不推Grok分支。

## 仍需明確裁決，或僅剩既定流程

| 項目 | 現況與可做範圍 |
|---|---|
| Q-323-ABC／#338 B2 | 三個具名場景的stdout及stderr都有I22要求的V_EXTENSION定位邊／超出區間新增字串。保原exact紅；須恢復exact或取得明確診斷版本／comparator裁決並登記後才重跑，不刪訊息、不normalize、無新數值門檻。 |
| #335 真CLI初放 | 原order12/order21/only2是1/1/0；e2先放本身成功但先長成1000，不是兩路第一支都立即失敗。原規則要求另案定放置路徑／條文差額；準備包已公開、因果84及封包1176獨審，沒有L CLI新實跑或核可產品修正。 |
| Q-314-SSOT | 原行為、提交相容例外已採納，題3/4不重問。精確有序補句的SSOT寫入／reader／採納hash流程仍是文書差額，不能誤寫為未決新政策。 |
| #239 | 發布替代方案原文要求使用者／dot決定；既有Git原件出版不等於核可新release方案。 |
| #203／#204 | 原提案已撤回：203剩餘併205，204不得重做撤回主張。只有owner重新核實目前issue狀態後，才考慮撤回案的行政收尾；本稿不關。 |
| #205／#230／#233 | 205已選A；230/233已有P116的legal D7／R43 unit分工裁決，不重問。當前完整產品／文件驗收未逐項對上，不能宣稱整案完成。 |

## 其餘 captured backlog 的保守去向

- #198、#319、#249：舊main已核到修正／實作與裁判入口；未逐一把原issue重現和當前原退出碼對上，不以source presence、ReadingA或§7綠直接關。
- #209：P78 request-abort／ready競態仍待查；#344只處理重連成功後stale error，不能當209已修。#211：本輪16MiB通過不能證明Linux預設8MiB已修。
- #19／#24／#25、#43–#49、#57／#61／#62、#77／#87、#54／#116／#128：舊來源已有bounded實作或入口；各總工單的完整旅程、真機／窄版、保存／取消、實圖、SR01–24等尚未逐項對帳。#24手機／Windows人工項不能由雲端原件補成已驗。#25仍只有限scene-native生成，不授權任意求值。
- #142／#123：可安排逐項真E2E／UX驗收，尚無本稿新增實測；不能以當前五browser子job全部綠代替各歷史需求清單。
- #308／#240：需對當前ReadingA／335／SSOT差額逐項釐清，不把舊研究數量當現行產品紅或新公理授權。#166／#232／#252為稽核／研究／協調串；#118為品質總工單，沒有單PR可替代全部關閉。
- #325／#331／#333及舊#324維持他人ownership；#194 LAN、#213 SketchUp沿既有owner。未收錄或未取得目前全文／判定條件的項目一律待查，未聲稱全專案open issues盤完。

下一個可執行順序是先完成root同L正式項與各owner已備的有界驗收，再在合併前將每個真正被修的issue對應到最終SHA／原退出碼／review接受。issue320可列明確待合併後關閉候選；214與300仍為部分覆蓋。其餘沒有足夠證據者保留，不為清空清單推定完成。

資料讀取限制：root common Git未含六個owner正文objects的首次show128已保，後改讀owner提供的固定正文副本；這是稽核來源位置限制，不是產品／測試紅。原38件非即時完整open枚舉；純草稿未另做獨立peer，交root對照採用。
