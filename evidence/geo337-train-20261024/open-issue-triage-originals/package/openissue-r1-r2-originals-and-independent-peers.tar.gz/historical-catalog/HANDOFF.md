# Open issue 只讀來源盤點

本次重用其他 owner 已抓取的 38 件 issue 原 JSON，沒有重打 API、執行產品或修改任何 branch。固定 main=425c092eaf16f90256d76433243baebde45163ac、train snapshot=2d1570691e4a29aafebdc0a4e739787d3fcdddaa；38 件各自的原 JSON 路徑/hash、文字／Git 證據等級與狀態都在 CATALOG.json。這是 captured set，並沒有完整且即時的 open-issue 分頁證明；未知項不算已盤完。

優先避免重做：#320 已有 owner 修復並定向 VM9/0-1-0，#198 主線已換 slab 精確交集，#319 主線已有跨分塊承接判官，#249 卡片級引用已有型別與裁判。#203/#204 的舊改法已撤回；#205 已選 A，不再重問。#325/#331 屬 Grok，#335/#322/#318/#316/#314/#300/#299/#248 既有 owner，本次不接。

12 個來源／merge commit 的 `merge-base --is-ancestor <commit> 425c...` 真退出皆 0，覆蓋 #47/#45/#44/#77/#25/#24/#19 的有限已合入切片。這只證歷史被 main 包含，不能當作功能完整或當前驗收通過。#44 舊「UI/HTTP 未接」文字已過時：main index 載入 model-update-app，serve 有真 prepare_update 路徑。#46、#49、#116、#87 也已有正式入口／registry，仍不可拿 source presence 冒充完整 E2E。

仍可安排的工作：#142/#123 的當前真 E2E／UX逐項驗收；#62 的原24條子規則整合驗收；#54/#87 的實圖識別準確性與取消／保存流程。這些都不是小 source patch，且本次未新執行。#239 發布方案明示需使用者與 dot 決策。

下一個不碰木工語意／共用產品檔的具體工程候選是 #214 A4：`tests/test_rule_case_workbench_http.py:40` 仍直接用標準 `serve_forever` 預設 polling，`:47` 每個 teardown 呼叫 shutdown，19 個原 test methods。可由 root 指定 owner 做 bounded HTTP fixture teardown 的排程加速，保持全部原 assertions、native child 上限、逾時／取消／cleanup行為；先收原版與修版同一套完整19例真結果和耗時，不設新的 elapsed-time 過關門檻，不把研究的8.55秒估算當收益。**這是來源核實的效能候選，不是已重現的產品缺陷。** 除已交 owner 的 #320，本次沒有確認另一個足以誠實稱為「小測試封閉的產品 bug」的案例，不能為湊下一題而捏造畸形輸入缺陷。候選需 root 分配後才實作。

盤點器自身有一次手抄 PR97 SHA 錯誤，造成最初 ancestry128；INITIAL_CATALOG_REVIEWER_TRANSCRIPTION_ERROR.json 與 INITIAL_GIT_COMMANDS.json 保留這個記錄。從 issue24 原全文讀取真 SHA377440fb...298c9cd3d 後重查為0。初版同名 Git stream 被重跑覆蓋，故不聲稱保有獨立原 stderr；試圖保留錯誤 stderr 時路徑漏零的 cp2 只在對話記錄。所有最終 ancestry raw 為重新核真的命令原件，非產品驗收。
