from pathlib import Path
import json,hashlib,subprocess,ast
B=Path('/tmp/open-issue-triage-handoff-refresh-20261024');R=Path('/tmp/train337-adversarial/OPENISSUE_TRIAGE_REFRESH_PEER.json');d=json.loads((B/'TRIAGE.json').read_text());idx=json.loads((B/'INDEX.json').read_text());draft=(B/'HANDOFF_DRAFT.md').read_text();checks=0;findings=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(v,label):
 global checks
 checks+=1
 if not v:findings.append(label)
for row in idx['files']:
 p=B/row['path'];ck(p.stat().st_size==row['bytes'] and h(p)==row['sha256'],'fixed indexed bytes '+row['path'])
ck(len(idx['files'])==idx['files_count']==31,'complete 31-item metadata index');ck(sum(x['bytes'] for x in idx['files'])==idx['bytes'],'metadata bytes sum')
cat=json.loads(Path(d['original_catalog']['path']).read_text());ck(h(d['original_catalog']['path'])==d['original_catalog']['sha256'],'historical catalog pin');original={i['number']:i for i in cat['issues']};ck(set(original)=={i['issue'] for i in d['captured_issues']} and len(original)==38,'38 historical issue identities preserved')
for i in d['captured_issues']:
 p=original[i['issue']];ck(i['original_issue_json']==p['sourceJSON'] and i['original_issue_sha256']==p['sourceSHA256'],'original source locator '+str(i['issue']));ck(i['current_github_state']=='NOT_REFRESHED' and i['close_authorized_or_done'] is False,'no close/complete claim '+str(i['issue']))
work={x['pr']:x for x in d['work'] if x['pr']};ck(set(work)==set(range(338,346)),'eight PRs');ck(len([x for x in d['work'] if x['pr'] is None])==1,'cut-list separate unnumbered request')
for pr in [341,343,345]:ck(('切片' in work[pr]['close_action'] or '一小段' in work[pr]['close_action']) and ('不關閉' in work[pr]['close_action'] or '不得關閉' in work[pr]['close_action'] or '不足以關閉' in work[pr]['close_action']),'aggregate issue not closed '+str(pr))
ck('目前維持OPEN/不得close' in work[344]['close_action'],'320 conditional close requires acceptance and merge');ck('11formal列僅3PASS/1RED/7UNRUN' in work[339]['unrun_or_blocked'],'339 no inherited train green')
notes={x['id']:x['status'] for x in d['policy_or_authority_notes']};ck('不可刪I22' in notes['Q-323-ABC/B2'],'B2 strict diagnostic decision retained');ck('待放置路徑' in notes['Q-335-CLI'] and '不冒L新實跑' in notes['Q-335-CLI'],'335 remains preparation');ck('已採納' in notes['Q-314-SSOT'] and '不列新待決' in notes['Q-314-SSOT'],'314 adopted lock not reopened');ck('沒有新增release授權' in notes['issue239'],'239 no new release authorization')
for s in ['三個同L fixture補齊0只證環境修復','Node13沒有獨立OS退出碼','不訂新性能門檻','不把等價撤回算 kill','沒有重新做完整 API 分頁','目前 GitHub open/closed 狀態與未收錄 issue 均待查']:ck(s in draft,'honest scope '+s)
L=d['final_source'];repo='/workspace/geometry-axiom';leaf=subprocess.check_output(['git','-C',repo,'show',L+':tests/test_rectangular_template.py']);expected=json.loads(subprocess.check_output(['git','-C',repo,'show',L+':tests/run_all.expected.json']));count=len([n for n in ast.walk(ast.parse(leaf)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]);registered=expected['suites']['py:test_rectangular_template']['count']
claim='owner回報來源已納L' in draft or 'owner回報來源已採L' in work[340]['execution_scope'];ck(not claim or (count==13 and registered==13),'F1: #340 claimed adopted in L but fixed Git L has old 11-method leaf and expected11; bfb13/source4d must remain independent pending integration')
report=dict(schema='independent-openissue-triage-classification-peer/1',checks=checks,findings=findings,exit_code=int(bool(findings)),input_pins={str(B/n):h(B/n) for n in ['HANDOFF_DRAFT.md','TRIAGE.json','INDEX.json']},direct_fixed_L_counterevidence={'source_sha':L,'path':'tests/test_rectangular_template.py','sha256':hashlib.sha256(leaf).hexdigest(),'ast_method_count':count,'registered_expected':registered},scope=['31 small indexed metadata files and original38 catalog bindings; no fresh open-issue API or issue/PR writes.','Only classification/closure/source boundaries, not new product or formal gate acceptance.','P116 and withdrawn203/204 cross-read captured originals; Q314/B2/335 cross-read current supplied QUESTIONS.','One actual stale adoption assertion requires correction; no source or historical test result changed by reviewer.'])
R.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(R),'sha256':h(R),'checks':checks,'findings':findings}));raise SystemExit(bool(findings))
