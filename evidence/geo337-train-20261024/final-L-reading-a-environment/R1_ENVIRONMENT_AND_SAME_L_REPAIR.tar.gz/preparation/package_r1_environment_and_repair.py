"""Package terminal r1 and completed same-L materialization repair, never live r2."""
from pathlib import Path
import hashlib,json,tarfile,datetime,stat
P=Path(__file__).parent;O=Path('/workspace/train337-L-reading-a-r1-environment-delivery');O.mkdir(exist_ok=False)
R=Path('/workspace/train337-L-reading-a-results-7af8c5d8')
terminal=json.loads((R/'RESULT.json').read_text());assert terminal['endedUTC']and terminal['after']['passed']and len(terminal['stageResults'])==2
assert [z['commandResult']['actual_process_returncode']for z in terminal['stageResults']]==[1,1]
def h(b):return hashlib.sha256(b).hexdigest()
files={}
for prefix,root in [('r1',R),('source-preparation',P/'source-preparation'),('source-repair-r2',P/'source-repair-r2')]:
 for path in sorted(root.rglob('*')):
  if not path.is_file():continue
  assert not path.is_symlink()and stat.S_ISREG(path.stat().st_mode)
  assert '.git'not in path.parts and '-r2/'not in str(root)
  files[prefix+'/'+path.relative_to(root).as_posix()]=path
for name in ['prepare_source.py','launch_two_original_stages.py','repair_source_r2.py','SOURCE_BINDING.r1.json','SOURCE_BINDING.json','REQUEST.r1.json','REQUEST.json','R1_ENVIRONMENT_CLASSIFICATION.json','FULL_ORACLE_GIT_FILE_LIST.json','IMPORT_AND_READ_CENSUS_R2.json','package_r1_environment_and_repair.py']:
 files['preparation/'+name]=P/name
peer=Path('/tmp/reading-a-L-launch-narrow-peer/REVIEW.json')
files['preparation-peer/REVIEW.json']=peer
provenance={'subjectSHA':'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db','scope':'Terminal r1 environment failures and completed sparse repair only, not live r2 results; no source checkout or .git','r1OuterSession':14832,'outerExitObservedFromToolAPI':1,'outerOSCaptureIndependent':False,'outerCaptureLimitation':'Launcher progress lines and exit were returned by exec/write_stdin API, without a separate predecode OS stdout/stderr capture; each original reaper/driver/CLI complete c387 raw streams are included.','r1CLIExits':[1,1],'classification':'Both stop at selftest.py1386 import make_golden, omitted by original11-path thin preparation, not assertion kills.','repair':'SameL whole oracle20files plus exact external PROPOSAL/decision queue; all22 physical bytes verified against immutable GitL. No product/tests/expected/assertions/timeouts/ledger modified.','r1BindingsPreserved':True,'noLiveR2FileReadForPackage':True,'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'PROVENANCE.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n');files['PROVENANCE.json']=O/'PROVENANCE.json'
index={'schema':'train337-reading-a-r1-env-and-same-L-repair/1','L':provenance['subjectSHA'],'scope':provenance['scope'],'files':{}}
for member,path in files.items():
 raw=path.read_bytes();assert not raw.startswith(b'\x7fELF');index['files'][member]={'originalPath':str(path),'bytes':len(raw),'sha256':h(raw)}
index['fileCount']=len(files);index['originalBytes']=sum(x['bytes']for x in index['files'].values());(O/'RAW_INVENTORY.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
archive=O/'R1_ENVIRONMENT_AND_SAME_L_REPAIR.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
 for member,path in files.items():tf.add(path,arcname=member,recursive=False)
 tf.add(O/'RAW_INVENTORY.json',arcname='RAW_INVENTORY.json',recursive=False)
with tarfile.open(archive,'r:gz')as tf:
 ms=tf.getmembers();assert len(ms)==len(set(m.name for m in ms))==len(files)+1
 for m in ms:
  assert m.isfile()and '..'not in Path(m.name).parts and not m.name.startswith('/')
  raw=tf.extractfile(m).read()
  if m.name=='RAW_INVENTORY.json':assert raw==(O/'RAW_INVENTORY.json').read_bytes();continue
  item=index['files'][m.name];assert len(raw)==item['bytes']and h(raw)==item['sha256']and raw==Path(item['originalPath']).read_bytes()
result={'archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSHA256':h(archive.read_bytes()),'inventorySHA256':h((O/'RAW_INVENTORY.json').read_bytes()),'members':len(files)+1,'originalBytes':index['originalBytes'],'roundtripEachOriginalBytes':True,'originalR1CLIExits':[1,1],'r2FormalResult':'Not included, currently running, no pass claim','sourceCodeCheckoutOrGitIncluded':False,'toolAPIOuterLimitationPreserved':True}
(O/'PACKAGE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
