from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys
S='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
R=Path('/workspace/train337-L-reading-a-source')
O=Path(__file__).parent
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
rec=cap.Recorder(O/'source-preparation',env,S)
def run(a,cwd=Path('/workspace'),data=None):
 row,out,err=rec.run(list(map(str,a)),cwd=cwd,data=data,timeout=120,source_sha=S,source_variant='independent-thin-source-preparation')
 if row['actual_process_returncode']!=0:raise RuntimeError('source preparation command failed')
 return out
assert not R.exists(),'refuse existing source'
run(['df','-B1','/workspace','/tmp'])
objects=Path(run(['git','--git-dir=/workspace/geometry-axiom/.git','rev-parse','--git-path','objects']).decode().strip()).resolve()
run(['git','init',R]);(R/'.git/objects/info/alternates').write_text(str(objects)+'\n')
req=json.loads(Path('/tmp/train337-reading-a-final-L-requests/REQUESTS.json').read_text());files=[x['path']for x in req['runtimeInputs']]
assert len(files)==11 and len(set(files))==11
run(['git','sparse-checkout','init','--no-cone'],R)
run(['git','sparse-checkout','set','--no-cone','--stdin'],R,(''.join('/'+x+'\n'for x in files)).encode())
run(['git','checkout','--detach',S],R)
inputs=[]
for name in files:
 raw=run(['git','show',S+':'+name],R);physical=(R/name).read_bytes();assert raw==physical
 inputs.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assert run(['git','rev-parse','HEAD'],R).decode().strip()==S
assert run(['git','status','--porcelain=v1','--untracked-files=all'],R)==b''
assert run(['git','diff','--cached','--name-only'],R)==b''
run(['git','ls-files','--stage','-z'],R)
result={'sourceSHA':S,'root':str(R),'gitDirectoryIndependent':(R/'.git').is_dir(),'objectsReadOnlyAlternate':str(objects),'files':inputs,'runtimeBytes':sum(x['bytes']for x in inputs),'indexSHA256':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'physicalSourceExpected':files,'noSubjectExecuted':True,'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'SOURCE_BINDING.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'source-preparation/commands.json').write_text(json.dumps(rec.rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'prepared':True,'sourceSHA':S,'bytes':result['runtimeBytes'],'indexSHA256':result['indexSHA256']},ensure_ascii=False))
