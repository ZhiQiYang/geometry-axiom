"""Materialize same-L oracle imports after preserved terminal sparse-input failure."""
from pathlib import Path
import ast,datetime,hashlib,importlib.util,json,os
P=Path(__file__).parent;R=Path('/workspace/train337-L-reading-a-source');L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
old=json.loads((Path('/workspace/train337-L-reading-a-results-7af8c5d8')/'RESULT.json').read_text());assert old['endedUTC'] and len(old['stageResults'])==2 and old['after']['passed']
assert [z['commandResult']['actual_process_returncode']for z in old['stageResults']]==[1,1]
spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8');rec=cap.Recorder(P/'source-repair-r2',env,L)
def run(argv,data=None):
 row,stdout,stderr=rec.run(list(map(str,argv)),cwd=R,data=data,timeout=120,source_sha=L,source_variant='same-L-sparse-environment-repair')
 assert row['actual_process_returncode']==0
 return stdout
assert run(['git','rev-parse','HEAD']).decode().strip()==L and run(['git','status','--porcelain=v1','--untracked-files=all'])==b''
old_binding=(P/'SOURCE_BINDING.json').read_bytes();(P/'SOURCE_BINDING.r1.json').write_bytes(old_binding)
(P/'REQUEST.r1.json').write_bytes((P/'REQUEST.json').read_bytes())
run(['git','sparse-checkout','set','--no-cone','--stdin'],data=b'/geometry-core/framing-template/oracle/\n/geometry-core/framing-template/PROPOSAL.md\n/\xe6\xb1\xba\xe7\xad\x96\xe4\xbd\x87\xe5\x88\x97.md\n')
files=[z['path']for z in json.loads((P/'FULL_ORACLE_GIT_FILE_LIST.json').read_text())]+['geometry-core/framing-template/PROPOSAL.md','決策佇列.md'];inputs=[];imports=[];reads=[]
for name in sorted(files):
 raw=run(['git','show',L+':'+name]);assert (R/name).read_bytes()==raw
 inputs.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 if name.endswith('.py'):
  text=raw.decode();tree=ast.parse(text)
  for n in ast.walk(tree):
   if isinstance(n,(ast.Import,ast.ImportFrom)):imports.append({'path':name,'line':n.lineno,'source':ast.get_source_segment(text,n)})
  for number,line in enumerate(text.splitlines(),1):
   if any(k in line for k in ['open(','.read_text(','.read_bytes(','FILES =','QUEUE_PATH =']):reads.append({'path':name,'line':number,'source':line})
assert len(files)==22
assert run(['git','rev-parse','HEAD']).decode().strip()==L and run(['git','status','--porcelain=v1','--untracked-files=all'])==b'' and run(['git','diff','--cached','--name-only'])==b''
run(['git','ls-files','--stage','-z'])
binding={'sourceSHA':L,'root':str(R),'gitDirectoryIndependent':True,'objectsReadOnlyAlternate':(R/'.git/objects/info/alternates').read_text().strip(),'files':inputs,'runtimeBytes':sum(z['bytes']for z in inputs),'indexSHA256':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'physicalSourceExpected':files,'noSubjectExecutedByRepair':True,'environmentRepair':'same-L whole oracle20 files plus external PROPOSAL and own decision queue; no tracked bytes changed','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'SOURCE_BINDING.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
(P/'IMPORT_AND_READ_CENSUS_R2.json').write_text(json.dumps({'localSubjectImportClosure':['selftest→framing_oracle','selftest→reading_a_cases','selftest→quote_check','selftest→make_golden→framing_oracle'],'externalReadClosure':['geometry-core/framing-template/PROPOSAL.md','決策佇列.md'],'imports':imports,'fileReads':reads,'allOracleModulesMaterialized':True,'sourceOnlyFromGitAtL':True,'originalJudgesUnchanged':True},ensure_ascii=False,indent=2)+'\n')
(P/'source-repair-r2/commands.json').write_text(json.dumps(rec.rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sourceSHA':L,'inputCount':22,'inputBytes':binding['runtimeBytes'],'sourceBindingSHA256':hashlib.sha256((P/'SOURCE_BINDING.json').read_bytes()).hexdigest(),'indexSHA256':binding['indexSHA256']},ensure_ascii=False))
