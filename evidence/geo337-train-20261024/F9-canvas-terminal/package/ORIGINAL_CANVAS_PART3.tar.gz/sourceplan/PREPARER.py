#!/usr/bin/env python3
"""Prepare independent browser checkouts; the existing workflow remains the judge.

Default mode only records a Git plan. --materialize-authorized is for the root's
later disk allocation; it is deliberately absent from the current preparation.
No existing source, receipt, fixture, Git object, or cache is deleted by this tool.
"""
from pathlib import Path
import argparse, difflib, hashlib, json, os, shutil, stat, subprocess, sys, tempfile

SUITES=('canvas','assembly','documents','grid','space','timber')
OMIT=('evidence/','tests/evidence/','tests/release-evidence/')
PRIVATE_FILES={'geometry-web/cdp_sections.golden.json','current_geometry.svg'}
DRIVER=Path('/workspace/geo261-environment/run_workflow_round.py')
DRIVER_PIN='6a3e3c327687ee6fdafb1044e4c4036f4d2f881a75498af97bd1e1af861e1310'
H=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def clean_git_env():
    env=dict(os.environ)
    for name in ('GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE'):env.pop(name,None)
    env.update(GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_NOSYSTEM='1')
    return env
def git(meta,args,**kw):
    return subprocess.run(['git','--git-dir',str(meta),'-c','gc.auto=0','-c','maintenance.auto=false',*args],check=True,capture_output=True,env=clean_git_env(),**kw).stdout
def plan(meta,sha,out,source_layout,suite):
    assert not out.exists(),'Refuse overwrite of any plan/raw output'
    out.mkdir()
    assert git(meta,['rev-parse',sha+'^{commit}']).decode().strip()==sha
    raw=git(meta,['ls-tree','-r','-l','-z',sha]);(out/'TREE.stdout.bin').write_bytes(raw)
    items=[];omitted=[]
    for part in raw.split(b'\0'):
        if not part:continue
        left,p=part.split(b'\t',1);mode,kind,oid,size=left.split();path=p.decode()
        if any(path.startswith(x) for x in OMIT):omitted.append(path);continue
        assert mode in (b'100644',b'100755') and kind==b'blob',path
        items.append(dict(path=path,mode=mode.decode(),git_blob=oid.decode(),bytes=int(size),private_copy=path in PRIVATE_FILES))
    assert len(items)==len({x['path'] for x in items}) and all(not Path(x['path']).is_absolute() and '..' not in Path(x['path']).parts for x in items)
    frozen=DRIVER.read_bytes();assert H(frozen)==DRIVER_PIN
    s=frozen.decode()
    old="XDG_CACHE_HOME=str(ENV_ROOT / 'xdg-cache'))"
    new="XDG_CACHE_HOME=str(tmp / 'xdg-cache'), npm_config_cache=str(tmp / 'npm-cache'))"
    assert s.count(old)==1;s=s.replace(old,new)
    old="        env['GEOMETRY_CHROME'] = str(CHROME)\n"
    new=old+"        env['GEOMETRY_SCHEDULE_SCREENSHOT_DIR'] = str(tmp / 'geometry-schedule-screens')\n"
    assert s.count(old)==1;s=s.replace(old,new)
    old="'XDG_DATA_HOME', 'XDG_CACHE_HOME', *original_env}"
    new="'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'npm_config_cache', 'GEOMETRY_SCHEDULE_SCREENSHOT_DIR', *original_env}"
    assert s.count(old)==1;s=s.replace(old,new)
    (out/'workflow-driver-original.py').write_bytes(frozen)
    (out/'workflow-driver-storage.py').write_text(s)
    (out/'WORKFLOW_DRIVER.patch').write_text(''.join(difflib.unified_diff(frozen.decode().splitlines(True),s.splitlines(True),fromfile='original-driver',tofile='storage-driver')))
    (out/'PREPARER.py').write_bytes(Path(__file__).read_bytes())
    parents={str(Path(x['path']).parent) for x in items}
    rounded=sum(((x['bytes']+4095)//4096)*4096 for x in items)
    private=sum(((x['bytes']+4095)//4096)*4096 for x in items if x['private_copy'])*6
    # Explicit planning estimates, never a product threshold or output cap.
    estimate=rounded+private+len(raw)*6+len(parents)*4096*7+16*1024*1024
    objects=Path(git(meta,['rev-parse','--git-path','objects']).decode().strip()).resolve()
    result=dict(schema='browser-private-git-readonly-pool-split-single-job-plan/1',sha=sha,objects=str(objects),metadata_git=str(meta),items=items,source_layout=str(source_layout),suites=[suite],
        omitted_new_checkout_paths=omitted,omission_scope='Only new checkout materialization; no existing physical files are removed.',
        ordinary_pool_bytes=sum(x['bytes'] for x in items),pool_rounded_4k=rounded,estimated_bootstrap_bytes=estimate,
        bootstrap_budget_limit='Estimate includes six private indexes/directories and metadata; real browser/ELF/output peaks need additional free disk. No output truncation.',
        workflow_original_sha256=DRIVER_PIN,workflow_storage_sha256=H(s.encode()),workflow_sha256=H(git(meta,['show',sha+':.github/workflows/integration-tests.yml'])),
        private_files=sorted(PRIVATE_FILES),private_writable_parents=True,pool_file_modes='0444 or executable0555',pool_directory_mode='0555',
        default_svg_tracked=any(x['path']=='current_geometry.svg' for x in items),
        default_svg='If tracked, private byte-identical copy; otherwise writable private parent creates an independent inode. Unexpected creation/change is still reported by original clean-source guards.',
        original_judge='Existing workflow driver unchanged except private XDG/npm cache paths and explicit schedule screenshot destination; no threshold/assertion/timeout/over-CI changes.',
        all_tests_builds_browser_and_product_materialization_unrun=True,
        selected_driver_commands={suite:[sys.executable,'-B',str(out/'workflow-driver-storage.py'),'--repo',str(source_layout/'jobs'/suite/'source'),'--sha',sha,'--job',suite,'--out-root','/tmp/browser-'+sha[:8]+'-'+suite+'/original']},
        single_job_scope='Exactly one complete original workflow job. Other five jobs are separate UNRUN rows until individually executed; no test selectors added.',
        split_resource_components=dict(metadata_bytes=len(raw)+32*1024*1024,source_directory_and_private_bytes=(private//6)+len(parents)*4096*2,original_v3_six_job_total_estimate_bytes=estimate-rounded+16*1024*1024),
        same_owner_chmod_limit='0444 blocks ordinary writes; it is not an immutable security boundary against the owner chmod-ing an inode. No such test path was found in the reviewed literal write closure.')
    dump(out/'PLAN.json',result)
    return result
def seed_pool(base,pool,plan,seed,native_root):
    """Only after root freezes the completed SEED at the final adopted L."""
    for path in (seed,native_root):
        assert all(not p.is_symlink() for p in (path,*path.parents)),str(path)
        assert path.is_dir()
    assert seed.stat().st_dev==pool.stat().st_dev,'Seed and readonly source pool must use the same filesystem; no automatic fallback'
    assert seed!=native_root and not seed.is_relative_to(native_root) and not native_root.is_relative_to(seed)
    calls=[]
    def seed_git(*argv):
        command=['git','-C',str(seed),*argv];prefix=base/('seed-git-%02d'%(len(calls)+1))
        dump(prefix.with_suffix('.request.json'),dict(command=command,status='starting'))
        try:p=subprocess.run(command,capture_output=True,env=clean_git_env())
        except BaseException as error:
            calls.append(dict(command=command,actual_exit=None,error=repr(error),raw_streams_complete=False));dump(base/'SEED_GIT_COMMANDS.json',calls);raise
        prefix.with_suffix('.stdout.bin').write_bytes(p.stdout);prefix.with_suffix('.stderr.bin').write_bytes(p.stderr)
        calls.append(dict(command=command,actual_exit=p.returncode,stdout_bytes=len(p.stdout),stdout_sha256=H(p.stdout),stderr_bytes=len(p.stderr),stderr_sha256=H(p.stderr)))
        dump(base/'SEED_GIT_COMMANDS.json',calls);assert p.returncode==0
        return p.stdout
    before=dict(head=seed_git('rev-parse','HEAD').decode().strip(),status=seed_git('status','--porcelain=v1','--untracked-files=all').decode(),tree=seed_git('rev-parse','HEAD^{tree}').decode().strip())
    assert before['head']==plan['sha'] and before['status']=='',before
    # Validate every byte/mode/native inode BEFORE the first chmod. Preserve this
    # manifest even if a later metadata operation fails; never auto-unfreeze.
    manifest=[];freeze=[]
    for x in plan['items']:
        p=seed/x['path'];n=native_root/x['path']
        assert p.is_file() and not p.is_symlink() and n.is_file() and not n.is_symlink(),x['path']
        assert p.resolve(strict=True)==p and n.resolve(strict=True)==n,('Input parent alias',x['path'])
        raw=p.read_bytes();st=p.stat();nst=n.stat()
        assert len(raw)==x['bytes'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==x['git_blob'],x['path']
        assert bool(st.st_mode&0o111)==(x['mode']=='100755'),x['path']
        assert (st.st_dev,st.st_ino)!=(nst.st_dev,nst.st_ino),('Native ROOT shares SEED inode',x['path'])
        manifest.append(dict(x,sha256=H(raw),source_role='verified final-L frozen SEED; no cat-file payload copy'))
        freeze.append(dict(path=x['path'],original_mode=stat.S_IMODE(st.st_mode),device=st.st_dev,inode=st.st_ino,bytes=len(raw),sha256=H(raw),native_device=nst.st_dev,native_inode=nst.st_ino))
    dump(base/'SEED_FREEZE_BEFORE.json',dict(seed=str(seed),native_root=str(native_root),source=before,files=freeze,no_native_or_mutator_may_reuse_seed=True,permission_limit='0444 only blocks ordinary writes; same owner may chmod. Not a security immutability guarantee.'))
    frozen_inodes=set()
    with (base/'SEED_FREEZE_EVENTS.jsonl').open('a') as events:
        for x,expected in zip(manifest,freeze):
            source=seed/x['path'];target=pool/x['path'];target.parent.mkdir(parents=True,exist_ok=True)
            assert source.resolve(strict=True)==source
            st=source.stat();raw=source.read_bytes();identity=(st.st_dev,st.st_ino)
            mode=(0o555 if x['mode']=='100755' else 0o444) if identity in frozen_inodes else expected['original_mode']
            assert identity==(expected['device'],expected['inode']) and stat.S_IMODE(st.st_mode)==mode and len(raw)==expected['bytes'] and H(raw)==expected['sha256'],('Seed changed between full preflight and freeze',x['path'])
            os.link(source,target)
            linked=target.stat();assert (linked.st_dev,linked.st_ino)==identity,('Seed changed at link; target retained without chmod',x['path'])
            target.chmod(0o555 if x['mode']=='100755' else 0o444)
            frozen_inodes.add(identity)
            events.write(json.dumps(dict(path=x['path'],linked=True,readonly_mode=stat.S_IMODE(target.stat().st_mode)))+'\n');events.flush()
    after=dict(head=seed_git('rev-parse','HEAD').decode().strip(),status=seed_git('status','--porcelain=v1','--untracked-files=all').decode(),tree=seed_git('rev-parse','HEAD^{tree}').decode().strip())
    assert before==after
    for x in manifest:
        p=seed/x['path'];raw=p.read_bytes();assert len(raw)==x['bytes'] and H(raw)==x['sha256'] and not p.stat().st_mode&0o222,x['path']
    dump(base/'SEED_FREEZE_AFTER.json',dict(source=after,all_raw_bytes_same=True,all_original_git_modes_preserved=True,payload_allocation_reused=True,new_payload_bytes=0,partial_failure_policy='Keep partial pool, seed original modes manifest, events and raw. No automatic fallback, deletion, or unfreeze.'))
    return manifest
def materialize(out,plan,reserve,seed,native_root):
    base=out/'layout';assert not base.exists()
    for protected in (seed,native_root):
        assert protected and protected!=out and not out.is_relative_to(protected) and not protected.is_relative_to(out),'Output and source roots must not contain each other'
    data=Path(plan['source_layout']);assert not data.exists(),'New readonly source layout required'
    assert len(plan['suites'])==1 and plan['suites'][0] in SUITES
    assert data.is_absolute() and all(not q.is_symlink() for q in (data,*data.parents))
    assert data.parent.is_dir(),'Source layout parent must already exist'
    for protected in (seed,native_root,out):
        assert data!=protected and not data.is_relative_to(protected) and not protected.is_relative_to(data),'Source layout overlaps protected root'
    free=shutil.disk_usage(out).free
    assert seed and native_root,'v3 materialization requires explicitly frozen existing SEED plus independent native ROOT; no payload fallback'
    assert reserve>=64*1024*1024,'Keep original64MiB reserve; this is not a product threshold'
    budget=plan['split_resource_components'];groups={}
    for label,path,amount in [('metadata',out,budget['metadata_bytes']),('readonly_source',data.parent,budget['source_directory_and_private_bytes'])]:
        dev=path.stat().st_dev;g=groups.setdefault(dev,dict(device=dev,labels=[],required_additional_bytes=reserve,free_bytes=shutil.disk_usage(path).free))
        g['labels'].append(label);g['required_additional_bytes']+=amount
    dump(out/'SPLIT_DEVICE_ADMISSION.json',dict(groups=list(groups.values()),reserve_per_device_bytes=reserve,existing_seed_payload_not_reallocated=True,actual_subject_launched=False))
    assert all(g['free_bytes']>=g['required_additional_bytes'] for g in groups.values()),('Insufficient split metadata/source budget: no layout created',groups)
    assert seed.stat().st_dev==data.parent.stat().st_dev,'Hardlinks require seed/source layout same device'
    estimate=budget['metadata_bytes']+budget['source_directory_and_private_bytes']
    base.mkdir();data.mkdir();pool=data/'pool';pool.mkdir();commands=[]
    (base/'MATERIALIZER.py').write_bytes(Path(__file__).read_bytes())
    dump(base/'SEED_REUSE_BUDGET.json',dict(source_sha=plan['sha'],existing_seed=str(seed),estimated_new_metadata_private_bytes=estimate,existing_payload_rounded_reused=plan['pool_rounded_4k'],reserve_bytes=reserve,no_fresh_payload_fallback=True))
    # v3 never streams a second product payload; v2 stays in its frozen file.
    manifest=seed_pool(base,pool,plan,seed,native_root)
    dump(base/'POOL_INPUTS.json',manifest)
    for p in sorted([p for p in pool.rglob('*') if p.is_dir()],key=lambda x:len(x.parts),reverse=True):p.chmod(0o555)
    pool.chmod(0o555)
    for suite in plan['suites']:
        job=data/'jobs'/suite;source=job/'source';source.mkdir(parents=True);gd=base/'jobs'/suite/'gitdir';gd.parent.mkdir(parents=True)
        for x in manifest:
            src=pool/x['path'];target=source/x['path'];target.parent.mkdir(parents=True,exist_ok=True)
            if x['private_copy']:shutil.copyfile(src,target);target.chmod(0o755 if x['mode']=='100755' else 0o644)
            else:os.link(src,target)
        def run(argv,data=None):
            index=len(commands)+1;prefix=base/('git-command-%03d'%index)
            dump(prefix.with_suffix('.request.json'),dict(command=argv,status='starting',stdin_bytes=0 if data is None else len(data),stdin_sha256=H(b'' if data is None else data)))
            if data is not None:prefix.with_suffix('.stdin.bin').write_bytes(data)
            try:p=subprocess.run(argv,input=data,capture_output=True,env=clean_git_env())
            except BaseException as error:
                commands.append(dict(command=argv,actual_exit=None,original_error=repr(error),raw_streams_complete=False))
                dump(base/'GIT_COMMANDS.json',commands);raise
            prefix.with_suffix('.stdout.bin').write_bytes(p.stdout);prefix.with_suffix('.stderr.bin').write_bytes(p.stderr)
            commands.append(dict(command=argv,actual_exit=p.returncode,stdin_bytes=0 if data is None else len(data),stdin_sha256=H(b'' if data is None else data),stdout_sha256=H(p.stdout),stderr_sha256=H(p.stderr)))
            dump(base/'GIT_COMMANDS.json',commands)
            assert p.returncode==0
            return p.stdout
        run(['git','init','--bare','--template=',str(gd)])
        (gd/'objects/info/alternates').write_text(plan['objects']+'\n')
        for key,value in [('core.bare','false'),('core.worktree',str(source)),('core.autocrlf','false'),('core.filemode','true'),('gc.auto','0'),('maintenance.auto','false')]:run(['git','--git-dir',str(gd),'config','--local',key,value])
        (source/'.git').write_text('gitdir: '+str(gd)+'\n');(gd/'HEAD').write_text(plan['sha']+'\n')
        run(['git','--git-dir',str(gd),'read-tree',plan['sha']])
        run(['git','--git-dir',str(gd),'update-index','-z','--skip-worktree','--stdin'],b''.join(p.encode()+b'\0' for p in plan['omitted_new_checkout_paths']))
    dump(base/'GIT_COMMANDS.json',commands)
    guard(out,plan)
    dump(base/'MATERIALIZED.json',dict(source_sha=plan['sha'],original_tests_unrun=True,free_before=free,free_after=shutil.disk_usage(out).free,actual_allocated_delta=free-shutil.disk_usage(out).free,reserve_bytes=reserve))
def guard(out,plan):
    base=out/'layout';data=Path(plan['source_layout']);manifest=json.loads((base/'POOL_INPUTS.json').read_bytes());checked=[]
    assert len(plan['suites'])==1 and plan['suites'][0] in SUITES
    logs=base/'guard-logs';logs.mkdir(exist_ok=True)
    log=Path(tempfile.mkdtemp(prefix='guard-',dir=logs));commands=[]
    def observed_git(argv):
        prefix=log/('%03d'%(len(commands)+1));dump(prefix.with_suffix('.request.json'),dict(command=argv,status='starting'))
        try:p=subprocess.run(argv,capture_output=True,env=clean_git_env())
        except BaseException as error:
            commands.append(dict(command=argv,actual_exit=None,error=repr(error),raw_streams_complete=False));dump(log/'COMMANDS.json',commands);raise
        prefix.with_suffix('.stdout.bin').write_bytes(p.stdout);prefix.with_suffix('.stderr.bin').write_bytes(p.stderr)
        commands.append(dict(command=argv,actual_exit=p.returncode,stdout_sha256=H(p.stdout),stderr_sha256=H(p.stderr)));dump(log/'COMMANDS.json',commands)
        assert p.returncode==0
        return p.stdout
    frozen=json.loads((base/'SEED_FREEZE_BEFORE.json').read_bytes());seed=Path(frozen['seed'])
    head=observed_git(['git','-C',str(seed),'rev-parse','HEAD']).decode().strip()
    status=observed_git(['git','-C',str(seed),'status','--porcelain=v1','--untracked-files=all'])
    assert head==plan['sha'] and status==b''
    for x in manifest:
        for source in (seed/x['path'],data/'pool'/x['path']):
            raw=source.read_bytes();assert len(raw)==x['bytes'] and H(raw)==x['sha256'] and not source.stat().st_mode&0o222,x['path']
    for suite in plan['suites']:
        source=data/'jobs'/suite/'source';gd=base/'jobs'/suite/'gitdir'
        assert observed_git(['git','--git-dir',str(gd),'rev-parse','HEAD']).decode().strip()==plan['sha']
        assert observed_git(['git','--git-dir',str(gd),'status','--porcelain=v1','--untracked-files=all'])==b''
        for x in manifest:
            p=source/x['path'];pool=data/'pool'/x['path'];assert not p.is_symlink() and p.is_file()
            raw=p.read_bytes();assert len(raw)==x['bytes'] and H(raw)==x['sha256'],(suite,x['path'])
            a,b=p.stat(),pool.stat()
            if x['private_copy']:assert (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino)
            else:assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) and not a.st_mode&0o222
        checked.append(dict(suite=suite,sha=plan['sha'],inputs=len(manifest),private_gitdir=str(gd),tree_clean=True))
    dump(base/'GUARD_LATEST.json',dict(sha=plan['sha'],passed=True,checks=checked,original_test_or_browser_executed=False))
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git-dir',type=Path);parser.add_argument('--sha');parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--materialize-authorized',action='store_true');parser.add_argument('--guard',action='store_true')
    parser.add_argument('--reuse-seed',type=Path);parser.add_argument('--native-root',type=Path)
    parser.add_argument('--seed-freeze-authorized',action='store_true')
    parser.add_argument('--reserve-bytes',type=int,default=64*1024*1024)
    parser.add_argument('--source-layout',type=Path)
    parser.add_argument('--job',choices=SUITES)
    a=parser.parse_args();assert not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ
    raw_out=a.out.absolute()
    assert all(not p.is_symlink() for p in (raw_out,*raw_out.parents)),'Refuse symlink output or parent before resolve'
    out=raw_out.resolve()
    assert str(out).startswith(('/tmp/','/workspace/'))
    for protected in (a.reuse_seed,a.native_root):
        if protected:
            p=protected.absolute()
            assert p!=out and not out.is_relative_to(p) and not p.is_relative_to(out),'Refuse overlapping output and source roots before any output write'
    if a.guard or a.materialize_authorized:
        v=json.loads((out/'PLAN.json').read_bytes())
        if a.materialize_authorized:
            assert a.seed_freeze_authorized and a.reuse_seed and a.native_root,'Root must first complete ledger, checkout adopted L in SEED, freeze it exclusively, and keep native ROOT independent'
            try:materialize(out,v,a.reserve_bytes,a.reuse_seed.absolute(),a.native_root.absolute())
            except BaseException as error:
                try:dump(out/'MATERIALIZATION_FAILED.json',dict(error=repr(error),partial_outputs_retained=True,tests_executed=False))
                except BaseException as cleanup:print('Failure-summary write failed: '+repr(cleanup),file=sys.stderr)
                raise
        else:guard(out,v)
    else:
        assert a.git_dir and a.sha and len(a.sha)==40 and a.source_layout and a.job
        layout=a.source_layout.absolute()
        assert all(not q.is_symlink() for q in (layout,*layout.parents)) and layout.parent.is_dir()
        assert layout!=out and not layout.is_relative_to(out) and not out.is_relative_to(layout)
        v=plan(a.git_dir.resolve(),a.sha,out,layout,a.job)
        print(json.dumps({k:v[k] for k in ['sha','ordinary_pool_bytes','pool_rounded_4k','estimated_bootstrap_bytes','all_tests_builds_browser_and_product_materialization_unrun']}))
if __name__=='__main__':main()
