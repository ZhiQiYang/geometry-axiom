"""Bind one prepared F9 browser source to the unchanged original workflow driver."""
from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,shutil,socket,stat,sys,traceback
F9='4f8a794f4167c3562eb182045102e86e9e37cca9'
DRIVER=Path('/workspace/train337-browser-pool-L-7af8c5d8/workflow-driver-browser-workspace.py')
PREPARER=Path('/tmp/geo337-browser-single-job-split-preparation-20261025/browser_readonly_pool_preparer_split_single_job.py')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
REAPER=Path('/workspace/geo261-environment/reap_children.py')
TEMPLATES=Path('/tmp/browser-six-minimal-requests-finalL-v2')
SEED=Path('/workspace/geo337-full123-F8-cache-20261025/_bridge-work/75a1e93811a52b69385cbdaf6a09d773ed9052ad/repo')
NATIVE=Path('/tmp/train337-323-f64d638f-source')
ENV_ROOT=Path('/workspace/geo261-environment')
WORKFLOW_PIN='b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d'
PINS={str(DRIVER):'2a42523fee66c7947313f567716b81f25c1cf50b965698ff5913216695cd1c98',str(PREPARER):'5e9b3fc3daeaf95ca4349e934dafb90eb915dc3dca17f6d1c418fe1d2ab85787',str(CAPTURE):'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',str(REAPER):'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'}
TEMPLATE_PINS={'canvas':'187aa912a593a7fa50fe6a897f8c55886ca998b5cc8d3be13e36d20c5674e465','assembly':'65d0daf1f755566c6e7d5e8d7ef1f2f883d86147ebfba9ee73d27899323c2a77','documents':'c6e97615ca77530add452792ad52ad6aa44a988db5ff083bb60f171e3bb4511c','grid':'9d9cb8166bc3e30569e0e155e1039721162c645ef3810b61127191ab5ed34f5d','space':'900d5ff380ee297894f727cd9b7fee5490d659a0805502c0a779dc866efc1629','timber':'05da53e3078753f62548cb9a0359b6fccb55f2e05e1d9011bb8dc87f2c3bcf40'}
PORTS={'canvas':(19081,9333),'assembly':(19082,9367),'documents':(19083,9366),'grid':(19084,9334),'space':(19085,9347),'timber':(19086,9348)}
def need(v,why):
 if not v:raise RuntimeError(why)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def path(value,root,exists=None):
 p=Path(value);need(p.is_absolute() and p.is_relative_to(root) and p!=root and '..' not in p.parts,'OWN_ABSOLUTE_PATH')
 need(all(not x.is_symlink() for x in (p,*p.parents)),'NO_PATH_ALIAS')
 if exists is not None:need(p.exists()==exists,'PATH_EXISTENCE:'+str(p))
 return p
def proof(v):
 p=Path(v['path']);need(p.is_absolute() and any(p.is_relative_to(r) for r in [Path('/tmp'),Path('/workspace')]),'OWN_PROOF_PATH')
 need(all(not x.is_symlink() for x in (p,*p.parents)) and p.is_file() and h(p)==v['sha256'],'EXACT_PREPARATION_PROOF')
 return json.loads(p.read_bytes())
def validate_preparation(q,job,plan_dir,layout):
 plan=proof(dict(path=str(plan_dir/'PLAN.json'),sha256=q['plan_sha256']))
 need(plan['schema']=='browser-private-git-readonly-pool-split-single-job-plan/1' and plan['sha']==F9 and plan['suites']==[job] and plan['source_layout']==str(layout),'EXACT_F9_SINGLE_JOB_PLAN')
 need(plan['workflow_sha256']==WORKFLOW_PIN and plan['private_files']==['current_geometry.svg','geometry-web/cdp_sections.golden.json'],'ORIGINAL_WORKFLOW_PRIVATE_GOLDEN')
 need(h(plan_dir/'PREPARER.py')==PINS[str(PREPARER)],'RETAINED_PLAN_PREPARER_SOURCE')
 need(h(plan_dir/'layout/MATERIALIZER.py')==PINS[str(PREPARER)],'RETAINED_ACTUAL_MATERIALIZER_SOURCE')
 prep=proof(q['source_preparation']);argv=prep['command']
 need(prep['actual_process_returncode']==0 and prep['timeout_expired'] is False and str(PREPARER) in argv and '--materialize-authorized' in argv and '--seed-freeze-authorized' in argv and '--guard' not in argv,'ORIGINAL_MATERIALIZATION_TRUE_ZERO')
 for flag,value in [('--out',str(plan_dir)),('--reuse-seed',str(SEED)),('--native-root',str(NATIVE))]:
  need(argv.count(flag)==1 and argv[argv.index(flag)+1]==value,'MATERIALIZATION_BOUND_ARGUMENT:'+flag)
 need(prep['source_sha']==F9,'MATERIALIZATION_SOURCE_F9')
 for stream in ['stdout','stderr']:
  p=Path(prep['directory'])/(stream+'.bin');need(p.stat().st_size==prep[stream+'_bytes'] and h(p)==prep[stream+'_sha256'],'ORIGINAL_PREPARATION_STREAM:'+stream)
 materialized=json.loads((plan_dir/'layout/MATERIALIZED.json').read_bytes())
 need(materialized['source_sha']==F9 and materialized['original_tests_unrun'] is True and materialized['reserve_bytes']>=64*1024*1024,'MATERIALIZED_F9_RECORDED')
 before=json.loads((plan_dir/'layout/SEED_FREEZE_BEFORE.json').read_bytes());after=json.loads((plan_dir/'layout/SEED_FREEZE_AFTER.json').read_bytes())
 need(before['seed']==str(SEED) and before['native_root']==str(NATIVE) and before['source']==after['source'] and after['source']['head']==F9 and after['source']['status']=='','EXACT_F9_FROZEN_SOURCE')
 need(all(after[k] is True for k in ['all_raw_bytes_same','all_original_git_modes_preserved','payload_allocation_reused']),'ORIGINAL_SOURCE_FREEZE_CHECKS')
 guard=json.loads((plan_dir/'layout/GUARD_LATEST.json').read_bytes())
 need(guard['sha']==F9 and guard['passed'] is True and len(guard['checks'])==1 and guard['checks'][0]['suite']==job and guard['checks'][0]['tree_clean'] is True,'SOURCE_PREPARATION_GUARD_RECORDED')
 return plan
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--request',type=Path,required=True);ap.add_argument('--request-sha256',required=True);a=ap.parse_args()
 need(not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ,'ASSERTIONS_REQUIRED')
 need(h(a.request)==a.request_sha256,'BOUND_REQUEST_PIN');q=json.loads(a.request.read_bytes())
 need(q['schema']=='geo337-F9-single-browser-launch/1' and q['source_sha']==F9 and q['root_scheduled_single_browser'] is True and q['root_execution_lease'] is True,'ROOT_BOUND_SINGLE_BROWSER_LEASE')
 job=q['job'];need(job in PORTS and q['resource_lock'] in ['heavy','secondary'],'ORIGINAL_JOB_AND_SCHEDULER')
 for p,pin in PINS.items():need(h(p)==pin,'ORIGINAL_TOOL_PIN:'+p)
 template=TEMPLATES/(job+'.REQUEST.template.json');need(h(template)==TEMPLATE_PINS[job],'ORIGINAL_TEMPLATE_PIN')
 plan_dir=path(q['plan_dir'],Path('/tmp'),True);layout=path(q['source_layout'],Path('/workspace'),True)
 out=path(q['out'],Path('/tmp'),False);storage=path(q['storage'],Path('/tmp'),False)
 need(out.parent.is_dir() and storage.parent.is_dir(),'EXISTING_OWN_OUTPUT_PARENTS')
 for x in [out,storage]:
  for y in [plan_dir,layout,SEED,NATIVE]:need(x!=y and not x.is_relative_to(y) and not y.is_relative_to(x),'OUTPUT_SOURCE_OVERLAP')
 need(not out.is_relative_to(storage) and not storage.is_relative_to(out),'OUTPUTS_DISTINCT')
 source=layout/'jobs'/job/'source';need(source.is_dir(),'PREPARED_JOB_SOURCE')
 env={k:v for k,v in os.environ.items() if not k.startswith(('GEOMETRY_','GIT_','GEO261_','MUTATE_'))}
 for k in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD']:env.pop(k,None)
 env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
 out.mkdir();spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
 recorder=cap.Recorder(out,env,F9);locks=[]
 report=dict(source_sha=F9,job=job,source=str(source),storage=str(storage),request_sha256=a.request_sha256,driver_pins=PINS,commands=recorder.rows,original_primary_exit=None,wrapper_exit=None,passed=False,errors=[],canvas_exclusive=job=='canvas',root_scheduled_single_browser=True,no_new_assertion_skip_or_timeout=True)
 code=2
 def save():cap.dump(out/'receipt.json',report)
 try:
  names=['heavy','secondary'] if job=='canvas' else [q['resource_lock']]
  for name in names:
   p=Path('/tmp/g261r3/'+name+'.lock');st=p.lstat();need(stat.S_ISREG(st.st_mode) and not p.is_symlink() and st.st_nlink==1,'EXISTING_REGULAR_SCHEDULER_LOCK')
   lock=p.open('r+b');locks.append(lock);need((os.fstat(lock.fileno()).st_dev,os.fstat(lock.fileno()).st_ino)==(st.st_dev,st.st_ino),'SCHEDULER_LOCK_IDENTITY');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  plan=validate_preparation(q,job,plan_dir,layout)
  need(h(source/'.github/workflows/integration-tests.yml')==WORKFLOW_PIN,'F9_WORKFLOW_EXACT_TEMPLATE')
  for port in PORTS[job]:
   with socket.socket() as s:s.bind(('127.0.0.1',port))
  raw=template.read_text().replace('<FINAL_L_40_HEX_NOT_ASSIGNED>',F9).replace('<FINAL_L_SHA8_NOT_ASSIGNED>',F9[:8])
  raw=raw.replace('<FINAL_BROWSER_PLAN_DIR_ABSOLUTE>/layout/jobs/'+job+'/source',str(source)).replace('<FINAL_BROWSER_PLAN_DIR_ABSOLUTE>',str(plan_dir)).replace('/tmp/browser-'+F9[:8]+'-'+job,str(storage))
  binding=json.loads(raw);binding.update(state='BOUND_F9_ORIGINAL_SINGLE_JOB_STARTING',driver_sha256=PINS[str(DRIVER)],preparer_sha256=PINS[str(PREPARER)],external_storage_constraint_delta='One complete original job: WS source layout; TMP Git metadata, browser outputs and scratch. Workflow/assertions/CI/golden unchanged.')
  binding['driver_argv'][2]=str(DRIVER);binding['immutable_inputs']['before_after_guard_argv']=[sys.executable,'-B',str(PREPARER),'--out',str(plan_dir),'--guard']
  need(binding['source_checkout']==str(source) and binding['private_gitdir']==str(plan_dir/'layout/jobs'/job/'gitdir'),'BOUND_SPLIT_JOB_SOURCE_AND_GITDIR')
  cap.dump(out/'BOUND_REQUEST.json',binding)
  guard=[sys.executable,'-B',str(PREPARER),'--out',str(plan_dir),'--guard']
  before,_,_=recorder.run(guard,cwd='/workspace',timeout=None,check=False,source_variant='F9-split-single-job-before-original-browser')
  report['before_guard']=before;save();need(before['actual_process_returncode']==0,'SOURCE_BEFORE_GUARD_ZERO')
  # Match the original driver's PATH construction; record versions without changing its logic.
  inherited_node=shutil.which('node',path=env.get('PATH'));need(inherited_node is not None,'NODE_PRESENT')
  old_path=env.get('PATH','');env['PATH']=os.pathsep.join(dict.fromkeys([str(ENV_ROOT/'bin'),str(Path(inherited_node).parent),*old_path.split(os.pathsep)]))
  for command,prefix in [(['google-chrome','--version'],b'Google Chrome 156.'),(['node','--version'],b'v24.')]:
   version,stdout,_=recorder.run(command,cwd='/workspace',timeout=30,check=False,source_variant='F9-required-original-browser-environment-version')
   report.setdefault('required_environment_versions',[]).append(version);save();need(version['actual_process_returncode']==0 and stdout.strip().startswith(prefix),'REQUIRED_BROWSER_ENVIRONMENT_VERSION')
  env['PATH']=old_path
  env['GEO261_REAPER_LOG']=str(out/'reaper.jsonl')
  argv=[sys.executable,'-B',str(REAPER),*binding['driver_argv']]
  row,_,_=recorder.run(argv,cwd='/workspace',timeout=None,check=False,source_variant='original-F9-full-single-browser-job')
  report['original_command']=row;save()
  original_path=storage/'original'/job/'receipt.json';original=json.loads(original_path.read_bytes())
  events=[json.loads(line) for line in (out/'reaper.jsonl').read_text().splitlines()];done=[e for e in events if e.get('event')=='完成'];need(len(done)==1 and events[-1]==done[0],'ORIGINAL_REAPER_TRUE_TERMINAL')
  need(original['sha']==F9 and original['job']==job and original['workflow_sha256']==WORKFLOW_PIN and original['driver_sha256']==PINS[str(DRIVER)],'ORIGINAL_F9_JOB_IDENTITY')
  need(row['actual_process_returncode']==done[0]['primary_returncode']==original['exit_code'],'ORIGINAL_EXIT_AGREEMENT')
  need(original['ci_timeout_minutes']==binding['ci_timeout_minutes'] and original['watchdog_factor']==3,'ORIGINAL_TIMELIMITS')
  report.update(original_primary_exit=original['exit_code'],original_receipt=str(original_path),original_receipt_sha256=h(original_path),over_ci_timeout=original['over_ci_timeout'])
  code=original['exit_code'] or (1 if original['over_ci_timeout'] else 0);report['passed']=code==0
 except BlockingIOError:
  code=75;report['errors'].append('Original browser not started: scheduler lock already held.')
 except BaseException:
  code=2;report['errors'].append(traceback.format_exc())
 finally:
  if report.get('before_guard'):
   try:
    after,_,_=recorder.run([sys.executable,'-B',str(PREPARER),'--out',str(plan_dir),'--guard'],cwd='/workspace',timeout=None,check=False,source_variant='F9-split-single-job-after-original-browser')
    report['after_guard']=after
    if after['actual_process_returncode']!=0:code=2;report['passed']=False
   except BaseException:report['errors'].append(traceback.format_exc());code=2;report['passed']=False
  for lock in reversed(locks):lock.close()
  report['wrapper_exit']=code;save()
 print(json.dumps({k:report[k] for k in ['source_sha','job','original_primary_exit','wrapper_exit','passed']}));return code
if __name__=='__main__':raise SystemExit(main())
