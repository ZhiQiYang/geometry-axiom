# F-20261027-002 · 自動擷取 · 2026-10-27 03:55:42

- 狀態:**open**
- 使用者說:(沒寫,看下面的操作紀錄與指到的元素)
- 畫面:面工作區 · 面 1(工具 select)
- 狀態快照:`{"oc": {"on": true, "tool": "select", "drawTool": null, "focus": {"t": "face", "id": 1}, "stack": [], "sel": null, "zoom": 1, "counts": {"faces": 1, "spaces": 0, "columns": 0, "beams": 0}}, "fe": {"tool": "select", "fiTab": "prop", "draftPts": 0, "lenBuf": ""}, "threeView": {"open": false, "tool": "view"}, "pendingSlot": null, "dialogs": [], "bodyClass": "", "activeElement": "body < html"}`
- 視窗:1382×900 @1x;場景:room_a.scene(/dev/shm/geo337-F9-browsers-20261025/Fr27-canvas/source-layout/jobs/canvas/source/room_a.scene)
- 程式版本:cbf0fb621

## 回報前的操作(最後 40 筆,時間相對於按下回報)

-   -33.3s api ✓ `line canvas-pos boundary 1 60 60`
-   -33.3s api ✓ `boundary 1`
-   -33.2s api ✓ `obstacles 1`
-   -33.2s api ✓ `references`
-   -33.2s api ✓ `dump`
-   -33.2s api ✓ `source-inspect`
-   -33.2s 狀態列 工具：選取
-   -33.2s 狀態列 面 1 · 選取
-   -33.2s api ✓ `dump`
-   -33.1s 點 button#refParameterOpen
-   -33.1s api ✓ `references`
-   -33.0s 改值 select#paramSpec = "主支中線"
-   -33.0s 點 input#paramSpecValue
-   -32.8s 鍵 Ctrl+a（input#paramSpecValue）
-   -32.7s api ✓ `dump`
-   -32.5s 點 button#paramSpecSave
-   -32.5s 改值 input#paramSpecValue = "900"
-   -32.4s api ✗ `line spec 主支中線 900` → line 734: I8a: impact preview required; inspect preview, then confirm token (World unchanged)
-   -32.2s 鍵 Escape（button.btn < div.impact-actions < dialog.reference-impact < body < html）
-   -32.2s api ✓ `line cancel-preview`
-   -32.2s 狀態列 ✗ 已取消；場景保持原狀
-   -32.2s toast[error] 已取消；場景保持原狀
-   -32.0s api ✓ `dump`
-   -31.9s api ✓ `default`
-   -31.9s api ✓ `objects`
-   -31.9s api ✓ `surfaces`
-   -31.9s api ✓ `boundary 1`
-   -31.9s api ✓ `section-profile-read`
-   -31.9s api ✓ `line canvas-pos boundary 1 60 60`
-   -31.8s api ✓ `boundary 1`
-   -31.8s api ✓ `obstacles 1`
-   -31.8s api ✓ `references`
-   -31.8s api ✓ `dump`
-   -31.8s api ✓ `source-inspect`
-   -31.8s 狀態列 工具：選取
-   -31.8s 狀態列 面 1 · 選取
-   -31.7s api ✗ `line place 999 on 1 at-line guide 1` → line 737: 欄位數不對，用法：place 角材id on 承載面id at-line guide 線id｜grid 網id u|v 索引 或 at-face e索引｜h孔e邊｜t角材，可加 through 座標 或 between 擋面 擋面）
-   -31.3s api ✓ `dump`
-   -30.2s api ✗ `line place 998 on 1 at-line guide 1` → line 738: 欄位數不對，用法：place 角材id on 承載面id at-line guide 線id｜grid 網id u|v 索引 或 at-face e索引｜h孔e邊｜t角材，可加 through 座標 或 between 擋面 擋面）
-    +0.0s **錯誤** Uncaught Error: fb-auto-probe

## 錯誤

- Uncaught Error: fb-auto-probe
  ```
  Error: fb-auto-probe
    at eval (eval at <anonymous> (:1:144), <anonymous>:1:23)
  ```

## 附件

`world.scene`、`events.jsonl`、`page.html`

重現:`python geometry-web/feedback_cli.py replay F-20261027-002`
