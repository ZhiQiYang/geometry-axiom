"""Read one terminated F full canvas gate; preserve originals, never rerun commands."""
from pathlib import Path
import datetime,hashlib,json,os,stat,traceback,argparse
ROOT=Path(__file__).parent;B=Path('/dev/shm/geo337-F9-browsers-20261025');S=B/'Fr27-canvas';F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';W=B/'r/rc/original/canvas';checks=[];pins={};count=0
H=lambda b:hashlib.sha256(b).hexdigest()
def need(v,msg):
 checks.append((msg,bool(v)))
 if not v:raise AssertionError(msg)
def read(p):
 global count
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode) and not p.is_symlink(),'regular:'+str(p));raw=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'stable:'+str(p));pins[str(p)]=H(raw);count+=len(raw);return raw
def j(p):return json.loads(read(p))
def capture(row):
 need(row['source_sha']==row['acceptance_sha']==F and row['actual_process_returncode']==0 and not row['timeout_expired'],'captured command F/0/not-timeout')
 p=Path(row['directory']);need(j(p/'result.json')==row,'original command row exact')
 for stream in ['stdout','stderr']:
  raw=read(p/(stream+'.bin'));need(len(raw)==row[stream+'_bytes'] and H(raw)==row[stream+'_sha256'],'complete original '+stream)
 raw=read(p/'stdin.bin');need(H(raw)==row['stdin_sha256'],'complete original stdin')

def validate_full_canvas(cdp,stdout,golden):
 """Existing full-suite contracts only; callable on tiny fixtures without any filesystem access."""
 need(golden['schema']=='geometry-cdp-sections/1' and golden['mode']=='full' and golden['total']==2267 and len(golden['sections'])==85 and sum(golden['sections'].values())==2267,'fixed full golden census schema/85/2267')
 need(cdp['schema']=='geometry-cdp-result/1' and cdp['completed'] is True,'full canvas completed result')
 need(cdp['scope']['mode']=='full' and cdp['scope']['filters']==[] and cdp['scope']['modifiers']==[],'full scope without partial filters/modifiers')
 need(cdp['passedAssertions']==golden['total'] and cdp['failedAssertions']==0 and cdp['sections']==golden['sections'] and not cdp.get('sectionsFailed',{}),'every golden section and total exact, no failed section')
 need(cdp['goldenCompare']=='matched' and not cdp['skipped'],'strict golden matched and zero skips, no update')
 need('[CDP FLOOR] 與 golden 逐段相符(85 段)' in stdout,'original strict floor matched log')
 expected=[line for line in stdout.splitlines() if line.startswith('[EXPECTED EXCEPTION]')]
 unexpected=[line for line in stdout.splitlines() if line.startswith('[UNEXPECTED EXCEPTION]')]
 need(cdp['uncaughtBrowserExceptions']==1 and expected==['[EXPECTED EXCEPTION] Error: fb-auto-probe'] and not unexpected,'one source-declared fb-auto-probe, zero unexpected exceptions')
 # Both traces are diagnostic features of existing negative tests, not extra skips.
 transport=cdp['firstTransportFailure'];network=cdp['firstNetworkFailure']
 need(isinstance(transport,dict) and transport.get('source')=='api-result' and transport.get('command')=='surfaces' and 'P53' in transport.get('step',''),'original P53 injected API transport probe')
 if network is not None:
  request=json.loads(network.get('postData','{}'))
  need(network.get('method')=='POST' and request.get('cmd')=='line spec receipt_probe 10' and 'P57' in network.get('step','') and network.get('errorText')=='net::ERR_ABORTED' and network.get('canceled') is True,'recorded first network failure is source-declared P57 receipt abort probe')
 return {'expected_runtime_probe':'fb-auto-probe','expected_exception_count':1,'unexpected_exception_lines':unexpected,'first_transport_failure':transport,'first_network_failure':network,'scope':'Full suite intentionally probes failures. Original full census and formal driver exit remain mandatory; no partial zero-exception/network-null rule copied.'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root-terminal-session',required=True);ap.add_argument('--root-terminal-chunk',required=True);a=ap.parse_args()
 need(a.root_terminal_session=='91441' and bool(a.root_terminal_chunk),'explicit completed root terminal attribution required')
 need((S/'control/launch/RESULT.json').is_file(),'launch terminal RESULT exists before any audit read')
 need(not(ROOT/'ACTUAL_PEER.json').exists() and not(ROOT/'SELECTION.json').exists(),'fresh audit output')
 outer={k:j(S/'control'/k/'RESULT.json')for k in ['plan','materialize','launch']}
 for k,r in outer.items():
  need(r['source_sha']==F and r['exit_code']==0 and not r['errors'],'root stage true0:'+k)
  for row in r['commands']:capture(row)
 sample=j(S/'sample-original/RESULT.json');launch=j(S/'launch-original/receipt.json');w=j(W/'receipt.json')
 need(sample['source_sha']==launch['source_sha']==w['sha']==F,'one fixed F')
 need(sample['job']==launch['job']==w['job']=='canvas','one full canvas job')
 need(launch['canvas_exclusive'] is True,'full canvas exclusive launcher locks')
 need(sample['original_process_returncode']==sample['wrapper_exit']==launch['original_primary_exit']==launch['wrapper_exit']==w['exit_code']==0,'true formal/launcher/sampler0')
 need(sample['original_passed'] and launch['passed'] and not sample['errors'] and not sample['sampling_errors'] and sample['sampling_complete'] and not launch['errors'],'complete clean wrappers')
 need(w['ci_timeout_minutes']==35 and w['watchdog_factor']==3 and not w['over_ci_timeout'] and w['seconds']<=2100,'original35min preserved')
 need(launch['before_guard']['actual_process_returncode']==launch['after_guard']['actual_process_returncode']==0,'before/after source guards0')
 need(w['checkout_before']==w['checkout_after'] and w['checkout_after']['head']==F and not w['checkout_after']['status'],'original checkout identity preserved')
 need(sample['original_receipt_sha256']==pins[str(S/'launch-original/receipt.json')] and launch['original_receipt_sha256']==pins[str(W/'receipt.json')],'full original receipt chain hashes')
 for row in sample['commands']+launch['commands']:capture(row)
 reaper=[json.loads(x)for x in read(S/'launch-original/reaper.jsonl').splitlines()];done=[r for r in reaper if r.get('event')=='完成'];need(len(done)==1 and reaper[-1]==done[0] and done[0]['primary_returncode']==0,'original reaper true terminal0')
 need(read(W/'receipt.sha256').decode().split()[0]==pins[str(W/'receipt.json')],'original receipt selfhash')
 for rel,meta in w['files'].items():
  need('..'not in Path(rel).parts and not Path(rel).is_absolute(),'workflow file relative')
  raw=read(W/rel);need(len(raw)==meta['bytes'] and H(raw)==meta['sha256'],'workflow original hash:'+rel)
 need(w['workflow_sha256']=='b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d' and w['driver_sha256']=='4cdfe3dd250bc9bba6f8e8a513bbd2007176dc914b60b034b2aa7761e295affd','unchanged workflow/driver')
 versions={}
 for row in w['versions']:
  need(row['exit_code']==row['actual_process_returncode']==0 and not row['watchdog_expired'],'original environment command0')
  versions[' '.join(row['command'])]=read(row['stdout']).decode().strip()
 need(versions['google-chrome --version'].startswith('Google Chrome 156.') and versions['node --version'].startswith('v24.'),'Chrome156/Node24 actual')
 need(any('install ok installed' in v and 'fonts-noto-cjk' in k for k,v in versions.items()),'fonts installed')
 formal_steps=[x for x in w['steps']if 'result'in x];need(len(formal_steps)==2 and all(x['result']['exit_code']==0 and not x['result']['watchdog_expired']for x in formal_steps),'build/browser original steps0')
 stdout=read(W/'steps/03.stdout').decode();lines=stdout.splitlines();results=[x[len('CDP_RESULT '):]for x in lines if x.startswith('CDP_RESULT ')];need(len(results)==1,'one current full canvas CDP result');cdp=json.loads(results[0])
 fixed_golden=json.loads(read(ROOT/'source-cdp_sections.golden.json'));need(H((ROOT/'source-cdp_sections.golden.json').read_bytes())=='de99e9d0073b57e0b80856823cb4c49eb48c3c1629d57b7134bd3311197ad86f','fixed F golden source pin')
 probe_summary=validate_full_canvas(cdp,stdout,fixed_golden)
 server_diagnostics={'broken_pipe_occurrences':stdout.count('BrokenPipeError'),'contexts':[{"line":i+1,"context":lines[max(0,i-4):min(len(lines),i+3)]}for i,line in enumerate(lines)if 'BrokenPipeError' in line], 'classification':'Server-side broken-pipe/client-disconnect diagnostic is retained in complete original stdout. Not a failed product assertion by text alone; full census, golden, source and exit chains decide the original formal result. Correlation to a specific aborted probe is not proven merely by this traceback.'}
 screens={k:v for k,v in w['files'].items()if k.endswith('.png')}
 expected_workflow_screens={'artifacts/06/grid-trial-desktop.png','artifacts/06/grid-trial-mobile-alignment.png','artifacts/06/grid-trial-mobile-canvas.png','artifacts/06/grid-trial-mobile-controls.png'}
 need(set(screens)==expected_workflow_screens,'exact four original workflow upload screenshots, not85')
 for rel in screens:need(read(W/rel).startswith(b'\x89PNG\r\n\x1a\n'),'workflow screenshot PNG:'+rel)
 observed=[json.loads(x)for x in read(S/'sample-original/SAMPLES.jsonl').splitlines()];obs=sample['sampled_observations'];need(len(observed)==obs['samples'] and len(observed)>=2 and all(not r['errors']for r in observed),'all original resource samples complete')
 for fs in ['/dev/shm','/workspace','/tmp']:
  rows=[r['filesystems'][fs]for r in observed];s=obs['filesystems'][fs];need(s['minimum_sampled_free_bytes']==min(r['free_bytes']for r in rows) and s['maximum_sampled_filesystem_used_bytes']==max(r['total_bytes']-r['free_bytes']for r in rows),'recomputed sampled mount extrema:'+fs)
 need(obs['maximum_sampled_cgroup_memory_bytes']==max(r['memory.current']for r in observed),'sampled cgroup max')
 need(obs['maximum_observed_gap_seconds']==max(b['monotonic']-a['monotonic']for a,b in zip(observed,observed[1:])),'sampled maximum gap')
 need(all(r['memory.events']['oom']==r['memory.events']['oom_kill']==0 for r in observed),'no sampled OOM')
 for endpoint in ['before','after']:
  own=j(S/('sample-original/OWN_'+endpoint.upper()+'.json'));need(own==sample['own_'+endpoint] and own['unique_allocated_bytes']==sum(x['unique_allocated_bytes']for x in own['roots']),'original own endpoint:'+endpoint)
 need(sample['startup_planning_increment_bytes']==512*1024**2 and sample['startup_planned_total_bytes']==sample['own_before']['unique_allocated_bytes']+512*1024**2<=8*1024**3,'8GiB reversible planning admission')
 cp=j(B/'Fd27/seed-copy-original/RESULT.json');need(cp['source_sha']==F and cp['exit_code']==0 and cp['items']==3759 and cp['new_seed_state']['head']==F and cp['new_seed_state']['status']=='' and cp['original_seed_pool_verifier_zero'],'accepted shared F seed original provenance0')
 before=j(S/'plan/layout/SEED_FREEZE_BEFORE.json');after=j(S/'plan/layout/SEED_FREEZE_AFTER.json');need(before['source']==after['source'] and after['source']['head']==F and all(after[k]for k in ['all_raw_bytes_same','all_original_git_modes_preserved','payload_allocation_reused']),'seed freeze original identity')
 pool=j(S/'plan/layout/POOL_INPUTS.json');need(len(pool)==3759,'full source guard closure3759')
 guard=j(S/'plan/layout/GUARD_LATEST.json');need(guard['passed']and guard['sha']==F and len(guard['checks'])==1 and guard['checks'][0]['inputs']==3759 and guard['checks'][0]['suite']=='canvas' and guard['checks'][0]['tree_clean'],'final guard full3759')
 private_git=S/'plan/layout/jobs/canvas/gitdir';source=S/'source-layout/jobs/canvas/source';golden_rel='geometry-web/cdp_sections.golden.json';golden=source/golden_rel;poolgolden=S/'source-layout/pool'/golden_rel
 golden_row=next(x for x in pool if x['path']==golden_rel);golden_raw=read(golden);need(H(golden_raw)==golden_row['sha256']=='de99e9d0073b57e0b80856823cb4c49eb48c3c1629d57b7134bd3311197ad86f' and json.loads(golden_raw)==fixed_golden,'private golden exact original F manifest bytes and full census');ga=golden.stat();gb=poolgolden.stat();need((ga.st_dev,ga.st_ino)!=(gb.st_dev,gb.st_ino),'private golden independent from readonly pool')
 need(read(source/'.git').decode().strip()=='gitdir: '+str(private_git),'private git pointer exact');need(read(private_git/'HEAD').decode().strip()==F,'private index HEAD fixedF');index_raw=read(private_git/'index');private_metadata=dict(gitdir=str(private_git),index_sha256=H(index_raw),index_bytes=len(index_raw),golden_sha256=H(golden_raw),golden_comparison_scope='full canvas exact85section census and2267 total matched fixed F golden; original private golden bytes retained')
 request=j(S/'control/launch/LAUNCH_REQUEST.json');need(request['storage']==str(B/'r/rc') and request['source_sha']==F and hpath(request['source_preparation']['path'])==request['source_preparation']['sha256'],'actual materializer receipt binding')
 # Complete metadata/raw namespaces; do not duplicate public tracked payload or Git object stores.
 plan=j(S/'plan/PLAN.json');tracked={x['path']:x for x in plan['items']};need(len(tracked)==3759,'selected tracked payload3759')
 payload_roots=[S/'source-layout/pool',S/'source-layout/jobs/canvas/source'];excluded_counts={str(p):0 for p in payload_roots};files=[];dirs=[];nonregular=[];runtime_screens={}
 for root in [S,B/'r/rc']:
  stack=[root]
  while stack:
   p=stack.pop()
   st=p.lstat();rel=str(p.relative_to(B));meta=dict(path=str(p),relative_to_browser_OWN=rel,mode=stat.S_IMODE(st.st_mode),raw_mode=st.st_mode,size=st.st_size,mtime_ns=st.st_mtime_ns,device=st.st_dev,inode=st.st_ino,nlink=st.st_nlink)
   if stat.S_ISDIR(st.st_mode):dirs.append(meta);stack.extend(sorted(p.iterdir(),reverse=True))
   elif stat.S_ISREG(st.st_mode):
    match=next((r for r in payload_roots if p.is_relative_to(r) and str(p.relative_to(r))in tracked),None)
    if match is not None:
     rel=str(p.relative_to(match));need(st.st_size==tracked[rel]['bytes'],'tracked payload planned size:'+rel);excluded_counts[str(match)]+=1;continue
    raw=read(p);meta['sha256']=H(raw);meta['allocated_bytes']=st.st_blocks*512;files.append(meta)
    if p.suffix.lower()=='.png' and p.is_relative_to(B/'r/rc/tmp'):
     need(raw.startswith(b'\x89PNG\r\n\x1a\n'),'runtime PNG:'+str(p));runtime_screens[str(p.relative_to(B/'r/rc'))]={'bytes':len(raw),'sha256':H(raw)}
   else:
    meta['kind']='symlink'if stat.S_ISLNK(st.st_mode)else 'socket'if stat.S_ISSOCK(st.st_mode)else 'other';meta['link_target']=os.readlink(p)if stat.S_ISLNK(st.st_mode)else None;nonregular.append(meta)
 need(all(n==3759 for n in excluded_counts.values()),'only exact3759 tracked payload omitted per actual source copy')
 selection=dict(schema='fixed-F-canvas-complete-raw-selection/3',source_sha=F,roots=[str(S),str(B/'r/rc')],files=files,directories=dirs,nonregular_metadata_only=nonregular,excluded_tracked_payload=dict(plan=str(S/'plan/PLAN.json'),plan_sha256=hpath(S/'plan/PLAN.json'),path_set=list(tracked),per_copy_counts=excluded_counts,rule='Omit only regular leaf matching exact original PLAN tracked payload path and size. Source .git, ignored or any other leaf plus every directory is retained. No physical deletion; original full byte guards remain mandatory.'),shared_seed_provenance=dict(path=str(B/'Fd27/seed-copy-original/RESULT.json'),sha256=hpath(B/'Fd27/seed-copy-original/RESULT.json'),already_owned_by_separate_seed_acceptance=True),git_objects_policy='No external object provider traversal or duplicate tracked source payload. Private Git metadata and objects/info/alternates text are selected.',logical_bytes=sum(x['size']for x in files),regular_files=len(files),directory_count=len(dirs),no_deletion=True)
 (ROOT/'SELECTION.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
 result=dict(schema='F-canvas-formal-actual-peer/3',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha=F,exit_code=0,blocking_findings=[],checks=len(checks),original_formal_exit=0,outer_control_exit=0,formal_assertions=cdp,original_started=w['started'],original_ended=w['ended'],original_seconds=w['seconds'],original_ci_minutes=35,over_ci_timeout=False,assertion_skips=0,original_versions=versions,private_metadata=private_metadata,original_screenshots=screens,runtime_screenshots=runtime_screens,workflow_screenshot_count=len(screens),runtime_screenshot_count=len(runtime_screens),golden_sections=85,expected_probe_diagnostics=probe_summary,server_diagnostics=server_diagnostics,root_terminal_observation={'session':a.root_terminal_session,'chunk':a.root_terminal_chunk,'exit_code':0,'source':'parent terminal message, not child poll'},workflow_original_files=len(w['files']),source_guard_leaf_count=3759,original_seed_copy_source_index_sha256=cp['original_index_sha256'],sampled_observations=obs,own_before=sample['own_before'],own_after=sample['own_after'],selection=dict(path=str(ROOT/'SELECTION.json'),sha256=hpath(ROOT/'SELECTION.json'),regular_files=len(files),logical_bytes=selection['logical_bytes'],nonregular_count=len(nonregular)),raw_bytes_read=count,limits=['Formal result refers only to fixed F full canvas; no other source results are relabeled.','Original GitHub checkout/upload actions are represented by exact clean checkout/local artifact preservation; apt install verified as already installed.','Complete job command/raw/screenshot/source-identity namespaces included. Only exact3759 tracked regular payload leaves are omitted per source copy; .git and all other leaves/directories remain selected. Shared seed acceptance is referenced by exact receipt hash, not rerun or redundantly repackaged.','Resource samples are shared mount/cgroup observations, not exact peaks or performance evidence.','Root session/chunk attribution is provided explicitly at invocation; audit validates persisted originals, not inherited process handles.','Remote package delivery is separate; no test or guard was rerun and no file deleted.'])
 (ROOT/'ACTUAL_PEER.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(exit_code=0,checks=len(checks),assertions=2267,golden_sections=85,workflow_screenshots=4,runtime_screenshots=len(runtime_screens),seconds=w['seconds'],selection_files=len(files),selection_bytes=selection['logical_bytes'],peer_sha256=hpath(ROOT/'ACTUAL_PEER.json'))))
def hpath(p):return H(Path(p).read_bytes())
if __name__=='__main__':main()
