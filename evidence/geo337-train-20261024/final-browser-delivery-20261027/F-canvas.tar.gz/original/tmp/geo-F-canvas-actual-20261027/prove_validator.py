"""Record one small validator mutation proof without reading canvas raw."""
import hashlib
import importlib.util
import json
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'validator-proof'
assert not OUT.exists()
OUT.mkdir()
capfile = pathlib.Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(capfile.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
sp = importlib.util.spec_from_file_location('capture', capfile)
cap = importlib.util.module_from_spec(sp)
sp.loader.exec_module(cap)
rec = cap.Recorder(OUT, dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), 'synthetic-local-only')
before = (ROOT/'audit_actual.py').read_bytes()
cases = []
for mode, expected in [('valid_baseline',0),('normal_guard',0),('withdrawn_guard',1),
                       ('restored_guard',0),('reject_skip',0),('reject_unexpected_exception',0),
                       ('reject_wrong_abort',0),('valid_network_null',0)]:
    row, stdout, stderr = rec.run([sys.executable,'-B',str(ROOT/'validator_fixture_worker.py'),mode],
                                  cwd=ROOT,timeout=30,check=False,source_variant=mode)
    result = json.loads(stdout)
    assert row['actual_process_returncode'] == result['exit_code'] == expected and stderr == b''
    cases.append(result)
assert (ROOT/'audit_actual.py').read_bytes() == before
stream_checks = 0
for row in rec.rows:
    for label in ['stdin','stdout','stderr']:
        data = (pathlib.Path(row['directory'])/(label+'.bin')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row[label+'_sha256']
        stream_checks += 1
result = {'exit_code':0,'mutation_sequence':[cases[i]['exit_code'] for i in [1,2,3]],
          'cases':cases,'commands':len(rec.rows),'stream_hash_checks':stream_checks,
          'auditor_unchanged':True,'auditor_sha256':hashlib.sha256(before).hexdigest(),
          'scope':'Pure synthetic validator tests only; no browser/raw canvas files, main audit, Git, network or package run'}
(OUT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':0,'mutation_sequence':result['mutation_sequence'],
                  'sha256':hashlib.sha256((OUT/'RESULT.json').read_bytes()).hexdigest(),
                  'commands':len(rec.rows),'stream_hash_checks':stream_checks}))
