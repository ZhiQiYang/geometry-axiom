"""Pure synthetic validator checks; no canvas raw files or browser execution."""
import ast
import copy
import hashlib
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT / 'audit_actual.py'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '6b60993ed9081adc4648ce0ff6b65169aac1998e143b96aac36d41d466636e89'
tree = ast.parse(raw)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'validate_full_canvas')
mode = sys.argv[1]
assert mode in {'valid_baseline', 'normal_guard', 'withdrawn_guard', 'restored_guard', 'reject_skip', 'reject_unexpected_exception', 'reject_wrong_abort', 'valid_network_null'}
if mode == 'withdrawn_guard':
    target = [n for n in ast.walk(fn) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
              and n.func.id == 'need' and len(n.args) == 2 and isinstance(n.args[1], ast.Constant)
              and n.args[1].value == 'every golden section and total exact, no failed section']
    assert len(target) == 1
    target[0].args[0] = ast.Constant(True)
calls = []
def need(value, message):
    calls.append({'message': message, 'passed': bool(value)})
    if not value:
        raise AssertionError(message)
namespace = {'json': json, 'need': need}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), '<pure-synthetic-validator>', 'exec'), namespace)
golden = json.loads((ROOT / 'source-cdp_sections.golden.json').read_bytes())
cdp = {'schema':'geometry-cdp-result/1', 'completed':True,
       'scope':{'mode':'full','filters':[],'modifiers':[]},
       'passedAssertions':2267, 'failedAssertions':0, 'sections':copy.deepcopy(golden['sections']),
       'goldenCompare':'matched','skipped':[], 'uncaughtBrowserExceptions':1,
       'firstTransportFailure':{'source':'api-result','command':'surfaces','step':'=== P53. synthetic probe ==='},
       'firstNetworkFailure':{'method':'POST','postData':json.dumps({'cmd':'line spec receipt_probe 10'}),
           'step':'=== P57–P61. synthetic probe ===','errorText':'net::ERR_ABORTED','canceled':True}}
stdout = '[CDP FLOOR] 與 golden 逐段相符(85 段)\n[EXPECTED EXCEPTION] Error: fb-auto-probe\n'
expect_rejection = mode not in {'valid_baseline','valid_network_null'}
if mode in {'normal_guard','withdrawn_guard','restored_guard'}:
    cdp['sections']['P88'] -= 1
    cdp['sections']['P73'] += 1
    assert sum(cdp['sections'].values()) == 2267 and len(cdp['sections']) == 85
elif mode == 'reject_skip':
    cdp['skipped'] = ['synthetic skip must be rejected']
elif mode == 'reject_unexpected_exception':
    cdp['uncaughtBrowserExceptions'] = 2
    stdout += '[UNEXPECTED EXCEPTION] synthetic unexpected error\n'
elif mode == 'reject_wrong_abort':
    cdp['firstNetworkFailure']['postData'] = json.dumps({'cmd':'unexpected command'})
elif mode == 'valid_network_null':
    cdp['firstNetworkFailure'] = None
rejected = False
error = None
try:
    namespace['validate_full_canvas'](cdp, stdout, golden)
except AssertionError as exc:
    rejected = True
    error = str(exc)
passed = rejected == expect_rejection
result = {'mode':mode,'exit_code':0 if passed else 1,'expected_rejection':expect_rejection,
          'actually_rejected':rejected,'error':error,'checks':calls,
          'injected_mutation':'Only pure AST exact section comparison disabled; actual audit file unchanged' if mode=='withdrawn_guard' else None,
          'synthetic_cdp':cdp,'synthetic_stdout':stdout,
          'scope':'Validator-only synthetic fixture; not product or actual canvas acceptance'}
print(json.dumps(result, ensure_ascii=False, sort_keys=True))
sys.exit(result['exit_code'])
