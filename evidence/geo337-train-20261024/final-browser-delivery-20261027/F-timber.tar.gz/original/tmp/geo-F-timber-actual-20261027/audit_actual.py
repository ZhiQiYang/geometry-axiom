"""Read one terminated F timber gate; preserve originals, never rerun commands."""
from pathlib import Path
import datetime,hashlib,json,os,stat,traceback
ROOT=Path(__file__).parent;B=Path('/dev/shm/geo337-F9-browsers-20261025');S=B/'Fr27-timber';F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';W=B/'r/rt/original/timber';checks=[];pins={};count=0
H=lambda b:hashlib.sha256(b).hexdigest()
def need(v,msg):
 checks.append((msg,bool(v)))
 if not v:raise AssertionError(msg)
def read(p):
 global count
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode) and not p.is_symlink(),'regular:'+str(p));raw=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'stable:'+str(p));pins[str(p)]=H(raw);count+=len(raw);return raw
def j(p):return json.loads(read(p))
def capture(row):
 need(row['source_sha']==row['acceptance_sha']==F and row['actual_process_returncode']==0 and not row['timeout_expired'],'captured command F/0/not-timeout')
 p=Path(row['directory']);need(j(p/'result.json')==row,'original command row exact')
 for stream in ['stdout','stderr']:
  raw=read(p/(stream+'.bin'));need(len(raw)==row[stream+'_bytes'] and H(raw)==row[stream+'_sha256'],'complete original '+stream)
 raw=read(p/'stdin.bin');need(H(raw)==row['stdin_sha256'],'complete original stdin')

def main():
 need(not(ROOT/'ACTUAL_PEER.json').exists() and not(ROOT/'SELECTION.json').exists(),'fresh audit output')
 outer={k:j(S/'control'/k/'RESULT.json')for k in ['plan','materialize','launch']}
 for k,r in outer.items():
  need(r['source_sha']==F and r['exit_code']==0 and not r['errors'],'root stage true0:'+k)
  for row in r['commands']:capture(row)
 sample=j(S/'sample-original/RESULT.json');launch=j(S/'launch-original/receipt.json');w=j(W/'receipt.json')
 need(sample['source_sha']==launch['source_sha']==w['sha']==F,'one fixed F')
 need(sample['job']==launch['job']==w['job']=='timber','one timber job')
 need(sample['original_process_returncode']==sample['wrapper_exit']==launch['original_primary_exit']==launch['wrapper_exit']==w['exit_code']==0,'true formal/launcher/sampler0')
 need(sample['original_passed'] and launch['passed'] and not sample['errors'] and not sample['sampling_errors'] and sample['sampling_complete'] and not launch['errors'],'complete clean wrappers')
 need(w['ci_timeout_minutes']==20 and w['watchdog_factor']==3 and not w['over_ci_timeout'] and w['seconds']<1200,'original20min preserved')
 need(launch['before_guard']['actual_process_returncode']==launch['after_guard']['actual_process_returncode']==0,'before/after source guards0')
 need(w['checkout_before']==w['checkout_after'] and w['checkout_after']['head']==F and not w['checkout_after']['status'],'original checkout identity preserved')
 need(sample['original_receipt_sha256']==pins[str(S/'launch-original/receipt.json')] and launch['original_receipt_sha256']==pins[str(W/'receipt.json')],'full original receipt chain hashes')
 for row in sample['commands']+launch['commands']:capture(row)
 reaper=[json.loads(x)for x in read(S/'launch-original/reaper.jsonl').splitlines()];done=[r for r in reaper if r.get('event')=='完成'];need(len(done)==1 and reaper[-1]==done[0] and done[0]['primary_returncode']==0,'original reaper true terminal0')
 need(read(W/'receipt.sha256').decode().split()[0]==pins[str(W/'receipt.json')],'original receipt selfhash')
 for rel,meta in w['files'].items():
  need('..'not in Path(rel).parts and not Path(rel).is_absolute(),'workflow file relative')
  raw=read(W/rel);need(len(raw)==meta['bytes'] and H(raw)==meta['sha256'],'workflow original hash:'+rel)
 need(w['workflow_sha256']=='b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d' and w['driver_sha256']=='4cdfe3dd250bc9bba6f8e8a513bbd2007176dc914b60b034b2aa7761e295affd','unchanged workflow/driver')
 versions={}
 for row in w['versions']:
  need(row['exit_code']==row['actual_process_returncode']==0 and not row['watchdog_expired'],'original environment command0')
  versions[' '.join(row['command'])]=read(row['stdout']).decode().strip()
 need(versions['google-chrome --version'].startswith('Google Chrome 156.') and versions['node --version'].startswith('v24.'),'Chrome156/Node24 actual')
 need(any('install ok installed' in v and 'fonts-noto-cjk' in k for k,v in versions.items()),'fonts installed')
 formal_steps=[x for x in w['steps']if 'result'in x];need(len(formal_steps)==2 and all(x['result']['exit_code']==0 and not x['result']['watchdog_expired']for x in formal_steps),'build/browser original steps0')
 stdout=read(W/'steps/03.stdout').decode();lines=stdout.splitlines();results=[x[len('SPACE_RESULT '):]for x in lines if x.startswith('SPACE_RESULT ')];need(len(results)==1,'one current SPACE_RESULT');cdp=json.loads(results[0])
 expected_groups={'setup':2,'timber-material':48,'timber-source-guards':8,'font-layout':19,'browser-health':2}
 included=['timber-material','timber-source-guards','font-layout'];omitted=['space-height-library','projection-lifecycle','projection-placement','space-flow','projection-close']
 need(cdp['schema']=='geometry-space-result/1' and cdp['completed'] and cdp['passed']==79 and cdp['failed']==0 and not cdp['completenessProblems'],'79 original timber assertions0 failed')
 need(cdp['scope']['mode']=='partial' and cdp['scope']['filters']==['GEOMETRY_TIMBER_ONLY'] and cdp['scope']['included']==included and cdp['scope']['omitted']==omitted,'exact original timber partial scope with5existing space group omissions')
 need(set(cdp['groups'])==set(expected_groups) and all(cdp['groups'][k]==dict(expected=n,passed=n,failed=0,completed=True)for k,n in expected_groups.items()),'original fixed census5groups complete without lowered floor')
 need(not cdp['exceptions'] and not cdp['consoleErrors'],'zero original timber browser exceptions/console errors')
 summaries=[x for x in lines if x.startswith('RESULT 79 passed / 0 failed; completed: true; scope: partial; omitted groups: space-height-library,projection-lifecycle,projection-placement,space-flow,projection-close; artifacts: ')];need(len(summaries)==1,'one exact original timber terminal summary')
 artifact_dir=Path(summaries[0].split('; artifacts: ',1)[1]);need(artifact_dir.parent==B/'r/rt/tmp/original/timber/geometry-tests' and artifact_dir.name.startswith('space-model-') and artifact_dir.name.removeprefix('space-model-').isdigit(),'timber artifact path within exact own runtime')
 artifact=j(artifact_dir/'result.json');need(all(artifact[k]==cdp[k]for k in ['scope','completed','groups','completenessProblems','passed','failed','exceptions','consoleErrors']),'full original individual-result document agrees with stdout')
 need(len(artifact['results'])==79 and all(r['ok'] is True and r['group']in expected_groups for r in artifact['results']) and all(sum(r['group']==k for r in artifact['results'])==n for k,n in expected_groups.items()),'all79individual original assertion rows true and counted once per group')
 need(sum(x.startswith('PASS ')for x in lines)==79 and not any(x.startswith('FAIL ')for x in lines),'full stdout79PASS and0FAIL')
 workflow_screens={k:v for k,v in w['files'].items()if k.endswith('.png')};need(len(workflow_screens)==0,'original timber workflow has no screenshot upload action; runtime images retained separately')
 observed=[json.loads(x)for x in read(S/'sample-original/SAMPLES.jsonl').splitlines()];obs=sample['sampled_observations'];need(len(observed)==obs['samples'] and len(observed)>=2 and all(not r['errors']for r in observed),'all original resource samples complete')
 for fs in ['/dev/shm','/workspace','/tmp']:
  rows=[r['filesystems'][fs]for r in observed];s=obs['filesystems'][fs];need(s['minimum_sampled_free_bytes']==min(r['free_bytes']for r in rows) and s['maximum_sampled_filesystem_used_bytes']==max(r['total_bytes']-r['free_bytes']for r in rows),'recomputed sampled mount extrema:'+fs)
 need(obs['maximum_sampled_cgroup_memory_bytes']==max(r['memory.current']for r in observed),'sampled cgroup max')
 need(obs['maximum_observed_gap_seconds']==max(b['monotonic']-a['monotonic']for a,b in zip(observed,observed[1:])),'sampled maximum gap')
 need(all(r['memory.events']['oom']==r['memory.events']['oom_kill']==0 for r in observed),'no sampled OOM')
 for endpoint in ['before','after']:
  own=j(S/('sample-original/OWN_'+endpoint.upper()+'.json'));need(own==sample['own_'+endpoint] and own['unique_allocated_bytes']==sum(x['unique_allocated_bytes']for x in own['roots']),'original own endpoint:'+endpoint)
 need(sample['startup_planning_increment_bytes']==512*1024**2 and sample['startup_planned_total_bytes']==sample['own_before']['unique_allocated_bytes']+512*1024**2<=8*1024**3,'8GiB reversible planning admission')
 cp=j(B/'Fd27/seed-copy-original/RESULT.json');need(cp['source_sha']==F and cp['exit_code']==0 and cp['items']==3759 and cp['new_seed_state']['head']==F and cp['new_seed_state']['status']=='' and cp['original_seed_pool_verifier_zero'],'accepted shared F seed original provenance0')
 before=j(S/'plan/layout/SEED_FREEZE_BEFORE.json');after=j(S/'plan/layout/SEED_FREEZE_AFTER.json');need(before['source']==after['source'] and after['source']['head']==F and all(after[k]for k in ['all_raw_bytes_same','all_original_git_modes_preserved','payload_allocation_reused']),'seed freeze original identity')
 pool=j(S/'plan/layout/POOL_INPUTS.json');need(len(pool)==3759,'full source guard closure3759')
 guard=j(S/'plan/layout/GUARD_LATEST.json');need(guard['passed']and guard['sha']==F and len(guard['checks'])==1 and guard['checks'][0]['inputs']==3759 and guard['checks'][0]['suite']=='timber' and guard['checks'][0]['tree_clean'],'final guard full3759')
 private_git=S/'plan/layout/jobs/timber/gitdir';source=S/'source-layout/jobs/timber/source';golden_rel='geometry-web/cdp_sections.golden.json';golden=source/golden_rel;poolgolden=S/'source-layout/pool'/golden_rel
 golden_row=next(x for x in pool if x['path']==golden_rel);golden_raw=read(golden);need(H(golden_raw)==golden_row['sha256'],'private golden exact original manifest bytes');ga=golden.stat();gb=poolgolden.stat();need((ga.st_dev,ga.st_ino)!=(gb.st_dev,gb.st_ino),'private golden independent from readonly pool')
 need(read(source/'.git').decode().strip()=='gitdir: '+str(private_git),'private git pointer exact');need(read(private_git/'HEAD').decode().strip()==F,'private index HEAD fixedF');index_raw=read(private_git/'index');private_metadata=dict(gitdir=str(private_git),index_sha256=H(index_raw),index_bytes=len(index_raw),golden_sha256=H(golden_raw),golden_comparison_scope='Original timber source golden preserved byte-identically; this SPACE_RESULT suite does not claim a canvas golden comparison')
 scope_contracts={}
 for rel in ['geometry-web/space_model_test.js','geometry-web/space_test_floor.js']:
  row=next(x for x in pool if x['path']==rel);raw=read(source/rel);need(len(raw)==row['bytes'] and H(raw)==row['sha256'],'original source scope/census contract exact:'+rel);scope_contracts[rel]=dict(bytes=len(raw),sha256=H(raw))
 request=j(S/'control/launch/LAUNCH_REQUEST.json');need(request['storage']==str(B/'r/rt') and request['source_sha']==F and hpath(request['source_preparation']['path'])==request['source_preparation']['sha256'],'actual materializer receipt binding')
 # Complete metadata/raw namespaces; do not duplicate public tracked payload or Git object stores.
 plan=j(S/'plan/PLAN.json');tracked={x['path']:x for x in plan['items']};need(len(tracked)==3759,'selected tracked payload3759')
 payload_roots=[S/'source-layout/pool',S/'source-layout/jobs/timber/source'];excluded_counts={str(p):0 for p in payload_roots};files=[];dirs=[];nonregular=[]
 for root in [S,B/'r/rt']:
  stack=[root]
  while stack:
   p=stack.pop()
   st=p.lstat();rel=str(p.relative_to(B));meta=dict(path=str(p),relative_to_browser_OWN=rel,mode=stat.S_IMODE(st.st_mode),raw_mode=st.st_mode,size=st.st_size,mtime_ns=st.st_mtime_ns,device=st.st_dev,inode=st.st_ino,nlink=st.st_nlink)
   if stat.S_ISDIR(st.st_mode):dirs.append(meta);stack.extend(sorted(p.iterdir(),reverse=True))
   elif stat.S_ISREG(st.st_mode):
    match=next((r for r in payload_roots if p.is_relative_to(r) and str(p.relative_to(r))in tracked),None)
    if match is not None:
     rel=str(p.relative_to(match));need(st.st_size==tracked[rel]['bytes'],'tracked payload planned size:'+rel);excluded_counts[str(match)]+=1;continue
    raw=read(p);meta['sha256']=H(raw);meta['allocated_bytes']=st.st_blocks*512;files.append(meta)
   else:
    meta['kind']='symlink'if stat.S_ISLNK(st.st_mode)else 'socket'if stat.S_ISSOCK(st.st_mode)else 'other';meta['link_target']=os.readlink(p)if stat.S_ISLNK(st.st_mode)else None;nonregular.append(meta)
 need(all(n==3759 for n in excluded_counts.values()),'only exact3759 tracked payload omitted per actual source copy')
 screens={str(Path(x['path']).relative_to(B/'r/rt')):dict(bytes=x['size'],sha256=x['sha256'])for x in files if Path(x['path']).is_relative_to(B/'r/rt') and x['path'].endswith('.png')};need(len(screens)==10,'all10original timber runtime PNGs selected with fullbyte hashes')
 need(set(screens)=={str(p.relative_to(B/'r/rt'))for p in artifact_dir.glob('*.png')},'timber runtime screenshot namespace exactly covered by selection')
 selection=dict(schema='fixed-F-timber-complete-raw-selection/2',source_sha=F,roots=[str(S),str(B/'r/rt')],files=files,directories=dirs,nonregular_metadata_only=nonregular,excluded_tracked_payload=dict(plan=str(S/'plan/PLAN.json'),plan_sha256=hpath(S/'plan/PLAN.json'),path_set=list(tracked),per_copy_counts=excluded_counts,rule='Omit only regular leaf matching exact original PLAN tracked payload path and size. Source .git, ignored or any other leaf plus every directory is retained. No physical deletion; original full byte guards remain mandatory.'),shared_seed_provenance=dict(path=str(B/'Fd27/seed-copy-original/RESULT.json'),sha256=hpath(B/'Fd27/seed-copy-original/RESULT.json'),already_owned_by_separate_seed_acceptance=True),git_objects_policy='No external object provider traversal or duplicate tracked source payload. Private Git metadata and objects/info/alternates text are selected.',logical_bytes=sum(x['size']for x in files),regular_files=len(files),directory_count=len(dirs),no_deletion=True)
 (ROOT/'SELECTION.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
 result=dict(schema='F-timber-formal-actual-peer/2',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha=F,exit_code=0,blocking_findings=[],checks=len(checks),original_formal_exit=0,outer_control_exit=0,formal_assertions=cdp,original_started=w['started'],original_ended=w['ended'],original_seconds=w['seconds'],original_ci_minutes=20,over_ci_timeout=False,assertion_skips=0,allowed_omitted_groups=omitted,omitted_group_count=5,scope_contracts=scope_contracts,original_versions=versions,private_metadata=private_metadata,original_screenshots=screens,workflow_screenshot_count=0,runtime_screenshot_count=10,workflow_original_files=len(w['files']),source_guard_leaf_count=3759,original_seed_copy_source_index_sha256=cp['original_index_sha256'],sampled_observations=obs,own_before=sample['own_before'],own_after=sample['own_after'],selection=dict(path=str(ROOT/'SELECTION.json'),sha256=hpath(ROOT/'SELECTION.json'),regular_files=len(files),logical_bytes=selection['logical_bytes'],nonregular_count=len(nonregular)),raw_bytes_read=count,limits=['Formal result refers only to fixed F timber job with original5space-group omissions; other browser rows are separate.','Original GitHub checkout/upload actions are represented by exact clean checkout/local artifact preservation; apt install verified as already installed.','Complete job command/raw/screenshot/source-identity namespaces included. Only exact3759 tracked regular payload leaves are omitted per source copy; .git and all other leaves/directories remain selected. Shared seed acceptance is referenced by exact receipt hash, not rerun or redundantly repackaged.','Resource samples are shared mount/cgroup observations, not exact peaks or performance evidence.','Root tool session21730/chunkc5eb9d exit0 was communicated by parent; independent audit verifies actual persisted control/subprocess/reaper originals, not inherited process handles.','Remote package delivery is separate; no test or guard was rerun and no file deleted.'])
 (ROOT/'ACTUAL_PEER.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(exit_code=0,checks=len(checks),assertions=79,screenshots=10,omitted_groups=5,seconds=w['seconds'],selection_files=len(files),selection_bytes=selection['logical_bytes'],peer_sha256=hpath(ROOT/'ACTUAL_PEER.json'))))
def hpath(p):return H(Path(p).read_bytes())
if __name__=='__main__':main()
