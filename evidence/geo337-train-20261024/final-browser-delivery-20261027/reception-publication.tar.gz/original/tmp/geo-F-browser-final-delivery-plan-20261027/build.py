#!/usr/bin/env python3
"""Build exactly frozen natural archives in one fresh owned SHM sibling; never publish."""
import pathlib,json,hashlib,tarfile,gzip,io,os,stat,time,sys,traceback,importlib.util
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('plan_helpers',ROOT/'prepare.py');helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
OWN=helpers.OWN;BOWN=helpers.BOWN
OUT=OWN/'final-browser-delivery-20261027'
RESERVE=67108864

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def allocated(roots):
 total=0;seen=set()
 for root in roots:
  for cur,dirs,files in os.walk(root,followlinks=False):
   for p in [pathlib.Path(cur)]+[pathlib.Path(cur)/n for n in files]+[pathlib.Path(cur)/n for n in dirs if (pathlib.Path(cur)/n).is_symlink()]:
    s=p.lstat();key=(s.st_dev,s.st_ino)
    if key not in seen:seen.add(key);total+=s.st_blocks*512
 return total

def observation():
 d={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'two_OWN_allocated':allocated([OWN,BOWN]),'mounts':{},'cgroup':{}}
 for p in [str(OWN),str(BOWN),'/tmp']:
  s=os.statvfs(p);d['mounts'][p]={'available_bytes':s.f_bavail*s.f_frsize,'total_bytes':s.f_blocks*s.f_frsize,'device':os.stat(p).st_dev}
 for p in ['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.stat','/sys/fs/cgroup/memory.events','/sys/fs/cgroup/memory.pressure','/proc/pressure/memory']:
  try:d['cgroup'][p]={'available':True,'text':pathlib.Path(p).read_text()}
  except OSError as e:d['cgroup'][p]={'available':False,'error':type(e).__name__,'errno':e.errno}
 return d

def validate(r):
 s=pathlib.Path(r['path']).lstat()
 assert stat.S_ISREG(s.st_mode),('not regular',r['path'])
 for key,v in [('size',s.st_size),('mode',stat.S_IMODE(s.st_mode)),('device',s.st_dev),('inode',s.st_ino),('mtime_ns',s.st_mtime_ns),('nlink',s.st_nlink)]:
  assert r[key]==v,('source drift',r['path'],key,r[key],v)
 return s
class HashReader:
 def __init__(self,f):self.f=f;self.h=hashlib.sha256();self.n=0
 def read(self,n=-1):
  b=self.f.read(n);self.h.update(b);self.n+=len(b);return b

def build_one(g):
 files={r['path']:r for r in g['files']};dirs={r['path']:r for r in g['directories']};non={r['path']:r for r in g['nonregular']}
 gg=dict(g,files=files,directories=dirs,nonregular=non);idx=helpers.frozen_index(gg)
 dest=OUT/(g['name']+'.tar.gz')
 hashes={};expected={}
 with dest.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
   with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
    for r in idx['directories']:
     name='original/'+r['path'].lstrip('/');tf.addfile(helpers.tarinfo(name,directory=True));expected[name]='dir'
    for r in g['files']:
     validate(r)
     with open(r['path'],'rb') as f:
      # Identity checked again on open FD to avoid following a replaced symlink.
      s=os.fstat(f.fileno());assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],r['size'],r['mtime_ns'])
      hr=HashReader(f);tf.addfile(helpers.tarinfo(r['archive_name'],r['size']),hr)
      assert hr.n==r['size'];h=hr.h.hexdigest();assert r['sha256'] is None or h==r['sha256'],('audited hash mismatch',r['path'])
      assert f.read(1)==b''
     validate(r);hashes[r['path']]=h;expected[r['archive_name']]={'size':r['size'],'sha256':h}
    for r in idx['files']:r['sha256']=hashes[r['path']]
    ib=helpers.data(idx);assert len(ib)==g['bounds']['index_bytes'];tf.addfile(helpers.tarinfo('INDEX.json',len(ib)),io.BytesIO(ib));expected['INDEX.json']={'size':len(ib),'sha256':hashlib.sha256(ib).hexdigest()}
  raw.flush();os.fsync(raw.fileno())
 assert dest.stat().st_size<=g['bounds']['gzip_worst_bytes']<helpers.LIMIT
 # Independent streamed roundtrip, no extraction/scratch copy.
 seen=set();uncompressed=0
 with gzip.open(dest,'rb') as gz:
  with tarfile.open(fileobj=gz,mode='r|') as tf:
   for m in tf:
    assert m.name in expected and m.name not in seen,('unexpected/duplicate tar member',m.name);seen.add(m.name);e=expected[m.name]
    if e=='dir':assert m.isdir();continue
    assert m.isfile() and m.size==e['size'];h=hashlib.sha256();n=0
    f=tf.extractfile(m)
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b);n+=len(b)
    assert n==e['size'] and h.hexdigest()==e['sha256'],('roundtrip mismatch',m.name)
  # Tarfile stream may buffer padding, so exact total checked in a separate gzip byte stream below.
 assert seen==set(expected)
 with gzip.open(dest,'rb') as gz:
  for b in iter(lambda:gz.read(1024*1024),b''):uncompressed+=len(b)
 assert uncompressed==g['bounds']['tar_exact_bytes'],('tar bound mismatch',g['name'],uncompressed,g['bounds']['tar_exact_bytes'])
 return {'name':g['name'],'path':str(dest),'size':dest.stat().st_size,'sha256':digest(dest),'index_sha256':hashlib.sha256(ib).hexdigest(),'roundtrip_exit':0,'members':len(seen),'regular_original_files':len(g['files']),'original_bytes':sum(r['size'] for r in g['files']),'tar_bytes':uncompressed,'source_sha':g['source_sha']}

def main():
 assert len(sys.argv)==2,'Pass reviewed PLAN SHA256'
 planp=ROOT/'FINAL_PLAN.json';assert digest(planp)==sys.argv[1]
 plan=json.loads(planp.read_text());cost=json.loads((ROOT/'FINAL_COST.json').read_text());assert cost['plan_sha256']==sys.argv[1]
 assert not OUT.exists(),('output exists; no overwrite/retry',str(OUT))
 obs=observation();inc=cost['incremental_total_upper'];assert obs['two_OWN_allocated']+inc<=cost['planning_cap_two_OWN'],('planning cap insufficient',obs['two_OWN_allocated'],inc)
 assert obs['mounts'][str(OWN)]['available_bytes']>=inc,('physical SHM insufficient',obs['mounts'][str(OWN)],inc)
 assert cost['incremental_total_upper']>=cost['original_3P_plus_L65536_plus_M8_plus64MiB']
 # Compression/roundtrip bounded buffers (<64MiB); actual memory observation and missing PSI preserved.
 cg=obs['cgroup'];cur=int(cg['/sys/fs/cgroup/memory.current']['text']);mx=cg['/sys/fs/cgroup/memory.max']['text'].strip();memstat=dict(x.split() for x in cg['/sys/fs/cgroup/memory.stat']['text'].splitlines());clean=max(0,int(memstat.get('inactive_file','0'))-int(memstat.get('file_dirty','0'))-int(memstat.get('file_writeback','0')))
 if mx!='max':assert int(mx)-cur+clean>=RESERVE,('insufficient memory headroom plus reclaimable inactive file',cur,mx,clean)
 OUT.mkdir(mode=0o700);(OUT/'ADMISSION.json').write_bytes(helpers.data({'observation':obs,'cost_sha256':digest(ROOT/'FINAL_COST.json'),'incremental_reservation':inc,'planning_cap_bytes':cost['planning_cap_two_OWN'],'memory_working_upper':RESERVE,'scope':'Only archive build now; reserved full later no-fetch publication, no source gate concurrent.'}))
 result={'schema':1,'plan_sha256':sys.argv[1],'evidence_parent':plan['evidence_parent'],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'exit_code':1,'archives':[],'aliases':plan['aliases'],'no_publish':True,'no_delete':True}
 try:
  for g in plan['groups']:
   r=build_one(g);result['archives'].append(r);(OUT/'RESULT.json').write_bytes(helpers.data(result));print(json.dumps(r),flush=True)
  result['exit_code']=0
 except BaseException as e:result['failure']=repr(e);result['traceback']=traceback.format_exc();raise
 finally:
  result['ended_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());result['after_observation']=observation();(OUT/'RESULT.json').write_bytes(helpers.data(result));print(json.dumps({'exit_code':result['exit_code'],'result':str(OUT/'RESULT.json')}),flush=True)
if __name__=='__main__':main()
