# 下一束證據：靜態範圍與峰值規劃

固定正式來源 F=`cbf0fb621888596aa14ad5f2349b503e23b1b72d`；候選證據父 E=`e5da59b7e570a360f99ee07e2194c938da0c2626`。這份只是靜態準備，沒有封包、發布、重跑正式驗收或讀取正在執行的 canvas 原件。

| 自然範圍 | 精確選取／狀態 | 原件 bytes | 暫估 gzip 最壞上界 |
|---|---|---:|---:|
| F-space | 624 regular／792 dirs；原正式與一次核收皆0；另收全部7個本地小工具／收據檔 | 43,084,061 | 48,327,109 |
| F-timber | 599 regular／792 dirs；原正式與一次核收皆0；另收全部6個本地小工具／收據檔 | 34,671,214 | 39,866,288 |
| 六包發布原流＋本地native接收peer/tool | 69命令、207已核原流；15份stdout走immutable blob引用，production Git objects留原地 | 898,304 新payload | 3,738,785 |
| F canvas | root91441 正式執行中；終態／一次核收／selection待定 | 未知 | 未知 |

上界以原始tar／PAX headers、每包2MiB INDEX預留及gzip最壞膨脹計算，不假設壓縮收益；最終exact INDEX需重算並由peer確認。space／timber與發布收據的已知各包均低於100MiB。canvas未有原件清單，不能先宣稱整束可准入。

## 原件保全與避免重複payload

15份剛發布的遠端stdout合計 **100,217,727 bytes**。STATIC_PLAN逐份列原始capture path、固定E、遠端原path、完整Git OID、size與SHA256。下一個commit為它們增加原始stdout的新tree葉，指向同一immutable blob；引用E′已完成逐byte readback及獨立207stream核收，確認新tree/path→同OID，不再複製或下載同一批payload。原本地streams仍保留。其餘完整命令、stdin、stdout、stderr、manifest、executed tool、provider before/after、實際peer一併收；Git objects不遍歷、不刪除。

外部native只連固定E=`732ef20e34876379a37eb69693a481becebea43e`的NATIVE_HANDOFF及原件；本地僅收RECEPTION_PEER.json、review_native.py、NATIVE_RECEPTION_STATIC_PEER.json三小檔。**不重包19份遠端原件、remote manifest、ELF或producer tarballs**。我方尚未直接讀兩個producer tarball內容的限制照實保留。

## 一次封包／發布的峰值方法

僅已知space＋timber＋發布收據的保守新增預留為 **539,761,638 bytes**，**不含canvas與新E7886接收review總量，不是整束准入結果**。完整P必須加入canvas最終封包最壞上界與16MiB小metadata預留。

以fresh兩OWN實際配置B為起點，逐項加：新archives生成、新loose、可能outgoing pack、全部**新**payload完整遠端readback、Git metadata／command streams、state，以及原64MiB保留。與原`3P+L*65536+M*8+67108864`取較大值；B＋完整增量≤8GiB，且實際工作掛載free充足，才可執行。既有原件／100MB readback／新舊Git objects已在B，不重算也不假設會刪除。

先等canvas真終態，接著一次核收／selection，再凍結整束並peer。沒有正式重測同跑時，一次串流封包、roundtrip與獨立hash；再一次普通no-fetch快進發布。新的hash-object仍以原檔argv讀取，stdin不複製payload；若改傳輸方式必須重算。缺失PSI記unavailable，不能視為零壓力；不改mount／quota／產品時限或斷言。

## 尚未完成

- canvas真終態、一次完整核收與exact selection；未讀其活動namespace。
- canvas單blob最壞上界。若超100MiB，先按自然原件類別提出分包，不拆已封存舊包，不倚賴壓縮率。
- 最終fresh實體容量／cgroup觀測與整束准入；現在不能把部分預算當全流程可行。
- 從單alias發布工具調整為精確15alias、精確paths／ordinary push／新blob完整遠端驗證，需獨立審查；這份規劃沒有可執行發布工具。
- 主代理確認當時證據父／分支與一般合流狀態後才固定manifest；來源F保持分列。
- 外部Reading A／RC／reader／required-eight已發布E=`7886f2eaa3da7f9f4855104ca4b028d2d06ce6da`；主代理在`/tmp/geo338-reading-a-reception-20261027`窄核收中。後續僅收完成的我方review／tool／meta小檔，exact清單與bytes未定、尚未納成本，不重包原137檔；不由發布通知推定核收完成。PF3由外部owner執行，未臆測終態。

沒有更新PR正文。
