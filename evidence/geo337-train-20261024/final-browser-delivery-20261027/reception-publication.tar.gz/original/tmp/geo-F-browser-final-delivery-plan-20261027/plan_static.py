#!/usr/bin/env python3
"""Metadata-only planning during exclusive canvas execution. Never package or publish."""
import pathlib,json,hashlib,os,stat,tarfile,math
ROOT=pathlib.Path('/tmp/geo-F-browser-final-delivery-plan-20261027')
PUB=pathlib.Path('/dev/shm/geometry-axiom-geo337-20261025/recovery-bundle-20261027/git-publication')
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';E='e5da59b7e570a360f99ee07e2194c938da0c2626';NATIVE='732ef20e34876379a37eb69693a481becebea43e'
PREFIX='evidence/geo337-train-20261024/final-browser-delivery-20261027/'
def js(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def smallhash(p):
 p=pathlib.Path(p);assert p.stat().st_size<2*1024**2,('not small metadata',str(p));return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 p=pathlib.Path(p);s=p.lstat();d={'path':str(p),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'raw_mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'device':s.st_dev,'inode':s.st_ino}
 if stat.S_ISLNK(s.st_mode):d['link_target']=os.readlink(p)
 return d

def basic_tar_bound(files,dirs,index_allowance):
 total=0
 for r in files:
  t=tarfile.TarInfo('original/'+r['path'].lstrip('/'));t.size=r['size'];t.mtime=0;t.mode=0o644
  total+=len(t.tobuf(format=tarfile.PAX_FORMAT))+512*((r['size']+511)//512)
 for r in dirs:
  t=tarfile.TarInfo('original/'+r['path'].lstrip('/'));t.type=tarfile.DIRTYPE;t.mode=0o755;t.mtime=0
  total+=len(t.tobuf(format=tarfile.PAX_FORMAT))
 t=tarfile.TarInfo('INDEX.json');t.size=index_allowance;total+=len(t.tobuf(format=tarfile.PAX_FORMAT))+512*((index_allowance+511)//512)+1024
 raw=((total+10239)//10240)*10240;gz=raw+(raw>>12)+(raw>>14)+(raw>>25)+45
 return {'uncompressed_tar_upper':raw,'gzip_worst_upper':gz,'reserved_index_bytes':index_allowance,'single_blob_limit':104857600,'below_limit':gz<104857600,'qualification':'Preliminary safe INDEX allowance; final frozen exact index/tar bound and peer required before any archive.'}

spec={'schema':1,'mode':'STATIC_ONLY_NO_ARCHIVE_NO_API','formal_source':F,'candidate_evidence_parent':E,'next_branch':'codex/train337-recovered-evidence-20261026','groups':[],'canvas':{'status':'RUNNING root91441, no terminal/selection inspected','source_sha':F,'selection_path':None,'regular_files':None,'raw_bytes':None,'archive_bound':None,'admission':'UNKNOWN until terminal, one actual audit and exact selection'},'exclusions':['Never scan/read active canvas namespaces.','Never archive production Git objects; retain them untouched.','Never repackage any existing six archive or prior card archive.','Native 19 fetched originals, remote manifest, ELF and original archive payloads remain outside this bundle; fixed external E references only.']}
for name in ['space','timber']:
 droot=pathlib.Path('/tmp/geo-F-'+name+'-actual-20261027');sel=json.loads((droot/'SELECTION.json').read_bytes());audit=json.loads((droot/'ACTUAL_PEER.json').read_bytes())
 assert sel['source_sha']==F and audit['exit_code']==0
 tools=[info(p) for p in sorted(droot.iterdir()) if p.is_file()];payload=sel['files']+tools;dirs=sel['directories']+[info(droot)]
 # Selection and exact tool metadata are referenced, not recopied into this small plan.
 spec['groups'].append({'name':'F-'+name,'status':'FORMAL0_ACTUAL_AUDIT0_UNPUBLISHED','selection':str(droot/'SELECTION.json'),'selection_sha256':smallhash(droot/'SELECTION.json'),'actual_peer':str(droot/'ACTUAL_PEER.json'),'actual_peer_sha256':smallhash(droot/'ACTUAL_PEER.json'),'selected_original_files':len(sel['files']),'selected_original_bytes':sum(r['size'] for r in sel['files']),'selected_directories':len(sel['directories']),'nonregular_metadata_only':len(sel['nonregular_metadata_only']),'tool_files':tools,'planned_regular_files':len(payload),'planned_logical_bytes':sum(r['size'] for r in payload),'preliminary_bounds':basic_tar_bound(payload,dirs,2*1024**2),'formal_seconds':audit['original_seconds'],'assertions':audit['formal_assertions']['passed'],'allowed_original_omissions':audit['allowed_omitted_groups'],'scope':'Exact audited selection only; exclude only exact3759 tracked leaves per source copy, preserve .git and all ignored/runtime/dirs. No payload read/hash by this planner.'})

m=json.loads((PUB/'MANIFEST.json').read_bytes());pr=json.loads((PUB/'RESULT.json').read_bytes());cmds=json.loads((PUB/'subcommands.json').read_bytes());byoid={x['git_blob']:x for x in m['files']}
assert pr['exit_code']==0 and pr['commit']==E
aliases=[]
for row in cmds:
 c=row['command']
 if c[0]=='gh' and c[-1].startswith('repos/ZhiQiYang/geometry-axiom/git/blobs/'):
  blob=c[-1].rsplit('/',1)[1];known=byoid[blob];assert row['stdout_bytes']==known['size'] and row['stdout_sha256']==known['sha256']
  raw=pathlib.Path(row['directory'])/'stdout.bin'
  aliases.append({'original_path':str(raw),'new_leaf':PREFIX+'six-bundle-publication/raw/subcommands/'+pathlib.Path(row['directory']).name+'/stdout.bin','size':known['size'],'sha256':known['sha256'],'git_blob':blob,'fixed_commit':E,'fixed_public_path':known['destination'],'proof':'Eprime prior full raw byte readback+independent207stream audit; next new tree/path must bind same immutable OID. No duplicate payload copy or download.'})
assert len(aliases)==15 and sum(a['size'] for a in aliases)==100217727
aliaspaths={x['original_path'] for x in aliases};rawfiles=[];rawdirs=[];nonregular=[];excluded=[]
for cur,dirs,files in os.walk(PUB,followlinks=False):
 p=pathlib.Path(cur)
 if p.name=='objects' and p.parent.name=='repo.git':
  excluded.append({'path':str(p),'policy':'All production Git object payloads retained in place; not traversed, copied or hashed.'});dirs[:]=[];files[:]=[];continue
 rawdirs.append(info(p))
 for n in sorted(files):
  q=p/n
  if str(q) in aliaspaths:continue
  r=info(q)
  if stat.S_ISREG(r['raw_mode']):rawfiles.append(r)
  else:nonregular.append(r)
# Retain alternates text as a small semantic source link; no Git object traversal.
a=PUB/'repo.git/objects/info/alternates';rawfiles.append(info(a))
extra=[pathlib.Path('/tmp/geo-next-bundle-plan-20261027')/n for n in ['PUBLICATION_ACTUAL_PEER.json','audit_publication.py','PUBLISH_CHECK_OBSERVATION.json','make_manifest.py']]
extra += [pathlib.Path('/tmp/geo338-native-reception-peer-20261027')/n for n in ['RECEPTION_PEER.json','review_native.py','NATIVE_RECEPTION_STATIC_PEER.json']]
extra_rows=[dict(info(p),sha256=smallhash(p)) for p in extra]
spec['publication_receipt']={'status':'FORMAL_PUBLISH0_ACTUAL_AUDIT0_UNPUBLISHED_RECEIPT','source_root':str(PUB),'published_evidence_head':E,'source_files':rawfiles,'directories':rawdirs,'nonregular_metadata_only':nonregular,'excluded_objects':excluded,'aliases':aliases,'aliased_full_bytes_not_copied':sum(a['size'] for a in aliases),'commands':len(cmds),'independently_verified_streams':207,'extra_small_files':extra_rows,'planned_regular_files':len(rawfiles)+len(extra_rows),'planned_logical_bytes':sum(r['size'] for r in rawfiles+extra_rows),'preliminary_bounds':basic_tar_bound(rawfiles+extra_rows,rawdirs,2*1024**2)}
spec['native']={'status':'EXTERNAL_FORMAL0_RECEPTION_PEER0','fixed_evidence_commit':NATIVE,'fixed_handoff_path':'evidence/geo337-native-validation-20261027/audit/NATIVE_HANDOFF.md','only_local_payloads':[str(p) for p in extra if 'native-reception-peer' in str(p)],'no_19_remote_originals_or_ELF_copy':True,'peer_limits':'Two producer tarballs not fetched/read by local receiver; explicitly link fixed external original evidence and keep this limitation.'}
known=sum(g['preliminary_bounds']['gzip_worst_upper'] for g in spec['groups'])+spec['publication_receipt']['preliminary_bounds']['gzip_worst_upper']
# metadata allowance for new plan/index/PROGRESS/peer/receipt, subject to final actual leaf/M checks.
Pknown=known+16*1024**2
z=Pknown+(Pknown>>12)+(Pknown>>14)+(Pknown>>25)+45
parts={'create_known_archives_and_metadata':Pknown,'new_loose_zlib_bound_known':z,'possible_outgoing_pack_known':z+16*1024**2,'complete_remote_readback_new_known':Pknown,'git_trees_and_command_streams':16*1024**2,'state_manifest':4*1024**2,'original_publication_reserve':67108864}
spec['resource_plan']={'not_admission':True,'known_groups_archive_upper':known,'known_P_with_metadata_allowance':Pknown,'unknown_canvas_archive_upper_C':None,'known_incremental_component_sum':sum(parts.values()),'known_components':parts,'planning_cap_two_OWN_bytes':8*1024**3,'original_formula':'3P+L*65536+M*8+67108864','L_preliminary_upper':32,'M_preliminary_upper':65536,'P_definition':'sum(final new archive worst upper)+16MiB metadata; 15 existing aliases add zero payload bytes; C for canvas is currently unknown','final_peak_rule':'Fresh B + archive creation + new loose + possible outgoing pack + full NEW payload readback + metadata/state + original64MiB reserve <=8GiB AND actual working mount free >= increment; take max with original full3P formula. No credit for deleting or compressing originals.','hash_object_mode':'Source argv paths only; no payload stdin/base64 copy. Changed transport requires another full-P budget before execution.','memory':'Bounded streaming tar/roundtrip first; publisher working estimate 2*actualP+128MiB with fresh host/cgroup observations; missing PSI unavailable, never zero.','unknowns':['Canvas terminal/audit/exact selection and exact tar bounds.','Actual global allocation after exclusive canvas; planning cap is not physical free.','Final candidate parent/ref after branch adoption coordination.','Final manifest actual P/L/M and SHA pins, no pre-approval of execute.'],'execution_order':['Keep canvas exclusive until its real terminal.','Perform one complete canvas audit/selection.','Freeze all exact inputs and peer small scope/cost diff.','Fresh real SHM/8GiB/cgroup admission before one deterministic archive build; no formal gate concurrent.','One full streamed roundtrip and independent archive hash audit, preserve all source/raw.','One ordinary no-fetch fast-forward commit; full remote raw verification of every NEW payload; existing15 aliases only new tree/path to same old OID proof.','Persist actual publication peer without repack or repeat API.'],'no_archive_built_by_this_plan':True}
(ROOT/'STATIC_PLAN.json').write_bytes(js(spec));print(json.dumps({'exit_code':0,'groups':[(g['name'],g['planned_logical_bytes'],g['preliminary_bounds']['gzip_worst_upper']) for g in spec['groups']],'receipt_bytes':spec['publication_receipt']['planned_logical_bytes'],'aliases':len(aliases),'avoided_duplicate_bytes':sum(a['size'] for a in aliases),'known_incremental_lower_slice':sum(parts.values()),'canvas_bound':'UNKNOWN'}))
if __name__=='__main__':pass
