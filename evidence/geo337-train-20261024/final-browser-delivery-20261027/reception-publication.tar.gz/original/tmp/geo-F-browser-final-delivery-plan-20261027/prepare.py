#!/usr/bin/env python3
"""Read-only natural-group inventory. No archive, fetch, push, deletion or product run."""
import os,stat,json,hashlib,tarfile,pathlib,math,time
ROOT=pathlib.Path('/tmp/geo-F-browser-final-delivery-plan-20261027')
OWN=pathlib.Path('/dev/shm/geometry-axiom-geo337-20261025')
BOWN=pathlib.Path('/dev/shm/geo337-F9-browsers-20261025')
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
W='a4bd77e8090f5a82f0c8934c30c5335782293922'
E='e5da59b7e570a360f99ee07e2194c938da0c2626'
LIMIT=100*1024*1024
HASH='0'*64
GROUPS={}
def data(v):return (json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def sh(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def group(name,source):
 d={'name':name,'source_sha':source,'files':{},'directories':{},'nonregular':{},'excluded':[],'selection_sources':[]};GROUPS[name]=d;return d
def meta(p):
 s=p.lstat();r={'path':str(p),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'raw_mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
 if stat.S_ISLNK(s.st_mode):r['link_target']=os.readlink(p)
 return r
INPUTS=json.loads((ROOT/'FIXED_INPUTS.json').read_text())
ALIASES={r['original_path']:r for r in INPUTS['aliases']}
def add(g,p,known=None):
 p=pathlib.Path(p);r=meta(p)
 if known:
  for k in ['size','mtime_ns','device','inode']:
   if k in known:assert r[k]==known[k],('selection source changed',str(p),k,r[k],known[k])
 if str(p) in ALIASES:
  alias=ALIASES[str(p)];assert r['size']==alias['size'];g['excluded'].append({'metadata':r,'reason':'Full original remote stdout retained via new tree/path pointing to already-public immutable blob; prior complete readback and independent207stream audit prove bytes. No duplicate copy/download.','alias':alias});return
 mode=r['raw_mode']
 if stat.S_ISREG(mode):
  r['archive_name']='original/'+str(p).lstrip('/');r['sha256']=known.get('sha256') if known else None
  g['files'][str(p)]=r
 elif stat.S_ISDIR(mode):g['directories'][str(p)]=r
 else:g['nonregular'][str(p)]=r

def tree(g,p,production=False):
 p=pathlib.Path(p);assert p.exists(),str(p)
 def visit(q):
  if production and q.name=='objects' and q.parent.name=='repo.git':
   # Retain precise objects metadata only, never payload-copy/hash a pack.
   excluded=[]
   for cur,dirs,files in os.walk(q,followlinks=False):
    for n in sorted(dirs+files):
     a=pathlib.Path(cur)/n
     if a==q/'info/alternates':add(g,a)
     else:excluded.append(meta(a))
   g['excluded'].append({'metadata':meta(q),'reason':'Production Git object payload remains untouched in its original repo; not duplicate evidence or rehash large packs. Raw command streams, verify-pack output and provider snapshots retained.','descendant_metadata':excluded});return
  add(g,q)
  if stat.S_ISDIR(q.lstat().st_mode):
   for ch in sorted(q.iterdir()):visit(ch)
 visit(p)

def selection(g,p):
 p=pathlib.Path(p);d=json.loads(p.read_text());g['selection_sources'].append({'path':str(p),'sha256':sh(p),'source_sha':d.get('source_sha'),'regular_files':len(d['files'])})
 for r in d['files']:add(g,r['path'],r)
 for r in d['directories']:
  # Original directory times may change without any selected leaf changing. Pin fresh metadata, preserve prior original record in source selection file.
  add(g,r['path'])
 for r in d.get('nonregular_metadata_only',[]):add(g,r['path'])

def tarinfo(name,size=0,directory=False):
 t=tarfile.TarInfo(name);t.size=size;t.mtime=0;t.uid=t.gid=0;t.uname=t.gname='';t.mode=0o755 if directory else 0o644
 if directory:t.type=tarfile.DIRTYPE;t.size=0
 return t

def frozen_index(g):
 return {'schema':1,'name':g['name'],'source_sha':g['source_sha'],'evidence_parent':E,'files':[dict(r,sha256=r['sha256'] or HASH) for r in sorted(g['files'].values(),key=lambda r:r['path'])],'directories':sorted(g['directories'].values(),key=lambda r:r['path']),'nonregular_metadata_only':sorted(g['nonregular'].values(),key=lambda r:r['path']),'excluded':g['excluded'],'selection_sources':g['selection_sources'],'policy':'All selected original regular bytes included with SHA256. Nonregular entries metadata only, never followed. Original empty directory metadata retained and normalized directory tar members present. No source payload outside exact prior audited selections.'}

def bounds(g):
 idx=data(frozen_index(g));n=0
 for r in g['files'].values():n+=len(tarinfo(r['archive_name'],r['size']).tobuf(format=tarfile.PAX_FORMAT))+((r['size']+511)//512)*512
 for r in g['directories'].values():n+=len(tarinfo('original/'+r['path'].lstrip('/'),directory=True).tobuf(format=tarfile.PAX_FORMAT))
 n+=len(tarinfo('INDEX.json',len(idx)).tobuf(format=tarfile.PAX_FORMAT))+((len(idx)+511)//512)*512+1024
 tar=((n+10239)//10240)*10240
 # zlib compressBound + gzip wrapper allowance; no compression savings assumed.
 gz=tar+(tar>>12)+(tar>>14)+(tar>>25)+13+32
 assert gz<LIMIT,(g['name'],'GitHub blob bound',gz,LIMIT)
 return {'regular_files':len(g['files']),'original_bytes':sum(r['size'] for r in g['files'].values()),'directories':len(g['directories']),'nonregular_metadata_only':len(g['nonregular']),'index_bytes':len(idx),'tar_exact_bytes':tar,'gzip_worst_bytes':gz,'blob_limit_bytes':LIMIT}

def main():
 assert INPUTS['parent']==E and INPUTS['source_sha']==F
 for name,root in INPUTS['selection_roots'].items():
  g=group('F-'+name,F);selection(g,pathlib.Path(root)/'SELECTION.json');tree(g,root)
 g=group('reception-publication',F);tree(g,INPUTS['publication_root'],production=True)
 for row in INPUTS['extra_files']:
  assert pathlib.Path(row['path']).stat().st_size==row['size'] and sh(row['path'])==row['sha256'],'frozen small receipt drift'
  add(g,row['path'],row)
 for p in INPUTS['extra_trees']:tree(g,p)
 for name in ['prepare.py','build.py','FIXED_INPUTS.json','STATIC_PLAN.json','PLAN.md','STATIC_PEER.json','STATIC_REVIEW_INITIAL_FAILURE.json','plan_static.py']:
  p=ROOT/name
  if p.exists():add(g,p)
 plan={'schema':2,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'evidence_parent':E,'formal_source':F,'aliases':list(ALIASES.values()),'external_links':INPUTS['external_links'],'groups':[],'policy':'One evidence commit with three full-browser natural archives and one small reception/publication archive. No formal rerun/deletion/fetch/repack.15 existing full stdout payloads via immutable blob alias; native19/ReadingA112-or137 remote originals stay external, only explicit small receptions and new golden-driver capture.'}
 for g in GROUPS.values():
  g['bounds']=bounds(g);g['files']=list(sorted(g['files'].values(),key=lambda r:r['path']));g['directories']=list(sorted(g['directories'].values(),key=lambda r:r['path']));g['nonregular']=list(sorted(g['nonregular'].values(),key=lambda r:r['path']));plan['groups'].append(g)
 (ROOT/'FINAL_PLAN.json').write_bytes(data(plan));budgets=[{'name':g['name'],**g['bounds']} for g in plan['groups']]
 packet=sum(x['gzip_worst_bytes']for x in budgets)+16*1024**2;L=32;M=65536
 original=3*packet+L*65536+M*8+67108864
 z=packet+(packet>>12)+(packet>>14)+(packet>>25)+45
 parts={'archive_and_small_payload_creation':packet,'new_loose_zlib_bound':z,'outgoing_pack_bound':z+16*1024**2,'complete_NEW_remote_readback':packet,'new_trees_metadata_command_streams':16*1024**2,'state_manifest':4*1024**2,'original_publication_reserve':67108864}
 cost={'schema':2,'plan_sha256':sh(ROOT/'FINAL_PLAN.json'),'bounds':budgets,'P_upper':packet,'L_upper':L,'M_upper':M,'original_3P_plus_L65536_plus_M8_plus64MiB':original,'explicit_incremental_allocated_upper':parts,'incremental_total_upper':sum(parts.values()),'planning_cap_two_OWN':8*1024**3,'physical_and_cgroup_fresh_observation_required_at_execution':True,'alias_additional_payload_bytes':0,'alias_count':15,'aliased_original_bytes':sum(x['size']for x in ALIASES.values()),'notes':['Current existing raw/objects/previous archives are baseline, never duplicate or delete.','Streaming tar and roundtrip, no scratch extraction.','New payload hash-object must use file argv, no extra stdin/base64 payload; add P if changed.','Final payload/leaf/manifest counts must stay within P/L/M reservations.','Only after independent plan/tool review and fresh actual8GiB/mount/cgroup admission can build run.','Canonical PROGRESS one replacement leaf; old resume pointer stays unchanged.']}
 (ROOT/'FINAL_COST.json').write_bytes(data(cost));print(json.dumps({'exit_code':0,'plan_sha256':cost['plan_sha256'],'groups':budgets,'incremental_total_upper':cost['incremental_total_upper'],'original_formula':original},ensure_ascii=False))
if __name__=='__main__':main()
