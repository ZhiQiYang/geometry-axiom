"""Review selected fixed remote native originals; never execute the tested commands."""
from pathlib import Path
import ast, datetime, hashlib, json, re

R = Path(__file__).parent
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
E = '732ef20e34876379a37eb69693a481becebea43e'
PREFIX = 'evidence/geo337-native-validation-20261027/'
URL = 'https://github.com/ZhiQiYang/geometry-axiom/blob/' + E + '/' + PREFIX
checks = []
def need(value, name):
    checks.append({'name': name, 'passed': bool(value)})
    if not value:
        raise AssertionError(name)
def j(rel):
    return json.loads((R / rel).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = j('MANIFEST.json')
fetch = j('SELECTED_FETCH.json')
need(manifest['source_F'] == F and manifest['complete_F_included'], 'manifest binds completed F')
need(len(manifest['files']) == 75, 'same 75-file manifest; no complete redownload')
need(len(fetch['files']) == 19 and fetch['total_bytes'] == 104542, 'only necessary small originals fetched')
for row in fetch['files']:
    rel = row['path'].removeprefix(PREFIX)
    expected = manifest['files'][row['path']]
    need(row['exit_code'] == 0 and (R / rel).stat().st_size == expected['bytes'] and sha(R / rel) == expected['sha256'], 'selected original identity: ' + rel)
req = j('F-complete/REQUEST.json')
res = j('F-complete/RESULT.json')
summary = j('F-complete/SUMMARY.json')
need(req['sha'] == res['sha'] == summary['sha'] == F, 'single fixed execution source')
need(req['argv'] == ['bash', '--noprofile', '--norc', '-c', 'ulimit -s 16384\npython3 tests/run_all.py --build'], 'unaltered formal argv')
need(req['stack_kib'] == 16384 and req['timeout_seconds'] == 2100, '16 MiB stack and original 35 minute timeout')
need(req['environment_is_explicit_allowlist'] and set(req['environment']) == {'PATH', 'HOME', 'LANG', 'LC_ALL', 'TMPDIR', 'PYTHONDONTWRITEBYTECODE', 'PYTHONIOENCODING'}, 'explicit environment; no injected GEOMETRY skip filters')
need(res['actual_process_returncode'] == res['workflow_gate_exit'] == summary['actual_exit'] == 0 and not res['timed_out'] and not summary['timed_out'], 'actual command exit0 without timeout')
need(res['elapsed_seconds'] == summary['elapsed_seconds'] == 1886.9963683060005 < 2100, 'observed original elapsed below unchanged timeout')
need(res['status_after'] == '' and summary['checkout_clean'], 'recorded clean checkout after run')
need(j('F-complete/OWNED_PROCESSES_AFTER.json') == [], 'recorded no owned live process after completion')
need(j('F-complete/launcher.stdout.bin') == res and (R / 'F-complete/launcher.stderr.bin').stat().st_size == 0, 'outer launcher original stream agrees with receipt')
need((R / 'F-complete/stderr.bin').stat().st_size == 0, 'complete original stderr empty')
stdout = (R / 'F-complete/stdout.bin').read_text()
lines = stdout.splitlines()
progress = [(int(a), int(b), c) for a, b, c in re.findall(r'^\[(\d+)/(\d+)\] (.+) …$', stdout, re.M)]
need(len(progress) == 230 and [x[0] for x in progress] == list(range(1, 231)) and all(x[1] == 230 for x in progress), 'all230 original suite progress entries ordered')
need(len({x[2] for x in progress}) == 230, '230 distinct registered suites')
rows = [(m[1], *[int(m[i]) for i in range(2, 6)], float(m[6])) for m in (re.match(r'^(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([0-9.]+)', x) for x in lines) if m and ':' in m[1]]
need(len(rows) == 223 and [sum(x[i] for x in rows) for i in range(1, 5)] == [5329, 5328, 0, 1], 'independent sum of223 counted suite rows:5329=5328pass+0fail+1skip')
need([x[:5] for x in rows if x[4]] == [('py:test_gdi_contract', 1, 0, 0, 1)], 'only Windows GDI harness skip')
need('requires compiled Windows GDI contract harness ×1' in stdout and '其中 1 個在具名允許清單' in stdout, 'original runner identifies permitted GDI skip')
need(next(x for x in rows if x[0] == 'py:test_assembly_mutation_check')[1:5] == (12, 12, 0, 0), 'original process-group containing suite12/12 zero skips')
script_names = {'oracle:framing-selftest', 'node:model_viewer', 'node:document_format', 'node:document_cases', 'node:cdp_navigation', 'node:cdp_confirmation_gate'}
script_rows = {m[1] for m in (re.match(r'^(\S+)\s+-\s+ok\s+-\s+-\s+', x) for x in lines) if m}
need(script_rows == script_names, 'six non-counting script gates all original ok')
need(set(x[0] for x in rows) | script_rows | {'mutation:check'} == set(x[2] for x in progress), 'all230 suites accounted:223counted+6script+1ledger')
ledger = next(x for x in lines if x.startswith('mutation:check '))
need(ledger.endswith('mutation inventory freshness (not test assertions); exit 0'), 'ledger freshness original0, not mutant reexecution')
need(lines[-1].startswith('exit 0：完整非瀏覽器登錄測試：全部 suite 都跑了、數量與 expected 相符'), 'original registry and expected-count successful terminal')
need(summary['suite_count'] == 230 and [summary[x] for x in ['counted_total', 'passed', 'failed', 'skipped']] == [5329, 5328, 0, 1], 'derived summary matches independent complete stdout census')
workflow = (R / 'F-complete/workflow.original.yml').read_text()
need(sha(R / 'F-complete/workflow.original.yml') == 'b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d', 'original fixed workflow byte identity')
need('timeout-minutes: 35' in workflow.split('  browser:')[0] and 'ulimit -s 16384' in workflow and 'python3 tests/run_all.py --build' in workflow, 'same native workflow command and limit')
launcher = (R / 'F-complete/launcher.original.py').read_text()
reaper = (R / 'F-complete/reaper.original.py').read_text()
ast.parse(launcher); ast.parse(reaper)
binding = j('F-complete/LAUNCHER_BINDING.json')
need(binding['sha256']['run_native_F.py'] == sha(R / 'F-complete/launcher.original.py') and binding['sha256']['reaper.py'] == sha(R / 'F-complete/reaper.original.py'), 'actual launcher and helper bound bytes')
prior = j('PRECOMPLETION_BINDING_FETCH.json')
need(len(prior) == 2 and all(x['source_commit'] == binding['matches_precompletion_commit'] == '1202060804dc05b9d9eb58994be7cf7a3254e05d' and x['exact_bound_bytes_verified'] and x['exit_code'] == 0 and x['sha256'] == binding['sha256'][Path(x['path']).name] for x in prior), 'independent API confirms same helper bytes already published before completion')
need("assert git('rev-parse','HEAD') == SHA" in launcher and "assert not git('status','--porcelain')" in launcher, 'launcher requires fixed clean input checkout before execution')
need("if fields[0]!='Z' or int(fields[1])!=os.getpid(): continue" in reaper and 'if pid in excluded: continue' in reaper and 'os.waitpid(pid,os.WNOHANG)' in reaper and 'orphan_reaper.reap({main_pid})' in launcher, 'subreaper only reaps exited own adopted children, excludes tested main process')
need(j('F-complete/reaper-selftest.json')['selftest'] == 'pass' and len(j('F-complete/reaper-selftest.json')['adopted_and_reaped']) == 1, 'retained actual subreaper selftest')
need(j('F-complete/REAPER.json')['scope'] == 'this launcher and its descendants only' and len(j('F-complete/REAPED.json')) == 10, 'retained process-local adaptation and10 actual reap records')
archive = j('F-complete/ARCHIVE_VERIFICATION.json')
need(archive['original_manifest_verified'] and archive['archive_files_match_live_owned_output'] and len(archive['files']) == 637, 'producer archive verification references637 original output members')
for member in ['geometry-tests/run_all-logs/mutation_check.log', 'geometry-tests/run_all-logs/py_test_assembly_mutation_check.unittest.log']:
    need(member in archive['files'], 'key complete raw log retained in fixed archive: ' + member)
old = j('a4bd-withdrawn/RESULT.json'); interrupted = j('F-interrupted/RESULT.json')
need(old['sha'] == 'a4bd77e8090f5a82f0c8934c30c5335782293922' and old['actual_process_returncode'] == old['workflow_gate_exit'] == 1 and not old['timed_out'], 'withdrawn a4bd true failure1 retained separately')
need(interrupted['sha'] == F and interrupted['actual_process_returncode'] == interrupted['workflow_gate_exit'] == 130 and not interrupted['timed_out'] and j('F-interrupted/INTERRUPTION.json')['signal'] == 'SIGINT', 'first F interrupted130 retained separately, not counted pass')
result = dict(schema='fixed-F-native-independent-reception/1', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), reviewer='/root/documents_resume_0127', execution_sha=F, evidence_sha=E, exit_code=0, blocking_findings=[], checks=checks, formal=dict(actual_exit=0, timeout_seconds=2100, stack_kib=16384, elapsed_seconds=res['elapsed_seconds'], suites=230, counted_suite_rows=223, counted_assertions=5329, passed=5328, failed=0, skipped=1, permitted_skip='requires compiled Windows GDI contract harness', non_counting_script_gates=6, mutation_freshness_exit=0, whole_mutation_rerun_claimed=False), source_and_environment=dict(clean_input_guard=True, recorded_clean_after=True, environment_allowlist=req['environment'], adaptation='Process-local subreaper waits only own exited adopted children; no product/test/expected/threshold edits in executed launcher.', before=req['before'], after=res['after'], sampled_output_peak_bytes=res['sampled_max_allocated_bytes']), original_links={p:URL+p for p in ['audit/NATIVE_HANDOFF.md','F-complete/REQUEST.json','F-complete/RESULT.json','F-complete/stdout.bin','F-complete/stderr.bin','F-complete/launcher.original.py','F-complete/reaper.original.py','F-complete/ARCHIVE_VERIFICATION.json','F-complete/native-output.original.tar.gz','a4bd-withdrawn/RESULT.json','F-interrupted/RESULT.json']}, limits=['Independent selective reception of19small originals plus2precompletion source bindings; parent75file full remote verification not repeated.', 'No native rerun, new clone, archive/ELF download, source modification or deletion.', 'Detailed mutant123 census remains producer handoff claim pending direct small log extraction; original freshness exit0 is independently visible.', 'Process-group containing suite12/12 is independently visible in full stdout; individual raw unittest member has not yet been read here.', 'Producer archive verification and637-member census read; complete archive content not independently decompressed here.', 'Environment PATH/locale/TMPDIR and device capacities retained; this reception does not invent missing compiler/interpreter version commands.', 'Native output lists separately required browser/owner integrations; this result does not establish them or any whole-project all-green claim.'])
with (R / 'RECEPTION_PEER.json').open('x') as f:
    f.write(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(exit_code=0, checks=len(checks), peer_path=str(R/'RECEPTION_PEER.json'), peer_sha256=sha(R/'RECEPTION_PEER.json'))))
