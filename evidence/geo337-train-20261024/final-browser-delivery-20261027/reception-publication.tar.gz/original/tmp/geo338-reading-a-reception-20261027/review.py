"""Independent receipt review only: no imports/execution of product or remote code."""
import datetime
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).parent
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
E = '7886f2eaa3da7f9f4855104ca4b028d2d06ce6da'
NATIVE_E = '732ef20e34876379a37eb69693a481becebea43e'
PREFIX = 'evidence/geo337-reading-a-oracle-20261027/'
SEED = Path('/dev/shm/geo337-F9-browsers-20261025/Fd27/seed/source')
selection = json.loads((ROOT/'selected-fetch/RESULT.json').read_bytes())
manifest = json.loads((ROOT/'manifest/MANIFEST.json').read_bytes())
checks = []
def need(ok, name):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        raise RuntimeError(name)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def raw(name):
    info = selection['files'][name]
    path = Path(info['capture_directory'])/'stdout.bin'
    need(path.is_relative_to(ROOT/'selected-fetch/subcommands'), 'local capture path '+name)
    data = path.read_bytes()
    expected = manifest['files'][PREFIX+name]
    need(len(data) == info['bytes'] == expected['bytes'] and sha(data) == info['sha256'] == expected['sha256'], 'fixed remote bytes '+name)
    return data
def j(name):
    return json.loads(raw(name))
def text(name):
    return raw(name).decode('utf-8')

result = {'schema': 'fixed-F-reading-A-independent-reception/1', 'execution_sha': F,
          'evidence_sha': E, 'native_evidence_sha': NATIVE_E, 'exit_code': 1,
          'checks': checks, 'product_rerun': False}
try:
    need(selection['exit_code'] == 0 and selection['execution_sha'] == F and selection['evidence_sha'] == E, 'fixed completed selective download')
    need(len(selection['files']) == 112 and selection['selected_bytes'] == 1988433, '112 bounded originals; no archive or ELF')
    need(manifest['source_F'] == F, '137-file producer manifest binds F')
    for name in selection['files']:
        raw(name)
    before = j('oracle/SOURCE_BEFORE.json')
    need(before == j('oracle/SOURCE_AFTER.json'), 'recorded oracle closure unchanged')
    local_bindings = []
    for name, binding in before.items():
        if name.startswith('evidence/'):
            continue
        data = (SEED/name).read_bytes()
        need(len(data) == binding['bytes'] and sha(data) == binding['sha256'], 'independent fixed F seed binding '+name)
        local_bindings.append(name)
    oracle = j('oracle/RESULT.json')
    need(oracle['sha'] == F and oracle['passed'] and oracle['source_unchanged'] and oracle['status_after'] == '', 'oracle terminal and clean F')
    expected_stages = ['golden-source-proof', 'golden-generate', 'golden-compare', 'oracle-mutants', 'oracle-quick']
    need([s['name'] for s in oracle['stages']] == expected_stages, 'all five original stages present in order')
    for stage in oracle['stages']:
        name = stage['name']; req = j('oracle/'+name+'/request.json'); res = j('oracle/'+name+'/result.json')
        need(res == stage and all(res[k] == v for k,v in req.items()), 'actual stage/request agrees '+name)
        need(res['sha'] == res['sha_after'] == F and res['actual_exit'] == 0 and not res['timed_out'] and res['status_after'] == '' and res['source_unchanged'], 'actual zero without source drift '+name)
        need(res['elapsed_seconds'] < res['timeout_seconds'], 'within declared collection cap '+name)
        need(raw('oracle/'+name+'/stderr.bin') == b'', 'empty original stderr '+name)
    for name,flag in [('oracle-mutants','--mutants-only'),('oracle-quick','--quick')]:
        argv = j('oracle/'+name+'/request.json')['argv']
        need(argv[1:] == ['-B','/workspace/geo337-native-F-cbf0fb62/geometry-core/framing-template/oracle/selftest.py',flag], 'exact original oracle command '+name)
    req = j('oracle/REQUEST.json')
    need(req['sha'] == F and req['stack_bytes'] == 16777216 and req['environment']['PYTHONOPTIMIZE'] == '0', 'stack and enabled assertions unchanged')
    quick = text('oracle/oracle-quick/stdout.bin')
    required_lines = ['要求 528、漏掃 0、非 buildable 0', '要求 1056、漏掃 0、非 buildable 0',
                      '奇數縫寬(1、3)矩形房 1872 次:不可施工或檢查失敗 0 個',
                      '凹角、壁龕與獨立柱房 579 間 × 8 種排法:物理上可施工 4632 個',
                      '410 間 × 8 種排法:物理上可施工 3280 個',
                      '820 間 × 8 種排法:物理上可施工 6560 個',
                      '掃描 39850 次建構(快速),368 秒;不可施工或檢查失敗 0 個']
    for line in required_lines:
        need(line in quick, 'full quick raw coverage '+line)
    need('已知缺陷 C11_MAIN_NOT_BUTTED 6 次,另開工單' in quick, 'six existing C11 known-defect observations retained')
    mutants = text('oracle/oracle-mutants/stdout.bin')
    need(mutants.endswith('(--mutants-only:跳過掃描)\n') and '[紅]' in mutants, 'mutants-only original scope and expected negative witnesses retained')
    golden = j('oracle/golden-proof/receipt.json')
    need(golden['source_sha'] == golden['source_sha_after'] == F and golden['passed'] and golden['source_bytes_unchanged'] and golden['variant_bytes_match_exact_withdrawal'], 'golden original targeted proof binding')
    need([(x['variant'],x['exit_code']) for x in golden['commands']] == [('baseline',0),('withdrawn',1),('restored',0)], 'golden true 0/1/0')
    for item in golden['commands']:
        phase = item['variant']
        need(text('oracle/golden-proof/'+phase+'/stdout.txt') == item['stdout'] and text('oracle/golden-proof/'+phase+'/stderr.txt') == item['stderr'], 'golden raw command outputs '+phase)
    need('ASSERT:golden-current-witness-nonempty' in golden['commands'][1]['stdout'] and 'AssertionError' in golden['commands'][1]['stderr'], 'golden withdrawal kills original nonempty-witness assertion')
    compare = j('oracle/golden-compare/stdout.bin')
    need(compare['byte_identical'] and compare['generated_sha256'] == compare['committed_sha256'] == before['geometry-core/framing-template/oracle/oracle-golden.json']['sha256'], 'golden byte-comparison raw hashes bind F')
    need(manifest['files'][PREFIX+'oracle/golden-generated.json']['sha256'] == compare['generated_sha256'], 'published generated golden manifest identity')
    worker = raw('tools/run_original_rc_method.py')
    need(sha(worker) == '34baecbd743921179327ec0700c9a3915f0a7f498dcf0850c372343b8edf5d4d', 'historical original RC worker exact pin')
    rc = j('rc/RESULT.json')
    need(rc['sha'] == F and rc['passed'] and rc['source_unchanged'] and rc['status_after'] == '', 'RC terminal fixed source and clean')
    need(len(rc['stages']) == 6, 'all six RC phases')
    for control in ['builder-whole-face','checker-whole-face']:
        rows = [s for s in rc['stages'] if s['control'] == control]
        need([(s['phase'],s['actual_exit']) for s in rows] == [('baseline',0),('withdrawn',1),('restored',0)], control+' true 0/1/0')
        for stage in rows:
            name = 'rc/'+control+'/'+stage['phase']
            res = j(name+'/result.json'); need(res == stage, 'RC raw result agrees '+name)
            need(not res['timed_out'] and res['sha'] == F, 'RC actual source/no timeout '+name)
            stdout = text(name+'/stdout.bin'); stderr = text(name+'/stderr.bin')
            outcomes = [json.loads(line.removeprefix('RC_METHOD_OUTCOME ')) for line in stdout.splitlines() if line.startswith('RC_METHOD_OUTCOME ')]
            need(outcomes == res['outcomes'] and len(outcomes) == 1, 'RC original outcome '+name)
            o = outcomes[0]
            need(o['sourceSha'] == F and o['testsRun'] == 1 and o['skips'] == o['errors'] == 0 and o['assertionFailures'] == int(stage['phase'] == 'withdrawn') and o['originalFilesUnchanged'], 'RC exact original assertion census '+name)
            need(('AssertionError' in stderr) == (stage['phase'] == 'withdrawn'), 'RC assertion failure instead of infrastructure error '+name)
    native_local = Path('/tmp/geo338-native-reception-peer-20261027/F-complete')
    for name in ['REQUEST.json','RESULT.json','SUMMARY.json']:
        need(raw('oracle/same-F-native-originals/'+name) == (native_local/name).read_bytes(), 'reused exact native original '+name)
    stdout = (native_local/'stdout.bin').read_text()
    coverage = j('oracle/required-eight-native-originals/COVERAGE.json')
    need(coverage['source_sha'] == F and coverage['evidence_commit'] == NATIVE_E and len(coverage['rows']) == 8, 'required-eight exact original native identity')
    need(sum(x['passed'] for x in coverage['rows']) == coverage['total'] == 681, 'required-eight independent sum 681')
    for row in coverage['rows']:
        need(row['original_stdout_row'] in stdout and row['passed'] == row['total'] and row['failed'] == row['skipped'] == 0, 'native full stdout matches '+row['suite'])
        if row['suite'].startswith('py:'):
            p='oracle/required-eight-native-originals/'+row['suite'].replace(':','_')+'.json'
            unit=j(p);need(unit['passed']==row['passed'] and unit['failed']==unit['skipped']==unit['extra_errors']==0 and unit['import_error'] is None,'original unittest result '+row['suite'])
    for path,count in [('oracle/same-F-native-originals/py_test_geo318_reading_a_oracle.json',14),('reader/same-F-native-unit/py_test_axiom_reader.json',51)]:
        unit=j(path);need(unit['total']==unit['run']==unit['passed']==count and unit['failed']==unit['skipped']==unit['extra_errors']==0 and unit['import_error'] is None,'same-F native unit count '+path)
    reader = j('reader/RESULT.json'); reader_req = j('reader/REQUEST.json')
    need(reader['sha'] == F and reader['passed'] and reader['status_after'] == '' and reader['source_after'] == reader_req['source_before'], 'reader generation/check byte-idempotence')
    for stage in reader['stages']:
        name=stage['stage']; need(stage == j('reader/'+name+'/result.json') and stage['actual_exit']==0 and not stage['timed_out'] and stage['source_unchanged'], 'reader actual zero '+name)
    result.update(exit_code=0, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), independently_bound_local_source_paths=local_bindings,
                  oracle_quick_seconds=j('oracle/oracle-quick/result.json')['elapsed_seconds'],
                  formal={'oracle_unit_native':14,'oracle_mutants_exit':0,'oracle_quick_exit':0,'golden':[0,1,0],'rc_builder':[0,1,0],'rc_checker':[0,1,0],'reader_native_unit':51,'required_eight_native':681},
                  limits=['Selective112 of137 original files; producer full137 remote verification not repeated.',
                          'No new oracle/native/reader/product execution; native14,51,681 remain original module/full-native coverage.',
                          'Generated golden and variant source copies were not downloaded; byte comparator, manifest, pinned worker and raw source guards reviewed.',
                          'Quick retains six existing C11_MAIN_NOT_BUTTED known-defect observations; no whole-project zero-defect claim.',
                          'Historical wrapper assigned caps but used timeout=None; this external launcher enforced declared stricter collection caps, none reached. No product threshold relaxed.',
                          'No P-189/strict-exact approval or cross-SHA exemption is inferred. PF3 is separately owned and not covered here.'])
finally:
    (ROOT/'RECEPTION_PEER.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':result['exit_code'],'checks':len(checks),'sha256':sha((ROOT/'RECEPTION_PEER.json').read_bytes())}))
