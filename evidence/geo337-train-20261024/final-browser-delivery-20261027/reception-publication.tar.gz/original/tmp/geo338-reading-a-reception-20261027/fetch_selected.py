"""Read fixed, bounded original receipts; never execute product code."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).parent
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
E = '7886f2eaa3da7f9f4855104ca4b028d2d06ce6da'
PREFIX = 'evidence/geo337-reading-a-oracle-20261027/'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
manifest = json.loads((ROOT / 'manifest/MANIFEST.json').read_bytes())
assert manifest['source_F'] == F
tools = {'run.py', 'run_rc.py', 'run_original_rc_method.py', 'run_readers.py', 'reaper.py', 'run_stage.historical.py'}
selected = {}
for path, binding in manifest['files'].items():
    assert path.startswith(PREFIX) and '..' not in Path(path).parts
    rel = path[len(PREFIX):]
    keep = (
        rel.startswith('tools/') and Path(rel).name in tools
        or rel.startswith('oracle/') and rel != 'oracle/golden-generated.json'
        and (not rel.startswith('oracle/golden-proof/') or Path(rel).suffix in {'.txt'} or rel == 'oracle/golden-proof/receipt.json')
        or rel.startswith('reader/')
        or rel.startswith('rc/') and not rel.endswith('framing_oracle.py')
    )
    if keep:
        assert binding['bytes'] <= 300000
        selected[rel] = binding
assert sum(v['bytes'] for v in selected.values()) < 3 * 1024 ** 2
out = ROOT / 'selected-fetch'
out.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('original_capture', CAP)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
rec = capture.Recorder(out, dict(os.environ), F)
result = {'execution_sha': F, 'evidence_sha': E, 'exit_code': 1,
          'selected_bytes': sum(v['bytes'] for v in selected.values()), 'files': {}}
try:
    for rel, expected in sorted(selected.items()):
        cmd = ['gh', 'api', '--method', 'GET', '-H', 'Accept: application/vnd.github.raw+json',
               'repos/ZhiQiYang/geometry-axiom/contents/' + PREFIX + rel + '?ref=' + E]
        row, raw, _ = rec.run(cmd, cwd='/workspace', timeout=60, check=False,
                             source_sha=F, source_variant='fixed external original reception; no product execution')
        assert row['actual_process_returncode'] == 0 and not row['timeout_expired'], rel
        digest = hashlib.sha256(raw).hexdigest()
        assert len(raw) == expected['bytes'] and digest == expected['sha256'], rel
        result['files'][rel] = {'bytes': len(raw), 'sha256': digest, 'capture_directory': row['directory']}
        (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    result['exit_code'] = 0
finally:
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'exit_code': result['exit_code'], 'files': len(result['files']), 'bytes': result['selected_bytes']}))
