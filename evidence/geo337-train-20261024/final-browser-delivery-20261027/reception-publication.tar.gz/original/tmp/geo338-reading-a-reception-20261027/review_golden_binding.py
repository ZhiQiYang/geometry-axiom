"""Append the independent fixed-F golden driver binding; preserve v1 originals."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
v1raw = (root/'RECEPTION_PEER.json').read_bytes()
assert hashlib.sha256(v1raw).hexdigest() == 'c81582593a93e199c728594f9c405b6b51533ab6c37a9c068f30b3d89f7eb8e7'
v2 = json.loads(v1raw)
binding = json.loads((root/'golden-driver-F/RESULT.json').read_bytes())
capture = Path(binding['capture_directory'])
assert capture.is_relative_to(root/'golden-driver-F/subcommands')
raw = (capture/'stdout.bin').read_bytes()
command = json.loads((capture/'result.json').read_bytes())
selected = json.loads((root/'selected-fetch/RESULT.json').read_bytes())
receipt = json.loads((Path(selected['files']['oracle/golden-proof/receipt.json']['capture_directory'])/'stdout.bin').read_bytes())
checks = [
    ('independent golden source extraction actual exit0', command['actual_process_returncode'] == 0 and not command['timeout_expired']),
    ('independent golden source exact Git object reference', command['command'][-1] == v2['execution_sha']+':evidence/issue318-reading-a-20261023/tools/prove_golden_witness.py'),
    ('independent extraction forbids lazy network fetch', '--no-lazy-fetch' in command['command'] and '--no-optional-locks' in command['command']),
    ('golden driver complete bytes and digest', len(raw) == binding['bytes'] == 9046 and hashlib.sha256(raw).hexdigest() == binding['sha256'] == receipt['driver_sha256']),
    ('golden original no optimization guard retained', b'if sys.flags.optimize' in raw),
    ('golden actual proof and extracted source same F', binding['source_sha'] == receipt['source_sha'] == v2['execution_sha']),
]
assert all(ok for _,ok in checks)
v2['checks'].extend({'name':name,'passed':bool(ok)} for name,ok in checks)
v2['golden_driver_independent_binding'] = binding
v2['prior_reception'] = {'path':'RECEPTION_PEER.json','sha256':hashlib.sha256(v1raw).hexdigest(),'retained':True}
v2['supplement_scope'] = 'Six source-binding checks only; prior483 checks retained without product rerun or repeated original download.'
v2['supplement_tool_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
out = root/'RECEPTION_PEER.v2.json'
with out.open('x') as f:
    f.write(json.dumps(v2,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':0,'inherited_checks':483,'new_checks':len(checks),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
