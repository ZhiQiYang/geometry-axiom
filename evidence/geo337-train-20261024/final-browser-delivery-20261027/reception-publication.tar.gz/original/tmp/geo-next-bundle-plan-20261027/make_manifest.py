#!/usr/bin/env python3
"""Bind only already finished archive/peer/document outputs; no publication."""
import importlib.util,pathlib,hashlib,json,os
HERE=pathlib.Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('publisher',HERE/'publish.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
allowed=p.allowed_sources();rows=[]
for dst,src in sorted(allowed.items()):
 assert src.is_file() and not src.is_symlink() and src.resolve()==src
 s=src.stat();sha=hashlib.sha256();git=hashlib.sha1(b'blob '+str(s.st_size).encode()+b'\0')
 with src.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):sha.update(b);git.update(b)
 s2=src.stat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(s2.st_dev,s2.st_ino,s2.st_size,s2.st_mtime_ns)
 rows.append({'destination':dst,'source_path':str(src),'size':s.st_size,'sha256':sha.hexdigest(),'git_blob':git.hexdigest()})
manifest={'schema':1,'parent':p.OLD,'branch':p.BRANCH,'files':rows,'alias':{'destination':p.ALIAS_DST,'git_blob':p.ALIAS_OID,'old_path':p.ALIAS_OLD,'bytes':55775729,'sha256':'475678a2227d503ba0781eb578ee86d27fa13716fb146ba510f62f0144097be9'},'policy':'Only normal fast-forward; no fetch, promisor, force, merge PR/main, or product changes. New remote payloads verified full bytes; alias bound by original full-readback and new remote tree/path immutable OID.'}
out=HERE/'MANIFEST.json';assert not out.exists(),'freeze once, do not overwrite manifest';out.write_bytes(p.js(manifest));print(json.dumps({'path':str(out),'size':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'P':sum(x['size'] for x in rows),'L':len(rows)+1}))
