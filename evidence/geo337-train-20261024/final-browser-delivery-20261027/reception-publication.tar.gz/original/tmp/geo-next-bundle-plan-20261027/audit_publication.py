#!/usr/bin/env python3
"""Read the completed publication once. No API, Git fetch, push or large-pack read."""
import pathlib,json,hashlib,sys
R=pathlib.Path('/dev/shm/geometry-axiom-geo337-20261025/recovery-bundle-20261027/git-publication')
D=pathlib.Path(__file__).resolve().parent
checks=[]
def ck(name,ok):
 checks.append({'check':name,'passed':bool(ok)})
 if not ok:raise RuntimeError(name)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def main():
 ck('root supplied terminal attribution',len(sys.argv)==4)
 result=json.loads((R/'RESULT.json').read_bytes());m=json.loads((R/'MANIFEST.json').read_bytes());rows=json.loads((R/'subcommands.json').read_bytes())
 ck('terminal completed delivery',result['exit_code']==0 and result['published'] and result['delivered'] and result['ordinary_fast_forward'] and result['force'] is False and result['no_fetch'])
 ck('fixed old parent',result['expected_parent']==m['parent']=='047d93f01ba1bd349ebc256c4e8d19209bfd0f49')
 ck('same frozen manifest',sha(R/'MANIFEST.json')==sys.argv[3])
 ck('provider retained',result['provider_unchanged'] and (R/'PROVIDER_BEFORE.json').read_bytes()==(R/'PROVIDER_AFTER.json').read_bytes())
 ck('exact changed leaves',set(result['changed_paths'])=={x['destination'] for x in m['files']}|{m['alias']['destination']})
 ck('exact alias identity',result['verified_alias']['git_blob']==m['alias']['git_blob'] and result['verified_alias']['new_download'] is False)
 ck('alias not resent',m['alias']['git_blob'] not in result['outgoing_objects'])
 seenpush=0;remote_capture={};streams=[]
 for i,row in enumerate(rows,1):
  cmd=row['command'];rc=row['actual_process_returncode'];base=pathlib.Path(row['directory']);ck('captured command dir contained '+str(i),base.parent==R/'subcommands')
  for stream in ['stdin','stdout','stderr']:
   p=base/(stream+'.bin');got=sha(p);ck(str(i)+' '+stream+' full capture hash',got==row[stream+'_sha256']);streams.append({'path':str(p),'bytes':p.stat().st_size,'sha256':got})
  expected_nonzero=cmd[0]=='git' and '--get-regexp' in cmd
  ck(str(i)+' actual exit',rc==(1 if expected_nonzero else 0) and not row['timeout_expired'])
  if cmd[0]=='git':
   ck(str(i)+' no fetch/clone/index-pack/repack',not any(x in cmd for x in ['fetch','clone','index-pack','repack']))
   if 'hash-object' in cmd:ck(str(i)+' hash-object path no payload stdin',(base/'stdin.bin').stat().st_size==0 and '--' in cmd and '--stdin' not in cmd)
   if 'push' in cmd:
    seenpush+=1;ck('ordinary exact push',cmd[-4:]==['push','--porcelain','https://github.com/ZhiQiYang/geometry-axiom.git','refs/heads/delivery:refs/heads/codex/train337-recovered-evidence-20261026'])
  if cmd[0]=='gh' and cmd[-1].startswith('repos/ZhiQiYang/geometry-axiom/git/blobs/'):
   remote_capture[cmd[-1].rsplit('/',1)[1]]=streams[-2]
 ck('one push',seenpush==1)
 ck('all new remote blobs full captures',set(remote_capture)=={x['git_blob'] for x in m['files']})
 for f in m['files']:
  got=remote_capture[f['git_blob']];ck('remote bytes and SHA '+f['destination'],got['bytes']==f['size'] and got['sha256']==f['sha256']);v=result['verified_blobs'][f['destination']];ck('driver verified record '+f['destination'],v['size']==f['size'] and v['sha256']==f['sha256'] and v['git_blob']==f['git_blob'])
 out={'schema':1,'exit_code':0,'checks':checks,'new_evidence_head':result['commit'],'expected_parent':result['expected_parent'],'root_terminal_observation':{'session':sys.argv[1],'chunk':sys.argv[2],'exit_code':0,'source':'root terminal message; child did not repoll'},'manifest_sha256':sha(R/'MANIFEST.json'),'executor_sha256':sha(R/'EXECUTOR.py'),'raw_streams':streams,'commands':len(rows),'scope':'One complete hash of each captured stdin/stdout/stderr; no new API, provider pack hash, product rerun or repackage. Formal gate status remains separately source-bound.'}
 (D/'PUBLICATION_ACTUAL_PEER.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'exit_code':0,'head':result['commit'],'checks':len(checks),'commands':len(rows),'peer_sha256':sha(D/'PUBLICATION_ACTUAL_PEER.json')}))
if __name__=='__main__':main()
