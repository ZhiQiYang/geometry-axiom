# 閱讀 A：逐毫米／579 專項及 RC 量法來源反證

這是 root 排程用的待執行方案，不是新掃描收據。固定來源參考 F64=`f64d638f15c48d2b9723b7ae9d230fb5dacb82d9`，其 oracle／原測試完整 Git blobs、指令、exit及hash保 `SOURCE_CAPTURE.json`（14檔、1,080,728B，全部Git exit0）。沒有 import 或執行 repository 程式，也沒有改列車、測試、帳本、SSOT或決策佇列。正式執行要等 root 全 ledger後固定的最後可解析 SHA，不能把 F64／P17 字串直接改標成新 final。

## 正式執行順序與原 CLI

所有命令 cwd 是 root 指定同一 final SHA 的乾淨 checkout。明設 `GITHUB_SHA=FINAL_SHA`、`GITHUB_WORKSPACE=ROOT_FINAL`；清 `PYTHONOPTIMIZE`、`PYTHONPATH`、`PYTHONHOME`、`PYTHONSTARTUP`、`FRAMING_QUOTE_QUEUE`；保原 assertions、原 params／golden／負控。TMPDIR／OUT 在 repo 外，由 root 查當前容量後指定。這些原入口沒有 R3，不另加阻塞鎖；root 分配執行槽，不能與獨占 perf/profile/canvas 並跑。

| 次序 | 精確入口 | 真完成判準 | 排程估計（不是新門檻） |
|---|---|---|---|
| 0 | 只讀 Git HEAD／status／原輸入 hash與版本前置 | final40碼可解析、clean，原 source／fixtures齊全 | 數秒 |
| 1 | 下節兩個 RC 量法精準來源反證；各跑同一原 unittest method 的0／1／0 | builder／checker分別只撤回自己的unlined-run量法，原assert必須紅；baseline/restored都綠 | 合計約1分鐘內，待實際觀察 |
| 2 | `python3 -B geometry-core/framing-template/oracle/selftest.py --mutants-only` | 原 exit0；原突變、手算、引文、golden及小型掃描守門全走；輸出最後明示只此模式跳過大掃描 | 歷史16–23秒；預留約1分鐘 |
| 3 | `python3 -B geometry-core/framing-template/oracle/selftest.py --quick` | 原 exit0；本文件全量掃描／528+1056／預期清單比較／golden等原判準，不按CI篩房 | 預留約10–20分鐘；不新增timeout或縮樣本 |

不先跑 CI抽樣再稱正式逐毫米／579已完成；原 full-native內的CI也不能取代第3項。第2項若紅仍收第3項獨立結果，保完整原因，不放寬assert或改golden。這裡沒有開 `--write-expected`、沒有原始碼快取結果替代掃描，也不自動接 `--full`。

`--full` 是另一種更大閉包：一維9402尺寸×全部8排法，二維改整段±45與97／211網格。原資料記錄3小時15分；本輪要求的逐mm＋579由原`--quick`完整涵蓋，須如實說一維只驗左上／板長沿Y，不把它寫成一維8方向全掃。若 root另要求full，另外給獨占／時間，不用quick文字冒full。

## quick 實際覆蓋與預期輸出

`STATIC_CASE_CENSUS.json` 只重算原固定整數迴圈，沒有跑幾何。此census用來查漏跑，不是依新oracle輸出回填答案。

| 範圍 | 原集合／排法 | 靜態數量與原判準 |
|---|---|---|
| 矩形一維逐mm | 寬300…4000×深2500；寬2000×深300…6000，左上起鋪／板長沿Y | 3701＋5701＝9402；任何conflict、check失敗或core_limit都進原bad |
| 矩形二維臨界帶 | 寬917k+{-43,-42,-41,-40,-39,-1,0,1,2}加331網格；深1832k+同偏移加617網格；全8排法 | 48寬×37深×8＝14208；原bad必須0 |
| 凹角／壁龕／柱房 | L408＋壁龕24＋獨立柱147，全8排法 | 579×8＝4632；可施工者跑原全部check，trace原判準維持 |
| 牆階／雙階 | 三族各100＋雙階110，全8排法 | 410×8＝3280；與完整step／step_core預期清單逐筆比對 |
| 牆階鏡像 | 前410間各上下、左右翻一次，全8排法 | 820×8＝6560；mirror mapping與完整鏡像清單逐筆比對 |
| P182候選四族 | t16／t14／t10／t4，原quick步距3 | 計數384／288／392／704；全部原check/trace/鏡像裁判保留 |
| 奇數縫寬 | gap1／3矩形，原全8排法 | 1872次，原odd_bad必須0 |

原最後印出的 `掃描 39850 次建構(快速)` 是該程式的 `runs` 計數；它**不含**奇數縫1872、t10額外鏡像392、先前golden／手寫控制及內部P182候選重建。不能把39850寫成所有 `build()` 真呼叫次數。完整輸出／原退出碼是判決；不以自製計數取代原檢查。

應有原progress段：矩形一維逐mm、矩形二維、凹角／壁龕／柱、牆階、牆階鏡像、P182四族、奇數縫寬與收尾。前半部許多 `[紅]` 是「預期壞變體成功被抓到」，不能按看到紅字就誤判產品失敗；以原 `failed`／退出碼及具體原assert判。

當前 `sweep-expected-unbuildable.json` 六類 reflex／reflex_core／step／step_core／step_mirror／step_mirror_core 全是空清單：原全量對比須六類實得0、多出0、少了0。不是把所有核心公理限制刪光：FZ120的I22延伸端點、其他手算負例與P182原控制仍在前半段驗。

凍結正例 `reading-a-expected-buildable.json` 必須保 SHA256 `b5e4e707a4fc4b2710db237d0252d67104e0a555a50a875e79de2ad43c7d46c0`；來源是原22ad28f基底身份，不能由新oracle產生。quick/full原 `expected_for_run(..., ci=False)` 不按本次房間集合過濾。原輸出必須逐筆證明：

```text
[綠] 閱讀 A step 凍結正例逐筆觀察：要求 528、漏掃 0、非 buildable 0
[綠] 閱讀 A step_mirror 凍結正例逐筆觀察：要求 1056、漏掃 0、非 buildable 0
```

不能只驗清空後 `step_core=0` 就漏掉未被建構的528／1056身份。原`compare_unbuildable`、`expected_for_scan`、C4 inconsistent、漏房控制都保留。

原P182四族只把**原來已特別列明的**純 `C11_MAIN_NOT_BUTTED` 計為已知缺陷而不算該族bad，仍須記實際次數／原文；不能擴到其他檢查碼或藏成skip。#335兩種CLI初放順序缺口仍依核可另案追蹤，本掃描不宣稱解決CLI放置次序。

## RC 未覆木連續段的精準來源反證

核可的量法是端面裸露段所在、同側未貼料的連續run；不是無條件量整個RC面，也不是只量端面內的小缺口。等於料寬仍拒絕；反側／未placed／異承載面／不同RC host不能拿來截短run。

native新 `rc-lining` 控制／M151 是精確撤回 `if(near!=at)continue;` → `continue;`，原具名 `lined-rc-short-run-permitted` 必紅。F64原7方法已包含11W＋1H共12控制真0／1／0，其中此刀已跑；最後全帳本M151仍須由root統一實跑／核對，不另產子帳本。現有oracle14也已綠，但其builder/checker source控制是整個閱讀A早退 `ordinary`，不是以下兩個新RC演算法精確撤回；移除liner fixture的正反例也不能冒來源撤回。

外部worker `run_original_rc_method.py`（本資料夾）預備執行原檔 `tests/test_geo318_reading_a_oracle.py` 的同一個原方法 `ReadingAOracle.test_rc_face_is_measured_along_its_unlined_run`，原method／assert／fixtures全部不改。每phase獨立Python程序，先把精確oracle variant以原名 `framing_oracle` 載入，再載入原test檔；硬核test真正消費所選module、只跑原一方法、Ran1、無error／skip。不是mock回傳值或新增一套幾何判官。

| 控制 | 只撤回的 source bytes | 預期 |
|---|---|---|
| builder-whole-face | `_reading_a_build_end` 的 `unlined = iv_subtract([(lo, hi)], lined)` → `unlined = [(lo, hi)]`（唯一一處） | COLSTEP(3000)原buildable斷言失敗；checker未變 |
| checker-whole-face | `reading_a_has_bare_rc` 依lined算run_lo／run_hi的兩行 → `run_lo, run_hi = lo, hi`（唯一一處） | 原同方法有liner的`assertFalse`／後續C8斷言必失敗；builder未變 |

每刀baseline用真final原source、withdrawn用repo外只此替換的variant、restored再用真final原source，必須0／1／0。worker拒絕任何其他byte差異；真1須是原 `AssertionError`，TypeError／missing file／skip／crash屬環境或工具錯，不能算killed。保存原unit完整stderr與traceback行、載入source hash、五個原輸入的Gitblob/hash、原HEAD/status初末；不把wrapper期待值蓋過真退出。

精確worker命令形狀（不是現在執行，`FINAL_SHA`必須root正式40碼）：

```text
python3 -B TOOL_DIR/run_original_rc_method.py --root ROOT_FINAL --sha FINAL_SHA --source ROOT_FINAL/geometry-core/framing-template/oracle/framing_oracle.py --control baseline
python3 -B TOOL_DIR/run_original_rc_method.py --root ROOT_FINAL --sha FINAL_SHA --source OUT/builder-whole-face/framing_oracle.py --control builder-whole-face
python3 -B TOOL_DIR/run_original_rc_method.py --root ROOT_FINAL --sha FINAL_SHA --source ROOT_FINAL/geometry-core/framing-template/oracle/framing_oracle.py --control baseline
```

checker以相同baseline/restored及`OUT/checker-whole-face/framing_oracle.py --control checker-whole-face`另一組。variants必須在final固定後從**該final原bytes**生成，先驗anchor恰1與「倒轉後等原檔」，不能直接拿目前F64副本冒新source。`RC_PROOF_REQUEST_TEMPLATE.json`列六命令、原期望及來源替換；工具目前只AST／靜態準備，待獨立peer，沒有執行任何一phase。

原單純13mm／14mm的 `reading_a_source_control.py` 不能代這兩刀：它沒有同側liner情境，撤回unlined算法可能仍綠。RC量法反證必打原帶liner測例。

## 來源、容量與全體耗時

完整前置包含oracle本身、selftest、reading_a_cases、兩份凍結／預期JSON、rooms／golden、quote_check、README、framing-template/PROPOSAL.md及同樹決策佇列；fixtures缺漏先作環境紅，不借外部舊佇列。原先缺PROPOSAL的環境失敗及F64以前三真紅保持歷史，不抹成新綠。

這些專項不需要第二套C編譯cache或Chrome。來源snapshot沿root唯一指定工作樹；若當前工作樹另有人持有，先等交棒，不能自行checkout移它HEAD。暫存與變體預估數MiB、log預估數十至數百KiB，但以原輸出實際容量保留，不截斷。c387錄製器必用完整原argv／cwd／env／source SHA／exit／stdin/stdout/stderr；外層timeout不得殺掉subreaper卻留下test，原無timeout的這些語意入口不自創新硬時限。

建議排一個slot連續約15–25分鐘窗口（來源前置＋RC兩刀＋mutants-only＋quick＋封原輸出），CPU獨占不是新判準，但不要污染另項perf。quick歷史Linux ae74曾掃描390秒／wall414秒而exit1（舊三紅）；Windows歷史790–869秒。這些只是排程估計，新的RCrun與主機負載未量，不預報綠燈或固定秒數。正式完成後立即交叉審查／封存，再依root安排下一項；不自動啟full掃描。
