#!/usr/bin/env python3
"""Read-only independent review of completed RC method proofs; no subject import."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import subprocess

B=Path('/tmp/train337-rc-run-proof-f64d638f')
OUT=Path('/tmp/geo324-owner-20261024/review-reading-a-rc-actual')
REPO=Path('/tmp/geo324-faces-work-20261024')
SHA='f64d638f15c48d2b9723b7ae9d230fb5dacb82d9'
LATER='504933473d7b9bdfc5964f73402a710f1222fc96'
TOOL_SHA='34baecbd743921179327ec0700c9a3915f0a7f498dcf0850c372343b8edf5d4d'
if OUT.exists():raise SystemExit('refuse overwrite')
OUT.mkdir()
checks=[];inventory={};git_rows=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(path):
    path=Path(path);raw=path.read_bytes()
    inventory[str(path)]={'bytes':len(raw),'sha256':digest(raw)}
    return raw
def data(path):return json.loads(read(path))
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
def git(*args):
    argv=['git',*args];p=subprocess.run(argv,cwd=REPO,capture_output=True)
    git_rows.append({'argv':argv,'cwd':str(REPO),'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':digest(p.stdout),'stderr':p.stderr.decode()})
    check('readonlyGit:'+':'.join(args),p.returncode==0)
    return p.stdout

result=data(B/'RESULT.json');request=data(B/'REQUEST.json')
rows=data(B/'subcommands.json');variants=data(B/'VARIANTS.json')
source=Path(result['source'])
tool=read(B/'tools/run_original_rc_method.py')
check('workerOriginalFrozenBytes',digest(tool)==TOOL_SHA and result['toolSha256']==TOOL_SHA)
ast.parse(tool)
check('actualSourceIdentity',result['sourceSha']==SHA and request['sourceSha']==SHA)
check('actualRequestEnvironment',request['environment']=={'GITHUB_SHA':SHA,'GITHUB_WORKSPACE':str(source)})
check('topTrueTerminal',result['passed'] is True and result['exit']==0 and result['finishedEpoch']>result['startedEpoch'])
check('lockReportedReleased',request['lockHeld'] is True and result['lockHeld'] is False and result['R3Released'] is True and result['lockMode']=='EX|NB')
check('twoOriginalProofs',[x['control'] for x in result['proofs']]==['builder-whole-face','checker-whole-face'])
check('thirteenOriginalCapturedCommands',len(rows)==13)
expected_exits=[0,0,0,0,0,0,0,0,1,0,0,1,0]
for number,row in enumerate(rows,1):
    directory=B/'subcommands'/f'{number:06d}'
    original=data(directory/'result.json');req=data(directory/'request.json')
    check(f'row{number}:originalRowEqualsAggregate',row==original)
    check(f'row{number}:actualExit',original['actual_process_returncode']==expected_exits[number-1] and not original['timeout_expired'])
    for key in ('command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','directory'):
        check(f'row{number}:request:{key}',req[key]==original[key])
    check(f'row{number}:sourceSHA',original['acceptance_sha']==SHA and original['source_sha']==SHA)
    for name in ('stdin','stdout','stderr'):
        raw=read(directory/(name+'.bin'))
        check(f'row{number}:{name}:sha',digest(raw)==original[name+'_sha256'])
        if name!='stdin':check(f'row{number}:{name}:bytes',len(raw)==original[name+'_bytes'])

inputs={name:git('show',SHA+':'+name) for name in result['sourceFiles']}
check('exactFiveInputs',len(inputs)==5)
input_hashes={name:digest(raw) for name,raw in inputs.items()}
for name,raw in inputs.items():
    check('actualOriginalFile:'+name,read(source/name)==raw)
    check('modeBlobClosureToLaterTrain:'+name,git('rev-parse',SHA+':'+name)==git('rev-parse',LATER+':'+name) and git('ls-tree',SHA,'--',name)==git('ls-tree',LATER,'--',name))

oracle='geometry-core/framing-template/oracle/framing_oracle.py'
original=inputs[oracle]
template=json.loads(read('/tmp/train337-reading-a-sweep-plan/RC_PROOF_REQUEST_TEMPLATE.json'))
for variant,expected in zip(variants,template['requests']):
    raw=read(variant['path']);old=expected['old'].encode();new=expected['new'].encode()
    check('variant:'+variant['control'],original.count(old)==1 and raw==original.replace(old,new,1) and len(raw)==variant['bytes'] and digest(raw)==variant['sha256'] and digest(original)==variant['originalSha256'])
    check('variantReversal:'+variant['control'],raw.replace(new,old,1)==original and variant['reversedByteIdentical'] is True)

proof_facts=[]
for proof in result['proofs']:
    check('trueThreeExits:'+proof['control'],[p['actualOriginalExit'] for p in proof['phases']]==[0,1,0])
    original_hashes=[]
    for phase in proof['phases']:
        directory=Path(phase['directory']);r=data(directory/'result.json')
        stdout=read(directory/'stdout.bin').decode();stderr=read(directory/'stderr.bin').decode()
        check('originalArgv:'+proof['control']+':'+phase['phase'],r['command']==phase['command'] and r['actual_process_returncode']==phase['expectedOriginalExit']==phase['actualOriginalExit'])
        check('noOptimize:'+directory.name,r['environment']['PYTHONOPTIMIZE'] in (None,'','0') and '-B' in r['command'])
        parsed={prefix:[json.loads(line[len(prefix):]) for line in stdout.splitlines() if line.startswith(prefix)] for prefix in ('RC_METHOD_BINDING ','RC_METHOD_OUTCOME ','RC_METHOD_GIT ')}
        check('uniqueBindingOutcome:'+directory.name,len(parsed['RC_METHOD_BINDING '])==len(parsed['RC_METHOD_OUTCOME '])==1)
        binding=parsed['RC_METHOD_BINDING '][0];outcome=parsed['RC_METHOD_OUTCOME '][0];gitlog=parsed['RC_METHOD_GIT ']
        check('exactFiveInputHashes:'+directory.name,binding['inputSha256']==input_hashes and binding['originalOracleSha256']==digest(original))
        original_hashes.append(binding['originalOracleSha256'])
        check('exactMethodAndNormalOutcome:'+directory.name,binding['method']==outcome['method']=='test_rc_face_is_measured_along_its_unlined_run' and outcome['testsRun']==1 and outcome['errors']==0 and outcome['skips']==0 and outcome['assertionFailures']==phase['actualOriginalExit'] and outcome['originalFilesUnchanged'] is True)
        check('originalUnittestFooter:'+directory.name,re.search(r'Ran 1 test in [0-9.]+s',stderr) is not None and ('FAILED (failures=1)' in stderr if phase['phase']=='withdrawn' else stderr.rstrip().endswith('OK')))
        check('noInfrastructureError:'+directory.name,all(word not in stderr for word in ('ERROR:','ImportError','SyntaxError','RC_METHOD_INFRASTRUCTURE','Traceback (most recent call last):\n  File "'+str(B/'tools'))))
        check('nineOriginalGitChecks:'+directory.name,len(gitlog)==9 and all(x['exit']==0 for x in gitlog))
        heads=[x for x in gitlog if x['argv']==['git','rev-parse','HEAD']]
        statuses=[x for x in gitlog if x['argv']==['git','status','--porcelain=v1','--untracked-files=all']]
        check('beforeAfterCleanSHA:'+directory.name,len(heads)==len(statuses)==2 and all(x['stdout']==SHA+'\n' for x in heads) and all(x['stdout']=='' for x in statuses))
        for name,raw in inputs.items():
            record=[x for x in gitlog if x['argv']==['git','show',SHA+':'+name]]
            check('originalInlineGitBlob:'+directory.name+':'+name,len(record)==1 and record[0]['stdout'].encode()==raw)
        if phase['phase']=='withdrawn':
            expected_assert='self.assertEqual(("buildable", []), fo.verdict(res, params))' if proof['control']=='builder-whole-face' else 'self.assertFalse(fo.reading_a_has_bare_rc(reg, 0, 500, (73, 100), [(90, 100)], [(0, 73)]))'
            check('specificOriginalAssertion:'+directory.name,'FAIL: test_rc_face_is_measured_along_its_unlined_run' in stderr and stderr.count('AssertionError:')==1 and expected_assert in stderr and ('CORE_LIMIT_BOUNDARY_END_RC' in stderr if proof['control']=='builder-whole-face' else 'AssertionError: True is not false' in stderr))
        proof_facts.append({'control':proof['control'],'phase':phase['phase'],'originalExit':phase['actualOriginalExit'],'directory':str(directory),'originalOutcome':outcome,'originalOracleSHA256':binding['originalOracleSha256']})
    check('baselineRestoredSameOriginal:'+proof['control'],len(set(original_hashes))==1 and original_hashes[0]==digest(original))

report={'schema':'independent-reading-a-rc-actual-peer.v1','generatedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'readOnly':True,'subjectTestsExecutedByReviewer':False,'actualExecutionSHA':SHA,'laterTrainComparedByFiveInputModeBlobIdentityOnly':LATER,'actualSource':str(source),'originalResultPath':str(B/'RESULT.json'),'originalResultSHA256':inventory[str(B/'RESULT.json')]['sha256'],'checks':checks,'checkCount':len(checks),'findings':[x for x in checks if not x['passed']],'exitCode':0 if all(x['passed'] for x in checks) else 1,'facts':proof_facts,'originalGitReadMetadata':git_rows,'limitations':['Actual execution is F64, never relabelled as later train execution. Only the five exact oracle/method fixture Git mode/blob identities were compared to train5049.','Two targeted RC withdrawals each ran the one original unittest method baseline/withdrawn/restored. This is not the full Reading A sweep, native workflow, or global mutation ledger.','Public Git archive roundtrip was outside this narrow actual review; original caller retains the complete raw files indexed separately.','R3 acquisition/release is original caller metadata and was statically reviewed; reviewer did not take or bypass R3.']}
(OUT/'CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'RAW_INVENTORY.json').write_text(json.dumps({'files':inventory,'bytes':sum(x['bytes'] for x in inventory.values())},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(OUT/'CHECKS.json'),'sha256':digest((OUT/'CHECKS.json').read_bytes()),'checkCount':len(checks),'findings':report['findings'],'exitCode':report['exitCode'],'rawInventorySHA256':digest((OUT/'RAW_INVENTORY.json').read_bytes())},ensure_ascii=False))
raise SystemExit(report['exitCode'])
