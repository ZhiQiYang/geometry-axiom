"""Read closed evidence only; measure a lossless fourth payload in memory."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import lzma
import os
import shutil
import stat
import tarfile

P = Path('/tmp/geo-resume1758-extra168-proof-plan-20261026')
OWN = Path('/dev/shm/geometry-axiom-geo337-20261025')
OTHER = Path('/dev/shm/geo337-F9-browsers-20261025')
PUB = OWN / 'continuation-publication-175947-20261026'
E = 'df84890966a600d3ba7e39c5b8ba882b18d1a9b2'
PROPOSED_PROOF = OWN / 'extra168-proof-stage-20261026/PROOF.tar.gz'


def h(b):
    return hashlib.sha256(b).hexdigest()


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def encode(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def facts(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=s.st_mode, uid=s.st_uid,
                gid=s.st_gid, nlink=s.st_nlink, bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns,
                allocated_bytes=s.st_blocks * 512)


def read(path):
    need(path.is_absolute(), 'absolute source required')
    for parent in reversed(path.parents):
        need(stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(), 'symlink ancestor')
    before = facts(path.lstat())
    need(stat.S_ISREG(before['mode']) and not path.is_symlink(), 'regular source required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    try:
        need(facts(os.fstat(fd)) == before, 'source changed at open')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        need(facts(os.fstat(fd)) == before, 'source changed at read')
    finally:
        os.close(fd)
    need(facts(path.lstat()) == before and len(raw) == before['bytes'], 'source changed after read')
    return raw, before


def used():
    seen, total = set(), 0
    for root in (OWN, OTHER):
        for path in root.rglob('*'):
            s = path.lstat()
            key = s.st_dev, s.st_ino
            if key not in seen:
                seen.add(key)
                total += s.st_blocks * 512
    return total


def main():
    roots_raw, _ = read(P / 'SOURCE_ROOTS.json')
    scope = json.loads(roots_raw)
    need(scope['external_fixed_evidence_head'] == E, 'external evidence changed')
    sources = []
    directory_files = {}
    for root in map(Path, scope['directories']):
        need(root.is_dir() and not root.is_symlink(), 'missing/linked explicit closed directory')
        entries = sorted(root.rglob('*'))
        need(all(not x.is_symlink() for x in entries), 'symlink in closed scope')
        files = [x for x in entries if x.is_file()]
        need(all(x.is_file() or x.is_dir() for x in entries), 'special file in closed scope')
        directory_files[str(root)] = [str(x) for x in files]
        sources.extend(files)
    sources.extend(map(Path, scope['individual_files']))
    need(len(set(sources)) == len(sources), 'overlapping source roots')
    sources = sorted(sources)
    contents, states = {}, {}
    for path in sources:
        contents[str(path)], states[str(path)] = read(path)
    backup_peer_path = '/tmp/geo-resume1758-extra168-backup-preparation-20261026/ACTUAL_REVIEW.json'
    need(backup_peer_path in contents, 'backup actual peer not closed')
    need(h(contents[backup_peer_path]) == '5d2e497a37121cd1b76eac1013b1f329d51e0b9b8e851f6146890026ce0bb161', 'backup actual peer pin changed')
    backup_peer = json.loads(contents[backup_peer_path])
    need(backup_peer['exit_code'] == 0 and not backup_peer['blocking_findings'], 'backup peer blocked')
    result_raw = contents[str(PUB / 'RESULT.json')]
    need(h(result_raw) == '757a521750d8558f7a335377c57c6a53c7daec781ffdae8cb5a5ade997c350f2', 'published result changed')
    published = json.loads(result_raw)
    need(published['exit_code'] == 0 and published['delivered'] is True and published['evidence_head'] == E, 'publication not terminal')
    publication_peer_path = '/tmp/geo-resume1758-publication-actual-peer-20261026/REVIEW.json'
    publication_peer_raw = contents[publication_peer_path]
    need(h(publication_peer_raw) == '1aff08605f83dc2f7f8809e0093b5aa1c258eb577094929a49ac9e4e093fd86b', 'publication peer changed')
    publication_peer = json.loads(publication_peer_raw)
    need(publication_peer['exit_code'] == 0 and not publication_peer['blocking_findings']
         and publication_peer['published_evidence_head'] == E, 'published path/blob review blocked')
    commands_raw = contents[str(PUB / 'subcommands.json')]
    commands = json.loads(commands_raw)
    manifest = json.loads(contents[str(PUB / 'MANIFEST.json')])
    remote = json.loads(contents[str(PUB / 'REMOTE_BLOBS.json')])
    external = []
    for number in scope['only_permitted_external_stdout_commands']:
        directory = PUB / 'subcommands' / f'{number:06d}'
        raw_path = directory / 'stdout.bin'
        raw = contents[str(raw_path)]
        command = next(x for x in commands if x['directory'] == str(directory))
        need(command['command'][:2] == ['gh', 'api'] and command['command'][2:6] ==
             ['--hostname', 'github.com', '-H', 'Accept: application/vnd.github.raw+json'], 'not exact raw API command')
        blob = command['command'][-1].split('/')[-1]
        need(len(blob) == 40 and command['command'][-1] == 'repos/ZhiQiYang/geometry-axiom/git/blobs/' + blob, 'wrong API endpoint')
        need(command['actual_process_returncode'] == 0 and not command['timeout_expired'], 'remote command not terminal 0')
        need(command['stdout_sha256'] == h(raw) and command['stdout_bytes'] == len(raw), 'full stdout mismatch')
        need(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == blob, 'raw Git OID mismatch')
        declared = next(x for x in manifest['files'] if x['sha256'] == h(raw) and x['bytes'] == len(raw))
        source_raw, _ = read(Path(declared['source_path']))
        need(source_raw == raw, 'published source not byte-identical to raw stdout')
        remote_row = next(x for x in remote if x['blob_oid'] == blob)
        need(remote_row == dict(blob_oid=blob, bytes=len(raw), sha256=h(raw)), 'REMOTE_BLOBS mismatch')
        peer_row = next(x for x in publication_peer['summary']['remote_raw_bindings'] if x['command_number'] == number)
        need(peer_row == dict(blob_oid=blob, bytes=len(raw), sha256=h(raw), destination=declared['destination'], command_number=number), 'fixed E/path/blob proof mismatch')
        need(json.loads(contents[str(directory / 'result.json')]) == command, 'per-command result differs from command table')
        external.append(dict(original_source=str(raw_path), bytes=len(raw), sha256=h(raw),
                             git_blob_oid=blob, evidence_head=E, repository_path=declared['destination'],
                             permalink='https://github.com/ZhiQiYang/geometry-axiom/blob/' + E + '/' + declared['destination'],
                             original_command_result_source=str(directory / 'result.json'),
                             command_number=number, original_command_exit_code=0,
                             publication_peer_sha256=h(publication_peer_raw),
                             published_result_sha256=h(result_raw),
                             exact_original_raw_stdout=True, no_new_API_request=True,
                             restoration='Read exact Git blob at the pinned commit/path or blob OID; verify byte count, SHA256 and Git blob OID before restoring only to an approved fresh receipt staging path.'))
    need(len(external) == 6 and len({x['original_source'] for x in external}) == 6, 'external scope must be exactly six full streams')
    external_by_path = {x['original_source']: x for x in external}
    records = []
    for path in sources:
        name = str(path)
        row = dict(original_source=name, bytes=len(contents[name]), sha256=h(contents[name]), metadata=states[name])
        if name in external_by_path:
            row.update(storage='external-pinned-complete-raw', external_binding=external_by_path[name])
        else:
            row.update(storage='archive-complete-raw', archive_member='originals/' + name.lstrip('/'))
        records.append(row)
    source_map = dict(schema='closed-extra168-proof-source-map/1', exact_source_roots_sha256=h(roots_raw),
                      sources=records, external_stream_count=6,
                      original_source_files_deleted=False, external_originals_retained=True,
                      only_six_fixed_remote_stdout_streams_external=True,
                      external_requires_reachable_fixed_Git_evidence=True,
                      no_test_result_or_product_SHA_relabeling=True,
                      CURRENT_PROGRESS_not_owned_or_included=True,
                      nativeplan_and_new_axiomprofile_not_read=True)
    map_raw = json.dumps(source_map, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        info = tarfile.TarInfo('SOURCE_MAP.json')
        info.size, info.mode, info.uid, info.gid, info.mtime = len(map_raw), 0o600, 1000, 1000, 0
        archive.addfile(info, io.BytesIO(map_raw))
        for row in records:
            if row['storage'] != 'archive-complete-raw':
                continue
            raw = contents[row['original_source']]
            info = tarfile.TarInfo(row['archive_member'])
            info.size, info.mode, info.uid, info.gid = len(raw), stat.S_IMODE(row['metadata']['mode']), row['metadata']['uid'], row['metadata']['gid']
            ns = row['metadata']['mtime_ns']
            info.mtime = ns // 1000000000
            info.pax_headers = {'mtime': f'{ns//1000000000}.{ns%1000000000:09d}'}
            archive.addfile(info, io.BytesIO(raw))
    tar_raw = buffer.getvalue()
    packed = gzip.compress(tar_raw, compresslevel=6, mtime=0)
    need(gzip.decompress(packed) == tar_raw, 'full proof gzip roundtrip failed')
    included = [x for x in records if x['storage'] == 'archive-complete-raw']
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)), mode='r:') as archive:
        need(archive.getnames() == ['SOURCE_MAP.json'] + [x['archive_member'] for x in included], 'member list mismatch')
        need(archive.extractfile('SOURCE_MAP.json').read() == map_raw, 'source map mismatch')
        for row in included:
            need(archive.extractfile(row['archive_member']).read() == contents[row['original_source']], 'complete original bytes mismatch')
    for path in sources:
        need(facts(path.lstat()) == states[str(path)], 'closed original metadata drifted')
    for root, names in directory_files.items():
        need(sorted(str(x) for x in Path(root).rglob('*') if x.is_file()) == names, 'closed source directory changed')
    old_manifest_path = OWN / 'extra168-backup-materialization-20261026/PUBLISHER_MANIFEST.json'
    old_manifest_raw, _ = read(old_manifest_path)
    old_manifest = json.loads(old_manifest_raw)
    for row in old_manifest['files']:
        raw, _ = read(Path(row['source_path']))
        need(len(raw) == row['bytes'] and h(raw) == row['sha256'], 'original three payload changed')
    files = old_manifest['files'] + [dict(source_path=str(PROPOSED_PROOF),
                 destination='evidence/geo337-train-20261024/extra168-preservation-candidate-20261026/PROOF.tar.gz',
                 bytes=len(packed), sha256=h(packed))]
    four_manifest_raw = encode(dict(files=files))
    publisher_budget = sum(x['bytes'] for x in files) * 3 + len(files) * 65536 + len(four_manifest_raw) * 8 + 64 * 1024**2
    future_source = ((len(packed) + 4095) // 4096) * 4096
    allocated = used()
    free_tmp = shutil.disk_usage('/tmp').free
    outcome = dict(schema='closed-extra168-fourth-proof-memory-plan/1', exit_code=0,
                   observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   preparer_sha256=h(Path(__file__).read_bytes()), source_roots_sha256=h(roots_raw),
                   source_files=len(sources), internal_complete_raw_files=len(included),
                   external_complete_raw_files=6, external_total_bytes=sum(x['bytes'] for x in external),
                   all_other_original_streams_and_metadata_preserved=True,
                   proof_tar_bytes=len(tar_raw), proof_tar_sha256=h(tar_raw),
                   proof_gzip_bytes=len(packed), proof_gzip_sha256=h(packed),
                   gzip_parameters=dict(compresslevel=6, mtime=0),
                   source_map_raw_bytes=len(map_raw), source_map_sha256=h(map_raw),
                   full_gzip_and_all_internal_members_roundtrip=True,
                   all_six_external_full_raw_byte_SHA256_GitOID_fixed_E_path_proven=True,
                   sources_unchanged_at_end=True, proof_payload_materialized=False,
                   original_three_payloads_unchanged=True,
                   original_publisher_formula='total*3+files*65536+manifest_raw_bytes*8+64MiB',
                   four_payload_manifest_bytes=len(four_manifest_raw), four_payload_manifest_sha256=h(four_manifest_raw),
                   four_payload_publisher_bound=publisher_budget, combined_OWN_allocated=allocated,
                   future_proof_source_allocation=future_source, source_counted_before_publisher=True,
                   combined_original_ceiling=2*1024**3,
                   source_plus_publisher_peak=allocated+future_source+publisher_budget,
                   remaining_original_ceiling_bytes=2*1024**3-allocated-future_source-publisher_budget,
                   actual_SHM_free=shutil.disk_usage(OWN).free,
                   original_four_payload_capacity_pass=(allocated+future_source+publisher_budget <= 2*1024**3 and shutil.disk_usage(OWN).free > future_source+publisher_budget),
                   additional_CURRENT_PROGRESS_or_other_payloads_not_in_estimate=True,
                   root_must_freeze_actual_final_manifest_and_fresh_capacity_before_materialize_and_publish=True,
                   actual_TMP_free=free_tmp,
                   hypothetical_TMP_after_new168_if_separately_approved=free_tmp+23707648,
                   hypothetical_TMP_margin_over_original_128MiB=free_tmp+23707648-134217728,
                   not_claiming_4MiB_extra_planning_margin=True,
                   new_cleanup_not_authorized_or_executed=True, new_Git_API_or_product_test_executed=False)
    # Only small planning artifacts are written; packed proof remains in memory.
    (P / 'EXTERNAL_MAP.json').write_bytes(encode(external))
    (P / 'SOURCE_MAP.json.xz').write_bytes(lzma.compress(map_raw, preset=6))
    (P / 'FOUR_PAYLOAD_MANIFEST_PREVIEW.json').write_bytes(four_manifest_raw)
    (P / 'RESULT.json').write_bytes(encode(outcome))
    print(json.dumps(outcome, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
