"""Review only frozen E/D substitution; no publishing or external operations."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
R=Path('/tmp/geo-resume1915-body-handoff-20261026')
O=Path(__file__).parent
def h(b):return hashlib.sha256(b).hexdigest()
old=json.loads((O/'REVIEW_R2.json').read_bytes())
template=(R/'NEXT_PREFIX.template.md').read_bytes()
prefix=(R/'frozen-E-D/NEXT_PREFIX.md').read_bytes()
body=(R/'frozen-E-D/PR_BODY.md').read_bytes()
tool=(R/'publish_metadata.py').read_bytes()
result_path=Path('/dev/shm/geometry-axiom-geo337-20261025/resume1915-body-publication-20261026/RESULT.json')
result_raw=result_path.read_bytes();result=json.loads(result_raw)
E='df84890966a600d3ba7e39c5b8ba882b18d1a9b2';D='a51af370fcfe4bc5022250d2b393db233e9951b6'
checks={
 'prior_static_50_passed':old['exit_code']==0 and not old['blocking'],
 'template_unchanged':h(template)==old['prefix_template_sha256'],
 'publisher_unchanged':h(tool)==old['tool_sha256'],
 'body_unchanged':h(body)==old['document_sha256']['body'],
 'only_expected_E_D_substitution':prefix==template.replace(b'__EVIDENCE_COMMIT__',E.encode()).replace(b'__BODY_COMMIT__',D.encode()),
 'frozen_prefix_hash':h(prefix)=='44a874f7058042a0b98bc6db6f11944d331defe67c26330249f00d61efb77456',
 'no_remaining_placeholders':b'__EVIDENCE_COMMIT__' not in prefix and b'__BODY_COMMIT__' not in prefix,
 'body_terminal_zero':result['exit_code']==0 and result['published'] and result['delivered'],
 'published_body_commit_and_hash':result['commit']==D and result['sha256']==h(body),
 'body_source_E_F':result['evidence_sha']==E and result['product_sha']=='cbf0fb621888596aa14ad5f2349b503e23b1b72d',
 'not_PR_application':result['PR_application_verified'] is False,
 'no_merged_product':result['PR_merged'] is False and result['product_ref_modified'] is False,
}
blocking=[k for k,v in checks.items() if not v]
report={'schema':'frozen-handoff-prefix-static-review/1','utc':datetime.now(timezone.utc).isoformat(),'exit_code':int(bool(blocking)),'blocking':blocking,'tool_sha256':h(tool),'document_sha256':{'body':h(body),'handoff':h(prefix)},'checks':checks,'checks_count':len(checks),'prior_static_review_sha256':h((O/'REVIEW_R2.json').read_bytes()),'body_terminal_sha256':h(result_raw),'scope':'Prefix is identical to reviewed template except fixed E and published D; body full original streams are being checked separately. This does not claim handoff publication or PR body application.','Git_or_network_executed':False,'publisher_executed':False}
(O/'HANDOFF_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':report['exit_code'],'blocking':blocking,'sha256':h((O/'HANDOFF_REVIEW.json').read_bytes())}));raise SystemExit(report['exit_code'])
