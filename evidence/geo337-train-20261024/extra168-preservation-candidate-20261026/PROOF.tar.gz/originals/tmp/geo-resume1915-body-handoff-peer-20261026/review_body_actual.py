"""Verify original body publication bytes only; do not repeat Git or API."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
R=Path('/dev/shm/geometry-axiom-geo337-20261025/resume1915-body-publication-20261026')
O=Path(__file__).parent
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';E='df84890966a600d3ba7e39c5b8ba882b18d1a9b2';D='a51af370fcfe4bc5022250d2b393db233e9951b6';P='990440297d851dccbc077cdf59fe654fdbd9ffd8';A='a6f4013364e21bcb7239b5dcc25caac0f6d61f77'
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def ck(name,ok):checks.append({'name':name,'passed':bool(ok)})
result_raw=(R/'RESULT.json').read_bytes();result=json.loads(result_raw)
rows=json.loads((R/'subcommands.json').read_bytes())
ck('31 original commands',len(rows)==31)
outputs={};inputs={};stream_bytes=0
for i,row in enumerate(rows,1):
    d=Path(row['directory']);ck(f'{i} exact stream root',d==R/'subcommands'/f'{i:06d}')
    ck(f'{i} result identity',json.loads((d/'result.json').read_bytes())==row)
    request=json.loads((d/'request.json').read_bytes())
    ck(f'{i} request matches command',request['command']==row['command'])
    ck(f'{i} source and original zero',row['source_sha']==F and row['acceptance_sha']==F and row['actual_process_returncode']==0 and not row['timeout_expired'])
    ck(f'{i} timestamp order',row['ended_epoch']>=row['started_epoch'])
    for stream in ('stdin','stdout','stderr'):
        b=(d/(stream+'.bin')).read_bytes();stream_bytes+=len(b)
        ck(f'{i} {stream} hash',h(b)==row[stream+'_sha256'])
        if stream!='stdin':ck(f'{i} {stream} bytes',len(b)==row[stream+'_bytes'])
        if stream=='stdout':outputs[i]=b
        if stream=='stdin':inputs[i]=b
body=(R/'INPUT.md').read_bytes();published=(R/'PUBLISHED.md').read_bytes()
ck('body fixed bytes',body==published and h(body)=='e2654b848d90fec408ba8d0484bf8699a1dd849141aa5a3d23a0ca4d9c13d15b' and len(body)==7549)
ck('actual executor covered by peer',h((R/'EXECUTOR.py').read_bytes())=='6afa1889913ad77fe14f087fbd1e8376e417d172671a4496028197c81d806689')
peer=json.loads((R/'PEER.json').read_bytes())
ck('actual peer passed frozen body',peer['exit_code']==0 and not peer['blocking'] and peer['document_sha256']['body']==h(body) and peer['tool_sha256']==h((R/'EXECUTOR.py').read_bytes()))
before=json.loads((R/'BEFORE.json').read_bytes());after=json.loads((R/'AFTER.json').read_bytes())
ck('exact head/index/status unchanged',before==after and before['HEAD']==before['train_ref']=='3e4f2560aa11ed2a626db98ba5ed6f129e791052' and before['status']=='')
ck('state streams confirm unchanged',outputs[1]==outputs[19]==outputs[27] and outputs[2]==outputs[20]==outputs[28] and outputs[3]==outputs[21]==outputs[29] and outputs[4]==outputs[22]==outputs[30]==b'')
bodyref='refs/heads/codex/train337-recovered-evidence-20261026-prbody'
ck('old remote parent read twice',outputs[5]==outputs[23]==(P+'\t'+bodyref+'\n').encode())
ck('new remote exact D',outputs[25]==(D+'\t'+bodyref+'\n').encode())
ck('product ref unchanged A',outputs[6]==outputs[31]==(A+'\trefs/heads/codex/train-337-continue-20261024\n').encode())
ck('evidence remote exact E',outputs[7]==(E+'\trefs/heads/codex/train337-recovered-evidence-20261026\n').encode())
ck('evidence only paths',outputs[9].splitlines() and all(p.startswith(b'evidence/') for p in outputs[9].splitlines()))
ck('progress fixed',h(outputs[8])=='65bc4fe930487a2ce96d913e5382ac1f209bb77bfa0d96139bc1ced4dc861c06')
ck('before body original retained',outputs[10]==(R/'BEFORE.md').read_bytes() and h(outputs[10])=='4f8e24fe0096db68f93cf06df8e3e23612d8b15748577593d09a25fb5c21731a')
blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
ck('written exact body blob',inputs[11]==body and outputs[11]==(blob+'\n').encode() and blob==result['blob'])
def tree(raw):
    result={}
    for row in raw.split(b'\0'):
        if row:
            header,name=row.split(b'\t',1);result[name]=tuple(header.split(b' '))
    return result
old_tree=tree(outputs[13]);new_tree=tree(outputs[15]);diff=[p for p in old_tree.keys()|new_tree.keys() if old_tree.get(p)!=new_tree.get(p)]
ck('root tree changed only body',diff==[b'PR_BODY.md'])
ck('body mode kept normal',new_tree[b'PR_BODY.md']==(b'100644',b'blob',blob.encode()))
ck('mktree stdin matches actual new tree',tree(inputs[14])==new_tree)
ck('normal single parent commit',outputs[16]==(D+'\n').encode() and outputs[18]==(P+'\n').encode() and rows[15]['command'][-2:]==['-p',P])
ck('English commit message',inputs[16]==b'docs: publish verified cleanup and candidate reader status\n')
ck('single leaf actual diff',outputs[17]==b'PR_BODY.md\0')
ck('exact normal push',rows[23]['command']==['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin',D+':'+bodyref])
ck('one push, no force/history rewrite',sum('push' in x['command'] for x in rows)==1 and not any(any(flag in x['command'] for flag in ['--force','--force-with-lease','merge','rebase','reset']) for x in rows))
ck('full remote API readback',rows[25]['command'][-1]=='repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob and outputs[26]==body)
capacity=json.loads((R/'CAPACITY.json').read_bytes())
ck('original capacity passed',capacity['additional_bound']==67108864 and capacity['ceiling']==2147483648 and capacity['two_OWN_allocated']+capacity['additional_bound']<=capacity['ceiling'])
ck('true terminal source/commit',result['exit_code']==0 and result['published'] and result['delivered'] and result['product_sha']==F and result['evidence_sha']==E and result['commit']==D and result['expected_parent']==P)
ck('no product/PR merge or application claim',not result['PR_merged'] and not result['product_ref_modified'] and result['PR_application_verified'] is False and result['head_and_index_unchanged'])
blocking=[c['name'] for c in checks if not c['passed']]
report={'schema':'body-publication-original-stream-review/1','utc':datetime.now(timezone.utc).isoformat(),'exit_code':int(bool(blocking)),'blocking':blocking,'subject_result_sha256':h(result_raw),'body_commit':D,'body_sha256':h(body),'tool_sha256':h((R/'EXECUTOR.py').read_bytes()),'checks_count':len(checks),'checks':checks,'original_commands':len(rows),'original_streams':len(rows)*3,'original_stream_bytes':stream_bytes,'Git_or_network_executed':False,'publisher_executed':False,'product_tests_executed':False,'PR_application_verified':False}
(O/'BODY_ACTUAL_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':report['exit_code'],'blocking':blocking,'checks':len(checks),'sha256':h((O/'BODY_ACTUAL_REVIEW.json').read_bytes())}));raise SystemExit(report['exit_code'])
