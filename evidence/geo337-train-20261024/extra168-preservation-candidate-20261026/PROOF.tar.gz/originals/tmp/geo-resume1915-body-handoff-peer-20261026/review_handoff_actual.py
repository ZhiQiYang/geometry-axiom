"""Review original handoff records, never repeat publisher, Git, API, or tests."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
R=Path('/dev/shm/geometry-axiom-geo337-20261025/resume1915-handoff-publication-20261026')
O=Path(__file__).parent
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';E='df84890966a600d3ba7e39c5b8ba882b18d1a9b2';D='a51af370fcfe4bc5022250d2b393db233e9951b6';P='628507bceec091241ee3c83fc1003ff2ac31ac74';H='2d18b25b56ae47308a56c478497fd10193cf6e26';A='a6f4013364e21bcb7239b5dcc25caac0f6d61f77'
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def ck(name,ok):checks.append({'name':name,'passed':bool(ok)})
result_raw=(R/'RESULT.json').read_bytes();result=json.loads(result_raw)
rows=json.loads((R/'subcommands.json').read_bytes());ck('37 original commands',len(rows)==37)
outputs={};inputs={};stream_bytes=0
for i,row in enumerate(rows,1):
    d=Path(row['directory']);ck(f'{i} original stream root',d==R/'subcommands'/f'{i:06d}')
    ck(f'{i} result identity',json.loads((d/'result.json').read_bytes())==row)
    ck(f'{i} request command',json.loads((d/'request.json').read_bytes())['command']==row['command'])
    ck(f'{i} original zero/time/source',row['source_sha']==F and row['acceptance_sha']==F and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'])
    for stream in ('stdin','stdout','stderr'):
        b=(d/(stream+'.bin')).read_bytes();stream_bytes+=len(b)
        ck(f'{i} {stream} hash',h(b)==row[stream+'_sha256'])
        if stream!='stdin':ck(f'{i} {stream} count',len(b)==row[stream+'_bytes'])
        if stream=='stdout':outputs[i]=b
        if stream=='stdin':inputs[i]=b
prefix=(R/'INPUT.md').read_bytes();old=(R/'BEFORE.md').read_bytes();published=(R/'PUBLISHED.md').read_bytes()
ck('frozen prefix covered',h(prefix)=='44a874f7058042a0b98bc6db6f11944d331defe67c26330249f00d61efb77456')
ck('old entire handoff retained',old==outputs[10] and len(old)==79234 and published==prefix+'\n\n---\n\n## 先前交接原文（完整保留，以下為歷史）\n\n'.encode()+old)
ck('full new bytes expected',len(published)==82588 and h(published)=='327d0e3103458f9f8a42c5cd5520749d70f64ed01fa519a39f9ed91d2571e759')
ck('tool unchanged covered',h((R/'EXECUTOR.py').read_bytes())=='6afa1889913ad77fe14f087fbd1e8376e417d172671a4496028197c81d806689')
peer=json.loads((R/'PEER.json').read_bytes());ck('peer exact prefix/tool',peer['exit_code']==0 and not peer['blocking'] and peer['document_sha256']['handoff']==h(prefix) and peer['tool_sha256']==h((R/'EXECUTOR.py').read_bytes()))
before=json.loads((R/'BEFORE.json').read_bytes());after=json.loads((R/'AFTER.json').read_bytes())
ck('publisher HEAD/index/worktree unchanged',before==after and before['HEAD']==before['train_ref']=='3e4f2560aa11ed2a626db98ba5ed6f129e791052' and before['status']=='')
ck('three original state streams equal',outputs[1]==outputs[25]==outputs[33] and outputs[2]==outputs[26]==outputs[34] and outputs[3]==outputs[27]==outputs[35] and outputs[4]==outputs[28]==outputs[36]==b'')
ref='refs/heads/handoff/codex-takeover-20261021';bodyref='refs/heads/codex/train337-recovered-evidence-20261026-prbody'
ck('parent remote before and prepush',outputs[5]==outputs[29]==(P+'\t'+ref+'\n').encode())
ck('new remote H',outputs[31]==(H+'\t'+ref+'\n').encode())
ck('original train ref unchanged',outputs[6]==outputs[37]==(A+'\trefs/heads/codex/train-337-continue-20261024\n').encode())
ck('evidence E remotely pinned',outputs[7]==(E+'\trefs/heads/codex/train337-recovered-evidence-20261026\n').encode())
ck('body D remotely pinned',outputs[11]==(D+'\t'+bodyref+'\n').encode())
ck('body exact unchanged',len(outputs[12])==7549 and h(outputs[12])=='e2654b848d90fec408ba8d0484bf8699a1dd849141aa5a3d23a0ca4d9c13d15b')
request=json.loads(outputs[13]);ck('existing request exact',request=={'head':'codex/train-337-continue-20261024','base':'main','title':'feat: complete the reading A integration train replacing #337','body_ref':'codex/train337-recovered-evidence-20261026-prbody','body_path':'PR_BODY.md'} and outputs[13]==(R/'REQUEST_UNCHANGED.json').read_bytes())
blob=hashlib.sha1(b'blob '+str(len(published)).encode()+b'\0'+published).hexdigest()
ck('exact written blob',inputs[14]==published and outputs[14]==(blob+'\n').encode() and result['blob']==blob)
def tree(raw):
    d={}
    for row in raw.split(b'\0'):
        if row:
            header,name=row.split(b'\t',1);d[name]=tuple(header.split(b' '))
    return d
before_root=tree(outputs[16]);before_sub=tree(outputs[17]);after_sub=tree(outputs[19]);after_root=tree(outputs[21])
ck('only root handoff entry changed',[p for p in before_root.keys()|after_root.keys() if before_root.get(p)!=after_root.get(p)]==[b'handoff'])
ck('only handoff NEXT changed',[p for p in before_sub.keys()|after_sub.keys() if before_sub.get(p)!=after_sub.get(p)]==[b'NEXT.md'])
ck('request subtree untouched',before_sub[b'pr-requests']==after_sub[b'pr-requests'])
ck('tree stdin matches readback',tree(inputs[18])==after_sub and tree(inputs[20])==after_root)
ck('new NEXT blob mode',after_sub[b'NEXT.md']==(b'100644',b'blob',blob.encode()))
ck('single parent H',outputs[22]==(H+'\n').encode() and outputs[24]==(P+'\n').encode() and rows[21]['command'][-2:]==['-p',P])
ck('single leaf actual delta',outputs[23]==b'handoff/NEXT.md\0')
ck('English commit message',inputs[22]==b'docs: hand off completed cleanup and candidate reader evidence\n')
ck('one ordinary push',rows[29]['command']==['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin',H+':'+ref] and sum('push' in r['command'] for r in rows)==1)
ck('no force or rewriting',not any(any(v in r['command'] for v in ['--force','--force-with-lease','merge','rebase','reset']) for r in rows))
ck('full remote exact readback',rows[31]['command'][-1]=='repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob and outputs[32]==published)
capacity=json.loads((R/'CAPACITY.json').read_bytes());ck('original capacity gate',capacity['additional_bound']==67108864 and capacity['ceiling']==2147483648 and capacity['two_OWN_allocated']+capacity['additional_bound']<=capacity['ceiling'])
ck('true successful terminal',result['exit_code']==0 and result['published'] and result['delivered'] and result['commit']==H and result['product_sha']==F and result['evidence_sha']==E)
ck('not main merge/product edit/PR application',not result['PR_merged'] and not result['product_ref_modified'] and result['PR_application_verified'] is False)
blocking=[c['name'] for c in checks if not c['passed']]
report={'schema':'handoff-publication-original-stream-review/1','utc':datetime.now(timezone.utc).isoformat(),'exit_code':int(bool(blocking)),'blocking':blocking,'subject_result_sha256':h(result_raw),'handoff_commit':H,'body_commit':D,'handoff_sha256':h(published),'tool_sha256':h((R/'EXECUTOR.py').read_bytes()),'checks_count':len(checks),'checks':checks,'original_commands':len(rows),'original_streams':len(rows)*3,'original_stream_bytes':stream_bytes,'Git_or_network_executed':False,'publisher_executed':False,'product_tests_executed':False,'PR_application_verified':False,'preservation_scope':'Original records prove publisher HEAD/index/working-tree preservation and only NEXT changed. No separate new old-/workspace snapshot was recorded; static publisher has no write path there.'}
(O/'HANDOFF_ACTUAL_REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
body_report=(O/'BODY_ACTUAL_REVIEW.json').read_bytes();bj=json.loads(body_report)
summary={'schema':'metadata-publication-actual-summary/1','exit_code':max(report['exit_code'],bj['exit_code']),'body':{'review':'BODY_ACTUAL_REVIEW.json','sha256':h(body_report),'commit':D,'exit_code':bj['exit_code'],'repeated':False},'handoff':{'review':'HANDOFF_ACTUAL_REVIEW.json','sha256':h((O/'HANDOFF_ACTUAL_REVIEW.json').read_bytes()),'commit':H,'exit_code':report['exit_code']},'PR_application_verified':False,'new_Git_or_network_executed':False}
(O/'METADATA_ACTUAL_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':report['exit_code'],'blocking':blocking,'checks':len(checks),'review_sha256':h((O/'HANDOFF_ACTUAL_REVIEW.json').read_bytes()),'summary_sha256':h((O/'METADATA_ACTUAL_SUMMARY.json').read_bytes())}));raise SystemExit(report['exit_code'])
