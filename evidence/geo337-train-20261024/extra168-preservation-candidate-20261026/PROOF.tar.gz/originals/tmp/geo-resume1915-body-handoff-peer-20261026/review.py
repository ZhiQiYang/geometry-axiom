"""One read-only static review; no Git, network, publisher, or product execution."""
import ast
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/tmp/geo-resume1915-body-handoff-20261026')
OUT = Path(__file__).parent
checks = []
def h(raw):
    return hashlib.sha256(raw).hexdigest()
def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
def read(relative, expected):
    raw = (ROOT/relative).read_bytes()
    check('fixed bytes: '+relative, h(raw) == expected)
    return raw

body_raw = read('frozen-E/PR_BODY.md', 'e2654b848d90fec408ba8d0484bf8699a1dd849141aa5a3d23a0ca4d9c13d15b')
prefix_raw = read('NEXT_PREFIX.template.md', 'e6f35d6dd126feb4068a3da3010e9879c6e74cb0aedc94b2b1fba647e0e08b64')
tool_raw = read('publish_metadata.py', '6afa1889913ad77fe14f087fbd1e8376e417d172671a4496028197c81d806689')
freeze_raw = read('freeze_documents.py', '06de0fbc1278ca3dae51b37d1722f3d815838e82e0d15a74ec4dbaec5a4585ee')
body = body_raw.decode(); prefix = prefix_raw.decode(); tool = tool_raw.decode()
tree = ast.parse(tool_raw); ast.parse(freeze_raw)
check('both Python files parse without execution', True)
publication_path = Path('/dev/shm/geometry-axiom-geo337-20261025/continuation-publication-175947-20261026/RESULT.json')
publication_raw = publication_path.read_bytes(); publication = json.loads(publication_raw)
check('publication actually delivered E', publication['exit_code'] == 0 and publication['published'] and publication['delivered'] and publication['evidence_head'] == 'df84890966a600d3ba7e39c5b8ba882b18d1a9b2' and publication['remote_blobs_verified'] == 6)
check('publication product and train unchanged', not publication['product_modified'] and not publication['train_ref_modified'] and publication['existing_writer_unchanged'])
sources = {}
for path, expected in [
    ('/tmp/geo-resume1758-root-20261026/PROGRESS-175947-final.md','65bc4fe930487a2ce96d913e5382ac1f209bb77bfa0d96139bc1ced4dc861c06'),
    ('/tmp/geo-resume1758-reader-actual-peer-20261026/REVIEW.json','805e8a051614c2d9d47a2852998fe54f283f9b46515c0c4451fba1ec7763a6f9'),
    ('/tmp/geo-resume1758-retirement-peer-20261026/RETIREMENT_ACTUAL_REVIEW_R2.json','839c02c12613bd46b101a0ba2155a006c66c9af10f09fb65cf6d81008232639c'),
    ('/dev/shm/geometry-axiom-geo337-20261025/reader-F-175947-20261026/RESULT.json','c4f253756cdb03d0f753c60b8a33b824104caa9cbd383f8e93f057a67a2fd94c'),
    ('/dev/shm/geometry-axiom-geo337-20261025/native-TMP-retirement-20261025/RESULT.json','075534e2c72f827b30fbe3d5d7da65398a371183fa263df12180ae5d8949aa4e'),
]:
    raw = Path(path).read_bytes(); sources[path] = h(raw)
    check('original source pin: '+path, h(raw)==expected)

for label, ok in [
    ('one current gate matrix', body.count('| Gate |')==1 and '唯一 current-state' in body),
    ('unmerged and incomplete explicit', '尚未 READY-TO-MERGE' in body and '完整雲端替代 CI | **尚不成立**' in body),
    ('fixed new F retained', 'cbf0fb621888596aa14ad5f2349b503e23b1b72d' in body),
    ('fixed E links count', body.count('df84890966a600d3ba7e39c5b8ba882b18d1a9b2')==4),
    ('no unresolved body placeholders', '__EVIDENCE_COMMIT__' not in body and '__BODY_COMMIT__' not in body),
    ('reader facts intact', '51 tests、0 skip' in body and '173 則 ResourceWarning' in body and 'inner 與 outer 全 0' in body),
    ('reader timer truth', '實際 timeout=None' in body and '未使用的 300/1200' in body),
    ('legacy full123 not rerun', '不是本輪新跑' in body and '沒有重產已有效帳本' in body),
    ('native and all six browsers unrun', body.count('新 F **UNRUN**')==7),
    ('historical failed native retained', 'F9 exit 1：5327 pass／1 fail／1 原允許 GDI skip' in body),
    ('original browser skips retained', '原 2 個分組 skip' in body and '原 5 個分組 skip' in body),
    ('axiom not represented passed', '新 F 兩項尚未正式執行' in body),
    ('R8 failed outer retained', '原 outer exit 1' in body and '不重抽最好樣本' in body),
    ('P189 original red and authority limit retained', '原 P-189 exact 紅燈保留' in body and '未核實對應新原始批准' in body),
    ('account versus direct instruction distinction', '帳戶核實不等於本對話直接原話' in body and '本機 Claude 整理，非原話' in body),
    ('cleanup completed, no longer awaiting approval', '3156 檔與 108 空目錄完成，跳過 0' in body and '這一批已完成，不再待批准' in body),
    ('new 168 scope explicitly not authorized', '3 個舊私有 index＋165 個 GPU cache' in body and '未取得新增刪除批准、未刪除' in body),
    ('fresh need and historical native gap distinguished', '18:30 當時' in body and '16,658,432' in body and '須 fresh 檢查' in body),
    ('all original resource guards retained', all(x in body for x in ['416 MiB＋thin seed','448 MiB','128 MiB','2 GiB'])),
    ('external stdout scope transparent', '1635 個原件' in body and '24 個 API stdout' in body and '不含這 24 個 gzip 容器' in body),
    ('manager ledger unknown and operations unrun', 'private ledger 仍 unknown' in body and '均 UNRUN' in body),
    ('no expansion #54 to #87', '#54 僅單房，不擴 #87' in body),
    ('prefix template not executable yet', prefix.count('__EVIDENCE_COMMIT__')==3 and prefix.count('__BODY_COMMIT__')==1),
    ('prefix preserves old handoff/request', '下方舊 NEXT 完整保留為歷史' in prefix and '不須再改 head/base/title' in prefix),
    ('prefix does not equate body push to PR application', '不能只據分支推送宣稱 PR 已更新' in prefix),
]: check(label,ok)

calls=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='git':
        first=node.args[0] if node.args else None
        if isinstance(first,ast.Constant):calls.append(first.value)
check('normal push only', calls.count('push')==1 and not any(x in calls for x in ['update-ref','checkout','switch','reset','rebase','merge','clean','gc','maintenance']))
check('no force push flags', '--force' not in tool and '--force-with-lease' not in tool)
check('single guarded metadata leaf', "target='PR_BODY.md' if a.mode=='body' else 'handoff/NEXT.md'" in tool and "==target.encode()+b'\\0'" in tool)
check('expected parent before creation and push', "remote(branch)==a.expected_parent" in tool and "git('commit-tree',tree,'-p',a.expected_parent" in tool)
check('index and product ref guard before/after', 'state()==before' in tool and 'after==before and remote(TRAIN)==A' in tool)
check('preserve original request and old handoff', "data.endswith(old)" in tool and "REQUEST_UNCHANGED.json" in tool and "body_ref':BODY" in tool)
check('fixed publication capacity guard', 'used+67108864<=2147483648' in tool and 'free>=67108864' in tool)
check('read-only default', 'if not a.execute:' in tool and tool.index('if not a.execute:') < tool.index('a.out.mkdir()'))
check('fresh root-owned output', 'not a.out.exists() and a.out.parent==OWN' in tool)
check('peer binds mode document and publisher', "peer['tool_sha256']==h(__file__)" in tool and "peer['document_sha256'].get(a.mode)==a.document_sha256" in tool)
check('full remote output verification', 'fetched==data' in tool and 'application/vnd.github.raw+json' in tool)
check('PR application never implied', 'PR_application_verified=False' in tool)
check('no deletion APIs', not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['unlink','rmdir','rmtree','remove'] for n in ast.walk(tree)))

blocking=[x['name'] for x in checks if not x['passed']]
result={
    'schema':'independent-body-and-metadata-static-review/1',
    'utc':datetime.now(timezone.utc).isoformat(),
    'exit_code':int(bool(blocking)), 'blocking':blocking,
    'tool_sha256':h(tool_raw), 'document_sha256':{'body':h(body_raw)},
    'prefix_template_sha256':h(prefix_raw), 'freeze_tool_sha256':h(freeze_raw),
    'publication_result_sha256':h(publication_raw), 'source_pins':sources,
    'checks':checks,'checks_count':len(checks),
    'manual_review':'Read all body/prefix/publisher/freeze text; source and authority boundaries match frozen original receipts. Prefix is not approved as an executable handoff input until its D token is replaced and separately reviewed.',
    'Git_or_network_executed':False,'publisher_executed':False,'product_tests_executed':False,
    'review_scope':'frozen body content and both publisher modes static review; no claimed remote body application or publication execution',
}
(OUT/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':result['exit_code'],'blocking':blocking,'checks':len(checks),'review_sha256':h((OUT/'REVIEW.json').read_bytes())}))
raise SystemExit(result['exit_code'])
