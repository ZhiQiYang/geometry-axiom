"""Correct one review literal; retain the first review, inputs, and failure."""
from pathlib import Path
original = Path(__file__).with_name('review.py')
source = original.read_text()
before = "'尚未 READY-TO-MERGE' in body"
after = "'仍未 READY-TO-MERGE' in body"
assert source.count(before) == 1
assert source.count("'REVIEW.json'") == 2
source = source.replace(before, after).replace("'REVIEW.json'", "'REVIEW_R2.json'")
exec(compile(source, str(original), 'exec'), {'__file__':str(original),'__name__':'__main__'})
