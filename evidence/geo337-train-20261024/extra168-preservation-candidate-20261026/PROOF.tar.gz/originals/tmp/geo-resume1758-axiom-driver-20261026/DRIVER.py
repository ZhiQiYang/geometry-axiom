"""Bounded, driver-only resource diagnosis for the fixed F axiom adapter.

Plan-only by default. This never executes cc1/as/ld, a test, or a produced ELF.
No source mutation, cache access, cleanup, publication, or acceptance result.
Root assigns the source and the existing scheduler lock before --execute.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import resource
import selectors
import shlex
import shutil
import signal
import subprocess
import time
import traceback

F = "cbf0fb621888596aa14ad5f2349b503e23b1b72d"
OWN = Path("/dev/shm/geometry-axiom-geo337-20261025")
OTHER = Path("/dev/shm/geo337-F9-browsers-20261025")
SOURCE = OWN / "a6-architecture-source-20261026"
PLAN = Path("/tmp/geo-resume1758-axiom-resource-plan-20261026")
PLAN_PIN = "9c4939dd4927aefe656328eb9dd85da9f7a5865cb8ac7ddeaea23d24ed1c1bde"
LOCK = Path("/tmp/g261r3/heavy.lock")
CEILING = 2 * 1024**3
TMP_RESERVE = 1024**2
RAW_RESERVE = 1024**2
STREAM_CAP = 64 * 1024
DRIVER_SECONDS = 30


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def filehash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def allocated(roots):
    seen = set()
    result = 0
    for root in roots:
        pending = [Path(root)]
        while pending:
            path = pending.pop()
            st = path.lstat()
            key = (st.st_dev, st.st_ino)
            if key in seen:
                continue
            seen.add(key)
            result += st.st_blocks * 512
            if path.is_dir() and not path.is_symlink():
                pending.extend(path.iterdir())
    return result


def available(path):
    st = os.statvfs(path)
    return st.f_bavail * st.f_frsize


def git(*args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    for key in list(env):
        if key.startswith("GIT_") and key != "GIT_OPTIONAL_LOCKS":
            del env[key]
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], env=env)


def verify_plan():
    need(filehash(PLAN / "MANIFEST.json") == PLAN_PIN, "Resource plan manifest drift")
    manifest = json.loads((PLAN / "MANIFEST.json").read_text())
    for row in manifest["files"]:
        path = PLAN / row["path"]
        need(path.is_file() and path.stat().st_size == row["bytes"] and
             filehash(path) == row["sha256"], "Resource plan leaf drift: " + str(path))


def source_guard():
    need(git("rev-parse", "HEAD").decode().strip() == F, "Source HEAD mismatch")
    need(not git("status", "--porcelain=v1", "--untracked-files=all"), "Source is dirty")
    need(not git("diff", "--cached", "--name-only"), "Source index is dirty")
    rows = []
    for line in (PLAN / "CLOSURE.tsv").read_text().splitlines()[1:]:
        name, oid, count = line.split("\t")
        path = SOURCE / name
        raw = path.read_bytes()
        actual = hashlib.sha1(("blob " + str(len(raw)) + "\0").encode() + raw).hexdigest()
        need(actual == oid and len(raw) == int(count), "Source closure mismatch: " + name)
        rows.append((name, oid, count))
    index_name = git("rev-parse", "--git-path", "index").decode().strip()
    index = Path(index_name)
    if not index.is_absolute():
        index = SOURCE / index
    return {"sha": F, "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
            "branch": git("rev-parse", "--abbrev-ref", "HEAD").decode().strip(),
            "closure_leaves": len(rows), "closure_tsv_sha256": filehash(PLAN / "CLOSURE.tsv"),
            "index_sha256": filehash(index), "status_clean": True, "index_clean": True}


def diagnostic_limits():
    # These limits apply ONLY to the -### diagnostic process, never an original gate.
    _, hard = resource.getrlimit(resource.RLIMIT_FSIZE)
    resource.setrlimit(resource.RLIMIT_FSIZE,
                       (min(STREAM_CAP, hard) if hard != resource.RLIM_INFINITY else STREAM_CAP, hard))


def run_driver(argv, env, directory):
    directory.mkdir()
    row = {"argv": argv, "cwd": str(SOURCE), "source_sha": F,
           "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "diagnostic_only": True, "formal_acceptance": False,
           "diagnostic_timeout_seconds": DRIVER_SECONDS,
           "diagnostic_stream_cap_bytes": STREAM_CAP,
           "diagnostic_child_regular_file_cap_bytes": STREAM_CAP,
           "actual_exit_code": None, "complete_output": False, "errors": []}
    save(directory / "request.json", row)
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    process = subprocess.Popen(argv, cwd=SOURCE, env=env, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               start_new_session=True, preexec_fn=diagnostic_limits)
    selector = selectors.DefaultSelector()
    for name in buffers:
        pipe = getattr(process, name)
        os.set_blocking(pipe.fileno(), False)
        selector.register(pipe, selectors.EVENT_READ, name)
    start = time.monotonic()
    interrupted = False
    killed_at = None
    try:
        while selector.get_map():
            if time.monotonic() - start > DRIVER_SECONDS and not interrupted:
                row["errors"].append("diagnostic timeout; not a formal gate result")
                interrupted = True
            if interrupted and killed_at is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                killed_at = time.monotonic()
            if killed_at is not None and time.monotonic() - killed_at > 5:
                row["errors"].append("diagnostic streams did not close after process-group termination")
                break
            for key, _ in selector.select(0.1):
                block = os.read(key.fileobj.fileno(), 4096)
                if not block:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                target = buffers[key.data]
                room = STREAM_CAP - len(target)
                target.extend(block[:room])
                if len(block) > room:
                    row["errors"].append(key.data + " exceeded diagnostic capture cap; output incomplete")
                    interrupted = True
        process.wait(timeout=5)
        row["actual_exit_code"] = process.returncode
        row["complete_output"] = not interrupted and not row["errors"]
    except BaseException as error:
        row["errors"].append(repr(error))
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)
        row["actual_exit_code"] = process.returncode
    finally:
        selector.close()
        row["elapsed_seconds"] = time.monotonic() - start
        row["ended_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        for name, data in buffers.items():
            (directory / (name + ".bin")).write_bytes(data)
            row[name + "_bytes"] = len(data)
            row[name + "_sha256"] = digest(data)
        save(directory / "result.json", row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--tmp-root", type=Path)
    parser.add_argument("--scheduler-slot", type=int, choices=(1, 2))
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"plan_only": True, "source_sha": F, "compiler_or_linker_stages_executed": False,
                          "TMPDIR_budget_bytes": TMP_RESERVE, "SHM_raw_budget_bytes": RAW_RESERVE,
                          "existing_OWN_ceiling_bytes": CEILING, "gate": "none; driver diagnosis"}))
        return 0
    need(args.output is not None and args.tmp_root is not None and args.scheduler_slot is not None,
         "Root must assign output, new private TMPDIR and scheduler slot")
    need(not args.output.exists() and not args.output.is_symlink(), "Output must be fresh")
    need(not args.tmp_root.exists() and not args.tmp_root.is_symlink(), "TMPDIR must be fresh")
    out = args.output.resolve()
    scratch = args.tmp_root.resolve()
    need(out.parent == OWN and out != SOURCE, "Need new direct child of original OWN")
    need(scratch.parent == Path("/tmp") and scratch.name.startswith("geo-axiom-driver-"),
         "Need fresh /tmp/geo-axiom-driver-* directory, never an old root")
    verify_plan()
    need(LOCK.is_file() and not LOCK.is_symlink(), "Need existing original R3 lock")
    lock = LOCK.open("rb")
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    before = source_guard()
    used = allocated((OWN, OTHER))
    need(used + RAW_RESERVE <= CEILING, "Original combined OWN 2GiB planning admission failed")
    need(available(OWN) >= RAW_RESERVE and available("/tmp") >= TMP_RESERVE,
         "Actual planned output/TMPDIR mount free space is insufficient")
    # The exact environment belongs to this diagnostic, and must also be used by
    # any subsequent resource probe before claiming its sample is transferable.
    env = dict(os.environ)
    removed = []
    for key in list(env):
        if key.startswith(("GIT_", "GEOMETRY_", "MUTATE_", "GEO261_", "GEO323_")) or key in (
                "PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONOPTIMIZE",
                "NODE_OPTIONS", "LD_PRELOAD", "AXIOM_ONLY", "FRAMING_QUOTE_QUEUE"):
            removed.append(key)
            env.pop(key)
    compiler_argv = shlex.split(env.get("CC", "cc"))
    need(compiler_argv in (["cc"], ["/usr/bin/cc"]),
         "Unexpected CC override; inspect it before source-bound resource profiling")
    cc = Path(shutil.which("cc", path=env.get("PATH")) or "").resolve()
    observed = json.loads((PLAN / "FACTS.json").read_text())["environment_observed"]
    need(str(cc) == observed["cc_resolved"] and filehash(cc) == observed["cc_sha256"],
         "Compiler differs from the source-bound static resource review")
    env.update(TMPDIR=str(scratch), LANG="C.UTF-8", LC_ALL="C.UTF-8",
               PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8", PYTHONOPTIMIZE="0")
    out.mkdir(mode=0o700)
    scratch.mkdir(mode=0o700)
    source = str(SOURCE / "geometry-core/model_base.c")
    obj = str(scratch / "model-base.o")
    binary = str(scratch / "model-base")
    commands = [
        ("original-adapter", [*compiler_argv, "-###", "-std=c11", "-O2", source, "-lm", "-o", binary]),
        ("assembly-to-stdout", [*compiler_argv, "-###", "-std=c11", "-O2", "-S", source, "-o", "-"]),
        ("assembly-from-stdin", [*compiler_argv, "-###", "-x", "assembler", "-c", "-o", obj, "-"]),
        ("link-object", [*compiler_argv, "-###", obj, "-lm", "-o", binary]),
    ]
    safe = ("PATH", "CC", "CFLAGS", "CPPFLAGS", "LDFLAGS", "C_INCLUDE_PATH", "CPATH",
            "LIBRARY_PATH", "LD_LIBRARY_PATH", "GCC_EXEC_PREFIX", "COMPILER_PATH",
            "TMPDIR", "TEMP", "TMP", "LANG", "LC_ALL", "PYTHONOPTIMIZE")
    receipt = {"schema": "axiom-resource-driver-only/1", "source_sha": F,
               "source_root": str(SOURCE), "formal_acceptance": False,
               "compiler_or_linker_stages_executed": False, "driver_invoked": True,
               "diagnostic_completed": False, "scheduler_slot": args.scheduler_slot,
               "R3": str(LOCK), "source_before": before, "source_after": None,
               "source_preserved": False, "commands": [], "errors": [],
               "tool_sha256": filehash(__file__), "resource_plan_pin": PLAN_PIN,
               "environment": {k: env.get(k) for k in safe},
               "environment_sha256": digest(json.dumps(sorted(env.items()), separators=(",", ":")).encode()),
               "removed_env_names": sorted(removed), "compiler_path": str(cc),
               "compiler_sha256": filehash(cc),
               "admission": {"OWN_used_bytes": used, "OWN_ceiling_bytes": CEILING,
                             "SHM_reserve_bytes": RAW_RESERVE, "TMPDIR_reserve_bytes": TMP_RESERVE,
                             "actual_TMP_available": available("/tmp"), "actual_SHM_available": available(OWN)}}
    save(out / "receipt.json", receipt)
    result = 1
    try:
        for name, argv in commands:
            row = run_driver(argv, env, out / name)
            receipt["commands"].append({"name": name, **row})
            save(out / "receipt.json", receipt)
            need(row["actual_exit_code"] == 0 and row["complete_output"],
                 "Driver diagnosis incomplete/nonzero: " + name)
        receipt["diagnostic_completed"] = True
        result = 0
    except BaseException as error:
        receipt["errors"].append(repr(error))
        (out / "exception.txt").write_text(traceback.format_exc())
    finally:
        try:
            after = source_guard()
            receipt["source_after"] = after
            receipt["source_preserved"] = before == after
            need(before == after, "Source or original index changed during diagnosis")
            receipt["TMPDIR_files"] = [{"path": str(p.relative_to(scratch)),
                                        "bytes": p.stat().st_size, "sha256": filehash(p)}
                                       for p in sorted(scratch.rglob("*")) if p.is_file()]
            receipt["TMPDIR_allocated_bytes"] = allocated((scratch,))
            need(receipt["TMPDIR_allocated_bytes"] <= TMP_RESERVE, "Diagnostic TMPDIR budget exceeded")
            need(not any(row["bytes"] for row in receipt["TMPDIR_files"]),
                 "-### unexpectedly produced nonempty files; inspect before compiling")
            receipt["OWN_final_used_bytes"] = allocated((OWN, OTHER))
            need(receipt["OWN_final_used_bytes"] <= CEILING, "Original 2GiB budget exceeded")
        except BaseException as error:
            receipt["errors"].append(repr(error))
            result = 1
        receipt["actual_exit_code"] = result
        save(out / "receipt.json", receipt)
        package = [{"path": str(p.relative_to(out)), "bytes": p.stat().st_size, "sha256": filehash(p)}
                   for p in sorted(out.rglob("*")) if p.is_file()]
        save(out / "MANIFEST.json", {"source_sha": F, "formal_acceptance": False, "files": package})
        need(allocated((out,)) <= RAW_RESERVE, "Diagnostic raw budget exceeded")
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        lock.close()
    print(json.dumps({"source_sha": F, "diagnostic_exit_code": result,
                      "formal_acceptance": False, "output": str(out)}, ensure_ascii=False))
    return result


if __name__ == "__main__":
    raise SystemExit(main())
