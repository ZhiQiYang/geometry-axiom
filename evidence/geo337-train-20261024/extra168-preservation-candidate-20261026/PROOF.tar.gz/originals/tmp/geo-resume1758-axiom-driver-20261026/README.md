# 新 F axiom 的第一步資源診斷

這個工具只執行 GCC `-###` driver 診斷，不執行 cc1、assembler、linker、ELF 或任何測試。預設只印計畫；本包準備時只有 AST 語法檢查，沒有啟動 driver。

完整來源為 `cbf0fb621888596aa14ad5f2349b503e23b1b72d`。工具固定修正後 262 葉閉包及 compiler bytes；獨占既有 `/tmp/g261r3/heavy.lock`，保留原兩 OWN 合計 2 GiB 規劃守門。新私有 `/tmp` 預算 1 MiB，SHM raw 預算 1 MiB。不讀寫 `/tmp/geometry-tests`，不讀待清理舊 source，不建立新 checkout，不刪檔。

主代理與同儕審查通過、reader 結束後，指派新的輸出名稱及 slot 才執行，例如：

```text
python3 -B /tmp/geo-resume1758-axiom-driver-20261026/DRIVER.py --execute --scheduler-slot 1 --tmp-root /tmp/geo-axiom-driver-F-cbf0fb62-20261026 --output /dev/shm/geometry-axiom-geo337-20261025/a7-axiom-driver-F-cbf0fb62-20261026
```

上面兩個目錄必須不存在。不要直接重跑同名或同版已完成樣本；先回收原終態。請在根排程的原 subreaper 保護下啟動並另記 outer log；不要把 outer reaper 的先建 log 放進本工具要求全新的 output 目錄。

順序診斷四個 driver 命令：原 adapter 整段、`-S … -o -`、`-x assembler -c … -`、object link。全部保留 argv、UTC、exit、stdout/stderr bytes/hash、環境安全欄位與完整環境 hash、source/index 前後守門。每個 stdout/stderr 64 KiB、30 秒、child regular-file 64 KiB 都是這個**診斷**的保護上限，不是正式驗收門檻；超過即標 incomplete，不宣稱原裁判紅綠。工具沒有降低或更動原 60／180 秒時限。

本工具不能單憑 exit 0 自動啟動真正編譯。root／peer 必須讀四份 stderr，核對 cc1/as/collect2 實際命令、單一 TU、plugin/LTO、所有暫存副產物和 compiler 搜尋路徑，再準備受審的有界編譯量測。完整原 compiler scratch peak 仍未量測。

`/tmp/geo-resume1758-axiom-resource-plan-20261026/PLAN.md` 的三段編譯僅是後續提案；若要保留 assembly 原始 stdout 到磁碟，應改計為 16 MiB assembly＋16 MiB object＋16 MiB ELF＋8 MiB log/餘量＝56 MiB `/tmp`，另 2 MiB SHM 原始收據。若使用記憶體 assembly，必須清楚記錄未保存在檔案的生成內容並解決可稽核保留，不能宣稱完整原始輸出已封存。目前兩種編譯方案都未執行、未宣稱已驗上界。

160 MiB 舊估計不是原 axiom gate。原 native 128 MiB、card 448 MiB 與兩 OWN 2 GiB 各自不變；本診斷完成也不代表 native 可跑。

方法內延後 import 已補查：`tests.test_geometry_source_runtime.envelope/decode` 只是 Python 中性資料處理，不會執行該模組的獨立測試、copytree 或 bridge；`space_modeling.preview` 與 `ModelWorld` 仍經同一 H `_build_adapter`。五組 axiom mutations 只改 Python `modeling/__init__.py`，不改固定 171 葉 C closure，因此同 F／compiler／flags／compiler environment 的資源樣本可供它們共用的 adapter 建置規劃；每個新 unittest 程序仍按原裁判自己編譯，不用診斷 ELF 覆寫。

原 `tempfile` 在可用 TMPDIR 存在時優先取它，再才考慮 TEMP、TMP 與預設路徑。工具建立可寫的私有 TMPDIR，並記錄 TEMP/TMP；沒有將原 fixture 或現行 F9 ELF 搬到此處。adapter 正常依 atexit 清除、scene 正常依 context 清除；異常終止與 cache 失效不能被假定沒有殘留。
