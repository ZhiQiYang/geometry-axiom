import datetime
import hashlib
import json
from pathlib import Path

OWN = Path('/dev/shm/geometry-axiom-geo337-20261025')
OUT = OWN/'continuation-publication-175947-20261026'
DEST = Path('/tmp/geo-resume1758-publication-actual-peer-20261026')
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
PARENT = 'dea5d12a88c0a2ed93141014524dce5d104f8b1f'
E = 'df84890966a600d3ba7e39c5b8ba882b18d1a9b2'
BRANCH = 'codex/train337-recovered-evidence-20261026'
TRAIN = 'codex/train-337-continue-20261024'
HEAD = '3e4f2560aa11ed2a626db98ba5ed6f129e791052'
GIT_PREFIX = ['git','-c','gc.auto=0','-c','maintenance.auto=false']
PIN_RESULT = '757a521750d8558f7a335377c57c6a53c7daec781ffdae8cb5a5ade997c350f2'
PIN_MANIFEST = 'ae9735f97872bc9dd898f49b5ba88720518a6ba01b2944649dd95b830f1882ae'
checks = 0
errors = []
summary = {}

def h(b):
    return hashlib.sha256(b).hexdigest()

def oid(b):
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def check(ok,name):
    global checks
    checks += 1
    if not ok:
        errors.append(name)

try:
    terminal_raw=(OUT/'RESULT.json').read_bytes()
    result=json.loads(terminal_raw)
    manifest_raw=(OUT/'MANIFEST.json').read_bytes()
    manifest=json.loads(manifest_raw)
    rows_raw=(OUT/'subcommands.json').read_bytes()
    rows=json.loads(rows_raw)
    remote_raw=(OUT/'REMOTE_BLOBS.json').read_bytes()
    remote=json.loads(remote_raw)
    check(h(terminal_raw)==PIN_RESULT,'fixed publisher terminal pin')
    check(h(manifest_raw)==PIN_MANIFEST,'fixed six-file manifest pin')
    check(h((OUT/'EXECUTOR.py').read_bytes())=='988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720','original publisher executor unchanged')
    check(result['exit_code']==0 and result['published'] and result['delivered'],'publisher true zero and delivery terminal')
    check(result['base_sha']==PARENT and result['recovery_anchor_sha']==F and result['evidence_head']==E and result['branch']==BRANCH,'fixed parent/product/new evidence anchors')
    check(result['source_execution_sha'] is None and not result['product_modified'] and not result['train_ref_modified'],'publication is not new product execution')
    check(result['files']==result['remote_blobs_verified']==len(manifest['files'])==len(remote)==6,'six publication blobs')
    check(len(rows)==49,'49 actual commands')
    streams={}
    for number,row in enumerate(rows,1):
        directory=OUT/'subcommands'/f'{number:06d}'
        check(Path(row['directory'])==directory,'command directory '+str(number))
        check(json.loads((directory/'result.json').read_bytes())==row,'command result original '+str(number))
        request=json.loads((directory/'request.json').read_bytes())
        for key in ['command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','stdin_provided','stdin_sha256','directory']:
            check(request[key]==row[key],'request field '+str(number)+' '+key)
        check(row['actual_process_returncode']==0 and row['timeout_expired'] is False and row['ended_epoch']>=row['started_epoch'],'actual termination '+str(number))
        check(row['acceptance_sha']==row['source_sha']==PARENT,'command bound to publication parent '+str(number))
        check(row['cwd']==str(OWN/'publisher-source'),'existing writer cwd '+str(number))
        for stream in ['stdin','stdout','stderr']:
            b=(directory/(stream+'.bin')).read_bytes()
            check(h(b)==row[stream+'_sha256'],'raw '+stream+' hash '+str(number))
            if stream!='stdin':
                check(len(b)==row[stream+'_bytes'],'raw '+stream+' length '+str(number))
            streams[(number,stream)]=b
    def matching(args):
        return [(i+1,row) for i,row in enumerate(rows) if row['command']==GIT_PREFIX+args]
    def single(args):
        found=matching(args)
        check(len(found)==1,'one recorded command '+str(args))
        return streams[(found[0][0],'stdout')]
    destinations={item['destination']:item for item in manifest['files']}
    check(len(destinations)==6,'unique six destinations')
    hash_objects={}
    for item in manifest['files']:
        source=Path(item['source_path']).read_bytes()
        check(len(source)==item['bytes'] and h(source)==item['sha256'],'source remains exact '+item['destination'])
        value=single(['hash-object','-w','--no-filters','--',item['source_path']]).decode().strip()
        check(oid(source)==value,'published local object ID '+item['destination'])
        hash_objects[value]=item
    apis=[(i+1,row) for i,row in enumerate(rows) if row['command'][0]=='gh']
    check(len(apis)==6,'exact six recorded raw API commands')
    raw_rows=[]
    for number,row in apis:
        command=row['command']
        blob=command[-1].rsplit('/',1)[1]
        check(command==['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json','repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob],'full raw API format '+str(number))
        body=streams[(number,'stdout')]
        check(blob in hash_objects,'remote blob is expected local blob '+blob)
        item=hash_objects[blob]
        check(body==Path(item['source_path']).read_bytes(),'remote complete bytes equal source '+blob)
        check(oid(body)==blob and h(body)==item['sha256'] and len(body)==item['bytes'],'remote full SHA/OID/length '+blob)
        rr={'blob_oid':blob,'bytes':len(body),'sha256':h(body)}
        check(rr in remote,'remote result row equals raw '+blob)
        raw_rows.append(dict(rr,destination=item['destination'],command_number=number))
    changed=single(['diff-tree','--no-commit-id','--name-only','-r','-z',PARENT,E]).decode().split('\0')
    changed=[x for x in changed if x]
    check(set(changed)==set(destinations) and len(changed)==6,'commit changes exactly six manifest paths')
    check(all(x.startswith('evidence/geo337-train-20261024/') for x in changed),'evidence-only changed paths')
    check(single(['diff','--name-only',PARENT,E,'--','.',':(exclude)evidence'])==b'','zero product diff')
    commit_rows=[(i+1,r) for i,r in enumerate(rows) if r['command'][:6]==GIT_PREFIX+['commit-tree']]
    check(len(commit_rows)==1,'one commit creation')
    n,r=commit_rows[0]
    check(r['command'][-2:]==['-p',PARENT] and streams[(n,'stdout')].decode().strip()==E,'ordinary single expected parent commit')
    check(streams[(n,'stdin')]==b'docs: append recovered architecture and acceptance evidence\n','English commit message')
    single(['update-ref','refs/heads/'+BRANCH,E,PARENT])
    single(['push','https://github.com/ZhiQiYang/geometry-axiom.git','refs/heads/'+BRANCH+':refs/heads/'+BRANCH])
    check(not any('--force' in x or '--force-with-lease' in x for row in rows for x in row['command']),'no force push or flag')
    remote_refs=matching(['ls-remote','--heads','https://github.com/ZhiQiYang/geometry-axiom.git','refs/heads/'+BRANCH])
    check(len(remote_refs)==4,'two before and two after remote refs')
    observed=[streams[(n,'stdout')] for n,_ in remote_refs]
    check(observed==[(PARENT+'\trefs/heads/'+BRANCH+'\n').encode()]*2+[(E+'\trefs/heads/'+BRANCH+'\n').encode()]*2,'actual remote ordinary parent transition')
    for args,expected in [(['rev-parse','HEAD'],(HEAD+'\n').encode()),(['status','--porcelain=v1'],b''),(['branch','--show-current'],(TRAIN+'\n').encode())]:
        found=matching(args)
        check(len(found)==3 and all(streams[(n,'stdout')]==expected for n,_ in found),'existing writer all three snapshots '+str(args))
    reader_raw=(OWN/'reader-F-175947-20261026/RESULT.json').read_bytes()
    check(h(reader_raw)=='c4f253756cdb03d0f753c60b8a33b824104caa9cbd383f8e93f057a67a2fd94c','fixed reader index baseline pin')
    baseline=json.loads(reader_raw)['publisher_before']
    index=OWN/'publisher-source/.git/index'
    s=index.stat()
    check(h(index.read_bytes())==baseline['index']['sha256'] and s.st_size==baseline['index']['bytes'] and s.st_ino==baseline['index']['inode'] and s.st_mtime_ns==baseline['index']['mtime_ns'],'existing index bytes/inode/mtime unchanged')
    check((OWN/'publisher-source/.git/HEAD').read_text()=='ref: refs/heads/'+TRAIN+'\n','HEAD symbolic branch unchanged')
    check((OWN/'publisher-source/.git/refs/heads'/TRAIN).read_text().strip()==HEAD,'original train ref unchanged')
    check(result['existing_writer_unchanged'],'publisher original writer comparison passed')
    bound=3*sum(x['bytes'] for x in manifest['files'])+6*65536+len(manifest_raw)*8+64*1024**2
    check(bound==result['capacity']['additional_bound']==74509070,'original publisher formula unchanged')
    check(result['capacity']['used']+bound<=2147483648,'original 2GiB admission observed')
    check((OUT/'RESULT.json').read_bytes()==terminal_raw and (OUT/'subcommands.json').read_bytes()==rows_raw,'terminal originals stable during review')
    summary={'commands':len(rows),'remote_blob_count':len(raw_rows),'remote_raw_bindings':raw_rows,
             'expected_progress_blob':result['expected_progress_blob'],'writer_index_sha256':baseline['index']['sha256'],
             'writer_head':HEAD,'writer_branch':TRAIN,'index_bytes_inode_mtime_unchanged':True,
             'publisher_result_sha256':h(terminal_raw),'publisher_commands_sha256':h(rows_raw),'remote_blobs_sha256':h(remote_raw),
             'capacity':result['capacity'],'new_network_requests':0}
except Exception as exc:
    errors.append(type(exc).__name__+': '+str(exc))
report={'schema':'resume1758-publication-independent-actual-review/1',
        'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exit_code':1 if errors else 0,'blocking_findings':errors,'check_count':checks,
        'product_sha':F,'evidence_parent':PARENT,'published_evidence_head':E,
        'review_script_sha256':h(Path(__file__).read_bytes()),'summary':summary,
        'existing_recorded_remote_full_bytes_reviewed':True,'new_API_or_Git_commands':False,
        'product_tests_rerun':False,'originals_modified_or_deleted':False}
p=DEST/'REVIEW.json'
with p.open('x',encoding='utf-8') as stream:
    json.dump(report,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps({'exit_code':report['exit_code'],'check_count':checks,'blocking':errors,'review_sha256':h(p.read_bytes()),'evidence_head':E},ensure_ascii=False))
raise SystemExit(report['exit_code'])
