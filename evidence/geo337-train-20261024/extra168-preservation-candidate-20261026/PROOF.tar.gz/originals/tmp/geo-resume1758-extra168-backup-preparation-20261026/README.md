# 固定 168 葉備份執行器（準備，未執行）

`materialize_backup.py` 只把指定三個舊私有 index 與 165 GPU cache 保存到新 OWN 目錄；沒有刪除、還原、Git 寫入、API 或發布程式路徑。原始三 payload 的 bytes/hash 精確符合已審 R2。預設不執行，只有主代理新建立且 hash 綁定的備份 request 可以開始。

這份工具本身先受獨立 `PEER_REVIEW.json` 審查；真正執行時還會要求 request 的 executor_review_sha256、review 的 subject_executor_sha256、exit 0 與無 blocking findings 同時吻合。`REQUEST_TEMPLATE_NOT_AUTHORIZATION.json` 的 root confirms 是 false，時間及review hash是placeholder，不能直接執行，也不是 no-reuse lease。新 request 最長30分鐘，只限備份期間防來源重用與容量競寫；deletion/publication/restore 授權必須全部false。

已固定主代理上一個發布終態 RESULT `757a521750d8558f7a335377c57c6a53c7daec781ffdae8cb5a5ade997c350f2`、evidence head `df84890966a600d3ba7e39c5b8ba882b18d1a9b2`。執行時才重新計算兩個 OWN 真實 allocated，保留原2GiB與實體SHM守門；來源payload配置、額外2MiB收據成本、未改publisher公式同時計入。2MiB是新工具的保守收據成本，不是新的native門檻。

守門包括：固定168葉完整uid/gid/allocated/identity/hash/xattrs、祖先無symlink、GPU exact namespace、原consumer及其/proc可見性限制；首次Git前確認私有根與index，前後三根HEAD/refs/status精確對cb9640ab…已完成退役baseline。Git全程--no-optional-locks、明確git-dir/work-tree，關fsmonitor/untrackedCache/submodule遞迴與lazy fetch，不對已刪index的兩根執行Git。

新輸出只有：

- `/dev/shm/geometry-axiom-geo337-20261025/extra168-preservation-candidate-20261026/`：SNAPSHOT.tar.xz、RESTORE.md、INDEX.json。
- `/dev/shm/geometry-axiom-geo337-20261025/extra168-backup-materialization-20261026/`：新request、executor、完整原始Git stdout/stderr的xz、consumer、BYTE_MAP、payload write intents、publisher manifest及終態RESULT。

INDEX.json保留R2的**備份前測量**原件（內含new_backup_written=false）；真實落盤狀態在新AUDIT/RESULT.json及host程序退出碼，不能把舊測量當新終態。部分落盤會保存intents／已寫清單，若任何後段守門失敗，保留原件與失敗，不刪除或覆寫後重試。新輸出路徑必須不存在。

工具只產生R2三payload的publisher manifest，不執行發布。若同次發布新AUDIT原件，主代理須把它加進新發布manifest，依同一原公式重新計算；原三payload budget不能當作已涵蓋額外audit發布。

這不是清理授權。33個目錄只保存metadata，不刪；168原始葉、原始收據、fixtures、Git objects/refs、F9 ELF與其他closed roots全部保留。完整bytes、uid/gid/mode/mtime可在另外批准的恢復操作中重建，inode/ctime無法還原。遠端完整回讀、刪除及native准入都尚未成立。
