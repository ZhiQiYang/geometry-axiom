import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

OUT = Path('/dev/shm/geometry-axiom-geo337-20261025/continuation-package-175947-20261026')
DEST = Path('/tmp/geo-resume1758-package-actual-peer-20261026')
F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
PARENT = 'dea5d12a88c0a2ed93141014524dce5d104f8b1f'
E9 = '9a57aea2128a7bc3985064932c24e2229fd8fcb8'
CONFIG_PIN = 'fd5671259bff5ebecde8464c848da50617425389110bc687ad3161a56ddb24a2'
PROGRESS_PIN = '65bc4fe930487a2ce96d913e5382ac1f209bb77bfa0d96139bc1ced4dc861c06'
PINS = {
    'ORIGINALS.tar.gz': 'de0062ca220ebb54732c6ae9f2bd1a2f466bcd3a0e5cbe171edf09df75f19121',
    'INDEX.json': '9d96c87b34eeef8bb5837d7e615b039242dc0009bc8c86b097b751c960dcfd45',
    'PUBLICATION_MANIFEST.json': 'ae9735f97872bc9dd898f49b5ba88720518a6ba01b2944649dd95b830f1882ae',
    'CONFIG.json': CONFIG_PIN,
    'PREPARER.py': 'a0f98026a8d27f91bedef0cb1f72001f19bdf9bbedd63a4d47253e43187e1faf'
}
checks = 0
failures = []
summary = {}

def digest(b):
    return hashlib.sha256(b).hexdigest()

def check(ok, name):
    global checks
    checks += 1
    if not ok:
        failures.append(name)

def state(p):
    s = p.lstat()
    return {'device': s.st_dev, 'inode': s.st_ino, 'mode': s.st_mode,
            'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns,
            'ctime_ns': s.st_ctime_ns, 'nlink': s.st_nlink}

try:
    output_bytes = {name: (OUT/name).read_bytes() for name in PINS}
    for name, expected in PINS.items():
        check(digest(output_bytes[name]) == expected, 'output pin: '+name)
    cfg = json.loads(output_bytes['CONFIG.json'])
    idx = json.loads(output_bytes['INDEX.json'])
    manifest = json.loads(output_bytes['PUBLICATION_MANIFEST.json'])
    result_raw = (OUT/'RESULT.json').read_bytes()
    result = json.loads(result_raw)
    check(result['exit_code'] == 0, 'preparer terminal zero')
    check(result['archive_sha256'] == PINS['ORIGINALS.tar.gz'], 'result archive pin')
    check(result['index_sha256'] == PINS['INDEX.json'], 'result index pin')
    check(result['publication_manifest_sha256'] == PINS['PUBLICATION_MANIFEST.json'], 'result manifest pin')
    check(result['config_sha256'] == CONFIG_PIN, 'result config pin')
    check(result['archive_bytes'] == len(output_bytes['ORIGINALS.tar.gz']) == 1286073, 'archive length')
    check(cfg['product_sha'] == idx['product_sha'] == manifest['product_sha'] == F, 'product F')
    check(cfg['expected_evidence_parent'] == idx['previous_evidence_head'] == manifest['previous_evidence_head'] == PARENT, 'evidence parent')
    check(cfg['external_raw_commit'] == idx['external_full_raw_commit'] == E9, 'external E9')
    check(len(cfg['roots']) == 15 and len({r['path'] for r in cfg['roots']}) == 15, '15 distinct sources')
    check(digest(Path('/tmp/geo-resume1758-package-inputs-20261026/CONFIG.json').read_bytes()) == CONFIG_PIN, 'root config unchanged')
    check(digest(Path(cfg['progress_path']).read_bytes()) == PROGRESS_PIN, 'root PROGRESS unchanged')
    rows = idx['files']
    indexed = {r['member']: r for r in rows}
    check(len(indexed) == len(rows), 'unique index names')
    files_now, dirs_now = {}, set()
    for root in cfg['roots']:
        base = Path(root['path'])
        alias = root['alias']
        dirs_now.add(alias)
        check(base.is_dir() and not base.is_symlink(), 'source root regular directory: '+alias)
        for p in base.rglob('*'):
            member = alias+'/'+p.relative_to(base).as_posix()
            check(not p.is_symlink(), 'no source symlink: '+member)
            if p.is_dir():
                dirs_now.add(member)
            else:
                files_now[member] = p
    check(set(files_now) == set(indexed), 'exact source file membership')
    check(set(idx['included_directories']) == dirs_now, 'exact source directory membership')
    for name, p in files_now.items():
        row = indexed[name]
        s1 = state(p)
        body = p.read_bytes()
        check(s1 == state(p) == row['source_state'], 'source state unchanged: '+name)
        check(str(p) == row['source_path'], 'source path exact: '+name)
        check(len(body) == row['bytes'] and digest(body) == row['sha256'], 'source byte identity: '+name)
    included = {n: r for n, r in indexed.items() if r['representation'] == 'included_full_file'}
    externals = {n: r for n, r in indexed.items() if r['representation'] == 'external_complete_raw_stdout'}
    check(len(included) == idx['included_files'] == result['included_files'] == 1635, '1635 included files')
    check(len(externals) == idx['external_stdout_container_files'] == result['external_complete_raw_stdout_files'] == 24, '24 external stdout containers')
    check(len(included)+len(externals) == len(rows), 'no unknown representation')
    with tarfile.open(OUT/'ORIGINALS.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        names = [t.name for t in members]
        check(len(names) == len(set(names)), 'no duplicate tar member')
        check(set(names) == set(included)|dirs_now, 'exact tar membership including empty directories')
        for item in members:
            check(item.uid == item.gid == item.mtime == 0, 'normalized tar identity: '+item.name)
            if item.name in dirs_now:
                check(item.isdir() and item.mode == 0o755, 'tar directory type/mode: '+item.name)
            else:
                check(item.isfile() and item.mode == 0o644, 'tar file type/mode: '+item.name)
                b = archive.extractfile(item).read()
                row = included[item.name]
                check(len(b) == row['bytes'] and digest(b) == row['sha256'], 'tar full bytes/hash: '+item.name)
    check('remote/000/stdout.bin.gz' in included, 'new ls-tree stdout internal')
    remote = json.loads(Path(next(r['path'] for r in cfg['roots'] if r['alias']=='remote'),'RESULT.json').read_bytes())
    check(digest(json.dumps(remote).encode()) != '', 'remote JSON read without new API')
    remote_by_path = {r['git_path']: r for r in remote['remote_checks']}
    aliases = []
    compressed_bytes = 0
    for name, row in externals.items():
        check(name.startswith('remote/') and name.endswith('/stdout.bin.gz') and name != 'remote/000/stdout.bin.gz', 'only API stdout external: '+name)
        packed = Path(row['source_path']).read_bytes()
        raw = gzip.decompress(packed)
        git_oid = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        check(row['evidence_commit'] == E9, 'external immutable commit: '+name)
        check(row['raw_bytes'] == len(raw) and row['raw_sha256'] == digest(raw) and row['blob_oid'] == git_oid, 'complete external raw bytes/SHA/OID: '+name)
        check(row['local_omitted_gzip_bytes'] == len(packed) and row['local_omitted_gzip_sha256'] == digest(packed), 'local gzip retained exact: '+name)
        check(row['local_gzip_retained'] and row['gzip_container_not_claimed_in_new_archive'] and row['exact_gzip_recompression_not_claimed'], 'container boundary explicit: '+name)
        compressed_bytes += len(packed)
        for alias in row['raw_aliases']:
            aliases.append(alias['git_path'])
            origin = remote_by_path[alias['git_path']]
            check(origin['expected_oid'] == origin['actual_git_oid'] == git_oid and origin['expected_sha256'] == digest(raw) and origin['expected_bytes'] == len(raw), 'E9 remote proof alias: '+alias['git_path'])
            check(origin['remote_stdout_directory'] == row['fresh_capture_directory'], 'alias exact fresh capture: '+alias['git_path'])
    check(compressed_bytes == 10225981, 'exact omitted gzip bytes')
    check(len(aliases) == 30 and set(aliases) == set(remote_by_path), 'all 30 exact E9 aliases')
    for pin in cfg['terminal_results']:
        original = Path(pin['path']).read_bytes()
        d = json.loads(original)
        check(digest(original) == pin['sha256'] and d['exit_code'] == pin['exit_code'], 'terminal remains pinned: '+pin['path'])
    check(len(manifest['files']) == 6, 'original six publication leaves')
    for item in manifest['files']:
        b = Path(item['source_path']).read_bytes()
        check(len(b) == item['bytes'] and digest(b) == item['sha256'], 'publication payload exact: '+item['destination'])
    payload = sum(x['bytes'] for x in manifest['files'])
    bound = 3*payload+len(manifest['files'])*65536+len(output_bytes['PUBLICATION_MANIFEST.json'])*8+64*1024**2
    cap = result['capacity']
    check(cap['original_ceiling'] == 2147483648 and cap['original_publisher_additional_bound'] == bound, 'unchanged original capacity formula')
    check(cap['used_before']+cap['prepared_output_upper']+bound <= 2147483648, 'original prewrite admission')
    check(cap['used_after_payloads']+cap['final_result_reserved_bytes']+bound <= 2147483648, 'original postwrite admission')
    check(cap['final_result_reserved_bytes'] == 65536, 'result reserve unchanged')
    seen = set()
    allocated_now = 0
    for root in [Path('/dev/shm/geometry-axiom-geo337-20261025'),Path('/dev/shm/geo337-F9-browsers-20261025')]:
        for p in root.rglob('*'):
            s = p.lstat()
            key = (s.st_dev,s.st_ino)
            if key not in seen:
                seen.add(key)
                allocated_now += s.st_blocks*512
    summary = {'included_files':len(included),'external_raw_stdout_files':len(externals),'external_path_aliases':len(aliases),
               'source_directories':len(dirs_now),'archive_bytes':len(output_bytes['ORIGINALS.tar.gz']),
               'preparer_result_sha256':digest(result_raw),'publication_payload_bytes':payload,'original_publisher_additional_bound':bound,
               'capacity_at_prepare':cap,'shared_allocated_observed_now':allocated_now,
               'shared_remaining_after_original_publish_bound_now':2147483648-allocated_now-bound,
               'prepare_RESULT_is_local_not_in_six_publication_leaves':True,
               'source_immutability_passed':not failures}
except Exception as exc:
    failures.append(type(exc).__name__+': '+str(exc))

report = {'schema':'resume1758-prepared-package-independent-review/1',
          'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code':1 if failures else 0,'blocking_findings':failures,'check_count':checks,
          'product_sha':F,'evidence_parent':PARENT,'expected_output_pins':PINS,
          'review_script_sha256':digest(Path(__file__).read_bytes()),'summary':summary,
          'executed_product_tests':False,'new_API_downloads':False,'Git_writes':False,'originals_modified_or_deleted':False,
          'remote_publication_accepted':False,'publisher_must_fresh_check_admission':True}
dest=DEST/'REVIEW.json'
with dest.open('x',encoding='utf-8') as stream:
    json.dump(report,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps({'exit_code':report['exit_code'],'checks':checks,'blocking':failures,'summary':summary,'review_sha256':digest(dest.read_bytes())},ensure_ascii=False))
raise SystemExit(report['exit_code'])
