"""Preserve the fixed 168 leaves. No source writes, removal, publication, or restore."""
import argparse
import base64
import datetime
import hashlib
import importlib.util
import io
import json
import lzma
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
OWN = Path('/dev/shm/geometry-axiom-geo337-20261025')
OTHER = Path('/dev/shm/geo337-F9-browsers-20261025')
OUT = OWN / 'extra168-preservation-candidate-20261026'
AUDIT = OWN / 'extra168-backup-materialization-20261026'
PREP = Path('/tmp/geo-resume1758-extra-index-scope-20261026')
PINNED = {
    'plan': (PREP / 'full168-plan/PLAN_R2.json', 'f805a78fe979eb4a8968fc97a0e81952d1a97051629f704c0339478cb329be9f'),
    'preview': (PREP / 'full168-plan/PUBLISHER_MANIFEST_PREVIEW_R2.json', '1c53174502c0b9df11e59ee7c5b19281435b9d1c130d5a2a60fb49df0a163fde'),
    'index_stat': (PREP / 'STAT.json', '12fe8c8d00cf610fc288fef9287441cf6ac57d6c6c2959444f27373b5b7aa99e'),
    'index_cost': (PREP / 'COMPRESSION_COST.json', '6cb13f3f40c56bb87b567488b7cafc3236ac68a9ba0fb43a9fe2f52d69ad2194'),
    'gpu': (Path('/tmp/geo-resume1758-extra-scope-20261026/EXACT_GPU_SCOPE_ORIGINAL.json'), '0b59d523b3f64a928e04049b9c6307b2801c1f99e9467ee508cc848d72d484da'),
    'plan_peer': (Path('/tmp/geo-resume1758-extra-scope-peer-20261026/TAR168_PLAN_REVIEW.json'), '725a14cfd0137eab80fef25b73e42044e2d0268b2821b557786e94dcc2bd8860'),
    'old_D': (OWN / 'native-TMP-retirement-20261025/SOURCE_STATUS_AFTER_EXACT_D.json', 'cb9640ab25222302cca2ebf21563dfa2a4d1cff444d3f1c21f7bccc3b284e60b'),
    'publisher': (Path('/tmp/geo337-recovery-evidence-append-preparation-20261026/publish_append.py'), '988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720'),
    'consumer': (Path('/workspace/clear_terminal_chrome_caches.py'), 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'),
    'previous_publication': (OWN / 'continuation-publication-175947-20261026/RESULT.json', '757a521750d8558f7a335377c57c6a53c7daec781ffdae8cb5a5ade997c350f2'),
}
ROOTS = [
    '/tmp/g261r3/source-final',
    '/tmp/g261r3/work/codex-geo261-8f76f2b7/repo',
    '/tmp/geo261-p73-resume-20261022-5z1cdxpj/source-proof',
]
RESTORE = '# 候選 168 葉逐 byte 保存：恢復界線\n本包先供備份審查，不是刪除授權。只含 BYTE_MAP.json 列的 3 個已退役私有 index 與 165 個 GPU cache，33 個 cache 目錄 metadata 供恢復參考；沒有原始 receipts、fixtures、Git objects 或 refs。\n恢復前須獨立取得指定路徑寫入授權、確認沒有活躍使用者與未知修改。不可盲目 tar extract 至原絕對路徑；逐一對 BYTE_MAP 的 archive_member 與 original_path，先比對 member SHA256 和完整 bytes，再在新批准操作中恢復。可恢復完整 byte、uid/gid/mode/mtime；inode/ctime 無法還原，後續驗收不得冒用舊身分。\n原數據/備份完整性由 SNAPSHOT.tar.xz 全 XZ roundtrip、BYTE_MAP 與逐 member hash 複核。原資料在備份與遠端完整核對成功之前不得刪除；此次計畫未執行備份或刪除。\n'
RECEIPT_ALLOWANCE = 2 * 1024**2
CEILING = 2 * 1024**3


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def h(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc)


def encoded(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def ancestors(path):
    need(path.is_absolute(), 'absolute path required')
    for parent in reversed(path.parents):
        need(stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(), 'symlink/non-directory ancestor: ' + str(parent))
    need(not path.is_symlink(), 'symlink leaf: ' + str(path))


def identity(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=s.st_mode, uid=s.st_uid,
                gid=s.st_gid, nlink=s.st_nlink, bytes=s.st_size,
                allocated_bytes=s.st_blocks * 512, mtime_ns=s.st_mtime_ns,
                ctime_ns=s.st_ctime_ns)


def exact_file(path, expected):
    ancestors(path)
    before = identity(path.lstat())
    need(stat.S_ISREG(before['mode']) and before['nlink'] == 1, 'non-private regular leaf: ' + str(path))
    need(all(before[k] == expected[k] for k in before), 'identity drift: ' + str(path))
    need(not os.listxattr(path, follow_symlinks=False), 'unexpected xattr: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NOATIME)
    try:
        need(identity(os.fstat(fd)) == before, 'open identity drift')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        need(identity(os.fstat(fd)) == before, 'read identity drift')
    finally:
        os.close(fd)
    need(identity(path.lstat()) == before and h(raw) == expected['sha256'], 'bytes/identity drift: ' + str(path))
    return raw


def pinned(name):
    path, expected = PINNED[name]
    ancestors(path)
    raw = path.read_bytes()
    need(h(raw) == expected, 'pin changed: ' + name)
    return raw


def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, raw):
    need(path.parent == OUT or path.is_relative_to(AUDIT), 'write outside fresh backup/receipt directories')
    ancestors(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb', closefd=False) as stream:
            stream.write(raw)
            stream.flush()
        os.fsync(fd)
    finally:
        os.close(fd)
    syncdir(path.parent)
    need(path.read_bytes() == raw, 'persisted byte mismatch')


def used():
    seen, amount = set(), 0
    for root in (OWN, OTHER):
        ancestors(root)
        need(root.is_dir(), 'missing original OWN root')
        for path in root.rglob('*'):
            s = path.lstat()
            key = (s.st_dev, s.st_ino)
            if key not in seen:
                seen.add(key)
                amount += s.st_blocks * 512
    return amount


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--request', type=Path)
    parser.add_argument('--request-sha256')
    args = parser.parse_args()
    if not args.execute:
        print('PLAN ONLY: fixed 168-leaf backup materialization; no deletion, publication, or source writes.')
        return
    need(not sys.flags.optimize, 'optimization forbidden')
    need(args.request is not None and args.request_sha256, 'new pinned root request required')
    request_raw = args.request.read_bytes()
    need(h(request_raw) == args.request_sha256, 'root request pin changed')
    request = json.loads(request_raw)
    need(request['schema'] == 'fixed168-backup-only-root-request/1', 'wrong request type')
    need(request['executor_sha256'] == h(Path(__file__).read_bytes()), 'executor pin changed')
    executor_peer_path = Path(__file__).parent / 'PEER_REVIEW.json'
    ancestors(executor_peer_path)
    executor_peer_raw = executor_peer_path.read_bytes()
    need(h(executor_peer_raw) == request['executor_review_sha256'], 'executor peer pin changed')
    executor_peer = json.loads(executor_peer_raw)
    need(executor_peer['subject_executor_sha256'] == request['executor_sha256']
         and executor_peer['exit_code'] == 0 and not executor_peer['blocking_findings'], 'executor peer missing or blocked')
    for key in ('materialize_backup_only', 'root_confirms_no_concurrent_source_or_profile_reuse',
                'root_confirms_capacity_serialization', 'root_acknowledges_original_proc_visibility_limits'):
        need(request[key] is True, 'missing backup-only coordination: ' + key)
    for key in ('deletion_authorized', 'publication_authorized', 'restore_authorized'):
        need(request[key] is False, 'forbidden action in backup request: ' + key)
    created = datetime.datetime.fromisoformat(request['created_utc'])
    expires = datetime.datetime.fromisoformat(request['expires_utc'])
    need(created.tzinfo is not None and expires.tzinfo is not None, 'UTC-aware request required')
    need(created <= utc() <= expires and (expires - created).total_seconds() <= 1800, 'expired/overbroad backup-only coordination')
    loaded = {name: pinned(name) for name in PINNED}
    plan = json.loads(loaded['plan'])
    preview = json.loads(loaded['preview'])
    baseline = json.loads(loaded['old_D'])
    previous = json.loads(loaded['previous_publication'])
    need(previous['exit_code'] == 0 and previous['delivered'] is True and previous['published'] is True
         and previous['existing_writer_unchanged'] is True
         and previous['evidence_head'] == 'df84890966a600d3ba7e39c5b8ba882b18d1a9b2', 'previous publication not genuine terminal success')
    peer = json.loads(loaded['plan_peer'])
    need(peer['exit_code'] == 0 and not peer['blocking_findings'], 'plan peer blocked')
    index_stat = json.loads(loaded['index_stat'])
    index_cost = json.loads(loaded['index_cost'])
    gpu = json.loads(loaded['gpu'])
    index_rows = [r for r in index_stat['rows'] if r.get('index', {}).get('is_regular')]
    need([r['root'] for r in index_rows] == ROOTS, 'exact three private roots changed')
    profiles = sorted({r['profile'] for r in gpu['files']})
    need(len(gpu['files']) == 165 and len(gpu['directories']) == 33 and len(profiles) == 11, 'fixed GPU scope changed')
    need(request['source_roots'] == ROOTS and request['profiles'] == profiles, 'root request scope mismatch')
    need(request['files'] == 168 and request['directories_to_delete'] == 0, 'root request count mismatch')
    expected_files, map_rows = [], []
    for i, r in enumerate(index_rows):
        cost = next(x for x in index_cost['rows'] if x['path'] == r['index_path'])
        e = dict(r['index'])
        e['device'] = e.pop('dev')
        e['mode'] = int(e['mode'], 8)
        e['sha256'] = cost['raw_sha256']
        path = Path(r['index_path'])
        expected_files.append((path, e))
        map_rows.append(dict(archive_member=f'private-index/{i:04d}.bin', original_path=str(path),
                             kind='private-index', raw_sha256=e['sha256'],
                             **{k: e[k] for k in identity(path.lstat())}, xattrs=[]))
    for i, r in enumerate(gpu['files']):
        expected_files.append((Path(r['path']), r))
        map_rows.append(dict(r, archive_member=f'chrome-cache/{i:04d}.bin', original_path=r['path'],
                             kind='regenerable-chrome-cache', raw_sha256=r['sha256'], xattrs=[]))
    need(len({str(p) for p, _ in expected_files}) == 168, 'duplicate fixed leaves')
    need(sum(e['allocated_bytes'] for _, e in expected_files) == 23707648, 'fixed allocated total changed')
    for name, binding in gpu['receipt_bindings'].items():
        need(h(Path(name).read_bytes()) == binding['sha256'], 'GPU owner receipt changed')
    manifest_raw = loaded['preview']
    payload_total = sum(x['bytes'] for x in preview['files'])
    publisher_budget = payload_total * 3 + len(preview['files']) * 65536 + len(manifest_raw) * 8 + 64 * 1024**2
    payload_allocation = sum(((x['bytes'] + 4095) // 4096) * 4096 for x in preview['files'])
    need(publisher_budget == plan['publisher_bound_bytes'] and payload_allocation == plan['source_archive_and_docs_future_allocated_bytes'], 'publisher formula differs from R2')
    need(not os.path.lexists(OUT) and not os.path.lexists(AUDIT), 'fresh backup and receipt directories required; no retries into old outputs')
    for path in (OWN, OTHER):
        ancestors(path)
    samples = []

    def capacity(label, materialized=False):
        allocated = used()
        future = 0 if materialized else payload_allocation
        extra = future + RECEIPT_ALLOWANCE + publisher_budget
        sample = dict(label=label, utc=utc().isoformat(), combined_OWN_allocated=allocated,
                      future_source_bytes=future, receipt_allowance_bytes=RECEIPT_ALLOWANCE,
                      original_publisher_bound=publisher_budget, planned_total=allocated + extra,
                      original_planning_ceiling=CEILING, actual_SHM_free=shutil.disk_usage(OWN).free,
                      TMP_free=shutil.disk_usage('/tmp').free)
        samples.append(sample)
        need(allocated + extra <= CEILING, 'original combined 2GiB budget insufficient')
        need(sample['actual_SHM_free'] > extra, 'actual SHM capacity insufficient')
        need(utc() <= expires, 'backup coordination expired')

    capacity('before_any_output')
    audit_created = False
    commands, consumer_rows = [], []
    result = dict(schema='fixed168-backup-materialization/1', exit_code=1, started_utc=utc().isoformat(),
                  request_sha256=h(request_raw), executor_sha256=h(Path(__file__).read_bytes()),
                  executor_peer_sha256=h(executor_peer_raw),
                  pins={k: {'path': str(v[0]), 'sha256': v[1]} for k, v in PINNED.items()},
                  no_source_write_or_delete=True, original_leaves=168, original_directories_deleted=0,
                  backup_materialized=False, remote_verified=False, published=False,
                  persisted_payloads=[], full_archive_persisted=False,
                  root_coordination_is_backup_only=True, deletion_authorized=False,
                  source_and_publisher_budget_both_included=True, capacity_samples=samples,
                  receipt_allowance_is_additional_conservative_cost=True,
                  INDEX_is_preserved_pre_materialization_measurement=True,
                  formal_gate_executed=False, inode_ctime_not_restorable=True)
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0',
               PYTHONDONTWRITEBYTECODE='1')
    guard = None

    def consumers(label):
        need(guard is not None, 'consumer module not initialized')
        path = AUDIT / ('consumer-' + label)
        path.mkdir(mode=0o700)
        guard.OUT = path
        guard.consumer_check(ROOTS + profiles)
        raw = (path / 'CONSUMERS.json').read_bytes()
        row = json.loads(raw)
        need(not row['hits'], 'observed original consumer')
        consumer_rows.append(dict(label=label, sha256=h(raw), **row))

    def git_state(label):
        states = []
        for r in index_rows:
            root = r['root']
            gd = Path(root) / '.git'
            index_path = gd / 'index'
            ancestors(index_path)
            need(Path(root).resolve() == Path(root) and gd.resolve() == gd and gd.is_dir(), 'non-private source ancestor')
            need(not any((gd / name).exists() for name in ('commondir', 'gitdir', 'worktrees')), 'private Git structure changed before Git')
            need(not list(gd.glob('*.lock')) and not list((gd / 'refs').rglob('*.lock')), 'active Git lock before Git')
            expected_index = next(e for p, e in expected_files if p == index_path)
            exact_file(index_path, expected_index)
            values = {}
            queries = [('head', ['rev-parse', 'HEAD']), ('refs', ['for-each-ref', '--format=%(refname) %(objectname)']),
                       ('staged', ['diff', '--cached', '--no-ext-diff', '--name-status', '-z']),
                       ('status', ['status', '--porcelain=v1', '-z', '--untracked-files=all']),
                       ('gitdir', ['rev-parse', '--absolute-git-dir']), ('common', ['rev-parse', '--git-common-dir']),
                       ('index', ['rev-parse', '--git-path', 'index'])]
            for name, query in queries:
                argv = ['git', '--no-optional-locks', '--git-dir=' + str(gd), '--work-tree=' + root,
                        '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', 'core.fsmonitor=false',
                        '-c', 'core.untrackedCache=false', '-c', 'submodule.recurse=false', *query]
                started = utc().isoformat()
                try:
                    process = subprocess.run(argv, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
                except subprocess.TimeoutExpired as exc:
                    commands.append(dict(phase=label, root=root, name=name, argv=argv, started_utc=started,
                                         ended_utc=utc().isoformat(), exit_code=None, timeout_expired=True,
                                         stdout_b64=base64.b64encode(exc.stdout or b'').decode(),
                                         stderr_b64=base64.b64encode(exc.stderr or b'').decode()))
                    raise
                commands.append(dict(phase=label, root=root, name=name, argv=argv, started_utc=started,
                                     ended_utc=utc().isoformat(), exit_code=process.returncode,
                                     stdout_b64=base64.b64encode(process.stdout).decode(),
                                     stderr_b64=base64.b64encode(process.stderr).decode()))
                need(process.returncode == 0 and not process.stderr, 'Git read-only guard failed: ' + name)
                values[name] = process.stdout
            observed = dict(head=values['head'].decode().strip(), status_sha256=h(values['status']), refs_sha256=h(values['refs']))
            need(observed == baseline[root] and not values['staged'], 'HEAD/refs/staged/known D changed: ' + root)
            need(all(x.startswith(b' D ') for x in values['status'].split(b'\0') if x), 'unknown non-D status')
            common = Path(values['common'].decode().strip())
            common = common if common.is_absolute() else Path(root) / common
            ix = Path(values['index'].decode().strip())
            ix = ix if ix.is_absolute() else Path(root) / ix
            need(Path(values['gitdir'].decode().strip()) == gd and gd.resolve() == gd
                 and common.resolve() == gd and ix.resolve() == gd / 'index', 'shared/effective Git path drift')
            need(gd.is_dir() and not any((gd / name).exists() for name in ('commondir', 'gitdir', 'worktrees')), 'private Git structure changed')
            need(not list(gd.glob('*.lock')) and not list((gd / 'refs').rglob('*.lock')), 'active Git lock')
            states.append(dict(root=root, **observed, staged_empty=True, status_is_exact_prior_D=True))
        return states

    def verify_namespace():
        for directory in gpu['directories']:
            path = Path(directory['path'])
            ancestors(path)
            s = path.lstat()
            need(stat.S_ISDIR(s.st_mode), 'GPU directory type drift')
            need((s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_mtime_ns) ==
                 tuple(directory[k] for k in ('device', 'inode', 'mode', 'nlink', 'mtime_ns')), 'GPU directory drift')
            expected = {str(p) for p, _ in expected_files if p.parent == path}
            need({str(p) for p in path.iterdir()} == expected, 'GPU exact namespace drift')

    try:
        AUDIT.mkdir(mode=0o700)
        audit_created = True
        syncdir(OWN)
        write_new(AUDIT / 'REQUEST.json', request_raw)
        write_new(AUDIT / 'EXECUTOR.py', Path(__file__).read_bytes())
        spec = importlib.util.spec_from_file_location('backup_only_readable_proc_consumer', PINNED['consumer'][0])
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        consumers('before')
        result['git_before'] = git_state('before')
        verify_namespace()
        bodies = [exact_file(path, e) for path, e in expected_files]
        byte_map = dict(schema='candidate-full168-restorable-byte-map/1', scope_only_not_cleanup_authorization=True,
                        original_gpu_manifest_sha256=h(loaded['gpu']), index_stat_sha256=h(loaded['index_stat']),
                        files=map_rows, directory_metadata=gpu['directories'], GPU_owner_receipt_bindings=gpu['receipt_bindings'],
                        inode_ctime_not_restorable=True, objects_refs_fixtures_original_receipts_excluded=True)
        byte_map_raw = json.dumps(byte_map, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
            info = tarfile.TarInfo('BYTE_MAP.json')
            info.size, info.mode, info.uid, info.gid, info.mtime = len(byte_map_raw), 0o600, 1000, 1000, 0
            archive.addfile(info, io.BytesIO(byte_map_raw))
            for row, body in zip(map_rows, bodies):
                info = tarfile.TarInfo(row['archive_member'])
                info.size, info.mode, info.uid, info.gid = len(body), stat.S_IMODE(row['mode']), row['uid'], row['gid']
                info.mtime = row['mtime_ns'] // 1000000000
                info.pax_headers = {'mtime': f"{row['mtime_ns']//1000000000}.{row['mtime_ns']%1000000000:09d}"}
                archive.addfile(info, io.BytesIO(body))
        tar_raw = buffer.getvalue()
        archive_raw = lzma.compress(tar_raw, format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6)

        def verify_archive(raw):
            unpacked = lzma.decompress(raw)
            need(unpacked == tar_raw, 'complete XZ mismatch')
            with tarfile.open(fileobj=io.BytesIO(unpacked), mode='r:') as archive:
                need(archive.getnames() == ['BYTE_MAP.json'] + [r['archive_member'] for r in map_rows], 'archive member list changed')
                need(archive.extractfile('BYTE_MAP.json').read() == byte_map_raw, 'internal byte map mismatch')
                for row, body in zip(map_rows, bodies):
                    need(archive.extractfile(row['archive_member']).read() == body, 'full archived bytes mismatch')

        verify_archive(archive_raw)
        index_raw = encoded(plan['archive_measurement'])
        payloads = {'SNAPSHOT.tar.xz': archive_raw, 'RESTORE.md': RESTORE.encode(), 'INDEX.json': index_raw}
        for item in preview['files']:
            path = Path(item['source_path'])
            need(path.parent == OUT and path.name in payloads, 'fixed preview source mismatch')
            raw = payloads[path.name]
            need(len(raw) == item['bytes'] and h(raw) == item['sha256'], 'deterministic payload differs from reviewed plan')
        need(h(byte_map_raw) == plan['archive_measurement']['internal_byte_map_sha256'], 'reviewed byte map changed')
        consumers('before-materialize')
        capacity('before_materialize')
        write_new(AUDIT / 'PAYLOAD_WRITE_INTENTS.json', encoded(preview['files']))
        OUT.mkdir(mode=0o700)
        syncdir(OWN)
        for name, raw in payloads.items():
            write_new(OUT / name, raw)
            result['persisted_payloads'].append(dict(path=str(OUT / name), bytes=len(raw), sha256=h(raw)))
        verify_archive((OUT / 'SNAPSHOT.tar.xz').read_bytes())
        result['full_archive_persisted'] = True
        verify_namespace()
        for (path, expected), body in zip(expected_files, bodies):
            need(exact_file(path, expected) == body, 'original changed after materialization')
        result['git_after'] = git_state('after')
        for path, expected in expected_files[:3]:
            exact_file(path, expected)
        consumers('after')
        capacity('after_materialize', materialized=True)
        write_new(AUDIT / 'PUBLISHER_MANIFEST.json', manifest_raw)
        write_new(AUDIT / 'BYTE_MAP.json', byte_map_raw)
        result.update(exit_code=0, backup_materialized=True, full_persisted_archive_roundtrip=True,
                      all_168_original_full_identity_and_hash_unchanged=True,
                      payloads=preview['files'], byte_map_sha256=h(byte_map_raw),
                      original_logical_bytes=sum(len(b) for b in bodies), original_allocated_bytes=23707648)
    except BaseException as exc:
        result['error'] = repr(exc)
        raise
    finally:
        if audit_created:
            result['ended_utc'] = utc().isoformat()
            result['consumers'] = consumer_rows
            command_raw = encoded(dict(commands=commands))
            command_xz = lzma.compress(command_raw, preset=6)
            need(lzma.decompress(command_xz) == command_raw, 'command evidence roundtrip')
            write_new(AUDIT / 'COMMANDS.json.xz', command_xz)
            result['command_streams'] = dict(commands=len(commands), raw_bytes=len(command_raw), raw_sha256=h(command_raw),
                                           xz_bytes=len(command_xz), xz_sha256=h(command_xz))
            result_raw = encoded(result)
            receipt_actual = sum(p.lstat().st_blocks * 512 for p in AUDIT.rglob('*'))
            projected_receipt = receipt_actual + ((len(result_raw) + 4095) // 4096) * 4096
            if projected_receipt > RECEIPT_ALLOWANCE:
                result['exit_code'] = 1
                result['error'] = 'receipt planning allowance exceeded'
                write_new(AUDIT / 'RESULT.json', encoded(result))
                raise RuntimeError(result['error'])
            write_new(AUDIT / 'RESULT.json', result_raw)
            syncdir(AUDIT)
            print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
