"""Root-only, index-free metadata append; default is a read-only local plan."""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from pathlib import Path

F = 'cbf0fb621888596aa14ad5f2349b503e23b1b72d'
A = 'a6f4013364e21bcb7239b5dcc25caac0f6d61f77'
HEAD = '3e4f2560aa11ed2a626db98ba5ed6f129e791052'
E = 'df84890966a600d3ba7e39c5b8ba882b18d1a9b2'
BODY = 'codex/train337-recovered-evidence-20261026-prbody'
HANDOFF = 'handoff/codex-takeover-20261021'
TRAIN = 'codex/train-337-continue-20261024'
RECOVERY = 'codex/train337-recovered-evidence-20261026'
OWN = Path('/dev/shm/geometry-axiom-geo337-20261025')
OTHER = Path('/dev/shm/geo337-F9-browsers-20261025')
P = OWN/'publisher-source'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_SHA = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
PROGRESS_SHA = '65bc4fe930487a2ce96d913e5382ac1f209bb77bfa0d96139bc1ced4dc861c06'

def need(ok, why):
    if not ok:
        raise RuntimeError(why)
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def h(path):
    return digest(Path(path).read_bytes())
def dump(path, obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--execute',action='store_true')
ap.add_argument('--mode',choices=('body','handoff'),required=True)
ap.add_argument('--expected-parent',required=True)
ap.add_argument('--document',type=Path,required=True)
ap.add_argument('--document-sha256',required=True)
ap.add_argument('--body-commit')
ap.add_argument('--body-sha256')
ap.add_argument('--peer',type=Path,required=True)
ap.add_argument('--peer-sha256',required=True)
ap.add_argument('--out',type=Path,required=True)
a=ap.parse_args()
need(not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ,'No optimized guards')
need(re.fullmatch('[0-9a-f]{40}',a.expected_parent),'Need full expected parent')
need(re.fullmatch('[0-9a-f]{64}',a.document_sha256),'Need full document hash')
raw=a.document.read_bytes()
need(digest(raw)==a.document_sha256 and raw.startswith(b'# '),'Document drift')
need(b'__EVIDENCE_COMMIT__' not in raw and b'__BODY_COMMIT__' not in raw,'Unresolved placeholders')
need(E.encode() in raw and F.encode() in raw,'Wrong fixed source/evidence')
need(h(CAPTURE)==CAPTURE_SHA,'Original capture drift')
need(h(a.peer)==a.peer_sha256,'Peer drift')
peer=json.loads(a.peer.read_bytes())
need(peer['exit_code']==0 and not peer['blocking'],'Peer did not approve')
need(peer['tool_sha256']==h(__file__),'Peer does not cover this publisher')
need(peer['document_sha256'].get(a.mode)==a.document_sha256,'Peer does not cover frozen document')
if a.mode=='handoff':
    need(a.body_commit and re.fullmatch('[0-9a-f]{40}',a.body_commit),'Need published body full SHA')
    need(a.body_sha256 and re.fullmatch('[0-9a-f]{64}',a.body_sha256),'Need body bytes hash')
    need(a.body_commit.encode() in raw,'Prefix does not bind body commit')
else:
    need(a.expected_parent=='990440297d851dccbc077cdf59fe654fdbd9ffd8','Unexpected body parent')
    need(a.body_commit is None and a.body_sha256 is None,'Body publication does not accept prior body fields')
if not a.execute:
    print(json.dumps({'execute':False,'mode':a.mode,'product_sha':F,'evidence_sha':E,'document_sha256':digest(raw),'out':str(a.out)}))
    sys.exit(0)
need(not a.out.exists() and a.out.parent==OWN,'Need fresh direct OWN output')
seen=set(); used=0
for root in (OWN,OTHER):
    for path in (root,*root.rglob('*')):
        s=path.lstat(); key=(s.st_dev,s.st_ino)
        if key not in seen:
            seen.add(key);used+=s.st_blocks*512
need(used+67108864<=2147483648,'Original 2 GiB planning guard')
need(shutil.disk_usage(OWN).free>=67108864,'Physical 64 MiB publication allowance')
a.out.mkdir()
(a.out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
(a.out/'INPUT.md').write_bytes(raw)
(a.out/'PEER.json').write_bytes(a.peer.read_bytes())
dump(a.out/'CAPACITY.json',{'two_OWN_allocated':used,'additional_bound':67108864,'ceiling':2147483648})
sys.path.insert(0,str(CAPTURE.parent))
from capture import Recorder
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
rec=Recorder(a.out,env,F)
def run(argv,data=None):
    row,b,e=rec.run(argv,cwd=P,data=data,timeout=180,check=False,source_variant='root metadata only; no source/index edits')
    need(row['actual_process_returncode']==0,row['directory'])
    return b
def git(*args,data=None):
    return run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],data)
def remote(branch):
    rows=git('ls-remote','--heads','origin','refs/heads/'+branch).splitlines()
    need(len(rows)==1,'Need one remote branch')
    sha,ref=rows[0].split(b'\t')
    need(ref==('refs/heads/'+branch).encode(),'Remote ref mismatch')
    return sha.decode()
def state():
    return {'HEAD':git('rev-parse','HEAD').decode().strip(),'train_ref':git('rev-parse','refs/heads/'+TRAIN).decode().strip(),'branch':git('branch','--show-current').decode().strip(),'index_sha256':h(P/'.git/index'),'status':git('status','--porcelain=v1','--untracked-files=all').decode()}
def tree_rows(tree):
    rows={}
    for row in git('ls-tree','-z',tree).split(b'\0'):
        if row:
            hdr,name=row.split(b'\t',1);mode,kind,oid=hdr.split(b' ')
            need(name not in rows,'Duplicate tree member')
            rows[name]=(mode,kind,oid)
    return rows
def replace_leaf(tree,parts,blob):
    rows=tree_rows(tree);name=parts[0].encode()
    need(name in rows,'Expected existing metadata path')
    if len(parts)==1:
        need(rows[name][:2]==(b'100644',b'blob'),'Expected normal metadata blob')
        rows[name]=(b'100644',b'blob',blob.encode())
    else:
        need(rows[name][:2]==(b'040000',b'tree'),'Expected metadata directory')
        rows[name]=(b'040000',b'tree',replace_leaf(rows[name][2].decode(),parts[1:],blob).encode())
    stream=b''.join(mode+b' '+kind+b' '+oid+b'\t'+name+b'\0' for name,(mode,kind,oid) in rows.items())
    new=git('mktree','-z',data=stream).decode().strip()
    need(tree_rows(new)==rows,'Unexpected tree contents')
    return new

result={'exit_code':1,'published':False,'delivered':False,'product_sha':F,'evidence_sha':E,'mode':a.mode,'expected_parent':a.expected_parent,'PR_merged':False,'product_ref_modified':False}
branch=BODY if a.mode=='body' else HANDOFF
target='PR_BODY.md' if a.mode=='body' else 'handoff/NEXT.md'
try:
    before=state();dump(a.out/'BEFORE.json',before)
    need(before['HEAD']==before['train_ref']==HEAD and before['branch']==TRAIN and before['status']=='','Publisher changed')
    need(remote(branch)==a.expected_parent and remote(TRAIN)==A and remote(RECOVERY)==E,'Expected remote source/evidence/metadata moved')
    need(h(P/'.git/index')==before['index_sha256'],'Index moved')
    need(digest(git('show',E+':evidence/geo337-train-20261024/resume-20261026/PROGRESS.md'))==PROGRESS_SHA,'Evidence PROGRESS mismatch')
    delta=git('diff','--name-only',F,E).decode().splitlines()
    need(delta and all(x.startswith('evidence/') for x in delta),'Evidence changes product paths')
    old=git('show',a.expected_parent+':'+target);(a.out/'BEFORE.md').write_bytes(old)
    if a.mode=='handoff':
        need(remote(BODY)==a.body_commit,'Published body moved')
        need(digest(git('show',a.body_commit+':PR_BODY.md'))==a.body_sha256,'Published body drift')
        request=git('show',a.expected_parent+':handoff/pr-requests/train-337-continue-20261024.json')
        q=json.loads(request)
        need(q=={'head':TRAIN,'base':'main','title':'feat: complete the reading A integration train replacing #337','body_ref':BODY,'body_path':'PR_BODY.md'},'Existing PR request differs')
        (a.out/'REQUEST_UNCHANGED.json').write_bytes(request)
        data=raw+'\n\n---\n\n## 先前交接原文（完整保留，以下為歷史）\n\n'.encode()+old
        need(data.endswith(old),'Old handoff not preserved')
    else:
        data=raw
    need(data!=old,'No new metadata')
    (a.out/'PUBLISHED.md').write_bytes(data)
    blob=git('hash-object','-w','--stdin',data=data).decode().strip()
    need(blob==hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'Blob mismatch')
    tree=replace_leaf(git('rev-parse',a.expected_parent+'^{tree}').decode().strip(),target.split('/'),blob)
    message=b'docs: publish verified cleanup and candidate reader status\n' if a.mode=='body' else b'docs: hand off completed cleanup and candidate reader evidence\n'
    commit=git('commit-tree',tree,'-p',a.expected_parent,data=message).decode().strip()
    need(git('diff-tree','--no-commit-id','--name-only','--no-renames','-r','-z',a.expected_parent,commit)==target.encode()+b'\0','Unexpected metadata delta')
    need(git('show','-s','--format=%P',commit).decode().strip()==a.expected_parent,'Unexpected commit parent')
    need(state()==before and remote(branch)==a.expected_parent,'Concurrent metadata/index movement')
    need(a.document.read_bytes()==raw,'Input changed before push')
    git('push','origin',commit+':refs/heads/'+branch)
    result.update(published=True,commit=commit,blob=blob,branch=branch)
    need(remote(branch)==commit,'Published remote differs')
    fetched=run(['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json','repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob])
    need(fetched==data,'Remote full bytes mismatch')
    after=state();dump(a.out/'AFTER.json',after)
    need(after==before and remote(TRAIN)==A,'Publisher or product ref moved')
    result.update(exit_code=0,delivered=True,sha256=digest(data),bytes=len(data),changed_path=target,head_and_index_unchanged=True,request_unchanged=True,PR_application_verified=False)
finally:
    dump(a.out/'RESULT.json',result)
print(json.dumps(result))
sys.exit(result['exit_code'])
