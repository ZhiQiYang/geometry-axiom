"""Capture one reviewed driver-only diagnostic; no formal test is run."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

own = Path('/dev/shm/geometry-axiom-geo337-20261025')
capfile = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
driver = Path('/tmp/geo-resume1758-axiom-driver-v2-20261026/DRIVER.py')
assert hashlib.sha256(capfile.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert hashlib.sha256(driver.read_bytes()).hexdigest() == 'e8eca29381076a94e4e34cfeba257ae810a4181fa1b7e44e6595223b9a69da30'
out = own / 'a7-driver-outer-F-cbf0fb62-v2-20261026'
assert not out.exists()
out.mkdir()
(out / 'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
spec = importlib.util.spec_from_file_location('capture', capfile)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           GEO261_REAPER_LOG=str(out / 'reaper.jsonl'))
rec = cap.Recorder(out, env, 'cbf0fb621888596aa14ad5f2349b503e23b1b72d')
argv = ['python3', '-B', '/workspace/geo261-environment/reap_children.py',
        'python3', '-B', str(driver), '--execute', '--scheduler-slot', '1',
        '--tmp-root', '/tmp/geo-axiom-driver-F-cbf0fb62-v2-20261026',
        '--output', str(own / 'a7-axiom-driver-F-cbf0fb62-v2-20261026')]
row, stdout, stderr = rec.run(argv, cwd='/workspace', timeout=None, check=False)
result = {'exit_code': row['actual_process_returncode'], 'formal_acceptance': False,
          'source_sha': rec.sha, 'command': argv, 'complete_raw_directory': str(out),
          'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
          'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
cap.dump(out / 'RESULT.json', result)
print(json.dumps(result))
raise SystemExit(row['actual_process_returncode'])
