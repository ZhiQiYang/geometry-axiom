import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

OUT=Path('/workspace/geo337-cold-retirement-execute-launch-20261023')
DRIVER=Path('/workspace/geo337-cold-retirement.py')
PREPARED=Path('/workspace/geo337-cold-retirement-20261023/PREPARED.json')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='1ef679ea1d26881fac4280e26bb4c3fe2b324ae8c0e9d231635cbf8595994a84'
assert sha(PREPARED)=='6032106c410f384e16faa00c7c2597149de11de650971aa323de6d273bbc62bc'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
head=subprocess.check_output(['git','-C','/workspace/geometry-axiom','rev-parse','HEAD']).decode().strip()
rec=cap.Recorder(OUT,env,head)
row,out,err=rec.run(['python3','-B',str(DRIVER),'--execute'],cwd='/workspace',timeout=None,check=False,source_variant='root-owned terminal checkout storage retirement; not a product gate')
cap.dump(OUT/'receipt.json',dict(source_sha=head,driver_sha256=sha(DRIVER),prepared_sha256=sha(PREPARED),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
