"""Retire exact immutable code copies from completed, root-owned checkouts."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

BASE=Path('/tmp/train337-cold-checkout-static-20261024')
OUT=Path('/workspace/geo337-cold-retirement-20261023')
PINS={'CANDIDATES.jsonl':'024fcfa150fa89b9ccf3fff29c15dcbf4a4375563fc18a1fd6d920ad722771b5',
      'SUMMARY.json':'6c19b02ffb83596fc374e6e85db19469532c2a7a18b0fbdaea6301075fc32b50',
      'PRODUCER_TERMINAL_ADDENDUM.json':'2454d87b7303c10f29e8e3a13ca2c40d8ee1b6d5e9a91b91f70625ce535d8113'}
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def free(): return {p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']}
def git(root,*args): return subprocess.check_output(['git','-C',root,*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
for name,h in PINS.items(): assert sha((BASE/name).read_bytes())==h
summary=json.loads((BASE/'SUMMARY.json').read_text())
rows=[json.loads(line) for line in (BASE/'CANDIDATES.jsonl').read_text().splitlines()]
roots={r['repo']:r['head'] for r in summary['repos'] if r['eligible_files_after_alias_guard']}
assert len(roots)==10 and len(rows)==9510
paths=[]
for r in rows:
    p=Path(r['repo'])/r['relative']
    assert r['repo'] in roots and r['head']==roots[r['repo']]
    assert p.resolve()==p and p.is_relative_to('/workspace/geo261-cold')
    assert p.suffix in {'.c','.h','.inc','.py','.js','.mjs','.cjs','.html','.htm','.css','.ps1','.sh','.bat','.cmd','.ts','.tsx','.jsx'}
    assert not any(x.lower() in {'.git','evidence','fixtures','fixture','receipts','receipt','raw','trace','withdrawn','counterfactual','new-mutation-cache','mutation-cache'} for x in p.parts)
    assert not any(x in str(p).lower() for x in ['mutant','counterfactual','withdrawn','/trace/'])
    assert p.name!='gmon.out' and r['nlink']==1
    paths.append(p)
assert len(set(paths))==9510
terminal={}
def find_receipts(value):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value and Path(value['path']).is_file(): terminal[value['path']]=value['sha256']
        if 'move_receipt' in value: terminal[value['move_receipt']]=value['move_receipt_sha256']
        for v in value.values():find_receipts(v)
    elif isinstance(value,list):
        for v in value: find_receipts(v)
find_receipts(summary['root_producer_retirement'])
find_receipts(json.loads((BASE/'PRODUCER_TERMINAL_ADDENDUM.json').read_text()))
def check_terminal():
    for p,h in terminal.items(): assert sha(Path(p).read_bytes())==h,p
def check_file(r,p):
    s=p.lstat();assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],1,r['bytes'],r['mtime_ns']),str(p)
    b=p.read_bytes();assert sha(b)==r['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob'],str(p)
    return b
def identities():
    values={}
    for root,h in roots.items():
        assert git(root,'rev-parse','HEAD').decode().strip()==h
        index=Path(git(root,'rev-parse','--git-path','index').decode().strip())
        if not index.is_absolute():index=Path(root)/index
        values[root]=dict(head=h,index_path=str(index),index_sha256=sha(index.read_bytes()))
    return values
def consumers(label):
    records=[];errors=[];matches=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:
            status=(proc/'status').read_text()
            fields={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in status.splitlines() if ':' in x}
            if fields.get('State','').startswith('Z'):continue
            raw=(proc/'cmdline').read_bytes()
        except FileNotFoundError:continue
        except OSError as e:errors.append(dict(pid=proc.name,error=repr(e)));continue
        item=dict(pid=int(proc.name),ppid=fields.get('PPid'),name=fields.get('Name'),cmdline_sha256=sha(raw))
        try:item['cwd']=os.readlink(proc/'cwd')
        except OSError as e:item['cwd_unreadable']=repr(e)
        text=raw.replace(b'\0',b' ').decode(errors='replace')
        if any(root in text or item.get('cwd','').startswith(root) for root in roots):matches.append(item)
        records.append(item)
    dump(OUT/(label+'-consumers.json'),dict(processes=records,errors=errors,matches=matches,limitation='Inaccessible proc cwd/exe not claimed inspected; exact producers are terminal and no current or planned job uses these ten source materializations. Git objects and all protected artifacts remain.'))
    assert not errors and not matches,'Potential current consumer; no deletion'
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');a=parser.parse_args()
if not a.execute:
    assert not OUT.exists();OUT.mkdir()
    check_terminal();before=identities();consumers('prepare')
    payloads={}
    for r,p in zip(rows,paths):
        b=check_file(r,p)
        if r['sha256'] not in payloads:payloads[r['sha256']]=b
    assert len(payloads)==966 and sum(map(len,payloads.values()))==20235083
    archive=OUT/'original-code-payloads-and-path-map.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for h,b in sorted(payloads.items()):
            info=tarfile.TarInfo('payloads/'+h);info.size=len(b);info.mode=0o444;tar.addfile(info,io.BytesIO(b))
        for name in PINS:tar.add(BASE/name,arcname='original-inventory/'+name,recursive=False)
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers())==969
        for h,b in sorted(payloads.items()):assert tar.extractfile('payloads/'+h).read()==b
        for name in PINS:assert tar.extractfile('original-inventory/'+name).read()==(BASE/name).read_bytes()
    assert identities()==before;check_terminal()
    dump(OUT/'PREPARED.json',dict(schema='cold-code-retirement/1',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_pins=PINS,archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,files=len(rows),logical_bytes=sum(r['bytes'] for r in rows),allocated_bytes=sum(r['allocated'] for r in rows),unique_payloads=966,complete_byte_roundtrip=True,git_identities=before,terminal_receipts=terminal,deleted=False,free_bytes=free()))
    print(json.dumps(dict(prepared=True,files=9510,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),free=free())))
else:
    prepared=json.loads((OUT/'PREPARED.json').read_text())
    assert not (OUT/'EXECUTED.json').exists()
    assert prepared['candidate_pins']==PINS and sha(Path(prepared['archive']).read_bytes())==prepared['archive_sha256']
    assert identities()==prepared['git_identities'];check_terminal()
    for r,p in zip(rows,paths):check_file(r,p)
    consumers('immediate-before-execute')
    result=dict(prepared_sha256=sha((OUT/'PREPARED.json').read_bytes()),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_before=free(),removed=[],exit_code=1,scope='Only exact 9510 immutable code copies in retired checkouts. Checkouts now intentionally lack these materializations; all full original bytes, Git identities/objects, receipts, evidence and fixtures remain.')
    try:
        for r,p in zip(rows,paths):
            check_file(r,p);p.unlink();result['removed'].append(dict(path=str(p),bytes=r['bytes'],sha256=r['sha256']))
        assert identities()==prepared['git_identities'];check_terminal();result['exit_code']=0
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=free());dump(OUT/'EXECUTED.json',result)
    print(json.dumps(dict(exit_code=result['exit_code'],removed=len(result['removed']),free_before=result['free_before'],free_after=result['free_after'])))
