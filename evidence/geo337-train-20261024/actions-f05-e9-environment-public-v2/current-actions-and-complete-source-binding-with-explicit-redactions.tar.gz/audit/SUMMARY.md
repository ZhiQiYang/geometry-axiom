# 新 head Actions 環境分類

#338 run 40043471807（f05e7cfd）與 #339 run 40040764499（e9ee6d08）各七 job 均 completed/failure、runner_id=0、runner_name 空、steps=[]。14 份原 annotation 都明示帳戶付款失敗 **或** 支出上限限制；無法由 API 區分兩者。這次是對新 run 逐項查證，未沿用舊 run 的結論。

兩次原 gh --log 均 exit 1，原因是簽章下載端點回 Forbidden；不能據此證明 log 不存在。原完整 stderr 留在雲端原 capture，公開包只精確遮蔽 signature query 的值，PUBLIC_REDACTIONS.json 保留原雜湊、長度、位元組範圍及公開副本雜湊；其餘原 API 流不改。此保密例外不冒稱公開流完全未遮蔽。

正式替代依據已找到：《決策佇列.md》57–58 的決策 B 採 WSL 等價七 job，286–301 的 M 改為進 main 的列車結果，317–327 指示不處理 Actions 計費。795–804 的雲端試行明限 #288，仍要求同可解析最終 SHA、七項及專項；handoff/HANDOFF.md:17 記載 Linux 等價七項。CLASSIFICATION.json 保存逐字引文、行號及來源 SHA。此處不自行擴張成任意 evidence head 可移標的規則，也不解除本輪 B3/B2；來源 L 的驗收結果仍須完整且接受複審。

共 53 個原始讀取命令：51 個 exit 0，兩個 log 下載 exit 1。沒有帳戶／workflow 設定變更、CI 重跑、API 寫入或產品測試執行。歷史 WSL 暫定 3× 時限僅作原文保留，不改本輪 CI 原時限。
