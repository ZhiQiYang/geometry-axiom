# 來源 SHA 與收據 head 的完整樹對照

此處沒有挑選幾個 closure 檔案，而是保存兩組完整未篩選 `git ls-tree -r -z --full-tree` 原流，逐全部路徑比對 mode/type/object ID，另保完整 raw diff 與 name-status。

- #338：`7af8c5d80d34cb4f49d01ba67deb78a3a6d725db` → `935dc904c933a2c54e89848bc99436073e84fcd8`；變更 260 路徑，root evidence/ 外變更 0，全部非 evidence 路徑映射相等：True。
- #339：`38da31bcac91db631e6325e40b228f8604810e82` → `e9ee6d088b0cad4e3984aa2842a50acc311c2351`；變更 20 路徑，root evidence/ 外變更 0，全部非 evidence 路徑映射相等：True。

這證明上述具名收據提交沒有改變產品、測試、fixture、workflow 等全部非 evidence tracked tree，不把舊 runtime execution SHA 改成新 evidence head。依既有 B/M 與 HANDOFF 的 Linux 等價七項流程，來源驗收與收據提交可明列對應；本調查不自行宣告 current Actions 成功或解除 B3/B2。native、其餘專項與跨版本 exact 等價門檻仍以主代理 current-state 矩陣的真正結果為準。

此次只讀調查最初把三字元縮寫 `935` 當 Git revision 的臨時查詢失敗（Git 最少四字元）；隨即讀取 branch log 取得完整 935dc904…，上述正式原流皆使用完整 40 字元 SHA，未執行任何 checkout/reset 或來源變更。
