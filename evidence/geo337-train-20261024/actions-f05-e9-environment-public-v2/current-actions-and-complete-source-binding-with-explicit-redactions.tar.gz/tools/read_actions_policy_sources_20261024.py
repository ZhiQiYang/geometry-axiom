"""Append original adopted policy texts to the read-only Actions audit."""
from pathlib import Path
import hashlib,importlib.util,json,os
B=Path('/workspace/pr338-pr339-current-actions-environment-20261024')
C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('cap',C);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GH_PROMPT_DISABLED='1')
sha='f05e7cfd373c9a77a366f7b2ddafd9401f261cf4';r=c.Recorder(B/'policy-original-metadata',env,sha)
for name,argv in [('main-sha',['git','rev-parse','origin/main']),('decisions',['git','show',sha+':決策佇列.md']),('manager-context',['git','show',sha+':geometry-web/work-manager/README.md']),('p0-validation-context',['git','show',sha+':geometry-core/domain-decoupling/VALIDATION.md']),('policy-exception-context',['git','show',sha+':evidence/geo261-codex-fix-policy-exception-protocol-20261018/README.md'])]:
 row,out,err=r.run(argv,cwd='/workspace/geometry-axiom',timeout=120,check=False,source_variant='read-only adopted policy text and limited contextual precedents')
 if row['actual_process_returncode']==0:(B/('PROCEDURE_SOURCE_'+name+'.txt')).write_bytes(out)
 print(json.dumps(dict(name=name,exit=row['actual_process_returncode'],stdoutBytes=len(out),directory=row['directory'])))
c.dump(B/'POLICY_READ_RESULT.json',dict(commands=r.rows,noPolicyChanges=True))
