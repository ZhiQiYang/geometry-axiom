"""Read complete tracked trees and raw Git diffs for source/evidence head binding."""
from pathlib import Path
import hashlib,importlib.util,json,os,datetime
B=Path('/workspace/pr338-pr339-current-actions-environment-20261024')
C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('cap',C);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
r=c.Recorder(B/'full-tree-original-metadata',env,'935dc904c933a2c54e89848bc99436073e84fcd8')
def run(argv,sha):
 row,out,err=r.run(argv,cwd='/workspace/geometry-axiom',timeout=120,check=False,source_sha=sha,source_variant='read-only whole tracked tree comparison; no runtime pass inferred')
 print(json.dumps(dict(exit=row['actual_process_returncode'],directory=row['directory'],stdoutBytes=len(out))))
 assert row['actual_process_returncode']==0
 return row,out
def tree(raw):
 result={}
 for entry in raw.split(b'\0'):
  if not entry:continue
  meta,path=entry.split(b'\t',1);assert path not in result;result[path]=meta
 return result
pairs=[(338,'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db','935dc904c933a2c54e89848bc99436073e84fcd8'),(339,'38da31bcac91db631e6325e40b228f8604810e82','e9ee6d088b0cad4e3984aa2842a50acc311c2351')]
reports=[]
for pr,source,evidence in pairs:
 trees=[];captures=[]
 for sha in [source,evidence]:
  row,out=run(['git','rev-parse',sha+'^{commit}'],sha);assert out.decode().strip()==sha
  row,out=run(['git','ls-tree','-r','-z','--full-tree',sha],sha);trees.append(tree(out));captures.append(dict(sha=sha,original_command=row,tree_raw_sha256=hashlib.sha256(out).hexdigest(),entries=len(trees[-1])))
 row,raw=run(['git','diff','--raw','--full-index','--no-abbrev','--no-renames','-z',source,evidence,'--'],evidence)
 raw_row=row
 row,names=run(['git','diff','--name-status','--no-renames','-z',source,evidence,'--'],evidence)
 a,b=trees;changed=sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k));outside=[k for k in changed if not k.startswith(b'evidence/')]
 non_a={k:v for k,v in a.items() if not k.startswith(b'evidence/')};non_b={k:v for k,v in b.items() if not k.startswith(b'evidence/')}
 ordered=lambda x:b'\0'.join(k+b'\t'+v for k,v in sorted(x.items()))
 proof=dict(pr=pr,execution_source=source,evidence_head=evidence,whole_tree_captures=captures,raw_diff_command=raw_row,name_status_command=row,total_changed_paths=len(changed),all_changed_paths=[k.decode() for k in changed],changed_outside_root_evidence=[k.decode() for k in outside],only_root_evidence_changed=not outside,complete_non_evidence_path_mode_type_object_id_maps_equal=non_a==non_b,non_evidence_paths_source=len(non_a),non_evidence_paths_evidence=len(non_b),canonical_non_evidence_map_sha256_source=hashlib.sha256(ordered(non_a)).hexdigest(),canonical_non_evidence_map_sha256_evidence=hashlib.sha256(ordered(non_b)).hexdigest(),method='Compare every path/mode/type/Git object ID from two complete unfiltered git ls-tree -rz --full-tree streams; root evidence/ is the sole excluded prefix. Raw Git diff independently retained. No handpicked executable closure.',limits=['Git blob/tree identity proof, not execution on evidence head.','Original runtime SHA/exit values remain source L or F, never relabeled to evidence head.','Any future product/test/fixture/workflow or non-evidence change requires a new comparison and impacted validation; this proof names only these exact pairs.'])
 reports.append(proof)
c.dump(B/'SOURCE_BINDING.json',dict(createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pairs=reports,exit_code=0,product_test_or_workflow_modified_by_audit=False))
summary='''# 來源 SHA 與收據 head 的完整樹對照

此處沒有挑選幾個 closure 檔案，而是保存兩組完整未篩選 `git ls-tree -r -z --full-tree` 原流，逐全部路徑比對 mode/type/object ID，另保完整 raw diff 與 name-status。

'''
for p in reports:
 summary+=f"- #{p['pr']}：`{p['execution_source']}` → `{p['evidence_head']}`；變更 {p['total_changed_paths']} 路徑，root evidence/ 外變更 {len(p['changed_outside_root_evidence'])}，全部非 evidence 路徑映射相等：{p['complete_non_evidence_path_mode_type_object_id_maps_equal']}。\n"
summary+='''
這證明上述具名收據提交沒有改變產品、測試、fixture、workflow 等全部非 evidence tracked tree，不把舊 runtime execution SHA 改成新 evidence head。依既有 B/M 與 HANDOFF 的 Linux 等價七項流程，來源驗收與收據提交可明列對應；本調查不自行宣告 current Actions 成功或解除 B3/B2。native、其餘專項與跨版本 exact 等價門檻仍以主代理 current-state 矩陣的真正結果為準。

此次只讀調查最初把三字元縮寫 `935` 當 Git revision 的臨時查詢失敗（Git 最少四字元）；隨即讀取 branch log 取得完整 935dc904…，上述正式原流皆使用完整 40 字元 SHA，未執行任何 checkout/reset 或來源變更。
'''
(B/'SOURCE_BINDING.md').write_text(summary)
print(json.dumps(dict(report=str(B/'SOURCE_BINDING.json'),sha256=hashlib.sha256((B/'SOURCE_BINDING.json').read_bytes()).hexdigest(),pairs=[dict(pr=x['pr'],changed=x['total_changed_paths'],outside=len(x['changed_outside_root_evidence']),equal=x['complete_non_evidence_path_mode_type_object_id_maps_equal']) for x in reports])))
