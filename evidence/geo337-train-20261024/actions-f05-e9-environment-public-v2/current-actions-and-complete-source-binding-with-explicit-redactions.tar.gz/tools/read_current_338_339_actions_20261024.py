"""Capture current reviewed Actions metadata and repository procedure sources; read-only."""
from pathlib import Path
import hashlib,importlib.util,json,os,datetime
BASE=Path('/workspace/pr338-pr339-current-actions-environment-20261024')
BASE.mkdir()
REPO=Path('/workspace/geometry-axiom')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('cap',CAP);cap=importlib.util.module_from_spec(s);s.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None)
env.update(PYTHONDONTWRITEBYTECODE='1',GH_PAGER='cat',PAGER='cat',GH_PROMPT_DISABLED='1',GIT_OPTIONAL_LOCKS='0')
CONTEXT='f05e7cfd373c9a77a366f7b2ddafd9401f261cf4'
rec=cap.Recorder(BASE/'original-metadata',env,CONTEXT)
def run(argv,sha=CONTEXT):
 row,out,err=rec.run(argv,cwd=REPO,timeout=120,check=False,source_sha=sha,source_variant='read-only current reviewed Actions or repository procedure; not product execution')
 print(json.dumps(dict(exit=row['actual_process_returncode'],directory=row['directory'],command=argv,stdoutBytes=len(out),stderrBytes=len(err))),flush=True)
 return row,out,err
def save(name,raw):
 (BASE/name).write_bytes(raw)
row,raw,_=run(['git','rev-parse','origin/handoff/codex-takeover-20261021'])
assert row['actual_process_returncode']==0
handoff=raw.decode().strip();assert handoff.startswith('e3934fbd')
save('handoff_sha.txt',raw)
run(['git','rev-parse','HEAD'])
run(['gh','--version'])
configs=[(338,40043471807,'f05e7cfd373c9a77a366f7b2ddafd9401f261cf4'),(339,40040764499,'e9ee6d088b0cad4e3984aa2842a50acc311c2351')]
outcomes=[]
for pr,runid,sha in configs:
 row,raw,_=run(['git','show',handoff+':handoff/pr-reviews/'+str(pr)+'.md'],sha)
 if row['actual_process_returncode']==0:save(f'LATEST_REVIEW_{pr}.md',raw)
 record=dict(pr=pr,run_id=runid,expected_reviewed_head=sha,requests=[],annotations=[],check_runs=[])
 for label,argv in [('run_api',['gh','api',f'repos/ZhiQiYang/geometry-axiom/actions/runs/{runid}']),('run_view',['gh','run','view',str(runid),'--repo','ZhiQiYang/geometry-axiom']),('jobs_api',['gh','api',f'repos/ZhiQiYang/geometry-axiom/actions/runs/{runid}/jobs','--paginate']),('logs',['gh','run','view',str(runid),'--repo','ZhiQiYang/geometry-axiom','--log'])]:
  row,raw,_=run(argv,sha);record['requests'].append(dict(label=label,command=row))
  if row['actual_process_returncode']==0:
   save(f'PR{pr}_{label}.original',raw)
   if label=='run_api':record['run']=json.loads(raw)
   if label=='jobs_api':record['jobs']=json.loads(raw)['jobs']
 for job in record.get('jobs',[]):
  checkurl=job.get('check_run_url');assert checkurl and checkurl.startswith('https://api.github.com/repos/ZhiQiYang/geometry-axiom/check-runs/')
  endpoint=checkurl.removeprefix('https://api.github.com/')
  for label,argv in [('check_run',['gh','api',endpoint]),('annotations',['gh','api',endpoint+'/annotations','--paginate'])]:
   row,raw,_=run(argv,sha);entry=dict(job=job['name'],job_id=job['id'],command=row)
   if row['actual_process_returncode']==0:entry['response']=json.loads(raw)
   record['check_runs' if label=='check_run' else 'annotations'].append(entry)
 cap.dump(BASE/f'PR{pr}_READ_RESULT.json',record);outcomes.append(dict(pr=pr,run=runid,source_sha=sha))
pattern='替代(驗收|流程)|正式.*雲端|required.*(checks|CI)|雲端驗收|同.head.*(收據|替代)|可.*取代.*CI|CI.*替代'
for name,sha,paths in [('handoff',handoff,['handoff']),('main','origin/main',['*.md',':!evidence/**',':!tests/evidence/**',':!tests/release-evidence/**',':!geometry-core/domain-decoupling/evidence/**']),('train',configs[0][2],['*.md',':!evidence/**',':!tests/evidence/**',':!tests/release-evidence/**',':!geometry-core/domain-decoupling/evidence/**'])]:
 row,raw,_=run(['git','grep','-n','-I','-E',pattern,sha,'--',*paths]);save('PROCEDURE_SEARCH_'+name+'.txt',raw)
for name,ref,path in [('handoff','handoff/HANDOFF.md',handoff),('request-format','handoff/pr-requests/README.md',handoff),('train-agents','AGENTS.md',configs[0][2]),('train-workflow','.github/workflows/integration-tests.yml',configs[0][2])]:
 row,raw,_=run(['git','show',path+':'+ref]);
 if row['actual_process_returncode']==0:save('PROCEDURE_SOURCE_'+name+'.txt',raw)
cap.dump(BASE/'READ_REQUEST.json',dict(createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),handoff_sha=handoff,runs=outcomes,sourceIsMetadataContextOnly=True,writeAPIInvoked=False,workflowRerunInvoked=False,accountSettingsChanged=False,commands=rec.rows,networkPolicySnapshot=json.loads(Path('/etc/codex/network-policy.json').read_text())))
