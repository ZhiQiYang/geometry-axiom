"""Package original current-run audit plus complete tree binding; redact only signed-log credential values."""
from pathlib import Path
import hashlib,json,tarfile,io,re
B=Path('/workspace/pr338-pr339-current-actions-environment-20261024')
OUT=Path('/workspace/pr338-pr339-current-actions-publication-v2-20261024')
def h(x):return hashlib.sha256(x).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=[r for n in ['original-metadata','policy-original-metadata','full-tree-original-metadata'] for r in j(B/n/'subcommands.json')]
assert len(rows)==65 and sum(r['actual_process_returncode']==0 for r in rows)==63
for r in rows:
 p=Path(r['directory']);assert j(p/'result.json')==r and j(p/'request.json')['command']==r['command']
 for stream in ['stdout','stderr']:
  data=(p/(stream+'.bin')).read_bytes();assert h(data)==r[stream+'_sha256'] and len(data)==r[stream+'_bytes']
 assert h((p/'stdin.bin').read_bytes())==r['stdin_sha256']
binding=j(B/'SOURCE_BINDING.json')
assert binding['exit_code']==0 and all(x['only_root_evidence_changed'] and x['complete_non_evidence_path_mode_type_object_id_maps_equal'] for x in binding['pairs'])
(B/'PUBLICATION_V2_NOTE.md').write_text('本 v2 在原 53 個 Actions／policy 讀取上，新增 12 個完整 Git tree／diff 原讀取，共 65 個（63 exit0、兩個簽章 log 下載 Forbidden exit1）。原 CLASSIFICATION／SUMMARY 的 53 指第一段調查，未改寫其原件。完整來源綁定另見 SOURCE_BINDING.json/md；兩具名對照的所有非 evidence/ tracked path/mode/type/blob ID 全同，不把 runtime SHA 移標。原簽章 query 值只留雲端，公開遮蔽範圍另列，無設定或 API 寫入，也不解除尚未完成的 B1/B2/B3。\n')
OUT.mkdir();inventory=[];redactions=[]
sources=[p for p in sorted(B.rglob('*')) if p.is_file()]+[Path('/workspace')/x for x in ['read_current_338_339_actions_20261024.py','read_actions_policy_sources_20261024.py','classify_and_package_current_actions_20261024.py','read_actions_full_tree_binding_20261024.py']]+[Path(__file__)]
archive=OUT/'current-actions-and-complete-source-binding-with-explicit-redactions.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for p in sources:
  raw=p.read_bytes();data=raw;member='audit/'+str(p.relative_to(B)) if p.is_relative_to(B) else 'tools/'+p.name
  matches=list(re.finditer(rb'(?<=[?&]signature=)[^&\s"\x27]+',raw))
  if matches:
   assert p.name=='stderr.bin' and '/original-metadata/subcommands/' in str(p)
   for m in reversed(matches):data=data[:m.start()]+b'REDACTED_SIGNED_QUERY_VALUE'+data[m.end():]
   redactions.append(dict(private_original=str(p),original_sha256=h(raw),original_bytes=len(raw),public_member=member+'.redacted',public_sha256=h(data),public_bytes=len(data),ranges=[dict(start_byte=m.start(),end_byte_exclusive=m.end(),field='signature',redacted_value_sha256=h(m.group())) for m in matches]))
   member+='.redacted'
  info=tarfile.TarInfo(member);info.size=len(data);tar.addfile(info,io.BytesIO(data))
  inventory.append(dict(member=member,source=str(p),original_bytes=len(raw),original_sha256=h(raw),public_bytes=len(data),public_sha256=h(data),redacted=bool(matches)))
 assert len(redactions)==2
 dump(OUT/'PUBLIC_REDACTIONS.json',dict(reason='Credential query values in signed log-download errors. Original complete streams retained in cloud and not modified.',items=redactions))
 dump(OUT/'MEMBER_INVENTORY.json',dict(members=inventory))
 for name in ['PUBLIC_REDACTIONS.json','MEMBER_INVENTORY.json']:
  data=(OUT/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers()}
 assert len(members)==len(inventory)+2
 for x in inventory:assert h(tar.extractfile(members[x['member']]).read())==x['public_sha256']
 for name in ['PUBLIC_REDACTIONS.json','MEMBER_INVENTORY.json']:assert tar.extractfile(members[name]).read()==(OUT/name).read_bytes()
assert all(h(Path(x['source']).read_bytes())==x['original_sha256'] for x in inventory)
package=dict(exit_code=0,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=h(archive.read_bytes()),member_count=len(inventory)+2,classification_sha256=h((B/'CLASSIFICATION.json').read_bytes()),source_binding_sha256=h((B/'SOURCE_BINDING.json').read_bytes()),command_count=65,command_exit_counts={'0':63,'1':2},public_redaction_manifest_sha256=h((OUT/'PUBLIC_REDACTIONS.json').read_bytes()),public_redactions=2,full_unredacted_originals_retained_locally=True,all_other_public_bytes_match_originals=True,previous_local_package_not_rewritten='58ec41f13243eabc0bc02fe7594c087fbdd0d2beb1f06ba32e915c29168849ac')
dump(OUT/'PACKAGE.json',package);print(json.dumps(package))
