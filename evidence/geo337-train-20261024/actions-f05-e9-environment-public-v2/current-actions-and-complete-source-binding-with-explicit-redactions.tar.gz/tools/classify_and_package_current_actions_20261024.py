"""Classify original responses; publish signed log-query redactions with exact original hashes."""
from pathlib import Path
import hashlib,json,datetime,tarfile,io,re,shutil
B=Path('/workspace/pr338-pr339-current-actions-environment-20261024')
OUT=Path('/workspace/pr338-pr339-current-actions-publication-20261024')
def h(x):return hashlib.sha256(x).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
checks=[]
def ck(label,value):checks.append(dict(label=label,passed=bool(value)))
rows=j(B/'original-metadata/subcommands.json')+j(B/'policy-original-metadata/subcommands.json')
for row in rows:
 p=Path(row['directory']);ck('raw request/result '+str(p),j(p/'request.json')['command']==row['command'] and j(p/'result.json')==row)
 for stream in ['stdout','stderr']:
  data=(p/(stream+'.bin')).read_bytes();ck('complete raw '+str(p)+'/'+stream,len(data)==row[stream+'_bytes'] and h(data)==row[stream+'_sha256'])
 ck('stdin '+str(p),h((p/'stdin.bin').read_bytes())==row['stdin_sha256'])
expected={'native','browser (canvas)','browser (assembly)','browser (documents)','browser (grid)','browser (space)','browser (timber)'}
message="The job was not started because recent account payments have failed or your spending limit needs to be increased. Please check the 'Billing & plans' section in your settings"
reports=[]
for pr in [338,339]:
 x=j(B/f'PR{pr}_READ_RESULT.json');run=x['run'];jobs=x['jobs']
 ck(f'{pr} exact reviewed run and SHA',run['id']==x['run_id'] and run['head_sha']==x['expected_reviewed_head'])
 ck(f'{pr} completed failure',run['status']=='completed' and run['conclusion']=='failure')
 ck(f'{pr} exact seven jobs',len(jobs)==len(x['annotations'])==len(x['check_runs'])==7 and {q['name'] for q in jobs}==expected)
 details=[]
 for job in jobs:
  annotation=next(q for q in x['annotations'] if q['job_id']==job['id']);check=next(q for q in x['check_runs'] if q['job_id']==job['id'])
  failures=[a for a in annotation.get('response',[]) if a['annotation_level']=='failure']
  ck(f'{pr} job no runner steps {job["name"]}',job['head_sha']==run['head_sha'] and job['status']=='completed' and job['conclusion']=='failure' and job['runner_id']==0 and job['runner_name']=='' and job['steps']==[])
  ck(f'{pr} exact original annotation {job["name"]}',annotation['command']['actual_process_returncode']==0 and len(failures)==1 and failures[0]['message']==message)
  cr=check.get('response',{});ck(f'{pr} independent check-run binding {job["name"]}',check['command']['actual_process_returncode']==0 and cr['head_sha']==run['head_sha'] and cr['name']==job['name'] and cr['status']=='completed' and cr['conclusion']=='failure')
  details.append(dict(name=job['name'],job_id=job['id'],check_run_id=cr.get('id'),runner_id=job['runner_id'],runner_name=job['runner_name'],steps=job['steps'],conclusion=job['conclusion'],failure_annotation=failures[0],annotation_capture=annotation['command']['directory']))
 log=next(q['command'] for q in x['requests'] if q['label']=='logs')
 raw=(Path(log['directory'])/'stderr.bin').read_bytes()
 ck(f'{pr} original log read failure retained',log['actual_process_returncode']==1 and b'Forbidden' in raw)
 reports.append(dict(pr=pr,run_id=run['id'],run_url=run['html_url'],reviewed_head=run['head_sha'],ci_status=run['status'],ci_conclusion=run['conclusion'],jobs=details,log_retrieval=dict(exit=log['actual_process_returncode'],classification='Signed GitHub log-download endpoint returned Forbidden; this does not prove a log archive does not exist.',private_original_capture=log['directory'],original_stderr_sha256=log['stderr_sha256'],original_stderr_bytes=log['stderr_bytes']),classification='GitHub scheduling prevented job execution: account payment failure OR spending-limit restriction; API does not distinguish which.',actions_executed_product=False,product_pass_inferred=False,current_ci_blocker_resolved=False))
ck('53 original reads',len(rows)==53)
ck('only two log retrieval exits are nonzero',len([x for x in rows if x['actual_process_returncode']!=0])==2 and all(x['command'][-1]=='--log' for x in rows if x['actual_process_returncode']!=0))
decisions=(B/'PROCEDURE_SOURCE_decisions.txt').read_text().splitlines();handoff=(B/'PROCEDURE_SOURCE_handoff.txt').read_text().splitlines()
quotes=[]
for name,lines,start,end,scope in [('決策 B',decisions,57,58,'Adopted WSL replacement for billing-blocked CI; PR head plus original equal seven jobs.'),('列車 M',decisions,286,301,'Adopted merge-result train; documented per-change test selection, not arbitrary head equivalence.'),('計費決策',decisions,317,327,'Adopted instruction not to fix account billing; existing B/M replacement remains.'),('雲端試行',decisions,795,804,'Explicit repository cloud trial scope is #288; same parseable SHA and all gates retained.'),('交接規則',handoff,14,17,'Handoff states Linux equivalent seven jobs; no CI failure relabel or arbitrary head transfer.')]:
 source='handoff/HANDOFF.md' if name=='交接規則' else '決策佇列.md';sha='e3934fbdee70c4dbd226eb19137fb4a5ecf885d6' if name=='交接規則' else 'f05e7cfd373c9a77a366f7b2ddafd9401f261cf4'
 quotes.append(dict(name=name,source=source,source_sha=sha,start_line=start,end_line=end,verbatim='\n'.join(lines[start-1:end]),scope=scope))
report=dict(schema='current-reviewed-pr338-pr339-actions-environment/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),handoff_sha=(B/'handoff_sha.txt').read_text().strip(),source_context='Original API run heads remain f05/e9ee. Cloud runtime evidence L is separate and not relabeled by this metadata audit.',runs=reports,policy_quotes=quotes,policy_conclusion='Adopted B/M replacement exists; #288 cloud trial and handoff Linux instructions are recorded. Current session instructs continuing cloud train verification. This audit does not create a broader same-head equivalence rule or mark B3/B2 resolved; final same-source results and review acceptance remain necessary.',repository_search_limits='Captured handoff search plus main/train markdown searches excluding large evidence trees. Captured complete decisions, AGENTS, workflow, handoff and contextual docs. Historical drafts or product work-manager README are not promoted into new project authorization.',limits=['No billing/settings/API writes, rerun requests, workflow changes, branch-protection bypasses or product execution.','Branch protection requiredness was not queried; required-seven terminology comes from latest mirrored reviews.','Runner0/empty steps and explicit annotation establish no job execution; log Forbidden is separate read-access failure.','The historical provisional WSL3x timeout text is not applied to relax current original CI time limits.','Signed log URL credential values remain only in original local streams; public copies explicitly redact those values and retain exact original hashes, sizes and ranges.'],checks=checks,findings=[x['label'] for x in checks if not x['passed']])
report['exit_code']=int(bool(report['findings']));dump(B/'CLASSIFICATION.json',report)
summary='''# 新 head Actions 環境分類

#338 run 40043471807（f05e7cfd）與 #339 run 40040764499（e9ee6d08）各七 job 均 completed/failure、runner_id=0、runner_name 空、steps=[]。14 份原 annotation 都明示帳戶付款失敗 **或** 支出上限限制；無法由 API 區分兩者。這次是對新 run 逐項查證，未沿用舊 run 的結論。

兩次原 gh --log 均 exit 1，原因是簽章下載端點回 Forbidden；不能據此證明 log 不存在。原完整 stderr 留在雲端原 capture，公開包只精確遮蔽 signature query 的值，PUBLIC_REDACTIONS.json 保留原雜湊、長度、位元組範圍及公開副本雜湊；其餘原 API 流不改。此保密例外不冒稱公開流完全未遮蔽。

正式替代依據已找到：《決策佇列.md》57–58 的決策 B 採 WSL 等價七 job，286–301 的 M 改為進 main 的列車結果，317–327 指示不處理 Actions 計費。795–804 的雲端試行明限 #288，仍要求同可解析最終 SHA、七項及專項；handoff/HANDOFF.md:17 記載 Linux 等價七項。CLASSIFICATION.json 保存逐字引文、行號及來源 SHA。此處不自行擴張成任意 evidence head 可移標的規則，也不解除本輪 B3/B2；來源 L 的驗收結果仍須完整且接受複審。

共 53 個原始讀取命令：51 個 exit 0，兩個 log 下載 exit 1。沒有帳戶／workflow 設定變更、CI 重跑、API 寫入或產品測試執行。歷史 WSL 暫定 3× 時限僅作原文保留，不改本輪 CI 原時限。
'''
(B/'SUMMARY.md').write_text(summary)
assert report['exit_code']==0,report['findings']
OUT.mkdir();inventory=[];redactions=[];sources=[p for p in sorted(B.rglob('*')) if p.is_file()]+[Path('/workspace/read_current_338_339_actions_20261024.py'),Path('/workspace/read_actions_policy_sources_20261024.py'),Path(__file__)]
archive=OUT/'current-actions-originals-with-explicit-signed-query-redactions.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for p in sources:
  raw=p.read_bytes();data=raw;member='audit/'+str(p.relative_to(B)) if p.is_relative_to(B) else 'tools/'+p.name
  matches=list(re.finditer(rb'(?<=[?&]signature=)[^&\s"\x27]+',raw))
  if matches:
   assert p.name=='stderr.bin' and '/original-metadata/subcommands/' in str(p)
   for m in reversed(matches):data=data[:m.start()]+b'REDACTED_SIGNED_QUERY_VALUE'+data[m.end():]
   redactions.append(dict(private_original=str(p),original_sha256=h(raw),original_bytes=len(raw),public_member=member+'.redacted',public_sha256=h(data),public_bytes=len(data),ranges=[dict(start_byte=m.start(),end_byte_exclusive=m.end(),field='signature',redacted_value_sha256=h(m.group())) for m in matches]))
   member+='.redacted'
  info=tarfile.TarInfo(member);info.size=len(data);tar.addfile(info,io.BytesIO(data))
  inventory.append(dict(member=member,source=str(p),original_bytes=len(raw),original_sha256=h(raw),public_bytes=len(data),public_sha256=h(data),redacted=bool(matches)))
 assert len(redactions)==2
 redaction_doc=dict(reason='Credential query values in log-download errors; original full streams remain private in cloud.',originals_modified=False,items=redactions)
 dump(OUT/'PUBLIC_REDACTIONS.json',redaction_doc);data=(OUT/'PUBLIC_REDACTIONS.json').read_bytes();info=tarfile.TarInfo('PUBLIC_REDACTIONS.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 dump(OUT/'MEMBER_INVENTORY.json',dict(members=inventory));data=(OUT/'MEMBER_INVENTORY.json').read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers()}
 for x in inventory:assert h(tar.extractfile(members[x['member']]).read())==x['public_sha256']
 for n in ['PUBLIC_REDACTIONS.json','MEMBER_INVENTORY.json']:assert tar.extractfile(members[n]).read()==(OUT/n).read_bytes()
assert all(h(Path(x['source']).read_bytes())==x['original_sha256'] for x in inventory)
package=dict(exit_code=0,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=h(archive.read_bytes()),member_count=len(inventory)+2,classification_sha256=h((B/'CLASSIFICATION.json').read_bytes()),command_count=len(rows),command_exit_counts={'0':51,'1':2},checks=len(checks),findings=report['findings'],public_redaction_manifest_sha256=h((OUT/'PUBLIC_REDACTIONS.json').read_bytes()),public_redactions=2,full_unredacted_originals_retained_locally=True,all_other_public_bytes_match_originals=True)
dump(OUT/'PACKAGE.json',package);print(json.dumps(package))
