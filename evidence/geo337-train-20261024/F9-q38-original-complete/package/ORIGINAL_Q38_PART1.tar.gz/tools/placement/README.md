本稿只擴原 outer out 白名單：可用精確 `/dev/shm/geo337-F9-browsers-20261025/` 的新 child。原 WS/TMP 行為保留；root 本輪只應用 SHM 新 OUT。僅 root 在正式 require_escalated 命令中執行，未改 mount/quota/security。

原 Q38/cardref/axiom/required-eight/PF3 指令、time limits、registered counts、退出判定、finally 還原、before/after identity、F8→F9 ledger-only guard、c387/reaper/v5/locks 不變。REQUESTS.json 保原模板 bytes（其中 F9 null 是原未綁模板歷史），本輪實際參數須固定 F9 `4f8a794f4167c3562eb182045102e86e9e37cca9`，source 為獨立可寫 `/tmp/train337-323-f64d638f-source`，不能用任何 readonly browser pool/seed。

原 source 支援 Q38 disposable copy、cardref/axiom 暫改後完整復原；必須原heavy lock與root獨占nativeROOT lease，不能與native/ledger/browser consumer同時使用它。此稿不啟動任何 gate，亦不取鎖。

Q38 `--jobs 1`／SPM01–44 原樣；原 TMPDIR=gate/tmp，因此原 clone/compiler scratch 指向 SHM。cardref的53mutants/4model mutants保全量，baseline2＋每mutant兩bridge＋每model mutant兩model＝116份保留ELF。required-eight 原 binaries.py 在 POSIX 硬編碼 `/tmp/geometry-tests`，單改 OUT 不會移走，必須另查該共享 cache 的實際 free/consumer；不允許把它誤報全在SHM。v5不限制OUT於WS/TMP，無需再改v5。

使用式（未執行）：python3 -B /workspace/geo337-F9-nonperf-SHM-placement-preparation-20261025/run_original_specials.py --gate q38 --repo /tmp/train337-323-f64d638f-source --sha 4f8a794f4167c3562eb182045102e86e9e37cca9 --out /dev/shm/geo337-F9-browsers-20261025/nonperf-q38 --heavy-lock /tmp/g261r3/heavy.lock --preparation-sha256 <本稿PREPARATION精確hash>。其他gate各新OUT、同原裁判。不得把路由檢查當formal綠。

峰值只是靜態估算，見 RESOURCE_ESTIMATE.json；原TemporaryDirectory/finally本來會清自身temporary，這不是本稿額外刪原件。原正式logs/receipts保留；若要求中間ELF完整保留，須另討論收件層，不能假稱原judge原本就保所有temporaryELF。
