Q38 驗收方法已由固定 F9 Git blobs 與封存 wrapper 靜態建立；本次未讀活 ROOT／OUT、未讀 SHM、未執行或 import 產品，亦未接觸 heavy 鎖。這份方法不是實績判定，實際驗收由 root FINAL 原件另做。

原 CASES 的精確順序為 SPM01–SPM35、SPM41–SPM44、SPM36–SPM40，共39 native＋5 model。預期43 killed＋SPM24 equivalent；SPM24仍須正常編譯、binary不同baseline及child exit0。SPM38／SPM40允許具名 ModelError；不得把原ERROR改標FAIL。JSON逐項保留44個ID、clause、具名方法與完整cause條件。

先驗 model-base-build 真0與fresh adapter，再驗無only/group/explore的完整Q38、jobs1。native baseline為29方法，model為20；各自完整exception receipt、0 skips與exit0。每個kill須由同一具名terminal exception的完整message含所有cause判斷，不能拼接stdout或依first_failure截短欄位。

Q38不做axiom式逐case restored重跑：所有變更在可拋棄副本，組後原裁判核shared base/model digest不變；外wrapper再核來源before/after的HEAD、tree、status、index、refs及F8→F9 closure相等。保留所有原compiler/test log及exception JSON；原TemporaryDirectory的ELF刪除不代表收據缺失。

外層c387保存分離原stdout/stderr bytes；內層原裁判保存stdout+stderr合併文字log與完整exception JSON，不能冒稱內層是分離binary streams。native compile原-O2/600秒；subject與mutant adapter build原900秒；outer timeout=None。本方法不改任何門檻。
