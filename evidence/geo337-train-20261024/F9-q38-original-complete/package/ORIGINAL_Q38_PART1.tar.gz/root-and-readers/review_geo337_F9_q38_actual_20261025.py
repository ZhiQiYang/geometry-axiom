"""Independent read-only terminal inspection of already completed F9 Q38; no subject runs."""
from pathlib import Path
import ast,collections,hashlib,json,os,re,stat,subprocess,time
F='4f8a794f4167c3562eb182045102e86e9e37cca9'
ROOT=Path('/dev/shm/geo337-F9-browsers-20261025/nonperf-q38-20261025')
OUT=Path('/workspace/geo337-F9-q38-actual-peer-20261025')
PREP=Path('/workspace/geo337-F9-nonperf-SHM-placement-preparation-20261025')
HOST=Path('/workspace/geo337-F9-q38-original-EXEC_FINAL-20261025.json')
checks=[]
def check(ok,label):
 checks.append(label)
 if not ok:raise RuntimeError(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def J(p):return json.loads(p.read_bytes())
def binding(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def pure_cases(raw):
 tree=ast.parse(raw);nodes=[]
 for n in tree.body:
  if isinstance(n,ast.Assign) and all(isinstance(t,ast.Name) for t in n.targets):
   if any(t.id=='CASES' for t in n.targets):nodes.append(n)
   else:
    try:ast.literal_eval(n.value)
    except (ValueError,TypeError):continue
    nodes.append(n)
  elif isinstance(n,ast.FunctionDef) and n.name=='case':nodes.append(n)
 scope={'__builtins__':{'list':list}}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<fixed-F9-pure-case-data>','exec'),scope)
 return scope

def evidence_check(code,e,label):
 fields={'schema','requested','executed','passed','tests_run','failures','errors','skipped','expected_failures','unexpected_successes','events'}
 check(type(e) is dict and set(e)==fields and e['schema']=='section-profile-exceptions/1',label+' exact exception schema')
 for k in ['requested','executed','passed']:
  check(type(e[k]) is list and all(type(x)is str and x for x in e[k]) and len(e[k])==len(set(e[k])),label+' '+k+' unique identities')
 check(e['requested']==e['executed'] and bool(e['requested']),label+' requested executed complete')
 for k in ['tests_run','failures','errors','skipped','expected_failures','unexpected_successes']:
  check(type(e[k]) is int and e[k]>=0,label+' '+k+' count')
 check(e['tests_run']==len(e['executed']) and e['skipped']==e['expected_failures']==e['unexpected_successes']==0,label+' count/no skip')
 seen=set()
 for event in e['events']:
  check(set(event)=={'test_id','subtest_id','kind','exception_type','message'} and event['test_id'] in e['executed'],label+' event exact fields and owner')
  check(event['subtest_id'] is None or (type(event['subtest_id'])is str and event['subtest_id'].startswith(event['test_id']+' ')),label+' subtest ownership')
  key=(event['test_id'],event['subtest_id']);check(key not in seen,label+' unique terminal event');seen.add(key)
  check(event['kind'] in ['failure','error'] and type(event['message'])is str and type(event['exception_type'])is str and re.fullmatch(r'[\w]+(?:\.[\w]+)+',event['exception_type']) is not None,label+' event type/message')
 check(e['failures']==sum(x['kind']=='failure' for x in e['events']) and e['errors']==sum(x['kind']=='error' for x in e['events']),label+' events equal counts')
 check(set(e['passed'])==set(e['executed'])-{x['test_id'] for x in e['events']},label+' passed set exact')
 check(type(code)is int and code==(1 if e['events'] else 0),label+' exit matches actual events')

def main():
 check(not OUT.exists(),'fresh WS review output')
 prep=J(PREP/'PREPARATION.json');check(digest(PREP/'PREPARATION.json')=='3f317ca29a9f475502f1971d020ed1f202a176d44f037801b89171ac9a850c5a','original placement preparation pin')
 check(digest(PREP/'run_original_specials.py')=='45c78d779e5db243c10a10990929eb24280380dbc57c94dc9ba94c67d242479d','original wrapper pin')
 raw=subprocess.check_output(['git','show',F+':tests/section_profile_mutation_check.py'],cwd='/workspace/geometry-axiom')
 check(sha(raw)==prep['original_judges_sha256']['tests/section_profile_mutation_check.py']=='313545d9ecc4be29da244791a70d96098b1dea90c74f0c1bca0b4ebc65d0528b','immutable F9 original Q38 judge')
 scope=pure_cases(raw);cases=scope['CASES'];ids=[c['id'] for c in cases]
 check(ids==['SPM%02d'%i for i in list(range(1,36))+list(range(41,45))+list(range(36,41))],'exact44 original ordered cases')
 receipt=J(ROOT/'receipt.json');gate=receipt['gates'][0]
 check(receipt['source_sha']==F and receipt['launcher_exit_code']==0 and receipt['passed'] is True and receipt['errors']==[],'original wrapper actual0/F9')
 check(receipt['original_judges_counts_limits_changed'] is False and receipt['outer_timeout'] is None,'original limits unchanged')
 check(receipt['stack_during'][0]==16777216 and receipt['environment']['PYTHONOPTIMIZE'] is None,'original16MiB stack/no optimize')
 check(len(receipt['gates'])==1 and gate['gate']=='q38' and gate['passed'] is True and gate['errors']==[] and gate['original_q38_case_ids']==ids,'one complete original Q38 gate')
 check([c['name'] for c in gate['commands']]==['model-base-build','q38'],'build prerequisite before subject')
 commands=J(ROOT/'subcommands.json');check(commands==receipt['commands'] and len(commands)==31,'all31 original c387 commands')
 for row in commands:
  d=Path(row['directory']);check(d.parent==ROOT/'subcommands','original command directory fixed')
  request=J(d/'request.json');terminal=J(d/'result.json');check(terminal==row,'original result row exact')
  for key in ['command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','stdin_provided','stdin_sha256','directory']:
   check(request[key]==row[key],'request/result '+d.name+' '+key)
  check(row['source_sha']==row['acceptance_sha']==F and row['actual_process_returncode']==0 and row['timeout_expired'] is False,'original process0/no timeout '+d.name)
  check(sha((d/'stdin.bin').read_bytes())==row['stdin_sha256'],'full stdin '+d.name)
  for stream in ['stdout','stderr']:
   p=d/(stream+'.bin');check(p.stat().st_size==row[stream+'_bytes'] and digest(p)==row[stream+'_sha256'],'full '+stream+' '+d.name)
 for item in gate['commands']:
  check(item['primary_command_exit']==item['outer_process_exit']==0 and item['capture'] in commands,'primary/outer0 '+item['name'])
  events=[json.loads(line) for line in Path(item['reaper_log']).read_text().splitlines()];check(digest(Path(item['reaper_log']))==item['reaper_sha256'],'original reaper hash '+item['name'])
  ends=[e for e in events if e.get('event')=='完成'];check(len(ends)==1 and events[-1]==ends[0] and ends[0]['primary_returncode']==0,'unique original terminal reaper '+item['name'])
  check(item['capture']['command'][1:3]==['-B','/workspace/geo261-environment/reap_children.py'] and item['capture']['command'][3:]==item['original_argv'],'exact wrapper preserves original argv '+item['name'])
 subject=gate['commands'][1];argv=subject['original_argv'];logs=ROOT/'q38/q38/logs';qpath=ROOT/'q38/q38/receipt.json';q=J(qpath)
 check(argv[1:]==['-B','-u','tests/section_profile_mutation_check.py','--receipt',str(qpath),'--logs',str(logs),'--jobs','1'],'exact original complete Q38 argv no selection/explore')
 check(subject['environment_explicit']['GEOMETRY_MODEL_BASE']==str(ROOT/'q38/q38-bin/model-base'),'fresh model adapter path')
 before=ROOT/'q38/before-source.json';after=ROOT/'q38/after-source.json';check(before.read_bytes()==after.read_bytes(),'original complete before/after source bytes exactly restored')
 source=J(before);check(source['head']==F and source['status']=='','original clean F9 source snapshot')
 check(q['schema']=='section-profile-mutations/2' and [x['id'] for x in q['results']]==ids,'Q38 receipt exact44 ordered rows')
 check(q['summary']=={'killed':43,'equivalent':1},'original43 killed+SPM24 equivalent summary')
 for group,count in [('native',29),('model',20)]:
  b=q['baselines'][group];evidence_check(b['exit'],b['exception_evidence'],group+' baseline');check(b['exit']==0 and b['exception_evidence']['tests_run']==count,group+' full zero-skip baseline')
  check(J(logs/(group+'-baseline.exceptions.json'))==b['exception_evidence'],group+' raw exception receipt exact')
 check(digest(ROOT/'q38/q38-bin/model-base')==q['baselines']['model']['adapter_sha256'],'retained fresh baseline adapter bytes')
 outcomes=[]
 for c,row in zip(cases,q['results']):
  name=c['id'];e=row['exception_evidence'];evidence_check(row['exit'],e,name)
  check(row['group']==c['group'] and row['clause']==c['clause'] and row['desc']==c['desc'],name+' exact original case metadata')
  module=scope['NATIVE_MODULE'] if c['group']=='native' else scope['MODEL_MODULE'];cls=scope['NATIVE_CLASS'] if c['group']=='native' else scope['MODEL_CLASS'];named=[module+'.'+cls+'.'+t for t in c['tests']]
  check(e['requested']==named,name+' exactly named case methods')
  check(J(logs/(name+'.exceptions.json'))==e,name+' complete original exception sidecar')
  log=logs/(name+'.log');check(log.is_file() and log.stat().st_size>0,name+' full original combined log present')
  if c['equivalent']:
   check(name=='SPM24' and row['exit']==0 and row['verdict']=='equivalent' and not e['events'],name+' declared original equivalent actually ran0')
  else:
   detected=[v for v in e['events'] if (v['kind']=='failure' and v['exception_type']=='builtins.AssertionError') or (v['kind']=='error' and v['exception_type'] in c['error_types'])]
   caused=[v for v in detected if v['test_id'] in named and all(text in v['message'] for text in c['cause'])]
   check(row['exit']==1 and row['verdict']=='killed' and bool(caused),name+' same full named terminal message all original cause tokens')
  if c['group']=='native':
   compile=J(logs/('bridge-'+name+'.compile.json'));check(compile['exit']==0 and compile['binary_sha256']==row['binary_sha256']!=q['baselines']['native']['binary_sha256'],name+' fresh changed native binary original compile0')
   check(compile['argv'][:3]==['cc','-std=c11','-O2'] and compile['argv'][-3:-1]==['-lm','-o'],name+' original native compiler argv')
  if name in ['SPM36','SPM39']:
   compile=J(logs/(name+'.model-base.compile.json'));check(compile['exit']==0 and compile['binary_sha256']==row['adapter_sha256']!=q['baselines']['model']['adapter_sha256'],name+' mutated adapter original build0/hash changed')
  outcomes.append({'id':name,'group':c['group'],'exit':row['exit'],'verdict':row['verdict'],'requested':e['requested'],'failures':e['failures'],'errors':e['errors'],'error_types':[x['exception_type'] for x in e['events'] if x['kind']=='error'],'log_sha256':digest(log),'exception_sidecar_sha256':digest(logs/(name+'.exceptions.json'))})
 compile=J(logs/'bridge-baseline.compile.json');check(compile['exit']==0 and compile['binary_sha256']==q['baselines']['native']['binary_sha256'],'baseline native compile0/hash')
 check(len(list(logs.glob('*.compile.json')))==42,'original40 native+2 adapter compile records')
 subjstdout=Path(subject['capture']['directory'])/'stdout.bin';printed=[];printed_summary=[]
 for line in subjstdout.read_text().splitlines():
  try:v=json.loads(line)
  except ValueError:continue
  if isinstance(v,dict) and 'id'in v:printed.append(v)
  if isinstance(v,dict) and set(v)=={'summary'}:printed_summary.append(v['summary'])
 check(printed==q['results'] and printed_summary==[q['summary']],'outer raw stdout complete44 records/summary equal receipt')
 check(b'PROBLEM:' not in subjstdout.read_bytes(),'original source-copy stability checks produced no PROBLEM')
 host=J(HOST);check(host['session_id']==66508 and host['status']=='FINISHED' and host['actual_tool_result']['exit_code']==0,'true completed host session66508/0')
 message=json.loads(host['actual_tool_result']['output']);check(message['source_sha']==F and message['launcher_exit_code']==0 and message['gates']==[{'gate':'q38','passed':True}] and message['receipt']==str(ROOT/'receipt.json'),'true host exact original gate receipt')
 inventory=[]
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():
   check(stat.S_ISREG(p.lstat().st_mode),'original leaf regular '+p.relative_to(ROOT).as_posix());inventory.append(binding(p))
 OUT.mkdir();report={'schema':'geo337-F9-Q38-original-actual-peer/1','exit_code':0,'checks':len(checks),'blocking_findings':[],'source_sha':F,'formal_gate_exit':0,'host_session':66508,'original_case_count':44,'native_case_count':39,'model_case_count':5,'killed':43,'equivalent':['SPM24'],'baseline_tests':{'native':29,'model':20},'allowed_model_errors':['SPM38','SPM40'],'outer_c387_commands':len(commands),'source_restored_exact':True,'source_before_after_sha256':digest(before),'bindings':[binding(ROOT/'receipt.json'),binding(qpath),binding(HOST),binding(PREP/'run_original_specials.py'),binding(PREP/'PREPARATION.json')],'outcomes':outcomes,'original_regular_files':len(inventory),'original_regular_bytes':sum(x['bytes'] for x in inventory),'original_allocated_bytes':sum(Path(x['path']).stat().st_blocks*512 for x in inventory),'limits':['No product rerun or read of active checkout; original terminal bytes only.','Q38 uses disposable copies; source restoration is shared-copy stability plus exact outer before/after, not per-mutant restored-control reruns.','Inner logs are original complete text stdout+stderr concatenations, not separated raw byte streams. Outer31 c387 commands retain separate full raw streams.','Original inner child exception-receipt tempfile argv is not retained; only original runner source plus named method receipt defines it. No reconstructed argv presented as original raw.','Temporary native/mutant adapter ELF and copied source trees were removed by original TemporaryDirectory/finally. Only original compile hash records survive for these; retained baseline model-base rehashed.','SPM24 is declared equivalent, not a skip. SPM38/SPM40 retain original named ModelError ERROR, not relabeled AssertionError.'],'subject_rerun':False,'published':False,'reviewed_epoch':time.time(),'checker_sha256':digest(Path(__file__))}
 (OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(OUT/'ORIGINAL_INVENTORY.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n');(OUT/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'exit_code':0,'checks':len(checks),'report':str(OUT/'REVIEW.json'),'sha256':digest(OUT/'REVIEW.json'),'raw_files':len(inventory),'raw_bytes':report['original_regular_bytes']}))
if __name__=='__main__':main()
