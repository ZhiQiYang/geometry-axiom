from pathlib import Path
import hashlib,importlib.util,json,os,sys
OWN=Path('/dev/shm/geo337-F9-browsers-20261025');OTHER=Path('/dev/shm/geometry-axiom-geo337-20261025')
PREP=Path('/workspace/geo337-F9-nonperf-SHM-placement-preparation-20261025');TOOL=PREP/'run_original_specials.py'
PEER=Path('/workspace/geo337-F9-nonperf-SHM-placement-static-peer-20261025/REVIEW.json')
SAMPLER=Path('/workspace/geo337-F9-browser-sampler-preparation-20261025/sample_original_browser_v2.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(TOOL)=='45c78d779e5db243c10a10990929eb24280380dbc57c94dc9ba94c67d242479d'
assert sha(PREP/'PREPARATION.json')=='3f317ca29a9f475502f1971d020ed1f202a176d44f037801b89171ac9a850c5a'
assert sha(PEER)=='505abceeddf75b56360ad42d4a7be2de220a468b67653c36204b4fb9de31080d'
assert sha(SAMPLER)=='919eafb54f20454ee44a27754ce04f6f63f05f6e1c9b32a5b51652058735af30'
prior=json.loads((OTHER/'geo314-counterproof-v3-20261025/RESULT.json').read_bytes())
assert prior['exit_code']==0 and not prior['restoration_errors'] and prior['before']==prior['after']
spec=importlib.util.spec_from_file_location('shared_metadata_inventory',SAMPLER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
inv=m.inventory([OWN,OTHER]);increment=335544320;assert inv['unique_allocated_bytes']+increment<=2147483648
out=OWN/'nonperf-q38-20261025';assert not out.exists()
q=dict(source_sha='4f8a794f4167c3562eb182045102e86e9e37cca9',gate='q38',root_source_exclusive=True,shared_allocated_before=inv['unique_allocated_bytes'],incremental_planning_bytes=increment,shared_planning_ceiling_bytes=2147483648,estimate_not_measured_peak=True,subject_tool_sha256=sha(TOOL),peer_sha256=sha(PEER),previous_counterproof_restore_exit=0)
request=OTHER/'q38-root-admission-20261025.json'
with request.open('x')as f:f.write(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(q),flush=True)
os.execv(sys.executable,[sys.executable,'-B',str(TOOL),'--repo','/tmp/train337-323-f64d638f-source','--sha',q['source_sha'],'--out',str(out),'--heavy-lock','/tmp/g261r3/heavy.lock','--preparation-sha256','3f317ca29a9f475502f1971d020ed1f202a176d44f037801b89171ac9a850c5a','--gate','q38'])
