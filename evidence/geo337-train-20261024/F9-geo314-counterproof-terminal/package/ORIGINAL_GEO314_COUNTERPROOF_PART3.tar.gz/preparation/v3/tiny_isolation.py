import ast, hashlib, json, os, subprocess, sys, time
from pathlib import Path
TOOL=Path(__file__).parent/'run_counterproof_v3.py'
MODE=sys.argv[1]; OUT=Path(sys.argv[2]);OUT.mkdir()
ROOT=OUT/'tiny-root';ROOT.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_OPTIONAL_LOCKS='1')
rows=[]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def meta(p):
 s=p.stat();return dict(dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns)
def run(args,expected=0):
 start=time.time_ns();r=subprocess.run(args,cwd=ROOT,env=env,capture_output=True)
 row=dict(argv=args,started_ns=start,ended_ns=time.time_ns(),exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),git_env={k:v for k,v in env.items() if k.startswith('GIT_')});rows.append(row)
 (OUT/'COMMANDS.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==expected,'tiny original Git command failed'
 return r.stdout
run(['git','init','-q']);run(['git','config','user.name','Tiny isolated fixture']);run(['git','config','user.email','tiny@example.invalid'])
f=ROOT/'K.c';f.write_bytes(b'original\n');run(['git','add','--','K.c']);run(['git','commit','-qm','Create private-index isolation fixture'])
gd=ROOT/'.git';real=gd/'index';ib=real.read_bytes();before=dict(sha256=h(real),meta=meta(real));objects=gd/'objects'
for name in ['ORIGINAL_INDEX.bin','phase-index']:
 p=OUT/name
 with p.open('xb') as stream:stream.write(ib);stream.flush();os.fsync(stream.fileno())
 assert p.read_bytes()==ib and p.stat().st_ino!=real.stat().st_ino
pobj=OUT/'private-objects';pobj.mkdir()
# Evaluate the exact reviewed env.update AST, not a hand-written equivalent.
tree=ast.parse(TOOL.read_text());updates=[n for n in ast.walk(tree) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='env' and n.value.func.attr=='update' and any(x.arg=='GIT_INDEX_FILE' for x in n.value.keywords)]
assert len(updates)==1
exec(compile(ast.fix_missing_locations(ast.Module(body=updates,type_ignores=[])),'exact-private-env','exec'),globals())
if MODE=='withdrawn':del env['GIT_INDEX_FILE']
assert run(['git','config','--get','core.splitIndex'])==b'false\n'
f.write_bytes(b'modified\n');run(['git','diff','--name-only','HEAD','--','K.c']);f.write_bytes(b'original\n')
# Force a stat-cache mismatch, without a timed sleep or changing content.
s=f.stat();os.utime(f,ns=(s.st_atime_ns,s.st_mtime_ns+2_000_000_000))
run(['git','diff','--name-only','HEAD','--','K.c'])
after=dict(sha256=h(real),meta=meta(real));private_after=h(OUT/'phase-index')
result=dict(mode=MODE,tool_sha256=h(TOOL),before=before,after=after,private_sha256=private_after,initial_sha256=hashlib.sha256(ib).hexdigest(),pressure='GIT_OPTIONAL_LOCKS=1 intentionally forces Git stat refresh; not a historical root-cause reproduction',actual_git_environment={k:v for k,v in env.items() if k.startswith('GIT_')},real_index_unchanged=before==after)
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
assert before==after,'real-index-isolation invariant: Git refresh escaped private index'
assert private_after!=before['sha256'],'tiny refresh pressure did not actually rewrite private index'
print(json.dumps(result))
