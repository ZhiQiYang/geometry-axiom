# #314 全階段 private index 外稿

尚未執行正式反證、尚未碰 NATIVE/index 或開分支。來源仍是 F9；原 v2 11+4 negative 行為達預期，但 outer exit 1 的 real index 守門失敗完整保留。

歷史 writer 未完全確立。原最後 index mtime 落在 restored-existing-K-1，早於 staged add；三個 ordinary/full-sparse/escalated-sparse tiny 在 optional-locks=0 未重現。不可宣稱此次工具改動證明了歷史原因，也不可回寫或猜 stat 來修 real index。

此版在第一個 Git subprocess 前，以 O_EXCL+fsync 保存完整原 index，另做 phase-index；所有 Git（含 nested tests）繼承 exact-copy private index/private objects 與 readonly original objects alternate。staged case 再用另一份 exact original index。環境強制 private core.splitIndex=false；原 full DIRC/link guard、sharedindex guard、signals/fault recovery、source/hash/inode guards、1200s 與 64MiB 全保留。每個原 command 後都檢 real index bytes/inode/mode/mtime/atime unchanged，並附明確 GIT_ENVIRONMENT.json。新預算計入三份完整 index。只把 OUT 改到既有 OWN 的 v3 子目錄，待 root fresh capacity/獨占租約。

Tiny 原 0/1/0 只證明隔離有效：故意 GIT_OPTIONAL_LOCKS=1 並改 timestamp 觸發 Git stat refresh；固定版讓 private index 真改且 real unchanged，撤回 GIT_INDEX_FILE 會改 real 並具名 Assertion1，恢復又0。沒有假裝這是歷史 rootcause 重現。

原 formal full11/既有與新增四 K 違規流程及 precise assertion 不變。v3 尚未 formal-run；新版 request 四租約仍 false，peer 未綁。舊函式 helper AST 全等，test 函式唯一差異是收據把 inherited private index 路徑寫出。
