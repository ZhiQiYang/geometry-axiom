ORIGINAL tiny kernel bytes
