/* GEO314 isolated new K source negative */
