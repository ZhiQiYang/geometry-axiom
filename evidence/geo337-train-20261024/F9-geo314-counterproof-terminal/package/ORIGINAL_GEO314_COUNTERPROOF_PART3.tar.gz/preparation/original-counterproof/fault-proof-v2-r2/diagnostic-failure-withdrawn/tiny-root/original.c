PARTIAL tiny variant
