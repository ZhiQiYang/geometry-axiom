"""Small isolated recovery proofs; imports tools but never runs their main()."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,signal,subprocess,sys,traceback
D=Path(__file__).parent
V1=D/'run_counterproof.py';V2=D/'run_counterproof_v2.py'
PROOF=D/'fault-proof-v2-r2'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def H(b):return hashlib.sha256(b).hexdigest()
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def need(v,msg):
 if not v:raise AssertionError(msg)
def v1_function(m,name,nodes):
 fn=ast.FunctionDef(name=name,args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=copy.deepcopy(nodes),decorator_list=[])
 tree=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));exec(compile(tree,str(V1)+'::exact_AST_'+name,'exec'),m.__dict__);return getattr(m,name)
def v1_nodes():
 t=ast.parse(V1.read_bytes());main=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='main');tr=next(x for x in main.body if isinstance(x,ast.Try));loops=[x for x in tr.finalbody if isinstance(x,ast.For)]
 newloop=next(x for x in tr.body if isinstance(x,ast.For) and 'NEWFILES' in ast.unparse(x.iter) and any(isinstance(n,ast.With) for n in x.body))
 ns=[]
 for n in newloop.body:
  ns.append(n)
  if isinstance(n,ast.Assign) and any(isinstance(a,ast.Subscript) and isinstance(a.value,ast.Name) and a.value.id=='created' for a in n.targets):break
 return ns,loops[0],loops[1]
class FaultFile:
 def __init__(self,f,stage):self.f=f;self.stage=stage
 def __enter__(self):self.f.__enter__();return self
 def __exit__(self,*a):return self.f.__exit__(*a)
 def __getattr__(self,k):return getattr(self.f,k)
 def write(self,b):
  if self.stage=='write':self.f.write(b[:3]);self.f.flush();raise OSError(28,'injected partial write')
  return self.f.write(b)
 def flush(self):
  self.f.flush()
  if self.stage=='flush':raise OSError(28,'injected flush')

def child(case,version,d):
 d.mkdir();root=d/'tiny-root';root.mkdir();out=d/'output';out.mkdir();m=load(V1 if version=='withdrawn' else V2,'subject')
 m.ROOT=root;m.OUT=out;detail={'case':case,'version':version,'fixture':str(root),'formal_test_run':False,'actual_source_read':False}
 origcreate,origrecovernew,origrecoversaved=v1_nodes()
 try:
  if case.startswith('probe-'):
   stage=case.split('-',1)[1];rel='probe.c';payload=b'/* GEO314 isolated new K source negative */\n';created={};result={'restoration_errors':[]};m.rel=rel;m.created=created;m.result=result
   originalopen=Path.open;originalfd=m.os.fdopen;originalsync=m.os.fsync
   def wrappedopen(p,*a,**kw):
    f=originalopen(p,*a,**kw);return FaultFile(f,stage) if p==root/rel and a and a[0]=='xb' else f
   def wrappedfd(fd,*a,**kw):return FaultFile(originalfd(fd,*a,**kw),stage)
   def failfsync(fd):raise OSError(28,'injected fsync')
   Path.open=wrappedopen;m.os.fdopen=wrappedfd
   if stage=='fsync':m.os.fsync=failfsync
   try:
    if version=='withdrawn':v1_function(m,'v1_create_exact',origcreate)()
    else:m.create_probe(root,rel,payload,created)
    raise AssertionError('fault injection did not fire')
   except OSError as e:detail['injected_error']=repr(e)
   finally:Path.open=originalopen;m.os.fdopen=originalfd;m.os.fsync=originalsync
   detail['registered_before_recovery']=list(created);detail['partial_bytes_hex']=(root/rel).read_bytes().hex();diag=[]
   if version=='withdrawn':v1_function(m,'v1_recover_new_exact',[origrecovernew])()
   else:m.recover_created(root,out,created,diag,result['restoration_errors'])
   detail['restoration_errors']=result['restoration_errors'];detail['diagnostic_errors']=diag;detail['probe_absent']=not (root/rel).exists()
   need(detail['probe_absent'] and not result['restoration_errors'],'RECOVERY-NEW-PROBE: fault left own registered probe')
  elif case in ('diagnostic-failure','signal-term','signal-int'):
   rel='original.c';p=root/rel;p.write_bytes(b'ORIGINAL tiny kernel bytes\n');raw,meta=m.read_owned(p);partial=b'PARTIAL tiny variant\n';m.write_exact(p,raw,partial,(meta['dev'],meta['inode']))
   saved={rel:(raw,meta)};expected={rel:partial};inflight={rel} if case=='diagnostic-failure' else set();diag=[];errors=[];m.saved=saved;m.expected=expected;m.inflight=inflight;m.result={'restoration_errors':errors}
   originalopen=Path.open;originalwb=Path.write_bytes;originalwrite=m.write_exact;signals=None;previous={}
   def failopen(p,*a,**kw):
    if p.name.startswith('PARTIAL_'):raise OSError(28,'injected diagnostic ENOSPC')
    return originalopen(p,*a,**kw)
   def failwb(p,data):
    if p.name.startswith('PARTIAL_'):raise OSError(28,'injected diagnostic ENOSPC')
    return originalwb(p,data)
   def throwing(signum,frame):raise RuntimeError('received signal '+str(signum)+'; restoring exact temporary changes')
   signum=signal.SIGTERM if case=='signal-term' else signal.SIGINT
   if case=='diagnostic-failure':Path.open=failopen;Path.write_bytes=failwb
   else:
    if version=='withdrawn':
     for s in (signal.SIGINT,signal.SIGTERM):previous[s]=signal.signal(s,throwing)
    else:signals=m.DeferredSignals();signals.install()
    def interrupted_write(path,expected,replacement,inode):
     originalwrite(path,expected,b'INFLIGHT',inode)
     os.kill(os.getpid(),signum)
     originalwrite(path,b'INFLIGHT',replacement,inode)
    m.write_exact=interrupted_write
   try:
    if version=='withdrawn':v1_function(m,'v1_recover_saved_exact',[origrecoversaved])()
    else:m.recover_saved(root,out,saved,expected,inflight,diag,errors)
   finally:
    Path.open=originalopen;Path.write_bytes=originalwb;m.write_exact=originalwrite
    if signals:detail['signals_received']=list(signals.received);signals.close()
    for sig,handler in previous.items():signal.signal(sig,handler)
   after,mm=m.read_owned(p);detail.update(restored_exact=after==raw and mm==meta,restoration_errors=errors,diagnostic_errors=diag,after_hex=after.hex())
   need(detail['restored_exact'] and not errors,('RECOVERY-PARTIAL-DIAGNOSTIC' if case=='diagnostic-failure' else 'RECOVERY-INTERRUPT')+': original source was not restored')
   if case=='diagnostic-failure':need(len(diag)==1,'diagnostic ENOSPC must stay visible')
   else:need(detail['signals_received']==[signum],'real OS signal was not deferred and recorded')
  elif case in ('split-source','private-stage'):
   env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_OPTIONAL_LOCKS='0')
   cap=load(CAP,'capture');rec=cap.Recorder(d/'git-commands',env,'SYNTHETIC-NO-PRODUCT-SHA')
   def git(args,extra=None):
    old=rec.env;rec.env={**env,**(extra or {})}
    try:r,so,se=rec.run(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=root,check=False,timeout=30,source_variant='tiny Git recovery fixture')
    finally:rec.env=old
    need(r['actual_process_returncode']==0 and not r['timeout_expired'],'tiny Git command failed: '+repr(args));return so
   git(['init','--quiet']);(root/'tracked.c').write_bytes(b'tiny original\n');git(['-c','core.splitIndex=false','add','--','tracked.c']);git(['-c','user.name=Tiny Proof','-c','user.email=tiny@example.invalid','commit','--quiet','-m','Create tiny proof fixture'])
   if case=='split-source':
    git(['update-index','--split-index']);index=root/'.git/index';before=index.read_bytes();shared=git(['rev-parse','--shared-index-path']);need(shared.strip(),'fixture must contain actual split index')
    blocked=False
    try:
     if version!='withdrawn':m.require_full_index(shared)
    except AssertionError as e:blocked=True;detail['guard_assertion']=str(e)
    detail.update(split_path=shared.decode().strip(),blocked=blocked,index_unchanged=index.read_bytes()==before)
    need(blocked and detail['index_unchanged'],'PRIVATE-INDEX-CONDITIONAL: split original was not rejected read-only')
   else:
    # The real original index is full while config requests auto split on a future add.
    git(['config','core.splitIndex','true']);original_index=(root/'.git/index').read_bytes();need(git(['rev-parse','--shared-index-path'])==b'','original fixture must be full')
    before={p.name:H(p.read_bytes()) for p in (root/'.git').glob('sharedindex.*')};private=d/'private-index';private.write_bytes(original_index);objects=d/'private-objects';objects.mkdir();(root/'new.c').write_bytes(b'tiny new source\n')
    extra={'GIT_INDEX_FILE':str(private),'GIT_OBJECT_DIRECTORY':str(objects),'GIT_ALTERNATE_OBJECT_DIRECTORIES':str(root/'.git/objects')}
    git(['add','--','new.c'] if version=='withdrawn' else m.private_stage_arguments('new.c'),extra)
    shared=git(['rev-parse','--shared-index-path'],extra);after={p.name:H(p.read_bytes()) for p in (root/'.git').glob('sharedindex.*')}
    detail.update(private_shared_index=shared.decode().strip(),real_index_unchanged=(root/'.git/index').read_bytes()==original_index,original_shared_before=before,original_shared_after=after,new_index_cached=git(['diff','--cached','--name-only','HEAD'],extra).decode())
    need(not shared.strip() and before==after and detail['real_index_unchanged'],'PRIVATE-INDEX-CONDITIONAL: private staging created split/shared index')
    need(detail['new_index_cached']=='new.c\n','private index staging evidence absent')
  elif case=='unknown-inode':
   rel='probe.c';payload=b'tiny\n';created={};m.create_probe(root,rel,payload,created);(root/rel).rename(root/'preserved-owned-probe.c');(root/rel).write_bytes(b'foreign replacement\n');before=(root/rel).read_bytes();errors=[];diag=[];m.recover_created(root,out,created,diag,errors)
   need(errors and (root/rel).read_bytes()==before and (root/'preserved-owned-probe.c').read_bytes()==payload,'unknown inode must be preserved and rejected');detail.update(rejected=True,errors=errors)
  else:raise AssertionError('unknown case')
  detail['exit_code']=0
 except BaseException:detail['exit_code']=1;detail['error']=traceback.format_exc()
 dump(d/'RESULT.json',detail);print(json.dumps(detail,ensure_ascii=False));return detail['exit_code']

def orchestrate():
 need(not PROOF.exists(),'fresh proof dir');PROOF.mkdir();cap=load(CAP,'capture');env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'};rec=cap.Recorder(PROOF/'commands',env,'SYNTHETIC-NO-PRODUCT-SHA');rows=[]
 for case in ['probe-write','probe-flush','probe-fsync','diagnostic-failure','signal-term','signal-int','split-source','private-stage']:
  for variant,expect in [('fixed',0),('withdrawn',1),('restored',0)]:
   r,so,se=rec.run([sys.executable,'-B',str(Path(__file__)),case,variant,str(PROOF/(case+'-'+variant))],cwd=D,timeout=60,check=False,source_variant='synthetic '+case+' '+variant)
   result=json.loads((PROOF/(case+'-'+variant)/'RESULT.json').read_bytes());need(r['actual_process_returncode']==expect and result['exit_code']==expect and not r['timeout_expired'],'proof expected exit mismatch '+case+' '+variant)
   if expect:need('AssertionError:' in result['error'],'withdrawal must fail behavioral recovery assertion')
   rows.append({'case':case,'variant':variant,'expected_exit':expect,'actual_exit':r['actual_process_returncode'],'capture':r,'result_path':str(PROOF/(case+'-'+variant)/'RESULT.json')})
 r,so,se=rec.run([sys.executable,'-B',str(Path(__file__)),'unknown-inode','fixed',str(PROOF/'unknown-inode-fixed')],cwd=D,timeout=60,check=False,source_variant='synthetic unknown inode rejection');need(r['actual_process_returncode']==0,'unknown inode rejection failed');rows.append({'case':'unknown-inode','capture':r})
 result={'exit_code':0,'checks':len(rows),'proofs':rows,'tool_sha256':H(V2.read_bytes()),'v1_sha256':H(V1.read_bytes()),'proof_sha256':H(Path(__file__).read_bytes()),'capture_sha256':H(CAP.read_bytes()),'scope':'25 tiny child executions; 8 exact behavioral 0/1/0 sequences plus unknown-inode rejection. No actual ROOT/SHM read, locks, product tests or production Git writes.','formal_11_run':False};dump(PROOF/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='proofs'},ensure_ascii=False))
if __name__=='__main__':
 if len(sys.argv)==1:orchestrate()
 else:raise SystemExit(child(sys.argv[1],sys.argv[2],Path(sys.argv[3])))
