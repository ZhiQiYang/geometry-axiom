"""Root-only temporary F9 variants; never a formal F9 acceptance or commit."""
from pathlib import Path
import argparse, ast, datetime, fcntl, hashlib, importlib.util, json, os
import re, signal, stat, sys, traceback

ROOT = Path('/tmp/train337-323-f64d638f-source')
OUT = Path('/workspace/geo314-F9-kernel-scope-counterproof-v2-20261025')
PREP = Path('/tmp/geo314-F9-kernel-scope-rootcause-20261025')
F9 = '4f8a794f4167c3562eb182045102e86e9e37cca9'
BASE = '4b665fae21ab63aaffb7d84f6a32d5a469ba1675'
I24 = '32f42e3d991c7d2d916d21bfe8ac5d3dd0f9b131'
KHEAD = '81b6c388f8b73e9aaf885b1d948e5f306b77bafd'
TEST = 'tests/test_geo314_commit_paths.py'
NAMED = 'test_kernel_has_no_changes_against_the_fixed_integration_base'
KFILES = ['geometry-core/kernel/source.c', 'geometry-core/kernel/candidate.c']
NEWFILES = ['geometry-core/kernel/geo314_scope_staged_probe.c', 'geometry-core/kernel/geo314_scope_untracked_probe.c']
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_PIN = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
ORIGINAL_PIN = 'f4f4fed9677b093bf0d16be185717a1e1959e5f1e887470523eb4c8333ee85cc'
PROPOSED_PIN = '3ace33248d6ce39b869bf09319315544610311c2ddb8434ad8a57d6a90a9f032'
PATCH_PIN = '233de5a153ad7d27d8caad56575c1545488987a6766d8075d7cf5f34216e78af'
REAPER = Path('/workspace/geo261-environment/reap_children.py')
REAPER_PIN = '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
RUNNER_PIN = 'f4e72e7a771f903094d6973874da8ccb2c98ddb4ff51571cb9179eabe284290e'

def H(raw):
    return hashlib.sha256(raw).hexdigest()

def need(v, text):
    if not v:
        raise AssertionError(text)

def dump(path, data):
    with Path(path).open('w') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
        f.flush()
        os.fsync(f.fileno())

def stat_meta(s):
    return dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, uid=s.st_uid,
                gid=s.st_gid, nlink=s.st_nlink, size=s.st_size,
                mtime_ns=s.st_mtime_ns, atime_ns=s.st_atime_ns)

def meta(path):
    return stat_meta(Path(path).lstat())

class DeferredSignals:
    """Cooperative stop: handlers never throw across writes or restoration."""
    def __init__(self):
        self.received=[]
        self.handlers={}
    def handler(self, signum, frame):
        self.received.append(signum)
    def install(self):
        for sig in (signal.SIGTERM, signal.SIGINT):
            self.handlers[sig]=signal.signal(sig,self.handler)
    def checkpoint(self):
        need(not self.received,'received signal; restore at safe boundary: '+repr(self.received))
    def close(self):
        # Called only after restoration, RESULT and scheduler lock release.
        for sig, handler in self.handlers.items():
            signal.signal(sig,handler)


def diagnostic(out, rel, observed, errors):
    """Evidence failure is reported separately and never prevents recovery."""
    try:
        p=Path(out)/('PARTIAL_'+rel.replace('/','__'))
        with p.open('xb') as f:
            f.write(observed);f.flush();os.fsync(f.fileno())
    except BaseException:
        errors.append(dict(path=rel,error=traceback.format_exc()))


def create_probe(root, rel, payload, created):
    """Register the exact O_EXCL inode before any payload write/flush/fsync."""
    p=Path(root)/rel
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        created[rel]=(stat_meta(os.fstat(fd)),payload)
        with os.fdopen(fd,'wb',closefd=False) as f:
            f.write(payload);f.flush();os.fsync(fd)
    finally:
        os.close(fd)


def recover_created(root, out, created, diagnostic_errors, restoration_errors):
    for rel,(m,payload) in list(created.items()):
        try:
            p=Path(root)/rel;observed,now=read_owned(p)
            need((now['dev'],now['inode'])==(m['dev'],m['inode']),
                 'new probe identity before recovery')
            if observed!=payload:diagnostic(out,rel,observed,diagnostic_errors)
            # Partial bytes are ours only because O_EXCL registration preceded
            # writing and the exclusive lease plus original inode still hold.
            p.unlink();del created[rel]
        except BaseException:
            restoration_errors.append(dict(path=rel,error=traceback.format_exc()))


def recover_saved(root, out, saved, expected, inflight, diagnostic_errors, restoration_errors):
    for rel,(raw,m) in saved.items():
        try:
            if rel in inflight:
                observed,now=read_owned(Path(root)/rel)
                need((now['dev'],now['inode'])==(m['dev'],m['inode']),
                     'inflight recovery same owned inode')
                diagnostic(out,rel,observed,diagnostic_errors)
                write_exact(Path(root)/rel,observed,raw,(m['dev'],m['inode']))
            elif expected[rel]!=raw:
                write_exact(Path(root)/rel,expected[rel],raw,(m['dev'],m['inode']))
            os.utime(Path(root)/rel,ns=(m['atime_ns'],m['mtime_ns']),follow_symlinks=False)
            nowraw,now=read_owned(Path(root)/rel)
            need(nowraw==raw and now==m,'exact bytes/inode/mode/mtime recovered: '+rel)
        except BaseException:
            restoration_errors.append(dict(path=rel,error=traceback.format_exc()))


def require_full_index(shared_path):
    need(shared_path.strip()==b'', 'original split index is unsupported; never convert it in place')


def private_stage_arguments(rel):
    return ['-c','core.splitIndex=false','add','--',rel]


def shared_index_state(gitdir):
    result={}
    for p in sorted(Path(gitdir).glob('sharedindex.*')):
        raw,m=read_owned(p);result[p.name]=dict(metadata=m,sha256=H(raw))
    return result


def read_owned(path):
    path = Path(path)
    for p in path.parents:
        need(stat.S_ISDIR(p.lstat().st_mode) and not p.is_symlink(), 'no symlink ancestor: '+str(p))
    m = meta(path)
    need(stat.S_ISREG(m['mode']) and m['uid']==os.getuid() and m['nlink']==1, 'owned independent regular leaf: '+str(path))
    with os.fdopen(os.open(path, os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME), 'rb') as f:
        raw = f.read()
    need(meta(path)==m, 'stable original metadata: '+str(path))
    return raw, m

def write_exact(path, expected, replacement, inode):
    current, m = read_owned(path)
    need(current==expected and (m['dev'],m['inode'])==inode, 'exclusive expected original bytes before write')
    fd = os.open(path, os.O_WRONLY|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd);need((s.st_dev,s.st_ino)==inode, 'opened inode exact')
        with os.fdopen(fd, 'wb', closefd=False) as f:
            f.write(replacement);f.truncate();f.flush();os.fsync(fd)
    finally:
        os.close(fd)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--request',type=Path,required=True)
    ap.add_argument('--request-sha256',required=True);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    need(a.execute and not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ,'explicit execute; assertions enabled')
    qraw=a.request.read_bytes();need(H(qraw)==a.request_sha256,'exact root request');q=json.loads(qraw)
    for key in ['root_execution_lease','root_source_exclusive','root_no_other_git_writer','root_recovery_authorized']:
        need(q[key] is True,'root lease: '+key)
    need(q['source_sha']==F9 and q['root']==str(ROOT) and q['out']==str(OUT),'exact source/root/out')
    need(H(Path(__file__).read_bytes())==q['tool_sha256'],'exact executor')
    peer_raw=Path(q['peer']['path']).read_bytes();peer=json.loads(peer_raw)
    need(H(peer_raw)==q['peer']['sha256'] and peer['exit_code']==0 and not peer['blocking_findings'] and peer['executor_sha256']==q['tool_sha256'],'accepted independent exact-tool peer')
    need(H(CAP.read_bytes())==CAP_PIN and H(GUARD.read_bytes())==GUARD_PIN and H(REAPER.read_bytes())==REAPER_PIN,'original recorder, consumer and reaper pins')
    original=(PREP/'test_geo314_commit_paths.F9.original.py').read_bytes()
    proposed=(PREP/'test_geo314_commit_paths.proposed.py').read_bytes()
    need(H(original)==ORIGINAL_PIN and H(proposed)==PROPOSED_PIN and H((PREP/'PROPOSED.patch').read_bytes())==PATCH_PIN,'reviewed exact original/proposed/patch')
    need(not OUT.exists(),'fresh fixed evidence output')
    recovering=False
    locks=[];saved={};expected={};created={};inflight=set();rec=None;state=None;index_before=None;shared_before=None;signals=DeferredSignals()
    result=dict(schema='geo314-F9-temporary-scope-counterproof/2',source_sha=F9,formal_F9_pass=False,
                product_or_test_commit_created=False,exit_code=1,phases=[],restoration_errors=[],diagnostic_errors=[],
                started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),request_sha256=a.request_sha256,
                actual_source_variant='F9 plus explicitly temporary reviewed test patch / named K probes',
                historical_I24_negative_fixture='NOT_EXECUTED_BY_THIS_DRIVER; ancestry and exact historical zero-K closure required',
                limitations=['Original ROOT index/refs/objects are never written; staged-new case uses an exact copied private index and private object store.',
                            'Temporary source inode/mode/bytes/mtime restored; ctime changes from temporary writes cannot be restored.',
                            'This preparation does not replace final patched-SHA native acceptance or ledger/architecture refresh.',
                            'SIGINT/SIGTERM are recorded without throwing; operational checkpoints stop after the current original subprocess (at most its unchanged 1200-second timeout). Recovery contains no signal checkpoint.',
                            'SIGKILL, host failure or persistent I/O failure can prevent recovery; original RECOVERY.json/backups and exact owned inode identities require root manual recovery, never a broad checkout/reset.',
                            'Split original indexes are rejected read-only; private staging forces core.splitIndex=false and original sharedindex leaves are checked unchanged.'])
    env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','MUTATE_','GEOMETRY_')) and k not in ('PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE','LD_PRELOAD','NODE_OPTIONS')}
    env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',LANG='C.UTF-8',LC_ALL='C.UTF-8')
    signals.install()
    try:
        for name in ['heavy','secondary']:
            p=Path('/tmp/g261r3')/(name+'.lock');s=p.lstat()
            need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink(),'existing scheduler lock')
            fd=p.open('r+b');locks.append(fd)
            need((os.fstat(fd.fileno()).st_dev,os.fstat(fd.fileno()).st_ino)==(s.st_dev,s.st_ino),'lock inode')
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        OUT.mkdir();(OUT/'backups').mkdir();(OUT/'tmp').mkdir();env['TMPDIR']=str(OUT/'tmp')
        spec=importlib.util.spec_from_file_location('original_capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
        rec=cap.Recorder(OUT/'commands',env,F9)
        guard={'__name__':'consumer_only'};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard)
        (OUT/'consumers').mkdir();guard['OUT']=OUT/'consumers';guard['consumer_check']([str(ROOT)])
        def cmd(argv, *, variant='temporary-counterproof-preflight', extra=None, expect=0, data=None):
            if not recovering:signals.checkpoint()
            old=rec.env;rec.env={**env,**(extra or {})}
            try:r,so,se=rec.run(argv,cwd=ROOT,data=data,check=False,timeout=1200,source_sha=F9,source_variant=variant)
            finally:rec.env=old
            if not recovering:signals.checkpoint()
            need(r['actual_process_returncode']==expect and not r['timeout_expired'],'unexpected original subprocess exit: '+variant)
            return r,so,se
        def git(args, **kw):
            return cmd(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args],**kw)[1]
        def identity():
            return dict(head=git(['rev-parse','HEAD']).decode().strip(),tree=git(['rev-parse','HEAD^{tree}']).decode().strip(),
                        status=git(['status','--porcelain=v1','--untracked-files=all']).decode(),refs_sha256=H(git(['for-each-ref','--format=%(refname) %(objectname)'])))
        state=identity();need(state['head']==F9 and state['status']=='','exact clean F9 root')
        gd=Path(git(['rev-parse','--absolute-git-dir']).decode().strip());index=gd/'index'
        ib,im=read_owned(index);index_before=(index,ib,im)
        require_full_index(git(['rev-parse','--shared-index-path']))
        shared_before=(gd,shared_index_state(gd))
        need(not (gd/'index.lock').exists(),'no existing index writer')
        objects=Path(git(['rev-parse','--git-path','objects']).decode().strip())
        if not objects.is_absolute():objects=ROOT/objects
        for sha in [BASE,I24,KHEAD]:
            git(['cat-file','-e',sha+'^{commit}']);git(['merge-base','--is-ancestor',sha,F9])
        need(git(['diff','--no-renames','--name-only',BASE,I24,'--','geometry-core/kernel'])==b'','historical I24 must have zero K delta')
        need(git(['ls-tree','-r','-z',KHEAD,'--','geometry-core/kernel'])==git(['ls-tree','-r','-z',F9,'--','geometry-core/kernel']),'complete approved K tree equals F9; no path whitelist')
        need(git(['diff','--no-renames','--name-only',BASE,F9,'--','geometry-core/kernel'])==b'geometry-core/kernel/source.c\n','original withdrawn disease exact source.c closure')
        for rel in [TEST,*KFILES]:
            raw,m=read_owned(ROOT/rel);need(raw==git(['show',F9+':'+rel]),'leaf equals actual F9 blob: '+rel)
            saved[rel]=(raw,m);expected[rel]=raw
        need(saved[TEST][0]==original,'real F9 test equals reviewed original')
        runner=(ROOT/'tests/_unittest_runner.py').read_bytes()
        need(H(runner)==RUNNER_PIN and runner==git(['show',F9+':tests/_unittest_runner.py']),'exact original full-suite runner')
        for rel in NEWFILES:
            need(not os.path.lexists(ROOT/rel),'new negative path must be absent')
            cmd(['git','check-ignore','--quiet','--',rel],expect=1)
        st=os.statvfs(OUT);free=st.f_bavail*st.f_frsize
        budget=len(ib)+sum(len(raw) for raw,m in saved.values())+4*1024*1024
        need(free>=budget+64*1024*1024,'fresh exact private-index/backup/metadata budget plus64MiB reserve')
        result['budget']=dict(free_before=free,upper_allocation=budget,reserve_bytes=64*1024*1024)
        for rel,(raw,m) in saved.items():
            b=OUT/'backups'/rel.replace('/','__');b.write_bytes(raw)
            with b.open('rb') as f:os.fsync(f.fileno())
        dump(OUT/'RECOVERY.json',dict(root=str(ROOT),source_sha=F9,files={rel:dict(backup=str(OUT/'backups'/rel.replace('/','__')),sha256=H(raw),metadata=m) for rel,(raw,m) in saved.items()},never_modify_real_index=True,new_paths=NEWFILES))
        result['before']=state;result['original_index']=dict(path=str(index),sha256=H(ib),metadata=im)
        def install(rel,raw):
            signals.checkpoint()
            dump(OUT/'WRITE_INTENT.json',dict(path=rel,from_sha256=H(expected[rel]),to_sha256=H(raw),original_sha256=H(saved[rel][0])))
            inflight.add(rel)
            write_exact(ROOT/rel,expected[rel],raw,(saved[rel][1]['dev'],saved[rel][1]['inode']))
            expected[rel]=raw;inflight.remove(rel)
            signals.checkpoint()
        def test(name, expect, full=False, badpath=None, extra=None):
            d=OUT/name;d.mkdir();ex={**(extra or {}),'GEO261_REAPER_LOG':str(d/'reaper.jsonl')}
            if full:
                inner=[sys.executable,'-B','tests/_unittest_runner.py',TEST,'--json-out',str(d/'unit.json'),'--log',str(d/'unit.log')]
            else:
                inner=[sys.executable,'-B','-m','unittest','tests.test_geo314_commit_paths.Geo314CommitPaths.'+NAMED]
            r,so,se=cmd([sys.executable,'-B',str(REAPER),*inner],variant=name,extra=ex,expect=expect)
            events=[json.loads(x) for x in (d/'reaper.jsonl').read_text().splitlines()]
            need(events[-1].get('primary_returncode')==expect,'original reaper primary exit matches')
            if full:
                unit=json.loads((d/'unit.json').read_bytes());need(unit['total']==unit['run']==11 and unit['skipped']==unit['blocked_by_error']==0 and not unit['import_error'],'full original11 count/no error/no skip')
                need(unit['failed']==expect and unit['passed']==11-expect,'full original11 exact expected outcomes')
                text=(d/'unit.log').read_text()
            else:
                text=se.decode();need(re.search(r'Ran 1 test in',text) is not None and 'ERROR:' not in text and 'skipped=' not in text,'one real named test/no infrastructure error/skip')
            if expect:
                need('FAIL: '+NAMED in text and 'AssertionError:' in text and 'I24 submission policy must not change K files' in text and badpath in text,'precise named K violation assertion')
            else:need(text.rstrip().endswith('OK'),'complete original green summary')
            result['phases'].append(dict(name=name,actual_exit=expect,total=11 if full else 1,original_timeout_seconds=1200,source_variant=name,test_sha256=H((ROOT/TEST).read_bytes()),private_index=ex.get('GIT_INDEX_FILE'),environment_overrides=ex,capture=r))
            dump(OUT/'PROGRESS.json',result)
        install(TEST,proposed);test('fixed-full11',0,full=True)
        install(TEST,original);test('withdrawn-original-full11',1,full=True,badpath=KFILES[0])
        install(TEST,proposed);test('restored-full11',0,full=True)
        for i,rel in enumerate(KFILES):
            install(rel,saved[rel][0]+b'\n/* GEO314 isolated kernel-scope negative */\n')
            test('negative-existing-K-'+str(i),1,badpath=rel)
            install(rel,saved[rel][0]);test('restored-existing-K-'+str(i),0)
        for i,rel in enumerate(NEWFILES):
            p=ROOT/rel;payload=b'/* GEO314 isolated new K source negative */\n'
            signals.checkpoint()
            create_probe(ROOT,rel,payload,created)
            signals.checkpoint();extra={}
            if i==0:
                private=OUT/'staged-index';private.write_bytes(ib);need(private.read_bytes()==ib,'private index exact original snapshot')
                pobj=OUT/'private-objects';pobj.mkdir()
                extra=dict(GIT_INDEX_FILE=str(private),GIT_OBJECT_DIRECTORY=str(pobj),GIT_ALTERNATE_OBJECT_DIRECTORIES=str(objects))
                git(private_stage_arguments(rel),variant='stage-new-K-private-index',extra=extra)
                require_full_index(git(['rev-parse','--shared-index-path'],extra=extra))
                need(git(['diff','--cached','--name-only',F9,'--','geometry-core/kernel'],extra=extra)==(rel+'\n').encode(),'new K truly staged in isolated full index')
            test('negative-new-K-'+str(i),1,badpath=rel,extra=extra)
            need(read_owned(p)[0]==payload and meta(p)['inode']==created[rel][0]['inode'],'own new probe unchanged before removal')
            p.unlink();del created[rel]
            # Stop using the staged private index, preserving it as original evidence.
            test('restored-new-K-'+str(i),0)
        result['counterproof_passed']=True
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        recovering=True
        # The non-throwing signal handler stays installed through RESULT and
        # lock release. No checkpoint, diagnostic failure or ordinary INT/TERM
        # can skip an owned leaf's restoration.
        recover_created(ROOT,OUT,created,result['diagnostic_errors'],result['restoration_errors'])
        recover_saved(ROOT,OUT,saved,expected,inflight,result['diagnostic_errors'],result['restoration_errors'])
        if shared_before:
            try:
                gd,prior=shared_before
                need(shared_index_state(gd)==prior,'original sharedindex leaves unchanged')
                result['shared_index_unchanged']=True
            except BaseException:result['restoration_errors'].append(traceback.format_exc())
        if index_before:
            try:
                path,raw,m=index_before;now,mm=read_owned(path);need(now==raw and mm==m,'original ROOT index bytes/inode/metadata untouched')
                result['after']=identity();need(result['after']==state,'original F9 HEAD/tree/full status/refs restored exactly')
                need(all(not os.path.lexists(ROOT/p) for p in NEWFILES),'temporary new K paths absent')
            except BaseException:result['restoration_errors'].append(traceback.format_exc())
        result['signals_received']=list(signals.received)
        result['exit_code']=0 if result.get('counterproof_passed') and not result['restoration_errors'] and not result['diagnostic_errors'] and not signals.received else 1
        result['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            if OUT.exists():dump(OUT/'RESULT.json',result)
        finally:
            for fd in reversed(locks):fd.close()
            signals.close()
    print(json.dumps({k:result.get(k) for k in ['exit_code','counterproof_passed','formal_F9_pass','restoration_errors']}))
    return result['exit_code']

if __name__=='__main__':raise SystemExit(main())
