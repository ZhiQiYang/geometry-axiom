from pathlib import Path
import ast,difflib,hashlib,json
D=Path(__file__).parent
p=D/'run_counterproof.py';old=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='274b3753daa489879cdb2ca95517ef8ae94d808ac5ec7919de8ce02091f1fe3a'
s=old.replace("OUT = Path('/workspace/geo314-F9-kernel-scope-counterproof-20261025')", "OUT = Path('/workspace/geo314-F9-kernel-scope-counterproof-v2-20261025')")
s=s.replace('def meta(path):\n    s = Path(path).lstat()\n', 'def stat_meta(s):\n')
pos=s.index('\ndef read_owned(path):')
s=s[:pos]+'''\ndef meta(path):
    return stat_meta(Path(path).lstat())

class DeferredSignals:
    """Cooperative stop: handlers never throw across writes or restoration."""
    def __init__(self):
        self.received=[]
        self.handlers={}
    def handler(self, signum, frame):
        self.received.append(signum)
    def install(self):
        for sig in (signal.SIGTERM, signal.SIGINT):
            self.handlers[sig]=signal.signal(sig,self.handler)
    def checkpoint(self):
        need(not self.received,'received signal; restore at safe boundary: '+repr(self.received))
    def close(self):
        # Called only after restoration, RESULT and scheduler lock release.
        for sig, handler in self.handlers.items():
            signal.signal(sig,handler)


def diagnostic(out, rel, observed, errors):
    """Evidence failure is reported separately and never prevents recovery."""
    try:
        p=Path(out)/('PARTIAL_'+rel.replace('/','__'))
        with p.open('xb') as f:
            f.write(observed);f.flush();os.fsync(f.fileno())
    except BaseException:
        errors.append(dict(path=rel,error=traceback.format_exc()))


def create_probe(root, rel, payload, created):
    """Register the exact O_EXCL inode before any payload write/flush/fsync."""
    p=Path(root)/rel
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        created[rel]=(stat_meta(os.fstat(fd)),payload)
        with os.fdopen(fd,'wb',closefd=False) as f:
            f.write(payload);f.flush();os.fsync(fd)
    finally:
        os.close(fd)


def recover_created(root, out, created, diagnostic_errors, restoration_errors):
    for rel,(m,payload) in list(created.items()):
        try:
            p=Path(root)/rel;observed,now=read_owned(p)
            need((now['dev'],now['inode'])==(m['dev'],m['inode']),
                 'new probe identity before recovery')
            if observed!=payload:diagnostic(out,rel,observed,diagnostic_errors)
            # Partial bytes are ours only because O_EXCL registration preceded
            # writing and the exclusive lease plus original inode still hold.
            p.unlink();del created[rel]
        except BaseException:
            restoration_errors.append(dict(path=rel,error=traceback.format_exc()))


def recover_saved(root, out, saved, expected, inflight, diagnostic_errors, restoration_errors):
    for rel,(raw,m) in saved.items():
        try:
            if rel in inflight:
                observed,now=read_owned(Path(root)/rel)
                need((now['dev'],now['inode'])==(m['dev'],m['inode']),
                     'inflight recovery same owned inode')
                diagnostic(out,rel,observed,diagnostic_errors)
                write_exact(Path(root)/rel,observed,raw,(m['dev'],m['inode']))
            elif expected[rel]!=raw:
                write_exact(Path(root)/rel,expected[rel],raw,(m['dev'],m['inode']))
            os.utime(Path(root)/rel,ns=(m['atime_ns'],m['mtime_ns']),follow_symlinks=False)
            nowraw,now=read_owned(Path(root)/rel)
            need(nowraw==raw and now==m,'exact bytes/inode/mode/mtime recovered: '+rel)
        except BaseException:
            restoration_errors.append(dict(path=rel,error=traceback.format_exc()))


def require_full_index(shared_path):
    need(shared_path.strip()==b'', 'original split index is unsupported; never convert it in place')


def private_stage_arguments(rel):
    return ['-c','core.splitIndex=false','add','--',rel]


def shared_index_state(gitdir):
    result={}
    for p in sorted(Path(gitdir).glob('sharedindex.*')):
        raw,m=read_owned(p);result[p.name]=dict(metadata=m,sha256=H(raw))
    return result

''' + s[pos:]
s=s.replace('index_before=None\n', 'index_before=None;shared_before=None;signals=DeferredSignals()\n')
s=s.replace("schema='geo314-F9-temporary-scope-counterproof/1'", "schema='geo314-F9-temporary-scope-counterproof/2'")
s=s.replace('exit_code=1,phases=[],restoration_errors=[],', 'exit_code=1,phases=[],restoration_errors=[],diagnostic_errors=[],')
s=s.replace("'This preparation does not replace final patched-SHA native acceptance or ledger/architecture refresh.'", "'This preparation does not replace final patched-SHA native acceptance or ledger/architecture refresh.',\n                            'SIGINT/SIGTERM are recorded without throwing; operational checkpoints stop after the current original subprocess (at most its unchanged 1200-second timeout). Recovery contains no signal checkpoint.',\n                            'SIGKILL, host failure or persistent I/O failure can prevent recovery; original RECOVERY.json/backups and exact owned inode identities require root manual recovery, never a broad checkout/reset.',\n                            'Split original indexes are rejected read-only; private staging forces core.splitIndex=false and original sharedindex leaves are checked unchanged.'")
a=s.index('    def interrupted(signum,frame):');b=s.index('    try:\n',a)
s=s[:a]+'    signals.install()\n'+s[b:]
s=s.replace("            old=rec.env;rec.env={**env,**(extra or {})}", "            signals.checkpoint()\n            old=rec.env;rec.env={**env,**(extra or {})}")
# Recovery identity uses same captured git helper but must not checkpoint pending signals.
s=s.replace("    locks=[];saved={}", "    recovering=False\n    locks=[];saved={}")
s=s.replace('            signals.checkpoint()\n            old=rec.env;', '            if not recovering:signals.checkpoint()\n            old=rec.env;')
s=s.replace("            need(r['actual_process_returncode']==expect", "            if not recovering:signals.checkpoint()\n            need(r['actual_process_returncode']==expect")
s=s.replace("        ib,im=read_owned(index);index_before=(index,ib,im)", "        ib,im=read_owned(index);index_before=(index,ib,im)\n        require_full_index(git(['rev-parse','--shared-index-path']))\n        shared_before=(gd,shared_index_state(gd))")
s=s.replace("        def install(rel,raw):\n            dump", "        def install(rel,raw):\n            signals.checkpoint()\n            dump")
s=s.replace('            expected[rel]=raw;inflight.remove(rel)', '            expected[rel]=raw;inflight.remove(rel)\n            signals.checkpoint()')
s=s.replace("            with p.open('xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())\n            created[rel]=(meta(p),payload);extra={}", "            signals.checkpoint()\n            create_probe(ROOT,rel,payload,created)\n            signals.checkpoint();extra={}")
s=s.replace("git(['add','--',rel],variant='stage-new-K-private-index',extra=extra)", "git(private_stage_arguments(rel),variant='stage-new-K-private-index',extra=extra)\n                require_full_index(git(['rev-parse','--shared-index-path'],extra=extra))")
a=s.index('        # No git reset/checkout/clean.');b=s.index('        if index_before:',a)
s=s[:a]+'''        recovering=True
        # The non-throwing signal handler stays installed through RESULT and
        # lock release. No checkpoint, diagnostic failure or ordinary INT/TERM
        # can skip an owned leaf's restoration.
        recover_created(ROOT,OUT,created,result['diagnostic_errors'],result['restoration_errors'])
        recover_saved(ROOT,OUT,saved,expected,inflight,result['diagnostic_errors'],result['restoration_errors'])
        if shared_before:
            try:
                gd,prior=shared_before
                need(shared_index_state(gd)==prior,'original sharedindex leaves unchanged')
                result['shared_index_unchanged']=True
            except BaseException:result['restoration_errors'].append(traceback.format_exc())
''' + s[b:]
s=s.replace("result['exit_code']=0 if result.get('counterproof_passed') and not result['restoration_errors'] else 1", "result['signals_received']=list(signals.received)\n        result['exit_code']=0 if result.get('counterproof_passed') and not result['restoration_errors'] and not result['diagnostic_errors'] and not signals.received else 1")
s=s.replace("        if OUT.exists():dump(OUT/'RESULT.json',result)\n        for fd in reversed(locks):fd.close()", "        try:\n            if OUT.exists():dump(OUT/'RESULT.json',result)\n        finally:\n            for fd in reversed(locks):fd.close()\n            signals.close()")
ast.parse(s)
p=D/'run_counterproof_v2.py';assert not p.exists();p.write_text(s)
(D/'V1_TO_V2.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='v1-red',tofile='v2-recovery-draft')))
q=json.loads((D/'REQUEST.pending-peer.root-lease-false.json').read_bytes());q['tool_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();q['out']='/workspace/geo314-F9-kernel-scope-counterproof-v2-20261025';(D/'REQUEST.v2.pending-peer.root-lease-false.json').write_text(json.dumps(q,indent=2)+'\n')
print(q['tool_sha256'],len(s.encode()))
