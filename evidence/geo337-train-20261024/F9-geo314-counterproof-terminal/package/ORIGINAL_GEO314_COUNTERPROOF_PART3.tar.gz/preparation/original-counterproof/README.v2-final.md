# #314 暫時反證工具 v2（尚未執行正式來源）

原 v1 `274b3753…` 及其四項靜審紅燈完整保留。`run_counterproof_v2_final.py` 是待 root 排程的工具，不是產品／測試修正，也沒有把 F9 native 紅燈改列為綠。

- `O_EXCL` 取得新 probe fd 後，先登記 inode，再寫入／flush／fsync；復原可辨識自己的部分寫入，拒絕陌生替換 inode。
- PARTIAL 診斷錯誤獨立記錄，不阻止同 inode 原 bytes／mtime 還原；診斷失敗仍使工具 exit 1。
- SIGINT／SIGTERM handler 只記錄。操作安全邊界才停止，復原區不拋訊號；原子命令最多沿原 1200 秒 timeout 後進入還原。SIGKILL、宿主崩潰與持續 I/O 失敗不保證自動還原，必須使用原 RECOVERY 與 backups，不能廣泛 reset／checkout。
- 原／私有 index 直接驗 DIRC v2/v3/v4 邊界、SHA-1 trailer 並拒 `link` extension；私有 stage 明確 `core.splitIndex=false`，原 sharedindex 葉前後相同。不能用受 config 影響的 `rev-parse --shared-index-path` 代替 index bytes 證據。

`fault-proof-v2-r3/RESULT.json` 為 28 個純 tiny 子執行，八組真 0／1／0，另含未知 inode 與原生 Git index v2/v3/v4／checksum 反例。原 c387 保存完整命令、環境、exit、stdout/stderr；tiny Git 子命令亦逐一保存。沒有讀寫真 ROOT、SHM、鎖或執行正式 11 項。

首輪抽錯 AST 預檢 loop 的 NameError，以及第二輪 query 判斷不可靠的原紅／工具稿完整保留；兩者不算產品反證，也不改寫原件。`test`、`read_owned`、`write_exact` AST、固定原件 pins、正式 full11／四類 K 負例門檻均未更改。

正式執行仍須獨立 peer pin、root 四項租約、雙鎖與原 fresh64MiB reserve。false request 保持四 false。原歷史 I24 tiny 負例仍另項未跑，不由這份工具自稱完成。新 main 合流與產品 final SHA 由 root 另行處理，這份預備反證只綁 F9 明列暫時變體。
