counterproof最終v2靜態獨審：0阻擋，原四問題已按其最小失敗路徑補正。原三核心helper/test AST未放寬，私有index改為DIRC直接驗證而非config敏感推測。

已唯讀核28個既有tiny原c387子程序全stream/exit/hash：20個0、8個具名Assertion1，八組真進程0/1/0及unknowninode/index2/3/4/checksum extras；沒有重跑tiny或接觸ROOT/SHM。原兩次未接受準備失敗與v1紅保留。

四lease仍false；正式11、歷史I24負例仍UNRUN/pending，formal_F9_pass=false。本報告只接受工具修復，不將F9 native原紅改綠。SIGKILL/hostfault/持續I/O故障須人工RECOVERY，ctime不可復原界線保持。
