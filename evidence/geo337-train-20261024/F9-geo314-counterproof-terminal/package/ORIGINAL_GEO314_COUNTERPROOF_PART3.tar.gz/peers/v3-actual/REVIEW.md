v3 actual獨立收件核對通過：349原raw核對/0。完整11測試固定0（11pass）→原test撤回1（10pass/1精確source.c FAIL）→恢復0（11pass），零skip/ERROR；4K類型各精確named Assertion1→還原0。

原命令實為38條/76stdoutstderr（非35），全部request/result/stdin/fullstream/hash/GIT_ENVIRONMENT與各reaper終態已讀核。每command realindex raw/meta守門由exact7465執行器原0及無error證實；沒有偽造38個個別實體snapshot，也未讀當前NATIVE。原完整indexsnapshot hash與checksum、3source backups對原Gitshow一致；before/after HEAD/tree/status/refs同、source恢復且無新probe/commit。

原v2真outer1/restoreerror1保留；writer原因仍未完全確定。這只接受temporarypatch反證，F9正式native仍1、formal_F9_pass=false。root可批次採入patch後固定新final並跑受影響正式門檻，不能把本focused結果改標整份native綠。
