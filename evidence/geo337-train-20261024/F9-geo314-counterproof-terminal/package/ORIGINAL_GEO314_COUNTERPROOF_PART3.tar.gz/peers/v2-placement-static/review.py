from pathlib import Path
import hashlib,json,ast,datetime
S=Path('/workspace/geo314-F9-counterproof-shm-placement-20261025');O=Path(__file__).parent
old=Path('/workspace/geo314-F9-kernel-scope-counterproof-preparation-20261025/run_counterproof_v2_final.py');new=S/'run_counterproof_v2_shm.py'
h=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(v,n):checks.append(dict(check=n,passed=bool(v)))
a=old.read_bytes();b=new.read_bytes();p=json.loads((S/'PREPARATION.json').read_bytes())
ck(h(a)=='706913fa818b14b91c9a9b09f6e12e55ddd9b463e06287fcb90599c2b376ba63','original accepted executor exact')
ck(h(b)=='bd471131af1f620964ec4f54a386b48b5127473f783c3292e256bfe3ba6f423d','new executor exact')
before=b"OUT = Path('/workspace/geo314-F9-kernel-scope-counterproof-v2-20261025')";after=b"OUT = Path('/dev/shm/geometry-axiom-geo337-20261025/geo314-counterproof-v2-20261025')"
ck(a.count(before)==1 and b.count(after)==1,'single exact OUT constant')
ck(a.replace(before,after)==b and b.replace(after,before)==a,'entire forward/reverse bytes equal except OUT')
ta=ast.parse(a);tb=ast.parse(b)
for tree in [ta,tb]:
 matches=[n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='OUT'for t in n.targets)]
 ck(len(matches)==1,'one OUT AST');matches[0].value=ast.Constant('PLACEMENT_ONLY')
ck(ast.dump(ta,include_attributes=False)==ast.dump(tb,include_attributes=False),'all AST except OUT identical')
ck(h((S/'PREPARATION.json').read_bytes())=='31093e9f53a816a7c74f25474cc42f7f6c6959299067cfe0b322fec578077947','preparation exact pin')
peer=Path(p['original_static_peer']['path']);ck(h(peer.read_bytes())==p['original_static_peer']['sha256'],'old accepted peer pin');pj=json.loads(peer.read_bytes());ck(pj['exit_code']==0 and not pj['blocking_findings'],'old peer accepted')
proof=p['original28_tiny_proofs_reused_not_reexecuted'];ck(h(Path(proof['path']).read_bytes())==proof['sha256'],'old28 proof retained without rerun')
qpath=S/'REQUEST.pending-peer.root-lease-false.json';q=json.loads(qpath.read_bytes());ck(h(qpath.read_bytes())==p['pending_request_sha256'],'pending request pin')
for k in ['root_execution_lease','root_source_exclusive','root_no_other_git_writer','root_recovery_authorized']:ck(q[k]is False,'lease remains false '+k)
ck(q['tool_sha256']==h(b)and q['out']==p['new_out']and q['root']==p['root']and q['source_sha']==p['source_sha'],'request exact identities')
ck(q['peer']['path']=='UNBOUND_REVIEW_PATH'and q['peer']['sha256']=='UNBOUND_SHA256','peer unbound until root pins')
ck(p['formal_executed']is False and p['source_or_SHM_read_or_write']is False and p['new_tiny_proof_run']is False,'only preparation claims')
fail=[r['check']for r in checks if not r['passed']]
report=dict(schema='geo314-counterproof-exact-OUT-only-static-peer/1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1 if fail else 0,blocking_findings=fail,executor_sha256=h(b),checks=len(checks),check_results=checks,scope='Exact full bytes/AST only OUT changed from accepted706913fa. No original ROOT/SHM/product/ELF reads and no counterproof or tiny-proof execution.',limitations=['Formal11/fourK-negative/restored remain UNRUN. Root must obtain true browser terminal, exclusive source/Git leases and common RAM/disk admission before approved SHM execution.','Original64MiB reserve,1200s command timeout, private index/objects, signals/recovery unchanged. No expanded authorization or changed test semantics.'])
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'exit_code':report['exit_code'],'checks':len(checks),'sha256':h((O/'REVIEW.json').read_bytes())}));raise SystemExit(report['exit_code'])
