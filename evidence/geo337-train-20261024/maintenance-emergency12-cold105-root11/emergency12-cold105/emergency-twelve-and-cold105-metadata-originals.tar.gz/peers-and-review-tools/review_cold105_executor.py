#!/usr/bin/env python3
"""Static tool/outer review only. Never imports or invokes retirement executor."""
import ast,hashlib,json,difflib
from pathlib import Path
O=Path('/workspace/train337-canvas-peer-resume')
P=Path('/workspace/retire_exact_cold105_source_copies_20261024.py')
W=Path('/workspace/launch_cold105_source_retirement_20261024.py')
PIN='3ddab4af2f51aa3546558e409b2af8279b647ebaa84de928dd6a5a75de99f1b9'
WPIN='c829c127ad6797d1cd69ba3e3501ae1b7649e8260a99a8da3faea2842ed62787'
C=[]
def need(v,s):C.append({'check':s,'passed':bool(v)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
need(sha(P)==PIN and sha(W)==WPIN,'final executor and original-capture wrapper exact pins')
t=P.read_text();w=W.read_text();tree=ast.parse(t);ast.parse(w)
need(True,'both tools parse without import/execution')
prior=O/'COLD105_METADATA_PLAN_STATIC_PEER.json';j=json.loads(prior.read_text())
need(sha(prior)=='5714a6fb54b56938051a652a6613750087142279b18f81f45e038752be155e07' and j['exit_code']==0 and not j['findings'],'prior 438/0 exact metadata plan review retained')
need("PIN='0af31de0299cf6611bd22ab5172c8d454de56e4e20c02ba8eaf32ccd79004cea'" in t,'fixed exact105 PLAN')
need("len(rows)==105 and len(roots)==7" in t and "sum(r['allocated'] for r in rows)==54906880" in t,'fixed105/7/count/gross scope')
need('add_mutually_exclusive_group(required=True)' in t and "group.add_argument('--prepare'" in t and "group.add_argument('--execute'" in t,'two explicit mutually-exclusive phases')
need('assert not out.exists();out.mkdir()' in t,'fresh OUT prevents silently reusing old execution')
need("os.open(out.parent,os.O_RDONLY)" in t and t.index('os.open(out.parent,os.O_RDONLY)')<t.index('cap=load_module'),'fresh PREP/EXEC parent directory fsynced before work')
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
def src(name):return ast.get_source_segment(t,functions[name])
f=src('file_bytes')
for token in ["p==Path(r['repo'])/r['relative']", "p.is_relative_to('/workspace/geo261-cold')", 'p.resolve(strict=True)==p', 'for parent in p.parents:assert not parent.is_symlink()', 'stat.S_ISREG(s.st_mode)', "r['inode'],1,r['bytes'],r['mtime_ns'],r['mode'],r['allocated']", "r['git_blob']"]:
 need(token in f,'fresh file guard '+token)
need(all(repr(s) in f for s in ['evidence','receipt','fixture','snapshot','golden','expected','/sources/','/raw/','/compiler/','.git','mutant','counterfactual','withdrawn']),'all protected classes excluded')
need("hashlib.sha1(b'blob '+str(len(b)).encode()+b'\\0'+b).hexdigest()==r['git_blob']" in f,'fresh full Git blob hash, not only stored metadata')
identity=src('identity')
need("git(root,'rev-parse','HEAD')" in identity and "merge-base','--is-ancestor'" in identity and "cwd='/workspace/geometry-axiom'" in identity,'exact owner heads and published-main ancestry in root repository')
need("assert tree==selected" in identity and "index_sha256=sha(index.read_bytes())" in identity,'selected Git tree and complete original index identity guarded')
need("len(b)==a['bytes'] and sha(b)==a['sha256']" in src('terminal'),'original terminal anchors full byte hash')
con=Path('/workspace/clear_terminal_chrome_caches.py');ct=con.read_text()
need(sha(con)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','known original consumer guard pin')
need("if __name__ == '__main__':\n    main()" in ct and 'con.consumer_check(list(roots))' in src('consume'),'imports consumer only; original cleanup main not invoked')
need("consume('before-consumers')" in t and "consume('immediate-before-consumers')" in t and "assert not hits, hits" in ct,'two original accessible-process consumer guards; unreadable-process limitation retained')
need("len(payloads)==16 and sum(map(len,payloads.values()))==14822323" in t,'16 exact deduplicated payloads / 14,822,323 bytes required')
need("tar.extractfile('payloads/'+h).read()==b" in t and "tar.extractfile('original-metadata/PLAN.json').read()==PLAN.read_bytes()" in t,'prepare original source and mapping full byte roundtrip')
sync=src('sync_preserved_payloads')
need('for p in (archive,prepared)' in sync and 'os.fsync(fd)' in sync and 'os.open(PREP,os.O_RDONLY)' in sync,'archive, PREPARED and containing directory durable')
need(t.count('sync_preserved_payloads(')==3,'both prepare and execute call durable-preservation guard')
need("prepared['identities']==before" in t and "sha(archive.read_bytes())==prepared['archive_sha256']" in t and "sha(file_bytes(r))==prepared['path_sha256'][r['path']]" in t,'execute freshly verifies preparation identities and all source bodies/archive')
need("sha(tar.extractfile('payloads/'+h).read())==h" in t,'execute independently verifies retained payload bytes')
need(t.index('sync_preserved_payloads(archive,p)')<t.index('p.unlink()'),'preservation durable before any unlink')
need("with journal.open('x') as f:" in t and "os.open(out,os.O_RDONLY)" in t and t.index('os.open(out,os.O_RDONLY)')<t.index('p.unlink()'),'fresh retirement journal directory entry durable before unlink')
need("stage='verified-before-unlink'" in t and "f.flush();os.fsync(f.fileno())" in t and t.index("stage='verified-before-unlink'")<t.index('p.unlink()'),'per-path before row durable before unlink')
need('p.unlink();fd=os.open(p.parent,os.O_RDONLY)' in t and "stage='source-materialization-retired'" in t,'unlink only exact reviewed source and fsync source directory then after journal')
unlinks=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['unlink','rmdir','rmtree','remove']]
need(len(unlinks)==1 and isinstance(unlinks[0].func.value,ast.Name) and unlinks[0].func.value.id=='p','one narrow unlink site; no recursive deletion')
need("assert len(result['removed'])==105" in t and 'terminal();assert identity()==before' in t,'postconditions preserve terminal/Git/index identities')
need("except BaseException as e:" in t and "result['error']=repr(e);raise" in t and "dump(out/'RESULT.json',result)" in t,'failures preserved with true nonzero exception and final RESULT')
need(PIN in w and "c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762" in w,'outer exact tool/capture pins')
need("[sys.executable,'-B',str(tool),'--'+a.phase]" in w and 'timeout=None,check=False' in w and "sys.exit(result['actual_exit'])" in w,'outer exact phase, complete c387 streams, no extra timeout, true process exit')
need("historical105-source-maintenance-not-product-acceptance" in w and 'not product acceptance at main' in w,'published-main ancestry reference not falsely a product execution SHA')
need(P.with_name(P.name+'.before-durable-preservation.txt').exists() and P.with_name(P.name+'.before-durable-directory-entries.txt').exists(),'both initial durability gaps retained as original drafts')
findings=[x['check'] for x in C if not x['passed']]
r={'scope':'Static exact105 source-copy maintenance executor/outer review only','checks':len(C),'exit_code':int(bool(findings)),'findings':findings,'executor':{'path':str(P),'sha256':PIN},'outer':{'path':str(W),'sha256':WPIN},'resolved_findings':['Initial archive/PREPARED close was not a durable backup barrier; final fsyncs both files and directory in both phases.','New output and journal directory entries now fsynced before any source unlink.'],'conditions':['Root grants performance exclusion before --prepare body hashing/archive.','Only root or explicitly delegated storage executes; reviewer has executed neither phase.','Require true prepare0 plus original archive retention before execute; actual105 removal and free-space effect remain UNRUN.','Original inaccessible process limitation is preserved; no blanket assertion of inspecting every OS process.'],'check_details':C}
dest=O/'COLD105_EXECUTOR_STATIC_PEER.json';dest.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(dest),'sha256':sha(dest),'checks':len(C),'exit_code':r['exit_code'],'findings':findings},ensure_ascii=False));raise SystemExit(r['exit_code'])
