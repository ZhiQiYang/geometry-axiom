"""Cross-check terminal preserving-link journals and metadata; never rehash archive bodies."""
from pathlib import Path
import hashlib,json,os
REPORT=Path('/workspace/THREE_EMERGENCY_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')
CASES=[('three-emergency','/workspace/three-emergency-terminal-archives-preparation-20261024','/workspace/three-emergency-terminal-archive-groups-preserving-links-execution-20261024','/workspace/three-emergency-terminal-archive-groups-preserving-links-launch-20261024',[7,7,7],163504128)]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
checks=0
def need(ok):
 global checks
 checks+=1
 assert ok
rows=[]
for label,base,raw,outer,counts,saving in CASES:
 b=Path(base);o=Path(raw);a=Path(outer);p=read(b/'PLAN.json');r=read(o/'RESULT.json');launch=read(a/'RESULT.json')
 need(r['exit_code']==launch['actual_process_returncode']==0)
 need(r['ended_utc'] and launch['ended_epoch'] and not launch['timeout_expired'])
 need(r['plan_sha256']==h(b/'PLAN.json') and r['core_sha256']==p['core']['sha256'])
 need(r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and r['actual_replacement_performed'])
 need(r['expected_allocated_saving']==saving==p['expected_allocated_saving'])
 groups=p.get('groups',[dict(members=p.get('members',[]))]);need([len(g['members']) for g in groups]==counts)
 for i,g in enumerate(groups,1):
  members=g['members'];n=len(members);canonical=members[0]
  j=o/f'GROUP-{i}.jsonl';events=[json.loads(line) for line in j.read_text().splitlines()]
  need([x['event'] for x in events]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*(n-1)+['complete'])
  need(events[0]['originals']==members and events[-1]['expected_alias_count']==n and events[-1]['bytes_unchanged'])
  for x in events[0]['temporary_paths']:need(not os.path.lexists(x))
  for index in range(1,n):
   triplet=events[1+3*(index-1):1+3*index]
   need(all(x['index']==index for x in triplet));need([x['expected_alias_count'] for x in triplet]==[index,index+1,index+1])
   need(triplet[0]['destination']==members[index]['path'])
  for x in members:
   path=Path(x['path']);s=path.lstat();need(path.resolve(strict=True)==path)
   need((s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns)==(canonical['dev'],canonical['inode'],n,canonical['size'],canonical['mode'],canonical['uid'],canonical['gid'],canonical['mtime_ns']))
  rows.append(dict(case=label,group=i,count=n,journal=str(j),journal_sha256=h(j),all_named_paths_retained_current_metadata=True,archive_sha256_from_original_fresh_executor=canonical['sha256']))
 for x in p['anchors']:need(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'])
 consumers=sorted(o.glob('consumers-*/CONSUMERS.json'));need(len(consumers)==r['consumer_checks']==1+sum(n-1 for n in counts))
 for q in consumers:
  d=read(q);need(not d['hits']);need(bool(d['limitation']))
 for root in [o/'git-originals',a]:
  for row in read(root/'subcommands.json'):
   q=Path(row['directory']);need(read(q/'result.json')==row)
   need(row['actual_process_returncode']==0 and not row['timeout_expired'])
   for kind in ['stdout','stderr']:
    f=q/(kind+'.bin');need(f.stat().st_size==row[kind+'_bytes'] and h(f)==row[kind+'_sha256'])
   f=q/'stdin.bin';need(h(f)==row['stdin_sha256'])
report=dict(exit_code=0,findings=[],checks=checks,groups=rows,total_groups=3,total_named_paths=21,
            configured_gross_source_block_saving=163504128,
            separate_reservations=['423 previous sealed cold receipt groups','2 previous cardref ELF groups','1 previous GEO339 archive/stream group','3 previous large historical archive groups','4 previous additional large historical archive groups','3 emergency archive groups'],
            limits=['Metadata and full small command streams only; no second archive-payload hash claimed. Original executors already performed fresh full-byte and Git checks.','All archive/stream paths and complete bytes remain. Inode/nlink and noncanonical timestamps intentionally change as disclosed.','Source block allocation sum is distinct from net/global filesystem free-space changes.','Inaccessible OS process descriptors retain the original consumer-check visibility limitation.','Historical failed receipts remain failed; this is not product acceptance.'])
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(report=str(REPORT),sha256=h(REPORT),checks=checks,exit_code=0)))
