from pathlib import Path
import hashlib,json,os,stat
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/workspace/two-prer5-terminal-archives-preparation-20261024');R=Path('/workspace/two-prer5-terminal-archive-groups-preserving-links-execution-20261024');A=Path('/workspace/two-prer5-terminal-archive-groups-preserving-links-launch-20261024');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json');owner=j('/workspace/EMERGENCY_FIVE_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')
ck(h('/workspace/EMERGENCY_FIVE_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')=='ab0997d9ab21ad8d4b2e29608a0de6d7e9744b1e970162ff5ab1704e304a0acd' and owner['exit_code']==0 and not owner['findings'] and owner['checks']==1500,'original four-group owner report')
ck(h(B/'PLAN.json')==r['plan_sha256']=='1691a39d62d16b12a65b1af3299b34ca0786576ec615e9f7e610843dd043f225' and r['core_sha256']==h(B/'exact_large_archive_group_link_core.py'),'reviewed exact PLAN/core execution')
ck(r['exit_code']==a['actual_process_returncode']==0 and r['ended_utc'] and a['ended_epoch'] and not a['timeout_expired'],'actual terminal inner and outer0')
ck(r['actual_replacement_performed'] and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'],'all paths and receipt bytes reported retained')
ck(r['expected_allocated_saving']==78667776 and [g['count'] for g in r['groups']]==[7,7],'three exact final groups/configured saving')
for index,g in enumerate(p['groups'],1):
 members=g['members'];n=len(members);can=members[0];events=[json.loads(x) for x in (R/f'GROUP-{index}.jsonl').read_text().splitlines()]
 ck([x['event'] for x in events]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*(n-1)+['complete'],'complete original atomic journal '+str(index))
 ck(events[0]['originals']==members and events[-1]['expected_alias_count']==n and events[-1]['bytes_unchanged'] and events[-1]['all_original_paths_present'],'journal exact originals and terminal '+str(index))
 ck(all(not os.path.lexists(x) for x in events[0]['temporary_paths']),'no residual temp aliases '+str(index))
 for i in range(1,n):
  t=events[1+3*(i-1):1+3*i];ck(all(x['index']==i for x in t) and [x['expected_alias_count'] for x in t]==[i,i+1,i+1] and t[0]['destination']==members[i]['path'],'ordered atomic transition '+str(index)+'/'+str(i))
 for m in members:
  q=Path(m['path']);s=q.lstat();ck(stat.S_ISREG(s.st_mode) and q.resolve()==q,'current regular retained path '+str(q))
  ck((s.st_dev,s.st_ino,s.st_nlink,s.st_mode,s.st_size,s.st_uid,s.st_gid,s.st_mtime_ns)==(can['dev'],can['inode'],n,can['mode'],can['size'],can['uid'],can['gid'],can['mtime_ns']),'current exact canonical identity '+str(q))
for x in p['anchors']:ck(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'],'small receipt anchor unchanged '+x['path'])
for x in p['terminal_rows']:ck(j(x['path'])==x['original_rows'],'original historical outcomes unchanged '+x['path'])
cons=sorted(R.glob('consumers-*/CONSUMERS.json'));ck(len(cons)==r['consumer_checks']==13,'13 original fresh consumers')
for q in cons:
 d=j(q);ck(not d['hits'] and bool(d['limitation']),'original consumer no visible hits; visibility limit retained '+str(q))
expected=[]
for owner0 in p['owners']:expected.append((owner0['root'],['git','rev-parse','HEAD'],owner0['head']))
for g in p['groups']:
 for m in g['members']:
  expected.extend([(m['owner_root'],['git','ls-tree',m['owner_head'],'--',m['git_path']],f"100644 blob {m['git_blob']}\t{m['git_path']}"),(m['owner_root'],['git','cat-file','-s',m['git_blob']],str(m['size'])),(m['owner_root'],['git','hash-object',m['path']],m['git_blob'])])
rows=j(R/'git-originals/subcommands.json');ck(len(rows)==98,'49 exact pre and49 post Git commands')
for row,(cwd,argv,out) in zip(rows,expected+expected):
 d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and (d/'stdout.bin').read_text().strip()==out and row['stderr_bytes']==0,'exact before/after original Git '+str(d))
for source in [R/'git-originals',A]:
 ledger=j(source/'subcommands.json')
 for row in ledger:
  d=Path(row['directory']);ck(j(d/'result.json')==row and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'],'original capture exit/time '+str(d))
  ck(bool(j(d/'request.json')) and h(d/'stdin.bin')==row['stdin_sha256'],'original request/stdin '+str(d))
  for stream in ['stdout','stderr']:
   q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'full original small stream '+str(q))
ck(a==j(A/'subcommands.json')[-1],'outer RESULT is actual captured original row')
ck('every alias is de-linked' in r['reservation'] and 'separate from423' in r['reservation'] and 'truncated' in r['excluded_reason'],'independent3groups lease and F2 exclusion retained')
helper=Path('/workspace/review_emergency_five_archive_groups_actual_metadata_20261024.py').read_text()
ck('for x in p[\'anchors\']' in helper and "for root in [o/'git-originals',a]" in helper and "h(x['path'])" in helper and "archive_sha256_from_original_fresh_executor=canonical['sha256']" in helper,'owner helper hashes small anchors/streams; labels archive hashes as inherited original')

old_path=Path('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py')
new_path=B/'link_exact_two_prer5_terminal_archive_groups.py'
expected=old_path.read_text().replace('three frozen immutable archive groups','two pre-R5 frozen immutable archive groups').replace('three-large-terminal','two-prer5-terminal').replace('7cbeec8b3c36f77dde886ef4e482ed6cfaf621a2e99ae734cb6bb11f174eb375','1691a39d62d16b12a65b1af3299b34ca0786576ec615e9f7e610843dd043f225').replace('[7,4,2]','[7,7]').replace("p['target_count']==13","p['target_count']==14").replace('452947968','78667776').replace("g['members']})==13","g['members']})==14")
ck(expected==new_path.read_text(),'entire executor identical after exact scope literal substitutions')
ck(h(new_path)=='3aebfecd862f1a26e37a8e93482dac687d096943d6cecef4b4b00e8640b5503d','exact executor pin')
ck(h(B/'exact_large_archive_group_link_core.py')=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','original core exact bytes')
ck([g['sha256'] for g in p['groups']]==['72fc05df87dd70ee74182b19bfcf56a66d0403c102116bcdc71bde30abeee53e','783531b8a8331593c8561383a14f522a626482263e9756be47dc7c3f066cd952'],'exact two archive identities')
ck([g['members'][0]['git_path'] for g in p['groups']]==['tests/release-evidence/20261008-card-wait/geometry-card-wait-evidence-b822a9ff.tar.gz','evidence/geo261-final-08dede0b/raw/architecture-refresh.raw.tar.gz'],'two exact archive paths')
ck(len({m['path'] for g in p['groups'] for m in g['members']})==14,'only14 exact named paths')
import ast
def body(path):return ast.dump(next(x for x in ast.parse(Path(path).read_text()).body if isinstance(x,ast.For)),include_attributes=False)
ck(body('/workspace/review_emergency_five_archive_groups_actual_metadata_20261024.py')==body('/workspace/review_three_emergency_archive_groups_actual_metadata_20261024.py'),'owner actual helper exact original per-case AST')

result={'schema':'two-prer5-archive-groups-static-and-actual-metadata-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'actual_result_sha256':h(R/'RESULT.json'),'actual_outer_sha256':h(A/'RESULT.json'),'owner_report_sha256':h('/workspace/EMERGENCY_FIVE_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json'),'owner_helper_sha256':h('/workspace/review_emergency_five_archive_groups_actual_metadata_20261024.py'),'counts':[7,7],'original_git_commands':98,'consumer_checks':13,'expected_allocated_saving':78667776,'free_before':r['free_before'],'free_after':r['free_after'],'limits':['Only actual two pre-R5 groups independently examined here; emergency three groups already independently reviewed separately.','No second archive body hashing; original full-byte executor checks and current metadata/journal/Git complete small streams examined.','Configured saving distinct from original df delta; all14 original paths retained with changed canonical identity as disclosed.','423cold+2cardref+1geo339+3large+4additional+3emergency+2prer5 reservations remain separate; no immutable alias may be reused before every alias is delinked.','Historical product failures unchanged; this is storage maintenance, not product acceptance.']}
q=O/'TWO_PRER5_ARCHIVE_GROUPS_STATIC_ACTUAL_METADATA_PEER.json';q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':result['exit_code'],'findings':find}));raise SystemExit(result['exit_code'])
