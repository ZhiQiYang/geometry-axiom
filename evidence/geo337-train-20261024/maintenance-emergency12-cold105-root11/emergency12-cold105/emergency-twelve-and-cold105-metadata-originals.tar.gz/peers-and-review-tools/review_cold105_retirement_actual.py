from pathlib import Path
import hashlib,json,os,tarfile
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/workspace/cold105-source-retirement-metadata-20261024');P=Path('/workspace/cold105-source-retirement-body-preparation-20261024');E=Path('/workspace/cold105-source-retirement-execution-20261024');checks=0;findings=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(Path(p).read_bytes())
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:findings.append(n)
plan=j(B/'PLAN.json');prep=j(P/'PREPARED.json');pr=j(P/'RESULT.json');er=j(E/'RESULT.json')
ck(h(B/'PLAN.json')==prep['plan_sha256']==pr['plan_sha256']==er['plan_sha256']=='0af31de0299cf6611bd22ab5172c8d454de56e4e20c02ba8eaf32ccd79004cea','exact reviewed105 plan')
ck(h('/workspace/retire_exact_cold105_source_copies_20261024.py')=='3ddab4af2f51aa3546558e409b2af8279b647ebaa84de928dd6a5a75de99f1b9' and h('/workspace/launch_cold105_source_retirement_20261024.py')=='c829c127ad6797d1cd69ba3e3501ae1b7649e8260a99a8da3faea2842ed62787','original reviewed durable executor and outer unchanged')
ck(pr['mode']=='prepare' and er['mode']=='execute' and pr['exit_code']==er['exit_code']==0 and pr['ended_utc']<=er['started_utc']<er['ended_utc'],'true ordered prepare0 then execute0')
ck(pr['prepared']==prep and pr['removed']==[] and h(P/'PREPARED.json')==er['prepared_sha256'],'immutable prepared result links into actual execution')
rows=plan['rows'];ck(len(rows)==len({r['path'] for r in rows})==prep['files']==105 and len(plan['owners'])==7,'exact105 paths seven owners')
ck(set(prep['path_sha256'])=={r['path'] for r in rows} and len(set(prep['path_sha256'].values()))==prep['unique_payloads']==16,'exact105-to16 preserved payload mapping')
ck(prep['full_byte_roundtrip'] and not prep['cleanup_executed'] and er['original_payloads_remain'] and er['git_and_terminal_identities_unchanged'],'preserve-before-retire true original claims')
archive=Path(prep['archive']);ck(archive.stat().st_size==prep['archive_bytes']==2849441 and h(archive)==prep['archive_sha256']==er['original_source_archive_sha256']=='9daa4fc1743fe2c864740dfeb679170da2adaa851a25b471f00e176b7f00c340','actual preservation archive exact compressed bytes/hash')
payloads={};total=0
with tarfile.open(archive) as tf:
 members=tf.getmembers();ck(len(members)==17 and len({m.name for m in members})==17 and all(m.isfile() for m in members),'17 unique regular archive members')
 for m in members:
  raw=tf.extractfile(m).read();ck(len(raw)==m.size,'actual payload length '+m.name)
  if m.name=='original-metadata/PLAN.json':ck(raw==(B/'PLAN.json').read_bytes(),'complete original exact PLAN bytes preserved')
  else:
   ck(m.name=='payloads/'+sha(raw) and m.mode==0o444,'preserved payload exact content address and mode');payloads[sha(raw)]=(len(raw),hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest());total+=len(raw)
ck(total==prep['unique_payload_bytes']==14822323 and set(payloads)==set(prep['path_sha256'].values()),'all16 payloads logical bytes and complete path mapping')
events=[json.loads(line) for line in (E/'RETIREMENT.jsonl').read_text().splitlines()];ck(len(events)==210,'each105 has durable before/after journal rows')
for i,r in enumerate(rows):
 path=Path(r['path']);ph=prep['path_sha256'][str(path)];size,blob=payloads[ph]
 ck(size==r['bytes'] and blob==r['git_blob'],'preserved bytes rebuild exact original Git blob '+str(path))
 ck(path==Path(r['repo'])/r['relative'] and r['repo'] in plan['owners'] and r['head']==plan['owners'][r['repo']],'exact path owner identity '+str(path))
 ck(not any(x in r['relative'].lower() for x in ['evidence','receipt','fixture','snapshot','golden','expected','/sources/','/raw/','/compiler/','.git','mutant','counterfactual','withdrawn']),'only allowed ordinary source '+r['relative'])
 ck(not os.path.lexists(path),'exact original materialization absent after retention '+str(path))
 before=dict(index=i,stage='verified-before-unlink',path=str(path),git_blob=r['git_blob'],sha256=ph,bytes=r['bytes'],allocated=r['allocated'])
 ck(events[2*i]==before and events[2*i+1]==dict(before,stage='source-materialization-retired'),'exact ordered durable pair '+str(i))
ck(er['removed']==[r['path'] for r in rows] and er['gross_allocated_bytes_eligible']==er['gross_allocated_bytes_retired']==sum(r['allocated'] for r in rows)==54906880,'exact removed list and configured gross separate fromdf')
for a in plan['anchors']:ck(Path(a['path']).stat().st_size==a['bytes'] and h(a['path'])==a['sha256'],'historical terminal anchor unchanged '+a['path'])
for root,num in [(P,1),(E,2)]:
 consumers=list(root.glob('*consumers/CONSUMERS.json'));ck(len(consumers)==num,'original consumer count '+str(root))
 for q in consumers:
  d=j(q);ck(not d['hits'] and bool(d['limitation']),'original no-visible-consumer and retained limitation '+str(q))
git_counts={};outer_pins={}
for root,count in [(P,56),(E,84),(Path('/workspace/cold105-source-retirement-prepare-launch-20261024'),1),(Path('/workspace/cold105-source-retirement-execute-launch-20261024'),1)]:
 ledger=j(root/'subcommands.json');git_counts[str(root)]=len(ledger);ck(len(ledger)==count,'exact original command count '+str(root))
 for row in ledger:
  d=Path(row['directory']);ck(j(d/'result.json')==row and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'],'original capture terminal0 '+str(d))
  ck(j(d/'request.json')['command']==row['command'],'original argv '+str(d))
  for stream in ['stdin','stdout','stderr']:
   raw=(d/(stream+'.bin')).read_bytes();ck(sha(raw)==row[stream+'_sha256'],'full original stream '+str(d)+'/'+stream)
   if stream!='stdin':ck(len(raw)==row[stream+'_bytes'],'original stream bytes '+str(d)+'/'+stream)
 if root in [P,E]:
  expected=[]
  for owner,head in plan['owners'].items():
   selected=sorted(r['relative'] for r in rows if r['repo']==owner)
   expected += [(['git','-c','gc.auto=0','rev-parse','HEAD'],owner),(['git','-c','gc.auto=0','merge-base','--is-ancestor',head,plan['published_main']],'/workspace/geometry-axiom'),(['git','-c','gc.auto=0','ls-tree','-z',head,'--',*selected],owner),(['git','-c','gc.auto=0','rev-parse','--git-path','index'],owner)]
  ck([(r['command'],r['cwd']) for r in ledger]==expected*(count//28),'exact before/intermediate/after identity commands '+str(root))
  for start in range(0,count,28):
   for n,(owner,head) in enumerate(plan['owners'].items()):
    subset=ledger[start+n*4:start+n*4+4];stdout=lambda row:(Path(row['directory'])/'stdout.bin').read_bytes()
    ck(stdout(subset[0]).decode().strip()==head and stdout(subset[1])==b'','actual ownerHEAD/publicmain ancestry '+owner)
    actual={}
    for entry in stdout(subset[2]).split(b'\0'):
     if entry:
      md,name=entry.split(b'\t',1);mode,kind,oid=md.decode().split();actual[name.decode()]=(mode,kind,oid)
    ck(actual=={r['relative']:(r['index_mode'],'blob',r['git_blob']) for r in rows if r['repo']==owner},'all exact15 original tree blob identities '+owner)
 else:
  outer=j(root/'RESULT.json');ck(outer['command']==ledger[-1] and outer['actual_exit']==ledger[-1]['actual_process_returncode']==0 and outer['phase'] in ['prepare','execute'],'outerRESULT binds true original OSexit row');outer_pins[str(root)]=h(root/'RESULT.json')
result={'schema':'cold105-retirement-preservation-actual-peer/1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'plan_sha256':h(B/'PLAN.json'),'prepared_sha256':h(P/'PREPARED.json'),'execution_result_sha256':h(E/'RESULT.json'),'archive_sha256':h(archive),'archive_bytes':archive.stat().st_size,'unique_payloads':16,'unique_payload_bytes':total,'exact_materializations_retired':105,'journal_rows':210,'original_command_counts':git_counts,'outer_result_sha256':outer_pins,'gross_allocated_bytes':54906880,'actual_free_before':er['free_before'],'actual_free_after':er['free_after'],'limits':['Only105 explicitly selected ordinary source materializations retired after durable unique-payload preservation; no receipt/fixture/Git objects/archive aliases deleted.','Preserved16 payloads independently read and bound to all105 original Git blob IDs; original removed source bodies were not reconstructed or read from absent paths.','Original140 read-only Git identity commands and two original outer commands checked; no new network/Git calls. Current large Git indices not rehashed; original pinned executor checked unchanged index hashes before/after.','Consumer no-hit subject to original OS visibility limitation; seven cold roots and their independent archive alias write bans remain.','No C/performance or acceptance rerun. Gross allocated retirement and globaldf difference remain distinct.']}
q=O/'COLD105_RETIREMENT_ACTUAL_PEER.json';q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':result['exit_code'],'findings':findings}));raise SystemExit(result['exit_code'])
