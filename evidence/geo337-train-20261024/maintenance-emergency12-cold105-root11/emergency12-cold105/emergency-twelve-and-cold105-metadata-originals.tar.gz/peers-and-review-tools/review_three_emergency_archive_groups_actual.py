from pathlib import Path
import hashlib,json,os,stat
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/workspace/three-emergency-terminal-archives-preparation-20261024');R=Path('/workspace/three-emergency-terminal-archive-groups-preserving-links-execution-20261024');A=Path('/workspace/three-emergency-terminal-archive-groups-preserving-links-launch-20261024');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json');owner=j('/workspace/THREE_EMERGENCY_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')
ck(h('/workspace/THREE_EMERGENCY_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')=='e4aa3cd6320ef2d304cb023865916dff73752d39e73dd5dcdc7196c049e841a9' and owner['exit_code']==0 and not owner['findings'] and owner['checks']==881,'original four-group owner report')
ck(h(B/'PLAN.json')==r['plan_sha256']=='b7c67e70991dd0a2368e4a8bb3ba83047f4925f410136efacfad56e2d67b836a' and r['core_sha256']==h(B/'exact_large_archive_group_link_core.py'),'reviewed exact PLAN/core execution')
ck(r['exit_code']==a['actual_process_returncode']==0 and r['ended_utc'] and a['ended_epoch'] and not a['timeout_expired'],'actual terminal inner and outer0')
ck(r['actual_replacement_performed'] and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'],'all paths and receipt bytes reported retained')
ck(r['expected_allocated_saving']==163504128 and [g['count'] for g in r['groups']]==[7,7,7],'three exact final groups/configured saving')
for index,g in enumerate(p['groups'],1):
 members=g['members'];n=len(members);can=members[0];events=[json.loads(x) for x in (R/f'GROUP-{index}.jsonl').read_text().splitlines()]
 ck([x['event'] for x in events]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*(n-1)+['complete'],'complete original atomic journal '+str(index))
 ck(events[0]['originals']==members and events[-1]['expected_alias_count']==n and events[-1]['bytes_unchanged'] and events[-1]['all_original_paths_present'],'journal exact originals and terminal '+str(index))
 ck(all(not os.path.lexists(x) for x in events[0]['temporary_paths']),'no residual temp aliases '+str(index))
 for i in range(1,n):
  t=events[1+3*(i-1):1+3*i];ck(all(x['index']==i for x in t) and [x['expected_alias_count'] for x in t]==[i,i+1,i+1] and t[0]['destination']==members[i]['path'],'ordered atomic transition '+str(index)+'/'+str(i))
 for m in members:
  q=Path(m['path']);s=q.lstat();ck(stat.S_ISREG(s.st_mode) and q.resolve()==q,'current regular retained path '+str(q))
  ck((s.st_dev,s.st_ino,s.st_nlink,s.st_mode,s.st_size,s.st_uid,s.st_gid,s.st_mtime_ns)==(can['dev'],can['inode'],n,can['mode'],can['size'],can['uid'],can['gid'],can['mtime_ns']),'current exact canonical identity '+str(q))
for x in p['anchors']:ck(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'],'small receipt anchor unchanged '+x['path'])
for x in p['terminal_rows']:ck(j(x['path'])==x['original_rows'],'original historical outcomes unchanged '+x['path'])
cons=sorted(R.glob('consumers-*/CONSUMERS.json'));ck(len(cons)==r['consumer_checks']==19,'19 original fresh consumers')
for q in cons:
 d=j(q);ck(not d['hits'] and bool(d['limitation']),'original consumer no visible hits; visibility limit retained '+str(q))
expected=[]
for owner0 in p['owners']:expected.append((owner0['root'],['git','rev-parse','HEAD'],owner0['head']))
for g in p['groups']:
 for m in g['members']:
  expected.extend([(m['owner_root'],['git','ls-tree',m['owner_head'],'--',m['git_path']],f"100644 blob {m['git_blob']}\t{m['git_path']}"),(m['owner_root'],['git','cat-file','-s',m['git_blob']],str(m['size'])),(m['owner_root'],['git','hash-object',m['path']],m['git_blob'])])
rows=j(R/'git-originals/subcommands.json');ck(len(rows)==140,'70 exact pre and70 post Git commands')
for row,(cwd,argv,out) in zip(rows,expected+expected):
 d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and (d/'stdout.bin').read_text().strip()==out and row['stderr_bytes']==0,'exact before/after original Git '+str(d))
for source in [R/'git-originals',A]:
 ledger=j(source/'subcommands.json')
 for row in ledger:
  d=Path(row['directory']);ck(j(d/'result.json')==row and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'],'original capture exit/time '+str(d))
  ck(bool(j(d/'request.json')) and h(d/'stdin.bin')==row['stdin_sha256'],'original request/stdin '+str(d))
  for stream in ['stdout','stderr']:
   q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'full original small stream '+str(q))
ck(a==j(A/'subcommands.json')[-1],'outer RESULT is actual captured original row')
ck('every alias is de-linked' in r['reservation'] and 'separate from423' in r['reservation'] and 'truncated' in r['excluded_reason'],'independent3groups lease and F2 exclusion retained')
helper=Path('/workspace/review_three_emergency_archive_groups_actual_metadata_20261024.py').read_text()
ck('for x in p[\'anchors\']' in helper and "for root in [o/'git-originals',a]" in helper and "h(x['path'])" in helper and "archive_sha256_from_original_fresh_executor=canonical['sha256']" in helper,'owner helper hashes small anchors/streams; labels archive hashes as inherited original')

old_path=Path('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py')
new_path=B/'link_exact_three_emergency_terminal_archive_groups.py'
expected=old_path.read_text().replace('three frozen immutable archive groups','three emergency frozen immutable archive groups').replace('three-large-terminal','three-emergency-terminal').replace('7cbeec8b3c36f77dde886ef4e482ed6cfaf621a2e99ae734cb6bb11f174eb375','b7c67e70991dd0a2368e4a8bb3ba83047f4925f410136efacfad56e2d67b836a').replace('[7,4,2]','[7,7,7]').replace("p['target_count']==13","p['target_count']==21").replace('452947968','163504128').replace("g['members']})==13","g['members']})==21")
ck(expected==new_path.read_text(),'entire executor identical after exact scope literal substitutions')
ck(h(new_path)=='bb2d41274cd380b6cc419e03be5463e0dffb87e6a925375c5959ac9dda33bfdf','exact executor pin')
ck(h(B/'exact_large_archive_group_link_core.py')=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','original core exact bytes')
ck([g['sha256'] for g in p['groups']]==['654b58e50d0eb8a56280e6ea38a26a0be57a6c8fff4016536269859deee7c5c0','194d9da2baf39905e8009203c75997164cb6e55cf3fc5fc205cc040449a390aa','9eaf579b8f520df5107aa1747dbf4ea85e58234cd4742bf866e4bd3492e9a247'],'exact three archive identities')
ck([g['members'][0]['git_path'] for g in p['groups']]==['tests/evidence/pf2-b1-bands-20261014/core-mutants-raw.tar.gz','tests/evidence/201-main-pf2-integration-20261014/executed-sources.tar.gz','tests/evidence/201-p104-wsl-budgets-20261014/executed-sources.tar.gz'],'three exact archive paths')
ck(len({m['path'] for g in p['groups'] for m in g['members']})==21,'only21 exact named paths')

result={'schema':'three-emergency-archive-groups-static-and-actual-metadata-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'actual_result_sha256':h(R/'RESULT.json'),'actual_outer_sha256':h(A/'RESULT.json'),'owner_report_sha256':h('/workspace/THREE_EMERGENCY_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json'),'owner_helper_sha256':h('/workspace/review_three_emergency_archive_groups_actual_metadata_20261024.py'),'counts':[7,7,7],'original_git_commands':140,'consumer_checks':19,'expected_allocated_saving':163504128,'free_before':r['free_before'],'free_after':r['free_after'],'limits':['Only the three emergency groups examined here; previous groups keep separate reservations and receipts.','No second archive body hashing; original full-byte executor checks and current metadata/journal/Git complete small streams examined.','Configured saving distinct from original df delta; all21 original paths retained with changed canonical identity as disclosed.','423cold+2cardref+1geo339+3large+4additional+3emergency reservations remain separate; no immutable alias may be reused before every alias is delinked.','Historical product failures unchanged; this is storage maintenance, not product acceptance.']}
q=O/'THREE_EMERGENCY_ARCHIVE_GROUPS_STATIC_ACTUAL_METADATA_PEER.json';q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':result['exit_code'],'findings':find}));raise SystemExit(result['exit_code'])
