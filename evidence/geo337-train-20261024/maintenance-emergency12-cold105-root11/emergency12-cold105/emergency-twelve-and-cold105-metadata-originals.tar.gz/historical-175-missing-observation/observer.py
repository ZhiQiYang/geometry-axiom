"""Exact terminal L executable-cache candidates; preserve source, sidecars and receipts."""
from pathlib import Path
import hashlib,json,os,stat,datetime
B=Path('/workspace/L175-elf-retirement-preparation-20261024');assert not B.exists();B.mkdir()
R=Path('/workspace/train337-ledger-L-7af8c5d8/receipt.json');r=json.loads(R.read_text());assert r['sourceSHA']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db' and r['passed'] and r['exit_code']==r['original_cli_exit']==0 and r['ledger_count']==123
BASE=Path('/workspace/train337-ledger-cache-L-7af8c5d8')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={x['path']:x for x in r['new_reused_artifacts']};rows=[]
for move in r['core_cache_moves']+r['bridge_cache_moves']:
 for old in move['files']:
  if old['name'].endswith('.json'):continue
  p=Path(move['to'])/old['name'];assert p.is_relative_to(BASE) and p.name in ['baseline.exe','_mut.exe','bridge'] and p.resolve()==p
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_mode)==(old['device'],old['inode'],old['bytes'],old['mtime_ns'],old['mode'])
  original=records[str(p)];assert original['sha256']==old['sha256'] and original['bytes']==s.st_size
  side=Path(str(p)+'.fingerprint.json');sv=json.loads(side.read_text());assert sv['exe_sha256']==old['sha256'] and h(side)==records[str(side)]['sha256']
  rows.append(dict(path=str(p),kind=move['kind'],bytes=s.st_size,sha256_from_original_terminal_receipt=old['sha256'],device=s.st_dev,inode=s.st_ino,mode=s.st_mode,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated=s.st_blocks*512,sidecar=str(side),sidecar_sha256=h(side),original_compile_locator=str(side),sidecar_retained=True))
assert len(rows)==175 and len({x['path'] for x in rows})==175
G=Path('/workspace/clear_terminal_chrome_caches.py');assert h(G)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
ns={'__name__':'_consumer_only','__file__':str(G)};exec(compile(G.read_bytes(),str(G),'exec'),ns);d=B/'consumers';d.mkdir();ns['OUT']=d;ns['consumer_check']([str(BASE)])
inputs=[R,Path('/workspace/train337-ledger-L-7af8c5d8/ARTIFACT_PAIR_RELOCATION.json'),Path('/workspace/train337-ledger-L-7af8c5d8/full-launch-request.json'),Path('/workspace/train337-ledger-L-7af8c5d8/CORE_RAW_MAPPING.json'),Path('/workspace/train337-ledger-L-7af8c5d8/BRIDGE_RAW_INVENTORY.json'),Path('/tmp/train337-ledger-L-prep/run_root_full_ledger_at_L.py')]
anchors=[dict(path=str(p),bytes=p.stat().st_size,sha256=h(p)) for p in inputs]
result=dict(schema='terminal-L175-rebuildable-ELF-retirement-plan/1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha=r['sourceSHA'],source_public_url='https://github.com/ZhiQiYang/geometry-axiom/commit/'+r['sourceSHA'],original_ledger=dict(path='/workspace/train337-ledger-L-7af8c5d8/mutants_results.json',sha256=r['ledger_sha256']),source_seed=str(BASE/'_bridge-work'/r['sourceSHA']/'repo'),source_seed_retained_and_readonly=True,terminal_anchors=anchors,entries=rows,count=175,logical_bytes=sum(x['bytes'] for x in rows),allocated_bytes=sum(x['allocated'] for x in rows),consumer_report=str(d/'CONSUMERS.json'),consumer_guard=dict(path=str(G),sha256=h(G)),root_reservation='Root confirms completed L acceptance is sealed and will not be rerun; these175 old executable cache leaves are not authorized for future consumers. All sources, fixtures, Git objects, sidecars, raw outputs and historical receipts remain.',execution_authorized=False,already_retired=False,policy='Only exact175 executable leaves may be retired after root review/fresh guards. Existing historical retained-at-the-time statements remain unchanged; new retirement metadata must explicitly record later disk reclamation. No ELF tar required under current root authorization.',rebuild='Use preserved public L source and tests/mutate.py definitions, original compile/fingerprint metadata and full-launch/reaper/raw mappings; new cache/results paths, never rewrite preserved historical sidecars/receipts. Initial compilation at earlier b6 source with identical closure remains explicit in original receipts.',limitations=['No executable payload reread during metadata preparation; original terminal SHA+current exact inode/mtime/size/mode/nlink and sidecar identity checked.','Visible consumer report is time-specific and incomplete for inaccessible OS process descriptors; fresh guard plus root cache lease required immediately before retirement.'])
(B/'PLAN.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(plan=str(B/'PLAN.json'),sha256=h(B/'PLAN.json'),count=175,logical=result['logical_bytes'],allocated=result['allocated_bytes'],consumer_report=result['consumer_report'])))
