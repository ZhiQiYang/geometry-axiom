"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/emergency-twelve-and-cold105-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 specs=[('three-emergency','/workspace/three-emergency-terminal-archives-preparation-20261024','/workspace/three-emergency-terminal-archive-groups-preserving-links-execution-20261024','/workspace/three-emergency-terminal-archive-groups-preserving-links-launch-20261024'),('two-prer5','/workspace/two-prer5-terminal-archives-preparation-20261024','/workspace/two-prer5-terminal-archive-groups-preserving-links-execution-20261024','/workspace/two-prer5-terminal-archive-groups-preserving-links-launch-20261024'),('seven-postr5','/workspace/seven-postr5-terminal-archives-preparation-20261024','/workspace/seven-postr5-terminal-archive-groups-preserving-links-execution-20261024','/workspace/seven-postr5-terminal-archive-groups-preserving-links-launch-20261024')]
 archive_bodies=set();gross=0;plans=[]
 for label,prep,actual,outer in specs:
  prep,actual,outer=map(Path,(prep,actual,outer));plan=readj(prep/'PLAN.json');r=readj(actual/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and a['actual_process_returncode']==0
  assert not a['timeout_expired'] and r['plan_sha256']==digest(prep/'PLAN.json');plans.append(plan);gross+=plan['expected_allocated_saving']
  members=[x for g in plan['groups'] for x in g['members']]
  archive_bodies.update(x['path'] for x in members)
  tree(prep,'preparation/'+label);tree(actual,'actual/'+label);tree(outer,'launch/'+label)
  for i,x in enumerate(plan['anchors']):
   assert digest(x['path'])==x['sha256']
   add(x['path'],f'anchors/{label}/{i:03d}-'+Path(x['path']).name)
  for key in ['original_core','core','consumer_guard']:
   x=plan[key];assert digest(x['path'])==x['sha256']
 assert gross==365010944
 assert [[len(g['members']) for g in p['groups']] for p in plans]==[[7,7,7],[7,7],[4,7,7,2,2,2,2]]
 assert len(archive_bodies)==61
 for i,t in enumerate(plans[0]['terminal_rows']):
  assert readj(t['path'])==t['original_rows']
  add(t['path'],f'terminal-originals/{i:03d}-'+Path(t['path']).name)
 for path in ['/workspace/prepare_three_emergency_terminal_archive_groups_20261024.py','/workspace/prepare_two_prer5_terminal_archive_groups_20261024.py','/workspace/prepare_seven_postr5_terminal_archive_groups_20261024.py','/workspace/prepare_three_large_terminal_archive_groups_20261024.py','/workspace/launch_three_emergency_archive_groups_20261024.py','/workspace/launch_two_prer5_archive_groups_20261024.py','/workspace/launch_seven_postr5_archive_groups_20261024.py','/workspace/geo261-cold-large-archive-metadata-combined-20261024.json','/workspace/geo261-cold-large-archive-identity-combined-20261024.json','/workspace/geo261-cold-large-archive-terminal-combined-20261024.json']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 train=Path('/workspace/train337-canvas-peer-resume')
 peer_names=['THREE_EMERGENCY_ARCHIVE_GROUPS_STATIC_ACTUAL_METADATA_PEER.json','TWO_PRER5_ARCHIVE_GROUPS_STATIC_ACTUAL_METADATA_PEER.json','SEVEN_POSTR5_ARCHIVE_GROUPS_STATIC_ACTUAL_METADATA_PEER.json','COLD105_EXECUTOR_STATIC_PEER.json','COLD105_RETIREMENT_ACTUAL_PEER.json']
 for name in peer_names:
  peer=readj(train/name);assert peer['exit_code']==0 and not peer['findings']
 for name in peer_names+['review_three_emergency_archive_groups_actual.py','review_two_prer5_archive_groups_actual.py','review_seven_postr5_archive_groups_actual.py','review_cold105_executor.py','review_cold105_retirement_actual.py','THREE_EMERGENCY_INITIAL_PATH_PREFIX_ASSUMPTION.json','review_three_emergency_archive_groups_actual.initial.py.txt','COLD105_RETIREMENT_INITIAL_OUTER_SCHEMA_ASSUMPTION.json','review_cold105_retirement_actual.initial.py.txt']:
  add(train/name,'peers-and-review-tools/'+name)
 for path in ['/workspace/review_three_emergency_archive_groups_actual_metadata_20261024.py','/workspace/THREE_EMERGENCY_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json','/workspace/review_emergency_five_archive_groups_actual_metadata_20261024.py','/workspace/EMERGENCY_FIVE_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json','/workspace/review_seven_postr5_archive_groups_actual_metadata_20261024.py','/workspace/SEVEN_POSTR5_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 coldprep=Path('/workspace/cold105-source-retirement-body-preparation-20261024');coldexec=Path('/workspace/cold105-source-retirement-execution-20261024');cp=readj(coldprep/'PREPARED.json');ce=readj(coldexec/'RESULT.json')
 assert cp['files']==105 and cp['unique_payloads']==16 and cp['full_byte_roundtrip'] is True
 assert readj(coldprep/'RESULT.json')['exit_code']==ce['exit_code']==0 and len(ce['removed'])==105 and ce['gross_allocated_bytes_retired']==54906880 and ce['git_and_terminal_identities_unchanged'] is True
 preserved=Path(cp['archive']);assert preserved.stat().st_size==cp['archive_bytes'] and ce['original_source_archive_sha256']==cp['archive_sha256']
 preserved_reference=dict(path=str(preserved),bytes=cp['archive_bytes'],sha256=cp['archive_sha256'],included_in_metadata_tar=False,publication_requirement='Publish this unique original preserved-source archive alongside the metadata package; do not claim its original bytes included in this tar.',hash_provenance='Original prepare/execute full-byte checks and independent cold105 actual peer; collector does not rehash this payload.')
 for q in sorted(coldprep.rglob('*')):
  if q.is_dir() or '__pycache__' in q.parts or q==preserved:continue
  add(q,'cold105/preparation/'+str(q.relative_to(coldprep)))
 tree('/workspace/cold105-source-retirement-metadata-20261024','cold105/metadata');tree(coldexec,'cold105/actual')
 for phase in ['prepare','execute']:
  q=Path('/workspace/cold105-source-retirement-'+phase+'-launch-20261024');assert readj(q/'RESULT.json')['actual_exit']==0
  tree(q,'cold105/launch-'+phase)
 for path in ['/workspace/retire_exact_cold105_source_copies_20261024.py','/workspace/launch_cold105_source_retirement_20261024.py','/workspace/retire_exact_cold105_source_copies_20261024.py.before-durable-preservation.txt','/workspace/retire_exact_cold105_source_copies_20261024.py.before-durable-directory-entries.txt']:
  add(path,'cold105/tools/'+Path(path).name)
 for path in ['/workspace/EMERGENCY_TWELVE_IMMUTABLE_ALIAS_REGISTRY_20261024.json','/workspace/FINAL_ACCEPTANCE_RESOURCE_PLAN_20261024.md']:
  add(path,'current-storage-metadata/'+Path(path).name)
 tree('/workspace/L175-elf-retirement-preparation-20261024','historical-175-missing-observation')
 add('/workspace/prepare_L175_elf_retirement_metadata_20261024.py','historical-175-missing-observation/observer.py')
 add(__file__,'collector.py');add('/workspace/collect_cold128_originals_20261024.py','original-collector.py')
 add('/workspace/collect_four_additional_archive_groups_originals_20261024.py','previous-four-additional-collector.py')
 add('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py','original-tools/previous-three-groups-executor.py')
 assert not archive_bodies.intersection(x['source'] for x in entries.values())
 assert str(preserved) not in [x['source'] for x in entries.values()]
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'emergency-twelve-and-cold105-metadata-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='emergency-twelve-and-cold105-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,preserved_source_archive=preserved_reference,groups_added={'emergency':3,'preR5':2,'postR5':7},configured_gross_archive_source_block_saving=gross,cold105_gross_retired=54906880,limits=['Maintenance only; no product gate is executed or relabeled.','All61 named archive paths and complete bytes remain; none of those large archive bodies or ELF payloads are duplicated here.','105 precise rebuildable ordinary source copies were retired; full16 unique original payloads remain in the separately named original archive, and Git objects/refs/index/fixtures/receipts/immutable aliases remain.','This package alone omits the105 original source archive; its exact separate publication locator and pin are explicit.','Original423 cold groups,2 cardref ELF groups,1 six-alias group,3 previous large and4 previous additional archive groups retain independent write/reuse bans.','Original terminal failures remain failed; maintenance0 does not turn them green.','Gross block sums are not net/global df recovery; tools/metadata/archives/Git and concurrent writes consume space.','Fresh byte/Git checks remain original; smallmetadata reviews do not claim a second archive body read.','F2perf counterfactual remains excluded because original owner receipt is truncated.','Original prep producers used direct exec and retain full Git capture streams; no invented outer OS transcript is backfilled.','The L175 historical ELF observation found all175 already absent; this agent did not reclaim them. Its original failed metadata preparation remains preserved.','Three-emergency initial reviewer path-prefix error and original105 durability drafts are retained; subject tools are not rewritten.','Independent post-package peer remains adjacent to avoid self-reference.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
