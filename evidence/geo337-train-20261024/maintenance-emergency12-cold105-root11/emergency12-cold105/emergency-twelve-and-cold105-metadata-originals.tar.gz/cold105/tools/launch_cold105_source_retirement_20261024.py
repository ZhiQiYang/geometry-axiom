"""Original c387 recording wrapper for the two reviewed maintenance phases."""
import argparse, hashlib, importlib.util, json, os, sys
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['prepare','execute'],required=True);a=parser.parse_args()
tool=Path('/workspace/retire_exact_cold105_source_copies_20261024.py')
assert hashlib.sha256(tool.read_bytes()).hexdigest()=='3ddab4af2f51aa3546558e409b2af8279b647ebaa84de928dd6a5a75de99f1b9'
capfile=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(capfile.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',capfile);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
out=Path('/workspace/cold105-source-retirement-'+a.phase+'-launch-20261024');assert not out.exists();out.mkdir()
rec=cap.Recorder(out,dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),'425c092eaf16f90256d76433243baebde45163ac')
row,stdout,stderr=rec.run([sys.executable,'-B',str(tool),'--'+a.phase],cwd='/workspace',timeout=None,check=False,source_variant='historical105-source-maintenance-not-product-acceptance')
result=dict(actual_exit=row['actual_process_returncode'],phase=a.phase,source_meaning='Public main contains all three original historical source commits; this is storage maintenance, not product acceptance at main.',command=row)
(out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(actual_exit=result['actual_exit'],phase=a.phase,out=str(out)),ensure_ascii=False));sys.exit(result['actual_exit'])
