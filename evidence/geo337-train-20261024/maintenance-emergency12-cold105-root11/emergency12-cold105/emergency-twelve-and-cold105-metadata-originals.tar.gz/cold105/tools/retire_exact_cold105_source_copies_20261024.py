"""Preserve exact original bytes before retiring only 105 rebuildable source copies."""
import argparse, datetime, hashlib, importlib.util, io, json, os, stat, sys, tarfile
from pathlib import Path
PLAN=Path('/workspace/cold105-source-retirement-metadata-20261024/PLAN.json')
PIN='0af31de0299cf6611bd22ab5172c8d454de56e4e20c02ba8eaf32ccd79004cea'
PREP=Path('/workspace/cold105-source-retirement-body-preparation-20261024')
EXEC=Path('/workspace/cold105-source-retirement-execution-20261024')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CON=Path('/workspace/clear_terminal_chrome_caches.py')
ORIGINAL=Path('/workspace/geo337-cold-retirement.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def free():return {p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']}
def sync_preserved_payloads(archive,prepared):
 for p in (archive,prepared):
  fd=os.open(p,os.O_RDONLY)
  try:os.fsync(fd)
  finally:os.close(fd)
 fd=os.open(PREP,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def load_module(p,n,pin):
 assert sha(p.read_bytes())==pin
 spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--prepare',action='store_true');group.add_argument('--execute',action='store_true');args=parser.parse_args()
assert sha(PLAN.read_bytes())==PIN
plan=json.loads(PLAN.read_text());rows=plan['rows'];roots=plan['owners']
assert plan['publication_reachability_proven'] is True and len(rows)==105 and len(roots)==7
assert len({r['path'] for r in rows})==105 and sum(r['allocated'] for r in rows)==54906880
out=PREP if args.prepare else EXEC;assert not out.exists();out.mkdir()
out_parent_fd=os.open(out.parent,os.O_RDONLY)
try:os.fsync(out_parent_fd)
finally:os.close(out_parent_fd)
cap=load_module(CAP,'original_c387_capture','c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762')
con=load_module(CON,'original_owned_consumer_guard','c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847')
rec=cap.Recorder(out,dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),'historical-cold105-source-retirement')
result=dict(started_utc=now(),mode='prepare' if args.prepare else 'execute',plan_sha256=PIN,exit_code=1,free_before=free(),removed=[])
def git(root,*argv):
 row,b,_=rec.run(['git','-c','gc.auto=0',*argv],cwd=root,source_sha=roots[root],timeout=None)
 return b
def terminal():
 for a in plan['anchors']:
  p=Path(a['path']);b=p.read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'],str(p)
def identity():
 identities={}
 for root,head in roots.items():
  assert git(root,'rev-parse','HEAD').decode().strip()==head
  _, ancestry_out, _ = rec.run(['git','-c','gc.auto=0','merge-base','--is-ancestor',head,plan['published_main']],cwd='/workspace/geometry-axiom',source_sha=head,timeout=None)
  assert ancestry_out==b''
  selected={r['relative']:(r['index_mode'],r['git_blob']) for r in rows if r['repo']==root}
  tree={}
  for entry in git(root,'ls-tree','-z',head,'--',*sorted(selected)).split(b'\0'):
   if entry:
    m,p=entry.split(b'\t',1);mode,kind,blob=m.decode().split();assert kind=='blob';tree[os.fsdecode(p)]=(mode,blob)
  assert tree==selected
  index=Path(git(root,'rev-parse','--git-path','index').decode().strip())
  if not index.is_absolute():index=Path(root)/index
  identities[root]=dict(head=head,index_path=str(index),index_sha256=sha(index.read_bytes()))
 return identities
def consume(label):
 d=out/label;d.mkdir();con.OUT=d;con.consumer_check(list(roots))
def file_bytes(r):
 p=Path(r['path']);assert p==Path(r['repo'])/r['relative'] and r['repo'] in roots and r['head']==roots[r['repo']]
 assert p.is_relative_to('/workspace/geo261-cold') and p.resolve(strict=True)==p
 assert not any(s in r['relative'].lower() for s in ['evidence','receipt','fixture','snapshot','golden','expected','/sources/','/raw/','/compiler/','.git','mutant','counterfactual','withdrawn'])
 for parent in p.parents:assert not parent.is_symlink()
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 assert (s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_mode,s.st_blocks*512)==(r['device'],r['inode'],1,r['bytes'],r['mtime_ns'],r['mode'],r['allocated']),str(p)
 b=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob'],str(p)
 return b
try:
 terminal();before=identity();consume('before-consumers')
 archive=PREP/'original-source-payloads-and-exact-path-map.tar.gz'
 if args.prepare:
  payloads={};hashes={}
  for r in rows:
   b=file_bytes(r);h=sha(b);hashes[r['path']]=h
   if h not in payloads:payloads[h]=b
  assert len(payloads)==16 and sum(map(len,payloads.values()))==14822323
  with tarfile.open(archive,'w:gz') as tar:
   for h,b in sorted(payloads.items()):
    info=tarfile.TarInfo('payloads/'+h);info.size=len(b);info.mode=0o444;tar.addfile(info,io.BytesIO(b))
   tar.add(PLAN,arcname='original-metadata/PLAN.json',recursive=False)
  with tarfile.open(archive) as tar:
   assert len(tar.getmembers())==17
   for h,b in payloads.items():assert tar.extractfile('payloads/'+h).read()==b
   assert tar.extractfile('original-metadata/PLAN.json').read()==PLAN.read_bytes()
  terminal();assert identity()==before
  prepared=dict(schema='cold105-preserved-source-preparation/1',created_utc=now(),plan_sha256=PIN,files=105,unique_payloads=16,unique_payload_bytes=14822323,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),path_sha256=hashes,identities=before,full_byte_roundtrip=True,cleanup_executed=False)
  dump(PREP/'PREPARED.json',prepared)
  sync_preserved_payloads(archive,PREP/'PREPARED.json')
  result.update(prepared=prepared,exit_code=0)
 else:
  p=PREP/'PREPARED.json';prepared=json.loads(p.read_text())
  assert prepared['plan_sha256']==PIN and prepared['identities']==before and prepared['full_byte_roundtrip'] is True
  assert prepared['files']==105 and prepared['unique_payloads']==16 and prepared['unique_payload_bytes']==14822323
  assert prepared['archive']==str(archive) and archive.stat().st_size==prepared['archive_bytes'] and sha(archive.read_bytes())==prepared['archive_sha256']
  for r in rows:assert sha(file_bytes(r))==prepared['path_sha256'][r['path']]
  with tarfile.open(archive) as tar:
   assert len(tar.getmembers())==17
   assert tar.extractfile('original-metadata/PLAN.json').read()==PLAN.read_bytes()
   for h in sorted(set(prepared['path_sha256'].values())):assert sha(tar.extractfile('payloads/'+h).read())==h
  sync_preserved_payloads(archive,p)
  terminal();assert identity()==before;consume('immediate-before-consumers')
  result.update(prepared_path=str(p),prepared_sha256=sha(p.read_bytes()),original_source_archive_sha256=prepared['archive_sha256'],gross_allocated_bytes_eligible=54906880,policy='Retire only exact ordinary source materializations after lossless original-payload preservation; all Git objects, index, refs, fixtures, receipts and immutable archive aliases remain. No recursive deletion.')
  journal=out/'RETIREMENT.jsonl'
  with journal.open('x') as f:
   f.flush();os.fsync(f.fileno())
   journal_parent_fd=os.open(out,os.O_RDONLY)
   try:os.fsync(journal_parent_fd)
   finally:os.close(journal_parent_fd)
   for i,r in enumerate(rows):
    p=Path(r['path']);assert sha(file_bytes(r))==prepared['path_sha256'][str(p)]
    before_row=dict(index=i,stage='verified-before-unlink',path=str(p),git_blob=r['git_blob'],sha256=prepared['path_sha256'][str(p)],bytes=r['bytes'],allocated=r['allocated'])
    f.write(json.dumps(before_row,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
    p.unlink();fd=os.open(p.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
    f.write(json.dumps(dict(before_row,stage='source-materialization-retired'),ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
    result['removed'].append(str(p))
  assert len(result['removed'])==105 and all(not Path(r['path']).exists() for r in rows)
  terminal();assert identity()==before
  result.update(exit_code=0,gross_allocated_bytes_retired=54906880,original_payloads_remain=True,git_and_terminal_identities_unchanged=True)
except BaseException as e:
 result['error']=repr(e);raise
finally:
 result.update(ended_utc=now(),free_after=free());dump(out/'RESULT.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ['removed','prepared']},ensure_ascii=False),flush=True)
