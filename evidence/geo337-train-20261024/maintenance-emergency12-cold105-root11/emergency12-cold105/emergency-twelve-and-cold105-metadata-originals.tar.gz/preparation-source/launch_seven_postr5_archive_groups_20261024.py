"""Root explicitly authorized self-reviewed execution with parallel independent peer."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
B=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024');tool=B/'link_exact_seven_postr5_terminal_archive_groups.py'
assert hashlib.sha256(tool.read_bytes()).hexdigest()=='1d81f53f1094bc62c655df00d1d409565ee44d26359178f944369540ec0d2c44'
selfreview=B/'SELF_REVIEW.json';assert json.loads(selfreview.read_text())['independent_peer'] is False
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert hashlib.sha256(cap.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('capture',cap);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
out=Path('/workspace/seven-postr5-terminal-archive-groups-preserving-links-launch-20261024');out.mkdir();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
r=c.Recorder(out,env,'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db');argv=[sys.executable,'-B',str(tool)]
c.dump(out/'REQUEST.json',dict(argv=argv,tool_sha256=hashlib.sha256(tool.read_bytes()).hexdigest(),root_authorized_self_review=str(selfreview),self_review_sha256=hashlib.sha256(selfreview.read_bytes()).hexdigest(),independent_peer_status_at_start='requested in parallel; not claimed complete',source_sha=r.sha))
row,stdout,stderr=r.run(argv,cwd='/workspace',timeout=None,check=False,source_variant='root-authorized-self-reviewed-emergency-maintenance-independent-peer-pending')
c.dump(out/'RESULT.json',row);print(json.dumps(dict(exit_code=row['actual_process_returncode'],stdout=stdout.decode(),stderr=stderr.decode())));sys.exit(row['actual_process_returncode'])
