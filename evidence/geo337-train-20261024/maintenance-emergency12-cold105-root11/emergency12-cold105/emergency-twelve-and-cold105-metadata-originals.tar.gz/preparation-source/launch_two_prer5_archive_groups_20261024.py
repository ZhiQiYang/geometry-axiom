"""Root explicitly authorized self-reviewed execution with parallel independent peer."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
B=Path('/workspace/two-prer5-terminal-archives-preparation-20261024');tool=B/'link_exact_two_prer5_terminal_archive_groups.py'
assert hashlib.sha256(tool.read_bytes()).hexdigest()=='3aebfecd862f1a26e37a8e93482dac687d096943d6cecef4b4b00e8640b5503d'
selfreview=B/'SELF_REVIEW.json';assert json.loads(selfreview.read_text())['independent_peer'] is False
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert hashlib.sha256(cap.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('capture',cap);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
out=Path('/workspace/two-prer5-terminal-archive-groups-preserving-links-launch-20261024');out.mkdir();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
r=c.Recorder(out,env,'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db');argv=[sys.executable,'-B',str(tool)]
c.dump(out/'REQUEST.json',dict(argv=argv,tool_sha256=hashlib.sha256(tool.read_bytes()).hexdigest(),root_authorized_self_review=str(selfreview),self_review_sha256=hashlib.sha256(selfreview.read_bytes()).hexdigest(),independent_peer_status_at_start='requested in parallel; not claimed complete',source_sha=r.sha))
row,stdout,stderr=r.run(argv,cwd='/workspace',timeout=None,check=False,source_variant='root-authorized-self-reviewed-emergency-maintenance-independent-peer-pending')
c.dump(out/'RESULT.json',row);print(json.dumps(dict(exit_code=row['actual_process_returncode'],stdout=stdout.decode(),stderr=stderr.decode())));sys.exit(row['actual_process_returncode'])
