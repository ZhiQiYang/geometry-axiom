# 下一個最終 SHA 的資源準備

此為小型 metadata 計畫，沒有物化新來源、改測試、變更 cache 或執行驗收。效能來源仍未定案；R5 的 N64/main 1.33696 紅燈不能因儲存維護而改判。

目前可行順序是先修定效能來源，再固定新來源與帳本生成策略；重用獨立的 native ROOT，另備可寫的 bridge seed。原 L 的共享唯讀 seed 不得改成新可寫來源。

## 可重用的 native ROOT

`/tmp/train337-323-f64d638f-source` 是先前完整 native 真 0 的獨立 Git checkout，HEAD 為 L `7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`，objects alternate 指向 root repository。現有 source 約 328.7 MB；待 root 確認無 consumer、保留所有實際 fixture、核對變更檔案 inode 互不相依後，可正常 checkout 最終 SHA，避免再複製一份。

此 ROOT 排除 `evidence/` 與大部分 `tests/evidence/`，保留以下三個原 fixture；它並未排除 `tests/release-evidence/`。不要為節省空間臨時縮小正式 native 的 closure：

- `tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas`
- `tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas`
- `tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas`

成功補齊 fixture 的原工具為 `/tmp/train337-native-L-fixture-diagnosis/materialize_three_original_fixtures.py`，SHA256 `2ff31df35fbddabccd132d812277b07b5dffbd5df27a28043a9b276429bbb8ed`。原工具綁定 L，不能直接拿來聲稱新 SHA 的所有 fixture 都已足夠；應依最終 Git tree 重新核對。

## TMP 與 native cache

backlog 代理已依 root 授權完成六個舊 checkout 的精確 ordinary-code 回收，執行原件在 `/workspace/tmp-coldcode-cleanup-20261024/execution-r2/`。其結果為 160,391,168 allocated bytes，完成時 `/tmp` free 183,652,352 B；之後其他工作可能繼續使用 TMP。這六個 owner 的相同路徑不得再次列作可回收，也不能由 storage 代理重複清理。

原 native launcher 的 TMP 守門是 128 MiB。`tests/binaries.py` 在 Linux 硬寫 `/tmp/geometry-tests`，設定 TMPDIR 不能搬走它；不改產品 OUT_DIR。既有 `/tmp/geometry-tests` 約 7.1 MB，六個普通 ELF 合計約 4.88 MB，不能誤認為 185 MB 的帳本 cache。

原 wrapper `/tmp/native-final-executable-preparation/run_full_native_workflow_v2.py` SHA256 `763a6e8064be212a020522a43a80bdb6cd353d329997c83479f469c2359f4d21`，以同一 TMP filesystem 原子保留舊 global cache、原 source guard、原命令與 timeout。新一輪應依這些原機制準備，不能把受測來源或原正式出口重標。

## bridge seed 與帳本空間

原 full sparse 定義為 `/*`，排除 `/evidence/`、`/tests/evidence/`、`/tests/release-evidence/`。原 L browser pool 有 3,755 項；以原 tree 加 L→U 完整 Git 差異推估，U 普通來源為 139,033,979 logical bytes／148,201,472 rounded bytes。metadata 原件為 `/workspace/next-full-source-budget-metadata-20261024/BUDGET.json`。U 不是即將固定的新最終 SHA，數字必須在來源定案後更新。

舊 L 175 組 ELF＋sidecar 的歷史觀測為 184,545,280 rounded bytes。這些 ELF **全部早已不存在**：本代理只做 lstat，105、archive 維護及 TMP 回收都沒有刪掉這 175 個檔案；側車與原收據仍保留。原未成功準備與精確 missing 清單在 `/workspace/L175-elf-retirement-preparation-20261024/OBSERVED_MISSING.json`，不能再把歷史 185 MB 算成現有可回收量。

若完整沿用舊 full sparse 定義，全新獨立 seed＋同規模完整帳本 cache，兩項歷史量約 332,746,752 B，尚未包含 raw output、編譯暫存、Git metadata、出版峰值及任何保留餘裕。這是該方案的規劃參考，不是所有可行方案的最低需求，也不是新數值門檻或保證上限。

05:07 更新：evidence 代理另已備更精確的 closure sparse 方案，原稿在 `/workspace/geo337-final-ledger-native-seed-preparation-20261024/ROOT_TRANSITION_PLAN.md`，仍待 root／train 最終審核與來源固定。其 seed 只省不屬 core/bridge、fixtures、全部604 architecture來源／exclusions、runtime、guide/vendor 的歷史 docs/prototypes payload，估77,619,200 B＋約5.7 MB index；不得用它省掉123完整定義或baseline。此方案可降空間需求，但仍須約184 MB cache、約10 MB帳本、raw、編譯與出版餘裕；當前約177 MB workspace free仍不足直接啟動。應以該代理最終已審工具為執行準據，本檔不另造平行物化工具。

`mutation_bridge.run_pass` 的自動 clone 不排除根目錄 evidence，會誤物化大量已公開收據；必須在原測試規則允許下先備獨立 sparse seed，再使用原帳本工具。舊 L driver 含 b6→L 的 175 對移動與舊 seed rename，不能原樣套到新來源。採用哪個產品／帳本 SHA 及其可解析關係由 root 的最終驗收流程決定，本計畫不改寫原 source attribution。

## browser pool

成功原工具是 `/workspace/train337-browser-pool-L-7af8c5d8/PREPARER.py`。其 seed freeze、完整 Git bytes 守門、獨立 index／私有可寫輸出，以及 native ROOT 與共享 seed 不共用 inode 的要求仍適用。新 seed 完成所有可寫工作後，才由 root 明確凍結供 6 個 browser checkout 唯讀共享。

歷史 browser pool metadata estimate 68,815,664 B、實際 59,600,896 B，原準備工具另保留 64 MiB 餘裕。不能把這些估算改寫成正式測試時限或斷言。完整 canvas 必須獨占，其他重測最多兩個；performance 獨占期間不做 archive hash／壓縮／連結維護。

## 目前維護邊界

七個冷 owner 的 19 組已知 archive 候選都已完成保路徑 hardlink，共 102 個 archive aliases；不得重算同一批空間。追加 3＋2＋7 批的精確 61 paths 在 `/workspace/EMERGENCY_TWELVE_IMMUTABLE_ALIAS_REGISTRY_20261024.json`。先前 423 seal 群、2 cardref ELF 群、1 GEO339 六 alias 群仍各自禁寫。

105 份 ordinary code copies 於 05:02 UTC 已精確退休，保留完整 16 unique payload 還原包、Git objects／refs／index、fixtures、receipts 與 archive aliases。原件在 `/workspace/cold105-source-retirement-{body-preparation,execution}-20261024/`；105 的 original manifest 不能再當作待執行清單。最後 execute free 為 workspace 177,020,928 B／TMP 178,987,008 B，兩者是當時快照，不是固定可用量。

後續優先避免多份 checkout／tar 的出版複本；root 已使用 hash-object／skip-worktree 出版大型完整包。任何新增清理仍應只針對明列、已終態、可重建的普通 cache／source，保留原 metadata 與公開 Git 復原關係，不刪 receipts、fixtures、Git objects 或受保護的共享 seed。
