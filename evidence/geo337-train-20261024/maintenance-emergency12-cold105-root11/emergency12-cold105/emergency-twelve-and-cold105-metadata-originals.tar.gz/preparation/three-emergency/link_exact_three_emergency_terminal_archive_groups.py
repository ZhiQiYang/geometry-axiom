"""Root-authorized preserving hardlinks for three emergency frozen immutable archive groups."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, sys

B=Path('/workspace/three-emergency-terminal-archives-preparation-20261024')
PLAN=B/'PLAN.json';PIN='b7c67e70991dd0a2368e4a8bb3ba83047f4925f410136efacfad56e2d67b836a'
CORE=B/'exact_large_archive_group_link_core.py';CORE_PIN='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py');GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
OUT=Path('/workspace/three-emergency-terminal-archive-groups-preserving-links-execution-20261024')

def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):v.update(b)
    return v.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert h(PLAN)==PIN and h(CORE)==CORE_PIN and h(GUARD)==GUARD_PIN and h(CAP)==CAP_PIN
    p=json.loads(PLAN.read_text())
    assert p['source_sha']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
    assert [g['count'] for g in p['groups']]==[7,7,7] and p['target_count']==21 and len(p['owners'])==7
    assert p['expected_allocated_saving']==163504128 and not p['actual_replacement_executed']
    assert len({x['path'] for g in p['groups'] for x in g['members']})==21
    assert all('/g261F2perf/' not in x['path'] for g in p['groups'] for x in g['members'])
    core={'__name__':'_link_only','__file__':str(CORE)};exec(compile(CORE.read_bytes(),str(CORE),'exec'),core)
    guard={'__name__':'_consumer_only','__file__':str(GUARD)};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard)
    OUT.mkdir()
    r=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,source_sha=p['source_sha'],
           plan_sha256=PIN,core_sha256=CORE_PIN,free_before=guard['free'](),actual_replacement_performed=False,
           groups=[],all_original_payload_paths_retained=False,reservation=p['reservation'],identity_limit=p['identity_limit'],
           failure_policy='Retain all original results, journal and pending aliases on failure; no cleanup or destructive rollback.',
           scope_limit=p['scope_limit'],excluded_unproven_owner=p['excluded_unproven_owner'],excluded_reason=p['excluded_reason'])
    count=0
    def anchors():
        for x in p['anchors']:
            q=Path(x['path']);core['ancestors'](q)
            assert q.stat().st_size==x['bytes'] and h(q)==x['sha256']
        for t in p['terminal_rows']:
            assert json.loads(Path(t['path']).read_text())==t['original_rows']
    def consumer():
        nonlocal count
        count+=1;d=OUT/f'consumers-{count:03d}';d.mkdir();guard['OUT']=d
        guard['consumer_check'](p['consumer_prefixes']);anchors()
    spec=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    rec=c.Recorder(OUT/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),p['source_sha'])
    def git(root,args,expected):
        row,out,err=rec.run(['git',*args],cwd=root,check=False,source_variant='read-only historical exact HEAD/blob guard; no index or objects writes')
        assert row['actual_process_returncode']==0 and not err and out.decode().strip()==expected
    def git_identity():
        for owner in p['owners']:git(owner['root'],['rev-parse','HEAD'],owner['head'])
        for g in p['groups']:
            for x in g['members']:
                git(x['owner_root'],['ls-tree',x['owner_head'],'--',x['git_path']],f"100644 blob {x['git_blob']}\t{x['git_path']}")
                git(x['owner_root'],['cat-file','-s',x['git_blob']],str(x['size']))
                git(x['owner_root'],['hash-object',x['path']],x['git_blob'])
    try:
        anchors();git_identity();consumer()
        for i,g in enumerate(p['groups'],1):
            members=g['members'];assert len(members)==g['count']
            core['state'](members,set())
            core['link_exact'](members,OUT/f'GROUP-{i}.jsonl',before_each=consumer)
            core['state'](members,set(range(1,len(members))));anchors()
            r['groups'].append(dict(count=len(members),sha256=g['sha256'],expected_allocated_saving=g['expected_allocated_saving'],
                                  all_paths_preserved=True,final_metadata=[dict(path=x['path'],**core['metadata'](x['path'])) for x in members]))
            r['actual_replacement_performed']=True;dump(OUT/'PROGRESS.json',r)
        git_identity();anchors()
        for g in p['groups']:core['state'](g['members'],set(range(1,len(g['members']))))
        r.update(exit_code=0,all_original_payload_paths_retained=True,all_original_receipt_bytes_preserved=True,
                 expected_allocated_saving=p['expected_allocated_saving'],consumer_checks=count)
    finally:
        r.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=guard['free']())
        dump(OUT/'RESULT.json',r);print(json.dumps({k:v for k,v in r.items() if k!='groups'}))

if __name__=='__main__':main()
