"""Prepare only eleven root immutable leaves; preserve all seven existing aliases."""
from pathlib import Path
import hashlib,json,datetime,os,importlib.util,difflib
B=Path('/workspace/root-eleven-archive-alias-extension-preparation-20261024')
CAND=Path('/workspace/root-published-archive-leaf-metadata-20261024/known-cold-group-crosscheck/CANDIDATES.json')
ORIGINAL=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
ROOT=Path('/workspace/geometry-axiom')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def module(p,n):
 spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
assert h(CAND)=='0dadb7385bd9d52490cffccc1440f00c195a419fb06c090fe5923c5a60ddc4d0'
assert h(ORIGINAL)=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec'
assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(GUARD)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
B.mkdir();old=ORIGINAL.read_text();new=old
changes=[('assert len(members) in (2, 4, 7) and','assert len(members) == 8 and'),("assert len({(x['dev'], x['inode']) for x in members}) == len(members)","assert len({(x['dev'], x['inode']) for x in members[:7]}) == 1\n    assert len({(x['dev'], x['inode']) for x in members}) == 2\n    assert all(x['nlink'] == 7 for x in members[:7]) and members[7]['nlink'] == 1"),('linked = set()','linked = set(range(1, 7))'),('for item in members[1:]]','for item in members[7:]]'),('expected_alias_count=1, temporary_paths','expected_alias_count=7, temporary_paths'),('for index, temp in enumerate(temporary, 1):','for index, temp in enumerate(temporary, 7):')]
for before,after in changes:
 assert new.count(before)==1;new=new.replace(before,after)
corepath=B/'exact_seven_plus_one_archive_link_core.py';corepath.write_text(new);(B/'CORE_DIFF.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(ORIGINAL),tofile=str(corepath))))
core=module(corepath,'extension_core');cap=module(CAP,'capture');guard=module(GUARD,'consumer')
rec=cap.Recorder(B/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),'historical-archive-root-leaf-extension-not-product-acceptance')
def git(root,args):
 row,b,e=rec.run(['git','-c','gc.auto=0',*args],cwd=root,timeout=None);assert not e;return b.decode().strip()
items=json.loads(CAND.read_text())['groups'];assert len(items)==11 and sum(x['gross_new_candidate'] for x in items)==134045696
roothead=git(ROOT,['rev-parse','HEAD']);owners={};anchors={};terminal={};groups=[]
for item in items:
 priorpath=Path(item['plan']);assert h(priorpath)==item['plan_sha256'];prior=json.loads(priorpath.read_text());priorgroup=prior['groups'][item['original_group']-1];oldmembers=priorgroup['members'];assert len(oldmembers)==7 and [x['path'] for x in oldmembers]==item['original_alias_paths']
 anchors[str(priorpath)]=dict(path=str(priorpath),bytes=priorpath.stat().st_size,sha256=h(priorpath))
 for x in prior['anchors']:anchors[x['path']]=x
 for x in prior['terminal_rows']:terminal[x['path']]=x
 members=[]
 for original in oldmembers:
  m=dict(original);m.update(core.metadata(m['path']));assert m['nlink']==7 and not os.listxattr(m['path']);assert core.digest(m['path'])==m['sha256'];owners[m['owner_root']]=m['owner_head'];members.append(m)
 leaf=ROOT/item['relative'];original=members[0];m=dict(path=str(leaf),owner_root=str(ROOT),owner_head=roothead,git_path=item['relative'],git_blob=original['git_blob'],sha256=original['sha256'],**core.metadata(leaf));assert m['nlink']==1 and not os.listxattr(leaf);assert core.digest(leaf)==m['sha256'];members.append(m)
 core.state(members,set(range(1,7)))
 for x in members:
  head='HEAD' if x['owner_root']==str(ROOT) else x['owner_head'];expected=f"100644 blob {x['git_blob']}\t{x['git_path']}"
  assert git(x['owner_root'],['ls-tree',head,'--',x['git_path']])==expected
  assert git(x['owner_root'],['cat-file','-s',x['git_blob']])==str(x['size'])
  assert git(x['owner_root'],['hash-object',x['path']])==x['git_blob']
 assert git(ROOT,['ls-files','--stage','--',m['git_path']])==f"100644 {m['git_blob']} 0\t{m['git_path']}"
 groups.append(dict(count=8,previous_alias_count=7,new_root_alias=str(leaf),members=members,sha256=m['sha256'],expected_allocated_saving=m['allocated_bytes']))
for root,head in owners.items():assert git(root,['rev-parse','HEAD'])==head
for a in anchors.values():assert Path(a['path']).stat().st_size==a['bytes'] and h(a['path'])==a['sha256']
for t in terminal.values():assert json.loads(Path(t['path']).read_text())==t['original_rows']
prefixes=list(owners)+[g['new_root_alias'] for g in groups];d=B/'prepare-consumers';d.mkdir();guard.OUT=d;guard.consumer_check(prefixes)
plan=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db',root_head_observed_at_prepare=roothead,root=str(ROOT),root_head_policy='Only eleven immutable leaves are frozen. Other root docs and Git metadata may change. Every current HEAD and index leaf must keep the exact existing blob; no root-wide clean/index/head freeze.',groups=groups,owners=[dict(root=k,head=v) for k,v in owners.items()],target_count=88,new_replacements=11,expected_allocated_saving=134045696,anchors=list(anchors.values()),terminal_rows=list(terminal.values()),consumer_prefixes=prefixes,core=dict(path=str(corepath),sha256=h(corepath)),original_core=dict(path=str(ORIGINAL),sha256=h(ORIGINAL)),consumer_guard=dict(path=str(GUARD),sha256=h(GUARD)),candidate=dict(path=str(CAND),sha256=h(CAND)),reservation='All88 immutable archive aliases are write/reuse banned until every applicable alias is de-linked. Only eleven new root leaves are frozen; ordinary unrelated root documents/publication do not imply archive use. The existing77 cold aliases are never replaced.',identity_limit='All named paths and complete bytes remain. Only11 root leaves adopt canonical inode/nlink/mtime/atime; canonical old aliases stay untouched except expected nlink increment.',scope_limit='Exact root immutable archive leaves plus existing fully inventoried groups. No product acceptance or clean whole-repository assertion.',excluded_unproven_owner='/workspace/geo261-cold/g261F2perf/source-counterfactual',excluded_reason='Never part of these exact original groups; unproven owner remains excluded.',actual_replacement_executed=False,preparation_provenance='Direct producer exec; original full Git captures and consumer records preserved; no invented outer transcript.')
dump(B/'PLAN.json',plan);print(json.dumps(dict(plan=str(B/'PLAN.json'),plan_sha256=h(B/'PLAN.json'),core_sha256=h(corepath),groups=len(groups),paths=88,new_root_leaves=11,gross_candidate=134045696)))
