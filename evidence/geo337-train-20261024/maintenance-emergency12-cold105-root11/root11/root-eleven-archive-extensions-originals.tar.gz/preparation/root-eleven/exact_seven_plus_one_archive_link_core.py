"""Exact-file atomic linking primitive; no directory scan, chmod, or removal."""
from pathlib import Path
import hashlib
import json
import os
import stat


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ancestors(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    for parent in reversed(path.parents):
        s = parent.lstat()
        assert stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode), str(parent)
    assert stat.S_ISREG(path.lstat().st_mode), str(path)


def metadata(path):
    ancestors(path)
    s = Path(path).lstat()
    return dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, size=s.st_size,
                mtime_ns=s.st_mtime_ns, atime_ns=s.st_atime_ns,
                uid=s.st_uid, gid=s.st_gid, nlink=s.st_nlink,
                allocated_bytes=s.st_blocks * 512)


def assert_identity(path, original, *, inode=None, nlink=1):
    current = metadata(path)
    for key in ['dev', 'inode', 'mode', 'size', 'mtime_ns', 'uid', 'gid']:
        expected = inode[key] if inode is not None else original[key]
        assert current[key] == expected, (str(path), key, current[key], expected)
    assert current['nlink'] == nlink, (str(path), 'nlink', current['nlink'], nlink)
    assert not os.listxattr(path, follow_symlinks=False), ('xattrs require separate policy', str(path))
    assert digest(path) == original['sha256'], ('bytes changed', str(path))


def state(members, linked, temp=None):
    """Every expected alias, including a journalled temporary alias, is counted."""
    canonical = members[0]
    count = 1 + len(linked) + (temp is not None)
    for index, item in enumerate(members):
        if index == 0 or index in linked:
            assert_identity(item['path'], item, inode=canonical, nlink=count)
        else:
            assert_identity(item['path'], item)
    if temp is not None:
        assert_identity(temp, canonical, inode=canonical, nlink=count)


def append_event(path, event):
    # No rewrite/truncation of the journal; each transition is durable first.
    with Path(path).open('ab') as stream:
        stream.write((json.dumps(event, sort_keys=True) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())


def link_exact(members, journal, before_each=lambda: None):
    assert len(members) == 8 and len({x['path'] for x in members}) == len(members)
    assert len({(x['dev'], x['inode']) for x in members[:7]}) == 1
    assert len({(x['dev'], x['inode']) for x in members}) == 2
    assert all(x['nlink'] == 7 for x in members[:7]) and members[7]['nlink'] == 1
    assert len({x['dev'] for x in members}) == 1
    assert len({(x['mode'], x['uid'], x['gid'], x['sha256'], x['size']) for x in members}) == 1
    assert not Path(journal).exists(), 'new journal required'
    linked = set(range(1, 7))
    state(members, linked)
    temporary = [Path(item['path']).with_name(Path(item['path']).name + '.receipt-dedup-pending')
                 for item in members[7:]]
    assert all(not os.path.lexists(p) for p in temporary), 'temporary name already exists'
    append_event(journal, dict(event='initial_verified', originals=members,
                              expected_alias_count=7, temporary_paths=list(map(str, temporary))))
    for index, temp in enumerate(temporary, 7):
        before_each()
        state(members, linked)
        assert not os.path.lexists(temp)
        append_event(journal, dict(event='before_link', index=index, temp=str(temp),
                                  destination=members[index]['path'], expected_alias_count=1 + len(linked)))
        os.link(members[0]['path'], temp, follow_symlinks=False)
        state(members, linked, temp=temp)
        append_event(journal, dict(event='temporary_link_verified', index=index,
                                  expected_alias_count=2 + len(linked)))
        # All named public paths exist throughout. Only the destination inode changes.
        os.replace(temp, members[index]['path'])
        directory = os.open(temp.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        linked.add(index)
        assert not os.path.lexists(temp)
        state(members, linked)
        append_event(journal, dict(event='replacement_verified', index=index,
                                  expected_alias_count=1 + len(linked),
                                  paths=[dict(path=x['path'], **metadata(x['path'])) for x in members]))
    state(members, set(range(1, len(members))))
    append_event(journal, dict(event='complete', expected_alias_count=len(members),
                              all_original_paths_present=True, bytes_unchanged=True))
