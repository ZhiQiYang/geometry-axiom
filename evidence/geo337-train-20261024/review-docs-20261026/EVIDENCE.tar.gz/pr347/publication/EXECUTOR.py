"""Publish the reviewed source identity correction through an ordinary fast-forward ref update."""
import argparse, base64, hashlib, json, os, shutil, sys
from pathlib import Path

ROOT = Path('/tmp/geo347-base-body-correction-20261026')
BRANCH = 'codex/issue128-empty-panel-rows-20261024-prbody'
OLD = '0109cab1a638cd5baa52673e83b136265c10f722'
DOC_SHA = '1b8b7febbdf70250acc5893b1f3a4ff9405b2c39d384112abcbb14720734797c'
OLD_SHA = 'fea35f60ee7a3f274ce134af846b3e7074bd83fcb9a228da5c7b78789ddb31db'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')

def need(ok, why):
    if not ok:
        raise RuntimeError(why)

def h(b):
    return hashlib.sha256(b).hexdigest()

ap = argparse.ArgumentParser()
ap.add_argument('--execute', action='store_true')
a = ap.parse_args()
need(not sys.flags.optimize, 'optimized guards forbidden')
doc = (ROOT/'PR_BODY.md').read_bytes()
old = (ROOT/'ORIGINAL_PR_BODY.md').read_bytes()
peer = json.loads((ROOT/'PEER.json').read_bytes())
need(h(doc) == DOC_SHA and h(old) == OLD_SHA, 'frozen documents changed')
need(peer['exit_code'] == 0 and not peer['blocking'] and peer['document_sha256'] == DOC_SHA, 'peer mismatch')
need(h(CAP.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'capture drift')
if not a.execute:
    print(json.dumps({'execute': False, 'branch': BRANCH, 'expected_parent': OLD, 'sha256': DOC_SHA}))
    sys.exit(0)

# Preserve both existing planning and actual-output-mount reserves. No mount/limit changes.
used = 0
seen = set()
for root in [Path('/dev/shm/geometry-axiom-geo337-20261025'), Path('/dev/shm/geo337-F9-browsers-20261025')]:
    need(root.is_dir() and not root.is_symlink(), 'missing or aliased existing OWN root')
    for p in root.rglob('*'):
        st = p.lstat()
        key = st.st_dev, st.st_ino
        if key not in seen:
            seen.add(key)
            used += st.st_blocks * 512
need(used + 67108864 <= 2147483648, 'original two-OWN planning guard')
need(shutil.disk_usage(ROOT).free >= 67108864, 'actual TMP metadata reserve')
out = ROOT/'publication'
out.mkdir(exist_ok=False)
(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
sys.path.insert(0, str(CAP.parent))
from capture import Recorder
env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env['PYTHONDONTWRITEBYTECODE'] = '1'
rec = Recorder(out, env, OLD)
result = {'exit_code': 1, 'branch': BRANCH, 'expected_parent': OLD, 'published': False,
          'publish_attempted': False,
          'delivered': False, 'PR_application_verified': False, 'product_modified': False,
          'capacity': {'two_OWN_used': used, 'retained_reserve': 67108864}}

def api(method, path, payload=None, raw=False):
    argv = ['gh', 'api', '--hostname', 'github.com', '--method', method]
    if raw:
        argv += ['-H', 'Accept: application/vnd.github.raw+json']
    argv += ['repos/ZhiQiYang/geometry-axiom/'+path]
    data = None
    if payload is not None:
        argv += ['--input', '-']
        data = (json.dumps(payload, ensure_ascii=False)+'\n').encode()
    row, b, err = rec.run(argv, cwd=ROOT, data=data, timeout=180, check=False)
    need(row['actual_process_returncode'] == 0, 'API command failed: '+row['directory'])
    return b if raw else json.loads(b)

try:
    need(api('GET', 'git/ref/heads/'+BRANCH)['object']['sha'] == OLD, 'body ref moved')
    need(api('GET', 'contents/PR_BODY.md?ref='+OLD, raw=True) == old, 'remote old body drift')
    parent = api('GET', 'git/commits/'+OLD)
    blob = api('POST', 'git/blobs', {'content': base64.b64encode(doc).decode(), 'encoding': 'base64'})['sha']
    need(blob == hashlib.sha1(b'blob '+str(len(doc)).encode()+b'\0'+doc).hexdigest(), 'blob OID mismatch')
    tree = api('POST', 'git/trees', {'base_tree': parent['tree']['sha'], 'tree': [
        {'path':'PR_BODY.md','mode':'100644','type':'blob','sha':blob}]})['sha']
    commit = api('POST', 'git/commits', {
        'message':'docs: distinguish product parent from current PR base',
        'tree':tree, 'parents':[OLD]})
    sha = commit['sha']
    need([p['sha'] for p in commit['parents']] == [OLD] and commit['tree']['sha'] == tree, 'commit scope drift')
    comparison = api('GET', 'compare/'+OLD+'...'+sha)
    need(comparison['ahead_by'] == 1 and comparison['behind_by'] == 0, 'unexpected ancestry')
    need([(f['filename'], f['status']) for f in comparison['files']] == [('PR_BODY.md','modified')], 'unexpected file scope')
    need(api('GET', 'git/ref/heads/'+BRANCH)['object']['sha'] == OLD, 'body ref moved before publish')
    # force:false rejects a concurrent divergent update; never rewrites branch history.
    result.update(publish_attempted=True, published=None, pending_commit=sha)
    (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    updated = api('PATCH', 'git/refs/heads/'+BRANCH, {'sha':sha, 'force':False})
    need(updated['object']['sha'] == sha, 'ref update mismatch')
    result.update(published=True, commit=sha, tree=tree, blob=blob)
    need(api('GET', 'git/ref/heads/'+BRANCH)['object']['sha'] == sha, 'remote ref differs')
    full = api('GET', 'git/blobs/'+blob, raw=True)
    need(full == doc, 'remote body bytes differ')
    need((ROOT/'PR_BODY.md').read_bytes() == doc and (ROOT/'ORIGINAL_PR_BODY.md').read_bytes() == old, 'inputs changed')
    result.update(exit_code=0, delivered=True, bytes=len(doc), sha256=DOC_SHA,
                  ordinary_fast_forward=True, changed_paths=['PR_BODY.md'])
finally:
    (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result))
