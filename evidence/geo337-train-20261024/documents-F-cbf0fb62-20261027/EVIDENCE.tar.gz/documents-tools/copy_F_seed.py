"""Copy one exact stable private F browser source to an existing task-owned SHM mount."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,importlib.util,json,os,shutil,stat,sys,traceback

F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
OWN=Path('/dev/shm/geo337-F9-browsers-20261025')
SCOPE=OWN/'Fd27'
DEST=SCOPE/'seed/source';GD=SCOPE/'seed/gitdir';OUT=SCOPE/'seed-copy-original'
SOURCE=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026')
NATIVE=Path('/tmp/train337-323-f64d638f-source')
META=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026/.git')
PLAN=Path('/dev/shm/geo337-F9-browsers-20261025/Fd27/plan/PLAN.json')
# This generated plan is pinned by the root's hash-bound execution request.
PREPARER=Path('/workspace/geo337-F9-five-browser-shm-preparation-20261025/browser_readonly_pool_preparer_single_job_shm_v2.py')
PREPARER_PIN='29e3248c3d09dac2977e0f85e5814f15aede0cbbfe743b7bad573f547dd188f7'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
RESERVE=64*1024*1024
CAPACITY_PLAN=Path('/tmp/geo-F-documents-20261027/CAPACITY.json')
CAPACITY_PIN='fd4c785cdfe5c5d68323732fb749c26b333888461973184724b674fc47b0ceda'

def need(ok,label):
    if not ok:raise AssertionError(label)
def H(raw):return hashlib.sha256(raw).hexdigest()
def J(path):return json.loads(Path(path).read_bytes())
def dump(path,data):
    with Path(path).open('w') as f:
        f.write(json.dumps(data,ensure_ascii=False,indent=2)+'\n');f.flush();os.fsync(f.fileno())
def no_alias(path):
    p=Path(path);need(p.is_absolute() and '..' not in p.parts,'absolute unaliased path')
    need(all(not x.is_symlink() for x in (p,*p.parents)),'no path symlink')
def metadata(path):
    s=Path(path).lstat()
    return dict(dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def raw_read(path):
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME),'rb') as f:return f.read()
def blob_id(raw):return hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()
def inspect_item(item,source,native):
    p=Path(source)/item['path'];n=Path(native)/item['path'];no_alias(p);no_alias(n)
    before=metadata(p);nm=metadata(n)
    need(stat.S_ISREG(before['mode']) and before['uid']==os.getuid() and before['nlink']==1,'exclusive owned private source regular nlink1')
    need(stat.S_ISREG(nm['mode']) and (before['dev'],before['inode'])!=(nm['dev'],nm['inode']),'native inode independent')
    raw=raw_read(p)
    need(len(raw)==item['bytes'] and blob_id(raw)==item['git_blob'],'exact original source Git bytes')
    need(bool(before['mode']&0o111)==(item['mode']=='100755'),'exact original executable mode')
    need(metadata(p)==before,'stable original source')
    return dict(item=item,sha256=H(raw),original=before,native_device=nm['dev'],native_inode=nm['inode'])
def copy_one(row,source,destination):
    item=row['item'];src=Path(source)/item['path'];dst=Path(destination)/item['path'];no_alias(src);no_alias(dst)
    need(metadata(src)==row['original'],'fresh original metadata before copy')
    raw=raw_read(src);need(H(raw)==row['sha256'] and blob_id(raw)==item['git_blob'] and len(raw)==item['bytes'],'fresh exact original bytes before copy')
    dst.parent.mkdir(parents=True,exist_ok=True)
    # O_EXCL prevents overwriting any previously created source or evidence.
    fd=os.open(dst,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(raw);f.flush();os.fsync(fd)
    finally:os.close(fd)
    dst.chmod(0o555 if item['mode']=='100755' else 0o444)
    after=metadata(dst);back=raw_read(dst)
    need(after['nlink']==1 and (after['dev'],after['inode'])!=(row['original']['dev'],row['original']['inode']) and (after['dev'],after['inode'])!=(row['native_device'],row['native_inode']),'new copy inode independently allocated')
    need(back==raw and H(back)==row['sha256'] and blob_id(back)==item['git_blob'] and bool(after['mode']&0o111)==(item['mode']=='100755') and not after['mode']&0o222,'copied exact bytes and Git mode')
    need(metadata(src)==row['original'] and H(raw_read(src))==row['sha256'],'original bytes/mode/nlink/metadata untouched')
    return dict(path=item['path'],sha256=H(back),git_blob=blob_id(back),destination=after)
def validate_source_state(value):
    need(value['head']==F and value['status']=='','original exclusive F clean')
def memory_snapshot():
    result={}
    for n in ['memory.max','memory.current','memory.events','memory.stat']:
        result[n]=Path('/sys/fs/cgroup/'+n).read_text().strip()
    result['meminfo']={k:v.strip() for k,v in (x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemAvailable','MemTotal','Shmem','SwapFree']}
    s=os.statvfs('/dev/shm');result['shm_free_bytes']=s.f_bavail*s.f_frsize
    return result
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--request',type=Path,required=True);ap.add_argument('--request-sha256',required=True);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    need(a.execute and not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ,'explicit execution and assertions')
    qraw=a.request.read_bytes();need(H(qraw)==a.request_sha256,'root request pin');q=json.loads(qraw)
    need(q['source_sha']==F and q['own_root']==str(OWN),'exact F OWN request')
    for k in ['root_execution_lease','root_original_source_stable_exclusive','root_native_source_stable','root_memory_budget_reviewed','root_git_objects_readonly','root_auto_review_shm_execution_approved']:
        need(q[k] is True,'root lease '+k)
    need(H(Path(__file__).read_bytes())==q['executor_sha256'],'exact executor')
    peerraw=Path(q['peer']['path']).read_bytes();peer=json.loads(peerraw)
    need(H(peerraw)==q['peer']['sha256'] and peer['exit_code']==0 and not peer['blocking_findings'] and peer['executor_sha256']==q['executor_sha256'],'independent accepted peer')
    for p,pin in [(PLAN,q['plan_sha256']),(PREPARER,PREPARER_PIN),(CAP,CAP_PIN),(GUARD,GUARD_PIN),(CAPACITY_PLAN,CAPACITY_PIN)]:need(H(p.read_bytes())==pin,'original pin '+str(p))
    capacity=J(CAPACITY_PLAN)['recommended_SHM']
    need(capacity['exact_OWN_root']==str(OWN) and q['whole_round_budget_bytes']==capacity['retained_plus_active_margin_budget_bytes'],'exact shared whole-round capacity plan')
    plan=J(PLAN);need(plan['sha']==F and len(plan['items'])==3759 and sum(x['bytes'] for x in plan['items'])==139053739,'exact selected browser3759 bytes')
    need(plan['pool_rounded_4k']==148230144 and plan['metadata_git']==str(META),'exact original source page/reference metadata')
    for p in [OWN,DEST,GD,OUT,SOURCE,NATIVE]:no_alias(p)
    need(all(not p.exists() for p in [DEST,GD,OUT]) and SOURCE!=DEST and NATIVE!=DEST,'fresh source/Gitdir/OUT; no overlap')
    locks=[];result=dict(schema='F-one-time-exact-SHM-seed-copy/1',source_sha=F,source=str(SOURCE),native=str(NATIVE),destination=str(DEST),private_gitdir=str(GD),exit_code=1,product_test_run=False,old_seed_mutated=False,copy_method='O_EXCL ordinary copy; no cross-filesystem link',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),root_request_sha256=a.request_sha256,partial_failure_policy='Retain all new partial SHM data and original streams; no automatic cleanup/fallback/unfreeze.')
    try:
        for name in ['heavy','secondary']:
            p=Path('/tmp/g261r3')/(name+'.lock');s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink(),'existing original scheduler lock')
            fd=p.open('r+b');locks.append(fd);need((os.fstat(fd.fileno()).st_dev,os.fstat(fd.fileno()).st_ino)==(s.st_dev,s.st_ino),'lock inode');fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        OWN.mkdir(mode=0o700,exist_ok=True);need(OWN.stat().st_uid==os.getuid() and OWN.stat().st_dev==Path('/dev/shm').stat().st_dev,'owned existing SHM device')
        result['memory_before']=memory_snapshot()
        # Original grouped reserve is retained once; one-time payload is additional.
        required=plan['pool_rounded_4k']+plan['split_resource_components']['metadata_bytes']+plan['split_resource_components']['source_directory_and_private_bytes']+RESERVE
        result['space_admission']=dict(required_bytes=required,reserve_bytes=RESERVE,estimate_not_runtime_peak=True,whole_round_budget_bytes=q['whole_round_budget_bytes'])
        need(q['whole_round_budget_bytes']>=required and result['memory_before']['shm_free_bytes']>=q['whole_round_budget_bytes'],'fresh approved whole-round allocation fits SHM')
        OUT.mkdir();(OUT/'tmp').mkdir()
        env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_')) and k not in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','LD_PRELOAD']};env.update(GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_NOSYSTEM='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'tmp'),LANG='C.UTF-8',LC_ALL='C.UTF-8')
        spec=importlib.util.spec_from_file_location('c387',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT/'commands',env,F)
        def git(cwd,args,data=None):
            r,so,se=rec.run(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=cwd,data=data,check=False,timeout=None,source_sha=F,source_variant='one-time copied F seed preparation; no product gate')
            need(r['actual_process_returncode']==0 and not r['timeout_expired'],'original Git true0');return so
        def state(root):
            return dict(head=git(root,['rev-parse','HEAD']).decode().strip(),tree=git(root,['rev-parse','HEAD^{tree}']).decode().strip(),status=git(root,['status','--porcelain=v1','--untracked-files=all']).decode(),refs_sha256=H(git(root,['for-each-ref','--format=%(objectname) %(refname)'])))
        before=state(SOURCE);validate_source_state(before)
        old_index=Path(git(SOURCE,['rev-parse','--git-path','index']).decode().strip())
        if not old_index.is_absolute():old_index=SOURCE/old_index
        old_index_meta=metadata(old_index);old_index_hash=H(raw_read(old_index))
        tree=git(SOURCE,['ls-tree','-r','-l','-z',F]);need(tree==(PLAN.parent/'TREE.stdout.bin').read_bytes(),'full original F TREE identical')
        selected=[];omitted=[]
        for part in tree.split(b'\0'):
            if not part:continue
            left,name=part.split(b'\t',1);mode,kind,oid,size=left.split();rel=name.decode()
            if rel.startswith(('evidence/','tests/evidence/','tests/release-evidence/')):omitted.append(rel);continue
            need(kind==b'blob' and mode in [b'100644',b'100755'] and not Path(rel).is_absolute() and '..' not in Path(rel).parts,'selected ordinary exact Git leaf')
            selected.append(dict(path=rel,mode=mode.decode(),git_blob=oid.decode(),bytes=int(size),private_copy=rel in ['geometry-web/cdp_sections.golden.json','current_geometry.svg']))
        need(selected==plan['items'] and omitted==plan['omitted_new_checkout_paths'],'original exact3759 selected/omission closure')
        guard={'__name__':'consumer_only'};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard);(OUT/'consumers').mkdir();guard['OUT']=OUT/'consumers';guard['consumer_check']([str(SOURCE),str(NATIVE)])
        originals=[inspect_item(x,SOURCE,NATIVE) for x in selected];dump(OUT/'ORIGINAL_INPUTS.json',originals)
        DEST.mkdir(parents=True);GD.parent.mkdir(exist_ok=True);copied=[]
        with (OUT/'COPY_EVENTS.jsonl').open('w') as log:
            for row in originals:
                event=copy_one(row,SOURCE,DEST);copied.append(event);log.write(json.dumps(event,separators=(',',':'))+'\n');log.flush()
            os.fsync(log.fileno())
        dump(OUT/'COPIED_INPUTS.json',copied)
        git(OWN,['init','--bare','--template=',str(GD)])
        (GD/'objects/info/alternates').write_text(plan['objects']+'\n')
        for key,value in [('core.bare','false'),('core.worktree',str(DEST)),('core.autocrlf','false'),('core.filemode','true'),('core.splitIndex','false'),('gc.auto','0'),('maintenance.auto','false')]:git(OWN,['--git-dir',str(GD),'config','--local',key,value])
        (GD/'HEAD').write_text(F+'\n');(DEST/'.git').write_text('gitdir: '+str(GD)+'\n')
        git(OWN,['--git-dir',str(GD),'read-tree',F])
        git(OWN,['--git-dir',str(GD),'update-index','-z','--skip-worktree','--stdin'],b''.join(p.encode()+b'\0' for p in omitted))
        flags=git(OWN,['--git-dir',str(GD),'ls-files','-v','-z']);flagrows={p[2:].decode():p[:1].decode() for p in flags.split(b'\0') if p}
        need(set(flagrows)==set(omitted)|{x['path'] for x in selected} and all(flagrows[p]=='S' for p in omitted) and all(flagrows[x['path']]=='H' for x in selected),'exact omitted flags, no hidden selected source')
        (DEST/'.git').chmod(0o444)
        for directory in sorted([p for p in DEST.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):directory.chmod(0o555)
        DEST.chmod(0o555)
        need(state(DEST)['head']==F and state(DEST)['status']=='','new exact private Git checkout clean')
        # Invoke the unchanged original seed_pool verifier into an additional,
        # retained own readonly alias pool. This creates no test/job checkout.
        spec=importlib.util.spec_from_file_location('original_preparer',PREPARER);prep=importlib.util.module_from_spec(spec);spec.loader.exec_module(prep)
        verifier=OUT/'original-seed-verifier';pool=SCOPE/'seed/verified-readonly-pool';verifier.mkdir();pool.mkdir()
        inherited=os.environ.copy()
        try:
            os.environ.clear();os.environ.update(env)
            manifest=prep.seed_pool(verifier,pool,plan,DEST,NATIVE)
        finally:
            os.environ.clear();os.environ.update(inherited)
        for directory in sorted([p for p in pool.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):directory.chmod(0o555)
        pool.chmod(0o555)
        need(len(manifest)==3759,'original seed verifier complete3759')
        for row in originals:
            need(inspect_item(row['item'],SOURCE,NATIVE)==row,'original source physical/content state unchanged')
            d=DEST/row['item']['path'];a=pool/row['item']['path'];m=metadata(d)
            need(H(raw_read(d))==row['sha256'] and m['nlink']==2 and (m['dev'],m['inode'])==(metadata(a)['dev'],metadata(a)['inode']),'new seed exactly own verified alias pair')
        after=state(SOURCE);newstate=state(DEST)
        need(before==after and metadata(old_index)==old_index_meta and H(raw_read(old_index))==old_index_hash,'original HEAD/index/refs/nlinks untouched')
        need(newstate['head']==F and newstate['status']=='','new seed after original verifier clean F')
        result['memory_after']=memory_snapshot()
        def events(snapshot):return dict((k,int(v)) for k,v in map(str.split,snapshot['memory.events'].splitlines()))
        eb,ea=events(result['memory_before']),events(result['memory_after'])
        need(all(ea.get(k,0)==eb.get(k,0) for k in ['oom','oom_kill','oom_group_kill']),'no new OOM counters during own copy window')
        result.update(exit_code=0,items=3759,payload_bytes=139053739,payload_copied_once=True,original_seed_before=before,original_seed_after=after,new_seed_state=newstate,original_seed_pool_verifier_zero=True,verified_alias_pool=str(pool),original_index_sha256=old_index_hash,native_inodes_independent=True)
    except BaseException:result['error']=traceback.format_exc()
    finally:
        result['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if OUT.exists():dump(OUT/'RESULT.json',result)
        for fd in reversed(locks):fd.close()
    print(json.dumps({k:result.get(k) for k in ['exit_code','items','payload_bytes','product_test_run']}));return result['exit_code']

if __name__=='__main__':raise SystemExit(main())
