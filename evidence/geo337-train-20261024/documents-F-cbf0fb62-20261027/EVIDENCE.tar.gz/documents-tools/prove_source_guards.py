"""Tiny private-fixture proof: never read or mutate the real F source."""
from pathlib import Path
import datetime,hashlib,json,os,sys,traceback,types
ROOT=Path(__file__).parent
TOOL=ROOT/'copy_F_seed.py'
OUT=ROOT/'guard-proof'

def load(source):
 m=types.ModuleType('fixture_subject');exec(compile(source,str(TOOL),'exec'),m.__dict__);return m

def main():
 assert not OUT.exists();OUT.mkdir(mode=0o700)
 raw=TOOL.read_text();m=load(raw);rows=[]
 def fixture(name,data=b'private fixture\n'):
  root=OUT/name;source=root/'source';native=root/'native';source.mkdir(parents=True);native.mkdir()
  p=source/'leaf';n=native/'leaf';p.write_bytes(data);n.write_bytes(data);p.chmod(0o600);n.chmod(0o600)
  item=dict(path='leaf',bytes=len(data),git_blob=m.blob_id(data),mode='100644')
  return root,source,native,item
 def run(name,fn,expected=0):
  path=OUT/name;path.mkdir(exist_ok=True)
  try:fn();actual=0;message='PASS\n'
  except BaseException:actual=1;message=traceback.format_exc()
  (path/'stdout.bin').write_text('');(path/'stderr.bin').write_text(message)
  rows.append(dict(case=name,actual_exit=actual,expected_exit=expected,matched=actual==expected,stderr_sha256=hashlib.sha256(message.encode()).hexdigest()))
  print(json.dumps(rows[-1]))
 def reject(fn):
  try:fn()
  except (AssertionError,OSError):return
  raise AssertionError('Invalid fixture was accepted')
 # Exact approved private-source transport works without chmod/source inode changes.
 _,src,nat,item=fixture('valid-private')
 before=m.metadata(src/'leaf');row=m.inspect_item(item,src,nat)
 run('valid-copy',lambda:m.copy_one(row,src,OUT/'valid-copy'/'destination'))
 assert m.metadata(src/'leaf')==before
 # Reinstating the old readonly guard rejects precisely this authorized private source.
 old=load(raw.replace("stat.S_ISREG(before['mode']) and before['uid']==os.getuid() and before['nlink']==1", "stat.S_ISREG(before['mode']) and before['uid']==os.getuid() and not before['mode']&0o222"))
 run('withdraw-private-adaptation',lambda:old.inspect_item(item,src,nat),1)
 run('restore-private-adaptation',lambda:m.inspect_item(item,src,nat))
 # Every adversarial input lives in a distinct small fixture. No real source touched.
 _,s,n,i=fixture('hardlink-fixture');os.link(s/'leaf',s/'alias')
 run('hardlink-rejected',lambda:reject(lambda:m.inspect_item(i,s,n)))
 mutant=load(raw.replace("and before['nlink']==1", "and True"))
 run('withdraw-hardlink-guard',lambda:reject(lambda:mutant.inspect_item(i,s,n)),1)
 run('restore-hardlink-guard',lambda:reject(lambda:m.inspect_item(i,s,n)))
 _,s,n,i=fixture('symlink-fixture');(s/'alias').symlink_to(s/'leaf');i=dict(i,path='alias');(n/'alias').write_bytes(b'private fixture\n')
 run('symlink-rejected',lambda:reject(lambda:m.inspect_item(i,s,n)))
 _,s,n,i=fixture('wrong-bytes-fixture');(s/'leaf').write_bytes(b'private fixture!')
 run('wrong-git-bytes-rejected',lambda:reject(lambda:m.inspect_item(i,s,n)))
 _,s,n,i=fixture('mode-fixture');(s/'leaf').chmod(0o700)
 run('git-mode-rejected',lambda:reject(lambda:m.inspect_item(i,s,n)))
 _,s,n,i=fixture('drift-fixture');r=m.inspect_item(i,s,n);(s/'leaf').chmod(0o640)
 run('metadata-drift-rejected',lambda:reject(lambda:m.copy_one(r,s,OUT/'unused-drift-destination')))
 run('dirty-source-rejected',lambda:reject(lambda:m.validate_source_state(dict(head=m.F,status=' M leaf\n'))))
 run('wrong-head-rejected',lambda:reject(lambda:m.validate_source_state(dict(head='0'*40,status=''))))
 run('clean-source-accepted',lambda:m.validate_source_state(dict(head=m.F,status='')))
 report=dict(schema='private-F-source-guard-fixture-proof/1',source_tool=str(TOOL),executor_sha256=hashlib.sha256(TOOL.read_bytes()).hexdigest(),exit_code=0 if all(r['matched'] for r in rows) else 1,rows=rows,real_F_source_accessed=False,product_test_run=False,created_files_retained=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (OUT/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');return report['exit_code']
if __name__=='__main__':raise SystemExit(main())
