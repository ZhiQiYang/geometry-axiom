"""Four explicit root checkpoints; captures exact original commands, never retries."""
from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,stat,sys,traceback
ROOT=Path(__file__).parent
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
OWN=Path('/dev/shm/geo337-F9-browsers-20261025');OTHER=Path('/dev/shm/geometry-axiom-geo337-20261025');SCOPE=OWN/'Fd27'
SOURCE=OTHER/'a6-architecture-source-20261026';PLAN=SCOPE/'plan';LAYOUT=SCOPE/'source-layout';SEED=SCOPE/'seed/source';NATIVE=Path('/tmp/train337-323-f64d638f-source')
PREPARER=Path('/workspace/geo337-F9-five-browser-shm-preparation-20261025/browser_readonly_pool_preparer_single_job_shm_v2.py')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
STAGES=('plan','copy','materialize','launch')
def need(v,msg):
 if not v:raise RuntimeError(msg)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def save(p,v):
 with Path(p).open('x') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n');f.flush();os.fsync(f.fileno())
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=STAGES,required=True);ap.add_argument('--peer-sha256',required=True);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 need(a.execute and not sys.flags.optimize and 'PYTHONOPTIMIZE' not in os.environ,'ROOT_EXPLICIT_EXECUTION')
 peerpath=ROOT/'EXECUTION_PEER.json';need(h(peerpath)==a.peer_sha256,'PINNED_STATIC_PEER');peer=json.loads(peerpath.read_bytes());need(peer['exit_code']==0 and not peer['blocking_findings'],'STATIC_PEER_ZERO')
 for name in ['root_steps.py','copy_F_seed.py','launch_F_documents.py','sample_F_documents.py','CAPACITY.json']:need(h(ROOT/name)==peer['reviewed_tools'][name]['sha256'],'PINNED_TOOL:'+name)
 need(h(CAP)==CAP_PIN,'ORIGINAL_CAPTURE_PIN');need(h(PREPARER)=='29e3248c3d09dac2977e0f85e5814f15aede0cbbfe743b7bad573f547dd188f7','ORIGINAL_PREPARER_PIN')
 cap=load(CAP,'capture_root_steps');sample=load(ROOT/'sample_F_documents.py','readonly_sampler_helpers')
 # These are same-task planning estimates, separate from unchanged formal assertions/time limits.
 used=sample.inventory([OWN,OTHER]);budget=json.loads((ROOT/'CAPACITY.json').read_bytes())['recommended_SHM'];increment=budget['retained_plus_active_margin_budget_bytes'] if a.stage in ['plan','copy'] else (704*1024**2 if a.stage=='materialize' else sample.RUNTIME_PLANNING_INCREMENT)
 free=os.statvfs('/dev/shm');freebytes=free.f_bavail*free.f_frsize
 need(used['unique_allocated_bytes']+increment<=4*1024**3 and freebytes>=increment,'FRESH_4GiB_AND_REAL_SHM_ADMISSION')
 need(OWN.stat().st_uid==os.getuid() and OWN.stat().st_dev==Path('/dev/shm').stat().st_dev,'OWN_EXISTING_REAL_SHM')
 for p in [SCOPE,PLAN,LAYOUT,SEED]:need(all(not q.is_symlink() for q in (p,*p.parents)),'NO_PATH_ALIAS')
 if a.stage=='plan':need(not SCOPE.exists(),'FRESH_SCOPE');SCOPE.mkdir(mode=0o700);(SCOPE/'control').mkdir(mode=0o700)
 else:
  previous=STAGES[STAGES.index(a.stage)-1];r=json.loads((SCOPE/'control'/previous/'RESULT.json').read_bytes());need(r['exit_code']==0 and r['source_sha']==F,'PREVIOUS_TRUE_ZERO')
 out=SCOPE/'control'/a.stage;need(not out.exists(),'NO_OVERWRITE_OR_RETRY');out.mkdir(mode=0o700)
 env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO261_','GEO323_')) and k not in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','NODE_OPTIONS','LD_PRELOAD']};env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_NOSYSTEM='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
 rec=cap.Recorder(out,env,F);report=dict(stage=a.stage,source_sha=F,exit_code=1,commands=rec.rows,planning=dict(own_allocated_before=used['unique_allocated_bytes'],increment_estimate=increment,ceiling=4*1024**3,physical_shm_free=freebytes,proven_worst_case=False),errors=[]);locks=[]
 try:
  if a.stage=='plan':
   argv=[sys.executable,'-B',str(PREPARER),'--git-dir',str(SOURCE/'.git'),'--sha',F,'--out',str(PLAN),'--source-layout',str(LAYOUT),'--job','documents']
  elif a.stage=='copy':
   q=dict(source_sha=F,own_root=str(OWN),executor_sha256=h(ROOT/'copy_F_seed.py'),peer=dict(path=str(peerpath),sha256=a.peer_sha256),plan_sha256=h(PLAN/'PLAN.json'),whole_round_budget_bytes=budget['retained_plus_active_margin_budget_bytes'])
   for k in ['root_execution_lease','root_original_source_stable_exclusive','root_native_source_stable','root_memory_budget_reviewed','root_git_objects_readonly','root_auto_review_shm_execution_approved']:q[k]=True
   request=out/'REQUEST.json';save(request,q);argv=[sys.executable,'-B',str(ROOT/'copy_F_seed.py'),'--execute','--request',str(request),'--request-sha256',h(request)]
  elif a.stage=='materialize':
   for name in ['heavy','secondary']:
    p=Path('/tmp/g261r3')/(name+'.lock');st=p.lstat();need(stat.S_ISREG(st.st_mode) and st.st_nlink==1 and not p.is_symlink(),'EXISTING_LOCK');f=p.open('r+b');locks.append(f);need((os.fstat(f.fileno()).st_dev,os.fstat(f.fileno()).st_ino)==(st.st_dev,st.st_ino),'LOCK_IDENTITY');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   argv=[sys.executable,'-B',str(PREPARER),'--out',str(PLAN),'--materialize-authorized','--seed-freeze-authorized','--reuse-seed',str(SEED),'--native-root',str(NATIVE)]
  else:
   # Bind the actual original preparer result, not a constructed pass receipt.
   prep=SCOPE/'control/materialize/subcommands/000001/result.json';p=json.loads(prep.read_bytes());need(p['actual_process_returncode']==0 and not p['timeout_expired'],'MATERIALIZER_TRUE_ZERO')
   q=dict(schema='geo337-F-single-browser-launch/1',source_sha=F,job='documents',root_scheduled_single_browser=True,root_execution_lease=True,resource_lock='heavy',plan_dir=str(PLAN),source_layout=str(LAYOUT),out=str(SCOPE/'launch-original'),storage=str(OWN/'r/fd'),plan_sha256=h(PLAN/'PLAN.json'),source_preparation=dict(path=str(prep),sha256=h(prep)))
   lp=out/'LAUNCH_REQUEST.json';save(lp,q)
   s=dict(schema='geo337-F-browser-sampled-launch/1',source_sha=F,job='documents',root_execution_lease=True,root_single_job_shared_SHM_budget_window=True,launch_request=dict(path=str(lp),sha256=h(lp)),launch_argv=[sys.executable,'-B',str(ROOT/'launch_F_documents.py'),'--request',str(lp),'--request-sha256',h(lp)],out=str(SCOPE/'sample-original'))
   request=out/'SAMPLED_REQUEST.json';save(request,s);argv=[sys.executable,'-B',str(ROOT/'sample_F_documents.py'),'--request',str(request),'--request-sha256',h(request)]
  row,stdout,stderr=rec.run(argv,cwd='/workspace',timeout=None,check=False,source_sha=F,source_variant='root-fixed-F-documents-'+a.stage)
  report['exit_code']=row['actual_process_returncode'];report['formal_launch_invoked']=a.stage=='launch'
  need(row['actual_process_returncode']==0 and not row['timeout_expired'],'ORIGINAL_COMMAND_NONZERO:'+str(row['directory']))
 except BaseException:report['errors'].append(traceback.format_exc());report['exit_code']=report['exit_code'] or 1
 finally:
  for f in reversed(locks):f.close()
  save(out/'RESULT.json',report)
 print(json.dumps({k:report[k] for k in ['stage','source_sha','exit_code','errors']}));return report['exit_code']
if __name__=='__main__':raise SystemExit(main())
