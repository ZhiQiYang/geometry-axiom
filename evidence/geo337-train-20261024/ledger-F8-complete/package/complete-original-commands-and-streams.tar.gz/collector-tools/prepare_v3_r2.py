from pathlib import Path
import hashlib,importlib.util,json,os,sys,datetime
B=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();F8='75a1e93811a52b69385cbdaf6a09d773ed9052ad';CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert H(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('c387_scope_proof',CAP);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_')) and k not in ['PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE']};env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
r=m.Recorder(B/'process-scope-original-capture-r2',env,F8);rows=[]
for phase,expected in [('fixed',0),('withdrawn',1),('restored',0)]:
 row,stdout,stderr=r.run([sys.executable,'-B',str(B/'check_process_scope.py'),'--phase',phase,'--out',str(B/'process-scope-fixtures-r2'/phase)],cwd=B,timeout=30,check=False,source_variant='private fake proc/locks only; original v2 withdrawal; no real proc or product read')
 rows.append({'phase':phase,'expected_exit':expected,'actual_exit':row['actual_process_returncode'],'original_command':row})
 assert row['actual_process_returncode']==expected,(phase,row['actual_process_returncode'],stderr)
proof={'schema':'F8-terminal-process-scope-synthetic-proof/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exits':[x['actual_exit'] for x in rows],'rows':rows,'exit':0,'cases_per_phase':13,'original_v2_withdrawal':True,'real_proc_read':False,'global_locks_used':False,'source_or_product_modified':False,'formal_executed':False};(B/'PROCESS_SCOPE_PROOF.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actual_exits':proof['actual_exits'],'cases_per_phase':13,'proof_sha256':H((B/'PROCESS_SCOPE_PROOF.json').read_bytes()),'formal_executed':False}))
