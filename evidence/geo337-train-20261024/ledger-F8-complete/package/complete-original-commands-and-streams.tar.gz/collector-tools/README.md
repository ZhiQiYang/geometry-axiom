# V3：保留全部正式裁判與收件守門，只釐清跨 UID 的 cwd 權限範圍

目前版本為 v3。v2 未授權與正式授權兩次 verify 都已真 exit1，均未進 collect 或改 source；首例 PID1 UID1000 需正式工具審批環境才可讀，第二例 dockerd PID208 UID65534 的 cwd 仍無權讀。原失敗與權限界線保留，不改程序權限／安全設定，也不偷偷忽略錯誤。

root 已核定：原 producer 都是本任務 UID1000，原正式命令沒有 sudo/docker/升權操作；protected ROOT/job/cache/tmp/outer 的 owner 同 UID。本工具再強制 caller real/effective/saved UID相同、五個目標目錄 owner匹配。collector仍須在正式獲批執行環境，否則同 UID的 PID1 cwd不可讀仍會拒絕。

v3 對 `/proc/PID/cwd` PermissionError只做以下精確分類：原 cmdline 必已可讀、不能命中任何 protected path；status 必有精確同PID與唯一四個合法 UID，四者均不含 task UID。符合者才記為跨UID cwd未知，保完整argv／UID／status hash／errno。任何同UID、mixedUID、UID不明、status不可讀、cmdline不可讀或 argv 命中皆繼續拒絕。可讀 cwd 命中也照舊拒絕，無 PID／程序名特例。此處不是宣稱所有系統 cwd 都可見；`PROCESS_SCOPE.json` 與 INDEX.process_scope 明載未知項目與界線。

原 locks 仍 heavy＋secondary NB，原完整 root終態、4phase、123/120F8/3retired、map/bridge、來源一致、資源入場、逐葉before/during/after、tar regular member/hash/closure、原範圍全未變。verify/collect 的原 CLI只換新工具目錄及 PREPARATION pin，使用相同新 BOUND request；不重跑 full123。root先verify，再collect，並公開PROCESS_SCOPE與首兩次v2紅燈。

新 proof 用真正原v2 context manager做撤回、v3固定／恢復，13 cases×3，原0/1/0；只私有 fake proc目錄及私有locks，不占真全域鎖或讀產品。首輪 fake Path constructor有隔離缺陷，意外讀真/proc並由同UID守門擋住，原流與誤述全部保留，詳 INITIAL_SYNTHETIC_ISOLATION_CORRECTION.json。r2同時修__init__映射並在調用前assert exact fake path；新原流在process-scope-original-capture-r2。現場 verify/collect 尚未由此準備執行。

以下保留 v2 原工具說明，『所有 cwd consumer』須按上述本任務UID與顯式跨UID未知界線解讀；其他正式與保全條件完全沿用。

# F8 完整帳本終態收件草稿：尚未收件、尚未採用

本目錄現在只備工具，沒有掃描、凍結或雜湊正在執行的 JOB/cache/outer payload。只能由 root 收到原 exec 真終態後，另存新的 BOUND_REQUEST.json 與原工具 FINAL 回應，再以已審工具執行。原未綁 request 不覆寫。

沿 `/workspace/prepare_geo337_ledger_4f4_terminal.py` 的原範圍：JOB 與原 outer 全部 regular 原件；cache 只有 M*、_baseline、_bridge-baseline 中 `.stdout/.stderr/.json`；原 driver/observer/map/capture/reaper 以及此輪 launcher/resource helper。額外帶入本收件工具與真 terminal 控制原件。未加入 ELF、source tree、Git objects 或整個 cache payload；observer 原件中 inline source preflight 仍原樣保留。所有原路徑保留，無 delete/move/link/checkout。

`verify_terminal.py` 只核真終態 metadata；`collect_terminal.py` 再核同一綁定，才列出原範圍並封包。兩者都先取得既有 heavy＋secondary 非阻塞鎖，確認 original ROOT/job/cache/tmp/outer 沒有 argv 或 cwd consumer，且要求 root 獨占 lease。原 final tool JSON 必為原 exec 回應形狀：整數 exit_code、無存活 session_id，與原 outer/root 結束碼一致。若外部工具回應封裝不同，先另審精確 adapter，不捏造回應或擷取假 terminal。

只有 CLI0/root0/outer0、原完整4phase（舊tracked check如實保留，full/map/newcheck各0）、observer complete、原map/bridge完整、123列/120個自然F8 head/3 retired、來源前後一致，才列 `formal_accepted=true`。這是原條件交叉核對，不新增突變 verdict 裁判；保留原killed/equivalent/crashed分類。還必須由另一peer核原每列/原流與封包後才可採用。

失敗也能封存已結束的原件：`collection_exit=0` 只表示封包成功；terminal formal_accepted保持false並列所有失敗條件，禁止採用。若缺少原root/outer/tool真終態，工具拒絕，原件仍在原處，不能把正在跑或被截斷的狀態叫terminal。所有結果寫入全新OUT，不覆寫失敗原件。

封包前只在已終態的 scope 列檔/stat；依輸出filesystem計算完整未壓縮大小＋每葉padding/headers＋索引保守額度＋root指定reserve，入場失敗不建OUT。每葉讀取前後metadata一致；tar全部regular、逐葉hash回讀相等，scope與終態pin前後一致。該預算是collector資源入場，不是native/browser預算，不用其他device free抵帳。

root 執行形式（全部未綁，現在不可執行）：

```
python3 -B verify_terminal.py --request <NEW_BOUND_REQUEST> --request-sha256 <ACTUAL_SHA256> --preparation-sha256 <REVIEWED_PREPARATION_SHA256> --out <FRESH_METADATA_OUT> --root-terminal-lease
python3 -B collect_terminal.py --request <SAME_BOUND_REQUEST> --request-sha256 <ACTUAL_SHA256> --preparation-sha256 <REVIEWED_PREPARATION_SHA256> --out <FRESH_PACKAGE_OUT> --reserve-bytes <ROOT_ACCEPTED_SAME_DEVICE_RESERVE> --root-terminal-lease
```

root 需以原 c387 outer 收全 argv/env/exit/stdout/stderr；這兩指令本身不替 root 建另一正式驗收。metadata self-test為純合成分類反例0/1/0，不讀實際run，也不代表帳本已過。採用步驟僅寫在 ADOPTION_PLAN.md，沒有可直接跑的舊b6 IDs或Git寫入工具。當前F8/R8真execution不改標F9。

V2 修正：四個可缺子件 observer/map/bridge/ledger 即使 JSON 截斷、重複鍵、UTF8壞或非object，仍記 raw hash/bytes 並保原件入tar；parse_errors強制formal/adoption false。只有三個根終態綁定保持嚴格拒絕。V1保留未執行，不能用其收件結論替V2。
