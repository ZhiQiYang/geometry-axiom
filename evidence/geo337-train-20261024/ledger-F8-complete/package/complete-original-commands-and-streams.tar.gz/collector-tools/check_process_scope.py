"""Only private tiny fake /proc + private locks, exercising original v2/v3 context managers."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['fixed','withdrawn','restored'],required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();assert not a.out.exists();a.out.mkdir()
HERE=Path(__file__).resolve().parent;old=Path('/tmp/geo337-F8-full123-terminal-preparation-v2-20261025/terminal_guard.py');source=old if a.phase=='withdrawn' else HERE/'terminal_guard.py'
if a.phase=='withdrawn':assert hashlib.sha256(source.read_bytes()).hexdigest()==json.loads((HERE/'PREPARATION.v2-original.json').read_text())['files'][next(i for i,x in enumerate(json.loads((HERE/'PREPARATION.v2-original.json').read_text())['files']) if x['path']=='terminal_guard.py')]['sha256']
spec=importlib.util.spec_from_file_location('synthetic_scope_subject',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[];uid=os.getuid();assert os.getresuid()==(uid,uid,uid);foreign=65534 if uid!=65534 else 65533
cases=[
 ('foreign-denied-recorded',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\n',False,'denied',True),
 ('task-denied-blocked',f'Uid:\t{uid} {uid} {uid} {uid}\n',False,'denied',False),
 ('mixed-task-uid-blocked',f'Uid:\t{foreign} {uid} {foreign} {foreign}\n',False,'denied',False),
 ('missing-uid-blocked','',False,'denied',False),
 ('malformed-uid-blocked','Uid:\tunknown 65534 65534 65534\n',False,'denied',False),
 ('short-uid-blocked','Uid:\t65534 65534 65534\n',False,'denied',False),
 ('duplicate-uid-blocked',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\nUid:\t{foreign} {foreign} {foreign} {foreign}\n',False,'denied',False),
 ('wrong-pid-blocked',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\n',False,'wrong-pid',False),
 ('foreign-argv-hit-blocked',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\n',True,'denied',False),
 ('same-uid-readable-nonconsumer',f'Uid:\t{uid} {uid} {uid} {uid}\n',False,'outside',True),
 ('same-uid-readable-consumer',f'Uid:\t{uid} {uid} {uid} {uid}\n',False,'inside',False),
 ('foreign-readable-consumer',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\n',False,'inside',False),
 ('foreign-cmdline-denial-blocked',f'Uid:\t{foreign} {foreign} {foreign} {foreign}\n',False,'cmdline-denied',False),
]
for n,(label,status,argvhit,mode,allowed) in enumerate(cases):
 root=a.out/label;root.mkdir();fakeproc=root/'proc';fakeproc.mkdir();pid=90101+n;pd=fakeproc/str(pid);pd.mkdir()
 roots=[root/x for x in ['job','outer','cache','source','tmp']]
 for d in roots:d.mkdir()
 (pd/'status').write_text('Pid:\t'+str(pid+1 if mode=='wrong-pid' else pid)+'\n'+status)
 (pd/'cmdline').write_bytes(b'/synthetic/daemon\0'+(str(roots[0]).encode()+b'\0' if argvhit else b'--synthetic-only\0'))
 locks=[root/'heavy.lock',root/'secondary.lock']
 for f in locks:f.touch()
 BasePath=type(Path())
 class FakeProcPath(BasePath):
  def __new__(cls,*args,**kwargs):
   if args==('/proc',):args=(str(fakeproc),)
   return super().__new__(cls,*args,**kwargs)
  def __init__(self,*args,**kwargs):
   if args==('/proc',):args=(str(fakeproc),)
   super().__init__(*args,**kwargs)
  def resolve(self,*args,**kwargs):
   if self.parent==pd and self.name=='cwd':
    if mode in ['denied','wrong-pid','cmdline-denied']:raise PermissionError(13,'synthetic denied cwd',str(self))
    return roots[0] if mode=='inside' else root
   return super().resolve(*args,**kwargs)
  def read_bytes(self):
   if self.parent==pd and self.name=='cmdline' and mode=='cmdline-denied':raise PermissionError(13,'synthetic denied cmdline',str(self))
   return super().read_bytes()
 assert FakeProcPath('/proc')==fakeproc,'synthetic proc mapping must precede original context manager'
 m.Path=FakeProcPath;m.JOB,m.OUTER,m.CACHE,m.ROOT,m.TMP=roots;m.LOCKS=tuple(map(str,locks));seen=None;error=None
 try:
  with m.terminal_lease() as audit:seen=audit
  actual_allowed=True
 except (RuntimeError,PermissionError,UnicodeError) as e:actual_allowed=False;error={'type':type(e).__name__,'text':str(e)}
 ok=actual_allowed==allowed
 if label=='foreign-denied-recorded' and actual_allowed:
  ok=ok and isinstance(seen,dict) and seen['all_system_cwds_inspected'] is False and len(seen['unreadable_foreign_cwds'])==1 and seen['unreadable_foreign_cwds'][0]['uids']==[foreign]*4 and seen['unreadable_foreign_cwds'][0]['cwd_status']=='permission-denied-not-inspected'
 checks.append({'case':label,'expected_allowed':allowed,'actual_allowed':actual_allowed,'passed':bool(ok),'audit':seen,'original_error':error})
r={'phase':a.phase,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'task_uid':uid,'cases':checks,'private_fixture_only':True,'actual_proc_read':False,'actual_global_locks_used':False,'product_test_executed':False,'exit':0 if all(x['passed'] for x in checks) else 1};(a.out/'RESULT.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False));raise SystemExit(r['exit'])
