"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/cold212-and-sevenfinal15-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 manifests=[('/workspace/cold_extra_103_exact_body_manifest_20261024.json','fbdfe5c8d6e9130b9628811d7e0959e760751bca553dc36dec7ecacf324ed0b4'),('/workspace/cold_remaining_109_exact_body_manifest_20261024.json','7dcf606ffdf1bcae72e2f3cf0e43d2e1e427feafc62242f68a1a7fb66d862f2b')]
 items=[]
 for path,pin in manifests:
  assert digest(path)==pin
  m=readj(path);items.extend(m['items']);add(path,'manifest/'+Path(path).name)
 assert len(items)==212 and sum(i['expected_allocated_saving'] for i in items)==401981440
 for i in items:
  name=i['name'];plan=Path(i['plan']);out=Path('/workspace')/(name+'-receipt-archive-three-dedup-execution-20261023');outer=Path('/workspace')/(name+'-receipt-archive-three-dedup-launch-20261024')
  assert digest(plan)==i['plan_sha256'] and digest(i['tool'])==i['tool_sha256']
  r=readj(out/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_three_paths_and_bytes_preserved'] and a['actual_process_returncode']==0
  tree(plan.parent,'preparation/'+name);tree(out,'actual/'+name);tree(outer,'launch/'+name);add(i['tool'],'tools/'+name+'-executor.py')
 for path in ['/tmp/cold_extra_300m_archive_preparation_manifest_20261024.json','/workspace/cold_remaining_109_archive_preparation_manifest_20261024.json','/tmp/cold_extra_300m_archive_scopes_20261024.json','/workspace/cold_remaining_109_archive_scopes_20261024.json','/tmp/cold_remaining_archive_candidates_20261024.json','/tmp/prepare_cold_extra_300m_archive_batch_20261024.py','/workspace/prepare_cold_remaining_109_archive_batch_20261024.py','/tmp/prepare_next_cold_archive_batch.py','/workspace/summarize_prepared_cold_archive_batch_20261024.py']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/cold-extra-103-body-preparation-launch-20261024','/workspace/cold-remaining-109-body-preparation-launch-20261024']:
  tree(path,'preparation-launch/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/deduplicate_release_exact_three_receipts.py','/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 base=Path('/workspace/terminal-sevenfinal-five-browser-15-elf-preparation-20261024')
 p=readj(base/'PLAN.json');assert digest(base/'PLAN.json')=='6b90994e52471f673d89ead8705783a1b29cf543c1edb9d1e8058a8054920c7b'
 assert p['sourceSHA']=='8f76f2b7d6f669670e5834310bfc26495b4a4aa6' and p['target_count']==15
 tree(base,'sevenfinal15/preparation')
 for stem in ['execution','launch']:
  source=Path('/workspace')/('terminal-sevenfinal-exact-15-runtime-elf-retirement-'+stem+'-20261024');tree(source,'sevenfinal15/'+stem)
 for k,x in enumerate(p['sidecars']+p['terminal_receipts']+[p['root_historical_receipt']]):
  assert digest(x['path'])==x['sha256'] and Path(x['path']).stat().st_size==x['bytes']
  add(x['path'],f'sevenfinal15/preserved-originals/{k:02d}-'+Path(x['path']).name)
 for path in ['/tmp/train337-adversarial/COLD_DEFERRED_212_METADATA_PREPARATION_PEER.json','/workspace/train337-canvas-peer-resume/COLD_103_EXACT_THREE_EXECUTOR_STATIC_PEER.json','/workspace/train337-canvas-peer-resume/COLD_109_EXACT_THREE_EXECUTOR_STATIC_PEER.json','/workspace/COLD_212_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json','/workspace/review_cold212_actual_metadata_20261024.py','/workspace/train337-canvas-peer-resume/SEVENFINAL_15_ELF_STATIC_FRESH_PROOF_PEER.json','/workspace/SEVENFINAL_15_ELF_ACTUAL_METADATA_PEER_20261024.json','/workspace/review_sevenfinal15_actual_20261024.py']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 add('/workspace/train337-canvas-peer-resume/COLD212_ACTUAL_SUMMARY_HELPER_PEER.json','peers-and-review-tools/COLD212_ACTUAL_SUMMARY_HELPER_PEER.json')
 add(__file__,'collector.py')
 for path,checks in [('/workspace/COLD_212_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json',21203),('/workspace/SEVENFINAL_15_ELF_ACTUAL_METADATA_PEER_20261024.json',67)]:
  r=readj(path);assert r['exit_code']==0 and r['checks']==checks and not r['findings']
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'cold212-and-sevenfinal15-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='cold212-sevenfinal15-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,archive_alias_groups_added=212,all_established_cold_alias_groups=236,preserving_dedup_allocated_saving=401981440,ordinary_elf_cache_retired_allocated_bytes=14745600,limits=['Maintenance only; no product gate is executed or relabeled.','All636 archive source paths/bytes remain; no actual receipt archive payload or ELF executable bytes duplicated into this package.','All236 existing cold alias groups including24 older groups must be de-linked before any writes/reuse of any of three cold checkouts.','The212 actual review rechecks metadata and all small original command streams, not huge canonical body bytes; original executors performed full physical and Git comparisons.','Historical fifteen runtime ELF cache paths retired after original full identity/hash/consumer guard; source fingerprints, all recipes, sidecars and original receipts preserved.','Physical allocated savings do not equal concurrent global free-space changes.','Independent reviewer reports created after this package remain adjacent attachments, not claimed present in this fixed archive.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
