"""Read-only fresh consumer observation for closed cardref payloads."""
from pathlib import Path
import hashlib
p=Path('/workspace/clear_terminal_chrome_caches.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
g={'__name__':'_original_consumer_only','__file__':str(p)};exec(compile(p.read_bytes(),str(p),'exec'),g)
out=Path(__file__).parent/'fresh-consumer-proof';out.mkdir();g['OUT']=out
g['consumer_check'](['/workspace/train337-final-L-cardref-7af8c5d8/cardref/subject'])
print('original consumer guard: exit 0; read-only; inaccessible process fields remain explicitly unknown')
