"""Root-only preserving hardlinks for two exact closed cardref ELF groups; no deletion."""
from pathlib import Path
import datetime,hashlib,json,os,sys
BASE=Path('/workspace/cardref-preserving-elf-links-preparation-20261024')
PLAN=BASE/'PLAN.json';PIN='d8c7d397aa041080c3b98fadb242069abd12b301d19475fb1c2aa3b4cb08ea58'
CORE=BASE/'cardref_exact_group_link_core.py';CORE_PIN='68dc068b50863a7a53de2874149d66b7f2794b9669c7b03ebf2562f91b70b569'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py');GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/cardref-exact-two-elf-groups-preserving-dedup-execution-20261024')
SUBJECT='/workspace/train337-final-L-cardref-7af8c5d8/cardref/subject'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
 assert h(PLAN)==PIN and h(CORE)==CORE_PIN and h(GUARD)==GUARD_PIN
 core={'__name__':'_exact_link_only','__file__':str(CORE)};exec(compile(CORE.read_bytes(),str(CORE),'exec'),core)
 guard={'__name__':'_original_consumer_only','__file__':str(GUARD)};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard)
 p=json.loads(PLAN.read_text());assert p['source_sha']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
 assert [x['count'] for x in p['groups']]==[58,5] and p['target_count']==63 and p['expected_allocated_saving']==79196160
 hashes=['4abe9f18b4d9ba214bf26d9d200b2d71a32508a5fb5e1efca307a88247263066','3dc5cd7e1ca4657883857eb1acc58b66a5cd3aa1f4f23b0871c06d89a0118aa2']
 inv=json.loads(Path(p['original_excluded_inventory']['path']).read_text());assert len(inv)==116
 assert h(p['original_excluded_inventory']['path'])==p['original_excluded_inventory']['sha256']
 for group,digest in zip(p['groups'],hashes):
  assert group['sha256']==digest
  expected=[x['source_path'] for x in inv if x['sha256']==digest]
  assert len(expected)==group['count'] and [x['path'] for x in group['members']]==expected
  assert all(Path(x).is_relative_to(SUBJECT) for x in expected)
 OUT.mkdir();r=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,source_sha=p['source_sha'],plan_sha256=PIN,core_sha256=CORE_PIN,free_before=guard['free'](),groups=[],all_original_payload_paths_retained=False,actual_replacement_performed=False,reservation=p['reservation'],identity_limit=p['identity_limit'],failure_policy='Preserve journal and any pending aliases on failure; no destructive rollback or cleanup.')
 count=0
 def consumer():
  nonlocal count
  count+=1;target=OUT/f'consumers-{count:03d}';target.mkdir();guard['OUT']=target;guard['consumer_check']([SUBJECT])
  assert h(p['terminal_receipt']['path'])==p['terminal_receipt']['sha256']
 def preserved():
  for x in inv:
   q=Path(x['source_path']);assert q.stat().st_size==x['bytes'] and h(q)==x['sha256']
  for x in p['all_selected_original_receipts_and_compile_artifacts']:
   q=Path(x['source_path']);assert q.stat().st_size==x['bytes'] and h(q)==x['sha256']
  for x in [p['original_inventory'],p['original_excluded_inventory'],p['terminal_receipt']]:assert h(x['path'])==x['sha256']
 try:
  preserved();consumer()
  for i,group in enumerate(p['groups'],1):
   members=group['members'];core['state'](members,set())
   core['link_exact'](members,OUT/f'GROUP-{i}.jsonl',before_each=consumer)
   r['groups'].append(dict(count=len(members),sha256=group['sha256'],expected_allocated_saving=group['expected_allocated_saving'],all_paths_preserved=True,final_metadata=[dict(path=x['path'],**core['metadata'](x['path'])) for x in members]))
   r['actual_replacement_performed']=True;dump(OUT/'PROGRESS.json',r)
  preserved()
  for group in p['groups']:core['state'](group['members'],set(range(1,len(group['members']))))
  r.update(exit_code=0,all_original_payload_paths_retained=True,all_original_receipt_bytes_preserved=True,expected_allocated_saving=79196160,consumer_checks=count)
 finally:
  r.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=guard['free']());dump(OUT/'RESULT.json',r);print(json.dumps({k:v for k,v in r.items() if k!='groups'}))
if __name__=='__main__':main()
