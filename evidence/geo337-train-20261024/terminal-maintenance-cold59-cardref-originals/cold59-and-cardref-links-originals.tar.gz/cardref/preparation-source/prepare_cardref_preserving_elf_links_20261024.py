"""Prepare exact closed cardref ELF aliases; no payload replacement."""
from pathlib import Path
import hashlib,importlib.util,json,os,difflib
BASE=Path('/workspace/cardref-preserving-elf-links-preparation-20261024');BASE.mkdir()
META=Path('/workspace/cardref-original-116-elf-duplicate-metadata-20261024.json')
RAW=Path('/tmp/train337-section7-terminal-collection/cardref/RAW_INVENTORY.json')
EXCLUDED=Path('/tmp/train337-section7-terminal-collection/cardref/EXCLUDED_ELF_PAYLOADS.json')
ORIGINAL=Path('/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert h(META)=='473a71351f2d98337e45942d90bd9f818c6eafebc22a33d2102d71db1a91336e'
assert h(ORIGINAL)=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
sp=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
rec=c.Recorder(BASE/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),L)
for path in ['geometry-core/card-reference/run_mutations.py','geometry-core/card-reference/mutations.py']:
 row,raw,err=rec.run(['git','show',L+':'+path],cwd='/workspace/geometry-axiom',check=False,source_variant='read-only fixed L original judge identity; never read live shared checkout')
 assert row['actual_process_returncode']==0
 expected=json.loads(Path('/tmp/train337-final-nonperf-specials-prep/PREPARATION.json').read_text())['original_judges_sha256'][path]
 assert hashlib.sha256(raw).hexdigest()==expected
old=ORIGINAL.read_text();source=old
changes=[('assert len(members) == 3 and len({x[\'path\'] for x in members}) == 3','assert len(members) in (5, 58) and len({x[\'path\'] for x in members}) == len(members)'),('assert len({(x[\'dev\'], x[\'inode\']) for x in members}) == 3','assert len({(x[\'dev\'], x[\'inode\']) for x in members}) == len(members)'),('All three public paths','All named public paths'),('state(members, {1, 2})','state(members, set(range(1, len(members))))'),("dict(event='complete', expected_alias_count=3,","dict(event='complete', expected_alias_count=len(members),")]
for a,b in changes:assert source.count(a)==1;source=source.replace(a,b)
core=BASE/'cardref_exact_group_link_core.py';core.write_text(source);compile(source,str(core),'exec')
(BASE/'CORE_DIFF.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile=str(ORIGINAL),tofile=str(core))))
ns={'__name__':'_readonly','__file__':str(core)};exec(compile(source,str(core),'exec'),ns)
meta=json.loads(META.read_text());excluded=json.loads(EXCLUDED.read_text());inv=json.loads(RAW.read_text());by_path={x['source_path']:x for x in excluded}
assert len(excluded)==116 and len(meta['items'])==2 and [x['count'] for x in meta['items']]==[58,5]
assert h(EXCLUDED)==meta['source_inventory_sha256']
groups=[]
for group in meta['items']:
 members=[]
 for name in group['paths']:
  p=Path(name);x=by_path[name];before=ns['metadata'](p)
  assert before['nlink']==1 and p.is_relative_to('/workspace/train337-final-L-cardref-7af8c5d8/cardref/subject')
  assert before['size']==x['bytes'] and ns['digest'](p)==x['sha256']==group['sha256']
  with p.open('rb') as f:assert f.read(4)==b'\x7fELF'
  members.append(dict(path=name,sha256=x['sha256'],**before))
 assert len({(x['mode'],x['uid'],x['gid'],x['sha256'],x['size']) for x in members})==1
 groups.append(dict(sha256=group['sha256'],count=len(members),members=members,expected_allocated_saving=sum(x['allocated_bytes'] for x in members[1:])))
for x in inv['members']:
 p=Path(x['source_path']);assert p.stat().st_size==x['bytes'] and h(p)==x['sha256']
terminal=Path('/workspace/train337-final-L-cardref-7af8c5d8/receipt.json');t=json.loads(terminal.read_text());assert t['source_sha']==L and t['passed'] and t['launcher_exit_code']==0 and t['ended_utc']
plan=dict(source_sha=L,groups=groups,exact_counts=[58,5],target_count=63,original_elf_count=116,excluded_unique_elf_count=53,expected_allocated_saving=sum(x['expected_allocated_saving'] for x in groups),original_inventory=dict(path=str(RAW),sha256=h(RAW)),original_excluded_inventory=dict(path=str(EXCLUDED),sha256=h(EXCLUDED)),terminal_receipt=dict(path=str(terminal),sha256=h(terminal)),core=dict(path=str(core),sha256=h(core)),original_core=dict(path=str(ORIGINAL),sha256=h(ORIGINAL)),all_selected_original_receipts_and_compile_artifacts=inv['members'],reservation='These two terminal cardref ELF groups are separately write/reuse banned until every member alias is de-linked. They are not any of the236 historical cold archive groups.',identity_limit='Every named ELF path and byte remains; destination inode/nlink/mtime adopt canonical metadata. Original inode IDs are not restorable.',source_sidecar_note='Original cardref inventory has no fingerprint sidecars; all223 original command JSONs and other original artifacts are retained and pinned instead. No new sidecar is invented.',actual_replacement_executed=False)
assert plan['expected_allocated_saving']==79196160
dump(BASE/'PLAN.json',plan)
print(json.dumps(dict(plan=str(BASE/'PLAN.json'),plan_sha256=h(BASE/'PLAN.json'),core_sha256=h(core),expected_allocated_saving=plan['expected_allocated_saving'],original_receipt_files=len(inv['members']),actual_replacement_executed=False)))
