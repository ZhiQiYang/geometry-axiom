"""Two literal historical receipt groups; read-only preparation, no replacements."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os
BASE=Path('/workspace/evidence-archive-dedup-readonly-20261023')
OLD=json.loads((BASE/'release-exact-three-proof/PLAN.json').read_text())
ORIGINAL=(BASE/'deduplicate_release_exact_three_receipts.py').read_text()
CORE=BASE/'archive_link_core.py'
assert hashlib.sha256(CORE.read_bytes()).hexdigest()=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
ns={'__name__':'_metadata_only','__file__':str(CORE)};exec(compile(CORE.read_bytes(),str(CORE),'exec'),ns)
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
sp=importlib.util.spec_from_file_location('cap',CAP);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
SCOPES=json.loads(Path('/workspace/cold-nonarchive-three-copy-metadata-20261024/COLD59_SCOPES.json').read_text())
for name,rel,blob,size in SCOPES:
 out=BASE/(name+'-exact-three-proof');out.mkdir();rec=cap.Recorder(out,dict(os.environ,GIT_OPTIONAL_LOCKS='0'),'historical receipt storage maintenance only');members=[]
 for prior in OLD['members']:
  item=copy.deepcopy(prior);p=Path(item['repo'])/rel;before=ns['metadata'](p);assert before['nlink']==1
  _,head,_=rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',item['repo'],'rev-parse','HEAD'],cwd=BASE,source_variant='historical source Git read only');assert head.decode().strip()==item['head']
  _,tree,_=rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',item['repo'],'ls-tree','-z','HEAD','--',rel],cwd=BASE,source_variant='historical exact receipt tree read only');assert tree==('100644 blob '+blob+'\t'+rel+'\0').encode()
  data=p.read_bytes();assert len(data)==size and hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()==blob
  assert cap.filehash(item['terminal_receipt']['path'])==item['terminal_receipt']['sha256']
  item.update(relative=rel,path=str(p),git_blob=blob,**ns['metadata'](p));item['original_pre_hash_metadata']=before;item['sha256']=hashlib.sha256(data).hexdigest();members.append(item)
 assert len({x['sha256'] for x in members})==1
 plan=copy.deepcopy(OLD);plan.update(git_blob=blob,sha256=members[0]['sha256'],size=size,expected_allocated_saving=sum(x['allocated_bytes'] for x in members[1:]),members=members)
 plan['parent_reservation']='All three historical cold checkouts remain barred from writes/reuse until every established archive alias is independently de-linked, including earlier groups.'
 cap.dump(out/'PLAN.json',plan);source=ORIGINAL
 changes=[('release-exact-three-proof/PLAN.json',name+'-exact-three-proof/PLAN.json'),('b4758f87087b7baef6fa07477de3e7584afb2e3b7574d9c24612edf7545367ac',cap.filehash(out/'PLAN.json')),('/workspace/release-receipt-archive-three-dedup-execution-20261023','/workspace/'+name+'-receipt-archive-three-dedup-execution-20261023'),('tests/release-evidence/20261008/geometry-main-evidence-459478e9.tar.gz',rel),('72ed8f50cbcaa08d1d218c7ddd7bc47c3839eff8',blob),('3bd6f83ec9bcdc9cfc70e88091ba46db215e6ad374e261248e227d1eda9a9203',members[0]['sha256']),('39046314',str(size))]
 for a,b in changes:assert a in source;source=source.replace(a,b)
 tool=BASE/('deduplicate_'+name.replace('-','_')+'_exact_three_receipts.py');tool.write_text(source);compile(source,str(tool),'exec')
 result={'exit_code':0,'readOnlyPreparation':True,'subjectMutationExecuted':False,'plan_sha256':cap.filehash(out/'PLAN.json'),'tool':str(tool),'tool_sha256':cap.filehash(tool),'payload_sha256':members[0]['sha256'],'expected_allocated_saving':plan['expected_allocated_saving'],'onlyLiteralSubstitutions':7,'coreUnchangedSHA256':cap.filehash(CORE)}
 cap.dump(out/'RESULT.json',result);print(json.dumps(result))
