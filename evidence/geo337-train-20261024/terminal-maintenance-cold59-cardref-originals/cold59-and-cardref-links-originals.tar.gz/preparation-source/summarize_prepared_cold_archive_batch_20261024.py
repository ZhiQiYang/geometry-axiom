"""Bind existing read-only preparation results; never execute archive replacement."""
from pathlib import Path
import argparse, hashlib, json

p = argparse.ArgumentParser()
p.add_argument('--manifest', required=True)
p.add_argument('--launch', required=True)
p.add_argument('--out', required=True)
a = p.parse_args()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
manifest = Path(a.manifest)
m = json.loads(manifest.read_text())
scopes = Path(m['scopes'])
assert digest(scopes) == m['scopes_sha256']
assert digest(m['deferred_producer']) == m['deferred_producer_sha256']
launch = Path(a.launch)
result = json.loads((launch / 'RESULT.json').read_text())
assert result['actual_process_returncode'] == 0 and not result['timeout_expired']
base = Path('/workspace/evidence-archive-dedup-readonly-20261023')
items = []
for name, relative, blob, size in json.loads(scopes.read_text()):
    plan = base / (name + '-exact-three-proof/PLAN.json')
    j = json.loads(plan.read_text())
    receipt = plan.parent / 'RESULT.json'
    r = json.loads(receipt.read_text())
    assert r['exit_code'] == 0 and r['readOnlyPreparation'] and not r['subjectMutationExecuted']
    assert digest(plan) == r['plan_sha256'] and digest(r['tool']) == r['tool_sha256']
    assert (j['git_blob'], j['size']) == (blob, size)
    assert len(j['members']) == 3 and all(x['relative'] == relative for x in j['members'])
    assert r['onlyLiteralSubstitutions'] == 7
    assert not Path('/workspace', name + '-receipt-archive-three-dedup-execution-20261023').exists()
    items.append(dict(name=name, plan=str(plan), plan_sha256=digest(plan), tool=r['tool'],
                      tool_sha256=r['tool_sha256'], relative=relative, git_blob=blob,
                      size=size, expected_allocated_saving=j['expected_allocated_saving'],
                      preparation_exit=0, preparation_receipt=str(receipt),
                      preparation_receipt_sha256=digest(receipt), actual_execution='UNRUN'))
assert len(items) == m['count']
assert sum(x['expected_allocated_saving'] for x in items) == m['expected_allocated_saving']
ref = base / 'deduplicate_release_exact_three_receipts.py'
out = Path(a.out)
assert not out.exists()
payload = dict(purpose='Read-only exact-body and Git-blob preparation only; independent peer before root-only replacement.',
               count=len(items), expected_allocated_saving=m['expected_allocated_saving'],
               core_sha256=digest(base / 'archive_link_core.py'), reference_tool=str(ref),
               reference_tool_sha256=digest(ref), source_manifest=str(manifest),
               source_manifest_sha256=digest(manifest), preparation_launch=str(launch),
               preparation_launch_result_sha256=digest(launch / 'RESULT.json'),
               same_three_cold_roots_write_ban='All previously established and any newly executed aliases must be de-linked before any cold-root writes/reuse. Every original archive path and byte is retained.',
               items=items)
out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(out=str(out), sha256=digest(out), count=len(items), expected_allocated_saving=m['expected_allocated_saving'], actual_execution='UNRUN')))
