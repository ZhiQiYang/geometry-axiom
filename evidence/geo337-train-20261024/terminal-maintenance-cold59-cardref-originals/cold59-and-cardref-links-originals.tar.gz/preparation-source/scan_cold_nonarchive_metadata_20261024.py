"""Read Git tree object metadata and file stats only; no file-body hashes or mutation."""
from pathlib import Path
import hashlib,importlib.util,json,os,stat,datetime
BASE=Path('/workspace/cold-nonarchive-three-copy-metadata-20261024');BASE.mkdir()
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
r=c.Recorder(BASE/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db')
roots=[Path('/workspace/geo261-cold/g261seal')/n for n in ['p-source','a-source','l-source']]
heads=['b6646d10751a0d85a2f03f5d24fbe1073cb78980','a12d184ec1865ad078700cea2387ac69e82ab62a','aa02a65e9d3923cc14c13340f05ed16c8b7d4fce']
trees=[]
for root,head in zip(roots,heads):
 row,out,_=r.run(['git','-c','gc.auto=0','-C',str(root),'rev-parse','HEAD'],cwd='/workspace',check=False,source_variant='cold historical metadata only');assert row['actual_process_returncode']==0 and out.decode().strip()==head
 row,out,_=r.run(['git','-c','gc.auto=0','-C',str(root),'ls-tree','-r','-l','-z','HEAD'],cwd='/workspace',check=False,source_variant='cold complete Git tree metadata; no payload read')
 assert row['actual_process_returncode']==0
 tree={}
 for entry in out.split(b'\0'):
  if not entry:continue
  metadata,path=entry.split(b'\t',1);mode,kind,blob,size=metadata.split()
  if kind==b'blob' and size!=b'-' and int(size)>=1024*1024:tree[path.decode()]=dict(mode=mode.decode(),blob=blob.decode(),size=int(size))
 trees.append(tree)
items=[];excluded=[]
for relative,first in trees[0].items():
 if any(t.get(relative)!=first for t in trees[1:]):continue
 if relative.endswith(('.zip','.tar.gz','.tgz','.gz','.xz','.7z','.rar','.bz2','.zst')):continue
 paths=[root/relative for root in roots]
 if not all(p.is_file() and not p.is_symlink() for p in paths):continue
 ss=[p.lstat() for p in paths]
 if len({(s.st_dev,s.st_ino) for s in ss})!=3 or any(s.st_nlink!=1 for s in ss):continue
 if len({s.st_dev for s in ss})!=1 or any(s.st_size!=first['size'] or not stat.S_ISREG(s.st_mode) for s in ss):continue
 receipt=relative.startswith(('evidence/','tests/evidence/','tests/release-evidence/','geometry-core/domain-decoupling/evidence/','geometry-web/docs/evidence/')) or '/evidence/' in relative
 item=dict(relative=relative,git_blob=first['blob'],bytes=first['size'],paths=list(map(str,paths)),expected_allocated_saving=sum(s.st_blocks*512 for s in ss[1:]),priority='immutable-receipt' if receipt else 'cold-source-or-document',members=[dict(path=str(p),dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,size=s.st_size,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,allocated_bytes=s.st_blocks*512) for p,s in zip(paths,ss)])
 items.append(item)
items.sort(key=lambda x:(x['priority']!='immutable-receipt',-x['expected_allocated_saving'],x['relative']))
report=dict(createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),heads=dict(zip(map(str,roots),heads)),scope='Nonarchive >=1MiB tracked same path/mode/blob/size on all three frozen cold heads; physical distinct inode/nlink1 and same device/stat size.',metadata_only=True,file_body_hashes_performed=False,actual_dedup_executed=False,items=items,count=len(items),total_expected_allocated_saving=sum(x['expected_allocated_saving'] for x in items),receipt_expected_allocated_saving=sum(x['expected_allocated_saving'] for x in items if x['priority']=='immutable-receipt'),limits=['Git object identity and stat metadata candidates only. Actual bytes must be compared freshly to Git and each other before any approved operation.','All three cold roots already write/reuse banned by236 archive alias groups; every additional alias group inherits the same ban until all aliases de-linked.','No existing source, receipt, fixture, Git object or payload changed. Existing shared inodes and archive suffixes excluded.'])
c.dump(BASE/'CANDIDATES.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ['items','heads','limits']}));print(json.dumps(dict(report=str(BASE/'CANDIDATES.json'),sha256=hashlib.sha256((BASE/'CANDIDATES.json').read_bytes()).hexdigest())))
