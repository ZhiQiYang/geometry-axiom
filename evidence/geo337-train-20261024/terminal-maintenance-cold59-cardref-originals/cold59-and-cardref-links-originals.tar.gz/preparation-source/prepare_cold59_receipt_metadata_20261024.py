"""Bind exactly59 already-inventoried immutable receipt candidates to the original read-only producer."""
from pathlib import Path
import hashlib,json
BASE=Path('/workspace/cold-nonarchive-three-copy-metadata-20261024')
SOURCE=BASE/'CANDIDATES.json';PIN='a3a3792d3d9787cea6fd28ff9f6b27644edb9215e56d2ad2814cfa13eb5ff55d'
ORIGINAL=Path('/tmp/prepare_next_cold_archive_batch.py')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(SOURCE)==PIN and h(ORIGINAL)=='f869c4c384352222bf80e0b57dffa9abc44fbdfb38ac71dcd496bf46cf3eeaab'
j=json.loads(SOURCE.read_text());items=[x for x in j['items'] if x['priority']=='immutable-receipt']
assert len(items)==59 and sum(x['expected_allocated_saving'] for x in items)==286375936
rows=json.loads((BASE/'git-originals/subcommands.json').read_text());tree_rows=[r for r in rows if 'ls-tree' in r['command']]
for r in tree_rows:
 raw=(Path(r['directory'])/'stdout.bin').read_bytes();assert hashlib.sha256(raw).hexdigest()==r['stdout_sha256']
 tree={}
 for e in raw.split(b'\0'):
  if e:
   fields,path=e.split(b'\t',1);mode,kind,blob,size=fields.split();tree[path.decode()]=(mode.decode(),kind.decode(),blob.decode(),size.decode())
 for x in items:assert tree[x['relative']]==('100644','blob',x['git_blob'],str(x['bytes']))
scopes=BASE/'COLD59_SCOPES.json';assert not scopes.exists()
scopes.write_text(json.dumps([[f'cold-text-{i:03d}',x['relative'],x['git_blob'],x['bytes']] for i,x in enumerate(items,1)],indent=2)+'\n')
old=ORIGINAL.read_text();source=old.replace('"""Prepare17 literal receipt preserving groups without touching an archive body."""','"""Prepare59 immutable nonarchive receipt groups; no payload replacements."""')
# Scope binding is the only operative change; source prefix/docstring is retained if its exact historical text differs.
needle="Path('/tmp/cold_next_archive_batch_scopes.json')";assert source.count(needle)==1
source=source.replace(needle,"Path('/workspace/cold-nonarchive-three-copy-metadata-20261024/COLD59_SCOPES.json')")
producer=BASE/'prepare_cold59_exact_receipts.py';producer.write_text(source);compile(source,str(producer),'exec')
manifest=dict(schema='cold59-immutable-nonarchive-readonly-preparation/1',count=59,expected_allocated_saving=286375936,source_candidates=str(SOURCE),source_candidates_sha256=PIN,scopes=str(scopes),scopes_sha256=h(scopes),deferred_producer=str(producer),deferred_producer_sha256=h(producer),original_producer=str(ORIGINAL),original_producer_sha256=h(ORIGINAL),items=items,nonreceipt_source_docs_excluded=9,body_read_budget=sum(x['bytes']*3 for x in items),subject_replacements_executed=False,lease='All previous236 plus any successful new59 groups form295 cold groups; all must be de-linked before cold checkout writes/reuse. Original paths/bytes remain.')
out=BASE/'PREPARATION_MANIFEST.json';out.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='items'}));print('manifest_sha256',h(out))
