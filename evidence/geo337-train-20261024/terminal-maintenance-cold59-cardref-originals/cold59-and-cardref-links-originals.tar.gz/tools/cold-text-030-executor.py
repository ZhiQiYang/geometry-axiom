"""Root-only reserved-checkout receipt storage dedup; preserves all paths/bytes."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

BASE = Path('/workspace/evidence-archive-dedup-readonly-20261023')
PLAN = BASE / 'cold-text-030-exact-three-proof/PLAN.json'
PLAN_PIN = '0ea1fa4111db7aad72e1b37254baf520b3d8dec0809f1e3a61d43d6b4f4e051d'
CORE = BASE / 'archive_link_core.py'
CORE_PIN = '6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT = Path('/workspace/cold-text-030-receipt-archive-three-dedup-execution-20261023')
ROOT = Path('/workspace/geo261-cold/g261seal')
RELATIVE = 'tests/evidence/cloud-takeover-20261009/ui-single-room-prior-public-v4/rounds/projection-c0-original-ten/artifacts/after-c0f05baa-r1/results.json'
EXPECTED = [str(ROOT / name / RELATIVE) for name in ['p-source', 'a-source', 'l-source']]
HEADS = ['b6646d10751a0d85a2f03f5d24fbe1073cb78980',
         'a12d184ec1865ad078700cea2387ac69e82ab62a',
         'aa02a65e9d3923cc14c13340f05ed16c8b7d4fce']
BLOB = '47f040c18120d58572aef717032a5abbac8f6e31'
SHA256 = '25c8e75804d2d5a1ca3151a9988c83f6ff18caa08e4a986f316e98c9ca55a8e9'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def dump(name, value):
    with (OUT / name).open('w') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def main():
    # Output may not live inside any source tree. Only this exact fresh path is used.
    assert sys.flags.optimize == 0 and 'PYTHONOPTIMIZE' not in os.environ
    for parent in [BASE, *BASE.parents, OUT.parent]: assert not parent.is_symlink()
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=1,
                  policy='Receipt bytes and all paths retained; root bars three checkouts from reuse until de-link.',
                  inode_limit='Original inode IDs are historical only, not restorable. No inode-unchanged claim.',
                  metadata_limit='Aliases adopt canonical mtime/inode. Original per-path metadata is in the pinned plan. No chmod/utime.',
                  failure_policy='No automatic cleanup/rollback on a partial failure; all public receipt paths remain readable. Preserve journal/temp for diagnosis.',
                  source_paths=EXPECTED)
    commands = []
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    core = None
    try:
        assert sha(PLAN) == PLAN_PIN and sha(CORE) == CORE_PIN and sha(GUARD) == GUARD_PIN
        plan = json.loads(PLAN.read_text()); members = plan['members']
        assert [m['path'] for m in members] == EXPECTED
        assert [m['head'] for m in members] == HEADS
        assert plan['git_blob'] == BLOB and plan['sha256'] == SHA256 and plan['size'] == 1490640
        assert all(m['git_blob'] == BLOB and m['sha256'] == SHA256 and m['nlink'] == 1 for m in members)
        core = {'__name__': '_exact_three_core', '__file__': str(CORE)}
        exec(compile(CORE.read_bytes(), str(CORE), 'exec'), core)
        guard = {'__name__': '_only_original_consumer_guard', '__file__': str(GUARD)}
        exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard)
        guard['OUT'] = OUT
        result['free_before'] = guard['free']()

        def command(argv):
            n = len(commands)
            dump(f'{n:03d}.request.json', dict(argv=argv, env=dict(GIT_OPTIONAL_LOCKS='0')))
            proc = subprocess.run(argv, env=env, capture_output=True)
            (OUT / f'{n:03d}.stdout.bin').write_bytes(proc.stdout)
            (OUT / f'{n:03d}.stderr.bin').write_bytes(proc.stderr)
            commands.append(dict(argv=argv, exit_code=proc.returncode,
                                 stdout_bytes=len(proc.stdout), stdout_sha256=hashlib.sha256(proc.stdout).hexdigest(),
                                 stderr_bytes=len(proc.stderr), stderr_sha256=hashlib.sha256(proc.stderr).hexdigest()))
            dump('COMMANDS.json', commands)
            assert proc.returncode == 0, (argv, proc.returncode)
            return proc.stdout

        def fresh_readonly_guards():
            assert sha(PLAN) == PLAN_PIN and sha(CORE) == CORE_PIN
            for item in members:
                receipt = item['terminal_receipt']
                assert sha(receipt['path']) == receipt['sha256']
                assert Path(receipt['path']).stat().st_size == receipt['bytes']
                prefix = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', item['repo']]
                assert command(prefix + ['rev-parse', 'HEAD']).decode().strip() == item['head']
                assert command(prefix + ['ls-tree', '-z', 'HEAD', '--', RELATIVE]) == (
                    '100644 blob ' + BLOB + '\t' + RELATIVE + '\0').encode()
            # Full checkout prefixes, not only archive files; inaccessible proc fields remain recorded.
            guard['consumer_check']([m['repo'] for m in members])
            n = len([p for p in OUT.glob('CONSUMERS-*.json')])
            (OUT / f'CONSUMERS-{n:02d}.json').write_bytes((OUT / 'CONSUMERS.json').read_bytes())

        fresh_readonly_guards()
        core['state'](members, set())
        # Fresh physical bytes are compared to the real Git object stream before any mutation.
        argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', members[0]['repo'], 'cat-file', 'blob', BLOB]
        n = len(commands)
        dump(f'{n:03d}.request.json', dict(argv=argv, stdout_retention='all bytes compared against three retained original paths; no duplicate payload archive'))
        count = 0; h = hashlib.sha256(); obj = hashlib.sha1(b'blob 1490640\0')
        with (OUT / f'{n:03d}.stderr.bin').open('wb') as err:
            proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=err)
            streams = [Path(item['path']).open('rb') for item in members]
            try:
                while chunk := proc.stdout.read(1024 * 1024):
                    assert all(stream.read(len(chunk)) == chunk for stream in streams), 'physical bytes differ from Git blob'
                    h.update(chunk); obj.update(chunk); count += len(chunk)
                assert all(stream.read(1) == b'' for stream in streams)
            finally:
                for stream in streams: stream.close()
                proc.stdout.close()
                if proc.poll() is None and count != 1490640: proc.terminate()
                rc = proc.wait()
                commands.append(dict(argv=argv, exit_code=rc, compared_bytes=count, stdout_sha256=h.hexdigest(),
                                     stdout_retained_at_original_paths=EXPECTED))
                dump('COMMANDS.json', commands)
        assert rc == 0 and count == 1490640 and h.hexdigest() == SHA256 and obj.hexdigest() == BLOB
        # The primitive rechecks identities, full hashes and exact alias counts before and after every step.
        core['link_exact'](members, OUT / 'JOURNAL.jsonl', before_each=fresh_readonly_guards)
        fresh_readonly_guards()
        result.update(exit_code=0, all_three_paths_and_bytes_preserved=True,
                      expected_allocated_saving=plan['expected_allocated_saving'],
                      final_metadata=[dict(path=m['path'], **core['metadata'](m['path'])) for m in members])
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_after'] = {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ['/workspace', '/tmp']}
        dump('RESULT.json', result)
        print(json.dumps(result))


if __name__ == '__main__': main()
