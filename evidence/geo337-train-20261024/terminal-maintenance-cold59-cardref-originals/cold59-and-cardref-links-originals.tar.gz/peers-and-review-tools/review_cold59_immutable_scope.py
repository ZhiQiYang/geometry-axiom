from pathlib import Path
import hashlib,json
B=Path('/workspace/cold-nonarchive-three-copy-metadata-20261024');O=Path('/workspace/train337-canvas-peer-resume/COLD59_IMMUTABLE_SCOPE_PEER.json')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
checks=[]
def ck(name,value):checks.append((name,bool(value)))
m=j(B/'PREPARATION_MANIFEST.json');f=j('/workspace/cold_text_59_exact_body_manifest_20261024.json');c=j(m['source_candidates']);sc=j(m['scopes'])
ck('formal manifest fixed',h('/workspace/cold_text_59_exact_body_manifest_20261024.json')=='482ad13ed12a4029dc4e79c6ab084ad034521abba16d073d74818178fb82f602')
for pathkey,pinkey in [('source_candidates','source_candidates_sha256'),('scopes','scopes_sha256'),('deferred_producer','deferred_producer_sha256'),('original_producer','original_producer_sha256')]:ck('pinned '+pathkey,h(m[pathkey])==m[pinkey])
ck('same original producer only exact scope path substituted',Path(m['original_producer']).read_text().replace("'/tmp/cold_next_archive_batch_scopes.json'","'/workspace/cold-nonarchive-three-copy-metadata-20261024/COLD59_SCOPES.json'")==Path(m['deferred_producer']).read_text())
selected=[x for x in c['items'] if x['priority']=='immutable-receipt'];other=[x for x in c['items'] if x['priority']!='immutable-receipt']
ck('exact59 immutable selected and9 source/docs excluded',len(selected)==len(m['items'])==len(f['items'])==len(sc)==59 and len(other)==m['nonreceipt_source_docs_excluded']==9)
ck('candidate-selected identity',selected==m['items'])
ck('all295coldgroups write lease',all(token in m['lease'] for token in ['236','59','295','de-linked','writes/reuse']))
for n,(x,y,s) in enumerate(zip(m['items'],f['items'],sc),1):
 ck('exact named scope '+str(n),x['priority']=='immutable-receipt' and [y['name'],x['relative'],x['git_blob'],x['bytes']]==s and y['name']==f'cold-text-{n:03d}' and (x['relative'],x['git_blob'],x['bytes'])==(y['relative'],y['git_blob'],y['size']))
 p=j(y['plan']);ck('exact3paths '+str(n),x['paths']==[z['path'] for z in p['members']])
 ck('historical terminal false retained '+str(n),[z['terminal_receipt']['original_passed'] for z in p['members']]==[True,False,True])
peer=O.parent/'COLD_59_EXACT_THREE_EXECUTOR_STATIC_PEER.json';r=j(peer);ck('2547 existing exact7literal/core/guard static peer',h(peer)=='e68859506063e627721e248d30af14880e42479e32b8de5fc98d807aac9a33fc' and r['checks']==2547 and r['exit_code']==0 and not r['findings'])
findings=[name for name,ok in checks if not ok];report={'schema':'cold59-immutable-scope-static-peer-v1','checks':len(checks),'exit_code':int(bool(findings)),'findings':findings,'manifest_sha256':h('/workspace/cold_text_59_exact_body_manifest_20261024.json'),'executor_peer_path':str(peer),'executor_peer_sha256':h(peer),'expected_allocated_saving':286375936,'scope':'59 exact immutable receipts in the same three closed cold roots; nine source/docs excluded. No body rehash, execution or source modification by reviewer.','limits':['Original executor naming retains archive for compatibility, but exact pinned relative paths and current immutable-receipt manifest define authority.','All295 cold alias groups are forbidden write/reuse until every alias is delinked. Each actual executor must still run original fresh Git/hash/consumer guards.','Historical owner receipt false for census remains false; maintenance does not make any product gate pass.']}
O.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(O),'sha256':h(O),'checks':len(checks),'findings':findings,'exit_code':report['exit_code']}));raise SystemExit(report['exit_code'])
