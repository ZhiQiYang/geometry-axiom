import ast,hashlib,json,pathlib,sys
P=pathlib.Path; O=P('/workspace/train337-canvas-peer-resume'); checks=[]
def c(label,yes): checks.append({'check':label,'ok':bool(yes)})
def h(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()
mp=P(sys.argv[1]); m=json.loads(mp.read_text()); base=P('/workspace/evidence-archive-dedup-readonly-20261023');ref=P(m['reference_tool']).read_text()
c('manifest exact SHA',h(mp)==sys.argv[2])
c('reference exact SHA',h(m['reference_tool'])==m['reference_tool_sha256']=='90f6ed3ac242f919c630d8c4841c05564854f560efc093d82a9a33369163937c')
c('core unchanged',h(base/'archive_link_core.py')==m['core_sha256']=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4')
c('guard unchanged',h('/workspace/clear_terminal_chrome_caches.py')=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847')
c('source metadata manifest pinned',h(m['source_manifest'])==m['source_manifest_sha256'])
launch=P(m['preparation_launch'])/'RESULT.json'; r=json.loads(launch.read_text())
c('preparation launch pin and terminal0',h(launch)==m['preparation_launch_result_sha256'] and r['actual_process_returncode']==0 and not r['timeout_expired'] and r['ended_epoch']>r['started_epoch'])
for stream in ('stdout','stderr'):
 q=P(r['directory'])/(stream+'.bin'); c('launch full '+stream,q.stat().st_size==r[stream+'_bytes'] and h(q)==r[stream+'_sha256'])
heads=['b6646d10751a0d85a2f03f5d24fbe1073cb78980','a12d184ec1865ad078700cea2387ac69e82ab62a','aa02a65e9d3923cc14c13340f05ed16c8b7d4fce']; allpaths=[]; reports=[]
for i in m['items']:
 n=i['name']; pp=P(i['plan']); p=json.loads(pp.read_text()); t=P(i['tool']).read_text(); c(n+' original preparation receipt pin',h(i['preparation_receipt'])==i['preparation_receipt_sha256'])
 c(n+' plan pin',h(pp)==i['plan_sha256']); c(n+' tool pin',h(i['tool'])==i['tool_sha256'])
 substitutions=[('release-exact-three-proof/PLAN.json',str(pp.relative_to(base))),('b4758f87087b7baef6fa07477de3e7584afb2e3b7574d9c24612edf7545367ac',i['plan_sha256']),('/workspace/release-receipt-archive-three-dedup-execution-20261023',f'/workspace/{n}-receipt-archive-three-dedup-execution-20261023'),('tests/release-evidence/20261008/geometry-main-evidence-459478e9.tar.gz',i['relative']),('72ed8f50cbcaa08d1d218c7ddd7bc47c3839eff8',i['git_blob']),('3bd6f83ec9bcdc9cfc70e88091ba46db215e6ad374e261248e227d1eda9a9203',p['sha256']),('39046314',str(i['size']))]
 expected=ref
 for a,b in substitutions:
  c(n+' literal present '+a[:16],a in expected); expected=expected.replace(a,b)
 c(n+' exact seven literal fulltext',expected==t);c(n+' AST same after literals',ast.dump(ast.parse(expected))==ast.dump(ast.parse(t)))
 c(n+' initial preparation only',i['preparation_exit']==0 and i['actual_execution']=='UNRUN')
 c(n+' plan identity',p['git_blob']==i['git_blob'] and p['size']==i['size'] and p['expected_allocated_saving']==i['expected_allocated_saving'])
 c(n+' exact roots and heads',[x['head'] for x in p['members']]==heads and [x['repo'] for x in p['members']]==[f'/workspace/geo261-cold/g261seal/{s}-source' for s in ('p','a','l')])
 c(n+' three distinct original inodes same filesystem',len(p['members'])==3 and len({x['inode'] for x in p['members']})==3 and len({x['dev'] for x in p['members']})==1)
 for x in p['members']:
  allpaths.append(x['path']);c(n+' member path '+x['repo'],x['path']==str(P(x['repo'])/i['relative']) and x['relative']==i['relative'] and x['git_mode']=='100644' and x['size']==i['size'] and x['nlink']==1 and x['git_blob']==i['git_blob'] and x['sha256']==p['sha256'])
  r=x['terminal_receipt'];c(n+' original terminal pin '+x['repo'],h(r['path'])==r['sha256'] and bool(r['ended']))
 c(n+' configured saving',sum(x['allocated_bytes'] for x in p['members'][1:])==i['expected_allocated_saving'])
 r=json.loads((pp.parent/'RESULT.json').read_text());c(n+' producer true read-only terminal',r['exit_code']==0 and r['readOnlyPreparation'] is True and r['subjectMutationExecuted'] is False and r['onlyLiteralSubstitutions']==7 and r['plan_sha256']==i['plan_sha256'] and r['tool_sha256']==i['tool_sha256'])
 rows=json.loads((pp.parent/'subcommands.json').read_text());c(n+' six original Git reads',len(rows)==6)
 for k,row in enumerate(rows):
  c(n+f' command {k+1} original zero',row['actual_process_returncode']==0 and not row['timeout_expired'] and row['command'][0]=='git' and ('rev-parse' in row['command'] or 'ls-tree' in row['command']))
  for stream in ('stdout','stderr'):
   q=P(row['directory'])/(stream+'.bin');c(n+f' command {k+1} {stream}',q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'])
 reports.append({'name':n,'plan_sha256':i['plan_sha256'],'tool_sha256':i['tool_sha256'],'expected_allocated_saving':i['expected_allocated_saving']})
c('exact groups and unique paths',len(reports)==m['count']==int(sys.argv[3]) and len(allpaths)==len(set(allpaths))==3*len(reports))
c('total configured saving',sum(x['expected_allocated_saving'] for x in reports)==m['expected_allocated_saving']==int(sys.argv[4]))
f=[x for x in checks if not x['ok']];result={'scope':'Exact cold receipt groups executor/plan static peer; no execution or large payload rehash','checks':len(checks),'findings':f,'exit_code':int(bool(f)),'manifest_sha256':h(mp),'groups':reports,'limits':['Actual root execution still requires original fresh guards.','All original paths and receipt bytes are retained; inode identity is not preserved.','Three cold checkouts remain write-banned until every alias is de-linked.','Readable proc inspection is limited; unknown fields are retained.']};out=O/('COLD_'+sys.argv[3]+'_EXACT_THREE_EXECUTOR_STATIC_PEER.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out),'checks':len(checks),'findings':f,'exit_code':result['exit_code']}));raise SystemExit(result['exit_code'])
