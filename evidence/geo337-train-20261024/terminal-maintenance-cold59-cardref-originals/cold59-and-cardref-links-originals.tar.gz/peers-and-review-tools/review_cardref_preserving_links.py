from pathlib import Path
import ast, hashlib, json, os
B=Path('/workspace/cardref-preserving-elf-links-preparation-20261024')
OUT=Path('/workspace/train337-canvas-peer-resume/CARDREF_PRESERVING_LINKS_STATIC_PEER.json')
checks=[]; findings=[]
def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def c(name,ok):
 checks.append(name)
 if not ok: findings.append(name)
pins={'PLAN.json':'d8c7d397aa041080c3b98fadb242069abd12b301d19475fb1c2aa3b4cb08ea58','link_exact_closed_cardref_elf_groups.py':'48573411027d6da410d7e05fe0d52a7030c2fc838361e229e421b63000d552e9','cardref_exact_group_link_core.py':'68dc068b50863a7a53de2874149d66b7f2794b9669c7b03ebf2562f91b70b569'}
for n,d in pins.items(): c('pin '+n,h(B/n)==d)
p=json.loads((B/'PLAN.json').read_text()); inv=json.loads(Path(p['original_excluded_inventory']['path']).read_text())
old=Path(p['original_core']['path']).read_text(); new=(B/'cardref_exact_group_link_core.py').read_text()
c('original core exact',h(p['original_core']['path'])=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4')
sub=[("len(members) == 3 and len({x['path'] for x in members}) == 3","len(members) in (5, 58) and len({x['path'] for x in members}) == len(members)"),("len({(x['dev'], x['inode']) for x in members}) == 3","len({(x['dev'], x['inode']) for x in members}) == len(members)"),('All three public paths','All named public paths'),('state(members, {1, 2})','state(members, set(range(1, len(members))))'),("event='complete', expected_alias_count=3","event='complete', expected_alias_count=len(members)")]
for a,b in sub:
 c('single approved core substitution '+a,old.count(a)==1);old=old.replace(a,b)
c('core only five approved substitutions',old==new)
t=(B/'link_exact_closed_cardref_elf_groups.py').read_text();ast.parse(t)
original=(B/'executor_initial_2581_reconstructed.py.txt').read_text()
c('initial executor pinned',hashlib.sha256(original.encode()).hexdigest()=='2581f2b76a176a3d2d542773f36d5967034b4074c5465efdf08fc1d33d6542c3')
addition="  for x in inv:\n   q=Path(x['source_path']);assert q.stat().st_size==x['bytes'] and h(q)==x['sha256']\n"
c('final executor exactly two added original ELF preservation lines',t.replace(addition,'',1)==original)
c('fixed source',p['source_sha']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db')
c('exact 116 original, 63 target, 53 unselected',len(inv)==116 and p['target_count']==63 and p['excluded_unique_elf_count']==53 and [g['count'] for g in p['groups']]==[58,5])
c('savings 79196160',sum(g['expected_allocated_saving'] for g in p['groups'])==p['expected_allocated_saving']==79196160)
for key in ['original_inventory','original_excluded_inventory','terminal_receipt']:
 c(key+' original bytes',h(p[key]['path'])==p[key]['sha256'])
for gi,g in enumerate(p['groups']):
 exp=[x['source_path'] for x in inv if x['sha256']==g['sha256']]
 c('group exact original paths '+str(gi),[m['path'] for m in g['members']]==exp and len(exp)==g['count'])
 c('group original distinct inode '+str(gi),len({(m['dev'],m['inode']) for m in g['members']})==g['count'])
 for m in g['members']:
  s=Path(m['path']).lstat()
  c('target original identity '+m['path'],(s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mode,s.st_mtime_ns)==(m['dev'],m['inode'],1,m['size'],m['mode'],m['mtime_ns']))
  c('closed exact scope '+m['path'],Path(m['path']).is_relative_to('/workspace/train337-final-L-cardref-7af8c5d8/cardref/subject'))
r=json.loads(Path(p['terminal_receipt']['path']).read_text())
c('original terminal true zero',r['passed'] is True and not r['errors'] and r['launcher_exit_code']==0 and r['ended_utc'] and r['source_sha']==p['source_sha'])
c('931 original metadata artifacts',len(p['all_selected_original_receipts_and_compile_artifacts'])==931)
for x in p['all_selected_original_receipts_and_compile_artifacts']:
 q=Path(x['source_path']);c('preserved raw '+x['name'],q.stat().st_size==x['bytes'] and h(q)==x['sha256'])
rows=json.loads((B/'git-originals/subcommands.json').read_text())
c('two original judge Git reads',len(rows)==2)
for i,row in enumerate(rows):
 c('original Git read zero '+str(i),row['actual_process_returncode']==0 and row['source_sha']==p['source_sha'] and not row['timeout_expired'])
 for channel in ['stdout','stderr','stdin']:
  c('original Git '+channel+' '+str(i),h(Path(row['directory'])/(channel+'.bin'))==row[channel+'_sha256'])
co=json.loads((B/'fresh-consumer-proof/CONSUMERS.json').read_text())
c('fresh observable consumer hits empty',co['hits']==[])
c('consumer visibility limitation explicit',bool(co['limitation']))
c('guard exact original',h('/workspace/clear_terminal_chrome_caches.py')=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847')
c('preserve-before-after and fresh per-transition',t.count('preserved()')==3 and "before_each=consumer" in t and "guard['consumer_check']([SUBJECT])" in t)
c('both alias groups explicitly forbidden reuse',bool(p['reservation']) and bool(p['identity_limit']) and bool(p['source_sidecar_note']))
result={'schema':'independent-static-tool-peer-v1','exit_code':int(bool(findings)),'checks':len(checks),'findings':findings,'pins':pins,'scope':'Static executor/core/plan and original metadata audit; no replacement or deletion executed by reviewer. Original ELF bodies will be fully hashed by executor before/after and each transition.','actual_replacement_executed_by_reviewer':False,'limitations':['Consumer scan cannot see permission-denied processes; original visibility limitation is retained.','Destination inode/nlink/mtime adopts canonical; original bytes and every path preserved, original inodes not restored.','All 63 aliases across two groups are forbidden write/reuse until every alias delinked. Distinct from 236 historical cold archive aliases.','No original fingerprint sidecars existed; 223 original compile command JSONs retained among 931 artifacts.'],'original_consumer_unreadable_count':len(co['unreadable'])}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':len(checks),'findings':findings,'exit_code':result['exit_code'],'path':str(OUT),'sha256':h(OUT)}));raise SystemExit(result['exit_code'])
