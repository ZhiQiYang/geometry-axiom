"""Review closed preserving-link receipts and exact current alias metadata; no ELF body reread."""
from pathlib import Path
import hashlib,json,stat
BASE=Path('/workspace/cardref-preserving-elf-links-preparation-20261024')
OUT=Path('/workspace/cardref-exact-two-elf-groups-preserving-dedup-execution-20261024')
LAUNCH=Path('/workspace/cardref-exact-two-elf-groups-preserving-dedup-launch-20261024')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
checks=0;findings=[]
def ck(n,v):
 global checks
 checks+=1
 if not v:findings.append(n)
p=j(BASE/'PLAN.json');r=j(OUT/'RESULT.json');outer=j(LAUNCH/'RESULT.json')
ck('plan pin',h(BASE/'PLAN.json')=='d8c7d397aa041080c3b98fadb242069abd12b301d19475fb1c2aa3b4cb08ea58')
ck('executor final pin',h(BASE/'link_exact_closed_cardref_elf_groups.py')=='48573411027d6da410d7e05fe0d52a7030c2fc838361e229e421b63000d552e9')
ck('original true terminal',r['exit_code']==0 and bool(r['ended_utc']) and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'])
ck('outer true terminal',outer['actual_process_returncode']==0 and bool(outer['ended_epoch']) and not outer['timeout_expired'])
ck('separate2groups',len(r['groups'])==2 and [x['count'] for x in r['groups']]==[58,5] and 'not any of the236' in r['reservation'])
for n,(before,after) in enumerate(zip(p['groups'],r['groups']),1):
 members=before['members'];journal=[json.loads(x) for x in (OUT/f'GROUP-{n}.jsonl').read_text().splitlines()]
 ck(f'group{n} original scope',len(members)==after['count'] and before['sha256']==after['sha256'] and after['all_paths_preserved'])
 ck(f'group{n} initial journal',journal[0]['event']=='initial_verified' and journal[0]['originals']==members)
 ck(f'group{n} temporary paths gone',all(not Path(q).exists() for q in journal[0]['temporary_paths']))
 ck(f'group{n} all transitions',[(e['index'],e['expected_alias_count']) for e in journal if e['event']=='replacement_verified']==[(k,k+1) for k in range(1,len(members))])
 ck(f'group{n} final event',journal[-1]['event']=='complete' and journal[-1]['expected_alias_count']==len(members) and journal[-1]['all_original_paths_present'] and journal[-1]['bytes_unchanged'])
 ids=[]
 for old,new in zip(members,after['final_metadata']):
  q=Path(old['path']);s=q.lstat();ids.append((s.st_dev,s.st_ino))
  ck('regular path '+str(q),stat.S_ISREG(s.st_mode) and not q.is_symlink() and s.st_size==old['size'] and s.st_nlink==len(members))
  ck('final metadata '+str(q),new['path']==str(q) and all(new[k]==getattr(s,v) for k,v in [('dev','st_dev'),('inode','st_ino'),('mode','st_mode'),('size','st_size'),('mtime_ns','st_mtime_ns'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink')]))
 ck(f'group{n} canonical identity',len(set(ids))==1 and ids[0]==(members[0]['dev'],members[0]['inode']))
for item in p['all_selected_original_receipts_and_compile_artifacts']:
 q=Path(item['source_path']);ck('unchanged raw '+str(q),q.stat().st_size==item['bytes'] and h(q)==item['sha256'])
inv=j(p['original_excluded_inventory']['path']);linked={x['path'] for g in p['groups'] for x in g['members']}
ck('116 payload paths present',len(inv)==116 and all(Path(x['source_path']).is_file() and Path(x['source_path']).stat().st_size==x['bytes'] for x in inv))
ck('53 excluded remain unlinked',len([x for x in inv if x['source_path'] not in linked])==53 and all(Path(x['source_path']).stat().st_nlink==1 for x in inv if x['source_path'] not in linked))
consumers=sorted(OUT.glob('consumers-*/CONSUMERS.json'));ck('62 fresh consumer snapshots',len(consumers)==r['consumer_checks']==62)
for q in consumers:
 x=j(q);ck('visible no consumers '+q.parent.name,x['hits']==[] and 'unreadable' in x and bool(x['limitation']))
for stream in ['stdout','stderr']:
 q=Path(outer['directory'])/(stream+'.bin');ck('outer full stream '+stream,q.stat().st_size==outer[stream+'_bytes'] and h(q)==outer[stream+'_sha256'])
report=dict(checks=checks,findings=findings,exit_code=int(bool(findings)),source_sha=p['source_sha'],result_sha256=h(OUT/'RESULT.json'),plan_sha256=h(BASE/'PLAN.json'),outer_sha256=h(LAUNCH/'RESULT.json'),groups=[58,5],retained_elf_paths=116,linked_elf_paths=63,unlinked_paths=53,configured_allocated_saving=79196160,original_free_before=r['free_before'],original_free_after=r['free_after'],limits=['This actual peer checks original full streams/metadata and931 small original receipt files; no independent ELF body rehash. Original root executor freshly full-hashed all116 bodies before/after and its original linking core repeatedly verified each target transition.','All116 original paths remain. Two63-member-target groups are separate from236 historical archive groups and write/reuse banned until all aliases de-linked.','Destination inode/nlink/mtime adopt canonical metadata; no original inode-restoration claim.','No new test execution, assertion changes, fixture deletion, source changes or compiler-cache retirement.','Configured allocated savings are not equal to concurrent whole-filesystem free-space deltas.'])
q=Path('/workspace/CARDREF_PRESERVING_LINKS_ACTUAL_METADATA_PEER_20261024.json');assert not q.exists();q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(path=str(q),sha256=h(q),checks=checks,findings=findings,exit_code=report['exit_code'])));raise SystemExit(report['exit_code'])
