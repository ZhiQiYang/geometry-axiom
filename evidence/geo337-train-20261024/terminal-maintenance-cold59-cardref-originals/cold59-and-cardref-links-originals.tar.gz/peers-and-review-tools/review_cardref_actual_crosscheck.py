from pathlib import Path
import hashlib,json,os,stat
B=Path('/workspace/cardref-preserving-elf-links-preparation-20261024');R=Path('/workspace/cardref-exact-two-elf-groups-preserving-dedup-execution-20261024');A=Path('/workspace/cardref-exact-two-elf-groups-preserving-dedup-launch-20261024')
O=Path('/workspace/train337-canvas-peer-resume/CARDREF_PRESERVING_LINKS_ACTUAL_CROSS_PEER.json')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
checks=0;findings=[]
def c(n,v):
 global checks
 checks+=1
 if not v:findings.append(n)
p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json');s=j('/workspace/CARDREF_PRESERVING_LINKS_ACTUAL_METADATA_PEER_20261024.json')
c('source metadata peer exact',h('/workspace/CARDREF_PRESERVING_LINKS_ACTUAL_METADATA_PEER_20261024.json')=='a3a36f4e0615644355ce378d2e84008920306c6a2fb3e46d5bf8a639771fa951' and s['checks']==1141 and s['exit_code']==0 and not s['findings'])
c('source helper exact reviewed',h('/workspace/review_cardref_preserving_links_actual_20261024.py')=='f1858305ac587994a302d103ea819f6bfd62ed45314aaee3b0976c87df16fb4a')
c('source and result binds',r['source_sha']==p['source_sha']==s['source_sha']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db' and h(R/'RESULT.json')==s['result_sha256'] and h(A/'RESULT.json')==s['outer_sha256'])
c('actual original tool terminal',r['exit_code']==0 and r['ended_utc'] and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and r['actual_replacement_performed'])
c('exact executed argv',a['actual_process_returncode']==0 and not a['timeout_expired'] and a['command'][1:]==['-B',str(B/'link_exact_closed_cardref_elf_groups.py')] and h(B/'link_exact_closed_cardref_elf_groups.py')=='48573411027d6da410d7e05fe0d52a7030c2fc838361e229e421b63000d552e9')
d=Path(a['directory']);c('actual c387 request/result',j(d/'result.json')==a and j(d/'request.json')['command']==a['command'])
for stream in ['stdout','stderr','stdin']:
 c('complete outer original '+stream,h(d/(stream+'.bin'))==a[stream+'_sha256'])
 if stream!='stdin':c('stream size '+stream,(d/(stream+'.bin')).stat().st_size==a[stream+'_bytes'])
total=0
for i,g in enumerate(p['groups'],1):
 n=len(g['members']);es=[json.loads(x) for x in (R/f'GROUP-{i}.jsonl').read_text().splitlines()]
 c('exact durable event sequence '+str(i),[x['event'] for x in es]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*(n-1)+['complete'])
 c('initial originals '+str(i),es[0]['originals']==g['members'])
 for k in range(1,n):
  before,temp,after=es[1+(k-1)*3:1+k*3];total+=1
  c('exact transition index '+str(i)+'/'+str(k),before['index']==temp['index']==after['index']==k and before['expected_alias_count']==k and temp['expected_alias_count']==after['expected_alias_count']==k+1 and before['destination']==g['members'][k]['path'] and not os.path.lexists(before['temp']))
 canonical=g['members'][0]
 for m in g['members']:
  st=Path(m['path']).lstat();c('actual alias '+m['path'],stat.S_ISREG(st.st_mode) and (st.st_dev,st.st_ino,st.st_nlink,st.st_size,st.st_mtime_ns)==(canonical['dev'],canonical['inode'],n,canonical['size'],canonical['mtime_ns']))
 c('final journal complete '+str(i),es[-1]['expected_alias_count']==n and es[-1]['bytes_unchanged'] and es[-1]['all_original_paths_present'])
c('61 exact atomic replacements',total==61)
consumers=sorted(R.glob('consumers-*/CONSUMERS.json'));c('62 fresh per-transition snapshots',len(consumers)==r['consumer_checks']==62)
for q in consumers:
 x=j(q);c('original visible consumers clear '+q.parent.name,x['hits']==[] and 'unreadable' in x and bool(x['limitation']))
inv=j(p['original_excluded_inventory']['path']);targets={m['path'] for g in p['groups'] for m in g['members']}
c('all116 paths exist',len(inv)==116 and all(Path(x['source_path']).is_file() and Path(x['source_path']).stat().st_size==x['bytes'] for x in inv))
c('53 originals remain single-link',len([x for x in inv if x['source_path'] not in targets])==53 and all(Path(x['source_path']).stat().st_nlink==1 for x in inv if x['source_path'] not in targets))
c('free-space raw not conflated with allocation',s['original_free_before']==r['free_before'] and s['original_free_after']==r['free_after'] and s['configured_allocated_saving']==79196160)
report={'schema':'independent-cardref-preserving-link-actual-metadata-cross-peer-v1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'actual_result_sha256':h(R/'RESULT.json'),'reviewed_source_peer_sha256':h('/workspace/CARDREF_PRESERVING_LINKS_ACTUAL_METADATA_PEER_20261024.json'),'target_paths':63,'retained_paths':116,'atomic_replacements':61,'fresh_consumer_checks':62,'limits':['No ELF bodies reread in this metadata cross-check. Root executed exact reviewed tool whose full original hash guards passed before/after and each transition.','The independently reviewed source peer hashed all931 original small receipts; this cross-check verifies its exact pins and original actual transitions/metadata/full outer streams.','Original consumer visibility limitations remain. Both alias groups must not be written or reused until every alias is delinked; no inode-restoration claim.','No product gate or acceptance test is inferred from storage maintenance.']}
O.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(O),'sha256':h(O),'checks':checks,'findings':findings,'exit_code':report['exit_code']}));raise SystemExit(report['exit_code'])
