from pathlib import Path
import ast,hashlib,json,os,stat
B=Path('/workspace/train337-canvas-peer-resume');O=B/'COLD59_ACTUAL_SUMMARY_HELPER_PEER.json'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
checks=0;findings=[]
def ck(n,v):
 global checks
 checks+=1
 if not v:findings.append(n)
reportpath=Path('/workspace/COLD_59_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json');r=j(reportpath)
old=Path('/workspace/review_cold212_actual_metadata_20261024.py');new=Path('/workspace/review_cold59_actual_metadata_20261024.py')
ck('frozen original212 helper',h(old)=='ca09933114165735a83c415e8f56fb4c08713bb945988fcab2f762cb3617df53')
ck('frozen new59 helper',h(new)=='00098b8219ba9bda241eff6d3d6d84ff889fb1a8682a8233d8f4c664c0a38a00')
def loop(p):return next(n for n in ast.parse(p.read_text()).body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='item')
ck('per-item actual audit AST unchanged',ast.dump(loop(old))==ast.dump(loop(new)))
mp=Path('/workspace/cold_text_59_exact_body_manifest_20261024.json');m=j(mp);ck('fixed exact59 manifest',h(mp)=='482ad13ed12a4029dc4e79c6ab084ad034521abba16d073d74818178fb82f602')
ck('actual source peer terminal0',r['exit_code']==0 and not r['findings'] and r['new_alias_groups']==59 and r['total_established_cold_alias_groups']==295)
ck('59 exact ordered groups',[x['group'] for x in r['groups']]==[x['name'] for x in m['items']] and len(r['groups'])==59)
gitcommands=0
for item,summary in zip(m['items'],r['groups']):
 name=item['name'];p=j(item['plan']);out=Path('/workspace')/(name+'-receipt-archive-three-dedup-execution-20261023');outer=Path('/workspace')/(name+'-receipt-archive-three-dedup-launch-20261024');actual=j(out/'RESULT.json');a=j(outer/'RESULT.json');cmds=j(out/'COMMANDS.json')
 ck(name+' actual terminal pins',h(out/'RESULT.json')==summary['result_sha256'] and h(out/'JOURNAL.jsonl')==summary['journal_sha256'] and h(item['plan'])==item['plan_sha256'] and h(item['tool'])==item['tool_sha256'])
 ck(name+' actual original root execution0',actual['exit_code']==a['actual_process_returncode']==summary['actual_exit']==summary['outer_exit']==0 and actual['all_three_paths_and_bytes_preserved'] and actual['ended_utc'] and a['ended_epoch'] and a['command'][-1]==item['tool'])
 events=[json.loads(line) for line in (out/'JOURNAL.jsonl').read_text().splitlines()];ck(name+' exact atomic event sequence',[x['event'] for x in events]==['initial_verified','before_link','temporary_link_verified','replacement_verified','before_link','temporary_link_verified','replacement_verified','complete'])
 ck(name+' journal original plan',events[0]['originals']==p['members'] and events[-1]['all_original_paths_present'] and events[-1]['bytes_unchanged'] and all(not os.path.lexists(x) for x in events[0]['temporary_paths']))
 canonical=p['members'][0]
 for member in p['members']:
  s=Path(member['path']).lstat();ck(name+' exact alias '+member['path'],stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(canonical['dev'],canonical['inode'],3,p['size']))
 ck(name+' original25 commands0',len(cmds)==25 and all(c['exit_code']==0 for c in cmds));gitcommands+=len(cmds)
 ck(name+' one physical Gitbody comparison',len([c for c in cmds if 'compared_bytes' in c])==1 and all(c['compared_bytes']==p['size'] and c['stdout_sha256']==p['sha256'] for c in cmds if 'compared_bytes' in c))
 ck(name+' historical owner false remains',[x['terminal_receipt']['original_passed'] for x in p['members']]==[True,False,True])
 ck(name+' original free values not savings',summary['observed_free_delta']=={k:actual['free_after'][k]-actual['free_before'][k] for k in ['/workspace','/tmp']} and summary['configured_saving']==item['expected_allocated_saving'])
ck('1475 original Git commands',gitcommands==r['original_git_commands']==1475)
ck('configured286375936 allocation',sum(x['configured_saving'] for x in r['groups'])==m['expected_allocated_saving']==286375936)
result={'schema':'independent-cold59-actual-summary-helper-cross-peer-v1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'original_actual_summary_path':str(reportpath),'original_actual_summary_sha256':h(reportpath),'original_actual_summary_checks':r['checks'],'helper_sha256':h(new),'manifest_sha256':h(mp),'alias_groups':59,'all_established_cold_alias_groups':295,'retained_original_paths':177,'original_git_commands':1475,'limits':['No large body rehash in this cross-check. Original root executors performed full physical hashes and Git blob comparisons, while preserved original source helper checks full small streams and exact metadata.','Actual owner census failure remains false; maintenance is not a product gate.','All295 cold alias groups must be delinked before any write/reuse; original inode/mtime identities are historical only.']}
O.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(O),'sha256':h(O),'checks':checks,'findings':findings,'exit_code':result['exit_code']}));raise SystemExit(result['exit_code'])
