from pathlib import Path
import hashlib,json
P=Path('/workspace/geo339-six-original-aliases-preparation-20261024');O=Path('/workspace/geo339-six-terminal-originals-preserving-links-execution-20261024');L=Path('/workspace/geo339-six-terminal-originals-preserving-links-launch-20261024')
p=json.loads((P/'PLAN.json').read_text());r=json.loads((O/'RESULT.json').read_text());j=[json.loads(x) for x in (O/'GROUP-1.jsonl').read_text().splitlines()];c=[]
def ck(n,b):c.append({'name':n,'pass':bool(b)})
def sha(x):return hashlib.sha256(x).hexdigest()
ck('actual terminal0',r['exit_code']==0 and r['actual_replacement_performed']);ck('plan raw pin',sha((P/'PLAN.json').read_bytes())==r['plan_sha256']);ck('core raw pin',sha((P/'exact_six_alias_link_core.py').read_bytes())==r['core_sha256'])
ck('six members exact',len(p['members'])==6 and {x['path'] for x in p['members']}=={x['path'] for x in r['final_metadata']});ck('17 journal rows',len(j)==17);ck('initial allfreshhash',len(j[0]['originals'])==6 and all(x['sha256']==p['sha256'] for x in j[0]['originals']));ck('initial allseparate',len({(x['dev'],x['inode']) for x in j[0]['originals']})==6 and all(x['nlink']==1 for x in j[0]['originals']))
for k in range(1,6):
 rows=j[1+(k-1)*3:1+k*3];ck('sequence'+str(k),[x['event'] for x in rows]==['before_link','temporary_link_verified','replacement_verified'] and all(x['index']==k for x in rows));ck('expected nlink'+str(k),rows[0]['expected_alias_count']==k and rows[1]['expected_alias_count']==k+1 and rows[2]['expected_alias_count']==k+1);ck('temp absent'+str(k),not Path(rows[0]['temp']).exists());ck('destination'+str(k),rows[0]['destination']==p['members'][k]['path'])
ck('complete retains',j[-1]['all_original_paths_present'] and j[-1]['bytes_unchanged'] and j[-1]['expected_alias_count']==6)
meta=[]
for x in p['members']:
 q=Path(x['path']);s=q.stat();meta.append((s.st_dev,s.st_ino));ck('stillregular '+str(q),q.is_file() and not q.is_symlink());ck('size+nlink '+str(q),s.st_size==4716492 and s.st_nlink==6)
ck('freshsameinode',len(set(meta))==1)
for x in p['anchors']:
 q=Path(x['path']);ck('anchor '+str(q),q.stat().st_size==x['bytes'] and sha(q.read_bytes())==x['sha256'])
for i in range(1,7):
 x=json.loads((O/f'consumers-{i:03d}'/'CONSUMERS.json').read_text());ck('consumer nohits '+str(i),x['hits']==[]);ck('visibilitylimit '+str(i),bool(x['unreadable']) and 'inaccessible' in x['limitation'])
ck('failures unchanged',r['original_failures_preserved']==p['original_failures_preserved']==[1,1,1,0])
for root,expected in [(O/'git-originals',3),(L,1)]:
 a=json.loads((root/'subcommands.json').read_text());ck('childcount '+str(root),len(a)==expected)
 for i,x in enumerate(a):
  ck('childexit '+str(root)+str(i),x['actual_process_returncode']==0 and not x['timeout_expired'])
  for stream in ['stdin','stdout','stderr']:ck('childraw '+str(root)+str(i)+stream,sha((Path(x['directory'])/(stream+'.bin')).read_bytes())==x[stream+'_sha256'])
ck('outer0',json.loads((L/'RESULT.json').read_text())['actual_process_returncode']==0)
report={'checks_total':len(c),'failed_checks':sum(not x['pass'] for x in c),'checks':c,'findings':[],'subject':str(O),'limits':['Actual metadata/raw small-stream review only; original 4,716,492B archive not rehashed by peer. Owner fresh hashes are preserved in original journal.','No rerun, replacement, deletion, Git or C; permission-inaccessible OS processes not claimed inspected.','Six immutable paths are shared; append/truncate/reuse ban remains until all are de-linked.','Historical1/1/1/0 publication exits retained; maintenance0 is not product acceptance.']}
Path(__file__).with_name('REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['checks_total'],report['failed_checks']);raise SystemExit(bool(report['failed_checks']))
