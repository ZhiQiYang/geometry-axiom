from pathlib import Path
import ast,hashlib,json,stat
B=Path('/workspace/three-large-terminal-archives-preparation-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');tool=B/'link_exact_three_large_terminal_archive_groups.py';code=tool.read_text();old=Path(p['original_core']['path']).read_text();core=Path(p['core']['path']).read_text()
ck(h(B/'PLAN.json')=='7cbeec8b3c36f77dde886ef4e482ed6cfaf621a2e99ae734cb6bb11f174eb375','fixed PLAN')
ck(h(tool)=='90e35cbf75a61bd84142a163283b5c8068f3fce619c2f1faaa681efbce3b82a1','fixed executor')
ck(h(p['original_core']['path'])==p['original_core']['sha256']=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4','original core pin')
ck(h(p['core']['path'])==p['core']['sha256']=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','new core pin')
expected=old.replace("len(members) == 3 and len({x['path'] for x in members}) == 3","len(members) in (2, 4, 7) and len({x['path'] for x in members}) == len(members)").replace("len({(x['dev'], x['inode']) for x in members}) == 3","len({(x['dev'], x['inode']) for x in members}) == len(members)").replace('All three public paths','All named public paths').replace('state(members, {1, 2})','state(members, set(range(1, len(members))))').replace("event='complete', expected_alias_count=3","event='complete', expected_alias_count=len(members)")
ck(core==expected and ast.dump(ast.parse(core))==ast.dump(ast.parse(expected)),'only five cardinality/comment changes; full-byte state/atomic link+replace/fsync/journal unchanged')
ck(h(p['consumer_guard']['path'])==p['consumer_guard']['sha256']=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','original consumer guard')
ck(h('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original capture')
roots=['/workspace/geo261-cold/g261r2/work/codex-geo261-fe863b03/repo','/workspace/geo261-cold/g261r2/work/q38/repo','/workspace/geo261-cold/g261a1/work/codex-geo261-a12d184e/repo','/workspace/geo261-cold/g261a1/work/q38/repo','/workspace/geo261-cold/g261r1/work/codex-geo261-f2c8837a/repo','/workspace/geo261-cold/g261r1/work/q38/repo','/workspace/geo261-cold/g261r1/source-final']
heads=['fe863b0374eafd9f1e57ec5107e28a1101804b56']*2+['a12d184ec1865ad078700cea2387ac69e82ab62a']*2+['f2c8837aeba3c49eacbd77b5161f07c819204263']*3
specs=[(7,'tests/release-evidence/20261008/geometry-main-evidence-459478e9.tar.gz','3bd6f83ec9bcdc9cfc70e88091ba46db215e6ad374e261248e227d1eda9a9203','72ed8f50cbcaa08d1d218c7ddd7bc47c3839eff8',39046314,234283008),(4,'evidence/geo261-final-f2c8837a/raw/card-reference.raw.tar.gz','a5fb2c0e2f4969b64acf3030510fc6bf5bd85195b462cfeb45ae063e8fd78204','e8994b13776c51595dcba7173bb1f3a19acbec37',54623441,163872768),(2,'evidence/geo261-final-a12d184e/raw/card-reference.raw.tar.gz','aae74f9612c688d7bd5afbb07fc6470b4f13ff06b4bd1e62cd0697076c6fbd2b','6f330359ee60ef26b448826c53ca1c8bdcde7079',54788215,54792192)]
ck([o['root'] for o in p['owners']]==roots and [o['head'] for o in p['owners']]==heads and p['consumer_prefixes']==roots,'exact seven owner HEADs and consumer coverage')
ck(p['target_count']==13 and len(p['groups'])==3 and sum(g['expected_allocated_saving'] for g in p['groups'])==p['expected_allocated_saving']==452947968,'exact three groups/13paths/configured allocation only')
commands=[(r,['git','rev-parse','HEAD'],head) for r,head in zip(roots,heads)]
for g,(n,rel,digest,blob,size,saving) in zip(p['groups'],specs):
 ck(g['count']==n and len(g['members'])==n and g['sha256']==digest and g['git_blob']==blob and g['expected_allocated_saving']==saving,'exact group '+rel)
 ck([x['path'] for x in g['members']]==[r+'/'+rel for r in roots[:n]],'named group paths '+rel)
 ck(len({(x['dev'],x['inode']) for x in g['members']})==n and len({x['dev'] for x in g['members']})==1,'distinct same-device originals '+rel)
 ck(sum(x['allocated_bytes'] for x in g['members'][1:])==saving,'planned allocation sum '+rel)
 for idx,x in enumerate(g['members']):
  ck(x['owner_root']==roots[idx] and x['owner_head']==heads[idx] and x['git_path']==rel and x['sha256']==digest and x['git_blob']==blob and x['size']==size and x['nlink']==1,'exact archive identity '+x['path'])
  s=Path(x['path']).lstat();ck(stat.S_ISREG(s.st_mode) and all(getattr(s,'st_ino' if k=='inode' else 'st_'+k)==x[k] for k in ['dev','inode','mode','size','mtime_ns','uid','gid','nlink']),'fresh metadata only '+x['path'])
  commands.extend([(x['owner_root'],['git','ls-tree',x['owner_head'],'--',rel],f'100644 blob {blob}\t{rel}'),(x['owner_root'],['git','cat-file','-s',blob],str(size)),(x['owner_root'],['git','hash-object',x['path']],blob)])
for x in p['anchors']:
 q=Path(x['path']);ck(not q.is_symlink() and q.stat().st_size==x['bytes'] and h(q)==x['sha256'],'original small anchor '+str(q))
rows=[]
for t in p['terminal_rows']:
 raw=j(t['path']);ck(raw==t['original_rows'],'original terminal values '+t['path']);rows.extend(raw)
ck(len(p['terminal_rows'])==8 and len(rows)==54,'8 terminal receipts/54 original rows')
ck(all((r.get('finished_utc') or r.get('completed_utc')) and type(r.get('exit_code',r.get('actual_exit'))) is int for r in rows),'all named owner rows genuinely terminal including reds')
ck(any(r.get('exit_code',r.get('actual_exit'))==1 for r in rows),'historical red1 retained')
rawrows=j(B/'git-originals/subcommands.json');ck(len(rawrows)==len(commands)==46,'46 original Git captures')
for row,(cwd,argv,wanted) in zip(rawrows,commands):
 d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'],'original exact Git invocation '+d.name)
 ck(j(d/'result.json')==row and bool(j(d/'request.json')),'full original request/result '+d.name)
 for stream in ['stdout','stderr']:
  q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'full original '+stream+' '+d.name)
 ck((d/'stdout.bin').read_text().strip()==wanted and (d/'stderr.bin').stat().st_size==0,'exact Git identity output '+d.name)
for phrase in ["assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ","anchors();git_identity();consumer()","before_each=consumer","git_identity();anchors()","all_original_payload_paths_retained=True","OUT.mkdir()","no cleanup or destructive rollback","set(range(1,len(g['members'])))","actual_process_returncode"]:ck(phrase in code,'executor original guard '+phrase[:60])
ck("'-w'" not in code and 'unlink' not in code and 'rmtree' not in code and "rec.run(['git',*args]" in code,'no object write/deletion commands in executor')
ck(p['actual_replacement_executed'] is False and 'No independent OS outer transcript' in p['preparation_provenance'],'prep-only honest provenance')
ck('/g261F2perf/' not in '\n'.join(x['path'] for g in p['groups'] for x in g['members']) and 'truncated' in p['excluded_reason'],'unproven truncated counterfactual excluded')
ck('every alias is de-linked' in p['reservation'] and 'separate from423' in p['reservation'] and 'No claim of a clean complete historical checkout or acceptance success' in p['scope_limit'],'separate exact lease and limited claims')
r={'schema':'three-large-terminal-archive-groups-static-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'plan_sha256':h(B/'PLAN.json'),'executor_sha256':h(tool),'core_sha256':h(p['core']['path']),'counts':[7,4,2],'expected_allocated_saving':452947968,'terminal_original_rows':54,'original_preparation_git_commands':46,'limits':['Static/metadata/full small-stream review only; no archive body hash or replacement performed by reviewer.','Executor freshly checks all full archive bytes and all 46 Git identities before and after, with original consumer and full byte guards before each atomic transition.','All13 original paths preserved; inode/nlink/mtime may adopt canonical. Allocation estimate is not df net free.','Three independent groups/13 aliases and seven historical roots reserved; excluded truncated F2 owner untouched. No acceptance success or whole-checkout-clean claim.','Preparation direct exec provenance retained; no invented outer OS capture.'],'reviewer_initial_lookup_correction':'Read-only probe first expected commands.json; actual c387 index is subcommands.json. FileNotFoundError exit1 occurred before any mutation or report; correct existing index was then used.'}
q=O/'THREE_LARGE_ARCHIVE_GROUPS_STATIC_PEER.json';q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
