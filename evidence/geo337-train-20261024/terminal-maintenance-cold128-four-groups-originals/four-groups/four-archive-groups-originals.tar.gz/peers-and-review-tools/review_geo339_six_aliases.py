from pathlib import Path
import ast,hashlib,json,stat
B=Path('/workspace/geo339-six-original-aliases-preparation-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');tool=B/'link_exact_six_terminal_originals.py';code=tool.read_text();old=Path(p['original_core']['path']).read_text();core=Path(p['core']['path']).read_text()
ck(h(B/'PLAN.json')=='fc239575635849e828af274874167975855b49ac1ee85e41146d33e0f39cbb97','fixed plan')
ck(h(tool)=='1c6e800e8fed60f7ef3f68242e7f39a3c9185161a8edfc73080c09f251b29ce9','fixed root executor')
ck(h(p['original_core']['path'])==p['original_core']['sha256']=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4','unchanged original core')
ck(h(p['core']['path'])==p['core']['sha256']=='2d6098d3ab98c3e0b5add90c4fcaaae52b203a9dca803b3526cf36cf2251c8f9','fixed six core')
expected=old.replace("len(members) == 3 and len({x['path'] for x in members}) == 3","len(members) == 6 and len({x['path'] for x in members}) == 6").replace("len({(x['dev'], x['inode']) for x in members}) == 3","len({(x['dev'], x['inode']) for x in members}) == 6").replace('All three public paths','All six public paths').replace('state(members, {1, 2})','state(members, {1, 2, 3, 4, 5})').replace("event='complete', expected_alias_count=3","event='complete', expected_alias_count=6")
ck(core==expected and ast.dump(ast.parse(core))==ast.dump(ast.parse(expected)),'only five cardinality/comment replacements; atomic/full-byte/journal guard unchanged')
ck(h(p['consumer_guard']['path'])==p['consumer_guard']['sha256']=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','unchanged original process guard')
wanted=['/workspace/geo339-F38da-affected-terminal-collection-20261024/ORIGINAL_F38DA_IMPORTERS_142_AND_PREDICATE_PROOFS.tar.gz','/workspace/geo339-publication-20261024/publication/subcommands/000012/stdin.bin','/workspace/geo339-publication-20261024/publication-resume-v3/subcommands/000043/stdout.bin','/workspace/geo339-publication-20261024/publication-resume-v3/subcommands/000034/stdout.bin','/workspace/geo339-publication-20261024/publication-resume/subcommands/000034/stdout.bin','/workspace/geo339-publication-20261024/publication-resume-v2/subcommands/000034/stdout.bin']
ck([x['path'] for x in p['members']]==wanted and p['count']==6 and len({(x['dev'],x['inode']) for x in p['members']})==6 and len({x['dev'] for x in p['members']})==1,'exact six named distinct same-device paths')
ck(all(x['size']==4716492 and x['nlink']==1 and x['sha256']==p['sha256']=='c2d2c75b39536d7e801cb31af2cc49d0de3aafd130a0a0cdd27b6701b8abc435' for x in p['members']),'all planned exact original archive bytes identity')
ck(sum(x['allocated_bytes'] for x in p['members'][1:])==p['expected_allocated_saving']==23592960,'configured allocation saving only')
for x in p['members']:
 s=Path(x['path']).lstat();ck(stat.S_ISREG(s.st_mode) and all(getattr(s,'st_ino' if k=='inode' else 'st_'+k)==x[k] for k in ['dev','inode','mode','size','mtime_ns','uid','gid','nlink']),'fresh current metadata without payload hash '+x['path'])
for x in p['anchors']:
 f=Path(x['path']);ck(not f.is_symlink() and f.stat().st_size==x['bytes'] and h(f)==x['sha256'],'small original anchor '+x['path'])
ck(p['original_failures_preserved']==[1,1,1,0],'historical failure outcomes retained')
for x in p['terminal_receipts']:
 r=j(x['path']);ck(h(x['path'])==x['sha256'] and r['endedUTC']==x['ended_utc'] and r['exitCode']==x['exit_code'],'closed immutable owner original '+x['path'])
for x in p['members'][1:]:
 f=Path(x['path']);row=j(f.parent/'result.json');stream=f.stem;ck(row[stream+'_sha256']==p['sha256'] and row['actual_process_returncode']==0 and row['ended_epoch'] and not row['timeout_expired'],'original c387 stream and true exit binding '+x['path'])
ck(p['consumer_prefixes']==['/workspace/geo339-publication-20261024','/workspace/geo339-F38da-affected-terminal-collection-20261024'],'fresh guard covers all owners')
for phrase in ["assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ","anchors();git_identity();consumer();core['state'](p['members'],set())","before_each=consumer","core['state'](p['members'],{1,2,3,4,5});anchors()","['hash-object',p['members'][0]['path']]","actual_replacement_performed=True","OUT.mkdir()"]:ck(phrase in code,'executor original safety guard '+phrase[:55])
ck("['cat-file','-s',g['blob']]" in code and "['ls-tree',g['evidence_head'],'--',g['path']]" in code and "'-w'" not in code,'immutable published Git identity read-only freshly checked')
ck('no cleanup or destructive rollback' in code and 'No producer may append, truncate, rewrite or reuse' in p['reservation'] and 'separate from the423 cold groups and the2 cardref ELF groups' in p['reservation'],'all6 retained independent write ban and failure preservation')
ck(p['actual_replacement_executed'] is False and 'No independent OS outer transcript' in p['preparation_provenance'],'prep-only honest provenance')
r={'schema':'geo339-six-original-archive-aliases-static-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'plan_sha256':h(B/'PLAN.json'),'executor_sha256':h(tool),'core_sha256':h(p['core']['path']),'scope_paths':wanted,'expected_allocated_saving':23592960,'historical_owner_exits':[1,1,1,0],'limits':['No payload hash or replacement by reviewer; original prep recorded exact body hashes and executor freshly rechecks every full byte and immutable Git blob before/through replacement.','Original archive and five captured stream paths remain present; original inode/mtime identities adopt canonical and are not claimed preserved.','One new six-alias group is separate from423 cold groups and2 controlled-cardref groups. No named path may be appended/reused until every alias delinked.','Readable process visibility limitations remain those of the original guard; do not claim unseen processes were inspected.','Original preparation was direct cloud exec and does not invent an independent outer capture.']}
q=O/'GEO339_SIX_ALIAS_STATIC_PEER.json';q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
