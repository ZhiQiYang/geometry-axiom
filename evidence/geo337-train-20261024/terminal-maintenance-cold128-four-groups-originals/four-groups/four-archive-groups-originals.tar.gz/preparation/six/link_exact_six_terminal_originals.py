"""Root-only exact six immutable aliases; all paths and bytes survive atomically."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, sys

B=Path('/workspace/geo339-six-original-aliases-preparation-20261024')
PLAN=B/'PLAN.json';PIN='fc239575635849e828af274874167975855b49ac1ee85e41146d33e0f39cbb97'
CORE=B/'exact_six_alias_link_core.py';CORE_PIN='2d6098d3ab98c3e0b5add90c4fcaaae52b203a9dca803b3526cf36cf2251c8f9'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py');GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
OUT=Path('/workspace/geo339-six-terminal-originals-preserving-links-execution-20261024')

def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):v.update(b)
    return v.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert h(PLAN)==PIN and h(CORE)==CORE_PIN and h(GUARD)==GUARD_PIN and h(CAP)==CAP_PIN
    p=json.loads(PLAN.read_text())
    assert p['source_sha']=='38da31bcac91db631e6325e40b228f8604810e82'
    assert p['count']==6 and len(p['members'])==6 and p['expected_allocated_saving']==23592960
    assert p['sha256']=='c2d2c75b39536d7e801cb31af2cc49d0de3aafd130a0a0cdd27b6701b8abc435'
    core={'__name__':'_link_only','__file__':str(CORE)};exec(compile(CORE.read_bytes(),str(CORE),'exec'),core)
    guard={'__name__':'_consumer_only','__file__':str(GUARD)};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard)
    OUT.mkdir()
    r=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,source_sha=p['source_sha'],
           plan_sha256=PIN,core_sha256=CORE_PIN,free_before=guard['free'](),actual_replacement_performed=False,
           all_original_payload_paths_retained=False,reservation=p['reservation'],identity_limit=p['identity_limit'],
           failure_policy='Retain original result, journal and pending aliases on any failure; no cleanup or destructive rollback.',
           original_failures_preserved=p['original_failures_preserved'])
    count=0
    def anchors():
        for x in p['anchors']:
            q=Path(x['path']);core['ancestors'](q)
            assert q.stat().st_size==x['bytes'] and h(q)==x['sha256']
        for x in p['terminal_receipts']:
            t=json.loads(Path(x['path']).read_text())
            assert t['endedUTC']==x['ended_utc'] and t['exitCode']==x['exit_code']
    def consumer():
        nonlocal count
        count+=1;d=OUT/f'consumers-{count:03d}';d.mkdir();guard['OUT']=d
        guard['consumer_check'](p['consumer_prefixes']);anchors()
    def git_identity():
        spec=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
        rec=c.Recorder(OUT/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),p['source_sha'])
        g=p['immutable_git_identity']
        for args,expected in [(['ls-tree',g['evidence_head'],'--',g['path']],f"100644 blob {g['blob']}\t{g['path']}"),
                              (['cat-file','-s',g['blob']],str(p['members'][0]['size'])),
                              (['hash-object',p['members'][0]['path']],g['blob'])]:
            row,out,err=rec.run(['git',*args],cwd='/workspace/geometry-axiom',check=False,source_variant='read-only immutable published archive guard; no index or object writes')
            assert row['actual_process_returncode']==0 and not err and out.decode().strip()==expected
    try:
        anchors();git_identity();consumer();core['state'](p['members'],set())
        core['link_exact'](p['members'],OUT/'GROUP-1.jsonl',before_each=consumer)
        core['state'](p['members'],{1,2,3,4,5});anchors()
        r.update(exit_code=0,actual_replacement_performed=True,all_original_payload_paths_retained=True,
                 all_original_receipt_bytes_preserved=True,expected_allocated_saving=p['expected_allocated_saving'],consumer_checks=count,
                 final_metadata=[dict(path=x['path'],**core['metadata'](x['path'])) for x in p['members']])
    finally:
        r.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=guard['free']())
        dump(OUT/'RESULT.json',r);print(json.dumps({k:v for k,v in r.items() if k!='final_metadata'}))

if __name__=='__main__':main()
