"""Prepare one exact group of terminal archive/stream aliases; never link here."""
from pathlib import Path
import datetime, difflib, hashlib, importlib.util, json, os

B = Path('/workspace/geo339-six-original-aliases-preparation-20261024')
P = Path('/workspace/geo339-publication-20261024')
A = Path('/workspace/geo339-F38da-affected-terminal-collection-20261024')
S = '38da31bcac91db631e6325e40b228f8604810e82'
D = 'c2d2c75b39536d7e801cb31af2cc49d0de3aafd130a0a0cdd27b6701b8abc435'
ORIGINAL = Path('/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py')
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')

def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):v.update(b)
    return v.hexdigest()

def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=h(p))

assert h(ORIGINAL)=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(GUARD)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
B.mkdir()
old=ORIGINAL.read_text();source=old
changes=[("assert len(members) == 3 and len({x['path'] for x in members}) == 3","assert len(members) == 6 and len({x['path'] for x in members}) == 6"),
         ("assert len({(x['dev'], x['inode']) for x in members}) == 3","assert len({(x['dev'], x['inode']) for x in members}) == 6"),
         ('All three public paths','All six public paths'),
         ('state(members, {1, 2})','state(members, {1, 2, 3, 4, 5})'),
         ("dict(event='complete', expected_alias_count=3,","dict(event='complete', expected_alias_count=6,")]
for a,b in changes:
    assert source.count(a)==1
    source=source.replace(a,b)
core=B/'exact_six_alias_link_core.py';core.write_text(source)
(B/'CORE_DIFF.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile=str(ORIGINAL),tofile=str(core))))
ns={'__name__':'_read_only_core','__file__':str(core)};exec(compile(source,str(core),'exec'),ns)
package=json.loads((A/'PACKAGE.json').read_text())
assert package['sourceSHA']==S and package['archive']['sha256']==D and package['archive']['bytes']==4716492
inventory=P/'TERMINAL_RAW_DUPLICATE_INVENTORY.json';items=json.loads(inventory.read_text())['groups'][D]
assert len(items)==5
archive=Path(package['archive']['path'])
paths=[archive]+[Path(x['path']) for x in items]
anchors=[pin(A/'PACKAGE.json'),pin(inventory)]
terminal=[]
for name,expected in [('publication',1),('publication-resume',1),('publication-resume-v2',1),('publication-resume-v3',0)]:
    p=P/name/'RESULT.json';r=json.loads(p.read_text())
    assert r['sourceSHA']==S and r['exitCode']==expected and r['endedUTC']
    terminal.append(dict(**pin(p),exit_code=expected,ended_utc=r['endedUTC']))
    anchors.append(pin(p))
peer=Path('/workspace/train337-canvas-peer-resume/GEO339_AFFECTED_ACTUAL_PACKAGE_PEER.json')
pd=json.loads(peer.read_text());assert pd['exit_code']==0 and pd['findings']==[] and D in peer.read_text()
anchors.append(pin(peer))
for p in paths[1:]:
    r=json.loads((p.parent/'result.json').read_text())
    assert r['actual_process_returncode']==0 and r['source_sha']==S and r['ended_epoch']
    assert r['stdin_sha256' if p.name=='stdin.bin' else 'stdout_sha256']==D
    for q in sorted(p.parent.iterdir()):
        if q != p:
            assert q.is_file() and not q.is_symlink() and q.stat().st_size<100000
            anchors.append(pin(q))
members=[]
for p in paths:
    m=ns['metadata'](p)
    assert m['nlink']==1 and m['size']==4716492 and h(p)==D and not os.listxattr(p,follow_symlinks=False)
    members.append(dict(path=str(p),sha256=D,**m))
assert len({(x['dev'],x['inode']) for x in members})==6
assert len({(x['mode'],x['uid'],x['gid'],x['sha256'],x['size']) for x in members})==1
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
rec=c.Recorder(B/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),S)
publication=json.loads((P/'publication-resume-v3/RESULT.json').read_text())
commit=publication['evidenceHead'];relative='evidence/geo339-final-F38da/raw/'+archive.name
def git(args):
    row,out,err=rec.run(['git',*args],cwd='/workspace/geometry-axiom',check=False,source_variant='read-only already-published immutable archive identity')
    assert row['actual_process_returncode']==0 and not err
    return out.decode().strip()
tree=git(['ls-tree',commit,'--',relative]);blob=tree.split()[2]
assert tree.startswith('100644 blob ') and int(git(['cat-file','-s',blob]))==4716492
assert git(['hash-object',str(archive)])==blob
plan=dict(source_sha=S,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sha256=D,
          count=6,members=members,expected_allocated_saving=sum(x['allocated_bytes'] for x in members[1:]),
          anchors=anchors,terminal_receipts=terminal,original_core=pin(ORIGINAL),core=pin(core),consumer_guard=pin(GUARD),
          immutable_git_identity=dict(evidence_head=commit,path=relative,blob=blob),
          consumer_prefixes=[str(P),str(A)],
          reservation='Only these six named immutable archive/stream paths form a separate write/reuse ban until every alias is de-linked. This group is separate from the423 cold groups and the2 cardref ELF groups. No producer may append, truncate, rewrite or reuse any named alias.',
          identity_limit='Every original path and complete byte stream remains. Inode/nlink and noncanonical mtime/atime adopt the canonical archive metadata; original inode numbers are not restorable.',
          original_failures_preserved=[1,1,1,0],actual_replacement_executed=False,
          preparation_provenance='Direct cloud exec of this saved producer; three Git reads have original c387 command/env/exit/full streams. No independent OS outer transcript is claimed for the producer.')
save(B/'PLAN.json',plan)
print(json.dumps(dict(plan=str(B/'PLAN.json'),plan_sha256=h(B/'PLAN.json'),core_sha256=h(core),expected_allocated_saving=plan['expected_allocated_saving'],body_reads=6,actual_replacement_executed=False)))
