"""Select one bounded batch using preserved original storage overhead; no receipt-body reads."""
from pathlib import Path
import datetime,hashlib,json,stat
B=Path('/workspace/cold-small-128-preparation-20261024')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def allocation(root):
    root=Path(root);rows=[]
    for p in [root,*sorted(root.rglob('*'))]:
        s=p.lstat();assert stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode)
        rows.append({'path':str(p),'mode':s.st_mode,'bytes':s.st_size,'allocated_bytes':s.st_blocks*512})
    return {'path':str(root),'entries':rows,'files':sum(stat.S_ISREG(x['mode']) for x in rows),'allocated_bytes':sum(x['allocated_bytes'] for x in rows)}
def main():
    assert not B.exists();B.mkdir()
    source=Path('/workspace/cold-small-receipt-frozen-metadata-20261024/CANDIDATES.json')
    assert h(source)=='89452900926c57ae94b86b7c003b9655a29c3b73e1807ff13a2440ea25df4d97'
    candidates=json.loads(source.read_text());old=json.loads(Path('/workspace/cold_text_59_exact_body_manifest_20261024.json').read_text());samples=[]
    for item in old['items']:
        name=item['name'];row={'name':name,'prep':allocation(Path(item['plan']).parent),'execution':allocation('/workspace/'+name+'-receipt-archive-three-dedup-execution-20261023'),'outer':allocation('/workspace/'+name+'-receipt-archive-three-dedup-launch-20261024')}
        p=Path(item['tool']);s=p.lstat();row['tool']={'path':str(p),'bytes':s.st_size,'allocated_bytes':s.st_blocks*512}
        row['total_allocated_bytes']=sum(row[k]['allocated_bytes'] for k in ['prep','execution','outer','tool']);samples.append(row)
    save(B/'ORIGINAL_59_OVERHEAD_SAMPLES.json',samples)
    observed=max(x['total_allocated_bytes'] for x in samples)
    conservative=observed+65536
    points=[];gross=0
    for n,item in enumerate(candidates['items'],1):
        gross+=item['expected_allocated_saving'];points.append({'n':n,'gross_allocated_saving':gross,'observed_max_pattern_cost':n*observed,'net_under_observed_max':gross-n*observed,'conservative_cost_scenario':n*conservative,'net_under_conservative_scenario':gross-n*conservative})
    chosen=128;selected=candidates['items'][:chosen]
    plan={'schema':'cold-small-receipt-net-batch-plan/1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_candidate':str(source),'source_candidate_sha256':h(source),'overhead_samples':str(B/'ORIGINAL_59_OVERHEAD_SAMPLES.json'),'overhead_samples_sha256':h(B/'ORIGINAL_59_OVERHEAD_SAMPLES.json'),'observed_max_per_group_including_directory_blocks':observed,'conservative_per_group_scenario':conservative,'conservative_scenario_note':'Observed maximum plus64KiB per group is a planning sensitivity scenario, not a guaranteed hard bound; original full outputs/proc visibility records are preserved and never truncated to meet this estimate.','points':points,'observed_max_net_optimum':max(points,key=lambda x:x['net_under_observed_max']),'conservative_net_optimum':max(points,key=lambda x:x['net_under_conservative_scenario']),'chosen':points[chosen-1],'choice_reason':'Root requested starting with128 at42MiB free. One128 batch keeps initial original six-Git metadata preparation bounded and recovers most net capacity sooner; no payload/body guard or original output is weakened.','prep_upper_scenario_bytes':chosen*(max(x['prep']['allocated_bytes']+x['tool']['allocated_bytes'] for x in samples)+4096),'comparisons':{str(n):points[n-1] for n in [128,256,384,512,666]},'limits':['Historical stat allocations, not future guaranteed bytes or global free-space deltas. Root-only execution follows exact body preparation and independent peer.','No new Git scan, candidate body read, deletion, hardlink replacement, source or test modification occurred in this selector.','Later compressed publication/Git objects are additional storage and not counted as recovered bytes.','All existing295 cold groups plus successful128 new groups become423 write/reuse-banned groups until every alias is delinked; cardref2 groups are separate.']}
    save(B/'NET_PLAN.json',plan)
    scopes=[[f'cold-small-{n:03d}',x['relative'],x['git_blob'],x['bytes']] for n,x in enumerate(selected,1)]
    save(B/'SCOPES.json',scopes)
    original=Path('/tmp/prepare_next_cold_archive_batch.py');assert h(original)=='f869c4c384352222bf80e0b57dffa9abc44fbdfb38ac71dcd496bf46cf3eeaab'
    oldliteral="'/tmp/cold_next_archive_batch_scopes.json'";s=original.read_text();assert s.count(oldliteral)==1
    producer=B/'prepare_exact_cold_small_128.py';producer.write_text(s.replace(oldliteral,repr(str(B/'SCOPES.json'))));compile(producer.read_text(),str(producer),'exec')
    manifest={'count':chosen,'expected_allocated_saving':sum(x['expected_allocated_saving'] for x in selected),'source_candidates':str(source),'source_candidates_sha256':h(source),'net_plan':str(B/'NET_PLAN.json'),'net_plan_sha256':h(B/'NET_PLAN.json'),'scopes':str(B/'SCOPES.json'),'scopes_sha256':h(B/'SCOPES.json'),'deferred_producer':str(producer),'deferred_producer_sha256':h(producer),'original_producer':str(original),'original_producer_sha256':h(original),'body_read_budget':sum(x['bytes']*3 for x in selected),'items':selected,'subject_replacements_executed':False,'lease':'All prior295 and any successful new128 groups form423 cold groups; all aliases must be delinked before cold-root writes/reuse. Original paths/bytes remain. cardref2 groups are separate.'}
    save(B/'PREPARATION_MANIFEST.json',manifest)
    print(json.dumps({'plan':str(B/'NET_PLAN.json'),'plan_sha256':h(B/'NET_PLAN.json'),'chosen':plan['chosen'],'observed_max_net_optimum':plan['observed_max_net_optimum'],'conservative_net_optimum':plan['conservative_net_optimum'],'prep_upper_scenario_bytes':plan['prep_upper_scenario_bytes'],'manifest':str(B/'PREPARATION_MANIFEST.json'),'manifest_sha256':h(B/'PREPARATION_MANIFEST.json'),'producer_sha256':h(producer),'body_preparation_executed':False}))
if __name__=='__main__':main()
