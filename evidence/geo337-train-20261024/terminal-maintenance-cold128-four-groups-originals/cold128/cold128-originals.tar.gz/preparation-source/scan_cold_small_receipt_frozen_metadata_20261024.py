"""Reuse the existing complete Git-tree captures and current lstat only; no payload reads or Git calls."""
from pathlib import Path
import datetime, hashlib, json, stat

BASE=Path('/workspace/cold-small-receipt-frozen-metadata-20261024')
OLD=Path('/workspace/cold-nonarchive-three-copy-metadata-20261024')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
    assert not BASE.exists()
    commands=json.loads((OLD/'git-originals/subcommands.json').read_text())
    roots=[Path('/workspace/geo261-cold/g261seal')/n for n in ['p-source','a-source','l-source']]
    heads=['b6646d10751a0d85a2f03f5d24fbe1073cb78980','a12d184ec1865ad078700cea2387ac69e82ab62a','aa02a65e9d3923cc14c13340f05ed16c8b7d4fce']
    trees=[];original_capture_pins=[]
    for index,(root,head) in enumerate(zip(roots,heads)):
        hr,tr=commands[2*index:2*index+2]
        assert hr['actual_process_returncode']==tr['actual_process_returncode']==0
        assert hr['command']==['git','-c','gc.auto=0','-C',str(root),'rev-parse','HEAD']
        assert tr['command']==['git','-c','gc.auto=0','-C',str(root),'ls-tree','-r','-l','-z','HEAD']
        for row in (hr,tr):
            path=Path(row['directory'])/'stdout.bin';raw=path.read_bytes()
            assert len(raw)==row['stdout_bytes'] and digest(raw)==row['stdout_sha256']
            original_capture_pins.append({'path':str(path),'bytes':len(raw),'sha256':digest(raw)})
            if row is hr:assert raw.decode().strip()==head
        tree={}
        for entry in raw.split(b'\0'):
            if not entry:continue
            meta,path=entry.split(b'\t',1);mode,kind,blob,size=meta.split()
            if mode==b'100644' and kind==b'blob' and size!=b'-' and 65536<=int(size)<1048576:
                tree[path.decode()]={'mode':mode.decode(),'blob':blob.decode(),'size':int(size)}
        trees.append(tree)
    items=[];excluded={}
    snapshot_parts={'source','sources','source-base','source-main','source-fix','fixtures','fixture','scenes','inputs','input','work','tools','tools-frozen','node_modules','.git'}
    suffixes=('.json','.jsonl','.log','.stdout','.stderr')
    for relative,first in trees[0].items():
        if any(tree.get(relative)!=first for tree in trees[1:]):continue
        parts=Path(relative).parts
        receipt=relative.startswith(('evidence/','tests/evidence/','tests/release-evidence/','geometry-core/domain-decoupling/evidence/','geometry-web/docs/evidence/')) or '/evidence/' in relative
        reason=None
        if not receipt:reason='outside-immutable-evidence-prefix'
        elif not relative.endswith(suffixes):reason='not-json-jsonl-or-named-text-log'
        elif any(p in snapshot_parts for p in parts):reason='source-fixture-input-tool-or-work-snapshot'
        if reason:excluded[reason]=excluded.get(reason,0)+1;continue
        paths=[root/relative for root in roots]
        if not all(p.is_file() and not p.is_symlink() for p in paths):continue
        ss=[p.lstat() for p in paths]
        if len({(s.st_dev,s.st_ino) for s in ss})!=3 or any(s.st_nlink!=1 for s in ss):continue
        if len({s.st_dev for s in ss})!=1 or any(s.st_size!=first['size'] or not stat.S_ISREG(s.st_mode) for s in ss):continue
        items.append({'relative':relative,'git_blob':first['blob'],'bytes':first['size'],'paths':list(map(str,paths)),'expected_allocated_saving':sum(s.st_blocks*512 for s in ss[1:]),'priority':'immutable-receipt','members':[dict(path=str(p),dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,size=s.st_size,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,allocated_bytes=s.st_blocks*512) for p,s in zip(paths,ss)]})
    items.sort(key=lambda x:(-x['expected_allocated_saving'],x['relative']))
    report={'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'heads':dict(zip(map(str,roots),heads)),'scope':'64KiB <= original blob size <1MiB; same complete path/mode/blob/size across original frozen three-head Git metadata; current regular distinct inode/nlink1 same-device stats; immutable receipt prefix and JSON/JSONL/named-text-log suffix only.','original_capture_pins':original_capture_pins,'original_commands_path':str(OLD/'git-originals/subcommands.json'),'original_commands_sha256':digest((OLD/'git-originals/subcommands.json').read_bytes()),'excluded_classification_counts':excluded,'metadata_only':True,'new_git_tree_commands':0,'file_body_hashes_performed':False,'actual_dedup_executed':False,'items':items,'count':len(items),'total_expected_allocated_saving':sum(x['expected_allocated_saving'] for x in items),'limits':['No original receipt/source/body read. Only previous recorded Git-tree bytes and current file lstat are consulted.','No new Git HEAD/tree query; original heads are historical recorded identities. Original executor must freshly recheck heads, Git blobs, physical bytes and consumers before any future authorized link operation.','Source/fixture/input/work/tool snapshots and all archive or .bin suffixes excluded conservatively. No active ROOT/cache or Git objects scanned.','All295 established cold alias groups remain write/reuse banned until all aliases are independently delinked; future approved groups inherit that reservation. Separate cardref2 controlled ELF groups are not part of this count.','Estimate only, not actual free space or executed maintenance. No path or bytes modified.']}
    BASE.mkdir();dump(BASE/'CANDIDATES.json',report)
    print(json.dumps({'path':str(BASE/'CANDIDATES.json'),'sha256':digest((BASE/'CANDIDATES.json').read_bytes()),'count':len(items),'expected_allocated_saving':report['total_expected_allocated_saving'],'executed':False}))

if __name__=='__main__':main()
