"""Reuse the original maintenance collector for the completed single128 batch only."""
from pathlib import Path
import hashlib,difflib
old=Path('/workspace/collect_cold59_and_cardref_originals_20261024.py');raw=old.read_text()
assert hashlib.sha256(old.read_bytes()).hexdigest()=='e4b0056a2dc08a5b1900f26abbeb7644726464a5a75d77b8a0fb226051a0c1b5'
s=raw.replace("OUT=Path('/workspace/cold59-and-cardref-links-originals-20261024')","OUT=Path('/workspace/cold128-originals-20261024')")
s=s.replace("[('/workspace/cold_text_59_exact_body_manifest_20261024.json','482ad13ed12a4029dc4e79c6ab084ad034521abba16d073d74818178fb82f602')]","[('/workspace/cold_small_128_exact_body_manifest_20261024.json','850b38009a13d79321a0de06b316fac85249889a531f6105056c9e712289ccfe')]")
s=s.replace('len(items)==59 and sum(i[\'expected_allocated_saving\'] for i in items)==286375936','len(items)==128 and sum(i[\'expected_allocated_saving\'] for i in items)==150953984')
start=s.index(" tree('/workspace/cold-nonarchive-three-copy-metadata-20261024'")
end=s.index(' total=sum(',start)
middle=''' tree('/workspace/cold-small-128-preparation-20261024','preparation-source/cold128')
 tree('/workspace/cold-small-receipt-frozen-metadata-20261024','preparation-source/metadata-census')
 tree('/workspace/cold-small-receipt-frozen-metadata-launch-20261024','preparation-launch/metadata-census')
 tree('/workspace/cold-small-128-body-preparation-launch-20261024','preparation-launch/cold128')
 for path in ['/workspace/prepare_cold_small_128_metadata_20261024.py','/workspace/scan_cold_small_receipt_frozen_metadata_20261024.py','/tmp/prepare_next_cold_archive_batch.py','/workspace/summarize_prepared_cold_archive_batch_20261024.py']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/deduplicate_release_exact_three_receipts.py','/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/run_cold_receipt_batch.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 add('/workspace/cold128-root-sequential-execution-20261024.json','root-sequential-execution.json')
 prior=Path('/workspace/cold59-and-cardref-links-originals-20261024/PACKAGE.json')
 assert digest(prior)=='43759f9d932eb66581fc3aad6a94e936e4c6334355c5e7fb56cc359646e0ab7d'
 add(prior,'prior-proof-reference/COLD59_CARDREF_PACKAGE.json')
 peers=['COLD128_NETPLAN_STATIC_PEER.json','review_cold128_netplan.py','COLD_128_EXACT_THREE_EXECUTOR_STATIC_PEER.json','review_cold_exact_preparation.py','COLD128_ROOT_WRAPPER_STATIC_PEER.json','review_cold128_root_wrapper.py','COLD128_ACTUAL_SUMMARY_HELPER_PEER.json','review_cold128_actual_summary.py']
 for name in peers:add(Path('/workspace/train337-canvas-peer-resume')/name,'peers-and-review-tools/'+name)
 for path in ['/workspace/COLD_128_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json','/workspace/review_cold128_actual_metadata_20261024.py']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 add(__file__,'collector.py')
 add('/workspace/prepare_cold128_original_collection_20261024.py','collector-preparation.py')
 add('/workspace/collect_cold59_and_cardref_originals_20261024.py','original-collector.py')
 for path in ['/workspace/COLD_128_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json','/workspace/train337-canvas-peer-resume/COLD128_ACTUAL_SUMMARY_HELPER_PEER.json']:
  r=readj(path);assert r['exit_code']==0 and not r['findings']
'''
s=s[:start]+middle+s[end:]
s=s.replace("archive=OUT/'cold59-and-cardref-links-originals.tar.gz'","archive=OUT/'cold128-originals.tar.gz'")
start=s.index(' result=dict(');end=s.index(" dump(OUT/'PACKAGE.json'",start)
result=''' result=dict(schema='cold128-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,cold_receipt_alias_groups_added=128,all_established_cold_alias_groups=423,configured_gross_source_block_saving=150953984,limits=['Maintenance only; no product gate is executed or relabeled.','All384 source receipt paths and bytes remain; no receipt body or ELF executable payload is duplicated into this package.','All423 established cold alias groups including295 previous groups must be delinked before any write/reuse of any of the three cold checkouts. Two separate cardref ELF alias groups are outside this count and remain independently write-banned.','Actual reviews verify metadata and complete small command streams; original executors performed full physical byte/Git blob comparisons. No second large payload rehash is claimed.','Original12.3MB Git-tree captures are already in the referenced prior cold59/cardref archive, pinned in its PACKAGE. Their exact pins are retained in the current metadata census; payloads are not copied again.','Original selector ran via direct exec_command. Its explicit transcript provenance discloses that no independent c387 environment/stream capture was made for that earlier selector; actual body preparation and replacement retain their complete original c387 captures.','Gross source block savings are not net storage recovery: full prep/exec/outer/tool/package/Git publication overhead remains. NET_PLAN preserves original59 stat samples and labels its margin as sensitivity scenario, not a hard bound.','Concurrent global free-space changes are not substituted for allocation measurements. Original inode identities and per-path mtime are not claimed unchanged.','Independent peer reports created after this fixed package remain adjacent attachments.'])
'''
s=s[:start]+result+s[end:]
p=Path('/workspace/collect_cold128_originals_20261024.py');assert not p.exists();p.write_text(s);compile(s,str(p),'exec')
Path('/workspace/cold128-collector-scope-diff-20261024.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(keepends=True),s.splitlines(keepends=True),fromfile=str(old),tofile=str(p))))
print(str(p),hashlib.sha256(p.read_bytes()).hexdigest())
