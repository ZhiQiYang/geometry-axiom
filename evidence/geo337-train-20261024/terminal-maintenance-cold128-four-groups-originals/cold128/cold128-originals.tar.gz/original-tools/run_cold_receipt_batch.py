"""Run an exact peer-reviewed batch through the unchanged maintenance recorder."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys

p = argparse.ArgumentParser()
for name in ('manifest', 'manifest-sha256', 'peer', 'peer-sha256', 'out'):
    p.add_argument('--' + name, required=True)
a = p.parse_args()
manifest, peer, out = Path(a.manifest), Path(a.peer), Path(a.out)
assert not out.exists()
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == a.manifest_sha256
assert hashlib.sha256(peer.read_bytes()).hexdigest() == a.peer_sha256
review = json.loads(peer.read_text())
assert review['exit_code'] == 0 and review['findings'] == []
data = json.loads(manifest.read_text())
assert data['count'] == len(data['items']) == 128
assert data['core_sha256'] == '6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
assert review['manifest_sha256'] == a.manifest_sha256
rows = []
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1'); env.pop('PYTHONOPTIMIZE', None)
for index, item in enumerate(data['items'], 1):
    assert item['name'].startswith('cold-small-') and '/' not in item['name']
    assert hashlib.sha256(Path(item['tool']).read_bytes()).hexdigest() == item['tool_sha256']
    argv = [sys.executable, '-B', '/workspace/run_approved_maintenance.py',
            '--tool', item['tool'], '--sha256', item['tool_sha256'],
            '--source-sha', '7af8c5d80d34cb4f49d01ba67deb78a3a6d725db',
            '--peer', str(peer), '--out', '/workspace/' + item['name'] + '-receipt-archive-three-dedup-launch-20261024']
    result = subprocess.run(argv, env=env, capture_output=True)
    rows.append(dict(name=item['name'], argv=argv, exit_code=result.returncode,
                     stdout=result.stdout.decode(), stderr=result.stderr.decode()))
    out.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    if index % 10 == 0 or result.returncode or index == len(data['items']):
        print(index, item['name'], result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)
print('ALL128_COMPLETE', flush=True)
