from pathlib import Path
import ast,hashlib,json
B=Path('/workspace/cold-small-128-preparation-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;find=[]
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
n=j(B/'NET_PLAN.json');m=j(B/'PREPARATION_MANIFEST.json');c=j(m['source_candidates']);samples=j(n['overhead_samples']);scopes=j(m['scopes'])
ck(h(B/'NET_PLAN.json')==m['net_plan_sha256']=='d0f9403899393173afc6b565549f70ed8116858a5291c1e7f6eb545c6814ff2c','fixed plan')
ck(h(B/'PREPARATION_MANIFEST.json')=='8818277dbf602a2ff01397336eeb863390560cd5c98715bd1baf3af2865a5c06','fixed prep manifest')
ck(h(m['source_candidates'])==m['source_candidates_sha256']==n['source_candidate_sha256']=='89452900926c57ae94b86b7c003b9655a29c3b73e1807ff13a2440ea25df4d97','fixed original candidates')
ck(h(n['overhead_samples'])==n['overhead_samples_sha256']=='2975f4cae08d1485c77abdf872a8fc54245f335eec37c6f389074425c1fc6a60','original sample metadata pin')
ck(h(m['scopes'])==m['scopes_sha256']=='85d6269b3f8c6025b71539361bbdf67611086caf4508e0b22b9613eb65ad7185','exact selected scope')
ck(len(samples)==59 and len({x['name'] for x in samples})==59,'59 distinct overhead samples')
for sample in samples:
 for k in ['prep','execution','outer']:ck(sum(x['allocated_bytes'] for x in sample[k]['entries'])==sample[k]['allocated_bytes'],'directory-inclusive allocation '+sample['name']+'/'+k)
 ck(sum(sample[k]['allocated_bytes'] for k in ['prep','execution','outer','tool'])==sample['total_allocated_bytes'],'total original allocation '+sample['name'])
observed=max(x['total_allocated_bytes'] for x in samples);ck(observed==n['observed_max_per_group_including_directory_blocks']==438272,'observed maximum')
ck(n['conservative_per_group_scenario']==observed+65536 and 'not a guaranteed hard bound' in n['conservative_scenario_note'],'sensitivity explicitly not hard bound')
ck(len(c['items'])==c['count']==666 and c['items']==sorted(c['items'],key=lambda x:(-x['expected_allocated_saving'],x['relative'])),'frozen candidate order')
ck(m['items']==c['items'][:128] and m['count']==128 and len(scopes)==128,'exact first128 only')
ck(scopes==[[f'cold-small-{i:03d}',x['relative'],x['git_blob'],x['bytes']] for i,x in enumerate(m['items'],1)],'one new unique namespace exact path/blob/size')
ck(len({x['relative'] for x in m['items']})==128 and len({p for x in m['items'] for p in x['paths']})==384,'unique selected128/384paths')
for x in m['items']:
 parts=Path(x['relative']).parts
 ck(x['priority']=='immutable-receipt' and x['relative'].endswith(('.json','.jsonl','.log','.stdout','.stderr')) and ('evidence' in parts or 'release-evidence' in parts) and not any(z in parts for z in ['source','sources','source-base','source-main','source-fix','fixtures','fixture','scenes','inputs','input','work','tools','tools-frozen','node_modules','.git']),'immutable scope '+x['relative'])
 ck(65536<=x['bytes']<1048576 and len(x['members'])==3 and len({(z['dev'],z['inode']) for z in x['members']})==3 and all(z['nlink']==1 and z['size']==x['bytes'] for z in x['members']),'original distinct singlelinks '+x['relative'])
ck(m['body_read_budget']==3*sum(x['bytes'] for x in m['items'])==225571263,'full body-read budget no payload copy')
total=0
for i,x in enumerate(c['items'],1):
 total+=x['expected_allocated_saving'];want={'n':i,'gross_allocated_saving':total,'observed_max_pattern_cost':observed*i,'net_under_observed_max':total-observed*i,'conservative_cost_scenario':(observed+65536)*i,'net_under_conservative_scenario':total-(observed+65536)*i}
 ck(n['points'][i-1]==want,'independent net point '+str(i))
ck(n['chosen']==n['points'][127] and m['expected_allocated_saving']==n['chosen']['gross_allocated_saving']==150953984,'selected128 exact planned gross')
old=Path(m['original_producer']).read_text();new=Path(m['deferred_producer']).read_text();ck(h(m['original_producer'])==m['original_producer_sha256']=='f869c4c384352222bf80e0b57dffa9abc44fbdfb38ac71dcd496bf46cf3eeaab','original producer pin')
ck(h(m['deferred_producer'])==m['deferred_producer_sha256']=='37b74da2b9b52822fd8cae10424ebcfa7e6e4d5cb494ce6a96709f83b7074faa','adapted producer pin')
expected=old.replace('/tmp/cold_next_archive_batch_scopes.json',str(B/'SCOPES.json'));ck(new==expected and ast.dump(ast.parse(new))==ast.dump(ast.parse(expected)),'single scope path literal only; original fresh preparation guards retained')
ck(m['subject_replacements_executed'] is False and '423' in m['lease'] and 'delinked' in m['lease'],'no claimed replacement; all aliases remain reserved')
r={'schema':'cold128-netplan-and-producer-static-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'plan_sha256':h(B/'NET_PLAN.json'),'preparation_manifest_sha256':h(B/'PREPARATION_MANIFEST.json'),'producer_sha256':h(m['deferred_producer']),'selected_groups':128,'gross_allocated_saving':150953984,'observed_pattern_net_estimate':94855168,'conservative_sensitivity_net_estimate':86466560,'initial_prep_scenario_bytes':18874368,'limits':['Historical observed allocations and sensitivity scenario only, not guaranteed upper bound or actual df recovery. Later publication/Git object storage excluded.','No body payload, current consumer process or source checkout read by this peer; actual formal preparation and root executor must apply original full fresh guards.','No maintenance executor run. All previous295 plus successful new128 groups are423 write/reuse-banned groups until every alias is independently delinked.']}
p=O/'COLD128_NETPLAN_STATIC_PEER.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
