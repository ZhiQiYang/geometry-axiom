"""Independent metadata review; preserves original cold17 actual checks with new frozen scope."""
from pathlib import Path
import hashlib,json,stat
P=Path;count=0;find=[];rows=[]
def ck(n,v):
 global count;count+=1
 if not v:find.append(n)
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(P(p).read_text())
items=[]
for path,pin in [('/workspace/cold_small_128_exact_body_manifest_20261024.json','850b38009a13d79321a0de06b316fac85249889a531f6105056c9e712289ccfe')]:
 ck('frozen manifest '+path,h(P(path).read_bytes())==pin);items.extend(j(path)['items'])
for item in items:
 n=item['name'];p=j(item['plan']);out=P(f'/workspace/{n}-receipt-archive-three-dedup-execution-20261023');outer=P(f'/workspace/{n}-receipt-archive-three-dedup-launch-20261024');r=j(out/'RESULT.json');a=j(outer/'RESULT.json');cmds=j(out/'COMMANDS.json');journal=[json.loads(x) for x in (out/'JOURNAL.jsonl').read_text().splitlines()]
 ck(n+' pins',h(P(item['plan']).read_bytes())==item['plan_sha256'] and h(P(item['tool']).read_bytes())==item['tool_sha256']);ck(n+' true terminal0',r['exit_code']==0 and bool(r['ended_utc']) and r['all_three_paths_and_bytes_preserved'] is True);ck(n+' exact3 scope',r['source_paths']==[x['path'] for x in p['members']] and r['expected_allocated_saving']==p['expected_allocated_saving']==item['expected_allocated_saving'])
 identities=[]
 for original,final in zip(p['members'],r['final_metadata']):
  path=P(original['path']);st=path.lstat();identities.append((st.st_dev,st.st_ino));ck(n+' regularalias '+str(path),stat.S_ISREG(st.st_mode) and st.st_nlink==3 and st.st_size==p['size']);ck(n+' closed final metadata '+str(path),all(getattr(st,attr)==final[key] for key,attr in [('dev','st_dev'),('inode','st_ino'),('mode','st_mode'),('size','st_size'),('mtime_ns','st_mtime_ns'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink')]))
  tr=original['terminal_receipt'];ck(n+' unchanged producer receipt '+str(path),h(P(tr['path']).read_bytes())==tr['sha256'])
 ck(n+' common canonical inode',len(set(identities))==1 and identities[0]==(p['members'][0]['dev'],p['members'][0]['inode']));ck(n+' source red retained',[x['terminal_receipt']['original_passed'] for x in p['members']]==[True,False,True]);ck(n+' original25Git0',len(cmds)==25 and all(x['exit_code']==0 for x in cmds))
 for k,c in enumerate(cmds):
  request=j(out/f'{k:03d}.request.json');ck(n+f' argv{k}',request['argv']==c['argv'])
  if 'compared_bytes' in c:ck(n+' original fullbody streamed comparison metadata',c['compared_bytes']==p['size'] and c['stdout_sha256']==p['sha256'] and c['stdout_retained_at_original_paths']==r['source_paths'])
  else:
   for stream in ('stdout','stderr'):
    data=(out/f'{k:03d}.{stream}.bin').read_bytes();ck(n+f' originalstream{k} '+stream,len(data)==c[stream+'_bytes'] and h(data)==c[stream+'_sha256'])
 ck(n+' initial exact and temps gone',journal[0]['event']=='initial_verified' and journal[0]['originals']==p['members'] and all(not P(x).exists() for x in journal[0]['temporary_paths']));repls=[x for x in journal if x['event']=='replacement_verified'];ck(n+' exact2 replacement sequence',[(x['index'],x['expected_alias_count']) for x in repls]==[(1,2),(2,3)])
 for q in sorted(out.glob('CONSUMERS*.json')):
  c=j(q);ck(n+' accessibleproc '+q.name,c['hits']==[] and 'unreadable' in c and bool(c['limitation']))
 ck(n+' no inode unchanged claim','not restorable' in r['inode_limit'] and 'canonical mtime/inode' in r['metadata_limit']);ck(n+' outer0',a['actual_process_returncode']==0 and a['timeout_expired'] is False)
 for stream in ('stdout','stderr'):
  data=(P(a['directory'])/(stream+'.bin')).read_bytes();ck(n+' outerstream '+stream,len(data)==a[stream+'_bytes'] and h(data)==a[stream+'_sha256'])
 rows.append({'group':n,'actual_exit':r['exit_code'],'outer_exit':a['actual_process_returncode'],'result_sha256':h((out/'RESULT.json').read_bytes()),'journal_sha256':h((out/'JOURNAL.jsonl').read_bytes()),'configured_saving':r['expected_allocated_saving'],'observed_free_delta':{p:r['free_after'][p]-r['free_before'][p] for p in ['/workspace','/tmp']},'canonical_body_independent_rehash':False})
ck('128 groups sum',len(rows)==128 and sum(x['configured_saving'] for x in rows)==150953984)
report={'scope':'128 exact3 immutable small receipt dedup completed operations: independent metadata, journal, original small command streams, alias and preserved-receipt checks only','checks':count,'findings':find,'exit_code':int(bool(find)),'groups':rows,'original_git_commands':sum(len(j(P('/workspace')/(x['group']+'-receipt-archive-three-dedup-execution-20261023/COMMANDS.json'))) for x in rows),'new_alias_groups':128,'total_established_cold_alias_groups':423,'limits':['No independent canonical payload rehash. Original executor full physical body/Git comparison records are preserved; this metadata review does not substitute for an independent body rehash.','All 384 original paths remain regular aliases; destination historical inode IDs and mtime are not claimed unchanged.','All423 cold checkout archive and nonarchive receipt alias groups remain write-banned until every one is de-linked; count includes295 previous groups.','Observable proc scope only; inaccessible fields remain unknown.','Configured allocated savings are not equal to concurrent observed global free-space changes.','This reviewer prepared metadata plans but did not execute any archive replacement; root executed original tools.']}
q=P('/workspace/COLD_128_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json');assert not q.exists();q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q.read_bytes()),'checks':count,'findings':find,'exit_code':report['exit_code']}));raise SystemExit(report['exit_code'])
