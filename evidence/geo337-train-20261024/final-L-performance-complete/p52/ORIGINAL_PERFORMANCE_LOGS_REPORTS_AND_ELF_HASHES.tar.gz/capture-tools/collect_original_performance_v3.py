"""Package only terminal original performance evidence; never run a subject or read ROOT."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,stat,tarfile
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
def hfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def need(x,s):
 if not x:raise RuntimeError(s)
p=argparse.ArgumentParser();p.add_argument('--gate',choices=['p52','p189','p189-timing','geo323','memo'],required=True);a=p.parse_args()
roots={'p52':'/tmp/g337p52L','p189':'/workspace/g337p189L','p189-timing':'/workspace/g337p189L-timing','geo323':'/workspace/g337323L','memo':'/workspace/g337323memoL'}
out=Path(roots[a.gate]);d=Path(__file__).parent/(a.gate+'-v3')
need(not d.exists(),'fresh collection directory required')
stages=['prepare','build','compare','perf','profile']
outer_names=['geo323-'+stage for stage in stages] if a.gate=='geo323' else [a.gate]
outer_roots=[('outer-'+gate,Path('/workspace/train337-L-'+gate+'-original-launch-20261024')) for gate in outer_names]
outer_results={gate:json.loads((root/'RESULT.json').read_text()) for gate,(_,root) in zip(outer_names,outer_roots)}
for gate,o in outer_results.items():
 need(o['source_sha']==L and o['gate']==gate and type(o['actual_exit']) is int and o['command']['ended_epoch'],'real exact-L terminal outer required')
 need(o['actual_exit']==o['command']['actual_process_returncode'],'original outer exit identity')
r=json.loads((out/'receipt.json').read_text())
for _,root in outer_roots:
 request=json.loads((root/'REQUEST.json').read_text())
 for path,wanted in request['entry_sha256'].items():need(hfile(Path(path))==wanted,'original frozen entry pin '+path)
if a.gate in ['p52','p189','p189-timing']:
 prep_path=Path('/tmp/train337-final-p52-p189-prep/PREPARATION.json');need(hfile(prep_path)==r['preparation_sha256'],'original special preparation pin')
 prep=json.loads(prep_path.read_text())
 for item in prep['files']:
  f=prep_path.parent/item['path'];need(f.stat().st_size==item['bytes'] and hfile(f)==item['sha256'],'original special tool '+item['path'])
elif a.gate=='geo323':
 for path,wanted in r['tool_hashes'].items():need(hfile(Path('/tmp/geo323-train337-lineage-20261024/acceptance-tools-v4-scene-binding')/path)==wanted,'original v4 tool '+path)
else:
 need(hfile(Path('/tmp/geo323-train337-lineage-20261024/memo-proof-tools/run.py'))==r['driver_sha256'],'original memo driver pin')
 for path,wanted in r['tool_hashes'].items():need(hfile(Path(path))==wanted,'original memo dependency '+path)
if a.gate in ['p52','p189','p189-timing']:
 need(r['source_sha']==L and r['gate']==a.gate and r.get('ended_utc') and r['launcher_exit_code']==outer_results[a.gate]['actual_exit'],'original special terminal receipt required')
 b=json.loads((out/'before-source.json').read_text());e=json.loads((out/'after-source.json').read_text())
 need(b==e and b['head']==L and b['status']=='','original closed source guard; no current ROOT read')
 summary={'original_driver_exit':r['launcher_exit_code'],'original_passed':r['passed'],'original_phases':r['phases'],'source_before':b,'source_after':e,'original_errors':r['errors'],'started_utc':r['started_utc'],'ended_utc':r['ended_utc']}
 if a.gate=='p52':
  summary.update(original_timing_criterion="medians['fix'] <= medians['main']",original_order=['main','fix','fix','main'],repetitions_per_block=8,samples_per_side=16,original_controls=['normal','delay','revert-delay','wrong','missing'])
 if a.gate=='p189-timing':
  need(r['overall_P189_passed'] is False,'timing-only cannot waive original full dump red')
  scope=json.loads((out/'measurement/TIMING_ONLY_SCOPE.json').read_text());need(scope['overall_P189_passed'] is False and scope['source_sha']==L,'original timing-only scope binding')
  summary.update(overall_P189_passed=False,original_timing_only_scope=scope,original_full_out=r['original_full_out'])
elif a.gate=='geo323':
 need(r['source_sha']==L and all(stage in r['stages'] and r['stages'][stage].get('ended_utc') for stage in stages),'five original formal stages must be terminal before sealing shared out')
 for stage in stages:
  row=r['stages'][stage];need(row['source_before']==row['source_after']=={'head':L,'status':''},'original closed stage guard '+stage)
 summary={key:r[key] for key in ['source_sha','base','main','stages','errors','quantitative_targets','wrapper_exit','all_executed_stage_commands_passed','all_measured_original_targets_met','all_required_stages_completed','full_acceptance_passed']}
 summary['original_passed']=r['full_acceptance_passed']
 summary['formal_stage_scope']=stages
 summary['stage_exit_note']='Each stages[name].execution_exit is separate from cumulative CLI/wrapper exits. An earlier compare1 can leave later perf/profile CLI1 even when those stage executions are0.'
else:
 need(r['sha']==L and r.get('ended_utc') and r['exit']==outer_results['memo']['actual_exit'],'original memo terminal receipt required')
 need(r['source_before']==r['source_after']=={'head':L,'status':''},'original closed memo guard')
 summary={key:r[key] for key in ['sha','started_utc','ended_utc','source_before','source_after','phases','errors','fixed_formal_criterion','formal_receipt_sha256','scope','passed','exit']}
 summary['original_passed']=r['passed']
 summary['negative_proof_note']='Original expected withdrawn1/restored0/abc0 requires execution_complete and original criterion; infrastructure2 is not a negative proof. Isolated175 ABC does not clear formal cross-feature comparison red.'
d.mkdir();rows=[];excluded=[];stream_rows=[];chrome_ipc=[];capture_annotations=[]
evidence_roots=[('original',out),*outer_roots]
if a.gate=='p52':evidence_roots.extend([('original-failed-collection',Path(__file__).parent/'p52-collection-launch'),('original-failed-collection-v2',Path(__file__).parent/'p52-v2-collection-launch')])
for label,root in evidence_roots:
 for f in sorted(root.rglob('*')):
  s=f.lstat();name=label+'/'+str(f.relative_to(root))
  if stat.S_ISDIR(s.st_mode):continue
  if not stat.S_ISREG(s.st_mode):
   parts=f.relative_to(root).parts
   allowed=(a.gate=='p52' and label=='original' and len(parts)==5 and parts[:3]==('formal','work','tmp') and (parts[3].startswith('chrome-') or parts[3].startswith('com.google.Chrome.')) and parts[4] in ['SingletonCookie','SingletonLock','SingletonSocket'] and (stat.S_ISLNK(s.st_mode) or (stat.S_ISSOCK(s.st_mode) and parts[4]=='SingletonSocket')))
   need(allowed,'unexpected nonregular original evidence: '+str(f))
   item={'name':name,'source_path':str(f),'mode':s.st_mode,'size':s.st_size,'dev':s.st_dev,'inode':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'kind':'symlink' if stat.S_ISLNK(s.st_mode) else 'unix-socket','reason':'Terminal Chrome IPC metadata only; original path retained, never dereferenced, opened, unlinked or archived as a regular payload.'}
   if stat.S_ISLNK(s.st_mode):
    target=os.readlink(f);body=os.fsencode(target);item.update(link_target=target,link_target_bytes_hex=body.hex(),link_target_sha256=hashlib.sha256(body).hexdigest())
   chrome_ipc.append(item);continue
  need(stat.S_ISREG(s.st_mode),'unexpected nonregular original evidence: '+str(f))
  with f.open('rb') as fh:elf=fh.read(4)==b'\x7fELF'
  z={'name':name,'source_path':str(f),'bytes':s.st_size,'sha256':hfile(f)}
  if elf:z['reason']='ELF payload excluded only; original ordinary or controlled executable retained at source_path';excluded.append(z)
  else:rows.append(z)
# Preserve every original c387/v4 recorder tree, including original nested phases.
 for record_file in sorted([*root.rglob('subcommands.json'),*root.rglob('commands.json')]):
  records=json.loads(record_file.read_text())
  need(isinstance(records,list),'original recorder rows must be a list: '+str(record_file))
  for row in records:
   q=Path(row['directory']);need(q.is_relative_to(root),'capture directory containment')
   saved=json.loads((q/'result.json').read_text())
   if saved!=row:
    extras=set(row)-set(saved)
    need(a.gate=='p52' and record_file==out/'formal/subcommands.json' and bool(extras) and extras<={'effective_environment','legacy_probe_log'} and set(saved)<=set(row) and {k:row[k] for k in saved}==saved,'only original P52 post-capture annotations may differ; every OS field remains exact')
    capture_annotations.append({'record_file':str(record_file),'result_file':str(q/'result.json'),'result_sha256':hfile(q/'result.json'),'original_appended_annotations':{k:row[k] for k in sorted(extras)},'shared_original_OS_fields_exact':True,'reason':'Original p52-formal.py run()/recorded_command() append these fields after c387 writes result.json. Both original JSON artifacts are retained unchanged.'})
   else:need(saved==row,'original capture row equals result')
   for kind in ['stdout','stderr']:
    f=q/(kind+'.bin');need(f.stat().st_size==row[kind+'_bytes'] and hfile(f)==row[kind+'_sha256'],'full captured '+kind)
   f=q/'stdin.bin'
   if f.exists():need(hfile(f)==row['stdin_sha256'],'full original stdin')
   else:need(row['stdin_provided'] is False and row['stdin_sha256']==hashlib.sha256(b'').hexdigest(),'original v4 absent stdin is explicit empty input')
   need((q/'request.json').is_file(),'original request retained')
   stream_rows.append({'record_file':str(record_file),'directory':str(q),'exit':row['actual_process_returncode'],'timeout':row['timeout_expired'],'source_sha':row['source_sha'],'acceptance_sha':row['acceptance_sha']})
# Frozen external tools are evidence; no driver is imported or executed here.
tool_roots=[('special','/tmp/train337-final-p52-p189-prep')] if a.gate in ['p52','p189','p189-timing'] else [('v4','/tmp/geo323-train337-lineage-20261024/acceptance-tools-v4-scene-binding')]
if a.gate=='memo':tool_roots += [('memo','/tmp/geo323-train337-lineage-20261024/memo-proof-tools'),('v3','/tmp/geo323-merge-20261023/acceptance-tools-v3')]
for label,path in tool_roots:
 root=Path(path)
 for f in sorted(root.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:
   need(not f.is_symlink(),'frozen original tool must be regular')
   rows.append({'name':'tools/'+label+'/'+str(f.relative_to(root)),'source_path':str(f),'bytes':f.stat().st_size,'sha256':hfile(f)})
for f in [Path(__file__),Path(__file__).parent/'collect_original_performance.py',Path(__file__).parent/'collect_original_performance_v2.py',Path('/workspace/launch_geo337_L_performance.py'),Path('/workspace/final-L-performance-exact-argv-20261024.json'),Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),Path('/workspace/geo261-environment/reap_children.py')]:
 rows.append({'name':'capture-tools/'+f.name,'source_path':str(f),'bytes':f.stat().st_size,'sha256':hfile(f)})
if a.gate=='memo':
 f=Path('/workspace/g337323L/receipt.json');need(hfile(f)==r['formal_receipt_sha256'],'original closed formal prerequisite receipt')
 rows.append({'name':'formal-binding/receipt.json','source_path':str(f),'bytes':f.stat().st_size,'sha256':hfile(f)})
need(len({z['name'] for z in rows})==len(rows),'unique package members')
summary.update(schema='original-performance-terminal-collection/1',source_sha=L,gate=a.gate,original_outer_exits={gate:o['actual_exit'] for gate,o in outer_results.items()},original_capture_rows=stream_rows,elf_payload_excluded_count=len(excluded),elf_payload_excluded_bytes=sum(z['bytes'] for z in excluded),no_existing_file_deleted=True,no_subject_executed=True,limitations=['Only original exposed outputs are retained. No hidden pipe, missing receipt or already-cleaned source snapshot is invented.','All excluded ELF payloads remain at original paths with hashes; no executable body is archived or unlinked.','Original source guards establish historical identity; current shared ROOT/cache is not read.','Timing-only never changes original full P189 red. Each GEO323 stage execution, cumulative CLI result and quantitative target is distinct.','Original v4 source_role/source_sha heuristic may label orchestration base because argv contains --base; original fields remain unmodified.','A collection roundtrip success only verifies evidence bytes, not acceptance success.'])
summary['terminal_chrome_ipc_metadata_count']=len(chrome_ipc)
summary['limitations'].append('Only exact terminal P52 Chrome Singleton IPC paths are metadata-only exclusions. Symlink bytes/targets and lstat are recorded without following links; socket payload is not representable and is not claimed archived. All original IPC paths remain. The initial collector failure and exact old collector bytes are retained separately inside this package.')
save(d/'EXCLUDED_CHROME_IPC_METADATA.json',chrome_ipc)
save(d/'ORIGINAL_P52_CAPTURE_ANNOTATIONS.json',capture_annotations)
summary['original_p52_post_capture_annotation_rows']=len(capture_annotations)
summary['limitations'].append('Only the original P52 formal ledger may append effective_environment/legacy_probe_log after c387 result persistence. No original common OS field may differ; both original files and their exact annotation mapping are preserved. Both initial collector failures remain separate from the original product result.')
for name,value in [('EXCLUDED_ELF_PAYLOADS.json',excluded),('SUMMARY.json',summary)]:save(d/name,value)
for f in sorted(d.iterdir()):
 rows.append({'name':'collection/'+f.name,'source_path':str(f),'bytes':f.stat().st_size,'sha256':hfile(f)})
inv={'source_sha':L,'gate':a.gate,'members':rows,'regular_file_count':len(rows),'logical_original_bytes':sum(z['bytes']for z in rows),'excluded_elf_manifest':'collection/EXCLUDED_ELF_PAYLOADS.json'};save(d/'RAW_INVENTORY.json',inv)
archive=d/'ORIGINAL_PERFORMANCE_LOGS_REPORTS_AND_ELF_HASHES.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as t:
 for z in rows:t.add(z['source_path'],arcname=z['name'],recursive=False)
 t.add(d/'RAW_INVENTORY.json',arcname='RAW_INVENTORY.json',recursive=False)
expected={z['name']:z for z in rows};seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  need(m.isfile() and m.name not in seen,'unique regular member');seen.add(m.name)
  body=t.extractfile(m).read()
  if m.name=='RAW_INVENTORY.json':need(body==(d/'RAW_INVENTORY.json').read_bytes(),'inventory roundtrip')
  else:
   z=expected[m.name];need(len(body)==z['bytes'] and hashlib.sha256(body).hexdigest()==z['sha256'] and hfile(Path(z['source_path']))==z['sha256'],'original byte roundtrip '+m.name)
need(seen==set(expected)|{'RAW_INVENTORY.json'},'exact archive coverage')
package={'source_sha':L,'gate':a.gate,'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':hfile(archive),'members':len(seen)},'inventory':{'path':str(d/'RAW_INVENTORY.json'),'sha256':hfile(d/'RAW_INVENTORY.json')},'all_selected_original_bytes_roundtrip':True,'elf_payloads_included':False,'original_elf_files_retained':True,'subject_executions':0,'published':False}
save(d/'PACKAGE.json',package);print(json.dumps(package))
