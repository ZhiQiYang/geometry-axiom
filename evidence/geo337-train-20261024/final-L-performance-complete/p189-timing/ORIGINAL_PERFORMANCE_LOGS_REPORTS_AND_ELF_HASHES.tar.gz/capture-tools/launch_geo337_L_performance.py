"""Capture one frozen original performance command; root grants an exclusive slot."""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, os, shutil, sys

p = argparse.ArgumentParser()
p.add_argument('--gate', choices=['p52', 'p189', 'memo', 'geo323-prepare', 'geo323-build', 'geo323-compare', 'geo323-perf', 'geo323-profile', 'p189-timing'], required=True)
p.add_argument('--root-exclusive-lease', action='store_true', required=True)
a = p.parse_args()
L = '7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
manifest = Path('/workspace/final-L-performance-exact-argv-20261024.json')
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '627438965715077a6fea35eb839ef0ecc2ffb62e4aa0f5bdcef75bc27ef4b86c'
data = json.loads(manifest.read_text())
assert data['L'] == L
entry_pins = {
    '/tmp/train337-final-p52-p189-prep/run_special.py': 'cbafab25c3a9ebe3d4cc07d5f14d8cf36fd38cf9b22bd28af21515c136315e42',
    '/tmp/geo323-train337-lineage-20261024/acceptance-tools-v4-scene-binding/run.py': 'd4a38b7b60ac698eba4a274c5d26c83684cd1c665b8399f5e47546befae1f70e',
    '/tmp/geo323-train337-lineage-20261024/memo-proof-tools/run.py': 'd60cfb09f9f70f196e8b6f27e0fb74bdb557d653eae3289501278682ad2b5378',
}
for entry, pin in entry_pins.items():
    assert hashlib.sha256(Path(entry).read_bytes()).hexdigest() == pin, entry
commands = data['commands']
if a.gate.startswith('geo323-'):
    stages = ['prepare', 'build', 'compare', 'perf', 'profile']
    argv = commands['geo323FormalInOriginalOrder'][stages.index(a.gate[7:])]
elif a.gate == 'p189-timing':
    argv = commands['optionalP189TimingOnlyAfterOriginalDumpAssertionRed']
else:
    argv = commands[a.gate]
capture = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(capture.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', capture)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
outer = Path('/workspace/train337-L-' + a.gate + '-original-launch-20261024')
assert not outer.exists()
secondary = Path('/tmp/g261r3/secondary.lock').open('r+b')
fcntl.flock(secondary, fcntl.LOCK_EX | fcntl.LOCK_NB)
# The original inner command owns the heavy lock. Probe it without double-locking.
with Path('/tmp/g261r3/heavy.lock').open('r+b') as probe:
    fcntl.flock(probe, fcntl.LOCK_EX | fcntl.LOCK_NB)
outer.mkdir()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
r = c.Recorder(outer, env, L)
c.dump(outer / 'REQUEST.json', dict(source_sha=L, gate=a.gate, argv=argv,
    exact_original_argv_manifest=str(manifest), root_exclusive_slot_granted=True,
    entry_sha256=entry_pins,
    free_before={x: shutil.disk_usage(x).free for x in ['/workspace', '/tmp']},
    original_assertions_thresholds_and_timeouts_unchanged=True))
row, stdout, stderr = r.run(argv, cwd=Path(data['cwd']), timeout=None, check=False,
                           source_variant='original-final-L-' + a.gate)
result = dict(source_sha=L, gate=a.gate, actual_exit=row['actual_process_returncode'], command=row)
c.dump(outer / 'RESULT.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'command'}))
sys.exit(row['actual_process_returncode'])
