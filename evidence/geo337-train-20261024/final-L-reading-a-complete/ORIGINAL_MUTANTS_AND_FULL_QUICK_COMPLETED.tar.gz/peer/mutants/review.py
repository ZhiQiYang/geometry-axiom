from pathlib import Path
import datetime,hashlib,json
P=Path('/workspace/train337-L-reading-a-results-7af8c5d8-r2/oracle-mutants');O=Path('/tmp/reading-a-L-mutants-r2-actual-peer');O.mkdir(exist_ok=True)
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db';h=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((P/'receipt.json').read_text());rows=json.loads((P/'subcommands.json').read_text());checks=[]
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
ck('true terminal stage at L',d['stage']=='oracle-mutants' and d['sha']==L and bool(d.get('ended_utc')))
ck('original exact CLI',d['original_command']==['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3','-B','/workspace/train337-L-reading-a-source/geometry-core/framing-template/oracle/selftest.py','--mutants-only'])
ck('original actual0 notwrapperonly',d['original_result']['actual_process_returncode']==d['actual_exit_code']==d['reaper_final']['primary_returncode']==0 and d['passed']is True and d['errors']==[] and d['reaper_final']['event']=='完成' and not d['original_result']['timeout_expired'])
ck('original stage driver pinned',d['tool_sha256']['/workspace/geo318-reading-a-prep/formal-tools/run_stage.py']=='1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a')
ck('explicit Lenvironment and16MiB',d['environment']['GITHUB_SHA']==L and d['environment']['GITHUB_WORKSPACE']==d['root']=='/workspace/train337-L-reading-a-source' and d['stack_during'][0]==16777216 and d['environment']['PYTHONOPTIMIZE']=='0')
ck('beforeafterLclean',[g['label']for g in d['guards']]==['before','after'] and all(g['head'].strip()==L and g['status']==g['cached']=='' and g['head_exit']==g['status_exit']==g['cached_exit']==0 for g in d['guards']))
ck('nine original captured commands',len(rows)==9)
for i,r in enumerate(rows,1):
 D=Path(r['directory']);stored=json.loads((D/'result.json').read_text());request=json.loads((D/'request.json').read_text())
 ck(f'row{i}original metadata',stored==r and request['command']==r['command'] and request['source_sha']==r['source_sha']==L and r['acceptance_sha']==L)
 for s in ('stdout','stderr'):
  raw=(D/(s+'.bin')).read_bytes();ck(f'row{i}{s}byteshash',len(raw)==r[s+'_bytes'] and h(raw)==r[s+'_sha256'])
 ck(f'row{i}stdinbyteshash',h((D/'stdin.bin').read_bytes())==r['stdin_sha256'])
ck('all original commands0',all(r['actual_process_returncode']==0 and not r['timeout_expired']for r in rows))
r=d['original_result'];output=(Path(r['directory'])/'stdout.bin').read_text();err=(Path(r['directory'])/'stderr.bin').read_bytes()
ck('original successful requested scope footer',output.rstrip().endswith('(--mutants-only:跳過掃描)') and 'README 審查 6332818768 的計數、方向、端面敘述:對'in output and not err)
ck('r1 retained not erased',Path('/workspace/train337-L-reading-a-results-7af8c5d8/oracle-mutants/receipt.json').is_file())
report={'schema':'reading-a-L-mutants-only-r2-actual-peer/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only terminal r2 original mutants-only command, full nine c387 streams, original source guards/environment and scope footer. No quick half-result read and no test executed.','L':L,'originalProcessExit':0,'receipt':{'path':str(P/'receipt.json'),'sha256':h((P/'receipt.json').read_bytes())},'originalStdout':{'path':str(Path(r['directory'])/'stdout.bin'),'bytes':r['stdout_bytes'],'sha256':r['stdout_sha256']},'checkCount':len(checks),'checks':checks,'findings':[x['label']for x in checks if not x['passed']],'limits':['--mutants-only explicitly does not run the rectangle/reflex/step scan; this result cannot stand in for the independently required full --quick.','Original printed [紅] negative-control diagnostics are intentional controls, not failed CLI exits.','r1 missing-module environment failures remain immutable and independently archived; this r2 result does not overwrite them.','Final outer before/after22-input/fullstage/index guard remains separate until both stages truly terminate.']}
report['exitCode']=int(bool(report['findings']));p=O/'REVIEW.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'findings':report['findings'],'exitCode':report['exitCode']}));raise SystemExit(report['exitCode'])
