from pathlib import Path
import datetime,hashlib,json
P=Path('/workspace/train337-L-reading-a-results-7af8c5d8-r2');O=Path('/tmp/reading-a-L-quick-r2-actual-peer');O.mkdir(exist_ok=True)
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db';h=lambda b:hashlib.sha256(b).hexdigest();checks=[];raw_index={}
def read(p):
 p=Path(p);raw=p.read_bytes();raw_index[str(p)]={'bytes':len(raw),'sha256':h(raw)};return raw
def load(p):return json.loads(read(p))
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
quick=load(P/'oracle-quick/receipt.json');outer=load(P/'RESULT.json');binding=load('/workspace/train337-L-reading-a-preparation/SOURCE_BINDING.json')
ck('quicktrue terminal L',quick['stage']=='oracle-quick' and quick['sha']==L and bool(quick.get('ended_utc')))
ck('original unshortened quick CLI',quick['original_command']==['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3','-B','/workspace/train337-L-reading-a-source/geometry-core/framing-template/oracle/selftest.py','--quick'])
q=quick['original_result'];ck('CLI/reaper0 and no tool error',q['actual_process_returncode']==quick['actual_exit_code']==quick['reaper_final']['primary_returncode']==0 and quick['passed']is True and quick['errors']==[] and not q['timeout_expired'] and quick['reaper_final']['event']=='完成')
ck('original stage L clean both guards',all(g['head'].strip()==L and g['head_exit']==g['status_exit']==g['cached_exit']==0 and g['status']==g['cached']==''for g in quick['guards']) and len(quick['guards'])==2)
ck('explicit environment/16MiB',quick['environment']['GITHUB_SHA']==L and quick['stack_during'][0]==16777216 and quick['environment']['PYTHONOPTIMIZE']=='0')
ck('outertrue terminal passed',outer['sha']==L and outer.get('endedUTC')=='2026-10-23T22:45:53.451047+00:00' and outer['passed']is True)
ck('both original stage0 in originalorder',[(s['stage'],s['commandResult']['actual_process_returncode'])for s in outer['stageResults']]==[('oracle-mutants',0),('oracle-quick',0)])
ck('outer22bytebindingsidentical',outer['before']['passed'] and outer['after']['passed'] and outer['before']['inputs']==outer['after']['inputs']==binding['files'] and len(binding['files'])==22)
ck('outerfullstageandindexsame',outer['before']['stage']['stdoutSHA256']==outer['after']['stage']['stdoutSHA256'] and outer['before']['indexSHA256']==outer['after']['indexSHA256'])
ck('source repaired sameL not newer source',outer['root']==binding['root']=='/workspace/train337-L-reading-a-source' and binding['sourceSHA']==L and outer['bindingSHA256']==h(read('/workspace/train337-L-reading-a-preparation/SOURCE_BINDING.json')))
count=0
for directory,expected in [(P/'oracle-quick',9),(P,10)]:
 rows=load(directory/'subcommands.json');ck('original command count '+str(directory),len(rows)==expected)
 for i,r in enumerate(rows,1):
  count+=1;D=Path(r['directory']);result=load(D/'result.json');request=load(D/'request.json')
  ck('original metadata '+str(D),result==r and request['command']==r['command'] and request['source_sha']==r['source_sha']==L and r['acceptance_sha']==L)
  ck('original process0 '+str(D),r['actual_process_returncode']==0 and not r['timeout_expired'])
  for stream in ('stdout','stderr'):
   raw=read(D/(stream+'.bin'));ck('streambytes '+str(D)+'/'+stream,len(raw)==r[stream+'_bytes'] and h(raw)==r[stream+'_sha256'])
  ck('stdinbytes '+str(D),h(read(D/'stdin.bin'))==r['stdin_sha256'])
stdout=read(Path(q['directory'])/'stdout.bin');ck('original39824Bquickoutputpin',len(stdout)==q['stdout_bytes']==39824 and h(stdout)==q['stdout_sha256']=='2710f75986babb4f3d7166823609477c591b43967c55331b7633a05ee91ec77e')
text=stdout.decode()
for name,part in [
 ('mainSweep39850quickfail0','掃描 39850 次建構(快速),365 秒;不可施工或檢查失敗 0 個'),
 ('reflex579x8','凹角、壁龕與獨立柱房 579 間 × 8 種排法:物理上可施工 4632 個'),
 ('step410x8','牆階 1–100 mm 的 L 形、壁龕與雙牆階 410 間 × 8 種排法:物理上可施工 3280 個'),
 ('mirror820x8','鏡像(上下、左右)的牆階與雙牆階 820 間 × 8 種排法:物理上可施工 6560 個'),
 ('odd1872separate','奇數縫寬(1、3)矩形房 1872 次:不可施工或檢查失敗 0 個'),
 ('frozen528coverage','閱讀 A step 凍結正例逐筆觀察：要求 528、漏掃 0、非 buildable 0'),
 ('frozen1056coverage','閱讀 A step_mirror 凍結正例逐筆觀察：要求 1056、漏掃 0、非 buildable 0'),
 ('t10mirror392','P-182 候選掃描 t10 分辨房族(含鏡像):392 次'),
 ('knownoriginalt4six','P-182 候選掃描 t4 牆階加柱:704 次,可施工 429、不可施工 275;檢查失敗、trace 被 C7 判有問題(這一族沒跑鏡像) 0(已知缺陷 C11_MAIN_NOT_BUTTED 6 次,另開工單)')]:ck('originalstdout '+name,part in text)
source=read('/workspace/train337-L-reading-a-source/geometry-core/framing-template/oracle/selftest.py').decode()
ck('originalquickgriddefinitions',all(s in source for s in ['range(300, 4001)','range(300, 6001)','(-43, -42, -41, -40, -39, -1, 0, 1, 2)','else (331, 617)']))
band=(-43,-42,-41,-40,-39,-1,0,1,2);w={k*917+d for k in range(1,5)for d in band if 300<=k*917+d<=4000}|set(range(300,4001,331));hh={k*1832+d for k in range(1,4)for d in band if 300<=k*1832+d<=6000}|set(range(300,6001,617))
ck('sourcearithmetic9402and14208',len(range(300,4001))+len(range(300,6001))==9402 and len(w)*len(hh)*8==14208)
report={'schema':'reading-a-L-quick-and-outer-r2-actual-peer/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Terminal original quick + final outer source/index/22inputs and19 completed c387 commands only; does not redo original mutants46 review or execute any subject.','L':L,'originalQuickExit':0,'outerBothStages':[0,0],'reportedMainSweepBuildCount':39850,'separatelyReportedOddRuns':1872,'actualReportedQuickSweepSeconds':365,'knownExistingT4C11Count':6,'originalCommandResultsVerified':count,'checkCount':len(checks),'checks':checks,'findings':[r['label']for r in checks if not r['passed']],'limits':['39850 is the original main sweep footer count, not a claim to include separately counted1872 odd cases or preliminary controls.','9402/14208 rectangle counts are static arithmetic from the exact original quick loops plus its successful actual command/footer, not independently instrumented counters.','Original t4 six C11_MAIN_NOT_BUTTED cases remain known and allowed by the unchanged judge; this peer does not claim they are fixed or create a new skip.','Original r1 missing-module environment failures remain preserved separately.','Outer host session19147 exit0 is API-observed only; full original driver/stage/CLI/reaper c387 streams and final outer source guards are verified.']}
rp=O/'RAW_INDEX.json';rp.write_text(json.dumps(raw_index,ensure_ascii=False,indent=2)+'\n');report['rawIndexSHA256']=h(rp.read_bytes());report['exitCode']=int(bool(report['findings']));p=O/'REVIEW.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'findings':report['findings'],'exitCode':report['exitCode'],'rawIndexSHA256':h(rp.read_bytes())}));raise SystemExit(report['exitCode'])
