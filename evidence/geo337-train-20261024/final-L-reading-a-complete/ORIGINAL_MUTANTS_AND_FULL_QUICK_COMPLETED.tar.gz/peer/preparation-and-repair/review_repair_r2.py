from pathlib import Path
import hashlib,json,datetime
P=Path('/workspace/train337-L-reading-a-preparation');O=Path('/tmp/reading-a-L-launch-narrow-peer')
h=lambda b:hashlib.sha256(b).hexdigest()
b=json.loads((P/'SOURCE_BINDING.json').read_text());old=json.loads((P/'SOURCE_BINDING.r1.json').read_text());request=json.loads((P/'REQUEST.json').read_text())
rows=json.loads((P/'source-repair-r2/subcommands.json').read_text());checks=[]
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
ck('r2 binding pinned',h((P/'SOURCE_BINDING.json').read_bytes())=='3f4dad1616442624941da4835f609a4fb397e35276773e7ec7186d410aa04325')
ck('same source L',b['sourceSHA']==old['sourceSHA']==request['L']=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db')
ck('22sameLfiles1530356bytes',len(b['files'])==22 and sum(z['bytes']for z in b['files'])==b['runtimeBytes']==1530356)
new={z['path']:z for z in b['files']}
ck('all old11 binding rows unchanged',all(new[z['path']]==z for z in old['files']))
ck('20oracleplus2external',sum(z['path'].startswith('geometry-core/framing-template/oracle/')for z in b['files'])==20 and set(new)-{z for z in new if z.startswith('geometry-core/framing-template/oracle/')}=={'geometry-core/framing-template/PROPOSAL.md','決策佇列.md'})
for item in b['files']:
 rs=[r for r in rows if r['command']==['git','show',b['sourceSHA']+':'+item['path']]]
 ck('originalGitread '+item['path'],len(rs)==1 and rs[0]['actual_process_returncode']==0 and rs[0]['stdout_bytes']==item['bytes'] and rs[0]['stdout_sha256']==item['sha256'])
 r=rs[0];p=Path(r['directory'])/'stdout.bin'
 ck('Gitraw bytes '+item['path'],p.stat().st_size==item['bytes'] and h(p.read_bytes())==item['sha256'])
ck('original launcher unchanged',h((P/'launch_two_original_stages.py').read_bytes())=='ede05fc668a2aeb2103adf16869bce2f56d8091b6089621e9070ed6ee2f7d3a2')
ck('new output only and r1 preserved',request['argv'][-1]=='/workspace/train337-L-reading-a-results-7af8c5d8-r2' and (P/'REQUEST.r1.json').is_file() and (P/'R1_ENVIRONMENT_CLASSIFICATION.json').is_file())
ck('allrepaircommands0',all(r['actual_process_returncode']==0 for r in rows))
report={'schema':'reading-a-L-sparse-repair-r2-static-peer/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Same-L terminal r1 environment repair metadata,22 original captured Git reads and frozen unmodified launcher; no stage reexecution.','checkCount':len(checks),'checks':checks,'findings':[r['label']for r in checks if not r['passed']],'limits':['Original15-check launcher review did not establish completeness of original11-input closure.','r1 missing make_golden is preserved as environment failure; no product assertion failure inferred.','r2 stage results are not inferred by this preparation peer.']}
report['exitCode']=int(bool(report['findings']));p=O/'REPAIR_R2_REVIEW.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'checks':len(checks),'findings':report['findings'],'exitCode':report['exitCode']}));raise SystemExit(report['exitCode'])
