"""Only original mutants-only then quick on root-authorized independent clean L."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,resource,sys
P=Path(__file__).parent
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
REAPER=Path('/workspace/geo261-environment/reap_children.py')
DRIVER=Path('/workspace/geo318-reading-a-prep/formal-tools/run_stage.py')
PINS={C:'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',REAPER:'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760',DRIVER:'1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a'}
def h(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sha',required=True);ap.add_argument('--root',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);a=ap.parse_args()
 assert not sys.flags.optimize and a.sha=='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
 root=a.root.resolve();out=a.out.resolve();assert root==Path('/workspace/train337-L-reading-a-source')and not out.exists()and not out.is_relative_to(root)and not root.is_relative_to(out)
 assert all(h(p.read_bytes())==v for p,v in PINS.items())
 binding=json.loads((P/'SOURCE_BINDING.json').read_text());assert binding['sourceSHA']==a.sha and binding['root']==str(root)
 out.mkdir(parents=True)
 env=dict(os.environ)
 for k in ['FRAMING_QUOTE_QUEUE','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD']:env.pop(k,None)
 env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8',GITHUB_SHA=a.sha,GITHUB_WORKSPACE=str(root))
 spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
 rec=cap.Recorder(out,env,a.sha);result={'sha':a.sha,'root':str(root),'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launcherSHA256':h(Path(__file__).read_bytes()),'bindingSHA256':h((P/'SOURCE_BINDING.json').read_bytes()),'toolPins':{str(k):v for k,v in PINS.items()},'stageResults':[],'passed':False,'R3':'original unlocked semantic entries; root assigned slot2, independent source; no extra lock','outerTimeout':None}
 def save():
  (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(rec.rows,ensure_ascii=False,indent=2)+'\n')
 def run(argv,timeout=120):return rec.run(list(map(str,argv)),cwd=root,timeout=timeout,check=False,source_sha=a.sha,source_variant='independent-original-L')
 def guard(label):
  rows={}
  for key,argv in [('head',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1','--untracked-files=all']),('cached',['git','diff','--cached','--name-only']),('stage',['git','ls-files','--stage','-z'])]:
   row,stdout,stderr=run(argv);rows[key]={'row':row,'stdoutSHA256':h(stdout),'stdout':stdout.decode()if key!='stage'else None}
  rows['indexSHA256']=h((root/'.git/index').read_bytes())
  rows['inputs']=[{'path':it['path'],'bytes':len((root/it['path']).read_bytes()),'sha256':h((root/it['path']).read_bytes())}for it in binding['files']]
  rows['passed']=all(z['row']['actual_process_returncode']==0 for z in rows.values()if isinstance(z,dict)and'row'in z)and rows['head']['stdout'].strip()==a.sha and rows['status']['stdout']==rows['cached']['stdout']==''and rows['inputs']==binding['files']
  result[label]=rows;save();return rows
 try:
  before=guard('before');assert before['passed']
  soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard));result['stackBytes']=16777216
  for stage in ['oracle-mutants','oracle-quick']:
   env['GEO261_REAPER_LOG']=str(out/(stage+'-outer-reaper.jsonl'))
   argv=[sys.executable,'-B',REAPER,sys.executable,'-B',DRIVER,'--root',root,'--sha',a.sha,'--output',out/stage,'--stage',stage,'--scheduler-slot','2']
   print('READING_A_STAGE_START '+stage,flush=True)
   row,stdout,stderr=run(argv,timeout=None);result['stageResults'].append({'stage':stage,'commandResult':row});save()
   print('READING_A_STAGE_TERMINAL '+stage+' exit='+str(row['actual_process_returncode']),flush=True)
  after=guard('after');result['passed']=after['passed']and before['stage']['stdoutSHA256']==after['stage']['stdoutSHA256']and before['indexSHA256']==after['indexSHA256']and all(z['commandResult']['actual_process_returncode']==0 for z in result['stageResults'])
 finally:result['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 return 0 if result['passed']else 1
if __name__=='__main__':raise SystemExit(main())
