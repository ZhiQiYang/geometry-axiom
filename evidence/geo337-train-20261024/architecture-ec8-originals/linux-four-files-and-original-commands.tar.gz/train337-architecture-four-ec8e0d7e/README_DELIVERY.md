本輪只讀封存 ec8 原三架構裁判（0/0/0，generic205/product18），未重跑裁判或變動產品。受測S=ec8e0d7e18aefa9b6b6b0cd26206ba720ea735f0；封存真checkout E=a6072dde8eac809e93ccd9373946dea98fa5c362，S→E僅evidence。604原始與LF輸入逐項比對ec8 Git blobs且與P17相同；334owned/270excluded/798edges/0diagnostics，原928/55政策未改。

new/ 四檔供root採用，manifest與scan逐bytes未改，report/receipt重新綁定S與真封存E。架構inventory只有五個sourceRoots與current_geometry.c、tests/__init__.py、tests/binaries.py，不涵蓋所有tests。兩個變動tests明列不在closure；帳本--check原紅1不沖銷。P17 manifest反證0/1/0保原執行SHA並核原raw；本輪沒重跑也不重標。

原完整raw/streams：/tmp/train337-ec8e0d7e-impact-gates；本工具17個Git原stream在同目錄subcommands，outer原cmd/env/exit在 /tmp/train337-architecture-four-ec8e0d7e-outer。獨審781checks0：/tmp/train337-adversarial/ARCHITECTURE_EC8_FOUR_ACTUAL_PEER.json，SHA e684665e19e2ad8bb2195fc3f3b8651ac7d82d3b66352f5a895f3e6c7bed8f6d。
