from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,resource,sys
ROOT=Path('/tmp/train337-323-f64d638f-source');SHA='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
OUT=Path('/workspace/train337-L-readers-and-rc-7af8c5d8');OUT.mkdir();(OUT/'tmp').mkdir()
CAP=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py');REAPER=Path('/workspace/geo261-environment/reap_children.py');STAGE=Path('/workspace/geo318-reading-a-prep/formal-tools/run_stage.py');WORKER=Path('/tmp/train337-reading-a-sweep-plan/run_original_rc_method.py')
H=lambda b:hashlib.sha256(b).hexdigest()
pins={CAP:'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',REAPER:'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760',STAGE:'1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a',WORKER:'34baecbd743921179327ec0700c9a3915f0a7f498dcf0850c372343b8edf5d4d'}
assert all(H(p.read_bytes())==h for p,h in pins.items())
env=dict(os.environ)
for k in ('PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','FRAMING_QUOTE_QUEUE','LD_PRELOAD'):env.pop(k,None)
env.update(GITHUB_SHA=SHA,GITHUB_WORKSPACE=str(ROOT),TMPDIR=str(OUT/'tmp'),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8')
spec=importlib.util.spec_from_file_location('original_capture',CAP);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);rec=mod.Recorder(OUT,env,SHA)
save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
request={'schema':'geo337.original-L-readers-and-RC-launch/1','sourceSHA':SHA,'root':str(ROOT),'output':str(OUT),'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'rootGrant':'slot1 exclusiveROOT original reader3 then two RC precise proofs; root ledger completed/released; native/other ROOT mutators paused','toolPins':{str(p):h for p,h in pins.items()},'launcherSHA256':H(Path(__file__).read_bytes()),'environment':{k:env.get(k) for k in ('PATH','LANG','LC_ALL','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE','FRAMING_QUOTE_QUEUE','GITHUB_SHA','GITHUB_WORKSPACE','TMPDIR')},'diskBefore':{str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in (Path('/workspace'),Path('/tmp'))},'stageResults':[],'rcResults':[],'sourceModifiedByLauncher':False}
save(OUT/'REQUEST.json',request)
def run(args,label):return rec.run(list(map(str,args)),cwd=ROOT,timeout=None,check=False,source_sha=SHA,source_variant=label)
def guard(label):
 r={}
 for k,args in [('HEAD',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1','--untracked-files=all']),('cached',['git','diff','--cached','--name-only'])]:
  row,b,e=run(args,label);assert row['actual_process_returncode']==0;r[k]=b.decode()
 assert r['HEAD'].strip()==SHA and r['status']=='' and r['cached']=='';return r
result={'sourceSHA':SHA,'startedUTC':request['startedUTC'],'readers':[],'RC':[],'errors':[]}
try:
 result['sourceBefore']=guard('before-original-readers')
 for stage in ('reader-generate','reader-check','reader-unit'):
  row,b,e=run([sys.executable,'-B',STAGE,'--root',ROOT,'--sha',SHA,'--output',OUT/stage,'--stage',stage,'--scheduler-slot','1'],stage)
  result['readers'].append({'stage':stage,'outerExit':row['actual_process_returncode'],'receipt':str(OUT/stage/'receipt.json')});save(OUT/'RESULT.json',result)
 result['sourceAfterReaders']=guard('after-original-readers')
 lock=Path('/tmp/g261r3/heavy.lock').open('r+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);result['RCOriginalR3']={'path':str(Path(lock.name)),'mode':'EX|NB','acquired':True};save(OUT/'RESULT.json',result)
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
  template=json.loads(Path('/tmp/train337-reading-a-sweep-plan/RC_PROOF_REQUEST_TEMPLATE.json').read_text());original=(ROOT/'geometry-core/framing-template/oracle/framing_oracle.py').read_bytes()
  for control in template['requests']:
   name=control['control'];target=OUT/name;target.mkdir();old=control['old'].replace('\\n','\n').encode();new=control['new'].replace('\\n','\n').encode();assert original.count(old)==1;variant=target/'framing_oracle.py';variant.write_bytes(original.replace(old,new,1))
   rows=[]
   for phase in ('baseline','withdrawn','restored'):
    src=variant if phase=='withdrawn' else ROOT/'geometry-core/framing-template/oracle/framing_oracle.py';chosen=name if phase=='withdrawn' else 'baseline'
    env['GEO261_REAPER_LOG']=str(target/(phase+'-reaper.jsonl'))
    row,b,e=run([sys.executable,'-B',REAPER,sys.executable,'-B',WORKER,'--root',ROOT,'--sha',SHA,'--source',src,'--control',chosen],name+'-'+phase);rows.append({'phase':phase,'actualExit':row['actual_process_returncode'],'commandDirectory':row['directory']})
   result['RC'].append({'control':name,'phases':rows});save(OUT/'RESULT.json',result)
 finally:
  resource.setrlimit(resource.RLIMIT_STACK,(soft,hard));fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
 result['sourceAfter']=guard('after-original-RC')
except BaseException:
 import traceback;result['errors'].append(traceback.format_exc());raise
finally:
 result['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(OUT/'RESULT.json',result)
print(json.dumps(result,ensure_ascii=False))
