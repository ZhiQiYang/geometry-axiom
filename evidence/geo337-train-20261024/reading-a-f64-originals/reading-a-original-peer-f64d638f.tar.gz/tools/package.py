"""在 root 解除效能獨占後啟動；唯讀原件，完整 streams 小包，ELF 僅列 hash。"""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,stat,tarfile
F='f64d638f15c48d2b9723b7ae9d230fb5dacb82d9'
OUT=Path('/tmp/train337-reading-a-package-f64d638f')
ROOTS={
 'original/reader':Path('/tmp/train337-reader-original-f64d638f'),
 'original/native-r2':Path('/workspace/train337-reading-a-native-f64d638f-r2'),
 'original/oracle':Path('/workspace/train337-reading-a-oracle-f64d638f'),
 'original/native-preparation-failure':Path('/tmp/train337-reading-a-native-f64d638f'),
 'peer/r1':Path('/tmp/train337-reading-a-peer-f64d638f'),
 'peer/r2':Path('/tmp/train337-reading-a-peer-f64d638f-r2'),
 'peer/accepted-r3':Path('/tmp/train337-reading-a-peer-f64d638f-r3'),
}
EXTRA={
 'tools/original-c387-capture.py':Path('/workspace/geo288-main-merge-20261023/oracle-proof-tools/capture.py'),
 'tools/package.py':Path(__file__),
 'tools/after-the-fact-producer-reference.py':Path('/tmp/geo337-linux-generation-prep/nested_sha_binding_producer_reference.py'),
}
h=lambda b:hashlib.sha256(b).hexdigest()
assert not (OUT/'PACKAGE.json').exists()
OUT.mkdir(exist_ok=True)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
members={};excluded=[]
for prefix,base in ROOTS.items():
 assert base.is_dir() and not base.is_symlink()
 for path in sorted(base.rglob('*')):
  assert not path.is_symlink(),str(path)
  if path.is_dir():continue
  assert stat.S_ISREG(path.stat().st_mode),str(path)
  name=prefix+'/'+path.relative_to(base).as_posix()
  raw=path.read_bytes()
  entry=dict(path=name,original_path=str(path),bytes=len(raw),sha256=h(raw))
  if raw[:4]==b'\x7fELF':excluded.append(entry);continue
  assert name not in members;members[name]=(path,entry)
for name,path in EXTRA.items():
 assert path.is_file() and not path.is_symlink() and name not in members
 raw=path.read_bytes();members[name]=(path,dict(path=name,original_path=str(path),bytes=len(raw),sha256=h(raw)))
checks=json.loads((ROOTS['peer/accepted-r3']/'CHECKS.json').read_bytes())
assert checks['source_sha']==F and checks['exit_code']==0 and checks['check_count']==629 and not checks['findings']
original_command_count=0
for label in ('original/reader','original/native-r2','original/oracle'):
 base=ROOTS[label];commands=json.loads((base/'subcommands.json').read_bytes())
 original_command_count+=len(commands)
 for row in commands:
  directory=Path(row['directory']);assert directory.is_relative_to(base)
  assert row['actual_process_returncode']==0 and row['source_sha']==F and not row['timeout_expired']
  for stream in ('stdout','stderr'):
   p=directory/(stream+'.bin');raw=p.read_bytes();assert len(raw)==row[stream+'_bytes'] and h(raw)==row[stream+'_sha256']
   assert label+'/'+p.relative_to(base).as_posix() in members
  assert label+'/'+(directory/'stdin.bin').relative_to(base).as_posix() in members
assert original_command_count==17
native_rows=[json.loads(x) for x in (ROOTS['original/native-r2']/'native-execution.jsonl').read_bytes().splitlines()]
elf_hashes=dict(scope='Original logger hashes of 41 executed child ELF; absent originals are not freshly rehashed by packager.',
 original_native_sha_null=True,rows=[dict(ordinal=i+1,command=x['command'],executable_sha256=x['executable_sha256'],phase=x['phase'],control=x['control'],actual_exit=x['actual_exit'],physical_elf_exists_now=Path(x['command'][0]).exists()) for i,x in enumerate(native_rows)],
 existing_elf_excluded=excluded)
generated={
 'ELF_HASHES.json':(json.dumps(elf_hashes,ensure_ascii=False,indent=2)+'\n').encode(),
 'MEMBER_HASHES.json':(json.dumps(dict(schema='train337.reading-a-original-files/1',source_sha=F,members=[entry for _,entry in members.values()]),ensure_ascii=False,indent=2)+'\n').encode(),
 'SHA256SUMS':''.join(entry['sha256']+'  '+name+'\n' for name,(_,entry) in sorted(members.items())).encode(),
}
archive=OUT/'reading-a-original-peer-f64d638f.tar.gz'
with archive.open('xb') as rawfile,gzip.GzipFile(filename='',mode='wb',fileobj=rawfile,mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tf:
 for name,(path,entry) in sorted(members.items()):
  raw=path.read_bytes();assert len(raw)==entry['bytes'] and h(raw)==entry['sha256']
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
  tf.addfile(info,io.BytesIO(raw))
 for name,raw in sorted(generated.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
  tf.addfile(info,io.BytesIO(raw))
seen=set()
with tarfile.open(archive,'r:gz') as tf:
 for member in tf:
  assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts and member.name not in seen
  seen.add(member.name);raw=tf.extractfile(member).read()
  if member.name in members:
   path,entry=members[member.name];assert len(raw)==entry['bytes'] and h(raw)==entry['sha256'] and raw==path.read_bytes()
  else:assert raw==generated[member.name]
assert seen==set(members)|set(generated)
for path,entry in members.values():
 raw=path.read_bytes();assert len(raw)==entry['bytes'] and h(raw)==entry['sha256']
for name,raw in generated.items():(OUT/name).write_bytes(raw)
archive_raw=archive.read_bytes()
result=dict(schema='train337.reading-a-original-peer-package/1',source_sha=F,started_utc=started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 archive=str(archive),archive_bytes=len(archive_raw),archive_sha256=h(archive_raw),archive_members=len(seen),original_regular_files=len(members),original_commands=original_command_count,
 original_streams_complete=True,original_files_unchanged_before_after=True,roundtrip_all_member_bytes_verified=True,
 existing_elf_excluded=excluded,historical_native_elf_hash_rows=len(native_rows),
 root_bindings={k:str(v) for k,v in ROOTS.items()},peer_exit=0,peer_checks=629,peer_report_sha256=h((ROOTS['peer/accepted-r3']/'CHECKS.json').read_bytes()),
 limits=checks['limitations'],product_tests_builds_executed_by_packager=False)
(OUT/'PACKAGE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('archive','archive_bytes','archive_sha256','archive_members','original_regular_files','original_commands','historical_native_elf_hash_rows')},ensure_ascii=False))
