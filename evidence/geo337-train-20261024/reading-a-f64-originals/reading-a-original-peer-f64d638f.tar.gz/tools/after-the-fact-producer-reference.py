"""事後整理的原 producer 算法參考稿；不是 native 執行時存在的工具。

NESTED_SHA_BINDING.json 原件來自工具 exec `8cfb5b` 的 Python -c。
此檔只將同一算法排版給 peer 獨立重建；本檔未執行、沒有覆寫原件。
所有 native 子 row 原 source_sha=null，不能填回或稱原 child 有 F64 欄值。
"""
import hashlib
import json
from pathlib import Path

def reconstruct(directory):
    """只回傳相同 payload，caller 不應覆寫原檔。"""
    p=Path(directory)
    rows=[json.loads(x) for x in (p/'native-execution.jsonl').read_text().splitlines()]
    request=json.loads((p/'REQUEST.json').read_bytes())
    nested=[]
    for index,row in enumerate(rows):
        nested.append({
            'ordinal':index+1,
            'originalRowSourceSha':row['source_sha'],
            'rowCanonicalJsonSha256':hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'executableSha256':row['executable_sha256'],
            'phase':row['phase'],
            'control':row['control'],
        })
    return {
        'schema':'geo337.native-original-child-sha-provenance/1',
        'parentSourceSha':request['sha'],
        'originalChildSourceShaField':None,
        'originalChildRowsUnmodified':True,
        'reason':'GITHUB_SHA was absent in native child environment; source_sha null preserved',
        'parentRecorderResult':'subcommands/000003/result.json',
        'parentRequestSha256':hashlib.sha256((p/'REQUEST.json').read_bytes()).hexdigest(),
        'headBefore':'subcommands/000001/stdout.bin',
        'statusBefore':'subcommands/000002/stdout.bin',
        'headAfter':'subcommands/000004/stdout.bin',
        'statusAfter':'subcommands/000005/stdout.bin',
        'bothHeadOutputs':[(p/x).read_text().strip() for x in ('subcommands/000001/stdout.bin','subcommands/000004/stdout.bin')],
        'bothStatusOutputsEmpty':all((p/x).read_bytes()==b'' for x in ('subcommands/000002/stdout.bin','subcommands/000005/stdout.bin')),
        'nestedOriginalRows':nested,
        'nextFinalEnvironmentFix':'Set GITHUB_SHA and GITHUB_WORKSPACE explicitly; no current rerun or original-field rewrite claimed',
    }
