Reading A F64 原件獨立覆核完成，629 checks、exit 0、findings=[]。本次只讀原收據、AST 與 immutable Git blob，沒有重跑產品、測試或編譯。

固定來源為 `f64d638f15c48d2b9723b7ae9d230fb5dacb82d9`。

- 閱讀器原三命令 exit 0/0/0；51 方法真 OK，原輸入前後 hash 相同且等 Git F64。
- native 原 7 方法真 OK；41 次子執行包含 5 正例、11 個 W 控制及 1 個 H 控制，各控制真 0/1/0、精確具名 ASSERT、恢復原 binary hash。86 份 compile/link 紀錄及全部 70 個實際 argv 直接 C 輸入完整保留，逐份比對 F64、生成 harness 或唯一精確撤回來源。H 四檔原始 bytes、LF、語意變體、include relocation 各層 hash 獨立重建一致。
- oracle 原 14 方法真 OK；builder/checker 各自精確 source anchor 撤回，真 0/1/0，原具名 AssertionError 而非匯入、語法或執行失敗。

證據界線：native 41 個子 row 的 `source_sha` 與其環境 `GITHUB_SHA` 全為 null，原件沒有回填。父 c387 REQUEST/result 與原前後 HEAD 均 F64、status 空；保存的實際編譯 C 另已對 immutable F64／明列變體逐份比對，NESTED_SHA_BINDING 的 41 個 canonical row hash 與 executable hash 映射亦由 peer 獨立重建。這支持父紀錄與來源輸入的間接綁定，不能稱子紀錄原本有 SHA。下輪正式執行須顯式設定 GITHUB_SHA/GITHUB_WORKSPACE。

三組原件直接由 c387 錄下 formal subprocess，未有額外 outer launch 或 reaper 事件；本報告不虛構此層保證。native 內部 compiler/harness 為原 text capture，上層 Python 輸出是完整 raw c387 bytes。H 是明列的 LF／include relocation 衍生來源，不能稱 raw-byte F64 編譯。原執行器 hash 過 ELF 後已由原 NativeBuild cleanup，peer 沒有重新 hash 已不存在的 ELF。oracle 的暫時 mutant source 亦由原測試清除，收據保留精確原 source／anchor 與真實子輸出，不冒稱保留 mutant raw file。

不外推 CLI 建構可達性、全場掃描、golden、架構三條、帳本或 noWood 13 方法。當前受驗 checkout 已授權前進，這裡依原時點 HEAD/status 與固定 Git F64 核身份。

原 native 首次準備失敗（retainer hash pin 不符、未啟動測試）另保 `/tmp/train337-reading-a-native-f64d638f/PREPARATION_FAILURE.json`，不冒稱產品紅或測試通過。peer 自身 r1 把 request 的初始 returncode=null 誤作終態 row 比較，r2 有 Python 名稱遮蔽；兩次 exit 1 原 CHECKS 與 Git 讀取輸出保留。修正的是 peer 程式，沒有改產品、原收據或原裁判，r3 完整覆核通過。
