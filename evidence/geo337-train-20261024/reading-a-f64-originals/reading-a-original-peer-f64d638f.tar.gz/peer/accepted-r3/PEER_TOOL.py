"""獨立唯讀核原件；不匯入/執行 subject，僅 Git 原件讀取及 AST/hash。"""
from pathlib import Path
import ast, datetime, hashlib, importlib.util, json, os, re, traceback
F='f64d638f15c48d2b9723b7ae9d230fb5dacb82d9'
ROOT=Path('/workspace/geometry-axiom')
ORIGINAL_ROOT=Path('/tmp/train337-323-f64d638f-source')
BASES={'reader':Path('/tmp/train337-reader-original-f64d638f'),
       'native':Path('/workspace/train337-reading-a-native-f64d638f-r2'),
       'oracle':Path('/workspace/train337-reading-a-oracle-f64d638f')}
OUT=Path('/tmp/train337-reading-a-peer-f64d638f-r3')
CAP=Path('/workspace/geo288-main-merge-20261023/oracle-proof-tools/capture.py')
h=lambda b:hashlib.sha256(b).hexdigest()
assert h(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('reading_a_peer_capture',CAP)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
r=cap.Recorder(OUT,dict(os.environ,LANG='C.UTF-8',LC_ALL='C.UTF-8',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),F)
report={'schema':'independent-train337-reading-a-original-peer/1','source_sha':F,
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'checks':[],'findings':[],'commands':r.rows,'subject_tests_builds_imports_executed':False,
 'scope':'Reader three, native seven/12 controls, oracle14/builder-checker controls. No CLI/full sweep/ledger claim.',
 'limitations':['Native 41 original child source_sha and GITHUB_SHA are null; not rewritten. Indirect parent/source-input binding only.',
 'No independent outer launch or reaper events existed for these three direct c387 invocations; none fabricated.',
 'Native compiler/harness inner outputs use original text capture, top Python outputs are original raw c387 bytes.',
 'H four-source LF/include-relocated variants are explicitly derived source, not F64 raw-byte compilation.',
 'Native executables were hashed by original execution logger and cleaned by original NativeBuild; peer does not claim rehashing absent ELF.',
 'Oracle temporary mutant sources were cleaned by original test; proof is immutable source/precise anchor plus actual original text output.',
 'Current checkout HEAD may have advanced; original fixed F64 head/status observations and immutable Git blobs are authoritative here.']}
def check(name,ok):
 report['checks'].append({'name':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
cache={}
def git(*args):
 row,raw,_=r.run(['git','-C',str(ROOT),'-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=OUT,timeout=120,source_variant='independent-immutable-F64-read-only')
 check('Git read exit0 '+str(args[:2]),row['actual_process_returncode']==0)
 return raw
def source(path):
 if path not in cache:cache[path]=git('show',F+':'+path)
 return cache[path]
def methods(raw):
 return [n.name for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
def original_stage(label,count):
 base=BASES[label];req=json.loads((base/'REQUEST.json').read_bytes());summary=json.loads((base/'SUMMARY.json').read_bytes())
 check(label+' request and summary fixed F64',req['sha']==summary['sha']==F and req['repo']==str(ORIGINAL_ROOT))
 check(label+' recorder exact reviewed hash',req['captureSha256']==h(CAP.read_bytes()))
 rows=json.loads((base/'subcommands.json').read_bytes());check(label+' exact command count',len(rows)==count)
 for i,row in enumerate(rows,1):
  directory=base/'subcommands'/f'{i:06}'
  check(label+' result matches original index '+str(i),Path(row['directory'])==directory and json.loads((directory/'result.json').read_bytes())==row)
  request=json.loads((directory/'request.json').read_bytes())
  check(label+' actual argv/env/source request '+str(i),all(row[k]==v for k,v in request.items() if k!='actual_process_returncode') and row['source_sha']==F and row['acceptance_sha']==F and request['actual_process_returncode'] is None)
  check(label+' actual terminal0 without timeout '+str(i),row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'])
  for stream in ('stdout','stderr'):
   raw=(directory/(stream+'.bin')).read_bytes()
   check(label+' complete '+stream+' raw '+str(i),len(raw)==row[stream+'_bytes'] and h(raw)==row[stream+'_sha256'])
  check(label+' original stdin hash '+str(i),h((directory/'stdin.bin').read_bytes())==row['stdin_sha256'])
 check(label+' original HEAD before and after',all((Path(x['directory'])/'stdout.bin').read_text().strip()==F for x in (rows[0],rows[-2])) and all(x['command'][-2:]==['rev-parse','HEAD'] for x in (rows[0],rows[-2])))
 check(label+' original clean before and after',all((Path(x['directory'])/'stdout.bin').read_bytes()==b'' for x in (rows[1],rows[-1])) and all(x['command'][-3:]==['status','--porcelain=v1','--untracked-files=all'] for x in (rows[1],rows[-1])))
 return req,summary,rows
def unittest_result(label,row,n,path):
 err=(Path(row['directory'])/'stderr.bin').read_bytes();observed=re.findall(rb'^(test_[a-zA-Z0-9_]+) \(',err,re.M)
 check(label+' true Ran'+str(n)+' OK/no skips',re.findall(rb'^Ran (\d+) tests in ',err,re.M)==[str(n).encode()] and re.search(rb'^OK\s*$',err,re.M) is not None and b'skipped=' not in err and b'... skipped' not in err)
 names=methods(source(path))
 check(label+' all immutable AST methods observed once',len(names)==len(observed)==n and sorted(names)==sorted(x.decode() for x in observed))
 return err
code=1
try:
 all_paths=set(git('ls-tree','-r','--name-only','-z',F).decode().split('\0'))-{''}
 req,summary,rr=original_stage('reader',7)
 expected=[['-B','geometry-guide/sync_axiom_reader.py'],['-B','geometry-guide/sync_axiom_reader.py','--check'],['-B','tests/test_axiom_reader.py']]
 for row,args,gate in zip(rr[2:5],expected,summary['gates']):
  check('reader exact original gate argv',row['command'][1:]==args and gate['argv']==row['command'] and gate['exit']==0 and gate['directory']==row['directory'])
 for path,digest in req['beforeSha256'].items():
  check('reader Git F64 before/after source hash '+path,h(source(path))==digest==summary['beforeSha256'][path]==summary['afterSha256'][path])
 check('reader preserved source input hashes',summary['inputBytesUnchanged'] is True and summary['beforeSha256']==summary['afterSha256'])
 for row in rr[2:4]:
  obj=json.loads((Path(row['directory'])/'stdout.bin').read_bytes())
  check('reader original generator/check assertions',all(obj[k]=='pass' for k in ('five_asserts','independent_ssot','source_sections','counts_single_source','geo120','search','color_tokens')) and obj['witness']==31)
 unittest_result('reader',rr[4],51,'tests/test_axiom_reader.py')

 nreq,ns,nr=original_stage('native',5);base=BASES['native']
 check('native exact original retainer hash',h((base/'tools/native_with_compile_log_retention.py').read_bytes())==nreq['retainerSha256']=='5dfe683e297514e0888db7b525053997b41142e6bb3509805fabee659f4fbc10')
 check('native exact unchanged stage argv',ns['argv']==nr[2]['command'] and ns['exit']==0 and ns['directory']==nr[2]['directory'] and nr[2]['command'][1:]==['-B',str(base/'tools/native_with_compile_log_retention.py'),'--root',str(ORIGINAL_ROOT),'--artifacts',str(base/'compile-logs')])
 unittest_result('native',nr[2],7,'tests/test_geo318_reading_a_native.py')
 tree=ast.parse(source('tests/test_geo318_reading_a_native.py'))
 controls=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
 check('native eleven original W controls',len(controls)==11)
 expected_controls={c[0]:dict(module=c[1],before=c[2],after=c[3],case=c[4],assertion=c[5]) for c in controls}
 expected_controls['host-collector']=dict(case='host-collector',assertion='actual-host-collector-accepts-partial')
 rows=[json.loads(x) for x in (base/'native-execution.jsonl').read_bytes().splitlines()]
 check('native exact41 original child rows',len(rows)==41)
 side=json.loads((base/'NESTED_SHA_BINDING.json').read_bytes())
 check('native provenance parent original request hash',side['parentRequestSha256']==h((base/'REQUEST.json').read_bytes()) and side['parentSourceSha']==F and side['parentRecorderResult']=='subcommands/000003/result.json')
 check('native provenance empty fields remain empty',side['originalChildSourceShaField'] is None and side['originalChildRowsUnmodified'] is True and all(x['source_sha'] is None and x['environment']['GITHUB_SHA'] is None for x in rows))
 check('native provenance original before/after parents',side['bothHeadOutputs']==[F,F] and side['bothStatusOutputsEmpty'] and side['headBefore']=='subcommands/000001/stdout.bin' and side['headAfter']=='subcommands/000004/stdout.bin' and side['statusBefore']=='subcommands/000002/stdout.bin' and side['statusAfter']=='subcommands/000005/stdout.bin')
 reconstructed=[]
 for i,row in enumerate(rows,1):
  reconstructed.append(dict(ordinal=i,originalRowSourceSha=row['source_sha'],rowCanonicalJsonSha256=h(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),executableSha256=row['executable_sha256'],phase=row['phase'],control=row['control']))
  check('native actual original child normal class/env '+str(i),row['actual_exit'] in (0,1) and row['environment']['PYTHONOPTIMIZE'] is None and row['capture_mode'].startswith('original subprocess text') and row['cwd']==str(ORIGINAL_ROOT))
  check('native true argv/executable hash '+str(i),len(row['command'])==2 and row['command'][1]==row['case'] and re.fullmatch('[0-9a-f]{64}',row['executable_sha256']) is not None)
 check('native independent all41 canonical row hash mapping',side['nestedOriginalRows']==reconstructed)
 positives=[x for x in rows if x['phase']=='positive']
 check('native all5 positive witnesses true0',len(positives)==5 and all(x['actual_exit']==0 and x['control'] is None and x['stderr']=='' for x in positives))
 for name,c in expected_controls.items():
  three=[x for x in rows if x['control']==name]
  check(name+' original three phases/true0-1-0',[x['phase'] for x in three]==['baseline','mutant','restored'] and [x['actual_exit'] for x in three]==[0,1,0] and all(x['case']==c['case'] for x in three))
  check(name+' named normal assertion not crash','ASSERT:'+c['assertion'] in three[1]['stderr'] and three[1]['expected_assertion']==c['assertion'] and 'Traceback' not in three[1]['stderr'])
  check(name+' exact original binary restoration',three[0]['executable_sha256']==three[2]['executable_sha256'] and three[0]['executable_sha256']!=three[1]['executable_sha256'])
 retention=json.loads((base/'compile-logs/retention.json').read_bytes());check('native one retained original log',len(retention)==1)
 item=retention[0];raw=Path(item['retained']).read_bytes();build=json.loads(raw)
 check('native retained complete original build log',len(raw)==item['bytes']==263434 and h(raw)==item['sha256']=='748ad90dcb258f7c6a8d493aad03e4aa18c5ba221627326be1d22cfb1b622954' and len(build)==86)
 retained={x['original']:x for x in item['compiled_sources']};prefix=Path(item['original']).parent
 actual_inputs={arg for b in build for arg in b['arguments'] if Path(arg).is_absolute() and Path(arg).suffix=='.c' and Path(arg).is_relative_to(prefix)}
 check('native all70 actual direct compiler C inputs retained',len(retained)==70 and set(retained)==actual_inputs)
 for i,b in enumerate(build):
  check('native complete successful original compile/link '+str(i),b['exit']==0 and b['command']==b['arguments'] and isinstance(b['stdout'],str) and isinstance(b['stderr'],str) and '\ufffd' not in b['stdout']+b['stderr'])
 for path,meta in retained.items():
  raw=Path(meta['retained']).read_bytes();rel=Path(path).relative_to(prefix).as_posix()
  check('native retained exact compiled source '+rel,len(raw)==meta['bytes'] and h(raw)==meta['sha256'])
  expected=None
  if rel.startswith('isolated-kernel/'):expected=source('geometry-core/kernel/'+rel.removeprefix('isolated-kernel/'))
  elif rel.startswith('isolated-host/'):expected=source('geometry-app/native/'+rel.removeprefix('isolated-host/'))
  elif rel=='exact-client.c':expected=source('tests/geo261_exact_harness.c')
  elif rel=='codec-client.c':
   codec_tree=ast.parse(source('tests/test_engineering_json.py'))
   s=next(ast.literal_eval(n.value) for n in codec_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='HARNESS' for t in n.targets))
   expected=re.sub(r'\beng_(json_|sha256|base64_)',r'geo_\1',s.replace('#include "engineering_json.inc"','#include "codec.h"').replace('EngJson','GeoJson')).encode()
  elif rel=='isolated-woodworking/native/geo318-boundary-ends-client.c':expected=source('tests/geo318_boundary_ends_harness.c')
  elif rel.startswith('isolated-woodworking/native/geo318-'):
   name=Path(rel).stem.removeprefix('geo318-');c=expected_controls[name]
   original=source('geometry-templates/woodworking/native/'+c['module']+'.c').decode().replace('\r\n','\n')
   check(name+' immutable original withdrawal anchor once',original.count(c['before'])==1)
   expected=original.replace(c['before'],c['after'],1).encode()
  elif rel.startswith('isolated-woodworking/'):expected=source('geometry-templates/woodworking/'+rel.removeprefix('isolated-woodworking/'))
  elif rel.startswith(('geo318-host-baseline/','geo318-host-withdrawn/')):
   label='host-withdrawn' if rel.startswith('geo318-host-withdrawn/') else 'host-baseline'
   expected=(base/'artifacts'/label/'relocated/tests/geo318_host_boundary_ends_harness.c').read_bytes()
  check('native actual compiler input independently maps to F64/precise derived change '+rel,expected is not None and raw==expected)
 output_paths={b['arguments'][b['arguments'].index('-o')+1] for b in build if '-o' in b['arguments'] and '-c' not in b['arguments']}
 check('all41 actual harness executables have original successful link command',all(x['command'][0] in output_paths for x in rows))
 manifests={}
 for label in ('host-baseline','host-withdrawn'):
  directory=base/'artifacts'/label;manifest=json.loads((directory/'source-manifest.json').read_bytes());manifests[label]=manifest
  check(label+' explicit derived variant identity',manifest['source_git_sha']==F and manifest['scope']=='Derived H source variant, not a byte-identical F build' and len(manifest['files'])==4)
  destinations={(ORIGINAL_ROOT/x['path']).resolve():x['relocated_path'] for x in manifest['files']}
  for row in manifest['files']:
   name=row['path'];raw=source(name);lf=raw.decode().replace('\r\n','\n');derived=(directory/'relocated'/name).read_bytes()
   check(label+' raw original exact GitF64 '+name,(directory/'original'/name).read_bytes()==raw and h(raw)==row['source_raw_sha256'] and h(lf.encode())==row['source_lf_sha256'] and raw.count(b'\r\n')==row['original_crlf'])
   semantic=lf
   if label=='host-withdrawn' and name=='geometry-core/references.inc':
    before='if(!wood_contact_end_support_check(admission,hits,a->has_between,detail,sizeof detail))';after='if(!hits || (!a->has_between && hits!=1))'
    check('H immutable delegate anchor once',semantic.count(before)==1);semantic=semantic.replace(before,after,1)
   check(label+' exact semantic change count '+name,h(semantic.encode())==row['semantic_variant_sha256'] and row['semantic_guard_changes']==int(label=='host-withdrawn' and name=='geometry-core/references.inc'))
   origin=(ORIGINAL_ROOT/name).resolve()
   def relocate(match):
    include=(origin.parent/match.group(1)).resolve()
    if include in destinations:return '#include "'+destinations[include]+'"'
    try:rel=include.relative_to(ORIGINAL_ROOT).as_posix()
    except ValueError:rel=None
    return '#include "'+include.as_posix()+'"' if rel in all_paths else match.group(0)
   check(label+' independently reconstructed include/LF bytes '+name,derived==re.sub(r'^#include "([^"\n]+)"',relocate,semantic,flags=re.M).encode() and h(derived)==row['relocated_raw_sha256'])
   variantroot=str(Path(row['relocated_path']).parents[len(Path(name).parts)-1])
   check(label+' normalized relocated directory hash '+name,h(derived.decode().replace(variantroot,'@VARIANT_ROOT@').encode())==row['relocated_directory_normalized_sha256'])
 before={x['path']:x for x in manifests['host-baseline']['files']};after={x['path']:x for x in manifests['host-withdrawn']['files']}
 check('H only delegate source semantic and normalized differs',all({p for p in before if before[p][key]!=after[p][key]}=={'geometry-core/references.inc'} for key in ('semantic_variant_sha256','relocated_directory_normalized_sha256')))

 oreq,osummary,orr=original_stage('oracle',5)
 check('oracle exact original14 unchanged argv',osummary['argv']==orr[2]['command'] and osummary['exit']==0 and osummary['directory']==orr[2]['directory'] and orr[2]['command'][1:]==['-B','tests/test_geo318_reading_a_oracle.py','-v'])
 unittest_result('oracle',orr[2],14,'tests/test_geo318_reading_a_oracle.py')
 framing=source('geometry-core/framing-template/oracle/framing_oracle.py');client=source('geometry-core/framing-template/oracle/reading_a_source_control.py');test=source('tests/test_geo318_reading_a_oracle.py')
 check('oracle source-client normal precise assertion',b'assert check(region, own, [own, other], 0, 500) == module.READING_A_PARTIAL' in client and b"'READING_A_' + control.upper() + '_PARTIAL'" in client)
 text=(Path(orr[2]['directory'])/'stdout.bin').read_text();proofs=[json.loads(x.removeprefix('READING_A_SOURCE_PROOF ')) for x in text.splitlines() if x.startswith('READING_A_SOURCE_PROOF ')]
 check('oracle actual builder/checker proofs distinct',len(proofs)==2 and [p['control'] for p in proofs]==['builder','checker'])
 for p in proofs:
  label=p['control'];phases=p['phases'];marker='READING_A_'+label.upper()+'_PARTIAL'
  check(label+' original source fingerprint matches immutableF64',p['source_sha256']==h(framing))
  check(label+' true0-1-0 phases',[x['phase'] for x in phases]==['baseline','withdrawn','restored'] and [x['exit_code'] for x in phases]==[0,1,0])
  check(label+' normal assertion exact kill',phases[1]['stderr'].rstrip().endswith('AssertionError: '+marker) and not phases[1]['stdout'] and not any(x in phases[1]['stderr'] for x in ('ImportError','SyntaxError','FileNotFoundError','TimeoutExpired')))
  check(label+' original/restored exact command and success',phases[0]['command']==phases[2]['command'] and phases[0]['stdout']==phases[2]['stdout']==marker+': PASS\n' and phases[0]['stderr']==phases[2]['stderr']=='')
  for phase in phases:
   check(label+' actual original control-client argv '+phase['phase'],phase['command'][:4]==[orr[2]['command'][0],'-B',str(ORIGINAL_ROOT/'geometry-core/framing-template/oracle/reading_a_source_control.py'),'--source'] and phase['command'][-2:]==['--control',label])
  check(label+' immutable vs isolated temporary source paths',phases[0]['command'][4]==str(ORIGINAL_ROOT/'geometry-core/framing-template/oracle/framing_oracle.py') and Path(phases[1]['command'][4]).is_relative_to(Path(oreq['temporaryDirectory'])))
  fn='_reading_a_build_end' if label=='builder' else 'reading_a_end_admission'
  check(label+' one immutable source withdrawal anchor',framing.decode().count('def '+fn+'(reg, timber, timbers, k, at):\n')==1)
 check('oracle test original precise withdrawal and restoration guard',all(x in test for x in (b'return READING_A_ORDINARY',b'text.replace(anchor, anchor +',b'self.assertEqual(digest, hashlib.sha256(source.read_bytes()).hexdigest())')))
 failure=Path('/tmp/train337-reading-a-native-f64d638f/PREPARATION_FAILURE.json')
 report.update(reader_methods=51,reader_original_exits=[0,0,0],native_methods=7,native_child_executions=41,native_controls=12,native_control_exits=[0,1,0],native_compile_link_commands=86,native_compiled_c_sources=70,oracle_methods=14,oracle_control_exits=[0,1,0],native_nested_SHA_binding='INDIRECT_PARENT_AND_ACTUAL_COMPILED_INPUTS; ORIGINAL_CHILD_SHA_NULL',native_first_preparation_failure_sha256=h(failure.read_bytes()),source_files_read={n:h(v) for n,v in cache.items()},accepted_with_disclosed_limits=True)
 code=0
except Exception:report['findings'].append(traceback.format_exc())
finally:
 report.update(exit_code=code,check_count=len(report['checks']),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (OUT/'CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report.get(k) for k in ('exit_code','check_count','native_controls','findings')},ensure_ascii=False))
raise SystemExit(code)
