"""Run the unmodified native suite; observe its existing build log before cleanup.

The audit hook does not patch any product/test/NativeBuild function or return
value. It only copies an existing diagnostic JSON before shutil.rmtree removes
the suite's temporary directory. Raw H variants are retained by the suite's
original GEO318_ARTIFACT_DIR mechanism.
"""
from pathlib import Path
import argparse,hashlib,json,os,runpy,sys

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--artifacts',type=Path,required=True);a=p.parse_args()
 root=a.root.resolve();out=a.artifacts.resolve();out.mkdir(parents=True,exist_ok=True)
 tmp=Path(os.environ['TMPDIR']).resolve();records=[]
 def audit(event,args):
  if event!='shutil.rmtree' or not args:return
  path=Path(os.fsdecode(args[0]))
  if not path.is_absolute():return
  path=path.resolve()
  if not path.is_relative_to(tmp) or not path.name.startswith('geo261-n1a-'):return
  log=path/'build-log.json'
  if not log.is_file():return
  raw=log.read_bytes();target=out/(path.name+'-build-log.json');target.write_bytes(raw)
  sources=[];seen=set()
  for row in json.loads(raw):
   for value in row['arguments']:
    original=Path(value)
    if not original.is_absolute() or original.suffix!='.c' or not original.is_file() or not original.is_relative_to(path) or str(original) in seen:continue
    seen.add(str(original));body=original.read_bytes();dest=out/path.name/'compiled-source'/original.relative_to(path)
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
    sources.append({'original':str(original),'retained':str(dest),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
  records.append({'original':str(log),'retained':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compiled_sources':sources,'before_event':'shutil.rmtree','scope':'original NativeBuild command/text stdout/stderr and actual compiled C diagnostics, no build method interception'})
  (out/'retention.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
  print('GEO318_RETAINED_COMPILE_LOG '+json.dumps(records[-1],ensure_ascii=False),flush=True)
 sys.addaudithook(audit)
 target=root/'tests/test_geo318_reading_a_native.py'
 sys.argv=[str(target),'-v']
 runpy.run_path(str(target),run_name='__main__')
if __name__=='__main__':main()
