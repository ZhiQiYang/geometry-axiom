# 新工作掛載配置：固定 F 的有界 codegen 診斷

只準備，尚未啟動 compiler。固定來源 `cbf0fb621888596aa14ad5f2349b503e23b1b72d`、原 driver 收據 `f087dfcd582114bc8ae26afc5ffe2ea9996a2d448069c0b3e89406a9083d9905`；不重跑已完成 driver。

主代理收到獨立 static 0 並重新確認無 writer／heavy 後，經原 c387 Recorder＋7d848d reaper 啟動：

```text
python3 -B /tmp/geo-resume1758-axiom-codegen-v3-20261026/PROFILE.py --execute --scheduler-slot 1 --output /workspace/geo-axiom-codegen-F-cbf0fb62-v3-20261026
```

`--output` 必須是新的 `/workspace/geo-axiom-codegen-*` 直接子目錄，父層由主代理獨占指派。本診斷的 raw、compiler scratch、PROFILE.tar 與衍生索引都只在該新目錄。F source 繼續讀原 SHM checkout；Git/publisher OUT 仍在原 OWN，不變更任何掛載、配額、安全設定，沒有搬動或刪除原件。原 `/tmp/geometry-tests`、現行 F9 ELF 與拒絕清理根不碰。

## 原工具的實際規則

原 `publish_append.py` pin `988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720`：lines 26–31 只遍歷兩個指定 OWN 根，按原 2 GiB 計畫守門；lines 58–62 要求 source_path 是固定 regular/non-symlink 檔且 bytes/hash 相符，沒有要求來源掛載等同 OWN。source_path 放既有 workspace 是本次明示的新診斷配置，不是改原 native／browser／axiom 的資源守門。

正式原 publisher 公式完整不變：

`3*payload_bytes + leaf_count*65536 + 8*manifest_raw_bytes + 67108864`

本批只發布 **PROFILE.tar 一葉**，內含真正 source/env/command/exit、完整已捕捉 stdout/stderr/trace 的 lossless gzip、執行器與閉包原件。DELIVERY.json、PUBLISH_MANIFEST.json 只是 archive hash／bytes／來源的衍生索引，不包含獨有正式事件；它們留 outer 收據，後續小批回收。不能省略任何正式流或唯一事件來縮 payload。

## 明確分開兩個掛載的成本

OWN 只預留原 publisher 追加成本及 outer 64 KiB；不再用舊 5L 把 workspace raw/archive 算入 OWN。workspace 另檢查原 raw + archive 的實體峰值，全部保留。

原 raw 內的 source/helper/closure/driver receipt/算術證明合成一份實際 gzip inputs.tar.gz，保留每份原 bytes/hash 並 roundtrip；不假設壓縮比。stdout assembly 仍只收於 RAM 的原 16 MiB 診斷 cap，同時完整 gzip，不先寫 raw 再刪。

外層使用固定 USTAR，檔案名稱須 ASCII 且不超過 100 bytes，最多 16 成員。固定 header 每檔 512 bytes、檔案填充最多 511 bytes、結尾 1024 bytes，加 10240 record 的最多 10239 bytes 填充：

`archive_bytes - sum(member_bytes) <= 16*1023 + 11263 = 27631`

預留 27648 bytes，實際生成時再核對；不使用舊 128 KiB 猜測 padding。各正式流已 gzip，所以外層 tar 不再多壓縮一次，大小可精算。若成員數／名稱／實際 tar 超界，明列診斷封包失敗，保留 raw，不默認可交付。

參考觀測兩 OWN `2,078,113,792 B`、headroom `69,369,856 B`：此固定路徑的一葉 manifest 上界 **339 B**（bytes 先保留最大 10 位、hash 64 位），原公式＋outer 64 KiB 得：

- publisher payload 上限 **709,069 B**；
- raw 包 L 上限 **681,421 B**；
- workspace raw＋archive＋頁配置與衍生索引餘量 **1,459,661 B**，低於觀測可用 **4,378,624 B**。

這些僅為參考觀測；實際啟動前按 fresh OWN used、實際輸出路徑 manifest 長度、兩掛載 available 重新計算。終態又按真 archive bytes、真 manifest raw bytes、真 allocated 核原公式，沒有降低 64 MiB 或 2 GiB。

512 KiB 原本只是 v2 **新診斷工具**的保守最小包估計，不是產品門檻；本版未降低它，而且此配置已滿足。真正開 compiler 前仍須 `實際 prefix allocated + 本次三條 pipe 容量 + 讀取塊／終態預留 +64 KiB < L`，故不靠刪掉 512 KiB 檢查過關。達到儲存 cap 可以使診斷非 0，並完整 drain／保存已發出的 bytes；不承諾 compiler 完整必過，不將環境容量失敗當產品紅燈。

## 不變的執行與收件規則

只執行 `cc -std=c11 -O2 -S <原 model_base.c> -lm -o -`，以 bounded strace 觀測本次子程序。不執行 as/link/ELF 或原 axiom；collect2 的 plugin/lto-wrapper/.res 已在原 driver 中確認，屬尚未執行的後續階段，未從總任務省略。原正式 60／180 秒未改。

固定 compiler／tool pins、source/index/262 葉與原 R3 獨占守門不變。逐 stream 記 EOF，未全 EOF 明列 unknown；gzip roundtrip 不能取代輸出完整性。晚期封包失敗保留候選，以 FAILED_DELIVERY.json 釘 stale hashes、do_not_publish，不把舊 archive 中的 exit 0 當終態。root 收件需 outer 0、current receipt 0、無 FAILED_DELIVERY 且全部 bytes/hash 一致。

BOUND_PROOF.py 只跑純算術與 USTAR，沒有 compiler／driver／產品測試。BOUND_RESULT.json 的 45 組 tar 邊界、8 項容量／反證均 exit 0，包含移除 64 MiB、忽略 payload 三倍、忽略 workspace archive、漏 tar headers 的反例；peer 應核實後才准 root 啟動。
