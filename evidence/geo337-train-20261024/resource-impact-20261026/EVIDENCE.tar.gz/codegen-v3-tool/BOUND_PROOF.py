"""Pure arithmetic/USTAR proof; no compiler, driver, product tests, Git or network."""
from pathlib import Path
import ast
import hashlib
import io
import json
import os
import fcntl
import tarfile

PUBLISHER = Path('/tmp/geo337-recovery-evidence-append-preparation-20261026/publish_append.py')
PIN = '988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720'
CAP = 2 * 1024**3
B = 2078113792  # root-supplied reference observation; execution always samples afresh
OUTER = 65536
PAD = 27648
WS_MARGIN = 65536
BASE = Path('/workspace/geo-axiom-codegen-F-cbf0fb62-v3-20261026')
DEST = 'evidence/geo337-train-20261024/' + BASE.name + '/PROFILE.tar'


def manifest(size):
    return (json.dumps({'files': [{'source_path': str(BASE / 'PROFILE.tar'),
                                  'destination': DEST, 'bytes': size, 'sha256': 'f' * 64}]},
                       indent=2) + '\n').encode()


def original_budget(payload, raw):
    source = PUBLISHER.read_bytes()
    assert hashlib.sha256(source).hexdigest() == PIN
    main = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    expr = next(n.value for n in main.body if isinstance(n, ast.Assign) and
                any(isinstance(t, ast.Name) and t.id == 'budget' for t in n.targets))
    allowed = (ast.Expression, ast.BinOp, ast.Add, ast.Mult, ast.Name, ast.Load, ast.Constant, ast.Call)
    assert all(isinstance(n, allowed) for n in ast.walk(ast.Expression(expr)))
    assert all(isinstance(n.func, ast.Name) and n.func.id == 'len'
               for n in ast.walk(expr) if isinstance(n, ast.Call))
    return eval(compile(ast.Expression(expr), '<pinned publisher arithmetic>', 'eval'),
                {'__builtins__': {'len': len}}, {'total': payload, 'files': [None], 'raw': raw})


def tar_bytes(sizes):
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for i, size in enumerate(sizes):
            info = tarfile.TarInfo('entry-' + str(i))
            info.size = size
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(b'x' * size))
    return out.getvalue()


def main():
    raw = manifest(CAP)
    fixed = original_budget(0, raw)
    pmax = (CAP - B - fixed - OUTER) // 3
    live = pmax - PAD
    workspace = live + ((pmax + 4095) // 4096) * 4096 + WS_MARGIN
    checks = []
    checks.append(('reference payload upper bound fits original formula', B + original_budget(pmax, raw) + OUTER <= CAP))
    checks.append(('one additional payload byte is rejected', B + original_budget(pmax + 1, raw) + OUTER > CAP))
    checks.append(('workspace raw plus archive independently fits observed space', workspace <= 4378624))
    checks.append(('retained conservative diagnostic 512KiB floor is met', live >= 512 * 1024))
    # Negative controls demonstrate why each original independent cost remains.
    bad_base = CAP - original_budget(1000, raw) - OUTER + 1
    checks.append(('negative omit64MiB would falsely admit',
                   bad_base + original_budget(1000, raw) + OUTER > CAP and
                   bad_base + original_budget(1000, raw) - 67108864 + OUTER <= CAP))
    checks.append(('negative omit publisher payload triplication would falsely admit',
                   bad_base + original_budget(1000, raw) + OUTER > CAP and
                   bad_base + original_budget(1000, raw) - 2000 + OUTER <= CAP))
    short_ws = live + WS_MARGIN
    checks.append(('negative omit archive persistence would falsely admit workspace',
                   short_ws < workspace and live + WS_MARGIN <= short_ws))
    tar_checks = 0
    for count in (0, 1, 2, 9, 16):
        for size in (0, 1, 511, 512, 513, 4095, 4096, 4097, 65535):
            sizes = [size] * count
            value = tar_bytes(sizes)
            exact = ((sum(512 + ((n + 511) // 512) * 512 for n in sizes) + 1024 + 10239) // 10240) * 10240
            assert len(value) == exact
            assert len(value) - sum(sizes) <= 16 * 1023 + 11263 <= PAD
            tar_checks += 1
    sizes = [4097] * 16
    extra = len(tar_bytes(sizes)) - sum(sizes)
    checks.append(('negative omit USTAR headers violates actual bytes', extra > 16 * 511 + 11263))
    capacities = []
    for _ in range(3):
        r, w = os.pipe()
        capacities.append(fcntl.fcntl(r, fcntl.F_GETPIPE_SZ))
        os.close(r)
        os.close(w)
    # This measurement is only a reference; PROFILE repeats it on the actual pipes.
    drain = sum(capacities) + 3 * (4096 + 1024) + 128 * 1024
    result = {'schema': 'workspace-codegen-bound-proof/1', 'formal_executed': False,
              'compiler_or_driver_executed': False, 'publisher_sha256': PIN,
              'reference_OWN_used_bytes': B, 'reference_headroom_bytes': CAP - B,
              'original_publisher_manifest_upper': raw.decode(), 'manifest_upper_bytes': len(raw),
              'original_publisher_fixed_with_manifest_bytes': fixed,
              'publisher_payload_limit_bytes': pmax, 'raw_workspace_profile_limit_bytes': live,
              'workspace_peak_budget_bytes': workspace, 'reference_workspace_available_bytes': 4378624,
              'archive_member_max': 16, 'exact_USTAR_padding_upper': 16 * 1023 + 11263,
              'reserved_USTAR_padding_bytes': PAD, 'tar_cases_checked': tar_checks,
              'reference_pipe_capacities': capacities, 'reference_drain_and_terminal_bytes': drain,
              'necessary_start_condition': 'actual prefix allocated + actual drain/terminal reserve +64KiB < L',
              'diagnostic_512KiB_floor': 'retained conservative tool condition, not a product gate; not lowered',
              'checks': [{'name': name, 'passed': passed} for name, passed in checks],
              'exit_code': 0 if all(passed for _, passed in checks) else 1}
    destination = Path(__file__).with_name('BOUND_RESULT.json')
    assert not destination.exists(), 'Do not replace an existing proof'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'arithmetic_and_tar_exit': result['exit_code'], 'tar_cases': tar_checks,
                      'negative_and_capacity_checks': len(checks), 'P': pmax, 'L': live,
                      'workspace_budget': workspace, 'manifest_bytes': len(raw), 'output': str(destination)}))
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
