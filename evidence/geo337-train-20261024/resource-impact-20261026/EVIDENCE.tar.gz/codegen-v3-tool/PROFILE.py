"""Resource-bounded O2 code-generation diagnosis; never a formal axiom gate.

Default is plan-only. No original driver rerun, source edits, cleanup, ELF use,
or publication. Root must assign the source, R3 and publication reserve.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import gzip
import hashlib
import importlib.util
import io
import json
import os
import resource
import selectors
import shutil
import signal
import subprocess
import tarfile
import time
import traceback
import zlib

HELPER = Path('/tmp/geo-resume1758-axiom-driver-v2-20261026/DRIVER.py')
HELPER_PIN = 'e8eca29381076a94e4e34cfeba257ae810a4181fa1b7e44e6595223b9a69da30'
DRIVER = Path('/dev/shm/geometry-axiom-geo337-20261025/a7-axiom-driver-F-cbf0fb62-v2-20261026')
DRIVER_PIN = 'f087dfcd582114bc8ae26afc5ffe2ea9996a2d448069c0b3e89406a9083d9905'
PUBLISHER = Path('/tmp/geo337-recovery-evidence-append-preparation-20261026/publish_append.py')
PUBLISHER_PIN = '988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720'
PINS = {
    '/usr/bin/strace': '69f88291a4e47f258b8e32b089c919a247509f063ef3d6afe5389939051102b3',
    '/usr/libexec/gcc/x86_64-linux-gnu/14/cc1': '02675980109a4a5496cddf67d5286de57942759edc830deaa525e36f9a2a0291',
    '/usr/bin/as': '07dd8551ea0aa065975e4dddb8e1bb7dc308d12d54eca22c3858db79467c7cb9',
    '/usr/libexec/gcc/x86_64-linux-gnu/14/collect2': 'ea31a4cebd9df1b6428c463428d461ccecfe66c897936409d5b2cde0b3af9e27',
    '/usr/bin/ld': 'd2766988b6a1b1d1518cdc09242e726d1f24e151e16410ada3092b11ffd9081b',
    '/usr/libexec/gcc/x86_64-linux-gnu/14/liblto_plugin.so': '1160335db754d964f3560d403aa58e21380b2284439fe75317ffe5652e8bd839',
    '/usr/libexec/gcc/x86_64-linux-gnu/14/lto-wrapper': '290775a27c6dac1f5cc9bb9e7f0265fd955e0c4f7b29aaa04811393144b6f528',
}
MiB = 1024**2
ASSEMBLY_CAP = 16 * MiB
STDERR_CAP = 256 * 1024
TRACE_CAP = MiB
REGULAR_FILE_CAP = 64 * 1024  # diagnostic only; -S/-o- has no normal file output
DIAGNOSTIC_SECONDS = 60
PUBLISH_FIXED = 64 * MiB
PUBLISH_LEAVES = 1  # the single lossless archive; derivative indexes stay with outer receipt
MAX_ARCHIVE_MEMBERS = 16
ARCHIVE_PADDING = 27 * 1024  # exact USTAR bound: 16*1023 + 11263 = 27631
WORKSPACE_MARGIN = 64 * 1024
OUTER_ALLOWANCE = 64 * 1024
TERMINAL_ALLOWANCE = 128 * 1024
READ_CHUNK = 4096


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def load_helper():
    need(digest(HELPER.read_bytes()) == HELPER_PIN, 'Reviewed helper drift')
    spec = importlib.util.spec_from_file_location('_reviewed_axiom_driver_helpers', HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # definitions only; never calls main()
    module.verify_plan()
    return module


class RawGzip:
    def __init__(self, path):
        self.path = path
        self.file = path.open('xb', buffering=0)
        self.encoder = zlib.compressobj(level=6, wbits=31)
        self.sha = hashlib.sha256()
        self.count = 0

    def write(self, block):
        self.sha.update(block)
        self.count += len(block)
        self.file.write(self.encoder.compress(block))
        # Bounded, immediately visible storage: no hidden multi-MiB pending buffer.
        self.file.write(self.encoder.flush(zlib.Z_SYNC_FLUSH))

    def close(self):
        self.file.write(self.encoder.flush(zlib.Z_FINISH))
        self.file.close()
        h = hashlib.sha256()
        count = 0
        with gzip.open(self.path, 'rb') as stream:
            for block in iter(lambda: stream.read(65536), b''):
                h.update(block)
                count += len(block)
        need(count == self.count and h.hexdigest() == self.sha.hexdigest(), 'Lossless gzip verification failed')
        return {'path': self.path.name, 'raw_bytes': count, 'raw_sha256': h.hexdigest(),
                'gzip_bytes': self.path.stat().st_size, 'gzip_sha256': digest(self.path.read_bytes()),
                'lossless_roundtrip': True}


def child_limits():
    # All limits here apply to this diagnostic only, never to run_axiom_mutations.
    resource.setrlimit(resource.RLIMIT_CORE, (0, resource.getrlimit(resource.RLIMIT_CORE)[1]))
    _, hard = resource.getrlimit(resource.RLIMIT_FSIZE)
    resource.setrlimit(resource.RLIMIT_FSIZE,
                       (REGULAR_FILE_CAP if hard == resource.RLIM_INFINITY else min(REGULAR_FILE_CAP, hard), hard))
    _, hard = resource.getrlimit(resource.RLIMIT_STACK)
    need(hard == resource.RLIM_INFINITY or hard >= 16 * MiB, 'Stack hard limit below original 16MiB')
    resource.setrlimit(resource.RLIMIT_STACK, (16 * MiB, hard))


def capture_codegen(helper, out, env, profile_limit):
    names = ('stdout', 'stderr', 'trace')
    pipes = {name: os.pipe() for name in names}
    capacities = {name: fcntl.fcntl(pair[0], fcntl.F_GETPIPE_SZ) for name, pair in pipes.items()}
    drain_reserve = sum(capacities.values()) + len(names) * (READ_CHUNK + 1024) + TERMINAL_ALLOWANCE
    need(profile_limit > helper.allocated((out,)) + drain_reserve + 64 * 1024,
         'Insufficient capacity for lossless pipe drain and terminal receipt')
    subject = ['cc', '-std=c11', '-O2', '-S', str(helper.SOURCE / 'geometry-core/model_base.c'), '-lm', '-o', '-']
    argv = ['/usr/bin/strace', '-f', '-qq', '-s', '256', '-e',
            'trace=execve,open,openat,creat,unlink,unlinkat,rename,renameat,renameat2,truncate,ftruncate',
            '-o', '/proc/self/fd/' + str(pipes['trace'][1]), '--', *subject]
    row = {'subject_argv': subject, 'observed_argv': argv, 'cwd': str(helper.SOURCE),
           'source_sha': helper.F, 'formal_acceptance': False,
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'diagnostic_seconds': DIAGNOSTIC_SECONDS, 'assembly_raw_cap_bytes': ASSEMBLY_CAP,
           'regular_file_diagnostic_cap_bytes': REGULAR_FILE_CAP,
           'profile_storage_limit_bytes': profile_limit, 'pipe_capacity_bytes': capacities,
           'lossless_drain_and_terminal_reserve_bytes': drain_reserve,
           'actual_exit_code': None, 'complete_output': False, 'errors': []}
    save(out / 'request.json', row)
    writers = {name: RawGzip(out / (name + '.bin.gz')) for name in names}
    memory = bytearray()
    process = None
    selector = selectors.DefaultSelector()
    start = time.monotonic()
    killed_at = None
    eof_streams = set()
    try:
        process = subprocess.Popen(argv, cwd=helper.SOURCE, env=env, stdin=subprocess.DEVNULL,
                                   stdout=pipes['stdout'][1], stderr=pipes['stderr'][1],
                                   pass_fds=(pipes['trace'][1],), start_new_session=True,
                                   preexec_fn=child_limits)
        for name, (reader, writer) in pipes.items():
            os.close(writer)
            os.set_blocking(reader, False)
            selector.register(reader, selectors.EVENT_READ, name)
        while selector.get_map():
            if time.monotonic() - start >= DIAGNOSTIC_SECONDS and not row['errors']:
                row['errors'].append('Diagnostic timeout; formal 60/180-second gates remain unchanged')
            if helper.allocated((out,)) >= profile_limit - drain_reserve and not row['errors']:
                row['errors'].append('Resource publication-storage guard reached; diagnosis incomplete')
            if row['errors'] and killed_at is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                killed_at = time.monotonic()
            if killed_at is not None and time.monotonic() - killed_at > 5:
                row['errors'].append('Diagnostic pipe failed to close after process-group termination')
                break
            for key, _ in selector.select(0.05):
                block = os.read(key.fd, READ_CHUNK)
                if not block:
                    selector.unregister(key.fd)
                    os.close(key.fd)
                    eof_streams.add(key.data)
                    continue
                name = key.data
                writers[name].write(block)  # retain every emitted byte, including post-kill drain
                if name == 'stdout':
                    memory.extend(block)
                limit = {'stdout': ASSEMBLY_CAP, 'stderr': STDERR_CAP, 'trace': TRACE_CAP}[name]
                if writers[name].count > limit and not row['errors']:
                    row['errors'].append(name + ' diagnostic stream cap exceeded; diagnosis incomplete')
        process.wait(timeout=5)
        row['actual_exit_code'] = process.returncode
        row['complete_output'] = not row['errors']
    except BaseException as error:
        row['errors'].append(repr(error))
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            # Preserve bytes already emitted after controller exceptions too.
            # A failed/unfinished drain is explicitly unknown, never complete.
            drain_deadline = time.monotonic() + 5
            while selector.get_map() and time.monotonic() < drain_deadline:
                for key, _ in selector.select(0.05):
                    block = os.read(key.fd, READ_CHUNK)
                    if not block:
                        selector.unregister(key.fd)
                        os.close(key.fd)
                        eof_streams.add(key.data)
                    else:
                        writers[key.data].write(block)
                        if key.data == 'stdout':
                            memory.extend(block)
            process.wait(timeout=5)
            row['actual_exit_code'] = process.returncode
    finally:
        row['stream_EOF_observed'] = sorted(eof_streams)
        row['all_emitted_streams_drained'] = eof_streams == set(names)
        if not row['all_emitted_streams_drained']:
            row['errors'].append('Output completeness unknown: EOF not observed on every stream')
            row['complete_output'] = False
        selector.close()
        for pair in pipes.values():
            for descriptor in pair:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
        row['elapsed_seconds'] = time.monotonic() - start
        row['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        row['streams'] = {name: writer.close() for name, writer in writers.items()}
        row['assembly_memory_bytes'] = len(memory)
        row['assembly_memory_sha256'] = digest(memory)
        need(row['streams']['stdout']['raw_sha256'] == digest(memory), 'Assembly RAM/stdout mismatch')
        save(out / 'result.json', row)
    return row


def ustar_bytes(members):
    need(len(members) <= MAX_ARCHIVE_MEMBERS, 'Diagnostic envelope member-count bound exceeded')
    result = io.BytesIO()
    with tarfile.open(fileobj=result, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in members:
            need(name.isascii() and len(name.encode()) <= 100, 'Need literal short USTAR member names')
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mtime = 0
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
    raw = result.getvalue()
    need(len(raw) <= sum(len(data) for _, data in members) + ARCHIVE_PADDING,
         'Actual USTAR bytes exceed the proven fixed-header/record-padding bound')
    return raw


def archive_bytes(out):
    return ustar_bytes([(str(p.relative_to(out)), p.read_bytes())
                        for p in sorted(out.rglob('*')) if p.is_file()])


def publish_manifest(archive_path, destination, size, sha256):
    return (json.dumps({'files': [{'source_path': str(archive_path), 'destination': destination,
                                  'bytes': size, 'sha256': sha256}]}, indent=2) + '\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--scheduler-slot', type=int, choices=(1, 2))
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'plan_only': True, 'stage': 'O2 code generation only',
                          'formal_acceptance': False, 'assembly_raw_cap_bytes': ASSEMBLY_CAP,
                          'publisher_formula': '3*payload + leaves*65536 + 8*manifestbytes + 64MiB',
                          'artifact_and_archive_storage_counted_separately': True}))
        return 0
    need(args.output is not None and args.scheduler_slot is not None, 'Root scheduling assignment required')
    helper = load_helper()
    need(helper.filehash(PUBLISHER) == PUBLISHER_PIN, 'Original publisher formula/schema changed')
    base = args.output.resolve()
    need(base.parent == Path('/workspace') and base.name.startswith('geo-axiom-codegen-') and
         not base.exists() and not args.output.is_symlink(), 'Need explicitly assigned fresh workspace evidence directory')
    out = base / 'raw'
    archive_path = base / 'PROFILE.tar'
    descriptor_path = base / 'DELIVERY.json'
    publisher_manifest_path = base / 'PUBLISH_MANIFEST.json'
    destination = 'evidence/geo337-train-20261024/' + base.name + '/PROFILE.tar'
    manifest_upper = publish_manifest(archive_path, destination, helper.CEILING, 'f' * 64)
    need(helper.filehash(DRIVER / 'receipt.json') == DRIVER_PIN, 'Actual original driver receipt drift')
    driver = json.loads((DRIVER / 'receipt.json').read_text())
    need(driver['actual_exit_code'] == 0 and driver['source_preserved'] and
         all(r['actual_exit_code'] == 0 and r['complete_output'] for r in driver['commands']), 'Driver was not complete')
    for row in driver['commands']:
        for stream in ('stdout', 'stderr'):
            need(helper.filehash(DRIVER / row['name'] / (stream + '.bin')) == row[stream + '_sha256'], 'Driver raw drift')
    for path, pin in PINS.items():
        need(helper.filehash(path) == pin, 'Observed compiler/tracer tool changed: ' + path)
    need(helper.LOCK.is_file() and not helper.LOCK.is_symlink(), 'Existing R3 lock required')
    lock = helper.LOCK.open('rb')
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    before = helper.source_guard()
    base_used = helper.allocated((helper.OWN, helper.OTHER))
    # Only the original two OWN roots are in the existing 2GiB guard.
    # New raw evidence and its archive live in the separately authorized workspace;
    # count their physical cost there, and preserve the FULL original publisher formula in OWN.
    publisher_fixed = PUBLISH_FIXED + PUBLISH_LEAVES * 65536 + 8 * len(manifest_upper)
    payload_limit = (helper.CEILING - base_used - publisher_fixed - OUTER_ALLOWANCE) // 3
    profile_limit = payload_limit - ARCHIVE_PADDING
    need(profile_limit >= 512 * 1024, 'Conservative diagnostic minimum not met; this is not a product gate')
    workspace_budget = profile_limit + ((payload_limit + 4095) // 4096) * 4096 + WORKSPACE_MARGIN
    workspace_available_before = helper.available('/workspace')
    need(workspace_available_before >= workspace_budget, 'Actual workspace capacity cannot preserve raw + archive + terminal metadata')
    need(helper.available(helper.OWN) > 3 * payload_limit + publisher_fixed + OUTER_ALLOWANCE,
         'Actual publisher mount capacity below original formula')
    env = dict(os.environ)
    for key in list(env):
        if key.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_', 'GEO261_', 'GEO323_')) or key in (
                'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONOPTIMIZE',
                'NODE_OPTIONS', 'LD_PRELOAD', 'AXIOM_ONLY', 'FRAMING_QUOTE_QUEUE'):
            env.pop(key)
    scratch = out / 'scratch'
    env.update(TMPDIR=str(scratch), LANG='C.UTF-8', LC_ALL='C.UTF-8',
               PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8', PYTHONOPTIMIZE='0')
    normalized = dict(env, TMPDIR=driver['environment']['TMPDIR'])
    normhash = digest(json.dumps(sorted(normalized.items()), separators=(',', ':')).encode())
    need(normhash == driver['environment_sha256'], 'Environment differs from actual driver (after explicit TMPDIR normalization)')
    need(str(Path(shutil.which('cc', path=env.get('PATH'))).resolve()) == driver['compiler_path'] and
         helper.filehash(driver['compiler_path']) == driver['compiler_sha256'], 'Compiler mismatch')
    base.mkdir(mode=0o700)
    out.mkdir(mode=0o700)
    scratch.mkdir(mode=0o700)
    input_members = [('PROFILE.py', Path(__file__).read_bytes()), ('DRIVER-helper.py', HELPER.read_bytes()),
                     ('CLOSURE.tsv', (helper.PLAN / 'CLOSURE.tsv').read_bytes()),
                     ('DRIVER-receipt.json', (DRIVER / 'receipt.json').read_bytes()),
                     ('BOUND_PROOF.py', Path(__file__).with_name('BOUND_PROOF.py').read_bytes()),
                     ('BOUND_RESULT.json', Path(__file__).with_name('BOUND_RESULT.json').read_bytes())]
    input_tar = ustar_bytes(input_members)
    input_gzip = gzip.compress(input_tar, mtime=0)
    need(gzip.decompress(input_gzip) == input_tar, 'Lossless preparation-input archive failed')
    (out / 'inputs.tar.gz').write_bytes(input_gzip)
    receipt = {'schema': 'axiom-O2-codegen-resource-diagnostic/1', 'source_sha': helper.F,
               'formal_acceptance': False, 'source_before': before, 'source_after': None,
               'source_preserved': False, 'scheduler_slot': args.scheduler_slot, 'R3': str(helper.LOCK),
               'driver_receipt_sha256': DRIVER_PIN, 'helper_sha256': HELPER_PIN,
               'publisher_tool_sha256': PUBLISHER_PIN,
               'tool_sha256': helper.filehash(__file__), 'compiler_tools_sha256': PINS,
               'normalized_driver_environment_sha256': normhash,
               'environment': {key: env.get(key) for key in driver['environment']},
               'input_archive': {'gzip_bytes': len(input_gzip), 'gzip_sha256': digest(input_gzip),
                                 'raw_tar_bytes': len(input_tar), 'raw_tar_sha256': digest(input_tar),
                                 'lossless_roundtrip': True,
                                 'members': [{'path': name, 'bytes': len(data), 'sha256': digest(data)}
                                             for name, data in input_members]},
               'TMPDIR': str(scratch), 'source_root': str(helper.SOURCE), 'errors': [],
               'admission': {'base_OWN_used_bytes': base_used, 'OWN_ceiling_bytes': helper.CEILING,
                             'profile_limit_bytes': profile_limit, 'payload_limit_bytes': payload_limit,
                             'publisher_fixed_bytes': PUBLISH_FIXED, 'publisher_leaves': PUBLISH_LEAVES,
                             'publisher_manifest_upper_bytes': len(manifest_upper),
                             'archive_padding_allowance': ARCHIVE_PADDING, 'complete_formula_preserved': True,
                             'placement': 'new workspace raw + archive; original publisher/Git remain in two OWN roots',
                             'workspace_available_before': workspace_available_before,
                             'workspace_peak_budget_bytes': workspace_budget,
                             'workspace_device': os.stat('/workspace').st_dev,
                             'workspace_block_bytes': os.statvfs('/workspace').f_frsize},
               'actual_exit_code': None, 'scope': 'Only O2 code generation; as/link/five mutants not run'}
    save(out / 'receipt.json', receipt)
    result = 1
    try:
        row = capture_codegen(helper, out, env, profile_limit)
        receipt['codegen'] = row
        need(row['actual_exit_code'] == 0 and row['complete_output'], 'O2 code-generation diagnosis incomplete/nonzero')
        need(row['streams']['stdout']['raw_bytes'] > 0, 'No generated assembly')
        result = 0
    except BaseException as error:
        receipt['errors'].append(repr(error))
        (out / 'exception.txt').write_text(traceback.format_exc())
    finally:
        try:
            after = helper.source_guard()
            receipt['source_after'] = after
            receipt['source_preserved'] = before == after
            need(before == after, 'Source or index changed during resource diagnosis')
            receipt['scratch_files'] = [{'path': str(p.relative_to(scratch)), 'bytes': p.stat().st_size,
                                         'sha256': helper.filehash(p)} for p in sorted(scratch.rglob('*')) if p.is_file()]
            receipt['scratch_allocated_bytes'] = helper.allocated((scratch,))
            need(not receipt['scratch_files'], 'Unexpected code-generation scratch; inspect before continuing')
            need(helper.allocated((out,)) <= profile_limit - 16 * 1024, 'Terminal evidence storage reserve exhausted')
        except BaseException as error:
            receipt['errors'].append(repr(error))
            result = 1
        def snapshot():
            receipt['actual_exit_code'] = result
            save(out / 'receipt.json', receipt)
            leaves = [{'path': str(p.relative_to(out)), 'bytes': p.stat().st_size,
                       'sha256': helper.filehash(p)} for p in sorted(out.rglob('*'))
                      if p.is_file() and p != out / 'MANIFEST.json']
            save(out / 'MANIFEST.json', {'source_sha': helper.F, 'formal_acceptance': False, 'files': leaves})
            payload = archive_bytes(out)
            descriptor = {'source_sha': helper.F, 'formal_acceptance': False,
                          'archive_name': archive_path.name, 'archive_bytes': len(payload),
                          'archive_sha256': digest(payload), 'source_receipt_sha256': helper.filehash(out / 'receipt.json'),
                          'source_root': str(out),
                          'observed_stream_prefixes_losslessly_archived': bool(receipt.get('codegen', {}).get('streams')),
                          'all_emitted_streams_drained': bool(receipt.get('codegen', {}).get('all_emitted_streams_drained')),
                          'output_completeness': ('complete' if receipt.get('codegen', {}).get('all_emitted_streams_drained') else 'unknown'),
                          'diagnostic_completed_without_cap_or_timeout': result == 0,
                          'diagnostic_exit_code': result}
            descriptor_raw = (json.dumps(descriptor, ensure_ascii=False, indent=2) + '\n').encode()
            return payload, descriptor_raw
        try:
            payload, descriptor_raw = snapshot()
            need(helper.allocated((out,)) <= profile_limit, 'Actual retained profile exceeds reserved limit')
            manifest_raw = publish_manifest(archive_path, destination, len(payload), digest(payload))
            publisher_extra = 3 * len(payload) + PUBLISH_LEAVES * 65536 + 8 * len(manifest_raw) + PUBLISH_FIXED
            current = helper.allocated((helper.OWN, helper.OTHER))
            persist_upper = sum(((size + 4095) // 4096) * 4096
                                for size in (len(payload), len(descriptor_raw), len(manifest_raw)))
            need(len(payload) <= payload_limit and len(manifest_raw) <= len(manifest_upper),
                 'Actual archive/manifest exceeds the proven admission envelope')
            need(current + publisher_extra + OUTER_ALLOWANCE <= helper.CEILING,
                 'Original two-OWN publisher formula does not fit; no ceiling or threshold change')
            need(helper.allocated((base,)) + persist_upper <= workspace_budget and
                 helper.available('/workspace') >= persist_upper,
                 'Actual workspace raw + archive + derivative metadata exceeds its independent physical budget')
            # New raw artifacts are kept. Archive is an additional lossless delivery object.
            with archive_path.open('xb') as stream:
                stream.write(payload)
            with descriptor_path.open('xb') as stream:
                stream.write(descriptor_raw)
            with publisher_manifest_path.open('xb') as stream:
                stream.write(manifest_raw)
            print(json.dumps({'source_sha': helper.F, 'diagnostic_exit_code': result,
                              'formal_acceptance': False, 'output': str(out),
                              'archive': str(archive_path), 'descriptor': str(descriptor_path),
                              'publisher_manifest': str(publisher_manifest_path),
                              'publisher_manifest_sha256': digest(manifest_raw),
                              'publisher_extra_bytes': publisher_extra,
                              'publisher_manifest_actual_bytes': len(manifest_raw)}, ensure_ascii=False))
        except BaseException as error:
            result = 1
            receipt['errors'].append('Terminal publication packaging failed: ' + repr(error))
            # Never leave a receipt0/launcher1 split after a late envelope guard.
            # Keep the original generated files; do not lower caps or delete data.
            receipt['actual_exit_code'] = result
            save(out / 'receipt.json', receipt)
            stale = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': helper.filehash(p)}
                     for p in (archive_path, descriptor_path, publisher_manifest_path) if p.is_file()]
            save(out / 'FAILED_DELIVERY.json', {
                'source_sha': helper.F, 'actual_exit_code': 1,
                'candidate_delivery_authoritative': False, 'do_not_publish': True,
                'reason': repr(error), 'stale_candidate_files_preserved': stale,
                'current_receipt_sha256': helper.filehash(out / 'receipt.json'),
                'rule': 'Any pre-existing archive/descriptor is historical only; require a fresh verified failure envelope before delivery.'})
            leaves = [{'path': str(p.relative_to(out)), 'bytes': p.stat().st_size,
                       'sha256': helper.filehash(p)} for p in sorted(out.rglob('*'))
                      if p.is_file() and p != out / 'MANIFEST.json']
            save(out / 'MANIFEST.json', {'source_sha': helper.F, 'formal_acceptance': False, 'files': leaves})
            raise
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            lock.close()
    return result


if __name__ == '__main__':
    raise SystemExit(main())
