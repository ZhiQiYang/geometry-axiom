# §7 axiom 全鏈容量結論

狀態：**BLOCKED；固定 F 的正式 axiom 未跑**。本報告只收斂資源依賴，不新增診斷工具、修改裁判或開始編譯。停止 v4／縮小碼流／調整 minimum 的逐段入場方式。

F：`cbf0fb621888596aa14ad5f2349b503e23b1b72d`。
來源：`/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026`。

## 已實測與未實測

- 四項 `cc -###` driver 真 exit 0；只證明展開命令，未產生 assembly、object 或 ELF。receipt SHA256：`f087dfcd582114bc8ae26afc5ffe2ea9996a2d448069c0b3e89406a9083d9905`。
- v3 真 exit 1，位置 `PROFILE.py:304`，原因為新診斷的保守 512 KiB floor。沒有 compiler、沒有新 WS output。這不是產品紅。完整原件仍在 OWN 的 `a8-codegen-outer-F-cbf0fb62-v3-20261026`；stderr SHA256：`86ebcea0343228fea4865c52a4d3fb30825d24a6a4a10bacace3632739f87417`。
- codegen、as、link、固定 F 的正式 11 子程序與其合併發布皆未完成；無可核實的全流程峰值或全 raw 封包大小。

## 完整剩餘路徑

1. **codegen**：固定原 O2 compiler 與 171 葉 C closure（1,987,138 B），讀原來源，不必複製。需保留 stdout、stderr、trace、命令、環境、退出碼及來源識別。assembly 真大小與 compiler 暫存峰值未知。診斷 16 MiB raw cap 不能帶入正式裁判。
2. **as**：assembly → object。可以同一 raw bytes 經 stdin 餵入，以免多留未壓縮 assembly；但完整原流仍須無損保存。object 大小及 assembler 暫存峰值未知。
3. **link**：object → ELF。實際 driver 包含 collect2、liblto_plugin、lto-wrapper 與 TMPDIR 的 `*.res`；ELF、res 與 link 峰值未知，不能只計一個 ELF。
4. **正式 axiom**：原命令 `python3 -B -u geometry-core/card-reference/run_axiom_mutations.py --output <fresh>/subject`。11 個順序子程序＝baseline 全 44＋5 個 mutation 各單測紅＋5 次恢復各全 44，合計 269 單測。五 mutation 僅改 Python，C compiler input 相同；不可將診斷 ELF 當正式 adapter。通常每子程序一個 adapter，正常 atexit 清自身 scratch；異常退出殘件仍須計入保留成本。原 compile 60 s／子程序 180 s／scene native 20 s 不變。單 scene input 最大 1 MiB；compiler scratch、異常殘件與 11 子程序全部 raw 總量沒有可用上界。
5. **完整終態與單次發布**：所有診斷與正式原始輸出、失敗、命令、退出、環境、SHA 一併保存及封存。不得只保下一 phase，或刪原件讓下一 phase 入場。不假設壓縮率；壓縮只可無損。獨立原始失敗亦必保留。

## 原守門與唯一容量觀測

2 GiB 起源由主代理核實：2026-10-25 12:52:38 的 PLAN.json，`recommended_SHM.root_planning_ceiling_bytes=2147483648`，並列 `no_new_CI_or_assertion_threshold=true`、`budget_is_not_proven_maximum=true`；13:01:56 TWO_ROOTS addendum 改成兩 OWN 合計。它是既有規劃及 publisher 強制守門，不是產品 assertion。本報告不降低或繞過。

唯一容量觀測採主代理 `/tmp/geo-resume2100-capacity-consolidation-20261026/OBSERVATION.json`（2026-10-26 20:35:17Z），未另量測：

|項目|bytes|
|---|---:|
|twoOWN 已用|2,078,834,688|
|twoOWN 原規劃餘額|68,648,960|
|TMP 實體可用|111,140,864|
|WS 實體可用|4,378,624|
|SHM 實體可用|15,793,045,504|

SHM 實體餘額不解除 twoOWN 守門。新診斷曾規劃把新 raw/archive 放 WS；WS 空間與 OWN 發布成本都必分別計算，不能把移掛載當容量消失。無新掛載、配額或安全設定修改。

原 publisher：`/tmp/geo337-recovery-evidence-append-preparation-20261026/publish_append.py`，SHA256 `988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720`。lines 26–31 檢查兩 OWN；單 leaf 完整發布額外需求：

`3P + 65,536 + 8M + 67,108,864`，再保留 root outer 65,536 B。

P 為 archive 真 bytes，M 為 manifest raw bytes。現 v3 單 leaf 路徑 M 上界 339 B；合併發布若換路徑需按真 schema 重算。以此 M 計，固定成本 67,242,648 B，當前整批 archive 上限只有 **468,770 B**。完整鏈 archive 大小未知，無證據支持它能落於此上限。

## 必要成本、保守情境與未知

實際純記憶體編碼 v3 inputs gzip 27,047 B，落盤 allocation 28,672 B；加最小 receipt 一塊，prefix 至少 32,768 B。原 drain 343,040 B＋start allowance 65,536 B，要求 L 至少 441,345 B；當前 L 441,122 B，連單純拿掉 512 KiB floor 都不足（至少 223 B，尚未計目錄等）。若只滿足 512 KiB floor，OWN 差 249,496 B。**兩者都只是下一診斷 phase 的局部差額，不能當整鏈最小解除量。**

保守情境：假設 assembly、object、ELF 各用滿診斷 16 MiB cap，三份 raw 48 MiB；不假設壓縮的 raw＋交付 archive 至少按 96 MiB 規劃。WS 此情境差 96,284,672 B；改用 TMP 也只剩 10,477,568 B，仍無正式 compiler、殘件及 11 raw 可容納的證明。僅 P=48 MiB 的上述發布公式已需 218,237,592 B，比 twoOWN 餘額多 149,588,632 B，尚未加正式 logs/header。這是 cap 極值情境，**不是已測大小，也不是實際必需下限**；正式 compiler 沒有 16 MiB cap，故亦不是全鏈最壞上界。

F9 歷史 axiom retained 504,080 logical B／585,728 allocated B，只是不同 SHA 的收件量，不是 compiler peak 或新 F 的 raw 上界。不能據此宣告 F 可跑或沿用全綠。

## 結論與解除條件

真正最大保留成本未知；因此全鏈無法證明能完成編譯、原正式 11 子程序及合併發布。實際完整缺額未知，不能聲稱再添 223 B 或 249,496 B 即可解決。此依賴維持 **BLOCKED**，不再為容量診斷增加下一輪收據。

可解除的必要證據：同 compiler／C closure／原正式路徑的既有有效峰值與產物量，或足以覆蓋完整鏈及原 publisher 公式的已授權保留容量。兩者都須包含異常終態、完整原流和發布，不能只證明下一 phase。沒有新語意、新門檻或刪檔授權請求隱含於此結論。

獨立 card 全套仍有既有 448 MiB 規劃，對當前 twoOWN 餘額差 401,113,088 B；它不因本報告視為可執行。native、browser、Q38 由主代理合併其各自依賴；本報告不改其守門或狀態。
