# F9 → F：正式 gate 靜態影響與重測候選分類

本報告只分類影響；沒有執行測試、重新取樣、重新比對 Git 全樹、變動來源／index／快取，沒有更改 current-state 矩陣。不得據此將歷史結果改標成 F 通過。

## 固定範圍與判準

- F9：`4f8a794f4167c3562eb182045102e86e9e37cca9`。
- F：`cbf0fb621888596aa14ad5f2349b503e23b1b72d`。
- 最新已發布證據 E：`9bd32131e1657ea3a35c41707ae3e1f42df5fdb8`。
- 唯一 current-state 正文 D：`2cce6afaeac87521924bde28660a71e43ad306e5`。本報告不改正文，也不宣稱它已套用 PR。
- 沿用既有 `/tmp/geo-resume1925-native-source-plan-20261026/observation/RESULT.json`（12,646 bytes，SHA256 `608b871b826ca7cd3fc338d0cc835291df89245245a7cfbf22f48e73e1547bfb`）：兩端 selected Git 集合各 6997 葉、無新增／移除，五檔異動。該觀測明列 `source_payloads_fully_rehashed=false`；不是現存 6997 實體檔完整物化證明。
- 本次讀取現 F 的入口與外層工具；來源根為 `/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026`。它的 3763 葉不能代替完整 native 根。
- **A 必須重跑**：直接執行裁判或裁判記錄的來源 closure 已受五檔影響；若尚無有效 F 原件，正式 gate 仍缺。
- **B 僅已查產品／裁判 bytes 相同**：已查入口沒有五檔行為輸入，但執行來源、環境、產物、外層守門或批准尚未閉合。這是可供審查的重測候選分類，**不是 skip／跨 SHA 沿用批准**；既有同 F 驗收要求不變。
- **C 已有同 F 有效原件**：保留已完成結果，沒有新變更就不為製造進度再跑。

五個 delta 簡稱：D1=`geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md`；D2=`geometry-core/domain-decoupling/product-architecture-receipt.json`；D3=`tests/mutants_results.json`；D4=`tests/test_geo314_commit_paths.py`；D5=`決策佇列.md`。selected 集合中的 C／JS、workflow、manifest／scan、其他 tests 檔案 Git bytes 不變；外部工具與選取範圍以外的動態依賴不能從這句推出等價。

## 分類表（不是新的結果矩陣）

| 正式項目／入口 | 五檔中的實際讀取或身分影響 | 分類與下一步界線 |
|---|---|---|
| native：`ulimit -s 16384; python3 tests/run_all.py --build` | registry 執行 D4；`mutation:check` 讀 D3，bridge oracle closure 又含 D4；SSOT adoption 測試直接讀 D5。外層核對 HEAD／tree／status／index。 | **A**。F9 原 exit 1（5327 pass／1 fail／1 原允許 GDI skip）不能沿用。F 完整 native **UNRUN**；必須在完整、乾淨、符合資源准入的 F 上跑原 35 分鐘流程。 |
| canvas：`node geometry-web/cdp_test.js` | 已查產品 runtime、binary 指紋與 JS 入口未直接讀 D1–D5；原 driver／preparer 真讀 HEAD、根、乾淨狀態與完整來源 manifest。 | **B**。F9 exit 0／2267 assertions／85 golden 保留歷史；新 F **UNRUN**。不新增 skip、不換綁。 |
| assembly：`GEOMETRY_ASSEMBLY_ONLY=1 node geometry-web/cdp_test.js` | 同 canvas 的共用來源守門；測項分流未新增五檔直接依賴。 | **B**。F9 r2 exit 0／150，r1 環境 exit 1 保留；新 F **UNRUN**。 |
| documents：`node geometry-web/documents_browser_test.js` | 共用守門；runtime 額外收錄固定公開文件／閱讀器／範例。D1 不在公開 documents allowlist，D5 不在版本集合。 | **B**。F9 exit 0／47 assertions／8 screens 保留；新 F **UNRUN**。不能把「是 Markdown」當通用排除理由。 |
| grid：`GEOMETRY_GRID_SYSTEM_ONLY=1 node geometry-web/cdp_test.js` | 共用 HEAD／root／manifest 守門及內容版本。 | **B**。F9 exit 0／356 保留；新 F **UNRUN**。 |
| space：`node geometry-web/space_model_test.js` | 共用守門與 binary／runtime 內容指紋。 | **B**。F9 exit 0／242、原 2 個分組 skip 保留；新 F **UNRUN**。 |
| timber：`GEOMETRY_TIMBER_ONLY=1 node geometry-web/space_model_test.js` | 同 space；不以木工 C 同 bytes 取代正式執行身分。 | **B**。F9 exit 0／79、原 5 個分組 skip 保留；新 F **UNRUN**。 |
| Q38：`python3 tests/section_profile_mutation_check.py` | 模型副本複製全部 `tests/*.py`，包含 D4；`tree_digest` 對全部副本取摘要。D4 即使不是該模型被執行的方法，仍改來源摘要。已查 copy 集合不含 D1／D2／D3／D5。 | **A**。不能說整組 closure 未變。F9 完整 44 項 exit 0（43 killed＋SPM24 equivalent）保留；F 正式原件仍缺。 |
| §7 card：`geometry-core/card-reference/run_mutations.py` | 讀 `tests/run_all.expected.json`（未變），並直接 `git rev-parse HEAD` 寫 `source_head`；已查入口未直接讀五檔。 | **B**。語意輸入未見 delta，執行身分有變；新 F 正式 **UNRUN**。原 448 MiB 規劃阻擋保留。 |
| §7 axiom：`geometry-core/card-reference/run_axiom_mutations.py` | 直接讀 HEAD 寫 `source_head`，讀 `公理層.md` 與固定 AXIOM_REVISION；此二者不在五檔 delta。 | **B**。F9 歷史 exit 0 保留；F 正式 **UNRUN**。本輪四個 `cc -###` exit 0 只證 driver 命令解析，沒有編譯或正式突變。 |
| Reading A／RC：原 `run_stage.py` 的 native／oracle／mutants／quick／golden 與 RC 精確方法 | 原 oracle、測試、rooms、Reading A fixtures 在 selected delta 外。stage 前後核 HEAD/status/index；RC worker 核 GITHUB_SHA／workspace、HEAD／clean、六份原輸入 Git blobs，再跑原方法及撤回／恢復。 | **B**。已查局部語意輸入未變，但整套正式與反證尚未核收為 F；**未閉合**。reader 三條通過不代表 oracle／RC／CLI 或凹角掃描通過。 |
| #314 提交路徑裁判與其反證 | D4 本身改動；它以固定歷史提交證 I24 原實作沒有 K 修改，並以另一完整 K 基準樹擋後續任意 K 修改，另檢 untracked K。 | **A**。需保留既有撤回／恢復原件與 index 保全，再核對其 SHA／原 assertion；本報告不宣稱已補跑 F 專項或八 focused／四組反證。完整 native 仍必跑。 |
| P52 放置後 timber 出現耗時；P-189 三方 N16/32/48/64 loadfile+dump；required-eight／PF3／whole-memo／replay | 五檔選取 diff 只排除已選產品／裁判直接字節變動，**未完成這些外部專項的完整入口、fixture、計時／stdout／參照基準 closure 審查**。不能從 browser 或 C 指紋推導耗時或位元組輸出可沿用。 | **B（尚未證明完整 bytes 等價）**。維持正文 **未閉合**；P-189 原 strict exact 紅燈保留。不得把 #323 三差範圍擴到 P-189，也不得自行接受新的跨 SHA 例外。 |
| `python3 tests/mutate.py --check` | D3 是被檢帳本；D4 進入 bridge oracle closure。結果檢 checksum、mutant／source／closure／oracle／execution，不是只看目前 HEAD 等於原執行 head。 | **C**。已有效 F exit 0、123/123；不重跑或整份重產已有效帳本。保留先前 stale exit 1。 |
| 架構三條：contract／test_architecture_contract／test_product_architecture | 三條以 manifest、登記來源與 exclusions 掃描；D1／D2 是產物，不是三條的主要圖來源。D4 不等於產品架構來源全部改變；D5 的批准審計另有 native 路徑。 | **C**。既有 F 0/0/0，798 edges／205 generic／18 product、零 skip。四檔組裝／provenance 已另驗，不由三條 pass 自動推出。 |
| reader generate／check／unit | generator 直接讀 canonical、`公理層.md`、白話與 optional review；原 unit 和外層有自身來源／fixture 守門。五檔無 generator 輸入 delta；更重要是已有 F 實跑。 | **C**。本輪 F inner／outer 0/0/0，51 tests／0 skip，173 ResourceWarning 原樣保存；不要再跑已有效同 F 原件。 |

## 動態依賴證據與反例

1. **native 真讀變動裁判與 queue。** `tests/run_all.py:51–57` 登記 #318、#314 及架構裁判，`:518` 是 `mutation:check`，`:714` 綁帳本。`tests/test_domain_decoupling_adoption.py:341–378,486,531–532` 對 D5 的批准段逐條驗證。即使產品 C 不動，改壞批准段或 D4 邏輯仍會改 native 判決；不能把所有 Markdown 或 tests 都排除。
2. **帳本 closure 不只是 C。** `tests/mutate.py:850–910` 的 C/include closure、普通 oracle 與 compile hash 各有範圍；`:1306` 起 `effective_record` 驗證記錄。`tests/mutation_bridge.py:102–114` 保守納入全部 tests Python/C、fixtures scene、root scene；`:467–485` 執行時真讀 HEAD 並只許帳本 dirty。反例：C 同 bytes、D4 改動仍會使舊 bridge oracle hash 過期。S10 全 123 原 exit 0 採入 F，F `--check` 已確認新記錄有效；120 個原 execution head 仍是 S10，不偽造成 F 重跑。
3. **#314 是 Git 語意裁判。** `tests/test_geo314_commit_paths.py:263–276` 對 `INTEGRATION_BASE→I24_IMPLEMENTATION_HEAD` 做 K diff，再把工作樹 K 對精確 `GENERIC_SOURCE_INDEX_KERNEL_HEAD` 比較並查 untracked。HEAD/tree/歷史物件可解析性、工作樹及 index 的情境會影響結果；只保存測試文字或略去 K 新檔不足。新增違規 K 檔應轉紅，不能將 generic K 改動當所有 K 的豁免。
4. **runtime 版本與 Git HEAD 是兩層。** `geometry-web/runtime_version.py:14–15,77–104,113–144,199–205` 用選定內容與實際根路徑 freshness。明確集合涵蓋五個產品目錄的特定副檔名、current_geometry、公理層、固定公開資產；五個 delta 不在其中。`tests/binaries.py:263–304` 的 C/h/inc／指定生成源與 compile 指紋另守 binary。這些不直接讀 HEAD，不能反過來省掉 browser 外層精確 Git 身分；錯根或舊 executable 可以在 JS 同 bytes 下失敗。
5. **browser 真實 workflow／外層不容換綁。** `.github/workflows/integration-tests.yml` 保留 native35、canvas35、assembly15、documents10、grid15、space15、timber20 分鐘，npm build、CJK、start_local 與 runtime probe。原 `workflow-driver-browser-workspace.py:58–68,215–217,235–236,357–359` 前後核 HEAD/root/status，讀指定 SHA workflow，設定 GITHUB_SHA/WORKSPACE；preparer `guard:200–216` 核 seed/private HEAD、乾淨樹、全 manifest 與私有 inode。改 launcher 常數或只驗測試 JS 相同不是執行證據；獨立 checkout／埠／tmp 仍須符合原規則。
6. **Q38 有非執行的來源摘要依賴。** `tests/section_profile_mutation_check.py:340–345,355–377` 的整份模型副本 hash 包含 D4；因此單以被執行方法名稱沒有 #314 就排除重跑，是可構造的漏判。
7. **§7 與 RC 確實記執行來源。** card runner `:30–32,106`；axiom runner `:77–80`。`/workspace/geo318-reading-a-prep/formal-tools/run_stage.py:43–48,58–81` 守 HEAD/clean 並 dispatch 原入口；`/tmp/train337-reading-a-sweep-plan/run_original_rc_method.py:44–60,72–75` 還核 env、原六份 Git blob、原方法與前後身分。不能把舊 `source_head` 字段改成 F；也不能只將四個 compiler diagnostic exit 0 當語意測試已跑。
8. **架構產物與裁判 pass 不同。** `tests/architecture_contract.py` 的 manifest 驗證／掃描與 `tests/test_product_architecture.py:23–41` 的 sources+exclusions snapshot，不等於重新檢驗 D2 所有 provenance。D1/D2 的更新來自另有原件的四檔組裝；本報告僅沿用已核收成果，不把報告文字自證為架構全綠。
9. **reader 已有真正 F 原件。** `geometry-guide/sync_axiom_reader.py:1921–1939` 與既有 F reader RESULT SHA256 `c4f253756cdb03d0f753c60b8a33b824104caa9cbd383f8e93f057a67a2fd94c`、actual peer `805e8a051614c2d9d47a2852998fe54f283f9b46515c0c4451fba1ec7763a6f9`。保全了 212 必要來源與五 fixtures；實際 timeout=None 仍如實保留，不把未使用的數值說成已執行時限。

外層工具精確位置（本輪唯讀，未執行）：

- browser driver：`/workspace/train337-browser-pool-L-7af8c5d8/workflow-driver-browser-workspace.py`。
- browser preparer：`/tmp/geo337-browser-single-job-split-preparation-20261025/browser_readonly_pool_preparer_split_single_job.py`。
- F9 launcher：`/tmp/geo337-F9-browser-launch-preparation-v2-20261025/launch_F9_browser.py`。
- native wrapper：`/tmp/native-final-executable-preparation/run_full_native_workflow_v2.py:77–85`；其 index guard 是 `git ls-files --stage -z` 摘要，不能與實體 index 檔 SHA 混稱。

## 不重抽樣、不可消失的失敗及尚缺原件

R8 源 `75a1e93811a52b69385cbdaf6a09d773ed9052ad` 的原 36 個效能樣本固定保留；不是同 F 實跑，**不重抽最好樣本**。原 outer exit 1 保留，雖各比例已在門檻內：N16/base 0.9834192453688345≤1，N32/base 0.9007932884873169≤1，N48/base 0.7392862448969592≤1，N64/main 1.2846970752586067≤1.3，calls64/32 4.407618425509266≤4.5。這些不替代 P-189 exact。

F9 exact 175 場景／350 列、outer/stage/audit 0 保持 F9 身分與原三差限定。GitHub 帳戶核實不等同留言中自述「本機 Claude 整理，非原話」段落已核為新的直接批准。未取得新原始批准，不改比較器或擴張沿用範圍。

可排除的無依據重測：再跑同 F reader／架構三條／帳本 check，或重產仍有效全 123；重取 R8 最好樣本。必做的實際缺口：完整 F native、Q38 受影響來源閉包；其餘 B 項先保留正式未驗，僅提交這份靜態分類供審查，沒有自行採用跨 SHA 豁免。

容量與正式工具八 focused／四組反證仍未閉合。本報告不配置新 checkout、不降低 admission 或 2 GiB 規劃守門、不改現有 source／index／cache；不以局部靜態工作包裝成產品 gate 通過。
