"""Capture one reviewed resource diagnostic with the unchanged recorder/reaper."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--tool', type=Path, required=True)
p.add_argument('--tool-sha256', required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--outer', type=Path, required=True)
a = p.parse_args()
own = Path('/dev/shm/geometry-axiom-geo337-20261025')
capfile = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
reaper = Path('/workspace/geo261-environment/reap_children.py')
def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert h(capfile) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(reaper) == '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
assert h(a.tool) == a.tool_sha256
assert a.outer.parent == own and not a.outer.exists()
assert a.output.parent == Path('/workspace') and not a.output.exists()
a.outer.mkdir()
(a.outer / 'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
spec = importlib.util.spec_from_file_location('capture', capfile)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           GEO261_REAPER_LOG=str(a.outer / 'reaper.jsonl'))
rec = cap.Recorder(a.outer, env, 'cbf0fb621888596aa14ad5f2349b503e23b1b72d')
argv = ['python3', '-B', str(reaper), 'python3', '-B', str(a.tool),
        '--execute', '--scheduler-slot', '1', '--output', str(a.output)]
row, stdout, stderr = rec.run(argv, cwd='/workspace', timeout=None, check=False)
result = {'exit_code': row['actual_process_returncode'], 'formal_acceptance': False,
          'source_sha': rec.sha, 'command': argv, 'tool_sha256': a.tool_sha256,
          'complete_raw_directory': str(a.outer),
          'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
          'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
cap.dump(a.outer / 'RESULT.json', result)
print(json.dumps(result))
raise SystemExit(row['actual_process_returncode'])
