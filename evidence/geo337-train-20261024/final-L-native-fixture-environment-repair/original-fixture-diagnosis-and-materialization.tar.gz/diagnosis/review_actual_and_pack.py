"""Read only completed materialization/raw and the three fixtures; no live C read."""
from pathlib import Path
import hashlib,io,json,tarfile
P=Path(__file__).parent;R=Path('/tmp/train337-323-f64d638f-source')
A=Path('/workspace/train337-native-L-three-fixtures-materialization');B=Path('/workspace/train337-native-L-three-fixtures-materialization-launch')
O=Path('/workspace/train337-native-L-fixture-environment-publication')
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not O.exists();O.mkdir()
checks=[]
def check(name,value):checks.append({'name':name,'passed':bool(value)})
diagnosis=json.loads((P/'DIAGNOSIS.json').read_text());before=json.loads((A/'BEFORE.json').read_text());after=json.loads((A/'RESULT.json').read_text());outer=json.loads((B/'RESULT.json').read_text());request=json.loads((B/'REQUEST.json').read_text())
check('actual_outer_terminal0',outer['actual_process_returncode']==0 and outer['ended_epoch'] and not outer['timeout_expired'])
check('all_actual_identities_L',outer['acceptance_sha']==outer['source_sha']==request['source_sha']==before['head']==after['sourceSHA']==L)
check('real_prior_source_mutator_released',request['cardref_original_terminal_exit']==0 and '--root-released' in outer['command'])
check('same_accepted_tool',h((P/'materialize_three_original_fixtures.py').read_bytes())==request['tool_sha256']=='2ff31df35fbddabccd132d812277b07b5dffbd5df27a28043a9b276429bbb8ed')
check('real_env_fix_only_not_test',after['environmentMaterializationOnly'] and after['subjectExecutions']==0 and after['originalFourENOENTNotRelabeledPassed'])
check('indexTree_preserved_but_flags_change_recorded',after['headAndCompleteIndexTreeUnchanged'] and after['rawIndexStatAndSparseFlagsExpectedToChange'] and before['indexSHA256']!=after['indexAfterSHA256'])
check('three_were_missing_originally',len(before['paths'])==3 and all(v['exists'] is False for v in before['paths'].values()))
expected={f['path']:f for f in diagnosis['fixtures']}
check('exact_three_results',set(expected)=={f['path'] for f in after['files']})
for f in after['files']:
 raw=(R/f['path']).read_bytes();e=expected[f['path']]
 check('fixture_bytes_'+f['path'],len(raw)==f['bytes']==e['bytes'] and h(raw)==f['sha256']==e['sha256'])
 check('fixture_original_public_oid_'+f['path'],f['gitBlob'] in e['GitTreeEntry'] and e['GitTreeEntry'].startswith('100644 blob '))
check('exact397952_bytes',sum(f['bytes'] for f in after['files'])==397952)
all_rows=[]
for label,root,index in (('inner',A/'commands','subcommands.json'),('outer',B,'subcommands.json')):
 rows=json.loads((root/index).read_text());all_rows+=rows
 for i,row in enumerate(rows):
  d=Path(row['directory']);check(label+'_terminal0_'+str(i),row['actual_process_returncode']==0 and row['ended_epoch'] and not row['timeout_expired'])
  for field,file in (('stdout','stdout.bin'),('stderr','stderr.bin')):
   raw=(d/file).read_bytes();check(label+'_'+field+'_hash_'+str(i),h(raw)==row[field+'_sha256'] and len(raw)==row[field+'_bytes'])
  raw=(d/'stdin.bin').read_bytes();check(label+'_stdin_hash_'+str(i),h(raw)==row['stdin_sha256'])
  check(label+'_source_L_'+str(i),row['acceptance_sha']==row['source_sha']==L)
inner=json.loads((A/'commands/subcommands.json').read_text())
head_results=[Path(r['directory'],'stdout.bin').read_bytes().decode().strip() for r in inner if r['command']==['git','rev-parse','HEAD']]
tree_results=[Path(r['directory'],'stdout.bin').read_bytes().decode().strip() for r in inner if r['command']==['git','write-tree']]
check('real_before_after_head_L',head_results==[L,L])
check('real_before_after_complete_index_tree',tree_results==[before['tree'],before['tree']])
check('only_sparse_add_original_three',len([r for r in inner if r['command'][:3]==['git','sparse-checkout','add']])==1)
check('no_subject_argv',[r for r in inner if r['command'][0]!='git']==[])
report={'schema':'independent-L-three-original-fixture-environment-materialization-actual/1','L':L,'checks':len(checks),'exitCode':0 if all(c['passed'] for c in checks) else 1,'findings':[c['name'] for c in checks if not c['passed']],'details':checks,'originalCommandCount':len(all_rows),'originalNativeR1':'unchanged exit1/Node733pass4ENOENT/0skip; a complete original native rerun still required','readScope':'Only completed requests/results/stdin/stdout/stderr and3 actual fixture bytes; no live ROOT C/source/index or SEED/pool read/write.','physicalModes':'Actual fixture permissions0o600 recorded by producer; Git mode100644 indicates regular non-executable blob, no false claim physical0644.','limits':['Current source lease belongs to §7; original before/after cleanL proof read from completed captured commands, not a new live clean check.','One earlier metadata read assumed outerreceipt.json and returned1; correct original outerRESULT.json is read here. No subject failed because of that reader assumption.']}
dump(O/'ACTUAL_PEER.json',report);assert report['exitCode']==0,report['findings']
sources={}
for label,root in (('diagnosis',P),('materialization',A),('outer',B)):
 for path in sorted(root.rglob('*')):
  rel=path.relative_to(root)
  if 'sparse-mechanics-only' in rel.parts:continue
  if path.is_file():assert not path.is_symlink();sources[label+'/'+rel.as_posix()]=path
sources['diagnosis/synthetic-sparse-mechanics-command-record.json']=P/'sparse-mechanics-only/RESULT.json'
peer=Path('/tmp/train337-adversarial/FINAL_L_THREE_FIXTURE_MATERIALIZATION_TOOL_PEER.json')
sources['tool-peer/'+peer.name]=peer;sources['actual-peer/ACTUAL_PEER.json']=O/'ACTUAL_PEER.json'
index={'L':L,'kind':'Original environment diagnosis and actual source materialization, not native test pass','members':[]}
archive=O/'original-fixture-diagnosis-and-materialization.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
 for name,path in sources.items():
  raw=path.read_bytes();st=path.stat();ti=tarfile.TarInfo(name);ti.size=len(raw);ti.mode=st.st_mode&0o777;ti.mtime=st.st_mtime;tf.addfile(ti,io.BytesIO(raw));index['members'].append({'member':name,'sourcePath':str(path),'bytes':len(raw),'sha256':h(raw)})
with tarfile.open(archive,'r:gz') as tf:
 assert tf.getnames()==list(sources)
 for m,row in zip(tf.getmembers(),index['members']):
  raw=tf.extractfile(m).read();assert raw==sources[m.name].read_bytes() and h(raw)==row['sha256'] and len(raw)==row['bytes']
index.update(archive=archive.name,archiveBytes=archive.stat().st_size,archiveSHA256=h(archive.read_bytes()),memberCount=len(sources),producerRoundtrip=True,actualPeerChecks=report['checks'],actualPeerExit=0)
dump(O/'INDEX.json',index)
print(json.dumps({'actualChecks':report['checks'],'exitCode':0,'INDEX':str(O/'INDEX.json'),'archiveBytes':index['archiveBytes'],'members':len(sources)},ensure_ascii=False))
