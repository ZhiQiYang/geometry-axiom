"""Finite literal dependency inventory from immutable L only; never execute JavaScript."""
from pathlib import Path,PurePosixPath
import ast,collections,hashlib,json,os,posixpath,re,subprocess
R=Path('/tmp/train337-323-f64d638f-source');O=Path(__file__).parent
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db';rows=[];cache={}
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1')
def h(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):
    p=subprocess.run(['git','-C',str(R),*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    rows.append({'argv':['git','-C',str(R),*args],'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':h(p.stdout),'stderr':p.stderr.decode(errors='replace')});assert p.returncode==0
    return p.stdout
tree={}
for row in git('ls-tree','-rlz',L).split(b'\0'):
    if row:
        meta,n=row.split(b'\t',1);mode,kind,oid,size=meta.split();tree[n.decode()]={'mode':mode.decode(),'blob':oid.decode(),'bytes':int(size)}
def source(name):
    if name not in cache:cache[name]=git('show',L+':'+name)
    return cache[name].decode(errors='replace')
runner=ast.parse(source('tests/run_all.py'))
node_roots=next(ast.literal_eval(n.value) for n in runner.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE_TEST_FILES' for t in n.targets))
static_require=re.compile(r'''require(?:\.resolve)?\(\s*(['"])([^'"\r\n]+)\1\s*\)''')
strings=re.compile(r'''(['"])([^'"\r\n]+)\1''')
by_basename=collections.defaultdict(list)
for n in tree:by_basename[PurePosixPath(n).name].append(n)
extensions={'.js','.cjs','.mjs','.json','.gcanvas','.scene','.pdf','.png','.jpg','.jpeg','.svg','.txt','.html','.css'}
def normalized(base,s):return posixpath.normpath(posixpath.join(base,s)).removeprefix('./')
def jsresolve(parent,value):
    if not value.startswith('.'):return None
    p=normalized(posixpath.dirname(parent),value)
    return next((n for n in (p,p+'.js',p+'.cjs',p+'.mjs',p+'.json',p+'/index.js') if n in tree),None)
results={}
for label,roots in (('node-tests-js',node_roots),('full-canvas-cdp',['geometry-web/cdp_test.js'])):
    todo=collections.deque(roots);seen=set();edges=[];inputs={};unresolved=[]
    while todo:
        name=todo.popleft()
        if name in seen:continue
        seen.add(name);text=source(name)
        for m in static_require.finditer(text):
            raw=m.group(2);target=jsresolve(name,raw)
            if raw.startswith('.') and not target:unresolved.append({'source':name,'line':text.count('\n',0,m.start())+1,'literal':raw})
            if target:
                edges.append({'source':name,'line':text.count('\n',0,m.start())+1,'target':target,'literal':raw})
                if PurePosixPath(target).suffix in ('.js','.cjs','.mjs'):todo.append(target)
                else:inputs.setdefault(target,[]).append({'source':name,'line':text.count('\n',0,m.start())+1,'literal':raw,'kind':'literal-require'})
        for m in strings.finditer(text):
            raw=m.group(2)
            if '\\' in raw or PurePosixPath(raw).suffix not in extensions:continue
            candidates=[]
            for p in (normalized(posixpath.dirname(name),raw),normalized('',raw)):
                if p in tree:candidates.append(p)
            # Exact conventional input directories disambiguate a literal basename.
            # Never associate an arbitrary generated basename with an unrelated Git file.
            if not candidates and "/" not in raw:
                candidates=[p for p in ("tests/fixtures/"+raw,"geometry-web/examples/"+raw) if p in tree]
            for p in set(candidates):
                if PurePosixPath(p).suffix in ('.js','.cjs','.mjs'):
                    # Non-require JS literals (e.g. vm source) are a conservative closure edge.
                    todo.append(p);edges.append({'source':name,'line':text.count('\n',0,m.start())+1,'target':p,'literal':raw,'kind':'other-literal-conservative'})
                else:inputs.setdefault(p,[]).append({'source':name,'line':text.count('\n',0,m.start())+1,'literal':raw,'kind':'other-literal-conservative'})
    names=sorted(inputs)
    flags={}
    if names:
        raw=git('ls-files','-v','-z','--',*names)
        for row in raw.split(b'\0'):
            if row:flags[row[2:].decode()]=row[:1].decode()
    result={'rootCount':len(roots),'roots':roots,'sourceCount':len(seen),'sources':[{'path':n,**tree[n],'sha256':h(cache[n])} for n in sorted(seen)],'edges':edges,'inputs':[{'path':n,**tree[n],'indexFlag':flags.get(n),'uses':uses} for n,uses in sorted(inputs.items())],'unresolvedLiteralRequires':unresolved}
    result['skipWorktreeInputs']=[i for i in result['inputs'] if i['indexFlag']=='S']
    results[label]=result
report={'schema':'L-original-Node-and-full-canvas-literal-input-census/1','sourceSHA':L,'subjectExecutions':0,'readOnly':True,'results':results,'gitCommands':rows,'limits':['Finite conservative literal require/resolve and string-path scan, not a JavaScript parser or dynamic execution; source may overinclude comment/generated-name matches.','Computed filesystem paths, network-delivered assets, conditions and dynamically composed modules are not proven by this scan. Full original suites remain the judges.','Skip-worktree is reported from Git index, not reinterpreted as a passing test or automatically missing file. Three named missing fixtures have independent real ENOENT and filesystem absence evidence.','No ROOT/source/index/SEED/pool/cache writes or subject execution.']}
(O/'LITERAL_INPUTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{'roots':v['rootCount'],'sources':v['sourceCount'],'inputs':len(v['inputs']),'skipWorktreeInputs':[i['path'] for i in v['skipWorktreeInputs']],'unresolvedLiteralRequires':v['unresolvedLiteralRequires']} for k,v in results.items()},ensure_ascii=False,indent=2))
