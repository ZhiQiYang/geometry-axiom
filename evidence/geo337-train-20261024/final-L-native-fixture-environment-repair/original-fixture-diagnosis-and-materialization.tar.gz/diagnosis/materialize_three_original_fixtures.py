"""Restore only three original L fixture materializations after the root lease is released."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
FILES={
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas':('c537fede64bbdb324d824d8b050070af00069f92',133167,'69f37d46587a98dc757cfbe16d0b0c4b44bd6da0a8746eab5627449823e2e007'),
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas':('c597dbc0d0b1ae8f8c089e9ae326e3b4e8c9cafe',133210,'3d5d3e19341356bad6a8b498cf75111e33a8bc61a4ef5c0c5dd615cbc12ffc0c'),
 'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas':('61f070ed4a9db6f3bfe5abc41cc9203ba0696fca',131575,'791089400a54bb3ec53f8dc94046fe292d712b77bb16696d45b8c3f3d3673db8')}
def h(raw):return hashlib.sha256(raw).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--root-released',action='store_true');a=ap.parse_args()
 assert a.root_released,'Root must explicitly release native/§7/source-mutator lease first'
 R=a.repo.absolute();O=a.out.absolute();assert R.resolve()==Path('/tmp/train337-323-f64d638f-source') and (R/'.git').is_dir(),'Only the private formal ROOT; never a readonly browser pool/SEED'
 assert not O.exists() and not O.is_relative_to(R) and not R.is_relative_to(O)
 O.mkdir(parents=True)
 C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py');assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
 spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1')
 for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR'):env.pop(k,None)
 rec=cap.Recorder(O/'commands',env,L)
 def git(*args,data=None):
  row,stdout,stderr=rec.run(['git',*args],cwd=R,data=data,timeout=120,check=False,source_sha=L,source_variant='environment-only-original-three-fixture-materialization')
  assert row['actual_process_returncode']==0,row['directory'];return stdout
 assert git('rev-parse','HEAD').decode().strip()==L
 assert git('status','--porcelain=v1','--untracked-files=all')==b'','Preserve a dirty or active ROOT; never reset it'
 tree=git('rev-parse','HEAD^{tree}').strip();assert git('write-tree').strip()==tree
 before={'head':L,'tree':tree.decode(),'indexSHA256':h((R/'.git/index').read_bytes()),'sparse':(R/'.git/info/sparse-checkout').read_text(),'paths':{n:{'exists':os.path.lexists(R/n)} for n in FILES}}
 (O/'BEFORE.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
 for name,(oid,size,digest) in FILES.items():
  raw=git('show',L+':'+name);assert len(raw)==size and h(raw)==digest
  assert git('ls-tree',L,'--',name).decode().startswith('100644 blob '+oid+'\t')
  if os.path.lexists(R/name):assert (R/name).is_file() and not (R/name).is_symlink() and (R/name).read_bytes()==raw
 # The original sparse pattern remains intact; only these exact three paths are appended.
 git('sparse-checkout','add','--stdin',data=('\n'.join('/'+n for n in FILES)+'\n').encode())
 after=[]
 for name,(oid,size,digest) in FILES.items():
  p=R/name;assert p.is_file() and not p.is_symlink();raw=p.read_bytes();st=p.stat();assert len(raw)==size and h(raw)==digest
  after.append({'path':name,'gitBlob':oid,'bytes':size,'sha256':digest,'mode':oct(st.st_mode&0o777),'allocatedBytes':st.st_blocks*512})
 assert git('rev-parse','HEAD').decode().strip()==L and git('write-tree').strip()==tree
 assert git('diff','--name-only')==b'' and git('diff','--cached','--name-only')==b'' and git('status','--porcelain=v1','--untracked-files=all')==b''
 report={'sourceSHA':L,'subjectExecutions':0,'environmentMaterializationOnly':True,'headAndCompleteIndexTreeUnchanged':True,'rawIndexStatAndSparseFlagsExpectedToChange':True,'indexAfterSHA256':h((R/'.git/index').read_bytes()),'files':after,'originalFourENOENTNotRelabeledPassed':True,'result':'Three exact original Git fixtures present; formal suite still requires original rerun.'}
 (O/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
