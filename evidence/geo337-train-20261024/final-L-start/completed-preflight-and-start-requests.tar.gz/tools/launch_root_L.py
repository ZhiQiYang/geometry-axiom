from pathlib import Path
import hashlib,importlib.util,json,os,sys
F="7af8c5d80d34cb4f49d01ba67deb78a3a6d725db"
DRIVER=Path("/tmp/train337-ledger-L-prep/run_root_full_ledger_at_L.py")
PREP=Path("/tmp/train337-ledger-L-prep/PREPARATION.json")
INDEX=Path("/workspace/geo337-ledger-b6-terminal-publication/INDEX.json")
OUT=Path("/workspace/train337-ledger-L-7af8c5d8-launch")
CAPTURE=Path("/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py")
JOB=Path("/workspace/train337-ledger-L-7af8c5d8")
CACHE=Path("/workspace/train337-ledger-cache-L-7af8c5d8")
TEMP=Path("/workspace/train337-ledger-L-7af8c5d8-tmp")
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(DRIVER)=="620a3cd27bb7f3aceaa6e3cadf1e6ada416d2000a73cc2a89f2c9d6f8d4a20e9"
assert h(PREP)=="662b548d855120ff298accf15521ec9139c96f34e38bc38c18aa7c17072e1a98"
assert h(INDEX)=="3878f6f93d0db149b7ac78873fd0e343a9c30d2ec4e188e89bc28acd215aa5d4"
assert h(CAPTURE)=="c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762"
assert not any(p.exists()for p in(OUT,JOB,CACHE,TEMP));OUT.mkdir()
spec=importlib.util.spec_from_file_location("original_L_capture",CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in("NODE_OPTIONS","PYTHONOPTIMIZE"):env.pop(key,None)
env["PYTHONDONTWRITEBYTECODE"]="1"
argv=[sys.executable,"-B",str(DRIVER),"--sha",F,"--job",str(JOB),"--cache",str(CACHE),"--tmp",str(TEMP),"--old-terminal-index",str(INDEX),"--old-terminal-index-sha256","3878f6f93d0db149b7ac78873fd0e343a9c30d2ec4e188e89bc28acd215aa5d4"]
r=cap.Recorder(OUT,env,F)
cap.dump(OUT/"launch-context.json",{"source_sha":F,"driver_sha256":h(DRIVER),"preparation_sha256":h(PREP),"old_b6_terminal_index_sha256":h(INDEX),"launcher_sha256":h(Path(__file__)),"argv":argv,"outer_timeout":None,"job":str(JOB),"cache":str(CACHE),"seed":str(CACHE/"_bridge-work"/F/"repo"),"free_bytes":{p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in("/workspace","/tmp")},"purpose":"Root-owned original complete123 at immutable L, fresh external RESULTS; exact b6 tracked JSON adopted without rewriting old execution heads; original builder/cache policy unchanged"})
row,out,err=r.run(argv,cwd="/workspace",timeout=None,check=False,source_sha=F,source_variant="root-owned-full-L-ledger-external-orchestrator")
cap.dump(OUT/"receipt.json",{"source_sha":F,"driver_sha256":h(DRIVER),"command":row,"exit_code":row["actual_process_returncode"]})
sys.stdout.buffer.write(out);sys.stderr.buffer.write(err)
raise SystemExit(row["actual_process_returncode"])
