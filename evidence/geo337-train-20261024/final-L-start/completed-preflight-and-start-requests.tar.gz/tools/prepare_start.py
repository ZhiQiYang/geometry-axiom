"""Archive only immutable completed L preflight1..39; never inspect live command40/observer/RESULTS."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile

F='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
JOB=Path('/workspace/train337-ledger-L-7af8c5d8')
LAUNCH=Path('/workspace/train337-ledger-L-7af8c5d8-launch')
TOOLS=Path('/tmp/train337-ledger-L-prep')
OUT=Path('/workspace/geo337-ledger-L-7af8c5d8-start-publication')
def h(body):return hashlib.sha256(body).hexdigest()
def need(ok,why):
    if not ok:raise RuntimeError(why)
def main():
    need(not OUT.exists(),'fresh start-publication output required')
    ready=json.loads((JOB/'root-ready-identity.json').read_bytes());seed=json.loads((JOB/'seed-ready-identity.json').read_bytes())
    need(ready['head']==seed['head']==F,'completed ready identities bind L')
    last=json.loads((JOB/'subcommands/000039/result.json').read_bytes())
    need(last['acceptance_sha']==last['source_sha']==F and last['actual_process_returncode']==0 and last.get('ended_epoch')and last['command'][-3:]==['-B','tests/mutate.py','--check'],'original tracked check39 truly completed0')
    launched=json.loads((JOB/'full-launch-request.json').read_bytes())
    need(launched['sourceSHA']==F and launched['full_environment_explicit']['GITHUB_SHA']==F,'fixed full-launch request')
    moves=json.loads((JOB/'ARTIFACT_PAIR_RELOCATION.json').read_bytes());metadata=json.loads((JOB/'OLD_ARTIFACT_METADATA_PATHS.json').read_bytes())
    need(len(moves['core'])==68 and len(moves['bridge'])==107 and len(metadata)==175,'completed175 artifact-pair moves/retained metadata')
    prep=(TOOLS/'PREPARATION.json').read_bytes();need(h(prep)=='662b548d855120ff298accf15521ec9139c96f34e38bc38c18aa7c17072e1a98','accepted tool prep pin')
    files=[]
    names=('request.json','full-launch-request.json','before-original-raw.json','before-consumers.json','immediate-before-move-consumers.json','immediate-before-artifact-pair-move-consumers.json','root-before-identity.json','seed-before-identity.json','root-ready-identity.json','seed-ready-identity.json','ARTIFACT_PAIR_RELOCATION.json','OLD_ARTIFACT_METADATA_PATHS.json')
    for name in names:files.append(('completed-preflight/'+name,JOB/name))
    for number in range(1,40):
        folder=JOB/'subcommands'/('%06d'%number);row=json.loads((folder/'result.json').read_bytes())
        need(type(row['actual_process_returncode'])is int and row.get('ended_epoch')and not row['timeout_expired'],'only truly completed command '+str(number))
        for p in sorted(folder.iterdir()):
            if p.is_file():files.append(('completed-preflight/subcommands/'+folder.name+'/'+p.name,p))
    preserved=JOB/'preserved-old-artifact-metadata'
    for original,target in sorted(metadata.items()):
        p=Path(target);need(p.is_relative_to(preserved),'only copied historical sidecar inside JOB')
        files.append(('completed-preflight/preserved-old-artifact-metadata/'+str(p.relative_to(preserved)),p))
    for name in ('before-old-b6-current_geometry.svg','before-old-b6-receipt.json'):
        p=JOB/'generated-outputs'/name
        if p.is_file():files.append(('completed-preflight/generated-outputs/'+name,p))
    for name in ('launch-context.json','subcommands/000001/request.json','subcommands/000001/stdin.bin'):
        files.append(('outer-start-request/'+name,LAUNCH/name))
    files.append(('tools/PREPARATION.json',TOOLS/'PREPARATION.json'))
    for item in json.loads(prep)['files']:
        p=TOOLS/item['name'];need(h(p.read_bytes())==item['sha256'],'accepted static tool drift '+item['name']);files.append(('tools/'+item['name'],p))
    for name,path,pin in [('capture.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py','c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'),('reap_children.py','/workspace/geo261-environment/reap_children.py','7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'),('launch_root_L.py','/tmp/train337-ledger-L-launch-7af8c5d8.py','fc5d6bb549e3fc1327538982fab41be960a2b57dd5bea89e46359796cd96aecb')]:
        p=Path(path);need(h(p.read_bytes())==pin,'actual original tool pin');files.append(('tools/'+name,p))
    files.append(('tools/prepare_start.py',Path(__file__).resolve()))
    need(len(files)==len({name for name,_ in files}),'unique member names')
    OUT.mkdir();archive=OUT/'completed-preflight-and-start-requests.tar.gz';members=[];payloads={}
    with tarfile.open(archive,'w:gz')as tar:
        for name,p in files:
            need(not p.is_symlink()and stat.S_ISREG(p.lstat().st_mode),'immutable regular original only '+str(p))
            before=p.stat();body=p.read_bytes();after=p.stat();need((before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns),'preflight raw changed')
            need(not body.startswith(b'\x7fELF'),'no ELF payload')
            digest=h(body);info=tar.gettarinfo(str(p),arcname=name);key=(len(body),digest,info.mode);canonical=payloads.get(key)
            if canonical is None:payloads[key]=name;tar.addfile(info,io.BytesIO(body))
            else:info.type=tarfile.LNKTYPE;info.linkname=canonical;info.size=0;tar.addfile(info)
            members.append({'path':name,'source':str(p),'bytes':len(body),'sha256':digest,'payload_member':canonical or name})
    with tarfile.open(archive)as tar:
        need(len(tar.getmembers())==len(members),'full member count')
        for row in members:
            body=tar.extractfile(row['path']).read();need(len(body)==row['bytes']and h(body)==row['sha256']and Path(row['source']).read_bytes()==body,'full source/tar bytes roundtrip')
    index={'schema':'geo337.final-L-start-not-terminal/1','source_sha':F,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'STARTED / NOT FINISHED','finished':False,'original_cli_exit':None,'root_wrapper_exit':None,'final_record_count':None,'root_reported_launch_utc':'2026-10-23T22:25:15Z','root_reported_session':56927,'completed_preflight_commands':39,'original_tracked_check39_exit':0,'root_ready':ready,'seed_ready':seed,'completed_artifact_pairs':175,'historical_sidecars_retained':175,'full_launch_request_captured':True,'live_observer_excluded':True,'live_RESULTS_excluded':True,'incomplete_command40_excluded':True,'outer_live_stdout_stderr_result_excluded':True,'duplicate_raw_storage':'Byte-identical payloads use ordinary backwards tar hardlink entries; every original member name/hash/full bytes remains reconstructible and extractfile-roundtrip verified. No filesystem/source hardlinks created.','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':h(archive.read_bytes()),'logical_original_bytes':sum(x['bytes']for x in members),'unique_payload_bytes':sum(k[0]for k in payloads),'members':members,'limits':'Only fixed completed preflight files and immutable outer start requests are included. No source/cache/ELF/Git/observer/RESULTS/current aggregate command file or command40 was read or copied. Initial request passed=false/phase lists are initialization snapshots, not terminal failure. This package does not claim fullCLI/native/browser/specials completion.'}
    (OUT/'INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'out':str(OUT),'index_sha256':h((OUT/'INDEX.json').read_bytes()),'members':len(members),'logical_original_bytes':index['logical_original_bytes'],'unique_payload_bytes':index['unique_payload_bytes'],'archive_bytes':index['archive_bytes'],'archive_sha256':index['archive_sha256'],'state':index['state']},ensure_ascii=False))
if __name__=='__main__':main()
