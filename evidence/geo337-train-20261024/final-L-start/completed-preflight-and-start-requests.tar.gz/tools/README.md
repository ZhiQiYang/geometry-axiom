# final L 全帳本：僅準備，由 root 執行

本工具尚未執行。先讓 b6 (`b6e1e45425f055cd825b259f46ef2c454f3ff13a`) 原輪真正完整 123 並通過；root 將它的外部原 JSON 不改字採入可解析的 L，再以本工具在 L 真跑完整 CLI。L 的 tracked 帳本仍保存 b6 真 execution.head；本輪新的外部帳本自然記 L，只封存到 evidence E，不能反覆改 L 或改舊 record.head。

執行者必先核專職 peer 接受的 driver/PREPARATION hash、b6 root/observer 雙終態、完整原件 INDEX 與磁碟。現有 ROOT/SEED 在 b6 仍執行時絕不可動。此工具要求舊輪 123、unrun 0、原 CLI 0、root 0；不接受部分輪或人工填補。

## 明確路徑與未來命令

ROOT 固定 `/tmp/train337-323-f64d638f-source`；舊 CACHE `/workspace/train337-ledger-cache-b6e1e454`；舊 SEED 是該 CACHE 下 `_bridge-work/<完整 b6>/repo`。永久保留 alternate parent `/workspace/geo314-train-f64d638f-m121/source/.git/objects`。ROOT 與舊 SEED 執行前都必須仍為乾淨 b6，L object 已可解析。

root 取得 L 後，將下面三個 `<L8>` 與 `<L>` 代入並以既有 c387 最外層 recorder 保存完整 argv、env、stdout、stderr、原結束碼；不新增外層 timeout：

```sh
env -u NODE_OPTIONS -u PYTHONOPTIMIZE python3 -B /tmp/train337-ledger-L-prep/run_root_full_ledger_at_L.py \
  --sha <完整L> \
  --job /workspace/train337-ledger-L-<L8> \
  --cache /workspace/train337-ledger-cache-L-<L8> \
  --tmp /workspace/train337-ledger-L-<L8>-tmp \
  --old-terminal-index <完整b6終態INDEX.json路徑> \
  --old-terminal-index-sha256 <該INDEX的SHA256>
```

新 SEED 最終路徑為 `/workspace/train337-ledger-cache-L-<L8>/_bridge-work/<完整L>/repo`。CACHE 必須與舊 CACHE/SEED 同檔案系統；JOB/TEMP 可以選 `/tmp` 的獨立新路徑分散空間，但實際代入值和 df 必須錄製。三者不得已存在、彼此或與舊 raw/source/cache/tools 重疊。不要新 clone 或建立可寫 source 硬連結。

若 L object 缺失，只能在 b6 原輪真正終態後，由 root 另錄製以下 object-only fetch，再核 refs/HEAD/index 沒變；本 driver 不自行 fetch、不改 live refs/FETCH_HEAD：

```sh
git -C /tmp/train337-323-f64d638f-source fetch --no-tags --no-write-fetch-head /workspace/geometry-axiom <完整L>
git -C /workspace/train337-ledger-cache-b6e1e454/_bridge-work/b6e1e45425f055cd825b259f46ef2c454f3ff13a/repo fetch --no-tags --no-write-fetch-head /workspace/geometry-axiom <完整L>
```

## 原件 INDEX 與嚴格來源契約

沿 root 既有 terminal INDEX schema：`source_sha, original_cli_exit, root_wrapper_exit, completed_utc, record_count, expected_record_count, unrun_count, verdicts, members`；每 member 有絕對 `source`、`bytes`、`sha256`。INDEX 必須涵蓋已生成的原命令 streams、metadata、工具和 sidecars，並固定 hash。此角色是原件保全 map，不能包含將合法重用/重編的 ELF 作為不可變 raw；完整 ELF 另用 artifact pair inventory 保存身份與原封包。若實際 INDEX 含 ELF，先向 root/peer 釐清 map，不過濾或暗改 INDEX。舊原 smoke、streams、locks 都留原目錄。

driver 同時保留歷史 M121/F64 raw INDEX pin。所有歷史原 sidecar 先完整 copy2 到新 JOB 的 `preserved-old-artifact-metadata/`，之後舊 raw guard 永遠讀此歷史副本，新 CACHE sidecar 仍交原 builder 正常判斷。舊 streams 不跟到新 CACHE，避免原 CLI 覆寫同名 stdout/stderr。

b6 必為 L ancestor，完整 tree diff 只准 `tests/mutants_results.json` 與 `evidence/`，且前者必改。L 在 ROOT/SEED 中的 tracked JSON 必須逐 byte 等 b6 外部 RESULTS。任何額外 docs、JS、Python、模板等差異都會拒絕；需另明列窄 diff 與 peer，不能靠副檔名排除。tracked `--check@L`、完整 CLI、原 core raw verifier、外部新 JSON `--check@L` 四個原程序都須 0。

## cache 移址與完整原裁判

保持原 123 definitions／原 timeouts／原 observer/verifier／所有 verdict/threshold。新的 `MUTATE_RESULTS` 必不存在；完整 CLI 不傳 ID。70 core（含 3 retired 判斷）及 53 bridge 全部重新判定，120 個實際 execution.head 必自然為 L，3 retired 不造 execution。原可接受 crashed 分類仍由原 CLI 處理。driver 取原 R3 nonblocking lock 與 16 MiB stack；native 若並行，必用另一實體 source checkout，不能碰此 ROOT/SEED。

175 個 artifact pair 只移其 ELF+sidecar：68 core（baseline+67 nonretired）與107 bridge（1 baseline+53×mutant/restored）。每 pair 先驗 bytes/hash/原 sidecar credential，ELF nlink 必為 1，再在同 FS 逐檔 rename，核 dev/inode/mode/mtime/size/nlink/hash 全不變；原 raw/smoke/lock 不搬。舊 SEED 同 FS rename 到新 L-key 路徑，普通 detached checkout L，保 refs/alternates/sparse bytes。不得先刪或 clone seed。

core compile fingerprint 使用 portable 原命令及 C/H/inc 內容，不含 HEAD 或 RESULT JSON；bridge 原 `binaries.py` fingerprint 亦不含 HEAD，stored ELF credential 用 SHA256/size/mtime。HEAD 僅參與 bridge-work/baseline 路徑和 execution 記錄。因此 b6→L 的 ledger/evidence-only 改動允許移址重用；仍真呼叫原 builder/53 bridge oracle，只有其原 fresh/reused 判決可證命中。不得強制跳編譯或沿用 verdict。合法 miss 仍照原工具編譯並保所有輸出。

## 磁碟預算與交還

不假定 workspace 有 200 MiB：最近只183 MiB，b6 尚增長。same-FS move 的175 pair資料與約147–153MB SEED增量均為0；68 core pair舊實測61,507,002 logical bytes／61,833,216 allocated bytes，不需再複製。107 bridge的終態總量尚未知，不能讀 live cache 估成已核值。

新增歷史 sidecar 副本約2.5MB（core35,130B，加107份約23KB，真精確量等 b6 終態 stat）；新 RESULTS、observer、53 bridge streams、可能合法 miss 的編譯峰值仍需餘量。舊108-row JSON 8,272,594B不是123-row上限。root 應以完整 b6 終態 JOB/raw/JSON 實測及當前 df 分配 JOB/TEMP，另計並行 native 的私有 build 峰值；不足就修容量，不改原 assertions 或少跑。不得把原件/cache 搬移當成免除新 raw 空間。

只有本輪真終態、raw/source guards 全過且 root 明確 release 後，新 SEED 才可成為 browser readonly pool 的來源；執行中不租給任何 consumer。未交還前，noWood/browser preparer 不得 checkout、建 pool 或讀取會競爭的整樹。原 b6 與本輪的 source/ledger/evidence SHA 分欄報告，不把 E 冒作 execution L。
