#!/usr/bin/env python3
"""完成驗收後列出可封存檔案；不壓縮、不commit/push、不啟動驗收。"""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description='依白名單列出GEO-323原始收據；不複製工作樹或執行檔')
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--manifest', required=True, type=Path)
    args = parser.parse_args()
    root = args.out.resolve()
    patterns = ('receipt.json', 'control/**', 'invocations/**', 'evidence/**',
                'tools-frozen/**', 'work/*/build.json')
    paths = set()
    for pattern in patterns:
        candidates = (root / pattern[:-3]).rglob('*') if pattern.endswith('/**') else root.glob(pattern)
        paths.update(path for path in candidates if path.is_file())
    included, excluded = [], []
    for path in sorted(paths):
        with path.open('rb') as handle:
            elf = handle.read(4) == b'\x7fELF'
        digest = hashlib.sha256()
        with path.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
        row = {'path': path.relative_to(root).as_posix(), 'absolute': str(path),
               'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
        if elf:
            row['reason'] = 'ELF只存hash；完整命令、輸出與來源證據仍封存'
            excluded.append(row)
        else:
            included.append(row)
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps({'schema': 'geo323-publication-file-selection/1',
        'root': str(root), 'patterns': patterns, 'files': included, 'excluded_elf': excluded,
        'not_copied': ['work/source-base/**', 'work/source-main/**', 'work/*-trace/source/**',
                       'work/*/bridge', 'work/*-pg/bridge'],
        'archive_stdout_preserved': 'invocations/**/commands/*/stdout.bin內原Gitarchive tar輸出必封存，不能把它當工作樹刪掉。',
        'not_acceptance_gate': True}, ensure_ascii=False, indent=2) + '\n')
    print(f'只讀選檔完成：{len(included)}檔；未壓縮、commit或push。', flush=True)


if __name__ == '__main__':
    main()
