# #323 Linux 驗收工具包（已準備，未執行）

本工具包只完成原版保存、機械適配、CLI、收據與語法檢查，沒有產品、編譯、測試、benchmark 或 Git 寫入結果。受驗 SHA 必須由 root 固定後填入；沒有預填新結果。原版、精確 diff 與 before/after hash 分別在 `original/`、`*.diff`、`ADAPTATION.json`。

固定原 base 為 `546e2eb2142ebf19859489c5391b57cbb8413d10`，main 為 `adbaebf9c73ea6801d7b4d5214e4b846b132923b`。需要 Linux、Python 3（含 tarfile data filter）、GNU gcc/gprof、Git、Node 及乾淨的受驗 checkout；兩個固定比較 Git 物件須已存在。工具不 clone、checkout、fetch、commit、push，也不變更產品或原裁判。

## 執行方式

以下命令等 root 正式固定新 SHA 後才執行。`GEO323_SOURCE_SHA` 應設為真正完整的 40 位 SHA；repo/out/lock 由呼叫端指定。out 與 lock 必須在 repo 外，out 不得混用不同來源或工具 bytes。

```sh
python3 -B /workspace/geo323-acceptance-tools-v2/run.py \
  --repo /tmp/g261-next323 --sha "$GEO323_SOURCE_SHA" \
  --out /tmp/geo323-final-round1 --heavy-lock /tmp/geo323-heavy.lock --stage all
```

`run.py` 自動透過原 `reap_children.py` 啟動子程序。只有 inner 取得 `heavy-lock`，外層不重複持鎖；不可再用外層 flock 包同一把鎖。stack soft 設 16 MiB，hard 保留；hard 不足時照實環境失敗。Python optimize 直接拒絕，避免原 assert 被停用。每個 command 有原 argv/cwd/env/SHA/起訖時間/原 exit/timeout/stdin/完整 stdout 與 stderr；Git archive 的完整 stdout tar 也原樣保留。

也可以用同一 out 逐 stage 各跑一次；不要先跑 all 再重跑相同 stage。每個已建立 stage 一律拒絕覆寫。需要環境修復後重試時，另開新 out，原紅收據保留。

```sh
python3 -B /workspace/geo323-acceptance-tools-v2/run.py --repo /tmp/g261-next323 \
  --sha "$GEO323_SOURCE_SHA" --out /tmp/geo323-final-round1 \
  --heavy-lock /tmp/geo323-heavy.lock --stage prepare
```

其他 stage 為 `build`、`compare`、`perf`、`profile`、`required-eight`、`pf3`、`native`。all 依此完整順序執行；獨立 stage 發生紅燈後仍收其他項，缺必要產物的項目明列前置失敗。`--stage native` 跑完整原 `python -B tests/run_all.py --build`；required-eight 跑原七套加 load_residual；pf3 跑完整原19 mutants工具（不縮 CASES）。兩種 run_all 的完整 suite logs 各另保存，紅燈與允許的 GDI skip 依原結果呈現，不套歷史數字。

## 原方法與結果界線

- prepare 以唯讀 Git archive 建 base/main 的原 C 範圍小 source tree，fix 直接用指定乾淨 worktree；完整 archive stdout、scope、排除路徑與逐檔 hash 入收據。沒有 full clone。171 個根 scene 名稱與 bytes 對照原 base，另以原 mini_gen 產生 N16/32/48/64，完整175，不縮水。
- build 沿用原 `gcc -std=c11 -O2 ... -lm`，base/fix/main 三個原 build 與 base/fix 兩個 trace build。TRACE、hooks、序列化、guards 原 bytes 未改；五個插入檔另存原／插入後 diff。
- compare 原175個場景各跑 base/fix 的原 loadfile+dump 和 trace，共350組。A 是完整 stdout bytes；B 是**每次 seal 的完整有序 node/edge/descriptor/value**；C 是**每 scene/process 的五 guard 總數**，不是每 seal 五計數。原 audit 的 stdout/stderr/graph/guards 四元組也從保存 raw 核對。拒絕場景仍比較原回覆，不假稱全部載入成功。
- perf 原順序是每個 N、每輪 **base→fix→main**，N16/32/48/64各3輪，共36筆；原 loadfile timeout600秒、只 load 不 dump、取中位數。沒有挑樣或逆序改法。原 verify 本身只輸出數字，不含1.3/4.5斷言。
- profile 使用 #323 原實跑 `-O1 -fno-inline -pg`，base/fix各 N32/N64 一次，獨立 cwd，loadfile無dump、完整 gprof與gzip gmon保留。原 profile **沒有 timeout**。不混用 handoff 另一支有 frame-pointer/timeout 的腳本，也沒有虛填 main profile。
- profile flat 以原 finalize 的規則擷取六個既定 symbols：7欄且末欄具名時取第4欄 calls；沒有 flat call record 時沿原規則列0，另外明列 missing symbol與原匹配行。`geo_eval_source` 分母0時比率/target_met留 null，不能算達標。
- 原 PROMPT-B 的 N64 fix/main≤1.3、fix 的 `geo_eval_source(N64)/N32≤4.5`，以及 N16/32/48相對固定變更前 base不變慢，各自列 actual/target_met。這些是原需求的衍生目標判定，不改原 verify/profile judge，也不使用 #288 的2×。CLI wrapper 若原命令紅或已量測目標未達，回1；原 command exit0仍原樣保留，不改成性能程序紅。只跑部分 stage 時 `full_acceptance_passed=null`。

每 stage 前後都唯讀檢查 HEAD=指定SHA、status空；不符合時保留原現況，不自行 reset。完整 stage/targets/環境摘要在 out/receipt.json；每次 invocation 原命令與 raw 在 out/invocations/，外層及回收事件在 out/control/。

## 收集與白名單

驗收全部完成、計時結束後，可執行純收集命令：

```sh
python3 -B /workspace/geo323-acceptance-tools-v2/select_outputs.py \
  --out /tmp/geo323-final-round1 --manifest /workspace/geo323-final-files.json
```

只列 `receipt.json`、`control/**`、`invocations/**`、`evidence/**`、`tools-frozen/**`、`work/*/build.json`。輸出逐檔 bytes/hash/路徑；ELF另列hash不封存。完整 ABC raw/graphs、36原輸出、四個完整 gprof/gmon、原 run_all suite logs／PF3 receipts 及所有 Git archive stdout 都在白名單內。source工作樹與 binaries不封存；本工具不 tar、不 commit、不 push。選檔是整理資料，不是新增裁判。

最終原資料均尚未產生。維護者 WSL 重測仍是原 PROMPT-B 明列的性能準據；雲端結果要如實列，不能把未達目標改寫成通過。

## v2 可選原執行JSONL

v1完整保留於 `/workspace/geo323-acceptance-tools/`。v2只對native／required-eight的原命令環境設定三個GEO261_*_EXECUTION_LOG，指向各自 `evidence/<kind>-executions/{host-facts,contact-sources,load-residual}.jsonl`，並將三值納入safe_env。原child提供的baseline／mutant／restored stdout、stderr、exit原樣保存；placement single的原0也保留，不能當作killed。沒有新增test_entry或subprocess monkeypatch，也未更改任何驗收命令、順序或目標。JSONL自然包含於既有evidence白名單。原v1逐檔hash與精確diff見 `V1_BASELINE.json`／`V1_TO_V2.diff`。
