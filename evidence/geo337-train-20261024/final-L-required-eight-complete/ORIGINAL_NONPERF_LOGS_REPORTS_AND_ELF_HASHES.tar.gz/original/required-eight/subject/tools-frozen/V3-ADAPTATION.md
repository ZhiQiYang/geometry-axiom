# 新整合基底的機械適配（未執行）

原 v2 固定舊 base `546e2eb2`，不適用本輪 #323 最終同步。v3 只把 base／main 改為必填的完整 SHA 參數，逐命令 provenance 與重用 out 守門一併綁定；不改 `verify_linux.py`、`profile_linux.py`、TRACE、175 場景方法、36 樣本順序、原 timeout 或數值門檻。

本工具已準備，沒有執行編譯、測試或量測。先等 #288 最終產品來源，普通 merge 到 #323；最後固定含帳本／架構的乾淨 F，再填入真正的 base／main／F。不能直接使用本文件範例作驗收結果。

```sh
python3 -B /tmp/geo323-merge-20261023/acceptance-tools-v3/run.py \
  --repo /tmp/g261-next323 --sha "$GEO323_FINAL_SHA" \
  --base "$GEO323_FINAL_BASE_SHA" --main "$GEO323_MAIN_SHA" \
  --out /tmp/geo323-postmerge-final-r1 \
  --heavy-lock /tmp/g261r3/heavy.lock --stage all
```

只能在 root 排程的獨占槽執行。可逐 stage 一次；既有輸出不可覆寫，不自動 retry 或重抽。完整 native 的 mutation／architecture 在最後來源未更新前會如實紅，不能拿掉兩個 suite。

原 root 171 場景 inventory 仍與指定新 base 比較，另有原 mini_gen N16／32／48／64；若 inventory 變化則原守門直接失敗，不偷偷換回舊 base。所有原 stage、trace、graph／guards 與 profile 規則照留。原 gate N64 fix/main ≤1.3、fix source64/source32 ≤4.5、小 N 對 base 不變慢皆未改。
