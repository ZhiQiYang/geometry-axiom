# 最終 L 原專項：僅準備，尚未執行

此 launcher 只綁定原 Q38、§7 compiled/axiom、#323 required-eight 與 PF3。原 subject、assertions、counts、child timeouts 均不改；P52/P-189 已另備，這裡不重做。`REQUESTS.json` 列出完整原 argv、輸出與互斥範圍。`--sha` 必須明確給 L，不能以移動分支或歷史 execution SHA 代入。

root 先核凍結 PREPARATION 與 peer 接受的 hash。只用 root 已交還、乾淨 L、實體 `.git/` 的獨立 checkout；不是 browser readonly pool，也不能是 ledger 的活 ROOT/SEED。launcher 不建立或複製新全來源，不 checkout/reset/clean，不自行修紅或重試。工具只在執行時呼叫原 c387/reaper；此準備階段僅 AST/小檔 hash。

```sh
env -u NODE_OPTIONS -u PYTHONOPTIMIZE python3 -B /tmp/train337-final-nonperf-specials-prep/run_original_specials.py \
  --gate all \
  --repo <root已獨占交還的乾淨L實體checkout> \
  --sha <完整40位L> \
  --out /workspace/train337-final-specials-<L8> \
  --heavy-lock /tmp/g261r3/heavy.lock \
  --preparation-sha256 <本目錄PREPARATION.json的SHA256>
```

也可 `--gate q38|cardref|axiom|required-eight|pf3` 逐項排程，每次使用全新 out。root 用既有 c387 最外層包住完整代入 argv，確保連啟動/preflight 紅也有原 exit/stdout/stderr。外層 timeout=None；不加重抽、數值門檻或新 timeout。

`all` 依上表順序各跑一次，任何原紅保存後繼續其他專項。Q38 prerequisite model-base 編譯紅時，Q38 subject 明載未跑，不假造結果。若 §7 異常未能還原 source，後續 gate 的 clean-L 守門會紅、不得在污染來源繼續編譯；不 reset 掩蓋。每項有原命令與真 exit、獨立 source before/after、完整 c387 streams；總體 passed 需要本次所有項目原命令 0 且原 source/index/refs 還原。#323 額外保原 stage/wrapper 兩碼，舊紅不混到另一新 out。

## 執行互斥與寫入

- **§7 compiled、axiom 會暫改原 checkout**，分別寫其 mutation table 列出的 C/H/inc 或 `geometry-core/modeling/__init__.py`，原 finally 逐 byte 還原；必獨占該 checkout，不能與 native、ledger、browser 或其他 source consumer 並行。compiled 每個原 compiler/test child180s；axiom 每個原 unittest180s，baseline/restored 全44、5個原具名 mutant，皆由原 judge 判斷。不是只挑子集。
- **Q38 不改原 checkout**，原工具把 C/H/inc、模型 Python/axiom/fixtures 複製到 private TMPDIR，再對副本做 native+model 全 registry；原 compile600s、test900s、model adapter build900s不變。先原 build model-base 到 private `q38-bin` 並設定 `GEOMETRY_MODEL_BASE`，不用共享 native 二進位。完整原 baseline/declared equivalent/exception evidence 保留，沒有 only/group/explore。
- **PF3 不改原 checkout**，原工具建立 baseline+19 mutants+restored 的21份必要 disposable C source，原 jobs1、每 child900s；baseline/restored全20，19個負控須真 named assertion，不能將 compile/crash/timeout 算 kill。這些原 copy/build 都會寫在本次 output，不是 launcher 偷建 full clone。
- **required-eight 沿原 run_all build/cache/log**，八指定 suite 的原登記數為14/18/5/4/24/432/166/13，合計676；runner 可列其原依賴 suites，不能把676冒稱整份 native。原 Python suite1200s、C/core等900s及原 builder政策不變。它使用原 `/tmp/geometry-tests`，即使 native 在另一 checkout，也不能與其他使用該共享 OUT_DIR 的 run_all/binaries 同時執行；會競爭 fingerprints/logs。不要改 OUT_DIR 或新增 shim 為了併跑。

Q38/§7 每項由小 launcher 取 R3 nonblocking lock；#323 v4 自己持同 R3/reaper/16MiB，外層不再雙鎖。root 仍須保 checkout 的獨占租約；R3 不等於所有 native 都會取鎖。個別 gate 若另排第二槽，必用另一實體 checkout，並確認共享 `/tmp/geometry-tests` 沒有第二個 writer。

原 #323 v4 已可直接參數化，這裡直接呼叫固定工具，不改其任何檔案。`--base b74f9a2ae7ade1555b9be45283adecc097fb76e3 --main adbaebf9c73ea6801d7b4d5214e4b846b132923b` 只是原 #323 receipt 身份；本入口只選 required-eight 或 pf3，不跑 prepare/build/compare/perf/profile，不借用 P-189 的 base/≤2，也不聲稱補齊 #323 全驗收。

## 身份與磁碟

初末真 Git HEAD/tree/status/index/refs、原判官/expected Git bytes 與工具 hash 都保存；guard 不採用 ledger source 自引用。不動公理/決策，沒有 golden/threshold 變更。`PREPARATION.json` 對已讀 b6 的原 judges/registry 固定 hash，L 若不是相同 judge closure 會拒絕，由 root 分析差異後另審，不能暗自更新 pin。

環境使用已安裝 Node24/Chrome156 PATH 前綴，清 optimize/preload/外來 GEOMETRY/MUTATE/測試注入；每命令明錄 TMPDIR、Q38 adapter、reaperlog 與 source SHA。沒有另安裝或升版。

選 out 在容量足夠的 workspace/tmp 原生私有目錄。launcher 本身僅小 metadata，原 Q38 的多個 disposable source/native ELF、PF3 的21份必要 source+build、§7 每個 restored build、required-eight 的原 shared build 仍有實際峰值；目前不保證現有餘量可承受，不設新「少跑」模式。root 啟動前記 df，修容量後只重跑環境受影響的項目並保留原紅。原 Q38 TemporaryDirectory 自行清理的歷史限制照實保留；log/receipt/streams 不清除。
