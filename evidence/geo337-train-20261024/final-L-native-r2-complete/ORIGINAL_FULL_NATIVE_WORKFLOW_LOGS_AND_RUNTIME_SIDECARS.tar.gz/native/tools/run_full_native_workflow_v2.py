#!/usr/bin/env python3
"""Run the original full native workflow after final-S and resource allocation.

This file is preparation only until root supplies a clean final-S checkout and
explicitly schedules cache quiescence. It never edits tests or judges their counts.
"""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, os, shutil, sys, traceback
import yaml

DRIVER=Path('/workspace/geo261-environment/run_workflow_round.py')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
REAPER=Path('/workspace/geo261-environment/reap_children.py')
PINS={str(DRIVER):'6a3e3c327687ee6fdafb1044e4c4036f4d2f881a75498af97bd1e1af861e1310',str(CAPTURE):'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',str(REAPER):'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'}
CACHE=Path('/tmp/geometry-tests')
H=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def no_alias(p):
    p=p.absolute();assert all(not x.is_symlink() for x in (p,*p.parents)),str(p)
    return p.resolve()
def inventory(root):
    rows=[]
    if not root.exists():return rows
    for p in sorted(root.rglob('*')):
        st=p.lstat();name=p.relative_to(root).as_posix()
        if p.is_symlink():rows.append(dict(path=name,kind='symlink',target=os.readlink(p),device=st.st_dev,inode=st.st_ino))
        elif p.is_file():
            raw=p.read_bytes();rows.append(dict(path=name,kind='file',bytes=len(raw),sha256=H(raw),device=st.st_dev,inode=st.st_ino))
        elif not p.is_dir():raise RuntimeError('Cache special file cannot be renamed as an ordinary completed cache: '+str(p))
    return rows
def consumers(root):
    hits=[];unreadable=[];needle=str(root)
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        for field in ('exe','cwd'):
            try:
                value=os.readlink(p/field)
                if value==needle or value.startswith(needle+'/'):hits.append(dict(pid=int(p.name),field=field,value=value))
            except (FileNotFoundError,ProcessLookupError):pass
            except (OSError,PermissionError) as e:unreadable.append(dict(pid=int(p.name),field=field,error=repr(e)))
        try:
            fds=list((p/'fd').iterdir())
        except (FileNotFoundError,ProcessLookupError):continue
        except (OSError,PermissionError) as e:unreadable.append(dict(pid=int(p.name),field='fd',error=repr(e)));continue
        for fd in fds:
            try:
                value=os.readlink(fd)
                if value==needle or value.startswith(needle+'/'):hits.append(dict(pid=int(p.name),field='fd/'+fd.name,value=value))
            except (FileNotFoundError,ProcessLookupError):pass
            except (OSError,PermissionError) as e:unreadable.append(dict(pid=int(p.name),field='fd/'+fd.name,error=repr(e)))
    return dict(observed_hits=hits,unreadable_fields=unreadable,limit='Observed /proc exe/cwd/fd only; not a claim of universal process visibility. Root scheduler cache-quiescence authorization is separately required.')
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--sha',required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--resource-lock',type=Path,required=True)
    ap.add_argument('--root-cache-quiescent',action='store_true',required=True)
    a=ap.parse_args();repo=no_alias(a.repo);out=no_alias(a.out);lockpath=no_alias(a.resource_lock)
    assert len(a.sha)==40 and all(x in '0123456789abcdef' for x in a.sha)
    assert repo.is_dir() and not out.exists() and str(out).startswith('/tmp/') and not out.is_relative_to(repo) and not repo.is_relative_to(out)
    assert not out.is_relative_to(CACHE) and not CACHE.is_relative_to(out),'Do not put outputs into the original cache or its ancestor'
    assert not repo.is_relative_to(CACHE) and not CACHE.is_relative_to(repo),'Source and original global cache must be separate roots'
    assert lockpath in [Path('/tmp/g261r3/heavy.lock'),Path('/tmp/g261r3/secondary.lock')] and lockpath.is_file()
    assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0')
    for name,pin in PINS.items():assert H(Path(name).read_bytes())==pin,name
    out.mkdir(parents=True);(out/'tools').mkdir()
    for p in [Path(__file__),DRIVER,CAPTURE,REAPER]:(out/'tools'/p.name).write_bytes(p.read_bytes())
    env=dict(os.environ,LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GEO261_REAPER_LOG=str(out/'reaper.jsonl'))
    cleared=[]
    for key in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONPYCACHEPREFIX','NODE_OPTIONS','GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR']:
        if key in env:cleared.append(key);env.pop(key)
    s=importlib.util.spec_from_file_location('full_native_original_capture',CAPTURE);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    r=m.Recorder(out,env,a.sha)
    report=dict(schema='original-full-native-final-sha-launch/1',source_sha=a.sha,repo=str(repo),resource_lock=str(lockpath),root_cache_quiescent_authorized=a.root_cache_quiescent,commands=r.rows,tools=PINS,cleared_environment_names=cleared,metadata_errors=[],original_command=None,original_native_cli='ulimit -s 16384; python3 tests/run_all.py --build',original_workflow_driver_unchanged=True,all_suites_selected=True,selectors=[],global_cache_deleted=False,tests_or_compiler_instrumented=False,original_internal_pipe_limit='Only original exposed Python/native workflow streams and original run_all-logs are saved. Inner compiler/test capture_output pipes and cleaned NativeBuild scratch are not claimed as separate raw pipes.',passed=False)
    code=2;locks=[];cachelocks=[]
    def git(*parts):return r.run(['git','-C',str(repo),*parts],cwd=out,timeout=120,source_variant='full-native-final-source-binding')[1]
    def guard():
        v=dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),index_sha256=H(git('ls-files','--stage','-z')))
        assert v['head']==a.sha and v['status']=='',v
        return v
    try:
        lock=lockpath.open('r+b');locks.append(lock);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        report['resource_lock_identity']=dict(device=os.fstat(lock.fileno()).st_dev,inode=os.fstat(lock.fileno()).st_ino)
        report['source_before']=guard()
        workflow_raw=git('show',a.sha+':.github/workflows/integration-tests.yml')
        native=yaml.safe_load(workflow_raw)['jobs']['native']
        runs=[step['run'] for step in native['steps'] if 'run' in step]
        lines=[line.strip() for script in runs for line in script.splitlines() if line.strip() and not line.lstrip().startswith('#')]
        assert native['timeout-minutes']==35 and lines==['ulimit -s 16384','python3 tests/run_all.py --build'],'Final-S workflow must still select the exact complete native CLI'
        report['original_workflow_sha256']=H(workflow_raw)
        report['verified_original_native_run_lines']=lines
        report['free_bytes_before']={p:shutil.disk_usage(p).free for p in ['/tmp','/workspace']}
        if CACHE.exists():
            assert not CACHE.is_symlink() and CACHE.is_dir()
            # Observe before acquiring our own cache lock descriptors, otherwise
            # they would count as artificial consumers of the completed cache.
            report['cache_consumers_before']=consumers(CACHE);dump(out/'CACHE_CONSUMERS.json',report['cache_consumers_before'])
            assert not report['cache_consumers_before']['observed_hits'],'Cache has observed live consumers'
            for name in ['build.lock','run_all.lock']:
                p=CACHE/name
                if p.exists():
                    assert p.is_file() and not p.is_symlink()
                    f=p.open('r+b');cachelocks.append(f);fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
            before=inventory(CACHE);dump(out/'GLOBAL_CACHE_BEFORE.json',before)
            assert not any(x['kind']=='symlink' for x in before),'Cache aliases need a separate exact preservation plan; leave entire old cache untouched'
            target=out/'preserved-global-geometry-tests'
            assert not target.exists() and CACHE.stat().st_dev==out.stat().st_dev
            os.rename(CACHE,target)
            after=inventory(target);dump(out/'GLOBAL_CACHE_PRESERVED.json',after)
            assert before==after,'Renamed old cache must retain every original file byte/inode'
            report['cache_preservation']=dict(method='atomic directory rename on same filesystem; no deletion or hardlink backup',old_path=str(CACHE),preserved_path=str(target),files=len(before),bytes=sum(x.get('bytes',0) for x in before),all_original_entries_equal=True)
            for f in cachelocks:f.close()
            cachelocks=[]
        else:report['cache_preservation']=dict(method='original global cache absent; nothing removed')
        dump(out/'REQUEST.json',report)
        argv=[sys.executable,'-B',str(REAPER),sys.executable,'-B',str(DRIVER),'--repo',str(repo),'--sha',a.sha,'--job','native','--out-root',str(out/'workflow')]
        row,_,_=r.run(argv,cwd=out,timeout=None,check=False,source_variant='unchanged-original-complete-native-workflow-with-original-subreaper')
        report['original_command']=row
        receipt=json.loads((out/'workflow/native/receipt.json').read_bytes())
        report['workflow_receipt_sha256']=H((out/'workflow/native/receipt.json').read_bytes())
        report['original_workflow_exit']=receipt['exit_code'];report['over_ci_timeout']=receipt['over_ci_timeout']
        assert receipt['sha']==a.sha and receipt['job']=='native' and receipt['ci_timeout_minutes']==35 and receipt['watchdog_factor']==3
        report['ci_35_minute_gate_exit']=1 if receipt['over_ci_timeout'] else 0
        events=[json.loads(x) for x in (out/'reaper.jsonl').read_bytes().splitlines()]
        done=[x for x in events if x.get('event')=='完成'];assert len(done)==1
        report['reaper_primary_exit']=done[0]['primary_returncode']
        assert row['actual_process_returncode']==done[0]['primary_returncode']==receipt['exit_code']
        report['source_after']=guard();assert report['source_before']==report['source_after']
        code=receipt['exit_code'] if receipt['exit_code'] else report['ci_35_minute_gate_exit']
        report['passed']=code==0
    except BlockingIOError:
        code=75;report['metadata_errors'].append('Busy resource/cache lock; original full-native judge was not started.')
    except BaseException:
        report['metadata_errors'].append(traceback.format_exc());code=2
    finally:
        for f in cachelocks+locks:f.close()
        report.update(actual_exit=code,free_bytes_after={p:shutil.disk_usage(p).free for p in ['/tmp','/workspace']})
        dump(out/'RECEIPT.json',report)
    print(json.dumps(dict(source_sha=a.sha,actual_exit=code,passed=report['passed'],original_workflow_exit=report.get('original_workflow_exit'),ci_35_minute_gate_exit=report.get('ci_35_minute_gate_exit')),ensure_ascii=False))
    return code
if __name__=='__main__':raise SystemExit(main())
