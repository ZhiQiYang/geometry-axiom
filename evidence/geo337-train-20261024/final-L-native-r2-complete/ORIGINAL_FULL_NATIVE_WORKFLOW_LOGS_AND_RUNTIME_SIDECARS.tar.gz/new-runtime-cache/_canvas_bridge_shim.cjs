const cp = require('child_process');
const fs = require('fs');
const orig = cp.spawn;
cp.spawn = function (cmd, args, opts) {
  const exe = process.env.GEOMETRY_TEST_BRIDGE;
  const marker = process.env.GEOMETRY_SHIM_MARKER;
  if (exe && typeof cmd === 'string' && /web_bridge\.exe/i.test(cmd)) {
    const before = cmd;
    cmd = cmd.replace(/"[^"]*web_bridge\.exe"/i, () => '"' + exe + '"');
    if (marker && cmd !== before) {
      try { fs.appendFileSync(marker, 'REDIRECT ' + exe + '\n'); } catch (e) { /* no marker => run_all distrusts the run */ }
    }
  }
  return orig.call(this, cmd, args, opts);
};
