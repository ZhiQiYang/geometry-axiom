# Q338-B2：待明確裁決，尚未採用

保留 #299 按 I22 產生的完整 V_EXTENSION 診斷。是否准許 #323 跨版本 comparator 只接受 `THREE_ORIGINAL_DIFFERENCES.json` 的三個具名場景、三對完整 `/0/error` 字串，以及 stderr 中同一確切訊息的變更？

若批准，才實作版本明確的新 comparator：

- 固定 base b74 與 final L；175 原場景／350 組都跑，原 raw、原 strict compare exit1 永久保留。
- 只允許清單內三個完整舊值→新值配對；兩側都須先匹配完整原值，缺欄、錯邊、錯區間、額外文字、少一份 stderr 或第四個差異一律失敗。不能用一般字串截斷或 JSON 重排來「相等」。
- 除該對精確字串對應的 bytes 外，其餘完整 stdout／stderr、退出碼、完整有序 graph bytes 與五 guards 全同。沒有 scene skip。原判式與測試斷言、性能門檻及分母不改。
- 具名反證：新 comparator 對原三對資料 0；撤回對應「明確核准差異」能力時，必以原 byte mismatch 轉1；恢復0。原 strict judge 三輪仍1，不能冒作原 judge 的0/1/0。另將一個 edge/range 字元、另一 JSON 欄、stderr、graph 次序或 guard 值分別改壞，均須正常具名拒絕；不能因 loader/crash/timeout 當反證。
- 需封存核准者、核准原文／時間、適用場景與完整 before/after 值、comparator 版本/hash，再於真正 final L 重跑全項。核准前不改原裁判、不產綠收據。

替代方案若指定「歷史 base 回填 #299 再做 exact」，該基準必記 b74＋明示 patch 的新 source variant／二進位 hash，不能稱原 b74；也需要本裁決。沒有自行採用。
