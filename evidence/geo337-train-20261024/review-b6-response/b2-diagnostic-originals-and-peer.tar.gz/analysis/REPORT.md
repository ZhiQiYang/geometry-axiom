# #338 B2：三個 V_EXTENSION 差異的根因（唯讀，未修產品／裁判）

在不改公理、既有斷言／golden、比較基準及 comparator 契約的限制下，**不能合法恢復 b74 舊短訊息的 exact**。差異來自 #299 已採用的可觀察診斷功能；不是 memo 改壞圖或 guard。`公理層.md` 的 I22 在 b74 本身已要求「訊息指名料件、定位邊與超出的區間」，b74 的舊輸出欠缺後兩項。

本次已讀 handoff `a47d625c` 的 #338 最新審查（20:44:17Z，head b6），以及 origin/main 425 的決策佇列 10-12～15／10-22／10-23、pr333 FIELD-RULES。10-23 閱讀 A 明示 I22 不改；FIELD-RULES 自身也明說不是公理、不能據以改條文或實作。本分析沒有新增幾何規則或數值。

原正式 ABC 是 base b74／execution F64，175 場景／350 組，原 compare exit1。三個 stdout JSON `/0/error` 的唯一差異，連同 stderr 上相同後綴，完整原字存 `THREE_ORIGINAL_DIFFERENCES.json`：

| 場景 | 新增診斷後綴 |
|---|---|
| `_role_priority_mutant.scene` | `——定位邊 e2 [2000,4000] mm，低端超出 [0,2000] mm` |
| `_s1_p8_l_room_primary_through_reflex_extension.scene` | `——定位邊 e3 [3000,4800] mm，低端超出 [27,3000] mm` |
| `_s1_p8b_l_room_primary_through_reflex_extension_hi.scene` | `——定位邊 e1 [0,1800] mm，高端超出 [1800,4773] mm` |

原三組完整有序 graph bytes 與五 guards 相等；**stdout 和 stderr 都不同**。這只是根因分類，未解除原 exact 紅。F64→b6 的全部 C/H/inc diff 真 exit0／空；本輪沒有在 b6 重跑或把 F64 原件換標 b6。

文字源頭是 commit `6366304eb787b2a50282e4132f45e51eb7d21290` 的 `geometry-templates/woodworking/native/contacts.c`。`wood_member_span_extension_check` 保原拒絕 Boolean guard，於第16–31行附加實際 edge index、定位區間與實際低／高端溢出。`contact_world.c:275` 提供該資料；`current_geometry.c:6009` 傳遞 error buffer，`:5492–5494` 同時寫 stderr 與 scene_last_error；`web_bridge.c:465` 原樣輸出 JSON error。因此只修 memo、改載入順序或移除記錄，不會使這兩個輸出管道回到舊 bytes。

直接把 formatter 回退短訊息，雖不改接受／拒絕幾何判式，仍會違反 I22 的診斷契約；`tests/run_tests.py:249–264`、contacts/contact_world/host_facts harness 的 exact 斷言與 M89–M96 都會紅。把詳細文字搬到另一欄、另一 channel、或只在非 benchmark 模式顯示，也不能同時滿足既有 exact 輸出與既有完整訊息斷言；依 scene 名或測試環境隱藏後綴更是測試特判，不能採用。沒有產出可被誤套的產品回退 patch。

最保守的下一步是取得並封存 B2 所要求的**明確裁決**：保留 #299 的 I22 完整診斷，是否准許 comparator 只承認這三個具名場景、這三對完整 error 字串及對應 stderr 的已知差異。方案詳 `QUESTIONS.proposed.md`，目前是未核准設計，不是新裁判。其餘所有 stdout bytes、完整 stderr、回傳碼、完整有序 graph bytes、五 guards、175/350 數量一律維持原比較。沒有泛用 strip-suffix、normalize 或 skip。原 exact exit1 要永久保留，不能被新結果覆寫。

若不批准 comparator 變更，B2 保持阻擋；另把 #299 診斷回填到歷史 comparator baseline 也會改變「原 b74」來源身份，同樣需要明確裁決，不能自行換分母或冒 b74 原二進位。性能分母／≤1.3／≤4.5 完全不因本分析更動。當前整份 ledger 照原 source 繼續收齊，這份分析不要求中斷或重抽。
