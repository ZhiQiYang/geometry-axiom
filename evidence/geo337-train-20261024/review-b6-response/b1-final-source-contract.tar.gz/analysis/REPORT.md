# B1：execution SHA／帳本 commit／證據 head 的界線

**原 checker 可以支持 b6 產帳本、L 收錄 JSON、E 封證據三欄；但 checker 0 不等於 full CLI 曾在 L 執行。** 不能改寫任何 execution.head 或 record checksum 來追逐新 commit。此份僅讀實碼／審查，沒有啟第二輪 ledger。

原 `tests/mutate.py:1214–1268` 的 execution receipt 驗證，只要求 `head` 為完整40位十六進位，另嚴查 source／include closure、mutant definition、tool、oracle、compile、binary 與完整 verdict。`:1306–1355` 以這些 hash 決定 stale，沒有 `execution.head == current HEAD` 的比較。bridge checker `mutation_bridge.py:404–458` 同樣保留真正 head，嚴驗 tool／methods／baseline-mutant-restored／source還原／oracle／binary identity，沒有要求 head 相同。

`mutation_bridge.py:102–113` 以 tests/*.py、tests/*.c、fixtures scene 與 root scene 為裁判閉包，註文明說結果帳本排除以避免 self-hashing。core oracle 是 run_tests.py＋其 TESTS scenes，include closure 只讀 C/H/inc；所以在 **b6→L 僅原 generated ledger JSON＋已確認不入 closure 的文件／evidence** 的前提下，採用原123完整結果而不改 row，應可在 L 用原 `python3 -B tests/mutate.py --check` 得到0。這仍要於 L 真跑；本報告不預填退出碼。若還有 source/test/judge/fixture 變更，必須重新判影響，不能套此結論。

此外，checker 對 head 只做格式檢查，沒有保證 GitHub 可解析；發布者仍須保存 b6、L、E 的真 `git rev-parse`、普通 push／ls-remote，並用 merge-base ancestry及完整差異清單證明鏈。不能由 head 格式合法推導遠端解析成功。

| 真實角色 | 應記錄 | 不得聲稱 |
|---|---|---|
| 帳本 producer P=b6 | full CLI 原退出／123rows／原execution.head=b6／全raw hash | fullCLI@L 已跑 |
| 收錄帳本的 L | 原JSON逐byte同、b6→L closure證明、原--check@L真退出 | 將各 row.head 改成L |
| native＋六browser＋全部specials | 固定L執行，逐項真exit/source/env/raw | 以舊P或partial代L |
| 證據 head E | L→E僅證據追加、原命令／原結果完整保存 | 所有命令實際在E執行 |

本輪 #338 最新審查（handoff a47d625c、20:44:17Z/headb6）B1 的字面是「固定唯一 final SHA，於該 SHA 重跑全帳本、完整 native、六 browser 與全部專項」。它尚未明確授權用 freshness@L 代替 fullCLI@L。#288 最後審查接受 F3d→evidence-only E 的精確來源繼承與分欄，是可參考的證據表示法，不能自動視為 #338 對 fullCLI 的例外裁決。

若必須嚴格滿足該句，最小真同源方案是：

1. 先等目前 b6 full CLI 真終態，原紅／未跑全部保留。完整有效時採其原JSON成 L；普通push解析L，真正固定L。
2. 在乾淨L checkout用**原 full CLI、全新外部 MUTATE_RESULTS／observer／raw** 跑完整123（不傳 IDs），所有新 execution.head 自然為L；不得從b6 partial／完整JSON補新rows。原允許的 compiler fingerprint cache可沿用，但所有原oracle仍真執行。
3. 新外部結果原 `--check`@L，並把 native、六browser、全部specials也固定L；此份新全帳本稱「L的完整驗證輸出」，原b6收錄的tracked ledger仍由原freshness@L驗有效。
4. **不要再用這份L執行輸出去改L的 tracked JSON。** 把新外部JSON及完整收據當證據封到 E 的 evidence prefix。這樣 fullCLI/native/browser/specials 的真 execution SHA 都是 L，而 E 只是封存。生成檔記其執行commit，無需把收據commit的SHA回寫自身。

每次重寫 execution.head 都會改 record checksum、tree與commit，因此正常Git流程不能用反覆回填含自身SHA的生成檔來取得同一commit。外部正式輸出＋固定來源L＋證據E是避免這個循環的方法。

若 reviewer 明確接受「同一 closure、b6完整帳本＋L freshness」即可滿足B1，則第2輪可以免做，但須記錄該明確裁決，矩陣仍保 generation@b6／check@L分欄。未有裁決或真正L fullCLI之前，不把 B1 全帳本行標為已在L重跑。當前不啟動第二輪、不中斷 live ROOT／SEED，也沒有為此改原 checker。
