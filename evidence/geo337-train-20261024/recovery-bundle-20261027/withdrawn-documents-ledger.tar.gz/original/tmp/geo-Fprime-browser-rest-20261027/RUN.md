固定來源：`a4bd77e8090f5a82f0c8934c30c5335782293922`。只重用已完成的 `/dev/shm/geo337-F9-browsers-20261025/Fp27/seed/source` 與其 private Git；原 seed 不重新 checkout。每個 job 各有自己的 plan、source layout、private Git index、private golden、runtime 與完整原件。

主代理讀 `EXECUTION_PEER.json` 並取得 SHA256 後，對每個 job 依序執行三個明確檢查點；只有前一步實際 exit 0 才進下一步：

```sh
python3 -B /tmp/geo-Fprime-browser-rest-20261027/root_steps.py --job documents --stage plan --execute --peer-sha256 <PEER_SHA256>
python3 -B /tmp/geo-Fprime-browser-rest-20261027/root_steps.py --job documents --stage materialize --execute --peer-sha256 <PEER_SHA256>
python3 -B /tmp/geo-Fprime-browser-rest-20261027/root_steps.py --job documents --stage launch --execute --peer-sha256 <PEER_SHA256>
```

同一套工具接受 `documents`、`grid`、`space`、`timber`、`canvas`。只有 job 參數不同；不需為每組再造工具。沒有自動重試或刪除。

| job | 新 scope | 短 runtime | 原 HTTP/CDP | 原 CI 分鐘 |
|---|---|---|---|---|
| documents | Fp27-documents | r/pd | 19083 / 9366 | 10 |
| grid | Fp27-grid | r/pg | 19084 / 9334 | 15 |
| space | Fp27-space | r/ps | 19085 / 9347 | 15 |
| timber | Fp27-timber | r/pt | 19086 / 9348 | 20 |
| canvas | Fp27-canvas | r/pc | 19081 / 9333 | 35 |

上述相對路徑都以 `/dev/shm/geo337-F9-browsers-20261025` 為根。原 tools/steps、斷言、golden、矩陣 skip、原 watchdog factor3、over-CI 不通過與 Chrome156/Node24/fonts 檢查保留。

`materialize` 實際取得既有 heavy 與 secondary 兩鎖，只有 root 確認 assembly／其他 seed 消費者已終態才排程；避免共用 seed 的 chmod/link 與正在執行的 job 重疊。`canvas` launch 也取得兩鎖，必須獨占。其餘 job 預設 heavy，可由 root 指定 `--resource-lock secondary`，最多兩個；若並行，root 必須把兩者尚未使用的規劃量一起算入，不能把單一 job 的容量檢查誤當兩 job 已預約。保守預設為逐項執行。

每步 fresh 兩 OWN 合計與真 SHM free；plan/materialize 保留 704 MiB 的剩餘規劃（64 metadata/private +64 tools/publication +64 原保留 +512 runtime/raw/archive/Git/remote/transient）；launch 512 MiB。這些是可逆工作規劃，不是產品門檻或已證最壞成本。整體 4 GiB 規劃、原 64 MiB 發布保留及發布時實測 `3P + L*65536 + 8MiB + 64MiB` 均不變；native 真 TMP 守門不受本工具影響。

`binding-proof/` 是小型工具自證，五個真子程序退出為 0／1／0／1／0；移除每 job 的 source 隔離或 canvas 雙鎖會紅。它沒有讀寫真 SHM、沒有執行 seed/materializer 或正式 browser。最初 proof 腳本的一處語法錯與原文保存在 `PREPARATION_FAILURE.txt`／`prove_bindings.initial.py.txt`，修正後才開始上述自證。
