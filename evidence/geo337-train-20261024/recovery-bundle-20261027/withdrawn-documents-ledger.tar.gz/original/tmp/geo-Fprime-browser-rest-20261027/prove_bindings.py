"""Small process-based binding proofs; never execute seed, workflow, or real SHM access."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,traceback,types
R=Path(__file__).parent
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,mutant=None):
 p=R/(name+'.py');raw=p.read_text()
 if mutant=='shared-source':raw=raw.replace("scope=OWN/('Fp27-'+job)","scope=OWN/'Fp27-documents'")
 if mutant=='weak-canvas':raw=raw.replace("return ['heavy','secondary'] if job=='canvas' else [resource_lock]","return [resource_lock]")
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);return m
def prove(mutant):
 root=module('root_steps',mutant);launch=module('launch_Fprime_browser',mutant);sample=module('sample_Fprime_browser')
 assert root.F==launch.F==sample.F=='a4bd77e8090f5a82f0c8934c30c5335782293922'
 assert root.STAGES==('plan','materialize','launch')
 assert set(root.JOBS)==set(sample.JOBS)=={'documents','grid','space','timber','canvas'}
 assert H(launch.DRIVER)==launch.PINS[str(launch.DRIVER)] and H(launch.PREPARER)==launch.PINS[str(launch.PREPARER)]
 expected={'canvas':(35,19081,9333),'documents':(10,19083,9366),'grid':(15,19084,9334),'space':(15,19085,9347),'timber':(20,19086,9348)}
 scopes=[];storages=[]
 for job in root.JOBS:
  scope,plan,layout,storage=root.job_paths(job);scopes.append(str(scope));storages.append(str(storage))
  path=launch.TEMPLATES/(job+'.REQUEST.template.json');assert H(path)==launch.TEMPLATE_PINS[job]
  template=json.loads(path.read_bytes());source=layout/'jobs'/job/'source';b=launch.bind_original_template(path.read_text(),job,source,plan,storage)
  assert '<FINAL_'not in json.dumps(b)
  assert b['final_sha']==root.F and b['source_checkout']==str(source) and b['private_gitdir']==str(plan/'layout/jobs'/job/'gitdir')
  assert b['driver_argv'][b['driver_argv'].index('--repo')+1]==str(source) and b['driver_argv'][b['driver_argv'].index('--sha')+1]==root.F
  assert b['driver_argv'][b['driver_argv'].index('--out-root')+1]==str(storage/'original')
  assert (b['ci_timeout_minutes'],b['http_port'],b['cdp_port'])==expected[job]
  for key in ['skips','original_case_environment','original_case_command','node_argv','scheduler','original_collection_watchdog_factor']:
   assert b[key]==template[key],key
  assert launch.lock_names(job,'heavy')==(['heavy','secondary']if job=='canvas'else['heavy'])
  assert launch.lock_names(job,'secondary')==(['heavy','secondary']if job=='canvas'else['secondary'])
  socket=storage/'tmp/original'/job/'com.google.Chrome.ABCDEF/SingletonSocket';assert len(str(socket).encode())+1<108
 assert len(scopes)==len(set(scopes))==5 and len(storages)==len(set(storages))==5,'each job has private source/plan/runtime'
 for invalid in ['assembly','../canvas','native','unknown']:
  try:root.job_paths(invalid)
  except RuntimeError:pass
  else:raise AssertionError('unknown/overlapping job accepted')
 print(json.dumps(dict(case=mutant,checks='five original bindings/ports/time limits/skips/lock isolation/private source/socket lengths',passed=True,real_SHM_accessed=False)))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',choices=['restored','shared-source','weak-canvas']);a=ap.parse_args()
 if a.case:prove(a.case);return 0
 out=R/'binding-proof';out.mkdir(mode=0o700);rows=[]
 for num,(case,expected)in enumerate([('restored',0),('shared-source',1),('restored',0),('weak-canvas',1),('restored',0)],1):
  prefix=out/str(num);prefix.mkdir();argv=[sys.executable,'-B',str(Path(__file__)),'--case',case];p=subprocess.run(argv,capture_output=True)
  (prefix/'stdout.bin').write_bytes(p.stdout);(prefix/'stderr.bin').write_bytes(p.stderr)
  row=dict(command=argv,actual_process_returncode=p.returncode,expected=expected,matched=p.returncode==expected,stdout_bytes=len(p.stdout),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_bytes=len(p.stderr),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(prefix/'RESULT.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(json.dumps(row))
 result=dict(schema='generic-Fprime-browser-binding-proof/1',exit_code=0 if all(x['matched']for x in rows)else 1,source_sha='a4bd77e8090f5a82f0c8934c30c5335782293922',tools={p.name:H(p)for p in R.glob('*.py')},rows=rows,formal_tests_run=False,SHM_accessed=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');return result['exit_code']
if __name__=='__main__':raise SystemExit(main())
