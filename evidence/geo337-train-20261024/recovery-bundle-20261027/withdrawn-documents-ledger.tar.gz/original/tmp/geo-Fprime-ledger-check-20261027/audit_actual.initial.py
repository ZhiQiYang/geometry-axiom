"""Audit saved --check and its complete Git-defined hash dependencies; never run mutate."""
from pathlib import Path
import ast,datetime,hashlib,json,os,posixpath,re,stat
OUT=Path('/tmp/geo-Fprime-ledger-check-20261027')
SOURCE=Path('/dev/shm/geo337-F9-browsers-20261025/Fp27/seed/source')
PLANROOT=Path('/dev/shm/geo337-F9-browsers-20261025/Fp27/plan')
F='a4bd77e8090f5a82f0c8934c30c5335782293922'
checks=[]
def need(ok,label):
 checks.append(label)
 if not ok:raise AssertionError(label)
def h(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
s=J(OUT/'SUMMARY.json');commands=J(OUT/'subcommands.json')
need(s['source_sha']==F and s['formal_exit']==1 and s['source_preserved'] and not s['compilation_requested'] and not s['ledger_rewritten'] and not s['verdict_override'],'actual nonzero original check retained')
need(len(commands)==4 and [x['actual_process_returncode'] for x in commands]==[0,0,1,0],'four original terminal commands 0/0/1/0')
need(s['inputs_before']==s['inputs_after'],'ledger and three judge hashes unchanged')
for n,row in enumerate(commands,1):
 p=OUT/'subcommands'/f'{n:06d}';q=J(p/'request.json')
 need(J(p/'result.json')==row and row['source_sha']==row['acceptance_sha']==F and row['cwd']==str(SOURCE) and not row['timeout_expired'],'original command identity '+str(n))
 for key in ('command','cwd','source_sha','acceptance_sha','environment','stdin_sha256','started_epoch','directory'):need(q[key]==row[key],'request/result '+str(n)+'/'+key)
 for stream in ('stdin','stdout','stderr'):
  raw=(p/(stream+'.bin')).read_bytes();need(h(raw)==row[stream+'_sha256'],'complete original raw '+str(n)+'/'+stream)
  if stream!='stdin':need(len(raw)==row[stream+'_bytes'],'original raw length '+str(n)+'/'+stream)
need((OUT/'subcommands/000001/stdout.bin').read_text().strip()==F,'original HEAD exact Fprime')
need((OUT/'subcommands/000002/stdout.bin').read_bytes()==(OUT/'subcommands/000004/stdout.bin').read_bytes()==b'','before/after original Git status clean')
need(commands[2]['command']==s['command'] and s['command'][1:]==['-B','tests/mutate.py','--check'],'original check-only argv')
text=(OUT/'subcommands/000003/stdout.bin').read_text();need('變異表 123 筆,紀錄 123 筆' in text,'all123 original table and records')
expected={'killed':62,'crashed':1,'survived':0,'equivalent':4,'invalid':0,'stale':53,'blocked':0,'retired':3}
for name,count in expected.items():need(re.search(r'\b'+name+r' '+str(count)+r'\b',text) is not None,'original printed count '+name)
need(sum(expected.values())==123,'all original categories cover123')
stale=re.findall(r'^  STALE ([^\(]+)\(原 ([^\)]+)\):(.+)$',text,re.M)
need(len(stale)==53 and len({x[0]for x in stale})==53,'53 unique printed stale rows')
need(all('bridge source/oracle restoration' in x[2] and ('裁判已變' in x[2] or 'equivalence audit oracle changed' in x[2]) for x in stale),'explicit original stale reasons retained')
need('  CRASHED M20 [_test_lshape.scene]' in text,'original M20 crash distinguished')
plan=J(PLANROOT/'PLAN.json');need(plan['sha']==F and len(plan['items'])==3759,'exact Fprime3759 plan')
tree_raw=(PLANROOT/'TREE.stdout.bin').read_bytes();tree={}
for part in tree_raw.split(b'\0'):
 if not part:continue
 left,name=part.split(b'\t',1);mode,kind,oid,size=left.split();tree[name.decode()]={'mode':mode.decode(),'kind':kind.decode(),'oid':oid.decode(),'bytes':int(size)}
selected={x['path']:x for x in plan['items']}
need(all(x in tree for x in selected),'all selected paths in complete Git tree')
for path,item in selected.items():need((item['mode'],item['git_blob'],item['bytes'])==(tree[path]['mode'],tree[path]['oid'],tree[path]['bytes']),'plan/Git TREE identity '+path)
records={}
def verify(path,kind):
 need(path in tree and path in selected,'tracked dependency selected '+path)
 p=SOURCE/path;z=p.lstat();b=p.read_bytes();entry=tree[path]
 need(stat.S_ISREG(z.st_mode) and not p.is_symlink(),'regular unaliased dependency '+path)
 need(len(b)==entry['bytes'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==entry['oid'],'exact Git dependency bytes '+path)
 need(bool(z.st_mode&0o111)==(entry['mode']=='100755'),'dependency executable Git mode '+path)
 if path not in records:records[path]={'path':path,'bytes':len(b),'sha256':h(b),'lf_sha256':h(b.replace(b'\r\n',b'\n')),'git_blob':entry['oid'],'kinds':[]}
 if kind not in records[path]['kinds']:records[path]['kinds'].append(kind)
 return b
for path,pin in s['inputs_before'].items():need(h(verify(path,'original_check_input'))==pin,'current exact recorded input '+path)
runner=verify('tests/run_tests.py','core_oracle');module=ast.parse(runner)
assignments=[node for node in module.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='TESTS'for t in node.targets)]
need(len(assignments)==1,'one literal TESTS declaration')
tests=ast.literal_eval(assignments[0].value);scenes=sorted({item['scene']for item in tests})
for name in scenes:verify(name,'core_TESTS_scene')
core_hash=h((h(runner.replace(b'\r\n',b'\n'))+'\n'+'\n'.join(name+' '+records[name]['lf_sha256']for name in scenes)).encode())
def bridge_match(path):
 parts=path.split('/')
 return (len(parts)==2 and parts[0]=='tests' and path.endswith(('.py','.c'))) or (path.startswith('tests/fixtures/')and path.endswith('.scene')) or (len(parts)==1 and path.endswith('.scene'))
expected_bridge=sorted(path for path in tree if bridge_match(path))
actual_bridge=sorted(p.relative_to(SOURCE).as_posix() for pattern in ['tests/*.py','tests/*.c','tests/fixtures/**/*.scene','*.scene']for p in SOURCE.glob(pattern))
need(expected_bridge==actual_bridge,'complete Git expected bridge oracle set equals actual glob set (no missing/extra files)')
for name in expected_bridge:verify(name,'bridge_oracle')
include=re.compile(r'^[ \t]*#[ \t]*include[ \t]+"([^"]+)"',re.M);visited=set();untracked_includes=[];outside=[]
def visit(name):
 if name in visited:return
 visited.add(name);data=verify(name,'core_bridge_include')
 for rel in include.findall(data.replace(b'\r\n',b'\n').decode()):
  target=posixpath.normpath(posixpath.join(posixpath.dirname(name),rel))
  if target.startswith('../') or target.startswith('/'):
   outside.append({'from':name,'include':rel});continue
  if target in tree:visit(target)
  else:
   need(not(SOURCE/target).is_file(),'unexpected untracked include file '+target)
   untracked_includes.append({'from':name,'include':rel,'resolved':target})
visit('current_geometry.c');visit('geometry-web/web_bridge.c')
source_closure_hash=h('\n'.join(x+' '+records[x]['lf_sha256']for x in sorted(visited)).encode())
# Methods, RESTORED, mutation definitions and backend logic are covered by their
# exact tracked source bytes; no evaluator, imported oracle or check is called.
for path in ['tests/mutation_bridge.py','tests/binaries.py']:
 verify(path,'check_import_and_tool_hash')
ledger=J(SOURCE/'tests/mutants_results.json');need(isinstance(ledger,dict),'original ledger object')
# Core/bridge execution evidence also consults optional local compiled artifacts.
# Their absence is explicitly permitted by the original execution_problems code;
# this audit does not compile or turn absent caches into a new test result.
cache=Path('/tmp/geometry-tests/mutants');cache_candidates=[cache/'_baseline/baseline.exe']
for rid in re.findall(r'^  STALE ([^\(]+)',text,re.M):cache_candidates.append(cache/rid/'bridge-mutant/bridge')
cache_state={'root':str(cache),'root_exists':cache.exists(),'explicit_stale_bridge_artifacts_present':[str(p)for p in cache_candidates if p.exists()],'not_required_tracked_source':True,'no_cache_run_or_write':True}
need(not outside,'no out-of-repository quoted includes in source closure')
need(not untracked_includes,'no missing Git quoted include dependencies')
manifest={'schema':'Fprime-ledger-check-input-closure/1','source_sha':F,'tree_sha256':h(tree_raw),'selected_paths':3759,'core_TESTS_count':len(tests),'core_unique_scenes':len(scenes),'core_oracle_sha256':core_hash,'bridge_oracle_files':len(expected_bridge),'bridge_inventory_sha256':h(json.dumps([(x,records[x]['lf_sha256'])for x in expected_bridge],separators=(',',':'),ensure_ascii=False).encode()),'quoted_include_files':len(visited),'source_closure_sha256':source_closure_hash,'missing_or_extra_bridge':[],'missing_quote_includes':untracked_includes,'outside_quote_includes':outside,'inputs':sorted(records.values(),key=lambda x:x['path']),'optional_cache_observation':cache_state,'not_a_rerun':True}
manifest_raw=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();(OUT/'INPUT_CLOSURE.json').write_bytes(manifest_raw)
summary={'schema':'Fprime-ledger-check-actual-peer/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'blocking':[],'checks':len(checks),'source_sha':F,'formal_exit':1,'root_outer_observation':{'source':'root session61766/chunkc5d12e','exit_code':1,'not_polled_by_this_reviewer':True},'counts':expected,'stale_ids':[x[0]for x in stale],'stale_from_counts':{'killed':sum(x[1]=='killed'for x in stale),'equivalent':sum(x[1]=='equivalent'for x in stale)},'source_ledger_judges_preserved':s['inputs_before'],'complete_original_commands':4,'complete_original_streams':12,'formal_elapsed_seconds':commands[2]['ended_epoch']-commands[2]['started_epoch'],'input_closure':{k:v for k,v in manifest.items()if k!='inputs'},'input_manifest':{'path':str(OUT/'INPUT_CLOSURE.json'),'bytes':len(manifest_raw),'sha256':h(manifest_raw)},'original_summary_sha256':h((OUT/'SUMMARY.json').read_bytes()),'original_stdout_sha256':commands[2]['stdout_sha256'],'limits':['Audit success0 authenticates original nonzero check1, not a product pass or automatic stale exemption.','No rerun of --check, compiler, gate, import of mutate/mutation_bridge, API, ledger write or cleanup occurred.','Hash closure is independently reconstructed from exact Git tree and literal TESTS; method/RESTORED declarations are bound by complete original mutate/backend bytes, without re-evaluating verdicts.','Original check permits absent optional TEMP executables; absence is not newly counted as executed validation.','This is only ledger-check completeness;3759 selected browser leaves are not certified as full native6997 checkout.']}
raw=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode();(OUT/'ACTUAL_PEER.json').write_bytes(raw)
print(json.dumps({'exit_code':0,'formal_exit':1,'checks':len(checks),'counts':expected,'core_tests':len(tests),'core_scenes':len(scenes),'bridge_files':len(expected_bridge),'include_files':len(visited),'union_files':len(records),'actual_peer_bytes':len(raw),'actual_peer_sha256':h(raw),'input_closure_bytes':len(manifest_raw),'input_closure_sha256':h(manifest_raw)}))
