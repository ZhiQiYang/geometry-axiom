"""Record the original read-only ledger check; never rewrite its verdicts."""
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

F = 'a4bd77e8090f5a82f0c8934c30c5335782293922'
SOURCE = Path('/dev/shm/geo337-F9-browsers-20261025/Fp27/seed/source')
OUT = Path('/tmp/geo-Fprime-ledger-check-20261027')
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert sys.dont_write_bytecode and not sys.flags.optimize
assert digest(CAP) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists()
OUT.mkdir(mode=0o700)
(OUT/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
env = {k:v for k,v in os.environ.items() if not k.startswith(('GIT_', 'MUTATE_', 'GEOMETRY_'))
       and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','LD_PRELOAD')}
env.update(PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', LANG='C.UTF-8', LC_ALL='C.UTF-8')
spec = importlib.util.spec_from_file_location('original_capture', CAP)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
rec = cap.Recorder(OUT, env, F)
def run(argv):
    return rec.run(argv, cwd=SOURCE, check=False, timeout=None,
                   source_sha=F, source_variant='original read-only Fprime ledger check')
row, head, _ = run(['git','rev-parse','HEAD'])
assert row['actual_process_returncode'] == 0 and head.decode().strip() == F
row, status, _ = run(['git','status','--porcelain=v1','--untracked-files=all'])
assert row['actual_process_returncode'] == 0 and status == b''
inputs = ['tests/mutate.py','tests/mutation_bridge.py','tests/mutants_results.json','tests/run_tests.py']
before = {p:digest(SOURCE/p) for p in inputs}
row, stdout, stderr = run([sys.executable,'-B','tests/mutate.py','--check'])
code = row['actual_process_returncode']
assert isinstance(code, int) and not row['timeout_expired']
after = {p:digest(SOURCE/p) for p in inputs}
tail, status_after, _ = run(['git','status','--porcelain=v1','--untracked-files=all'])
preserved = before == after and tail['actual_process_returncode'] == 0 and status_after == status
summary = dict(source_sha=F, command=row['command'], formal_exit=code,
               source_preserved=preserved, inputs_before=before, inputs_after=after,
               environment={k:env.get(k) for k in ['PATH','LANG','LC_ALL','CC','PYTHONDONTWRITEBYTECODE']},
               python=sys.version, compilation_requested=False, ledger_rewritten=False,
               verdict_override=False, note='Nonzero formal result remains nonzero; stale is not relabelled passed.')
(OUT/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(stdout.decode(),end='')
print(json.dumps(summary,ensure_ascii=False))
raise SystemExit(code if preserved else 2)
