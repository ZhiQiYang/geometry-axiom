"""Run only build_one over a tiny local fixture; no real archive build."""
import importlib.util
import json
import pathlib
import sys
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
TOOLS = pathlib.Path('/tmp/geo-next-bundle-plan-20261027')
spec = importlib.util.spec_from_file_location('reviewed_build', TOOLS / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
case = sys.argv[1]
assert case in {'normal', 'mutated_source', 'restored_source'}
build.OUT = ROOT / 'fixture' / case
build.OUT.mkdir()
group = json.loads((ROOT / 'fixture' / 'GROUP.json').read_text())
result = {'case': case, 'exit_code': 1, 'synthetic_only': True}
try:
    result['archive'] = build.build_one(group)
    result['exit_code'] = 0
except BaseException as exc:
    result['error'] = repr(exc)
    result['traceback'] = traceback.format_exc()
    traceback.print_exc()
finally:
    (build.OUT / 'WORKER_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))
sys.exit(result['exit_code'])
