"""Independent small normal/drift/restored proof for the submitted archive builder."""
import hashlib
import importlib.util
import json
import os
import pathlib
import sys
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent
TOOLS = pathlib.Path('/tmp/geo-next-bundle-plan-20261027')
CAPTURE = pathlib.Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def digest(b):
    return hashlib.sha256(b).hexdigest()
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
fixture = ROOT / 'fixture'
assert not fixture.exists(), 'One run only; preserve prior attempts'
fixture.mkdir()
helpers = load('independent_fixture_helpers', TOOLS / 'prepare.py')
capture = load('original_capture', CAPTURE)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
rec = capture.Recorder(fixture, env, 'synthetic-local-only')
pins = {str(p): digest(p.read_bytes()) for p in [TOOLS/'prepare.py', TOOLS/'build.py', TOOLS/'PLAN.json', TOOLS/'COST.json']}
source = fixture / 'source'
source.mkdir()
(source / 'empty-dir').mkdir()
(source / 'empty-file').write_bytes(b'')
longdir = source / ('long-' + 'x' * 85) / ('deep-' + 'y' * 85)
longdir.mkdir(parents=True)
target = longdir / ('payload-' + 'z' * 65 + '.bin')
original = b''.join(hashlib.sha256(str(i).encode()).digest() for i in range(512))
target.write_bytes(original)
(source / 'metadata-link').symlink_to('/nonexistent-peer-fixture-target')
g = helpers.group('tiny-natural-job', 'synthetic-local-only')
helpers.tree(g, source)
for r in g['files'].values():
    r['sha256'] = digest(pathlib.Path(r['path']).read_bytes())
g['bounds'] = helpers.bounds(g)
for key in ['files', 'directories', 'nonregular']:
    g[key] = sorted(g[key].values(), key=lambda x: x['path'])
(fixture / 'GROUP.json').write_bytes(helpers.data(g))
saved = target.stat()
results = []
for case, expected in [('normal', 0), ('mutated_source', 1), ('restored_source', 0)]:
    if case == 'mutated_source':
        target.write_bytes(bytes([original[0] ^ 1]) + original[1:])
        os.utime(target, ns=(saved.st_atime_ns, saved.st_mtime_ns))
    elif case == 'restored_source':
        target.write_bytes(original)
        os.utime(target, ns=(saved.st_atime_ns, saved.st_mtime_ns))
    row, _, _ = rec.run([sys.executable, '-B', str(ROOT/'fixture_worker.py'), case],
                        cwd=ROOT, timeout=30, check=False, source_variant=case)
    r = json.loads((fixture / case / 'WORKER_RESULT.json').read_text())
    assert row['actual_process_returncode'] == r['exit_code'] == expected
    if expected:
        assert 'audited hash mismatch' in r['error'], 'Must reject actual changed content, not incidental filesystem error'
    else:
        archive = pathlib.Path(r['archive']['path'])
        assert archive.stat().st_size <= g['bounds']['gzip_worst_bytes'] < helpers.LIMIT
        with tarfile.open(archive, 'r:gz') as tf:
            members = tf.getmembers()
            idx = json.load(tf.extractfile('INDEX.json'))
            names = {m.name: m for m in members}
            assert names['original/' + str(source/'empty-dir').lstrip('/')].isdir()
            assert not any(m.issym() for m in members)
            assert idx['nonregular_metadata_only'][0]['link_target'] == '/nonexistent-peer-fixture-target'
            longname = 'original/' + str(target).lstrip('/')
            assert len(longname) > 255 and tf.extractfile(longname).read() == original
            assert names[longname].pax_headers['path'] == longname
            assert len(members) == len(g['files']) + len(g['directories']) + 1
            assert idx['source_sha'] == 'synthetic-local-only'
    results.append(r)
assert target.read_bytes() == original
assert results[0]['archive']['sha256'] == results[2]['archive']['sha256'], 'Restoration must reproduce the exact gzip bytes'
assert pins == {p: digest(pathlib.Path(p).read_bytes()) for p in pins}, 'Submitted tools/plan changed while fixture ran'
hash_checks = 0
for row in rec.rows:
    d = pathlib.Path(row['directory'])
    for label in ['stdin','stdout','stderr']:
        assert digest((d/(label+'.bin')).read_bytes()) == row[label+'_sha256']
        hash_checks += 1
result = {'exit_code': 0, 'scope': 'Synthetic local fixture only; original real PLAN, sources and outputs not executed or modified',
          'tool_pins': pins, 'gate_sequence': [r['exit_code'] for r in results],
          'cases': results, 'stream_hash_checks': hash_checks, 'bounds': g['bounds'],
          'assertions': ['PAX path longer than 255 bytes roundtrips', 'Empty directory included',
                         'Symlink captured as index metadata, never followed or emitted as tar symlink',
                         'Same size/mtime/inode content mutation rejected by audited SHA256',
                         'Restored source recreates byte-identical deterministic gzip',
                         'All original worker streams retained, including intentional exit 1']}
(fixture/'RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'exit_code':0, 'gate_sequence':result['gate_sequence'], 'result_sha256':digest((fixture/'RESULT.json').read_bytes()), 'bounds':g['bounds']}))
