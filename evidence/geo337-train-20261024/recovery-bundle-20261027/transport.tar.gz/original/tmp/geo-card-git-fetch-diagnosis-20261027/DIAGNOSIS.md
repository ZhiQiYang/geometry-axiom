# Card 證據 Git 傳輸的本地重包根因

本診斷只讀原失敗收據與 object indexes，沒有再次 fetch／push、刪除 objects 或重跑正式驗收。原程序 root session75914／chunke286ac exit1；published=false、push_attempted=false。所有原件留在 `card-F-git-delivery-20261027/git-publication/`。

第4條 `git fetch --filter=blob:none --depth=1 --no-tags --no-write-fetch-head … 45dd4d662eac9297eda8473742c9943a1cb336cb:refs/heads/fixed-parent` 本身 exit0、耗時53.77350449562073秒，先產生15,945B pack（1 commit、11 trees），約52秒後又產生2,422,150,411B pack（5,959 trees、21,779 blobs）。第5條rev-parse及第6／7條verify-pack都在兩份pack形成之後；不能把後者當觸發原因。原stderr沒有filter不支援訊息。

這是我設計遺漏的 Git 2.52 `index-pack --promisor` 本地行為：`--promisor` 啟用 `record_outgoing_links`；結束時 `repack_local_links()` 把新promisor樹連到、但位於非promisor本地ODB／alternates的物件交給 `pack-objects --exclude-promisor-objects-best-effort`，於本地建立第二份promisor pack。該步不是lazy network fetch，故 `GIT_NO_LAZY_FETCH=1` 不能禁止它。Git binary版本與字串已證實支援此變數，不能歸咎版本不支援。

只讀 `PROVIDER_MEMBERSHIP.json` 證明第二份pack的全部27,738個OID早已存在於fetch開始前的provider chain（原pack index／loose object時間戳皆早於開始）；missing=0。這支持「本地複製」而不是把2.4GB誤報為額外下載。原指令沒有trace2／protocol trace，不能虛構已捕獲內層argv。

對照的Git v2.52.0公開原碼與完整來源檔保存於本目錄：

- [builtin/index-pack.c](https://github.com/git/git/blob/v2.52.0/builtin/index-pack.c)：1814–1876為`repack_local_links`，1954–1955處理`--promisor`，2126呼叫重包。
- [fetch-pack.c](https://github.com/git/git/blob/v2.52.0/fetch-pack.c)：接收filtered pack時傳`index-pack --promisor`。
- [promisor-remote.c](https://github.com/git/git/blob/v2.52.0/promisor-remote.c)：32行附近的NO_LAZY_FETCH只阻止lazy遠端補件。

原post-fetch「pack不得含blob」守門有正確轉紅，但檢查太晚，已超出64MiB metadata估量。此工具失敗及其2.4GB objects全部保留；原provider metadata及更早HTTP422原件均未變。

修復不重試fetch：全新私有bare Gitdir只用已存在E45 ODB作唯讀alternates，不設promisor remote、不執行fetch／clone／index-pack／repack；缺物件即失敗。只建立兩個新evidence blobs、所需trees與單parent commit；push前以rev-list精確核對新物件閉包及size，一般push後再完整核對兩個遠端blob與ref。

純本機小反證位於 `/tmp/geo-card-no-fetch-proof-20261027/`：僅354B、兩個物件的incoming pack，沒有網路命令。固定／撤回／恢復`oldblob_not_copied`真退出碼0/1/0；撤回no-ingest修復會在NO_LAZY_FETCH=1下複製oldblob／oldtree，固定／恢復的privateODB只有四個新evidence物件。完整31外層命令、2內層verify-pack及原流保留；我另做172checks獨立核對，exit0。這是工具反證，不是產品gate。

父端已將自訂工作規劃上限更新為兩OWN最多8GiB，沒有改產品、掛載、配額或安全設定。新發布模型逐項計入loose blobs、可能outgoing pack、完整remote readback、metadata／state與原64MiB保留，並取不低於原3P公式的上界。修復工具要在fresh實體SHM與共用cgroup觀測後才執行，不能將這份靜態診斷當推送成功。
