"""One-shot, tiny local promisor regex regression with original streams."""
import datetime
import ast
import hashlib
import importlib.util
import json
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
CAPTURE = pathlib.Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
ORIGINAL = pathlib.Path('/tmp/geo-card-F-no-fetch-delivery-20261027/publish_no_fetch.py')
EXPECTED = 'dcf40e34228eac195f223a6090a06bd303d515e48f6e47d37ec5ea9814338e44'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
assert not (ROOT / 'RESULT.json').exists(), 'Never replace a prior run'
original = ORIGINAL.read_bytes()
assert digest(original) == EXPECTED
assert digest(CAPTURE.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
patterns = [node.value for node in ast.walk(ast.parse(original))
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and 'promisor$' in node.value]
assert patterns == [r'^remote\..*\.promisor$']
gate_patterns = [node.value for node in ast.walk(ast.parse((ROOT / 'gate.py').read_bytes()))
                 if isinstance(node, ast.Constant) and isinstance(node.value, str) and 'promisor$' in node.value]
assert set(gate_patterns) == {patterns[0], patterns[0].replace('\\', '\\\\')}
spec = importlib.util.spec_from_file_location('capture', CAPTURE)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
git_flags = {'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
             'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0'}
env.update(git_flags)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['LC_ALL'] = 'C.UTF-8'
rec = capture.Recorder(ROOT, env, 'synthetic-local-only')
result = {'exit_code': 1, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'original_tool': {'path': str(ORIGINAL), 'sha256': EXPECTED},
          'premise_correction': 'Actual frozen tool has correct literal-dot escaping. Earlier communicated defect allegation was based on JSON presentation, not runtime bytes. PREPARATION_FAILURE.json preserves the failed source-premise check. This proof injects an artificial mutant and does not claim the real publisher was defective.',
          'actual_pattern': patterns[0], 'actual_pattern_utf8_hex': patterns[0].encode().hex(),
          'prior_peer_preserved': 'a1b16229501b1df39743c23dfd6175b0361516ab60a295fbaa01e59b20104c59',
          'safe_test_environment_overrides': git_flags,
          'scope': 'Three new synthetic bare repositories only; no URL, network, fetch, push, publication, real repository edits or product gate reruns.',
          'cases': []}
try:
    _, version, _ = rec.run(['git', '--version'], cwd=ROOT, timeout=30)
    result['git_version'] = version.decode().strip()
    for name, present, expected_exit in [('actual_regex_promisor', True, 0),
                                         ('mutant_regex_promisor', True, 1),
                                         ('restored_no_promisor', False, 0)]:
        case = ROOT / name
        case.mkdir()
        gitdir = case / 'fixture.git'
        rec.run(['git', 'init', '--bare', '--quiet', str(gitdir)], cwd=ROOT, timeout=30, source_variant=name)
        if present:
            rec.run(['git', '--git-dir=' + str(gitdir), 'config', '--local', 'remote.origin.promisor', 'true'],
                    cwd=ROOT, timeout=30, source_variant=name)
        baseline, stdout, _ = rec.run(['git', '--git-dir=' + str(gitdir), 'config', '--get', 'remote.origin.promisor'],
                                      cwd=ROOT, timeout=30, check=False, source_variant=name)
        assert baseline['actual_process_returncode'] == (0 if present else 1)
        assert stdout == (b'true\n' if present else b'')
        before = (gitdir / 'config').read_bytes()
        row, _, _ = rec.run([sys.executable, '-B', str(ROOT / 'gate.py'), name], cwd=ROOT,
                            timeout=30, check=False, source_variant=name)
        gate = json.loads((case / 'gate' / 'RESULT.json').read_text())
        assert row['actual_process_returncode'] == gate['gate_exit'] == expected_exit
        assert (gitdir / 'config').read_bytes() == before
        assert b'url =' not in before
        result['cases'].append({'name': name, 'fixture_config_sha256': digest(before),
                                'actual_gate_exit': row['actual_process_returncode'],
                                'expected_gate_exit': expected_exit, 'result': gate})
    assert ORIGINAL.read_bytes() == original
    result.update(exit_code=0, original_tool_unchanged=True,
                  gate_sequence=[x['actual_gate_exit'] for x in result['cases']],
                  proposal_applied=False)
finally:
    result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(ROOT / 'RESULT.json', result)
print(json.dumps({'exit_code': result['exit_code'], 'gate_sequence': result['gate_sequence'],
                  'result': str(ROOT / 'RESULT.json'), 'sha256': digest((ROOT / 'RESULT.json').read_bytes())}))
