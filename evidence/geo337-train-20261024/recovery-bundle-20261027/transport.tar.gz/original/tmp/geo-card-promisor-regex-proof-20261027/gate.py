"""Synthetic-only regression gate; no network or production mutation."""
import hashlib
import importlib.util
import json
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
CAPTURE = pathlib.Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
SPEC = importlib.util.spec_from_file_location('capture', CAPTURE)
CAP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CAP)
case = sys.argv[1]
assert case in {'actual_regex_promisor', 'mutant_regex_promisor', 'restored_no_promisor'}
out = ROOT / case / 'gate'
out.mkdir()
rec = CAP.Recorder(out, dict(os.environ), 'synthetic-local-only')
pattern = r'^remote\\..*\\.promisor$' if case == 'mutant_regex_promisor' else r'^remote\..*\.promisor$'
expected_present = case != 'restored_no_promisor'
argv = ['git', '--no-lazy-fetch', '--git-dir=' + str(ROOT / case / 'fixture.git'),
        'config', '--get-regexp', pattern]
row, stdout, stderr = rec.run(argv, cwd=ROOT, check=False, timeout=30, source_variant=case)
detected = row['actual_process_returncode'] == 0 and stdout == b'remote.origin.promisor true\n'
normal_query = row['actual_process_returncode'] in (0, 1) and stderr == b''
passed = normal_query and detected == expected_present
result = {'case': case, 'gate': 'effective_promisor_policy_matches_fixture',
          'regex': pattern, 'query_command': argv,
          'expected_promisor_present': expected_present,
          'query_actual_exit': row['actual_process_returncode'],
          'query_stdout_utf8': stdout.decode(), 'query_stderr_utf8': stderr.decode(),
          'detected_promisor': detected, 'production_guard_would_accept':
          row['actual_process_returncode'] == 1 and stdout == b'',
          'gate_exit': 0 if passed else 1,
          'query_stdout_sha256': hashlib.sha256(stdout).hexdigest(),
          'query_stderr_sha256': hashlib.sha256(stderr).hexdigest(),
          'scope': 'Synthetic query correctness only; no real provider or publisher execution'}
(out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, sort_keys=True))
sys.exit(result['gate_exit'])
