"""Archive the reviewed closed card selection once; no tests, cleanup or API."""
from pathlib import Path
import gzip, hashlib, io, json, os, shutil, stat, tarfile

TOOLS=Path('/tmp/geo-card-F-delivery-20261027')
ROOT=Path('/dev/shm/geometry-axiom-geo337-20261025/card-F-delivery-20261027')
BROWSER=Path('/dev/shm/geo337-F9-browsers-20261025')
REVIEW=Path('/tmp/geo-card-F-formal-20261027')
SELECTION_HASH='83fa3e6d4922e97f6e9f3994f580e640fc1f7c67932c457573da8bcf34df3d1e'
PEER_HASH='80615fd46f55ecc5aa0e15b6fa77de86a0b6eb63fcb20260bfc0ef0c9be439d4'
OWNS=[ROOT.parent,BROWSER]
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'

def h(b):return hashlib.sha256(b).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def meta(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def own_used():
 seen=set();total=0
 for root in OWNS:
  assert root.is_dir() and root.resolve()==root and not root.is_symlink()
  for p in [root]+list(root.rglob('*')):
   s=p.lstat();key=s.st_dev,s.st_ino
   if key not in seen:seen.add(key);total+=s.st_blocks*512
 return total
def main():
 assert not ROOT.exists(),'single new archive directory only'
 sr=(REVIEW/'SELECTION.json').read_bytes();assert h(sr)==SELECTION_HASH
 assert h((REVIEW/'ACTUAL_PEER.json').read_bytes())==PEER_HASH
 selection=json.loads(sr);assert selection['source_sha']==F
 assert len(selection['files'])==987 and sum(r['bytes'] for r in selection['files'])==152414354
 assert len(selection['directories'])==126 and not selection['nonregular']
 entries=[];snapshots={};members={};metaonly=[]
 def add(p,name,expected=None):
  assert not name.startswith('/') and '..' not in Path(name).parts and name not in members
  m=meta(p);snapshots[str(p)]=m
  if expected is not None:
   assert stat.S_IMODE(m[2])==expected['mode'],str(p)
   if 'sha256' in expected:
    assert [m[0],m[1],m[3],m[4]]==[expected[k] for k in ['dev','inode','nlink','bytes']],str(p)
  row={'member':name,'source':str(p),'original_metadata':m}
  if stat.S_ISDIR(m[2]):row['type']='directory'
  elif stat.S_ISREG(m[2]):
   b=p.read_bytes();assert meta(p)==m
   row.update(type='file',bytes=len(b),sha256=h(b))
   if expected is not None:assert row['sha256']==expected['sha256']
  else:
   row.update(type='metadata_only',link_target=os.readlink(p) if stat.S_ISLNK(m[2]) else None)
   if expected is not None:assert row['link_target']==expected['link_target']
   metaonly.append(row)
  entries.append(row);members[name]=row
 rawroot=Path(selection['root'])
 assert rawroot==Path('/dev/shm/geometry-axiom-geo337-20261025/card-F-cbf0fb62-formal-20261027')
 assert rawroot.resolve()==rawroot and rawroot.is_dir() and not rawroot.is_symlink()
 assert {'.'}|{p.relative_to(rawroot).as_posix() for p in rawroot.rglob('*')}=={r['path'] for group in ['directories','files'] for r in selection[group]},'complete original namespace drift'
 for group in ['directories','files']:
  for row in selection[group]:
   rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
   add(rawroot/rel,'card-original'+('/'+rel.as_posix() if rel.as_posix()!='.' else ''),row)
 for alias,src in [('card-tools',REVIEW)]:
  assert src.resolve()==src and not src.is_symlink()
  for p in [src]+sorted(src.rglob('*')):add(p,alias+('/'+p.relative_to(src).as_posix() if p!=src else ''))
 add(Path('/tmp/geo-documents-F-delivery-20261027/ACTUAL_PEER.json'),'previous-documents-delivery-ACTUAL_PEER.json')
 add(TOOLS/'ROOT_TERMINAL.json','card-ROOT_TERMINAL.json')
 index={'schema':'card-F-closed-delivery/1','execution_source_sha':F,'selection_sha256':SELECTION_HASH,
        'selected_original_files':987,'selected_original_logical_bytes':152414354,'selected_original_directories':126,
        'original_nonregular_metadata_only':[],
        'excluded_original_source_namespaces':[],
        'selection_rule':selection['rule'],'entries':entries,
        'scope':['Only fixed F card formal result; new Fprime is distinct and not marked passed.',
                 'All 116 ELF and every original descendant including empty directories preserved.',
                 'All selected compiler/test streams, source/fixture guard, private backups and runtime artifacts preserved.',
                 'No deletion, product rerun, remote writes or approval expansion.',
                 'Fprime source-impact report does not automatically authorize cross-SHA transfer.']}
 extras={'INDEX.json':js(index),'PACKAGER.py':Path(__file__).read_bytes(),'CURRENT_PROGRESS.md':(TOOLS/'PROGRESS.md').read_bytes()}
 # No compression-ratio assumption: a rounded tar bound plus generous gzip framing,
 # then retain packet + original 3P publication allowance + 64MiB and 16MiB metadata.
 tar_bound=sum(512+(r.get('bytes',0)+511)//512*512 for r in entries if r['type']!='metadata_only')
 tar_bound+=sum(512+(len(b)+511)//512*512 for b in extras.values())+1048576
 gzip_bound=tar_bound+tar_bound//100+1048576
 chain_bound=4*gzip_bound+67108864+16777216
 used=own_used();free=shutil.disk_usage(ROOT.parent).free
 assert used+chain_bound<=4294967296 and free>chain_bound,'complete SHM chain admission failed'
 ROOT.mkdir(mode=0o700)
 plan={'two_OWN_before':used,'actual_mount':str(ROOT.parent),'actual_free_before':free,'tar_bound':tar_bound,
       'gzip_bound':gzip_bound,'retained_packet_plus_publication_bound':chain_bound,'ceiling':4294967296,
       'publication_reserve':67108864,'TMP_native_guard_changed':False,'compression_assumption':False}
 extras['PACKAGE_ADMISSION.json']=js(plan)
 with (ROOT/'EVIDENCE.tar.gz').open('xb') as sink:
  with gzip.GzipFile(filename='',mode='wb',fileobj=sink,compresslevel=9,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
    for row in entries:
     if row['type']=='metadata_only':continue
     ti=tarfile.TarInfo(row['member']);ti.mtime=0;ti.mode=0o755 if row['type']=='directory' else 0o644
     if row['type']=='directory':ti.type=tarfile.DIRTYPE;t.addfile(ti)
     else:
      p=Path(row['source']);assert meta(p)==snapshots[str(p)];b=p.read_bytes()
      assert len(b)==row['bytes'] and h(b)==row['sha256'];ti.size=len(b);t.addfile(ti,io.BytesIO(b))
    for name,b in sorted(extras.items()):
     ti=tarfile.TarInfo(name);ti.mode=0o644;ti.mtime=0;ti.size=len(b);t.addfile(ti,io.BytesIO(b))
 assert (ROOT/'EVIDENCE.tar.gz').stat().st_size<=gzip_bound
 with tarfile.open(ROOT/'EVIDENCE.tar.gz','r:gz') as t:
  seen=set()
  for m in t:
   assert m.name not in seen and not m.name.startswith('/') and '..' not in Path(m.name).parts;seen.add(m.name)
   if m.name in extras:assert t.extractfile(m).read()==extras[m.name]
   elif m.isdir():assert members[m.name]['type']=='directory'
   else:
    assert m.isfile() and members[m.name]['type']=='file';b=t.extractfile(m).read()
    assert len(b)==members[m.name]['bytes'] and h(b)==members[m.name]['sha256']
  assert seen=={r['member'] for r in entries if r['type']!='metadata_only'}|set(extras)
 for p,m in snapshots.items():assert meta(Path(p))==m,'original metadata drift '+p
 (ROOT/'PROGRESS.md').write_bytes((TOOLS/'PROGRESS.md').read_bytes())
 prefix='evidence/geo337-train-20261024/';manifest={'files':[]}
 for local,dst in [('EVIDENCE.tar.gz',prefix+'card-F-cbf0fb62-20261027/EVIDENCE.tar.gz'),('PROGRESS.md',prefix+'resume-20261026/PROGRESS.md')]:
  b=(ROOT/local).read_bytes();manifest['files'].append({'source_path':str(ROOT/local),'destination':dst,'bytes':len(b),'sha256':h(b)})
 (ROOT/'MANIFEST.json').write_bytes(js(manifest))
 result={'exit_code':0,'archive_bytes':(ROOT/'EVIDENCE.tar.gz').stat().st_size,'archive_sha256':manifest['files'][0]['sha256'],
         'members':len(seen),'original_regular_files':sum(r['type']=='file' for r in entries),
         'original_directories':sum(r['type']=='directory' for r in entries),'nonregular_metadata_only':len(metaonly),
         'roundtrip_verified':True,'original_metadata_preserved':True,'admission':plan,
         'manifest_sha256':h((ROOT/'MANIFEST.json').read_bytes())}
 (TOOLS/'PACKAGE_RESULT.json').write_bytes(js(result));print(json.dumps(result))
if __name__=='__main__':main()
