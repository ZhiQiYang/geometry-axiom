本機 Git transport 反證；不屬產品 gate。

指令：`python3 -B /tmp/geo-card-no-fetch-proof-20261027/prove.py`，tool chunk `d1fc3c`，outer exit 0。三個獨立 receiver 的 `oldblob_not_copied` 真正 exit 為 0/1/0。所有原始命令與 stdin/stdout/stderr/exit/hash 在 `raw/`；withdrawn-gate 的內層 verify-pack 輸出另保留。

僅 354 bytes、2 objects 的 incoming pack 在 `index-pack --stdin --promisor` 下，會從非 promisor alternate 複製舊 blob/tree/base，`GIT_NO_LAZY_FETCH=1` 無法阻止。移除這條 ingestion 路徑，以普通本地 hash-object/mktree/commit-tree 建精確兩葉變更，兩個 fixed receiver 均只有新物件。

沒有任何 network/fetch/push；所有 fixture 保留。provider前後metadata/hash比較於原程式記憶體執行、未另存兩份snapshot，此限制保留。正式工具仍須自己的來源/範圍/容量/遠端核對守門。
