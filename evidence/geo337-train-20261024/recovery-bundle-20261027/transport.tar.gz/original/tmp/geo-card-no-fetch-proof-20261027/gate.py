import argparse, hashlib, importlib.util, json, os, re
from pathlib import Path

ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--forbidden',type=Path,required=True);a=ap.parse_args()
root=Path('/tmp/geo-card-no-fetch-proof-20261027');assert a.repo.parent==root and a.out.parent==root
a.out.mkdir(mode=0o700,exist_ok=False)
cap_path=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(cap_path.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
sp=importlib.util.spec_from_file_location('capture',cap_path);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
forbid=json.loads(a.forbidden.read_bytes());rec=cap.Recorder(a.out,dict(os.environ),forbid['base_commit'])
local=set()
for p in sorted((a.repo/'objects').glob('[0-9a-f][0-9a-f]/*')):
 if p.is_file():
  oid=p.parent.name+p.name;assert re.fullmatch('[0-9a-f]{40}',oid);local.add(oid)
packs=[]
for idx in sorted((a.repo/'objects/pack').glob('*.idx')):
 row,b,_=rec.run(['git','--git-dir='+str(a.repo),'verify-pack','-v',str(idx)],cwd=root,timeout=30,source_variant='tiny synthetic own-ODB inventory; no network')
 for line in b.decode().splitlines():
  parts=line.split()
  if len(parts)>1 and re.fullmatch('[0-9a-f]{40}',parts[0]) and parts[1] in ['blob','tree','commit','tag']:local.add(parts[0])
 packs.append(str(idx))
copied=sorted(set(forbid['old_object_oids'])&local)
passed=forbid['old_blob'] not in local and forbid['old_tree'] not in local
result={'gate':'oldblob_not_copied','exit_code':0 if passed else 1,'old_blob_copied':forbid['old_blob'] in local,'old_tree_copied':forbid['old_tree'] in local,'copied_old_oids':copied,'local_oids':sorted(local),'pack_indexes':packs,'GIT_NO_LAZY_FETCH':os.environ.get('GIT_NO_LAZY_FETCH'),'network_used':False}
(a.out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(result['exit_code'])
