"""Tiny local Git repack_local_links withdrawal/restoration proof. No network."""
import hashlib,importlib.util,json,os,re,sys,shutil
from pathlib import Path
root=Path('/tmp/geo-card-no-fetch-proof-20261027');assert sys.dont_write_bytecode and not sys.flags.optimize
assert not (root/'raw').exists();assert shutil.disk_usage(root).free>8*1024*1024
cap_path=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(cap_path.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
sp=importlib.util.spec_from_file_location('capture',cap_path);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_AUTHOR_DATE='2026-10-27T00:00:00+00:00',GIT_COMMITTER_DATE='2026-10-27T00:00:00+00:00')
(root/'raw').mkdir(mode=0o700);rec=cap.Recorder(root/'raw',env,'synthetic-local-transport-proof')
def run(argv,data=None,expected=0):
 assert not any(x in ['fetch','push','clone'] for x in argv)
 row,b,e=rec.run(argv,cwd=root,data=data,timeout=30,check=False,source_variant='tiny synthetic fixture only; not product gate')
 assert row['actual_process_returncode']==expected,(argv,row['actual_process_returncode']);return b
def git(repo,*args,data=None):return run(['git','--git-dir='+str(repo),'-c','gc.auto=0','-c','maintenance.auto=false',*args],data)
def oid(b):
 s=b.decode().strip();assert re.fullmatch('[0-9a-f]{40}',s);return s
def init(name,borrow=None):
 p=root/name;assert not p.exists();run(['git','init','--bare','--initial-branch=fixture',str(p)])
 if borrow:(p/'objects/info/alternates').write_text(str(borrow/'objects')+'\n')
 return p
def blob(repo,b):return oid(git(repo,'hash-object','-w','--stdin',data=b))
def tree(repo,entries):return oid(git(repo,'mktree',data=b''.join((mode+' '+kind+' '+obj+'\t'+name+'\n').encode() for mode,kind,obj,name in entries)))
def commit(repo,tr,parent=None):
 args=['-c','user.name=Local transport proof','-c','user.email=proof@example.invalid','commit-tree',tr]
 if parent:args+=['-p',parent]
 return oid(git(repo,*args,data=b'synthetic evidence fixture\n'))
def snap(repo):
 return {str(p.relative_to(repo)):[p.stat().st_mode,p.stat().st_nlink,p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ctime_ns,hashlib.sha256(p.read_bytes()).hexdigest()] for p in sorted(repo.rglob('*')) if p.is_file()}
version=run(['git','--version']).decode().strip();provider=init('provider.git')
oldblob=blob(provider,b'old immutable blob; must remain only in provider\n')
oldtree=tree(provider,[('100644','blob',oldblob,'kept.txt')])
basetree=tree(provider,[('100644','blob',oldblob,'PROGRESS.md'),('040000','tree',oldtree,'kept'),('100644','blob',oldblob,'old.txt')]);base=commit(provider,basetree)
git(provider,'update-ref','refs/heads/fixture',base,'0'*40);before=snap(provider)
forbid={'base_commit':base,'old_blob':oldblob,'old_tree':oldtree,'old_object_oids':[oldblob,oldtree,basetree,base]};(root/'FORBIDDEN.json').write_text(json.dumps(forbid,indent=2)+'\n')
def build(repo):
 packet=blob(repo,b'new tiny evidence packet\n');progress=blob(repo,b'new progress\n')
 tr=tree(repo,[('100644','blob',packet,'EVIDENCE.bin'),('100644','blob',progress,'PROGRESS.md'),('040000','tree',oldtree,'kept'),('100644','blob',oldblob,'old.txt')]);co=commit(repo,tr,base)
 diff=git(repo,'diff-tree','--no-commit-id','--no-renames','--name-status','-r','-z',base,co).split(b'\0');assert diff==[b'A',b'EVIDENCE.bin',b'M',b'PROGRESS.md',b'']
 return co,tr
builder=init('builder.git',provider);newcommit,newtree=build(builder)
incoming=git(builder,'pack-objects','--stdout',data=(newcommit+'\n'+newtree+'\n').encode());(root/'incoming-metadata.pack').write_bytes(incoming)
assert len(incoming)<4096
results=[]
for label,expected in [('fixed',0),('withdrawn',1),('restored',0)]:
 receiver=init(label+'.git',provider)
 if label=='withdrawn':
  git(receiver,'index-pack','--stdin','--promisor',data=incoming)
 else:
  c,t=build(receiver);assert c==newcommit and t==newtree
 payload=run([sys.executable,'-B',str(root/'gate.py'),'--repo',str(receiver),'--out',str(root/(label+'-gate')),'--forbidden',str(root/'FORBIDDEN.json')],expected=expected)
 result=json.loads(payload);results.append(result)
assert [x['exit_code'] for x in results]==[0,1,0] and results[1]['old_blob_copied'] and results[1]['old_tree_copied']
assert snap(provider)==before
summary={'exit_code':0,'schema':'tiny-no-fetch-transport-proof/1','git_version':version,'source_scope':'synthetic local fixture only, no product source touched','gate':'oldblob_not_copied','gate_exits':[0,1,0],'GIT_NO_LAZY_FETCH':'1','incoming_metadata_pack_bytes':len(incoming),'incoming_metadata_pack_sha256':hashlib.sha256(incoming).hexdigest(),'incoming_objects':[newcommit,newtree],'old_blob':oldblob,'old_tree':oldtree,'base_commit':base,'new_commit':newcommit,'provider_files_unchanged':True,'network_commands':0,'all_fixture_originals_retained':True,'results':results}
(root/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
