"""Publish exactly the reviewed archive and progress, without touching local Git."""
import argparse, base64, hashlib, importlib.util, json, os, re, shutil, sys
from pathlib import Path

ROOT = Path('/dev/shm/geometry-axiom-geo337-20261025/card-F-delivery-20261027')
BRANCH = 'codex/train337-recovered-evidence-20261026'
OLD = '45dd4d662eac9297eda8473742c9943a1cb336cb'
PREFIX = 'evidence/geo337-train-20261024/'
ARCHIVE = PREFIX+'card-F-cbf0fb62-20261027/EVIDENCE.tar.gz'
PROGRESS = PREFIX+'resume-20261026/PROGRESS.md'
OLD_PROGRESS_BLOB = 'bb6fd09082dd7381d6b581f101c415140762d0ef'
OLD_PROGRESS_HASH = '44109ca6d485228284fbdb4ec5feb24cb7ee8438ea08a42115c3e15e389fedb3'
MANIFEST_HASH = '20e6117afe043414856a0a74e7fa49f17bab6603b98077b7fa4f17e9747372e0'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_HASH = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
OWNS = [Path('/dev/shm/geometry-axiom-geo337-20261025'),
        Path('/dev/shm/geo337-F9-browsers-20261025')]

def need(ok, why):
    if not ok:
        raise RuntimeError(why)

def h(b):
    return hashlib.sha256(b).hexdigest()

def oid(b):
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--execute', action='store_true')
    a = ap.parse_args()
    need(not sys.flags.optimize and sys.dont_write_bytecode, 'use python -B without optimization')
    need(ROOT.is_dir() and ROOT.resolve()==ROOT and not ROOT.is_symlink(), 'existing real output root required')
    manifest_path = ROOT/'MANIFEST.json'
    need(manifest_path.is_file() and not manifest_path.is_symlink(), 'regular manifest required')
    raw = manifest_path.read_bytes()
    need(h(raw)==MANIFEST_HASH, 'frozen manifest changed')
    m = json.loads(raw)
    files = m['files']
    need(len(files)==2 and {x['destination'] for x in files}=={ARCHIVE,PROGRESS}, 'exact two allowed paths required')
    allowed = {ARCHIVE:ROOT/'EVIDENCE.tar.gz', PROGRESS:ROOT/'PROGRESS.md'}
    payloads = {}
    for item in files:
        dst = item['destination']
        src = Path(item['source_path'])
        need(src==allowed[dst] and src.resolve()==src and src.is_file() and not src.is_symlink(), 'source outside frozen output inputs')
        need(type(item['bytes']) is int and item['bytes']>0 and re.fullmatch('[0-9a-f]{64}',item['sha256']), 'invalid manifest identity')
        b = src.read_bytes()
        need(len(b)==item['bytes'] and h(b)==item['sha256'], 'input payload drift')
        payloads[dst] = b
    need(h(CAP.read_bytes())==CAP_HASH, 'original recorder changed')
    P = sum(x['bytes'] for x in files)
    L, M = len(files), len(raw)
    budget = 3*P + L*65536 + M*8 + 67108864
    if not a.execute:
        print(json.dumps({'execute':False,'branch':BRANCH,'expected_parent':OLD,
                          'paths':sorted(allowed),'P':P,'L':L,'M':M,'budget':budget}))
        return

    # Original full planning formula, not a reduced metadata minimum.
    used, seen = 0, set()
    for root in OWNS:
        need(root.is_dir() and not root.is_symlink() and root.resolve()==root, 'missing or aliased OWN root')
        for p in root.rglob('*'):
            st = p.lstat()
            key = st.st_dev, st.st_ino
            if key not in seen:
                seen.add(key)
                used += st.st_blocks*512
    free = shutil.disk_usage(ROOT).free
    capacity = {'two_OWN_used':used,'P':P,'L':L,'M':M,'budget':budget,
                'formula':'3P+L*65536+M*8+67108864','ceiling':4294967296,
                'actual_output_mount':str(ROOT),'actual_free_bytes':free}
    print(json.dumps({'admission':capacity}), flush=True)
    need(used+budget<=4294967296, 'current complete two-OWN planning bound failed')
    need(free>budget, 'actual output mount free must exceed complete budget')
    out = ROOT/'publication'
    out.mkdir(exist_ok=False)
    (out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
    (out/'MANIFEST.json').write_bytes(raw)
    spec = importlib.util.spec_from_file_location('original_capture', CAP)
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    rec = capture.Recorder(out, env, OLD)
    result = {'exit_code':1,'branch':BRANCH,'expected_parent':OLD,'published':False,
              'publish_attempted':False,'delivered':False,'product_modified':False,
              'train_ref_modified':False,'capacity':capacity,'verified_blobs':{}}
    def save():
        (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    def api(method, path, payload=None, raw_response=False):
        argv = ['gh','api','--hostname','github.com','--method',method]
        if raw_response:
            argv += ['-H','Accept: application/vnd.github.raw+json']
        argv += ['repos/ZhiQiYang/geometry-axiom/'+path]
        data = None
        if payload is not None:
            argv += ['--input','-']
            data = (json.dumps(payload,ensure_ascii=False)+'\n').encode()
        row,b,err = rec.run(argv,cwd=ROOT,data=data,timeout=180,check=False)
        need(row['actual_process_returncode']==0, 'API command failed; do not retry: '+row['directory'])
        return b if raw_response else json.loads(b)
    try:
        save()
        need(api('GET','git/ref/heads/'+BRANCH)['object']['sha']==OLD, 'recovery ref moved')
        parent = api('GET','git/commits/'+OLD)
        need(parent['sha']==OLD, 'wrong parent commit')
        original = api('GET','contents/'+PROGRESS+'?ref='+OLD)
        need(original['type']=='file' and original['path']==PROGRESS and original['sha']==OLD_PROGRESS_BLOB
             and original['encoding']=='base64', 'wrong original progress blob')
        old = base64.b64decode(original['content'])
        need(len(old)==original['size']==12475 and h(old)==OLD_PROGRESS_HASH and oid(old)==OLD_PROGRESS_BLOB,
             'original progress payload mismatch')
        entries = []
        for dst in sorted(payloads):
            b = payloads[dst]
            blob = api('POST','git/blobs',{'content':base64.b64encode(b).decode(),'encoding':'base64'})['sha']
            need(blob==oid(b), 'new blob OID mismatch')
            entries.append({'path':dst,'mode':'100644','type':'blob','sha':blob})
        tree = api('POST','git/trees',{'base_tree':parent['tree']['sha'],'tree':entries})['sha']
        commit = api('POST','git/commits',{'message':'docs: archive complete F card mutation evidence',
                                        'tree':tree,'parents':[OLD]})
        new = commit['sha']
        need(re.fullmatch('[0-9a-f]{40}',new) and [p['sha'] for p in commit['parents']]==[OLD]
             and commit['tree']['sha']==tree, 'unexpected new parent or tree')
        comparison = api('GET','compare/'+OLD+'...'+new)
        need(comparison['ahead_by']==1 and comparison['behind_by']==0, 'unexpected ancestry')
        need(len(comparison['files'])==2 and {f['filename']:f['status'] for f in comparison['files']}
             =={ARCHIVE:'added',PROGRESS:'modified'}, 'anything outside exact two-leaf evidence scope changed')
        need(manifest_path.read_bytes()==raw and all(allowed[k].read_bytes()==v for k,v in payloads.items()), 'inputs changed before ref update')
        need(api('GET','git/ref/heads/'+BRANCH)['object']['sha']==OLD, 'recovery ref moved before publish')
        result.update(publish_attempted=True,published=None,pending_commit=new,tree=tree,entries=entries)
        save()
        updated = api('PATCH','git/refs/heads/'+BRANCH,{'sha':new,'force':False})
        need(updated['object']['sha']==new, 'ref ACK mismatch')
        result.update(published=True,commit=new)
        save()
        need(api('GET','git/ref/heads/'+BRANCH)['object']['sha']==new, 'new recovery ref differs')
        for entry in entries:
            b = api('GET','git/blobs/'+entry['sha'],raw_response=True)
            need(b==payloads[entry['path']] and oid(b)==entry['sha'], 'complete remote bytes or OID differ')
            result['verified_blobs'][entry['path']] = {'oid':entry['sha'],'bytes':len(b),'sha256':h(b)}
        need(api('GET','git/ref/heads/'+BRANCH)['object']['sha']==new, 'recovery ref moved during verification')
        need(manifest_path.read_bytes()==raw and all(allowed[k].read_bytes()==v for k,v in payloads.items()), 'frozen inputs changed')
        result.update(exit_code=0,delivered=True,ordinary_fast_forward=True,changed_paths=sorted(payloads))
    except BaseException as exc:
        result['error'] = repr(exc)
        raise
    finally:
        save()
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':
    main()
