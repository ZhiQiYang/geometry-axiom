"""Publish the fixed card packet by ordinary Git after API input-size 422."""
import argparse, base64, hashlib, importlib.util, json, os, re, shutil, stat, sys
from pathlib import Path

ROOT=Path('/dev/shm/geometry-axiom-geo337-20261025/card-F-git-delivery-20261027')
PROVIDER=ROOT.parent/'publisher-source/.git'
ARCHIVE_SOURCE=ROOT.parent/'card-F-delivery-20261027/EVIDENCE.tar.gz'
FAILED=ROOT.parent/'card-F-delivery-20261027/publication'
OLD='45dd4d662eac9297eda8473742c9943a1cb336cb'
BRANCH='codex/train337-recovered-evidence-20261026'
REMOTE='https://github.com/ZhiQiYang/geometry-axiom.git'
PREFIX='evidence/geo337-train-20261024/'
ARCHIVE=PREFIX+'card-F-cbf0fb62-20261027/EVIDENCE.tar.gz'
PROGRESS=PREFIX+'resume-20261026/PROGRESS.md'
MANIFEST_HASH='d7c85e221dc2ff348da4e561b11e4f3f3adf1d50bda0dcaeda4424dbe8f0e522'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_HASH='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
OWNS=[ROOT.parent,Path('/dev/shm/geo337-F9-browsers-20261025')]

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def h(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def meta(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def used():
 seen=set();total=0
 for root in OWNS:
  need(root.is_dir() and root.resolve()==root and not root.is_symlink(),'real OWN root')
  for p in [root]+list(root.rglob('*')):
   s=p.lstat();k=s.st_dev,s.st_ino
   if k not in seen:seen.add(k);total+=s.st_blocks*512
 return total
def snapshot_provider():
 need(PROVIDER.is_dir() and PROVIDER.resolve()==PROVIDER and not PROVIDER.is_symlink(),'private original provider')
 result={}
 candidates=[PROVIDER/n for n in ['HEAD','index','config','packed-refs','FETCH_HEAD','shallow','objects/info/alternates']]
 candidates+=list((PROVIDER/'refs').rglob('*')) if (PROVIDER/'refs').exists() else []
 for p in sorted(set(candidates)):
  if not p.exists():result[str(p.relative_to(PROVIDER))]=None;continue
  m=meta(p);need(not p.is_symlink(),'provider metadata symlink')
  result[str(p.relative_to(PROVIDER))]={'meta':m,'sha256':h(p.read_bytes()) if p.is_file() else None}
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');args=ap.parse_args()
 need(not sys.flags.optimize and sys.dont_write_bytecode,'python -B without optimize')
 need(ROOT.is_dir() and ROOT.resolve()==ROOT and not ROOT.is_symlink(),'real prepared output root')
 mraw=(ROOT/'MANIFEST.json').read_bytes();need(h(mraw)==MANIFEST_HASH,'manifest pin')
 files=json.loads(mraw)['files'];need(len(files)==2 and {f['destination'] for f in files}=={ARCHIVE,PROGRESS},'two frozen leaves')
 allowed={ARCHIVE:ARCHIVE_SOURCE,PROGRESS:ROOT/'PROGRESS.md'};payloads={}
 for f in files:
  p=Path(f['source_path']);need(p==allowed[f['destination']] and p.resolve()==p and p.is_file() and not p.is_symlink(),'frozen source path')
  b=p.read_bytes();need(len(b)==f['bytes'] and h(b)==f['sha256'],'frozen source bytes');payloads[f['destination']]=b
 need(len(payloads[ARCHIVE])==55775729 and h(payloads[ARCHIVE])=='475678a2227d503ba0781eb578ee86d27fa13716fb146ba510f62f0144097be9','original archive unchanged')
 P=sum(len(b) for b in payloads.values());base_budget=3*P+2*65536+len(mraw)*8+67108864
 # Retain the full original formula, add a separate metadata/pack bookkeeping allowance.
 extra_metadata=67108864;budget=base_budget+extra_metadata
 if not args.execute:
  print(json.dumps({'execute':False,'expected_parent':OLD,'paths':sorted(payloads),'P':P,'M':len(mraw),'original_formula_budget':base_budget,'extra_private_metadata_allowance':extra_metadata,'total_budget':budget}));return
 need(h(CAP.read_bytes())==CAP_HASH,'original recorder changed')
 occupancy=used();free=shutil.disk_usage(ROOT).free
 need(occupancy+budget<=4294967296 and free>budget,'fresh full-chain actual-mount admission')
 out=ROOT/'git-publication';out.mkdir(mode=0o700,exist_ok=False)
 (out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'MANIFEST.json').write_bytes(mraw)
 sp=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
 env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_NO_LAZY_FETCH='1')
 rec=cap.Recorder(out,env,OLD);gitdir=out/'repo.git'
 result={'exit_code':1,'branch':BRANCH,'expected_parent':OLD,'published':False,'push_attempted':False,'delivered':False,'product_modified':False,'train_ref_modified':False,'capacity':{'two_OWN_before':occupancy,'actual_mount':str(ROOT),'actual_free_before':free,'P':P,'L':2,'M':len(mraw),'original_formula':'3P+L*65536+M*8+67108864','original_formula_budget':base_budget,'extra_private_metadata_allowance':extra_metadata,'total_budget':budget,'ceiling':4294967296},'verified_blobs':{}}
 def save():(out/'RESULT.json').write_bytes(js(result))
 def run(cmd,data=None,check=True):
  row,b,err=rec.run(cmd,cwd=ROOT,data=data,timeout=180,check=False)
  if check:need(row['actual_process_returncode']==0,'command failed; preserve, no retry: '+row['directory'])
  return row,b,err
 def git(*a,data=None):return run(['git','--git-dir='+str(gitdir),'-c','gc.auto=0','-c','maintenance.auto=false',*a],data=data)[1]
 def object_id(b):
  s=b.decode().strip();need(re.fullmatch('[0-9a-f]{40}',s),'full Git OID');return s
 def ref():
  raw=git('ls-remote','--heads',REMOTE,'refs/heads/'+BRANCH)
  rows=raw.decode().splitlines();need(len(rows)==1,'single remote branch');sha,name=rows[0].split('\t');need(name=='refs/heads/'+BRANCH and re.fullmatch('[0-9a-f]{40}',sha),'exact remote ref');return sha
 def api(path,raw=False):
  cmd=['gh','api','--hostname','github.com']
  if raw:cmd+=['-H','Accept: application/vnd.github.raw+json']
  cmd+=['repos/ZhiQiYang/geometry-axiom/'+path]
  b=run(cmd)[1];return b if raw else json.loads(b)
 before=None;failure_index={}
 try:
  save();before=snapshot_provider();(out/'PROVIDER_BEFORE.json').write_bytes(js(before))
  failed=json.loads((FAILED/'RESULT.json').read_bytes())
  need(failed['exit_code']==1 and failed['published'] is False and failed['publish_attempted'] is False,'expected untouched failed API state')
  fr=json.loads((FAILED/'subcommands.json').read_bytes());need(len(fr)==4 and fr[-1]['actual_process_returncode']!=0,'only first blob API failed')
  need(h((FAILED/'subcommands/000004/stdout.bin').read_bytes())=='22970568d7bdb2b2d6d95efaf8d26b752ab0228c62f6ee4d74b2b109caa343d7','exact input-size 422')
  for p in [FAILED/'RESULT.json',FAILED/'subcommands.json']+sorted((FAILED/'subcommands').rglob('*')):
   if p.is_file():failure_index[str(p)]={'meta':meta(p),'sha256':h(p.read_bytes())}
  (out/'ORIGINAL_API_FAILURE_INDEX.json').write_bytes(js(failure_index))
  run(['git','init','--bare','--initial-branch=metadata-only',str(gitdir)])
  (gitdir/'objects/info/alternates').write_text(str(PROVIDER/'objects')+'\n')
  need(Path(git('rev-parse','--absolute-git-dir').decode().strip())==gitdir,'fresh private Gitdir')
  need(ref()==OLD,'remote parent moved before fetch')
  _,_,fetcherr=run(['git','--git-dir='+str(gitdir),'-c','gc.auto=0','-c','maintenance.auto=false','fetch','--filter=blob:none','--depth=1','--no-tags','--no-write-fetch-head',REMOTE,OLD+':refs/heads/fixed-parent'])
  need(b'filtering not recognized' not in fetcherr.lower(),'filter unsupported; no unfiltered fallback')
  need(object_id(git('rev-parse','refs/heads/fixed-parent'))==OLD,'fetched exact expected parent')
  packstats=[]
  for idx in sorted((gitdir/'objects/pack').glob('*.idx')):
   raw=git('verify-pack','-v',str(idx));lines=raw.decode().splitlines()
   need(not any(len(x.split())>1 and x.split()[1]=='blob' for x in lines),'metadata fetch unexpectedly contains blobs')
   packstats.append({'index':str(idx),'bytes':idx.stat().st_size,'sha256':h(idx.read_bytes())})
  metadata_used=sum(p.lstat().st_blocks*512 for p in gitdir.rglob('*'))
  need(metadata_used<extra_metadata,'private fetched metadata exceeded additional allowance')
  result['metadata_fetch']={'allocated_bytes':metadata_used,'packs':packstats,'filter':'blob:none','depth':1}
  oldprogress=api('contents/'+PROGRESS+'?ref='+OLD);oldbytes=base64.b64decode(oldprogress['content'])
  need(len(oldbytes)==oldprogress['size']==12475 and h(oldbytes)=='44109ca6d485228284fbdb4ec5feb24cb7ee8438ea08a42115c3e15e389fedb3' and oid(oldbytes)==oldprogress['sha']=='bb6fd09082dd7381d6b581f101c415140762d0ef','full original PROGRESS binding')
  entries={}
  for dst in sorted(payloads):
   entries[dst]=object_id(git('hash-object','-w','--no-filters','--',str(allowed[dst])))
   need(entries[dst]==oid(payloads[dst]),'new local blob OID')
  def readtree(tree):
   rows={}
   if tree:
    for line in git('ls-tree','-z',tree).split(b'\0'):
     if line:
      head,name=line.split(b'\t',1);mode,kind,obj=head.split(b' ');rows[name.decode()]=(mode,kind,obj)
   return rows
  def update(tree,changes,prefix=''):
   rows=readtree(tree);groups={}
   for path,blob in changes.items():
    first,sep,tail=path.partition('/');groups.setdefault(first,{})[tail if sep else '']=blob
   for name,g in groups.items():
    previous=rows.get(name);full=prefix+name
    if '' in g:
     need(len(g)==1 and full in entries,'exact evidence leaf')
     if full==ARCHIVE:need(previous is None,'archive must be new')
     else:need(full==PROGRESS and previous==(b'100644',b'blob',b'bb6fd09082dd7381d6b581f101c415140762d0ef'),'only frozen PROGRESS replacement')
     rows[name]=(b'100644',b'blob',g[''].encode())
    else:
     need(previous is None or previous[:2]==(b'040000',b'tree'),'tree collision')
     child=update(previous[2].decode() if previous else None,g,full+'/');rows[name]=(b'040000',b'tree',child.encode())
   data=b''.join(mode+b' '+kind+b' '+obj+b'\t'+name.encode()+b'\0' for name,(mode,kind,obj) in rows.items())
   # Unchanged parent blobs intentionally absent in the private blobless object DB.
   treeid=object_id(git('mktree','--missing','-z',data=data));need(readtree(treeid)==rows,'exact tree entries');return treeid
  tree=update(object_id(git('rev-parse',OLD+'^{tree}')),entries)
  new=object_id(git('-c','user.name=Codex','-c','user.email=codex@openai.com','commit-tree',tree,'-p',OLD,data=b'docs: publish complete card evidence through ordinary Git\n'))
  need(git('rev-list','--parents','-n','1',new).decode().strip()==new+' '+OLD,'single expected parent')
  changes=git('diff-tree','--no-commit-id','--no-renames','--name-status','-r','-z',OLD,new).split(b'\0');need(changes[-1]==b'','terminated diff');changes=changes[:-1]
  need(len(changes)==4 and dict(zip(changes[1::2],changes[0::2]))=={ARCHIVE.encode():b'A',PROGRESS.encode():b'M'},'only exact two evidence paths')
  need(snapshot_provider()==before,'provider metadata changed before push')
  need((ROOT/'MANIFEST.json').read_bytes()==mraw and all(allowed[k].read_bytes()==v for k,v in payloads.items()),'frozen payload drift')
  need(ref()==OLD,'remote parent moved before ordinary push')
  git('update-ref','refs/heads/delivery',new,'0'*40)
  result.update(push_attempted=True,published=None,pending_commit=new,tree=tree,entries=entries);save()
  git('push','--porcelain',REMOTE,'refs/heads/delivery:refs/heads/'+BRANCH)
  result.update(published=True,commit=new);save();need(ref()==new,'remote ref after push')
  for dst in sorted(entries):
   b=api('git/blobs/'+entries[dst],raw=True)
   need(b==payloads[dst] and oid(b)==entries[dst],'complete remote blob bytes/hash/OID')
   result['verified_blobs'][dst]={'bytes':len(b),'sha256':h(b),'oid':entries[dst]}
  need(ref()==new,'remote ref after full verification')
  need((ROOT/'MANIFEST.json').read_bytes()==mraw and all(allowed[k].read_bytes()==v for k,v in payloads.items()),'final payload drift')
  result.update(exit_code=0,delivered=True,ordinary_fast_forward=True,changed_paths=sorted(payloads))
 except BaseException as exc:result['error']=repr(exc);raise
 finally:
  try:
   if before is not None:
    after=snapshot_provider();(out/'PROVIDER_AFTER.json').write_bytes(js(after));result['provider_metadata_unchanged']=after==before
    if after!=before:result.update(exit_code=1,delivered=False,provider_error='provider metadata changed during private publication')
   result['original_API_failure_unchanged']=all(meta(Path(p))==v['meta'] and h(Path(p).read_bytes())==v['sha256'] for p,v in failure_index.items())
   if not result['original_API_failure_unchanged']:result.update(exit_code=1,delivered=False,failure_preservation_error=True)
  finally:save()
 need(result['exit_code']==0,'publication or preservation failed')
 print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
