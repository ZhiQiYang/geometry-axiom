from pathlib import Path
import datetime,hashlib,importlib.util,json,os,resource
R=Path('/workspace/geometry-axiom');L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
O=Path('/workspace/geo337-final-L-architecture');O.mkdir();T=O/'tmp';T.mkdir()
p=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s=importlib.util.spec_from_file_location('cap',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
e={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','MUTATE_','GEOMETRY_'))};e.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TMPDIR=str(T),GIT_OPTIONAL_LOCKS='0',GITHUB_SHA=L,GITHUB_WORKSPACE=str(R))
for k in ['PYTHONOPTIMIZE','NODE_OPTIONS','PYTHONPATH','PYTHONSTARTUP']:e.pop(k,None)
r=m.Recorder(O,e,L)
def run(a):return r.run(a,cwd=R,timeout=None,check=False,source_variant='fixed-L-original-architecture-gates')
head=run(['git','rev-parse','HEAD']);assert head[0]['actual_process_returncode']==0 and head[1].decode().strip()==L
clean=run(['git','status','--porcelain=v1','--untracked-files=all']);assert clean[0]['actual_process_returncode']==0 and not clean[1]
index=R/'.git/index';before=hashlib.sha256(index.read_bytes()).hexdigest()
manifest=json.loads((R/'geometry-core/domain-decoupling/product-architecture.json').read_text());inputs={x['path']:hashlib.sha256((R/x['path']).read_bytes()).hexdigest() for x in manifest['sources']+manifest['exclusions']}
m.dump(O/'before.json',dict(head=L,index_sha256=before,input_hashes=inputs,free_bytes={str(x):os.statvfs(x).f_bavail*os.statvfs(x).f_frsize for x in [R,Path('/tmp')]}))
commands=[['python3','-B','tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json'],['python3','-B','tests/test_architecture_contract.py'],['python3','-B','tests/test_product_architecture.py']]
rows=[run(a)[0] for a in commands]
end=run(['git','rev-parse','HEAD']);status=run(['git','status','--porcelain=v1','--untracked-files=all']);assert end[1].decode().strip()==L and status[0]['actual_process_returncode']==0 and not status[1]
assert hashlib.sha256(index.read_bytes()).hexdigest()==before
assert inputs=={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in inputs}
result=dict(source_sha=L,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase_exits=[x['actual_process_returncode'] for x in rows],source_and_index_unchanged=True,input_count=len(inputs),tool_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),commands=r.rows)
m.dump(O/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='commands'}));raise SystemExit(0 if all(x['actual_process_returncode']==0 for x in rows) else 1)
