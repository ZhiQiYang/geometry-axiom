import hashlib
import importlib.util
import json
import os
from pathlib import Path

F='125c4d8a3f12ab292b15d7c2652d3dcdae521832'
DRIVER=Path('/workspace/clear_terminal_baseline_runtime_elfs.py')
OUT=Path('/workspace/terminal-baseline-runtime-54-launch-20261023')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='df571547c732fc47a16a10cebbdc113f351ec8dca1d5bb51070e75b9f5d90821'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in ('NODE_OPTIONS','PYTHONOPTIMIZE'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,F)
cap.dump(OUT/'launch-context.json',dict(source_sha=F,driver_sha256=sha(DRIVER),outer_timeout=None,free_bytes={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']},purpose='Unlink only 54 exact rebuildable baseline runtime ELF cache files from 18 terminal browser jobs; retain sidecars, source and original receipts.'))
row,out,err=rec.run(['python3','-B',str(DRIVER)],cwd='/workspace/geometry-axiom',timeout=None,check=False,source_variant='root-owned-terminal-baseline-runtime-retirement')
cap.dump(OUT/'receipt.json',dict(source_sha=F,driver_sha256=sha(DRIVER),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
