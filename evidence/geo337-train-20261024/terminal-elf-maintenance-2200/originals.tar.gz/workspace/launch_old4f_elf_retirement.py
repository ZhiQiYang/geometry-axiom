import hashlib
import importlib.util
import json
import os
from pathlib import Path

F='125c4d8a3f12ab292b15d7c2652d3dcdae521832'
DRIVER=Path('/tmp/train337-old4f-elf-cache-prep/unlink_exact_old_elf_cache.py')
OUT=Path('/workspace/old4f-elf-retirement-launch-20261023')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='151c5b1116e49cf62c569cae930811cbcb33ceffdffec8c33a831634f7c3fce6'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in ('NODE_OPTIONS','PYTHONOPTIMIZE'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,F)
cap.dump(OUT/'launch-context.json',dict(source_sha=F,driver_sha256=sha(DRIVER),outer_timeout=None,free_bytes={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']},purpose='Unlink only 76 exact retired rebuildable ELF cache files from the failed old4f ledger attempt; retain sidecars, sources and full original receipts.'))
row,out,err=rec.run(['python3','-B',str(DRIVER),'--execute','--result','/tmp/train337-old4f-elf-cache-prep/RETIREMENT.json'],cwd='/workspace/geometry-axiom',timeout=None,check=False,source_variant='root-owned-terminal-old4f-elf-retirement')
cap.dump(OUT/'receipt.json',dict(source_sha=F,driver_sha256=sha(DRIVER),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
