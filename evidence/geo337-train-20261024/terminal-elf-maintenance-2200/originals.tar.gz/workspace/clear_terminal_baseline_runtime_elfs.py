"""Unlink only 54 reviewed, reconstructible historical browser runtime ELFs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import sys
import traceback

PLAN = Path('/workspace/cold-build-cache-readonly-20261023/baseline-runtime-54-plan/PLAN.json')
PLAN_PIN = '542d8a44b8c8658a7fdb0ffdd1748b2f17a70aaa7af81edc8561a875e02a5e4e'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT = Path('/workspace/terminal-baseline-runtime-54-execution-20261023')
ROUNDS = {
    'g261r1': 'f2c8837aeba3c49eacbd77b5161f07c819204263',
    'g261r2': 'fe863b0374eafd9f1e57ec5107e28a1101804b56',
    'g261a1': 'a12d184ec1865ad078700cea2387ac69e82ab62a',
}
JOBS = {'assembly', 'canvas', 'documents', 'grid', 'space', 'timber'}
NAMES = {'core', 'bridge', 'model-base'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    assert not sys.flags.optimize, 'Python assertions must remain enabled'
    raw = GUARD.read_bytes()
    assert sha(raw) == GUARD_PIN
    guard = {'__name__': '_original_terminal_cache_readonly_guards', '__file__': str(GUARD)}
    exec(compile(raw, str(GUARD), 'exec'), guard)
    guard['OUT'] = OUT
    guard['ancestors'](OUT)
    OUT.mkdir(exist_ok=False)
    result = dict(schema='terminal-baseline-runtime-elf-retirement/1', argv=sys.argv,
        started_utc=now(), tool_sha256=sha(Path(__file__).read_bytes()), plan_sha256=PLAN_PIN,
        original_guard_sha256=GUARD_PIN, removed=[], exit_code=1, mutation_attempted=False,
        free_before=guard['free'](),
        policy='Root reserves the exact 18 historical runtime cache directories against reuse.',
        limits=['Accessible process fields only; uninspectable OS consumers remain explicitly recorded.',
                'Only exact ELF file unlinks. No source, Git, sidecar, obj, smoke, lock, directory or raw cleanup.',
                'Rebuild recipe verified; recompilation and future byte-identical ELF reproduction are not claimed.'])

    def save():
        guard['dump']('RESULT.json', result)

    def protected(plan):
        for row in plan['terminal_receipts']:
            path = Path(row['path'])
            guard['ancestors'](path)
            s = path.lstat()
            assert stat.S_ISREG(s.st_mode) and s.st_size == row['bytes']
            assert guard['digest'](path) == row['sha256']
            original = json.loads(path.read_text())
            assert original['ended'] and original['sha'] == row['source_sha']
            assert original['exit_code'] == row['original_exit'] and original['status'] == row['original_status']
        for row in plan['sidecars']:
            item = dict(row, size=row['bytes'])
            guard['identity'](Path(row['path']), item, is_file=True)
        for builder in plan['original_builders'].values():
            for row in builder['files']:
                path = Path(row['raw'])
                guard['ancestors'](path)
                assert path.is_file() and path.stat().st_size == row['bytes']
                assert guard['digest'](path) == row['sha256']

    def elf(row, sidecars):
        path = Path(row['path'])
        guard['identity'](path, row, is_file=True)
        assert path.lstat().st_blocks * 512 == row['allocated_bytes']
        with path.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
        side = sidecars[row['fingerprint_sidecar']]
        guard['identity'](Path(side['path']), dict(side, size=side['bytes']), is_file=True)
        value = json.loads(Path(side['path']).read_text())
        assert value['name'] == value['exe'] == row['name']
        assert value['exe_size'] == row['size'] and value['exe_mtime_ns'] == row['mtime_ns']
        assert value['exe_sha256'] == row['sha256'] and value['fingerprint'] == side['source_fingerprint']
        assert value['command'] == side['command'] and value['built_at'] == side['built_at']
        return path

    save()
    try:
        assert guard['digest'](PLAN) == PLAN_PIN
        plan = json.loads(PLAN.read_text())
        candidates = plan['targets']
        expected = set()
        for roundname, source_sha in ROUNDS.items():
            original_checkout = '/tmp/' + roundname + '/source-final'
            key = sha(original_checkout.encode())[:20]
            for job in JOBS:
                for name in NAMES:
                    expected.add(f'/workspace/geo261-cold/{roundname}/tmp/seven-final/{job}/geometry-runtime/{key}/{name}')
        assert len(candidates) == plan['target_count'] == 54
        assert {row['path'] for row in candidates} == expected
        assert len({(row['dev'], row['inode']) for row in candidates}) == 54
        assert len(plan['terminal_receipts']) == 18 and len(plan['sidecars']) == 54
        assert sum(row['allocated_bytes'] for row in candidates) == plan['allocated_bytes'] == 53_035_008
        sidecars = {row['path']: row for row in plan['sidecars']}
        for row in candidates:
            assert row['round'] in ROUNDS and row['job'] in JOBS and row['name'] in NAMES
            assert row['path'] == str(Path(row['runtime_directory']) / row['name'])
            assert row['fingerprint_sidecar'] == row['path'] + '.fingerprint.json'
            assert sidecars[row['fingerprint_sidecar']]['source_sha_from_parent_receipt'] == ROUNDS[row['round']]
        protected(plan)
        for row in candidates:
            elf(row, sidecars)
        guard['consumer_check'](sorted({row['runtime_directory'] for row in candidates}))
        protected(plan)
        for row in candidates:
            path = elf(row, sidecars)
            result['mutation_attempted'] = True
            save()
            path.unlink()
            result['removed'].append(str(path))
            save()
        assert len(result['removed']) == 54
        assert all(not Path(row['path']).exists() and not Path(row['path']).is_symlink() for row in candidates)
        assert all(Path(row['runtime_directory']).is_dir() for row in candidates)
        protected(plan)
        result.update(exit_code=0, removed_allocated_file_bytes=53_035_008,
                      original_receipts_and_build_recipes_preserved=True, runtime_directories_preserved=True)
    except BaseException:
        result['error'] = traceback.format_exc()
    finally:
        result['ended_utc'] = now()
        result['free_after'] = guard['free']()
        result['observed_free_delta'] = {p: result['free_after'][p] - result['free_before'][p]
                                         for p in result['free_before']}
        save()
        print(json.dumps({key: value for key, value in result.items() if key != 'removed'}, ensure_ascii=False))
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
