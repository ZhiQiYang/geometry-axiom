"""Root-only exact old4f rebuildable ELF retirement; never deletes directories or metadata."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,stat,sys,traceback
HERE=Path(__file__).resolve().parent
CACHE=Path('/workspace/train337-ledger-cache-4f4a24d7')
SOURCE='4f4a24d76e816274bfae06868b4dbf31f0860299'
PIN='aa94cbfa624b006f69d416c75627cd4205a50736798f7c1bdf8ccd4939251a9d'
PATTERN=re.compile(re.escape(str(CACHE))+r'/(?:_bridge-baseline/'+SOURCE+r'|M[0-9]+/bridge-(?:mutant|restored))/bridge')
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,why):
 if not ok:raise RuntimeError(why)
def check_binding(row):
 p=Path(row['path']);body=p.read_bytes();need(len(body)==row['bytes']and h(body)==row['sha256'],'retained original metadata/raw changed '+str(p))
def fields(st):return {'device':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'nlink':st.st_nlink}
def check_elf(row):
 p=Path(row['path']);st=p.lstat();need(PATTERN.fullmatch(str(p))and p.resolve()==p and stat.S_ISREG(st.st_mode)and st.st_nlink==1,'only exact independent regular old4f ELF')
 need(fields(st)=={k:row[k]for k in fields(st)},'ELF inode/metadata drift '+str(p))
 body=p.read_bytes();need(body[:4]==b'\x7fELF'and h(body)==row['sha256'],'ELF bytes drift '+str(p))
 need(fields(p.lstat())==fields(st),'ELF changed during hash '+str(p))
def consumers():
 result={'matches':[],'unreadable':{},'scope':'observable cwd/exe/cmdline only; inaccessible OS views explicitly remain uninspected'}
 for q in Path('/proc').iterdir():
  if not q.name.isdigit()or int(q.name)==os.getpid():continue
  try:
   if any(line.startswith('State:')and'\tZ'in line for line in(q/'status').read_text().splitlines()):continue
  except OSError:pass
  values={}
  for part in ('cwd','exe','cmdline'):
   try:values[part]=(q/'cmdline').read_bytes().replace(b'\0',b' ').decode('utf-8','replace')if part=='cmdline'else os.readlink(q/part)
   except OSError as e:
    key=part+':errno'+str(e.errno);result['unreadable'][key]=result['unreadable'].get(key,0)+1
  if any(str(CACHE)in value for value in values.values()):result['matches'].append({'pid':int(q.name),'cwd':values.get('cwd'),'exe':values.get('exe'),'cmdline_preview':values.get('cmdline','')[:180]})
 return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--result',type=Path,required=True);a=p.parse_args()
 out=a.result.resolve();need(out.parent.is_dir()and not out.exists()and not out.is_relative_to(CACHE),'fresh external result required')
 raw=(HERE/'ALLOWLIST.json').read_bytes();need(h(raw)==PIN,'reviewed exact allowlist pin');manifest=json.loads(raw)
 need(manifest['cache']==str(CACHE)and manifest['source_sha']==SOURCE and manifest['count']==76 and len(manifest['candidates'])==76,'fixed old cache/count only')
 result={'schema':'exact-old4f-ELF-cache-retirement/1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':sys.argv,'allowlist_sha256':PIN,'execute':a.execute,'removed':[],'errors':[],'passed':False,'protected':'metadata/source/Git/fixtures/raw/sidecars/gmon/obj/smoke untouched; no archive; no liveb6 path','before_available_bytes':os.statvfs(CACHE).f_bavail*os.statvfs(CACHE).f_frsize}
 def retained():
  terminal=manifest['terminal_index'];check_binding({'path':terminal['path'],'bytes':Path(terminal['path']).stat().st_size,'sha256':terminal['sha256']})
  data=json.loads(Path(terminal['path']).read_bytes());need((data['source_sha'],data['original_cli_exit'],data['root_wrapper_exit'],data['record_count'],data['unrun_count'])==(SOURCE,2,1,108,15)and data['completed_utc'],'old failed attempt truly terminal; not pass')
  paths={row['source']for row in data['members']};need(not any(row['path']in paths for row in manifest['candidates']),'ELFs must not be original raw payloads')
  check_binding(manifest['ledger']);check_binding(manifest['terminal_receipt'])
  for row in manifest['candidates']:
   check_binding(row['sidecar'])
   for stream in row['compile_streams']:check_binding(stream)
 try:
  retained()
  for row in manifest['candidates']:check_elf(row)
  result['consumer_observation']=consumers();need(not result['consumer_observation']['matches'],'observable old-cache consumer exists; nothing deleted')
  if a.execute:
   for row in manifest['candidates']:
    check_elf(row);Path(row['path']).unlink();result['removed'].append({'path':row['path'],'sha256':row['sha256'],'bytes':row['bytes'],'allocated_bytes':row['allocated_bytes'],'inode':row['inode']})
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  retained();result['passed']=True
 except BaseException:result['errors'].append(traceback.format_exc())
 finally:
  result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),removed_allocated_bytes=sum(row['allocated_bytes']for row in result['removed']),after_available_bytes=os.statvfs(CACHE).f_bavail*os.statvfs(CACHE).f_frsize,df_delta_limit='other live ledger may change free bytes concurrently; do not attribute all net df movement to this retirement')
  out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:result[k]for k in ('execute','passed','removed_allocated_bytes','errors')},ensure_ascii=False));return 0 if result['passed']else 1
if __name__=='__main__':raise SystemExit(main())
