from pathlib import Path
import datetime,hashlib,json,os,re,stat,subprocess
HERE=Path(__file__).resolve().parent
CACHE=Path('/workspace/train337-ledger-cache-4f4a24d7')
SOURCE='4f4a24d76e816274bfae06868b4dbf31f0860299'
INDEX=Path('/workspace/geo337-ledger-4f4-terminal-publication/INDEX.json')
PIN='59e2bb3ed8c5ffa6bd33c45073c7629748da137cfd2d58a043ccdab88ee72372'
PUB='fa76529f6339d8e844ef7555c59465ce1ee23ed7'
IPATH='evidence/geo337-train-20261024/ledger-4f4-terminal/INDEX.json'
def h(b):return hashlib.sha256(b).hexdigest()
def require(ok,why):
 if not ok:raise RuntimeError(why)
def canonical(o):return json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def main():
 raw=INDEX.read_bytes();require(h(raw)==PIN,'terminal index pin');index=json.loads(raw)
 require((index['source_sha'],index['original_cli_exit'],index['root_wrapper_exit'],index['record_count'],index['unrun_count'])==(SOURCE,2,1,108,15),'true failed terminal preserved')
 published=subprocess.check_output(['git','-C','/workspace/geometry-axiom','show',PUB+':'+IPATH]);require(published==raw,'published index bytes')
 members={r['source']:r for r in index['members']}
 def binding(path):
  r=members[str(path)];b=path.read_bytes();require(len(b)==r['bytes']and h(b)==r['sha256'],'original raw binding '+str(path));return {'path':str(path),'bytes':len(b),'sha256':h(b),'published_member':r['path']}
 ledgerpath=Path('/tmp/train337-ledger-4f4a24d7-r2/mutants_results.json');ledgerbinding=binding(ledgerpath);ledger=json.loads(ledgerpath.read_bytes())
 terminal=binding(Path('/tmp/train337-ledger-4f4a24d7-r2/receipt.json'))
 candidates=[];excluded=[]
 targets=[(CACHE/'_bridge-baseline'/SOURCE/'bridge',None,'baseline')]
 targets += [(CACHE/mid/('bridge-'+role)/'bridge',mid,role)for mid,row in ledger.items()if row.get('execution',{}).get('schema')=='geometry-bridge-mutation-execution/1'for role in ('mutant','restored')]
 for p,mid,role in targets:
  if not p.exists():excluded.append({'path':str(p),'reason':'no existing ELF'});continue
  side=p.with_name('bridge.fingerprint.json')
  if not side.exists():excluded.append({'path':str(p),'reason':'no original fresh sidecar; incomplete build stays excluded'});continue
  st=p.lstat();require(stat.S_ISREG(st.st_mode)and not p.is_symlink()and st.st_nlink==1,'regular independent ELF')
  b=p.read_bytes();require(b[:4]==b'\x7fELF','ELF magic');digest=h(b);sb=side.read_bytes();s=json.loads(sb)
  require((s['exe_sha256'],s['exe_size'],s['exe_mtime_ns'])==(digest,st.st_size,st.st_mtime_ns),'original sidecar credential')
  require(s['command']=='cc -std=c11 -O2 geometry-web/web_bridge.c -lm -> bridge'and s['files'],'original recipe/source closure')
  sid=binding(side)
  if mid is None:
   owner=next(k for k,r in ledger.items()if r.get('execution',{}).get('schema')=='geometry-bridge-mutation-execution/1');row=ledger[owner];ex=row['execution'];identity=ex['baseline_identity'];build=ex['baseline_build'];rawparent=CACHE/'_bridge-baseline'/SOURCE
  else:owner=mid;row=ledger[mid];ex=row['execution'];identity=ex[role+'_identity'];build=ex[role+'_build'];rawparent=CACHE/mid
  require(ex['head']==SOURCE and identity['exe_sha256']==digest and identity['sidecar_sha256']==h(sb),'original execution binary identity')
  require(build['exit_code']==0 and build['process_returncode']==0 and not build['timed_out'],'original successful build')
  streams=[binding(rawparent/build[k+'_file'])for k in ('stdout','stderr')]
  require(all(r['sha256']==build[k+'_sha256']for r,k in zip(streams,('stdout','stderr'))),'original compile streams')
  candidates.append({'path':str(p),'sha256':digest,'bytes':st.st_size,'allocated_bytes':st.st_blocks*512,'device':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'mtime_ns':st.st_mtime_ns,'nlink':st.st_nlink,'source_sha':SOURCE,'id':owner,'role':role,'original_row_verdict':row['verdict'],'mutation_source_file':row['source_file'],'source_sha256':row['source_sha256'],'mutant_sha256':row['mutant_sha256'],'closure_sha256':row['closure_sha256'],'sidecar':sid,'portable_compile':s['command'],'source_fingerprint':s['fingerprint'],'source_file_hash_count':len(s['files']),'original_build_argv':build['command'],'compile_streams':streams,'reconstruction':'retained Git SOURCE + original mutation registry/patch and full sidecar source hashes + original binaries.py recipe; original ELF bytes not receipt payload'})
 observations={'matches':[],'unreadable':{},'scope':'cwd/exe/cmdline independently; inaccessible OS views remain uninspected, not zero consumers'}
 for q in Path('/proc').iterdir():
  if not q.name.isdigit()or int(q.name)==os.getpid():continue
  vals={}
  for part in ('cwd','exe','cmdline'):
   try:vals[part]=(q/'cmdline').read_bytes().replace(b'\0',b' ').decode('utf-8','replace')if part=='cmdline'else os.readlink(q/part)
   except OSError as e:
    k=part+':errno'+str(e.errno);observations['unreadable'][k]=observations['unreadable'].get(k,0)+1
  if any(str(CACHE)in v for v in vals.values()):observations['matches'].append({'pid':int(q.name),'cwd':vals.get('cwd'),'exe':vals.get('exe'),'cmdline_preview':vals.get('cmdline','')[:180],'cmdline_sha256':h(vals.get('cmdline','').encode())})
 require(candidates,'nonempty exact ELF allowlist')
 result={'schema':'terminal-old4f-rebuildable-ELF-allowlist/1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nothing_deleted':True,'cache':str(CACHE),'source_sha':SOURCE,'terminal_index':{'path':str(INDEX),'sha256':PIN,'published_commit':PUB,'published_path':IPATH,'original_cli_exit':2,'root_wrapper_exit':1,'record_count':108,'unrun_count':15},'ledger':ledgerbinding,'terminal_receipt':terminal,'count':len(candidates),'logical_bytes':sum(x['bytes']for x in candidates),'allocated_bytes':sum(x['allocated_bytes']for x in candidates),'candidates':candidates,'excluded':excluded,'consumer_observation':observations,'protected':'all sidecars/source/Git/fixtures/gmon/streams/receipts/obj/smoke stay; b6 CACHE and P189 reference binaries never included','archive_policy':'user permits deletion of rebuildable cache; no ELF archive created or required; original published raw/metadata retained','live_cache_modified':False}
 p=HERE/'ALLOWLIST.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':h(p.read_bytes()),'count':result['count'],'allocated_bytes':result['allocated_bytes'],'observed_consumers':len(observations['matches'])}))
if __name__=='__main__':main()
