僅準備；尚未刪檔。原4f輪是真終態 CLI2/root1、108/123、15未跑，原件已公開於 fa76529f6339d8e844ef7555c59465ce1ee23ed7；不得改稱通過。

ALLOWLIST 固定76個舊4f、regular/nlink1的bridge ELF，85,291,008 allocated bytes；其完整source/compile/sidecar/原流仍保存。只刪這76檔，不刪任何目錄、sidecar、原raw、source、Git、fixture、gmon、smoke或obj。M118缺fresh sidecar的restored ELF不在清單。沒有新ELF封包，使用者已允許退休可重建cache。

root取得peer接受的工具/清單hash並fresh確認owner/future consumer後，以既有外層錄製器包住：

```sh
python3 -B /tmp/train337-old4f-elf-cache-prep/unlink_exact_old_elf_cache.py \
  --execute --result /tmp/train337-old4f-elf-cache-prep/RETIREMENT.json
```

預設不帶execute只檢核，不刪檔；這裡也沒有跑dryrun。工具將在任何刪除前核完整原INDEX、ledger、原終態receipt、全部sidecar/compile streams、每ELF inode/mode/mtime/nlink/hash及可觀察consumer，再在每次unlink前重核ELF，逐檔保存結果。OS不可讀process範圍照實記錄，不能說已檢查所有程序；root仍需擁有舊cache租約。任一缺件/不符便紅，不自動略過或resume。並行live ledger會改df，因此淨free變化不全歸因這次unlink。
