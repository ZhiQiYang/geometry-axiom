import os,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
peer=Path('/tmp/geo337-a6-architecture-static-peer-20261026/REVIEW.json');assert h(peer)=='c46793c42cec2bf893f27a3eaeb8482caeca2a2dee25df84d82c8eb3f94890c2';assert json.loads(peer.read_bytes())['exit_code']==0
tool=Path('/tmp/geo337-a6-architecture-preparation-20261026/prepare_source.py');assert h(tool)=='8f08d1325d5fa43fef2c3a46ef8bca94693568d7318b1c1326496c44c48fee16'
out=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-source-root-original-20261026');assert not out.exists();out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'STATIC_PEER.json').write_bytes(peer.read_bytes())
rec=Recorder(out,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),'a6f4013364e21bcb7239b5dcc25caac0f6d61f77')
row,stdout,stderr=rec.run(['python3','-B',str(tool),'--execute-root-approved'],cwd='/workspace',timeout=300,check=False,source_variant='independent architecture source preparation; no cleanup or product testing')
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'product_tests_executed':False});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
