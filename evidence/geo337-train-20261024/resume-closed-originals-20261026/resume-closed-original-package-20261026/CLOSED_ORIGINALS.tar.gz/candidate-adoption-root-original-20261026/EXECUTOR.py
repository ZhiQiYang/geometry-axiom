import os,sys,json,hashlib,resource,argparse
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def item(p):
 p=Path(p);return {'path':str(p),'sha256':h(p),'bytes':p.stat().st_size}
ap=argparse.ArgumentParser();ap.add_argument('--architecture-peer',required=True);ap.add_argument('--architecture-peer-sha256',required=True);a=ap.parse_args()
own=Path('/dev/shm/geometry-axiom-geo337-20261025');prep=Path('/tmp/geo337-resume-final-source-plan-20261026');out=own/'candidate-adoption-root-original-20261026';assert not out.exists()
tool=prep/'adopt_candidate_three_leaves.py';assert h(tool)=='71b0b4eb9ddde59f6b8e9ab90eb2492f8e403d1469a645d81864585a631fefba'
tiny=Path('/tmp/geo337-candidate-adopter-runtime-actual-peer-20261026/REVIEW.json');assert h(tiny)=='21ac8cda0e50f3fbd957e6a52310cae573d704abf5fae37a6439a1b9a6d9ad6d';t=json.loads(tiny.read_bytes());assert t['exit_code']==0 and t['blocking_findings']==[] and t['subject_sha256']==h(tool)
peer=Path(a.architecture_peer);assert h(peer)==a.architecture_peer_sha256;p=json.loads(peer.read_bytes());assert p['source_sha']=='a6f4013364e21bcb7239b5dcc25caac0f6d61f77' and p['exit_code']==0 and p['blocking_findings']==[] and p['result_sha256']=='a532b83a67e19b37e2cf724fb4d9ec86753b3a090de554093646b2e2c3d1b2df'
q=json.loads((prep/'REQUEST.UNBOUND.json').read_bytes());q.update(root_execution_lease=True,root_exclusive_publisher_window=True,root_originals_and_peers_reviewed=True,root_candidate_ref_exclusive=True,expected_publisher_index_sha256='7a0cdcc3cc447eb2fae06aec47e97cf24f192aa62ed383839dc7b21e18942842')
for name in q['artifacts']:
 if name!='tests/mutants_results.json':q['artifacts'][name]=item(own/'a6-architecture-four-original-20261026/new'/Path(name).name)
idx=own/'S10-ledger-complete-package/INDEX.json';assert h(idx)=='7166053cceef6c95a24eefaea3f084082976698d92850264acba6d8b67fdcfec'
q['artifacts']['tests/mutants_results.json']=item(json.loads(idx.read_bytes())['terminal']['terminal_files']['ledger']['path']);assert q['artifacts']['tests/mutants_results.json']['sha256']=='a4b5f1957e4bde6d30e4c05328e8a8dc1282fa811c52260eb01670cd560d56e7'
q['original_receipts']={'terminal':item(own/'S10-ledger-terminal-verify/TERMINAL.json'),'ledger_index':item(idx),'architecture_result':item(own/'a6-architecture-four-original-20261026/RESULT.json')}
q['peers']['architecture_actual']={**item(peer),'key_paths':{'exit':['exit_code'],'source':['source_sha'],'result_sha256':['result_sha256']}}
for role in ['ledger_actual','ledger_package']:
 d=q['peers'][role];assert item(d['path'])=={k:d[k]for k in ['path','sha256','bytes']}
out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'tiny-actual-peer.json').write_bytes(tiny.read_bytes())
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);assert hard==-1 or hard>=16777216;resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
rec=Recorder(out,env,q['architecture_source_sha'])
for side,rev in [('old',q['source_sha']),('new',q['architecture_source_sha'])]:
 row,b,e=rec.run(['git','show',rev+':決策佇列.md'],cwd=own/'publisher-source',timeout=60,check=True,source_variant='read exact old/new decision bytes for adoption closure binding')
 q['s10_to_architecture_decision'][side]={'mode':'100644','oid':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
dump(out/'REQUEST.json',q)
row,stdout,stderr=rec.run(['python3','-B',str(tool),'--request',str(out/'REQUEST.json'),'--request-sha256',h(out/'REQUEST.json'),'--execute-root-approved'],cwd='/workspace',timeout=600,check=False,source_variant='adopt exact S10 ledger and a6 architecture into isolated candidate; preserve historical refs')
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'architecture_source_sha':q['architecture_source_sha'],'ledger_source_sha':q['source_sha'],'stack_soft_bytes':16777216});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
