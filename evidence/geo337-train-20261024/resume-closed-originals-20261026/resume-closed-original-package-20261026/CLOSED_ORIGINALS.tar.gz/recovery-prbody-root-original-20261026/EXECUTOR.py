import os,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
own=Path('/dev/shm/geometry-axiom-geo337-20261025');repo=own/'publisher-source';out=own/'recovery-prbody-root-original-20261026';inner=own/'recovery-prbody-publication-20261026'
branch='codex/train337-recovered-evidence-20261026-prbody';ref='refs/heads/'+branch;base='9a57aea2128a7bc3985064932c24e2229fd8fcb8'
body=Path('/tmp/geo337-recovered-PR_BODY-20261026.md');pin=hashlib.sha256(body.read_bytes()).hexdigest()
tool=Path('/tmp/prbody-index-free-preparation/publish_body_index_free.py');assert hashlib.sha256(tool.read_bytes()).hexdigest()=='9967f712d0e829a8d6e80bab2598eb6c294fff84fa34fb1c1a10e491fc2250ba'
assert not out.exists() and not inner.exists();out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'PR_BODY.md').write_bytes(body.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
rec=Recorder(out,env,base)
def run(cmd):
 row,stdout,stderr=rec.run(cmd,cwd=repo,timeout=180,check=False);assert row['actual_process_returncode']==0,row['directory'];return stdout
def git(*args):return run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args])
result={'exit_code':1,'published':False,'delivered':False,'existing_PR_body_updated':False}
try:
 before={'head':git('rev-parse','HEAD').decode(),'index':hashlib.sha256((repo/'.git/index').read_bytes()).hexdigest(),'train':git('rev-parse','refs/heads/codex/train-337-continue-20261024').decode()};dump(out/'BEFORE.json',before)
 assert not git('ls-remote','--heads','origin',ref) and not git('for-each-ref','--format=%(objectname)',ref)
 git('update-ref',ref,base,'0'*40);git('push','origin',ref+':'+ref)
 run(['python3','-B',str(tool),'--git-dir',str(repo/'.git'),'--branch',branch,'--expected-parent',base,'--body',str(body),'--body-sha256',pin,'--out',str(inner),'--message','docs: record recovered train evidence and remaining acceptance gates','--publish'])
 j=json.loads((inner/'RESULT.json').read_bytes());assert j['passed'] and j['published']
 remote=run(['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json','repos/ZhiQiYang/geometry-axiom/git/blobs/'+j['newBodyBlob']]);assert remote==body.read_bytes() and hashlib.sha256(remote).hexdigest()==pin
 after={'head':git('rev-parse','HEAD').decode(),'index':hashlib.sha256((repo/'.git/index').read_bytes()).hexdigest(),'train':git('rev-parse','refs/heads/codex/train-337-continue-20261024').decode()};dump(out/'AFTER.json',after);assert after==before
 result.update(exit_code=0,published=True,delivered=True,branch=branch,body_commit=j['newCommit'],body_sha256=pin,body_bytes=len(remote),original_writer_unchanged=True)
finally:dump(out/'RESULT.json',result)
print(json.dumps(result))
