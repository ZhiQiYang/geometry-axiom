import os,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
own=Path('/dev/shm/geometry-axiom-geo337-20261025');base=Path('/tmp/geo337-candidate-adopter-runtime-preparation-20261026');out=own/'candidate-tiny-root-original-20261026';assert not out.exists()
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
peer=base/'PEER.json';assert h(peer)=='b79c2d607c6db9413c9cd2148189cffd6c542075e9d8988a12500440b5a14af8';assert json.loads(peer.read_bytes())['exit_code']==0
runner=base/'run_candidate_tiny.py';assert h(runner)=='ef136f13a7037f37e98e19f0e7e72f9da6fd8d3e07e446031c7ba7bb8d381d0c'
seen=set();used=0
for root in [own,Path('/dev/shm/geo337-F9-browsers-20261025')]:
 for p in root.rglob('*'):
  st=p.lstat();k=(st.st_dev,st.st_ino)
  if k not in seen:seen.add(k);used+=st.st_blocks*512
assert used+80*1024**2<2*1024**3
out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());q=json.loads((base/'REQUEST.UNBOUND.json').read_bytes());q.update(execute=True,root_capacity_admitted=True,root_new_fixture_only_lease=True,out=str(own/'geo337-candidate-adopter-tiny-20261026'));dump(out/'REQUEST.json',q);dump(out/'CAPACITY.json',{'shared_used':used,'synthetic_bound':16*1024**2,'reserve':64*1024**2,'shared_ceiling':2*1024**3})
rec=Recorder(out,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),'SYNTHETIC_CANDIDATE_PRIMITIVES_ONLY')
row,stdout,stderr=rec.run(['python3','-B',str(runner),'--execute','--request',str(out/'REQUEST.json'),'--request-sha256',h(out/'REQUEST.json')],cwd='/workspace',timeout=300,check=False)
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'formal_adoption_executed':False});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
