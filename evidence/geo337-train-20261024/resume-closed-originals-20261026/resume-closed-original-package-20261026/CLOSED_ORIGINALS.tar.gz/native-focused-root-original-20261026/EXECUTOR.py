import os,sys,json,hashlib,shutil,fcntl
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
own=Path('/dev/shm/geometry-axiom-geo337-20261025');out=own/'native-focused-root-original-20261026';target=own/'geo337-native-final-focused-20261026'
def need(c,m):
 if not c:raise RuntimeError(m)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
module=Path('/tmp/geo337-recovery-native-transition-preparation-20261026/transition_native_final.py');mp='6248a86b6ac174a6c624f64c14186862c841aea5efdd387c8d81b80766b80893'
peer=Path('/tmp/geo337-recovery-native-transition-preparation-20261026/PEER.json')
need(h(module)==mp and h(peer)=='f284d27922a494b93743b13c0c20efe551f6a96284dbb04feabd01dad58a14b6','binding pins')
need(json.loads(peer.read_text())['exit_code']==0,'binding peer')
base=Path('/tmp/geo337-native-final-source-transition-preparation-20261025');runner=base/'run_focused_proof.py';harness=base/'tiny_transition.py'
need(h(runner)=='78c6a4c203402450c63d86f890a7fbc909afe230f7c5976da54e45b5a84c5f0b','runner pin')
hp='1aca97bbcdc0823b3ea13930b7e802f2aa02784e5fadcab5ca97c01f0ef0747d';need(h(harness)==hp,'harness pin')
need(not out.exists() and not target.exists(),'fresh proof paths')
used=0;seen=set()
for root in [own,Path('/dev/shm/geo337-F9-browsers-20261025')]:
 for p in root.rglob('*'):
  st=p.lstat();k=(st.st_dev,st.st_ino)
  if k not in seen:seen.add(k);used+=st.st_blocks*512
need(used+320*1024*1024<2*1024**3,'original 2GiB shared plan with focused64MiB + architecture256MiB')
need(shutil.disk_usage(own).free>320*1024*1024,'real mount capacity')
locks=[]
for name in ['heavy.lock','secondary.lock']:
 f=open('/tmp/g261r3/'+name,'r');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());dump(out/'RESOURCE_PLAN.json',{'current_used':used,'focused_increment':64*1024*1024,'architecture_pending_reserved':256*1024*1024,'shared_ceiling':2*1024**3})
rec=Recorder(out,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),'a6f4013364e21bcb7239b5dcc25caac0f6d61f77')
cmd=['python3','-B',str(runner),'--module',str(module),'--module-sha256',mp,'--harness',str(harness),'--harness-sha256',hp,'--out',str(target),'--root-capacity-admitted','--execute']
row,stdout,stderr=rec.run(cmd,cwd='/workspace',timeout=240,check=False,source_variant='synthetic tool proof only; no product/native execution')
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'source_transition_executed':False,'native_executed':False,'proof_out':str(target)})
print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
