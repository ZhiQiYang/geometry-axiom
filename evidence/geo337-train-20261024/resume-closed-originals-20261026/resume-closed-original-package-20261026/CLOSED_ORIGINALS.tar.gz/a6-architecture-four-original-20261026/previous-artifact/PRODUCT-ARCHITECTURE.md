# Product architecture — integration train fixed-source receipt

產品／裁判實際來源 `6e50aef65513b7b38f93228919272c6d40d6c196`。三條原命令 exit 0／0／0；generic 205、product 18，零 skip。完整604 inputs、334 owned／270 exclusions、798 edges／0 diagnostics。LF closure `8d47b6202e793aa5755a887ea2cbb6b90506c68ca4270e0c0df0716142ca3b89`。來源 HEAD、604個Git blob／raw／LF、三個裁判及兩份 SSOT 前後不變。

本輪 manifest 與前份產物逐 bytes 相同：forbiddenIdentifiers 937→937、forbiddenStrings 55；分類、路徑、exclusion、trust及所有政策不變。完整604輸入相較前份收據僅 `geometry-core/references.inc` 的來源雜湊改變。原完整 W lexer 盤點仍覆蓋全部 W identifiers。九組既有 guard 在本次來源重新實跑0／1／0；撤回用歷史928版 Git `ca7838e0f4950452b9befcf40899d606db9b81fa`、原SHA256 `80f44b8c870e097413e395d30ba029199ba66b7302985c0f325d4f446d0ce525`，明確不同於上一份937版 manifest。兩個neutral probe亦重新通過，沒有移標歷史判決。

前份收據 source `e321026fb9bc9bc19c54b8034af6e6eaec2857f9`，產物提交 `6df0264f75e84f03adb70746b6ac3db07a9910fc`；本次完整輸入差異在 receipt／source-inputs.json，歷史報告保於該Git提交。四檔寫至來源外，receipt不hash自己。原native／browser／mutation ledger／效能需各自原收據，本四檔不代稱它們通過。
