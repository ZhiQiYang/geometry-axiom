"""Small private Git protocol fixtures only; never uses production ROOT/provider/cache."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,traceback
def H(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--module',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--proof-root',type=Path);ap.add_argument('--case',choices=['focused','unknown','hook','ignored','observation'],default='focused');ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 if not a.execute:print(json.dumps({'state':'FOCUSED_PROOF_UNRUN','executed':False}));return 2
 sys.dont_write_bytecode=True
 own=Path('/dev/shm/geometry-axiom-geo337-20261025');proof_root=a.proof_root or a.out
 if proof_root.parent!=own or proof_root.parent.resolve()!=own or proof_root.parent.is_symlink()or not proof_root.name.startswith('geo337-native-final-focused-'):raise RuntimeError('root must bind a fresh direct approved OWN SHM proof child')
 if a.out!=proof_root and (a.out.parent!=proof_root or proof_root.resolve()!=proof_root or proof_root.is_symlink()):raise RuntimeError('phase output must be a fresh direct child of the bound proof ROOT')
 if a.out.exists():raise RuntimeError('fresh tiny output required')
 a.out.mkdir();os.environ.update(TMPDIR=str(a.out),TMP=str(a.out),TEMP=str(a.out));s=importlib.util.spec_from_file_location('tiny_subject',a.module);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);helpers,cap,guard=m.load_tools()
 empty_setup=a.out/'synthetic-empty-template-and-hooks';empty_setup.mkdir()
 env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','MUTATE_'))and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME')};env.update(GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TEMPLATE_DIR=str(empty_setup),PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',TMPDIR=str(a.out),TMP=str(a.out),TEMP=str(a.out))
 cases=['positive','hook','filter','worktree','sparse','promisor','ignored','observation']if a.case=='focused'else[a.case];records=[];failed=[]
 for case in cases:
  d=a.out/case;d.mkdir();rec=cap.Recorder(d/'setup-original-commands',env,'SYNTHETIC_PRIVATE_GIT_PROTOCOL_NOT_PRODUCT')
  def git(repo,*args,expected=0):
   row,b,e=rec.run(['git','-c','user.name=Native protocol fixture','-c','user.email=fixture@example.invalid','-c','gc.auto=0','-c','maintenance.auto=false','-c','init.templateDir='+str(empty_setup),'-c','core.hooksPath='+str(empty_setup),*args],cwd=repo,timeout=30,check=False,source_variant='Synthetic private Git fixture setup; external Git config, templates and hooks isolated; no real project source')
   if row['actual_process_returncode']!=expected:raise RuntimeError('tiny setup Git failed '+str(args))
   return b
  try:
   if case=='default':
    row,b,e=rec.run([sys.executable,'-B',str(a.module)],cwd=d,timeout=30,check=False,source_variant='Default refusal only; no production source accessed')
    if row['actual_process_returncode']!=2 or json.loads(b)['executed']is not False:raise AssertionError('default entry must refuse')
    records.append({'case':case,'harness_exit':0,'actual_cli_exit':2,'classification':'expected preexecution refusal'});continue
   original=d/'old-provider';original.mkdir();git(original,'init','-q','--initial-branch=fixture')
   initial={name:('fixture-'+str(i)+'\n').encode()for i,name in enumerate(helpers['FIXTURES'])}
   initial.update({name:('old-'+name+'\n').encode()for name in m.ALLOWED});initial['source.c']=b'/* synthetic source; never compiled */\n';initial['evidence/old.txt']=b'synthetic excluded evidence\n'
   for name,b in initial.items():p=original/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
   git(original,'add','--all');git(original,'commit','-q','-m','Create private native transition fixture');old=git(original,'rev-parse','HEAD').decode().strip()
   native=d/'native';git(d,'clone','-q','--shared','--no-checkout',str(original),str(native));git(native,'config','core.sparseCheckout','true');git(native,'config','core.sparseCheckoutCone','false');(native/'.git/info').mkdir(exist_ok=True);(native/'.git/info/sparse-checkout').write_bytes(m.SPARSE);git(native,'checkout','-q','--detach',old)
   publisher=d/'publisher';git(d,'clone','-q','--shared',str(original),str(publisher));git(publisher,'checkout','-q','-b','train');changed='tests/test_geo314_commit_paths.py';(publisher/changed).write_bytes(b'new synthetic policy\n');git(publisher,'add','--',changed);git(publisher,'commit','-q','-m','Update allowed synthetic leaf')
   if case=='unknown':(publisher/'unexpected.txt').write_bytes(b'unknown source change\n');git(publisher,'add','--','unexpected.txt');git(publisher,'commit','-q','-m','Introduce unknown synthetic source leaf')
   if case=='nonff':git(publisher,'checkout','-q','--orphan','divergent');git(publisher,'commit','-q','-m','Create unrelated synthetic target')
   final=git(publisher,'rev-parse','HEAD').decode().strip();git(publisher,'remote','set-url','origin',str(publisher));branch='divergent'if case=='nonff'else'train'
   remote_rec=cap.Recorder(d/'completed-synthetic-remote-observation',env,'SYNTHETIC_LOCAL_REMOTE_NOT_GITHUB')
   remote_row,remote_stdout,remote_stderr=remote_rec.run(['git','ls-remote','--heads',str(publisher),branch],cwd=d,timeout=30,check=False,source_variant='Completed local synthetic remote observation; never reads GitHub or real provider')
   if remote_row['actual_process_returncode']!=0:raise RuntimeError('synthetic published ref setup failed')
   remote_dir=Path(remote_row['directory'])
   if case=='observation':
    tampered=d/'synthetic-wrong-argv-observation';tampered.mkdir()
    for name in ('request.json','result.json','stdin.bin','stdout.bin','stderr.bin'):(tampered/name).write_bytes((remote_dir/name).read_bytes())
    for name in ('request.json','result.json'):
     x=json.loads((tampered/name).read_bytes());x['command'][3]=str(d/'wrong-synthetic-origin');(tampered/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    (d/'SYNTHETIC_OBSERVATION_MUTATION.json').write_text(json.dumps({'original_directory':str(remote_dir),'mutant_directory':str(tampered),'note':'Only a synthetic copied image is tampered; original c387 streams remain immutable.'})+'\n');remote_dir=tampered
   if case=='dirty':(native/changed).write_bytes(b'preexisting dirty source\n')
   if case=='fixture':
    f=helpers['FIXTURES'][0];(native/f).write_bytes(b'wrong hidden fixture bytes\n');git(native,'update-index','--assume-unchanged','--',f)
   marker=d/'UNAUTHORIZED_HOOK_OR_FILTER_MARKER'
   if case=='hook':
    hook=native/'.git/hooks/post-merge';hook.parent.mkdir(exist_ok=True);hook.write_text('#!/bin/sh\nprintf unsafe > '+str(marker)+'\n');hook.chmod(0o755)
   if case=='filter':git(native,'config','filter.synthetic.smudge','sh -c "printf unsafe > '+str(marker)+'; cat"')
   if case=='worktree':
    other=d/'UNAUTHORIZED_WORKTREE';other.mkdir();git(native,'config','core.worktree',str(other))
   if case=='sparse':git(native,'config','core.sparseCheckoutCone','true')
   if case=='promisor':git(publisher,'config','remote.origin.promisor','true')
   if case=='ignored':
    with (native/'.git/info/exclude').open('ab')as f:f.write(b'\ninjected.tmp\n')
   locks=[d/'heavy.lock',d/'secondary.lock']
   for p in locks:p.write_bytes(b'')
   fixtures={name:{'bytes':len(initial[name]),'sha256':H(initial[name]),'oid':git(original,'rev-parse',old+':'+name).decode().strip()}for name in helpers['FIXTURES']}
   policy={'root':native,'owner':publisher,'old':old,'branch':branch,'remote_url':str(publisher),'cache':d/'private-cache-never-production','locks':locks,'out_parents':{d},'sparse':m.SPARSE,'fixtures':fixtures,'allowed':m.ALLOWED,'artifacts':m.ARTIFACTS,'minimum_tmp_reserve':0}
   def blob(commit,name):
    b=git(publisher,'show',commit+':'+name);oid=git(publisher,'rev-parse',commit+':'+name).decode().strip();return {'mode':'100644','oid':oid,'bytes':len(b),'sha256':H(b)}
   q={'schema':'native-F9-final-source-transition/1','execute':True,'root':str(native),'provider_repo':str(publisher),'provider_objects':str(publisher/'.git/objects'),'old_sha':old,'final_sha':final,'expected_sparse_sha256':H(m.SPARSE),'expected_old_index_sha256':H((native/'.git/index').read_bytes()),'minimum_free_tmp_bytes':0,'minimum_free_output_bytes':0,'out':str(d/('geo337-native-final-transition-'+case)),'exact_non_evidence_delta':[{'path':changed,'old':blob(old,changed),'new':blob(final,changed)}],'artifact_sha256':{name:H(git(publisher,'show',final+':'+name))for name in sorted(m.ARTIFACTS)}}
   q.update({key:True for key in m.LEASES})
   q['published_ref_observation']={'directory':str(remote_dir),'sha256':{name:H((remote_dir/name).read_bytes())for name in ('request.json','result.json','stdin.bin','stdout.bin','stderr.bin')}}
   if case=='lease':q['root_execution_lease']=False
   (d/'SYNTHETIC_REQUEST.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
   def fingerprint():return {p.relative_to(native).as_posix():H(p.read_bytes())for p in sorted(native.rglob('*'))if p.is_file()}
   before=fingerprint();failure=None;original_run=cap.Recorder.run
   if case=='ignored':
    def inject_after_merge(self,args,**kwargs):
     row,b,e=original_run(self,args,**kwargs)
     if 'merge'in args and '--ff-only'in args and Path(kwargs['cwd'])==native and row['actual_process_returncode']==0:
      (native/'injected.tmp').write_bytes(b'synthetic unexpected ignored producer\n');(d/'INJECTION.json').write_text(json.dumps({'scope':'Synthetic only; recorder method wrapper injects one ignored file after real successful ff merge, original capture.py is unmodified','path':str(native/'injected.tmp'),'bytes':(native/'injected.tmp').stat().st_size})+'\n')
     return row,b,e
    cap.Recorder.run=inject_after_merge
   try:
    try:result=m.transition(q,policy,helpers,cap,guard)
    except RuntimeError as e:failure=str(e);result={'exit_code':2,'preexecution_refused':True,'error':failure}
   finally:cap.Recorder.run=original_run
   if case=='positive':
    if result['exit_code']!=0:raise AssertionError('positive source transition failed: '+result.get('error',''))
    if git(native,'rev-parse','HEAD').decode().strip()!=final:raise AssertionError('positive final HEAD mismatch')
    if (native/changed).read_bytes()!=b'new synthetic policy\n':raise AssertionError('allowed bytes not adopted')
    if not result['provider_metadata_unchanged']or not result['old_refs_and_objects_preserved']:raise AssertionError('positive preservation not proven')
   elif case=='ignored':
    if result['exit_code']==0 or 'ignored path set changed'not in result.get('error','')or result.get('merge_exit')!=0:raise AssertionError('new ignored leaf must be detected after actual ff merge')
    if not(native/'injected.tmp').exists():raise AssertionError('synthetic ignored injection missing')
   else:
    if result['exit_code']==0:raise AssertionError(case+' must refuse (real guard did not stop transition)')
    if fingerprint()!=before:raise AssertionError(case+' changed native source/Git before rejection')
    if marker.exists():raise AssertionError('unsafe hook/filter was executed before refusal')
    expected={'unknown':'actual non-evidence difference not exact allowlist','dirty':'clean native source required','fixture':'physical source mismatch','nonff':'merge-base','lease':'explicit root execution','hook':'executable Git hook refused','filter':'configuration refused','worktree':'configuration refused','sparse':'effective original non-cone sparse configuration','promisor':'configuration refused','observation':'explicit approved remote observation argv'}[case]
    if expected not in result.get('error',''):raise AssertionError(case+' failed for wrong reason: '+result.get('error',''))
   records.append({'case':case,'harness_exit':0,'actual_transition_exit':result['exit_code'],'actual_transition':case in ('positive','ignored'),'expected_rejection':case!='positive','scope':'synthetic only; no production roots or product test','native_root':str(native),'old_sha':old,'final_sha':final})
  except BaseException:
   failure=traceback.format_exc();failed.append(case);records.append({'case':case,'harness_exit':1,'error':failure});print(failure,file=sys.stderr)
  finally:
   (d/'HARNESS_CASE.json').write_text(json.dumps(records[-1]if records and records[-1]['case']==case else{'case':case,'harness_exit':1},ensure_ascii=False,indent=2)+'\n')
 result={'schema':'native-transition-private-tiny-proof/2','exit_code':1 if failed else 0,'cases':records,'failed':failed,'subject_path':str(a.module),'subject_sha256':H(a.module.read_bytes()),'harness_sha256':H(Path(__file__).read_bytes()),'production_roots_accessed':False,'product_tests_executed':False,'all_fixture_capture_and_tmp_root':str(a.out),'original_seven_case_suite_repeated':False,'threshold_note':'Tiny policy uses zero space requirement only for synthetic private directories; production minimum64MiB remains fixed and was not changed.'}
 (a.out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'exit_code':result['exit_code'],'cases':len(records),'failed':failed,'path':str(a.out/'RESULT.json')}));return result['exit_code']
if __name__=='__main__':raise SystemExit(main())
