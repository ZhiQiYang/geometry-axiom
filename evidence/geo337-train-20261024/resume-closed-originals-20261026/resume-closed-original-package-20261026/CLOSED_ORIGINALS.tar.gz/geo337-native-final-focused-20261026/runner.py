"""Root-admitted synthetic Git proof only; all writes stay in one fresh OWN SHM child."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,traceback
OWN=Path('/dev/shm/geometry-axiom-geo337-20261025')
def H(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--module',type=Path,required=True);ap.add_argument('--module-sha256',required=True);ap.add_argument('--harness',type=Path,required=True);ap.add_argument('--harness-sha256',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--execute',action='store_true');ap.add_argument('--root-capacity-admitted',action='store_true');a=ap.parse_args()
 if not a.execute or not a.root_capacity_admitted:print(json.dumps({'state':'UNRUN_ROOT_CAPACITY_REQUIRED','executed':False}));return 2
 sys.dont_write_bytecode=True
 need(sys.flags.optimize==0,'nonoptimized proof required');out=a.out
 need(out.parent==OWN and OWN.resolve()==OWN and not OWN.is_symlink()and out.name.startswith('geo337-native-final-focused-')and not out.exists(),'fresh direct approved OWN proof root')
 source=a.module.read_bytes();harness=a.harness.read_bytes();need(H(source)==a.module_sha256 and H(harness)==a.harness_sha256,'frozen proof inputs')
 fs=os.statvfs(OWN);need(fs.f_bavail*fs.f_frsize>=64*1024*1024,'fresh synthetic proof space64MiB; root shared-cap admission remains separately required')
 out.mkdir();(out/'original-module.py').write_bytes(source);(out/'original-harness.py').write_bytes(harness);(out/'runner.py').write_bytes(Path(__file__).read_bytes())
 os.environ.update(TMPDIR=str(out),TMP=str(out),TEMP=str(out),PYTHONDONTWRITEBYTECODE='1')
 s=importlib.util.spec_from_file_location('focused_original_module',a.module);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);helpers,cap,guard=m.load_tools()
 env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','MUTATE_'))and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME')};env.update(TMPDIR=str(out),TMP=str(out),TEMP=str(out),PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8')
 rec=cap.Recorder(out/'original-phase-commands',env,'SYNTHETIC_GIT_PROTOCOL_NOT_PRODUCT');rows=[];failed=[]
 def phase(name,module,case,expected):
  target=out/name;argv=[sys.executable,'-B',str(out/'original-harness.py'),'--module',str(module),'--proof-root',str(out),'--out',str(target),'--case',case,'--execute']
  row,b,e=rec.run(argv,cwd=out,timeout=180,check=False,source_variant='Synthetic Git guards only; 180s is a proof watchdog, not a product threshold')
  result=json.loads((target/'RESULT.json').read_bytes())if(target/'RESULT.json').is_file()else None
  good=type(row['actual_process_returncode'])is int and row['actual_process_returncode']==expected and row['timeout_expired']is False and result is not None and result['exit_code']==expected
  if expected==1:
   expected_error='new ignored leaf must be detected after actual ff merge'if case=='ignored'else case+' must refuse (real guard did not stop transition)'
   transition_result=target/case/('geo337-native-final-transition-'+case)/'RESULT.json';actual=json.loads(transition_result.read_bytes())if transition_result.is_file()else None
   good=good and result['failed']==[case]and len(result['cases'])==1 and expected_error in result['cases'][0].get('error','')and actual is not None and actual['exit_code']==0 and actual['merge_exit']==0
  else:good=good and result['failed']==[]
  rows.append({'phase':name,'case':case,'expected_exit':expected,'actual_exit':row['actual_process_returncode'],'timeout':row['timeout_expired'],'command_directory':row['directory'],'result_path':str(target/'RESULT.json'),'module_sha256':H(module.read_bytes()),'accepted_expected_outcome':good})
  if not good:failed.append(name)
  (out/'PROGRESS.json').write_text(json.dumps({'phases':rows,'failed':failed},ensure_ascii=False,indent=2)+'\n')
 original=out/'original-module.py';phase('new-focused-baseline',original,'focused',0)
 # These remove one real guard at a time, leaving all original capture streams intact.
 mutations={
  'unknown':("need(non_evidence==[r['path']for r in q['exact_non_evidence_delta']],'actual non-evidence difference not exact allowlist')","need(True,'actual non-evidence difference not exact allowlist')"),
  'hook':("need(hook.name.endswith('.sample')or not(row['mode']&0o111),'executable Git hook refused: '+hook.name)","need(True,'executable Git hook refused: '+hook.name)"),
  'ignored':("need(set(ignored_after)==set(unknown),'ignored path set changed')","need(True,'ignored path set changed')"),
  'observation':("need(request.get('command')==argv and result.get('command')==argv,'explicit approved remote observation argv')","need(True,'explicit approved remote observation argv')")}
 for case,(old,new)in mutations.items():
  need(source.count(old.encode())==1,'unique exact mutation anchor: '+case);mutant=out/('guard-withdrawn-'+case+'.py');mutant.write_bytes(source.replace(old.encode(),new.encode(),1))
  phase(case+'-before',original,case,0);phase(case+'-withdrawn',mutant,case,1);phase(case+'-restored',original,case,0)
 result={'schema':'native-transition-focused-proof/1','exit_code':1 if failed else 0,'phases':rows,'failed':failed,'original_module_sha256':H(source),'original_harness_sha256':H(harness),'runner_sha256':H(Path(__file__).read_bytes()),'production_source_accessed':False,'product_tests_executed':False,'all_writes_under':str(out),'original_seven_suite_repeated':False,'tiny_capacity_estimate_allocated_upper_bytes':64*1024*1024,'native128MiB_gate_modified':False,'old_tiny_originals_modified':False}
 (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'exit_code':result['exit_code'],'phases':len(rows),'failed':failed,'result':str(out/'RESULT.json')}));return result['exit_code']
if __name__=='__main__':raise SystemExit(main())
