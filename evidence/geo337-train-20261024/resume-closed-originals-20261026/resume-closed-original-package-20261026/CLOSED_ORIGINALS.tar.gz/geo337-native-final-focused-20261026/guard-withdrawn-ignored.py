"""Root-bound F9 native source transition. Default refusal; no product execution."""
from pathlib import Path
import argparse,datetime,fcntl,gzip,hashlib,importlib.util,json,os,re,runpy,stat,sys,traceback

BASE=Path('/tmp/geo337-resume-resource-review-20261025/transition_root_unbound_v2.py')
BASE_PIN='687ad58c86bd70e32958314eb1312bcbb6c19396f244a88b6e10b4f05875363c'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
NOTE=Path('/tmp/geo337-final-native-source-binding-notes-20261025/NOTE.json')
NOTE_PIN='eeedb05249fb310faf4a0a6ad88d0d755ea5f2419d5bfb57f3c12f53ce010e97'
OLD='4f8a794f4167c3562eb182045102e86e9e37cca9'
ROOT=Path('/tmp/train337-323-f64d638f-source')
OWNER=Path('/dev/shm/geometry-axiom-geo337-20261025/publisher-source')
OWN=OWNER.parent
SPARSE=b'/*\n!/evidence/\n!/tests/evidence/\n/tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas\n/tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas\n/tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas\n'
ALLOWED={'tests/test_geo314_commit_paths.py','決策佇列.md','tests/mutants_results.json','geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md','geometry-core/domain-decoupling/product-architecture-receipt.json'}
ARTIFACTS={'tests/mutants_results.json','geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md','geometry-core/domain-decoupling/product-architecture-receipt.json'}
LEASES=('root_execution_lease','native_source_exclusive','cache_quiescent','publisher_writer_quiescent','provider_protected_until_dependencies_migrated','output_capacity_admitted')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def load_tools():
 for p,pin in ((BASE,BASE_PIN),(CAP,CAP_PIN),(GUARD,GUARD_PIN),(NOTE,NOTE_PIN)):need(sha(p.read_bytes())==pin,'original helper pin: '+str(p))
 helpers=runpy.run_path(str(BASE),run_name='_native_source_helpers_only')
 s=importlib.util.spec_from_file_location('original_capture',CAP);cap=importlib.util.module_from_spec(s);s.loader.exec_module(cap)
 guard=runpy.run_path(str(GUARD),run_name='_original_consumer_guard_only')
 return helpers,cap,guard
def production_policy():
 note=json.loads(NOTE.read_bytes())
 return dict(root=ROOT,owner=OWNER,old=OLD,branch='codex/train337-recovered-evidence-20261026',remote_url='https://github.com/ZhiQiYang/geometry-axiom.git',cache=Path('/tmp/geometry-tests'),locks=[Path('/tmp/g261r3/heavy.lock'),Path('/tmp/g261r3/secondary.lock')],out_parents={Path('/tmp'),OWN},sparse=SPARSE,fixtures={r['path']:{'bytes':r['bytes'],'sha256':r['sha256'],'oid':r['git_blob_oid_F8']}for r in note['fixtures']},allowed=ALLOWED,artifacts=ARTIFACTS,minimum_tmp_reserve=64*1024*1024)
def validate_request(q,p):
 need(q.get('schema')=='native-F9-final-source-transition/1','request schema')
 need(q.get('execute')is True and all(q.get(k)is True for k in LEASES),'explicit root execution and every source/provider/cache lease required')
 need(q.get('root')==str(p['root'])and q.get('provider_repo')==str(p['owner'])and q.get('provider_objects')==str(p['owner']/'.git/objects')and q.get('old_sha')==p['old'],'fixed private source/provider/old identity')
 need(isinstance(q.get('final_sha'),str)and re.fullmatch('[0-9a-f]{40}',q['final_sha'])and q['final_sha']!=p['old'],'bind real distinct final SHA')
 need(q.get('expected_sparse_sha256')==sha(p['sparse']),'exact original native sparse')
 need(re.fullmatch('[0-9a-f]{64}',q.get('expected_old_index_sha256',''))is not None,'bind actual original physical index hash')
 need(type(q.get('minimum_free_tmp_bytes'))is int and q['minimum_free_tmp_bytes']>=p['minimum_tmp_reserve'],'original transition reserve cannot decrease')
 need(type(q.get('minimum_free_output_bytes'))is int and q['minimum_free_output_bytes']>=p['minimum_tmp_reserve'],'root must bind output capacity')
 rows=q.get('exact_non_evidence_delta');need(isinstance(rows,list)and rows,'bind nonempty exact non-evidence delta')
 names=[r.get('path')for r in rows];need(names==sorted(set(names))and set(names)<=p['allowed'],'unknown or duplicate source difference refused')
 for row in rows:
  need(set(row)=={'path','old','new'},'exact delta row fields')
  for side in ('old','new'):
   x=row[side];need(isinstance(x,dict)and set(x)=={'mode','oid','bytes','sha256'},'complete old/new blob identity')
   need(x['mode']in ('100644','100755')and re.fullmatch('[0-9a-f]{40}',x['oid'])and type(x['bytes'])is int and x['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',x['sha256']),'valid old/new identity')
 need(set(q.get('artifact_sha256',{}))==p['artifacts']and all(re.fullmatch('[0-9a-f]{64}',x)for x in q['artifact_sha256'].values()),'bind exact adopted ledger/report/receipt blobs')
 out=Path(q['out']);need(out.is_absolute()and out.parent in p['out_parents']and out.name.startswith('geo337-native-final-transition-')and not out.exists(),'fresh direct approved output only')
 need(not out.parent.is_symlink()and out.parent.resolve()==out.parent,'canonical output parent')
 for directory,minimum in ((p['root'],q['minimum_free_tmp_bytes']),(out.parent,q['minimum_free_output_bytes'])):
  fs=os.statvfs(directory);need(fs.f_bavail*fs.f_frsize>=minimum,'fresh capacity before any output or capture')
 return out
def published_ref_observation(q,p):
 """Read a root-bound, completed original capture; never start any network helper."""
 proof=q.get('published_ref_observation',{});directory=Path(proof.get('directory',''))
 need(directory.is_absolute()and directory.resolve()==directory and not directory.is_symlink(),'canonical remote observation directory')
 files=proof.get('sha256',{});names={'request.json','result.json','stdin.bin','stdout.bin','stderr.bin'}
 need(set(files)==names,'complete original remote observation binding')
 raw={}
 for name in sorted(names):
  path=directory/name;need(path.is_file()and not path.is_symlink(),'original remote observation leaf')
  raw[name]=path.read_bytes();need(sha(raw[name])==files[name],'original remote observation hash: '+name)
 request=json.loads(raw['request.json']);result=json.loads(raw['result.json']);argv=['git','ls-remote','--heads',p['remote_url'],p['branch']]
 need(request.get('command')==argv and result.get('command')==argv,'explicit approved remote observation argv')
 need(all(result.get(k)==v for k,v in request.items()if k not in ('actual_process_returncode','timeout_expired')),'original remote request/result identity')
 need(type(result.get('actual_process_returncode'))is int and result['actual_process_returncode']==0 and result.get('timeout_expired')is False,'actual completed remote observation must be zero')
 need(raw['stdin.bin']==b''and request.get('stdin_provided')is False and request.get('actual_process_returncode')is None and request.get('timeout_expired')is False and request.get('stdin_sha256')==sha(b'')and result.get('stdin_sha256')==sha(b''),'original remote observation stdin')
 for stream in ('stdout','stderr'):
  b=raw[stream+'.bin'];need(result.get(stream+'_sha256')==sha(b)and result.get(stream+'_bytes')==len(b),'original remote observation '+stream)
 match=re.fullmatch(rb'([0-9a-f]{40})\trefs/heads/'+re.escape(p['branch'].encode())+rb'\n',raw['stdout.bin']);need(match is not None,'one exact published train reference required')
 return match.group(1).decode(),raw
def transition(q,p,helpers,cap,guard,request_raw=None):
 """Tests may call this with private tiny Git fixtures; CLI always uses fixed production_policy."""
 out=validate_request(q,p);root=p['root'];owner=p['owner'];final=q['final_sha'];old=p['old'];safe_file=helpers['safe_file'];path_at=helpers['path_at'];blob_oid=helpers['blob_oid'];dump=helpers['dump'];h=helpers['h']
 handles=[];out.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','MUTATE_'))and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONPYCACHEPREFIX')};env.update(GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',LANG='C.UTF-8')
 rec=cap.Recorder(out/'commands',env,old);request_raw=request_raw if request_raw is not None else (json.dumps(q,ensure_ascii=False,indent=2)+'\n').encode();(out/'BOUND_REQUEST.json').write_bytes(request_raw)
 report=dict(schema='native-final-source-transition-actual/1',old_sha=old,final_sha=final,request_sha256=sha(request_raw),tool_sha256=sha(Path(__file__).read_bytes()),original_helpers_sha256=BASE_PIN,original_capture_sha256=CAP_PIN,original_consumer_guard_sha256=GUARD_PIN,exit_code=1,alternate_appended=False,merge_started=False,merge_exit=None,product_gate_executed=False,old_objects_deleted=False,provider_written=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),failure_policy='Preserve every original and partial state; no reset, clean, rollback or force.')
 def git(repo,*args,expected=0):
  row,b,e=rec.run(['git','-c','core.autocrlf=false','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=repo,timeout=None,check=False,source_variant='Root-bound native source metadata/ordinary ff-only merge; not a product gate')
  need(row['actual_process_returncode']in expected if isinstance(expected,tuple)else row['actual_process_returncode']==expected,'Git returncode '+str(args)+': '+str(row['actual_process_returncode']));return b
 def canonical_dir(d):need(d.is_dir()and d.resolve()==d and not d.is_symlink(),'canonical private directory '+str(d))
 config_count=0
 def execution_policy(repo):
  nonlocal config_count
  config_count+=1
  # git config and rev-parse are read-only builtins; validate before status, merge,
  # any object read that could otherwise trigger lazy fetching. No network is run.
  pattern=r'^(core\.(worktree|bare|hookspath|fsmonitor|sparsecheckout|sparsecheckoutcone|attributesfile|sshcommand)|index\.sparse|filter\..*|diff\.external|diff\..*\.(command|textconv)|merge\..*\.driver|merge\.verifysignatures|gpg\..*|remote\..*\.(promisor|partialclonefilter|vcs)|extensions\.partialclone)$'
  raw=git(repo,'config','--null','--get-regexp',pattern,expected=(0,1));settings={}
  for entry in raw.split(b'\0'):
   if entry:
    key,value=entry.split(b'\n',1);settings.setdefault(key.decode().lower(),[]).append(value.decode())
  dump(out/(('NATIVE'if repo==root else'PROVIDER')+f'_EXECUTION_CONFIG_{config_count:03d}.json'),settings)
  for key,values in settings.items():
   value=values[-1].lower()
   if key in ('core.bare','core.sparsecheckout','core.sparsecheckoutcone','index.sparse'):continue
   if key in ('core.fsmonitor','merge.verifysignatures')or key.endswith('.promisor'):
    need(value in ('false','no','off','0'),'executable Git configuration refused: '+key)
   else:need(False,'executable or redirected Git configuration refused: '+key)
  hooks=repo/'.git/hooks'
  if hooks.exists():
   canonical_dir(hooks)
   for hook in hooks.iterdir():
    row=safe_file(hook);need(hook.name.endswith('.sample')or not(row['mode']&0o111),'executable Git hook refused: '+hook.name)
  need(git(repo,'rev-parse','--absolute-git-dir').decode().strip()==str(repo/'.git'),'actual private Gitdir identity')
  if repo==root:
   need(git(repo,'rev-parse','--show-toplevel').decode().strip()==str(root)and git(repo,'rev-parse','--is-bare-repository').strip()==b'false','actual native worktree identity')
   for key,default,wanted in [('core.sparseCheckout','false',b'true'),('core.sparseCheckoutCone','false',b'false'),('index.sparse','false',b'false')]:
    need(git(repo,'config','--bool','--default='+default,'--get',key).strip()==wanted,'effective original non-cone sparse configuration: '+key)
  return settings
 def tree(repo,commit):
  result={}
  for item in git(repo,'ls-tree','-rz','--full-tree',commit).split(b'\0'):
   if not item:continue
   head,name=item.split(b'\t',1);mode,kind,oid=head.decode().split();name=os.fsdecode(name);path_at(root,name)
   need(kind=='blob'and mode in ('100644','100755'),'unsupported Git entry '+name);result[name]={'mode':mode,'oid':oid}
  return result
 def selected(name):return not(name.startswith('evidence/')or name.startswith('tests/evidence/'))or name in p['fixtures']
 def inventory(expected):
  actual={}
  for name,t in expected.items():
   if not selected(name):continue
   f=path_at(root,name);row=safe_file(f);need(blob_oid(f)==t['oid']and bool(row['mode']&0o111)==(t['mode']=='100755'),'physical source mismatch '+name);actual[name]=row
  tracked_present={name for name in expected if path_at(root,name).exists()}
  need(tracked_present==set(actual),'original native sparse materialized set mismatch')
  return actual
 def metadata(repo):
  answer={}
  for current,dirs,files in os.walk(repo/'.git'):
   dirs[:]=[n for n in dirs if not(Path(current)==repo/'.git'and n=='objects')]
   for n in dirs:canonical_dir(Path(current)/n)
   for n in files:answer[(Path(current)/n).relative_to(repo/'.git').as_posix()]=safe_file(Path(current)/n)
  return answer
 def objects(repo):
  answer={}
  for current,dirs,files in os.walk(repo/'.git/objects'):
   for n in dirs:canonical_dir(Path(current)/n)
   for n in files:
    f=Path(current)/n;rel=f.relative_to(repo/'.git/objects').as_posix()
    if rel!='info/alternates':answer[rel]=safe_file(f,independent=False)
  return answer
 def provider_object_states():
  answer={}
  for current,dirs,files in os.walk(owner/'.git/objects'):
   for n in dirs:canonical_dir(Path(current)/n)
   for n in files:
    f=Path(current)/n;s=f.lstat();need(stat.S_ISREG(s.st_mode)and not f.is_symlink(),'provider object type');answer[f.relative_to(owner/'.git/objects').as_posix()]={'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
  return answer
 consumer_number=0
 def consumers():
  nonlocal consumer_number
  consumer_number+=1;d=out/f'consumers-{consumer_number:03d}';d.mkdir();guard['consumer_check'].__globals__['OUT']=d;guard['consumer_check']([str(root),str(p['cache'])])
 def status():need(git(root,'status','--porcelain=v1','--untracked-files=all')==b'','clean native source required')
 def raw_blob(repo,t):
  b=git(repo,'cat-file','blob',t['oid']);return dict(mode=t['mode'],oid=t['oid'],bytes=len(b),sha256=sha(b))
 try:
  for path in p['locks']+[p['cache']/'build.lock',p['cache']/'run_all.lock']:
   if path not in p['locks']and not path.exists():continue
   safe_file(path,independent=False);f=path.open('r+b');handles.append(f);fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  for d in (root,owner,root/'.git',root/'.git/objects',root/'.git/objects/info',owner/'.git',owner/'.git/objects'):canonical_dir(d)
  need(root!=owner and root/'.git'!=owner/'.git','independent native Gitdir')
  for repo in (root,owner):
   need(git(repo,'rev-parse','--git-common-dir').decode().strip()=='.git','private Git common directory required');need(git(repo,'rev-parse','--show-object-format').strip()==b'sha1','Git object format')
  config_before={str(repo):execution_policy(repo)for repo in (root,owner)}
  owner_before=metadata(owner);owner_alt=owner/'.git/objects/info/alternates';owner_alt_before=safe_file(owner_alt)if owner_alt.exists()else None;provider_objects_before=provider_object_states();dump(out/'PROVIDER_OBJECT_STATES_BEFORE.json',provider_objects_before);dump(out/'PROVIDER_METADATA_BEFORE.json',owner_before);dump(out/'PROVIDER_ALTERNATES_BEFORE.json',owner_alt_before)
  need(git(root,'rev-parse','HEAD').decode().strip()==old,'actual native HEAD must be F9');need(git(root,'symbolic-ref','-q','HEAD',expected=1)==b'','native HEAD must be detached');status()
  need(not(root/'.git/index.lock').exists()and h(root/'.git/index')==q['expected_old_index_sha256'],'original physical index identity')
  sparse=root/'.git/info/sparse-checkout';need(sparse.read_bytes()==p['sparse'],'original sparse bytes')
  need(git(owner,'cat-file','-t',final).strip()==b'commit','true final resolves in private provider');git(owner,'merge-base','--is-ancestor',old,final)
  remote_head,remote_raw=published_ref_observation(q,p);remote_out=out/'published-ref-original';remote_out.mkdir()
  for name,b in remote_raw.items():(remote_out/name).write_bytes(b)
  git(owner,'merge-base','--is-ancestor',final,remote_head);report.update(published_train_head=remote_head,network_command_executed=False,published_ref_observation='Root-bound completed original CLI; no live network lookup by this transition')
  old_tree=tree(root,old);new_tree=tree(owner,final)
  delta=sorted(n for n in old_tree.keys()|new_tree.keys()if old_tree.get(n)!=new_tree.get(n));non_evidence=[n for n in delta if not n.startswith('evidence/')]
  need(non_evidence==[r['path']for r in q['exact_non_evidence_delta']],'actual non-evidence difference not exact allowlist')
  for row in q['exact_non_evidence_delta']:
   name=row['path'];need(name in old_tree and name in new_tree,'source removal/addition not approved')
   need(raw_blob(root,old_tree[name])==row['old']and raw_blob(owner,new_tree[name])==row['new'],'bound old/new blob differs '+name)
  for name,pin in q['artifact_sha256'].items():need(name in new_tree and raw_blob(owner,new_tree[name])['sha256']==pin,'adopted artifact differs '+name)
  for name,pin in p['fixtures'].items():need(old_tree.get(name)==new_tree.get(name)and old_tree[name]['oid']==pin['oid'],'fixture Git identity changed '+name)
  need(git(root,'ls-files','--unmerged','-z')==b'','unmerged original index');git(root,'diff-index','--cached','--quiet',old,'--');git(root,'ls-files','--stage','-z');git(root,'ls-files','-v','-z')
  before=inventory(old_tree);refs=git(root,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines();meta=metadata(root);obj=objects(root)
  unknown=[os.fsdecode(x)for x in git(root,'ls-files','--others','--ignored','--exclude-standard','-z').split(b'\0')if x];need(set(unknown)<={'current_geometry.svg'},'unknown ignored originals');ignored={n:safe_file(path_at(root,n))for n in unknown}
  for name,pin in p['fixtures'].items():need(before[name]['sha256']==pin['sha256']and before[name]['bytes']==pin['bytes'],'original fixture bytes changed '+name)
  alt=root/'.git/objects/info/alternates';alt_before=alt.read_bytes()if alt.exists()else b''
  alt_state=safe_file(alt)if alt.exists()else None
  new_provider=os.fsencode(str(owner/'.git/objects'));need(new_provider not in alt_before.splitlines(),'provider already present: classify unexpected original metadata')
  new_alt=alt_before+(b''if not alt_before or alt_before.endswith(b'\n')else b'\n')+new_provider+b'\n'
  for label,data in [('MATERIALIZED_BEFORE',before),('GIT_METADATA_BEFORE',meta),('NATIVE_OBJECTS_BEFORE',obj),('IGNORED_BEFORE',ignored),('EXACT_DELTA',q['exact_non_evidence_delta'])]:dump(out/(label+'.json'),data)
  for name in meta:
   dest=out/'git-before'/name;dest.parent.mkdir(parents=True,exist_ok=True);data=(root/'.git'/name).read_bytes()
   if name=='index':dest=dest.with_name('index.gz');dest.write_bytes(gzip.compress(data,compresslevel=1,mtime=0));need(gzip.decompress(dest.read_bytes())==data,'lossless original index backup')
   else:dest.write_bytes(data)
  (out/'ALTERNATES.before.bin').write_bytes(alt_before);(out/'ALTERNATES.after.expected.bin').write_bytes(new_alt)
  fixture_rows={}
  for i,name in enumerate(p['fixtures']):data=(root/name).read_bytes();(out/f'fixture-{i:02d}.bin').write_bytes(data);fixture_rows[name]=before[name]
  dump(out/'FIXTURES_BEFORE.json',fixture_rows)
  free=lambda d:os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
  need(free(root)>=q['minimum_free_tmp_bytes']and free(out)>=q['minimum_free_output_bytes'],'fresh transition/output capacity')
  consumers();need(inventory(old_tree)==before and metadata(root)==meta and objects(root)==obj,'original source/Git/object drift before transition');need(metadata(owner)==owner_before and provider_object_states()==provider_objects_before,'private provider metadata/object state drift');need({str(repo):execution_policy(repo)for repo in (root,owner)}==config_before,'effective execution configuration drift');status()
  need((safe_file(alt)if alt.exists()else None)==alt_state,'original alternates drift before append')
  with alt.open('ab'if alt_state is not None else'xb')as f:f.write(new_alt[len(alt_before):]);f.flush();os.fsync(f.fileno())
  report['alternate_appended']=True;dump(out/'PROGRESS.json',report)
  need(alt.read_bytes()==new_alt and git(root,'cat-file','-t',final).strip()==b'commit','native private final object resolution')
  preserve='refs/codex-preserved/native-F9-before-final-'+final[:8]+'-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');git(root,'update-ref',preserve,old,'0'*40);report['preservation_ref']=preserve
  report['merge_started']=True;dump(out/'PROGRESS.json',report)
  row,stdout,stderr=rec.run(['git','-c','core.autocrlf=false','-c','gc.auto=0','-c','maintenance.auto=false','merge','--ff-only','--no-edit','--no-stat',final],cwd=root,timeout=None,check=False,source_variant='Actual ordinary fast-forward-only merge F9 to root-bound final; no force/reset/clean')
  report['merge_exit']=row['actual_process_returncode'];need(report['merge_exit']==0,'ordinary ff merge failed; preserve partial state')
  need(git(root,'rev-parse','HEAD').decode().strip()==final and git(root,'symbolic-ref','-q','HEAD',expected=1)==b'','final detached HEAD');status();git(root,'diff-index','--cached','--quiet',final,'--');need(git(root,'ls-files','--unmerged','-z')==b'','final unmerged index');git(root,'ls-files','--stage','-z')
  after=inventory(new_tree);need(set(after)=={n for n in new_tree if selected(n)},'complete final materialized closure')
  ignored_after=[os.fsdecode(x)for x in git(root,'ls-files','--others','--ignored','--exclude-standard','-z').split(b'\0')if x];need(True,'ignored path set changed');dump(out/'IGNORED_AFTER.json',{n:safe_file(root/n)for n in ignored_after})
  for name,row in before.items():
   if name not in non_evidence:need(after.get(name)==row,'unchanged source inode/bytes lost '+name)
  for name,row in ignored.items():need(safe_file(root/name)==row,'ignored original lost '+name)
  for name,pin in p['fixtures'].items():need(after[name]==before[name],'fixture byte/inode changed '+name)
  need(sparse.read_bytes()==p['sparse']and alt.read_bytes()==new_alt,'sparse or native alternates changed')
  need(set(git(root,'for-each-ref','--format=%(refname) %(objectname)').decode().splitlines())==set(refs)|{preserve+' '+old},'old refs changed')
  aftermeta=metadata(root);allowed_meta={'HEAD','index','ORIG_HEAD','logs/HEAD',preserve,'logs/'+preserve};need(set(meta)<=set(aftermeta)and set(aftermeta)-set(meta)<=allowed_meta,'Git metadata removed or unexpected addition')
  for name,row in meta.items():
   if name not in allowed_meta:need(aftermeta[name]==row,'unexpected Git metadata change '+name)
  need(objects(root)==obj,'original native Git objects changed');need(metadata(owner)==owner_before and(safe_file(owner_alt)if owner_alt.exists()else None)==owner_alt_before and provider_object_states()==provider_objects_before,'private provider was modified')
  consumers();dump(out/'MATERIALIZED_AFTER.json',after);dump(out/'GIT_METADATA_AFTER.json',aftermeta);dump(out/'NATIVE_OBJECTS_AFTER.json',objects(root));dump(out/'PROVIDER_METADATA_AFTER.json',metadata(owner));dump(out/'PROVIDER_OBJECT_STATES_AFTER.json',provider_object_states())
  report.update(exit_code=0,complete_selected_paths=len(after),old_selected_paths=len(before),source_clean_after=True,all_five_fixtures_preserved=True,sparse_preserved=True,old_refs_and_objects_preserved=True,provider_metadata_unchanged=True,provider_object_entries_and_state_unchanged=True,provider_object_payloads_not_rehashed=True,lazy_fetch_disabled=True,provider_dependency_remains=True,actual_transition=True,non_evidence_changed_paths=non_evidence,free_tmp_after=free(root),free_output_after=free(out))
 except BaseException:report['error']=traceback.format_exc()
 finally:
  report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dump(out/'RESULT.json',report)
  for f in reversed(handles):f.close()
 print(json.dumps({k:report.get(k)for k in ('exit_code','old_sha','final_sha','alternate_appended','merge_started','merge_exit','complete_selected_paths','product_gate_executed')}));return report
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--request',type=Path);ap.add_argument('--request-sha256');ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 if not a.execute:print(json.dumps({'state':'PREPARATION_ONLY_REFUSED','executed':False,'final_sha':None}));return 2
 need(a.request is not None and re.fullmatch('[0-9a-f]{64}',a.request_sha256 or '')is not None,'explicit pinned request required');need(sys.flags.optimize==0 and os.environ.get('PYTHONOPTIMIZE')in (None,'','0'),'nonoptimized original guards required')
 raw=a.request.read_bytes();need(sha(raw)==a.request_sha256,'request bytes changed');q=json.loads(raw);helpers,cap,guard=load_tools();p=production_policy();validate_request(q,p)
 peer=q.get('independent_peer',{});peerfile=Path(peer.get('path',''));need(peerfile.is_file()and sha(peerfile.read_bytes())==peer.get('sha256'),'exact independent peer');review=json.loads(peerfile.read_bytes());need(type(review.get('exit_code'))is int and review['exit_code']==0 and review.get('tool_sha256')==sha(Path(__file__).read_bytes()),'peer must accept exact tool')
 return transition(q,p,helpers,cap,guard,raw)['exit_code']
if __name__=='__main__':raise SystemExit(main())
