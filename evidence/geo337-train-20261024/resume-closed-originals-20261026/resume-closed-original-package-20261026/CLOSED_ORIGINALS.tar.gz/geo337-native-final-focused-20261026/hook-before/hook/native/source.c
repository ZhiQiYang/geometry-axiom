/* synthetic source; never compiled */
