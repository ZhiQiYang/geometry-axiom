new synthetic policy
