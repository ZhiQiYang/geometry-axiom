import os,sys,json,hashlib,resource
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
own=Path('/dev/shm/geometry-axiom-geo337-20261025');prep=Path('/tmp/geo337-a6-architecture-preparation-20261026');out=own/'a6-gates-root-original-20261026';assert not out.exists()
peer=Path('/tmp/geo337-a6-source-actual-peer-20261026/REVIEW.json');assert h(peer)=='59e9ac0d16fcfdf30b57bf11201755c1ddede4294bf70bfcf4cb79b5b36b305a';assert json.loads(peer.read_bytes())['exit_code']==0
source=own/'a6-architecture-source-original-20261026/RESULT.json';assert h(source)=='2c8542df06b79b21a2a94ef5ce382d07a697a562e035ea86613dfb4a135274c4'
tool=prep/'run_original_gates.py';assert h(tool)=='51e25963f5ede37b2fe516b14862cf73b895c9780fad62d4083ec56109a9962f'
q=json.loads((prep/'ROOT_GATE_REQUEST.template.json').read_bytes());q.update(root_execution_lease=True,source_result={'path':str(source),'sha256':h(source)},source_actual_peer={'path':str(peer),'sha256':h(peer)})
out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());dump(out/'REQUEST.json',q)
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);assert hard==-1 or hard>=16777216;resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
rec=Recorder(out,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),q['source_sha'])
row,stdout,stderr=rec.run(['python3','-B',str(tool),'--request',str(out/'REQUEST.json'),'--request-sha256',h(out/'REQUEST.json'),'--execute-root-approved'],cwd='/workspace',timeout=600,check=False,source_variant='original three architecture judges on fixed a6 source')
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'source_sha':q['source_sha'],'stack_soft_bytes':16777216});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
