import os,sys,json,hashlib,resource
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
own=Path('/dev/shm/geometry-axiom-geo337-20261025');prep=Path('/tmp/geo337-a6-architecture-preparation-20261026');out=own/'a6-assembly-root-original-20261026'
assert not out.exists()
pins={'source_result':(own/'a6-architecture-source-original-20261026/RESULT.json','2c8542df06b79b21a2a94ef5ce382d07a697a562e035ea86613dfb4a135274c4'),'source_actual_peer':(Path('/tmp/geo337-a6-source-actual-peer-20261026/REVIEW.json'),'59e9ac0d16fcfdf30b57bf11201755c1ddede4294bf70bfcf4cb79b5b36b305a'),'gate_result':(own/'a6-architecture-gates-original-20261026/RESULT.json','1dd78c0ef53d715316da892886bdb20d475a2a03e3dccf8a84c3f060e26b6f25'),'gate_actual_peer':(Path('/tmp/geo337-a6-gates-actual-peer-20261026/REVIEW.json'),'5b28a6e10719570dc02d64a17257e20a2fb8a8a51e5308c8f020ed27be113bee')}
q=json.loads((prep/'ROOT_ASSEMBLY_BINDINGS.template.json').read_bytes());q['root_execution_lease']=True
for k,(p,pin) in pins.items():
 assert h(p)==pin
 q[k]={'path':str(p),'sha256':pin}
tool=prep/'assemble_a6.py';assert h(tool)=='97da235f9a9d69b4cdfbc67dc3f49e5b447b574176e39e3300ffd887993fab62'
out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());dump(out/'BINDINGS.json',q)
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);assert hard==-1 or hard>=16777216;resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
rec=Recorder(out,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),q['source_sha'])
row,stdout,stderr=rec.run(['python3','-B',str(tool),'--root',str(own/'a6-architecture-source-20261026'),'--sha',q['source_sha'],'--out',str(own/'a6-architecture-four-original-20261026'),'--root-execution-lease','--bindings',str(out/'BINDINGS.json'),'--bindings-sha256',h(out/'BINDINGS.json')],cwd='/workspace',timeout=600,check=False,source_variant='assemble four artifacts from closed original a6 gates; no judge rerun')
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'source_sha':q['source_sha'],'stack_soft_bytes':16777216});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode()}));sys.exit(row['actual_process_returncode'])
