old geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md
