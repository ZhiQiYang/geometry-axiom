import os,sys,json,hashlib,resource,argparse,contextlib,fcntl,stat,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/geo261-environment/final-f-contact-checker-proof-tools')
from capture import Recorder,dump
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--tool-sha256',required=True);ap.add_argument('--peer',required=True);ap.add_argument('--peer-sha256',required=True);a=ap.parse_args()
O=Path('/dev/shm/geometry-axiom-geo337-20261025');R=O/'a6-architecture-source-20261026';P=O/'publisher-source';out=O/'final-light-root-original-20261026';prep=Path('/tmp/geo337-final-light-gates-preparation-20261026');A='a6f4013364e21bcb7239b5dcc25caac0f6d61f77';F='cbf0fb621888596aa14ad5f2349b503e23b1b72d';assert not out.exists()
peer=Path(a.peer);assert h(peer)==a.peer_sha256 and json.loads(peer.read_bytes())['exit_code']==0
tool=prep/'run_after_ff_four_gates.py';assert h(tool)==a.tool_sha256
adpeer=Path('/tmp/geo337-candidate-three-leaf-actual-peer-20261026/REVIEW.json');assert h(adpeer)=='819f0d2f9f2db05eb3ec6ae7e70d8a98fff7463203e92143de7f33ede58b0eb6';j=json.loads(adpeer.read_bytes());assert j['exit_code']==0 and not j['blocking_findings'] and j['final_sha']==F and j['full_remote_delivery_verified']
adopt=O/'candidate-three-leaf-adoption-original-20261026/RESULT.json';assert h(adopt)=='51dc88fae03dfca5dc08ba20aadd8c7beea42cbcb5e9dc292e77d9f8c1019558'
man=O/'a6-architecture-source-original-20261026/SOURCE_MANIFEST.json';assert h(man)=='fbd0ded63cf26fab983e9befe1c957b5ade9e1e18a1f390f19a1fe4ebb8ff385';manifest=json.loads(man.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','MUTATE_','GEOMETRY_')) and k not in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD']};env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);assert hard==-1 or hard>=16777216;resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
def protected():
 paths=[P/'.git/HEAD',P/'.git/index',P/'.git/packed-refs',*sorted((P/'.git/refs').rglob('*'))]
 return {str(p):h(p) for p in paths if p.is_file()}
with contextlib.ExitStack() as stack:
 for p in map(Path,['/tmp/g261r3/heavy.lock','/tmp/g261r3/secondary.lock']):
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid();fd=stack.enter_context(p.open('r+b'));assert (os.fstat(fd.fileno()).st_dev,os.fstat(fd.fileno()).st_ino)==(s.st_dev,s.st_ino);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 seen=set();used=0
 for root in [O,Path('/dev/shm/geo337-F9-browsers-20261025')]:
  for p in [root,*root.rglob('*')]:
   s=p.lstat();k=(s.st_dev,s.st_ino)
   if k not in seen:seen.add(k);used+=s.st_blocks*512
 assert used+67108864<=2147483648 and shutil.disk_usage(O).free>=67108864
 out.mkdir();(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'static-peer.json').write_bytes(peer.read_bytes());(out/'adoption-peer.json').write_bytes(adpeer.read_bytes());dump(out/'CAPACITY.json',{'shared_before':used,'additional_bound':67108864,'shared_ceiling':2147483648})
 rec=Recorder(out,env,F)
 def git(*args):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,timeout=180,check=True,source_sha=A,source_variant='root ordinary FF from a6 to fixed candidate; not a product acceptance gate')[1]
 before=protected();dump(out/'PUBLISHER.before.json',before);assert git('rev-parse','HEAD').decode().strip()==A and not git('status','--porcelain=v1','--untracked-files=all')
 selected={os.fsdecode(x[2:]) for x in git('ls-files','-t','-z').split(b'\0') if x and x[:1]!=b'S'};assert selected==set(manifest['files']) and len(selected)==3763
 for name,x in manifest['files'].items():
  p=R/name;s=p.lstat();b=p.read_bytes();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink();assert len(b)==x['bytes'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['oid']
 assert len(manifest['fixture_paths'])==5
 changed=set(git('diff','--no-renames','--name-only','-z',A,F,'--','.',':(exclude)evidence').decode().rstrip('\0').split('\0'));assert changed=={'tests/mutants_results.json','geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md','geometry-core/domain-decoupling/product-architecture-receipt.json'}
 git('merge-base','--is-ancestor',A,F);(out/'SOURCE_INDEX.before.bin').write_bytes((R/'.git/index').read_bytes());dump(out/'SOURCE_BEFORE.json',{'head':A,'index_sha256':h(R/'.git/index'),'selected':3763,'fixtures':5})
 git('merge','--ff-only',F)
 assert git('rev-parse','HEAD').decode().strip()==F and not git('status','--porcelain=v1','--untracked-files=all');assert protected()==before
 dump(out/'SOURCE_AFTER_FF.json',{'head':F,'index_sha256':h(R/'.git/index'),'publisher_unchanged':True})
q=json.loads((prep/'REQUEST.UNBOUND.json').read_bytes());q.update(root_execution_lease=True,root_source_exclusive=True,root_adoption_actual_peer_reviewed=True,source_actual_peer={'path':'/tmp/geo337-a6-source-actual-peer-20261026/REVIEW.json','sha256':'59e9ac0d16fcfdf30b57bf11201755c1ddede4294bf70bfcf4cb79b5b36b305a'},adoption_result={'path':str(adopt),'sha256':h(adopt)})
dump(out/'REQUEST.json',q)
row,b,e=rec.run(['python3','-B',str(tool),'--execute-root-approved','--request',str(out/'REQUEST.json'),'--request-sha256',h(out/'REQUEST.json')],cwd='/workspace',timeout=600,check=False,source_sha=F,source_variant='tracked mutation check and three original architecture judges on fixed final candidate')
after=protected();dump(out/'PUBLISHER.after.json',after);assert after==before
dump(out/'RESULT.json',{'exit_code':row['actual_process_returncode'],'source_sha':F,'prepared_source_sha':A,'ff_completed':True,'publisher_unchanged':True,'stack_soft_bytes':16777216});print(json.dumps({'exit_code':row['actual_process_returncode'],'stdout':b.decode(),'stderr':e.decode()}));sys.exit(row['actual_process_returncode'])
