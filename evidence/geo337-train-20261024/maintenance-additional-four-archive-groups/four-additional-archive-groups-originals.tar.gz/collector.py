"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/four-additional-archive-groups-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 specs=[('four-additional','/workspace/four-additional-terminal-archives-preparation-r2-20261024','/workspace/four-additional-terminal-archive-groups-preserving-links-execution-20261024','/workspace/four-additional-terminal-archive-groups-preserving-links-launch-20261024')]
 archive_bodies=set();gross=0;plans=[]
 for label,prep,actual,outer in specs:
  prep,actual,outer=map(Path,(prep,actual,outer));plan=readj(prep/'PLAN.json');r=readj(actual/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and a['actual_process_returncode']==0
  assert not a['timeout_expired'] and r['plan_sha256']==digest(prep/'PLAN.json');plans.append(plan);gross+=plan['expected_allocated_saving']
  members=[x for g in plan['groups'] for x in g['members']]
  archive_bodies.update(x['path'] for x in members)
  tree(prep,'preparation/'+label);tree(actual,'actual/'+label);tree(outer,'launch/'+label)
  for i,x in enumerate(plan['anchors']):
   assert digest(x['path'])==x['sha256']
   add(x['path'],f'anchors/{label}/{i:03d}-'+Path(x['path']).name)
  for key in ['original_core','core','consumer_guard']:
   x=plan[key];assert digest(x['path'])==x['sha256']
 assert gross==300097536
 assert len(plans)==1 and [g['count'] for g in plans[0]['groups']]==[7,7,7,7]
 assert len(archive_bodies)==28
 tree('/workspace/four-additional-terminal-archives-preparation-20261024','initial-prefix-preparation-failure')
 for i,t in enumerate(plans[0]['terminal_rows']):
  assert readj(t['path'])==t['original_rows']
  add(t['path'],f'terminal-originals/{i:03d}-'+Path(t['path']).name)
 for path in ['/workspace/prepare_four_additional_terminal_archive_groups_20261024.py','/workspace/prepare_four_additional_terminal_archive_groups_v2_20261024.py','/workspace/prepare_three_large_terminal_archive_groups_20261024.py','/workspace/geo261-cold-large-archive-metadata-combined-20261024.json','/workspace/geo261-cold-large-archive-identity-combined-20261024.json','/workspace/geo261-cold-large-archive-terminal-combined-20261024.json']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 train=Path('/workspace/train337-canvas-peer-resume')
 for name in ['FOUR_ADDITIONAL_ARCHIVE_GROUPS_STATIC_PEER.json','review_four_additional_archive_groups.py','FOUR_ADDITIONAL_ARCHIVE_GROUPS_ACTUAL_METADATA_PEER.json','review_four_additional_archive_groups_actual.py']:
  add(train/name,'peers-and-review-tools/'+name)
 for path in ['/workspace/review_four_additional_archive_groups_actual_metadata_20261024.py','/workspace/FOUR_ADDITIONAL_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 for path in [train/'FOUR_ADDITIONAL_ARCHIVE_GROUPS_STATIC_PEER.json',train/'FOUR_ADDITIONAL_ARCHIVE_GROUPS_ACTUAL_METADATA_PEER.json',Path('/workspace/FOUR_ADDITIONAL_ARCHIVE_GROUPS_ACTUAL_METADATA_20261024.json')]:
  peer=readj(path);assert peer['exit_code']==0 and not peer['findings']
 add(__file__,'collector.py');add('/workspace/collect_cold128_originals_20261024.py','original-collector.py')
 add('/workspace/collect_four_archive_groups_originals_combined_20261024.py','previous-four-groups-collector.py')
 add('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py','original-tools/previous-three-groups-executor.py')
 assert not archive_bodies.intersection(x['source'] for x in entries.values())
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'four-additional-archive-groups-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='four-additional-archive-groups-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,groups_added={'additional_large_archive_groups':4},configured_gross_source_block_saving=gross,limits=['Maintenance only; no product gate is executed or relabeled.','All28 named archive paths and original bytes remain; no archive bodies or ELF payloads are duplicated into this metadata package.','Original423 cold groups,2 cardref ELF groups,1 six-alias group,3 previous large archive groups and4 additional groups are separate write/reuse bans. Every applicable alias must be de-linked before rewrite.','Original54 terminal rows including failures remain unchanged; maintenance0 does not turn them green.','Owner fresh byte/Git checks remain in journals; independent actual reviews inspect metadata/small streams without second large body hash.','Gross300097536 source block saving is not net df recovery; package/Git overhead and concurrent writes remain.','F2perf source-counterfactual excluded because its owner receipt is truncated; baseline formal-F is not that owner terminal.','Original prep producers ran via direct exec, with full recorded Git subcommands but no independent outer producer transcript; nothing is backfilled.','Initial exact-prefix preparation exit1 omitted tests/evidence; original tool/partial captures/direct exec transcript remain, no links occurred. The r2 scope stays exact4groups/28paths.','Independent post-package peer is adjacent to avoid self-reference.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
