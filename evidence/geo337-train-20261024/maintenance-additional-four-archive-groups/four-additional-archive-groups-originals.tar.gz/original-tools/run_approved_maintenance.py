"""Record one independently reviewed exact maintenance tool without a timeout."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
p=argparse.ArgumentParser()
for name in ('tool','sha256','source-sha','peer','out'):
 p.add_argument('--'+name,required=True)
a=p.parse_args();tool=Path(a.tool);peer=Path(a.peer)
assert hashlib.sha256(tool.read_bytes()).hexdigest()==a.sha256
assert peer.is_file() and len(a.source_sha)==40
capture=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(capture.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap',capture);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
out=Path(a.out);out.mkdir();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
r=c.Recorder(out,env,a.source_sha);argv=[sys.executable,'-B',str(tool)]
c.dump(out/'REQUEST.json',dict(argv=argv,tool_sha256=a.sha256,peer=str(peer),peer_sha256=hashlib.sha256(peer.read_bytes()).hexdigest(),source_sha=a.source_sha))
row,stdout,stderr=r.run(argv,cwd=Path('/workspace'),timeout=None,check=False,source_variant='exact-reviewed-terminal-maintenance')
c.dump(out/'RESULT.json',row);print(json.dumps(dict(exit_code=row['actual_process_returncode'],stdout=stdout.decode(),stderr=stderr.decode())))
sys.exit(row['actual_process_returncode'])
