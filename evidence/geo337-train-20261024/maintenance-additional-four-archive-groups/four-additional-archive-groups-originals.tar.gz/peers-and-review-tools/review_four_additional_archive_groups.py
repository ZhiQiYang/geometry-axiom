from pathlib import Path
import ast,hashlib,json,stat
B=Path('/workspace/four-additional-terminal-archives-preparation-r2-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');tool=B/'link_exact_four_additional_terminal_archive_groups.py';code=tool.read_text();old=Path(p['original_core']['path']).read_text();core=Path(p['core']['path']).read_text()
ck(h(B/'PLAN.json')=='6f991e1eb359440d27e7c7c44f8acb47084aa0e34c4e0e630a6c8b7035ed5a3d','fixed PLAN')
ck(h(tool)=='947d07db415afb84547e3baeb9cb0034663afea96c364ac71f060f18fcda7939','fixed executor')
ck(h(p['original_core']['path'])==p['original_core']['sha256']=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4','original core pin')
ck(h(p['core']['path'])==p['core']['sha256']=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','new core pin')
expected=old.replace("len(members) == 3 and len({x['path'] for x in members}) == 3","len(members) in (2, 4, 7) and len({x['path'] for x in members}) == len(members)").replace("len({(x['dev'], x['inode']) for x in members}) == 3","len({(x['dev'], x['inode']) for x in members}) == len(members)").replace('All three public paths','All named public paths').replace('state(members, {1, 2})','state(members, set(range(1, len(members))))').replace("event='complete', expected_alias_count=3","event='complete', expected_alias_count=len(members)")
ck(core==expected and ast.dump(ast.parse(core))==ast.dump(ast.parse(expected)),'only five cardinality/comment changes; full-byte state/atomic link+replace/fsync/journal unchanged')
ck(h(p['consumer_guard']['path'])==p['consumer_guard']['sha256']=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','original consumer guard')
ck(h('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original capture')
roots=['/workspace/geo261-cold/g261r2/work/codex-geo261-fe863b03/repo','/workspace/geo261-cold/g261r2/work/q38/repo','/workspace/geo261-cold/g261a1/work/codex-geo261-a12d184e/repo','/workspace/geo261-cold/g261a1/work/q38/repo','/workspace/geo261-cold/g261r1/work/codex-geo261-f2c8837a/repo','/workspace/geo261-cold/g261r1/work/q38/repo','/workspace/geo261-cold/g261r1/source-final']
heads=['fe863b0374eafd9f1e57ec5107e28a1101804b56']*2+['a12d184ec1865ad078700cea2387ac69e82ab62a']*2+['f2c8837aeba3c49eacbd77b5161f07c819204263']*3
specs=[(7,'tests/release-evidence/20261008/geometry-full-cdp-evidence-459478e9.tar.gz','30c623444e1bfb65187f9e3f9b482dcf4ff8716621bdb7dd0d6537d939212dd2','b6ecc8370f18fac8ff5c88c26bd5478464bffa83',15356034,92160000),(7,'tests/evidence/pf3-native-20261015/mutations-v2-originals.tar.gz','8f376ebd8d093f7750fb7b0d32da930a537163440ef195d4ca6087c435a67f80','9d44157ba422085bb202b77e92c2944ece0bc62b',11886655,71344128),(7,'tests/evidence/pf3-native-20261015/mutations-originals.tar.gz','5b90058f7169b4da0f58845bf3812cfae1846b29a1dc4187efa60e30810dd537','f8564babdb37fda0013f6d37f245e53a6e58f613',11886101,71319552),(7,'tests/evidence/pf3-native-20261015/official-originals.tar.gz','1139f364e55dd5af72fae9cc791830f9253b9bc210395329d34dc1ad62bfe935','c1748c2aec6dd1ff5204277a90314c49a9c6f92c',10875864,65273856)]
ck([o['root'] for o in p['owners']]==roots and [o['head'] for o in p['owners']]==heads and p['consumer_prefixes']==roots,'exact seven owner HEADs and consumer coverage')
ck(p['target_count']==28 and len(p['groups'])==4 and sum(g['expected_allocated_saving'] for g in p['groups'])==p['expected_allocated_saving']==300097536,'exact four groups/28paths/configured allocation only')
commands=[(r,['git','rev-parse','HEAD'],head) for r,head in zip(roots,heads)]
for g,(n,rel,digest,blob,size,saving) in zip(p['groups'],specs):
 ck(g['count']==n and len(g['members'])==n and g['sha256']==digest and g['git_blob']==blob and g['expected_allocated_saving']==saving,'exact group '+rel)
 ck([x['path'] for x in g['members']]==[r+'/'+rel for r in roots[:n]],'named group paths '+rel)
 ck(len({(x['dev'],x['inode']) for x in g['members']})==n and len({x['dev'] for x in g['members']})==1,'distinct same-device originals '+rel)
 ck(sum(x['allocated_bytes'] for x in g['members'][1:])==saving,'planned allocation sum '+rel)
 for idx,x in enumerate(g['members']):
  ck(x['owner_root']==roots[idx] and x['owner_head']==heads[idx] and x['git_path']==rel and x['sha256']==digest and x['git_blob']==blob and x['size']==size and x['nlink']==1,'exact archive identity '+x['path'])
  s=Path(x['path']).lstat();ck(stat.S_ISREG(s.st_mode) and all(getattr(s,'st_ino' if k=='inode' else 'st_'+k)==x[k] for k in ['dev','inode','mode','size','mtime_ns','uid','gid','nlink']),'fresh metadata only '+x['path'])
  commands.extend([(x['owner_root'],['git','ls-tree',x['owner_head'],'--',rel],f'100644 blob {blob}\t{rel}'),(x['owner_root'],['git','cat-file','-s',blob],str(size)),(x['owner_root'],['git','hash-object',x['path']],blob)])
for x in p['anchors']:
 q=Path(x['path']);ck(not q.is_symlink() and q.stat().st_size==x['bytes'] and h(q)==x['sha256'],'original small anchor '+str(q))
rows=[]
for t in p['terminal_rows']:
 raw=j(t['path']);ck(raw==t['original_rows'],'original terminal values '+t['path']);rows.extend(raw)
ck(len(p['terminal_rows'])==8 and len(rows)==54,'8 terminal receipts/54 original rows')
ck(all((r.get('finished_utc') or r.get('completed_utc')) and type(r.get('exit_code',r.get('actual_exit'))) is int for r in rows),'all named owner rows genuinely terminal including reds')
ck(any(r.get('exit_code',r.get('actual_exit'))==1 for r in rows),'historical red1 retained')
rawrows=j(B/'git-originals/subcommands.json');ck(len(rawrows)==len(commands)==91,'91 original Git captures')
for row,(cwd,argv,wanted) in zip(rawrows,commands):
 d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>=row['started_epoch'],'original exact Git invocation '+d.name)
 ck(j(d/'result.json')==row and bool(j(d/'request.json')),'full original request/result '+d.name)
 for stream in ['stdout','stderr']:
  q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'full original '+stream+' '+d.name)
 ck((d/'stdout.bin').read_text().strip()==wanted and (d/'stderr.bin').stat().st_size==0,'exact Git identity output '+d.name)
for phrase in ["assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ","anchors();git_identity();consumer()","before_each=consumer","git_identity();anchors()","all_original_payload_paths_retained=True","OUT.mkdir()","no cleanup or destructive rollback","set(range(1,len(g['members'])))","actual_process_returncode"]:ck(phrase in code,'executor original guard '+phrase[:60])
ck("'-w'" not in code and 'unlink' not in code and 'rmtree' not in code and "rec.run(['git',*args]" in code,'no object write/deletion commands in executor')
ck(p['actual_replacement_executed'] is False and 'No independent OS outer transcript' in p['preparation_provenance'],'prep-only honest provenance')
ck('/g261F2perf/' not in '\n'.join(x['path'] for g in p['groups'] for x in g['members']) and 'truncated' in p['excluded_reason'],'unproven truncated counterfactual excluded')
ck('every alias is de-linked' in p['reservation'] and 'separate from423' in p['reservation'] and 'No claim of a clean complete historical checkout or acceptance success' in p['scope_limit'],'separate exact lease and limited claims')

prior=Path('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py').read_text()
for a,z in [('three frozen immutable','four additional frozen immutable'),('/workspace/three-large-terminal-archives-preparation-20261024','/workspace/four-additional-terminal-archives-preparation-r2-20261024'),('7cbeec8b3c36f77dde886ef4e482ed6cfaf621a2e99ae734cb6bb11f174eb375','6f991e1eb359440d27e7c7c44f8acb47084aa0e34c4e0e630a6c8b7035ed5a3d'),('/workspace/three-large-terminal-archive-groups-preserving-links-execution-20261024','/workspace/four-additional-terminal-archive-groups-preserving-links-execution-20261024'),('[7,4,2]','[7,7,7,7]'),("p['target_count']==13","p['target_count']==28"),('452947968','300097536'),("g['members']})==13","g['members']})==28")]:
 ck(a in prior,'exact original executor replacement exists '+a);prior=prior.replace(a,z)
ck(code==prior,'executor differs only exact scope/cardinality/path/pin literals; no guard change')
consumer=j(B/'prepare-consumers/CONSUMERS.json');ck(consumer['hits']==[] and bool(consumer['limitation']) and isinstance(consumer['unreadable'],list),'original prep consumer no hit with inaccessible-process limits preserved')
ck('previous3 large archive groups/13aliases' in p['reservation'],'new fourgroups lease kept separate from prior three')

r={'schema':'four-additional-terminal-archive-groups-static-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'plan_sha256':h(B/'PLAN.json'),'executor_sha256':h(tool),'core_sha256':h(p['core']['path']),'counts':[7,7,7,7],'expected_allocated_saving':300097536,'terminal_original_rows':54,'original_preparation_git_commands':91,'limits':['Static/metadata/full small-stream review only; no archive body hash or replacement performed by reviewer.','Executor freshly checks all full archive bytes and all 91 Git identities before and after, with original consumer and full byte guards before each atomic transition.','All28 original paths preserved; inode/nlink/mtime may adopt canonical. Allocation estimate is not df net free.','Four additional independent groups/28 aliases and seven historical roots reserved; excluded truncated F2 owner untouched. No acceptance success or whole-checkout-clean claim.','Preparation direct exec provenance retained; no invented outer OS capture.'],'producer_initial_error':'Original first producer rejected tests/evidence prefix before linking; original failing directory/tool/transcript retained, r2 fresh exact labels add that path class. This reviewer did not execute producer.'}
q=O/'FOUR_ADDITIONAL_ARCHIVE_GROUPS_STATIC_PEER.json';q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
