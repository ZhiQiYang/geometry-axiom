"""Prepare 13 exact immutable archive aliases in three closed historical groups."""
from pathlib import Path
import datetime, difflib, hashlib, importlib.util, json, os

B=Path('/workspace/three-large-terminal-archives-preparation-20261024')
META=Path('/workspace/geo261-cold-large-archive-metadata-combined-20261024.json')
IDENTITY=Path('/workspace/geo261-cold-large-archive-identity-combined-20261024.json')
TERMINAL=Path('/workspace/geo261-cold-large-archive-terminal-combined-20261024.json')
ORIGINAL=Path('/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'

def h(p):
    v=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):v.update(b)
    return v.hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=h(p))

assert h(ORIGINAL)=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4'
assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(GUARD)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
B.mkdir()
old=ORIGINAL.read_text();source=old
changes=[("assert len(members) == 3 and len({x['path'] for x in members}) == 3","assert len(members) in (2, 4, 7) and len({x['path'] for x in members}) == len(members)"),
         ("assert len({(x['dev'], x['inode']) for x in members}) == 3","assert len({(x['dev'], x['inode']) for x in members}) == len(members)"),
         ('All three public paths','All named public paths'),
         ('state(members, {1, 2})','state(members, set(range(1, len(members))))'),
         ("dict(event='complete', expected_alias_count=3,","dict(event='complete', expected_alias_count=len(members),")]
for a,b in changes:
    assert source.count(a)==1;source=source.replace(a,b)
core=B/'exact_large_archive_group_link_core.py';core.write_text(source)
(B/'CORE_DIFF.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile=str(ORIGINAL),tofile=str(core))))
ns={'__name__':'_read_only_core','__file__':str(core)};exec(compile(source,str(core),'exec'),ns)
meta=json.loads(META.read_text());identity=json.loads(IDENTITY.read_text());terminal=json.loads(TERMINAL.read_text())
owners=[x for x in identity['owners'] if '/g261F2perf/' not in x['root']]
assert len(owners)==7
spec=importlib.util.spec_from_file_location('cap',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
rec=c.Recorder(B/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0'),L)
def git(root,args):
    row,out,err=rec.run(['git',*args],cwd=root,check=False,source_variant='read-only exact historical HEAD/archive identity; not a whole-tree clean claim')
    assert row['actual_process_returncode']==0 and not err
    return out.decode().strip()
for o in owners:
    assert o['git_exists'] and o['git_type']=='directory'
    o['head']=o['HEAD'].strip();assert len(o['head'])==40 and git(o['root'],['rev-parse','HEAD'])==o['head']
anchors=[pin(META),pin(IDENTITY),pin(TERMINAL)];terminal_rows=[]
for group in terminal['groups']:
    if group['root'].endswith('g261F2perf'):continue
    for x in group['receipts']:
        q=Path(x['path']);raw=json.loads(q.read_text());assert isinstance(raw,list) and raw
        for row in raw:
            ended=row.get('finished_utc') or row.get('completed_utc')
            assert ended and type(row.get('exit_code',row.get('actual_exit'))) is int
        anchors.append(pin(q));terminal_rows.append(dict(path=str(q),original_rows=raw))
groups=[]
for expected_count,g in zip([7,4,2],meta['candidates'][:3]):
    selected=[x for x in g['members'] if '/g261F2perf/' not in x['path']]
    assert len(selected)==expected_count
    members=[];blobs=set();digests=set()
    for x in selected:
        p=Path(x['path']);o=next(o for o in owners if p.is_relative_to(o['root']))
        relative=str(p.relative_to(o['root']));assert relative.startswith(('evidence/','tests/release-evidence/'))
        m=ns['metadata'](p)
        assert m['nlink']==1 and m['size']==g['each_bytes'] and m['dev']==x['dev'] and m['inode']==x['inode']
        assert not os.listxattr(p,follow_symlinks=False)
        digest=h(p);digests.add(digest)
        raw=git(o['root'],['ls-tree',o['head'],'--',relative]);assert raw.startswith('100644 blob ') and raw.split('\t',1)[1]==relative
        blob=raw.split()[2];blobs.add(blob)
        assert int(git(o['root'],['cat-file','-s',blob]))==m['size']
        assert git(o['root'],['hash-object',str(p)])==blob
        members.append(dict(path=str(p),sha256=digest,owner_root=o['root'],owner_head=o['head'],git_path=relative,git_blob=blob,**m))
    assert len(blobs)==len(digests)==1 and len({(x['dev'],x['inode']) for x in members})==expected_count
    assert len({(x['mode'],x['uid'],x['gid'],x['sha256'],x['size']) for x in members})==1
    groups.append(dict(relative_label=g['relative_evidence'],count=len(members),members=members,
                       sha256=members[0]['sha256'],git_blob=members[0]['git_blob'],
                       expected_allocated_saving=sum(x['allocated_bytes'] for x in members[1:])))
assert [g['count'] for g in groups]==[7,4,2]
plan=dict(source_sha=L,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),groups=groups,owners=owners,
          target_count=13,anchors=anchors,terminal_rows=terminal_rows,expected_allocated_saving=sum(g['expected_allocated_saving'] for g in groups),
          original_core=pin(ORIGINAL),core=pin(core),consumer_guard=pin(GUARD),consumer_prefixes=[o['root'] for o in owners],
          reservation='Only these three exact groups/13 immutable archive aliases are write/reuse banned until every alias is de-linked. During execution all seven named historical owner roots are reserved against use. This scope is separate from423 seal cold groups,2 cardref ELF groups and1 GEO339 six-alias group.',
          identity_limit='Every original archive path and complete byte sequence remains. Destination inode/nlink/mtime/atime adopt the canonical archive metadata; original inode numbers are not restorable.',
          excluded_unproven_owner='/workspace/geo261-cold/g261F2perf/source-counterfactual',
          excluded_reason='Its receipt.json is originally truncated; formal-F receipt belongs to an earlier baseline and cannot prove this counterfactual terminal. Both candidate aliases remain untouched.',
          scope_limit='Exact immutable Git blob/HEAD/archive proofs only. No claim of a clean complete historical checkout or acceptance success. All original red terminal results remain red.',
          actual_replacement_executed=False,preparation_provenance='Saved direct cloud exec producer; all Git commands have c387 env/exit/full streams. No independent OS outer transcript is claimed for producer.')
save(B/'PLAN.json',plan)
print(json.dumps(dict(plan=str(B/'PLAN.json'),plan_sha256=h(B/'PLAN.json'),core_sha256=h(core),counts=[7,4,2],expected_allocated_saving=plan['expected_allocated_saving'],actual_replacement_executed=False)))
