"""Review exact historical terminal cache retirement; no current cache access."""
from pathlib import Path
import hashlib,json
BASE=Path('/workspace/terminal-sevenfinal-five-browser-15-elf-preparation-20261024')
OUT=Path('/workspace/terminal-sevenfinal-exact-15-runtime-elf-retirement-execution-20261024')
LAUNCH=Path('/workspace/terminal-sevenfinal-exact-15-runtime-elf-retirement-launch-20261024')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
checks=0;findings=[]
def ck(n,v):
 global checks
 checks+=1
 if not v:findings.append(n)
p=j(BASE/'PLAN.json');r=j(OUT/'RESULT.json');a=j(LAUNCH/'RESULT.json')
ck('frozen plan',h(BASE/'PLAN.json')=='6b90994e52471f673d89ead8705783a1b29cf543c1edb9d1e8058a8054920c7b')
ck('frozen tool',h(BASE/'retire_exact_fifteen_terminal_runtime_elf.py')=='10d281fe1456f99d7be0cb356373a5363d1c2a9c8ff458ccea02d5a27df510ab')
ck('historical source binding',p['sourceSHA']==r['historical_sourceSHA']==a['source_sha']=='8f76f2b7d6f669670e5834310bfc26495b4a4aa6')
ck('actual true terminal',r['exit_code']==0 and bool(r['ended_utc']) and r['no_receipt_or_source_removed'] and r['historical_results_unchanged'])
ck('outer true terminal',a['actual_process_returncode']==0 and a['ended_epoch'] and not a['timeout_expired'])
ck('exact15 removed in plan order',r['removed']==[x['path'] for x in p['targets']] and len(r['removed'])==15)
ck('original allocation',p['allocated_file_bytes']==r['retired_allocated_file_bytes']==14745600)
ck('unchanged limits','no future cross-toolchain identical-ELF guarantee' in r['rebuild'] and 'inaccessible fields' in r['consumer_limit'])
for item in p['targets']:
 target=Path(item['path']);ck('only target absent '+str(target),not target.exists() and target.parent.is_dir())
 side=Path(item['fingerprint_path']);f=j(side)
 ck('original recipe '+str(side),h(side)==item['fingerprint_sha256'] and f['exe_sha256']==item['sha256'] and f['fingerprint']==item['fingerprint'] and f['command']==item['build_command'])
for item in p['terminal_receipts']+p['sidecars']+[p['root_historical_receipt']]:
 q=Path(item['path']);ck('preserved original '+str(q),q.stat().st_size==item['bytes'] and h(q)==item['sha256'])
for group in p['groups']:
 q=j(group['receipt_path']);ck('unchanged historical result '+group['job'],q['sha']==p['sourceSHA'] and q['job']==group['job'] and q['exit_code']==0 and q['status']=='完成' and bool(q['ended']))
for stream in ['stdout','stderr']:
 q=Path(a['directory'])/(stream+'.bin');ck('original full outer '+stream,q.stat().st_size==a[stream+'_bytes'] and h(q)==a[stream+'_sha256'])
c=j(OUT/'CONSUMERS.json');ck('consumer observation preserved',c['hits']==[] and 'unreadable' in c and bool(c['limitation']))
result=dict(scope='Exact15 ordinary runtime ELF cache retirement from five historical 8f76 noncanvas jobs only',checks=checks,findings=findings,exit_code=int(bool(findings)),plan_sha256=h(BASE/'PLAN.json'),actual_result_sha256=h(OUT/'RESULT.json'),outer_result_sha256=h(LAUNCH/'RESULT.json'),allocated_bytes=14745600,original_free_before=r['free_before'],original_free_after=r['free_after'],limitations=['No runtime product test or final-L acceptance claimed.','ELF payloads retired by root; original execution performed fresh full hash/identity/consumer checks. This reviewer checks preserved records, terminal scope, sidecars and exact current absence.','Original source/raw/fixtures/Git objects and all sidecars remain; future build need not produce identical bytes across toolchains.','Free-space delta is a historical observation and may include concurrent writers.'])
q=Path('/workspace/SEVENFINAL_15_ELF_ACTUAL_METADATA_PEER_20261024.json');assert not q.exists();q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(path=str(q),sha256=h(q),checks=checks,findings=findings,exit_code=result['exit_code'])));raise SystemExit(result['exit_code'])
