"""Read-only check of the original exact fifteen cache retirement guards."""
from pathlib import Path
import datetime, hashlib, json, os, sys

BASE = Path('/workspace/terminal-sevenfinal-five-browser-15-elf-preparation-20261024')
PLAN = BASE / 'PLAN.json'
TOOL = BASE / 'retire_exact_fifteen_terminal_runtime_elf.py'
OUT = BASE / 'fresh-guard-proof'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
ROOT = Path('/tmp/g261r3')
JOBS = ['documents', 'assembly', 'grid', 'space', 'timber']
SHA = '8f76f2b7d6f669670e5834310bfc26495b4a4aa6'

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

assert sys.flags.optimize == 0 and 'PYTHONOPTIMIZE' not in os.environ
assert digest(PLAN) == '6b90994e52471f673d89ead8705783a1b29cf543c1edb9d1e8058a8054920c7b'
assert digest(TOOL) == '10d281fe1456f99d7be0cb356373a5363d1c2a9c8ff458ccea02d5a27df510ab'
assert digest(GUARD) == 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
g = {'__name__': '_read_only_guard_check', '__file__': str(GUARD)}
exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), g)
OUT.mkdir()
g['OUT'] = OUT
r = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         exit_code=1, read_only=True, retirement_executed=False, source_sha=SHA,
         plan_sha256=digest(PLAN), tool_sha256=digest(TOOL), verified=[])
try:
    p = json.loads(PLAN.read_text())
    assert p['root'] == str(ROOT) and p['sourceSHA'] == SHA
    assert [x['job'] for x in p['groups']] == JOBS
    assert len(p['targets']) == p['target_count'] == 15
    assert p['allocated_file_bytes'] == sum(x['allocated_bytes'] for x in p['targets']) == 14745600
    expected = set()
    for group in p['groups']:
        tmp = ROOT / 'tmp/seven-final' / group['job']
        run = Path(group['runtime_directory'])
        assert group['temporary_directory'] == str(tmp) and run.parent == tmp / 'geometry-runtime'
        assert len(run.name) == 20 and all(c in '0123456789abcdef' for c in run.name)
        assert group['receipt_path'] == str(ROOT / 'seven-final' / group['job'] / 'receipt.json')
        expected.update(str(run / n) for n in ['bridge', 'core', 'model-base'])
        receipt = json.loads(Path(group['receipt_path']).read_text())
        assert receipt['sha'] == SHA and receipt['job'] == group['job']
        assert receipt['status'] == '完成' and receipt['exit_code'] == 0 and receipt['ended']
        assert receipt['temporary_directory'] == str(tmp)
    assert {x['path'] for x in p['targets']} == expected
    preserved = p['terminal_receipts'] + p['sidecars'] + [p['root_historical_receipt']]
    for item in preserved:
        source = Path(item['path'])
        g['ancestors'](source)
        assert source.stat().st_size == item['bytes'] and digest(source) == item['sha256']
    for item in p['targets']:
        target = Path(item['path'])
        g['identity'](target, item, is_file=True)
        s = target.stat()
        assert (s.st_uid, s.st_gid) == (item['uid'], item['gid'])
        with target.open('rb') as f:
            assert f.read(4) == b'\x7fELF'
        assert item['fingerprint_path'] == str(target) + '.fingerprint.json'
        sidecar = Path(item['fingerprint_path'])
        assert digest(sidecar) == item['fingerprint_sha256']
        side = json.loads(sidecar.read_text())
        assert side['exe_sha256'] == item['sha256'] and side['exe_size'] == item['size']
        assert side['fingerprint'] == item['fingerprint'] and side['command'] == item['build_command']
        r['verified'].append(dict(path=str(target), sha256=item['sha256'], size=item['size']))
    g['consumer_check']([x['temporary_directory'] for x in p['groups']])
    for item in preserved:
        assert digest(item['path']) == item['sha256']
    r.update(exit_code=0, originals_still_present=all(Path(x['path']).is_file() for x in p['targets']),
             terminal_and_sidecar_pins_preserved=len(preserved),
             future_execution='Root must rerun original tool fresh guards; this read-only snapshot does not authorize bypassing any guard.')
except Exception as exc:
    r['error'] = repr(exc)
    raise
finally:
    r['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    g['dump']('RESULT.json', r)
    print(json.dumps({k: v for k, v in r.items() if k != 'verified'}))
