"""Bind a final-L original browser job to private storage; keep its judge unchanged."""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, os, socket, sys, traceback
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
POOL=Path('/workspace/train337-browser-pool-L-7af8c5d8')
DRIVER=POOL/'workflow-driver-browser-workspace.py'
PREPARER=Path('/tmp/browser_readonly_pool_preparer_v3_seed.py')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
REAPER=Path('/workspace/geo261-environment/reap_children.py')
PINS={str(DRIVER):'2a42523fee66c7947313f567716b81f25c1cf50b965698ff5913216695cd1c98',str(PREPARER):'be176d0a55643cdab19f0e5ae79734e91b4cc63a34783132c689c9ec83aec643',str(CAPTURE):'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',str(REAPER):'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'}
PORTS={'canvas':(19081,9333),'assembly':(19082,9367),'documents':(19083,9366),'grid':(19084,9334),'space':(19085,9347),'timber':(19086,9348)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--job',choices=PORTS,required=True);ap.add_argument('--resource-lock',choices=['heavy','secondary'],required=True);a=ap.parse_args()
 assert not sys.flags.optimize
 for path,pin in PINS.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==pin,path
 env={k:v for k,v in os.environ.items() if not k.startswith(('GEOMETRY_','GIT_','GEO261_','MUTATE_'))}
 for k in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD']:env.pop(k,None)
 env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
 out=Path('/workspace/train337-browser-L-'+a.job+'-launch');out.mkdir()
 storage=Path('/workspace/train337-browser-L-'+a.job);assert not storage.exists()
 source=POOL/'layout/jobs'/a.job/'source'
 spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
 recorder=cap.Recorder(out,env,L);locks=[]
 report=dict(source_sha=L,job=a.job,source=str(source),storage=str(storage),driver_pins=PINS,commands=recorder.rows,original_primary_exit=None,wrapper_exit=None,passed=False,errors=[],canvas_exclusive=a.job=='canvas',no_new_assertion_skip_or_timeout=True)
 code=2
 def save():cap.dump(out/'receipt.json',report)
 try:
  names=['heavy','secondary'] if a.job=='canvas' else [a.resource_lock]
  for name in names:
   lock=Path('/tmp/g261r3/'+name+'.lock').open('r+b');locks.append(lock);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  for port in PORTS[a.job]:
   with socket.socket() as s:s.bind(('127.0.0.1',port))
  template=Path('/tmp/browser-six-minimal-requests-finalL-v2')/(a.job+'.REQUEST.template.json')
  raw=template.read_text().replace('<FINAL_L_40_HEX_NOT_ASSIGNED>',L).replace('<FINAL_L_SHA8_NOT_ASSIGNED>',L[:8]).replace('<FINAL_BROWSER_PLAN_DIR_ABSOLUTE>',str(POOL))
  raw=raw.replace('/tmp/browser-'+L[:8]+'-'+a.job,str(storage))
  binding=json.loads(raw);binding.update(state='BOUND_FINAL_L_ORIGINAL_JOB_STARTING',driver_sha256=PINS[str(DRIVER)],external_storage_constraint_delta='Only browser output may also use /workspace; native stays /tmp. Original workflow/assertions/CI/timeout/golden unchanged.')
  binding['driver_argv'][2]=str(DRIVER)
  cap.dump(out/'BOUND_REQUEST.json',binding)
  guard=[sys.executable,'-B',str(PREPARER),'--out',str(POOL),'--guard']
  before,_,_=recorder.run(guard,cwd='/workspace',timeout=None,check=False,source_variant='private-pool-before-original-browser');assert before['actual_process_returncode']==0
  report['before_guard']=before;save()
  env['GEO261_REAPER_LOG']=str(out/'reaper.jsonl')
  argv=[sys.executable,'-B',str(REAPER),*binding['driver_argv']]
  row,_,_=recorder.run(argv,cwd='/workspace',timeout=None,check=False,source_variant='original-final-L-full-browser-job')
  report['original_command']=row;save()
  original_path=storage/'original'/a.job/'receipt.json';original=json.loads(original_path.read_bytes())
  events=[json.loads(line) for line in (out/'reaper.jsonl').read_text().splitlines()];done=[e for e in events if e.get('event')=='完成'];assert len(done)==1 and events[-1]==done[0]
  assert original['sha']==L and original['job']==a.job
  assert row['actual_process_returncode']==done[0]['primary_returncode']==original['exit_code']
  assert original['ci_timeout_minutes']==binding['ci_timeout_minutes'] and original['watchdog_factor']==3
  report.update(original_primary_exit=original['exit_code'],original_receipt=str(original_path),original_receipt_sha256=hashlib.sha256(original_path.read_bytes()).hexdigest(),over_ci_timeout=original['over_ci_timeout'])
  code=original['exit_code'] or (1 if original['over_ci_timeout'] else 0)
  report['passed']=code==0
 except BlockingIOError:
  code=75;report['errors'].append('Original browser not started: scheduler lock already held.')
 except BaseException:
  code=2;report['errors'].append(traceback.format_exc())
 finally:
  if report.get('before_guard'):
   try:
    after,_,_=recorder.run([sys.executable,'-B',str(PREPARER),'--out',str(POOL),'--guard'],cwd='/workspace',timeout=None,check=False,source_variant='private-pool-after-original-browser')
    report['after_guard']=after
    if after['actual_process_returncode']!=0:code=2;report['passed']=False
   except BaseException:report['errors'].append(traceback.format_exc());code=2;report['passed']=False
  for lock in reversed(locks):lock.close()
  report['wrapper_exit']=code;save()
 print(json.dumps({k:report[k] for k in ['source_sha','job','original_primary_exit','wrapper_exit','passed']}));return code
if __name__=='__main__':raise SystemExit(main())
