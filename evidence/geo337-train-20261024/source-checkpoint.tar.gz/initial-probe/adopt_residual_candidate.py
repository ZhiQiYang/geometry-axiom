"""Apply the independently reviewed exact four-file candidate to the train."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('/workspace/geometry-axiom')
candidate = Path('/tmp/geo323-train337-lineage-20261024/candidate-H3cbeb759-v2')
manifest = json.loads((candidate / 'CANDIDATE.json').read_text())

def git(*args):
    result = subprocess.run(['git', *args], cwd=root, capture_output=True, check=True)
    print(json.dumps({'argv': ['git', *args], 'exit': result.returncode,
                      'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()}, ensure_ascii=False))
    return result.stdout.decode().strip()

assert git('branch', '--show-current') == 'codex/train-337-continue-20261024'
assert git('rev-parse', 'HEAD') == '3417ab932e40431fc99ca74e50762149ebfc09f8'
assert git('status', '--porcelain') == ''
assert hashlib.sha256((candidate / 'candidate.patch').read_bytes()).hexdigest() == manifest['patch_sha256']
for row in manifest['files']:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['H_sha256'], row['path']
git('apply', '--check', str(candidate / 'candidate.patch'))
git('apply', str(candidate / 'candidate.patch'))
for row in manifest['files']:
    actual = hashlib.sha256((root / row['path']).read_bytes()).hexdigest()
    assert actual == row['candidate_sha256'], row['path']
    print(json.dumps({'path': row['path'], 'sha256': actual, 'match': True}))
assert set(git('diff', '--name-only').splitlines()) == set(manifest['changed_paths'])
git('diff', '--check')
git('add', '--', *manifest['changed_paths'])
git('commit', '-m', 'fix: preserve consumer dependencies in contact placement memoization')
sha = git('rev-parse', 'HEAD')
git('push', 'origin', 'HEAD:refs/heads/codex/train-337-continue-20261024')
remote = git('ls-remote', '--heads', 'origin', 'refs/heads/codex/train-337-continue-20261024').split()[0]
assert remote == sha
print(json.dumps({'product_sha': sha, 'published': True}, ensure_ascii=False))
