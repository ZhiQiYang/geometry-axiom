# #323 候選移植到 #337 H3cbeb759

移植目標為 `3cbeb75926bb188e6c8f153d182303feadfa27dc`，只在此目錄的外部 snapshots/candidate 寫檔，沒有變更任何 Git 工作樹、index、HEAD 或 branch。

候選 patch 與先前經獨立靜審的 a44018ad 原 patch 逐位元組相同；四檔機制與 controls 沒有新增變動。H 中 reading A 新增內容位於原 patch hunk 範圍之後，兩個 C 候選保留完整 H 內容；兩個 tests 原件與 S 相同，所以其候選內容也與 a440 相同。

`candidate-H3cbeb759-v2/CANDIDATE.json` 綁定 H 原件／候選各檔 hash、每個原 hunk 的 S→H 精確完整區塊映射及逆向重建。重新將全部 replacements 反向套用會逐位元組恢復 H；同樣對 S 套用則逐位元組重建原 a440 候選。只用 AST 解析確認原13個 test methods 保留，沒有執行測試。

先前 porter v1 對整份文字要求 context 唯一，在 test 檔中找到兩個相同 context 而安全拒絕（exit 1）。該失敗 porter 和 partial external tree 保留；v2 依原 patch 的 S 行範圍、完整不變區塊映射與內容相等守門，準備完成 exit 0。這是外部準備工具更正，不是產品測試結果，也沒有放寬任何產品裁判。

仍未套入產品、未編譯、未跑三suite／反證／PF3／175ABC／36timing／4gprof／native／帳本／架構。性能收益未知；原 S 紅燈維持原身分，H 尚無新結果。root 固定新列車來源後才能決定驗收與採用。
