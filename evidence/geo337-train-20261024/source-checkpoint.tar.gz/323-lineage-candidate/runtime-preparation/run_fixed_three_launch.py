from pathlib import Path
import argparse,datetime,importlib.util,json,os,hashlib,traceback
parser=argparse.ArgumentParser();parser.add_argument('--sha',required=True);args=parser.parse_args()
F=args.sha; tag=F[:8]
ROOT=Path('/workspace/geometry-axiom');REPO=Path('/tmp/train337-323-'+tag+'-source');OUT=Path('/tmp/train337-323-'+tag+'-three');LAUNCH=Path('/tmp/train337-323-'+tag+'-three-launch')
C=Path('/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not REPO.exists() and not OUT.exists() and not LAUNCH.exists()
LAUNCH.mkdir();spec=importlib.util.spec_from_file_location('originalcap',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env['PATH']='/workspace/geo261-environment/bin:'+env['PATH'];env.pop('NODE_OPTIONS',None);env.pop('PYTHONOPTIMIZE',None)
rec=cap.Recorder(LAUNCH,env,F);report={'source_sha':F,'repo':str(REPO),'out':str(OUT),'commands':rec.rows,'errors':[],'started_utc':utc(),'sparse_patterns':'/*\n!/evidence/\n!/tests/evidence/\n','scope':'Original13/22/15 PARTIAL not full native; omitted evidence paths not claimed materialized-identical','runtime_actual_exit':None,'ended_utc':None}
try:
 rec.run(['df','-B1','/tmp','/workspace'],cwd=ROOT,check=True)
 rec.run(['git','clone','--shared','--no-checkout','--single-branch','--branch','codex/train-337-continue-20261024',str(ROOT),str(REPO)],cwd=Path('/tmp'),check=True,timeout=180)
 rec.run(['git','config','core.sparseCheckout','true'],cwd=REPO,check=True)
 rec.run(['git','config','core.sparseCheckoutCone','false'],cwd=REPO,check=True)
 (REPO/'.git/info/sparse-checkout').write_text(report['sparse_patterns'])
 rec.run(['git','checkout','--detach','--no-progress',F],cwd=REPO,check=True,timeout=180)
 head=rec.run(['git','rev-parse','HEAD'],cwd=REPO,check=True)[1].decode().strip();status=rec.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=REPO,check=True)[1].decode();assert head==F and status==''
 report['input_before']={'head':head,'status':status,'candidate_files':[]}
 manifest=json.loads(Path('/tmp/geo323-train337-lineage-20261024/candidate-H3cbeb759-v2/CANDIDATE.json').read_text())
 for file in manifest['files']:
  raw=(REPO/file['path']).read_bytes();got=hashlib.sha256(raw).hexdigest();assert got==file['candidate_sha256'];report['input_before']['candidate_files'].append({'path':file['path'],'sha256':got,'bytes':len(raw)})
 for command in [['node','--version'],['google-chrome','--version'],['python3','--version']]:rec.run(command,cwd=REPO,check=True,timeout=30)
 command=['python3','-B','/tmp/geo323-merge-20261023/fixed-three-driver-preparation/run_three_fixed.py','--repo',str(REPO),'--sha',F,'--out',str(OUT)]
 cap.dump(LAUNCH/'TOP_REQUEST.json',{'source_sha':F,'argv':command,'cwd':str(REPO),'environment':{k:env.get(k) for k in ['PATH','NODE_OPTIONS','PYTHONOPTIMIZE','LANG','LC_ALL']},'input_before':report['input_before'],'stack_policy':'Original driver16MiB','source_variant':'Formal candidate same F, not withdrawal'})
 cap.dump(LAUNCH/'receipt.json',report)
 report['runtime_actual_exit']=rec.run(command,cwd=REPO,check=False,timeout=None)[0]['actual_process_returncode']
except BaseException:report['errors'].append(traceback.format_exc())
finally:
 report['ended_utc']=utc();report['launch_exit']=report['runtime_actual_exit'] if report['runtime_actual_exit'] is not None and not report['errors'] else 2;cap.dump(LAUNCH/'receipt.json',report)
 print(json.dumps({'source_sha':F,'runtime_actual_exit':report['runtime_actual_exit'],'launch_exit':report['launch_exit'],'errors':report['errors']},ensure_ascii=False),flush=True)
raise SystemExit(report['launch_exit'])
