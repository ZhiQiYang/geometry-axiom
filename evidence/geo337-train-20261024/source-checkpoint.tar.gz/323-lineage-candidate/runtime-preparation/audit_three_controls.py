"""Read completed original three-suite artifacts; never execute a judge or modify raw."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);p.add_argument('--report',required=True,type=Path);a=p.parse_args()
def digest(b):return hashlib.sha256(b).hexdigest()
assert not a.report.exists(),'append-only report requires fresh path'
r=json.loads((a.out/'receipt.json').read_text());assert r.get('ended_utc'),'original terminal receipt required'
report={'schema':'geo323-original-three-artifact-audit/1','source_sha':r['source_sha'],'raw_receipt_sha256':digest((a.out/'receipt.json').read_bytes()),'original_run_exit':r.get('original_run_exit'),'reaper_process_exit':r.get('reaper_process_exit'),'outer_exit':r.get('outer_exit'),'source_before':r.get('source_before'),'source_after':r.get('source_after'),'suite_results':{},'controls':{},'findings':[],'judge_or_gate_modified':False,'tests_executed_by_auditor':False}
for name,count in [('load_residual',13),('host_facts_authority',22),('contact_sources',15)]:
 q=a.out/'selected-logs-after'/('py_test_geo261_'+name+'.json')
 if not q.exists():report['findings'].append('missing original sidecar '+str(q));continue
 d=json.loads(q.read_text());report['suite_results'][name]={'sha256':digest(q.read_bytes()),'raw':d}
 if not (d['total']==d['run']==d['passed']==count and d['failed']==0 and d['skipped']==0 and d.get('extra_errors',0)==0 and d.get('import_error') is None):report['findings'].append('original suite not exact green '+name)
q=a.out/'executions/load-residual.jsonl'
rows=[json.loads(line) for line in q.read_text().splitlines()]
report['load_execution_jsonl']={'path':str(q),'bytes':q.stat().st_size,'sha256':digest(q.read_bytes()),'entries':len(rows)}
normal={
 'contact-edge':('cache-contact','contact-cache-second-consumer-edge-and-order'),
 'contact-kind':('cache-contact','contact-cache-second-consumer-edge-and-order'),
 'contact-order':('cache-contact','contact-cache-second-consumer-edge-and-order'),
 'definition-edge':('cache-definition','definition-cache-second-consumer-edge-and-order'),
 'definition-kind':('cache-definition','definition-cache-second-consumer-edge-and-order'),
 'anchor-edge':('cache-anchor','anchor-cache-second-consumer-edge-and-order'),
 'anchor-kind':('cache-anchor','anchor-cache-second-consumer-edge-and-order'),
 'footprint-edge':('cache-footprint','footprint-cache-second-consumer-edge-and-order'),
 'footprint-kind':('cache-footprint','footprint-cache-second-consumer-edge-and-order'),
 'footprint-order':('cache-footprint','footprint-cache-second-consumer-edge-and-order'),
 'pose-edge':('cache-pose','pose-cache-second-consumer-edge-and-order'),
 'pose-kind':('cache-pose-kind','pose-cache-preserves-requested-dependency-kind'),
 'footprint-hit-raw-snapshot':('cache-footprint-source','footprint-cache-hit-preserves-source-out'),
 'anchor-id-key':('member-anchor-id','member-anchor-cache-id-must-match'),
 'contact-id-key':('member-anchor-miss','member-anchor-miss-invalidates-footprint'),
 'anchor-miss-invalidation':('member-anchor-miss','member-anchor-miss-invalidates-footprint'),
 'placement-second-consumer-reader-and-hit-edge':('consumers','cross-consumer-placement-edge-missing'),
}
for control,(case,marker) in normal.items():
 selected=[x for x in rows if x.get('control')==control]
 record={'case':case,'marker':marker,'raw_entries':selected,'expected_exit_sequence':[0,1,0],'passed':True}
 for phase,code in [('baseline',0),('mutant',1),('restored',0)]:
  x=[x for x in selected if x.get('phase')==phase]
  good=len(x)==1
  if good:
   v=x[0];good=v['source_sha']==r['source_sha'] and v['case']==case and v['actual_exit']==code and v['timeout_expired'] is False
   if phase=='mutant':good=good and ('ASSERT:'+marker+' ') in v['stderr'] and v['stderr'].count('ASSERT:')==1
   else:good=good and v['stdout']=='PASS '+case+'\n'
  if not good:record['passed']=False;report['findings'].append('original named phase mismatch '+control+' '+phase)
 report['controls'][control]=record
# Preserve the preexisting intentionally equivalent single withdrawal and paired defence separately.
for control,phases in [('placement-key-single',[('baseline',0),('single-mutant-equivalent',0),('restored',0)]),('placement-key-paired',[('baseline-anchor-invalidator-disabled',0),('mutant-anchor-invalidator-disabled',1),('restored-anchor-invalidator-disabled',0)])]:
 selected=[x for x in rows if x.get('control')==control];good=True
 for phase,code in phases:
  items=[x for x in selected if x.get('phase')==phase]
  good=good and len(items)==1 and items[0]['actual_exit']==code and items[0]['timeout_expired'] is False and items[0]['source_sha']==r['source_sha']
 report['controls'][control]={'expected_phases':phases,'passed':good,'raw_entries':selected,'scope':'single withdrawal is intentionally equivalent0, not killed; paired defence has its explicit precondition'}
 if not good:report['findings'].append('original placement proof mismatch '+control)
report['unlabelled_entries_count']=sum(x.get('control') is None for x in rows)
report['scope']='19 original labelled control groups audited from original JSONL; unlabelled positive/legacy controls retained in raw, not relabelled; no whole-memo performance withdrawal claim.'
report['passed']=not report['findings'] and r.get('metadata_complete') is True and r.get('original_run_exit')==0 and r.get('reaper_process_exit')==0 and r.get('outer_exit')==0
for k in ['source_before','source_after']:
 if not report[k] or report[k].get('head')!=r['source_sha'] or report[k].get('status')!='':report['passed']=False;report['findings'].append('source guard mismatch '+k)
a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'controls':len(report['controls']),'findings':report['findings'],'report':str(a.report),'sha256':digest(a.report.read_bytes())},ensure_ascii=False))
raise SystemExit(0 if report['passed'] else 1)
