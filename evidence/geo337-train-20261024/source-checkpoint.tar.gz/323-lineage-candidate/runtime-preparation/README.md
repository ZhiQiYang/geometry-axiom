# 新列車 #323 原驗收準備

此處尚未執行產品／測試／編譯／計時，也未建立 checkout。直接重用原動態 CLI，沒有改驗收 driver。完整 argv template、原工具各檔 hash、13/22/15、四個新增 controls 與兩個修正 controls 的精確 0/1/0 marker 收於 PREPARATION.json。

root 固定並公開新 F 後，先在自己的乾淨 detached snapshot 跑原 fixed-three。原 load13 的各 controls 每個都已內建 baseline/mutant/restored：必須 0/1/0，mutant 只有一個具名 ASSERT；編譯／loader／timeout 不能當 kill。保存原 JSONL，不以 suite 顯示綠代替逐原件核對。

之後按原 v3 prepare → build → compare → perf → profile 收齊，不用 old S 的紅綠替代。prepare/build/compare 後在 stage 邊界等 root 性能獨占時槽；perf 原36筆、profile原4次，各只跑一次。分母固定 b74f9a2a／adbaebf9，N32/base≤1、N64/main≤1.3、calls≤4.5 都不變。紅燈保留並繼續其餘不受影響工作。

整體 memo 撤回／恢復的性能反證仍是待 root 確定 scope 的計畫；四個 guard controls 不是「把整個memo拿掉即性能紅」的替代證據。不能用舊 S profile 冒新F撤回phase；實際未轉紅就寫未證，禁止重抽。
