# #323 → #337 唯讀合流核對

結論：#323 既有產品／測試內容已完整收入 `3cbeb75926bb188e6c8f153d182303feadfa27dc`。未找到缺漏，後續工作應移至 root 新列車，不再推舊 #323 分支。

`b2445b5a` 與 evidence `4ea6c507` 不是 H 祖先（原指令 exit 1），但真正產品合流點 `5c29eba3` 與舊 `239040fd` 都是 H 祖先（exit 0）。產品依 `5c29 → c939d4f3 → 15a73595 → #318 → main/#288 同步` 收入；另以 B→S 的 16 個產品／測試 delta 逐檔檢查後續內容，沒有依 evidence ancestry 代替核對。

16 檔有 9 檔逐位元組相同。7 檔後續延伸包括 reading A／stagger adapter、精確診斷文字及其他 suite 註冊。323 新增／替換行與後續刪改行的交集為空；完整 diff 亦確認 memo、逐 consumer 依賴、raw prefix completion、cleanup、W contact query 與原三套測試內容保留。H 原三套 count 仍為 13／22／15。機械行交集本身不代表語意等價，此結論限於既有變更完整收入。

已讀 handoff `d193946b8e0fbda024d3b134c4851e9393a43d38` 最新 #323 審查：2026-10-23 16:42:08 UTC、head `4ea6c50`。它要求同步最終來源、修原紅燈及做最終驗收。原 S 的 N32/base `1.0008656473515014 > 1`、calls64/32 `6.154996228372071 > 4.5` 與兩 controls drift 保留；N64/main `1.160861952340483 ≤ 1.3` 已在 S 過。這些不是 H 的新實測。

未執行測試、編譯、掃描、bench、profile；未 fetch／push，未更改工作樹、index 或 HEAD。外部原命令、exit、完整輸出、環境與 SHA 保存在 STEP1／2／3。早前即時訊息的「10/16 相同」為計數筆誤；原 STEP2 及此終版均為 **9/16**。
