#!/usr/bin/env python3
"""Apply immutable, exact-context #323 candidate to external H snapshots only."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
OLD = Path('/tmp/geo323-merge-20261023/combined-memo-controls-candidate-v1')
OUT = HERE / 'candidate-H3cbeb759-v1'
SHA = '3cbeb75926bb188e6c8f153d182303feadfa27dc'
OLD_PATCH_SHA = 'a44018ad1e3455af89dc9fbc19ea4ec3d9b0e4dfec56f9ddab5d2893d91871b0'


def digest(value):
    return hashlib.sha256(value).hexdigest()


def parse_patch(raw):
    changes = []
    current = None
    hunk = None
    for line in raw.decode('utf-8').splitlines(keepends=True):
        if line.startswith('--- a/'):
            current = {'path': line[6:].rstrip('\n'), 'hunks': []}
            changes.append(current)
            hunk = None
        elif line.startswith('+++ b/'):
            assert current is not None
            assert line[6:].rstrip('\n') == current['path']
        elif line.startswith('@@ '):
            assert current is not None
            m = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', line)
            assert m, repr(line)
            hunk = {'header': line.rstrip('\n'), 'old': [], 'new': []}
            current['hunks'].append(hunk)
        elif hunk is not None:
            assert line[:1] in (' ', '+', '-'), repr(line)
            if line[0] in (' ', '-'):
                hunk['old'].append(line[1:])
            if line[0] in (' ', '+'):
                hunk['new'].append(line[1:])
        else:
            raise AssertionError(repr(line))
    return changes


def transform(data, change):
    text = data.decode('utf-8')
    records = []
    for hunk in change['hunks']:
        before = ''.join(hunk['old'])
        after = ''.join(hunk['new'])
        assert before and text.count(before) == 1, (change['path'], hunk['header'], text.count(before))
        offset = text.index(before)
        records.append({'header': hunk['header'], 'exact_occurrences': 1,
                        'offset_before_this_replacement': offset,
                        'old_sha256': digest(before.encode()),
                        'new_sha256': digest(after.encode())})
        text = text.replace(before, after, 1)
    return text.encode('utf-8'), records


def main():
    assert not OUT.exists(), 'refuse overwrite of prepared candidate'
    raw = (OLD / 'candidate.patch').read_bytes()
    assert digest(raw) == OLD_PATCH_SHA
    changes = parse_patch(raw)
    assert len(changes) == 4
    assert {c['path'] for c in changes} == {
        'geometry-core/references.inc',
        'geometry-app/native/reference_sources.inc',
        'tests/test_geo261_load_residual.py',
        'tests/geo261_load_residual_harness.c',
    }
    OUT.mkdir()
    files = []
    all_diff = []
    for change in changes:
        path = change['path']
        s = (HERE / 'snapshots/S' / path).read_bytes()
        h = (HERE / 'snapshots/H' / path).read_bytes()
        candidate_s, s_hunks = transform(s, change)
        assert candidate_s == (OLD / 'candidate' / path).read_bytes(), ('old-candidate-reconstruction', path)
        candidate_h, h_hunks = transform(h, change)
        before_path = OUT / 'base' / path
        after_path = OUT / 'candidate' / path
        before_path.parent.mkdir(parents=True, exist_ok=True)
        after_path.parent.mkdir(parents=True, exist_ok=True)
        before_path.write_bytes(h)
        after_path.write_bytes(candidate_h)
        diff = ''.join(difflib.unified_diff(h.decode().splitlines(keepends=True),
                                          candidate_h.decode().splitlines(keepends=True),
                                          fromfile='a/' + path, tofile='b/' + path))
        all_diff.append(diff)
        # The H-S additions/changes must survive exactly: removing only our
        # uniquely matching replacements from each candidate recovers H and S.
        h_restored = candidate_h.decode()
        for hunk in reversed(change['hunks']):
            before, after = ''.join(hunk['old']), ''.join(hunk['new'])
            assert h_restored.count(after) == 1, ('unique reverse', path, hunk['header'])
            h_restored = h_restored.replace(after, before, 1)
        assert h_restored.encode() == h
        files.append({'path': path, 'H_sha256': digest(h), 'H_bytes': len(h),
                      'candidate_sha256': digest(candidate_h), 'candidate_bytes': len(candidate_h),
                      'S_candidate_sha256': digest(candidate_s),
                      'same_candidate_bytes_as_a440': candidate_h == candidate_s,
                      'exact_hunks': h_hunks, 'reverse_to_original_H': True})
    patch = ''.join(all_diff).encode()
    (OUT / 'candidate.patch').write_bytes(patch)
    test_path = 'tests/test_geo261_load_residual.py'
    old_ast = ast.parse((OUT / 'base' / test_path).read_text())
    new_ast = ast.parse((OUT / 'candidate' / test_path).read_text())
    def methods(tree):
        return sorted(n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_'))
    assert methods(old_ast) == methods(new_ast) and len(methods(new_ast)) == 13
    original_manifest = json.loads((OLD / 'CANDIDATE.json').read_text())
    manifest = {
        'schema': 'geo323-train337-external-candidate/1',
        'base_sha': SHA,
        'old_candidate_base_sha': original_manifest['base_sha'],
        'old_patch_sha256': OLD_PATCH_SHA,
        'patch_sha256': digest(patch),
        'patch_bytes': len(patch),
        'port_method': 'Every original a440 hunk old context must match exactly once in H; no fuzzy matching, no line-number trust. Same replacements also reconstruct a440 original candidate from S byte-for-byte. Reversing only those exact replacements recovers H byte-for-byte.',
        'changed_paths': [f['path'] for f in files],
        'files': files,
        'original_test_methods': methods(old_ast),
        'candidate_test_methods': methods(new_ast),
        'product_mechanism_or_controls_changed_from_a440': False,
        'later_314_318_H_edits_preserved': True,
        'thresholds_expected_ledger_architecture_or_axiom_changed': False,
        'git_worktree_index_or_HEAD_changed': False,
        'applied_to_product': False,
        'compiled': False,
        'tested': False,
        'benchmarked': False,
        'performance_gain_claimed': False,
        'old_baseline_results_reclassified_as_H': False,
        'dynamic_requirements': original_manifest['dynamic_pending'],
        'source_data': 'Exact read-only Git-show S and H snapshots in parent audit directory, captured argv/env/exit/stdout/stderr/hash in STEP2.',
        'porter_sha256': digest(Path(__file__).read_bytes()),
    }
    (OUT / 'CANDIDATE.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'out': str(OUT), 'patch_sha256': digest(patch),
                      'manifest_sha256': digest((OUT / 'CANDIDATE.json').read_bytes()),
                      'files': len(files), 'ast_methods': len(methods(new_ast)),
                      'tests_executed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
