# 下一輪全帳本 v5：僅準備，root 執行

固定新來源 `b6e1e45425f055cd825b259f46ef2c454f3ff13a`；舊來源 `4f4a24d76e816274bfae06868b4dbf31f0860299`。此目錄只有工具與靜態準備，不是帳本驗收通過。

舊輪真終態為 root 1／原 CLI 2，108/123（98 killed、5 equivalent、1 crashed、3 retired、1 blocked），15 未跑。M118 restored-build 與 M119 mkdir 的 ENOSPC 原件由 root 完整 INDEX 封存；本工具固定該 INDEX 的 SHA256，保原部分結果，絕不將它填入新結果。

執行前 root 應確認專職 peer 已接受本目錄 driver hash，舊輪已終態、沒有 cache/source consumer，磁碟有完整新 53 bridge 與編譯暫存空間。`DISK_BUDGET.json` 是 stat 實測與限制，沒有保證尚未執行的完整輪峰值。新 JOB/TEMP 預設都在 workspace；如需改落盤位置，先另存精確窄 diff 並重核，不偷偷沿用本版 hash。

```sh
env -u NODE_OPTIONS -u PYTHONOPTIMIZE python3 -B /tmp/train337-ledger-v5-prep/run_root_full_ledger_v5.py
```

root 仍以既有 c387 最外層錄製器包住上述完整 argv，外層不設新 timeout。driver 自身取原 R3 nonblocking lock、16 MiB stack，所有原 subject timeout／observer／verifier／裁判不改。

只將 baseline 加 67 個非退休 core cache 目錄與同 FS seed 移址；逐檔驗 inode／mode／mtime／bytes／SHA256。68 份舊 sidecar 先精確複製到 JOB 的歷史唯讀角色目錄，後續舊 raw guard 固定讀它們，任由原 CLI 正常決定新 cache hit/miss。原舊 bridge cache、全部原 stdout/stderr 與 Git objects 都留原位。ROOT/SEED ordinary detached checkout 新 F，refs／alternates／稀疏模式前後不變；生成 SVG 跨 FS 時先逐 byte 與 mode/mtime 驗證副本再退休原物化。

新 RESULTS 路徑必不存在。原 `tests/mutate.py` 完整 CLI 不傳 ID；70 core（包括 3 retired 定義判斷）＋53 bridge 全部重判，新 ledger 需 123 rows、原 CLI 0、原 core stream verifier 0、原外部帳本 check 0，並通過原 source clean 與完整 raw 保全。既存可接受 crashed 分類仍由原 CLI 判定；未新增略過、重試、放寬斷言或數值門檻。

交付後收據仍須以 source SHA／帳本 commit／evidence head 分欄；不能把含收據的新 commit 冒作原 execution SHA。
