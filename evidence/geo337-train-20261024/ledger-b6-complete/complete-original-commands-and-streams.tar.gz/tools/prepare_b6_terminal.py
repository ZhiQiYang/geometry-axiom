"""One fixed b6 terminal package, derived from the original fa765 packer. Never run while b6 is live."""
import hashlib,io,json,stat,tarfile
from pathlib import Path

F='b6e1e45425f055cd825b259f46ef2c454f3ff13a'
JOB=Path('/workspace/train337-ledger-b6e1e454-v5')
LAUNCH=Path('/workspace/train337-ledger-b6e1e454-v5-launch')
CACHE=Path('/workspace/train337-ledger-cache-b6e1e454')
TOOLS=Path('/tmp/train337-ledger-v5-prep')
OUT=Path('/workspace/geo337-ledger-b6-terminal-publication')

def sha(body):return hashlib.sha256(body).hexdigest()
def need(ok,why):
    if not ok:raise RuntimeError(why)
def main():
    # Root must also have observed its real outer session terminal. These on-disk
    # guards ensure the launcher/reaper and original observer finished first.
    r=json.loads((JOB/'receipt.json').read_bytes())
    launch=json.loads((LAUNCH/'receipt.json').read_bytes())
    observer=json.loads((JOB/'observer/receipt.json').read_bytes())
    ledger=json.loads((JOB/'mutants_results.json').read_bytes())
    need(r['sourceSHA']==F and r.get('endedUtc')and type(r.get('exit_code'))is int,'root b6 terminal receipt required')
    need(launch['source_sha']==F and type(launch.get('exit_code'))is int and launch['command'].get('ended_epoch')and launch['command']['actual_process_returncode']==launch['exit_code']==r['exit_code'],'true launcher/root terminal exits must agree')
    need(observer['source_sha']==F and observer.get('ended_utc')and observer.get('original_completed')is True and type(observer.get('original_exit'))is int,'original observer truly completed required')
    need(r.get('original_cli_exit')==observer['original_exit'],'original CLI exits must agree, red retained')
    events=[json.loads(line)for line in(JOB/'full-ledger-reaper.jsonl').read_text().splitlines()]
    terminal=[e for e in events if e.get('event')=='完成']
    need(len(terminal)==1 and events[-1]is terminal[0]and type(terminal[0].get('primary_returncode'))is int,'unique original reaper terminal required')
    primary=terminal[0]['primary_returncode'];full=[p for p in r['phases']if p['phase']=='original-full-ledger-through-passive-observer']
    need(len(full)==1 and full[0]['command']['actual_process_returncode']==(primary if primary>=0 else 128-primary),'original observer/reaper outer mapping')
    for name,pin in r['tools_sha256'].items():need(sha(Path(name).read_bytes())==pin,'actual executed tool bytes drifted '+name)
    for name,pin in [('retain_mutation_streams.py','67af8f6768232aa8439a0815a490a8b1076560afd0e40656f6de7edaa009e895'),('verify_observed_core_raw.py','12aa2060d03078b96d81ee6b4d28facdb4d3727fb6ff7d0b4c41271f550ac46b')]:need(sha((TOOLS/name).read_bytes())==pin,'original observer/verifier bytes')
    need(not OUT.exists(),'fresh terminal publication only')
    files=[]
    for base in (JOB,LAUNCH):
        files.extend((base.name+'/'+str(p.relative_to(base)),p)for p in sorted(base.rglob('*'))if p.is_file())
    # Exactly the old fa765 raw/metadata scope: all generated original streams and
    # JSON, including sidecars/attempts; never include ELF, obj, smoke payloads or
    # _bridge-work source/Git/fixtures. Never rewrite an old execution record.
    for folder in sorted(CACHE.iterdir()):
        if not(folder.name.startswith('M')and folder.name[1:].isdigit()or folder.name in('_baseline','_bridge-baseline')):continue
        for p in sorted(folder.rglob('*')):
            if p.is_file()and p.name.endswith(('.stdout','.stderr','.json')):
                files.append(('original-cache-metadata-and-streams/'+str(p.relative_to(CACHE)),p))
    for p in sorted(TOOLS.iterdir()):
        if p.is_file():files.append(('tools/v5/'+p.name,p))
    for name,path in [('capture.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),('reap_children.py','/workspace/geo261-environment/reap_children.py'),('launch_geo337_full_ledger_v5.py','/workspace/launch_geo337_full_ledger_v5.py')]:
        files.append(('tools/'+name,Path(path)))
    files.append(('tools/prepare_b6_terminal.py',Path(__file__).resolve()))
    need(len({name for name,_ in files})==len(files),'unique archive names')
    for _,p in files:need(not p.is_symlink()and stat.S_ISREG(p.lstat().st_mode),'regular original file only '+str(p))
    needed=('receipt.json','request.json','mutants_results.json','full-launch-request.json','full-ledger-reaper.jsonl','observer/request.json','observer/receipt.json','CORE_RAW_MAPPING.json','BRIDGE_RAW_INVENTORY.json','root-ready-identity.json','root-after-identity.json','seed-ready-identity.json','seed-after-identity.json','before-original-raw.json','after-original-raw.json','final-original-raw-original-raw.json','CORE_CACHE_RELOCATION.json','OLD_CORE_METADATA_PATHS.json')
    missing=[name for name in needed if not(JOB/name).is_file()]
    OUT.mkdir();archive=OUT/'complete-original-commands-and-streams.tar.gz';members=[]
    with tarfile.open(archive,'w:gz')as tar:
        for name,p in files:
            before=p.stat();body=p.read_bytes();after=p.stat()
            need((before.st_dev,before.st_ino,before.st_mode,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_size,after.st_mtime_ns),'original changed during collection '+str(p))
            need(not body.startswith(b'\x7fELF'),'ELF must stay outside original raw package')
            info=tar.gettarinfo(str(p),arcname=name);tar.addfile(info,io.BytesIO(body))
            members.append({'path':name,'source':str(p),'bytes':len(body),'sha256':sha(body)})
    with tarfile.open(archive)as tar:
        need(len(tar.getmembers())==len(members),'complete archive count')
        for item in members:
            body=tar.extractfile(item['path']).read();need(len(body)==item['bytes']and sha(body)==item['sha256'],'full byte/hash roundtrip '+item['path'])
            original=Path(item['source']).read_bytes();need(original==body,'terminal original changed after packaging '+item['source'])
    heads=[row['execution']['head']for row in ledger.values()if isinstance(row.get('execution'),dict)]
    index={'schema':'geo337.full-ledger-b6-terminal-originals/1','source_sha':F,'original_cli_exit':observer['original_exit'],'root_wrapper_exit':r['exit_code'],'original_launcher_exit':launch['exit_code'],'completed_utc':r['endedUtc'],'record_count':len(ledger),'expected_record_count':123,'unrun_count':max(0,123-len(ledger)),'verdicts':r.get('verdicts',{}),'root_passed':r.get('passed')is True,'observation_complete':observer.get('observer_complete'),'observer_errors':observer.get('observation_errors',[]),'actual_execution_head_counts':{head:heads.count(head)for head in sorted(set(heads))},'missing_expected_files':missing,'original_phases':[{'phase':p['phase'],'actual_process_returncode':p['command']['actual_process_returncode']}for p in r['phases']],'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'members':members,'packager_sha256':sha(Path(__file__).read_bytes()),'limits':'All generated JOB/launch files and original cache stdout/stderr/JSON are retained. Observer bytes are copied unchanged; its original str outputs are the exact UTF-8 representation hashed by the original judge, not pre-decode OS pipe bytes. ELF/object/smoke payload/source/Git/fixtures are excluded; original sidecar source/compile hashes and execution binary identity remain. No record/head/verdict was rewritten. Prior 4f CLI2/root1/108rows/15unrun remains historical and is referenced by v5 guards, not relabelled by this package.'}
    (OUT/'INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'out':str(OUT),'index_sha256':sha((OUT/'INDEX.json').read_bytes()),'archive_bytes':index['archive_bytes'],'archive_sha256':index['archive_sha256'],'members':len(members),'logical_bytes':sum(x['bytes']for x in members),'actual_cli_exit':index['original_cli_exit'],'actual_root_exit':index['root_wrapper_exit'],'record_count':len(ledger),'unrun_count':index['unrun_count'],'missing_expected_files':missing},ensure_ascii=False))

if __name__=='__main__':main()
