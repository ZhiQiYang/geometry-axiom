import hashlib
import importlib.util
import json
import os
from pathlib import Path

F='b6e1e45425f055cd825b259f46ef2c454f3ff13a'
DRIVER=Path('/tmp/train337-ledger-v5-prep/run_root_full_ledger_v5.py')
OUT=Path('/workspace/train337-ledger-b6e1e454-v5-launch')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='6925b810d24e2902cb6b10de40e8694407e7918e3097e6547d9ec44c3ce054e1'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in ('NODE_OPTIONS','PYTHONOPTIMIZE'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,F)
cap.dump(OUT/'launch-context.json',dict(source_sha=F,driver_sha256=sha(DRIVER),outer_timeout=None,free_bytes={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']},purpose='Root-only complete original 123-row CLI after the preserved old ENOSPC failure; original subject thresholds/timeouts and cache fingerprints unchanged.'))
row,out,err=rec.run(['python3','-B',str(DRIVER)],cwd='/workspace/geometry-axiom',timeout=None,check=False,source_variant='root-owned-full-ledger-external-orchestrator')
cap.dump(OUT/'receipt.json',dict(source_sha=F,driver_sha256=sha(DRIVER),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
