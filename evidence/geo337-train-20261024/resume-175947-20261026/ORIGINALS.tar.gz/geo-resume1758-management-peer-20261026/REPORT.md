# 管理入口核實的獨立對抗審查

結論：接受「工具入口 known、現行 ledger unknown」；沒有阻擋此保守結論的發現。這不是工具 runtime 驗收或全機無資料庫的證明。

已直接核對兩份輸入文件／manifest，以及 repo 七份來源的 bytes、SHA-256、報告所列 Git blob OID。CLI 的 import-snapshot、reconcile、list-ready、list-alerts 確實存在；一般操作先建 Store。Store.__init__ 會 mkdir、O_CREAT|O_EXCL 建 SQLite、建立 tables；目前指定預設 .local 路徑也不存在。不能把在缺失路徑上試跑 reconcile 當純唯讀探針，或把新空 store 當既有排程。

Store 對相同 source/version/canonical snapshot 回 duplicates，event_id 異內容拒絕交易；adapter 先檢查已存在 ledger 才呼叫 Store，並驗證既有 observation 格式、來源時間與完整 SHA。這些是固定來源的靜態核對，未匯入或執行任何操作。

限制：原三檔調查包沒有保存有限路徑及 process argv 搜尋的完整命令／stdout；本審查依任務不重掃全機，因此那些零命中維持原作者觀測，不能升級為本審查獨立證明。Store 也支援任意 .db、.sqlite、.sqlite3 檔名；只查 state.sqlite3 及有限深度不涵蓋所有可能資料位置。原報告已明確承認此界線，故不需要為了保留 unknown 重做搜索。

本審查未使用 Git/API，未 import CLI/Store、建立 DB、改 ledger、執行產品測試、清理或變更分支。若後續取得既有 data-dir/export，須先核其來源、版本水位與穩定 task/source ID，再由主代理依原授權決定匯入；不能由本報告推導新建佇列的授權。
