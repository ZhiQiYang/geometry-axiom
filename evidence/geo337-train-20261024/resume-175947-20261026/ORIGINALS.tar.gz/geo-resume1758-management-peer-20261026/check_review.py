from pathlib import Path
import datetime
import hashlib
import json
import os

base = Path('/tmp/geo-resume1758-management-20261026')
out = Path('/tmp/geo-resume1758-management-peer-20261026')
repo = Path('/workspace/geometry-axiom')
facts = json.loads((base / 'FACTS.json').read_bytes())
manifest = json.loads((base / 'MANIFEST.json').read_bytes())
checks = []

def record(name, ok):
    checks.append({'check': name, 'ok': bool(ok)})

for row in manifest['files']:
    raw = (base / row['path']).read_bytes()
    record('input bytes: ' + row['path'], len(raw) == row['bytes'])
    record('input SHA256: ' + row['path'], hashlib.sha256(raw).hexdigest() == row['sha256'])
for row in facts['sources']:
    raw = (repo / row['path']).read_bytes()
    record('source bytes: ' + row['path'], len(raw) == row['bytes'])
    record('source SHA256: ' + row['path'], hashlib.sha256(raw).hexdigest() == row['sha256'])
    oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    record('reported Git blob OID matches actual bytes: ' + row['path'], oid == row['head_blob_oid'])
record('conservative entry known', facts['tool_entry_verified'] is True)
record('conservative current ledger unknown', facts['current_ledger'] == 'unknown')
record('four operations UNRUN', set(facts['operations'].values()) == {'UNRUN'} and len(facts['operations']) == 4)
record('default .local absent', not os.path.lexists(repo / 'geometry-web/work-manager/.local'))
report = out / 'REPORT.md'
result = {
    'schema': 'geometry-management-entry-independent-static-review/1',
    'reviewed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': 0 if all(x['ok'] for x in checks) else 1,
    'checks': checks,
    'check_count': len(checks),
    'blocking_findings': [x['check'] for x in checks if not x['ok']],
    'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
    'source_report_sha256': hashlib.sha256((base / 'REPORT.md').read_bytes()).hexdigest(),
    'source_manifest_sha256': hashlib.sha256((base / 'MANIFEST.json').read_bytes()).hexdigest(),
    'verdict': '工具入口 known；現行 ledger unknown；不得新建空資料冒充原排程。',
    'static_code_verified': ['CLI 四操作存在且一般操作先 Store', 'Store 建目錄/SQLite/table', '來源快照與 event ID 冪等/衝突約束', 'adapter 缺 ledger 時拒絕且要求原格式/時間/完整SHA'],
    'limitations': ['原調查未封存有限路徑/argv搜尋的完整原流；本審查不重掃，零命中只作原作者觀測。', 'Store 支援任意 .db/.sqlite/.sqlite3；有限 state.sqlite3 搜尋不是全機證明。', 'Git blob OID僅以來源bytes重算；未執行Git重核commit tree。'],
    'cli_or_store_executed': False,
    'database_created_or_modified': False,
    'git_or_api_executed': False,
    'cleanup_executed': False,
    'product_test_executed': False,
}
(out / 'REVIEW.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': result['exit_code'], 'checks': len(checks), 'blocking_findings': result['blocking_findings'], 'review_sha256': hashlib.sha256((out / 'REVIEW.json').read_bytes()).hexdigest()}, ensure_ascii=False))
raise SystemExit(result['exit_code'])
