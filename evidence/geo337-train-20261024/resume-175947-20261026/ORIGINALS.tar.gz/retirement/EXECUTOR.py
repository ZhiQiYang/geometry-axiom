"""Stage C: exact root-authorized retirement, only after full remote preservation."""
from pathlib import Path
import argparse,datetime,gzip,hashlib,importlib.util,json,os,stat,sys
HERE=Path(__file__).parent
COMMON_PIN='d11e9dd829a0a0d53386943556b55bd0f6721eb12301534e875ce485202409b5'
COMMON=HERE/'exact_common.py'
def H(raw):return hashlib.sha256(raw).hexdigest()
if H(COMMON.read_bytes())!=COMMON_PIN:raise RuntimeError('exact common helper pin')
spec=importlib.util.spec_from_file_location('native_tmp_exact_common',COMMON)
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def append_journal(path,row):
    with path.open('a') as stream:
        stream.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno())
    c.syncdir(path.parent)

def unlink_exact(path,state,guard,journal,removed,kind):
    c.exact_file(path,state,guard)
    append_journal(journal,dict(event='intent',path=str(path),kind=kind,original_state=state))
    c.exact_file(path,state,guard)
    path.unlink()
    # Record actual effect before any later fsync can fail; the final absence
    # census remains authoritative if the process dies between these steps.
    removed.append(dict(path=str(path),kind=kind,original_sha256=state['sha256'],original_allocated_bytes=state['allocated']))
    c.syncdir(path.parent)
    append_journal(journal,dict(event='completed',path=str(path),kind=kind,original_sha256=state['sha256']))

def checked_peer(item):
    p=Path(item['path']);raw=p.read_bytes();c.need(H(raw)==item['sha256'],'actual peer pin');data=json.loads(raw)
    c.need(data['exit_code']==0 and not data['blocking_findings'],'actual peer must accept');return data

def preserved_payloads(q,payloads):
    archive_root=c.OWN/'native-TMP-preservation-20261025'
    p=archive_root/'RESULT.json';raw=p.read_bytes();c.need(H(raw)==q['archive_result_sha256'],'exact original archive result pin');ar=json.loads(raw)
    c.need(ar['exit_code']==0 and ar['plan_sha256']==c.PLAN_PIN and ar['all_26_original_payloads_still_present'] and ar['all_full_raw_and_gzip_roundtrips'] and not ar['originals_removed'],'complete archive required')
    ap=checked_peer(q['archive_actual_peer']);c.need(ap['archive_result_sha256']==H(raw) and ap['plan_sha256']==c.PLAN_PIN,'archive actual identity')
    rp=Path(q['remote_result']['path']);rr_raw=rp.read_bytes();c.need(H(rr_raw)==q['remote_result']['sha256'],'remote result pin');rr=json.loads(rr_raw)
    c.need(rr['exit_code']==0 and rr['delivered'] is True and rr['evidence_head']==q['evidence_head'],'remote full delivery required')
    rbpath=rp.parent/'REMOTE_BLOBS.json';rbraw=rbpath.read_bytes();c.need(H(rbraw)==q['remote_blobs_sha256'],'remote complete blob set pin');remote=json.loads(rbraw)
    pp=checked_peer(q['publication_actual_peer']);c.need(pp['evidence_head']==q['evidence_head'] and pp['full_remote_delivery_verified'] is True and pp['archive_result_sha256']==H(raw) and pp['remote_result_sha256']==H(rr_raw) and pp['remote_blobs_sha256']==H(rbraw),'normal publication/remote actual peer identity')
    c.need(len(ar['archives'])==26 and {x['original_path'] for x in ar['archives']}=={x['path'] for x in payloads},'exact archive payload set')
    matches=[]
    for item in payloads:
        a=next(x for x in ar['archives'] if x['original_path']==item['path'])
        c.need(a['original_state']==item['original_state'] and a['raw_bytes']==item['original_state']['bytes'] and a['raw_sha256']==item['original_state']['sha256'] and a['complete_roundtrip'],'archive original-byte identity')
        for member,size,pin in [(a['raw_member'],a['raw_bytes'],a['raw_sha256']),(a['gzip_member'],a['gzip_bytes'],a['gzip_sha256'])]:
            target=archive_root/member;c.need(target.resolve()==target and target.is_relative_to(archive_root),'archive member path')
            body=target.read_bytes();c.need(len(body)==size and H(body)==pin,'local complete preservation bytes')
            found=[r for r in remote if r['bytes']==size and r['sha256']==pin]
            c.need(len(found)==1,'complete original raw/gzip remote blob not verified')
            matches.append(dict(original_path=item['path'],member=member,sha256=pin,remote_blob=found[0]))
        c.need(gzip.decompress((archive_root/a['gzip_member']).read_bytes())==(archive_root/a['raw_member']).read_bytes(),'full archive roundtrip at retirement')
    return matches

def git_metadata_snapshot(indexes):
    # Index removal is last. Afterwards no Git command may recreate it.
    snapshots={}
    for item in indexes:
        gd=Path(item['effective_gitdir']);paths=[gd/'HEAD',gd/'config',gd/'packed-refs']
        paths += list((gd/'refs').rglob('*')) if (gd/'refs').exists() else []
        vals={}
        for path in paths:
            if not path.exists():continue
            s=path.lstat();c.need(not path.is_symlink(),'protected Git metadata symlink')
            if stat.S_ISREG(s.st_mode):vals[str(path)]=dict(bytes=s.st_size,sha256=H(c.original_bytes(path)),mode=s.st_mode,device=s.st_dev,inode=s.st_ino)
        snapshots[item['root']]=vals
    return snapshots

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--request',type=Path,required=True);parser.add_argument('--request-sha256',required=True);parser.add_argument('--execute-retirement',action='store_true');args=parser.parse_args()
    c.need(not sys.flags.optimize,'PYTHONOPTIMIZE forbidden')
    raw=args.request.read_bytes();c.need(H(raw)==args.request_sha256,'root request pin');q=json.loads(raw)
    plan,source,indexes,elfs,chrome=c.read_plan()
    if not args.execute_retirement:
        print(json.dumps(dict(executed=False,stage='retirement-after-remote-preservation',plan_sha256=c.PLAN_PIN)));return 0
    c.bind_request(q,'independent_retirement_executor_peer',Path(__file__))
    for key in ('root_complete_remote_preservation_verified','root_exact_retirement_authorized'):c.need(q[key] is True,'missing root lease: '+key)
    out=Path(q['out']);c.need(out==c.OWN/'native-TMP-retirement-20261025' and out.resolve()==out and not out.exists(),'exact fresh approved SHM retirement output')
    c.need(c.OWN.is_dir() and not c.OWN.is_symlink(),'existing exact OWN root')
    cap=c.load(c.original.CAP,c.original.CAP_PIN,'original_capture');guard=c.load(c.original.GUARD,c.original.GUARD_PIN,'original_consumer')
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
    index_payloads=[dict(path=x['effective_index'],original_state=x['original_state']) for x in indexes]
    payloads=index_payloads+elfs
    cache_files=[dict(path=str(Path(group['path'])/item['relative']),original_state=item['original_state']) for group in chrome for item in group['files']]
    all_leaves=source+cache_files+elfs+index_payloads
    c.need(len(all_leaves)==3156,'exact total retirement leaf count')
    paths=c.group_paths(source,indexes,elfs,chrome)
    with c.leases():
        remote_matches=preserved_payloads(q,payloads)
        free=os.statvfs(c.OWN);needed=64*1024**2+8*1024**2
        c.need(free.f_bavail*free.f_frsize>=needed and c.owned_allocated()+needed<=2*1024**3,'SHM journal/receipt preservation budget')
        out.mkdir(mode=0o700);c.syncdir(out.parent);c.syncdir(out);rec=cap.Recorder(out/'commands',env,q['task_sha'])
        result=dict(schema='native-TMP-exact-retirement/1',exit_code=1,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),plan_sha256=c.PLAN_PIN,request_sha256=args.request_sha256,executor_sha256=H(Path(__file__).read_bytes()),common_sha256=COMMON_PIN,evidence_head=q['evidence_head'],formal_executed=False,removed=[],removed_empty_cache_directories=[],actual_absent_paths=[],original_receipts_fixtures_Git_objects_modified=False,commands=rec.rows)
        journal=out/'JOURNAL.jsonl';before_free=os.statvfs('/tmp');result['TMP_free_before']=before_free.f_bavail*before_free.f_frsize
        try:
            (out/'REQUEST.json').write_bytes(raw);(out/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes());(out/'COMMON.py').write_bytes(COMMON.read_bytes());(out/'PLAN.json').write_bytes(c.PLAN.read_bytes());c.dump(out/'REMOTE_PAYLOAD_BINDINGS.json',remote_matches)
            c.consumers(out,'before',guard,paths)
            initial=c.source_state(rec)
            for item in indexes:c.private_index_state(rec,item)
            protected=git_metadata_snapshot(indexes);c.dump(out/'PROTECTED_GIT_METADATA_BEFORE.json',protected)
            c.chrome_namespace(chrome)
            cache_root_identity={group['path']:(Path(group['path']).lstat().st_dev,Path(group['path']).lstat().st_ino,Path(group['path']).lstat().st_mode) for group in chrome}
            for item in all_leaves:c.exact_file(Path(item['path']),item['original_state'],guard)
            # All scopes pass before the first unlink. Original evidence and the
            # complete remote payload bindings remain outside removal scope.
            for group_number,group in enumerate([source,cache_files,elfs]):
                c.consumers(out,'before-group-'+str(group_number),guard,paths)
                kind=('pure-product-source','regenerable-Chrome-cache','remote-preserved-old-ELF')[group_number]
                for item in group:unlink_exact(Path(item['path']),item['original_state'],guard,journal,result['removed'],kind)
                c.save_mutable(out/'RESULT.json',result)
            for group in chrome:
                root=Path(group['path'])
                for item in sorted(group['directories'],key=lambda x:len(Path(x['relative']).parts),reverse=True):
                    path=root/item['relative'];s=path.lstat();c.need(stat.S_ISDIR(s.st_mode) and not path.is_symlink() and (s.st_dev,s.st_ino)==(item['device'],item['inode']),'exact cache directory identity')
                    append_journal(journal,dict(event='empty-directory-intent',path=str(path)));path.rmdir();result['removed_empty_cache_directories'].append(str(path));c.syncdir(path.parent)
                current=root.lstat();c.need((current.st_dev,current.st_ino,current.st_mode)==cache_root_identity[str(root)] and not root.is_symlink(),'original same-run cache root identity')
                append_journal(journal,dict(event='empty-cache-root-intent',path=str(root)));root.rmdir();result['removed_empty_cache_directories'].append(str(root));c.syncdir(root.parent)
            after_source=c.source_state(rec,removed=[x['path'] for x in source])
            c.need(all(after_source[k]['head']==v['head'] and after_source[k]['refs_sha256']==v['refs_sha256'] for k,v in initial.items()),'source HEAD/refs changed')
            c.dump(out/'SOURCE_STATUS_AFTER_EXACT_D.json',after_source)
            for item in indexes:c.private_index_state(rec,item)
            c.need(git_metadata_snapshot(indexes)==protected,'protected private Git metadata before index retirement')
            c.consumers(out,'before-indexes',guard,paths)
            for item in index_payloads:unlink_exact(Path(item['path']),item['original_state'],guard,journal,result['removed'],'remote-preserved-private-index')
            c.need(git_metadata_snapshot(indexes)==protected,'protected Git metadata after index retirement')
            c.consumers(out,'after',guard,paths)
            c.need(all(not os.path.lexists(x['path']) for x in all_leaves),'exact planned leaves absent')
            c.need(len(result['removed'])==3156,'actual removed count')
            c.dump(out/'INACTIVE_REQUIRE_REBUILD_AND_INDEX_RESTORE.json',dict(source_roots=sorted(initial),index_roots=[x['root'] for x in indexes],old_ELF_cache_roots=sorted({str(Path(x['path']).parent) for x in elfs}),remote_evidence_head=q['evidence_head'],no_future_gate_reuse=True,restore_bytes_from_verified_remote_archive=True,inode_ctime_not_reproducible=True,original_Git_objects_refs_fixtures_retained=True))
            result['exit_code']=0
        except BaseException as error:
            result['error']=repr(error);raise
        finally:
            result['actual_absent_paths']=[x['path'] for x in all_leaves if not os.path.lexists(x['path'])]
            result['partial_failure_no_rollback']=result['exit_code']!=0
            result['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            after_free=os.statvfs('/tmp');result['TMP_free_after']=after_free.f_bavail*after_free.f_frsize;result['actual_TMP_net_free_change']=result['TMP_free_after']-result['TMP_free_before']
            result['observed_native_128MiB_free_gate']=result['TMP_free_after']>=134217728
            result['native_not_started_and_requires_fresh_original_admission']=True
            c.save_mutable(out/'RESULT.json',result);c.syncdir(out);c.syncdir(out.parent)
        print(json.dumps({k:v for k,v in result.items() if k not in ('commands','removed','actual_absent_paths','removed_empty_cache_directories')}))
    return 0

if __name__=='__main__':raise SystemExit(main())
