"""Resolve only the peer's two-line unittest-name parser finding; never rerun gates."""
import ast
import datetime
import hashlib
import json
import re
from pathlib import Path

OUT = Path('/tmp/geo-resume1758-reader-actual-peer-20261026')
ROOT = Path('/dev/shm/geometry-axiom-geo337-20261025')
RAW = ROOT / 'reader-F-175947-20261026/reader-unit/subcommands/000006/stderr.bin'
SOURCE = ROOT / 'a6-architecture-source-20261026/tests/test_axiom_reader.py'
review_path = OUT / 'REVIEW.json'
initial = review_path.read_bytes()
review = json.loads(initial)
assert review['exit_code'] == 1
assert review['blocking_findings'] == ['unit all51 actual names']
backup = OUT / 'REVIEW.initial-parser.json'
assert not backup.exists()
backup.write_bytes(initial)
raw = RAW.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'bf6d35412da077987e8a05780b8ad94d89019650ed1cde35ddf6889735008a72'
text = raw.decode()
tree = ast.parse(SOURCE.read_text())
methods = {n.name for c in tree.body if isinstance(c, ast.ClassDef) and c.name == 'CanonicalReader'
           for n in c.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
printed = re.findall(r'^(test_\w+) \(__main__\.CanonicalReader\.(test_\w+)\)(?= \.\.\.|\n)', text, re.M)
assert len(printed) == len(methods) == 51
assert {a for a, b in printed} == methods
assert all(a == b for a, b in printed)
assert len({a for a, b in printed}) == 51
summary = re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK\n\Z', text)
assert summary and summary[1] == '51'
assert not re.search(r'\.\.\. skipped|FAILED \(|OK \(', text)
affected = ['test_review_merge_rejects_conflicts_inside_one_backup', 'test_review_merge_takes_an_exact_repeat_only_once']
snippets = {}
for name in affected:
    start = text.index(name + ' (__main__.CanonicalReader.' + name + ')\n')
    end = text.find('\ntest_', start + 1)
    fragment = text[start:end if end >= 0 else len(text)]
    assert re.search(r'\.\.\. ok\n?\Z', fragment)
    snippets[name] = fragment
correction = {
    'scope': 'peer parser only; original stderr, source, assertions and gates unchanged',
    'initial_review_sha256': hashlib.sha256(initial).hexdigest(),
    'initial_review_exit': 1,
    'initial_peer_finding': 'unit all51 actual names',
    'cause': 'Two unittest cases have docstrings: verbose output places the description and ... ok on the next line.',
    'affected_original_text': snippets,
    'actual_test_names': sorted(a for a, b in printed),
    'actual_test_count': 51,
    'method_AST_count': 51,
    'unique_names': 51,
    'product_or_test_changed': False,
    'formal_gates_rerun': False,
    'raw_stderr_sha256': hashlib.sha256(raw).hexdigest(),
    'targeted_parser_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(OUT / 'PARSER_CORRECTION.json').write_text(json.dumps(correction, ensure_ascii=False, indent=2) + '\n')
review['exit_code'] = 0
review['blocking_findings'] = []
review['reviewed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
review['parser_correction'] = {key: correction[key] for key in ('initial_review_sha256', 'initial_review_exit', 'cause', 'actual_test_count', 'product_or_test_changed', 'formal_gates_rerun', 'targeted_parser_script_sha256')}
review['parser_correction']['report_sha256'] = hashlib.sha256((OUT / 'PARSER_CORRECTION.json').read_bytes()).hexdigest()
review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': 0, 'review_sha256': hashlib.sha256(review_path.read_bytes()).hexdigest(), 'actual_test_count': 51, 'original_gate_exits': review['all_three_actual_exits'], 'initial_peer_result_preserved': str(backup)}, ensure_ascii=False))
