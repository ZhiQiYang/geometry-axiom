from pathlib import Path
import ast
import datetime
import hashlib
import json
import re

ROOT=Path('/dev/shm/geometry-axiom-geo337-20261025/reader-F-175947-20261026')
OUT=Path('/tmp/geo-resume1758-reader-actual-peer-20261026')
HOST=Path('/tmp/geo-resume1758-root-20261026/READER_HOST_FINAL.json')
STATIC=Path('/tmp/geo-resume1758-reader-executor-peer-20261026/REVIEW.json')
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
EXEC_PIN='509fbc7bcf366d8e78a782e48dbbacb5472b8f09518f0da884267343881477f8'
SRC=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026')
REAPER='/workspace/geo261-environment/reap_children.py'
checks=0;failures=[];stream_index=[];command_count=0
def h(raw):return hashlib.sha256(raw).hexdigest()
def ck(label,ok):
    global checks
    checks+=1
    if not ok:failures.append(label)
def read_json(p):return json.loads(Path(p).read_bytes())
def hash_file(p):return h(Path(p).read_bytes())
def capture_rows(base):
    global command_count
    rows=read_json(base/'subcommands.json')
    actual_dirs={p for p in (base/'subcommands').iterdir() if p.is_dir()}
    ck('capture exact directory set '+str(base),actual_dirs=={Path(x['directory']) for x in rows})
    bydir={}
    for row in rows:
        command_count+=1;d=Path(row['directory'])
        ck('capture path confinement '+str(d),d.is_relative_to(ROOT) and d.resolve()==d)
        stored=read_json(d/'result.json');ck('result matches index '+str(d),stored==row)
        request=read_json(d/'request.json')
        for key in ('command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','stdin_provided','stdin_sha256','directory'):
            ck('request matches final '+str(d)+' '+key,request[key]==row[key])
        ck('request pending, not fabricated final '+str(d),request['actual_process_returncode'] is None)
        for kind in ('stdin','stdout','stderr'):
            p=d/(kind+'.bin');b=p.read_bytes()
            ck('original stream hash '+str(p),h(b)==row[kind+'_sha256'])
            if kind!='stdin':ck('original stream size '+str(p),len(b)==row[kind+'_bytes'])
            stream_index.append({'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':h(b)})
        ck('actual command terminal '+str(d),row['actual_process_returncode']==0 and row['timeout_expired'] is False and row['ended_epoch']>=row['started_epoch'])
        ck('F acceptance binding '+str(d),row['source_sha']==F and row['acceptance_sha']==F)
        bydir[str(d)]=row
    return rows,bydir

r=read_json(ROOT/'RESULT.json')
ck('fixed tested F',r['source_sha']==F and r['source']==str(SRC))
ck('actual root complete',r['exit_code']==0 and r['all_three_passed'] is True and r['protected_inputs_unchanged'] is True and not r['errors'])
ck('executor accepted bytes',hash_file(ROOT/'EXECUTOR.py')==EXEC_PIN)
static=read_json(STATIC)
ck('independent static peer pin',hash_file(STATIC)=='602263373a15c24044aa3d5c8ef97f7d19c1dbb2a1a0c816809c0f768f938c63' and static['exit_code']==0 and static['executor_sha256']==EXEC_PIN)
ck('plan manifest pin',hash_file(ROOT/'plan-MANIFEST.json')==r['plan_sha256']=='5463ea4c4c4364acb9a51b18eec68d2921318acb8e220b3d29636dde755ecf64')
for item in read_json(ROOT/'plan-MANIFEST.json')['files']:
    b=(ROOT/('plan-'+item['path'])).read_bytes();ck('frozen plan '+item['path'],len(b)==item['bytes'] and h(b)==item['sha256'])
for path,pin in r['tool_sha256'].items():ck('saved original tool '+path,hash_file(ROOT/'tool-sources'/Path(path).name)==pin)
root_rows,root_by=capture_rows(ROOT)
expected_names=['reader-generate','reader-check','reader-unit']
ck('exact original three stages',[x['stage'] for x in r['stages']]==expected_names)
stages=[];previous_end=None
for entry in r['stages']:
    name=entry['stage'];base=ROOT/name;inner=read_json(base/'receipt.json')
    rows,by=capture_rows(base);outer=entry['outer_result'];original=inner['original_result']
    ck(name+' outer row identity',root_by[outer['directory']]==outer)
    ck(name+' inner original row identity',by[original['directory']]==original==entry['original_result'])
    ck(name+' original source/stage',inner['sha']==F and inner['root']==str(SRC) and inner['stage']==name)
    ck(name+' real exits/passed',entry['actual_exit']==entry['inner_actual_exit']==inner['actual_exit_code']==outer['actual_process_returncode']==original['actual_process_returncode']==0 and entry['passed'] is True and inner['passed'] is True and not inner['errors'])
    py=inner['versions'][0]['result']['command'][0]
    expected_command=[py,'-B',str(SRC/('tests/test_axiom_reader.py' if name=='reader-unit' else 'geometry-guide/sync_axiom_reader.py'))]
    if name=='reader-check':expected_command.append('--check')
    ck(name+' unchanged original command',inner['original_command']==expected_command and original['command']==[py,'-B',REAPER,*expected_command])
    ck(name+' actual timeout None',entry['actual_outer_timeout_seconds'] is None and inner['outer_timeout_seconds'] is None and outer['timeout_expired'] is False and original['timeout_expired'] is False)
    ck(name+' raw guard source states',entry['source_before']==entry['source_after']==r['source_before'])
    for guard in inner['guards']:
        ck(name+' original source guard '+guard['label'],guard['head'].strip()==F and guard['status']==guard['cached']=='' and all(guard[x+'_exit']==0 for x in ('head','status','cached')))
    reapers={}
    for label,path in [('outer',Path(entry['outer_reaper_log'])),('inner',base/'reaper.jsonl')]:
        raw=path.read_bytes();events=[json.loads(line) for line in raw.splitlines()]
        ck(name+' '+label+' reaper configured',events[0]['event']=='啟用子程序回收' and events[0]['pr_get_child_subreaper']==1)
        ck(name+' '+label+' reaper terminal',events[-1]['event']=='完成' and events[-1]['primary_returncode']==0)
        primary=[x for x in events if x['event']=='回收' and x['primary']]
        ck(name+' '+label+' true primary0',len(primary)==1 and primary[0]['returncode']==0)
        ck(name+' '+label+' reaper final binding',events[-1]==entry[label+'_reaper_final'])
        reapers[label]={'sha256':h(raw),'primary_exit':events[-1]['primary_returncode'],'events':len(events),'primary_elapsed_seconds':primary[0]['utc_epoch']-events[0]['utc_epoch']}
    versions=[]
    for v in inner['versions']:
        actual=by[v['result']['directory']]
        ck(name+' version exact receipt',actual==v['result'] and Path(actual['directory'],'stdout.bin').read_bytes().decode()==v['stdout'] and actual['actual_process_returncode']==0)
        versions.append(v['stdout'].strip())
    ck(name+' expected environment versions',versions==['Python 3.12.14','v24.19.0'])
    ck(name+' within root actual interval',datetime.datetime.fromisoformat(r['started_utc']).timestamp()<=outer['started_epoch']<=outer['ended_epoch']<=datetime.datetime.fromisoformat(r['ended_utc']).timestamp())
    if previous_end is not None:ck(name+' sequential after previous',outer['started_epoch']>=previous_end)
    previous_end=outer['ended_epoch']
    row={'stage':name,'source_sha':F,'outer_exit':outer['actual_process_returncode'],'inner_exit':original['actual_process_returncode'],'outer_seconds':outer['ended_epoch']-outer['started_epoch'],'inner_seconds':original['ended_epoch']-original['started_epoch'],'actual_outer_timeout_seconds':None,'original_command':expected_command,'reapers':reapers,'versions':versions,'receipt_sha256':hash_file(base/'receipt.json')}
    if name!='reader-unit':
        value=json.loads(Path(original['directory'],'stdout.bin').read_bytes())
        for key in ('five_asserts','independent_ssot','source_sections','counts_single_source','geo120','search','color_tokens'):
            ck(name+' '+key,value[key]=='pass')
        ck(name+' clause/block/witness counts',value['clauses']==207 and value['blocks']==1261 and value['witness']==31)
        row['validation_report']=value
    else:
        text=Path(original['directory'],'stderr.bin').read_text()
        m=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK\n\Z',text)
        ck('unit real OK summary',m is not None)
        printed=re.findall(r'^(test_\w+) \(__main__\.CanonicalReader\.(test_\w+)\) \.\.\.',text,re.M)
        tree=ast.parse((SRC/'tests/test_axiom_reader.py').read_text())
        methods={n.name for c in tree.body if isinstance(c,ast.ClassDef) and c.name=='CanonicalReader' for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
        ck('unit all51 actual names',len(printed)==51 and len(methods)==51 and {x[0] for x in printed}==methods and all(a==b for a,b in printed))
        ck('unit51 no skip/fail summary',m is not None and int(m[1])==51 and not re.search(r'\.\.\. skipped|FAILED \(|OK \(',text))
        row.update(unit_tests=int(m[1]) if m else None,unittest_reported_seconds=float(m[2]) if m else None,unit_skips=0,unit_raw_stderr_sha256=h(text.encode()),unit_stderr_bytes=original['stderr_bytes'],resource_warning_count=text.count('ResourceWarning: unclosed file'))
    stages.append(row)

listed={}
for line in (ROOT/'plan-CLOSURE.tsv').read_text().splitlines()[1:]:
    name,mode,oid,size=line.split('\t');listed[name]=(oid,int(size))
ck('before/after closure unchanged',r['closure_before']==r['closure_after'])
ck('full212 expected closure',len(r['closure_before'])==212 and {x['path']:(x['git_blob'],x['bytes']) for x in r['closure_before']}==listed)
ck('full closure bytes',sum(x['bytes'] for x in r['closure_before'])==8628746)
fixture_names={
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas',
 'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
 'tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene',
 'geometry-web/docs/evidence/issue48-34a6222-20261005/archives/1280-full.gcanvas'}
ck('exact original fivefixtures',set(r['fixtures_before'])==fixture_names)
for field in ('source','fixtures','publisher','old_workspace'):
    ck(field+' before/after exact preservation',r[field+'_before']==r[field+'_after'])
ck('source F clean before/after',r['source_before']['head']==F and r['source_before']['status']==r['source_before']['cached']=='')
ck('canonical original bytes unchanged',r['canonical_before']['sha256']==r['canonical_after']['sha256']=='768be0fe5aa1b4e06a0823492030749a08965dee4a9eeabf89b0cd2ee0e6a342' and r['canonical_before']['bytes']==r['canonical_after']['bytes']==7024570)
ck('each canonical stage stays same',all(e['canonical_after_sha256']==r['canonical_before']['sha256'] for e in r['stages']))
cap=r['capacity'];ck('original capacity admission',cap['original_ceiling']==2147483648 and cap['additional_bound_bytes']==33554432 and cap['shared_allocated_before']+cap['additional_bound_bytes']<=cap['original_ceiling'] and cap['actual_mount_free_before']>=cap['additional_bound_bytes'])
host=read_json(HOST);ck('host true last chunk exit0',host['exit_code']==0)
last=json.loads(host['output'].splitlines()[-1]);ck('host summary matches packet',last['source_sha']==F and last['output']==str(ROOT) and last['exit_code']==0 and last['all_three_passed'] is True and last['protected_inputs_unchanged'] is True)
result={'schema':'new-F-reader-three-gates-independent-actual-review/1','reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0 if not failures else 1,'blocking_findings':failures,'check_count':checks,'source_sha':F,'source_result_sha256':hash_file(ROOT/'RESULT.json'),'executor_sha256':hash_file(ROOT/'EXECUTOR.py'),'original_commands_verified':command_count,'original_streams_verified':len(stream_index),'stream_index_sha256':h(json.dumps(stream_index,sort_keys=True,separators=(',',':')).encode()),'stages':stages,'all_three_actual_exits':[x['inner_exit'] for x in stages],'closure_count':212,'closure_bytes':8628746,'fivefixtures_preserved':r['fixtures_before']==r['fixtures_after'],'source_index_sha256':r['source_before']['index']['sha256'],'publisher_head':r['publisher_before']['head'],'publisher_index_sha256':r['publisher_before']['index']['sha256'],'old_workspace_head':r['old_workspace_before']['head'],'old_workspace_index_sha256':r['old_workspace_before']['index']['sha256'],'canonical_bytes_sha256':r['canonical_before']['sha256'],'canonical_inode_before':r['canonical_before']['inode'],'canonical_inode_after':r['canonical_after']['inode'],'capacity_admission':cap,'capacity_actual_peak_measured':False,'host_final_chunk_sha256':hash_file(HOST),'host_raw_is_final_chunk_only':True,'only_reader_gates_accepted':True,'native_or_browser_accepted':False,'old_F9_relabelled':False,'audit_reran_reader_Node_Git_API':False,'remaining_delivery_requirement':'將本輪完整SHM原件正常推送並核遠端；本審核不冒稱已發布或全專案完成。'}
(OUT/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'HOST_FINAL_CHUNK.json').write_bytes(HOST.read_bytes())
print(json.dumps({'exit_code':result['exit_code'],'checks':checks,'blocking_findings':failures,'commands':command_count,'streams':len(stream_index),'source_result_sha256':result['source_result_sha256'],'review_sha256':hash_file(OUT/'REVIEW.json'),'stage_summary':[{k:x.get(k) for k in ('stage','outer_exit','inner_exit','outer_seconds','inner_seconds','unit_tests','unit_skips','resource_warning_count')} for x in stages]},ensure_ascii=False))
raise SystemExit(result['exit_code'])
