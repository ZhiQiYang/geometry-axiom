# 新 F 閱讀器三項原件獨立核收

來源 `cbf0fb621888596aa14ad5f2349b503e23b1b72d`。本輪獨立核收通過，只接受閱讀器三項，不接受 native、browser 或其他專項，不拿 F9 收據替代新 F。

| 正式項 | 原命令（固定來源內） | inner exit／秒 | outer exit／秒 |
| --- | --- | --- | --- |
| generate | `python3 -B geometry-guide/sync_axiom_reader.py` | 0／4.566017 | 0／4.836538 |
| check | `python3 -B geometry-guide/sync_axiom_reader.py --check` | 0／1.664875 | 0／1.942518 |
| unit | `python3 -B tests/test_axiom_reader.py` | 0／163.323779 | 0／163.605904 |

原執行器起訖為 2026-10-26 18:34:20.641815 至 18:37:12.663976 UTC。三個 stage 皆順序完成；inner、outer reaper 的 primary 與 final exit 均為 0。實際 outer timeout 是 `None`，沒有宣稱 300／1200 秒守門。Python 3.12.14、Node v24.19.0 的原版本收據均 exit 0。

核過 92 筆捕捉命令、276 份 stdin／stdout／stderr 原流的長度與 SHA256，原件與 result/request 相符。主代理 session 89082 的 host exit 0 來自 `HOST_FINAL_CHUNK.json`，它只包含最後一段工具輸出；完整正式項輸出來自各 stage 的捕捉原件。

unit 原 stderr 記錄 `Ran 51 tests in 163.148s`、`OK`，無 skip。51 個實際名稱與來源 AST 的 51 個方法逐一相符。原 stderr 保留 173 個 `ResourceWarning: unclosed file`；未當成零警告。首次 peer 名稱解析漏算兩個含 docstring 的換行案例，原結果保存在 `REVIEW.initial-parser.json`；窄幅修正與原行文在 `PARSER_CORRECTION.json`，沒有修改產品、測試或重新執行 gate。

212 葉、8,628,746 bytes 的閱讀器 closure 與先前獨立固定的 F manifest 一致，前後完整相同。selected3763 checkout 的完整性只涵蓋閱讀器所需來源，不外推 native6997。原五份 fixture、來源／publisher／舊 workspace 的 HEAD、index 與 dirty 狀態前後保全。生成器正常替換 canonical 的 inode，但 7,024,570 bytes 與 SHA256 前後一致，沒有擅自還原或把差異冒稱 F。

啟動時兩 OWN 合計 2,062,921,728 bytes，加本輪 33,554,432 bytes 預算為 2,096,476,160 bytes，低於原 2 GiB 門檻 2,147,483,648 bytes；實際掛載可用 15,808,958,464 bytes。原件沒有實測峰值，本審核不補造峰值或擴張為 native／browser 容量已足夠。

本輪核收未執行 reader、Node、Git、API 或其他正式測試。完整 SHM 原件的持久化、推送及遠端核對由主代理接續；本報告不宣稱已完成遠端交付。
