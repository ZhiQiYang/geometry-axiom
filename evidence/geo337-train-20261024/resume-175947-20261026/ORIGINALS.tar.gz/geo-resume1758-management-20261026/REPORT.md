# 既有 Geometry 工作管理入口核實

結論：**工具入口已核實；目前應接續的私有 ledger 路徑仍 unknown。** 不能把前者說成工具不存在，也不能因找得到 CLI 就建立另一份空佇列。

本輪只讀 `/workspace/geometry-axiom` 的根及工具 AGENTS、README、CLI、Store、adapter 與 schema；根 HEAD 為 `70d00309d7985db722c339c77331c436d26a7ab1`。指定工具範圍 tracked status 為空。這是此現有 checkout 的程式版本核對，不宣稱已核實最新 main／候選 F 的工具版本。

## 已知入口及原契約

- 入口：`geometry-web/work-manager/cli.py`，非新工具或臨時替代佇列。
- 該目錄 AGENTS 明文：「本目錄是 Geometry 工作管理工具，不是 Geometry 產品介面或第二份公理閱讀器。」SQLite、匯入快照、owner thread、原始事件預設放私有 `.local/`，不得提交或 force-add。
- CLI 實作 `import-snapshot`、`record-assignment`、`record-result`、`reconcile`、`list-ready [--mode read_only|write]`、`list-alerts`、`inspect`、`coverage`、`export`、`restore` 與 loopback `serve`。
- README 指定 snapshot 的 `schema_version`、`source.id/kind/version/as_of/status`（可含完整 `source_sha`）、永久 `event_id`、`task_id`、遞增 stream version、含時區 `occurred_at`，及 task/result 的完整 `head_sha`。`store.py` 校驗 SHA，交易內驗證整份投影。
- `store.py:956` 對相同 source/version/canonical snapshot 回 duplicates，不新增資料；`976–980` 拒絕相同 event_id 不同內容。重送不可換 ID 製造新進度。
- `adapter.py` 接受 `geometry-github-read-observation/1`、`read_only_connector_snapshot`，含 repository、observed_at、main、counts、issues、PRs、exact_head_ci；沿用既有工作 ID，局部來源不會刷新未讀項，PR metadata 不覆寫獨立 review／批准／owner。
- `reconcile`、`list-ready`、`list-alerts` 都使用同一 Store projection。匯入不是授權；工具不能派 agent、寫 GitHub、批准、merge 或發布。

## 尚未核實的實際資料入口

1. `/workspace/geometry-axiom/geometry-web/work-manager/.local` 不存在。
2. 在 `/workspace` 與 `/tmp` 各自以有限深度核對 `*/state.sqlite3`、`*/*/state.sqlite3`、`*/.local/state.sqlite3` 及 `*/geometry-web/work-manager/.local/state.sqlite3`，無命中。
3. 在可見 `/dev/shm` 以有限深度核對 `*/state.sqlite3`、`*/*/state.sqlite3`、`*/geometry-web/work-manager/.local/state.sqlite3` 與 `*/publisher-source/geometry-web/work-manager/.local/state.sqlite3`，無命中。這次為只讀核對，沒有更動掛載、配額或檔案。
4. `/proc` 的真正 argv 路徑項目，沒有以 `work-manager/cli.py`、`work-manager/server.py` 或 `work-manager/adapter.py` 結尾的執行者。首次寬字串尋找誤命中本核對腳本本身的 shell command；修正成單一實際 argv 路徑比對後為空，未把那些自命中算成管理器。

以上是已列明的有限範圍，**不是全機不存在 ledger 的證明**，也未聲稱其他主機或未披露路徑沒有資料。不查閱 secrets，不新建 store，不用 synthetic demo 代替真隊列。

## 為何尚未執行四項操作

`cli.py` 每個非 serve 指令都先呼叫 `Store(args.data_dir)`。`store.py:775–803` 會建立 data-dir、以 O_CREAT|O_EXCL 建立 SQLite、初始化 tables 並設定私有權限；`reconcile` 不是可以對缺失資料路徑安全試跑的唯讀探針。adapter 在 DB 不存在時也明文拒絕並要求先初始化。

因此，匯入觀測、`reconcile`、`list-ready`、`list-alerts` 本輪均 **UNRUN**。無匯入、無資料庫建立、無來源時間更新、無新派工／完成狀態、無產品測試或分支更動。

可解除條件是核實現行私有 ledger／export 的路徑與身分，以及其既有 source/task ID、原始版本水位；若只取得 export，是否恢復另一私有目錄須由主代理按既有授權判定，不能自行用空 store 取代。得到原 ledger 後才可按既有格式將真正已讀來源的時間與完整 SHA 冪等匯入，再跑三項查詢；失敗或缺失來源應保留舊資料並標 error／unknown，不刷新為 live。

本輪審查輸出總量小於 100 KB；容量第一次觀測 `/tmp` 可用 10,588,160 bytes、`/workspace` 可用 4,382,720 bytes。這不是執行 native/browser 的准入證據。
