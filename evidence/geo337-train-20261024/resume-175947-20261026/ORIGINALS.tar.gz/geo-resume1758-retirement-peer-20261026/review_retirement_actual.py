from pathlib import Path
import collections,datetime,hashlib,json,os,stat
O=Path('/dev/shm/geometry-axiom-geo337-20261025');R=O/'approved-retirement-root-175947-20261026';I=O/'native-TMP-retirement-20261025';B=Path('/tmp/geo337-native-TMP-combined-preservation-20261025');P=Path('/tmp/geo-resume1758-retirement-peer-20261026')
def H(b):return hashlib.sha256(b).hexdigest()
def h(p):return H(Path(p).read_bytes())
def load(p):return json.loads(Path(p).read_bytes())
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd,'rb') as f:return f.read()
checks=0;fails=[]
def ck(n,v):
 global checks
 checks+=1
 if not v:fails.append(n)
rr=load(R/'RESULT.json');r=load(I/'RESULT.json');request=load(I/'REQUEST.json')
ck('root_exit',rr['exit_code']==0);ck('inner_exit',r['exit_code']==0 and not r['partial_failure_no_rollback'])
ck('root_result_pin',h(R/'RESULT.json')=='dba05a85a7896a1e326a243d3d80c865f9b074f170ec2804df5b1110ea9ea84c')
ck('inner_result_pin',h(I/'RESULT.json')=='075534e2c72f827b30fbe3d5d7da65398a371183fa263df12180ae5d8949aa4e')
ck('new_request_pin',h(I/'REQUEST.json')==h(O/'native-TMP-retirement-APPROVED_REQUEST-175947-20261026.json')==rr['request_sha256']==r['request_sha256']=='2ff427e9b9c5f075351e9be26ce6fc3121f754d8a8ed2af80acf7904accce6d6')
ck('old_request_unchanged',h(O/'native-TMP-retirement-ROOT_REQUEST-20261026.json')=='66cc070dfa595b38182629c9e6e9dfcb97db0aa1791da74888eac65d6e7988a9')
ck('wrapper_exact_reviewed',h(R/'EXECUTOR.py')=='1eafd71e29c4065d4508b3dda2d12343821eca2b20131bdcf1de9f9ecd0fa279')
ck('original_inner_unchanged',h(I/'EXECUTOR.py')==h(B/'retire_exact_leaves_v2.py')==r['executor_sha256']=='612de38f3cdcc84febf77c7dcbbff455f76c0887d4fd91e37ac439dff6402fba')
ck('common_unchanged',h(I/'COMMON.py')==h(B/'exact_common.py')==r['common_sha256']=='d11e9dd829a0a0d53386943556b55bd0f6721eb12301534e875ce485202409b5')
ck('plan_unchanged',h(I/'PLAN.json')==h(B/'PLAN.v2.json')==r['plan_sha256']=='38e28b2e0b63ad263d2eb22beb6f80e90190073d68a40ad9cc9b81f6e1ac83be')
ck('new_approval_exact_scope',request['new_approval_scope']=={'approved_utc':'2026-10-26T17:59:47Z','fixed_manifest_commit':'9a57aea2128a7bc3985064932c24e2229fd8fcb8','files':3156,'empty_directories':108,'no_expansion':True})
ck('fresh_evidence_bound',request['fresh_eligibility']['fresh_remote_result_sha256']=='cb81d42bf76485e2fe1413cda4b7d78b6740bbc7230a26b4cc4a5b63fab3366b' and request['fresh_eligibility']['fresh_remote_peer_sha256']==h(P/'REMOTE_FRESH_ACTUAL_REVIEW.json') and request['fresh_eligibility']['platform_assessment_sha256']==h(P/'PLATFORM_CONSUMER_ASSESSMENT.json') and request['fresh_eligibility']['preflight_maps_exit_preserved']==1)
scope=load(B/'SOURCE_SCOPE.v2.json');source=[json.loads(x)for x in (B/'source-readonly-validation/VALIDATED.jsonl').read_text().splitlines()];indexes=load(B/'auxiliary-readonly-validation/EXACT_INDEX_LEAVES.json');elfs=load(B/'auxiliary-readonly-validation/EXACT_ELF_LEAVES.json');chrome=load(B/'auxiliary-readonly-validation/EXACT_CHROME_CACHE_LEAVES.json')
cache=[{'path':str(Path(g['path'])/x['relative']),'original_state':x['original_state']} for g in chrome for x in g['files']]
indexleaves=[{'path':x['effective_index'],'original_state':x['original_state']}for x in indexes]
leaves=source+cache+elfs+indexleaves;by={x['path']:x for x in leaves};expected_paths=set(by)
expected_dirs={str(Path(g['path'])/x['relative'])for g in chrome for x in g['directories']}|{g['path']for g in chrome}
ck('fixed3156',len(leaves)==len(by)==3156);ck('fixed108dirs',len(expected_dirs)==108)
ck('result_exact_removed',len(r['removed'])==3156 and {x['path']for x in r['removed']}==expected_paths)
ck('result_exact_absent',len(r['actual_absent_paths'])==3156 and set(r['actual_absent_paths'])==expected_paths)
ck('result_exact_empty_dirs',len(r['removed_empty_cache_directories'])==108 and set(r['removed_empty_cache_directories'])==expected_dirs)
for row in r['removed']:
 state=by[row['path']]['original_state']
 ck('removed_identity_'+row['path'],row['original_sha256']==state['sha256'] and row['original_allocated_bytes']==state['allocated'])
 ck('post_absent_'+row['path'],not os.path.lexists(row['path']))
for path in expected_dirs:ck('post_directory_absent_'+path,not os.path.lexists(path))
journal=[json.loads(x)for x in (I/'JOURNAL.jsonl').read_text().splitlines()]
counts=collections.Counter(x['event']for x in journal)
ck('journal_exact_event_counts',counts=={'intent':3156,'completed':3156,'empty-directory-intent':63,'empty-cache-root-intent':45})
intents={};completed=[];dirs=[]
for e in journal:
 path=e['path']
 if e['event']=='intent':
  ck('unique_journal_intent_'+path,path not in intents and path in by)
  ck('journal_full_original_state_'+path,e['original_state']==by[path]['original_state'])
  intents[path]=e
 elif e['event']=='completed':
  ck('completion_matches_prior_intent_'+path,path in intents and path not in completed and e['kind']==intents[path]['kind'] and e['original_sha256']==by[path]['original_state']['sha256'])
  completed.append(path)
 else:
  ck('directory_journal_in_scope_'+path,path in expected_dirs and path not in dirs)
  dirs.append(path)
ck('journal_completion_order',completed==[x['path']for x in leaves])
ck('last_two_are_indexes',completed[-2:]==[x['path']for x in indexleaves])
ck('journal_all_absent',set(completed)==expected_paths and set(dirs)==expected_dirs)
ck('durable_journal_implementation',all(x in (I/'EXECUTOR.py').read_text() for x in ['os.fsync(stream.fileno())','c.syncdir(path.parent)',"event='intent'","event='completed'","path.unlink()","path.rmdir() ".rstrip()]))
# No Git is launched. Original captured Git output is verified byte-for-byte.
all_rows=[];streams={};scoped_rows=[]
for label,root in [('wrapper',R),('inner',I)]:
 rows=load(root/'commands/subcommands.json')
 if label=='inner':ck('inner_result_command_table',rows==r['commands'])
 for row in rows:
  d=Path(row['directory']);saved=load(d/'result.json')
  ck(label+'_command_record_'+d.name,saved==row)
  ck(label+'_command_zero_'+d.name,row['actual_process_returncode']==0 and not row['timeout_expired'])
  for part in ['stdout','stderr','stdin']:
   b=(d/(part+'.bin')).read_bytes();ck(label+'_'+part+'_hash_'+d.name,H(b)==row[part+'_sha256'])
   if part!='stdin':ck(label+'_'+part+'_length_'+d.name,len(b)==row[part+'_bytes'])
  streams[str(d)]=(d/'stdout.bin').read_bytes();all_rows.append(row)
  if label=='inner':scoped_rows.append(row)
wrapper_rows=load(R/'commands/subcommands.json')
ck('one_original_attempt',sum('--execute-retirement' in x['command']for x in wrapper_rows)==1 and wrapper_rows[-1]['command'][0:3]==['python3','-B',str(B/'retire_exact_leaves_v2.py')])
ck('same_300s_capture_request',load(Path(wrapper_rows[-1]['directory'])/'request.json').get('timeout_seconds')==300)
# Check source HEAD/ref/object/status guards from original receipts only.
old={x['path']for x in load('/workspace/ordinary-code-retirement-20261023/RESULT.json')['removed']}|set(load('/workspace/geo337-retired-three-source-retirement-execution-20261025/RESULT.json')['removed_paths'])
old|={json.loads(x)['path']for x in Path('/workspace/tmp-coldcode-cleanup-20261024/execution-r2/UNLINKED.jsonl').read_text().splitlines()}
roots={x['root']:x['head']for x in scope['retained_rows']};after=load(I/'SOURCE_STATUS_AFTER_EXACT_D.json')
for root,head in roots.items():
 rows=[x for x in scoped_rows if x['cwd']==root]
 for args,expect_count in [(['rev-parse','HEAD'],2),(['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],2),(['status','--porcelain=v1','-z','--untracked-files=all'],2),(['for-each-ref','--format=%(refname) %(objectname)'],2)]:
  matches=[x for x in rows if x['command'][6:]==args]
  ck('two_source_phase_'+root+args[0],len(matches)==expect_count)
  data=[streams[x['directory']]for x in matches]
  if args[0]=='rev-parse':ck('source_heads_'+root,all(x.decode().strip()==head for x in data))
  elif args[0]=='cat-file':
   members=[x for x in scope['retained_rows']if x['root']==root];want=[f"{x['Git_blob']} blob {x['Git_bytes']}"for x in members]
   ck('all_source_objects_still_available_'+root,all(x.decode().splitlines()==want for x in data))
  elif args[0]=='status':
   for index,rawstatus in enumerate(data):
    rows0=[x for x in rawstatus.split(b'\0')if x];removed=old|(expected_paths if index else set());wanted={x[len(root)+1:]for x in removed if x.startswith(root+'/')}
    ck('precise_D_union_'+root+str(index),len(rows0)==len(wanted) and {x[3:].decode()for x in rows0 if x.startswith(b' D ')}==wanted)
   ck('after_status_hash_'+root,H(data[-1])==after[root]['status_sha256'])
  else:ck('refs_before_after_identical_'+root,data[0]==data[1] and H(data[-1])==after[root]['refs_sha256'])
 ck('after_HEAD_'+root,after[root]['head']==head)
protected=load(I/'PROTECTED_GIT_METADATA_BEFORE.json');protected_count=0
for root,vals in protected.items():
 for path,wanted in vals.items():
  p=Path(path);s=p.lstat();b=read(p);protected_count+=1
  ck('protected_privateGit_metadata_'+path,stat.S_ISREG(s.st_mode) and not p.is_symlink() and len(b)==wanted['bytes'] and H(b)==wanted['sha256'] and (s.st_mode,s.st_dev,s.st_ino)==(wanted['mode'],wanted['device'],wanted['inode']))
# Direct read-only preservation checks for excluded source, F9 six binaries and the five locked fixtures.
excluded=[]
for x in scope['excluded_ambiguous_rows']:
 p=Path(x['root'])/x['relative'];s=p.lstat();b=read(p)
 ck('excluded73_preserved_'+str(p),str(p) not in expected_paths and stat.S_ISREG(s.st_mode) and not p.is_symlink() and (s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(x['device'],x['inode'],x['nlink'],x['physical_bytes']) and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['Git_blob'])
 excluded.append(str(p))
f9=[]
for name in ['bridge','core','engineering-json-test','integrity','model-base','pf3-algorithm']:
 p=Path('/tmp/geometry-tests')/name;fp=load(str(p)+'.fingerprint.json');s=p.lstat();b=read(p)
 ck('F9_binary_matches_existing_fingerprint_'+name,str(p) not in expected_paths and stat.S_ISREG(s.st_mode) and b.startswith(b'\x7fELF') and len(b)==fp['exe_size'] and H(b)==fp['exe_sha256'] and s.st_mtime_ns==fp['exe_mtime_ns'])
 f9.append({'path':str(p),'bytes':len(b),'sha256':H(b),'fingerprint_sha256':h(str(p)+'.fingerprint.json')})
fixture_raw=Path('/tmp/geo337-new-final-six-browser-preparation-20261025/FIXTURE_TREE.stdout.bin').read_bytes()
ck('fixed_fixture_manifest',H(fixture_raw)=='cd9a09b18bd1f697e382179f8e9e29cc796632636f5a3f2d4162eb8455a4042e')
fixtures=[]
for row in fixture_raw.split(b'\0'):
 if not row:continue
 header,path=row.split(b'\t');mode,kind,oid,size=header.split();p=O/'a6-architecture-source-20261026'/path.decode();b=read(p)
 ck('fixed_F_fixture_preserved_'+path.decode(),str(p) not in expected_paths and len(b)==int(size) and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid.decode())
 fixtures.append({'path':str(p),'bytes':len(b),'sha256':H(b),'expected_git_oid':oid.decode()})
ck('five_fixtures_checked',len(fixtures)==5)
for folder in ['consumers-before','consumers-before-group-0','consumers-before-group-1','consumers-before-group-2','consumers-before-indexes','consumers-after']:
 x=load(I/folder/'CONSUMERS.json')
 ck('consumer_zero_hits_'+folder,x['hits']==[])
 ck('consumer_only_known_unreadable_'+folder,{int(a[0])for a in x['unreadable']} <= {208,260})
ck('root_immediate_disposition',load(R/'IMMEDIATE_CONSUMER_DISPOSITION.json')=={'platform_pids':[208,260],'exited_pids':[],'zombie_pids':[],'unresolved_pids':[]})
ck('local_full_remote_bindings',len(load(I/'REMOTE_PAYLOAD_BINDINGS.json'))==52)
ck('rebuild_notice',load(I/'INACTIVE_REQUIRE_REBUILD_AND_INDEX_RESTORE.json')['no_future_gate_reuse'] is True)
for mount in ['/workspace','/tmp','/dev/shm']:
 ck('actual_mount_difference_'+mount,rr['mounts_after'][mount]['free']-rr['mounts_before'][mount]['free']==rr['actual_net_free_changes'][mount])
ck('actual_TMP_exact',rr['mounts_before']['/tmp']['free']==r['TMP_free_before']==10326016 and rr['mounts_after']['/tmp']['free']==r['TMP_free_after']==117559296 and rr['actual_net_free_changes']['/tmp']==r['actual_TMP_net_free_change']==107233280)
ck('gross_equals_recorded_actual_in_this_run',sum(x['original_state']['allocated']for x in leaves)==107233280)
ck('native_not_admitted',r['observed_native_128MiB_free_gate'] is False and r['native_not_started_and_requires_fresh_original_admission'] is True and 134217728-r['TMP_free_after']==16658432)
ck('not_product_acceptance',rr['formal_product_test_executed'] is False and r['formal_executed'] is False)
review={'schema':'resume1758-exact-retirement-actual-peer/1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0 if not fails else 1,'blocking_findings':fails,'check_count':checks,'subject_root_result_sha256':h(R/'RESULT.json'),'subject_result_sha256':h(I/'RESULT.json'),'subject_root_exit':rr['exit_code'],'subject_exit':r['exit_code'],'subject_started_utc':r['started_utc'],'subject_ended_utc':r['ended_utc'],'approved_request_sha256':h(I/'REQUEST.json'),'executed_wrapper_sha256':h(R/'EXECUTOR.py'),'executed_original_sha256':h(I/'EXECUTOR.py'),'exact_removed':{'files':len(r['removed']),'source':len(source),'Chrome':len(cache),'ELF':len(elfs),'indexes':len(indexleaves),'empty_directories':len(expected_dirs),'skipped_files':0,'unexpected_paths':[],'direct_postabsence_verified':True},'journal':{'sha256':h(I/'JOURNAL.jsonl'),'events':dict(counts),'file_order_exact':True,'private_indexes_last':True,'durable_intent_completion_implementation_verified':True,'limit':'fsync calls及成功流程由精確已審executor與真exit0證成；不宣稱做了獨立斷電耐久測試。'},'original_command_receipts_verified':len(all_rows),'source_roots_verified':len(roots),'protected_private_Git_metadata_leaves_verified':protected_count,'protected_excluded_source_count':len(excluded),'protected_F9_binaries':f9,'protected_F_fixtures':fixtures,'protection_limits':['73排除來源做了現場inode/bytes/GitOID驗證。','F9六ELF匹配現有fingerprint的size/mtime/SHA且不在清理scope；沒有另存清理前fingerprint檔本身的獨立hash，不冒稱完整前後snapshot。','五個固定fixture在F source逐byte/OID核，其他fixture/raw/object保護依精確刪除範圍、原source status D集合與executor無越界寫路徑；不是對全檔案系統逐檔全hash。','source保留Git物件由原執行後cat-file type/size成功收據核對，private HEAD/config/refs等另實際hash；本代理沒有對退役root跑Git或重建已刪index。','已知平台不可讀proc限制持續明列；沒有聲稱其maps曾可讀。'],'actual_resources':{'mounts_before':rr['mounts_before'],'mounts_after':rr['mounts_after'],'actual_net_free_changes':rr['actual_net_free_changes'],'native_original_floor_bytes':134217728,'native_deficit_at_recorded_end_bytes':16658432,'native_start_authorized_by_this_review':False,'time_scope':'執行結束18:30:39原觀測；本審查之後的新資料成本不回填成當時數字。'},'no_repeat_operation':True,'new_permission_or_threshold_change':False,'reviewer_reran_Git_API_or_cleanup':False,'inputs':{str(p):h(p)for p in [I/'RESULT.json',R/'RESULT.json',I/'REQUEST.json',I/'JOURNAL.jsonl',I/'PLAN.json',I/'SOURCE_STATUS_AFTER_EXACT_D.json',I/'PROTECTED_GIT_METADATA_BEFORE.json',R/'IMMEDIATE_CONSUMER_DISPOSITION.json']}}
out=P/'RETIREMENT_ACTUAL_REVIEW.json'
if out.exists():raise RuntimeError('fresh peer output')
out.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
if sum(p.stat().st_size for p in P.iterdir())>150*1024:raise RuntimeError('report budget')
print(json.dumps({'exit_code':review['exit_code'],'checks':checks,'blocking_findings':fails,'review_sha256':h(out),'report_bytes':out.stat().st_size,'directory_total_bytes':sum(p.stat().st_size for p in P.iterdir())}))
