from pathlib import Path
import datetime,gzip,hashlib,json,os,stat
R=Path('/dev/shm/geometry-axiom-geo337-20261025/retirement-remote-fresh-175947-20261026')
O=Path('/tmp/geo-resume1758-retirement-peer-20261026')
E9='9a57aea2128a7bc3985064932c24e2229fd8fcb8'
S=Path('/tmp/geo337-retirement-approval-packet-20261026/SCOPE.json')
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(Path(p).read_bytes())
def read_original(p):
 p=Path(p)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 with os.fdopen(fd,'rb') as f:return f.read()
count=0;fail=[]
def ck(n,ok):
 global count
 count+=1
 if not ok:fail.append(n)
raw=(R/'RESULT.json').read_bytes();r=json.loads(raw)
if not r.get('ended_utc') or r.get('exit_code')!=0:raise RuntimeError('not an actual successful terminal result')
ck('subject_pin',sha(raw)=='cb81d42bf76485e2fe1413cda4b7d78b6740bbc7230a26b4cc4a5b63fab3366b')
ck('fixed_E9',r['evidence_sha']==E9)
ck('scope_pin',h(S)==r['scope_sha256']=='e68e692921f4b235d1dd48e03c36ed49d7860aec2229404dcacf9567662355c2')
ck('executor_pin',h(R/'EXECUTOR.py')=='80aa5c69c8aca327ed076612f472c0050aed73016e6dbd675becef6069e4bfd0')
ck('no_mutations',all(r[k] is False for k in ['deletion_executed','lease_modified','branch_modified','product_test_executed']))
host=json.loads((R/'HOST_EXEC_FINAL_CHUNK.json').read_bytes())
ck('host_actual_exit0',host['host_result']['exit_code']==0 and host['reported_session_id']==73265)
host_tail=json.loads(host['host_result']['output'].splitlines()[-1])
ck('host_terminal_matches',host_tail['exit_code']==0 and host_tail['ended_utc']==r['ended_utc'] and host_tail['verified_manifest_count']==4 and host_tail['verified_raw_payload_count']==26)
packet=json.loads(S.read_bytes());expected=[]
for x in packet['classes']:
 b=read_original(x['original_manifest'])
 ck('manifest_pin_'+x['kind'],sha(b)==x['manifest_sha256'])
 expected.append({'kind':'manifest','original_path':x['original_manifest'],'git_path':x['published_path'],'expected_bytes':len(b),'expected_sha256':x['manifest_sha256'],'expected_oid':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
url='https://github.com/ZhiQiYang/geometry-axiom/blob/'+E9+'/'
for x in packet['preservation']['payload_matches']:
 if x['form']!='raw':continue
 ck('fixed_raw_URL_'+x['original_path'],x['github_url'].startswith(url))
 expected.append({'kind':'raw','original_path':x['original_path'],'git_path':x['github_url'][len(url):],'expected_bytes':x['bytes'],'expected_sha256':x['sha256'],'expected_oid':x['blob_oid']})
ck('30_exact_paths',len(expected)==len({x['git_path'] for x in expected})==len(r['remote_checks'])==30)
bydir={};command_info=[];gzip_total=0
for i,row in enumerate(r['commands']):
 d=R/('%03d'%i)
 ck('directory_'+str(i),row['directory']==str(d))
 ck('record_'+str(i),json.loads((d/'RESULT.json').read_bytes())==row)
 req=json.loads((d/'request.json').read_bytes())
 ck('request_'+str(i),all(req[k]==row[k] for k in req))
 ck('fresh_time_'+str(i),r['started_utc']<=row['started_utc']<=row['ended_utc']<=r['ended_utc'])
 ck('true_exit_'+str(i),row['exit_code']==0 and row['timeout_expired'] is False)
 ck('timeout_unchanged_'+str(i),row['timeout_seconds']==60)
 z=(d/'stdout.bin.gz').read_bytes();b=gzip.decompress(z);e=(d/'stderr.bin').read_bytes()
 ck('gzip_bytes_'+str(i),len(z)==row['stdout_gzip_bytes'])
 ck('gzip_hash_'+str(i),sha(z)==row['stdout_gzip_sha256'])
 ck('stdout_bytes_'+str(i),len(b)==row['stdout_bytes'])
 ck('stdout_hash_'+str(i),sha(b)==row['stdout_sha256'])
 ck('stderr_bytes_'+str(i),len(e)==row['stderr_bytes']==0)
 ck('stderr_hash_'+str(i),sha(e)==row['stderr_sha256'])
 ck('complete_roundtrip_'+str(i),row['gzip_roundtrip'] is True and gzip.decompress(z)==b)
 if i:
  ck('normal_API_argv_'+str(i),row['argv'][:7]==['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json',row['argv'][6]] and len(row['argv'])==7 and row['argv'][6].startswith('repos/ZhiQiYang/geometry-axiom/git/blobs/'))
 bydir[str(d)]=(b,row);gzip_total+=len(z)
 command_info.append({'directory':d.name,'exit_code':row['exit_code'],'stdout_bytes':len(b),'stdout_sha256':sha(b),'stdout_gzip_sha256':sha(z)})
tree_bytes,tree_row=bydir[str(R/'000')]
ck('exact_tree_argv',tree_row['argv']==['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false','ls-tree','-r','-z',E9,'--']+[x['git_path'] for x in expected])
tree={}
for line in tree_bytes.split(b'\0'):
 if not line:continue
 hdr,path=line.split(b'\t',1);mode,kind,oid=hdr.split(b' ')
 ck('regular_tree_'+path.decode(),mode==b'100644' and kind==b'blob')
 tree[path.decode()]=oid.decode()
ck('tree_exact_set',set(tree)=={x['git_path'] for x in expected})
seen={};paths_info=[]
for item,row in zip(expected,r['remote_checks']):
 label=item['git_path']
 ck('exact_path_fields_'+label,all(row[k]==v for k,v in item.items()))
 ck('tree_path_oid_'+label,tree[label]==item['expected_oid']==row['actual_git_oid'])
 b,cmd=bydir[row['remote_stdout_directory']]
 ck('remote_argv_oid_'+label,cmd['argv'][-1]=='repos/ZhiQiYang/geometry-axiom/git/blobs/'+item['expected_oid'])
 ck('blob_identity_'+label,len(b)==item['expected_bytes'] and sha(b)==item['expected_sha256'])
 ck('blob_oid_'+label,hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['expected_oid'])
 local=read_original(item['original_path'])
 ck('complete_local_equal_'+label,local==b)
 ck('check_stream_binding_'+label,row['stdout_sha256']==cmd['stdout_sha256'] and row['stdout_bytes']==cmd['stdout_bytes'] and row['stdout_gzip_sha256']==cmd['stdout_gzip_sha256'])
 ck('check_booleans_'+label,row['E9_tree_verified'] is True and row['local_original_byte_equal'] is True and row['gzip_roundtrip'] is True)
 reused=item['expected_oid'] in seen
 ck('same_fresh_blob_reuse_flag_'+label,row['same_fresh_blob_reused']==reused)
 if reused:ck('same_fresh_blob_stream_'+label,seen[item['expected_oid']]==row['remote_stdout_directory'])
 else:seen[item['expected_oid']]=row['remote_stdout_directory']
 paths_info.append({'kind':item['kind'],'git_path':label,'original_path':item['original_path'],'bytes':len(b),'sha256':sha(b),'git_oid':item['expected_oid'],'fresh_stream':Path(row['remote_stdout_directory']).name,'reused_same_fresh_stream':reused})
ck('unique_remote_count',len(seen)==r['unique_remote_download_count']==len(r['commands'])-1==24)
ck('complete_gzip_sum',gzip_total==r['complete_stdout_gzip_bytes']==10226839)
ck('declared_counts',r['verified_manifest_count']==4 and r['verified_raw_payload_count']==26)
ck('capacity_constants',r['capacity_limits']=={'combined_bytes':2*1024**3,'retirement_reserve_bytes':72*1024**2,'task_bytes':20*1024**2,'gzip_bytes':18*1024**2})
ck('gzip_budget',gzip_total<=18*1024**2)
for i,x in enumerate(r['capacity_checks']):
 ck('capacity_formula_'+str(i),x['planned_total']==x['combined_allocated']+x['remaining_task_budget']+x['retirement_reserve'])
 ck('capacity_remaining_'+str(i),x['remaining_task_budget']==max(0,20*1024**2-x['task_allocated']))
 ck('capacity_shared_bound_'+str(i),x['planned_total']<=2*1024**3 and x['retirement_reserve']==72*1024**2)
 ck('capacity_actual_mount_'+str(i),x['actual_free']>=x['remaining_task_budget']+72*1024**2)
 ck('capacity_next_write_'+str(i),x['task_allocated']+x['next_write_bound']<=20*1024**2)
ck('result_unchanged_during_review',(R/'RESULT.json').read_bytes()==raw)
review={'schema':'resume1758-fresh-remote-actual-peer/1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0 if not fail else 1,'blocking_findings':fail,'subject_result_sha256':sha(raw),'subject_exit_code':r['exit_code'],'subject_host_exit_code':host['host_result']['exit_code'],'subject_started_utc':r['started_utc'],'subject_ended_utc':r['ended_utc'],'evidence_sha':E9,'scope_sha256':h(S),'check_count':count,'verified_manifest_paths':4,'verified_raw_payload_paths':26,'unique_fresh_remote_downloads':len(seen),'new_command_count':len(r['commands']),'complete_stdout_gzip_bytes':gzip_total,'commands':command_info,'path_bindings':paths_info,'capacity':{'samples':len(r['capacity_checks']),'peak_planned_total_bytes':max(x['planned_total'] for x in r['capacity_checks']),'combined_ceiling_bytes':2*1024**3,'preserved_retirement_reserve_bytes':72*1024**2,'actual_mount_free_also_verified':True},'eligibility':'本輪新遠端4manifest與26raw全內容/固定E9 path OID/可還原性成立，可作新root request的fresh_remote證據；不單獨授權清理或替代即時檔案/consumer守門。','not_relabelled_old_evidence':True,'reviewer_reran_Git_or_API':False,'reviewer_deleted_or_changed_lease':False,'limitations':['host檔只保存工具最後chunk，沒有冒稱先前進度chunk也保存；完整實際Git/API stdout均逐命令gzip保留並獨立解壓/hash/OID驗。','30固定path中重複OID共享本次同一完整遠端回應，不把歷史E9已下載內容充數。','這是封包恢復能力核收，非產品測試、全專案驗收或原來源身份的未來保證。']}
P=O/'REMOTE_FRESH_ACTUAL_REVIEW.json'
if P.exists():raise RuntimeError('fresh reviewer output required')
P.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
if sum(p.stat().st_size for p in O.iterdir())>150*1024:raise RuntimeError('review directory budget')
print(json.dumps({'exit_code':review['exit_code'],'checks':count,'blocking_findings':fail,'review_sha256':h(P),'subject_result_sha256':sha(raw),'review_bytes':P.stat().st_size}))
