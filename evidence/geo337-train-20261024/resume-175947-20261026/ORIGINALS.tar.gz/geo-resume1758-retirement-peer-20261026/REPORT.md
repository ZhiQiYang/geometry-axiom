# 固定3156清理：獨立靜態稽核

靜態核對通過，**尚不是可執行資格**；本代理刪除0、未改lease／分支。詳細檢查、輸入pins及限制見 REVIEW.json。

- 0000僅 retained_rows 的2439來源；其餘691 Chrome、2 index、24舊ELF，恰3156。108空目錄恰63子目錄＋45cache root。
- 與73排除來源無交集；沒有Git objects/refs、fixtures、raw evidence/run_all-logs；F9六ELF不在四個pre-*舊根。僅兩個指定.git/index。
- 原wrapper綁的66cc070d請求已撤銷，不能原樣重用。新批准必須配fresh no-reuse、consumer、hash/dirty、遠端備份可恢復與root lease。
- 原retire_exact_leaves_v2.py先全量核對再開始，逐葉兩次驗身份/hash；它不支援skip且最終硬核3156。預檢任何疑慮就保留，不能縮manifest或伪造原pin。若要skip-aware操作，需先對同一固定集合內的保留規則與單次執行作獨審；拒絕後不得改名/拆批。
- 原remote守門是本地已下載完整回條與raw/gzip逐byte核對，不是新的網路讀回。proc guard僅可讀cwd/exe/cmdline/fd，不含maps；unreadable只記限制。因此fresh現有執行者與scheduler no-reuse不能省略。

2GiB追到歷史root資源計畫的root_planning_ceiling_bytes，後由two-roots addendum合計兩OWN，sampler與清理工具再實作；不是實體SHM quota或已量測峰值。初計1536MiB是五job保守分配；現browser啟動U+416MiB≤2GiB，retirement需U+72MiB≤2GiB及實際SHM餘量。未在本次讀過檔案找到使用者最初逐字指定2GiB的原文；**但本輪指示已明確要求維持，不可自行放寬**。

主代理仍須fresh核所有葉與dirty、存活使用者/鎖、備份可恢復；核准TMP清理不會減少SHM計帳，且原毛107,233,280B不是實測回收。完成後才量測native128MiB准入，不能把整批清理成功當成所有測試可跑。
