"""Run the three original reader gates once on the fixed, existing F source.

Plan-only by default. No cleanup, source copying, Git mutation, or publication.
Root must assign the source and scheduler slot before explicit execution.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import traceback

F = "cbf0fb621888596aa14ad5f2349b503e23b1b72d"
OWN = Path("/dev/shm/geometry-axiom-geo337-20261025")
OTHER = Path("/dev/shm/geo337-F9-browsers-20261025")
SOURCE = OWN / "a6-architecture-source-20261026"
PUBLISHER = OWN / "publisher-source"
OLD = Path("/workspace/geometry-axiom")
PLAN = Path("/tmp/geo-resume1758-reader-plan-20261026")
PLAN_PIN = "5463ea4c4c4364acb9a51b18eec68d2921318acb8e220b3d29636dde755ecf64"
STAGE = Path("/workspace/geo318-reading-a-prep/formal-tools/run_stage.py")
REAPER = Path("/workspace/geo261-environment/reap_children.py")
CAPTURE = Path("/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py")
NATIVE_HELPER = STAGE.parent / "native_with_compile_log_retention.py"
PINS = {
    STAGE: "1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a",
    REAPER: "7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760",
    CAPTURE: "c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762",
    NATIVE_HELPER: "5dfe683e297514e0888db7b525053997b41142e6bb3509805fabee659f4fbc10",
}
FIXTURES = [
    "tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas",
    "tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas",
    "tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas",
    "tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene",
    "geometry-web/docs/evidence/issue48-34a6222-20261005/archives/1280-full.gcanvas",
]
RESERVE = 32 * 1024 ** 2
CEILING = 2 * 1024 ** 3


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def filehash(path):
    return digest(Path(path).read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--scheduler-slot", type=int, choices=(1, 2))
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"plan_only": True, "source_sha": F,
                          "source": str(SOURCE), "additional_bound_bytes": RESERVE,
                          "stages": ["reader-generate", "reader-check", "reader-unit"]}))
        return 0
    need(not sys.flags.optimize, "optimized Python forbidden")
    need(args.scheduler_slot in (1, 2), "explicit root scheduler slot required")
    need(args.output is not None and args.output.parent == OWN and not args.output.exists(),
         "fresh output directly within the existing OWN required")
    need(SOURCE.is_dir() and PUBLISHER.is_dir() and OLD.is_dir() and OTHER.is_dir(),
         "existing source and protected roots must be present")
    for path, expected in PINS.items():
        need(filehash(path) == expected, "original tool drift: " + str(path))
    need(filehash(PLAN / "MANIFEST.json") == PLAN_PIN, "plan pin")
    for item in json.loads((PLAN / "MANIFEST.json").read_bytes())["files"]:
        path = PLAN / item["path"]
        need(path.is_file() and not path.is_symlink(), "regular plan input")
        raw = path.read_bytes()
        need(len(raw) == item["bytes"] and digest(raw) == item["sha256"], "plan input drift")

    # Original shared planning limit and actual mount capacity are both retained.
    seen, used = set(), 0
    for root in (OWN, OTHER):
        for path in root.rglob("*"):
            stat = path.lstat()
            identity = (stat.st_dev, stat.st_ino)
            if identity not in seen:
                seen.add(identity)
                used += stat.st_blocks * 512
    available = shutil.disk_usage(OWN).free
    need(used + RESERVE <= CEILING, "original combined OWN 2 GiB planning limit")
    need(available >= RESERVE, "actual output mount capacity")

    out = args.output
    out.mkdir()
    (out / "tmp").mkdir()
    (out / "EXECUTOR.py").write_bytes(Path(__file__).read_bytes())
    for name in ("PLAN.md", "CLOSURE.tsv", "FACTS.json", "MANIFEST.json"):
        (out / ("plan-" + name)).write_bytes((PLAN / name).read_bytes())
    tool_dir = out / "tool-sources"
    tool_dir.mkdir()
    for path in PINS:
        (tool_dir / path.name).write_bytes(path.read_bytes())
    spec = importlib.util.spec_from_file_location("reader_original_capture", CAPTURE)
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    env = dict(os.environ)
    cleared = []
    for key in list(env):
        if key.startswith(("MUTATE", "GEOMETRY_", "GIT_")) or key in (
            "PYTHONOPTIMIZE", "PYTHONPATH", "PYTHONSTARTUP", "NODE_OPTIONS", "LD_PRELOAD"
        ):
            cleared.append(key)
            env.pop(key)
    env.update(LANG="C.UTF-8", LC_ALL="C.UTF-8", PYTHONDONTWRITEBYTECODE="1",
               PYTHONIOENCODING="utf-8", GIT_OPTIONAL_LOCKS="0", GITHUB_SHA=F,
               GITHUB_WORKSPACE=str(SOURCE), TMPDIR=str(out / "tmp"))
    rec = capture.Recorder(out, env, F)
    receipt = {
        "schema": "new-F-reader-three-original-gates/1", "source_sha": F,
        "source": str(SOURCE), "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "capacity": {"shared_allocated_before": used, "original_ceiling": CEILING,
                     "additional_bound_bytes": RESERVE, "actual_mount_free_before": available},
        "cleared_environment_names": cleared, "tool_sha256": {str(p): h for p, h in PINS.items()},
        "plan_sha256": PLAN_PIN, "scheduler_slot": args.scheduler_slot,
        "execution_scope": "new F reader run assigned by root; prior F9 is historical only",
        "stages": [], "errors": [],
        "cleanup_performed": False, "new_checkout_created": False,
        "all_three_passed": False, "exit_code": None,
    }

    def save():
        capture.dump(out / "RESULT.json", receipt)

    def run(argv, cwd=SOURCE, timeout=120):
        return rec.run(list(map(str, argv)), cwd=cwd, timeout=timeout, check=False,
                       source_sha=F, source_variant="new-F-original-reader")

    def git(root, *argv):
        row, raw, err = run(["git", "-c", "gc.auto=0", "-c", "maintenance.auto=false",
                             "-c", "core.fsmonitor=false", "-C", root, *argv], cwd=root)
        need(row["actual_process_returncode"] == 0, "Git guard failed; raw retained")
        return raw

    def file_identity(path):
        need(path.is_file() and not path.is_symlink(), "regular protected input: " + str(path))
        stat = path.stat()
        return {"sha256": filehash(path), "bytes": stat.st_size,
                "inode": stat.st_ino, "mtime_ns": stat.st_mtime_ns}

    def repo_identity(root):
        index = Path(git(root, "rev-parse", "--git-path", "index").decode().strip())
        if not index.is_absolute():
            index = root / index
        result = {"head": git(root, "rev-parse", "HEAD").decode().strip(),
                  "branch": git(root, "branch", "--show-current").decode().strip(),
                  "status": git(root, "status", "--porcelain=v1", "--untracked-files=all").decode(),
                  "cached": git(root, "diff", "--cached", "--name-only").decode(),
                  "index": file_identity(index)}
        if root == PUBLISHER:
            result["original_train_ref"] = git(root, "rev-parse", "refs/heads/codex/train-337-continue-20261024").decode().strip()
        return result

    def closure_identity():
        items = []
        for line in (PLAN / "CLOSURE.tsv").read_text().splitlines()[1:]:
            name, mode, expected_oid, size = line.split("\t")
            path = SOURCE / name
            need(path.is_file() and not path.is_symlink(), "required source missing: " + name)
            raw = path.read_bytes()
            oid = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            actual_mode = "100755" if path.stat().st_mode & 0o111 else "100644"
            need(oid == expected_oid and len(raw) == int(size) and actual_mode == mode,
                 "source closure mismatch: " + name)
            items.append({"path": name, "git_blob": oid, "bytes": len(raw), "sha256": digest(raw)})
        expected_scenes = {x["path"] for x in items if "/" not in x["path"] and x["path"].endswith(".scene")}
        need(expected_scenes == {p.name for p in SOURCE.glob("*.scene")}, "root scene set differs")
        return items

    def source_guard():
        state = repo_identity(SOURCE)
        need(state["head"] == F and state["status"] == "" and state["cached"] == "",
             "source must stay clean fixed F")
        return state

    save()
    try:
        receipt["source_before"] = source_guard()
        receipt["closure_before"] = closure_identity()
        receipt["fixtures_before"] = {name: file_identity(SOURCE / name) for name in FIXTURES}
        receipt["publisher_before"] = repo_identity(PUBLISHER)
        receipt["old_workspace_before"] = repo_identity(OLD)
        receipt["canonical_before"] = file_identity(SOURCE / "geometry-guide/公理層-閱讀器.html")
        save()
        for stage in ("reader-generate", "reader-check", "reader-unit"):
            env["GEO261_REAPER_LOG"] = str(out / (stage + "-outer-reaper.jsonl"))
            argv = ["python3", "-B", REAPER, "python3", "-B", STAGE,
                    "--root", SOURCE, "--sha", F, "--output", out / stage,
                    "--stage", stage, "--scheduler-slot", str(args.scheduler_slot)]
            entry = {"stage": stage, "argv": list(map(str, argv)),
                     "source_before": source_guard(), "actual_outer_timeout_seconds": None,
                     "outer_reaper_log": env["GEO261_REAPER_LOG"], "passed": False,
                     "actual_exit": None}
            receipt["stages"].append(entry)
            save()
            print("開始 " + stage, flush=True)
            try:
                row, stdout, stderr = run(argv, timeout=None)
                entry["outer_result"] = row
                entry["actual_exit"] = row["actual_process_returncode"]
                inner = json.loads((out / stage / "receipt.json").read_bytes())
                entry["inner_sha"] = inner.get("sha")
                entry["inner_actual_exit"] = inner.get("actual_exit_code")
                entry["inner_passed"] = inner.get("passed")
                entry["original_result"] = inner.get("original_result")
                entry["inner_errors"] = inner.get("errors")
                entry["inner_reaper_final"] = inner.get("reaper_final")
                terminal = json.loads(Path(env["GEO261_REAPER_LOG"]).read_text().splitlines()[-1])
                entry["outer_reaper_final"] = terminal
                entry["passed"] = (entry["actual_exit"] == 0 and entry["inner_sha"] == F
                                   and entry["inner_actual_exit"] == 0 and entry["inner_passed"] is True
                                   and terminal.get("event") == "完成")
            except BaseException:
                entry["error"] = traceback.format_exc()
                traceback.print_exc()
            finally:
                entry["canonical_after_sha256"] = filehash(SOURCE / "geometry-guide/公理層-閱讀器.html")
                save()
            # Do not relabel a generated changed source as F for subsequent gates.
            entry["source_after"] = source_guard()
            need(entry["canonical_after_sha256"] == receipt["canonical_before"]["sha256"],
                 "generated canonical drift retained; remaining F stages not started")
            save()
            print("完成 " + stage + " exit=" + str(entry["actual_exit"]), flush=True)
        receipt["all_three_passed"] = len(receipt["stages"]) == 3 and all(s["passed"] for s in receipt["stages"])
    except BaseException:
        receipt["errors"].append(traceback.format_exc())
        traceback.print_exc()
    finally:
        try:
            receipt["source_after"] = source_guard()
            receipt["closure_after"] = closure_identity()
            receipt["fixtures_after"] = {name: file_identity(SOURCE / name) for name in FIXTURES}
            receipt["publisher_after"] = repo_identity(PUBLISHER)
            receipt["old_workspace_after"] = repo_identity(OLD)
            receipt["canonical_after"] = file_identity(SOURCE / "geometry-guide/公理層-閱讀器.html")
            need(receipt["source_after"] == receipt["source_before"], "source index/state drift")
            for name in ("closure", "fixtures", "publisher", "old_workspace"):
                need(receipt[name + "_after"] == receipt[name + "_before"], name + " preservation failed")
            need(receipt["canonical_after"]["sha256"] == receipt["canonical_before"]["sha256"],
                 "canonical bytes changed")
            receipt["protected_inputs_unchanged"] = True
        except BaseException:
            receipt["protected_inputs_unchanged"] = False
            receipt["errors"].append(traceback.format_exc())
        receipt["ended_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        receipt["exit_code"] = 0 if receipt["all_three_passed"] and not receipt["errors"] and receipt["protected_inputs_unchanged"] else 1
        save()
    print(json.dumps({"output": str(out), "source_sha": F, "exit_code": receipt["exit_code"],
                      "all_three_passed": receipt["all_three_passed"],
                      "protected_inputs_unchanged": receipt.get("protected_inputs_unchanged")}), flush=True)
    return receipt["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
