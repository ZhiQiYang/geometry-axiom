"""Fresh read-only E9 backup verification. Never deletes or grants a lease."""
from pathlib import Path
import datetime, gzip, hashlib, json, os, shutil, stat, subprocess, sys, time

OWN=Path('/dev/shm/geometry-axiom-geo337-20261025')
OTHER=Path('/dev/shm/geo337-F9-browsers-20261025')
OUT=OWN/'retirement-remote-fresh-175947-20261026'
REPO=OWN/'publisher-source'
E9='9a57aea2128a7bc3985064932c24e2229fd8fcb8'
LIMIT=2*1024**3
RESERVE=72*1024**2
BUDGET=20*1024**2
GZIP_LIMIT=18*1024**2
SCOPE=Path('/tmp/geo337-retirement-approval-packet-20261026/SCOPE.json')
SCOPE_PIN='e68e692921f4b235d1dd48e03c36ed49d7860aec2229404dcacf9567662355c2'
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def allocated(roots):
    seen=set(); total=0
    for root in roots:
        if not root.exists(): continue
        for base,dirs,files in os.walk(root,followlinks=False):
            for name in dirs+files:
                s=(Path(base)/name).lstat(); key=(s.st_dev,s.st_ino)
                if key not in seen: seen.add(key); total+=s.st_blocks*512
    return total
capacity=[]
def admit(addition=0):
    used=allocated((OWN,OTHER)); task=allocated((OUT,))
    remaining=max(0,BUDGET-task)
    free=shutil.disk_usage(OWN).free
    record={'utc':now(),'combined_allocated':used,'task_allocated':task,'remaining_task_budget':remaining,'retirement_reserve':RESERVE,'planned_total':used+remaining+RESERVE,'actual_free':free,'next_write_bound':addition}
    capacity.append(record)
    need(task+addition<=BUDGET,'fresh task 20MiB bound')
    need(used+remaining+RESERVE<=LIMIT,'original combined 2GiB bound including remaining task and 72MiB retirement reserve')
    need(free>=remaining+RESERVE,'actual mount free reserve')
def write(path,raw):
    need(path.is_relative_to(OUT) and not path.is_symlink(),'output confined to own fresh root')
    admit(((len(raw)+4095)//4096)*4096)
    with path.open('wb') as f: f.write(raw);f.flush();os.fsync(f.fileno())
def dump(path,value):
    write(path,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def mkdir(path):
    admit(4096);path.mkdir()
need(not sys.flags.optimize,'optimized Python forbidden')
need(OUT.is_dir() and not OUT.is_symlink() and {p.name for p in OUT.iterdir()}=={'EXECUTOR.py'},'fresh exact output containing only executor')
need(sha(SCOPE.read_bytes())==SCOPE_PIN,'fixed approved scope')
packet=json.loads(SCOPE.read_bytes())
need(packet['evidence_head']==E9,'fixed E9')
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
result={'schema':'fixed-E9-fresh-remote-original-verification/1','exit_code':1,'started_utc':now(),'evidence_sha':E9,'scope_sha256':SCOPE_PIN,'deletion_executed':False,'lease_modified':False,'branch_modified':False,'product_test_executed':False,'commands':[],'remote_checks':[],'environment':{'python':sys.version,'platform':sys.platform,'cwd':str(REPO),'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1','network_and_credentials':'inherited normal gh/API configuration; no credentials dumped and no alternate route'},'capacity_limits':{'combined_bytes':LIMIT,'retirement_reserve_bytes':RESERVE,'task_bytes':BUDGET,'gzip_bytes':GZIP_LIMIT}}
gzip_total=0
def command(argv):
    global gzip_total
    index=len(result['commands']);d=OUT/('%03d'%index);mkdir(d)
    request={'argv':argv,'cwd':str(REPO),'started_utc':now(),'timeout_seconds':60}
    dump(d/'request.json',request)
    started=time.monotonic()
    try:
        p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,timeout=60)
        raw,err,code,timeout=p.stdout,p.stderr,p.returncode,False
    except subprocess.TimeoutExpired as exc:
        raw,err,code,timeout=exc.stdout or b'',exc.stderr or b'',None,True
    packed=gzip.compress(raw,mtime=0)
    need(gzip_total+len(packed)<=GZIP_LIMIT,'18MiB complete stdout gzip limit')
    write(d/'stdout.bin.gz',packed);gzip_total+=len(packed)
    write(d/'stderr.bin',err)
    roundtrip=gzip.decompress((d/'stdout.bin.gz').read_bytes())==raw
    row={**request,'ended_utc':now(),'seconds':time.monotonic()-started,'exit_code':code,'timeout_expired':timeout,'stdout_bytes':len(raw),'stdout_sha256':sha(raw),'stderr_bytes':len(err),'stderr_sha256':sha(err),'stdout_gzip_bytes':len(packed),'stdout_gzip_sha256':sha(packed),'gzip_roundtrip':roundtrip,'directory':str(d)}
    dump(d/'RESULT.json',row);result['commands'].append(row)
    need(code==0 and not timeout,'command failed; no retry or route substitution: '+str(index))
    need(not err,'unexpected command stderr')
    need(roundtrip,'full preserved stdout roundtrip')
    return raw,row
try:
    items=[]
    for item in packet['classes']:
        local=Path(item['original_manifest']).read_bytes()
        need(sha(local)==item['manifest_sha256'],'fixed local manifest pin')
        items.append({'kind':'manifest','original_path':item['original_manifest'],'git_path':item['published_path'],'expected_bytes':len(local),'expected_sha256':item['manifest_sha256'],'expected_oid':hashlib.sha1(b'blob '+str(len(local)).encode()+b'\0'+local).hexdigest()})
    raws=[x for x in packet['preservation']['payload_matches'] if x['form']=='raw']
    need(len(items)==4 and len(raws)==26,'exact four manifests and 26 raw payloads')
    urlprefix='https://github.com/ZhiQiYang/geometry-axiom/blob/'+E9+'/'
    for item in raws:
        need(item['github_url'].startswith(urlprefix),'exact E9 payload URL')
        items.append({'kind':'raw','original_path':item['original_path'],'git_path':item['github_url'][len(urlprefix):],'expected_bytes':item['bytes'],'expected_sha256':item['sha256'],'expected_oid':item['blob_oid']})
    need(len({x['git_path'] for x in items})==30,'exact distinct Git leaf paths')
    tree_raw,tree_row=command(['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false','ls-tree','-r','-z',E9,'--']+[x['git_path'] for x in items])
    tree={}
    for raw in tree_raw.split(b'\0'):
        if not raw: continue
        header,path=raw.split(b'\t',1);mode,kind,oid=header.split(b' ')
        need(mode==b'100644' and kind==b'blob','fixed regular E9 blob')
        tree[path.decode()]=oid.decode()
    need(set(tree)=={x['git_path'] for x in items},'E9 tree exact requested leaves')
    downloaded={}
    for item in items:
        need(tree[item['git_path']]==item['expected_oid'],'E9 path OID mismatch')
        p=Path(item['original_path']);s0=p.lstat()
        need(stat.S_ISREG(s0.st_mode) and not p.is_symlink(),'original regular file')
        descriptor=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
        with os.fdopen(descriptor,'rb') as f: local=f.read()
        s1=p.lstat()
        need((s0.st_dev,s0.st_ino,s0.st_size,s0.st_mtime_ns,s0.st_ctime_ns)==(s1.st_dev,s1.st_ino,s1.st_size,s1.st_mtime_ns,s1.st_ctime_ns),'original changed during read')
        need(len(local)==item['expected_bytes'] and sha(local)==item['expected_sha256'],'original local content drift')
        oid=item['expected_oid']
        reused=oid in downloaded
        if reused:
            raw,row=downloaded[oid]
        else:
            raw,row=command(['gh','api','--hostname','github.com','-H','Accept: application/vnd.github.raw+json','repos/ZhiQiYang/geometry-axiom/git/blobs/'+oid])
            downloaded[oid]=(raw,row)
        need(raw==local and len(raw)==item['expected_bytes'] and sha(raw)==item['expected_sha256'],'fresh remote original full-byte identity')
        actual_oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        need(actual_oid==oid,'fresh remote Git blob OID')
        result['remote_checks'].append({**item,'actual_git_oid':actual_oid,'E9_tree_verified':True,'local_original_byte_equal':True,'remote_stdout_directory':row['directory'],'same_fresh_blob_reused':reused,'stdout_sha256':row['stdout_sha256'],'stdout_bytes':row['stdout_bytes'],'stdout_gzip_sha256':row['stdout_gzip_sha256'],'gzip_roundtrip':row['gzip_roundtrip']})
        dump(OUT/'RESULT.json',result)
        if len(result['remote_checks'])%5==0: print(json.dumps({'verified_paths':len(result['remote_checks']),'unique_remote_downloads':len(downloaded)}),flush=True)
    need(len(result['remote_checks'])==30,'complete exact remote set')
    result['exit_code']=0
except BaseException as exc:
    result['error']=repr(exc)
finally:
    result['ended_utc']=now()
    result['verified_manifest_count']=sum(x['kind']=='manifest' for x in result['remote_checks'])
    result['verified_raw_payload_count']=sum(x['kind']=='raw' for x in result['remote_checks'])
    result['unique_remote_download_count']=max(0,len(result['commands'])-1)
    result['complete_stdout_gzip_bytes']=gzip_total
    result['capacity_checks']=capacity[:]
    dump(OUT/'RESULT.json',result)
    print(json.dumps({k:result[k] for k in ('exit_code','verified_manifest_count','verified_raw_payload_count','unique_remote_download_count','complete_stdout_gzip_bytes','ended_utc')},ensure_ascii=False),flush=True)
raise SystemExit(result['exit_code'])
