from pathlib import Path
import ast
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess

OUT=Path('/tmp/geo-resume1758-reader-executor-peer-20261026')
SOURCE=Path('/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026')
PLAN=Path('/tmp/geo-resume1758-reader-plan-20261026')
EXEC=Path('/tmp/geo-resume1758-reader-executor-20261026/EXECUTOR.py')
F='cbf0fb621888596aa14ad5f2349b503e23b1b72d'
checks=[]; commands=[]
def h(raw): return hashlib.sha256(raw).hexdigest()
def ck(name,ok): checks.append({'check':name,'ok':bool(ok)})
def git(*args):
    argv=['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false',*args]
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
    p=subprocess.run(argv,cwd=SOURCE,env=env,capture_output=True,timeout=60)
    i=len(commands); packed=gzip.compress(p.stdout,mtime=0)
    name='%02d.stdout.gz'%i; (OUT/name).write_bytes(packed)
    commands.append({'argv':argv,'cwd':str(SOURCE),'exit_code':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':h(p.stdout),'stdout_gzip':name,'stdout_gzip_sha256':h(packed),'stderr':p.stderr.decode('utf-8','replace')})
    ck('read-only Git '+str(i),p.returncode==0 and not p.stderr)
    if p.returncode: raise RuntimeError('Git source identity read failed')
    return p.stdout
def parse_tree(raw):
    result={}
    for row in raw.split(b'\0'):
        if not row: continue
        header,path=row.split(b'\t',1); mode,kind,oid,size=header.split()
        if kind==b'blob': result[path.decode()]=(mode.decode(),oid.decode(),int(size))
    return result

ck('executor pin',h(EXEC.read_bytes())=='509fbc7bcf366d8e78a782e48dbbacb5472b8f09518f0da884267343881477f8')
ck('plan manifest pin',h((PLAN/'MANIFEST.json').read_bytes())=='5463ea4c4c4364acb9a51b18eec68d2921318acb8e220b3d29636dde755ecf64')
for item in json.loads((PLAN/'MANIFEST.json').read_bytes())['files']:
    b=(PLAN/item['path']).read_bytes()
    ck('plan input '+item['path'],len(b)==item['bytes'] and h(b)==item['sha256'])
ast.parse(EXEC.read_text());ck('executor syntax',True)
index_before=h((SOURCE/'.git/index').read_bytes())
ck('actual HEAD F',git('rev-parse','HEAD').decode().strip()==F)
ck('actual clean status',git('status','--porcelain=v1','--untracked-files=all')==b'')
fixed=['公理層.md','current_geometry.c','tests/mutate.py','tests/test_axiom_reader.py','geometry-guide/sync_axiom_reader.py','geometry-guide/axiom_matrix.py','geometry-guide/公理層-閱讀器.html','geometry-guide/公理層-白話.md','geometry-guide/witness/manifest.json']
root_tree=parse_tree(git('ls-tree','-l','-z',F))
scenes={p:v for p,v in root_tree.items() if '/' not in p and p.endswith('.scene')}
witness_tree=parse_tree(git('ls-tree','-r','-l','-z',F,'--','geometry-guide/witness'))
svgs={p:v for p,v in witness_tree.items() if p.endswith('.svg')}
fixed_tree=parse_tree(git('ls-tree','-l','-z',F,'--',*fixed))
ck('nine fixed F leaves',set(fixed_tree)==set(fixed))
expected={**scenes,**svgs,**fixed_tree}
listed={}
for line in (PLAN/'CLOSURE.tsv').read_text().splitlines()[1:]:
    path,mode,oid,size=line.split('\t');ck('unique closure path '+path,path not in listed)
    listed[path]=(mode,oid,int(size))
ck('212-leaf closure exact F tree',listed==expected and len(expected)==212)
ck('F root scenes complete 172',len(scenes)==172 and set(scenes)=={p.name for p in SOURCE.glob('*.scene')})
manifest=json.loads((SOURCE/'geometry-guide/witness/manifest.json').read_bytes())
ck('31 manifest SVG inputs exact',len(svgs)==31 and set(svgs)=={'geometry-guide/witness/'+cid+'.svg' for cid in manifest})
bad=[]; actual=[]
for path,(mode,oid,size) in listed.items():
    p=SOURCE/path;b=p.read_bytes()
    actual_oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    m='100755' if p.stat().st_mode&0o111 else '100644'
    ok=p.is_file() and not p.is_symlink() and (m,actual_oid,len(b))==(mode,oid,size)
    if not ok: bad.append(path)
    actual.append({'path':path,'sha256':h(b),'git_blob_oid':actual_oid,'bytes':len(b),'mode':m})
ck('all physical closure leaves match F',not bad)
ck('closure byte count 8628746',sum(x['bytes'] for x in actual)==8628746)
ck('source index preserved by static review',h((SOURCE/'.git/index').read_bytes())==index_before)
node_env=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE')
node_path=shutil.which('node')
node={'CODEX_PRIMARY_RUNTIME_NODE':node_env,'PATH_node':node_path,'selected':node_env or node_path}
node['selected_exists']=bool(node['selected']) and Path(node['selected']).is_file()
ck('selected Node exists (not executed)',node['selected_exists'])
if node_env and node_path:node['same_resolved_as_PATH_node']=Path(node_env).resolve()==Path(node_path).resolve()
pins={
 '/workspace/geo318-reading-a-prep/formal-tools/run_stage.py':'1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a',
 '/workspace/geo261-environment/reap_children.py':'7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760',
 '/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py':'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',
 '/workspace/geo318-reading-a-prep/formal-tools/native_with_compile_log_retention.py':'5dfe683e297514e0888db7b525053997b41142e6bb3509805fabee659f4fbc10'}
for p,pin in pins.items():ck('original tool pin '+p,h(Path(p).read_bytes())==pin)
result={'schema':'F-reader-executor-static-review-facts/1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0 if all(x['ok'] for x in checks) else 1,'executor_sha256':h(EXEC.read_bytes()),'source_sha':F,'check_count':len(checks),'checks':checks,'blocking_findings':[x['check'] for x in checks if not x['ok']],'commands':commands,'closure_count':len(actual),'closure_bytes':sum(x['bytes'] for x in actual),'closure_bad':bad,'closure_identity_sha256':h(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()),'source_index_sha256_before_and_after':index_before,'node_selection_not_executed':node,'product_tests_executed':False,'reader_executor_imported_or_executed':False,'source_modified':False}
(OUT/'FACTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('exit_code','check_count','blocking_findings','closure_count','closure_bytes','node_selection_not_executed')},ensure_ascii=False))
raise SystemExit(result['exit_code'])
