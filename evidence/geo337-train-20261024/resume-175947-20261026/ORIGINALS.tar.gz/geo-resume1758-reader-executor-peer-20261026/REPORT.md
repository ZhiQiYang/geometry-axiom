# 新 F reader 執行計畫與執行器靜審

接受指定執行器 `509fbc7bcf366d8e78a782e48dbbacb5472b8f09518f0da884267343881477f8`，本次靜態核對無阻擋。**未啟動 reader、Node、C 或 browser，也不是產品通過收據。** 主代理仍須依既有排程獨占來源、與清理錯開，實際啟動時重新通過原容量准入。

## 閉包實質核對

獨立唯讀 Git tree 與實體位元組核對證成 HEAD 為完整 F `cbf0fb621888596aa14ad5f2349b503e23b1b72d`、status 空，212 葉共 8,628,746 bytes：9 固定輸入、F 根目錄全數 172 個 scene、31 個 manifest 條目對應 SVG；無遺漏、錯誤 OID/模式/大小或額外根 scene。靜審前後來源 index SHA-256 相同。

這個結論不是由 3763 葉的總數推測：直接讀取三份 Python 的 AST／檔案 I/O 與實作後，sync 只讀 canonical、SSOT、白話、witness manifest/SVG，並經 axiom_matrix 讀完整 current_geometry.c、mutate.py 文字及 root scene。它不 import mutate、不編譯 C、不讀其 C include 閉包，也不執行 witness 引擎。unit import 同一 sync；其餘 imports 都是 Python 標準庫。其 Node 子命令只有 `-e` 加 stdin 的真閱讀器 JS/packet。因而 native 的 6997 葉不是這三個 reader gate 的必要前置，亦未宣稱這份 selected checkout 足以跑 native。

實際 `CODEX_PRIMARY_RUNTIME_NODE` 與 PATH 的 node 為同一解析路徑，檔案存在；本審查未執行版本命令。正式 stage 自己會核 Python/Node 版本，讀取或執行失敗不能 skip 冒綠。

## 執行、時限與保全

- 三項命令仍為原 `reader-generate`、`reader-check`、`reader-unit`，原 run_stage、capture、reaper、被記錄但 reader 不執行的 native helper pins 均吻合。
- capture 保留傳入 env 的同一 dict；每項開跑前設定外層 `GEO261_REAPER_LOG` 確實會傳入。run_stage 再設定獨立內層 log。成功要求實際外層 exit 0、內層 F/exit/passed 及外層 reaper 完成；原 run_stage 自己也核內層 reaper 完成和前後 clean source。
- 原 runner 的 300/300/1200 變數沒有傳給最後的 capture；真正 outer timeout 是 None。新執行器保留這個事實，沒有宣稱已施行上述限時或更改裁判。
- 32 MiB 是本 reader 的新資源預留，啟動前仍檢兩 OWN 合計加預留不超過原 2 GiB，並檢實際掛載空間；不是修改 native/browser 門檻，也不是新增 OS 配額。本靜審不宣稱已量測執行峰值。
- source HEAD/status/cached/index、五 fixtures、publisher HEAD/branch/status/index/原列車 ref、old workspace 皆前後核對。canonical 允許同步器正常替換檔案 inode，但必須保住原 bytes。
- generate 若造成 canonical bytes 或 clean source 漂移，原變更保留，後兩項不再冒 F 啟動；沒有 reset/checkout/自動還原或修改公理的路徑。其餘失敗且來源保持 F 時，仍收齊三項真結果。
- 預設 plan-only；真正執行需 `--execute`、全新外部輸出及 root 指定 slot。slot 是既有排程契約，不是本工具額外取得的全域檔案鎖，主代理必須實際維持互斥與最多兩個重測試。

本包保存獨立 tree/head/status 原 stdout gzip 與指令、237 項靜態身份核對。沒有重跑同 SHA 已完成的產品測試，沒有把前一輪 F9 的綠搬到 F。實際 gate 完成後仍須另核其原件、exit 與保全，並持久化 SHM 收據。
