# 本輪一次證據交付計畫（尚未執行）

固定產品 F：`cbf0fb621888596aa14ad5f2349b503e23b1b72d`。既有證據 parent：`dea5d12a88c0a2ed93141014524dce5d104f8b1f`；原分支由 root 單獨寫入。此計畫不執行 Git、網路、清理或產品測試，也不把上一輪 F／證據視為本輪成果。

## 交付內容

1. 本輪 maps 預檢原 exit 1、完整原流與錯誤，不改成綠。
2. Fresh 遠端 30 路徑的原 argv、時間、退出碼、stderr、RESULT、執行器與 host 終態；輸出去重邊界見下。
3. 新批准的清理 root／原本體完整 argv、journal、結果與原流。3156 檔／108 目錄和回收量依真實原件，與產品驗收分開。
4. 新 F reader 的完整新原件；必須已有真正 `ended_utc`、固定 RESULT hash、真 exit 與獨審，不能打包仍執行中的 reader。
5. 本輪入口核實、計畫、執行器、獨立審查、root 的新 PROGRESS。必要時由 root 在凍結 config 前加入其他已終態的小型原件，不讀 active 工作。

準備器只把明列新 roots 一次組成 `ORIGINALS.tar.gz` 與完整 `INDEX.json`；tar 內保留所有獨有檔案與空目錄。tar container metadata 正規化為 uid/gid/mtime=0、file mode0644/dir0755，來源實體 mode/inode/mtime/ctime 等另列 INDEX，不把正規化 tar metadata 當原始 metadata。

## 唯一可外部引用的資料

固定 E9：`9a57aea2128a7bc3985064932c24e2229fd8fcb8`。

`retirement-remote-fresh-175947-20261026/RESULT.json` 真 exit 0，完整 hash `cb81d42bf76485e2fe1413cda4b7d78b6740bbc7230a26b4cc4a5b63fab3366b`；獨審 hash `53c6275d0ed80a1710d988853adc30d3395f561b980ce98c7e4b52e7bbaea836`。4 manifest＋26 raw 是30個固定 E9 路徑，因內容相同別名共用24個唯一 fresh API captures。

只外部引用 `001..024/stdout.bin.gz` 這24份**精確集合**，不按 extension 廣排。其完整解壓 stdout 逐 byte 符合 E9 已持久化的原件，索引記 E9完整 SHA、path、Git OID、raw bytes/SHA256、全部30路徑別名、fresh capture 目錄和本地 gzip bytes/SHA256。引用的是完整 raw stdout，不宣稱新 tar 含被省略的 gzip 容器，也不保證不同環境重壓後 gzip bytes 相同。所有本地 gzip 仍保留。

這可省 **10,225,981 bytes**。`000/stdout.bin.gz`（本次 git ls-tree 完整輸出，858 bytes）是獨有輸出，必須收入新 tar。Freshremote 的103檔中，新 tar 仍保留79檔／161,950 bytes，包含所有新命令、時間、exit、stderr、結果、執行器與 host final。此界線已由獨立子代理 `/root/resume1758_delivery_plan/dedupe_binding_review` 唯讀逐 byte 核實；該代理未重跑 Git/API 或接觸 active reader。

## 原容量公式，沒有放寬

18:45:42 UTC 的**只讀規劃觀測**：兩 OWN 合計 `2,064,420,864 bytes`，距原 `2,147,483,648` 上限餘 `83,062,784`。實體 SHM free 為 `15,807,459,328 bytes`，不能取代規劃守門。

對已閉合11 roots（未讀 active reader）的1132檔／7,629,863 raw bytes，只在記憶體試作 tar.gz，壓縮後 `1,165,403 bytes`，沒有建包。這不是最終交付大小；reader終態、後續審查及 INDEX 必須加入後重新算。

準備器先在記憶體組出真正 archive 與 INDEX，計算輸出 allocated 上界，再套原 publisher 原式：

`publish_bound = 3 × published_payload_bytes + 65,536 × published_leaf_count + 8 × manifest_bytes + 67,108,864`

要求 `兩OWN當下allocated + 新準備輸出allocated上界 + publish_bound ≤ 2GiB` 且實體掛載亦足夠。上述條件不過時不建立輸出目錄，錯誤明列精確缺額。寫出後再次量測，為最後 RESULT 另留64KiB；root 真正發布時仍由**未修改的原 publisher** fresh 重驗同一守門。

估計 archive＋完整 INDEX＋小文件在約2–3MB時可容納；這只是方向，不能據估計宣稱最後准入。加入新專項後若不合原式，直接列缺額，不刪原件、不降64MiB／3倍係數／2GiB門檻。

## root 執行順序

1. 等 reader 及要收入的所有工作真正終態；讀各 RESULT／host exit／peer。將 `CONFIG.template.json` 另存成凍結 config，填入真 terminal hashes／退出碼、新 PROGRESS path/hash、完整 root 清單，確認後把 `template_only_not_executable` 設為 `false`。保留本模板。原預檢1與產品紅燈都可以且必須封存。
2. 交另一代理靜審 `prepare_package.py` 與凍結 config。執行器預設只印 plan-only，不讀 captures。正式準備命令形狀：

   `python3 -B /tmp/geo-resume1758-delivery-plan-20261026/prepare_package.py --execute --config <frozen.json> --config-sha256 <sha256> --out /dev/shm/geometry-axiom-geo337-20261025/continuation-package-175947-20261026`

3. 準備結果真 exit 0後，另一代理核全 member／24外部完整stdout引用、讀回 hash、原件未變與容量公式。這仍不是發布成功。
4. root 取得 parent 的原 PROGRESS blob OID，沿用 `/tmp/geo337-recovery-evidence-append-preparation-20261026/publish_append.py`。受審原 SHA256 `988a3b851db4417d41c073d02e8d3e440ea7dd22c10c53421490da79174cb720` 不變。傳剛生成 `PUBLICATION_MANIFEST.json` 的 hash、expected-parent=`dea5d12a88c0a2ed93141014524dce5d104f8b1f`、精確 expected-progress-blob、新 output。普通 push，遠端全文核驗後才算交付。
5. 若遠端 parent 已移動，停止發布並讀新狀態；不 force、不覆寫別人的分支。原 publisher 保全 HEAD/index/train；只容許精確舊 PROGRESS OID 的既有葉覆寫。

本工具沒有 publisher 呼叫、shell、Git、網路、unlink/rmdir、原件搬移或還原，也沒有自動更新正文／交接。產品 SHA／執行 SHA繼續按每份原收據分開。
