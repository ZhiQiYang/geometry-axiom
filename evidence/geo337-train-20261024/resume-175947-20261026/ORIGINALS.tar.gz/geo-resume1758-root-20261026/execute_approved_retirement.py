"""Execute the unchanged, fixed-scope retirement once after new approval and proof."""
import argparse, datetime, hashlib, importlib.util, json, os, shutil, stat, sys
from pathlib import Path

def need(value, message):
    if not value:
        raise RuntimeError(message)

def h(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

need(not sys.flags.optimize, 'optimized Python forbidden')
p = argparse.ArgumentParser()
p.add_argument('--remote-result-sha', required=True)
p.add_argument('--remote-peer-sha', required=True)
a = p.parse_args()
own = Path('/dev/shm/geometry-axiom-geo337-20261025')
tool = Path('/tmp/geo337-native-TMP-combined-preservation-20261025/retire_exact_leaves_v2.py')
need(h(tool) == '612de38f3cdcc84febf77c7dcbbff455f76c0887d4fd91e37ac439dff6402fba', 'unchanged original retirement tool')
spec = importlib.util.spec_from_file_location('approved_original_retirement', tool)
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
c = t.c
remote = own / 'retirement-remote-fresh-175947-20261026/RESULT.json'
remote_peer = Path('/tmp/geo-resume1758-retirement-peer-20261026/REMOTE_FRESH_ACTUAL_REVIEW.json')
platform_peer = Path('/tmp/geo-resume1758-retirement-peer-20261026/PLATFORM_CONSUMER_ASSESSMENT.json')
need(h(remote) == a.remote_result_sha and json.loads(remote.read_bytes())['exit_code'] == 0, 'new complete remote proof')
need(h(remote_peer) == a.remote_peer_sha, 'fresh remote actual peer pin')
rp = json.loads(remote_peer.read_bytes())
need(rp['exit_code'] == 0 and not rp['blocking_findings'] and rp['subject_result_sha256'] == a.remote_result_sha, 'independent fresh remote review')
need(h(platform_peer) == '83ae57a0f66efbc5cd84170b880b20d93047e8a5f11a69d70a5a41a6bbcc2912', 'limited platform consumer assessment pin')
need(json.loads(platform_peer.read_bytes())['exit_code'] == 0, 'platform assessment failed')
preflight = own / 'retirement-preflight-175947-20261026/RESULT.json'
need(h(preflight) == '040bf15ca7e5b2cb9270a0754b0583fc657213b7ba486f7e912a582775ffb283', 'original preflight retained')
v = json.loads(preflight.read_bytes())
need(v['exit_code'] == 1 and len(v['eligible_leaves']) == 3156 and not v['ineligible_leaves'] and v['deletion_executed'] is False, 'preflight scope identity')
need(not os.environ.get('DOCKER_HOST') and not os.environ.get('DOCKER_CONTEXT'), 'Docker endpoint override')
oldrequest = own / 'native-TMP-retirement-ROOT_REQUEST-20261026.json'
need(h(oldrequest) == '66cc070dfa595b38182629c9e6e9dfcb97db0aa1791da74888eac65d6e7988a9', 'preserve historical request bytes')
need(not (own / 'native-TMP-retirement-20261025').exists(), 'original operation has not run')
out = own / 'approved-retirement-root-175947-20261026'
request = own / 'native-TMP-retirement-APPROVED_REQUEST-175947-20261026.json'
need(not out.exists() and not request.exists(), 'one fresh execution only')
need(c.owned_allocated() + 72 * 1024**2 <= 2 * 1024**3, 'unchanged retirement preservation reserve')
out.mkdir()
(out / 'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
cap = c.load(c.original.CAP, c.original.CAP_PIN, 'approved_capture')
env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
rec = cap.Recorder(out / 'commands', env, 'cbf0fb621888596aa14ad5f2349b503e23b1b72d')

def run(argv):
    row, so, se = rec.run(argv, cwd='/workspace', timeout=30, check=True)
    need(not se, 'unexpected diagnostic in live service check')
    return so

need(run(['docker','context','show']) == b'default\n', 'Docker context changed')
need(json.loads(run(['docker','context','inspect','--format','{{json .Endpoints.docker.Host}}'])) == 'unix:///var/run/docker.sock', 'local Docker endpoint changed')
socket = Path('/var/run/docker.sock')
socket_stat = socket.stat()
need(socket.resolve() == Path('/run/docker.sock') and stat.S_ISSOCK(socket_stat.st_mode) and (socket_stat.st_dev, socket_stat.st_ino) == (27, 1048630), 'local Docker socket identity changed')
need(json.loads(run(['docker','info','--format','{{json .DockerRootDir}}'])) == '/var/lib/docker', 'Docker data root changed')
for argv in [['docker','ps','--all','--no-trunc','--format','{{json .}}'], ['docker','volume','ls','--format','{{json .}}'], ['docker','plugin','ls','--format','{{json .}}']]:
    need(run(argv) == b'', 'new Docker task workload; preserve all targets')
for pid, name, ppid in [(208,'dockerd',1),(260,'containerd',208)]:
    s = {}
    for line in (Path('/proc') / str(pid) / 'status').read_text().splitlines():
        key, sep, value = line.partition(':')
        if sep:
            s[key] = value.strip()
    need(s['Name'] == name and s['PPid'] == str(ppid) and s['Uid'].split() == ['0']*4 and not s['State'].startswith('Z'), 'platform process identity changed')
plan, source, indexes, elfs, chrome = c.read_plan()
guard = c.load(c.original.GUARD, c.original.GUARD_PIN, 'approved_immediate_consumer')
c.consumers(out, 'root-immediate', guard, c.group_paths(source, indexes, elfs, chrome))
observed = json.loads((out / 'consumers-root-immediate/CONSUMERS.json').read_bytes())
unreadable = sorted({int(row[0]) for row in observed['unreadable']})
disposition = {'platform_pids': [], 'exited_pids': [], 'zombie_pids': [], 'unresolved_pids': []}
for pid in unreadable:
    proc = Path('/proc') / str(pid)
    if not proc.exists():
        disposition['exited_pids'].append(pid)
    elif pid in (208, 260):
        disposition['platform_pids'].append(pid)
    else:
        try:
            state = next(line for line in (proc / 'status').read_text().splitlines() if line.startswith('State:'))
            disposition['zombie_pids' if '\tZ' in state else 'unresolved_pids'].append(pid)
        except (FileNotFoundError, ProcessLookupError):
            disposition['exited_pids'].append(pid)
        except (OSError, StopIteration):
            disposition['unresolved_pids'].append(pid)
c.dump(out / 'IMMEDIATE_CONSUMER_DISPOSITION.json', disposition)
need(not observed['hits'] and not disposition['unresolved_pids'], 'new unknown consumer; preserve all targets')
q = json.loads(oldrequest.read_bytes())
q.update(task_sha='cbf0fb621888596aa14ad5f2349b503e23b1b72d', root_exact_old_roots_no_reuse_lease=True, root_no_active_consumers_lease=True, root_complete_remote_preservation_verified=True, root_exact_retirement_authorized=True)
q['new_approval_scope'] = {'approved_utc':'2026-10-26T17:59:47Z','fixed_manifest_commit':'9a57aea2128a7bc3985064932c24e2229fd8fcb8','files':3156,'empty_directories':108,'no_expansion':True}
q['fresh_eligibility'] = {'preflight_result_sha256':h(preflight),'preflight_maps_exit_preserved':1,'platform_assessment_sha256':h(platform_peer),'fresh_remote_result_sha256':h(remote),'fresh_remote_peer_sha256':h(remote_peer),'consumer_scope':'Original readable-proc guard plus explicit no-reuse lease; local Docker platform has no task workload; inaccessible maps not represented as read'}
c.dump(request, q)
before = {p:dict(zip(('total','used','free'),shutil.disk_usage(p))) for p in ['/workspace','/tmp','/dev/shm']}
c.dump(out / 'MOUNTS_BEFORE.json', before)
row, so, se = rec.run(['python3','-B',str(tool),'--request',str(request),'--request-sha256',h(request),'--execute-retirement'], cwd='/workspace', timeout=300, check=False, source_variant='Newly approved exact 3156 leaves and 108 empty directories; unchanged original retirement executor')
after = {p:dict(zip(('total','used','free'),shutil.disk_usage(p))) for p in ['/workspace','/tmp','/dev/shm']}
result = {'exit_code':row['actual_process_returncode'],'request_sha256':h(request),'executor_sha256':h(tool),'started_after_new_approval':True,'formal_product_test_executed':False,'mounts_before':before,'mounts_after':after,'actual_net_free_changes':{p:after[p]['free']-before[p]['free'] for p in before}}
c.dump(out / 'RESULT.json', result)
print(json.dumps(result,ensure_ascii=False))
print(so.decode())
print(se.decode(),file=sys.stderr)
raise SystemExit(row['actual_process_returncode'])
