# root CONFIG 與 PROGRESS 獨立核對

結果：exit 0，沒有阻擋項。對象只限 root 新寫的凍結 CONFIG（fd567125…）與 PROGRESS（65bc4fe9…），不是自審打包程式。

15 個來源根存在；五份終態 hash、exit 與必要結束時間均吻合。新 F reader 三項 inner/outer 都是 0；原 stderr 證實 51 tests、0 skip、173 個 ResourceWarning 警告事件。字串出現 346 次是每則另附 tracemalloc 提示，PROGRESS 沒有稱零警告。reader actual peer 的 1955 checks、212 來源與五份 fixture 保全吻合。

清理收據證實 /tmp 10,326,016 → 117,559,296 bytes，實際增加 107,233,280。距原 128 MiB 准入尚差 16,658,432 bytes；正文清楚標示為 18:30 的量測、啟動前需重驗及 native 未啟動。舊固定清單已獲新批准並完成，額外 scope 仍沒有刪除批准或執行。

舊 F 有效 gates 明確是基線，F9 歷史資料沒有冒充新 F。新 axiom/card/resource/額外 scope 沒納入本批。正文保留 preflight、peer 初次失敗與 runner 未實際使用 timeout 的限制。

外部引用只准 24 個 API stdout 的完整 raw bytes 指向固定 E9、保留 30 路徑 aliases；正文明說新 tar 不含其 gzip 容器。新 ls-tree stdout 與新 reader／清理獨有原流必須留在 tar。真正 archive/index、容量守門及遠端持久化仍由原 preparer/publisher 執行並確認；本審查沒有把尚未生成的封包當已交付。

一個輔助唯讀摘要命令先假設 stderr.bin.gz 而 exit 1，改讀既有 stderr.bin 後 exit 0；沒有修改原件或重跑測試。完整結論及固定來源 hash 見 REVIEW.json。
