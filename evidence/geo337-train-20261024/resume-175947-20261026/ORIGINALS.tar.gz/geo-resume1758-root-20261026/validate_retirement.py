"""Read-only eligibility and restoration check for the newly approved fixed scope."""
import datetime, gzip, hashlib, importlib.util, json, os, stat, subprocess, sys
from pathlib import Path

def need(value, message):
    if not value:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

need(not sys.flags.optimize, "optimized Python forbidden")
base = Path('/tmp/geo337-native-TMP-combined-preservation-20261025')
tool = base / 'retire_exact_leaves_v2.py'
need(sha(tool.read_bytes()) == '612de38f3cdcc84febf77c7dcbbff455f76c0887d4fd91e37ac439dff6402fba', 'retirement tool pin')
spec = importlib.util.spec_from_file_location('approved_retirement_readonly', tool)
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
c = t.c
out = c.OWN / 'retirement-preflight-175947-20261026'
need(not out.exists(), 'fresh preflight output')
need(c.owned_allocated() + 90 * 1024**2 <= 2 * 1024**3, 'retain original retirement reserve plus bounded preflight space')
out.mkdir()
(out / 'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
cap = c.load(c.original.CAP, c.original.CAP_PIN, 'approved_capture')
guard = c.load(c.original.GUARD, c.original.GUARD_PIN, 'approved_consumer')
env = {k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
rec = cap.Recorder(out / 'commands', env, 'cbf0fb621888596aa14ad5f2349b503e23b1b72d')
result = {'exit_code': 1, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'deletion_executed': False, 'eligible_leaves': [], 'ineligible_leaves': [], 'remote_checks': []}

def remote_blob(oid, expected_sha, expected_bytes, label):
    argv = ['gh', 'api', '--hostname', 'github.com', '-H', 'Accept: application/vnd.github.raw+json', 'repos/ZhiQiYang/geometry-axiom/git/blobs/' + oid]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=c.OWN / 'publisher-source', env=env, capture_output=True, timeout=60)
    directory = out / 'remote' / ('%03d' % len(result['remote_checks']))
    directory.mkdir(parents=True)
    packed = gzip.compress(p.stdout, mtime=0)
    (directory / 'stdout.bin.gz').write_bytes(packed)
    (directory / 'stderr.bin').write_bytes(p.stderr)
    row = {'argv': argv, 'started_utc': started, 'exit_code': p.returncode, 'label': label, 'stdout_bytes': len(p.stdout), 'stdout_sha256': sha(p.stdout), 'stderr_sha256': sha(p.stderr), 'stdout_gzip_sha256': sha(packed), 'expected_sha256': expected_sha, 'expected_bytes': expected_bytes, 'blob_oid': oid}
    c.dump(directory / 'RESULT.json', row)
    result['remote_checks'].append(row)
    need(p.returncode == 0, 'remote read failed: ' + label)
    need(not p.stderr and len(p.stdout) == expected_bytes and sha(p.stdout) == expected_sha, 'remote original payload identity: ' + label)
    need(hashlib.sha1(b'blob ' + str(len(p.stdout)).encode() + b'\0' + p.stdout).hexdigest() == oid, 'remote Git OID')
    need(gzip.decompress(packed) == p.stdout, 'complete remote output preservation')
    need(c.owned_allocated() + 72 * 1024**2 <= 2 * 1024**3, 'original retirement reserve preserved')

try:
    plan, source, indexes, elfs, chrome = c.read_plan()
    scope = json.loads((base / 'SOURCE_SCOPE.v2.json').read_bytes())
    scope_by_path = {str(Path(x['root']) / x['relative']): x for x in scope['retained_rows']}
    need(set(scope_by_path) == {x['path'] for x in source}, 'fixed retained_rows only')
    index_payloads = [dict(path=x['effective_index'], original_state=x['original_state']) for x in indexes]
    caches = [dict(path=str(Path(g['path']) / x['relative']), original_state=x['original_state']) for g in chrome for x in g['files']]
    leaves = source + caches + elfs + index_payloads
    need(len(leaves) == 3156 and len({x['path'] for x in leaves}) == 3156, 'fixed exact scope')
    paths = c.group_paths(source, indexes, elfs, chrome)
    oldq = json.loads((c.OWN / 'native-TMP-retirement-ROOT_REQUEST-20261026.json').read_bytes())
    with c.leases():
        c.consumers(out, 'before', guard, paths)
        result['source_state'] = c.source_state(rec)
        for item in indexes:
            c.private_index_state(rec, item)
        c.chrome_namespace(chrome)
        for item in leaves:
            try:
                body = c.exact_file(Path(item['path']), item['original_state'], guard)
                if item['path'] in scope_by_path:
                    r = scope_by_path[item['path']]
                    need(hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == r['Git_blob'], 'source Git content identity')
                result['eligible_leaves'].append(item['path'])
            except Exception as exc:
                result['ineligible_leaves'].append({'path': item['path'], 'reason': repr(exc)})
        need(not result['ineligible_leaves'], 'changed or ambiguous leaves must be retained; original all-or-nothing executor not authorized to skip guards')
        result['empty_directory_scope_count'] = sum(len(g['directories']) + 1 for g in chrome)
        need(result['empty_directory_scope_count'] == 108, 'original directory count')
        result['local_preservation_matches'] = t.preserved_payloads(oldq, index_payloads + elfs)
        # Also inspect memory mappings; never treat unreadable live processes as absent.
        maps = {'hits': [], 'unreadable_live': [], 'checked': 0}
        for proc in Path('/proc').iterdir():
            if not proc.name.isdigit():
                continue
            try:
                status_text = (proc / 'status').read_text()
                state = next(x for x in status_text.splitlines() if x.startswith('State:'))
                if '\tZ' in state:
                    continue
                text = (proc / 'maps').read_text()
                maps['checked'] += 1
                hits = [r for r in paths if r in text]
                if hits:
                    maps['hits'].append({'pid': int(proc.name), 'paths': hits})
            except (FileNotFoundError, ProcessLookupError):
                continue
            except PermissionError:
                maps['unreadable_live'].append(int(proc.name))
        c.dump(out / 'MEMORY_MAP_CONSUMERS.json', maps)
        need(not maps['hits'] and not maps['unreadable_live'], 'active or unreadable memory-map consumer')
        packet = json.loads(Path('/tmp/geo337-retirement-approval-packet-20261026/SCOPE.json').read_bytes())
        need(packet['evidence_head'] == '9a57aea2128a7bc3985064932c24e2229fd8fcb8', 'fixed approval evidence')
        for item in packet['classes']:
            local = Path(item['original_manifest']).read_bytes()
            need(sha(local) == item['manifest_sha256'], 'approved manifest identity')
            row, so, se = rec.run(['git', 'rev-parse', packet['evidence_head'] + ':' + item['published_path']], cwd=c.OWN / 'publisher-source', timeout=60, check=True)
            oid = so.decode().strip()
            need(len(oid) == 40, 'manifest blob oid')
            remote_blob(oid, item['manifest_sha256'], len(local), item['published_path'])
        raws = [x for x in packet['preservation']['payload_matches'] if x['form'] == 'raw']
        need(len(raws) == 26 and {x['original_path'] for x in raws} == {x['path'] for x in index_payloads + elfs}, 'exact 26 remote original payloads')
        for item in raws:
            remote_blob(item['blob_oid'], item['sha256'], item['bytes'], item['original_path'])
        c.consumers(out, 'after', guard, paths)
        for item in leaves:
            c.exact_file(Path(item['path']), item['original_state'], guard)
        result['exit_code'] = 0
except BaseException as exc:
    result['error'] = repr(exc)
    raise
finally:
    result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['combined_OWN_allocated_bytes'] = c.owned_allocated()
    c.dump(out / 'RESULT.json', result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('eligible_leaves','local_preservation_matches','remote_checks','source_state')}, ensure_ascii=False))
