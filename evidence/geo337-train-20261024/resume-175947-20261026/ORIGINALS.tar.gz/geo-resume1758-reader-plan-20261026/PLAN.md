# 新 F 閱讀器三項正式驗收：可執行計畫

這是未執行的新 F 計畫，不沿用 F9 pass。固定來源為 `/dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026`，HEAD `cbf0fb621888596aa14ad5f2349b503e23b1b72d`。主代理獨占執行；子代理僅唯讀分析。

## 原裁判及命令

根 AGENTS「正典重建與驗證」與 F9 實際收據一致，順序為：

1. `python3 -B geometry-guide/sync_axiom_reader.py`
2. `python3 -B geometry-guide/sync_axiom_reader.py --check`
3. `python3 -B tests/test_axiom_reader.py`

正式保留既有 `/workspace/geo318-reading-a-prep/formal-tools/run_stage.py`、c387 capture 與原 reaper。對每個 `S=reader-generate,reader-check,reader-unit` 順序跑下式；`B` 是本次新建且在來源以外的 OWN 輸出根，`B/S` 必須尚未存在。這是可代入 argv 計畫，子代理未執行：

```text
env GEO261_REAPER_LOG=<B>/outer-<S>-reaper.jsonl
  python3 -B /workspace/geo261-environment/reap_children.py
  python3 -B /workspace/geo318-reading-a-prep/formal-tools/run_stage.py
  --root /dev/shm/geometry-axiom-geo337-20261025/a6-architecture-source-20261026
  --sha cbf0fb621888596aa14ad5f2349b503e23b1b72d
  --output <B>/<S> --stage <S> --scheduler-slot 1
```

外層 reaper 需要先給自己的 `GEO261_REAPER_LOG`。F9 首輪因漏給而三項都在 reader 啟動前失敗；其原失敗仍保存，不可重犯或誤判產品。run_stage 會給內層獨立 log、TMPDIR、16 MiB stack、locale、Python/Node版本及 SHA，清掉干擾環境；主代理外層沿用原環境清理（含 `MUTATE*`、`GEOMETRY_*`、PYTHONOPTIMIZE/PYTHONPATH/PYTHONSTARTUP/NODE_OPTIONS/LD_PRELOAD）。

**實際原時限**：run_stage 雖設定 `timeout=300/300/1200` 變數，最後對 reaper 的 recorder 呼叫明文 `timeout=None`，收據也寫 `outer_timeout_seconds=None`。不能宣稱那三個變數是已執行的外部限時，也不在本輪偷偷改守門。既有正式 runner 原樣使用；若出現異常長跑，回報真實程序與病因，不挑最好樣本。

## 來源與執行類型

必要閉包共 **212 葉、8,628,746 bytes**：9 固定輸入、172 個 root `.scene`、31 個見證 SVG。完整路徑／Git blob／bytes 列於 `CLOSURE.tsv`。每葉實體 Git blob SHA1 與 F 相等；缺失、錯位與額外 root scene 均為 0；source HEAD 正確，status/cached 空。

9 固定輸入：`公理層.md`、`current_geometry.c`、`tests/mutate.py`、`tests/test_axiom_reader.py`、`geometry-guide/sync_axiom_reader.py`、`geometry-guide/axiom_matrix.py`、`geometry-guide/公理層-閱讀器.html`、`geometry-guide/公理層-白話.md`、`geometry-guide/witness/manifest.json`。

這不是純 Python：Python 標準庫之外，sync validate 與 unit 透過 Node 執行閱讀器真正 JS／packet。沒有 C 編譯、核心執行、Chrome、網路或 npm；`axiom_matrix` 只讀 C／mutate／scene 作追溯。同步器只讀既有見證 SVG，不跑 witness 引擎。該閉包包含會靜默略過缺圖／scene的全數固定 F 檔案，所以不能只靠 exit 0 忽略 sparse 缺漏。

## 寫入與預算

- `reader-generate` 僅在這份主代理獨占來源寫 `geometry-guide/公理層-閱讀器.tmp`，驗證後 replace 同一正典；canonical 目前 **7,024,570 bytes**。
- `--check` 與 unit 不寫 canonical；unit 的重建在記憶體內。Node 用 `-e` 和 pipes，不建編譯／npm cache；`-B`／PYTHONDONTWRITEBYTECODE 防止 pyc。
- 不需另建 checkout，不用 `/tmp/geometry-tests`。輸出及 stage TMPDIR 放同一 OWN SHM 新資料夾，正式 raw 隨後必須持久化／推送，不能只留揮發掛載。
- F9 三個 stage 完整既有輸出量為 **257,736 logical bytes／466,944 allocated bytes**；這只是歷史規模參考，非本次實測峰值。三項歷史原程序耗時約 3.42、1.37、155.34 秒，非新時限。
- 建議本輪在**原兩 OWN 合計 2 GiB 規劃守門與實際可用空間**內預留 **32 MiB**：含 canonical 旁 `.tmp` 約 7 MiB、原件與 metadata、source identity 及餘量。32 MiB 是本計畫資源預算，不是放寬既有 native/browser 128/416 MiB 門檻；這三項不會啟動 native/browser。
- 啟動前 fresh 核實兩 OWN allocated +32 MiB ≤2 GiB，實際掛載可用量亦足夠；本子代理不根據舊容量批准啟動。

## 驗收與保全

逐項保存原 argv、全 stdout/stderr、環境、實際 exit、F、reaper 終態與 runner `passed`。保留 stage 前後 HEAD/status/index 與 canonical hash；generate 後 canonical 必須與 F 原 bytes 相同，才可說來源不變。若生成改變內容，保留新輸出與原 Git blob，不將後兩項的綠冒稱乾淨 F，也不在此計畫自行修正或重寫 SSOT。

主代理亦維持原五 fixture、publisher/index 等既有保全；此 reader 不需要它們的內容，不因本計畫刪除或變更它們。三 stage 各跑一次新 F；先前 F9 的三項結果是歷史，不是重跑理由或目前 pass。

成功可新交付「F reader 三項正式收據」，尚不代表 native、browser、Reading A oracle 或整體全綠。

## 固定原工具

- run_stage：`1f10c3028e2491a4076e83b9f4396e9428ede31389a8577224da85f7f1272c8a`
- runner 會記錄但 reader 不執行的 native_with_compile_log_retention：`5dfe683e297514e0888db7b525053997b41142e6bb3509805fabee659f4fbc10`
- capture：`c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762`
- reaper：`7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760`

F9 原件定位：`/workspace/geo337-F9-readers-actual-urce1nqh/environment-retry1/RESULT.json` 及其三個 `reader-*/receipt.json`。本輪沒有執行其中的舊 driver／原 SHA 測試。
