# 同 F 的 contact memo 精準撤回／恢復設計（尚未執行）

此證據另列為 isolated323 counterfactual，不取代 b74→F 原175 exact compare 的3個 #299 診斷紅燈，不改 b74/adba 性能分母。先收完新 F 原36timing及4gprof，之後才依 root 獨占窗口做本控制。

來源由原 verify_linux.closure(F repo, external phase/source, geometry-web/web_bridge.c) 複製必要 C/include 閉包；工作樹、index、HEAD 均不改。fixed/restored 全部閉包bytes必須與 F 相同；withdrawn 僅反向撤回本次 a440 的兩個 C 產品增量，tests/Reading A/diagnostic/其他功能不動。兩個 C 在 F64 的 expected hashes 為 core 1c77919f801bb639c5b42f621759fd940b0a3b9e3d90aa6be8e98dd4c952b751、H sources 77c03a865a39f6ab0e0eff7005d04ccf91d36db92c9f218ed69630f28be9bd56；撤回後必須等於固定 H 原件 f2d1f595be0279b2a052bde8ae0fd55c44e7d710610ea21cac2209d2d6603c10／a6dece841da1a19d5df5c032a17d713363136c49aee09f7f641d374c26b85512。各phase source/binary/patch/full runtime input清單留存。

原正式 fixed profile 的真程序可作 baseline：只引用原 geo_eval_source64/32 target，本控制不能以因其他已知紅累積的 wrapper1 代替該 target。撤回與恢復各用原 -O1 -fno-inline -pg 建置一次，原 profile_linux.py（不改bytes）仍跑 base/fix 各N32/N64一次、原stack16MiB、原loadfile、原gprof、無新增timeout。base沿原 b74，不換；每phase四次全留，不拿這些另外的控制結果重抽或取代正式profile。固定／撤回／恢復依原 fix calls64/calls32≤4.5 判0/1/0；分母0、缺symbol、crash、工具前置失敗一律不能當有效預期紅。若撤回仍綠，誠實寫未證，不重抽、不放寬門檻。四新增語意guards已有原load13具名0/1/0，它們不能替代此整體性能反證。

另外以同 F 的 fixed 與僅撤回兩 C 的 variant 跑原175 ABC：原固定171+4場景bytes及順序不變，O2 normal和trace各自真建置；原compare所有stdout/stderr、每seal完整有序圖及五guards exact相等斷言不改。隔離工作目錄的base/fix標籤只代表withdrawn/fixed兩source variant，manifest明確標 acceptance F + variant source hashes，不冒正式性能的b74 base。可以保留已完成F正式fixed binaries的hardlink（核全hash），withdrawn用原build工具新編；恢復phase若需再次編譯則源bytes必等F。

只在所有原phase真終態後判總證據；任何紅仍收其他不受影響phase。完整argv/env/exit/stdout/stderr、stack、F before/after clean、工具hash、場景hash與全部sourcevariant保留，不把負控預期1算正式產品紅。現階段只有設計，未建立任何受控source／編譯／profile／ABC。
