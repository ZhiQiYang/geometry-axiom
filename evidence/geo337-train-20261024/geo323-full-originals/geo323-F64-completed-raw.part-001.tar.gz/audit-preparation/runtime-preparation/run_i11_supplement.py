"""Separate added-I11 comparison plus the unchanged original native scene runner."""
import argparse,ast,datetime,fcntl,hashlib,importlib.util,json,os,resource,sys,traceback
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path);p.add_argument('--sha',required=True);p.add_argument('--formal-out',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--heavy-lock',required=True,type=Path);a=p.parse_args()
repo=a.repo.resolve();out=a.out.resolve();assert not out.exists();out.mkdir();(out/'tmp').mkdir();(out/'comparison').mkdir();(out/'comparison/scenes').mkdir();(out/'fixture').mkdir();(out/'work').mkdir();(out/'inputs').mkdir()
TOOLS=Path('/tmp/geo323-merge-20261023/acceptance-tools-v3')
for name,want in [('verify_linux.py','ccbce3a5d32bee81f22be31a31c1f771ca05c54f53f21e4d94b11b4a08b4534d'),('geo323_record.py','8aa05afded8738078cb319606422270345abc0317257d63e8879009acaaabb9b')]:assert hashlib.sha256((TOOLS/name).read_bytes()).hexdigest()==want
sys.path.insert(0,str(TOOLS));import geo323_record as original_record
C=Path('/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env['PATH']='/workspace/geo261-environment/bin:'+env['PATH']
for n in list(env):
 if n.startswith('GEOMETRY_') or n in ['NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','LD_PRELOAD']:env.pop(n,None)
env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TMPDIR=str(out/'tmp'),GITHUB_SHA=a.sha,GITHUB_WORKSPACE=str(repo),GEO323_BASE_SHA='b74f9a2ae7ade1555b9be45283adecc097fb76e3',GEO323_MAIN_SHA='adbaebf9c73ea6801d7b4d5214e4b846b132923b')
os.environ.clear();os.environ.update(env);rec=cap.Recorder(out,env,a.sha)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def guard():
 head=rec.run(['git','rev-parse','HEAD'],cwd=repo)[1].decode().strip();status=rec.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=repo)[1].decode();assert head==a.sha and not status;return {'head':head,'status':status}
r={'driver_sha256':cap.filehash(Path(__file__)), 'tool_hashes':{name:cap.filehash(TOOLS/name) for name in ['verify_linux.py','geo323_record.py']}, 'capture_sha256':cap.filehash(C), 'sha':a.sha,'repo':str(repo),'started_utc':now(),'ended_utc':None,'source_before':None,'source_after':None,'commands':rec.rows,'errors':[],'scope':'One added I11 comparison is separate from original175; semantic positive uses whole original run_tests.py unchanged. This scene runner is not full tests/run_all native; no custom length oracle.','comparison_exit':None,'native_build_exit':None,'native_runner_exit':None,'I11_original_case':None}
stack_before=resource.getrlimit(resource.RLIMIT_STACK);r['stack_before']=list(stack_before)
try:
 if stack_before[1]!=resource.RLIM_INFINITY and stack_before[1]<16777216:raise RuntimeError('Original16MiB stack unavailable')
 resource.setrlimit(resource.RLIMIT_STACK,(16777216,stack_before[1]));r['stack_during']=list(resource.getrlimit(resource.RLIMIT_STACK))
 if sys.flags.optimize:raise RuntimeError('Original asserts must remain enabled')
 formal=json.loads((a.formal_out/'receipt.json').read_text());assert formal['source_sha']==a.sha and formal['stages']['build']['execution_exit']==0
 assert out.stat().st_dev==a.formal_out.stat().st_dev, 'Environment: supplemental output and formal binaries must share filesystem for lossless hardlinks'
 r['source_before']=guard();rec.run(['df','-B1','/tmp','/workspace'],cwd=repo)
 name='_i11_two_surfaces_same_uv_accept.scene';payload=(repo/name).read_bytes();assert cap.digest(payload)=='4a1c2e411aa070ef89333eff235036f27d6c2f42806eefc6d0351c68cade89cb';(out/'fixture'/name).write_bytes(payload)
 for rel in ['tests/run_tests.py','tests/mutate.py',name]:
  raw=(repo/rel).read_bytes();q=out/'inputs'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 r['fixture']={'name':name,'bytes':len(payload),'sha256':cap.digest(payload),'introduced':'6366304eb787b2a50282e4132f45e51eb7d21290'}
 a.heavy_lock.parent.mkdir(parents=True,exist_ok=True)
 with a.heavy_lock.open('a+') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  for label in ['base','fix','base-trace','fix-trace']:
   src=a.formal_out/'work'/label/'bridge';dst=out/'work'/label/'bridge';dst.parent.mkdir();os.link(src,dst)
   r.setdefault('binary_bindings',[]).append({'label':label,'source':str(src),'hardlink':str(dst),'sha256':cap.filehash(dst)})
  spec=importlib.util.spec_from_file_location('original_verify',TOOLS/'verify_linux.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
  original_rec=original_record.Recorder(out/'comparison-commands',repo,a.sha,env);original_record.ACTIVE=original_rec
  try:
   v.compare(out/'fixture',out/'work',out/'comparison');r['comparison_exit']=0
  except BaseException:r['comparison_exit']=1;r['errors'].append(traceback.format_exc())
  r['comparison_commands']=original_rec.rows
  tree=ast.parse((repo/'tests/mutate.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compile_command');ns={'os':os,'HERE':repo/'tests'};exec(compile(ast.Module(body=[fn],type_ignores=[]),'original-F-compile_command','exec'),ns)
  r['compile_command_function_ast']=ast.dump(fn,include_attributes=False)
  exe=out/'native-cli';command=ns['compile_command'](repo/'current_geometry.c',exe)
  r['native_build_exit']=rec.run(command,cwd=repo,check=False,timeout=1200)[0]['actual_process_returncode']
  if r['native_build_exit']==0:
   row,stdout,stderr=rec.run(['python3','-B',str(repo/'tests/run_tests.py'),str(exe)],cwd=repo,check=False,timeout=None);r['native_runner_exit']=row['actual_process_returncode']
   matches=[line[len(b'GEOMETRY_TEST_RESULT '):] for line in stdout.splitlines() if line.startswith(b'GEOMETRY_TEST_RESULT ')];assert len(matches)==1;native=json.loads(matches[0]);r['native_original_result']=native;items=[x for x in native['cases'] if x['scene']==name];assert len(items)==1;r['I11_original_case']=items[0]
except BaseException:r['errors'].append(traceback.format_exc())
finally:
 try:r['source_after']=guard()
 except BaseException:r['errors'].append(traceback.format_exc())
 resource.setrlimit(resource.RLIMIT_STACK,stack_before)
 r['ended_utc']=now();r['passed']=not r['errors'] and r['comparison_exit']==0 and r['native_build_exit']==0 and r['native_runner_exit']==0 and r.get('I11_original_case',{}).get('status')=='pass';r['exit']=0 if r['passed'] else 1;cap.dump(out/'receipt.json',r)
print(json.dumps({k:r.get(k) for k in ['sha','comparison_exit','native_build_exit','native_runner_exit','I11_original_case','errors','passed']},ensure_ascii=False),flush=True)
raise SystemExit(r['exit'])
