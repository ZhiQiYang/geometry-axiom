"""Run the three original v3 pre-performance stages once; never starts perf/profile."""
import argparse,datetime,hashlib,importlib.util,json,os,traceback
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--sha',required=True);a=p.parse_args();F=a.sha;tag=F[:8]
repo=Path('/tmp/train337-323-'+tag+'-source');out=Path('/workspace/train337-323-'+tag+'-v3-r1');launch=Path('/workspace/train337-323-'+tag+'-preperf-launch');three=repo.parent/('train337-323-'+tag+'-three')
assert not out.exists() and not launch.exists();launch.mkdir()
r=json.loads((three/'receipt.json').read_text());assert r.get('ended_utc') and r.get('source_sha')==F
assert r.get('source_after',{}).get('head')==F and r.get('source_after',{}).get('status')==''
C=Path('/workspace/geo288-main-merge-20261023/native-final-tools/capture.py');assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env['PATH']='/workspace/geo261-environment/bin:'+env['PATH']
for n in ['NODE_OPTIONS','PYTHONOPTIMIZE','LD_PRELOAD']:env.pop(n,None)
rec=cap.Recorder(launch,env,F)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
report={'sha':F,'repo':str(repo),'out':str(out),'started_utc':utc(),'ended_utc':None,'commands':rec.rows,'stages':[],'errors':[],'three_original_run_exit':r.get('original_run_exit'),'performance_or_profile_started':False,'base':'b74f9a2ae7ade1555b9be45283adecc097fb76e3','main':'adbaebf9c73ea6801d7b4d5214e4b846b132923b'}
try:
 for stage in ['prepare','build','compare']:
  rec.run(['df','-B1','/tmp','/workspace'],cwd=repo,check=True,timeout=30)
  command=['python3','-B','/tmp/geo323-merge-20261023/acceptance-tools-v3/run.py','--repo',str(repo),'--sha',F,'--base',report['base'],'--main',report['main'],'--out',str(out),'--heavy-lock','/tmp/g261r3/heavy.lock','--stage',stage]
  row={'stage':stage,'argv':command,'started_utc':utc(),'actual_exit':None,'ended_utc':None};report['stages'].append(row);cap.dump(launch/'receipt.json',report)
  result=rec.run(command,cwd=repo,check=False,timeout=None)[0];row.update(actual_exit=result['actual_process_returncode'],ended_utc=utc(),command_directory=result['directory']);cap.dump(launch/'receipt.json',report)
except BaseException:report['errors'].append(traceback.format_exc())
finally:
 report['ended_utc']=utc();report['launch_exit']=int(bool(report['errors']) or len(report['stages'])!=3 or any(x['actual_exit']!=0 for x in report['stages']));cap.dump(launch/'receipt.json',report)
print(json.dumps({'sha':F,'stages':report['stages'],'errors':report['errors'],'launch_exit':report['launch_exit'],'perf_started':False},ensure_ascii=False),flush=True)
raise SystemExit(report['launch_exit'])
