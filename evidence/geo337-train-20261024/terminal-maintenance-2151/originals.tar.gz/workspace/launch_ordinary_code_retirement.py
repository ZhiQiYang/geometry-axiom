import hashlib
import importlib.util
import json
import os
from pathlib import Path

F='791e53d72fc0ed34331c193132ca0db4f3734a8a'
DRIVER=Path('/workspace/retire_completed_code_checkouts.py')
OUT=Path('/workspace/ordinary-code-retirement-launch-20261023')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='92188ff404f3d0e226924f916e94f21c2357c20bfdc291f299ad9497fb6589c0'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in ('NODE_OPTIONS','PYTHONOPTIMIZE'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,F)
cap.dump(OUT/'launch-context.json',dict(source_sha=F,driver_sha256=sha(DRIVER),outer_timeout=None,free_bytes={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']},purpose='Retire only 1229 individually verified ordinary code files from four terminal checkouts; retained Git blobs reconstruct them. No receipts, fixtures, Git metadata, or controlled proof sources are removed.'))
row,out,err=rec.run(['python3','-B',str(DRIVER)],cwd='/workspace/geometry-axiom',timeout=None,check=False,source_variant='root-owned-terminal-code-retirement')
cap.dump(OUT/'receipt.json',dict(source_sha=F,driver_sha256=sha(DRIVER),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
