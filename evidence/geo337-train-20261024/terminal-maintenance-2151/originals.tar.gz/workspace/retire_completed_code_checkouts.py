"""Retire exact, Git-reconstructible code files from four completed checkouts."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import stat

OUT = Path('/workspace/ordinary-code-retirement-20261023')
INPUTS = [
    ('/workspace/old-code-checkout-preflight-20261023/CANDIDATES.json',
     '692b8c032f2f5790622354f85ce1490955525218808b6b4413cb254cf0ed4e10', ['p3-source', 'html-source']),
    ('/workspace/old-code-checkout-workspace-preflight-20261023/CANDIDATES.json',
     '98b2ac7c4cf3504737492c9d76bc21a6f71281a1adec2a9332460321858303e1', ['p52-final-3d']),
    ('/workspace/old-code-ae74-preflight-20261023/CANDIDATES.json',
     '1bcc5033256ac97754a1b24ecf5cbeee127015c19a4556404f08333507912585', ['318-ae74']),
]
SUMMARIES = [
    ('/workspace/old-code-checkout-preflight-20261023/SUMMARY.json',
     '192027e2c6524920cfa5772a3ee1978fb8e446ac3da453d9a4d543109c46b8d6'),
    ('/workspace/old-code-checkout-workspace-preflight-20261023/P52_FINAL_SOURCE_SUMMARY.json',
     '865c8176e6802c41607d4264d67ec455aed592f6ffb38eb9154e3b5d897d4588'),
    ('/workspace/old-code-ae74-preflight-20261023/SUMMARY.json',
     '5d3ab92b2e3040a69930e6ee4cf114b15fe507f3cb7727feb28d4f88f7fa1441'),
]
ROOTS = {'/tmp/g261p3/source-final', '/tmp/g261htmlseal/html-source',
         '/workspace/geo288-main-merge-20261023/p52-final-source-3d681636',
         '/workspace/geo318-reading-a-work'}
FORBIDDEN = {'.git', 'fixtures', 'fixture', 'evidence', 'raw', 'trace', 'traces',
             'mutant', 'mutants', 'withdrawn', 'golden', 'goldens', 'data', '__pycache__'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def free():
    return {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ['/workspace', '/tmp']}

def safe_file(path, item):
    for parent in path.parents:
        assert stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(), str(parent)
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    values = dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, bytes=s.st_size,
                  mtime_ns=s.st_mtime_ns, nlink=s.st_nlink)
    assert all(values[k] == item[k] for k in values), str(path)
    data = path.read_bytes()
    assert sha(data) == item['sha256']
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == item['git_blob']

def main():
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('capture', '/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
    cap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cap)
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
    rec = cap.Recorder(OUT, env, '791e53d72fc0ed34331c193132ca0db4f3734a8a')
    result = dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  inputs=INPUTS, summaries=SUMMARIES, removed=[], exit_code=1, free_before=free(),
                  method='Exact regular-file unlink only; no Git writes or sparse/index/config changes. Selected old code is reconstructible from retained Git blobs; other files remain physical.',
                  reserved_roots=sorted(ROOTS))

    def git(case, *args, data=None):
        row, stdout, stderr = rec.run(['git', *args], cwd=Path(case['repo']), data=data,
                                      check=False, source_sha=case['head'],
                                      source_variant='read-only-terminal-checkout-retirement')
        assert row['actual_process_returncode'] == 0, args
        return stdout

    try:
        cases, receipts = [], []
        for filename, pin, names in INPUTS:
            data = Path(filename).read_bytes()
            assert sha(data) == pin
            found = [x for x in json.loads(data)['cases'] if x['case'] in names]
            assert {x['case'] for x in found} == set(names)
            cases += found
        for filename, pin in SUMMARIES:
            data = Path(filename).read_bytes()
            assert sha(data) == pin
            summary = json.loads(data)
            receipts += ([x['terminal_receipt'] for x in summary['proposed']]
                         if 'proposed' in summary else [summary['terminal_receipt']])
        assert {x['repo'] for x in cases} == ROOTS
        assert sum(len(x['ordinary_sources']) for x in cases) == 1229
        for receipt in receipts:
            p = Path(receipt['path'])
            assert p.stat().st_size == receipt['bytes'] and sha(p.read_bytes()) == receipt['sha256']
        before = {}
        for case in cases:
            repo = Path(case['repo'])
            assert git(case, 'rev-parse', 'HEAD').decode().strip() == case['head']
            assert git(case, 'rev-parse', 'HEAD^{tree}').decode().strip() == case['tree']
            assert not git(case, 'status', '--porcelain=v1', '-z', '--untracked-files=all')
            assert not git(case, 'ls-files', '--others', '--ignored', '--exclude-standard', '-z')
            assert not git(case, 'diff', '--cached', '--name-only')
            stage = git(case, 'ls-files', '--stage', '-z')
            assert sha(stage) == case['index_stage_sha256']
            index = Path(git(case, 'rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
            before[case['repo']] = dict(index=str(index), index_sha256=sha(index.read_bytes()), stage_sha256=sha(stage))
            blobs = []
            for item in case['ordinary_sources']:
                rel = Path(item['path'])
                assert not rel.is_absolute() and '..' not in rel.parts
                assert not (FORBIDDEN & {p.lower() for p in rel.parts})
                assert rel.suffix in {'.c', '.h', '.inc', '.py', '.js', '.css', '.html'}
                safe_file(repo / rel, item)
                assert (item['git_mode'] + ' ' + item['git_blob'] + ' 0\t' + item['path']).encode() in stage.split(b'\0')
                blobs.append(item['git_blob'])
            available = git(case, 'cat-file', '--batch-check', data=('\n'.join(blobs) + '\n').encode()).decode().splitlines()
            assert len(available) == len(blobs)
            for item, line in zip(case['ordinary_sources'], available):
                assert line == item['git_blob'] + ' blob ' + str(item['bytes'])
        cap.dump(OUT / 'BEFORE.json', before)
        spec2 = importlib.util.spec_from_file_location('consumer_guard', '/workspace/clear_terminal_chrome_caches.py')
        guard = importlib.util.module_from_spec(spec2)
        spec2.loader.exec_module(guard)
        guard.OUT = OUT
        guard.consumer_check(sorted(ROOTS))
        for case in cases:
            repo = Path(case['repo'])
            for item in case['ordinary_sources']:
                p = repo / item['path']
                safe_file(p, item)
                p.unlink()
                result['removed'].append(dict(path=str(p), git_blob=item['git_blob'], sha256=item['sha256']))
            after = git(case, 'status', '--porcelain=v1', '-z', '--untracked-files=all')
            entries = [x for x in after.split(b'\0') if x]
            assert all(x.startswith(b' D ') for x in entries)
            assert {x[3:].decode() for x in entries} == {x['path'] for x in case['ordinary_sources']}
            old = before[case['repo']]
            assert sha(Path(old['index']).read_bytes()) == old['index_sha256']
            assert sha(git(case, 'ls-files', '--stage', '-z')) == old['stage_sha256']
            assert git(case, 'rev-parse', 'HEAD').decode().strip() == case['head']
        for receipt in receipts:
            assert sha(Path(receipt['path']).read_bytes()) == receipt['sha256']
        result['removed_allocated_bytes'] = sum(x['allocated_bytes'] for c in cases for x in c['ordinary_sources'])
        assert len(result['removed']) == 1229
        result['exit_code'] = 0
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_after'] = free()
        cap.dump(OUT / 'RESULT.json', result)
        print(json.dumps({k: v for k, v in result.items() if k != 'removed'}))

if __name__ == '__main__':
    main()
