import hashlib
import importlib.util
import json
import os
from pathlib import Path

F='791e53d72fc0ed34331c193132ca0db4f3734a8a'
DRIVER=Path('/workspace/clear_terminal_browser_metrics_spares.py')
OUT=Path('/workspace/cache-terminal-metrics-execution-launch-20261023')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DRIVER)=='ec607be081c5e57336af8bee03addaecf8a614178a29b1a9f35115771c64639b'
assert sha(CAPTURE)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('capture',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for key in ('NODE_OPTIONS','PYTHONOPTIMIZE'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,F)
cap.dump(OUT/'launch-context.json',dict(source_sha=F,driver_sha256=sha(DRIVER),outer_timeout=None,free_bytes={p:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/workspace','/tmp']},purpose='Unlink only 13 exact all-zero 4MiB BrowserMetrics spare cache files from terminal Chrome profiles; retain profiles and original receipts.'))
row,out,err=rec.run(['python3','-B',str(DRIVER)],cwd='/workspace/geometry-axiom',timeout=None,check=False,source_variant='root-owned-terminal-zero-pma-retirement')
cap.dump(OUT/'receipt.json',dict(source_sha=F,driver_sha256=sha(DRIVER),command=row,exit_code=row['actual_process_returncode']))
print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(row['actual_process_returncode'])
