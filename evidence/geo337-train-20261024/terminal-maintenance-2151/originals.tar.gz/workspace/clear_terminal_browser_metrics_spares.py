"""Root-only maintenance: unlink exactly 13 reviewed, all-zero Chrome PMA spares."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import sys
import traceback

PLAN = Path('/workspace/cache-terminal-preflight-20261023/METRICS_COMPONENT_PLAN.json')
PLAN_PIN = 'fd32c86a7a388b4066e4a54c13ed2884e00e82adfc18f33f127f3c9a8fc52e23'
PEER = Path('/tmp/train337-adversarial/TERMINAL_CHROME_METRICS_COMPONENT_SCOPE_PEER.json')
PEER_PIN = '34e3991d489e0d4bb6f61438d838b277410eb803c55501aa88badcb2614b2376'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
ZERO_4M_SHA256 = 'bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8'
OUT = Path('/workspace/cache-terminal-metrics-execution-20261023')
EXACT_PATHS = {
    '/tmp/g261r3/tmp/seven-final/assembly/geometry-cdp-6EiFXZ/BrowserMetrics-spare.pma',
    '/tmp/g261r3/tmp/seven-final/canvas/geometry-cdp-R9xr2x/BrowserMetrics-spare.pma',
    '/tmp/g261r3/tmp/seven-final/grid/geometry-cdp-GDPBTQ/BrowserMetrics-spare.pma',
    '/tmp/g261r3/tmp/seven-final/space/geometry-tests/space-model-498878/chrome-profile/BrowserMetrics-spare.pma',
    '/tmp/g288p88o1/tmp/workflow/canvas/chrome-profile/BrowserMetrics-spare.pma',
    '/tmp/g288p88o2/tmp/workflow/canvas/chrome-profile/BrowserMetrics-spare.pma',
    '/tmp/g288p88o3/tmp/workflow/canvas/chrome-profile/BrowserMetrics-spare.pma',
    '/tmp/g288p88q/fixed/tmp/workflow/grid/geometry-cdp-jxTJea/BrowserMetrics-spare.pma',
    '/tmp/g288p88q/restored/tmp/workflow/grid/geometry-cdp-6ZAM4b/BrowserMetrics-spare.pma',
    '/tmp/g288p88q/withdrawn/tmp/workflow/grid/geometry-cdp-aPCet6/BrowserMetrics-spare.pma',
    '/tmp/g288p88r/fixed/tmp/workflow/grid/geometry-cdp-xNjZAd/BrowserMetrics-spare.pma',
    '/tmp/g288p88r/restored/tmp/workflow/grid/geometry-cdp-ui2Z0h/BrowserMetrics-spare.pma',
    '/tmp/g288p88r/withdrawn/tmp/workflow/grid/geometry-cdp-HEfAHk/BrowserMetrics-spare.pma',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    assert not sys.flags.optimize, 'Python assertions must remain enabled'
    guard_raw = GUARD.read_bytes()
    assert sha(guard_raw) == GUARD_PIN
    # Reuse only the original reviewed read-only guards; its main is never called.
    guard = {'__name__': '_pinned_terminal_cache_guards', '__file__': str(GUARD)}
    exec(compile(guard_raw, str(GUARD), 'exec'), guard)
    guard['OUT'] = OUT
    guard['ancestors'](OUT)
    OUT.mkdir(exist_ok=False)
    result = dict(schema='exact-terminal-zero-browser-metrics-retirement/1',
        argv=sys.argv, started_utc=now(), tool_sha256=sha(Path(__file__).read_bytes()),
        plan_sha256=PLAN_PIN, scope_peer_sha256=PEER_PIN, original_guard_sha256=GUARD_PIN,
        policy='Root reserves these 13 historical Chrome profiles against reuse during maintenance.',
        removed=[], exit_code=1, mutation_attempted=False, free_before=guard['free'](),
        limits=['Accessible proc fields only; unknown OS consumers remain explicitly recorded.',
                'Only 13 exact file unlinks; no profile/directory deletion, component-cache cleanup, Git or source writes.',
                'Allocated bytes are not observed filesystem free gain.'])

    def save():
        guard['dump']('RESULT.json', result)

    def receipts(plan):
        for row in plan['terminal_receipts']:
            path = Path(row['path'])
            guard['ancestors'](path)
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode) and info.st_size == row['bytes'], str(path)
            assert guard['digest'](path) == row['sha256'], str(path)

    def spare(row):
        path = Path(row['path'])
        assert str(path) in EXACT_PATHS and path.name == 'BrowserMetrics-spare.pma'
        assert str(path.parent) == row['profile']
        assert row['kind'] == 'BrowserMetrics-spare.pma' and not row['directories']
        assert len(row['files']) == 1
        item = row['files'][0]
        assert item['relative'] == '.' and item['size'] == item['allocated_bytes'] == 4 * 1024 * 1024
        assert item['sha256'] == ZERO_4M_SHA256 and item['all_zero'] is True and item['nonzero_bytes'] == 0
        guard['identity'](path, item, is_file=True)
        assert path.lstat().st_blocks * 512 == item['allocated_bytes']
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                assert block.count(0) == len(block), str(path)
        guard['identity'](path, item, is_file=True)
        return path

    save()
    try:
        assert guard['digest'](PLAN) == PLAN_PIN and guard['digest'](PEER) == PEER_PIN
        plan = json.loads(PLAN.read_text())
        peer = json.loads(PEER.read_text())
        assert peer['exit_code'] == 0 and peer['check_count'] == 619 and not peer['findings']
        assert peer['sha256'] == PLAN_PIN
        candidates = [row for row in plan['candidates'] if row['kind'] == 'BrowserMetrics-spare.pma']
        assert len(candidates) == 13 and {row['path'] for row in candidates} == EXACT_PATHS
        assert len({(row['files'][0]['dev'], row['files'][0]['inode']) for row in candidates}) == 13
        assert sum(row['allocated_file_bytes'] for row in candidates) == 54_525_952
        receipts(plan)
        for row in candidates:
            spare(row)
        guard['consumer_check'](sorted({row['profile'] for row in candidates}))
        receipts(plan)
        for row in candidates:
            path = spare(row)
            result['mutation_attempted'] = True
            save()
            path.unlink()
            result['removed'].append(str(path))
            save()
        assert len(result['removed']) == 13
        assert all(not Path(row['path']).exists() and not Path(row['path']).is_symlink() for row in candidates)
        assert all(Path(row['profile']).is_dir() for row in candidates)
        receipts(plan)
        result.update(exit_code=0, removed_allocated_file_bytes=54_525_952,
                      profile_directories_preserved=True, original_receipts_preserved=True)
    except BaseException:
        result['error'] = traceback.format_exc()
    finally:
        result['ended_utc'] = now()
        result['free_after'] = guard['free']()
        result['observed_free_delta'] = {p: result['free_after'][p] - result['free_before'][p]
                                         for p in result['free_before']}
        save()
        print(json.dumps({key: value for key, value in result.items() if key != 'removed'}, ensure_ascii=False))
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
