# 新來源準備：預留量綁定實際工作掛載點

狀態：僅外部工具與 metadata 反證；未物化新來源、未執行產品或 dependency closure。新來源 S=82c922a3941525d3a094ac0158bdc7dea57ea360。

原值 25,165,824 B＝24 MiB，既有文書「25 MiB」為單位誤植。數值完全保留；舊已釘 README/COMMAND 不覆寫，UNIT_CORRECTION.md 及本新版更正文書。未傳 --reserve-anchor 時，原 /workspace 行為不變。新模式只接受 fresh pool 的真實既存父目錄，禁止 existing_pool；pool/cache/out 父目錄必須同一 st_dev，新 reserve 不得小於 25,165,824 B。

原 source-by-device 公式不變：pool 與 seed 各自累加頁面向上取整來源 bytes、owner index bytes、16 MiB metadata，再在所選 anchor device 加原 24 MiB reserve。free 恰等 required 可過，少 1 B 必拒；這是 source admission，不能當 full123 runtime peak 證明。plan/report 在正式 clone admission 前產生沿原方法，實際 free 在它們落盤後再量。

五組真 subprocess／原 c387 完整流 0/1/0：錯 anchor、跨 device、reserve 低 1 B、撤回新路由而錯加到 workspace、free 低 1 B。執行的是原工具抽取的 exact AST 與假 filesystem metadata，沒有執行來源、Git、dependencies、SHM 或編譯；撤回只在小測試 AST 內，原工具不改。

原 604 architecture、五 fixture、metadata closure、123/3 retired、clone、private index、nlink 與 Git bytes guards 不變。EXACT_REVERSE_CHECK.json 證明除列出的配置表達式／新 guard 以外，反向移除新變更可重建原 0859 全檔 bytes；source_closure_facts.py exact 不變。

寫入去向見 WRITE_ROUTES.json。特別是原 mutate import 會呼叫 tempfile.gettempdir，因此新模式顯式將 TMPDIR/TMP/TEMP 指向新 out；不以「只讀 closure」忽略這個 temporary probe。Linux binaries.OUT_DIR=/tmp/geometry-tests 僅被宣告，source_closure_facts 只算 fingerprint，不呼叫 build/mkdir。完整 native 仍有 /tmp cache 原限制，這項適配沒有處理或聲稱解掉它。

所有真 SHM 操作仍必由 root 正式 require_escalated，source/launcher 的原容量、memory、lease 與互斥檢查保持。root outer 的完整 stream/capture 也要落 SHM，本小工具稿本身在 WS 只讀；不偷偷把正式 stdout 複本留回 WS。舊 Git objects 是只讀 alternate，沒有移動或複製。新的 out 使用 F10-source-preparation-reserve-anchor，避免覆寫任何舊未成功準備收據。
