"""Read original Python source/fingerprint functions only; never build or test."""
from pathlib import Path
import json,sys
root=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(root/'tests'),str(root)]
import mutate
import mutation_bridge
import binaries
source=mutate.Sources(root)
mutants=mutate.MUTANTS
bridge=[m for m in mutants if m.get('binary')=='bridge']
print(json.dumps({'scope':'original source/definition/oracle/fingerprint facts only; no C or test execution',
 'mutant_ids':[m['id']for m in mutants],
 'retired_ids':[m['id']for m in mutants if m.get('retired')],
 'closure':source.closure,'closure_files':source.hashes,
 'oracle_hashes':{m['id']:mutation_bridge.oracle_hash(m,root)for m in bridge},
 'restored_methods':mutation_bridge.RESTORED,
 'bridge_fingerprint':binaries.compute_fingerprint(binaries.BY_NAME['bridge'])},sort_keys=True))
