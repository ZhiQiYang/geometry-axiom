"""Root-only fresh full validation pool and independent mutable ledger seed.
Default is metadata plan only. No C, mutation or acceptance test is executed.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,stat,subprocess,sys,time

EXCLUDED=('evidence/','tests/evidence/','tests/release-evidence/')
FIXTURES=(
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
 'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas',
 'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
 'tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene',
 'geometry-web/docs/evidence/issue48-34a6222-20261005/archives/1280-full.gcanvas',
)
SEED_OMIT=('geometry-web/docs/','geometry-web/prototypes/')

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def reserve_anchor(requested,pool,cache,out,existing_pool,reserve_bytes):
 # Default preserves the original workspace reserve. Relocation is explicit,
 # fresh-only, canonical and tied to every actual write target's device.
 if requested==Path('/workspace'):return requested
 need(requested.is_absolute()and requested==requested.resolve()and requested.is_dir(),'reserve anchor must be a real existing absolute directory')
 need(not existing_pool,'relocated reserve requires a fresh pool')
 need(requested==pool.parent,'reserve anchor must equal the fresh pool existing parent')
 need(reserve_bytes>=25165824,'relocated reserve must preserve at least 25165824 bytes (24 MiB)')
 dev=requested.stat().st_dev
 need(all(t.parent.stat().st_dev==dev for t in (pool,cache,out)),'relocated reserve requires pool/cache/out on the same device')
 return requested
def main():
 ap=argparse.ArgumentParser()
 for n in ('owner','pool','cache','out'):ap.add_argument('--'+n,type=Path,required=True)
 ap.add_argument('--sha',required=True);ap.add_argument('--materialize',action='store_true');ap.add_argument('--existing-pool',action='store_true',help='Only after root separately completed and audited the old native ROOT transition')
 ap.add_argument('--reserve-workspace-bytes',type=int,required=True,help='Resource headroom only, not a product threshold')
 ap.add_argument('--reserve-anchor',type=Path,default=Path('/workspace'),help='Default preserves workspace reserve; explicit relocation requires fresh same-device outputs')
 a=ap.parse_args();need(re.fullmatch('[0-9a-f]{40}',a.sha),'explicit full source SHA')
 a.owner=a.owner.resolve();a.pool=a.pool.resolve();a.cache=a.cache.resolve();a.out=a.out.resolve()
 seed=a.cache/'_bridge-work'/a.sha/'repo'
 targets=(a.pool,a.cache,a.out)
 for t in targets:
  need(t.is_relative_to(Path('/workspace'))or t.is_relative_to(Path('/tmp'))or any(t!=r and t.is_relative_to(r)for r in (Path('/dev/shm/geo337-F9-browsers-20261025'),Path('/dev/shm/geometry-axiom-geo337-20261025'))),'private writable output only')
  need(t.parent.is_dir(),'existing output parent required: '+str(t))
  need(t.is_dir()if t==a.pool and a.existing_pool else not t.exists(),'fresh output or explicit existing pool required: '+str(t))
  need(not t.is_relative_to(a.owner)and not a.owner.is_relative_to(t),'owner/output must not overlap')
 need(all(not x.is_relative_to(y)and not y.is_relative_to(x)for i,x in enumerate(targets)for y in targets[i+1:]),'independent pool/cache/report paths')
 need(a.reserve_workspace_bytes>=0,'nonnegative resource reserve')
 reserve_path=reserve_anchor(a.reserve_anchor,a.pool,a.cache,a.out,a.existing_pool,a.reserve_workspace_bytes)
 a.out.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','GEOMETRY_','MUTATE_'))and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS')}
 env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
 if reserve_path!=Path('/workspace'):env.update(TMPDIR=str(a.out),TMP=str(a.out),TEMP=str(a.out))
 commands=[];report={'source_sha':a.sha,'pool':str(a.pool),'seed':str(seed),'cache':str(a.cache),'materialized':False,'formal_executed':False,'existing_pool':a.existing_pool,'exit':1}
 def git(*args,cwd=a.owner,data=None):
  d=a.out/'commands'/f'{len(commands)+1:04d}';d.mkdir(parents=True)
  argv=['git','-c','gc.auto=0','-c','maintenance.auto=false',*map(str,args)];start=time.time()
  r=subprocess.run(argv,cwd=cwd,env=env,input=data,capture_output=True)
  (d/'stdout.bin').write_bytes(r.stdout);(d/'stderr.bin').write_bytes(r.stderr)
  if data is not None:(d/'stdin.bin').write_bytes(data)
  row={'argv':argv,'cwd':str(cwd),'source_sha':a.sha,'started_epoch':start,'ended_epoch':time.time(),'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}
  dump(d/'RESULT.json',row);commands.append(row);need(r.returncode==0,'Git failed; original streams at '+str(d));return r.stdout
 def entry_rows(raw,prefix=''):
  for row in raw.rstrip(b'\0').split(b'\0'):
   if not row:continue
   meta,name=row.split(b'\t',1);mode,kind,oid,size=meta.split()
   yield prefix+os.fsdecode(name),mode.decode(),kind.decode(),oid.decode(),None if size==b'-'else int(size)
 try:
  need(git('rev-parse',a.sha+'^{commit}').decode().strip()==a.sha,'fixed commit exists')
  need(git('rev-parse','--show-object-format').strip()==b'sha1','Git SHA1 blob identity required')
  files={};todo=['']
  while todo:
   prefix=todo.pop();spec=a.sha+(':'+prefix.rstrip('/')if prefix else '')
   for n,mode,kind,oid,size in entry_rows(git('ls-tree','-z','-l',spec),prefix):
    if kind=='tree':
     if n+'/'not in EXCLUDED:todo.append(n+'/')
    else:
     need(kind=='blob'and mode in ('100644','100755'),'regular blob closure only: '+n)
     files[n]={'mode':mode,'oid':oid,'bytes':size}
  for n in FIXTURES:
   rows=list(entry_rows(git('ls-tree','-z','-l',a.sha,'--',n)));need(len(rows)==1 and rows[0][0]==n,'mandatory original fixture missing '+n)
   name,mode,kind,oid,size=rows[0];need(kind=='blob'and mode in ('100644','100755'),'fixture regular blob');files[n]={'mode':mode,'oid':oid,'bytes':size}
  manifest=json.loads(git('show',a.sha+':geometry-core/domain-decoupling/product-architecture.json'))
  declared={x['path']for x in manifest['sources']+manifest['exclusions']}
  need(declared<=files.keys(),'all declared architecture sources AND exclusions required')
  selected={n for n in files if not n.startswith(SEED_OMIT)or n in declared or n.endswith(('.c','.h','.inc'))or n in FIXTURES}
  # Full pool keeps every docs/prototype/guide/vendor file. Only the mutation
  # seed omits nondeclared docs/prototype payloads, never a C/header or fixture.
  patterns={'pool':'/*\n'+''.join('!/'+n+'\n'for n in EXCLUDED)+''.join('/'+n+'\n'for n in FIXTURES),
            'seed':''.join('/'+n+'\n'for n in sorted(selected))}
  sets={'pool':set(files),'seed':selected}
  budget={label:{'files':len(names),'logical_bytes':sum(files[n]['bytes']for n in names),'allocated_floor_bytes':sum((files[n]['bytes']+4095)//4096*4096 for n in names)}for label,names in sets.items()}
  report.update(layout=budget,architecture_declared_count=len(declared),fixture_paths=list(FIXTURES),reserve_workspace_bytes=a.reserve_workspace_bytes,reserve_anchor=str(reserve_path))
  dump(a.out/'SOURCE_MANIFEST.json',{'source_sha':a.sha,'files':files,'seed_paths':sorted(selected),'architecture_paths':sorted(declared),'fixture_paths':list(FIXTURES)})
  for label,text in patterns.items():(a.out/(label+'-sparse-checkout.txt')).write_text(text)
  if not a.materialize:report['exit']=0;return 0
  # Ordinary writes create independent source inodes; objects alone use Git's
  # readonly alternates. No cp/reflink/hardlink or existing checkout is reused.
  owner_index=Path(git('rev-parse','--git-path','index').decode().strip())
  if not owner_index.is_absolute():owner_index=a.owner/owner_index
  index_bytes=owner_index.stat().st_size
  bydev={};anchors={}
  for label,target in [('pool',a.pool),('seed',a.cache)]:
   if label=='pool'and a.existing_pool:continue
   st=target.parent.stat();anchors[st.st_dev]=target.parent
   bydev[st.st_dev]=bydev.get(st.st_dev,0)+budget[label]['allocated_floor_bytes']+index_bytes+16*1024*1024
  reservedev=reserve_path.stat().st_dev;anchors[reservedev]=reserve_path;bydev[reservedev]=bydev.get(reservedev,0)+a.reserve_workspace_bytes
  admission=[]
  for dev,needed in bydev.items():
   fs=os.statvfs(anchors[dev]);free=fs.f_bavail*fs.f_frsize;admission.append({'device':dev,'path':str(anchors[dev]),'free':free,'required':needed});need(free>=needed,'storage admission failed; no checkout started')
  report['storage_admission']=admission
  for label,target in [('pool',a.pool),('seed',seed)]:
   target.parent.mkdir(parents=True,exist_ok=True)
   if not(label=='pool'and a.existing_pool):
    git('clone','--shared','--no-hardlinks','--no-checkout',a.owner,target)
    need(sorted(p.name for p in target.iterdir())==['.git'],'clone must not materialize default head')
    git('config','--local','core.autocrlf','false',cwd=target);git('config','--local','core.sparseCheckout','true',cwd=target);git('config','--local','core.sparseCheckoutCone','false',cwd=target)
    (target/'.git/info/sparse-checkout').write_text(patterns[label])
    git('checkout','--detach',a.sha,cwd=target)
   need(git('rev-parse','HEAD',cwd=target).decode().strip()==a.sha,'fixed source head')
   need(not git('status','--porcelain=v1','--untracked-files=all',cwd=target),'fresh checkout clean')
   materialized=set();rows=[]
   for n in sorted(sets[label]):
    path=target/n;st=path.lstat();need(stat.S_ISREG(st.st_mode)and(not(label=='seed'or not a.existing_pool)or st.st_nlink==1),'independent writable source inode '+n)
    raw=path.read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();need(oid==files[n]['oid'],'exact Git source bytes '+n)
    rows.append({'path':n,'oid':oid,'bytes':len(raw),'device':st.st_dev,'inode':st.st_ino,'nlink':st.st_nlink})
   for raw in git('ls-files','-t','-z',cwd=target).rstrip(b'\0').split(b'\0'):
    if raw and raw[:1]!=b'S':materialized.add(os.fsdecode(raw[2:]))
   need(sets[label]<=materialized if label=='pool'and a.existing_pool else materialized==sets[label],'required or exact sparse materialization inventory')
   dump(a.out/(label+'-materialized.json'),rows)
  # Compare original public closure/fingerprint functions in separate fresh
  # Python interpreters. No original build, unittest, mutation or --check here.
  facts={}
  for label,target in [('pool',a.pool),('seed',seed)]:
   argv=[sys.executable,'-B',str(Path(__file__).with_name('source_closure_facts.py')),str(target)]
   r=subprocess.run(argv,cwd=target,env=env,capture_output=True)
   (a.out/(label+'-closure.stdout.bin')).write_bytes(r.stdout);(a.out/(label+'-closure.stderr.bin')).write_bytes(r.stderr)
   dump(a.out/(label+'-closure.RESULT.json'),{'argv':argv,'cwd':str(target),'source_sha':a.sha,'actual_exit':r.returncode,'scope':'source metadata only; no compilation or oracle tests'})
   need(r.returncode==0,'original metadata closure read failed '+label);facts[label]=json.loads(r.stdout)
  need(facts['pool']==facts['seed'],'original Sources/oracle/fingerprint/RESTORED closure differs')
  need(len(facts['pool']['mutant_ids'])==123 and len(set(facts['pool']['mutant_ids']))==123 and len(facts['pool']['retired_ids'])==3,'original full123 definitions and3 retired unchanged')
  report['original_metadata_closure_equal']=True
  report['materialized']=True;report['exit']=0;return 0
 except BaseException as exc:
  report['error']=repr(exc);raise
 finally:
  report['commands']=commands;dump(a.out/'RESULT.json',report)
if __name__=='__main__':raise SystemExit(main())
