"""Exact production AST, deterministic filesystem metadata only; no source imports."""
import ast, copy, hashlib, json, sys
from pathlib import Path as RealPath, PurePosixPath
from types import SimpleNamespace

TOOL=RealPath(__file__).with_name('prepare_fresh_sources.py')
CASE,MODE=sys.argv[1:]
tree=ast.parse(TOOL.read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='reserve_anchor')
needfn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='need')
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main')
start=next(i for i,n in enumerate(main.body)if isinstance(n,ast.Try))
body=main.body[start].body
first=next(i for i,n in enumerate(body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='bydev'for t in n.targets))
last=next(i for i,n in enumerate(body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Subscript)and isinstance(t.value,ast.Name)and t.value.id=='report'for t in n.targets)and ast.unparse(n.targets[0])=="report['storage_admission']")
budgetcode=copy.deepcopy(body[first:last])
fn=copy.deepcopy(fn)
if MODE=='withdrawn':
    guards={'wrong-anchor':'reserve anchor must equal','cross-mount':'relocated reserve requires pool','low-reserve':'relocated reserve must preserve'}
    if CASE in guards:
        found=[n for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='need'and len(n.args)==2 and isinstance(n.args[1],ast.Constant)and str(n.args[1].value).startswith(guards[CASE])]
        assert len(found)==1
        found[0].args[0]=ast.Constant(True)
    elif CASE=='actual-mount-budget':
        # Restore the old hardcoded reserve placement in this tiny AST only.
        replace=ast.parse("reservedev=Path('/workspace').stat().st_dev; anchors[reservedev]=Path('/workspace'); bydev[reservedev]=bydev.get(reservedev,0)+a.reserve_workspace_bytes").body
        idx=next(i for i,n in enumerate(budgetcode)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='reservedev'for t in n.targets))
        assert len(replace)==3
        budgetcode[idx:idx+3]=replace
    elif CASE=='low-free':
        calls=[n for n in ast.walk(ast.Module(body=budgetcode,type_ignores=[]))if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='need'and isinstance(n.args[-1],ast.Constant)and n.args[-1].value=='storage admission failed; no checkout started']
        assert len(calls)==1
        calls[0].args[0]=ast.Constant(True)
    else:raise AssertionError('unknown case')

dirs={'/workspace':11,'/own':22,'/other':22,'/cross':33}
free={11:1<<40,22:1<<40,33:1<<40}
class FakePath(PurePosixPath):
    def resolve(self):return self
    def is_dir(self):return str(self)in dirs
    def stat(self):return SimpleNamespace(st_dev=dirs[str(self)])
Path=FakePath
ns={'Path':Path,'SimpleNamespace':SimpleNamespace}
exec(compile(ast.fix_missing_locations(ast.Module(body=[needfn,fn],type_ignores=[])),str(TOOL),'exec'),ns)
anchor=Path('/own');pool=anchor/'pool';cache=anchor/'cache';out=anchor/'out';reserve=25165824
assert ns['reserve_anchor'](Path('/workspace'),pool,cache,out,True,0)==Path('/workspace'),'default behavior changed'
assert ns['reserve_anchor'](anchor,pool,cache,out,False,reserve)==anchor
if CASE=='wrong-anchor':anchor=Path('/other')
if CASE=='cross-mount':cache=Path('/cross/cache')
if CASE=='low-reserve':reserve-=1
observed=None
try:
    selected=ns['reserve_anchor'](anchor,pool,cache,out,False,reserve)
    if CASE in ('actual-mount-budget','low-free'):
        budget={'pool':{'allocated_floor_bytes':4096},'seed':{'allocated_floor_bytes':8192}}
        expected=4096+8192+2*(12345+16*1024*1024)+reserve
        free[22]=expected
        context={'a':SimpleNamespace(pool=pool,cache=cache,existing_pool=False,reserve_workspace_bytes=reserve),'Path':Path,'reserve_path':selected,'budget':budget,'index_bytes':12345,'os':SimpleNamespace(statvfs=lambda p:SimpleNamespace(f_bavail=free[p.stat().st_dev],f_frsize=1)),'need':ns['need']}
        if MODE!='withdrawn':
            exec(compile(ast.fix_missing_locations(ast.Module(body=budgetcode,type_ignores=[])),str(TOOL),'exec'),context)
            assert context['admission']==[{'device':22,'path':'/own','free':expected,'required':expected}],'exact source-plus-reserve boundary changed'
        free[22]=expected-1
        exec(compile(ast.fix_missing_locations(ast.Module(body=budgetcode,type_ignores=[])),str(TOOL),'exec'),context)
except RuntimeError as e:observed=str(e)
result={'case':CASE,'mode':MODE,'tool_sha256':hashlib.sha256(TOOL.read_bytes()).hexdigest(),'observed_rejection':observed,'scope':'only exact AST and fake filesystem metadata; no source, Git, SHM, locks, imports or compilation'}
print(json.dumps(result,sort_keys=True),flush=True)
assert observed is not None,'reserve-anchor invariant escaped: '+CASE
expected_message={'wrong-anchor':'fresh pool existing parent','cross-mount':'same device','low-reserve':'25165824','actual-mount-budget':'storage admission failed','low-free':'storage admission failed'}[CASE]
assert expected_message in observed,'wrong rejection cause'
