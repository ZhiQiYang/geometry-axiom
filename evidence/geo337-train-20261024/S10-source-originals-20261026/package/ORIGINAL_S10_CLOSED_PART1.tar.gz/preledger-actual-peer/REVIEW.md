# S10 preledger 原件核對

原六項退出碼依序為 **1／0／0／0／0／0**，外層0僅表示收件完成。

帳本123筆中53筆bridge裁判過期：52筆原killed、M110原equivalent；另62 killed、1 crashed、4 equivalent、3 retired。唯一tests/*.py變更是#314範圍測試，因此保守bridge oracle閉包失效。舊byte_restored全true，restoration字樣來自oracle不符，非產品還原損壞。

架構原裁判：334來源／6可信未解析／798依賴／0diagnostics；unit205、product18、#314完整11、adoption15皆0、零skip。原前後SHA／完整stage listing／clean status一致。

只讀封閉原流與不可變Git，沒有讀寫活動來源、重跑測試或將舊F8帳本移標。各原argv、環境、完整輸出位置、SHA256與退出碼見REVIEW.json。
