"""Read completed receipts only; never open live pool, seed, or Git objects."""
from pathlib import Path
import hashlib,json,datetime
B=Path('/dev/shm/geometry-axiom-geo337-20261025/F10-source-preparation-reserve-anchor')
O=Path('/dev/shm/geometry-axiom-geo337-20261025/S10-source-preparation-root-original-20261025')
D=Path('/workspace/geo337-S10-source-preparation-actual-peer-20261025')
S='82c922a3941525d3a094ac0158bdc7dea57ea360'
H=lambda b:hashlib.sha256(b).hexdigest()
bindings={};checks=0
def read(p):
    raw=p.read_bytes();bindings[str(p)]=H(raw);return raw
def J(p):return json.loads(read(p))
def C(ok,msg):
    global checks
    checks+=1
    assert ok,msg
final=J(Path('/workspace/geo337-S10-source-preparation-EXEC_FINAL-20261025.json'))
C(final['status']=='FINISHED'and final['actual_tool_result']['exit_code']==0,'host terminal0')
r=J(B/'RESULT.json');C(bindings[str(B/'RESULT.json')]=='f1e689eb26653609943e7e899aaf6d6e8430b9d0b2291d8e1ee94ebb7c14fdf9','original result pin')
C(r['exit']==0 and r['source_sha']==S and r['materialized']and not r['formal_executed']and not r['existing_pool'],'preparation result semantics')
outer=J(O/'RESULT.json');req=J(O/'REQUEST.json');C(outer['exit_code']==0 and outer['source_sha']==S and outer['command']['actual_process_returncode']==0,'outer true0')
C(req['root_execution_lease']and not req['formal_tests_executed'],'actual lease no formal test')
C(req['tool_sha256']=='8fdfe577cb3f5c3a5da6cfddb2d81fe2bbb5a794bd7a804c3ce13b21bdd2ebcb','actual tool binding')
cd=Path(outer['command']['directory'])
rr=J(cd/'result.json');rq=J(cd/'request.json')
for key,name in [('stdout_sha256','stdout.bin'),('stderr_sha256','stderr.bin')]:C(H(read(cd/name))==rr[key],'outer original '+name)
C(rr['actual_process_returncode']==0 and not rr['timeout_expired'],'outer child true0')
C(rq['command']==req['argv'],'outer exact source argv')
C(req['reserve_bytes_unchanged']==r['reserve_workspace_bytes']==25165824,'same24MiB')
C(req['reserve_anchor']==r['reserve_anchor']==str(B.parent),'same actual anchor')
manifest=J(B/'SOURCE_MANIFEST.json');C(manifest['source_sha']==S,'manifest source')
files=manifest['files'];poolset=set(files);seedset=set(manifest['seed_paths'])
C(len(files)==3763 and len(seedset)==len(manifest['seed_paths'])==2738,'full inventory counts')
C(seedset<=poolset,'seed subset pool')
rows=r['commands'];C(len(rows)==342,'342 actual Git commands')
gitfiles={};stream_bytes=0;allrows=[]
for i,row in enumerate(rows,1):
    d=B/'commands'/f'{i:04d}';rec=J(d/'RESULT.json');C(rec==row,'original command row match')
    C(row['source_sha']==S and row['exit']==0 and row['ended_epoch']>=row['started_epoch'],'command binding/exit/time')
    so=read(d/'stdout.bin');se=read(d/'stderr.bin');stream_bytes+=len(so)+len(se)
    C(H(so)==row['stdout_sha256']and H(se)==row['stderr_sha256'],'original full streams hashes')
    C(row['argv'][:5]==['git','-c','gc.auto=0','-c','maintenance.auto=false'],'original no-maintenance git')
    args=row['argv'][5:]
    if args[0]=='ls-tree':
        spec=args[3];prefix=(spec.split(':',1)[1].rstrip('/')+'/')if ':'in spec else ''
        C(spec.split(':',1)[0]==S,'tree source')
        for item in so.rstrip(b'\0').split(b'\0'):
            if not item:continue
            meta,name=item.split(b'\t',1);mode,kind,oid,size=meta.split();name=prefix+name.decode()
            if kind==b'blob':
                entry={'mode':mode.decode(),'oid':oid.decode(),'bytes':int(size)}
                C(name not in gitfiles or gitfiles[name]==entry,'repeated fixture exact')
                gitfiles[name]=entry
    allrows.append((args,so,se,row))
C(gitfiles==files,'all manifest entries match original complete Git tree streams')
archs=[json.loads(so)for args,so,se,row in allrows if args==['show',S+':geometry-core/domain-decoupling/product-architecture.json']]
C(len(archs)==1,'one original architecture blob')
arch=archs[0];declared=[x['path']for x in arch['sources']+arch['exclusions']]
C(len(declared)==len(set(declared))==604 and set(declared)==set(manifest['architecture_paths'])<=seedset,'complete architecture and seed closure')
C(len(arch['sources'])==334 and len(arch['exclusions'])==270,'architecture exact split')
C(len(manifest['fixture_paths'])==5 and manifest['fixture_paths']==r['fixture_paths']and set(manifest['fixture_paths'])<=seedset,'all five fixtures')
inodes={};closures={}
for label,names in [('pool',poolset),('seed',seedset)]:
    materialized=J(B/(label+'-materialized.json'))
    C(len(materialized)==len(names)and {x['path']for x in materialized}==names,'exact '+label+' set')
    for x in materialized:
        C(x['oid']==files[x['path']]['oid']and x['bytes']==files[x['path']]['bytes'],'recorded raw Git bytes '+label)
        C(x['nlink']==1 and x['device']==26,'recorded independent inode '+label)
    inodes[label]={(x['device'],x['inode'])for x in materialized};C(len(inodes[label])==len(materialized),'unique within '+label)
    logical=sum(files[n]['bytes']for n in names);rounded=sum((files[n]['bytes']+4095)//4096*4096 for n in names)
    C(r['layout'][label]=={'files':len(names),'logical_bytes':logical,'allocated_floor_bytes':rounded},'source byte budget '+label)
    cwd=r[label]if label=='pool'else r['seed']
    statuses=[so for args,so,se,row in allrows if row['cwd']==cwd and args==['status','--porcelain=v1','--untracked-files=all']]
    heads=[so for args,so,se,row in allrows if row['cwd']==cwd and args==['rev-parse','HEAD']]
    indexflags=[so for args,so,se,row in allrows if row['cwd']==cwd and args==['ls-files','-t','-z']]
    C(statuses==[b'']and heads==[(S+'\n').encode()]and len(indexflags)==1,'actual head/status '+label)
    C({x[2:].decode()for x in indexflags[0].rstrip(b'\0').split(b'\0')if x and x[:1]!=b'S'}==names,'exact sparse materialized flags '+label)
    cr=J(B/(label+'-closure.RESULT.json'));so=read(B/(label+'-closure.stdout.bin'));se=read(B/(label+'-closure.stderr.bin'));closures[label]=json.loads(so)
    C(cr['actual_exit']==0 and cr['source_sha']==S and cr['cwd']==cwd and not se,'closure original exit/source/stderr '+label)
    C(cr['argv'][1]=='-B' and cr['argv'][2].endswith('/source_closure_facts.py')and cr['argv'][3]==cwd,'original metadata helper '+label)
C(not(inodes['pool']&inodes['seed']),'pool and seed independent physical inodes at creation')
C(closures['pool']==closures['seed']and r['original_metadata_closure_equal'],'all metadata closure values equal')
f=closures['pool'];C(len(f['mutant_ids'])==len(set(f['mutant_ids']))==123 and len(f['retired_ids'])==3,'full123/3retired')
C(len(f['closure_files'])==185 and len(f['oracle_hashes'])==53 and len(f['restored_methods'])==43,'exact original closure counts')
ad=r['storage_admission'];C(len(ad)==1 and ad[0]['device']==26 and ad[0]['path']==r['reserve_anchor'],'actual single output device')
source_cost=sum(v['allocated_floor_bytes']for v in r['layout'].values())
index_cost=(ad[0]['required']-source_cost-2*16*1024*1024-r['reserve_workspace_bytes'])//2
C(index_cost==1940086 and source_cost+2*index_cost+2*16*1024*1024+25165824==298845900,'unchanged original source+index+metadata+reserve formula')
C(ad[0]['free']==17180909568 and ad[0]['free']>=ad[0]['required'],'actual free admission')
D.mkdir(exist_ok=False)
result={'exit_code':0,'blocking_findings':[],'checks':checks,'source_sha':S,'actual_git_commands':342,'original_stream_bytes_read':stream_bytes,'pool_leaves':3763,'seed_leaves':2738,'architecture_inputs':604,'mandatory_fixtures':5,'metadata_closure_equal':True,'original_mutant_definitions':123,'retired':3,'reserve_bytes':25165824,'reserve_MiB':24,'admission':ad,'derived_owner_index_bytes':index_cost,'formal_acceptance_executed':False,'scope':'Completed original receipts and captured manifests only; no current pool/seed/Git objects/source scan and no commands repeated','limitations':['Physical inode facts are original creation snapshots, not new current-source assertions.','Original row records Git OID/size/nlink; mode registration is from Git tree plus original clean status, not a new per-file stat-mode snapshot.','Full123 and subsequent native/runtime are separate gates.'],'bindings':bindings,'review_script_sha256':H(Path(__file__).read_bytes()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(D/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':0,'checks':checks,'path':str(D/'REVIEW.json'),'sha256':H((D/'REVIEW.json').read_bytes())}))
