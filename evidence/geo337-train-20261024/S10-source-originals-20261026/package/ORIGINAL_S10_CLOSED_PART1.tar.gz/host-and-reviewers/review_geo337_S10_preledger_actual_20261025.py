from pathlib import Path
import json,hashlib,datetime,re,subprocess,ast
B=Path('/dev/shm/geometry-axiom-geo337-20261025/S10-preledger-checks-original-20261025');O=Path('/workspace/geo337-S10-preledger-actual-peer-20261025');O.mkdir(exist_ok=False)
S='82c922a3941525d3a094ac0158bdc7dea57ea360';F9='4f8a794f4167c3562eb182045102e86e9e37cca9'
def H(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(Path(p).read_bytes())
checks=[]
def C(v,l):
 checks.append(l)
 if not v:raise AssertionError(l)
rows=J(B/'subcommands.json');r=J(B/'RESULT.json');request=J(B/'REQUEST.json');hostp=Path('/workspace/geo337-S10-preledger-checks-EXEC_FINAL-20261025.json');host=J(hostp);hostout=json.loads(host['actual_tool_result']['output'])
C(host['status']=='FINISHED' and host['actual_tool_result']['exit_code']==r['wrapper_exit']==0,'True host terminal0 means capture complete not all gates green')
C(hostout['source_sha']==r['source_sha']==request['source_sha']==S,'Source exact S10')
C(hostout['gates']==[{k:v for k,v in q.items()if k!='command'}for q in r['gates']],'Host all gate exits match original result')
C(hostout['all_gates_passed'] is False and r['all_gates_passed'] is False,'Tracked stale red retained')
C(len(rows)==12 and [q['actual_process_returncode']for q in rows]==[0,0,0,1,0,0,0,0,0,0,0,0],'Exact twelve original command exits')
raw={};total=0
for i,row in enumerate(rows,1):
 d=Path(row['directory']);C(d==B/'subcommands'/f'{i:06d}','Only exact closed original stream directory')
 C(J(d/'result.json')==row,'Full original result identity')
 req=J(d/'request.json');C(req['command']==row['command'] and req['environment']==row['environment'] and req['started_epoch']==row['started_epoch'],'Original argv/env/start identity')
 C(row['source_sha']==row['acceptance_sha']==S and not row['timeout_expired'],'Exact source no timeout')
 C(row['environment']['PYTHONDONTWRITEBYTECODE']=='1' and row['environment']['PYTHONOPTIMIZE']is None and row['environment']['TMPDIR']==str(B/'tmp'),'Original controlled runtime env')
 for stream in ['stdout','stderr','stdin']:
  p=d/(stream+'.bin');b=p.read_bytes();raw[(i,stream)]=b;total+=len(b)
  C(H(b)==row[stream+'_sha256'],'Complete original '+stream+' hash')
  if stream!='stdin':C(len(b)==row[stream+'_bytes'],'Complete original '+stream+' bytes')
 C(row['ended_epoch']>=row['started_epoch'],'Real terminal after start')
for i in [1,10]:C(raw[(i,'stdout')].decode().strip()==S,'Original pre/post HEAD')
for i in [2,11]:C(raw[(i,'stdout')]==b'','Original pre/post full status clean')
C(raw[(3,'stdout')]==raw[(12,'stdout')],'Complete original stage index listing unchanged')
C(r['before']==r['after']==request['before'] and r['before']['head']==S and r['before']['status']=='' and r['before']['index']==H(raw[(3,'stdout')]),'Captured source states exact unchanged')
expected=[('tracked-ledger-check',['tests/mutate.py','--check'],1),('architecture-contract',['tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json'],0),('architecture-unit',['tests/test_architecture_contract.py'],0),('product-architecture-unit',['tests/test_product_architecture.py'],0),('I24-scoped-kernel-contract',['tests/test_geo314_commit_paths.py'],0),('decision-adoption',['tests/test_domain_decoupling_adoption.py'],0)]
gates=[]
for i,(gate,argv,ex)in enumerate(expected,4):
 q=r['gates'][i-4];row=rows[i-1];C(q['gate']==gate and q['command']==row and q['exit_code']==ex and row['command'][1:]==['-B',*argv],'Exact original gate argv/exit '+gate)
 C(request['gates'][i-4]==[gate,row['command']],'Request gate binding '+gate)
 gates.append({'gate':gate,'argv':row['command'],'exit_code':ex,'source_sha':S,'cwd':row['cwd'],'original_stdout':str(Path(row['directory'])/'stdout.bin'),'stdout_bytes':row['stdout_bytes'],'stdout_sha256':row['stdout_sha256'],'original_stderr':str(Path(row['directory'])/'stderr.bin'),'stderr_bytes':row['stderr_bytes'],'stderr_sha256':row['stderr_sha256'],'started_epoch':row['started_epoch'],'ended_epoch':row['ended_epoch'],'elapsed_seconds':row['ended_epoch']-row['started_epoch'],'environment':row['environment']})
text=raw[(4,'stdout')].decode();stale=re.findall(r'^  STALE (M\d+)\(原 ([^)]+)\):(.+)$',text,re.M)
C(len(stale)==53 and len({x[0]for x in stale})==53,'Exactly53 stale bridge rows')
C(sum(v=='killed'for _,v,_ in stale)==52 and [(m,v)for m,v,_ in stale if v!='killed']==[('M110','equivalent')],'52 formerkilled plus M110 equivalence')
reason='裁判已變(run_tests.py 或被 TESTS 引用的夾具內容不同);bridge source/oracle restoration'
C(all(why==(reason if v=='killed'else'equivalence audit oracle changed;bridge source/oracle restoration')for m,v,why in stale),'Every exact original stale reason')
counts={'killed':62,'crashed':1,'survived':0,'equivalent':4,'invalid':0,'stale':53,'blocked':0,'retired':3}
for k,v in counts.items():C(re.search(r'\b'+k+r' '+str(v)+r'\b',text)is not None,'Original verdict count '+k)
C(sum(counts.values())==123 and '變異表 123 筆,紀錄 123 筆'in text,'All123 table/accounting retained')
C('CRASHED M20'in text and '連跑 3 次都在同一夾具以存取違規結束'in text and '不是斷言殺死'in text,'Original M20 crash remains crash not assertion killed')
arch=json.loads(raw[(5,'stdout')]);C(arch['ok'] and arch['diagnostics']==[],'Architecture contract true no diagnostics');C(len(arch['sources'])==334 and len(arch['trustedSourcesNotParsed'])==6 and len(arch['edges'])==798,'Architecture334owned/6trusted/798edges')
unitcounts={6:205,7:18,8:11,9:15}
for i,num in unitcounts.items():
 err=raw[(i,'stderr')].decode();C(re.search(r'Ran '+str(num)+r' tests in [0-9.]+s\n\nOK\n$',err)is not None,'Full unit count and OK '+str(i));C(not re.search(r'(^FAIL:|^ERROR:|\.\.\. skipped|OK \(skipped=)',err,re.M),'No failures/errors/allowedskip invented '+str(i))
 if i!=7:C(len(re.findall(r'^test_.* \.\.\. ok$',err,re.M))==num,'All verbose methods counted '+str(i))
 gates[i-4]['tests_run']=num;gates[i-4]['skipped']=0
C('test_kernel_has_no_changes_against_the_fixed_integration_base' in raw[(8,'stderr')].decode(),'Original former native red method now actual pass')
# Immutable Git objects only; never status/index/worktree of active F10-pool/cache.
immutable=[]
def git(*args):
 argv=['git','--git-dir=/dev/shm/geometry-axiom-geo337-20261025/publisher-source/.git',*args];v=subprocess.run(argv,capture_output=True)
 immutable.append({'argv':argv,'exit_code':v.returncode,'stdout_bytes':len(v.stdout),'stdout_sha256':H(v.stdout),'stderr_bytes':len(v.stderr),'stderr_sha256':H(v.stderr),'stdout_storage':'immutable object/query, hash-only audit identity; not claimed as separate archived original workflow stream'})
 C(v.returncode==0,'Readonly immutable Git query');return v.stdout
changed=git('diff','--no-renames','--name-only','-z',F9,S,'--',':(exclude)evidence')
C(set(changed.decode().strip('\0').split('\0'))=={'tests/test_geo314_commit_paths.py','決策佇列.md'},'Only exact I24 test and decision changed since F9')
mutate=git('show',S+':tests/mutate.py');bridge=git('show',S+':tests/mutation_bridge.py')
C(H(mutate)=='bd2d0c768439a93e7f848ff0299a5b164aabe1d80a0f4e9a5bcb7ab83eb4b315' and H(bridge)=='7febe80ba29a3c0e7821277f47102a57a0c9ab0610a02e8981bb0eb2a79b3c58','Exact immutable oracle source identities')
C(b'root.glob("tests/*.py")'in bridge and b'root.glob("tests/*.c")'in bridge and b'root.glob("tests/fixtures/**/*.scene")'in bridge,'Bridge conservative closure includes changed I24 Python file')
C(b'if not e.get("byte_restored") or e["oracle_sha256"] != oracle_hash(m, src.root):'in bridge and b'raise ValueError("bridge source/oracle restoration")'in bridge,'Restoration text also represents oracle mismatch not proof damagedsource')
ids={}
for n in ast.walk(ast.parse(mutate)):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict':
  fields={v.arg:v.value.value for v in n.keywords if isinstance(v.value,ast.Constant)}
  if 'id'in fields:ids[fields['id']]=fields
C(all(ids[m].get('binary')=='bridge'for m,_,_ in stale),'All53 stale IDs declared bridge mutants')
lo=git('rev-parse',S+':tests/mutants_results.json');oldlo=git('rev-parse',F9+':tests/mutants_results.json');C(lo==oldlo,'Tracked ledger original F9 bytes unchanged')
ledger_raw=git('show',S+':tests/mutants_results.json');ledger=json.loads(ledger_raw)
C(len(ledger)==123 and all(ledger[m]['execution']['byte_restored']is True for m,_,_ in stale),'Original53 bridge byte-restored flags alltrue')
C(all(ledger[m]['execution']['oracle_sha256']==ledger[m]['oracle_sha256']for m,_,_ in stale),'Original record and execution oracle identities internally agree')
# Record original source of all execution evidence honestly; do not relabel as S10.
heads={x['execution']['head']for x in ledger.values()if isinstance(x.get('execution'),dict)}
C(heads=={'75a1e93811a52b69385cbdaf6a09d773ed9052ad'},'Original ledger execution heads remainF8')
C(not r['full_native_executed'] and not r['full123_executed'] and r['source_unchanged'],'This preledger capture is neither new fullnative nor full123')
report={'schema':'S10-preledger-original-actual-peer/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'checks':len(checks),'source_sha':S,'original_wrapper_exit':0,'all_original_gates_passed':False,'original_gate_exits':[1,0,0,0,0,0],'source_before_after_captured_equal':True,'source_index_listing_sha256':H(raw[(3,'stdout')]),'original_command_count':len(rows),'original_full_stream_bytes_verified':total,'gates':gates,'architecture':{'owned_sources':334,'trusted_not_parsed':6,'edges':798,'diagnostics':0,'unit_tests':205,'product_tests':18},'stale':{'count':53,'former_killed':52,'former_equivalent':['M110'],'rows':[{'id':m,'original_verdict':v,'original_reason':why}for m,v,why in stale],'verdict_counts':counts,'root_cause':'S10 只變更 tests/test_geo314_commit_paths.py 與決策原文；bridge oracle 保守雜湊納入所有 tests/*.py，因此53筆bridge裁判閉包過期。第二段 restoration 訊息由同一oracle hash不符觸發；舊53筆 byte_restored 全true，不能解讀成產品來源還原失敗。','ledger_execution_heads_original':sorted(heads),'tracked_ledger_sha256':H(ledger_raw),'ledger_not_relabelled':True},'immutable_git_checks':immutable,'pins':{'result':H((B/'RESULT.json').read_bytes()),'request':H((B/'REQUEST.json').read_bytes()),'executor':H((B/'EXECUTOR.py').read_bytes()),'subcommands':H((B/'subcommands.json').read_bytes()),'host_final':H(hostp.read_bytes())},'blocking_findings':[],'limits':['正式require_escalated唯讀已封閉preledger原流與privatepublisher不可變Git物件；沒有存取活動F10-pool/cache的檔案或索引、沒有重跑任何產品或測試。','本peer0表示原件與分類核對通過；mutate --check仍真1，完整native/full123並未由這批執行或通過。','前後原index為git ls-files --stage -z完整內容等同，不冒實體index inode/mtime前後保全。','架構三原裁判0不等於架構四檔已重新產生；影響沿用矩陣另由acceptance提出並獨審。','原capture記錄白名單環境，沒有版本stage；本peer不補猜本批Chrome/Node/compiler版本。原executor無timeout，不冒新的watchdog。','唯讀根因探索先猜tests/mutation_bridge_runner.py，Git128無該blob；改讀真正mutation_bridge.py。此探索不是正式gate且未執任何原程式。']}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(O/'REVIEW.md').write_text('# S10 preledger 原件核對\n\n原六項退出碼依序為 **1／0／0／0／0／0**，外層0僅表示收件完成。\n\n帳本123筆中53筆bridge裁判過期：52筆原killed、M110原equivalent；另62 killed、1 crashed、4 equivalent、3 retired。唯一tests/*.py變更是#314範圍測試，因此保守bridge oracle閉包失效。舊byte_restored全true，restoration字樣來自oracle不符，非產品還原損壞。\n\n架構原裁判：334來源／6可信未解析／798依賴／0diagnostics；unit205、product18、#314完整11、adoption15皆0、零skip。原前後SHA／完整stage listing／clean status一致。\n\n只讀封閉原流與不可變Git，沒有讀寫活動來源、重跑測試或將舊F8帳本移標。各原argv、環境、完整輸出位置、SHA256與退出碼見REVIEW.json。\n')
print(json.dumps({'exit_code':0,'checks':len(checks),'review':str(O/'REVIEW.json'),'sha256':H((O/'REVIEW.json').read_bytes()),'original_gate_exits':[1,0,0,0,0,0],'stale':53},ensure_ascii=False))
