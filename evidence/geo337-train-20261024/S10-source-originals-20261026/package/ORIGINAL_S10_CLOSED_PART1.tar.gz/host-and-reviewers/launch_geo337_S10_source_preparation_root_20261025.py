from pathlib import Path
import hashlib,importlib.util,json,os,sys
OWN=Path('/dev/shm/geometry-axiom-geo337-20261025');OTHER=Path('/dev/shm/geo337-F9-browsers-20261025')
PREP=Path('/workspace/geo337-F10-source-reserve-anchor-preparation-20261025');TOOL=PREP/'prepare_fresh_sources.py'
PEER=Path('/workspace/geo337-F10-source-reserve-anchor-static-peer-20261025/REVIEW.json')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
SAMPLER=Path('/workspace/geo337-F9-browser-sampler-preparation-20261025/sample_original_browser_v2.py')
SOURCE='82c922a3941525d3a094ac0158bdc7dea57ea360'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert h(TOOL)=='8fdfe577cb3f5c3a5da6cfddb2d81fe2bbb5a794bd7a804c3ce13b21bdd2ebcb'
assert h(PEER)=='e8d849d787010f96111ce253937806352c67aa4731afc7a898e3b5d53e2c6395'
assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(SAMPLER)=='919eafb54f20454ee44a27754ce04f6f63f05f6e1c9b32a5b51652058735af30'
q=json.loads((PREP/'COMMAND.bound-S82c922a3.pending-peer.json').read_bytes());cmd=q['argv'];assert q['source_sha']==SOURCE and cmd[2]==str(TOOL) and cmd[cmd.index('--sha')+1]==SOURCE
assert cmd[cmd.index('--reserve-workspace-bytes')+1]=='25165824' and cmd[cmd.index('--reserve-anchor')+1]==str(OWN)
for option,name in [('--pool','F10-pool'),('--cache','F10-cache'),('--out','F10-source-preparation-reserve-anchor')]:
    path=Path(cmd[cmd.index(option)+1]);assert path==OWN/name and not path.exists()
sp=importlib.util.spec_from_file_location('shared_inventory',SAMPLER);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
inv=m.inventory([OWN,OTHER]);increment=384*1024*1024;fs=os.statvfs(OWN);free=fs.f_bavail*fs.f_frsize
assert inv['unique_allocated_bytes']+increment<=2147483648 and free>=increment
OUT=OWN/'S10-source-preparation-root-original-20261025';assert not OUT.exists();OUT.mkdir(mode=0o700)
sp=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
request={'source_sha':SOURCE,'root_execution_lease':True,'formal_tests_executed':False,'independent_peer':str(PEER),'peer_sha256':h(PEER),'tool_sha256':h(TOOL),'argv':cmd,'shared_allocated_before':inv['unique_allocated_bytes'],'additional_planning_bytes':increment,'shared_ceiling_bytes':2147483648,'actual_mount_free_before':free,'reserve_bytes_unchanged':25165824,'reserve_anchor':str(OWN),'planning_not_measured_peak':True,'memory':{n:(Path('/sys/fs/cgroup')/n).read_text()for n in ['memory.current','memory.max','memory.events','memory.stat']},'meminfo':Path('/proc/meminfo').read_text()}
cap.dump(OUT/'REQUEST.json',request);(OUT/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT),TMP=str(OUT),TEMP=str(OUT));env.pop('PYTHONOPTIMIZE',None)
rec=cap.Recorder(OUT,env,SOURCE);row,b,e=rec.run(cmd,cwd='/workspace',timeout=None,check=False,source_variant='Fresh S10 pool and seed with unchanged reserve checked on actual write mount; metadata only')
cap.dump(OUT/'RESULT.json',{'exit_code':row['actual_process_returncode'],'source_sha':SOURCE,'formal_tests_executed':False,'command':row,'source_result':str(OWN/'F10-source-preparation-reserve-anchor/RESULT.json')});sys.stdout.buffer.write(b);sys.stderr.buffer.write(e);raise SystemExit(row['actual_process_returncode'])
