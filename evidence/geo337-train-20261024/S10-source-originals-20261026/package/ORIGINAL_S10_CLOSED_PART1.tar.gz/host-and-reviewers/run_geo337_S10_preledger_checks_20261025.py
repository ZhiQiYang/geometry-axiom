from pathlib import Path
import hashlib,importlib.util,json,os,sys,fcntl
ROOT=Path('/dev/shm/geometry-axiom-geo337-20261025/F10-pool')
OUT=ROOT.parent/'S10-preledger-checks-original-20261025'
SHA='82c922a3941525d3a094ac0158bdc7dea57ea360'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not OUT.exists();OUT.mkdir(mode=0o700);TMP=OUT/'tmp';TMP.mkdir()
s=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(s);s.loader.exec_module(cap)
env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','GEOMETRY_','MUTATE_'))and k not in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','NODE_OPTIONS','LD_PRELOAD']}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GIT_OPTIONAL_LOCKS='0',TMPDIR=str(TMP),TMP=str(TMP),TEMP=str(TMP),GITHUB_SHA=SHA,GITHUB_WORKSPACE=str(ROOT))
rec=cap.Recorder(OUT,env,SHA);lock=Path('/tmp/g261r3/heavy.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def run(argv,kind):
    return rec.run(argv,cwd=ROOT,timeout=None,check=False,source_sha=SHA,source_variant=kind)
def state():
    d={}
    for key,args in [('head',['rev-parse','HEAD']),('status',['status','--porcelain=v1','--untracked-files=all']),('index',['ls-files','--stage','-z'])]:
        row,b,e=run(['git',*args],'S10 original source identity');assert row['actual_process_returncode']==0
        d[key]=hashlib.sha256(b).hexdigest()if key=='index'else b.decode().strip()
    assert d['head']==SHA and not d['status'];return d
before=state();rows=[]
gates=[('tracked-ledger-check',[sys.executable,'-B','tests/mutate.py','--check']),('architecture-contract',[sys.executable,'-B','tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json']),('architecture-unit',[sys.executable,'-B','tests/test_architecture_contract.py']),('product-architecture-unit',[sys.executable,'-B','tests/test_product_architecture.py']),('I24-scoped-kernel-contract',[sys.executable,'-B','tests/test_geo314_commit_paths.py']),('decision-adoption',[sys.executable,'-B','tests/test_domain_decoupling_adoption.py'])]
cap.dump(OUT/'REQUEST.json',{'source_sha':SHA,'gates':gates,'before':before,'scope':'Original check, three architecture judges and affected I24/decision tests; not full native or ledger generation','timeouts':None})
(OUT/'EXECUTOR.py').write_bytes(Path(__file__).read_bytes())
try:
    for name,argv in gates:
        row,b,e=run(argv,name);rows.append({'gate':name,'exit_code':row['actual_process_returncode'],'command':row});cap.dump(OUT/'PROGRESS.json',{'source_sha':SHA,'gates':rows,'terminal':False})
    after=state();assert before==after
    result={'source_sha':SHA,'gates':rows,'before':before,'after':after,'source_unchanged':True,'full_native_executed':False,'full123_executed':False,'all_gates_passed':all(x['exit_code']==0 for x in rows),'wrapper_exit':0}
    cap.dump(OUT/'RESULT.json',result);print(json.dumps({'source_sha':SHA,'gates':[{k:v for k,v in x.items()if k!='command'}for x in rows],'all_gates_passed':result['all_gates_passed'],'wrapper_exit':0}))
finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
