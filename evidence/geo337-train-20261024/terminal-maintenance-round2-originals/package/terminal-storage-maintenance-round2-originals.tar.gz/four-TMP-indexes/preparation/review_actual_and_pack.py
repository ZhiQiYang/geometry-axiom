"""Audit only completed exact-cache retirement, then package its small immutable originals."""
from pathlib import Path
import hashlib,io,json,os,tarfile
P=Path(__file__).parent;A=Path('/workspace/four-external-index-retirement-execution-20261024');B=Path('/workspace/four-external-index-retirement-launch-20261024');O=Path('/workspace/four-external-index-retirement-publication-20261024')
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not O.exists();O.mkdir()
plan=json.loads((P/'PLAN.json').read_text());result=json.loads((A/'RESULT.json').read_text());outer=json.loads((B/'RESULT.json').read_text());request=json.loads((A/'REQUEST.json').read_text());consumers=json.loads((A/'CONSUMERS.json').read_text())
checks=[]
def check(n,b):checks.append({'name':n,'passed':bool(b)})
check('pinned_original_plan',h((P/'PLAN.json').read_bytes())==result['planSHA256']==request['planSHA256']=='f6f9899366f9405c4d6f172950f8e0db95d67b0c735aa0134a245e03765a1bb9')
check('pinned_original_tool',h((P/'retire_exact_four_indexes.py').read_bytes())==request['toolSHA256']=='6525bb8d2a19444c503083052acf40dcb52f9e2fb93be08d50c0a6ba7e85f114')
check('true_child_and_outer_terminal0',result['exitCode']==outer['actual_process_returncode']==0 and result['endedUTC'] and outer['ended_epoch'] and not outer['timeout_expired'] and result['errors']==[])
check('optimization_not_disabling_guards',outer['environment']['PYTHONOPTIMIZE'] is None and '-O' not in outer['command'] and '-OO' not in outer['command'])
check('explicit_root_scope_reservation',request['rootReservationFlag'] and request['execute'] and '--root-reserved-four-paths' in outer['command'])
targets={r['path']:r for r in plan['targets']};removed={r['path']:r for r in result['removed']}
check('exact_four_scope',len(targets)==len(removed)==4 and set(result['scope'])==set(targets)==set(removed))
for path,row in targets.items():
 check('absent_exact_cache_'+path,not os.path.lexists(path))
 check('never_true_repository_index_'+path,'.git' not in Path(path).parts and Path(path).name!='index')
 for dst,src in (('inode','inode'),('bytes','bytes'),('allocatedBytes','allocated'),('sha256','sha256')):check('original_'+dst+'_'+path,removed[path][dst]==row[src])
check('no_observable_consumer',consumers['observableMatches']==[])
check('unknown_proc_limits_not_erased',isinstance(consumers['unreadableOrDisappeared'],list) and 'inaccessible' in consumers['limitation'] and 'not proof' in result['consumerLimit'])
check('three_unknown_creators_still_unknown',result['unknownThreeOriginalCreatorsRetainedAsUnknown'] and sum(not r['producerTerminalProven'] for r in plan['targets'])==3)
check('grid_real_terminal13_0_retained',plan['targets'][0]['producerTerminal']['exit']==0 and plan['targets'][0]['producerTerminal']['originalCommandCount']==13)
for ref in plan['preservedReferences']:
 path=Path(ref['path']);check('preserved_reference_'+str(path),path.is_file() and path.stat().st_size==ref['bytes'] and h(path.read_bytes())==ref['sha256'])
check('allocated_sum_18432000',result['removedAllocatedBytes']==sum(r['allocated'] for r in targets.values())==18432000)
check('true_observed_tmp_delta',result['freeBefore']['/tmp']==91598848 and result['freeAfter']['/tmp']==110030848 and result['observedFreeDelta']['/tmp']==18432000)
check('workspace_cost_kept_separate',result['observedFreeDelta']['/workspace']==-126976 and result['allocatedNotClaimedAsObservedFree'])
rows=json.loads((B/'subcommands.json').read_text());check('one_original_outer_command',len(rows)==1)
for i,row in enumerate(rows):
 d=Path(row['directory']);check('outer_row_equals_result_'+str(i),row==outer)
 for k in ('stdout','stderr'):
  raw=(d/(k+'.bin')).read_bytes();check('outer_'+k+'_'+str(i),h(raw)==row[k+'_sha256'] and len(raw)==row[k+'_bytes'])
 check('outer_original_stdin_'+str(i),h((d/'stdin.bin').read_bytes())==row['stdin_sha256'])
report={'schema':'four-external-index-cache-retirement-actual-narrow-peer/1','checks':len(checks),'exitCode':0 if all(c['passed'] for c in checks) else 1,'findings':[c['name'] for c in checks if not c['passed']],'details':checks,'scope':'Four exact external reconstructible caches only. No payload rehash after deletion, no true index/source/ROOT/SEED/live cache reads or subject execution.','allocatedBytes':18432000,'observedTmpFreeDelta':18432000,'unknownThreeOriginalCreatorsRemainUnknown':True,'semanticStageRebuildNotOriginalStatBytes':True,'limits':['Accessible proc-only absence retained; hidden/inaccessible consumers not proved absent. Root explicitly reserved paths and accepted this bounded cache retirement.','This maintenance is not a product gate. No claim every repository index bytes were independently measured before/after; none selected by fixed unlink scope.','No full index or multi-MB stage listing duplicated. Original Git commits/patches and stage hashes/counts remain.']}
dump(O/'ACTUAL_PEER.json',report);assert report['exitCode']==0,report['findings']
sources={}
for label,root in (('preparation',P),('execution',A),('outer',B)):
 for path in sorted(root.rglob('*')):
  if path.is_file():assert not path.is_symlink();sources[label+'/'+path.relative_to(root).as_posix()]=path
peer=Path('/tmp/train337-adversarial/FOUR_EXTERNAL_PROBE_INDEX_EXECUTOR_PEER.json');sources['static-peer/'+peer.name]=peer;sources['actual-peer/ACTUAL_PEER.json']=O/'ACTUAL_PEER.json'
index={'schema':'four-external-index-cache-maintenance-originals/1','subjectExecutions':0,'members':[]}
archive=O/'originals-plan-tool-static-and-actual-peer.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
 for name,path in sources.items():
  raw=path.read_bytes();st=path.stat();ti=tarfile.TarInfo(name);ti.size=len(raw);ti.mode=st.st_mode&0o777;ti.mtime=st.st_mtime;tf.addfile(ti,io.BytesIO(raw));index['members'].append({'member':name,'sourcePath':str(path),'bytes':len(raw),'sha256':h(raw)})
with tarfile.open(archive,'r:gz') as tf:
 assert tf.getnames()==list(sources)
 for m,row in zip(tf.getmembers(),index['members']):
  raw=tf.extractfile(m).read();assert raw==sources[m.name].read_bytes() and h(raw)==row['sha256'] and len(raw)==row['bytes']
index.update(memberCount=len(sources),archive=archive.name,archiveBytes=archive.stat().st_size,archiveSHA256=h(archive.read_bytes()),producerRoundtrip=True,actualPeerChecks=report['checks'],actualPeerExit=0)
dump(O/'INDEX.json',index);print(json.dumps({'checks':report['checks'],'exitCode':0,'INDEX':str(O/'INDEX.json'),'archiveBytes':index['archiveBytes'],'members':len(sources)},ensure_ascii=False))
