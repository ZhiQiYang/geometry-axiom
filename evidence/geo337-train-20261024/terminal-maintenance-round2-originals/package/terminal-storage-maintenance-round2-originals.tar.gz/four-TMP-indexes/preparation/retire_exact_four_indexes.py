"""Parent-root execution only: retire exactly four reserved, reconstructible external indexes."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,json,os,shutil,stat,sys

P=Path(__file__).parent
PLAN=P/'PLAN.json'
PLAN_SHA='f6f9899366f9405c4d6f172950f8e0db95d67b0c735aa0134a245e03765a1bb9'
EXACT={
 '/tmp/g288-final-grid-3d681636/prbody-independent.index',
 '/tmp/geo314-readonly-index-vg9bousx/current314.index',
 '/tmp/geo314-readonly-index-vg9bousx/currentCombined.index',
 '/tmp/geo314-readonly-index-vg9bousx/314ThenCombined.index'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def identity(path,row):
 assert str(path) in EXACT and path.resolve(strict=True)==path
 assert '.git' not in path.parts and path.name!='index','Never a true repository index'
 st=path.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 for name,key in (('st_dev','device'),('st_ino','inode'),('st_size','bytes'),('st_mtime_ns','mtime_ns'),('st_ctime_ns','ctime_ns')):assert getattr(st,name)==row[key],(str(path),key)
 assert st.st_blocks*512==row['allocated'] and oct(st.st_mode&0o777)==row['mode']
 with path.open('rb') as f:raw=f.read()
 assert h(raw)==row['sha256'] and raw[:4]==b'DIRC' and hashlib.sha1(raw[:-20]).digest()==raw[-20:]
 return st
def consumers():
 matches=[];unknown=[];visible=0;needles=[v.encode() for v in EXACT]
 for q in Path('/proc').iterdir():
  if not q.name.isdigit() or int(q.name)==os.getpid():continue
  for field in ('cmdline','environ'):
   try:
    raw=(q/field).read_bytes();visible+=1
    if any(n in raw for n in needles):matches.append({'pid':int(q.name),'field':field,'matchedPaths':[v for v in EXACT if v.encode() in raw]})
   except (OSError,PermissionError) as e:unknown.append({'pid':int(q.name),'field':field,'errno':e.errno})
  try:
   for fd in (q/'fd').iterdir():
    try:
     value=os.readlink(fd)
     if value.removesuffix(' (deleted)') in EXACT:matches.append({'pid':int(q.name),'field':'fd/'+fd.name,'matchedPaths':[value]})
    except OSError as e:unknown.append({'pid':int(q.name),'field':'fd/'+fd.name,'errno':e.errno})
  except OSError as e:unknown.append({'pid':int(q.name),'field':'fd','errno':e.errno})
 return {'visibleFields':visible,'observableMatches':matches,'unreadableOrDisappeared':unknown,'limitation':'Not proof of absence in inaccessible proc fields. Root reserves these exact paths and accepts this documented observation boundary.'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--execute',action='store_true');ap.add_argument('--root-reserved-four-paths',action='store_true');a=ap.parse_args()
 assert a.execute and a.root_reserved_four_paths,'Only root may run after peer and reserving all four paths; preparation never deletes'
 assert h(PLAN.read_bytes())==PLAN_SHA
 plan=json.loads(PLAN.read_text());assert {v['path'] for v in plan['targets']}==EXACT and len(plan['targets'])==4
 assert plan['totalAllocatedBytes']==18432000 and plan['subjectExecutions']==0
 O=a.out.absolute();assert not O.exists() and O.resolve()==O and all(not O.is_relative_to(Path(p)) and not Path(p).is_relative_to(O) for p in EXACT)
 O.mkdir(parents=True)
 result={'startedUTC':now(),'exitCode':None,'scope':sorted(EXACT),'planSHA256':PLAN_SHA,'removed':[],'errors':[],'consumerLimit':plan['procLimit'],'unknownThreeOriginalCreatorsRetainedAsUnknown':True,'noSubjectOrGitIndexWriter':True,'freeBefore':{p:shutil.disk_usage(p).free for p in ('/tmp','/workspace')}}
 dump(O/'REQUEST.json',{'argv':sys.argv,'cwd':os.getcwd(),'planSHA256':PLAN_SHA,'toolSHA256':h(Path(__file__).read_bytes()),'environment':{k:os.environ.get(k) for k in ('PATH','LANG','LC_ALL','TMPDIR','GIT_INDEX_FILE','GIT_DIR','GIT_WORK_TREE')},'rootReservationFlag':a.root_reserved_four_paths,'execute':a.execute})
 try:
  with open('/tmp/train337-four-external-index-retirement.lock','a+b') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   # Preserve all provenance/patches/recipes. No source, raw, object or true index is selected.
   for row in plan['preservedReferences']:
    p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and h(p.read_bytes())==row['sha256'],str(p)
   for row in plan['targets']:identity(Path(row['path']),row)
   c=consumers();dump(O/'CONSUMERS.json',c);assert not c['observableMatches'],'Observable active consumer; stop all retirement'
   # All four pass before the first unlink. Recheck exact metadata immediately before each.
   for row in plan['targets']:
    p=Path(row['path']);identity(p,row);os.unlink(p)
    result['removed'].append({'path':str(p),'inode':row['inode'],'bytes':row['bytes'],'allocatedBytes':row['allocated'],'sha256':row['sha256']})
    dump(O/'PROGRESS.json',result)
   for row in plan['preservedReferences']:
    p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and h(p.read_bytes())==row['sha256'],str(p)
   assert all(not os.path.lexists(p) for p in EXACT)
   result['removedAllocatedBytes']=sum(v['allocatedBytes'] for v in result['removed']);assert result['removedAllocatedBytes']==18432000
   result['exitCode']=0
 except BaseException as e:
  result['errors'].append(repr(e));result['exitCode']=1
 finally:
  result['endedUTC']=now();result['freeAfter']={p:shutil.disk_usage(p).free for p in ('/tmp','/workspace')}
  result['observedFreeDelta']={p:result['freeAfter'][p]-result['freeBefore'][p] for p in ('/tmp','/workspace')}
  result['allocatedNotClaimedAsObservedFree']=True;dump(O/'RESULT.json',result)
 print(json.dumps(result,ensure_ascii=False));return result['exitCode']
if __name__=='__main__':raise SystemExit(main())
