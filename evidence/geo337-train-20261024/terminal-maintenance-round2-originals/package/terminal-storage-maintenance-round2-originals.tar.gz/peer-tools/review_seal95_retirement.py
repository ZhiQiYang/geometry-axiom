from pathlib import Path
import json,hashlib,ast,re,sys
B=Path('/workspace/seal-terminal-95-elf-preparation-20261023');O=Path('/tmp/train337-adversarial');n=0;f=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(v,s):
 global n
 n+=1
 if not v:f.append(s)
p=json.loads((B/'PLAN.json').read_text());tool=B/'retire_exact_95_terminal_elf_caches.py';txt=tool.read_text();tree=ast.parse(txt);guard=Path('/workspace/clear_terminal_chrome_caches.py');g=guard.read_text()
ck(h(B/'PLAN.json')=='fc2b29246ee95e8323c16a90b7c889fc03c1cccc933cb59e142524cab99a8208','plan pin');ck(h(tool)=='da642faff95a981be49b9c0da98150ce8c6d608906a847fd9a7cb3f0e8e1426a','tool pin');ck(h(guard)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','original guard pin')
cache=Path('/workspace/geo261-cold/g261seal/new-mutation-cache');items=p['targets'];ck(p['cache']==str(cache) and p['sourceSHA']=='b6646d10751a0d85a2f03f5d24fbe1073cb78980','old cache identity');ck(len(items)==len({x['path'] for x in items})==95 and sum(x['allocated_bytes'] for x in items)==92467200,'95 allocation');ck(sum(x['kind']=='core' for x in items)==58 and sum(x['kind']=='bridge' for x in items)==37,'58core37bridge')
for x in items:
 q=Path(x['path']);rel=q.relative_to(cache).as_posix();ck(bool(re.fullmatch(r'(?:M\d+/_mut\.exe|_baseline/baseline\.exe|M\d+/bridge-(?:mutant|restored)/bridge|_bridge-baseline/[0-9a-f]{40}/bridge)',rel)),'exact ELF shape '+rel);ck(x['nlink']==1 and '_bridge-work' not in q.parts,'singlelink/no seed '+rel)
 sp=Path(x['fingerprint_path']);s=json.loads(sp.read_text());ck(str(sp)==str(q)+'.fingerprint.json' and h(sp)==x['fingerprint_sha256'],'sidecar pin '+rel);ck(s['exe_sha256']==x['sha256'],'sidecar executable expectedhash '+rel)
for x in p['terminal_and_source_pins']+p['sidecars']:
 q=Path(x['path']);ck(q.stat().st_size==x['bytes'] and h(q)==x['sha256'],'retained original '+str(q))
r=json.loads(Path(p['terminal_and_source_pins'][0]['path']).read_text());c=json.loads(Path(p['terminal_and_source_pins'][1]['path']).read_text());ck(r['source_sha']==p['sourceSHA'] and r['stage_execution_passed'] is True and r['finished_utc'],'original terminal ledger');ck(r['commands'][14]['actual_process_returncode']==0 and r['commands'][14]['ended_utc'] and r['environment']['MUTATE_CACHE']=='/tmp/g261seal/new-mutation-cache','original fullCLI/cache relocation');ck(c['stage_execution_passed'] is False and c['finished_utc'],'later census remains red')
rows=json.loads((B/'subcommands.json').read_text());ck(len(rows)==8,'eight readonly source object commands')
for z,row in enumerate(rows):
 d=Path(row['directory']);ck(row['actual_process_returncode']==0 and not row['timeout_expired'] and row['source_sha']==p['sourceSHA'],'source command exit '+str(z))
 for stream in ('stdout','stderr'):
  raw=(d/(stream+'.bin')).read_bytes();ck(len(raw)==row[stream+'_bytes'] and hashlib.sha256(raw).hexdigest()==row[stream+'_sha256'],'source raw '+str(z)+stream)
for j,x in enumerate(p['source_object_proof']):
 rev=rows[2*j];show=rows[2*j+1];raw=(Path(show['directory'])/'stdout.bin').read_bytes();ck((Path(rev['directory'])/'stdout.bin').read_text().strip()==x['git_blob'] and show['command']==['git','cat-file','-e',x['git_blob']] and show['actual_process_returncode']==0 and raw==b'','immutable recipe Gitblob '+x['path'])
mutators=[x for x in ast.walk(tree) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr in ('unlink','rmdir','rename','replace','chmod','rmtree')];ck(len(mutators)==1 and ast.unparse(mutators[0])=="Path(x['path']).unlink()",'single exact unlink site')
for needle in ["g={'__name__':'_original_guard_reuse_only'", "for x in items:identity(x)", "identity(x)\n            Path(x['path']).unlink()", "preserved()\n        assert all", "g['consumer_check']([x['path'] for x in items]", "assert '_bridge-work' not in p.parts", "g['dump']('PROGRESS.json',result)", "assert sys.flags.optimize==0", "assert stream.read(4)==b'\\x7fELF'", "g['identity'](p,x,is_file=True)"]:
 ck(needle in txt,'executor guard '+needle)
for needle in ['ancestors(path)','assert s.st_nlink == 1 and digest(path)',"assert not path.is_symlink()","parent.lstat()", "'Only accessible cwd/exe/cmdline/fd"]:ck(needle in g,'reused fresh guard '+needle)
ck(p['actual_elf_hash_validated_during_preparation'] is False and 'root executor must full-hash' in p['expected_elf_sha_source'],'no unperformed fullhash claim');ck('Root reserves' in p['lease'],'no reuse lease')
report={'schema':'independent-old-seal95-cache-executor-peer/1','checks':n,'exit_code':int(bool(f)),'findings':f,'tool_sha256':h(tool),'plan_sha256':h(B/'PLAN.json'),'targets':95,'allocated_bytes':92467200,'scope':'Static executor and exact metadata scope; original terminal ledger/census, 95 sidecars and eight source-Git command raw checked. No executable read/hash, cleanup, compile or test run.','reviewer_correction':'Initial checker incorrectly treated original cat-file -e existence proof as blob payload. Initial report/script retained; only checker corrected to exact original argv/0/existing object. No subject/tool change.', 'conditions':['Root reserves this old cache against reuse; execute exact pinned tool only.','Executor must freshly hash/identity/ELFmagic/ancestor/singlelink every target and recheck each immediately before unlink.','Retain all source/Git/sidecars/raw/obj/smoke/_bridge-work; later census false remains historical red.','Accessible process observation only; original unknown fields retained.']}
q=O/'SEAL_95_ELF_EXECUTOR_PEER.json';q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':n,'exit_code':report['exit_code'],'findings':f,'report':str(q),'sha256':h(q)}));sys.exit(report['exit_code'])
