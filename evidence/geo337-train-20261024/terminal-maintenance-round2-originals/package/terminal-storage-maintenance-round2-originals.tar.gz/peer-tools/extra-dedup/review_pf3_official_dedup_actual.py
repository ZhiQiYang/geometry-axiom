from pathlib import Path
import hashlib,json,stat
B=Path('/workspace/evidence-archive-dedup-readonly-20261023');O=Path('/workspace/pf3-official-receipt-archive-three-dedup-execution-20261023');A=Path('/workspace/pf3-official-receipt-archive-three-dedup-launch-20261023');checks=[]
def ck(n,x):checks.append({'check':n,'passed':bool(x)})
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
p=j(B/'pf3-official-exact-three-proof/PLAN.json');r=j(O/'RESULT.json');cmds=j(O/'COMMANDS.json');journal=[json.loads(x)for x in (O/'JOURNAL.jsonl').read_text().splitlines()];a=j(A/'RESULT.json')
ck('exact plan pin',h((B/'pf3-official-exact-three-proof/PLAN.json').read_bytes())=='5e5a600d07afb13ba7c07b51b5619ee1ccb7dc4ecda52b4bbbad735945a6122b')
ck('root terminal0',r['exit_code']==0 and bool(r['ended_utc'])and r['all_three_paths_and_bytes_preserved']is True)
ck('exact3 allowlist and configuredsaving',r['source_paths']==[x['path']for x in p['members']]and r['expected_allocated_saving']==p['expected_allocated_saving']==21757952)
canonical=Path(p['members'][0]['path']).read_bytes();ck('one full canonical body hash',len(canonical)==p['size']==10875864 and h(canonical)==p['sha256'])
ck('canonical actual Git blob identity',hashlib.sha1(b'blob '+str(len(canonical)).encode()+b'\0'+canonical).hexdigest()==p['git_blob'])
identities=[]
for original,final in zip(p['members'],r['final_metadata']):
 path=Path(original['path']);st=path.lstat();identities.append((st.st_dev,st.st_ino));ck('regularalias '+str(path),stat.S_ISREG(st.st_mode)and st.st_nlink==3 and st.st_size==len(canonical))
 ck('actual metadata agrees final '+str(path),all(getattr(st,attr)==final[key]for key,attr in [('dev','st_dev'),('inode','st_ino'),('mode','st_mode'),('size','st_size'),('mtime_ns','st_mtime_ns'),('uid','st_uid'),('gid','st_gid'),('nlink','st_nlink')]))
 tr=original['terminal_receipt'];ck('original terminal bytes retained '+str(path),h(Path(tr['path']).read_bytes())==tr['sha256'])
ck('all3 alias single canonical inode',len(set(identities))==1 and identities[0]==(p['members'][0]['dev'],p['members'][0]['inode']))
ck('source red census preserved',[x['terminal_receipt']['original_passed']for x in p['members']]==[True,False,True])
ck('25 original Git commands all0',len(cmds)==25 and all(c['exit_code']==0 for c in cmds))
for n,c in enumerate(cmds):
 req=j(O/f'{n:03d}.request.json');ck('original argv '+str(n),req['argv']==c['argv'])
 if 'compared_bytes'in c:ck('original full streamed Git body retained at3paths',c['compared_bytes']==len(canonical)and c['stdout_sha256']==h(canonical)and c['stdout_retained_at_original_paths']==r['source_paths'])
 else:
  for stream in ['stdout','stderr']:
   data=(O/f'{n:03d}.{stream}.bin').read_bytes();ck('original Git stream '+str(n)+stream,len(data)==c[stream+'_bytes']and h(data)==c[stream+'_sha256'])
ck('initial exact originals and no forgotten temporary aliases',journal[0]['event']=='initial_verified' and journal[0]['originals']==p['members']and all(not Path(x).exists()for x in journal[0]['temporary_paths']))
replacements=[x for x in journal if x['event']=='replacement_verified'];ck('two exact replacement journal sequence',[(x['index'],x['expected_alias_count'])for x in replacements]==[(1,2),(2,3)])
ck('no inode preservation claim','not restorable'in r['inode_limit']and 'canonical mtime/inode'in r['metadata_limit'])
for q in sorted(O.glob('CONSUMERS*.json')):
 c=j(q);ck('fresh consumers accessible nohits '+q.name,c['hits']==[]and 'unreadable'in c and bool(c['limitation']))
ck('outer original0 non-timeout',a['actual_process_returncode']==0 and a['timeout_expired']is False)
d=Path(a['directory'])
for stream in ['stdout','stderr']:
 raw=(d/(stream+'.bin')).read_bytes();ck('outer full '+stream,len(raw)==a[stream+'_bytes']and h(raw)==a[stream+'_sha256'])
report={'scope':'Independent necessary actual metadata/raw and canonical body hash once; no product rerun or cleanup','checks':checks,'check_count':len(checks),'exit_code':int(any(not x['passed']for x in checks)),'findings':[x['check']for x in checks if not x['passed']],'original_actual_exit':0,'configured_allocated_saving':21757952,'observed_free_workspace_delta':r['free_after']['/workspace']-r['free_before']['/workspace'],'limits':['Three original archive paths and bytes retained, same new alias inode; old destination inode IDs not preserved.','All cold checkout aliases remain barred from writes/reuse until independently de-linked.','Readable proc observation only; unreadable fields retained, no global no-consumer guarantee.','Configured allocated saving is not equal to concurrent observed free-space delta.']}
q=Path('/tmp/train337-adversarial/PF3_OFFICIAL_EXACT_THREE_ACTUAL_PEER.json');q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(q),'sha256':h(q.read_bytes()),'checks':len(checks),'exit_code':report['exit_code'],'findings':report['findings']}))
