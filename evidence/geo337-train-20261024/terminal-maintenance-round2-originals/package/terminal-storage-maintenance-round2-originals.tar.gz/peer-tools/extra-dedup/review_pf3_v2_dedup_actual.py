from pathlib import Path
import hashlib,json,stat
B=Path('/workspace/evidence-archive-dedup-readonly-20261023')
P=Path('/tmp/pf3-tools-full-cdp-dedup-independent-peer')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(label,value):checks.append({'label':label,'passed':bool(value)})
checks=[]
O=Path('/workspace/pf3-v2-receipt-archive-three-dedup-execution-20261023')
LAUNCH=Path('/workspace/pf3-v2-receipt-archive-three-dedup-launch-20261023')
plan_path=B/'pf3-v2-exact-three-proof/PLAN.json';plan=json.loads(plan_path.read_bytes());result=json.loads((O/'RESULT.json').read_bytes());commands=json.loads((O/'COMMANDS.json').read_bytes());journal=[json.loads(x)for x in(O/'JOURNAL.jsonl').read_text().splitlines()];members=plan['members'];paths=[m['path']for m in members]
ck('pf3-v2 original frozen plan',H(plan_path)=='d04fbb3b2cc39b81db328663427e7704101eb97d4c5d9977d0f857cc56ca52f0')
ck('pf3-v2 original frozen executor',H(B/'deduplicate_pf3_v2_exact_three_receipts.py')=='9d8e759ff1730ee099a6e0a48f5338dcf12d70d33a031e97f4e3160490500f08')
ck('actual terminal0 paths preserved',result['exit_code']==0 and result['all_three_paths_and_bytes_preserved'] and result['source_paths']==paths and bool(result['ended_utc']))
ck('actual25 Git metadata/stream commands',len(commands)==25 and all(x['exit_code']==0 for x in commands))
for i,row in enumerate(commands):
    request=json.loads((O/f'{i:03d}.request.json').read_bytes());ck('original argv '+str(i),request['argv']==row['argv'])
    if 'compared_bytes'in row:
        ck('Git catfile full stdout retained at three paths',row['compared_bytes']==plan['size']and row['stdout_sha256']==plan['sha256']and row['stdout_retained_at_original_paths']==paths and row['argv'][-3:]==['cat-file','blob',plan['git_blob']])
        ck('streamed catfile stderr retained',(O/f'{i:03d}.stderr.bin').read_bytes()==b'')
    else:
        for field in ['stdout','stderr']:
            raw=(O/f'{i:03d}.{field}.bin').read_bytes();ck('complete original Git stream '+str(i)+'/'+field,len(raw)==row[field+'_bytes']and hashlib.sha256(raw).hexdigest()==row[field+'_sha256'])
        repo=row['argv'][6]
        m=next(x for x in members if x['repo']==repo)
        if row['argv'][-2:]==['rev-parse','HEAD']:
            ck('original fixed historical HEAD '+str(i),(O/f'{i:03d}.stdout.bin').read_bytes().decode().strip()==m['head'])
        else:
            ck('original exact tree mode blob path '+str(i),(O/f'{i:03d}.stdout.bin').read_bytes()==('100644 blob '+plan['git_blob']+'\t'+m['relative']+'\0').encode())
ck('journal phase order',[x['event']for x in journal]==['initial_verified','before_link','temporary_link_verified','replacement_verified','before_link','temporary_link_verified','replacement_verified','complete'])
ck('journal exact alias progression',[x['expected_alias_count']for x in journal]==[1,1,2,2,2,3,3,3])
ck('journal no payload loss',journal[-1]['all_original_paths_present']and journal[-1]['bytes_unchanged'])
metadata=[]
for p in paths:
    s=Path(p).stat();metadata.append(s)
ck('retained exact3 aliases and one canonical inode',len({(s.st_dev,s.st_ino)for s in metadata})==1 and all(s.st_nlink==3 and s.st_size==plan['size']and stat.S_ISREG(s.st_mode)for s in metadata))
# Read only the one retained canonical inode; do not duplicate/archive its15MB payload.
canonical=Path(paths[0]);before=canonical.stat();payload_hash=H(canonical);after=canonical.stat()
ck('one retained canonical full bytes sha256',payload_hash==plan['sha256']and before.st_ino==after.st_ino and before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns)
for i,m in enumerate(members):
    s=Path(m['path']).stat();final=result['final_metadata'][i]
    ck('final recorded inode/mode/size/mtime alias '+str(i),all(final[k]==v for k,v in {'dev':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}.items()))
    r=m['terminal_receipt'];ck('producer terminal unchanged '+str(i),H(r['path'])==r['sha256']and Path(r['path']).stat().st_size==r['bytes'])
for i in range(4):
    c=json.loads((O/f'CONSUMERS-{i:02d}.json').read_bytes());ck('fresh consumer snapshot no readable hits '+str(i),c['hits']==[] and 'unreadable'in c and bool(c['limitation']))
ck('configured saving23781376 not observed free delta',result['expected_allocated_saving']==plan['expected_allocated_saving']==23781376)
outer=json.loads((LAUNCH/'RESULT.json').read_bytes());request=json.loads((LAUNCH/'REQUEST.json').read_bytes());d=Path(outer['directory'])
ck('prelaunched original outer0 same reviewed tool',outer['actual_process_returncode']==0 and not outer['timeout_expired']and outer['command']==request['argv']and request['tool_sha256']==H(B/'deduplicate_pf3_v2_exact_three_receipts.py'))
for field in ['stdout','stderr']:
    raw=(d/(field+'.bin')).read_bytes();ck('outer complete raw '+field,len(raw)==outer[field+'_bytes']and hashlib.sha256(raw).hexdigest()==outer[field+'_sha256'])
ck('outer stdin preserved',hashlib.sha256((d/'stdin.bin').read_bytes()).hexdigest()==outer['stdin_sha256'])
actual={'role':'completed dedup actual/retained-byte peer only; no cleanup or subject repeat','checkCount':len(checks),'checks':checks,'findings':[r['label']for r in checks if not r['passed']],'exitCode':int(any(not r['passed']for r in checks)),'actualResult':str(O/'RESULT.json'),'actualResultSHA256':H(O/'RESULT.json'),'outerResult':str(LAUNCH/'RESULT.json'),'outerSHA256':H(LAUNCH/'RESULT.json'),'commandCount':25,'retainedCanonicalPayloadSHA256':payload_hash,'retainedPayloadBytes':plan['size'],'expectedConfiguredAllocatedSaving':23781376,'observedFreeDelta':result['free_after']['/workspace']-result['free_before']['/workspace'],'limits':['Only one canonical retained inode payload was streamed; all three paths are exact same dev/inode/nlink3. No15MB payload copied into peer output.','Git catfile original stdout is retained at the three original paths and verified; not fabricated as a separate stdout.bin. Other24commands/outer streams individually retained.','Only original readable consumer snapshots checked; /proc inaccessible fields remain unknown. No new universal consumer visibility claim.','Source/terminal receipts unchanged and census originally red preserved; maintenance is not product acceptance.','All previous/new alias groups keep three cold checkouts barred until separately de-linked; original inode IDs and per-path mtimes not claimed restored.']}
(P/'PF3_V2_DEDUP_ACTUAL_REVIEW.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n')

q=P/'PF3_V2_DEDUP_ACTUAL_REVIEW.json';print(json.dumps({'path':str(q),'sha256':H(q),'checks':actual['checkCount'],'findings':actual['findings'],'exit':actual['exitCode']}));raise SystemExit(actual['exitCode'])
