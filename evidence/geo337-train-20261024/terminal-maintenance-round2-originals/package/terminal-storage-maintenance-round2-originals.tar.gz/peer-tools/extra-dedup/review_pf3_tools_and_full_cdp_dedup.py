"""Static exact literal adaptation and completed metadata/retained-byte peer only."""
from pathlib import Path
import ast, hashlib, json, os, stat

B=Path('/workspace/evidence-archive-dedup-readonly-20261023')
P=Path('/tmp/pf3-tools-full-cdp-dedup-independent-peer')
assert not P.exists()
P.mkdir()
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def ck(label,value):checks.append({'label':label,'passed':bool(value)})
release=B/'deduplicate_release_exact_three_receipts.py'
ck('original release executor pin',H(release)=='90f6ed3ac242f919c630d8c4841c05564854f560efc093d82a9a33369163937c')
ck('shared core pin',H(B/'archive_link_core.py')=='6a492177bea09eb1b28e31b61658680de77de55d236f5c0337fc089fe5f194c4')
original=release.read_text()
old_plan_pin='b4758f87087b7baef6fa07477de3e7584afb2e3b7574d9c24612edf7545367ac'
old_blob='72ed8f50cbcaa08d1d218c7ddd7bc47c3839eff8'
old_sha='3bd6f83ec9bcdc9cfc70e88091ba46db215e6ad374e261248e227d1eda9a9203'
summaries=[]
for key,tool,pin,planpin in [
 ('pf3-v2','deduplicate_pf3_v2_exact_three_receipts.py','9d8e759ff1730ee099a6e0a48f5338dcf12d70d33a031e97f4e3160490500f08','d04fbb3b2cc39b81db328663427e7704101eb97d4c5d9977d0f857cc56ca52f0'),
 ('pf3-original','deduplicate_pf3_original_exact_three_receipts.py','26b7702766767e9b7571ec9a88d2a1b4e3bb4339dfa95306b8a5159bea83f401','b832b1ceded6e891be40bf6a5a61472b34e4235fc770093aef0fe4c292f0f1d9'),
]:
    p=B/(key+'-exact-three-proof/PLAN.json');plan=json.loads(p.read_bytes());f=B/tool;text=f.read_text();ast.parse(text)
    ck(key+' exact plan pin',H(p)==planpin);ck(key+' exact executor pin',H(f)==pin)
    changes=[('release-exact-three-proof/PLAN.json',key+'-exact-three-proof/PLAN.json'),(old_plan_pin,planpin),('/workspace/release-receipt-archive-three-dedup-execution-20261023','/workspace/'+key+'-receipt-archive-three-dedup-execution-20261023'),('tests/release-evidence/20261008/geometry-main-evidence-459478e9.tar.gz',plan['members'][0]['relative']),(old_blob,plan['git_blob']),(old_sha,plan['sha256']),('39046314',str(plan['size']))]
    expected=original
    for old,new in changes:
        ck(key+' original literal exists '+old[:30],old in expected)
        expected=expected.replace(old,new)
    ck(key+' exact only seven literal groups',text==expected)
    members=plan['members'];ck(key+' exactly same three cold roots',[x['repo']for x in members]==['/workspace/geo261-cold/g261seal/'+n for n in ['p-source','a-source','l-source']])
    ck(key+' exactly same per-root expected HEADs',[x['head']for x in members]==['b6646d10751a0d85a2f03f5d24fbe1073cb78980','a12d184ec1865ad078700cea2387ac69e82ab62a','aa02a65e9d3923cc14c13340f05ed16c8b7d4fce'])
    ck(key+' metadata singleton before and exact same payloads',all(x['nlink']==1 and x['size']==plan['size'] and x['git_blob']==plan['git_blob'] and x['sha256']==plan['sha256'] and x['path']==str(Path(x['repo'])/x['relative'])for x in members))
    ck(key+' expected allocated saving only extra two allocations',plan['expected_allocated_saving']==sum(x['allocated_bytes']for x in members[1:]))
    ck(key+' cold roots barred until all groups de-linked','All three historical cold checkouts remain barred' in plan['parent_reservation']and 'including earlier groups' in plan['parent_reservation'])
    ck(key+' red census original false preserved',members[1]['terminal_receipt']['original_passed']is False)
    for x in members:
        r=x['terminal_receipt'];ck(key+' exact terminal receipt '+x['repo'],H(r['path'])==r['sha256'] and Path(r['path']).stat().st_size==r['bytes'] and bool(r['ended']))
    ck(key+' full path fresh consumer/Git/blob/alias/operation primitive unchanged',all(s in text for s in ["core['state'](members, set())","core['link_exact'](members, OUT / 'JOURNAL.jsonl', before_each=fresh_readonly_guards)","assert proc.returncode == 0",'fresh_readonly_guards()',"assert rc == 0 and count == "]))
    summaries.append({'group':key,'tool':str(f),'toolSHA256':H(f),'plan':str(p),'planSHA256':H(p),'literalEditGroups':7,'onlyPreparedNoExecution':True,'expectedAllocatedSaving':plan['expected_allocated_saving']})
ck('two PF3 theoretical configured savings exactly47554560',sum(s['expectedAllocatedSaving']for s in summaries)==47554560)
static={'role':'pre-execution exact literal adaptation peer; no import/tool/cache/source execution','checks':checks.copy(),'checkCount':len(checks),'findings':[r['label']for r in checks if not r['passed']],'exitCode':int(any(not r['passed']for r in checks)),'groups':summaries,'limits':['No PF3 payload hash, fresh consumer scan or mutation performed here. Original frozen executor must freshly recheck all before any root-authorized action.','Configured47,554,560B is not observed free bytes; original per-path inode/mtime limits and census red remain.','All prior and new archive aliases bar the three cold checkouts until every group de-linked.']}
(P/'PF3_TWO_STATIC_REVIEW.json').write_text(json.dumps(static,ensure_ascii=False,indent=2)+'\n')
checks=[]
O=Path('/workspace/full-cdp-receipt-archive-three-dedup-execution-20261023')
LAUNCH=Path('/workspace/full-cdp-receipt-archive-three-dedup-launch-20261023')
plan_path=B/'full-cdp-exact-three-proof/PLAN.json';plan=json.loads(plan_path.read_bytes());result=json.loads((O/'RESULT.json').read_bytes());commands=json.loads((O/'COMMANDS.json').read_bytes());journal=[json.loads(x)for x in(O/'JOURNAL.jsonl').read_text().splitlines()];members=plan['members'];paths=[m['path']for m in members]
ck('fullCDP original frozen plan',H(plan_path)=='71df97f8dc27676231c2bdb0ba6c88abc0c3f94d3c02fdd3ccc2cc3d26ea686a')
ck('fullCDP original frozen executor',H(B/'deduplicate_full_cdp_exact_three_receipts.py')=='49f9868aae23eee96f09238d4959c2cd3fe4955166891bc6cc911e3e7e78807f')
ck('actual terminal0 paths preserved',result['exit_code']==0 and result['all_three_paths_and_bytes_preserved'] and result['source_paths']==paths and bool(result['ended_utc']))
ck('actual25 Git metadata/stream commands',len(commands)==25 and all(x['exit_code']==0 for x in commands))
for i,row in enumerate(commands):
    request=json.loads((O/f'{i:03d}.request.json').read_bytes());ck('original argv '+str(i),request['argv']==row['argv'])
    if 'compared_bytes'in row:
        ck('Git catfile full stdout retained at three paths',row['compared_bytes']==plan['size']and row['stdout_sha256']==plan['sha256']and row['stdout_retained_at_original_paths']==paths and row['argv'][-3:]==['cat-file','blob',plan['git_blob']])
        ck('streamed catfile stderr retained',(O/f'{i:03d}.stderr.bin').read_bytes()==b'')
    else:
        for field in ['stdout','stderr']:
            raw=(O/f'{i:03d}.{field}.bin').read_bytes();ck('complete original Git stream '+str(i)+'/'+field,len(raw)==row[field+'_bytes']and hashlib.sha256(raw).hexdigest()==row[field+'_sha256'])
        repo=row['argv'][6]
        m=next(x for x in members if x['repo']==repo)
        if row['argv'][-2:]==['rev-parse','HEAD']:
            ck('original fixed historical HEAD '+str(i),(O/f'{i:03d}.stdout.bin').read_bytes().decode().strip()==m['head'])
        else:
            ck('original exact tree mode blob path '+str(i),(O/f'{i:03d}.stdout.bin').read_bytes()==('100644 blob '+plan['git_blob']+'\t'+m['relative']+'\0').encode())
ck('journal phase order',[x['event']for x in journal]==['initial_verified','before_link','temporary_link_verified','replacement_verified','before_link','temporary_link_verified','replacement_verified','complete'])
ck('journal exact alias progression',[x['expected_alias_count']for x in journal]==[1,1,2,2,2,3,3,3])
ck('journal no payload loss',journal[-1]['all_original_paths_present']and journal[-1]['bytes_unchanged'])
metadata=[]
for p in paths:
    s=Path(p).stat();metadata.append(s)
ck('retained exact3 aliases and one canonical inode',len({(s.st_dev,s.st_ino)for s in metadata})==1 and all(s.st_nlink==3 and s.st_size==plan['size']and stat.S_ISREG(s.st_mode)for s in metadata))
# Read only the one retained canonical inode; do not duplicate/archive its15MB payload.
canonical=Path(paths[0]);before=canonical.stat();payload_hash=H(canonical);after=canonical.stat()
ck('one retained canonical full bytes sha256',payload_hash==plan['sha256']and before.st_ino==after.st_ino and before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns)
for i,m in enumerate(members):
    s=Path(m['path']).stat();final=result['final_metadata'][i]
    ck('final recorded inode/mode/size/mtime alias '+str(i),all(final[k]==v for k,v in {'dev':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}.items()))
    r=m['terminal_receipt'];ck('producer terminal unchanged '+str(i),H(r['path'])==r['sha256']and Path(r['path']).stat().st_size==r['bytes'])
for i in range(4):
    c=json.loads((O/f'CONSUMERS-{i:02d}.json').read_bytes());ck('fresh consumer snapshot no readable hits '+str(i),c['hits']==[] and 'unreadable'in c and bool(c['limitation']))
ck('configured saving30,720,000 not observed free delta',result['expected_allocated_saving']==plan['expected_allocated_saving']==30720000)
outer=json.loads((LAUNCH/'RESULT.json').read_bytes());request=json.loads((LAUNCH/'REQUEST.json').read_bytes());d=Path(outer['directory'])
ck('prelaunched original outer0 same reviewed tool',outer['actual_process_returncode']==0 and not outer['timeout_expired']and outer['command']==request['argv']and request['tool_sha256']==H(B/'deduplicate_full_cdp_exact_three_receipts.py'))
for field in ['stdout','stderr']:
    raw=(d/(field+'.bin')).read_bytes();ck('outer complete raw '+field,len(raw)==outer[field+'_bytes']and hashlib.sha256(raw).hexdigest()==outer[field+'_sha256'])
ck('outer stdin preserved',hashlib.sha256((d/'stdin.bin').read_bytes()).hexdigest()==outer['stdin_sha256'])
actual={'role':'completed dedup actual/retained-byte peer only; no cleanup or subject repeat','checkCount':len(checks),'checks':checks,'findings':[r['label']for r in checks if not r['passed']],'exitCode':int(any(not r['passed']for r in checks)),'actualResult':str(O/'RESULT.json'),'actualResultSHA256':H(O/'RESULT.json'),'outerResult':str(LAUNCH/'RESULT.json'),'outerSHA256':H(LAUNCH/'RESULT.json'),'commandCount':25,'retainedCanonicalPayloadSHA256':payload_hash,'retainedPayloadBytes':plan['size'],'expectedConfiguredAllocatedSaving':30720000,'observedFreeDelta':result['free_after']['/workspace']-result['free_before']['/workspace'],'limits':['Only one canonical retained inode payload was streamed; all three paths are exact same dev/inode/nlink3. No15MB payload copied into peer output.','Git catfile original stdout is retained at the three original paths and verified; not fabricated as a separate stdout.bin. Other24commands/outer streams individually retained.','Only original readable consumer snapshots checked; /proc inaccessible fields remain unknown. No new universal consumer visibility claim.','Source/terminal receipts unchanged and census originally red preserved; maintenance is not product acceptance.','All previous/new alias groups keep three cold checkouts barred until separately de-linked; original inode IDs and per-path mtimes not claimed restored.']}
(P/'FULL_CDP_DEDUP_ACTUAL_REVIEW.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'staticPath':str(P/'PF3_TWO_STATIC_REVIEW.json'),'staticSHA256':H(P/'PF3_TWO_STATIC_REVIEW.json'),'staticChecks':static['checkCount'],'staticFindings':static['findings'],'actualPath':str(P/'FULL_CDP_DEDUP_ACTUAL_REVIEW.json'),'actualSHA256':H(P/'FULL_CDP_DEDUP_ACTUAL_REVIEW.json'),'actualChecks':actual['checkCount'],'actualFindings':actual['findings']}))
raise SystemExit(static['exitCode'] or actual['exitCode'])
