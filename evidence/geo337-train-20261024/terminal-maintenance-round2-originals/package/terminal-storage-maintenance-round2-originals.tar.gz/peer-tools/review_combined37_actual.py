from pathlib import Path
import json,hashlib
P=Path('/workspace/combined-terminal-37-elf-preparation-20261023');B=Path('/workspace/combined-exact-37-elf-retirement-execution-20261023');A=Path('/workspace/combined-exact-37-elf-retirement-launch-20261023');p=json.loads((P/'PLAN.json').read_text());r=json.loads((B/'RESULT.json').read_text());o=json.loads((A/'RESULT.json').read_text());n=0;f=[]
def ck(x,s):
 global n
 n+=1
 if not x:f.append(s)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ck(r['exit_code']==o['actual_process_returncode']==0 and not o['timeout_expired'] and r['ended_utc'] and o['ended_epoch'],'actual/outerterminal0')
ck(r['sourceSHA']==p['sourceSHA'] and r['removed']==[x['path'] for x in p['targets']] and len(r['removed'])==37,'exact37scope')
for x in p['targets']:
 q=Path(x['path']);ck(not q.exists() and q.parent.is_dir(),'ELF absent parent preserved '+str(q))
for x in p['sidecars']+p['terminal_and_source_pins']:
 q=Path(x['path']);ck(q.stat().st_size==x['bytes'] and h(q)==x['sha256'],'original retained '+str(q))
ck(Path(p['cache'],'_bridge-work').is_dir(),'bridge-work retained')
consumer=json.loads((B/'CONSUMERS.json').read_text());ck(consumer['hits']==[] and isinstance(consumer['unreadable'],list) and 'Only accessible' in consumer['limitation'],'consumer observation limits')
ck(r['retired_allocated_file_bytes']==40914944 and r['no_receipt_or_source_removed'],'allocation/source limits')
ck(json.loads((B/'PROGRESS.json').read_text())['removed']==r['removed'],'final exact removal journal')
for name in ('stdout','stderr'):
 q=Path(o['directory'])/(name+'.bin');ck(q.stat().st_size==o[name+'_bytes'] and h(q)==o[name+'_sha256'],'original outer '+name)
report={'schema':'independent-combined37-actual-retirement-peer/1','checks':n,'exit_code':int(bool(f)),'findings':f,'original_actual_exit':0,'removed_count':37,'configured_allocated_bytes':40914944,'observed_free_before':r['free_before'],'observed_free_after':r['free_after'],'result_sha256':h(B/'RESULT.json'),'outer_receipt_sha256':h(A/'RESULT.json'),'scope':'Exact37 absent/parents retained; all37 sidecars and6 original terminal/source pins fullhash unchanged, original outer exit/fullstreams, journal and accessible-process limits checked. No executable rehash after removal or subject rerun. Historical single-full-command false preserved separately from two-phase recovery0.'};q=Path('/tmp/train337-adversarial/COMBINED_37_ELF_ACTUAL_PEER.json');q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':n,'exit_code':report['exit_code'],'findings':f,'path':str(q),'sha256':h(q)}));raise SystemExit(report['exit_code'])
