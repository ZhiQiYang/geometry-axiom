import ast,hashlib,json,re,sys
from pathlib import Path
B=Path('/workspace/combined-terminal-37-elf-preparation-20261023');n=0;f=[]
def ck(v,s):
 global n
 n+=1
 if not v:f.append(s)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((B/'PLAN.json').read_text());tool=B/'retire_exact_37_terminal_elf_caches.py';txt=tool.read_text();tree=ast.parse(txt);old=Path('/workspace/seal-terminal-95-elf-preparation-20261023/retire_exact_95_terminal_elf_caches.py').read_text()
ck(h(B/'PLAN.json')=='aa10b23cd0bde4b036668cac14944dbc877b33f6e78c40343636845cc771681c','exactplan');ck(h(tool)=='80799a6a24b8843541445fe051d7f07a939d5ecbf82019fa004d8d403d253d1c','exacttool');ck(h('/workspace/clear_terminal_chrome_caches.py')=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','originalguard')
items=p['targets'];cache=Path('/workspace/geo299316-ledger-environment-retry-e40762e9-r2/cache');ck(p['cache']==str(cache) and len(items)==len({x['path'] for x in items})==37 and sum(x['allocated_bytes'] for x in items)==40914944,'exact37scope')
for x in items:
 q=Path(x['path']);rel=q.relative_to(cache).as_posix();ck(bool(re.fullmatch(r'(?:M\d+/bridge-(?:mutant|restored)/bridge|_bridge-baseline/[0-9a-f]{40}/bridge)',rel)) and x['kind']=='bridge' and x['nlink']==1,'target '+rel)
 sp=Path(x['fingerprint_path']);ck(str(sp)==str(q)+'.fingerprint.json' and h(sp)==x['fingerprint_sha256'] and json.loads(sp.read_text())['exe_sha256']==x['sha256'],'sidecar expected ELF '+rel)
for x in p['terminal_and_source_pins']+p['sidecars']:
 q=Path(x['path']);ck(q.stat().st_size==x['bytes'],'retained size '+str(q))
 if x['bytes']<1000000:ck(h(q)==x['sha256'],'retained small originalhash '+str(q))
r=json.loads(Path(p['terminal_and_source_pins'][0]['path']).read_text());ck(r['source_sha']==p['sourceSHA']=='e40762e99b078335d78c65a3a2682a0c9ab875d0' and r['exit_code']==0 and r['ended_utc'] and r['errors']==[],'original recovery terminal');ck(r['single_full_command_passed'] is False and r['complete_regeneration_in_two_environment_phases'] is True and r['original_core_records_byte_equivalent'] is True,'no historical full-pass relabel')
orig=json.loads(Path(p['terminal_and_source_pins'][1]['path']).read_text())
for idx in (7,8):
 row=orig[idx];ck(row['actual_process_returncode']==0 and not row['timeout_expired'] and row['ended_epoch']>row['started_epoch'],'original recovered retry/check '+str(idx))
 for stream in ('stdout','stderr'):
  raw=(Path(row['directory'])/(stream+'.bin')).read_bytes();ck(hashlib.sha256(raw).hexdigest()==row[stream+'_sha256'],'original recovery raw '+str(idx)+stream)
rows=json.loads((B/'subcommands.json').read_text());ck(len(rows)==8,'four original Git existence pairs')
for row in rows:
 ck(row['actual_process_returncode']==0 and not row['timeout_expired'],'source object read0')
 for stream in ('stdout','stderr'):ck(h(Path(row['directory'])/(stream+'.bin'))==row[stream+'_sha256'],'source object stream '+stream)
for j,x in enumerate(p['source_object_proof']):
 a,b=rows[2*j:2*j+2];ck((Path(a['directory'])/'stdout.bin').read_text().strip()==x['git_blob'] and b['command']==['git','cat-file','-e',x['git_blob']],'Git object exists '+x['path'])
mut=[x for x in ast.walk(tree) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr in ('unlink','rmdir','rename','replace','chmod','rmtree')];ck(len(mut)==1 and ast.unparse(mut[0])=="Path(x['path']).unlink()",'one exact unlink')
# Shared helper implementation, initial all-target validation, repeat immediately before unlink, unchanged consumer/preservation ordering.
for name in ['identity']:
 a=next(x for x in ast.walk(ast.parse(old)) if isinstance(x,ast.FunctionDef) and x.name==name);b=next(x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name==name);ck(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),'unchanged fresh '+name)
for needle in ["g={'__name__':'_original_guard_reuse_only'","for x in items:identity(x)","identity(x)\n            Path(x['path']).unlink()","preserved()\n        assert all","g['consumer_check']([x['path'] for x in items]","assert '_bridge-work' not in p.parts","g['dump']('PROGRESS.json',result)","assert sys.flags.optimize==0"]:ck(needle in txt,'guard '+needle)
ck(p['actual_elf_hash_validated_during_preparation'] is False and 'Root reserves' in p['lease'],'fresh execution requirement/lease')
report={'schema':'independent-combined37-elf-retirement-executor-peer/1','checks':n,'exit_code':int(bool(f)),'findings':f,'tool_sha256':h(tool),'plan_sha256':h(B/'PLAN.json'),'scope':'Exact37 terminal bridges, 40914944 allocated bytes; small original metadata/sidecar/Git existence proof and original retry/check stdout/stderr examined. No ELF read/hash, delete or subject execution.','limits':['Root must reserve old cache and freshly hash/identity each ELF using pinned executor.','5.74MB historical ledger checked for retained size/pin declaration only here; executor validates original full hash before and after.','Original single-full-command false retained; two-environment-phase recovery exit0 is separate.','All _bridge-work/source/Git/raw/sidecars/locks/smoke/objects retained; accessible-proc limitation stays explicit.']}
q=Path('/tmp/train337-adversarial/COMBINED_37_ELF_EXECUTOR_PEER.json');q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':n,'exit_code':report['exit_code'],'findings':f,'report':str(q),'sha256':h(q)}));sys.exit(report['exit_code'])
