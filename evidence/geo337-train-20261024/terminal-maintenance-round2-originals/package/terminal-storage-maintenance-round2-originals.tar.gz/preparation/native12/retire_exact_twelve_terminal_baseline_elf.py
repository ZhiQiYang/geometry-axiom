"""Root-only exact native-cache retirement; preserve every sidecar, recipe and raw."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN=Path('/workspace/terminal-native-baseline-12-elf-preparation-20261024/PLAN.json')
PIN='bdab496cc89e0145cc970be169c15930719d4a6f3674d73cacc144c53b154095'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/terminal-native-exact-12-baseline-elf-retirement-execution-20261024')
ROOTS=[Path('/tmp/geometry-tests'),Path('/tmp/train337-full-native-L-7af8c5d8/preserved-global-geometry-tests')]
NAMES=['bridge','core','model-base','integrity','pf3-algorithm','engineering-json-test']
SHA='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'


def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==GUARD_PIN
    g={'__name__':'_original_guard_reuse_only','__file__':str(GUARD)}
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),g);g['OUT']=OUT;OUT.mkdir()
    result=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,
                historical_acceptance_sha=SHA,removed=[],free_before=g['free'](),
                scope='Only 12 ordinary terminal native baseline executable cache paths. No sidecar/raw/source/obj/smoke/log/fixture/Git removal.',
                original_native_r1_exit=1,original_native_r1_passed=False,
                preserved_bridge_limit='Preexisting preserved bridge differs from r1-new bridge; no claim that preserved bridge was built or executed at final L.')
    try:
        assert g['digest'](PLAN)==PIN
        plan=json.loads(PLAN.read_text());items=plan['targets']
        assert plan['sourceSHA']==SHA and plan['roots']==list(map(str,ROOTS))
        expected={str(root/name) for root in ROOTS for name in NAMES}
        assert plan['target_count']==len(items)==len({x['path'] for x in items})==12
        assert {x['path'] for x in items}==expected
        assert sum(x['allocated_bytes'] for x in items)==plan['allocated_file_bytes']==9773056
        for x in items:
            p=Path(x['path']);assert p.parent in ROOTS and p.name in NAMES
            assert x['fingerprint_path']==str(p)+'.fingerprint.json'
        def preserved():
            for x in plan['terminal_and_source_pins']+plan['sidecars']:
                p=Path(x['path']);g['ancestors'](p)
                assert p.stat().st_size==x['bytes'] and g['digest'](p)==x['sha256']
            receipt=json.loads(Path(plan['terminal_and_source_pins'][0]['path']).read_text())
            assert receipt['source_sha']==SHA and receipt['actual_exit']==1 and receipt['passed'] is False
            assert receipt['original_command']['ended_epoch'] and receipt['original_command']['actual_process_returncode']==1
            assert receipt['cache_preservation']['all_original_entries_equal'] is True
            assert receipt['cache_preservation']['preserved_path']==str(ROOTS[1])
            assert receipt['source_after']['head']==SHA and receipt['source_after']['status']==''
            prior=json.loads(Path(plan['terminal_and_source_pins'][3]['path']).read_text())
            prior_files={x['path']:x for x in prior if x['kind']=='file'}
            for x in items:
                if Path(x['path']).parent==ROOTS[1]:
                    assert prior_files[Path(x['path']).name]['sha256']==x['sha256']
                    assert prior_files[Path(x['fingerprint_path']).name]['sha256']==x['fingerprint_sha256']
        def identity(x):
            p=Path(x['path']);g['identity'](p,x,is_file=True);s=p.stat()
            assert (s.st_uid,s.st_gid)==(x['uid'],x['gid'])
            with p.open('rb') as stream:assert stream.read(4)==b'\x7fELF'
            side=Path(x['fingerprint_path']);assert g['digest'](side)==x['fingerprint_sha256']
            f=json.loads(side.read_text())
            assert f['exe_sha256']==x['sha256'] and f['fingerprint']==x['fingerprint']
            assert f['command']==x['build_command'] and f['exe_size']==x['size']
        preserved()
        for x in items:identity(x)
        g['consumer_check'](list(map(str,ROOTS)))
        for x in items:
            identity(x);Path(x['path']).unlink();result['removed'].append(x['path']);g['dump']('PROGRESS.json',result)
        preserved()
        assert all(not Path(x['path']).exists() and Path(x['path']).parent.is_dir() for x in items)
        result.update(exit_code=0,retired_allocated_file_bytes=9773056,no_receipt_or_source_removed=True,
                      rebuild='Original sidecars retain compiler recipes and per-source hashes; original preserved-cache inventories and native r1 raw retained. Future cross-toolchain identical ELF not promised.',
                      consumer_limit='Only readable proc fields observed; inaccessible fields recorded explicitly. Both caches reserved from concurrent reuse for this action.')
    except Exception as exc:result['error']=repr(exc);raise
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=g['free']())
        g['dump']('RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='removed'}))


if __name__=='__main__':main()
