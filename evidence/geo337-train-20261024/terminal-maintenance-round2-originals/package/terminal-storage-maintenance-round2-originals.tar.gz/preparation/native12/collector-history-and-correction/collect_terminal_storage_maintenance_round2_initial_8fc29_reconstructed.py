"""Bounded original maintenance records only; no ELF bodies or duplicated large ledger."""
from pathlib import Path
import datetime,hashlib,io,json,os,stat,tarfile

OUT=Path('/workspace/terminal-storage-maintenance-round2-originals-20261024')
ACTIONS=[('seal',95,92467200,'b6646d10751a0d85a2f03f5d24fbe1073cb78980'),('combined',37,40914944,'e40762e99b078335d78c65a3a2682a0c9ab875d0')]
PEERS=['SEAL_95_ELF_EXECUTOR_PEER.json','SEAL_95_ELF_ACTUAL_PEER.json','SEAL_95_ELF_INITIAL_EXISTENCE_PROOF_ASSUMPTION.json','COMBINED_37_ELF_EXECUTOR_PEER.json','COMBINED_37_ELF_ACTUAL_PEER.json']
HELPERS=['review_seal95_retirement.py','review_seal95_initial_assumption.py.txt','review_seal95_actual.py','review_combined37_retirement.py','review_combined37_actual.py']
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def main():
 OUT.mkdir();entries={};actions=[];large_pins=[]
 def add(p,n):
  p=Path(p);assert p.resolve(strict=True)==p and not p.is_symlink()
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<4*1024*1024
  assert p.name not in ['bridge','baseline.exe','_mut.exe','ledger.json'] and not p.name.endswith(('.exe','.tar.gz','.zip','.pyc'))
  assert n not in entries
  entries[n]={'source':str(p),'bytes':s.st_size,'sha256':digest(p),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'uid':s.st_uid,'gid':s.st_gid}
 def tree(root,n):
  root=Path(root);assert root.is_dir() and not root.is_symlink()
  for p in sorted(root.rglob('*')):
   assert not p.is_symlink()
   if p.is_dir() or '__pycache__' in p.parts:continue
   add(p,n+'/'+str(p.relative_to(root)))
 for stem,count,allocated,sha in ACTIONS:
  prep=Path(f'/workspace/{stem}-terminal-{count}-elf-preparation-20261023')
  actual=Path(f'/workspace/{stem}-exact-{count}-elf-retirement-execution-20261023')
  launch=Path(f'/workspace/{stem}-exact-{count}-elf-retirement-launch-20261023')
  p=json.loads((prep/'PLAN.json').read_text());r=json.loads((actual/'RESULT.json').read_text());rows=json.loads((launch/'subcommands.json').read_text())
  assert p['target_count']==count and p['allocated_file_bytes']==allocated and p['sourceSHA']==sha
  assert r['exit_code']==0 and r['retired_allocated_file_bytes']==allocated and len(r['removed'])==count
  assert len(rows)==1 and rows[0]['actual_process_returncode']==0 and rows[0]['ended_epoch'] and not rows[0]['timeout_expired']
  assert all(not Path(x['path']).exists() and Path(x['path']).parent.is_dir() for x in p['targets'])
  tree(prep,'preparation/'+stem);tree(actual,'actual/'+stem);tree(launch,'launch/'+stem)
  for k,x in enumerate(p['sidecars']):add(x['path'],f'preserved-sidecars/{stem}/{k:03d}.fingerprint.json')
  for k,x in enumerate(p['terminal_and_source_pins']):
   source=Path(x['path']);assert source.stat().st_size==x['bytes'] and digest(source)==x['sha256']
   if source.name=='ledger.json' or source.stat().st_size>=4*1024*1024:
    large_pins.append(dict(action=stem,**x,reason='Original large ledger retained at exact path; hash pinned, not duplicated into maintenance archive.'))
   else:add(source,f'preserved-terminal/{stem}/{k:03d}-'+source.name)
  actions.append({'action':stem,'sourceSHA':sha,'target_count':count,'allocated_file_bytes':allocated,'original_exit':0,'outer_exit':0,'original_free_before':r['free_before'],'original_free_after':r['free_after']})
 for n in PEERS:add(Path('/tmp/train337-adversarial')/n,'peers/'+n)
 for n in HELPERS:add(Path('/tmp/train337-adversarial')/n,'peer-tools/'+n)
 # Receipt-preserving groups; never collect any payload archive itself.
 archivebase=Path('/workspace/evidence-archive-dedup-readonly-20261023')
 for group in ['full-cdp','pf3-v2','pf3-original','pf3-official']:
  prep=archivebase/(group+'-exact-three-proof')
  actual=Path('/workspace')/(group+'-receipt-archive-three-dedup-execution-20261023')
  launch=Path('/workspace')/(group+'-receipt-archive-three-dedup-launch-20261023')
  result=json.loads((actual/'RESULT.json').read_text());rows=json.loads((launch/'subcommands.json').read_text())
  plan=json.loads((prep/'PLAN.json').read_text())
  assert result['exit_code']==0 and result['all_three_paths_and_bytes_preserved'] and rows[-1]['actual_process_returncode']==0
  tree(prep,'preparation/'+group+'-dedup');tree(actual,'actual/'+group+'-dedup');tree(launch,'launch/'+group+'-dedup')
  add(archivebase/('deduplicate_'+group.replace('-','_')+'_exact_three_receipts.py'),'tools/'+group+'-executor.py')
  actions.append({'action':group+'-exact-three-receipt-preserving-dedup','target_count':3,'allocated_file_bytes':plan['expected_allocated_saving'],'original_exit':0,'outer_exit':0,'original_free_before':result['free_before'],'original_free_after':result['free_after']})
 # Exactly the already-completed seventeen literal archive groups, without any archive payload.
 batch=Path('/tmp/cold_next_archive_batch_manifest.json')
 b=json.loads(batch.read_text());assert b['count']==17 and b['expected_allocated_saving']==158367744
 add(batch,'batch17/immutable-preparation-manifest.json')
 add('/tmp/cold_next_archive_batch_scopes.json','batch17/immutable-scopes.json')
 add('/tmp/prepare_next_cold_archive_batch.py','batch17/original-read-only-producer.py')
 for x in b['items']:
  name=x['name'];prep=Path(x['plan']).parent
  actual=Path('/workspace')/(name+'-receipt-archive-three-dedup-execution-20261023')
  launch=Path('/workspace')/(name+'-receipt-archive-three-dedup-launch-20261024')
  r=json.loads((actual/'RESULT.json').read_text());rows=json.loads((launch/'subcommands.json').read_text())
  assert digest(x['plan'])==x['plan_sha256'] and digest(x['tool'])==x['tool_sha256']
  assert r['exit_code']==0 and r['all_three_paths_and_bytes_preserved'] and rows[-1]['actual_process_returncode']==0
  tree(prep,'preparation/'+name);tree(actual,'actual/'+name);tree(launch,'launch/'+name)
  add(x['tool'],'tools/'+name+'-executor.py')
  actions.append(dict(action=name+'-exact-three-receipt-preserving-dedup',target_count=3,allocated_file_bytes=x['expected_allocated_saving'],original_exit=0,outer_exit=0,original_free_before=r['free_before'],original_free_after=r['free_after']))
 for n in ['COLD_17_EXACT_THREE_EXECUTOR_STATIC_PEER.json','COLD_17_EXACT_THREE_ACTUAL_METADATA_PEER.json']:
  add(Path('/tmp/train337-adversarial')/n,'peers/'+n)
 for n in ['review_cold17_literal_tools.py','review_cold17_actual_metadata.py']:
  add(Path('/tmp/train337-adversarial')/n,'peer-tools/'+n)
 # Subsequent exact native-cache maintenance; initial r1/old-S7 judgments are never relabeled.
 for label,prep,actual,launch,count,allocated in [
  ('native12','/workspace/terminal-native-baseline-12-elf-preparation-20261024','/workspace/terminal-native-exact-12-baseline-elf-retirement-execution-20261024','/workspace/terminal-native-exact-12-baseline-elf-retirement-launch-20261024',12,9773056),
  ('historical-s7-15','/workspace/terminal-s7-five-browser-15-elf-preparation-20261024','/workspace/terminal-s7-exact-15-runtime-elf-retirement-execution-20261024','/workspace/terminal-s7-exact-15-runtime-elf-retirement-launch-20261024',15,14745600)]:
  prep,actual,launch=map(Path,[prep,actual,launch]);p=json.loads((prep/'PLAN.json').read_text());r=json.loads((actual/'RESULT.json').read_text());rows=json.loads((launch/'subcommands.json').read_text())
  assert p['target_count']==count and p['allocated_file_bytes']==allocated and r['exit_code']==0 and r['retired_allocated_file_bytes']==allocated
  assert rows[-1]['actual_process_returncode']==0 and rows[-1]['ended_epoch']
  assert all(not Path(x['path']).exists() for x in p['targets'])
  tree(prep,'preparation/'+label);tree(actual,'actual/'+label);tree(launch,'launch/'+label)
  for k,x in enumerate(p['sidecars']):add(x['path'],f'preserved-sidecars/{label}/{k:03d}.fingerprint.json')
  pins=p.get('terminal_and_source_pins',p.get('terminal_receipts',[]))
  if 'root_historical_receipt' in p:pins=pins+[p['root_historical_receipt']]
  for k,x in enumerate(pins):
   assert digest(x['path'])==x['sha256'];add(x['path'],f'preserved-terminal/{label}/{k:03d}-'+Path(x['path']).name)
  actions.append(dict(action=label+'-terminal-ordinary-ELF-cache-retirement',sourceSHA=p['sourceSHA'],target_count=count,allocated_file_bytes=allocated,original_exit=0,outer_exit=0,original_free_before=r['free_before'],original_free_after=r['free_after']))
 for n in ['NATIVE_BASELINE_12_ELF_EXECUTOR_PEER.json','NATIVE_BASELINE_12_ELF_ACTUAL_PEER.json','HISTORICAL_S7_15_ELF_EXECUTOR_PEER.json','HISTORICAL_S7_15_ELF_ACTUAL_PEER.json']:
  add(Path('/tmp/train337-adversarial')/n,'peers/'+n)
 # Four independent external indexes: bounded immutable producer inventory, not actual Git indexes.
 q=Path('/workspace/four-external-index-retirement-publication-20261024/INDEX.json');j=json.loads(q.read_text());assert j['actualPeerChecks']==118 and j['actualPeerExit']==0
 add(q,'four-TMP-indexes/immutable-original-package-index.json')
 for x in j['members']:
  assert digest(x['sourcePath'])==x['sha256'];add(x['sourcePath'],'four-TMP-indexes/'+x['member'])
 actions.append(dict(action='four-terminal-external-rebuildable-index-caches',target_count=4,allocated_file_bytes=18432000,original_exit=0,outer_exit=0,three_probe_creators_unknown=True))
 # Second historical raw namespace relocation: retain all original paths/bytes; never duplicate its 9.76MB raw payload.
 prep=Path('/workspace/raw-terminal-relocation-preparation-20261023');p=json.loads((prep/'PLAN.second-group-only.json').read_text())
 actual=Path('/workspace/terminal-native-raw-one-relocation-execution-20261023');launch=Path('/workspace/terminal-native-raw-one-relocation-launch-20261024')
 r=json.loads((actual/'RESULT.json').read_text());rows=json.loads((launch/'subcommands.json').read_text())
 assert len(p['groups'])==1 and p['file_count']==360 and r['exit_code']==0 and r['all_original_paths_bytes_mode_mtime_uid_gid_preserved'] and rows[-1]['actual_process_returncode']==0
 for n in ['PLAN.json','PLAN.initial_128mib_workspace_reserve.json','PLAN.first-group-only.json','PLAN.second-group-only.json','relocate_exact_two_raw_directories.py','relocate_exact_first_raw_directory.py','relocate_exact_second_raw_directory.py']:
  candidate=prep/n
  if candidate.exists():add(candidate,'second-raw-relocation/preparation/'+n)
 tree(prep/'second-group-fresh-proof','second-raw-relocation/preparation/fresh-proof-and-initial-draft-history')
 add(p['guard_disjoint']['path'],'second-raw-relocation/original-guard-disjoint.json')
 tree(actual,'second-raw-relocation/actual');tree(launch,'second-raw-relocation/launch')
 add('/tmp/second-native-raw-relocation-static-peer/REVIEW.json','second-raw-relocation/peers/static-REVIEW.json')
 add('/tmp/train337-adversarial/SECOND_NATIVE_RAW_RELOCATION_ACTUAL_METADATA_PEER.json','second-raw-relocation/peers/actual-REVIEW.json')
 add('/tmp/train337-adversarial/review_second_raw_actual_metadata.py','second-raw-relocation/peer-tools/review_second_raw_actual_metadata.py')
 actions.append(dict(action='second-historical-raw-cross-filesystem-relocation',target_count=360,allocated_file_bytes=p['allocated_file_bytes'],operation='cross-filesystem-preserved-relocation-not-global-byte-reduction',original_exit=0,outer_exit=0,original_free_before=r.get('free_before'),original_free_after=r.get('free_after')))
 add(archivebase/'deduplicate_release_exact_three_receipts.py','tools/original-release-literal-reference.py')
 add(archivebase/'archive_link_core.py','tools/original-exact-three-link-core.py')
 for name in ['PF3_TWO_STATIC_REVIEW.json','FULL_CDP_DEDUP_ACTUAL_REVIEW.json','PF3_V2_DEDUP_ACTUAL_REVIEW.json','PF3_ORIGINAL_DEDUP_ACTUAL_REVIEW.json']:
  add(Path('/tmp/pf3-tools-full-cdp-dedup-independent-peer')/name,'peers/extra-dedup/'+name)
 for name in ['FULL_CDP_ARCHIVE_EXACT_THREE_EXECUTOR_PEER.json','PF3_OFFICIAL_EXACT_THREE_EXECUTOR_PEER.json','PF3_OFFICIAL_EXACT_THREE_ACTUAL_PEER.json']:
  add(Path('/tmp/train337-adversarial')/name,'peers/extra-dedup/'+name)
 for path in ['/tmp/review_pf3_tools_and_full_cdp_dedup.py','/tmp/review_pf3_v2_dedup_actual.py','/tmp/review_pf3_original_dedup_actual.py','/tmp/train337-adversarial/review_pf3_official_dedup_actual.py']:
  add(path,'peer-tools/extra-dedup/'+Path(path).name)
 add('/workspace/clear_terminal_chrome_caches.py','tools/original-consumer-and-identity-guard.py')
 add('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py','tools/original-c387-capture.py')
 add(__file__,'tools/collector.py')
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 index={'schema':'terminal-storage-maintenance-round2-originals/1','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'maintenanceOnly':True,'productGateExecutedOrRelabeled':False,'actions':actions,'allocated_scope_bytes_including_cross_fs_relocation':sum(x['allocated_file_bytes'] for x in actions),'allocated_storage_reduction_bytes':sum(x['allocated_file_bytes'] for x in actions if x.get('operation')!='cross-filesystem-preserved-relocation-not-global-byte-reduction'),'allocated_rebuildable_elf_cache_bytes':157900800,'allocated_preserving_dedup_saving':sum(x['allocated_file_bytes'] for x in actions if x['target_count']==3),'files':[dict(member=n,**x) for n,x in sorted(entries.items())],'retained_not_duplicated_large_originals':large_pins,'limits':['Expected hashes in initial ELF plans came from fingerprint sidecars; original root executors freshly full-hashed all159 targets before deleting any cache body. Historical r1 native exit1 and preserved preexisting bridge identity remain unchanged.','All raw/sidecars/smoke/obj/source/fixtures/Git and _bridge-work paths retained. No ELF archive is created.', 'All twenty-four established exact-three archive groups retain every original receipt path/byte; inode aliases inherit canonical metadata. The three cold checkouts remain barred from any writes/reuse until all aliases are de-linked. Original inode IDs cannot be reconstructed.','Original seal census false and original combined first full command failure remain historical; two-phase recovery is separately documented.','Historical tracked source materializations were already retired; fixed Git object existence was recorded, not claimed to be a fresh full source-body read.','Only readable process fields observed; original unknown lists retained.','Allocated scope reduction is not claimed equal to concurrent statvfs free deltas. Cross-filesystem relocation transfers storage rather than creating global space.', 'Batch17 actual peer during exclusive canvas independently checked metadata/raw only, not canonical archive bodies; original root executors performed full physical-byte/Git comparisons.', 'External indexes exclude real Git index/objects; three historical readonly-probe creators remain unknown as explicitly accepted by root.', 'Raw relocation retains all followed bytes/mode/mtime/uid/gid at original paths through symlinks; inode/device/lstat identity and brief switch-gap differ. Original second-native collection remains partial, not full native. Its actual peer during exclusive canvas independently checked metadata/outer streams but did not rehash 9.76MB bodies; original root executor recorded full copy/byte verification.'], 'previous_seven_maintenance_archive_sha256':'eba221475730fefff24833b058e4aa5adc365771e1a4b9875341dc08aba3c51a'}
 dump(OUT/'INDEX.json',index);archive=OUT/'terminal-storage-maintenance-round2-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result={'exit_code':0,'member_count':len(entries),'payload_bytes':total,'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive),'index_sha256':digest(OUT/'INDEX.json'),'original_bytes_before_after_and_tar_roundtrip':True}
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))

if __name__=='__main__':main()
