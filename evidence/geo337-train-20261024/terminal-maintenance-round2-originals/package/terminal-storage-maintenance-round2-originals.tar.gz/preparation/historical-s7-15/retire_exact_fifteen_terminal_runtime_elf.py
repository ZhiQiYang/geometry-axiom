"""Root-only: five historical terminal noncanvas jobs' exact ordinary runtime ELFs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN=Path('/workspace/terminal-s7-five-browser-15-elf-preparation-20261024/PLAN.json')
PIN='c6f3cd7ef0ab3038bcbb8a50bd2367e9226d6985268c62e962bbc02fc1860e81'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/terminal-s7-exact-15-runtime-elf-retirement-execution-20261024')
ROOT=Path('/tmp/g288s7')
SHA='13d02c1db7022145a52ee063286a558e595eb212'
JOBS=['documents','assembly','grid','space','timber']
NAMES=['bridge','core','model-base']


def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==GUARD_PIN
    g={'__name__':'_original_guard_reuse_only','__file__':str(GUARD)}
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),g);g['OUT']=OUT;OUT.mkdir()
    result=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,
                historical_sourceSHA=SHA,removed=[],free_before=g['free'](),
                scope='Only 15 ordinary runtime executable cache paths from five historical terminal noncanvas jobs. Historical canvas and all live final-L paths excluded.',
                historical_results_unchanged=True)
    try:
        assert g['digest'](PLAN)==PIN
        plan=json.loads(PLAN.read_text());items=plan['targets'];groups=plan['groups']
        assert plan['sourceSHA']==SHA and plan['root']==str(ROOT)
        assert [x['job'] for x in groups]==JOBS
        expected=set()
        for group in groups:
            tmp=ROOT/'tmp/workflow'/group['job'];run=Path(group['runtime_directory'])
            assert group['temporary_directory']==str(tmp) and run.parent==tmp/'geometry-runtime'
            assert len(run.name)==20 and all(c in '0123456789abcdef' for c in run.name)
            assert group['receipt_path']==str(ROOT/'workflow'/group['job']/'receipt.json')
            expected.update(str(run/name) for name in NAMES)
        assert plan['target_count']==len(items)==len({x['path'] for x in items})==15
        assert {x['path'] for x in items}==expected
        assert sum(x['allocated_bytes'] for x in items)==plan['allocated_file_bytes']==14745600
        for x in items:
            p=Path(x['path']);assert x['job'] in JOBS and p.name==x['kind'] and p.name in NAMES
            assert x['fingerprint_path']==str(p)+'.fingerprint.json'
        def preserved():
            pins=plan['terminal_receipts']+plan['sidecars']+[plan['root_historical_receipt']]
            for x in pins:
                p=Path(x['path']);g['ancestors'](p)
                assert p.stat().st_size==x['bytes'] and g['digest'](p)==x['sha256']
            for group in groups:
                r=json.loads(Path(group['receipt_path']).read_text())
                assert r['sha']==SHA and r['job']==group['job'] and r['status']=='完成' and r['exit_code']==0 and r['ended']
                assert r['temporary_directory']==group['temporary_directory']
        def identity(x):
            p=Path(x['path']);g['identity'](p,x,is_file=True);s=p.stat()
            assert (s.st_uid,s.st_gid)==(x['uid'],x['gid'])
            with p.open('rb') as stream:assert stream.read(4)==b'\x7fELF'
            side=Path(x['fingerprint_path']);assert g['digest'](side)==x['fingerprint_sha256']
            f=json.loads(side.read_text())
            assert f['exe_sha256']==x['sha256'] and f['fingerprint']==x['fingerprint']
            assert f['command']==x['build_command'] and f['exe_size']==x['size']
        preserved()
        for x in items:identity(x)
        g['consumer_check']([x['temporary_directory'] for x in groups])
        for x in items:
            identity(x);Path(x['path']).unlink();result['removed'].append(x['path']);g['dump']('PROGRESS.json',result)
        preserved()
        assert all(not Path(x['path']).exists() and Path(x['path']).parent.is_dir() for x in items)
        result.update(exit_code=0,retired_allocated_file_bytes=14745600,no_receipt_or_source_removed=True,
                      rebuild='Original source fingerprints, complete compiler recipes and all raw retained; no future cross-toolchain identical-ELF guarantee.',
                      consumer_limit='Only readable proc fields observed; inaccessible fields recorded explicitly. Five historical job temporary directories reserved from concurrent reuse for this action.')
    except Exception as exc:result['error']=repr(exc);raise
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=g['free']())
        g['dump']('RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='removed'}))


if __name__=='__main__':main()
