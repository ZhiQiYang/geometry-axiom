"""Root-only historical combined-recovery cache retirement: remove exact rebuildable ELFs only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN=Path('/workspace/combined-terminal-37-elf-preparation-20261023/PLAN.json')
PIN='aa10b23cd0bde4b036668cac14944dbc877b33f6e78c40343636845cc771681c'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/combined-exact-37-elf-retirement-execution-20261023')
CACHE=Path('/workspace/geo299316-ledger-environment-retry-e40762e9-r2/cache')
SHA='e40762e99b078335d78c65a3a2682a0c9ab875d0'


def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==GUARD_PIN
    g={'__name__':'_original_guard_reuse_only','__file__':str(GUARD)}
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),g);g['OUT']=OUT;OUT.mkdir()
    result=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,
                sourceSHA=SHA,removed=[],free_before=g['free'](),
                prerequisite='Root invokes only after independent exact historical-cache scope/tool peer; reserve this old cache against reuse.',
                scope='37 exact terminal rebuildable ELF caches only. All raw, sidecars, smoke, source, fixtures, Git and entire _bridge-work retained.')
    try:
        assert g['digest'](PLAN)==PIN
        plan=json.loads(PLAN.read_text());items=plan['targets']
        assert plan['sourceSHA']==SHA and plan['cache']==str(CACHE)
        assert plan['target_count']==len(items)==len({x['path'] for x in items})==37
        assert sum(x['allocated_bytes'] for x in items)==40914944
        assert sum(x['kind']=='core' for x in items)==0 and sum(x['kind']=='bridge' for x in items)==37
        for x in items:
            p=Path(x['path']);assert p.is_relative_to(CACHE) and p.name=='bridge'
            assert '_bridge-work' not in p.parts and 'repo' not in p.relative_to(CACHE).parts
            assert x['fingerprint_path']==str(p)+'.fingerprint.json'
        def preserved():
            for x in plan['terminal_and_source_pins']+plan['sidecars']:
                p=Path(x['path']);assert p.stat().st_size==x['bytes'] and g['digest'](p)==x['sha256']
            receipt=json.loads(Path(plan['terminal_and_source_pins'][0]['path']).read_text())
            assert receipt['source_sha']==SHA and receipt['exit_code']==0 and receipt['ended_utc']
            assert receipt['new_cache']==str(CACHE) and receipt['environment']['MUTATE_CACHE']==str(CACHE)
            assert receipt['single_full_command_passed'] is False and receipt['complete_regeneration_in_two_environment_phases'] is True
            assert receipt['original_core_records_byte_equivalent'] is True
            assert len(plan['source_object_proof'])==4
            assert all(x['sourceSHA']==SHA and len(x['git_blob'])==40 for x in plan['source_object_proof'])
        def identity(x):
            p=Path(x['path']);g['identity'](p,x,is_file=True);s=p.stat()
            assert (s.st_uid,s.st_gid)==(x['uid'],x['gid'])
            with p.open('rb') as stream:assert stream.read(4)==b'\x7fELF'
            side=Path(x['fingerprint_path']);assert g['digest'](side)==x['fingerprint_sha256']
            assert json.loads(side.read_text())['exe_sha256']==x['sha256']
        preserved()
        for x in items:identity(x)
        # Narrow consumer prefixes exclude the retained SEED and its legitimate browserpool readers.
        g['consumer_check']([x['path'] for x in items]+sorted({str(Path(x['path']).parent) for x in items}))
        for x in items:
            identity(x)
            Path(x['path']).unlink()
            result['removed'].append(x['path'])
            g['dump']('PROGRESS.json',result)
        preserved()
        assert all(not Path(x['path']).exists() and Path(x['path']).parent.is_dir() for x in items)
        result.update(exit_code=0,retired_allocated_file_bytes=40914944,
                      no_receipt_or_source_removed=True,
                      rebuild='Preserved historical Git source objects/registry, original compile metadata/full raw and fingerprint sidecars; no promise of future cross-toolchain byte-identical ELF. Historical full first command remains failed; original environment recovery is separately recorded.',
                      consumer_limit='Only readable proc fields observed; inaccessible fields retained explicitly.')
    except Exception as exc:result['error']=repr(exc);raise
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=g['free']())
        g['dump']('RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='removed'}))


if __name__=='__main__':main()
