"""Root-only historical seal cache retirement: remove exact rebuildable ELFs only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN=Path('/workspace/seal-terminal-95-elf-preparation-20261023/PLAN.json')
PIN='fc2b29246ee95e8323c16a90b7c889fc03c1cccc933cb59e142524cab99a8208'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/seal-exact-95-elf-retirement-execution-20261023')
CACHE=Path('/workspace/geo261-cold/g261seal/new-mutation-cache')
SHA='b6646d10751a0d85a2f03f5d24fbe1073cb78980'


def main():
    assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==GUARD_PIN
    g={'__name__':'_original_guard_reuse_only','__file__':str(GUARD)}
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),g);g['OUT']=OUT;OUT.mkdir()
    result=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,
                sourceSHA=SHA,removed=[],free_before=g['free'](),
                prerequisite='Root invokes only after independent exact historical-cache scope/tool peer; reserve this old cache against reuse.',
                scope='95 exact terminal rebuildable ELF caches only. All raw, sidecars, smoke, source, fixtures, Git and entire _bridge-work retained.')
    try:
        assert g['digest'](PLAN)==PIN
        plan=json.loads(PLAN.read_text());items=plan['targets']
        assert plan['sourceSHA']==SHA and plan['cache']==str(CACHE)
        assert plan['target_count']==len(items)==len({x['path'] for x in items})==95
        assert sum(x['allocated_bytes'] for x in items)==92467200
        assert sum(x['kind']=='core' for x in items)==58 and sum(x['kind']=='bridge' for x in items)==37
        for x in items:
            p=Path(x['path']);assert p.is_relative_to(CACHE) and p.name in ['baseline.exe','_mut.exe','bridge']
            assert '_bridge-work' not in p.parts and 'repo' not in p.relative_to(CACHE).parts
            assert x['fingerprint_path']==str(p)+'.fingerprint.json'
        def preserved():
            for x in plan['terminal_and_source_pins']+plan['sidecars']:
                p=Path(x['path']);assert p.stat().st_size==x['bytes'] and g['digest'](p)==x['sha256']
            receipt=json.loads(Path(plan['terminal_and_source_pins'][0]['path']).read_text())
            census=json.loads(Path(plan['terminal_and_source_pins'][1]['path']).read_text())
            assert receipt['source_sha']==SHA and receipt['stage_execution_passed'] is True and receipt['finished_utc']
            assert receipt['environment']['MUTATE_CACHE']=='/tmp/g261seal/new-mutation-cache'
            assert receipt['commands'][14]['actual_process_returncode']==0 and receipt['commands'][14]['ended_utc']
            assert census['finished_utc'] and census['stage_execution_passed'] is False
            assert len(plan['source_object_proof'])==4
            assert all(x['sourceSHA']==SHA and len(x['git_blob'])==40 for x in plan['source_object_proof'])
        def identity(x):
            p=Path(x['path']);g['identity'](p,x,is_file=True);s=p.stat()
            assert (s.st_uid,s.st_gid)==(x['uid'],x['gid'])
            with p.open('rb') as stream:assert stream.read(4)==b'\x7fELF'
            side=Path(x['fingerprint_path']);assert g['digest'](side)==x['fingerprint_sha256']
            assert json.loads(side.read_text())['exe_sha256']==x['sha256']
        preserved()
        for x in items:identity(x)
        # Narrow consumer prefixes exclude the retained SEED and its legitimate browserpool readers.
        g['consumer_check']([x['path'] for x in items]+sorted({str(Path(x['path']).parent) for x in items}))
        for x in items:
            identity(x)
            Path(x['path']).unlink()
            result['removed'].append(x['path'])
            g['dump']('PROGRESS.json',result)
        preserved()
        assert all(not Path(x['path']).exists() and Path(x['path']).parent.is_dir() for x in items)
        result.update(exit_code=0,retired_allocated_file_bytes=92467200,
                      no_receipt_or_source_removed=True,
                      rebuild='Preserved historical Git source objects/registry, original compile metadata/full raw and fingerprint sidecars; no promise of future cross-toolchain byte-identical ELF. Historical census remains red.',
                      consumer_limit='Only readable proc fields observed; inaccessible fields retained explicitly.')
    except Exception as exc:result['error']=repr(exc);raise
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=g['free']())
        g['dump']('RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='removed'}))


if __name__=='__main__':main()
