"""Root-only preserving relocation of one closed raw directory, not deletion of receipts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import sys

PLAN = Path('/workspace/raw-terminal-relocation-preparation-20261023/PLAN.first-group-only.json')
PIN = '52adc474f1f2eb80e73c3bd505179abacbc471f4829a20b2869385952e7c967c'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT = Path('/workspace/terminal-raw-one-relocation-execution-20261023')
DEST_PARENT = Path('/workspace/geo337-preserved-originals')
SOURCES = ['/tmp/g261p2bind2/subcommands']
ORIGINAL_TWO = SOURCES + ['/tmp/g288-final-native-3d681636/subcommands']
DESTINATIONS = [str(DEST_PARENT / 'g261p2bind2-subcommands-20261023')]


def main():
    assert sys.flags.optimize == 0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest() == GUARD_PIN
    guard = {'__name__': '_original_read_only_guards', '__file__': str(GUARD)}
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard)
    guard['OUT'] = OUT
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=1,
                  policy='Root reserves exact one historical raw namespace; source paths remain readable via destination symlink after successful relocation.',
                  copies_verified=[], switched=[], retired_materializations=0,
                  cross_fs_limit='Brief rename/install pathname gap, not atomic across FS. Failed switch restores hold only if original pathname absent; no unknown path overwritten.',
                  metadata_limit='Followed file/directory bytes, mode, mtime, uid/gid retained. Device/inode and symlink lstat metadata differ; original identities remain in plan.',
                  failure_policy='Preserve destination and any source/hold copies. Never auto-delete a failed partial copy.',
                  free_before=guard['free']())

    def event(name, **fields):
        with (OUT / 'JOURNAL.jsonl').open('ab') as stream:
            stream.write((json.dumps(dict(event=name, **fields), sort_keys=True) + '\n').encode())
            stream.flush(); os.fsync(stream.fileno())

    try:
        assert guard['digest'](PLAN) == PIN
        plan = json.loads(PLAN.read_text()); groups = plan['groups']
        assert [x['source'] for x in groups] == SOURCES
        assert [x['destination'] for x in groups] == DESTINATIONS
        assert plan['file_count'] == 195 and plan['allocated_file_bytes'] == 82776064
        assert plan['logical_bytes'] == 82518009 and plan['workspace_reserve_bytes'] == 100663296
        for p in [DEST_PARENT, *DEST_PARENT.parents]:
            if p.exists(): assert p.is_dir() and not p.is_symlink(), str(p)
        DEST_PARENT.mkdir(exist_ok=True)
        guard['ancestors'](DEST_PARENT)
        needed = sum(((f['size'] + 4095) // 4096) * 4096 for g in groups for f in g['files'])
        needed += sum(len(g['directories']) * 4096 for g in groups) + 4 * 1024 * 1024
        assert guard['free']()['/workspace'] >= needed + plan['workspace_reserve_bytes'], 'workspace copy plus 96MiB reserve unavailable'

        def external_guards():
            assert guard['digest'](PLAN) == PIN
            disjoint = plan['guard_disjoint']
            assert guard['digest'](Path(disjoint['path'])) == disjoint['sha256']
            rows = json.loads(Path(disjoint['path']).read_text())
            assert len(rows) == 4 and all(r['intersection'] == [] and r['prefix'] in ORIGINAL_TWO for r in rows)
            for row in rows:
                assert guard['digest'](Path(row['index'])) == row['index_sha256']
            for group in groups:
                t = group['terminal']
                assert guard['digest'](Path(t['receipt_path'])) == t['receipt_sha256']
                assert guard['digest'](Path(t['subcommands_path'])) == t['subcommands_sha256']

        def inventory(root, group, *, original, logical=False):
            if logical:
                assert root == Path(group['source']) and root.is_symlink()
                assert root.resolve(strict=True) == Path(group['destination'])
            else:
                assert not root.is_symlink()
            expected = {x['relative'] for x in group['files'] + group['directories'] if x['relative']}
            assert {str(p.relative_to(root)) for p in root.rglob('*')} == expected, str(root)
            for d in group['directories']:
                p = root / d['relative']
                assert p.is_dir() and (not p.is_symlink() or (logical and p == root))
                s = p.stat()
                for key, actual in [('mode',s.st_mode),('mtime_ns',s.st_mtime_ns),('uid',s.st_uid),('gid',s.st_gid)]:
                    assert actual == d[key], (str(p), key)
                if original: guard['identity'](p, d, is_file=False)
            for item in group['files']:
                p = root / item['relative']; s = p.lstat()
                assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and not p.is_symlink()
                for key, actual in [('mode',s.st_mode),('size',s.st_size),('mtime_ns',s.st_mtime_ns),('uid',s.st_uid),('gid',s.st_gid)]:
                    assert actual == item[key], (str(p), key)
                if original: guard['identity'](p, item, is_file=True)
                else: assert guard['digest'](p) == item['sha256']

        external_guards()
        for group in groups:
            source, destination = Path(group['source']), Path(group['destination'])
            assert source.resolve(strict=True) == source
            assert group['hold'] == str(source) + '.relocation-hold'
            assert group['pending_link'] == str(source) + '.relocation-link'
            assert all(not os.path.lexists(p) for p in [destination, group['hold'], group['pending_link']])
            inventory(source, group, original=True)
        guard['consumer_check'](SOURCES + DESTINATIONS)
        event('initial_verified', sources=SOURCES, destinations=DESTINATIONS,
              files=195, allocated_source_bytes=82776064, logical_bytes=82518009)
        # The selected destination is fully copied and verified before its source namespace is switched.
        for group in groups:
            source, destination = Path(group['source']), Path(group['destination'])
            event('before_copy', source=str(source), destination=str(destination))
            destination.mkdir()
            assert source.stat().st_dev != destination.stat().st_dev, 'expected cross-FS copy'
            for item in sorted(group['directories'], key=lambda x:len(Path(x['relative']).parts)):
                if item['relative']: (destination / item['relative']).mkdir()
            for item in group['files']:
                src, dst = source / item['relative'], destination / item['relative']
                guard['identity'](src, item, is_file=True)
                shutil.copy2(src, dst, follow_symlinks=False)
                with dst.open('rb') as stream: os.fsync(stream.fileno())
                assert guard['digest'](dst) == item['sha256']
            for item in sorted(group['directories'], key=lambda x:len(Path(x['relative']).parts), reverse=True):
                shutil.copystat(source / item['relative'], destination / item['relative'], follow_symlinks=False)
            inventory(source, group, original=True)
            inventory(destination, group, original=False)
            result['copies_verified'].append(group['source'])
            event('copy_all_bytes_and_metadata_verified', source=str(source), destination=str(destination))
        external_guards()
        guard['consumer_check'](SOURCES + DESTINATIONS)
        (OUT / 'CONSUMERS-before-switch.json').write_bytes((OUT / 'CONSUMERS.json').read_bytes())
        for group in groups:
            source, destination = Path(group['source']), Path(group['destination'])
            hold, pending = Path(group['hold']), Path(group['pending_link'])
            external_guards(); inventory(source, group, original=True); inventory(destination, group, original=False)
            assert all(not os.path.lexists(p) for p in [hold, pending])
            os.symlink(str(destination), pending, target_is_directory=True)
            event('before_hold_and_install', source=str(source), hold=str(hold), pending=str(pending))
            os.rename(source, hold)
            try:
                assert not os.path.lexists(source)
                os.replace(pending, source)
            except Exception as install_error:
                event('install_failed', error=repr(install_error), source_present=os.path.lexists(source))
                if not os.path.lexists(source):
                    os.rename(hold, source)
                    event('original_hold_restored_without_overwriting_unknown_path', source=str(source))
                raise
            assert source.is_symlink() and os.readlink(source) == str(destination)
            assert source.resolve(strict=True) == destination
            # Logical original paths now refer to the complete verified destination.
            inventory(source, group, original=False, logical=True)
            inventory(hold, group, original=True)
            result['switched'].append(group['source'])
            event('original_path_symlink_verified', source=str(source), target=str(destination))
            for item in group['files']:
                old = hold / item['relative']; live = source / item['relative']
                guard['identity'](old, item, is_file=True)
                assert live.resolve(strict=True) == destination / item['relative']
                assert guard['digest'](live) == item['sha256']
                event('before_retiring_verified_old_materialization', source=group['source'], relative=item['relative'], sha256=item['sha256'])
                old.unlink()
                result['retired_materializations'] += 1
            for item in sorted(group['directories'], key=lambda x:len(Path(x['relative']).parts), reverse=True):
                (hold / item['relative']).rmdir()
            assert not os.path.lexists(hold) and not os.path.lexists(pending)
            inventory(source, group, original=False, logical=True)
            event('relocation_complete', source=str(source), destination=str(destination))
        external_guards()
        assert result['retired_materializations'] == 195
        result.update(exit_code=0, all_original_paths_bytes_mode_mtime_uid_gid_preserved=True,
                      retired_original_allocated_file_bytes=82776064,
                      no_receipt_content_removed=True, no_product_test_execution=True)
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_after'] = guard['free']()
        guard['dump']('RESULT.json', result)
        print(json.dumps(result))


if __name__ == '__main__': main()
