from pathlib import Path
import json,hashlib,stat,os
B=Path('/workspace/raw-terminal-relocation-preparation-20261023');O=Path('/workspace/terminal-native-raw-one-relocation-execution-20261023');X=Path('/workspace/terminal-native-raw-one-relocation-launch-20261024');R=Path('/tmp/train337-adversarial/SECOND_NATIVE_RAW_RELOCATION_ACTUAL_METADATA_PEER.json')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=0;findings=[]
def ck(v,label):
 global checks
 checks+=1
 if not v:findings.append(label)
p=B/'PLAN.second-group-only.json';t=B/'relocate_exact_second_raw_directory.py';d=json.loads(p.read_text());g=d['groups'][0];r=json.loads((O/'RESULT.json').read_text());x=json.loads((X/'RESULT.json').read_text())
ck(h(p)=='141e095c0235841d4c06d301f2d7adad57abb1c22a1ac94dd0a3dbf56e78fe5b','plan pin');ck(h(t)=='ccc9c416764c94e24d038ea45030bb954785453b7e94e3a18736a8f4b02d28fa','executor pin')
ck(len(d['groups'])==1 and g['source']=='/tmp/g288-final-native-3d681636/subcommands','exact single historical scope');ck(r['exit_code']==0 and r['ended_utc'] and x['actual_process_returncode']==0 and not x['timeout_expired'],'true terminal exits');ck(x['command'][-1]==str(t),'actual executable');ck(x['environment']['PYTHONOPTIMIZE'] is None,'assertions enabled')
s=Path(g['source']);dst=Path(g['destination']);ck(s.is_symlink() and os.readlink(s)==str(dst) and s.resolve(strict=True)==dst,'original namespace symlink');ck(dst.is_dir() and not dst.is_symlink(),'destination ordinary directory')
for key in ['hold','pending_link']:ck(not os.path.lexists(g[key]),key+' absent')
ck(len(g['files'])==360 and len(g['directories'])==73,'exact counts');ck(sum(a['size'] for a in g['files'])==9760495,'logical bytes');ck(sum(a['allocated_bytes'] for a in g['files'])==10346496,'original allocated bytes')
expected={a['relative'] for a in g['files']+g['directories'] if a['relative']};ck({str(a.relative_to(dst)) for a in dst.rglob('*')}==expected,'complete exact destination membership')
for a in g['directories']:
 q=dst/a['relative'];z=q.lstat();ck(stat.S_ISDIR(z.st_mode) and not q.is_symlink(),'ordinary directory '+a['relative']);ck((z.st_mode,z.st_mtime_ns,z.st_uid,z.st_gid)==tuple(a[k] for k in ['mode','mtime_ns','uid','gid']),'directory preserved metadata '+a['relative'])
for a in g['files']:
 q=s/a['relative'];z=q.lstat();ck(stat.S_ISREG(z.st_mode) and z.st_nlink==1 and not q.is_symlink(),'ordinary retained file '+a['relative']);ck(q.resolve(strict=True)==dst/a['relative'],'retained logical path '+a['relative']);ck((z.st_size,z.st_mode,z.st_mtime_ns,z.st_uid,z.st_gid)==tuple(a[k] for k in ['size','mode','mtime_ns','uid','gid']),'retained file metadata '+a['relative'])
term=g['terminal']
for key in ['receipt','subcommands']:ck(h(term[key+'_path'])==term[key+'_sha256'],'historical terminal '+key)
commands=json.loads(Path(term['subcommands_path']).read_text());ck(len(commands)==72 and all(v['actual_process_returncode']==0 for v in commands),'original 72 commands retained (partial native only)')
j=[json.loads(a) for a in (O/'JOURNAL.jsonl').read_text().splitlines()];ret=[a for a in j if a['event']=='before_retiring_verified_old_materialization'];ck(len(ret)==360,'retirement journal count');ck([(a['relative'],a['sha256']) for a in ret]==[(a['relative'],a['sha256']) for a in g['files']],'journal all original file hashes in exact order');ck([a['event'] for a in j[:5]]==['initial_verified','before_copy','copy_all_bytes_and_metadata_verified','before_hold_and_install','original_path_symlink_verified'],'journal copy verify before namespace switch');ck(j[-1]['event']=='relocation_complete','journal completed');ck(all(a.get('source',g['source'])==g['source'] for a in j),'journal scope')
for name in ['CONSUMERS.json','CONSUMERS-before-switch.json']:
 v=json.loads((O/name).read_text());ck(v['hits']==[] and bool(v['unreadable']) and 'inaccessible' in v['limitation'],'observable consumers and explicit unknown '+name)
for label in ['stdout','stderr']:
 q=Path(x['directory'])/(label+'.bin');ck(h(q)==x[label+'_sha256'] and q.stat().st_size==x[label+'_bytes'],'outer exact '+label)
ck(r['copies_verified']==r['switched']==[g['source']] and r['retired_materializations']==360,'actual selected scope/count');ck(r['all_original_paths_bytes_mode_mtime_uid_gid_preserved'] and r['no_receipt_content_removed'],'executor full-byte guards recorded');ck(d['workspace_reserve_bytes']==96*1024*1024,'reserve unchanged')
report=dict(schema='independent-second-historical-raw-relocation-metadata-peer/1',exit_code=int(bool(findings)),checks=checks,findings=findings,scope={'files':360,'directories':73,'historical_command_count':72,'logical_bytes':9760495,'original_allocated_file_bytes':10346496},original_process_exits={'inner':r['exit_code'],'outer':x['actual_process_returncode']},free_delta={k:r['free_after'][k]-r['free_before'][k] for k in r['free_before']},pins={str(q):h(q) for q in [p,t,O/'RESULT.json',O/'JOURNAL.jsonl',X/'RESULT.json']},limitations=['Metadata-only independent check during exclusive canvas: no new independent hash of the 9,760,495-byte relocated bodies. Executor full-byte comparisons are recorded and journal-checked, not represented as this reviewer independently rehashing those bodies.','Original paths and followed metadata checked; old device/inode and symlink lstat are intentionally different. Cross-FS switch is not atomic.','Historical partial native four-selector success is not full native or current L execution; outer L is maintenance acceptance identity.','Only accessible process fields inspected by executor; unreadable process visibility remains unknown.','No subject execution, source changes, new archive, or receipt mutation.'])
R.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(R),'sha256':h(R),'checks':checks,'findings':findings}));raise SystemExit(bool(findings))
