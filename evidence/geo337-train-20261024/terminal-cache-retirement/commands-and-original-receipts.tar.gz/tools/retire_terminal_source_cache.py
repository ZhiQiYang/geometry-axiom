"""Retain all bytes before removing only reviewed, completed rebuildable copies."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

BASE = Path('/workspace/geo323-f64-publication-20261024')
JOB = Path('/tmp/geo337-terminal-cache-retirement-20261023-r2')
OLD_ARCHIVE = Path('/tmp/geo337-terminal-cache-retirement-20261023/previously-unarchived-terminal-ELFs.tar.gz')
ALLOW = BASE / 'source-cache-inventory/CONSERVATIVE_ALLOWLIST.json'
ELFS = BASE / 'ELF_TERMINAL_CACHE_CANDIDATES.json'
PEERS = {
    '/tmp/geo324-owner-20261024/review-323-source-cache-metadata/CHECKS.json': 'f91f2b62bd7f85ba763d8ec8b3f98fe1cb0437fe43430dfdab3f9a61c1a56bec',
    '/tmp/geo324-owner-20261024/review-323-terminal-elf-candidates/CHECKS.json': '892690f42bebb34f2e79bf2ef0766c143a2521cbcf269eafb573fb4d025c1aca',
}
FORBIDDEN = [Path(p) for p in [
    '/tmp/train337-323-f64d638f-source', '/workspace/train337-ledger-cache-4f4a24d7',
    '/tmp/train337-ledger-4f4a24d7-r2', '/tmp/train337-ledger-4f4a24d7-r2-tmp',
    '/workspace/geo314-train-f64d638f-m121/source/.git/objects', '/tmp/g261-next323',
]]
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + '\n')
def free():
    return {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ['/tmp', '/workspace']}
def load_plan():
    assert sha(ALLOW.read_bytes()) == '224e6b7b8d19e5b7e2ce2d78cf4929ce0982fb562954effa70f716de3837104d'
    assert sha(ELFS.read_bytes()) == '3795ae0aff1aa520f72c773875fb09e7b5e855ff9bc3355fafcf0948207a5d77'
    for p,h in PEERS.items(): assert sha(Path(p).read_bytes()) == h
    allow = json.loads(ALLOW.read_text())
    rows = [dict(r) for r in allow['candidate_files'] if r['kind'] != 'retired_clean_tracked_checkout_source']
    assert len(rows) == 1980
    for r in json.loads(ELFS.read_text())['candidates']:
        rows.append(dict(path=r['path'], bytes=r['bytes'], expected_sha256=r['sha256'], device=r['dev'], inode=r['inode'], nlink=r['nlink'], blocks_bytes=r['allocated_bytes'], kind='terminal_archived_ELF', archived_bytes=dict(archive=r['archive_part'], archive_sha256=r['archive_part_sha256'], member=r['archive_member'], sha256=r['archive_member_sha256'], bytes=r['bytes'])))
    assert len(rows) == 2000 and len({r['path'] for r in rows}) == 2000
    for r in rows:
        p = Path(r['path'])
        assert p.is_absolute() and p.resolve() == p
        assert all(p != q and q not in p.parents for q in FORBIDDEN)
        assert '.git' not in p.parts and 'fixtures' not in p.parts and p.name != 'gmon.out'
        assert 'expected_sha256' in r
    for r in allow['named_terminal_receipts']:
        assert sha(Path(r['path']).read_bytes()) == r['sha256']
    return allow, rows
def verify_file(r, removed=0):
    p=Path(r['path']); s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and (s.st_dev,s.st_ino,s.st_size,s.st_nlink) == (r['device'],r['inode'],r['bytes'],r['nlink']-removed), str(p)
    b=p.read_bytes(); assert sha(b)==r['expected_sha256'], str(p)
    return b
def consumers(rows, label):
    paths=[r['path'] for r in rows]
    roots=['/tmp/geo323-baseline-b2445b5a-v3-r1', '/workspace/train337-323-f64d638f-v4-r1', '/workspace/train337-323-f64d638f-memo-proof', '/workspace/train337-323-f64d638f-I11-retry1']
    result=dict(scope='Visible live cmdline and readable cwd only; inaccessible cwd/exe not claimed inspected. Original named producers are terminal; all remaining job roots are excluded.', processes=[], errors=[], matches=[])
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid(): continue
        try:
            status=(proc/'status').read_text()
            fields={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in status.splitlines() if ':' in x}
            if fields.get('State','').startswith('Z'): continue
            raw=(proc/'cmdline').read_bytes(); text=raw.replace(b'\0',b' ').decode(errors='replace')
        except FileNotFoundError: continue
        except OSError as e:
            result['errors'].append(dict(pid=proc.name,part='cmdline/status',error=repr(e))); continue
        args=[x.decode(errors='replace') for x in raw.split(b'\0') if x]
        item=dict(pid=int(proc.name), ppid=fields.get('PPid'), name=fields.get('Name'), command=args[0] if args else None, cmdline_sha256=sha(raw))
        try: item['cwd']=os.readlink(proc/'cwd')
        except OSError as e: item['cwd_unreadable']=repr(e)
        # The current preparation/capture command mentions this script, not any old producer root.
        if any(p in text for p in paths) or any(q in text or item.get('cwd','').startswith(q) for q in roots): result['matches'].append(item)
        result['processes'].append(item)
    dump(JOB/(label+'-processes.json'),result)
    assert not result['matches'] and not result['errors'], 'Unproven live consumer; leave all selected files intact'

parser=argparse.ArgumentParser(); parser.add_argument('--execute', action='store_true'); args=parser.parse_args()
allow, rows=load_plan()
if not args.execute:
    assert not JOB.exists(); JOB.mkdir()
    before=free(); consumers(rows,'prepare')
    for r in rows: verify_file(r)
    old=[r for r in rows if r['kind']=='terminal_previously_published_rebuildable_ELF_cache']
    assert len(old)==49
    # The first preflight fully wrote this archive before detecting one relative
    # producer archive path. Preserve that failed attempt and verify its bytes.
    archive=OLD_ARCHIVE
    assert sha(archive.read_bytes())=='36613ce2b2ee95d8b0bdc024611412723a213eb7344e16e065758450983336fb'
    for i,r in enumerate(old):
        assert verify_file(r).startswith(b'\x7fELF')
        member=f'{i:03d}/'+Path(r['path']).name
        r['archived_bytes']=dict(archive=str(archive),member=member,sha256=r['expected_sha256'],bytes=r['bytes'])
    archive_sha=sha(archive.read_bytes())
    for r in old: r['archived_bytes']['archive_sha256']=archive_sha
    archives={}
    for r in rows:
        a=r['archived_bytes']; p=Path(a['archive'])
        if not p.is_absolute():
            assert p.name==str(p) and p.name.startswith('geo323-F64-completed-raw.part-') and p.name.endswith('.tar.gz')
            a['original_relative_archive']=str(p)
            a['archive']=str(BASE/p)
        archives.setdefault(a['archive'],[]).append(r)
    checked=[]
    for name, group in archives.items():
        p=Path(name); expected={r['archived_bytes']['archive_sha256'] for r in group}
        assert len(expected)==1 and sha(p.read_bytes())==next(iter(expected))
        with tarfile.open(p) as tar:
            for r in group:
                a=r['archived_bytes']; b=tar.extractfile(a['member']).read()
                assert len(b)==r['bytes'] and sha(b)==r['expected_sha256']
        checked.append(dict(path=name,sha256=next(iter(expected)),members_verified=len(group)))
    dump(JOB/'PREPARED.json',dict(schema='terminal-source-cache-retirement/1',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=rows,archives=checked,peers=PEERS,original_allowlist_sha256=sha(ALLOW.read_bytes()),terminal_receipts=allow['named_terminal_receipts'],free_before=before,free_after=free(),executed=False,retired_git_checkout_preserved=True,whole_mutant_trace_withdrawn_source_trees_preserved=True))
    print(json.dumps(dict(prepared=True,deleted=False,files=len(rows),new_archive_bytes=archive.stat().st_size,new_archive_sha256=archive_sha,prepared_sha256=sha((JOB/'PREPARED.json').read_bytes()))))
else:
    p=JOB/'PREPARED.json'; prepared=json.loads(p.read_text())
    assert not (JOB/'EXECUTED.json').exists()
    expected={r['path']:r for r in rows}
    assert set(expected)=={r['path'] for r in prepared['files']}
    rows=prepared['files']
    for r in rows:
        old=expected[r['path']]
        for key in ['expected_sha256','device','inode','nlink','bytes']: assert r[key]==old[key]
        verify_file(r)
    for r in prepared['archives']: assert sha(Path(r['path']).read_bytes())==r['sha256']
    consumers(rows,'immediate-before-execute')
    result=dict(prepared_sha256=sha(p.read_bytes()),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_before=free(),removed=[],exit_code=1,limit='No receipt, fixture, Git object, gmon, mutant/trace/withdrawn source, or retired Git checkout materialization was removed. All removed bytes remain in verified archives.')
    removed={}
    try:
        for r in rows:
            key=(r['device'],r['inode']); n=removed.get(key,0)
            verify_file(r,n)
            Path(r['path']).unlink()
            removed[key]=n+1
            result['removed'].append(dict(path=r['path'],bytes=r['bytes'],sha256=r['expected_sha256']))
        for r in allow['named_terminal_receipts']: assert sha(Path(r['path']).read_bytes())==r['sha256']
        result['exit_code']=0
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=free())
        dump(JOB/'EXECUTED.json',result)
    print(json.dumps(dict(exit_code=result['exit_code'],removed=len(result['removed']),free_before=result['free_before'],free_after=result['free_after'])))
