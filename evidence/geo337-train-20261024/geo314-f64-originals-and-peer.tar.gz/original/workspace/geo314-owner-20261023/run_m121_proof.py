#!/usr/bin/env python3
"""Run the unmodified partial M121 CLI after a root resource slot is granted.

Two local object-sharing sparse checkouts avoid materialising publication raw
archives. The original runner still checks exact source closure, judge hashes,
real builds, complete baseline/restoration and normal assertion classification.
The output is external; this never writes the repository's global ledger.
"""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import sys

CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_HASH = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
PREFIX = 'tests.test_geo314_stagger_commit.StaggerCommit.'
METHODS = [PREFIX + 'test_Q3_same_final_reference_preserves_card_then_unbind_and_rebind_order',
           PREFIX + 'test_Q3_same_final_reference_cannot_exempt_value_changing_rebind']

def digest(data):
    return hashlib.sha256(data).hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--heavy-lock', type=Path, required=True)
    args = parser.parse_args()
    require(not sys.flags.optimize, 'Optimized Python is not an assertion oracle')
    repo, out = args.repo.resolve(), args.out.resolve()
    require(repo.is_dir() and args.heavy_lock.is_file(), 'Existing source repository and root resource lock required')
    require(not out.exists() and not out.is_relative_to(repo), 'Use a fresh external output directory')
    require(len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha), 'Pass the full committed SHA')
    require(digest(CAPTURE.read_bytes()) == CAPTURE_HASH, 'Original recorder hash changed')
    frozen = Path(__file__).read_bytes()
    lock = args.heavy_lock.open('a+b')
    # Never wait silently for another compiler/browser owner.
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    out.mkdir(parents=True, exist_ok=False)
    tmp = out / 'tmp'
    tmp.mkdir()
    source = out / 'source'
    cache = out / 'mutation-cache'
    results = out / 'M121-results.json'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('GIT_', 'GEOMETRY_', 'MUTATE_'))}
    env.pop('PYTHONOPTIMIZE', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8', TMPDIR=str(tmp),
               MUTATE_CACHE=str(cache), MUTATE_RESULTS=str(results))
    spec = importlib.util.spec_from_file_location('geo314_original_capture', CAPTURE)
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    recorder = capture.Recorder(out, env, args.sha)
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    receipt = {'schema': 'geo314-m121-targeted-original-cli/1', 'sourceSHA': args.sha,
               'startedUtc': now(), 'driverSha256': digest(frozen),
               'recorderSha256': CAPTURE_HASH, 'originalCommand': [sys.executable, '-B', 'tests/mutate.py', 'M121'],
               'environment': {'platform': platform.platform(), 'python': sys.version,
                               'MUTATE_CACHE': str(cache), 'MUTATE_RESULTS': str(results), 'TMPDIR': str(tmp)},
               'globalLedgerWritten': False, 'originalCliExit': None, 'execution': None,
               'commands': recorder.rows, 'problems': [], 'endedUtc': None}
    code = 2
    def run(argv, cwd, timeout=120, check=True):
        return recorder.run(argv, cwd=cwd, timeout=timeout, check=check, source_variant='committed-source')
    def sparse_checkout(origin, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        run(['git', 'clone', '--shared', '--no-checkout', str(origin), str(destination)], out)
        run(['git', 'sparse-checkout', 'set', '--no-cone', '/*', '!/evidence/',
             '!/tests/evidence/', '!/tests/release-evidence/'], destination)
        run(['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', args.sha], destination)
    try:
        require(hard == resource.RLIM_INFINITY or hard >= 16384 * 1024, 'Stack hard limit below 16 MiB')
        resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
        _, resolved, _ = run(['git', 'rev-parse', args.sha + '^{commit}'], repo)
        require(resolved.decode().strip() == args.sha, 'Source SHA did not resolve exactly')
        sparse_checkout(repo, source)
        # Precreate the runner's normal scratch path using the same committed
        # index. Only publication/test evidence archives are sparse omitted.
        # The original runner's source/judge equality guards remain unchanged.
        scratch = cache / '_bridge-work' / args.sha / 'repo'
        sparse_checkout(source, scratch)
        row, _, _ = run(receipt['originalCommand'], source, timeout=3600, check=False)
        receipt['originalCliExit'] = row['actual_process_returncode']
        require(not row['timeout_expired'] and row['actual_process_returncode'] == 0,
                'Original partial mutation CLI did not complete with exit 0')
        table = json.loads(results.read_text(encoding='utf-8'))
        record = table['M121']
        execution = record['execution']
        receipt['execution'] = {
            'head': execution.get('head'), 'verdict': record.get('verdict'),
            'methods': execution.get('methods'), 'byteRestored': execution.get('byte_restored'),
            'originalTestExits': {name: execution[name]['exit_code'] for name in ['baseline', 'mutant', 'restored']},
            'originalBuildExits': {name: execution[name]['exit_code'] for name in ['baseline_build', 'mutant_build', 'restored_build']},
            'mutantFailures': execution['mutant']['result']['failures'],
            'ledgerPath': str(results), 'ledgerSha256': digest(results.read_bytes()),
        }
        require(execution['head'] == args.sha and record['verdict'] == 'killed', 'Original record did not prove M121 killed at the committed SHA')
        require(execution['methods'] == METHODS and all(m in execution['restored_methods'] for m in METHODS),
                'Original test/restoration list changed')
        require([execution[n]['exit_code'] for n in ['baseline', 'mutant', 'restored']] == [0, 1, 0],
                'Original test exits are not 0/1/0')
        failures = execution['mutant']['result']['failures']
        require(len(failures) == 1 and failures[0]['test'] == METHODS[1] and failures[0].get('kind') == 'assertion',
                'The controlled negative did not fail by its own normal assertion')
        require(execution['byte_restored'], 'Original runner did not restore exact source bytes')
        for directory in [source, scratch]:
            _, dirty, _ = run(['git', 'diff', '--name-only', 'HEAD'], directory)
            require(not dirty.strip(), 'Committed source was not restored cleanly')
        code = 0
    except BaseException as error:
        receipt['problems'].append(type(error).__name__ + ': ' + str(error))
        code = 2
    finally:
        if Path(__file__).read_bytes() != frozen:
            receipt['problems'].append('Driver changed during execution')
            code = 2
        receipt['endedUtc'] = now()
        receipt['collectorExit'] = code
        (out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        resource.setrlimit(resource.RLIMIT_STACK, (soft, hard))
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()
    print(json.dumps({'collectorExit': code, 'originalCliExit': receipt['originalCliExit'], 'receipt': str(out / 'receipt.json')}, ensure_ascii=False))
    return code

if __name__ == '__main__':
    raise SystemExit(main())
