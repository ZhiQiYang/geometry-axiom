from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,resource,sys,datetime
F='f64d638f15c48d2b9723b7ae9d230fb5dacb82d9'
root=Path('/workspace/geo314-train-f64d638f-m121/mutation-cache/_bridge-work')/F/'repo'
binaries=Path('/workspace/geo314-train-f64d638f-m121/mutation-cache/_bridge-baseline')/F
out=Path('/tmp/geo314-train-f64d638f-native');out.mkdir(exist_ok=False);(out/'tmp').mkdir()
lock=Path('/tmp/g261r3/heavy.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
assert not sys.flags.optimize
helper=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap',helper);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env={k:v for k,v in os.environ.items() if not k.startswith(('GEOMETRY_','MUTATE_','GIT_'))}
for k in ['NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP']:env.pop(k,None)
env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(out/'tmp'))
r=cap.Recorder(out,env,F);record={'sha':F,'source':str(root),'binaries':str(binaries),'phases':[],'commands':r.rows,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Original partial6suite103+Node inspector;no global ledger;existing M121clean scratch/baseline reused'}
def save():cap.dump(out/'receipt.json',record)
def cmd(a,**kw):return r.run(a,cwd=root,**kw)
try:
 assert cmd(['git','rev-parse','HEAD'])[1].decode().strip()==F
 assert cmd(['git','status','--porcelain=v1','--untracked-files=all'])[1]==b''
 record['ledger_before']=hashlib.sha256((root/'tests/mutants_results.json').read_bytes()).hexdigest();save()
 selectors=['py:test_geo314_stagger_commit','py:test_geo314_commit_paths','py:test_geo314_ordered_facts','py:test_geo261_wood_grid_application','py:test_geo261_native_grid_product','py:test_grid_inspector_contract']
 binding='import pathlib,sys;sys.path.insert(0,"tests");import binaries;binaries.OUT_DIR=pathlib.Path(sys.argv[1]);import run_all;raise SystemExit(run_all.main(sys.argv[2:]))'
 row,_,_=cmd([sys.executable,'-B','-c',binding,str(binaries),'--build',*[w for s in selectors for w in ('--only',s)]],timeout=7200,check=False)
 record['phases'].append({'label':'original-six-native-suites','result':row});save()
 r.env=dict(env,GEOMETRY_TEST_BRIDGE=str(binaries/'bridge'),GEOMETRY_263_TRANSCRIPT=str(out/'inspector-transcript.jsonl'))
 row,_,_=cmd(['node','--test','--test-reporter=spec','tests/test_grid_inspector_stagger.cjs'],timeout=900,check=False)
 record['phases'].append({'label':'original-node-inspector','result':row});save();r.env=env
 assert cmd(['git','rev-parse','HEAD'])[1].decode().strip()==F
 assert cmd(['git','status','--porcelain=v1','--untracked-files=all'])[1]==b''
 record['ledger_after']=hashlib.sha256((root/'tests/mutants_results.json').read_bytes()).hexdigest();assert record['ledger_before']==record['ledger_after']
 record['exit_code']=0 if all(x['result']['actual_process_returncode']==0 and not x['result']['timeout_expired'] for x in record['phases']) else 1
except BaseException as e:
 record['error']=repr(e);record['exit_code']=2
finally:
 record['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
print(json.dumps({'exit_code':record['exit_code'],'receipt':str(out/'receipt.json')}));raise SystemExit(record['exit_code'])
