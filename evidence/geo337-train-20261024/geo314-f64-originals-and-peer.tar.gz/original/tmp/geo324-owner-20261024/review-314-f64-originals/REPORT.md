# #314 F64 實際原件獨立審查

來源：`f64d638f15c48d2b9723b7ae9d230fb5dacb82d9`。只讀原收據、完整 streams／sidecars、原 Git source 與 125 件 raw index；沒有重跑原測試、編譯、owner collector 或 browser，也沒有寫入 #314 分支。

獨立 metadata checker 實際退出0；541 checks，0 findings。M121 三次原建置皆0；原測試為43／2／43個method，真0／1／0。mutant唯一正常 assertion 是 `test_Q3_same_final_reference_cannot_exempt_value_changing_rebind` 的 `preview guard`，不是 import／setup／crash／timeout；兩個具名正反例均在 baseline／restored完整43-method原清單中。全部六階段原 stdout/stderr hash、原sentinel結果、c387 request/result／streams與來源F核對一致；還原產品bytes及binary與baseline相同。

原六suite為47＋11＋14＋23＋5＋3＝103，全部pass、無fail／skip，原stdout明示PARTIAL。Node原命令為 `node --test --test-reporter=spec tests/test_grid_inspector_stagger.cjs`；實際12個內部checks加container報13 tests/pass13，原native protocol transcript完整。它是VM＋真native bridge，沒有HTTP／Chrome／P72B或full-browser聲明。

原始／scratch的全帳本bytes均等Git F，native前後hash同；M121只寫repo外單筆results，沒有重產全帳本。這不代表完整帳本freshness check已通過。

限制如實保留：native沒有事前request檔，依真正reaper、`run_native_now.py`與逐命令c387原件核執行，不把事後index冒稱prelaunch；owner最初raw index把basename誤當absolute的失敗原件保留，修正只解析原baseline／M121檔案位置。本審查重新獨立核所有原hash，沒有改原件。

原入口：M121 `/workspace/geo314-train-f64d638f-m121/receipt.json`；native `/tmp/geo314-train-f64d638f-native/receipt.json`；launcher `/tmp/geo314-train-f64d638f-launch/`。本checker原命令為 `python3 -B /tmp/geo324-owner-20261024/review_314_originals.py`，cwd `/tmp`，exec_command實際exit0；完整判定和逐檔hash見同目錄CHECKS.json／RAW_INVENTORY.json。
