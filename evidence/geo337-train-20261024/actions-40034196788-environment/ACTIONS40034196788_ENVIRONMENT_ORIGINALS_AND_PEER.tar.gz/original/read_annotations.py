from pathlib import Path
import hashlib,importlib.util,json,os
P=Path(__file__).parent;C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('original_capture_annotations',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None);env.update(PYTHONDONTWRITEBYTECODE='1',GH_PAGER='cat',PAGER='cat',GH_PROMPT_DISABLED='1')
sha='c6c0b0d06e101352d19aceabbfd97c0e1681833c';rec=cap.Recorder(P/'original-metadata',env,sha);rec.rows=json.loads((P/'original-metadata/subcommands.json').read_text())
def run(argv):
 row,out,err=rec.run(argv,cwd='/workspace/issue320-work-20261024',timeout=120,check=False,source_sha=sha,source_variant='read-only Actions metadata; not product execution')
 print(json.dumps({'argv':argv,'actualExit':row['actual_process_returncode'],'directory':row['directory'],'stdoutBytes':len(out),'stderrBytes':len(err)}),flush=True);return row,out
row,raw=run(['gh','run','view','40034196788','--repo','ZhiQiYang/geometry-axiom','--json','conclusion,createdAt,databaseId,displayTitle,event,headBranch,headSha,jobs,name,number,startedAt,status,updatedAt,url,workflowDatabaseId,workflowName'])
if row['actual_process_returncode']==0:(P/'RUN.json').write_bytes(raw)
jobs=json.loads((P/'original-metadata/subcommands/000006/stdout.bin').read_bytes())['jobs'];annotations=[]
for job in jobs:
 row,raw=run(['gh','api','repos/ZhiQiYang/geometry-axiom/check-runs/'+str(job['id'])+'/annotations','--paginate'])
 if row['actual_process_returncode']==0:annotations.append({'job':job['name'],'jobID':job['id'],'annotations':json.loads(raw),'originalCommand':row})
cap.dump(P/'ANNOTATIONS.json',annotations)
