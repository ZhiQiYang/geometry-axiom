from pathlib import Path
import hashlib,importlib.util,json,os
P=Path(__file__).parent;C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('original_capture_readonly_metadata',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None);env.update(PYTHONDONTWRITEBYTECODE='1',GH_PAGER='cat',PAGER='cat',GH_PROMPT_DISABLED='1')
audit='c6c0b0d06e101352d19aceabbfd97c0e1681833c'
rec=cap.Recorder(P/'original-metadata',env,audit)
def run(argv,cwd='/workspace/issue320-work-20261024'):
 row,out,err=rec.run(argv,cwd=cwd,timeout=120,check=False,source_sha=audit,source_variant='read-only metadata audit context; not product execution')
 print(json.dumps({'command':argv,'exit':row['actual_process_returncode'],'stdoutBytes':len(out),'stderrBytes':len(err),'directory':row['directory']}),flush=True)
 return row,out,err
ref='refs/remotes/origin/pr338-actions-read-handoff'
fetch,_,_=run(['git','fetch','--no-write-fetch-head','origin','refs/heads/handoff/codex-takeover-20261021:'+ref])
if fetch['actual_process_returncode']==0:
 row,head,_=run(['git','rev-parse',ref]);assert row['actual_process_returncode']==0
 sha=head.decode().strip();row,review,_=run(['git','show',sha+':handoff/pr-reviews/338.md'])
 if row['actual_process_returncode']==0:(P/'LATEST_REVIEW_338.md').write_bytes(review)
 cap.dump(P/'HANDOFF_SOURCE.json',{'head':sha,'fetchExit':fetch['actual_process_returncode'],'reviewPath':'handoff/pr-reviews/338.md','readOnlyFetchOnlyOwnTrackingRef':True})
run(['gh','run','view','40034196788','--repo','ZhiQiYang/geometry-axiom','--json','attempt,conclusion,createdAt,databaseId,displayTitle,event,headBranch,headSha,jobs,name,number,startedAt,status,updatedAt,url,workflowDatabaseId,workflowName'])
run(['gh','run','view','40034196788','--repo','ZhiQiYang/geometry-axiom'])
run(['gh','api','repos/ZhiQiYang/geometry-axiom/actions/runs/40034196788/jobs','--paginate'])
cap.dump(P/'READ_REQUEST.json',{'scope':'Readonly Git fresh mirrored338 review and original gh run view/jobs API; no workflow rerun, configuration/billing write, source change or product execution.','runID':40034196788,'auditContextSHA':audit,'auditContextIsNotExecutionResult':True,'commands':rec.rows})
