from pathlib import Path
import datetime,hashlib,json,platform,sys
P=Path(__file__).parent;h=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((P/'original-metadata/subcommands.json').read_text());jobs=json.loads((P/'original-metadata/subcommands/000006/stdout.bin').read_bytes())['jobs'];run=json.loads((P/'RUN.json').read_bytes());annotations=json.loads((P/'ANNOTATIONS.json').read_text());handoff=json.loads((P/'HANDOFF_SOURCE.json').read_text());review=(P/'LATEST_REVIEW_338.md').read_text()
message="The job was not started because recent account payments have failed or your spending limit needs to be increased. Please check the 'Billing & plans' section in your settings"
checks=[]
def ck(k,v):checks.append({'label':k,'passed':bool(v)})
ck('freshhandoffread0andactual22:39review',rows[0]['actual_process_returncode']==rows[1]['actual_process_returncode']==rows[2]['actual_process_returncode']==0 and handoff['head']=='9bb3ada437c6f127f9aaaf7de5ecf9ec9fc416b6' and '2026-10-23T22:39:41Z'in review and 'Actions run [40034196788]'in review)
ck('14 captured original commands',len(rows)==14)
for r in rows:
 D=Path(r['directory']);request=json.loads((D/'request.json').read_text());result=json.loads((D/'result.json').read_text())
 ck('request/result '+str(D),result==r and request['command']==r['command'])
 for stream in ('stdout','stderr'):
  raw=(D/(stream+'.bin')).read_bytes();ck('fullbytes '+str(D)+'/'+stream,len(raw)==r[stream+'_bytes'] and h(raw)==r[stream+'_sha256'])
 ck('stdin '+str(D),h((D/'stdin.bin').read_bytes())==r['stdin_sha256'])
ck('initialghfieldcompatfailurepreserved',rows[3]['actual_process_returncode']==1 and b'Unknown JSON field: "attempt"'in(Path(rows[3]['directory'])/'stderr.bin').read_bytes())
ck('allotherreadonlycommands0',all(r['actual_process_returncode']==0 for i,r in enumerate(rows)if i!=3))
ck('runcompletedfailureoriginalhead',run['databaseId']==40034196788 and run['headSha']=='c6c0b0d06e101352d19aceabbfd97c0e1681833c' and run['status']=='completed' and run['conclusion']=='failure' and run['headBranch']=='codex/train-337-continue-20261024')
expected={'native','browser (canvas)','browser (assembly)','browser (documents)','browser (grid)','browser (space)','browser (timber)'}
ck('sevenexactworkflowjobs',len(jobs)==len(annotations)==7 and {j['name']for j in jobs}==expected)
classified=[]
for j in jobs:
 a=next(a for a in annotations if a['jobID']==j['id']);fails=[x for x in a['annotations']if x['annotation_level']=='failure'];notice=[x for x in a['annotations']if x['annotation_level']=='notice']
 ck('failure noassignedrunner nosteps '+j['name'],j['status']=='completed' and j['conclusion']=='failure' and j['steps']==[] and j['runner_id']==0 and j['runner_name']=='' and j['head_sha']==run['headSha'])
 ck('exactGitHubbillingannotation '+j['name'],len(fails)==1 and fails[0]['message']==message and a['originalCommand']['actual_process_returncode']==0)
 classified.append({'name':j['name'],'jobID':j['id'],'conclusion':j['conclusion'],'runnerID':j['runner_id'],'runnerName':j['runner_name'],'steps':j['steps'],'originalHeadSHA':j['head_sha'],'jobURL':j['html_url'],'annotationAPI':a['originalCommand']['command'],'annotationOriginalCapture':a['originalCommand']['directory'],'failureAnnotation':fails,'notices':notice,'classification':'GitHub scheduling blocked before job start: account payment failure OR spending-limit restriction; exact branch not distinguished by this API.'})
report={'schema':'pr338-actions-40034196788-environment-classification/1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only fresh mirrored review, original gh run view and jobs/check-run-annotation APIs, preserving argv/exit/fullstdout/fullstderr/hash. No CI rerun, billing/settings/source/workflow change or product execution.','handoff':handoff,'latestReview':{'path':str(P/'LATEST_REVIEW_338.md'),'sha256':h((P/'LATEST_REVIEW_338.md').read_bytes()),'timestamp':'2026-10-23T22:39:41Z','head':'c6c0b0d','newB3':'Actions required-jobs failure','priorB3':'Five original evidence packages: already addressed in that latest review; not the current Actions blocker.'},'run':run,'jobs':classified,'sourceIdentities':{'actionsRunHead':run['headSha'],'separateCloudAcceptanceL':'7af8c5d80d34cb4f49d01ba67deb78a3a6d725db','originalContextSHAIsNotTestResult':True,'actionsRunRetaggedAsL':False},'classification':{'category':'GitHub account billing/payment-or-spending-limit scheduling environment','explicitGitHubFailureText':message,'basis':'Every original check-run API supplies the same failure annotation, corroborated by7 runner_id0/empty-runner/empty-steps jobs.','exactPaymentVsLimitCause':None,'ubuntu26MigrationNoticeIsNotFailureCause':True,'productExecutedByThisActionsRun':False,'productPassInferred':False,'ciConclusionRemains':'failure (7/7)','B3Resolved':False,'cloudSupplementComplete':False,'requirednessSource':'Latest ChatGPT review names these seven required; branch-protection configuration was not independently queried.'},'nextSteps':['Preserve this explicit environment classification and complete original API responses in evidence.','Continue independently planned same-L original native/browser/special gates; this API diagnosis does not fill any product PASS row.','Account owner may resolve the GitHub Billing & plans restriction; no billing operation, rerun request or approval bypass was performed here.','Keep current B3 distinct from prior evidence-packaging B3; do not present old resolved B3 as current Actions resolved.'],'readToolCompatibility':{'firstRunViewJSONExit':1,'cause':'Installed gh does not support requested JSON field attempt; available-fields error preserved.','correctedRunViewJSONExit':0,'correction':'Only unsupported attempt field removed; not an API authorization failure, product failure or altered gate.'},'metadataIntegrity':{'checkCount':len(checks),'checks':checks,'findings':[x['label']for x in checks if not x['passed']]},'reviewerEnvironment':{'python':sys.version,'platform':platform.platform()},'limits':['Exact billing account/payment/spending-limit state was not separately queried; the GitHub error states an OR condition.','No branch-protection or workflow settings were written or bypassed.','No product runtime, compiler, browser, native suite or cloud gate executed during this audit.','No inference that current C1 PR-body issue is resolved: this audit reads review and Actions data, not current GitHub PR-body publication.']}
report['exitCode']=int(bool(report['metadataIntegrity']['findings']));(P/'CLASSIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
summary="""#338 最新 B3：GitHub Actions 環境分類

2026-10-23 22:39:41 的審查指 Actions run40034196788；fresh handoff固定9bb3ada437c6f127f9aaaf7de5ecf9ec9fc416b6。這次B3是CI紅燈，與前次已解的五包原件B3分開。

原 gh run view 與 jobs API 均真exit0；run head為c6c0b0d06e101352d19aceabbfd97c0e1681833c，七項均completed/failure、runner_id0、runner_name空、steps空。逐job check-run annotation API七條全真exit0，GitHub對七項逐一明示：

> The job was not started because recent account payments have failed or your spending limit needs to be increased. Please check the 'Billing & plans' section in your settings

這是排程前的帳戶付款／支出上限環境阻擋；不是只憑無runner作猜測。API未區分付款失敗與支出上限，不能再猜其一；Ubuntu26 label migration另為notice，不是failure原因。不能由未啟動推論產品通過，七required CI仍紅；原雲端L7af驗收另保原SHA與原退出碼，未完成項仍未完成。無CI重跑、帳單／設定修改、來源變更或測試執行。

原14命令argv/cwd/env/退出碼、完整stdout/stderr/stdin與sha在original-metadata/subcommands.json及各子目錄。第一個gh JSON讀取因本版本不支持attempt欄位真exit1，錯誤原保；只刪該欄位的讀取真exit0，不能當API403或產品紅。CLASSIFICATION.json有逐job URL/API與原capture locator。

本報告只完成環境分類，不自行解除B3或合併：應保存此分類與後續同L完整補跑結果，或在帳戶限制修好後取得適用head的required CI綠燈。本輪沒有查branch protection獨立確認requiredness；required七項的要求來源是最新審查。
"""
(P/'SUMMARY.md').write_text(summary)
files={}
for path in sorted(P.rglob('*')):
 if path.is_file()and path.name!='RAW_INVENTORY.json':files[str(path.relative_to(P))]={'bytes':path.stat().st_size,'sha256':h(path.read_bytes())}
inventory={'schema':'readonly-actions-audit-files/1','files':files,'selfExcluded':True,'commandCount':len(rows),'allOriginalCommandStreamsIncluded':True};ip=P/'RAW_INVENTORY.json';ip.write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(P/'CLASSIFICATION.json'),'reportSHA256':h((P/'CLASSIFICATION.json').read_bytes()),'inventorySHA256':h(ip.read_bytes()),'files':len(files),'commands':len(rows),'checks':len(checks),'findings':report['metadataIntegrity']['findings'],'exitCode':report['exitCode']},ensure_ascii=False));raise SystemExit(report['exitCode'])
