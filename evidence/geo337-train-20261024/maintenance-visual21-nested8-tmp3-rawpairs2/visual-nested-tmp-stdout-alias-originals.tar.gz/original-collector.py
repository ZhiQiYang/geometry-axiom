"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/cold128-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 manifests=[('/workspace/cold_small_128_exact_body_manifest_20261024.json','850b38009a13d79321a0de06b316fac85249889a531f6105056c9e712289ccfe')]
 items=[]
 for path,pin in manifests:
  assert digest(path)==pin
  m=readj(path);items.extend(m['items']);add(path,'manifest/'+Path(path).name)
 assert len(items)==128 and sum(i['expected_allocated_saving'] for i in items)==150953984
 for i in items:
  name=i['name'];plan=Path(i['plan']);out=Path('/workspace')/(name+'-receipt-archive-three-dedup-execution-20261023');outer=Path('/workspace')/(name+'-receipt-archive-three-dedup-launch-20261024')
  assert digest(plan)==i['plan_sha256'] and digest(i['tool'])==i['tool_sha256']
  r=readj(out/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_three_paths_and_bytes_preserved'] and a['actual_process_returncode']==0
  tree(plan.parent,'preparation/'+name);tree(out,'actual/'+name);tree(outer,'launch/'+name);add(i['tool'],'tools/'+name+'-executor.py')
 tree('/workspace/cold-small-128-preparation-20261024','preparation-source/cold128')
 tree('/workspace/cold-small-receipt-frozen-metadata-20261024','preparation-source/metadata-census')
 tree('/workspace/cold-small-receipt-frozen-metadata-launch-20261024','preparation-launch/metadata-census')
 tree('/workspace/cold-small-128-body-preparation-launch-20261024','preparation-launch/cold128')
 for path in ['/workspace/prepare_cold_small_128_metadata_20261024.py','/workspace/scan_cold_small_receipt_frozen_metadata_20261024.py','/tmp/prepare_next_cold_archive_batch.py','/workspace/summarize_prepared_cold_archive_batch_20261024.py']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/deduplicate_release_exact_three_receipts.py','/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/run_cold_receipt_batch.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 add('/workspace/cold128-root-sequential-execution-20261024.json','root-sequential-execution.json')
 prior=Path('/workspace/cold59-and-cardref-links-originals-20261024/PACKAGE.json')
 assert digest(prior)=='43759f9d932eb66581fc3aad6a94e936e4c6334355c5e7fb56cc359646e0ab7d'
 add(prior,'prior-proof-reference/COLD59_CARDREF_PACKAGE.json')
 peers=['COLD128_NETPLAN_STATIC_PEER.json','review_cold128_netplan.py','COLD_128_EXACT_THREE_EXECUTOR_STATIC_PEER.json','review_cold_exact_preparation.py','COLD128_ROOT_WRAPPER_STATIC_PEER.json','review_cold128_root_wrapper.py','COLD128_ACTUAL_SUMMARY_HELPER_PEER.json','review_cold128_actual_summary.py']
 for name in peers:add(Path('/workspace/train337-canvas-peer-resume')/name,'peers-and-review-tools/'+name)
 for path in ['/workspace/COLD_128_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json','/workspace/review_cold128_actual_metadata_20261024.py']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 add(__file__,'collector.py')
 add('/workspace/prepare_cold128_original_collection_20261024.py','collector-preparation.py')
 add('/workspace/collect_cold59_and_cardref_originals_20261024.py','original-collector.py')
 for path in ['/workspace/COLD_128_EXACT_THREE_ACTUAL_METADATA_REVIEW_20261024.json','/workspace/train337-canvas-peer-resume/COLD128_ACTUAL_SUMMARY_HELPER_PEER.json']:
  r=readj(path);assert r['exit_code']==0 and not r['findings']
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'cold128-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='cold128-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,cold_receipt_alias_groups_added=128,all_established_cold_alias_groups=423,configured_gross_source_block_saving=150953984,limits=['Maintenance only; no product gate is executed or relabeled.','All384 source receipt paths and bytes remain; no receipt body or ELF executable payload is duplicated into this package.','All423 established cold alias groups including295 previous groups must be delinked before any write/reuse of any of the three cold checkouts. Two separate cardref ELF alias groups are outside this count and remain independently write-banned.','Actual reviews verify metadata and complete small command streams; original executors performed full physical byte/Git blob comparisons. No second large payload rehash is claimed.','Original12.3MB Git-tree captures are already in the referenced prior cold59/cardref archive, pinned in its PACKAGE. Their exact pins are retained in the current metadata census; payloads are not copied again.','Original selector ran via direct exec_command. Its explicit transcript provenance discloses that no independent c387 environment/stream capture was made for that earlier selector; actual body preparation and replacement retain their complete original c387 captures.','Gross source block savings are not net storage recovery: full prep/exec/outer/tool/package/Git publication overhead remains. NET_PLAN preserves original59 stat samples and labels its margin as sensitivity scenario, not a hard bound.','Concurrent global free-space changes are not substituted for allocation measurements. Original inode identities and per-path mtime are not claimed unchanged.','Independent peer reports created after this fixed package remain adjacent attachments.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
