"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/root-eleven-archive-extensions-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 specs=[('root-eleven','/workspace/root-eleven-archive-alias-extension-preparation-20261024','/workspace/root-eleven-archive-alias-extension-execution-20261024','/workspace/root-eleven-archive-alias-extension-launch-20261024')]
 archive_bodies=set();gross=0;plans=[]
 for label,prep,actual,outer in specs:
  prep,actual,outer=map(Path,(prep,actual,outer));plan=readj(prep/'PLAN.json');r=readj(actual/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and a['actual_process_returncode']==0
  assert not a['timeout_expired'] and r['plan_sha256']==digest(prep/'PLAN.json');plans.append(plan);gross+=plan['expected_allocated_saving']
  members=[x for g in plan['groups'] for x in g['members']]
  archive_bodies.update(x['path'] for x in members)
  tree(prep,'preparation/'+label);tree(actual,'actual/'+label);tree(outer,'launch/'+label)
  for i,x in enumerate(plan['anchors']):
   assert digest(x['path'])==x['sha256']
   add(x['path'],f'anchors/{label}/{i:03d}-'+Path(x['path']).name)
  for key in ['original_core','core','consumer_guard']:
   x=plan[key];assert digest(x['path'])==x['sha256']
 assert gross==134045696
 assert len(plans)==1 and [g['count'] for g in plans[0]['groups']]==[8]*11
 assert len(archive_bodies)==88
 for i,t in enumerate(plans[0]['terminal_rows']):
  assert readj(t['path'])==t['original_rows']
  add(t['path'],f'terminal-originals/{i:03d}-'+Path(t['path']).name)
 for path in ['/workspace/prepare_root_eleven_archive_alias_extensions_20261024.py','/workspace/launch_root_eleven_archive_alias_extensions_20261024.py','/workspace/root-published-archive-leaf-metadata-20261024/known-cold-group-crosscheck/CANDIDATES.json']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/run_approved_maintenance.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py']:
  add(path,'original-tools/'+Path(path).name)
 train=Path('/workspace/train337-canvas-peer-resume')
 for name in ['ROOT_ELEVEN_ALIAS_EXTENSIONS_STATIC_ACTUAL_PEER.json','review_root_eleven_alias_extensions.py']:
  add(train/name,'peers-and-review-tools/'+name)
 for path in ['/workspace/review_root_eleven_archive_extensions_actual_metadata_20261024.py','/workspace/ROOT_ELEVEN_ARCHIVE_EXTENSIONS_ACTUAL_METADATA_20261024.json','/workspace/ROOT_ELEVEN_EXTENDED_IMMUTABLE_ALIAS_REGISTRY_20261024.json']:
  add(path,'peers-and-review-tools/'+Path(path).name)
 for path in [train/'ROOT_ELEVEN_ALIAS_EXTENSIONS_STATIC_ACTUAL_PEER.json',Path('/workspace/ROOT_ELEVEN_ARCHIVE_EXTENSIONS_ACTUAL_METADATA_20261024.json')]:
  peer=readj(path);assert peer['exit_code']==0 and not peer['findings']
 add('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py','original-tools/previous-exact-core354.py')
 add('/workspace/seven-postr5-terminal-archives-preparation-20261024/link_exact_seven_postr5_terminal_archive_groups.py','original-tools/previous-seven-executor.py')
 add(__file__,'collector.py');add('/workspace/collect_cold128_originals_20261024.py','original-collector.py')
 add('/workspace/collect_four_archive_groups_originals_combined_20261024.py','previous-four-groups-collector.py')
 add('/workspace/three-large-terminal-archives-preparation-20261024/link_exact_three_large_terminal_archive_groups.py','original-tools/previous-three-groups-executor.py')
 assert not archive_bodies.intersection(x['source'] for x in entries.values())
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'root-eleven-archive-extensions-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='root-eleven-archive-extensions-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,existing_archive_groups_extended=11,old_aliases_preserved=77,new_root_aliases=11,total_aliases_in_scope=88,configured_gross_new_root_leaf_saving=gross,limits=['Maintenance only; no product gate is executed or relabeled.','All88 original paths and bytes remain; no archive body or ELF payload is duplicated into this metadata package.','Eleven existing7-alias groups gained one exact immutable root leaf each. Existing77 cold aliases were never replaced; only11 root destination inodes changed.','Total previous19 cold archive groups now113paths, not30groups. Other8groups/25paths and423seal/2cardref/1GEO339 bans stay unchanged.','Only exact11 root immutable archive leaves are write frozen; unrelated root document or Git publication work is allowed.','Root current HEAD and index exact leaf blobs were checked before/after. Entire root HEAD or index is not falsely claimed unchanged.','Original failed terminal receipts remain failed. Gross134045696 new root source blocks are not net/global df recovery.','Exact88path current alias registry is additive history; older packages and their historical nlink7 fields are not rewritten.','Original prepare ran direct exec with full Git capture streams; no invented producer OS transcript is backfilled.','Independent post-package peer remains adjacent, not recursively included.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
