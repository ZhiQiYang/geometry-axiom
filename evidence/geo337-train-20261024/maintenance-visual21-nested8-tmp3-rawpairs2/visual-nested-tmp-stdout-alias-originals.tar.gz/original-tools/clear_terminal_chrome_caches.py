"""Remove only the independently inventoried, terminal Chrome cache leaves."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat

PLAN = Path('/workspace/cache-terminal-preflight-20261023/EXACT_CACHE_PLAN.json')
PIN = '876aeb30f4ef0e60eb49a51c4a270d911fa69458c745324522fbaef9e458f191'
OUT = Path('/workspace/cache-terminal-execution-20261023')
ALLOWED_NAMES = {'Cache', 'Code Cache', 'DawnGraphiteCache', 'DawnWebGPUCache',
                 'GPUCache', 'GrShaderCache', 'ShaderCache'}
ROOTS = ['/tmp/g261r3/tmp/seven-final', '/workspace/geo261-cold',
         '/tmp/g288p88q', '/tmp/g288p88r', '/tmp/g288p88o1', '/tmp/g288p88o2',
         '/tmp/g288p88o3', '/tmp/g288pf', '/tmp/g288pff', '/tmp/g288pr']

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def ancestors(path):
    assert path.is_absolute()
    for parent in reversed(path.parents):
        assert stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(), str(parent)
    assert not path.is_symlink(), str(path)

def free():
    return {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ['/workspace', '/tmp']}

def identity(path, item, *, is_file):
    ancestors(path)
    s = path.lstat()
    assert (stat.S_ISREG(s.st_mode) if is_file else stat.S_ISDIR(s.st_mode)), str(path)
    values = dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, size=s.st_size,
                  mtime_ns=s.st_mtime_ns, nlink=s.st_nlink)
    assert all(values[k] == item[k] for k in values), str(path)
    if is_file:
        assert s.st_nlink == 1 and digest(path) == item['sha256'], str(path)

def consumer_check(profiles):
    hits, unreadable = [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal() or int(proc.name) == os.getpid():
            continue
        try:
            status = (proc / 'status').read_text()
            if any(line.startswith('State:') and '\tZ' in line for line in status.splitlines()):
                continue
        except OSError:
            pass
        fields = {}
        for name in ['cwd', 'exe']:
            try:
                fields[name] = os.readlink(proc / name)
            except OSError as exc:
                unreadable.append([proc.name, name, type(exc).__name__])
        try:
            fields['cmdline'] = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        except OSError as exc:
            unreadable.append([proc.name, 'cmdline', type(exc).__name__])
        try:
            for fd in (proc / 'fd').iterdir():
                try:
                    fields['fd:' + fd.name] = os.readlink(fd)
                except OSError:
                    pass
        except OSError as exc:
            unreadable.append([proc.name, 'fd', type(exc).__name__])
        for key, value in fields.items():
            matches = [p for p in profiles if p in value]
            if matches:
                # Record only matched owned paths, never arbitrary process argv.
                hits.append(dict(pid=int(proc.name), field=key, profiles=matches))
    dump('CONSUMERS.json', dict(hits=hits, unreadable=unreadable,
         limitation='Only accessible cwd/exe/cmdline/fd can be inspected; inaccessible OS processes are not claimed inspected.'))
    assert not hits, hits

def main():
    OUT.mkdir()
    result = dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  plan_sha256=PIN, removed=[], removed_directories=[], exit_code=1,
                  policy='Root reserves these historical profiles against reuse during this maintenance.',
                  free_before=free())
    try:
        assert digest(PLAN) == PIN
        plan = json.loads(PLAN.read_text())
        assert plan['candidate_count'] == 426 and plan['file_count'] == 5678
        assert set(plan['cache_leaf_names']) == ALLOWED_NAMES
        candidates = plan['candidates']
        paths = [Path(x['path']) for x in candidates]
        assert len(set(paths)) == len(paths)
        for p in paths:
            assert p.name in ALLOWED_NAMES and any(p.is_relative_to(root) for root in ROOTS), str(p)
            assert not any(p != other and p.is_relative_to(other) for other in paths)
        for receipt in plan['terminal_receipts']:
            p = Path(receipt['path'])
            assert p.stat().st_size == receipt['bytes'] and digest(p) == receipt['sha256']
        for candidate in candidates:
            p = Path(candidate['path'])
            ancestors(p)
            expected = {x['relative'] for x in candidate['files'] + candidate['directories']}
            assert {str(x.relative_to(p)) for x in p.rglob('*')} == expected, str(p)
            for item in candidate['files']:
                identity(p / item['relative'], item, is_file=True)
            for item in candidate['directories']:
                identity(p / item['relative'], item, is_file=False)
        consumer_check(sorted({x['profile'] for x in candidates}))
        for candidate in candidates:
            p = Path(candidate['path'])
            for item in candidate['files']:
                target = p / item['relative']
                identity(target, item, is_file=True)
                target.unlink()
                result['removed'].append(str(target))
            # rmdir refuses any unexpected content; never recursively remove a profile.
            for item in sorted(candidate['directories'], key=lambda x: len(Path(x['relative']).parts), reverse=True):
                target = p / item['relative']
                ancestors(target)
                target.rmdir()
                result['removed_directories'].append(str(target))
            p.rmdir()
            result['removed_directories'].append(str(p))
        for receipt in plan['terminal_receipts']:
            assert digest(Path(receipt['path'])) == receipt['sha256']
        assert len(result['removed']) == 5678
        result['removed_allocated_file_bytes'] = plan['allocated_file_bytes']
        result['exit_code'] = 0
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_after'] = free()
        dump('RESULT.json', result)
        print(json.dumps({k: v for k, v in result.items() if k not in ['removed', 'removed_directories']}))

if __name__ == '__main__':
    main()
