from pathlib import Path
import datetime,hashlib,json,os,sys
B=Path('/workspace/r5-r6-two-archive-stdout-pairs-preparation-20261024');PLAN=B/'PLAN.json';PIN='2fdaa5bd109917692a0913ddab97cdd4e82d17047e56e5c912465dba022f3ca9'
CORE=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py');COREPIN='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec'
GUARD=Path('/workspace/clear_terminal_chrome_caches.py');GUARDPIN='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT=Path('/workspace/r5-r6-two-archive-stdout-pairs-preserving-links-execution-20261024')
def h(p):
 x=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):x.update(b)
 return x.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 assert sys.flags.optimize==0 and 'PYTHONOPTIMIZE' not in os.environ
 assert h(PLAN)==PIN and h(CORE)==COREPIN and h(GUARD)==GUARDPIN
 p=json.loads(PLAN.read_text());assert [x['count'] for x in p['groups']]==[2,2] and p['expected_allocated_saving']==31252480 and not p['actual_replacement_executed']
 assert [x['role'] for x in p['groups']]==['base','main'] and len({x['path'] for g in p['groups'] for x in g['members']})==4
 core={'__name__':'core'};exec(compile(CORE.read_bytes(),str(CORE),'exec'),core)
 guard={'__name__':'guard'};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard)
 OUT.mkdir();r=dict(exit_code=1,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha=p['source_sha'],plan_sha256=PIN,core_sha256=COREPIN,free_before=guard['free'](),groups=[],reservation=p['reservation'],original_failures_preserved=True,expected_allocated_saving=p['expected_allocated_saving']);count=0
 def anchors():
  for a in p['anchors']:
   q=Path(a['path']);core['ancestors'](q);assert q.stat().st_size==a['bytes'] and h(q)==a['sha256']
  for a in p['terminal_receipts']:
   t=json.loads(Path(a['path']).read_text());assert t['source_sha']==a['source_sha'] and t['stages']==a['stages']
 def consumer():
  nonlocal count
  count+=1;d=OUT/f'consumers-{count:03d}';d.mkdir();guard['OUT']=d;guard['consumer_check'](p['consumer_prefixes']);anchors()
 try:
  anchors();consumer()
  for i,g in enumerate(p['groups'],1):
   core['link_exact'](g['members'],OUT/f'GROUP-{i}.jsonl',before_each=consumer);anchors()
   r['groups'].append(dict(role=g['role'],sha256=g['sha256'],all_paths_preserved=True,final_metadata=[dict(path=x['path'],**core['metadata'](x['path'])) for x in g['members']]))
  for g in p['groups']:core['state'](g['members'],{1})
  anchors();r.update(exit_code=0,consumer_checks=count,all_original_payload_paths_retained=True,all_original_receipt_bytes_preserved=True)
 finally:
  r.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=guard['free']());dump(OUT/'RESULT.json',r);print(json.dumps({k:v for k,v in r.items() if k!='groups'}))
if __name__=='__main__':main()
