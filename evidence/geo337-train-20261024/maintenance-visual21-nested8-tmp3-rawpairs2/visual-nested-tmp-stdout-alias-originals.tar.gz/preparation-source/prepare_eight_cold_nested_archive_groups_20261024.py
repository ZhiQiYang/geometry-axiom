"""Only prepare preserving links for56 explicitly authorized immutable nested archive paths."""
from pathlib import Path
import hashlib,json,datetime,os,importlib.util
B=Path('/workspace/eight-cold-nested-archive-groups-preparation-20261024');CAND=Path('/workspace/cold-seven-nested-archive-candidates-20261024.json');ORIG=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py');PRIOR=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/PLAN.json');CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');GUARD=Path('/workspace/clear_terminal_chrome_caches.py')
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert h(CAND)=='76599fcd9fab110aca196c9ec8733fce0834dcc6effcd2b9d1bf2a36cb93affc';assert h(ORIG)=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec';assert h(PRIOR)=='d99c4b6001fc562d4ff7df638b17e2bbe3b5a804d794b0bff09065d0e48264dc';assert h(CAP)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762';assert h(GUARD)=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
B.mkdir();corepath=B/'exact_large_archive_group_link_core.py';corepath.write_bytes(ORIG.read_bytes());core=module(corepath,'original_core');cap=module(CAP,'capture');guard=module(GUARD,'consumer');prior=json.loads(PRIOR.read_text());cand=json.loads(CAND.read_text());items=cand['groups'];assert len(items)==8 and cand['gross_candidate']==50405376;owners={x['root']:x['head'] for x in prior['owners']}
rec=cap.Recorder(B/'git-originals',dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),'historical-cold-nested-archive-path-preservation-not-product-acceptance')
def git(root,args):
 row,b,e=rec.run(['git','-c','gc.auto=0',*args],cwd=root,timeout=None);assert not e;return b.decode().strip()
for root,head in owners.items():assert git(root,['rev-parse','HEAD'])==head
groups=[]
for item in items:
 assert item['count']==7;members=[]
 for r in item['members']:
  path=Path(r['path']);assert r['root'] in owners and r['head']==owners[r['root']] and path==Path(r['root'])/r['relative'];assert path.name.endswith(('.tar.xz','.zip'))
  m=core.metadata(path);assert (m['dev'],m['inode'],m['nlink'],m['size'],m['mode'],m['mtime_ns'],m['allocated_bytes'])==(r['device'],r['inode'],1,r['bytes'],r['mode'],r['mtime_ns'],r['allocated']);assert not os.listxattr(path)
  m=dict(path=str(path),owner_root=r['root'],owner_head=r['head'],git_path=r['relative'],git_blob=r['git_blob'],sha256=core.digest(path),**m)
  assert git(r['root'],['ls-tree',r['head'],'--',r['relative']])==f"100644 blob {r['git_blob']}\t{r['relative']}"
  assert git(r['root'],['cat-file','-s',r['git_blob']])==str(r['bytes']);assert git(r['root'],['hash-object',str(path)])==r['git_blob'];members.append(m)
 assert len({(m['dev'],m['inode']) for m in members})==7 and len({(m['mode'],m['uid'],m['gid'],m['size'],m['sha256']) for m in members})==1
 core.state(members,set());saving=sum(m['allocated_bytes'] for m in members[1:]);assert saving==item['gross_candidate'];groups.append(dict(count=7,members=members,sha256=members[0]['sha256'],expected_allocated_saving=saving,classification='Immutable nested archive preserving links; all original receipt/fixture bytes and paths remain',deletion_allowed=False))
anchors={x['path']:x for x in prior['anchors']};anchors[str(PRIOR)]=dict(path=str(PRIOR),bytes=PRIOR.stat().st_size,sha256=h(PRIOR));anchors[str(CAND)]=dict(path=str(CAND),bytes=CAND.stat().st_size,sha256=h(CAND))
for a in anchors.values():assert Path(a['path']).stat().st_size==a['bytes'] and h(a['path'])==a['sha256']
for t in prior['terminal_rows']:assert json.loads(Path(t['path']).read_text())==t['original_rows']
d=B/'prepare-consumers';d.mkdir();guard.OUT=d;guard.consumer_check(list(owners))
plan=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db',groups=groups,owners=prior['owners'],target_count=56,expected_allocated_saving=50405376,anchors=list(anchors.values()),terminal_rows=prior['terminal_rows'],consumer_prefixes=list(owners),core=dict(path=str(corepath),sha256=h(corepath)),original_core=dict(path=str(ORIG),sha256=h(ORIG)),consumer_guard=dict(path=str(GUARD),sha256=h(GUARD)),reservation='Only these8 nested archive groups/56 exact archive paths are new immutable write/reuse bans until every alias is de-linked. All paths and full archive/fixture/evidence bytes remain. Existing archive and other alias bans are separate and unchanged.',identity_limit='No source/archive/fixture is deleted. Noncanonical inode/nlink/mtime/atime adopt canonical metadata; every complete original byte sequence remains at every path.',scope_limit='Immutable tracked nested archive originals including historical receipts; preserving links only, never source retirement. Historical acceptance failures remain failures.',excluded_unproven_owner='/workspace/geo261-cold/g261F2perf/source-counterfactual',excluded_reason='Not in seven proven historical owners; remains untouched.',actual_replacement_executed=False,preparation_provenance='Direct producer exec; full original Git captures and consumer output retained, no invented outer OS transcript.')
assert sum(g['expected_allocated_saving'] for g in groups)==50405376 and len({m['path'] for g in groups for m in g['members']})==56;dump(B/'PLAN.json',plan);print(json.dumps(dict(plan=str(B/'PLAN.json'),plan_sha256=h(B/'PLAN.json'),core_sha256=h(corepath),groups=8,paths=56,gross_candidate=50405376)))
