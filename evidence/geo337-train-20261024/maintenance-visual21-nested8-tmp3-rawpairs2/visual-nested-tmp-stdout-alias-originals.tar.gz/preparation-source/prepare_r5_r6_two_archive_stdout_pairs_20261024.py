from pathlib import Path
import json,hashlib,datetime,os
B=Path('/workspace/r5-r6-two-archive-stdout-pairs-preparation-20261024');B.mkdir(exist_ok=True)
CORE=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py')
assert hashlib.sha256(CORE.read_bytes()).hexdigest()=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec'
ns={'__name__':'core'};exec(compile(CORE.read_bytes(),str(CORE),'exec'),ns)
def h(p):return ns['digest'](p)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
roots=[Path('/workspace/g337323R5'),Path('/workspace/g337323R6')];groups=[];anchors={};terminals=[]
def anchor(p):anchors[str(p)]={'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
for root in roots:
 p=root/'receipt.json';r=json.loads(p.read_text());assert list(r['stages'])==['prepare','build','compare','perf','profile'];assert all(x.get('ended_utc') and isinstance(x['execution_exit'],int) for x in r['stages'].values());anchor(p);terminals.append({'path':str(p),'source_sha':r['source_sha'],'stages':r['stages']})
for role,sha in [('base','b74f9a2ae7ade1555b9be45283adecc097fb76e3'),('main','adbaebf9c73ea6801d7b4d5214e4b846b132923b')]:
 members=[]
 for root in roots:
  found=[]
  for ledger in root.glob('invocations/*/commands/commands.json'):
   rows=json.loads(ledger.read_text())
   for row in rows:
    if 'archive' in row['command'] and row.get('source_sha')==sha:found.append((ledger,row))
  assert len(found)==1
  ledger,row=found[0];d=Path(row['directory']);raw=d/'stdout.bin';actual=json.loads((d/'result.json').read_text());assert actual==row and row['actual_process_returncode']==0 and row['recording_complete'] and row['ended_epoch']
  assert row['stdin_provided'] is False and not (d/'stdin.bin').exists()
  for p in [ledger,d/'result.json',d/'request.json',d/'stderr.bin']:anchor(p)
  member=dict(path=str(raw),**ns['metadata'](raw),sha256=h(raw),source_sha=sha,role=role,original_command_result=str(d/'result.json'))
  assert member['sha256']==row['stdout_sha256'] and member['size']==row['stdout_bytes'] and member['nlink']==1
  members.append(member)
 assert members[0]['sha256']==members[1]['sha256']
 groups.append(dict(role=role,members=members,count=2,sha256=members[0]['sha256'],expected_allocated_saving=members[1]['allocated_bytes']))
p=dict(source_sha=terminals[-1]['source_sha'],groups=groups,anchors=list(anchors.values()),terminal_receipts=terminals,consumer_prefixes=[str(x) for x in roots],expected_allocated_saving=sum(g['expected_allocated_saving'] for g in groups),reservation='All four original raw receipt paths and bytes immutable; no append/reuse. Every alias must be independently delinked before any future write.',identity_limit='Original terminal recorder rows bind source SHA, full command, stdout bytes/SHA. Fresh full bytes checked; no archive payload duplicated.',original_failures_preserved=True,actual_replacement_executed=False)
dump(B/'PLAN.json',p);dump(B/'SELF_REVIEW.json',dict(exit_code=0,independent_peer=False,scope='exact2pairs/4rawpaths',core_original_sha256=h(CORE),plan_sha256=h(B/'PLAN.json'),fullbody_fresh_checked=True,original_red_stages_preserved=True))
print(json.dumps({'PLAN':str(B/'PLAN.json'),'sha256':h(B/'PLAN.json'),'expected_allocated_saving':p['expected_allocated_saving']}))
