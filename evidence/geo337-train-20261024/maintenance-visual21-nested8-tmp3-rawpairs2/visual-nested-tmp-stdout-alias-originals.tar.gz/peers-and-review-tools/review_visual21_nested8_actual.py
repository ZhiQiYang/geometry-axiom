from pathlib import Path
import hashlib,json,os,stat
O=Path('/workspace/train337-canvas-peer-resume');checks=0;find=[];cases=[('twentyone-cold-visual-groups',21,101842944,'43b806c9e12ddaa4b909e8a479de1d172297a6e90cd6d606606bb3b81690a6cd','link_exact_twentyone_cold_visual_groups.py','3dce8d1c21272579edce94bce2706a82933bf142bc89bab02e6152ce1de0ae3a','for21 exact cold visual PNG groups; no image or fixture deletion.'),('eight-cold-nested-archive-groups',8,50405376,'1b62e1ec65931e413b8645cb0d26d0b2681f494cb13ed3656783152a22fdeeae','link_exact_eight_cold_nested_archive_groups.py','ace3b950b8bddeb5f60e3506c41eff50d532da27a572b5c4e73599aec19c7dd2','for8 exact cold nested archive groups; all receipt/fixture paths preserved.')]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
original=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024/link_exact_seven_postr5_terminal_archive_groups.py').read_text();results=[]
for label,count,saving,planpin,tool,toolpin,desc in cases:
 B=Path('/workspace')/(label+'-preparation-20261024');R=Path('/workspace')/(label+'-preserving-links-execution-20261024');A=Path('/workspace')/(label+'-preserving-links-launch-20261024');p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json')
 ck(h(B/'PLAN.json')==r['plan_sha256']==planpin and h(B/tool)==toolpin and h(B/'exact_large_archive_group_link_core.py')==r['core_sha256']=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','fixed exact PLAN/tool/original core '+label)
 expected=original.replace('for seven post-R5 frozen immutable archive groups.',desc).replace('seven-postr5-terminal-archives-preparation',label+'-preparation').replace('seven-postr5-terminal-archive-groups-preserving-links-execution',label+'-preserving-links-execution').replace('d99c4b6001fc562d4ff7df638b17e2bbe3b5a804d794b0bff09065d0e48264dc',planpin).replace('[4,7,7,2,2,2,2]',f'[7]*{count}').replace("p['target_count']==26",f"p['target_count']=={count*7}").replace('122839040',str(saving)).replace("g['members']})==26",f"g['members']}})=={count*7}")
 ck(expected==(B/tool).read_text(),'executor exact previous logic with scope literals only '+label)
 ck(r['exit_code']==a['actual_process_returncode']==0 and r['ended_utc'] and a['ended_epoch'] and not a['timeout_expired'],'actual terminal0 '+label)
 ck(r['actual_replacement_performed'] and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'],'all original paths/bytes retained '+label)
 ck([g['count'] for g in p['groups']]==[7]*count and [g['count'] for g in r['groups']]==[7]*count and p['target_count']==7*count and len({x['path'] for g in p['groups'] for x in g['members']})==7*count and r['expected_allocated_saving']==saving,'exact group scope and configured saving '+label)
 for i,g in enumerate(p['groups'],1):
  m=g['members'];can=m[0];ev=[json.loads(x) for x in (R/f'GROUP-{i}.jsonl').read_text().splitlines()];ck([x['event'] for x in ev]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*6+['complete'],'six atomic transitions '+label+'/'+str(i))
  ck(ev[0]['originals']==m and ev[-1]['expected_alias_count']==7 and ev[-1]['bytes_unchanged'] and ev[-1]['all_original_paths_present'],'original exact journal/terminal '+label+'/'+str(i))
  ck(all(x['nlink']==1 for x in m) and len({(x['dev'],x['inode']) for x in m})==7,'original seven independent bodies '+label+'/'+str(i))
  ck(all(not os.path.lexists(x) for x in ev[0]['temporary_paths']),'no pending alias '+label+'/'+str(i))
  for k in range(1,7):
   t=ev[1+3*(k-1):1+3*k];ck([x['expected_alias_count'] for x in t]==[k,k+1,k+1] and all(x['index']==k for x in t) and t[0]['destination']==m[k]['path'],'exact transition order '+label+'/'+str(i)+'/'+str(k))
  for x in m:
   q=Path(x['path']);s=q.lstat();ck(stat.S_ISREG(s.st_mode) and q.resolve()==q,'retained regular path '+str(q));ck((s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns)==(can['dev'],can['inode'],7,can['size'],can['mode'],can['uid'],can['gid'],can['mtime_ns']),'current canonical metadata '+str(q))
   ck(x['path'].startswith(x['owner_root']+'/') and x['path']==str(Path(x['owner_root'])/x['git_path']) and x['git_blob']==can['git_blob'] and x['sha256']==can['sha256'],'same original Git/body identity '+str(q))
   ck(q.suffix.lower()=='.png' if count==21 else q.name.endswith(('.tar.xz','.zip')),'exact reviewed immutable type '+str(q))
 for x in p['anchors']:ck(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'],'small original anchor unchanged '+x['path'])
 for x in p['terminal_rows']:ck(j(x['path'])==x['original_rows'],'historical failures unchanged '+x['path'])
 cons=sorted(R.glob('consumers-*/CONSUMERS.json'));ck(len(cons)==r['consumer_checks']==1+6*count,'original fresh consumer count '+label)
 for q in cons:
  d=j(q);ck(not d['hits'] and bool(d['limitation']),'visible consumer nohits with limit '+str(q))
 expected=[]
 for o in p['owners']:expected.append((o['root'],['git','rev-parse','HEAD'],o['head']))
 for g in p['groups']:
  for x in g['members']:expected.extend([(x['owner_root'],['git','ls-tree',x['owner_head'],'--',x['git_path']],f"100644 blob {x['git_blob']}\t{x['git_path']}"),(x['owner_root'],['git','cat-file','-s',x['git_blob']],str(x['size'])),(x['owner_root'],['git','hash-object',x['path']],x['git_blob'])])
 rows=j(R/'git-originals/subcommands.json');ck(len(rows)==2*(7+count*7*3),'complete pre/post original Git count '+label)
 for row,(cwd,argv,out) in zip(rows,expected+expected):
  d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and (d/'stdout.bin').read_text().strip()==out and row['stderr_bytes']==0,'exact original Git outcome '+str(d))
 for base in [R/'git-originals',A]:
  for row in j(base/'subcommands.json'):
   d=Path(row['directory']);ck(j(d/'result.json')==row and row['actual_process_returncode']==0 and not row['timeout_expired'],'original actualexit '+str(d));ck(bool(j(d/'request.json')) and h(d/'stdin.bin')==row['stdin_sha256'],'original request/stdin '+str(d))
   for st in ['stdout','stderr']:
    q=d/(st+'.bin');ck(q.stat().st_size==row[st+'_bytes'] and h(q)==row[st+'_sha256'],'complete original smallstream '+str(q))
 ck(a==j(A/'subcommands.json')[-1],'outer RESULT exact original row '+label)
 results.append({'scope':label,'groups':count,'paths':count*7,'transitions':count*6,'consumer_checks':1+count*6,'original_git_commands':len(rows),'plan_sha256':planpin,'tool_sha256':toolpin,'actual_result_sha256':h(R/'RESULT.json'),'outer_result_sha256':h(A/'RESULT.json'),'configured_gross_saving':saving,'free_before':r['free_before'],'free_after':r['free_after']})
r={'schema':'visual21-nested8-static-actual-metadata-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'cases':results,'limits':['Only small immutable original scripts/plans/command streams/anchors and currentlstat checked; no second203 PNG/archive payload read or hash.','Root explicitly authorized selfreview execution with parallel/post independent peer; this is post-execution metadata review.','All original image/receipt/fixture paths and bytes retained; configured savings distinct from actual df net recovery.','Existing alias groups keep their independent leases; these29groups203paths also require all aliases delinked before write/reuse.','Original consumer visibility limits and historical product failures preserved; storage0 not product gate0.']};q=O/'VISUAL21_NESTED8_STATIC_ACTUAL_METADATA_PEER.json';q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
