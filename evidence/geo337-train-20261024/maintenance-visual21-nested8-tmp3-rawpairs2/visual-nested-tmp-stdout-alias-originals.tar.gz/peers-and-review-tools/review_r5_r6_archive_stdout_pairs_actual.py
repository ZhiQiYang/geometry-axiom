from pathlib import Path
import hashlib,json,stat
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/workspace/r5-r6-two-archive-stdout-pairs-preparation-20261024');R=Path('/workspace/r5-r6-two-archive-stdout-pairs-preserving-links-execution-20261024');A=Path('/workspace/r5-r6-two-archive-stdout-pairs-preserving-links-launch-20261024')
checks=0;findings=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_bytes())
def ck(v,n):
 global checks
 checks+=1
 if not v:findings.append(n)
p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json');tool=B/'link_exact_two_archive_stdout_pairs.py'
ck(h(B/'PLAN.json')==r['plan_sha256']=='2fdaa5bd109917692a0913ddab97cdd4e82d17047e56e5c912465dba022f3ca9','fixed exact plan')
ck(h(tool)=='965efd7797d7abc51f9f387be0bd100eda31262212b3a646d3b3c8a9395329c2','fixed executor')
ck(h('/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py')==r['core_sha256']=='354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec','unchanged full byte/metadata/atomic core')
ck(h('/workspace/clear_terminal_chrome_caches.py')=='c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847','original consumer guard pin')
s=tool.read_text()
for t in ["[x['count'] for x in p['groups']]==[2,2]","p['expected_allocated_saving']==31252480","[x['role'] for x in p['groups']]==['base','main']","h(PLAN)==PIN and h(CORE)==COREPIN and h(GUARD)==GUARDPIN","core['link_exact'](g['members'],OUT/f'GROUP-{i}.jsonl',before_each=consumer)","core['state'](g['members'],{1})","anchors();consumer()","guard['consumer_check'](p['consumer_prefixes']);anchors()","finally:"]:
 ck(t in s,'static guard '+t)
ck(r['exit_code']==a['actual_process_returncode']==0 and not a['timeout_expired'] and r['ended_utc'],'true terminal maintenance0')
ck(r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and r['original_failures_preserved'],'original receipts retained')
ck([g['count'] for g in p['groups']]==[2,2] and p['expected_allocated_saving']==r['expected_allocated_saving']==31252480,'exact two groups four paths configured allocation')
for x in p['anchors']:ck(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'],'original small receipt anchor '+x['path'])
for x in p['terminal_receipts']:
 t=j(x['path']);ck(t['source_sha']==x['source_sha'] and t['stages']==x['stages'],'original source and stage bytes unchanged')
 ck([t['stages'][k]['execution_exit'] for k in ['prepare','build','compare','perf','profile']]==[0,0,1,0,0] and all(t['stages'][k]['ended_utc'] for k in t['stages']),'original terminal red preserved')
for i,g in enumerate(p['groups'],1):
 m=g['members'];can=m[0];n=2;ev=[json.loads(x) for x in (R/f'GROUP-{i}.jsonl').read_text().splitlines()]
 ck([x['event'] for x in ev]==['initial_verified','before_link','temporary_link_verified','replacement_verified','complete'],'complete atomic journal '+str(i))
 ck(ev[0]['originals']==m and ev[-1]['expected_alias_count']==2 and ev[-1]['bytes_unchanged'] and ev[-1]['all_original_paths_present'],'original byte and terminal journal '+str(i))
 ck(all(x['nlink']==1 for x in m) and m[0]['inode']!=m[1]['inode'],'two original independent files')
 ck([x['expected_alias_count'] for x in ev[1:4]]==[1,2,2] and all(x['index']==1 for x in ev[1:4]),'exact one replacement')
 ck(all(not Path(x).exists() for x in ev[0]['temporary_paths']),'no pending temporary link')
 for x in m:
  q=Path(x['path']);z=q.lstat();ck(q.name=='stdout.bin' and stat.S_ISREG(z.st_mode) and q.resolve()==q,'exact original regular raw path')
  ck((z.st_dev,z.st_ino,z.st_nlink,z.st_size,z.st_mode,z.st_uid,z.st_gid,z.st_mtime_ns)==(can['dev'],can['inode'],2,can['size'],can['mode'],can['uid'],can['gid'],can['mtime_ns']),'current preserved canonical metadata')
  c=j(x['original_command_result']);d=Path(c['directory']);req=j(d/'request.json')
  ck(c['actual_process_returncode']==0 and not c['timeout_expired'] and c['stdout_sha256']==x['sha256']==g['sha256'] and c['stdout_bytes']==x['size'],'original archive command exact stdout identity')
  ck(c['command']==req['command'] and c['command'][:2]==['git','-C'] and c['command'][3:6]==['archive','--format=tar',x['source_sha']] and c['command'][2]==('/workspace/geo323-final-r5-source-20261024' if '/g337323R5/' in x['path'] else '/workspace/geo323-final-r6-source-20261024'),'original archive SHA and argv')
  ck(c['stdin_provided'] is False and c['stdin_sha256']==hashlib.sha256(b'').hexdigest() and not (d/'stdin.bin').exists(),'original inherited stdin absence retained')
  ck(c['command'][3:]==j(Path(m[0]['original_command_result']))['command'][3:],'identical archived Git scopes in each pair')
cons=sorted(R.glob('consumers-*/CONSUMERS.json'));ck(len(cons)==r['consumer_checks']==3,'three original consumer checks')
for f in cons: c=j(f);ck(not c['hits'] and bool(c['limitation']),'consumer nohits with visibility limitation')
rows=j(A/'subcommands.json');ck(len(rows)==1 and rows[0]==a,'actual outer original result')
for row in rows:
 d=Path(row['directory']);ck(j(d/'result.json')==row and j(d/'request.json')['command']==row['command'],'original outer request and result')
 for stream in ['stdout','stderr']:
  q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'full original outer '+stream)
ck((B/'INITIAL_STDIN_ASSUMPTION.json').is_file(),'original producer absent-stdin assumption failure preserved')
report={'schema':'R5-R6-two-original-archive-stdout-pairs-static-actual-peer-v1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'plan_sha256':h(B/'PLAN.json'),'executor_sha256':h(tool),'actual_result_sha256':h(R/'RESULT.json'),'outer_result_sha256':h(A/'RESULT.json'),'groups':2,'paths':4,'transitions':2,'consumer_checks':3,'configured_gross_saving':31252480,'free_before':r['free_before'],'free_after':r['free_after'],'limits':['Small plan/tool/original command rows/anchors/journal/current lstat only; no second31MB archive stdout hash. Executor fresh full byte checks preserved.','R5/R6 raw archives remain at all original paths with identical bytes; every pair alias must be delinked before future write. Immutable raw receipt lease is additional to other archive groups.','Historical source SHA stays R5 a22 and R6 F2bbe respectively. Both original compare reds and full-stage flags remain unchanged; maintenance0 is not product gate0.','Root explicitly authorized owner self-review execution with concurrent/post independent peer. Consumer visibility limitation is preserved.']}
out=O/'R5_R6_ARCHIVE_STDOUT_PAIRS_STATIC_ACTUAL_PEER.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out),'checks':checks,'exit_code':report['exit_code'],'findings':findings}));raise SystemExit(report['exit_code'])
