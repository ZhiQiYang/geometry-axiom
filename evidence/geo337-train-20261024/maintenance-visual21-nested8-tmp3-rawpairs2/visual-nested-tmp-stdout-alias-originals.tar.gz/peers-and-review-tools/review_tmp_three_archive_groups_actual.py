from pathlib import Path
import hashlib,json,os,stat
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/workspace/tmp-three-cold-archive-groups-preparation-20261024');R=Path('/workspace/tmp-three-cold-archive-groups-preserving-links-execution-20261024');A=Path('/workspace/tmp-three-cold-archive-groups-preserving-links-launch-20261024');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
p=j(B/'PLAN.json');r=j(R/'RESULT.json');a=j(A/'RESULT.json');pin='d0c9a4ad4da4991365ff93c88703a87b69228896b425e838d5482750ea4d85b1';tool=B/'link_exact_tmp_three_cold_archive_groups.py';core=B/'exact_four_six_archive_group_link_core.py'
ck(h(B/'PLAN.json')==r['plan_sha256']==pin and h(tool)=='b243e9f958a432579c5191cc194baf589bcd1ff2e4360b780c73f671582b1270' and h(core)==r['core_sha256']=='6029b0d1608c5a851b05c8339c97ac779d1ff4c35d389ca60bd68dd4ec1cf5e9','fixed plan/tool/core pins')
old=Path('/workspace/seven-postr5-terminal-archives-preparation-20261024');ck(core.read_text()==(old/'exact_large_archive_group_link_core.py').read_text().replace('len(members) in (2, 4, 7)','len(members) in (4, 6)'),'one count literal core delta; all byte/meta/atomic guards unchanged')
s=(old/'link_exact_seven_postr5_terminal_archive_groups.py').read_text()
changes={'for seven post-R5 frozen immutable archive groups.':'for3 exact cold TMP archive groups14paths; no payload deletion.','seven-postr5-terminal-archives-preparation':'tmp-three-cold-archive-groups-preparation','seven-postr5-terminal-archive-groups-preserving-links-execution':'tmp-three-cold-archive-groups-preserving-links-execution','d99c4b6001fc562d4ff7df638b17e2bbe3b5a804d794b0bff09065d0e48264dc':pin,'exact_large_archive_group_link_core.py':'exact_four_six_archive_group_link_core.py','354d49ff43303bbc9e8256389f75d72bcb250e68ab79f97f02cff7cf357d1eec':h(core),'[4,7,7,2,2,2,2]':'[6,4,4]',"p['target_count']==26":"p['target_count']==14","len(p['owners'])==7":"len(p['owners'])==6",'122839040':'523485184',"g['members']})==26":"g['members']})==14"}
for x,y in changes.items():ck(x in s,'original literal '+x);s=s.replace(x,y)
ck(s==tool.read_text(),'exact executor previous logic with scope literals only')
ck(r['exit_code']==a['actual_process_returncode']==0 and r['ended_utc'] and a['ended_epoch'] and not a['timeout_expired'],'actual terminal0')
ck(r['actual_replacement_performed'] and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'],'all original paths and bytes retained')
counts=[6,4,4];ck([g['count'] for g in p['groups']]==[g['count'] for g in r['groups']]==counts and p['target_count']==14 and len(p['owners'])==6 and r['expected_allocated_saving']==523485184,'exact three groups14paths configured saving')
ck(len({x['path'] for g in p['groups'] for x in g['members']})==14,'no repeated target')
for i,g in enumerate(p['groups'],1):
 m=g['members'];n=len(m);can=m[0];ev=[json.loads(x) for x in (R/f'GROUP-{i}.jsonl').read_text().splitlines()]
 ck([x['event'] for x in ev]==['initial_verified']+['before_link','temporary_link_verified','replacement_verified']*(n-1)+['complete'],'all atomic transitions '+str(i))
 ck(ev[0]['originals']==m and ev[-1]['expected_alias_count']==n and ev[-1]['bytes_unchanged'] and ev[-1]['all_original_paths_present'],'exact original and terminal journal '+str(i))
 ck(all(x['nlink']==1 for x in m) and len({(x['dev'],x['inode']) for x in m})==n,'original independent bodies '+str(i))
 ck(all(not os.path.lexists(x) for x in ev[0]['temporary_paths']),'no pending temporary aliases '+str(i))
 for k in range(1,n):
  t=ev[1+3*(k-1):1+3*k];ck([x['expected_alias_count'] for x in t]==[k,k+1,k+1] and all(x['index']==k for x in t) and t[0]['destination']==m[k]['path'],'exact transition order '+str(i)+'/'+str(k))
 for x in m:
  q=Path(x['path']);z=q.lstat();ck(stat.S_ISREG(z.st_mode) and q.resolve()==q and q.name.endswith('.tar.gz') and x['owner_root'].startswith('/tmp/'),'retained exact immutable TMP archive '+str(q))
  ck((z.st_dev,z.st_ino,z.st_nlink,z.st_size,z.st_mode,z.st_uid,z.st_gid,z.st_mtime_ns)==(can['dev'],can['inode'],n,can['size'],can['mode'],can['uid'],can['gid'],can['mtime_ns']),'current canonical metadata '+str(q))
  ck(x['path']==str(Path(x['owner_root'])/x['git_path']) and x['git_blob']==can['git_blob'] and x['sha256']==can['sha256'],'exact original Git/body identity '+str(q))
  ck(not any(t in x['path'] for t in ['g337323R6','source-20261024','node-hint','native-r2']),'not live source/cache '+str(q))
for x in p['anchors']:ck(Path(x['path']).stat().st_size==x['bytes'] and h(x['path'])==x['sha256'],'small original anchor bytes preserved '+x['path'])
ret=p['old_source_retirement'];ck(h(ret['path'])==ret['sha256'],'previous source retirement truth retained')
for x in p['terminal_rows']:ck(j(x['path'])==x['original_rows'],'historical results preserved')
cons=sorted(R.glob('consumers-*/CONSUMERS.json'));ck(len(cons)==r['consumer_checks']==12,'twelve actual consumer checks')
for q in cons: d=j(q);ck(not d['hits'] and bool(d['limitation']),'visible nohits with limitation '+str(q))
expected=[]
for o in p['owners']:expected.append((o['root'],['git','rev-parse','HEAD'],o['head']))
for g in p['groups']:
 for x in g['members']:expected.extend([(x['owner_root'],['git','ls-tree',x['owner_head'],'--',x['git_path']],f"100644 blob {x['git_blob']}\t{x['git_path']}"),(x['owner_root'],['git','cat-file','-s',x['git_blob']],str(x['size'])),(x['owner_root'],['git','hash-object',x['path']],x['git_blob'])])
rows=j(R/'git-originals/subcommands.json');ck(len(rows)==96,'96 original pre/post Git commands')
for row,(cwd,argv,out) in zip(rows,expected+expected):
 d=Path(row['directory']);ck(row['cwd']==cwd and row['command']==argv and (d/'stdout.bin').read_text().strip()==out and row['stderr_bytes']==0,'exact original Git outcome '+str(d))
for base in [R/'git-originals',A]:
 for row in j(base/'subcommands.json'):
  d=Path(row['directory']);ck(j(d/'result.json')==row and row['actual_process_returncode']==0 and not row['timeout_expired'],'original exit '+str(d));ck(j(d/'request.json')['command']==row['command'] and h(d/'stdin.bin')==row['stdin_sha256'],'original request/stdin '+str(d))
  for stream in ['stdout','stderr']:
   q=d/(stream+'.bin');ck(q.stat().st_size==row[stream+'_bytes'] and h(q)==row[stream+'_sha256'],'complete original small stream '+str(q))
ck(a==j(A/'subcommands.json')[-1],'outer RESULT is original command row')
result={'schema':'tmp-three-cold-archive-static-actual-metadata-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'plan_sha256':pin,'executor_sha256':h(tool),'core_sha256':h(core),'actual_result_sha256':h(R/'RESULT.json'),'outer_result_sha256':h(A/'RESULT.json'),'groups':3,'counts':counts,'paths':14,'transitions':11,'consumer_checks':12,'original_git_commands':96,'configured_gross_saving':523485184,'free_before':r['free_before'],'free_after':r['free_after'],'limits':['Only exact small plan/tool/core/raw Git streams/anchors and current lstat checked; no second large archive body hash.','Root explicitly authorized selfreview execution and concurrent/post independent peer.','Six historical owners include original unmerged historical heads; no claim all ancestry is current main. Original recovery bindings and retirement receipt remain intact.','14 original immutable archive paths retained and newly share aliases; every alias must be delinked before writes/reuse. Other existing leases unchanged.','Consumer visibility limit and original failure records preserved. Maintenance0 is not product acceptance.']}
q=O/'TMP_THREE_ARCHIVE_STATIC_ACTUAL_METADATA_PEER.json';q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':result['exit_code'],'findings':find}));raise SystemExit(result['exit_code'])
