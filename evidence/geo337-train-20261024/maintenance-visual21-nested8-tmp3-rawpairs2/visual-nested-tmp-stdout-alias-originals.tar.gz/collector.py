"""Collect exact completed maintenance originals; never archive receipt payloads or ELF bodies."""
from pathlib import Path
import datetime,hashlib,io,json,stat,tarfile
OUT=Path('/workspace/visual-nested-tmp-stdout-alias-originals-20261024')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):return json.loads(Path(p).read_text())
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def main():
 OUT.mkdir();entries={}
 def add(p,n):
  p=Path(p);s=p.lstat()
  assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and not p.is_symlink()
  assert s.st_size<4*1024*1024 and not p.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
  assert n not in entries
  entries[n]=dict(source=str(p),bytes=s.st_size,sha256=digest(p),mode=s.st_mode,mtime_ns=s.st_mtime_ns,uid=s.st_uid,gid=s.st_gid)
 def tree(p,n):
  p=Path(p);assert p.is_dir() and not p.is_symlink()
  for q in sorted(p.rglob('*')):
   assert not q.is_symlink()
   if q.is_dir() or '__pycache__' in q.parts:continue
   add(q,n+'/'+str(q.relative_to(p)))
 specs=[
 ('visual21','/workspace/twentyone-cold-visual-groups-preparation-20261024','/workspace/twentyone-cold-visual-groups-preserving-links-execution-20261024','/workspace/twentyone-cold-visual-groups-preserving-links-launch-20261024',21,147,101842944),
 ('nested8','/workspace/eight-cold-nested-archive-groups-preparation-20261024','/workspace/eight-cold-nested-archive-groups-preserving-links-execution-20261024','/workspace/eight-cold-nested-archive-groups-preserving-links-launch-20261024',8,56,50405376),
 ('tmp3','/workspace/tmp-three-cold-archive-groups-preparation-20261024','/workspace/tmp-three-cold-archive-groups-preserving-links-execution-20261024','/workspace/tmp-three-cold-archive-groups-preserving-links-launch-20261024',3,14,523485184),
 ('rawpairs2','/workspace/r5-r6-two-archive-stdout-pairs-preparation-20261024','/workspace/r5-r6-two-archive-stdout-pairs-preserving-links-execution-20261024','/workspace/r5-r6-two-archive-stdout-pairs-preserving-links-launch-20261024',2,4,31252480)]
 archive_bodies=set();gross=0;plans=[]
 for label,prep,actual,outer,group_count,target_count,saving in specs:
  prep,actual,outer=map(Path,(prep,actual,outer));plan=readj(prep/'PLAN.json');r=readj(actual/'RESULT.json');a=readj(outer/'RESULT.json')
  assert r['exit_code']==0 and r['all_original_payload_paths_retained'] and r['all_original_receipt_bytes_preserved'] and a['actual_process_returncode']==0
  assert not a['timeout_expired'] and r['plan_sha256']==digest(prep/'PLAN.json');plans.append(plan);gross+=plan['expected_allocated_saving']
  members=[x for g in plan['groups'] for x in g['members']]
  assert len(plan['groups'])==group_count and len(members)==target_count and plan['expected_allocated_saving']==saving
  archive_bodies.update(x['path'] for x in members)
  tree(prep,'preparation/'+label);tree(actual,'actual/'+label);tree(outer,'launch/'+label)
  for i,x in enumerate(plan['anchors']):
   assert digest(x['path'])==x['sha256']
   add(x['path'],f'anchors/{label}/{i:03d}-'+Path(x['path']).name)
  for i,t in enumerate(plan.get('terminal_rows',[])):
   assert readj(t['path'])==t['original_rows'];add(t['path'],f'terminal-originals/{label}/{i:03d}-'+Path(t['path']).name)
  for i,t in enumerate(plan.get('terminal_receipts',[])):
   v=readj(t['path']);assert v['source_sha']==t['source_sha'] and v['stages']==t['stages'];add(t['path'],f'terminal-originals/{label}/{i:03d}-'+Path(t['path']).name)
  for key in ['original_core','core','consumer_guard']:
   if key in plan:
    x=plan[key];assert digest(x['path'])==x['sha256']
 assert gross==706985984 and len(archive_bodies)==221
 for path in [
 '/workspace/prepare_twentyone_cold_visual_groups_20261024.py','/workspace/launch_twentyone_cold_visual_groups_20261024.py',
 '/workspace/prepare_eight_cold_nested_archive_groups_20261024.py','/workspace/launch_eight_cold_nested_archive_groups_20261024.py',
 '/workspace/prepare_tmp_three_cold_archive_groups_20261024.py','/workspace/launch_tmp_three_cold_archive_groups_20261024.py',
 '/workspace/prepare_r5_r6_two_archive_stdout_pairs_20261024.py','/workspace/prepare_r5_r6_two_archive_stdout_pairs_20261024.py.initial-stdin-assumption.txt','/workspace/launch_r5_r6_two_archive_stdout_pairs_20261024.py']:
  add(path,'preparation-source/'+Path(path).name)
 for path in ['/workspace/evidence-archive-dedup-readonly-20261023/archive_link_core.py','/workspace/clear_terminal_chrome_caches.py','/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py','/workspace/seven-postr5-terminal-archives-preparation-20261024/exact_large_archive_group_link_core.py']:
  add(path,'original-tools/'+Path(path).name)
 train=Path('/workspace/train337-canvas-peer-resume')
 for name in ['VISUAL21_NESTED8_STATIC_ACTUAL_METADATA_PEER.json','review_visual21_nested8_actual.py','VISUAL21_NESTED8_INITIAL_ARCHIVE_SUFFIX_ASSUMPTION.json','review_visual21_nested8_actual.initial-suffix.py.txt','TMP_THREE_ARCHIVE_STATIC_ACTUAL_METADATA_PEER.json','review_tmp_three_archive_groups_actual.py','R5_R6_ARCHIVE_STDOUT_PAIRS_STATIC_ACTUAL_PEER.json','review_r5_r6_archive_stdout_pairs_actual.py','R5_R6_STDOUT_PAIRS_REVIEW_INITIAL_ARGV_ASSUMPTION.json','review_r5_r6_archive_stdout_pairs_actual.initial-argv.py.txt']:
  add(train/name,'peers-and-review-tools/'+name)
 for name in ['VISUAL21_NESTED8_STATIC_ACTUAL_METADATA_PEER.json','TMP_THREE_ARCHIVE_STATIC_ACTUAL_METADATA_PEER.json','R5_R6_ARCHIVE_STDOUT_PAIRS_STATIC_ACTUAL_PEER.json']:
  peer=readj(train/name);assert peer['exit_code']==0 and not peer['findings']
 for path in ['/workspace/TWENTYONE_VISUAL_IMMUTABLE_ALIAS_REGISTRY_20261024.json','/workspace/EIGHT_NESTED_ARCHIVE_IMMUTABLE_ALIAS_REGISTRY_20261024.json','/workspace/TMP_THREE_ARCHIVE_IMMUTABLE_ALIAS_REGISTRY_20261024.json','/workspace/R5_R6_TWO_ARCHIVE_STDOUT_IMMUTABLE_ALIAS_REGISTRY_20261024.json']:
  add(path,'registries/'+Path(path).name)
 add(__file__,'collector.py');add('/workspace/collect_cold128_originals_20261024.py','original-collector.py');add('/workspace/collect_root_eleven_archive_extensions_originals_20261024.py','previous-root11-collector.py')
 assert not archive_bodies.intersection(x['source'] for x in entries.values())
 total=sum(x['bytes'] for x in entries.values());assert total<64*1024*1024
 inventory=dict(schema='preserved-maintenance-original-member-inventory/1',members=[dict(member=n,**x) for n,x in sorted(entries.items())])
 inv=OUT/'MEMBER_INVENTORY.json';dump(inv,inventory)
 archive=OUT/'visual-nested-tmp-stdout-alias-originals.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for n,x in sorted(entries.items()):
   data=Path(x['source']).read_bytes();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=stat.S_IMODE(x['mode']);info.mtime=x['mtime_ns']/1e9;info.uid=x['uid'];info.gid=x['gid'];tar.addfile(info,io.BytesIO(data))
  data=inv.read_bytes();info=tarfile.TarInfo('MEMBER_INVENTORY.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(entries)|{'MEMBER_INVENTORY.json'}
  for n,x in entries.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==x['sha256']
  assert tar.extractfile('MEMBER_INVENTORY.json').read()==inv.read_bytes()
 assert all(digest(x['source'])==x['sha256'] for x in entries.values())
 result=dict(schema='visual-nested-tmp-stdout-preservation-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=0,member_count=len(entries)+1,original_member_count=len(entries),original_bytes=total,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),inventory=str(inv),inventory_sha256=digest(inv),roundtrip_original_bytes=True,group_counts=[21,8,3,2],preserved_path_counts=[147,56,14,4],configured_gross_saving=gross,limits=['Maintenance only; all product red stages retained. No formal product judge run or changed.','All221 original payload paths/bytes stay in place; payload bodies excluded from this metadata-only archive.','Each registry is additive immutable alias history. No previous registry or historical inode/nlink/mtime observation is rewritten.','21PNG includes image/fixture/evidence originals; no deletion. Nested8 contains4tar.xz+4zip. TMP3 is only3 of27 metadata candidates; other24 untouched.','Two raw stdout pairs are exact fixed base/main git archives from terminal R5/R6. All four original raw paths/bytes retained; original full packages remain byte-for-byte unchanged.','Original producer stdin-file assumption and two reviewer path/suffix assumptions remain visible as failures; these were collection/review errors, not product fixes.','Direct producer tool invocations have no invented OS outer transcript. Existing actual executions and original capture streams are fully preserved.','Old source-retirement/public recovery anchors remain original; no new source retirements or Git-object changes occur.','Post-package peer/outer remain adjacent, not recursively included.'])
 dump(OUT/'PACKAGE.json',result);print(json.dumps(result))
if __name__=='__main__':main()
