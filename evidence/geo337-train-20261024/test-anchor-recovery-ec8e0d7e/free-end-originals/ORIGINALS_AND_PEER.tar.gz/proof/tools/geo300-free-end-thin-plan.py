import hashlib
import importlib.util
import json
import os
from pathlib import Path

repo=Path('/tmp/geo300-prerequisites-20261024')
out=Path('/tmp/train337-free-end-anchor-leaf-20261024')
source='4f4a24d76e816274bfae06868b4dbf31f0860299'
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
spec=importlib.util.spec_from_file_location('geo300_capture',cap)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_'))}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
rec=mod.Recorder(out/'thin-plan-commands',env,source)
_,raw,_=rec.run(['git','ls-tree','-r','-l',source,'--','geometry-core','geometry-app','geometry-templates','geometry-web','tests','current_geometry.c','AGENTS.md'],cwd=repo,timeout=60)
files=[]
for line in raw.decode().splitlines():
    meta,path=line.split('\t',1);mode,kind,oid,size=meta.split()
    if kind!='blob':continue
    root=path.split('/')[0]
    include=(root in {'geometry-core','geometry-app','geometry-templates','geometry-web'} and Path(path).suffix in {'.c','.h','.inc','.py'})
    include|=path=='current_geometry.c' or path=='AGENTS.md'
    include|=root=='tests' and len(Path(path).parts)==2 and Path(path).suffix in {'.c','.h','.py','.txt','.scene'}
    include|=path=='geometry-core/domain-decoupling/product-architecture.json'
    if include:files.append({'path':path,'blob':oid,'mode':mode,'bytes':int(size)})
plan={'schema':'free-end-original-suite-thin-plan/1','source':source,
      'scope':'original single tests/test_geo261_wood_contact_world.py; nine unittest methods and all eighteen original controls',
      'files':files,'materialized_file_count':len(files),'materialized_Git_blob_bytes':sum(f['bytes'] for f in files),
      'materialized_now':False,'new_clone_created':False,'compile_started':False,
      'future_subject_commands':[['python3','-B','tests/test_geo261_wood_contact_world.py']],
      'future_proof':'original nine-method suite on original F4f expected count-anchor assertion red; one-line anchor patch then same original suite green; withdraw patch expected same count-anchor red; restore expected green. Product guard control also retains original 0/1/0 and exact ASSERT.',
      'binary_disk_budget_note':'NativeBuild fresh dependent objects/bridge/18 mutant objects require additional space; not measured here, suggest reserve 40 MiB and 1–3 minutes before launch. This is an estimate, not a numerical pass criterion.',
      'original_commands':rec.rows}
(out/'THIN_PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'Git_blob_bytes':plan['materialized_Git_blob_bytes'],'plan_sha256':hashlib.sha256((out/'THIN_PLAN.json').read_bytes()).hexdigest()}))
