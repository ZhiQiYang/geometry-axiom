"""Independent original F4f anchor maintenance proof; no GEO-300 product."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import ast

SOURCE='4f4a24d76e816274bfae06868b4dbf31f0860299'
OWNER=Path('/tmp/geo300-prerequisites-20261024')
ROOT=Path('/tmp/train337-free-end-f4f-source')
OUT=Path('/tmp/train337-free-end-f4f-proof')
TMP=Path('/tmp/train337-free-end-f4f-tmp')
LEAF=Path('/tmp/train337-free-end-anchor-leaf-20261024')
OBSERVER=Path('/tmp/free-end-retain-original-suite.py')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
TARGET='tests/test_geo261_wood_contact_world.py'
STRIP_ENV={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT',
           'LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH',
           'C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}

def digest(data):return hashlib.sha256(data).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    if any(path.exists() for path in (ROOT,OUT,TMP)):raise RuntimeError('fresh source/output/temp required')
    for path,pin in [(CAP,'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'),
                     (OBSERVER,'875213bbe26941626cadb844ad3ac4ff35f5540a317045435d7782d3c4ed9762'),
                     (LEAF/'before.py.txt','c361ec62822c102367f6cb9e37f69a8a8c1d6d1eddcb444020ba69b8bfd5f2fd'),
                     (LEAF/'after.py.txt','8c34f87a4b6228efe5722abee9881fdf72a647dfa632802e62ebf16c41f815c1'),
                     (LEAF/'ANCHOR_ONLY.patch','10e30443932f047fc5bdcd9c4926c00df26f2a5d4935fb64090b16366ed91afe')]:
        if digest(path.read_bytes())!=pin:raise RuntimeError('tool/input pin changed: '+str(path))
    OUT.mkdir();TMP.mkdir()
    stack_before=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,stack_before[1]))
    spec=importlib.util.spec_from_file_location('free_end_capture',CAP)
    cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
    env={k:v for k,v in os.environ.items() if k not in STRIP_ENV and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_'))}
    env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=SOURCE,LC_ALL='C.UTF-8',LANG='C.UTF-8')
    rec=cap.Recorder(OUT,env,SOURCE)
    receipt={'schema':'free-end-original-nine-suite-proof/1','source':SOURCE,'root':str(ROOT),'started_utc':utc(),
             'scope':'original nine-method W contact suite and all eighteen controls; no GEO-300 compaction code',
             'expected_phase_exits':[1,0,1,0],'phases':[],'accepted':False,'subject_timeouts_unchanged':True,
             'outer_subject_timeout':None,'global_ledger_written':False,'R3_lock_taken':False,
             'slot_authority':'root explicit second non-performance slot while full ledger holds R3',
             'stack_before':stack_before,'stack_after':resource.getrlimit(resource.RLIMIT_STACK),
             'logical_original_argv':['python3','-B',TARGET],'actual_runpy_shell_exposed':True,
             'observer_sha256':digest(OBSERVER.read_bytes()),'patch_sha256':digest((LEAF/'ANCHOR_ONLY.patch').read_bytes())}
    receipt['environment_overrides_removed']={name:env.get(name) for name in sorted(STRIP_ENV)}
    (OUT/'launch-request.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    def run(argv,*,cwd=ROOT,data=None,check=True,source_variant=None,timeout=300):
        return rec.run(argv,cwd=cwd,data=data,check=check,source_variant=source_variant,timeout=timeout)
    try:
        run(['df','-B1','/tmp','/workspace'],cwd=OWNER)
        run(['git','clone','--shared','--no-checkout',str(OWNER),str(ROOT)],cwd=OWNER)
        plan=json.loads((LEAF/'THIN_PLAN.json').read_text())
        patterns=''.join('/'+row['path']+'\n' for row in plan['files']).encode()
        run(['git','sparse-checkout','set','--no-cone','--stdin'],data=patterns)
        run(['git','-c','core.autocrlf=false','checkout','--detach',SOURCE])
        _,head,_=run(['git','rev-parse','HEAD'])
        if head.decode().strip()!=SOURCE:raise RuntimeError('wrong source HEAD')
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        if status:raise RuntimeError('unclean original source')
        run(['git','ls-files','--stage'])
        _,product,_=run(['git','show',SOURCE+':geometry-templates/woodworking/native/contact_world.c'])
        if (ROOT/'geometry-templates/woodworking/native/contact_world.c').read_bytes()!=product:raise RuntimeError('product blob differs')
        old=(LEAF/'before.py.txt').read_bytes();new=(LEAF/'after.py.txt').read_bytes()
        if (ROOT/TARGET).read_bytes()!=old:raise RuntimeError('original judge differs')
        control_node=next(n.value for n in ast.parse(old).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROLS' for t in n.targets))
        controls={ast.literal_eval(row.elts[0]):ast.literal_eval(row.elts[4]) for row in control_node.elts}
        if len(controls)!=18:raise RuntimeError('not the original eighteen controls')
        for phase,body,expected in [('original',old,1),('fixed',new,0),('withdrawn',old,1),('restored',new,0)]:
            phase_dir=OUT/phase;phase_dir.mkdir()
            (ROOT/TARGET).write_bytes(body)
            _,names,_=run(['git','diff','--name-only'],source_variant=phase)
            if set(names.decode().splitlines())!=({TARGET} if body!=old else set()):raise RuntimeError('unexpected subject changes')
            if (ROOT/'geometry-templates/woodworking/native/contact_world.c').read_bytes()!=product:raise RuntimeError('product changed')
            env['GEO299316_EXECUTION_LOG']=str(phase_dir/'native-executions.jsonl')
            row,stdout,stderr=run([sys.executable,'-B',str(OBSERVER),'--root',str(ROOT),'--artifacts',str(phase_dir/'compile-retention')],check=False,source_variant=phase,timeout=None)
            text=stderr.decode('utf-8',errors='replace')
            phase_receipt={'phase':phase,'expected_exit':expected,'actual_exit':row['actual_process_returncode'],
                           'judge_sha256':digest(body),'command':row,'nine_methods_reported':'Ran 9 tests' in text,
                           'no_skips_reported':'skipped' not in text,
                           'source_product_sha256':digest(product),'native_executions':str(phase_dir/'native-executions.jsonl'),
                           'compile_retention':str(phase_dir/'compile-retention/retention.json')}
            if expected==1:
                phase_receipt['expected_count_assertion']='Control must change one actual site: free-end' in text and '1 != 3' in text and 'FAILED (failures=1)' in text
            else:
                phase_receipt['expected_count_assertion']=None
            log=phase_dir/'native-executions.jsonl'
            events=[json.loads(line) for line in log.read_text().splitlines()] if log.is_file() else []
            proofs=[]
            for control,assertion in controls.items():
                expected_phases={'baseline':0,'mutant':1,'restored':0}
                if expected==1 and control=='free-end':expected_phases={'baseline':0}
                for child_phase,child_exit in expected_phases.items():
                    matches=[e for e in events if e.get('control')==control and e.get('phase')==child_phase]
                    good=len(matches)==1 and matches[0]['actual_exit']==child_exit
                    if good and child_phase=='mutant':good='ASSERT:'+assertion in matches[0]['stderr']
                    proofs.append({'control':control,'phase':child_phase,'expected_exit':child_exit,'matches':len(matches),'passed':good})
            retention=phase_dir/'compile-retention/retention.json'
            build_logs=json.loads(retention.read_text()) if retention.is_file() else []
            build_rows=[]
            for retained in build_logs:
                raw=Path(retained['retained']).read_bytes()
                if digest(raw)!=retained['sha256']:raise RuntimeError('retained build log changed')
                build_rows.extend(json.loads(raw))
            phase_receipt['control_proofs']=proofs
            phase_receipt['original_build_commands']=len(build_rows)
            phase_receipt['all_original_build_exits_zero']=bool(build_rows) and all(r['exit']==0 for r in build_rows)
            phase_receipt['passed']=row['actual_process_returncode']==expected and phase_receipt['nine_methods_reported'] and phase_receipt['no_skips_reported'] and (phase_receipt['expected_count_assertion'] is not False) and all(p['passed'] for p in proofs) and phase_receipt['all_original_build_exits_zero']
            receipt['phases'].append(phase_receipt)
            (phase_dir/'receipt.json').write_text(json.dumps(phase_receipt,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps({'phase':phase,'exit':row['actual_process_returncode'],'expected':expected,'checks':phase_receipt['passed']}),flush=True)
            # Deliberate red/error does not stop the following independent phases.
        (ROOT/TARGET).write_bytes(old)
        _,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
        receipt['source_restored_clean']=status==b''
        run(['git','ls-files','--stage'])
        run(['df','-B1','/tmp','/workspace'])
        receipt['accepted']=receipt['source_restored_clean'] and len(receipt['phases'])==4 and all(p['passed'] for p in receipt['phases'])
    except BaseException as exc:
        receipt['exception']=repr(exc)
        raise
    finally:
        receipt['ended_utc']=utc();receipt['original_commands']=rec.rows
        (OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'accepted':receipt['accepted'],'receipt':str(OUT/'receipt.json')}),flush=True)
    return 0 if receipt['accepted'] else 1

if __name__=='__main__':raise SystemExit(main())
