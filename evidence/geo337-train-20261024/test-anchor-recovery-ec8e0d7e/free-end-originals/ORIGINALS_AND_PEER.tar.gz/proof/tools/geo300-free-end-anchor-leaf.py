import ast
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path

repo=Path('/tmp/geo300-prerequisites-20261024')
out=Path('/tmp/train337-free-end-anchor-leaf-20261024')
if out.exists():raise SystemExit('fresh output required')
out.mkdir()
source='4f4a24d76e816274bfae06868b4dbf31f0860299'
path='tests/test_geo261_wood_contact_world.py'
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
spec=importlib.util.spec_from_file_location('geo300_capture',cap)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_'))}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
rec=mod.Recorder(out/'commands',env,source)
_,old,_=rec.run(['git','show',source+':'+path],cwd=repo,timeout=60)
_,product,_=rec.run(['git','show',source+':geometry-templates/woodworking/native/contact_world.c'],cwd=repo,timeout=60)
before='    ("free-end", "||face->fixity==WOOD_STOP_FREE", "", "ends", "free-end-faces-ignored"),'
after='    ("free-end", "||face->lo>cross_lo||face->hi<cross_hi||face->fixity==WOOD_STOP_FREE", "||face->lo>cross_lo||face->hi<cross_hi", "ends", "free-end-faces-ignored"),'
text=old.decode();assert text.count(before)==1
new=text.replace(before,after).encode()
patch=''.join(difflib.unified_diff(text.splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode()
(out/'before.py.txt').write_bytes(old);(out/'after.py.txt').write_bytes(new)
(out/'ANCHOR_ONLY.patch').write_bytes(patch)
old_anchor='||face->fixity==WOOD_STOP_FREE'
new_anchor='||face->lo>cross_lo||face->hi<cross_hi||face->fixity==WOOD_STOP_FREE'
replacement='||face->lo>cross_lo||face->hi<cross_hi'
product_text=product.decode()
assert product_text.count(old_anchor)==3
assert product_text.count(new_anchor)==1
# The new mutation's complete product bytes are exactly those obtained by
# withdrawing the old suffix at this one intended, original end-face site.
target=product_text.index(new_anchor)+len(replacement)
expected=product_text[:target]+product_text[target+len(old_anchor):]
assert product_text.replace(new_anchor,replacement)==expected
ast_old,ast_new=ast.parse(text),ast.parse(new)
assert ast.dump(ast_old).replace(ast.dump(ast.Constant(old_anchor)),ast.dump(ast.Constant(new_anchor)),1)!=ast.dump(ast_new) # replacement also explicitly retains the old width checks
def defs(tree):
    result={}
    for n in ast.walk(tree):
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):result[n.name]=ast.dump(n)
    return result
assert defs(ast_old)==defs(ast_new)
manifest={'schema':'train337-free-end-one-anchor-maintenance/1','source':source,'path':path,
          'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),
          'patch_sha256':hashlib.sha256(patch).hexdigest(),'old_anchor_count':3,'new_anchor_count':1,
          'product_source_written':False,'old_judge_function_ASTs_exact':True,
          'same_withdrawn_product_bytes':True,'all_test_methods_ASSERTs_timeouts_unchanged':True,
          'dynamic_status':'UNRUN','original_commands':rec.rows}
(out/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'patch_sha256':manifest['patch_sha256'],'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest(),'status':'UNRUN'}))
