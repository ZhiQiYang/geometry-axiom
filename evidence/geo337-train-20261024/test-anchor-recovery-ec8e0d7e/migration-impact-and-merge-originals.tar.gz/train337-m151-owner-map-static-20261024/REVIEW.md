M151 owner-map 修正可接受；唯一 source leaf 是 tests/test_geo261_mutation_migration.py。其餘60檔只新增歷史收據，不能當成新列車完整綠燈。原完整owner-map相等斷言保留，M151實際仍由contact_world.c持有，11→12／72→73是確切registry聯集數。

已在8f9301fc精確Git-byte薄來源跑原命令 python3 -B tests/test_geo261_mutation_migration.py -v，15方法全綠；只撤回該leaf到f702原bytes後，原完整map assert單一正常FAIL exit1，恢復後15方法全綠。三程序真0/1/0，完整argv/env/輸出/sourcehash見各phase。沒有C或ledger命令，也不冒這是當前4f4整份native。

Closure：C include閉包、mutant定義、核心run_tests場景oracle沒變；bridge oracle明確glob tests/*.py，所以這leaf會使合併後bridge帳本過期。當前4f4執行原件仍保歷史效力，不能改標新final；root在最後共同來源整份重產／check。

QUESTIONS草稿：#314程式符合已鎖題3的有序語意，條文採納狀態另列；19:44交接轉述使用者先不寫SSOT，不擅改公理或決策。#335的13mm正例CLI兩順序仍不可放，是已知且獲准另行設計的產品能力缺口；不洗綠，也不是本次owner-map patch修好的項目。
