import ast,datetime,hashlib,json,os,pathlib,posixpath,re,resource,subprocess,sys,time
O=pathlib.Path(__file__).resolve().parent;G='/workspace/geometry-axiom';F='8f9301fc1b78712d930ffc68074437e44d068aab';OLD='f7026c110b4800ee87f9ecc1eff0cc14d535841a'
ROOT=O/'thin-source';assert not ROOT.exists(),'fresh only';ROOT.mkdir();env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');gitrows=[]
def git(args):
 r=subprocess.run(['git','-C',G,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);assert r.returncode==0,(args,r.stderr.decode());return r.stdout
names=set(git(['ls-tree','-r','--name-only',F]).decode().splitlines());cache={}
def blob(path):
 if path not in cache:cache[path]=git(['show',F+':'+path])
 return cache[path]
# Original mutate.Sources visits the same two C entrypoints and quoted includes.
inc=re.compile(r'^\s*#\s*include\s+"([^"]+)"',re.M);selected=set()
def add_c(path):
 if path in selected:return
 selected.add(path);data=blob(path).decode('utf-8')
 for name in inc.findall(data):
  target=posixpath.normpath(posixpath.join(posixpath.dirname(path),name))
  if target in names:add_c(target)
for path in ('current_geometry.c','geometry-web/web_bridge.c'):add_c(path)
# Import only original local Python dependency closure; no modified judge or compiler shim.
py_pending=['tests/test_geo261_mutation_migration.py','tests/mutate.py'];py_seen=set()
while py_pending:
 path=py_pending.pop()
 if path in py_seen:continue
 py_seen.add(path);selected.add(path);tree=ast.parse(blob(path),filename=path)
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):mods=[x.name for x in n.names]
  elif isinstance(n,ast.ImportFrom):mods=[n.module] if n.module else []
  else:continue
  for mod in mods:
   candidate='tests/'+mod.split('.')[0]+'.py'
   if candidate in names and candidate not in py_seen:py_pending.append(candidate)
for rel in sorted(selected):
 f=ROOT/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(blob(rel))
def inventory():
 return {p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.rglob('*')) if p.is_file()}
initial=inventory();(O/'THIN_SOURCE_MANIFEST.json').write_text(json.dumps({'base_source_sha':F,'git_repo_read_only':G,'materialization':'Only original two-entrypoint C include closure plus Python import closure; not full checkout, no .git/index/objects copied.','python_files':sorted(py_seen),'files':initial},ensure_ascii=False,indent=2)+'\n')
leaf='tests/test_geo261_mutation_migration.py';fixed=blob(leaf);withdrawn=git(['show',OLD+':'+leaf]);assert fixed!=withdrawn
before=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16777216,before[1]))
runenv=dict(os.environ)
removed={}
for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD'):
 removed[k]=runenv.pop(k,None)
runenv.update(PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',LANG='C.UTF-8',GITHUB_SHA=F,GITHUB_WORKSPACE=str(ROOT))
result={'schema':'m151-owner-map-pure-python-proof/1','base_source_sha':F,'withdraw_test_leaf_sha':OLD,'source_kind':'isolated exact Git-byte thin source, not a Git checkout','original_test':'tests/test_geo261_mutation_migration.py','source_manifest':str(O/'THIN_SOURCE_MANIFEST.json'),'stack_before':before,'stack_during':resource.getrlimit(resource.RLIMIT_STACK),'cleared_env_names':list(removed),'phases':[],'errors':[]}
for phase,leafdata,expected in [('baseline',fixed,0),('withdrawn',withdrawn,1),('restored',fixed,0)]:
 d=O/phase;assert not d.exists();d.mkdir();(d/'tmp').mkdir();(ROOT/leaf).write_bytes(leafdata)
 inv=inventory();others={k:v for k,v in inv.items() if k!=leaf};assert others=={k:v for k,v in initial.items() if k!=leaf}
 penv=dict(runenv,TMPDIR=str(d/'tmp'),MUTATE_CACHE=str(d/'unused-mutant-cache'),MUTATE_RESULTS=str(d/'unused-results.json'))
 argv=[sys.executable,'-B',leaf,'-v'];req={'phase':phase,'source_sha':F,'source_variant':'original Git leaf' if phase!='withdrawn' else 'only migration test leaf reverted to f7026c11; product/MUTANTS unchanged','withdrawn_test_leaf_source_sha':OLD if phase=='withdrawn' else None,'argv':argv,'cwd':str(ROOT),'environment':{k:penv.get(k) for k in ('PATH','TMPDIR','LANG','LC_ALL','PYTHONOPTIMIZE','PYTHONDONTWRITEBYTECODE','PYTHONPATH','NODE_OPTIONS','LD_PRELOAD','MUTATE_CACHE','MUTATE_RESULTS','GITHUB_SHA','GITHUB_WORKSPACE')},'source_before':inv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};(d/'request.json').write_text(json.dumps(req,ensure_ascii=False,indent=2)+'\n')
 started=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=penv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(d/'stdout.bin').write_bytes(p.stdout);(d/'stderr.bin').write_bytes(p.stderr);after=inventory();same=after==inv
 row={'phase':phase,'argv':argv,'cwd':str(ROOT),'actual_exit':p.returncode,'expected_exit':expected,'duration_seconds':time.monotonic()-started,'stdout_bytes':len(p.stdout),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_bytes':len(p.stderr),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'source_after_unchanged':same,'results_file_created':(d/'unused-results.json').exists(),'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stderr_tail':p.stderr.decode(errors='replace')[-1600:]};(d/'receipt.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');result['phases'].append(row)
 if p.returncode!=expected or not same or row['results_file_created']:result['errors'].append(phase+' original exit/source/result guard mismatch')
 print(phase,p.returncode,row['stderr_tail'],flush=True)
(ROOT/leaf).write_bytes(fixed);result['source_restored_equal_initial']=inventory()==initial;result['criterion_exits']=[r['actual_exit'] for r in result['phases']];result['passed']=not result['errors'] and result['source_restored_equal_initial'];result['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'PROOF_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('passed',result['passed'],'C_compile_or_executable_command_launched',False);sys.exit(0 if result['passed'] else 1)
