import subprocess,pathlib,os,json,hashlib,ast
O=pathlib.Path(__file__).resolve().parent;G='/workspace/geometry-axiom';env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');F='8f9301fc1b78712d930ffc68074437e44d068aab';B='f7026c110b4800ee87f9ecc1eff0cc14d535841a';T='4f4a24d76e816274bfae06868b4dbf31f0860299'
def git(*args):
 r=subprocess.run(['git','-C',G,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);assert r.returncode==0,(args,r.stderr.decode());return r.stdout
paths=git('diff','--name-only',B,F).decode().splitlines();tree=ast.parse((O/'04.stdout').read_text());methods=[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')];x=json.loads((O/'PROOF_RECEIPT.json').read_text());blobs={}
for path in ['tests/mutate.py','tests/mutation_bridge.py','tests/test_geo261_mutation_migration.py','tests/run_all.expected.json','geometry-core/domain-decoupling/product-architecture.json']:
 blobs[path]={sha:git('rev-parse',sha+':'+path).decode().strip() for sha in (B,F,T)}
m151=None
for n in ast.walk(ast.parse(git('show',T+':tests/mutate.py'))):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict':
  kws={k.arg:k.value for k in n.keywords}
  if 'id' in kws and isinstance(kws['id'],ast.Constant) and kws['id'].value=='M151':
   m151={k:ast.literal_eval(kws[k]) for k in ('id','file','binary','tests') if k in kws}
assert m151['file']=='geometry-templates/woodworking/native/contact_world.c'
(O/'train-decision-queue.md').write_bytes(git('show',T+':決策佇列.md'))
neg=(O/'withdrawn/stderr.bin').read_text();fixed=[(O/f'{n}/stderr.bin').read_text() for n in ('baseline','restored')]
assert neg.count('\nFAIL: ')==1 and 'test_all_fifty_definitions_keep_live_or_retired_targets' in neg and 'FAILED (failures=1)' in neg and '\nERROR: ' not in neg
assert all('Ran 15 tests' in s and s.rstrip().endswith('OK') for s in fixed)
r={
 'schema':'m151-owner-map-independent-static-and-purepy-review/1',
 'base_claude_sha':B,'reviewed_claude_sha':F,'current_train_sha_read_only':T,
 'diff_paths_count':len(paths),'evidence_paths_count':sum(p.startswith('evidence/') for p in paths),
 'only_non_evidence_path':[p for p in paths if not p.startswith('evidence/')],
 'changed_leaf_sha256':hashlib.sha256((O/'04.stdout').read_bytes()).hexdigest(),
 'original_test_methods':len(methods),'method_names':methods,'blob_ids':blobs,
 'M151_current_train_registration':m151,
 'proof':{'receipt':str(O/'PROOF_RECEIPT.json'),'receipt_sha256':hashlib.sha256((O/'PROOF_RECEIPT.json').read_bytes()).hexdigest(),'sourcebase':F,'source_kind':x['source_kind'],'exits':x['criterion_exits'],'passed':x['passed'],'normal_named_assertion_negative':True,'no_compile_or_C_or_ledger_command':True,'scope':'15 original Python unit methods on isolated exact Git-byte thin source, not full native or final train checkout.'},
 'closure_assessment':{'native_C_and_include_closure_change_from_this_leaf':False,'mutant_definitions_change_from_this_leaf':False,'core_scene_oracle_change_from_this_leaf':False,'bridge_oracle_change_from_this_leaf':True,'basis':'mutation_bridge.oracle_hash() directly includes every tests/*.py, plus tests/*.c, tests/fixtures/**/*.scene and root *.scene. This leaf belongs to that conservative judge closure.','current_4f4_ledger':'Current run remains evidence for original 4f4 only. Merge of this leaf changes bridge oracle hash; do not relabel current records as fresh under new final SHA. Root must regenerate/check final ledger under agreed complete-run rules.','architecture':'This leaf is a test, not an H-layer product change; no C/build command/source fingerprint changed by this patch. Final architecture receipts still must bind the actual final manifest closure.'},
 'decision_questions':[{'id':'Q314-SSOT-DEFERRED','authority':'origin/main 決策佇列.md 2026-10-22 題3/4鎖定有序語意；handoff337 2026-10-23T19:44:03Z轉述使用者2026-10-24先不寫I24/D29/D10b。','classification':'Known approved behavior vs deferred SSOT text; preserve separate status, not permission to modify axiom/queue.','question':'何時重新提出逐字條文採納？此輪維持先不寫；如需採納，根代理另循使用者逐字核可、POST_APPROVAL_REVISIONS、reader同步和AXIOM_REVISION流程。','scope_limit':'handoff先不寫是Claude轉述，不能冒使用者逐字核可文本。'}, {'id':'Q335-PLACEMENT-PATH-GAP','authority':'handoff337 19:44 Known gap: approved 13mm thin-step positive B not expressible by CLI in either placement order; issue335 policy advances first, placement design deferred.','classification':'Documented product capability gap outside M151 owner-map fix; do not count as passed/allowed skip.','question':'依既有使用者選擇保留缺口與後續具名owner/issue335，不能藉本輪owner-map修正宣稱CLI正例已可放置。'}],
 'findings':[],'verdict':'No static blocker in the one-leaf M151 registry-owner fix; original 15 tests and exact withdrawal/restoration proof accepted. Other final train gates not claimed by this pure-Python run.',
 'worktree_mutations':'None to root, active ROOT/SEED/CACHE or Claude/train branch. Only isolated thin-source leaf changed and restored.'
}
f=O/'REVIEW.json';f.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
md='''M151 owner-map 修正可接受；唯一 source leaf 是 tests/test_geo261_mutation_migration.py。其餘60檔只新增歷史收據，不能當成新列車完整綠燈。原完整owner-map相等斷言保留，M151實際仍由contact_world.c持有，11→12／72→73是確切registry聯集數。

已在8f9301fc精確Git-byte薄來源跑原命令 python3 -B tests/test_geo261_mutation_migration.py -v，15方法全綠；只撤回該leaf到f702原bytes後，原完整map assert單一正常FAIL exit1，恢復後15方法全綠。三程序真0/1/0，完整argv/env/輸出/sourcehash見各phase。沒有C或ledger命令，也不冒這是當前4f4整份native。

Closure：C include閉包、mutant定義、核心run_tests場景oracle沒變；bridge oracle明確glob tests/*.py，所以這leaf會使合併後bridge帳本過期。當前4f4執行原件仍保歷史效力，不能改標新final；root在最後共同來源整份重產／check。

QUESTIONS草稿：#314程式符合已鎖題3的有序語意，條文採納狀態另列；19:44交接轉述使用者先不寫SSOT，不擅改公理或決策。#335的13mm正例CLI兩順序仍不可放，是已知且獲准另行設計的產品能力缺口；不洗綠，也不是本次owner-map patch修好的項目。
'''
(O/'REVIEW.md').write_text(md)
print('review',hashlib.sha256(f.read_bytes()).hexdigest(),f.stat().st_size)
print('proof',r['proof']['receipt_sha256'],'exits',x['criterion_exits'],'methods',len(methods),'same_migration_blob_old_train',blobs['tests/test_geo261_mutation_migration.py'][B]==blobs['tests/test_geo261_mutation_migration.py'][T])
