"""Publish scoped metadata with an isolated Git index and ordinary fast-forward push."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('request', type=Path)
a = p.parse_args()
request = json.loads(a.request.read_text())
repo = Path('/workspace/geometry-axiom')
branch = request['branch']
assert branch.startswith('codex/') or branch == 'handoff/codex-takeover-20261021'
out = Path(request['out'])
out.mkdir(parents=True)
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('capture', helper)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = dict(os.environ, GIT_INDEX_FILE=str(out / 'index'), LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1')
r = capture.Recorder(out, env, request['source_sha'])

def git(*args, data=None, check=True):
    row, stdout, _ = r.run(['git', *args], cwd=repo, data=data, check=check,
                           source_variant='metadata-only-isolated-index')
    return row, stdout.decode().strip()

_, current = git('branch', '--show-current')
assert current != branch, 'Do not move a checked-out branch through a separate index'
_, worktrees = git('worktree', 'list', '--porcelain')
assert 'branch refs/heads/' + branch not in worktrees.splitlines(), 'Branch is checked out in another worktree'
_, actual_remote = git('ls-remote', '--heads', 'origin', 'refs/heads/' + branch)
remote_sha = actual_remote.split()[0] if actual_remote else None
assert remote_sha == request.get('expected_remote'), (remote_sha, request.get('expected_remote'))
parent = request['parent']
if remote_sha:
    assert parent == remote_sha
local_row, old_local = git('rev-parse', '--verify', 'refs/heads/' + branch, check=False)
old_local = old_local if local_row['actual_process_returncode'] == 0 else '0' * 40
assert old_local == '0' * 40 or old_local == remote_sha, 'Preserve any local unpublished commits'
git('cat-file', '-e', parent + '^{commit}')
git('read-tree', parent)
files = []
for item in request['files']:
    path = item['path']
    assert not path.startswith('/') and '..' not in Path(path).parts
    assert path in request['allowed_paths']
    if branch == 'handoff/codex-takeover-20261021':
        assert path == 'handoff/NEXT.md' or (path.startswith('handoff/pr-requests/') and path.endswith('.json'))
    elif branch.endswith('-prbody'):
        assert path == 'PR_BODY.md'
    else:
        assert path.startswith('evidence/geo337-train-20261024/')
    data = Path(item['source']).read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()
    assert sha256 == item['sha256']
    _, blob = git('hash-object', '-w', '--stdin', data=data)
    git('update-index', '--add', '--cacheinfo', '100644,' + blob + ',' + path)
    files.append(dict(path=path, sha256=sha256, bytes=len(data), blob=blob))
_, names = git('diff', '--cached', '--name-only', parent)
assert set(names.splitlines()) == set(request['allowed_paths'])
git('diff', '--cached', '--check', parent)
_, tree = git('write-tree')
_, commit = git('commit-tree', tree, '-p', parent, data=(request['message'] + '\n').encode())
git('update-ref', 'refs/heads/' + branch, commit, old_local)
push_row, _ = git('push', 'origin', commit + ':refs/heads/' + branch, check=False)
published = push_row['actual_process_returncode'] == 0
if published:
    _, observed = git('ls-remote', '--heads', 'origin', 'refs/heads/' + branch)
    assert observed.split()[0] == commit
result = dict(branch=branch, source_sha=request['source_sha'], parent=parent, commit=commit,
              published=published, push_exit=push_row['actual_process_returncode'], files=files,
              acceptance_executed=False, commands=r.rows)
capture.dump(out / 'RESULT.json', result)
print(json.dumps({k: result[k] for k in ('branch', 'commit', 'published', 'push_exit')}))
raise SystemExit(push_row['actual_process_returncode'])
