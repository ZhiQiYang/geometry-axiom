"""Root-only exact eight closed standalone index caches; no Git writes or receipts removed."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN = Path('/workspace/additional-closed-index-proof-20261023/PLAN.json')
PIN = '18c0504bc0c6c5cb6d71ef63b0e1116985f11157d43fc45ec7973bb9bfd6724c'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT = Path('/workspace/exact-eight-additional-index-execution-20261023')
EXPECTED = ['/tmp/nowood-bfbab207-evidence-publication/private.index',
            '/workspace/geo337-prbody-final-L-first-gates-publication/index'] + [
    f'/tmp/geo337-continue-20261024/{name}/index'
    for name in ['publish-body-a6072dde','publish-body-5b0','publish-body-5049','body-source-checkpoint',
                 'initial-prbody-publication','initial-progress-publication']]


def main():
    assert sys.flags.optimize == 0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest() == GUARD_PIN
    g={'__name__':'_original_guards_only','__file__':str(GUARD)}
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),g);g['OUT']=OUT;OUT.mkdir()
    result=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=1,
                removed=[],free_before=g['free'](),scope='Eight exact rebuildable standalone caches only; no real .git/index, objects, source or receipts.')
    try:
        assert g['digest'](PLAN)==PIN
        plan=json.loads(PLAN.read_text());items=plan['candidates']
        assert plan['exit_code']==0 and plan['deleted']==0 and [x['path'] for x in items]==EXPECTED
        assert plan['allocated_by_fs']=={'/workspace':5005312,'/tmp':35098624}
        def terminal():
            for x in items:
                for key in ['receipt','subcommands']:
                    assert g['digest'](Path(x[key]['path']))==x[key]['sha256']
                d=json.loads(Path(x['receipt']['path']).read_text())
                assert d['push_exit']==0 and (d.get('published') is True or d.get('passed') is True)
                assert d.get('commit',d.get('evidence_head'))==x['public_commit']
        def identity(x):
            p=Path(x['path']);assert not any(a=='.git' or a.endswith('.git') for a in p.parts)
            assert p.resolve(strict=True)==p and p.name in ['index','private.index']
            assert not os.path.lexists(str(p)+'.lock'), 'possible active index writer'
            g['identity'](p,x,is_file=True);s=p.stat()
            assert (s.st_uid,s.st_gid)==(x['uid'],x['gid']) and not os.listxattr(p,follow_symlinks=False)
        terminal()
        for x in items:identity(x)
        g['consumer_check'](EXPECTED+[str(Path(x).parent) for x in EXPECTED])
        for x in items:
            terminal();identity(x);Path(x['path']).unlink();result['removed'].append(x['path'])
            g['dump']('PROGRESS.json',result)
        terminal();assert all(not Path(p).exists() and Path(p).parent.is_dir() for p in EXPECTED)
        result.update(exit_code=0,removed_allocated_by_fs=plan['allocated_by_fs'],
                      reconstruction='All retained public commits and semantic read-tree recipes remain in pinned plan.',
                      consumer_limit='Only readable proc fields observed; unknown fields retained.')
    except Exception as exc:result['error']=repr(exc);raise
    finally:
        result.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_after=g['free']())
        g['dump']('RESULT.json',result);print(json.dumps(result))


if __name__=='__main__':main()
