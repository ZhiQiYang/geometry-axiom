"""Read-only proof for the single root-authorized three-copy receipt group."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
from archive_link_core import ancestors, digest, metadata

BASE = Path(__file__).resolve().parent
PIN = '7983d3b725d971bad1a69174fea533442160be78c3424e968573b394e2ac7c53'
SOURCE = BASE / 'ARCHITECTURE_METADATA_CANDIDATES.json'
OUT = BASE / 'architecture-exact-three-proof'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
RELATIVE = 'evidence/geo261-final-08dede0b/raw/architecture-refresh.raw.tar.gz'
ROOT = Path('/workspace/geo261-cold/g261seal')
HEADS = ['b6646d10751a0d85a2f03f5d24fbe1073cb78980',
         'a12d184ec1865ad078700cea2387ac69e82ab62a',
         'aa02a65e9d3923cc14c13340f05ed16c8b7d4fce']
RECEIPTS = ['ledger/receipt.json', 'census/receipt.json', 'architecture-refresh/RESULT.json']
BLOB = 'e3c6459d8cf86b72076c7ff2f35834a2c5870d0d'


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  exit_code=1, operation='read_only_full_byte_and_git_blob_comparison')
    commands = []
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    try:
        assert sys.flags.optimize == 0 and digest(SOURCE) == PIN
        original = json.loads(SOURCE.read_text())['top_groups'][0]
        members = original['members']
        expected = [str(ROOT / name / RELATIVE) for name in ['p-source', 'a-source', 'l-source']]
        assert [m['path'] for m in members] == expected
        assert [m['head'] for m in members] == HEADS
        assert original['git_blob'] == BLOB
        for i, item in enumerate(members):
            p = Path(item['path']); ancestors(p)
            before = metadata(p)
            for key in ['dev', 'inode', 'mode', 'size', 'mtime_ns', 'uid', 'gid', 'nlink']:
                assert before[key] == item[key], (str(p), key)
            assert before['nlink'] == 1 and not os.listxattr(p, follow_symlinks=False)
            item['original_pre_hash_metadata'] = before
            for suffix in [['rev-parse', 'HEAD'], ['ls-tree', '-z', 'HEAD', '--', RELATIVE]]:
                argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', item['repo'], *suffix]
                n = len(commands); dump(f'{n:03d}.request.json', dict(argv=argv))
                proc = subprocess.run(argv, env=env, capture_output=True)
                (OUT / f'{n:03d}.stdout.bin').write_bytes(proc.stdout)
                (OUT / f'{n:03d}.stderr.bin').write_bytes(proc.stderr)
                commands.append(dict(argv=argv, exit_code=proc.returncode,
                                     stdout_sha256=hashlib.sha256(proc.stdout).hexdigest(), stderr_bytes=len(proc.stderr)))
                dump('COMMANDS.json', commands)
                assert proc.returncode == 0
                if suffix[0] == 'rev-parse': assert proc.stdout.decode().strip() == item['head']
                else: assert proc.stdout == ('100644 blob ' + BLOB + '\t' + RELATIVE + '\0').encode()
            receipt = ROOT / RECEIPTS[i]
            r = json.loads(receipt.read_text())
            assert r['source_sha'] == item['head']
            ended = r.get('finished_utc', r.get('finished', r.get('finishedUtc')))
            assert ended
            item['terminal_receipt'] = dict(path=str(receipt), sha256=digest(receipt),
                                           bytes=receipt.stat().st_size, ended=ended,
                                           original_passed=r.get('stage_execution_passed', r.get('passed')))
        # Compare all physical bytes with the actual object stream, never copy archive payloads.
        argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', members[0]['repo'], 'cat-file', 'blob', BLOB]
        dump('006.request.json', dict(argv=argv, stdout_retention='compared in full with all three retained original paths; no second archive copy'))
        h = hashlib.sha256(); obj = hashlib.sha1(b'blob 5248602\0'); count = 0
        with (OUT / '006.stderr.bin').open('wb') as err:
            proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=err)
            streams = [Path(m['path']).open('rb') for m in members]
            try:
                while chunk := proc.stdout.read(1024 * 1024):
                    assert all(s.read(len(chunk)) == chunk for s in streams), 'byte mismatch'
                    h.update(chunk); obj.update(chunk); count += len(chunk)
                assert all(s.read(1) == b'' for s in streams), 'trailing physical data'
            finally:
                for stream in streams: stream.close()
                proc.stdout.close()
                if proc.poll() is None and count != 5248602: proc.terminate()
                rc = proc.wait()
                commands.append(dict(argv=argv, exit_code=rc, compared_bytes=count, stdout_sha256=h.hexdigest(),
                                     stdout_retained_at_original_paths=expected))
                dump('COMMANDS.json', commands)
        assert rc == 0 and count == 5248602 and obj.hexdigest() == BLOB
        for item in members:
            item['sha256'] = h.hexdigest()
            after = metadata(item['path'])
            for k in ['dev', 'inode', 'mode', 'size', 'mtime_ns', 'uid', 'gid', 'nlink']:
                assert after[k] == item[k]
        raw = GUARD.read_bytes(); assert hashlib.sha256(raw).hexdigest() == GUARD_PIN
        namespace = {'__name__': '_guard_only', '__file__': str(GUARD)}
        exec(compile(raw, str(GUARD), 'exec'), namespace)
        namespace['OUT'] = OUT
        namespace['consumer_check']([m['repo'] for m in members])
        plan = dict(schema='receipt-archive-exact-three-dedup/1', members=members,
                    git_blob=BLOB, sha256=h.hexdigest(), size=count,
                    expected_allocated_saving=2 * members[0]['allocated_bytes'],
                    terminal_state='historical stages terminal; census originally red remains red',
                    parent_reservation='Root explicitly bars all three checkouts from mutation/reuse until de-linked.',
                    inode_limit='Original inodes cannot be restored. De-link can restore independent bytes/mode/mtime, not original inode IDs.',
                    metadata_limit='Aliases adopt canonical inode and mtime; no chmod/utime in dedup. Original per-path metadata is retained here.',
                    consumer_limit='Only readable proc cwd/exe/cmdline/fd observed; unreadable fields remain explicit.',
                    live_exclusion='Exact three historical cold paths only, all initially nlink1; no active ROOT/SEED/cache/Git/fixture path is an operation target.',
                    no_payload_copy=True)
        dump('PLAN.json', plan)
        result.update(exit_code=0, plan_sha256=digest(OUT / 'PLAN.json'), sha256=h.hexdigest(),
                      all_three_physical_bytes_match_git_blob=True, archive_replacements=0)
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        dump('RESULT.json', result)
        print(json.dumps(result))


if __name__ == '__main__': main()
