"""Read-only exact additional private-index proof; retain no large Git stdout copies."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess

OUT = Path('/workspace/additional-closed-index-proof-20261023')
ROOT_GIT = '/workspace/geometry-axiom/.git'
OWN_GIT = '/workspace/kernel-no-wood-prep/metadata.git'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
CASES = [('/tmp/nowood-bfbab207-evidence-publication/private.index', 'receipt.json', OWN_GIT),
         ('/workspace/geo337-prbody-final-L-first-gates-publication/index', 'RESULT.json', ROOT_GIT)] + [
    (f'/tmp/geo337-continue-20261024/{name}/index', 'RESULT.json', ROOT_GIT)
    for name in ['publish-body-a6072dde','publish-body-5b0','publish-body-5049','body-source-checkpoint',
                 'initial-prbody-publication','initial-progress-publication']]


def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,d): (OUT/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')


def main():
    OUT.mkdir(); result=dict(exit_code=1,candidates=[],commands=[],deleted=0,
      stdout_policy='Git full stdout consumed and normalized/hash counted, not duplicated on disk; exact published commit remains the rebuild source.')
    try:
        for raw_path,receipt_name,gitdir in CASES:
            p=Path(raw_path);receipt=p.parent/receipt_name;d=json.loads(receipt.read_text());rows=json.loads((p.parent/'subcommands.json').read_text())
            assert (d.get('published') is True or d.get('passed') is True) and d['push_exit']==0
            if receipt_name=='receipt.json':
                assert d['ls_remote_exit']==0 and d['exit_code']==0;commit=d['evidence_head']
            else:commit=d['commit']
            assert all(row['ended_epoch'] for row in rows)
            assert any('push' in row['command'] and row['actual_process_returncode']==0 for row in rows)
            assert any('ls-remote' in row['command'] and row['actual_process_returncode']==0 for row in rows)
            assert p.resolve(strict=True)==p and not any(q.is_symlink() for q in [p,*p.parents])
            assert '.git' not in p.parts and 'objects' not in p.parts
            s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
            raw=p.read_bytes();assert raw[:4]==b'DIRC' and hashlib.sha1(raw[:-20]).digest()==raw[-20:]
            item=dict(path=str(p),dev=s.st_dev,inode=s.st_ino,mode=s.st_mode,size=s.st_size,mtime_ns=s.st_mtime_ns,
                      uid=s.st_uid,gid=s.st_gid,nlink=1,allocated_bytes=s.st_blocks*512,sha256=hashlib.sha256(raw).hexdigest(),
                      receipt=dict(path=str(receipt),sha256=digest(receipt)),subcommands=dict(path=str(p.parent/'subcommands.json'),sha256=digest(p.parent/'subcommands.json')),
                      public_commit=commit,gitdir_read_only=gitdir,terminal_last_ended=rows[-1]['ended_epoch'])
            del raw
            env=dict(os.environ,GIT_INDEX_FILE=str(p),GIT_OPTIONAL_LOCKS='0');prefix=['git','--git-dir',gitdir,'-c','gc.auto=0','-c','maintenance.auto=false']
            observed={}
            for args,role in [(['ls-files','--stage','-z'],'index'),(['ls-tree','-r','-z','--full-tree',commit],'commit')]:
                argv=prefix+args;n=len(result['commands']);dump(f'{n:03d}.request.json',dict(argv=argv,environment=dict(GIT_INDEX_FILE=str(p),GIT_OPTIONAL_LOCKS='0')))
                proc=subprocess.run(argv,env=env,capture_output=True)
                (OUT/f'{n:03d}.stderr.bin').write_bytes(proc.stderr)
                row=dict(argv=argv,exit_code=proc.returncode,stdout_bytes=len(proc.stdout),stdout_sha256=hashlib.sha256(proc.stdout).hexdigest(),stderr_bytes=len(proc.stderr))
                result['commands'].append(row);dump('COMMANDS.json',result['commands']);assert proc.returncode==0 and proc.stdout.endswith(b'\0')
                normalized=[]
                for entry in proc.stdout[:-1].split(b'\0'):
                    fields,path=entry.split(b'\t',1);a,b,c=fields.split(b' ')
                    if role=='index':assert c==b'0';blob=b
                    else:assert b in [b'blob',b'commit'];blob=c
                    normalized.append(a+b' '+blob+b'\t'+path+b'\0')
                observed[role]=dict(entries=len(normalized),sha256=hashlib.sha256(b''.join(sorted(normalized))).hexdigest())
            assert observed['index']==observed['commit']
            assert digest(p)==item['sha256'] and p.stat().st_ino==item['inode']
            item['all_stage0_entries_exact_public_commit']=observed['index']
            item['reconstruction_not_executed']=['env','GIT_INDEX_FILE=<fresh-standalone-cache>',*prefix,'read-tree',commit]
            result['candidates'].append(item);dump('PARTIAL.json',result)
        assert digest(GUARD)==GUARD_PIN
        namespace={'__name__':'_only_consumer_guard','__file__':str(GUARD)};exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),namespace);namespace['OUT']=OUT
        namespace['consumer_check']([x['path'] for x in result['candidates']])
        result.update(exit_code=0,allocated_by_fs={root:sum(x['allocated_bytes'] for x in result['candidates'] if x['path'].startswith(root+'/')) for root in ['/workspace','/tmp']},
                      limitations=['No actual deletion or index reconstruction. No original index-byte/stat/TREE-cache reproduction claim, only exact stage entries from public commit.',
                                   'Consumer observation covers only readable proc fields; unknown fields remain explicit.',
                                   'Own original publication was a transient Python producer; no fabricated persistent producer script. Original 27 captured Git commands and exact commit-stage equivalence bind its standalone index.'])
    except Exception as exc:result['error']=repr(exc);raise
    finally:dump('PLAN.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['commands','candidates']},ensure_ascii=False))


if __name__=='__main__':main()
