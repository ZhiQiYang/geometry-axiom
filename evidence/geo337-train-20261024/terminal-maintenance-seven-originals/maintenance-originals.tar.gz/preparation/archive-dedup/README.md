僅三份相同收據的儲存去重準備

這不是刪除收據。三個原 pathname 與完整 bytes 必須持續保留。唯一候選是
`g261seal/{p-source,a-source,l-source}/evidence/geo261-final-f2c8837a/raw/card-reference.raw.tar.gz`。
三份均為 54,623,441 bytes；Git blob `e8994b13776c51595dcba7173bb1f3a19acbec37`，
SHA256 `a5fb2c0e2f4969b64acf3030510fc6bf5bd85195b462cfeb45ae063e8fd78204`。
預估 allocated 儲存減量 109,248,512 bytes；尚未執行原件，沒有實測回收值。

`exact-three-proof-r2/PLAN.json` 保存每一原 pathname 的 dev/inode/mode/mtime/atime/uid/gid/nlink、
原 Git HEAD、原終態 receipt 的 hash 與原 gate 結果。原 census 為 false，不改標為綠。
七條 Git 唯讀命令與每個小 stdout/stderr 已保；`cat-file blob` 的全部輸出直接與三份實體原件逐位元組比對，
不再複製成第四份壓縮包。原 Git object 與三個 pathname 都保留。

初版 prep 對 `finished_utc` schema 的查詢錯誤已原封保在
`prepare_exact_three.initial_schema_error.py.txt` 與 `exact-three-proof/RESULT.json`；
r2 只修正準備工具欄位，未改任何產品、收據或門檻。

Root 已明確將三個舊 checkout 禁止任何 mutator/native/browser/checkout/寫入重用。
此禁用持續到逐一 de-link 完成；原 kernel/Git/fixtures/active ROOT/SEED/cache 不在操作路徑。
proc consumer 守門只涵蓋可讀 cwd/exe/cmdline/fd；不可讀的 OS 欄位會原樣列出，不能聲稱全系統無 consumer。
初始三檔必須各自 nlink=1、不同 inode、同 FS、無 symlink 祖先／xattr，且 bytes/mode/uid/gid 同。

原子替換採固定 canonical 的 temporary hardlink，再 `os.replace` 目的 path。
每一步以 journal 記錄全部預期 alias，並重新檢查完整內容與 inode/nlink。
任何不符即拒絕；失敗不自動刪 temp 或回滾，以免丟失診斷原件。
Journal 每行 flush/fsync 檔案，但不主張突然斷電時首次 journal 目錄 entry 必定持久化。
所有原 pathname 始終存在；檔案 inode/nlink 與目的檔 mtime 會因共用 canonical inode 而改變。
不做 chmod/utime，不宣稱原 inode 可重建。目錄 entry 替換本身也會自然變更父目錄 timestamps。

`synthetic-roundtrip/` 是唯一已執行的替換證明，僅三個新 16KiB 檔。
原 alias 守門真 0/1/0：加入一個非預期 alias 時因 nlink=2≠1 拒絕，移除該 synthetic alias 後通過。
其後用與實際工具相同 primitive 將三檔連結，再只對 synthetic 複本解除連結。
三個 path 與 bytes 一直保留；de-link 可恢復獨立 bytes/mode/mtime，但不能恢復原 inode 編號。
原結果記錄的 synthetic allocated 為寫最終 RESULT 前的 69,632 bytes；
RESULT 本身再佔 4,096 bytes，完整目錄事後唯讀總和為 73,728 bytes，仍小於 1MiB。
原結果保留，不因計量時點重跑或覆寫；未執行任何產品／Chrome／C 編譯。

實際工具需獨立 peer 接受後由 root 執行：

```
env -u PYTHONOPTIMIZE PYTHONDONTWRITEBYTECODE=1 python3 -B /workspace/evidence-archive-dedup-readonly-20261023/deduplicate_exact_three_receipts.py
```

固定結果目錄 `/workspace/receipt-archive-three-dedup-execution-20261023` 必須原先不存在。
本目錄的 synthetic 結果不等於原件 actual；以 root 日後實際輸出與 peer 為準。
