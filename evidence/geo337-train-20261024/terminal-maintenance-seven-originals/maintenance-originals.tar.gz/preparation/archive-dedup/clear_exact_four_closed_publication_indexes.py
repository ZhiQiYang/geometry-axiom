"""Prepared only: root may retire four exact rebuildable private index caches."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys

PLAN = Path('/workspace/closed-publication-index-inventory-20261023/PLAN.json')
PIN = 'f6ae967c7b189709949946fc8837ebdc60decdb92c5b4daa04b11e8c631f7fd2'
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
OUT = Path('/workspace/exact-four-closed-publication-index-execution-20261023')
NAMES = ['b6e1e454', '2d157069', '50a4533b', 'b3']
EXPECTED = [f'/workspace/geo337-prbody-{name}-publication/index' for name in NAMES]


def main():
    assert sys.flags.optimize == 0 and 'PYTHONOPTIMIZE' not in os.environ
    assert hashlib.sha256(GUARD.read_bytes()).hexdigest() == GUARD_PIN
    guard = {'__name__': '_reuse_original_guards_only', '__file__': str(GUARD)}
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard)
    guard['OUT'] = OUT
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=1,
                  removed=[], free_before=guard['free'](),
                  scope='Four exact standalone closed GIT_INDEX_FILE caches; no real .git/index, objects, receipt, or source.',
                  consumer_limit='Only readable proc fields observed; inaccessible fields are retained explicitly.')
    try:
        assert guard['digest'](PLAN) == PIN
        plan = json.loads(PLAN.read_text()); items = plan['candidates']
        assert plan['exit_code'] == 0 and plan['executed_deletions'] == 0
        assert [x['path'] for x in items] == EXPECTED and len(items) == 4
        assert plan['allocated_candidate_bytes'] == 20021248
        producer = plan['producer']
        assert guard['digest'](Path(producer['path'])) == producer['sha256']

        def terminal_guards():
            for item in items:
                for name in ['request', 'terminal_receipt', 'subcommands']:
                    original = item[name]
                    assert guard['digest'](Path(original['path'])) == original['sha256']
                receipt = json.loads(Path(item['terminal_receipt']['path']).read_text())
                assert receipt['published'] is True and receipt['push_exit'] == 0
                assert receipt['commit'] == item['terminal_receipt']['commit']
                request = json.loads(Path(item['request']['path']).read_text())
                assert str(Path(request['out']) / 'index') == item['path']

        def index_guard(item):
            p = Path(item['path'])
            assert p.name == 'index' and '.git' not in p.parts and 'objects' not in p.parts
            assert p.resolve(strict=True) == p
            guard['identity'](p, item, is_file=True)
            s = p.lstat()
            assert s.st_uid == item['uid'] and s.st_gid == item['gid']
            assert not os.listxattr(p, follow_symlinks=False)

        terminal_guards()
        for item in items: index_guard(item)
        guard['consumer_check'](EXPECTED)
        for item in items:
            terminal_guards()
            index_guard(item)
            Path(item['path']).unlink()
            result['removed'].append(item['path'])
            guard['dump']('PROGRESS.json', result)
        terminal_guards()
        assert all(not Path(p).exists() and Path(p).parent.is_dir() for p in EXPECTED)
        result.update(exit_code=0, removed_allocated_bytes=20021248,
                      reconstruction='Retained public commits and per-index read-tree recipes remain in pinned plan; no unique stage entries are removed.')
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_after'] = guard['free']()
        guard['dump']('RESULT.json', result)
        print(json.dumps(result))


if __name__ == '__main__': main()
