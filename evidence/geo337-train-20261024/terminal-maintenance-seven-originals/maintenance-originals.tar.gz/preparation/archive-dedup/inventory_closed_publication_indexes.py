"""Read-only inventory; never deletes or writes any Git index or source."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess

OUT = Path('/workspace/closed-publication-index-inventory-20261023')
NAMES = ['b6e1e454', '2d157069', '50a4533b', 'b3']
PRODUCER = Path('/tmp/geo337-continue-20261024/publish_metadata.py')
GUARD = Path('/workspace/clear_terminal_chrome_caches.py')
GUARD_PIN = 'c51b4da96fc8ce88043484d3072a870fd725a18b00e6288e12144c399069e847'
REPO = Path('/workspace/geometry-axiom')


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(name, value): (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=1,
                  operation='READ_ONLY_CLOSED_TEMP_GIT_INDEX_INVENTORY_NO_DELETION', candidates=[], commands=[])
    try:
        producer = PRODUCER.read_bytes()
        assert b"GIT_INDEX_FILE=str(out / 'index')" in producer
        assert b"git('read-tree', parent)" in producer and b"git('write-tree')" in producer
        result['producer'] = dict(path=str(PRODUCER), sha256=digest(PRODUCER),
                                  provenance='Root identified this original metadata-only publisher; four original requests/results bind out/index.')
        for name in NAMES:
            directory = Path('/workspace') / f'geo337-prbody-{name}-publication'
            path = directory / 'index'
            request_path = Path('/workspace') / f'geo337-prbody-{name}-request.json'
            request = json.loads(request_path.read_text())
            receipt = json.loads((directory / 'RESULT.json').read_text())
            rows = json.loads((directory / 'subcommands.json').read_text())
            assert request['out'] == str(directory) and request['parent'] == receipt['parent']
            assert request['source_sha'] == receipt['source_sha']
            assert receipt['published'] is True and receipt['push_exit'] == 0
            assert receipt['acceptance_executed'] is False
            assert rows[-1]['command'][:2] == ['git', 'ls-remote'] and rows[-1]['actual_process_returncode'] == 0
            assert rows[-1]['ended_epoch']
            assert any(r['command'] == ['git', 'read-tree', receipt['parent']] and r['actual_process_returncode'] == 0 for r in rows)
            assert any(r['command'][:2] == ['git', 'write-tree'] and r['actual_process_returncode'] == 0 for r in rows)
            assert path.resolve(strict=True) == path and not any(p.is_symlink() for p in [path, *path.parents])
            s = path.lstat()
            assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_size == 5001385
            assert '.git' not in path.parts and 'objects' not in path.parts
            raw = path.read_bytes()
            assert raw[:4] == b'DIRC' and hashlib.sha1(raw[:-20]).digest() == raw[-20:]
            candidate = dict(path=str(path), dev=s.st_dev, inode=s.st_ino, mode=s.st_mode,
                             uid=s.st_uid, gid=s.st_gid, size=s.st_size, allocated_bytes=s.st_blocks * 512,
                             mtime_ns=s.st_mtime_ns, nlink=s.st_nlink, sha256=hashlib.sha256(raw).hexdigest(),
                             request=dict(path=str(request_path), sha256=digest(request_path)),
                             terminal_receipt=dict(path=str(directory / 'RESULT.json'), sha256=digest(directory / 'RESULT.json'),
                                                   commit=receipt['commit'], push_exit=0, ended_epoch=rows[-1]['ended_epoch']),
                             subcommands=dict(path=str(directory / 'subcommands.json'), sha256=digest(directory / 'subcommands.json')))
            del raw
            env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_INDEX_FILE=str(path))
            prefix = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO)]
            actual = {}
            for argv, role in [(prefix + ['ls-files', '--stage', '-z'], 'temporary_index_entries'),
                               (prefix + ['ls-tree', '-r', '-z', '--full-tree', receipt['commit']], 'published_commit_tree')]:
                n = len(result['commands']); dump(f'{n:03d}.request.json', dict(argv=argv, env=dict(GIT_INDEX_FILE=str(path), GIT_OPTIONAL_LOCKS='0'),
                    stdout_policy='consume exact complete records and retain SHA/count only; no large raw duplication; published Git tree is reconstruction source'))
                proc = subprocess.run(argv, env=env, capture_output=True)
                # Large stdout is intentionally not saved as another cache/archive.
                (OUT / f'{n:03d}.stderr.bin').write_bytes(proc.stderr)
                row = dict(argv=argv, role=role, exit_code=proc.returncode,
                           stdout_bytes=len(proc.stdout), stdout_sha256=hashlib.sha256(proc.stdout).hexdigest(),
                           stderr_bytes=len(proc.stderr), stderr_sha256=hashlib.sha256(proc.stderr).hexdigest())
                result['commands'].append(row); dump('COMMANDS.json', result['commands'])
                assert proc.returncode == 0 and proc.stdout.endswith(b'\0')
                entries = []
                for entry in proc.stdout[:-1].split(b'\0'):
                    info, relative = entry.split(b'\t', 1)
                    mode, blob_or_kind, stage_or_blob = info.split(b' ')
                    if role == 'temporary_index_entries':
                        assert stage_or_blob == b'0', 'unmerged index may hold unique data'
                        blob = blob_or_kind
                    else:
                        assert blob_or_kind in [b'blob', b'commit']
                        blob = stage_or_blob
                    entries.append(mode + b' ' + blob + b'\t' + relative + b'\0')
                normalized = b''.join(sorted(entries))
                actual[role] = dict(entry_count=len(entries), normalized_sha256=hashlib.sha256(normalized).hexdigest())
                del entries, normalized, proc
            assert actual['temporary_index_entries'] == actual['published_commit_tree']
            assert digest(path) == candidate['sha256'] and path.stat().st_ino == candidate['inode']
            candidate['all_stage0_entries_exact_public_commit'] = actual['temporary_index_entries']
            candidate['rebuild_recipe_not_executed'] = dict(environment=dict(GIT_INDEX_FILE='<fresh-private-index-path>'),
                                                           argv=['git', '-C', str(REPO), 'read-tree', receipt['commit']],
                                                           scope='Semantic temporary index reconstructed from retained public commit; not a promise of identical stat/TREE-extension cache bytes.')
            result['candidates'].append(candidate)
        assert digest(GUARD) == GUARD_PIN
        namespace = {'__name__': '_only_consumer_guard', '__file__': str(GUARD)}
        exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), namespace)
        namespace['OUT'] = OUT
        namespace['consumer_check']([item['path'] for item in result['candidates']])
        result.update(exit_code=0, allocated_candidate_bytes=sum(x['allocated_bytes'] for x in result['candidates']),
                      executed_deletions=0, consumer_limit='Only readable proc fields observed; original unknown list retained.',
                      scope='Only four exact standalone closed publication index files; all RESULT/requests/streams/Gitobjects/real .git/index preserved.')
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        dump('PLAN.json', result)
        print(json.dumps({k:v for k,v in result.items() if k not in ['candidates','commands']}, ensure_ascii=False))


if __name__ == '__main__': main()
