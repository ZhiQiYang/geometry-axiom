第二個 root 明確授權的 receipt exact3 群

只限同三個已禁寫的舊 checkout：`/workspace/geo261-cold/g261seal/{p-source,a-source,l-source}`。
相對路徑只限 `tests/release-evidence/20261008/geometry-main-evidence-459478e9.tar.gz`。
不擴到一般 fixtures、work、mutant、withdrawn 或其他 paths。

三份逐位元組比對真 Git blob `72ed8f50cbcaa08d1d218c7ddd7bc47c3839eff8` 完全相同，
每份 39,046,314 bytes，SHA256 `3bd6f83ec9bcdc9cfc70e88091ba46db215e6ad374e261248e227d1eda9a9203`。
每份 allocated 39,047,168 bytes，預估去重減量 78,094,336 bytes；尚無 actual 回收主張。

`release-exact-three-proof/PLAN.json` 保存各原 path 的完整 metadata、HEAD 與原終態 receipt hash。
只讀 proof exit0，原 census false 照實保留，無原件替換。
`RELEASE_EXECUTOR.patch` 只把原第一組已審 executor 的七項 literal scope 換成此組的路徑／size／hash／out。
`archive_link_core.py` 完全不變；沿原 synthetic roundtrip，不重跑產品／Chrome／C。

執行守門、journal、無 chmod/utime、未知 proc 欄位、無斷電持久性主張，均沿原 README。
全部 receipt path/bytes 保留；只改目的 entry 對應 inode，目的 mtime 採 canonical，父目錄 timestamp 自然變化。
原 inode 不可還原，原 mode/mtime/uid/gid/inode 歷史保存在 plan；de-link 可以恢復獨立 bytes/mode/mtime。
三個 checkout 在兩群去重後均持續禁止寫入／checkout／mutator／native／browser，直到全部 alias de-link 完成。

獨立 peer 接受後，只由 root 執行：

```
env -u PYTHONOPTIMIZE PYTHONDONTWRITEBYTECODE=1 python3 -B /workspace/evidence-archive-dedup-readonly-20261023/deduplicate_release_exact_three_receipts.py
```

固定新 OUT 是 `/workspace/release-receipt-archive-three-dedup-execution-20261023`。
此準備狀態不等於實際去重完成；以 root 後續 actual 與 peer 原件為準。
