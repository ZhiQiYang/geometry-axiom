"""Single bounded maintenance package. Never reads archived payloads, ELFs, or relocated raw bodies."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import stat
import tarfile

BASE=Path('/workspace/evidence-archive-dedup-readonly-20261023')
OUT=Path('/workspace/storage-maintenance-originals-package-20261023')
ACTIONS=['receipt-archive-three-dedup','release-receipt-archive-three-dedup',
         'architecture-receipt-archive-three-dedup','exact-four-closed-publication-index',
         'exact-eight-additional-index','L-ledger-exact-175-elf-retirement','terminal-raw-one-relocation']
PEER_NAMES=['EXACT_THREE_RECEIPT_HARDLINK_EXECUTOR_PEER.json','EXACT_THREE_RECEIPT_HARDLINK_ACTUAL_PEER.json',
 'RELEASE_RECEIPT_THREE_LITERAL_EXECUTOR_PEER.json','ARCHITECTURE_ARCHIVE_EXACT_THREE_EXECUTOR_PEER.json',
 'ARCHITECTURE_ARCHIVE_EXACT_THREE_ACTUAL_PEER.json','FOUR_TERMINAL_PUBLISHER_INDEX_EXECUTOR_PEER.json',
 'EIGHT_CLOSED_INDEX_EXECUTOR_PEER.json','EIGHT_CLOSED_INDEX_ACTUAL_PEER.json',
 'EXACT_TWO_TERMINAL_RAW_RELOCATION_EXECUTOR_PEER.json','EXACT_FIRST_RAW_RELOCATION_VARIANT_PEER.json',
 'EXACT_FIRST_RAW_RELOCATION_INITIAL_SCOPE_NAME_ASSUMPTION.json','EXACT_FIRST_RAW_RELOCATION_ACTUAL_PEER.json',
 'FINAL_L_175_ELF_RETIREMENT_EXECUTOR_PEER.json','FINAL_L_175_ELF_RETIREMENT_ACTUAL_PEER.json']


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def main():
    OUT.mkdir()
    entries={};actual=[]
    def add(path,member):
        path=Path(path);assert path.resolve(strict=True)==path and not path.is_symlink()
        s=path.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=4*1024*1024,(str(path),'unexpected large member')
        assert path.name not in ['index','private.index'] and not path.name.endswith(('.tar.gz','.zip','.exe','.pyc'))
        assert member not in entries and not member.startswith('/') and '..' not in Path(member).parts
        entries[member]=dict(source=str(path),bytes=s.st_size,sha256=digest(path),mode=s.st_mode,mtime_ns=s.st_mtime_ns,
                             dev=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid)
    def tree(root,prefix):
        root=Path(root);assert root.is_dir() and not root.is_symlink()
        for p in sorted(root.rglob('*')):
            assert not p.is_symlink(),str(p)
            if p.is_dir():continue
            if '__pycache__' in p.parts or p.suffix=='.pyc':continue
            add(p,prefix+'/'+str(p.relative_to(root)))
    # Only these own small preparation roots, never all /workspace or adversarial.
    tree(BASE,'preparation/archive-dedup')
    for name in ['closed-publication-index-inventory-20261023','additional-closed-index-proof-20261023',
                 'raw-terminal-relocation-preparation-20261023','L-ledger-175-elf-retirement-preparation-20261023']:
        tree(Path('/workspace')/name,'preparation/'+name)
    for action in ACTIONS:
        root=Path('/workspace')/f'{action}-execution-20261023'
        launch=Path('/workspace')/f'{action}-launch-20261023'
        result=json.loads((root/'RESULT.json').read_text());outer=json.loads((launch/'receipt.json').read_text())
        assert result['exit_code']==0 and outer['actual_process_returncode']==0 and outer['ended_epoch'] and not outer['timeout_expired']
        actual.append(dict(action=action,result_source=str(root/'RESULT.json'),result_sha256=digest(root/'RESULT.json'),
                           outer_sha256=digest(launch/'receipt.json'),free_before=result['free_before'],free_after=result['free_after'],
                           actual_exit=0,outer_exit=0))
        tree(root,'actual/'+action);tree(launch,'launch/'+action)
    for name in PEER_NAMES:add(Path('/tmp/train337-adversarial')/name,'peers/dedicated/'+name)
    for name in ['train337-release-three-actual-peer','train337-four-index-actual-peer',
                 'closed-publisher-index-scope-peer','additional8-closed-index-scope-peer']:
        tree(Path('/tmp')/name,'peers/'+name)
    for path,member in [('/workspace/clear_terminal_chrome_caches.py','tools/original-consumer-and-identity-guard.py'),
        ('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py','tools/original-c387-capture.py'),
        ('/tmp/geo337-continue-20261024/publish_metadata.py','tools/original-isolated-index-publisher.py'),
        ('/workspace/final-L-old-raw-move-guard-disjoint.json','reference-pins/raw-move-active-guard-disjoint.json')]:add(path,member)
    # Small original publication command streams bind rebuildable caches; their actual index caches are not included.
    pubs=[Path('/workspace')/f'geo337-prbody-{n}-publication' for n in ['b6e1e454','2d157069','50a4533b','b3','final-L-first-gates']]
    pubs += [Path('/tmp/nowood-bfbab207-evidence-publication')]
    pubs += [Path('/tmp/geo337-continue-20261024')/n for n in ['publish-body-a6072dde','publish-body-5b0','publish-body-5049','body-source-checkpoint','initial-prbody-publication','initial-progress-publication']]
    for number,root in enumerate(pubs):
        prefix=f'references/closed-publisher-{number:02d}'
        for name in ['RESULT.json','receipt.json','subcommands.json']:
            p=root/name
            if p.exists():add(p,prefix+'/'+name)
        tree(root/'subcommands',prefix+'/subcommands')
    for rel in ['ledger/receipt.json','census/receipt.json','architecture-refresh/RESULT.json']:
        add(Path('/workspace/geo261-cold/g261seal')/rel,'references/historical-seal/'+rel)
    L=Path('/workspace/train337-ledger-L-7af8c5d8')
    for name in ['receipt.json','ARTIFACT_PAIR_RELOCATION.json','CORE_RAW_MAPPING.json','BRIDGE_RAW_INVENTORY.json',
                 'full-ledger-reaper.jsonl','root-after-identity.json','seed-after-identity.json']:
        add(L/name,'references/final-L/'+name)
    # Fingerprint/compile input manifests are retained; the 175 executable bodies never enter this tar.
    elf_plan=json.loads(Path('/workspace/L-ledger-175-elf-retirement-preparation-20261023/PLAN.json').read_text())
    for number,item in enumerate(elf_plan['sidecars']):add(item['path'],f'references/elf-sidecars/{number:03d}.fingerprint.json')
    assert sum(x['bytes'] for x in entries.values())<=32*1024*1024,'unexpected package growth'
    index=dict(schema='preserving-storage-maintenance-originals/1',createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       executionContextSHA='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db',maintenanceOnly=True,productOrTestSourcesChanged=False,
       actions=actual,files=[dict(member=k,**v) for k,v in sorted(entries.items())],
       allocatedReductionFromDedupAndRebuildableCaches=439607296,
       rawRelocationAllocatedFileBytes=82776064,
       logicalReceiptPreservation='Three receipt groups retain all nine original paths/bytes. The original P2 raw directory and all195 files remain readable after workspace relocation.',
       checkoutWriteBan=['/workspace/geo261-cold/g261seal/'+x for x in ['p-source','a-source','l-source']],
       lease='All three cold checkouts barred from writes/reuse until all three archive groups are de-linked. Relocated old raw namespace is historical/read-only; do not reuse for recording.',
       limits=['Allocated reductions are scope totals, not a claim that concurrent statvfs deltas equal them; each original free-before/after is retained.',
        'Raw relocation shifts storage between filesystems and does not delete receipt bytes or count as global freed bytes.',
        'Original inode IDs cannot be restored; archive alias destinations inherit canonical inode/mtime; historical per-path metadata stays in original plans.',
        'Cross-FS raw relocation has a documented brief pathname switch gap and changed device/inode/symlink lstat; followed bytes/mode/mtime/uidgid preserved.',
        'Only accessible process fields were observable; original unknown lists remain in raw.',
        'Some read-only Git full stage/blob stdout was deliberately hash/count compared against retained original files/public Git objects, never duplicated as large output. Original request/command records state this.',
        'No archive payload54/39/5MB, no relocated82MBraw body, no ELF181MB body, no live ROOT/SEED/cache tree is packaged.',
        'Full final-L original ledger/source package is already public at evidence head ffa6e438; its ten-MB ledger body is not duplicated here. Retained local original path and hash remain in ELF plan.',
        'Synthetic allocated69,632 was measured before RESULT; complete synthetic directory73,728 bytes. No product runtime test was executed by synthetic probe.'])
    dump('INDEX.json',index)
    archive=OUT/'maintenance-originals.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
        for member,item in sorted(entries.items()):
            p=Path(item['source']);raw=p.read_bytes();assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
            s=p.lstat();assert (s.st_dev,s.st_ino,s.st_mtime_ns)==(item['dev'],item['inode'],item['mtime_ns'])
            info=tarfile.TarInfo(member);info.size=len(raw);info.mode=stat.S_IMODE(item['mode']);info.mtime=item['mtime_ns']/1e9;info.uid=item['uid'];info.gid=item['gid']
            tar.addfile(info,io.BytesIO(raw))
    with tarfile.open(archive,'r:gz') as tar:
        assert set(tar.getnames())==set(entries)
        for member,item in entries.items():assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==item['sha256']
    for item in entries.values():assert digest(item['source'])==item['sha256']
    package=dict(exit_code=0,member_count=len(entries),payload_bytes=sum(x['bytes'] for x in entries.values()),
                 archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),
                 index_sha256=digest(OUT/'INDEX.json'),source_before_after_and_archive_roundtrip=True)
    dump('PACKAGE.json',package);print(json.dumps(package))


if __name__=='__main__':main()
