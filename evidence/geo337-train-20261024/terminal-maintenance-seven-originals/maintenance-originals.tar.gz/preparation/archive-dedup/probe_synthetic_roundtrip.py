"""Only new tiny synthetic files; never opens a real receipt or product input."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import sys
from archive_link_core import digest, link_exact, metadata, state

BASE = Path(__file__).resolve().parent
OUT = BASE / 'synthetic-roundtrip'
PAYLOAD = bytes(range(256)) * 64


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    OUT.mkdir()
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  exit_code=1, synthetic_only=True, payload_bytes=len(PAYLOAD), phases=[])
    try:
        assert sys.flags.optimize == 0
        members = []
        for index in range(3):
            path = OUT / f'synthetic-receipt-{index}.bin'
            with path.open('xb') as stream: stream.write(PAYLOAD)
            os.chmod(path, 0o600)
            stamp = 1700000000000000000 + index * 1000000000
            os.utime(path, ns=(stamp, stamp))
            members.append(dict(path=str(path), **metadata(path), sha256=digest(path)))
        dump('ORIGINAL_METADATA.json', members)
        state(members, set())
        result['phases'].append(dict(name='independent_baseline', exit_code=0))
        rogue = OUT / 'synthetic-extra-alias.bin'
        os.link(members[0]['path'], rogue)
        caught = None
        try: state(members, set())
        except AssertionError as exc: caught = repr(exc)
        assert caught and 'nlink' in caught, 'normal alias-count guard must refuse extra alias'
        result['phases'].append(dict(name='withdrawn_alias_reservation', exit_code=1, normal_assertion=caught))
        rogue.unlink()  # Only the extra synthetic alias, never an original receipt path.
        state(members, set())
        result['phases'].append(dict(name='restored_alias_reservation', exit_code=0))
        link_exact(members, OUT / 'JOURNAL.jsonl')
        linked = [dict(path=x['path'], **metadata(x['path']), sha256=digest(x['path'])) for x in members]
        dump('LINKED_METADATA.json', linked)
        assert len({x['inode'] for x in linked}) == 1 and all(x['nlink'] == 3 for x in linked)
        # De-link demonstration is confined to these tiny synthetic copies.
        for item in members[1:]:
            path = Path(item['path']); temp = path.with_name(path.name + '.synthetic-delink')
            assert not temp.exists()
            with temp.open('xb') as stream:
                stream.write(path.read_bytes()); stream.flush(); os.fsync(stream.fileno())
            os.chmod(temp, item['mode'] & 0o7777)
            os.utime(temp, ns=(item['atime_ns'], item['mtime_ns']))
            os.replace(temp, path)
        final = [dict(path=x['path'], **metadata(x['path']), sha256=digest(x['path'])) for x in members]
        assert len({x['inode'] for x in final}) == 3 and all(x['nlink'] == 1 for x in final)
        for expected, actual in zip(members, final):
            for key in ['sha256', 'mode', 'mtime_ns', 'uid', 'gid', 'size']:
                assert actual[key] == expected[key], (key, actual[key], expected[key])
        dump('DELINKED_METADATA.json', final)
        result.update(exit_code=0, all_three_paths_and_bytes_preserved=True,
                      independent_bytes_mode_mtime_roundtrip=True,
                      original_inode_restoration_claimed=False,
                      total_synthetic_allocated_bytes=sum(p.stat().st_blocks * 512 for p in OUT.iterdir() if p.is_file()))
        assert result['total_synthetic_allocated_bytes'] < 1024 * 1024
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        dump('RESULT.json', result)
        print(json.dumps(result))


if __name__ == '__main__': main()
