from pathlib import Path
import json,hashlib,subprocess,datetime
O=Path(__file__).parent;P=Path('/tmp/geo337-F9-native-terminal-publication-20261025');M=Path('/tmp/geo337-F9-native-terminal-publication-preparation-v3-20261025');F='4f8a794f4167c3562eb182045102e86e9e37cca9';E='59064fe0478f7ebe9126e6fe042c2054f336a42f';B='cd19c63a9fe625c039a421c52d3c6d335e2009c4';C=[];own=[]
def J(p):return json.loads(Path(p).read_bytes())
def h(b):return hashlib.sha256(b).hexdigest()
def ck(n,b):C.append({'name':n,'ok':bool(b)})
def git(args):
 a=['git','-c','gc.auto=0','-c','maintenance.auto=false']+args;q=subprocess.run(a,cwd='/workspace/geometry-axiom',stdout=subprocess.PIPE,stderr=subprocess.PIPE);own.append({'argv':a,'cwd':'/workspace/geometry-axiom','exit_code':q.returncode,'stdout_bytes':len(q.stdout),'stdout_sha256':h(q.stdout),'stderr_utf8':q.stderr.decode(errors='replace'),'stderr_sha256':h(q.stderr),'stdout_storage':'Git immutable blob原處保留；此peer不另複製完整payload，只記實讀hash/size。'});ck('git'+str(len(own))+':exit0',q.returncode==0);return q.stdout
r=J(P/'RESULT.json');rows=J(M/'FILES.json')['files'];commands=J(P/'subcommands.json');final=J('/tmp/geo337-F9-native-terminal-publication-EXEC_FINAL-20261025.json')
ck('actual_result',r['published'] is True and r['push_exit']==0 and r['evidence_head']==E and r['previous_head']==B and r['product_source']==F and r['product_unchanged'] is True)
ck('actual_manifest',r['manifest_sha256']==h((M/'FILES.json').read_bytes()) and r['files']==104 and r['logical_bytes']==4059715)
ck('true_tool_final',final['exit_code']==0 and 'session_id' not in final)
ck('exact_changed_paths',set(r['changed_paths'])=={x['destination'] for x in rows} and len(r['changed_paths'])==104)
ck('199commands',len(commands)==199)
for i,c in enumerate(commands):
 ck(f'raw{i}:exit0_source_env',c['actual_process_returncode']==0 and not c['timeout_expired'] and c['source_sha']==F and isinstance(c['environment'],dict))
 for n in ['stdout','stderr']:
  raw=(Path(c['directory'])/(n+'.bin')).read_bytes();ck(f'raw{i}:{n}',len(raw)==c[n+'_bytes'] and h(raw)==c[n+'_sha256'])
push=[c for c in commands if 'push' in c['command']];remote=[c for c in commands if 'ls-remote' in c['command']]
ck('one_normal_push',len(push)==1 and push[0]['command'][-3:]==['push','origin','HEAD:refs/heads/codex/train-337-continue-20261024'] and not any(x.startswith('--force') or x.startswith('+') for x in push[0]['command']))
ck('original_remote_before_after',[(Path(c['directory'])/'stdout.bin').read_text().split()[0] for c in remote]==[B,B,E])
ck('single_exact_parent',git(['rev-list','--parents','-n','1',E]).decode().split()==[E,B])
ck('product_closure_F9_exact',git(['diff','--no-renames','--name-only',F,E,'--','.',':(exclude)evidence'])==b'')
changed=git(['diff-tree','--no-commit-id','--no-renames','--name-only','-r',B,E]).decode().splitlines();ck('actual_changed_paths_git',set(changed)=={x['destination'] for x in rows} and len(changed)==104)
for i,x in enumerate(rows):
 raw=git(['show',E+':'+x['destination']]);ck(f'public_blob{i}:fullbytes',len(raw)==x['bytes'] and h(raw)==x['sha256'])
body=Path('/tmp/geo337-F9-native-terminal-PR_BODY-bound-20261025.md').read_bytes();template=(M/'PR_BODY.template.md').read_bytes();ck('boundbody_exactfourE',template.count(b'{{EVIDENCE_HEAD}}')==4 and body==template.replace(b'{{EVIDENCE_HEAD}}',E.encode()) and h(body)=='f728d6cefab5f9c8862704dae1b88a040e415789a67c2c3ead316485289d9632')
DP=Path('/tmp/geo337-F9-native-terminal-prbody-publication-20261025');D='f752e23466c6804334bb0a3d1ab84126d1f0526a';DR=J(DP/'RESULT.json');DC=J(DP/'subcommands.json');DF=J('/tmp/geo337-F9-native-terminal-prbody-EXEC_FINAL-20261025.json')
ck('body_truefinal',DF['exit_code']==0 and 'session_id' not in DF)
ck('body_result',DR['published'] is True and DR['passed'] is True and DR['errors']==[] and DR['newCommit']==D and DR['headAndIndexUnchanged'] is True and DR['bodySha256']==h(body))
ck('body_21_original_commands',len(DC)==21)
for i,c in enumerate(DC):
 ck(f'bodyraw{i}:exit0',c['actual_process_returncode']==0 and not c['timeout_expired'])
 for n in ['stdout','stderr']:
  raw=(Path(c['directory'])/(n+'.bin')).read_bytes();ck(f'bodyraw{i}:{n}',len(raw)==c[n+'_bytes'] and h(raw)==c[n+'_sha256'])
dpush=[c for c in DC if 'push' in c['command']];dremote=[c for c in DC if 'ls-remote' in c['command']]
ck('body_normal_push',len(dpush)==1 and dpush[0]['command'][-3:]==['push','origin',D+':refs/heads/codex/train-337-continue-20261024-prbody'] and not any(x.startswith('--force') or x.startswith('+') for x in dpush[0]['command']))
ck('body_remote_last',len(dremote)>=2 and (Path(dremote[0]['directory'])/'stdout.bin').read_text().split()[0]==DR['expectedParent'] and (Path(dremote[-1]['directory'])/'stdout.bin').read_text().split()[0]==D)
ck('body_single_exact_parent',git(['rev-list','--parents','-n','1',D]).decode().split()==[D,DR['expectedParent']])
ck('body_only_changed_leaf',git(['diff-tree','--no-commit-id','--no-renames','--name-only','-r',DR['expectedParent'],D])==b'PR_BODY.md\n')
ck('body_exact_published_blob',git(['show',D+':PR_BODY.md'])==body)
fail=[x for x in C if not x['ok']]
r={'schema':'geo337-F9-native-terminal-publication-actual-peer/2','source_sha':F,'exit_code':int(bool(fail)),'evidence_head':E,'previous_head':B,'manifest_sha256':h((M/'FILES.json').read_bytes()),'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks_count':len(C),'failed_checks':fail,'public_leaves':104,'public_bytes':4059715,'original_commands_count':199,'normal_push_exit':0,'formal_native_exit':1,'CI35MinuteGateExit':0,'collection_exit':0,'product_unchanged_vs_F9':True,'bound_body_sha256':h(body),'prbody_publication_verified':True,'prbody_head':D,'prbody_website_update_verified':False,'original_peer_issue':'v1只假定兩remote；原publisher實際三次B/B/E，原紅保留，v2精確核三次。','limits':['實核104 Git blob完整bytes、原199指令及原普通push前後remote；不重收native、不掃cache。','新正文D及原21CLI均已核，只有PR_BODY.md改動、逐byte等於v3四處E替換；GitHub網站bot是否套用尚未驗。','本peer內部Git show完整bytes實讀，但僅保存hash/size，payload仍在Git物件及原source，不冒完整stdout另存。','授權身分待核實／未採用仍保留；peer0不改native1或解除gate。'],'bindings':[{'path':str(P/'RESULT.json'),'sha256':h((P/'RESULT.json').read_bytes())},{'path':str(M/'FILES.json'),'sha256':h((M/'FILES.json').read_bytes())}],'checks':C}
(O/'GIT_COMMANDS.v2.json').write_text(json.dumps(own,ensure_ascii=False,indent=2)+'\n');(O/'REVIEW.v2.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(O/'REVIEW.v2.md').write_text(f'# F9 native 證據出版實際核對\n\n{len(C)} 項／{len(fail)} 錯，peer exit={int(bool(fail))}。E `{E}` 單父 `{B}`，104 Git blobs／4,059,715 bytes 與已審manifest逐byte hash相符；原199CLI全0、普通push前後remote正確，非evidence仍F9。\n\nnative1／CI35gate0／collection0不變。正文D=f752e23466c6804334bb0a3d1ab84126d1f0526a真終態、原21CLI、單父／唯一PR_BODY.md及四處E替換全核；尚未確認bot套用網站。原peer計數誤判B/B/E三次remote的紅件保留。未跑產品或修改分支。\n')
print(json.dumps({'exit_code':r['exit_code'],'checks':len(C),'failures':fail,'review_sha256':h((O/'REVIEW.v2.json').read_bytes())},ensure_ascii=False));raise SystemExit(bool(fail))
