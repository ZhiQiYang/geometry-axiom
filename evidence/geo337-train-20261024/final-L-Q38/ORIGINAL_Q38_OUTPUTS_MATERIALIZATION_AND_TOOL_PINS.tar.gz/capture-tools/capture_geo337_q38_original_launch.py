"""Capture the two frozen original Q38 commands without changing their arguments."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import sys

CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
REQUEST = Path('/tmp/train337-L-q38-isolated-source-preparation/MATERIALIZATION_AND_LAUNCH_REQUEST.json')
assert hashlib.sha256(REQUEST.read_bytes()).hexdigest() == '1e5c9076551133f3c5507c920c9f7ecaa74d1dfe27d6f870a5472ea86ff9026b'
request = json.loads(REQUEST.read_bytes())
out = Path('/workspace/train337-L-q38-execution-capture-20261024')
out.mkdir()
spec = importlib.util.spec_from_file_location('capture', CAP)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONOPTIMIZE', None)
rec = c.Recorder(out, env, request['sourceSHA'])
c.dump(out / 'REQUEST.json', {
    'sourceSHA': request['sourceSHA'],
    'requestSHA256': hashlib.sha256(REQUEST.read_bytes()).hexdigest(),
    'sourceLease': request['source'],
    'secondaryLock': '/tmp/g261r3/secondary.lock',
    'freeBefore': {str(p): shutil.disk_usage(p).free for p in ('/workspace', '/tmp')},
    'commands': [request['materializationArgv'], request['launchArgv']],
    'subjectChanges': False,
    'outerTimeout': None,
})
result = {'sourceSHA': request['sourceSHA'], 'commands': rec.rows, 'exitCode': None}
for key in ('materializationArgv', 'launchArgv'):
    row, stdout, stderr = rec.run(request[key], cwd='/workspace', timeout=None,
                                  check=False, source_variant='frozen-original-Q38-' + key)
    result['exitCode'] = row['actual_process_returncode']
    c.dump(out / 'RESULT.json', result)
    print(json.dumps({'phase': key, 'actualProcessExit': row['actual_process_returncode']}, ensure_ascii=False), flush=True)
    if row['actual_process_returncode'] != 0:
        break
raise SystemExit(result['exitCode'])
