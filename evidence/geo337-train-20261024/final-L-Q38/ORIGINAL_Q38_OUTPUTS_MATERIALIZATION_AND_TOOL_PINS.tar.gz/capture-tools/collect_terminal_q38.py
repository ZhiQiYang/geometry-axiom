"""Preserve terminal fixed-L Q38 outputs; never run a subject or read its checkout."""
from pathlib import Path
import hashlib
import json
import stat
import tarfile

L = '7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
OUT = Path('/workspace/train337-L-q38-isolated-results-7af8c5d8')
OUTER = Path('/workspace/train337-L-q38-isolated-launch-7af8c5d8')
CAPTURE = Path('/workspace/train337-L-q38-execution-capture-20261024')
MATERIAL = Path('/workspace/train337-L-q38-source-materialization-7af8c5d8')
PREP = Path('/tmp/train337-L-q38-isolated-source-preparation')
DEST = Path('/workspace/train337-q38-terminal-collection')

def need(value, message):
    if not value:
        raise RuntimeError(message)

def hfile(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

need(not DEST.exists(), 'fresh collection directory required')
receipt = read(OUT / 'receipt.json')
outer = read(OUTER / 'RESULT.json')
capture = read(CAPTURE / 'RESULT.json')
material = read(MATERIAL / 'RESULT.json')
need(receipt['source_sha'] == outer['sourceSHA'] == capture['sourceSHA'] == material['sourceSHA'] == L,
     'all original outputs must bind exact fixed L')
need(receipt.get('ended_utc') and outer.get('endedUTC') and len(capture['commands']) == 2,
     'real terminal original driver and both capture phases required')
need(type(receipt['launcher_exit_code']) is int and receipt['launcher_exit_code'] == outer['exitCode'] == capture['exitCode'],
     'original driver and outer actual terminal exits must agree')
need(material['exitCode'] == 0 and material['materializedFileCount'] == 565 and material['old22Preserved'],
     'successful original source materialization required')
need(len(receipt['gates']) == 1 and receipt['gates'][0]['gate'] == 'q38', 'original Q38-only run required')
gate = receipt['gates'][0]
before = read(OUT / 'q38/before-source.json')
after = read(OUT / 'q38/after-source.json')
need(before == after and before['head'] == L and before['status'] == '', 'original source identity must restore')
DEST.mkdir()
rows = []
excluded = []
streams = []

def add(path, name, permit_elf_exclusion=False):
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode), 'unexpected nonregular evidence: ' + str(path))
    with path.open('rb') as stream:
        elf = stream.read(4) == b'\x7fELF'
    row = {'name': name, 'source_path': str(path), 'bytes': info.st_size, 'sha256': hfile(path)}
    if elf:
        need(permit_elf_exclusion, 'unexpected executable in tools/materialization evidence: ' + str(path))
        row['reason'] = 'ELF payload excluded from archive only; original executable remains at source_path'
        excluded.append(row)
    else:
        rows.append(row)

for label, root in [('original', OUT), ('outer', OUTER), ('execution-capture', CAPTURE), ('materialization', MATERIAL)]:
    for path in sorted(root.rglob('*')):
        if stat.S_ISDIR(path.lstat().st_mode):
            continue
        add(path, label + '/' + path.relative_to(root).as_posix(), permit_elf_exclusion=(root == OUT))
    for row in read(root / 'subcommands.json'):
        directory = Path(row['directory'])
        need(directory.is_relative_to(root), 'capture path must remain beneath its original root')
        need(read(directory / 'result.json') == row, 'original command result mismatch')
        for kind in ('stdout', 'stderr'):
            path = directory / (kind + '.bin')
            need(path.stat().st_size == row[kind + '_bytes'] and hfile(path) == row[kind + '_sha256'],
                 'complete original captured ' + kind + ' required')
        need(hfile(directory / 'stdin.bin') == row['stdin_sha256'], 'complete original stdin required')
        need((directory / 'request.json').is_file(), 'original request required')
        streams.append({'directory': str(directory), 'actual_exit': row['actual_process_returncode'],
                        'timeout': row['timeout_expired'], 'source_sha': row['source_sha']})

for path in sorted(PREP.rglob('*')):
    if stat.S_ISDIR(path.lstat().st_mode):
        continue
    add(path, 'preparation/' + path.relative_to(PREP).as_posix())

tools = [Path(__file__), Path('/workspace/capture_geo337_q38_original_launch.py'),
         Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),
         Path('/workspace/geo261-environment/reap_children.py')]
for path in tools:
    add(path, 'capture-tools/' + path.name)
for path in [Path('/tmp/train337-adversarial/FINAL_L_Q38_PRIVATE_ENVIRONMENT_STATIC_PEER.json'),
             Path('/tmp/train337-adversarial/FINAL_L_Q38_MATERIALIZE_LAUNCH_STATIC_PEER.json')]:
    add(path, 'preparation-peers/' + path.name)

subject_path = OUT / 'q38/q38/receipt.json'
subject = read(subject_path) if subject_path.is_file() else None
summary = {
    'schema': 'fixed-L-Q38-original-terminal-collection/1',
    'source_sha': L,
    'driver_exit': receipt['launcher_exit_code'],
    'outer_exit': outer['exitCode'],
    'execution_capture_exit': capture['exitCode'],
    'original_passed': receipt['passed'],
    'original_commands': gate['commands'],
    'original_case_count': len(subject['results']) if subject else None,
    'original_summary': subject['summary'] if subject else None,
    'original_baselines': subject['baselines'] if subject else None,
    'subject_receipt_sha256': hfile(subject_path) if subject else None,
    'subject_receipt_missing': subject is None,
    'source_before': before,
    'source_after': after,
    'started_utc': receipt['started_utc'],
    'ended_utc': receipt['ended_utc'],
    'capture_rows': streams,
    'elf_payload_excluded_count': len(excluded),
    'elf_payload_excluded_bytes': sum(row['bytes'] for row in excluded),
    'no_subject_executed_by_collector': True,
    'no_existing_file_deleted': True,
    'limitations': [
        'The collector preserves actual red or green outputs; it does not replace the original Q38 judge.',
        'Only streams exposed by the original runner/capture are retained; no hidden pipe is invented.',
        'Original Q38 TemporaryDirectory cleanup may already remove disposable sources/executables. Those payloads are not invented; original compile/log/exception hashes remain.',
        'Only ELF payloads still present under original OUT are excluded from this archive, with hashes and unchanged source paths. The collector deletes nothing.',
        'The original closed before/after identity is used; the live checkout and global native cache are never read.',
    ],
}
save(DEST / 'SUMMARY.json', summary)
save(DEST / 'EXCLUDED_ELF_PAYLOADS.json', excluded)
for path in sorted(DEST.iterdir()):
    add(path, 'collection/' + path.name)
need(len({row['name'] for row in rows}) == len(rows), 'unique package members required')
inventory = {'source_sha': L, 'gate': 'q38', 'members': rows, 'regular_file_count': len(rows),
             'logical_original_bytes': sum(row['bytes'] for row in rows),
             'excluded_elf_manifest': 'collection/EXCLUDED_ELF_PAYLOADS.json'}
save(DEST / 'RAW_INVENTORY.json', inventory)
archive = DEST / 'ORIGINAL_Q38_OUTPUTS_MATERIALIZATION_AND_TOOL_PINS.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6, dereference=True) as stream:
    for row in rows:
        stream.add(row['source_path'], arcname=row['name'], recursive=False)
    stream.add(DEST / 'RAW_INVENTORY.json', arcname='RAW_INVENTORY.json', recursive=False)
expected = {row['name']: row for row in rows}
seen = set()
with tarfile.open(archive, 'r:gz') as stream:
    for member in stream:
        need(member.isfile() and member.name not in seen, 'unique regular archive member required')
        seen.add(member.name)
        body = stream.extractfile(member).read()
        if member.name == 'RAW_INVENTORY.json':
            need(body == (DEST / 'RAW_INVENTORY.json').read_bytes(), 'inventory roundtrip')
        else:
            row = expected[member.name]
            need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
                 and hfile(Path(row['source_path'])) == row['sha256'], 'original byte roundtrip ' + member.name)
need(seen == set(expected) | {'RAW_INVENTORY.json'}, 'exact archive coverage')
package = {'source_sha': L, 'gate': 'q38',
           'archive': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': hfile(archive), 'members': len(seen)},
           'inventory': {'path': str(DEST / 'RAW_INVENTORY.json'), 'sha256': hfile(DEST / 'RAW_INVENTORY.json')},
           'all_selected_original_bytes_roundtrip': True, 'elf_payloads_included': False,
           'existing_original_elf_files_retained': True, 'subject_executions': 0, 'published': False}
save(DEST / 'PACKAGE.json', package)
print(json.dumps(package))
