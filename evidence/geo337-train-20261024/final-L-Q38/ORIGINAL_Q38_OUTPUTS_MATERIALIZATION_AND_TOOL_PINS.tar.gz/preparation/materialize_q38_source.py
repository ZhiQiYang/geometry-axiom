"""Materialize the reviewed fixed-L 565-file source; never compile or run a gate."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import traceback

HERE=Path(__file__).resolve().parent
SOURCE=Path('/workspace/train337-L-reading-a-source')
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
PLAN=HERE/'SOURCE_PLAN.json'
PLAN_SHA='7a5c9b44d9d2df1150ebbdab032575e75353570e749d0d477363245e63980d41'
OLD_BINDING=Path('/workspace/train337-L-reading-a-preparation/SOURCE_BINDING.json')
CAPTURE=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_SHA='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok:raise RuntimeError(message)
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def physical_files():
 result={}
 for base,dirs,files in os.walk(SOURCE,followlinks=False):
  if Path(base)==SOURCE:dirs[:]=[n for n in dirs if n!='.git']
  for name in dirs:
   p=Path(base)/name;need(not p.is_symlink(),'symlink source directory '+str(p))
  for name in files:
   p=Path(base)/name;s=p.lstat();need(stat.S_ISREG(s.st_mode)and s.st_nlink==1,'source must be private ordinary file '+str(p))
   b=p.read_bytes();result[p.relative_to(SOURCE).as_posix()]={'bytes':len(b),'sha256':h(b),'physicalMode':oct(stat.S_IMODE(s.st_mode))}
 return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--root-source-release',action='store_true',required=True)
 a=p.parse_args();out=a.out.absolute()
 need(a.root_source_release,'root source lease required; no overlapping ReadingA/Q38/source writer')
 need(not sys.flags.optimize,'assertion disabling Python environment rejected')
 need(out.parent.is_dir()and not out.exists(),'fresh output required')
 need(out.is_relative_to(Path('/tmp'))or out.is_relative_to(Path('/workspace')),'private output root only')
 need(not out.is_relative_to(SOURCE)and not SOURCE.is_relative_to(out),'output/source overlap rejected')
 need(SOURCE.is_dir()and not SOURCE.is_symlink()and(SOURCE/'.git').is_dir()and not(SOURCE/'.git').is_symlink(),'existing independent ordinary .git checkout required')
 raw=PLAN.read_bytes();need(h(raw)==PLAN_SHA,'reviewed source plan pin');plan=json.loads(raw)
 need(plan['L']==L and plan['source']==str(SOURCE)and plan['selectedFileCount']==565,'fixed plan identity')
 rows=plan['inputs'];paths=[r['path']for r in rows]
 need(len(paths)==len(set(paths))==565 and sum(r['bytes']for r in rows)==9996978,'exact selected file count/bytes')
 need(all(r['mode']=='100644'and not PurePosixPath(r['path']).is_absolute()and'..'not in PurePosixPath(r['path']).parts and not any(c in r['path']for c in '\n\x00[]*?\\')for r in rows),'safe exact ordinary Git blob paths required')
 need(h(CAPTURE.read_bytes())==CAPTURE_SHA,'pin recorder before import')
 oldraw=OLD_BINDING.read_bytes();old=json.loads(oldraw)
 need(old['sourceSHA']==L and old['root']==str(SOURCE)and len(old['files'])==22,'original 22-file source binding')
 need(set(r['path']for r in old['files'])<=set(paths),'all original22 must be retained')
 out.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO261_','GEO323_'))}
 for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD'):env.pop(k,None)
 env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=L,GITHUB_WORKSPACE=str(SOURCE),GIT_OPTIONAL_LOCKS='0')
 recordedEnv={k:env.get(k)for k in ('PATH','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','NODE_OPTIONS','LD_PRELOAD','GITHUB_SHA','GITHUB_WORKSPACE','GIT_OPTIONAL_LOCKS','GEOMETRY_TEST_BRIDGE','GEOMETRY_MODEL_BASE')}
 save(out/'REQUEST.json',{'role':'same-L source materialization only; no build/test/gate','argv':sys.argv,'sourceSHA':L,'source':str(SOURCE),'sourcePlanSHA256':PLAN_SHA,'driverSHA256':h(Path(__file__).read_bytes()),'captureSHA256':CAPTURE_SHA,'old22BindingSHA256':h(oldraw),'rootSourceLeaseExplicit':True,'environment':recordedEnv,'subjectExecutions':0})
 (out/'ORIGINAL_READING_A_BINDING.json').write_bytes(oldraw)
 spec=importlib.util.spec_from_file_location('q38_materialize_c387',CAPTURE);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(out,env,L)
 result={'sourceSHA':L,'source':str(SOURCE),'subjectExecutions':0,'environmentMaterializationOnly':True,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':[],'commands':rec.rows,'exitCode':2}
 def run(args,data=None):
  row,b,e=rec.run(args,cwd=SOURCE,data=data,timeout=1200,check=True,source_sha=L,source_variant='Q38-same-L-private-source-materialization');return b
 def identity(label):
  value={}
  for key,args in [('head',['git','rev-parse','HEAD']),('tree',['git','rev-parse','HEAD^{tree}']),('status',['git','status','--porcelain=v1','--untracked-files=all']),('cached',['git','diff','--cached','--exit-code']),('diff',['git','diff','--exit-code']),('refs',['git','for-each-ref','--format=%(refname) %(objectname)']),('selectedStage',['git','ls-files','--stage','-z','--',*paths])]:value[key]=run(args)
  need(value['head'].decode().strip()==L and not value['status']and not value['cached']and not value['diff'],'exact clean L required; no reset/clean performed')
  summary={'head':L,'tree':value['tree'].decode().strip(),'statusEmpty':True,'cachedDiffEmpty':True,'worktreeDiffEmpty':True,'refsSHA256':h(value['refs']),'selectedStageSHA256':h(value['selectedStage']),'rawIndexSHA256':h((SOURCE/'.git/index').read_bytes())}
  save(out/(label+'-IDENTITY.json'),summary);return summary,value
 try:
  before,beforeRaw=identity('BEFORE');existing=physical_files();need(len(existing)==22 and set(existing)==set(r['path']for r in old['files']),'expected original physical22 only; refuse extra file removal')
  for r in old['files']:need(existing[r['path']]['bytes']==r['bytes']and existing[r['path']]['sha256']==r['sha256'],'old source file changed '+r['path'])
  save(out/'BEFORE_PHYSICAL_FILES.json',existing)
  tree=run(['git','ls-tree','-r','-l','-z',L,'--',*paths]);entries={}
  for line in tree.split(b'\0'):
   if not line:continue
   meta,path=line.split(b'\t',1);mode,kind,oid,size=meta.split();entries[path.decode()]={'mode':mode.decode(),'kind':kind.decode(),'gitBlob':oid.decode(),'bytes':int(size)}
  need(set(entries)==set(paths),'exact Git L selected path set')
  for r in rows:need(entries[r['path']]=={'mode':r['mode'],'kind':'blob','gitBlob':r['gitBlob'],'bytes':r['bytes']},'plan vs real Git tree differs '+r['path'])
  batch=run(['git','cat-file','--batch'],data=('\n'.join(r['gitBlob']for r in rows)+'\n').encode());pos=0;expected=[]
  for r in rows:
   end=batch.index(b'\n',pos);oid,kind,size=batch[pos:end].split();size=int(size);start=end+1;body=batch[start:start+size];pos=start+size
   need(oid.decode()==r['gitBlob']and kind==b'blob'and size==r['bytes']and batch[pos:pos+1]==b'\n','exact original blob batch framing '+r['path']);pos+=1
   need(hashlib.sha1(b'blob '+str(size).encode()+b'\0'+body).hexdigest()==r['gitBlob'],'Git object identity '+r['path'])
   expected.append({**r,'sha256':h(body)})
  need(pos==len(batch),'no unexplained batch tail')
  save(out/'EXPECTED_FIXED_L_FILES.json',expected)
  # Exact rooted paths include all prior22. Git may update sparse flags/index;
  # core.autocrlf=false preserves raw committed bytes including original CRLF.
  patterns='\n'.join('/'+path for path in paths)+'\n'
  run(['git','-c','core.autocrlf=false','sparse-checkout','set','--no-cone','--stdin'],patterns.encode())
  actual=physical_files();need(set(actual)==set(paths),'exact materialized565 physical files, no extras')
  for r in expected:need(actual[r['path']]['bytes']==r['bytes']and actual[r['path']]['sha256']==r['sha256'],'materialized file != original Git blob '+r['path'])
  for path,v in existing.items():need(actual[path]==v,'original22 physical file bytes/mode changed '+path)
  after,afterRaw=identity('AFTER');need(all(before[k]==after[k]for k in ('head','tree','refsSHA256','selectedStageSHA256')),'source head/tree/refs/logical selected stage changed')
  save(out/'SOURCE_BINDING.json',{'sourceSHA':L,'source':str(SOURCE),'sourcePlanSHA256':PLAN_SHA,'files':[{**r,**actual[r['path']]}for r in expected],'fileCount':565,'logicalBytes':9996978,'original22Preserved':True,'allPrivateOrdinaryFiles':True,'independentGitDirectory':True,'beforeIdentity':before,'afterIdentity':after,'indexSparseFlagsMayChange':True,'subjectExecutions':0,'runtimeReadyClaimed':False})
  result.update(exitCode=0,materializedFileCount=565,materializedLogicalBytes=9996978,old22Preserved=True,originalJudgesUnchanged=True)
 except BaseException:result['errors'].append(traceback.format_exc())
 finally:
  result['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'RESULT.json',result)
 print(json.dumps({k:v for k,v in result.items()if k!='commands'},ensure_ascii=False));return result['exitCode']
if __name__=='__main__':raise SystemExit(main())
