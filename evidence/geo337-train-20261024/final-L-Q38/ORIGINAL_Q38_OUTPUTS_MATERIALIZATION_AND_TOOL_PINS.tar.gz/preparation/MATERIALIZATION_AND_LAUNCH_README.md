Q38 固定來源與啟動準備，尚未執行。

固定 L `7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`；使用已完成 ReadingA 的獨立實體 `.git` 來源 `/workspace/train337-L-reading-a-source`，不新 clone、不改 ROOT／SEED／pool。原 22 檔／收據／binding 保留；只在 root 明確釋放來源及磁碟後，依 SOURCE_PLAN 精確物化 565 檔。

精確 argv 在 MATERIALIZATION_AND_LAUNCH_REQUEST.json。先執行 materializationArgv；只有其真 RESULT.exitCode=0、565 Git blob 原 bytes／mode／全部私有 ordinary files、原22 bytes、前後 HEAD／tree／refs／完整 cached diff／selected stage 通過後，才可依 root 新 C 時槽執行 launchArgv。尚未執行任何一條，不能把本文件當受測收據。

新 materializer 固定並先讀 c387 pin；完整錄製 Git request/stdin/stdout/stderr/result。先取精確 565 個 Git tree entries，再 cat-file --batch 保存全部 9,996,978 source bytes 和 Git framing；以原 blob object identity 驗證；rooted noncone patterns 包含原22，core.autocrlf=false 只確保原 raw Git bytes，不改任何原 source/judge。Git 自己的 sparse flags/index stat 可變，HEAD／tree／refs／selected stage listing 與完整 cached diff 不可變。舊 SOURCE_BINDING 不覆寫，新 binding 寫自己的新 OUT。任何額外物化檔、symlink、hardlink、舊22不同、Git失敗均保原輸出並失敗；不 reset／clean／刪舊 source。

物化額外預算約32MiB（新普通檔9.65MB＋完整cat-file原流約10.08MB＋暫時index重寫6MB＋小metadata）；這是規劃估計，沒有保留空間，也不含真正Q38編譯／多個ELF／logs。root當下free與canvas負載允許才執行，不自行清理。

原6789工具與錯誤歷史README均不改；其『只copy來源便不共native cache』說法被保留作歷史並在已627/0外部environment derivative更正。真正模型baseline會呼叫 find_bridge。fa12 derivative先沿原 tests.binaries build私有bridge，成功後才綁真正支援的 GEOMETRY_TEST_BRIDGE；再原 model-base build與完整Q38/jobs1/原600、900秒裁判。build失敗不冒 subject 已跑；explicit path stale／skip仍由原baseline拒絕。不新增threshold／skip／裁判。

launch_q38_private.py 只給已審fa12 driver加事前 REQUEST與c387完整最外命令輸出，未改其原 argv、secondary.lock非阻塞、stack16MiB、600/900內限、source finally守門或真gate。outer0另核原receipt真終態，outer2只metadata問題不冒產品判決。與 native r2不同source/private bridge/model-base，無寫 global /tmp/geometry-tests；自己的 §7 不得同時寫此來源。全部執行結果目前未知。
