# Q38 最窄環境 derivative（未執行）

原6789與原afc PREPARATION、原產品、tests及裁判一字不改，完整保在original/。只允許排q38：先沿原tests.binaries.main([build,bridge])並call-time OUT_DIR私綁到q38-bin；成功才明設原tests._bridge支援的GEOMETRY_TEST_BRIDGE。再沿原model-base build與原完整Q38 argv/jobs1。新增橋build失敗不冒Q38或model-base已跑；原compile600/900/test900、完整baseline/cases/equivalent/exception oracle全保，零額外skip。

原README第24行『不用共享native二進位』說法不完整：model baseline包含test_parameter_and_fixed_material_sources_survive_native_dump_and_package，直接呼叫_bridge.find_bridge；原wrapper清外來GEOMETRY變數，只有model-base私綁，因此bridge fallback會讀global /tmp/geometry-tests，stale時甚至可原生自動build。一律保原README作歷史，不沿錯誤說法並行。這份derivative用真支援的explicit bridge路徑，_explicit若不fresh只回skip，完整原Q38 baseline零skip守門會紅，不fallback寫global。

來源方案SOURCE_PLAN.json為既有private.git/clean L的ReadingA工作樹增補，約新增8.47MB logical／9.65MB檔案allocation，總565檔10.0MB logical；未物化。不寫root/frozenSEED/pool，不新clone。每phase原source/index/refs守門保；§7會改其自身source，不能與Q38共用這個工作樹。

runtime另需原Q38 disposable copy/ELF/log空間。jobs1的native prepare_native於每次compile finally移除該source副本，仍會保多個mutant ELF到原TemporaryDirectory結束；不聲稱10MB來源預算涵蓋整段runtime。root檢查磁碟並授第二槽才可執行；native可用另一ROOT/cache，但本Q38 explicit私有bridge及model-base不得共享可寫inode。暫改source/編譯/Chrome/測試執行皆尚未做。
