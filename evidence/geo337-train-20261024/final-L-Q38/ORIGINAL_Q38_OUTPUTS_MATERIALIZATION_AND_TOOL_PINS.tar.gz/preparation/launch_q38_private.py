"""Prelaunched full-stream capture for the already reviewed Q38-only driver."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback

HERE=Path(__file__).resolve().parent
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_SHA='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
L='7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
DRIVER_SHA='fa12c19d290e192d3952d270b7ad07714d95007bc2b540c13aa57b3e78493195'
REQUEST_SHA='523cbcff7c814d26b3f04de979fc60c570224effc139df2dd1042636293e68e0'
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok:raise RuntimeError(message)
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--materialization-out',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 out=a.out.absolute();need(out.parent.is_dir()and not out.exists(),'fresh prelaunch output required');need(not sys.flags.optimize,'optimized Python rejected')
 need(h(CAP.read_bytes())==CAP_SHA,'pin c387 before import')
 requestPath=HERE/'q38-private-environment-tools/PINNED_REQUEST.json';raw=requestPath.read_bytes();need(h(raw)==REQUEST_SHA,'reviewed exact Q38 request pin');request=json.loads(raw);argv=request['argvTemplate']
 need(h(Path(argv[2]).read_bytes())==DRIVER_SHA,'reviewed environment-only driver pin')
 sourceBinding=(a.materialization_out/'SOURCE_BINDING.json').read_bytes();source=json.loads(sourceBinding);material=json.loads((a.materialization_out/'RESULT.json').read_text())
 need(material['exitCode']==0 and not material['errors']and material['sourceSHA']==L and source['fileCount']==565 and source['sourceSHA']==L and source['original22Preserved']and source['allPrivateOrdinaryFiles'],'successful reviewed565 materialization required')
 need(not Path(request['out']).exists(),'fresh original Q38 result output required')
 env={k:v for k,v in os.environ.items()if not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO261_','GEO323_'))}
 for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD','AXIOM_ONLY','FRAMING_QUOTE_QUEUE'):env.pop(k,None)
 env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=L,GITHUB_WORKSPACE=request['repo'])
 recordedEnv={k:env.get(k)for k in ('PATH','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','NODE_OPTIONS','LD_PRELOAD','GITHUB_SHA','GITHUB_WORKSPACE','GEOMETRY_TEST_BRIDGE','GEOMETRY_MODEL_BASE','CC','CFLAGS','CPPFLAGS','LDFLAGS')}
 out.mkdir();save(out/'REQUEST.json',{'role':'original whole Q38 with private bridge environment derivative; no changed judge/timeout/count','sourceSHA':L,'argv':argv,'cwd':request['repo'],'environment':recordedEnv,'driverSHA256':DRIVER_SHA,'captureSHA256':CAP_SHA,'pinnedRequestSHA256':REQUEST_SHA,'sourceBindingSHA256':h(sourceBinding),'materializationOut':str(a.materialization_out),'outerTimeout':None,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 spec=importlib.util.spec_from_file_location('q38_launch_c387',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(out,env,L);result={'sourceSHA':L,'errors':[],'exitCode':2}
 try:
  row,b,e=rec.run(argv,cwd=request['repo'],timeout=None,check=False,source_sha=L,source_variant='original-Q38-private-bridge-environment');result.update(commandResult=row,exitCode=row['actual_process_returncode'])
  if row['actual_process_returncode']==0:
   original=json.loads((Path(request['out'])/'receipt.json').read_text());need(original['launcher_exit_code']==0 and original['passed']is True and not original['errors'],'original driver zero must retain original real terminal success')
 except BaseException:result.update(exitCode=2);result['errors'].append(traceback.format_exc())
 finally:result['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'RESULT.json',result)
 print(json.dumps(result,ensure_ascii=False));return result['exitCode']
if __name__=='__main__':raise SystemExit(main())
