## Q-335-CLI：Reading A 正例的初放入口缺口（另案設計，未解決）

已核可 Reading A 的接觸政策，不等於真 CLI 已能初放兩支互頂壁邊材。原 core 收據（issue 標 074a004a、後補 README 標 3cbeb759，兩者 C/H/inc 相同）是 order12/order21/only2 退出 1/1/0：先放 e0 時第一支端面無支撐；先放 e2 時 e2 先延伸成長1000，再使 e0 無合法跨距。完整 scene/stdout/stderr/core hash 已保留；本輪只有 L 靜態來源核對，沒有將舊負例重標為 L 實測，oracle/Reading A 綠燈也不補此能力。

依決策佇列 2026-10-24 Q318-1「政策先合，另開工單」與 issue335，放置路徑及逐條條文差異定案前不實作。較窄待審方向為明示 Reading A boundary 固定段原子放置契約，須釐清組內已放/完成狀態、初始跨度、無環來源與 dump/重建；未採用，不把未 placed 料當已放、不硬裁 auto 跨距，不放寬 I22、I20/R18、I5/I11，不新增數值門檻。根因與限制經獨立 peer84/0；這是準備證據，不是產品修正或 #335 驗收通過。
