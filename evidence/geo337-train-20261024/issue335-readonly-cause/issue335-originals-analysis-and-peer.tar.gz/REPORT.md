# #335 初放缺口：唯讀根因與修正可行性

結論：已有 Reading A 幾何政策，尚無可直接採用的初放語意。舊 CLI 原件確證兩個既有命令次序不能建出正例 B；這不是 Chrome、stack 或 oracle 掃描問題。L 的相關拒絕函式與舊來源相同，支持缺口仍在的靜態判斷，**本輪沒有在 L 重跑 CLI**。不能藉改 `placed` 篩選、裁短 auto 跨距、history 分組或載入捷徑將它當純缺陷直接修綠。

## 原始來源與權限

- 唯一受驗 L：`7af8c5d80d34cb4f49d01ba67deb78a3a6d725db`。沒有修改其工作樹、index、HEAD、公理或決策。
- fresh handoff：`339096a7af711bb86224af27e2a981cdeae824c8`；一次 no-tags/no-write-fetch-head 的 object-only fetch exit 0。完整 #337/#338 留言已保存；該 handoff 不含 `pr-reviews/335.md`，原讀取 exit 128 保留。
- 依 root 授權，`gh issue view 335 --repo ZhiQiYang/geometry-axiom --json number,title,state,body,comments,url,updatedAt` 只讀一次，exit 0，原 stdout 2546 bytes、stderr 0，comments 空，updatedAt `2026-10-23T17:00:39Z`；全文及 c387 命令/環境/退出碼在 `issue335-read-once/`。沒有 API 寫入。
- 推理前已讀 L 決策 2026-10-12～15、10-22、10-23、10-24，以及 L `geometry-templates/woodworking/FIELD-RULES.md`（#333 已合入的現場規則引文）。FIELD-RULES 不是 SSOT，也不能取代較新的 10-23/24 條文。
- Q318-1 的使用者選項是「政策先合，另開工單」；同節與 #335 全文都明示設計/條文差異定案前不實作。不能由「正例 B 已核可」推導某種批次、求解或已放語意已核可。

## 原 protocol 與真正拒絕點

六頂點外輪廓 `(0,0),(500,0),(500,13),(1000,13),(1000,1000),(0,1000)`；surface 1，origin `(0,0,2500)`，u=+x/v=+y；兩支 `27×20 role boundary`。原 scene 保留 comment 行，所以錯誤行號如下。

| 原場景 | 原退出/完整流 | 原件證明 |
|---|---|---|
| `order12.scene`：`place 1 on 1 at-face e0 +u +n` 再 e2 | 1；stdout 0 bytes，stderr 79 bytes | 第 5 行第一支 e0：`R6/I5/I6 timber 1: 跨距終點沒有擋面（端面懸空）`。不是第二支錯誤。 |
| `order21.scene`：先 e2 再 e0 | 1；stdout 0 bytes，stderr 70 bytes | 第 6 行第二支 e0：`R6/I5/I6 timber 1: 中線上沒有任何合法跨距`。第一支 e2 已成功。 |
| `only2.scene`：只放 e2 | 0；stdout 2595 bytes，stderr 0 | e2 長 1000、原點 `(0,13,2500)`，足跡 `[0,1000]×[13,40]`，不是正例想要的 `[500,1000]×[13,40]`。 |

三套完整 scene/out/err/exits/core.sha256 都在 L 可解析路徑 `evidence/issue318-reading-a-20261023/claude-followup-20261024/q318-1-cli/`，本地逐 Git bytes 複本在 `originals/claude-followup/q318-1-cli/`。原 core SHA256 `679d5b7206a2a3c67231bc401dc54f39429a6455fe84208a40b00062febfee59`。

來源標記需分欄：issue 原文說 `074a004ade0a8bddccaf986c0dec2f247ead7366`；後補 README 說 `3cbeb75926bb188e6c8f153d182303feadfa27dc`。兩提交全部 C/H/inc diff 為空，並非兩次獨立重測。本輪沒有補造當時完整 argv、編譯旗標、stack、環境或時間；舊收據沒有這些欄位。`current_geometry.c` 的原 CLI 入口是 `--no-window --scene <path> --out <svg>`，這只作將來重現模板，不能說原件已保存了該 argv。

## 根因與現行契約對照

1. **e0 第一個放。** `wood_member_resolve_span()` 先依 R6(b) 求完整合法直帶，低牆段候選為 `[0,500]×[0,27]`。x=500 的 RC e1 只蓋 13mm；另 14mm 沒有角材接觸。`wood_contact_boundary_end_admission()` 要有真已放角材側面，否則回 ORDINARY；`wood_stop_pick()` 沒有全寬擋面，走終點 unsupported。I19 例外三與 R6(d) 明確仍拒「完全沒頂到角材」，不是漏了某個舊例外。
2. **e2 第一個放。** R6(b) 相鄰合法 cell 合併，R6(c) at-face 只要求與 e2 範圍重疊，不把跨度裁到定位邊 `[500,1000]`。因此舊原輸出是 `[0,1000]×[13,40]`，可在有效區域內延伸，左端於 u=0 有原完整擋面。後續 e0 寬度帶與它在 `[0,500]×[13,27]` 有正面積重疊（靜態算式 7000mm²），無合法跨距符合 I11/R6(b)。原診斷由 geometry_status 非 OK 或 interval_count=0 共用；舊原流沒分支 trace，不冒稱已動態辨識這兩個內部分支。
3. **重建/載入不會自動補救。** `reference_rebuild()` 先將 wanted 記下並把 placed 清 false；`reference_contact_facts()`、`wood_contact_collect_stops()` 略過未 placed 的物件；`apply_reference_place()` 保存有序 order 然後立刻驗證。`parse_scene_file()` 逐行 apply；bridge `loadfile` 外層雖有原子 candidate，仍呼叫原場景重放且完整 seal，並未提供「先將兩支視為已放」的輸入單位。
4. **幾何政策與入口能力不同。** 原 `geo318_boundary_ends_harness.c` 的 `init()` 人工給兩支 `.placed=true` 及長 500 的完整足跡；oracle `step()` 也直接給這兩塊 final rectangles。它們驗證接觸政策，不證明現行 CLI 能初次建出此狀態。既有負例還明驗 `only-already-placed-timber`、`partial-rc-alone-remains-unsupported`。

L 的 `member_reference.c`、`contact_world.c`、`contact_sources.c` 與舊 3cb 逐整檔 bytes 同；`reference_rebuild`、`wood_member_resolve_span`、`wood_contact_boundary_end_admission`、`wood_contact_collect_stops` 四個完整函式文本也同。H references 另有已採 #323 memo 變化，明列 `static-identity/3cb-to-L-reference-source.diff`，不以四函式同義宣稱完整 L 執行閉包或真負例已跑。

## 最小可審設計方向；目前均未採用

優先設計一個**明示、限 Reading A boundary 固定段的原子放置單位**，避免改所有既有逐行 `place`。它必須先明定來源與長度如何唯一求出（例如指定有身分外輪廓邊的固定段），再對同一候選的所有物件作接觸、RC 未覆木連續段、I20/R18、I22、I5/I11 全驗；正式 World 只在全過後一次替換。這需要逐條釐清 D11/I19/R6 的「已放」與 I9 的完成狀態、R6 auto 最大跨距/不裁段、D9/R4 dump 表示；不能僅新增一個 CLI begin/end 就認定既有 SSOT 已授權。

若改成整個 evaluator 先求所有幾何、再驗所有端面，影響更大：需要把獨立 pose 來源與 admission 依賴清楚分層、禁止以 cached/provisional pose 藏環或藏失敗，並保留 ordered facts、來源種類/順序、freshness、回滾與重算。它不是目前可直接採用的更小修正。改為允許完全無接觸的第一支、將未 placed 成員直接加入接觸、硬裁 e2 長度、暫時跳過 I22/I20/R18 都與現行條文或已核負例相衝突，不列實作候選。

定案後最少產品範圍：W 明示放置契約與 span/end-admission API，H 的命令/候選協調、持久化與重建；不把木工角色搬回 K。測試須新增真 CLI/core/bridge 正反例及 source/runtime receipts，不能只增加手工 W fixture。

最低反證方案：保留現有兩個逐行失敗原件，對新增明示路徑作 baseline0/withdrawn1/restored0，負控必須正常具名 assertion，非 compiler/loader failure。精確撤掉新路徑而保其餘規則；另分別撤掉 group 終態接觸守門、I22、原子 publish 守門，負例各自要紅。量測/門檻不變、不新增懸空 mm 下限。全組必須涵蓋取消/半包錯誤不提交、資料更動後重建、save/loadfile/dump 往返、角色不適用、零長/錯側/無接觸、裸露 RC 長度恰料寬、延伸段仍全寬、碰撞與跨宿主拒絕。撤回仍綠即未證，不重抽或刪負例。

本輪只準備：未新開分支、未寫產品/測試、未跑 C/Chrome/perf、未改 #325/#331/#333。政策選項見 `QUESTIONS.md`，不向使用者送問題或代替選擇。
