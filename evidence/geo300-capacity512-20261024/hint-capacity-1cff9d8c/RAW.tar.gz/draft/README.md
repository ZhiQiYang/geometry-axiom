# PR #348：固定 4096 hint 容量私有候選

基底是 `8b128aa7bf53b41b493dd3a0bee49f0d53391254`。讀取工作樹時 HEAD 為 `b05288e2be691dd5229937ab6c9a1f555b3f64e2`，但下述三份 base bytes 全部逐 hash 等 8b；此 patch 不含 b052 的 W run-skip、先前 full64 tag 或 main-index metadata。**未套用 active、未 commit/push、未編譯或跑測試。**

補丁：`candidate-with-tests.patch`，SHA-256 `3b45f1e6a0101bc501ecac54999354a906413fe6d4918eeb0e1e961fe03de040`。完整三檔 candidate 在 prototype，逐檔 base/candidate SHA-256 在 IDENTITY.json。

## 最小產品差異

僅 `geometry-core/kernel/source.c` 兩行：

```c
size_t node_hint[4096];
size_t slot=(size_t)hash&(sizeof ctx->node_hint/sizeof *ctx->node_hint-1);
```

第二行取的是元素數減一，不是 array bytes 減一。4096 是這個私有實驗的單一固定實作常數且為 2 的冪；沒有 runtime tuning、沒有多容量掃描、沒有新增驗收性能門檻。

原完整 `provider/key_size/key bytes` identity 比較、hash 函式、主 uint32 ordinal table、必要配置次序、node/key/array 必要配置失敗、optional table OOM→linear、ordered graph、seal 與 public API 全不改。原 `geo_eval_clear()` 已用 `sizeof ctx->node_hint` 清空整個陣列。

成本：此 64-bit 環境 `size_t` 的 hint payload 從 2,048B 變 32,768B，**每個存活 context 增加 30,720B（30KiB）**。原 context calloc 仍一筆，沒有新 allocation call，但該筆必要配置大小變大、zero-fill 成本變高；不能聲稱實體 OOM 可達集合完全相同，也不能把多 context 的成本只記一次。32-bit size_t 才是增 15,360B，本機此輪不據此推論。

## 為何只能作有界可行性候選

主代理真 512 profile 觀測 883,227,010 node calls／792,730,861 finder calls，約 10% hint 命中；這支持檢查熱集合污染，但沒有證明 4096 槽必能消除全部工作。容量不會減少真 cold miss、主表真正碰撞、每次 key hash 或必要 provider callbacks。先前 tag N256 的 34.7013→34.9025 沒有收益，已保留不採；本 patch 不疊加該失敗實驗。

新增 fixture 特意固定 distinct 4096 slots，是對「容量有沒有真的承接熱集合」的精確工作量證明，不代表真 512 世界的 hash 分布或牆鐘速度。主代理僅在控制通過後做一次既定 N256 可行性觀測，再決定採不採；本草稿沒有宣告加速或 H7 已解除。

## 原控制與必要適配

- source-index 原 29、node-slot 原 6 不動；array width/ordinal guard/原 calloc index 故障攔截均仍命中原碼，沒有改 table slot width。
- 原 7 個 node-hint 測試都保留。HINT_SLOT instrumentation anchor 改為新的真 mask 整行；舊 selector 撤回仍是原 low8 選擇器，代表回退原行為而不是新 4096 實作。
- 原 `typed-collision` 223／256、所有 frame、invalid-before-hash 與 closed-seal 斷言保留。它只證明舊 low8 碰撞，不能在 4096 下繼續冒稱會碰到同一 hint。
- 原「拿掉完整 identity」mutant 的 predicate anchor 完全不變；只是改以先前經 peer 靜態複核的真正 full64 collision fixture 抓同一個原具名缺陷：`node-hint-collision-retains-full-identity`。兩個 16-byte key 以第二 word 補償第一輪 hash state，先由真 production hash 證 full64 相同且 bytes 不同，再由獨立 linear_node／ordered graph 作身份 oracle。相同 hash 不被視為身份相同。
- 舊 reset 斷言名稱保留，迴圈從固定 256 擴到實際陣列全長，這是加強覆蓋。另 `capacity-reset` 以真 512 keys 暖過高槽，證明 >255 有非零 hints，reset 後所有槽為零、只剩 context allocation，destroy 無洩漏。

## 512／1024 真 key 工作量 fixture

只使用正式 `geo_placement_source_ref()`／decoder 的 FRAME keys、原 provider evaluate 與真正 `geo_eval_source()`，沒有手造替代幾何或 fake lookup。

1. 固定候選 key corpus 是 placement IDs 1…65536；以真 hash 的 low12 在固定 4096 槽中取前 512／1024 個不同槽，逐 key decode 驗 id/kind、逐 slot 驗真 hash。65536 是有限 fixture 輸入集合，非產品容量／時間門檻。
2. 無論正常 4096 或撤回 256 版本，選出的 key bytes 完全相同；fixture 不依被測 ctx 的槽數重新挑有利輸入。
3. 先完整暖入，然後固定四輪讀同順序所有 keys。既有 instrumentation 直接計數真 hash/finder/probe：正常版 finder=0、probe=0、hash=4N。每次都驗真 frame、node 身分；後續核 provider 每鍵只呼叫一次、完整有序圖、seal 後讀取／無額外 callback、sealed depend/reset 拒絕。
4. 正常觀測命令的原 stdout 包含 keys／slots／requests／hashes／finds／probes JSON，Python 明確核實；不拿「有跑」代替工作量結果。
5. 容量撤回僅把 `[4096]` 改回 `[256]`，sizeof mask 自動跟隨，完整 identity 與主表全留。由於同一組至少 512 個 keys 分進 256 slots，必有碰撞；按相同順序循環重讀會出現 finder/probe，具名 `node-hint-capacity-hot-set-avoids-finder` 應紅。兩個 N 都使用 baseline→mutant→restored 原 helper；不得把 crash/setup/timeout 當有效 kill。

## 待實際執行

三檔 unified diff 沒有 run_all.expected.json 修改；新增的 unittest 方法數必須由完整 census 實跑更新，不能手填。靜態設計預期的紅／綠不是已取得收據。

若主代理採入私有實驗，先執行原 source-index／node-slot／node-hint／edge-scope 控制，並保留新兩個具名撤回（capacity、full64 identity）的正常 0/1/0 原件；一項失敗先找病因，不改舊斷言。只有這些控制實際成功後，才做一次既定 N256 可行性與記憶體記錄。是否需要後續 graph172/H7/架構/帳本取決於是否正式採用，不為未採候選重做全部 gate。
