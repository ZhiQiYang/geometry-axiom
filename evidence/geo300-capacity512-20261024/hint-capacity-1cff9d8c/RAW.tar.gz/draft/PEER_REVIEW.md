# 4096 hint 槽候選：有界對抗靜態複核

結論：**未發現阻斷，可交 root 依排程實跑；不代表性能已改善。** 唯讀檢查指定 patch、source與tests，僅新增本報告。未編譯、未執行、未改active。

固定內容：

- patch SHA-256：`3b45f1e6a0101bc501ecac54999354a906413fe6d4918eeb0e1e961fe03de040`
- candidate source SHA-256：`f97cd0640b0d40722bc9eba4664f4e697ba6922711ac30424a72d4d55453d8c6`
- Python test SHA-256：`467165c9a10899f5803274261f03c13e4e2f6c6d21738d6383c4c90eb3acd08d`
- C harness SHA-256：`993b51a9389ca5cf69acdea31aae33dafcb292942d94ab083a3c4ca875eb99ff`

## 產品邊界

產品只把 node_hint 陣列256增為4096，mask改成 `sizeof array / sizeof element - 1`。4096是2的冪，故mask4095不超界；候選沒有full64 tag。原完整source identity仍逐byte比對，hint miss依原finder處理，不限制authoritative node/edge數量、不截斷來源。

clear/reset原 `memset(ctx->node_hint,0,sizeof ctx->node_hint)` 自動覆蓋全部4096槽；測試也依sizeof遍歷。fresh context原calloc全零。所有hint寫入仍只有既有finder命中或必要append成功後兩處；invalid/missing及node/key/array配置失敗路徑未變。舊node/key兩個必要配置點、array exact-size retry、optional index fallback不受這兩行改動。

固定內嵌陣列增加 `3840*sizeof(size_t)` bytes/context，64bit為30720B（30KiB），32bit為15360B。context calloc的次數不變，但尺寸變大，所以不能宣稱實際記憶體壓力或OOM可達範圍完全不變；需納入真峰值，不能以靜態通過排除此風險。

## Fixture 沒有換掉來源，但證明範圍有限

capacity_prepare從固定id1..65536 corpus，以正式K placement key constructor/decoder產生5-byte typed keys，挑4096槽下互異的前512或1024筆。選樣用固定CAPACITY_SLOTS=4096，不讀被測ctx容量；縮到256的mutant不改hash函式，所以兩版本取得同樣id及key bytes。

warm後4096版本每個key仍在自己的槽，四輪只有一次正式hash、不進finder或main-index probe。512/1024個不同來源超過256槽，縮容量版本至少有一個bucket含兩key；固定順序輪讀該bucket必換出前一key，因此finder>0，會命中 `node-hint-capacity-hot-set-avoids-finder`。此論證不靠時間門檻。

512個4096互異槽不可能全落0..255，因此高槽warm前置成立；reset後全槽0的測試確實覆蓋新增區域。1024在既有linear oracle的MAX_REFS容量內，靜態陣列與key lifetime足夠，未見顯性C型別/連結問題。

**這是刻意保證distinct-slot的controlled hot-set，不是實際512已放置world的來源分布。** 若正式world有大量4096碰撞、provider切換或短生命週期context，收益可能很小；本測試不能證實新容量已解除H7阻擋。

## 碰撞與舊測試

舊low8 typed-collision baseline保留，但low8相同不保證low12相同，故它單獨不能證明4096候選遇hint collision仍正確。新增16-byte full64碰撞已補足：兩個key第一word0/1，第二word0及第一輪狀態xor，第二輪輸入相同，正式fullhash核對相等但bytes不同。

identity撤回不再依low8fixture，而在full64碰撞第二個來源由獨立linear oracle要求2nodes、產品錯只留1node，正常落 `node-hint-collision-retains-full-identity`。full64 fixture用memcpy寫回／讀回uint64，沒有little-endian假設。低8 selector撤回仍明確使用原255 mask，為歷史比較，不冒充4096真碰撞。

## 尚待實跑

新容量正例、256撤回0/1/0、full64 identity0/1/0、原K配置/slot/scope/reset/seal裁判均尚未由本peer執行。root須保留命令、exit、來源SHA及raw；效能與記憶體結論只根據正式固定來源結果，不依上述工作量推論。
