# PR #348：K hint 256→4096 私有候選對抗審查

**靜態審查沒有發現 blocking。** 可進入主代理安排的原控制與一次有界實際對照；不是產品通過或加速證據。

固定 base：`8b128aa7bf53b41b493dd3a0bee49f0d53391254`。審查使用固定 `git show` 的 base bytes，不依靠變動中的 active HEAD。

- Patch：`/dev/shm/pr348-hint-capacity-draft/candidate-with-tests.patch`。
- Patch SHA-256：`3b45f1e6a0101bc501ecac54999354a906413fe6d4918eeb0e1e961fe03de040`。
- source.c：`f97cd0640b0d40722bc9eba4664f4e697ba6922711ac30424a72d4d55453d8c6`。
- Python suite：`467165c9a10899f5803274261f03c13e4e2f6c6d21738d6383c4c90eb3acd08d`。
- C harness：`993b51a9389ca5cf69acdea31aae33dafcb292942d94ab083a3c4ca875eb99ff`。
- 三檔 base/candidate hashes 均與 IDENTITY.json 相符；patch 前後固定未變。

未編譯、未啟動產品、未執行 tests、未改 active/Git。僅跑 AST／字串轉換與 hash 前置核對，結束碼 0。

## 產品兩行與成本

只把私有 `size_t node_hint[256]` 改為 `[4096]`，並以 `sizeof ctx->node_hint / sizeof *ctx->node_hint - 1` 產生 mask。4096 是二的冪；此式先求元素數再減一，不是 bytes mask。hash、source 合法性、完整 provider/key_size/key identity、finder、ordered node/edge arrays、scope marks、sealed 路徑及公開 API 不變。

對 64-bit size_t：hint payload 2048 → 32768 bytes，**每個存活 context 增加 30720 bytes（30 KiB）**，context 的必要 calloc 仍一次，但大小與 zero-fill 成本增加。不能把多個 live contexts 的增量只算一次，也不能聲稱極限實體 heap 的 OOM 可達集合完全不變。32-bit size_t 才是增加 15360 bytes；本次未編譯量實際 struct padding。

原 node calloc → key malloc → node-array grow → optional index 的先後完全未改；未插入新 allocation call。必要配置失敗返回、optional index OOM→linear、uint32 ordinal guard 與 fallback 也未改。主表還是原主表，容量增加不會吞掉 MEMORY/CAPACITY。

## 完整碰撞、舊 low8 與原控制

原 typed IDs 223/256 的整個 `typed_collision()` 函式保持原文；它們仍提供原 frame／invalid-before-hash／輸出保全／sealed 斷言。但 low8 相同不能在新 4096 槽下冒稱為實際 hint 碰撞。

原 identity 撤回只更換其觸發輸入為真 full64 collision：兩個 16-byte keys 用第二 word 抵消第一輪 state 差異，fixture 先以真 production hash 證 full64 相同且 bytes 不同。判決仍用原 independent `linear_node`／ordered graph，不把 hash 當身份。移除完整 identity 檢查後，第二個 key 被錯併，應由原具名 `node-hint-collision-retains-full-identity` 紅。產品仍完整比 key，沒有因較大槽數改為相信 hash。

原 source-index harness 前 32 個 key 本來就強制 `hash & 4095 == 4095`，新 4096 槽仍把它們放在同一 hint 槽。因此 never-find-node、ignore-key、first-probe-miss/hit 的真主索引碰撞路徑不會因更大 hint 被全面旁路。原 node-slot harness 查舊 keys 時以 `sizeof ctx->node_hint` 清空全部 hint，仍強制主 finder 及真 ordinal。scope／edge 路徑無產品差異。

原 old-selector 撤回仍用舊 provider/keysize/首尾 byte 及 low8 mask，它撤回的是舊選槽行為，32 個重讀的原負例仍具意義；不需為4096把它悄悄改成另一種對照。

## 512／1024 fixture 是工作量證據，不是實際世界代表樣本

fixture 只使用真 `geo_placement_source_ref`／decoder 的 FRAME keys，provider 回傳由 id 決定的 frame，每次 `geo_eval_source` 都核 exact frame 及獨立 linear node identity。最多1024 keys 小於原 oracle 的1552容量，未越界；沒有替代產品 finder 或 geometry。

選鍵策略固定在 4096 slots 的 low12：從有限 IDs 1…65536 取前512／1024個不同槽。這是刻意選出的理想熱資料分布，使用 production hash 作 fixture 篩選並非獨立效能樣本；它不會證明真512世界也具有此分布。它仍是有意義的精確工作測試，因為：

1. baseline 與縮回256的 mutant 使用相同 key bytes；fixture 不依被測 context 槽數重新挑選。
2. 初次暖機後，四輪真 API 重讀的 finder/probe/hash 由原真函式 instrumentation 計數，不是讀新容量常數就宣告成功。
3. baseline 要求 finder=0、probe=0、hash=4N；每次還必須正確回 frame，provider 每鍵一次、完整 ordered identity、sealed 行為與無洩漏。
4. 縮回256只改陣列長度，sizeof mask跟隨。N>=512個不同 keys 必有至少兩個共用一槽；循環同序讀取時，該槽的最後持有者無法同時是兩個 keys，必然有 finder/probe 工作，故具名 `node-hint-capacity-hot-set-avoids-finder` 應紅。不是鏡像比較被測表的內容。

新容量測試主要核 node 熱集合，沒有額外 consumer edges；這不能單獨聲稱覆蓋大圖 edge correctness。原 K29／scope17 與舊 hint consumer 三種 dependency 測試保留，仍須按原排程實跑。

## reset 完整性

產品 `geo_eval_clear` 本來就是 `memset(ctx->node_hint,0,sizeof ctx->node_hint)`，4096自然全清，沒有固定256殘留。舊 harness 逐槽檢查從固定256改成 sizeof全長，是加強覆蓋。

新增 capacity-reset 使用真512個 distinct4096-slot keys；至少有高於255的槽暖成非零，先斷言此事，再 reset、逐4096槽清零、檢查只剩 context allocation、destroy 無洩漏。它能抓「只清低256槽」這種實作壞法，未以未暖過的零值假證完整清空。sealed reset 仍拒絕。

## 靜態前置結果

- 原 edge／node-slot／scope instrumentation 與新 hint instrumentation 字串轉換完成。
- old-selector、recomputed-hash、identity-ignored、capacity-256 四個撤回 anchor 各恰好1次；各自套入後仍可完成 instrumentation。
- 原 K source-index、node-slot、edge-scope、source-context Python 中命中產品的 literal 出現次數相對固定base無變化。
- 舊 typed_collision 整函式未改；三檔完整hash符合 IDENTITY。
- 新 node-hint 實際 AST method census 是11（原7＋新增4）；512/1024在同method內分別執行。與29＋6＋17合計應是63個methods；這是靜態數量，不是已通過數量。

## 未驗事項

主代理尚須回收所有真 baseline／mutant／restored exits、完整圖與原ELF對新候選的有界效能／記憶體結果。本審查不因微測為綠就接受4096，也不把先前 tag、W run-skip 的結果套到本來源。此 patch 不含那兩個已不採候選；沒有改測試時間或性能門檻。若真對照無收益，保留原件並不採即可，不做無界容量掃描。
