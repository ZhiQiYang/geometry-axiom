import atexit, hashlib, json, os, pathlib, platform, shutil, subprocess, sys, time
ROOT=pathlib.Path('/dev/shm/pr348-diagnostic-c754')
OUT=pathlib.Path('/dev/shm/pr348-static-profile-1cff-n256')
OLD=pathlib.Path('/dev/shm/pr348-tag-pair-256')
SHA='1cff9d8c3deab815d5ae6562f3163c95e6f82ac9'
os.environ['TMPDIR']=str(OUT/'tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1';(OUT/'tmp').mkdir()
sys.path.insert(0,str(ROOT))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def command(args,name):
 r=subprocess.run(args,cwd=OUT,capture_output=True)
 (OUT/(name+'.stdout')).write_bytes(r.stdout);(OUT/(name+'.stderr')).write_bytes(r.stderr)
 dump(name+'.json',{'command':args,'exit':r.returncode})
 return r
raw_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert raw_head==SHA,raw_head
files=set()
for name in ['geometry-core','geometry-app','geometry-templates','geometry-web']:
 for p in (ROOT/name).rglob('*'):
  if p.is_file() and p.suffix in ('.c','.h','.inc'):files.add(p)
for name in ['current_geometry.c','tests/test_geo261_native_kernel.py','tests/_bridge.py','tests/test_engineering_json.py']:
 files.add(ROOT/name)
manifest=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
dump('SOURCE_MANIFEST_BEFORE.json',manifest)
dump('ENVIRONMENT.json',{'source_sha':SHA,'source_root':str(ROOT),'raw_head':raw_head,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'python':sys.version,'tmpdir':os.environ['TMPDIR'],'shm_free_bytes':shutil.disk_usage('/dev/shm').free,'cgroup_memory_current':pathlib.Path('/sys/fs/cgroup/memory.current').read_text().strip(),'cgroup_memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip(),'purpose':'one bounded static O0-pg diagnostic; not formal performance acceptance'})
command(['/usr/bin/cc','--version'],'cc-version');command(['/usr/bin/gprof','--version'],'gprof-version')
libs=[pathlib.Path(p) for p in ['/usr/lib/x86_64-linux-gnu/libc.a','/usr/lib/x86_64-linux-gnu/gcrt1.o','/usr/lib/x86_64-linux-gnu/libm.a','/usr/lib/x86_64-linux-gnu/libm-2.41.a','/usr/lib/x86_64-linux-gnu/libmvec.a','/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a','/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_eh.a']]
dump('STATIC_LIBRARIES.json',[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in libs])
from tests.test_geo261_native_kernel import NativeBuild
class StaticProfileBuild(NativeBuild):
 def run_build(self,args):
  args=list(args);args.insert(1,'-pg')
  if '-c' not in args and '-o' in args and pathlib.Path(args[args.index('-o')+1]).name=='product-bridge':args.insert(1,'-static')
  try:super().run_build(args)
  finally:dump('build-log.json',self.logs)
start=time.monotonic();b=StaticProfileBuild();exe=b.bridge()
atexit.unregister(b.temp.cleanup);b.temp._finalizer.detach()
shutil.copy2(exe,OUT/'bridge-static-pg')
dump('BUILD.json',{'source_sha':SHA,'seconds':time.monotonic()-start,'work':str(b.work),'executable':str(OUT/'bridge-static-pg'),'sha256':sha(OUT/'bridge-static-pg'),'bytes':(OUT/'bridge-static-pg').stat().st_size,'exit':0,'flags_change_from_original_profile':'Only final product-bridge link adds -static; every original compile retains -O0 -pg'})
command(['/usr/bin/readelf','-h',str(OUT/'bridge-static-pg')],'elf-header')
command(['/usr/bin/readelf','-l',str(OUT/'bridge-static-pg')],'elf-programs')
command(['/usr/bin/readelf','-d',str(OUT/'bridge-static-pg')],'elf-dynamic')
shutil.copy2(OLD/'stdin.bin',OUT/'stdin.bin')
dump('INPUT.json',{'stdin':str(OLD/'stdin.bin'),'stdin_sha256':sha(OLD/'stdin.bin'),'scene':str(OLD/'input.scene'),'scene_sha256':sha(OLD/'input.scene'),'original_stdout_sha256':sha(OLD/'baseline.stdout'),'original_stderr_sha256':sha(OLD/'baseline.stderr')})
print('STATIC_PROFILE_START',time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),flush=True)
args=[sys.executable,'-B','/tmp/pr348-runs/measure.py','--exe',str(OUT/'bridge-static-pg'),'--input',str(OUT/'stdin.bin'),'--out',str(OUT/'run'),'--sha',SHA,'--timeout','600']
r=command(args,'measure');print('MEASURE_EXIT',r.returncode,flush=True)
comparisons=[]
for name in ['stdout.bin','stderr.bin']:
 old=OLD/('baseline.stdout' if name=='stdout.bin' else 'baseline.stderr');new=OUT/'run'/name
 if new.is_file():
  result=command(['/usr/bin/cmp',str(old),str(new)],'cmp-'+name)
  comparisons.append({'name':name,'exit':result.returncode,'old_sha256':sha(old),'new_sha256':sha(new),'old_bytes':old.stat().st_size,'new_bytes':new.stat().st_size})
dump('COMPARISONS.json',comparisons)
gmon=OUT/'run/gmon.out'
if gmon.exists():
 command(['/usr/bin/gprof','-b',str(OUT/'bridge-static-pg'),str(gmon)],'gprof')
 command(['/usr/bin/gprof','-b','--flat-profile=__mcount_internal','--time=__mcount_internal',str(OUT/'bridge-static-pg'),str(gmon)],'gprof-mcount-only')
after=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
dump('SOURCE_MANIFEST_AFTER.json',after)
result={'source_sha':SHA,'measure_exit':r.returncode,'source_unchanged':manifest==after,'comparison_exits':[x['exit'] for x in comparisons],'diagnostic_only':True}
dump('SUMMARY.json',result);print(json.dumps(result),flush=True)
sys.exit(0 if r.returncode==0 and manifest==after and len(comparisons)==2 and all(x['exit']==0 for x in comparisons) else 1)
