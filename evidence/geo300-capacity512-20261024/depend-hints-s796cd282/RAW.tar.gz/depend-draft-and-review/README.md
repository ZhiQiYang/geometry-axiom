# PR #348：generic dependency ordinal hint 私有候選

基底：`1cff9d8c3deab815d5ae6562f3163c95e6f82ac9`。僅修改 K 的 `source.h/source.c`，新增兩個測試檔；未修改任何舊測試、H/W、帳本或架構產物。此目錄是私有草稿，尚未編譯或實跑；不能當效能或驗收通過。

`geo_eval_depend_hint(ctx, source, kind, &hint)` 的 hint 是節點 ordinal + 1；0 表示未知。非零 hint 先檢查當前 context 範圍，再比 provider、key_size、全部 key bytes。命中仍原樣呼叫 `geo_source_edge`，未命中仍走原 `geo_source_node` 再 `geo_source_edge`。只有完整成功才更新 caller hint，NULL hint 直接呼叫舊 API。不配置提示表、不保存值、指標、圖邊或跨 World 結果；K context 大小不變，H 每個提示的成本是 `sizeof(size_t)`（H 欄位及接線由主代理實作）。

錯誤順序保留：sealed、NULL context、無效 key 先拒絕；缺 provider 回 MISSING，必要 node/key/array 配置失敗回 MEMORY，即使 kind 無效亦保留原優先順序；已知 provider 的新 identity 在無效 kind 情境仍可先插入 NEW node。已知 hint 不是邊存在的證據：換 consumer／kind 仍可因必要 edge grow 回 MEMORY；provider describe/evaluate、ACTIVE/CYCLE、FAILED、optional index fallback 及封圖均仍由原路徑支配。

新測試 15 項：11 正例與 4 個各有不同具名紅的撤回。沿用未修改的 `geo261_source_index_harness.c` 配置注入、獨立線性 ordered graph oracle，以及原 `instrument_hint_work` 真 hash/find/probe 計數。包含同址改 key、同 bytes 異址、provider／長度、full64 collision、0／越界／SIZE_MAX、reset、跨 context 同序號異 identity／同 identity 異值、NULL API 等價、sealed、NEW/FAILED/ACTIVE、真 nested provider、必要配置失敗及 retry、optional fallback。512 個真 byte key 各循環 4 次的工作量斷言只要求命中後不重新 hash/find；不是 wall-time 門檻，也不宣稱真 512 world 效能。

撤回項：

- 移除完整 identity：`depend-hint-full-identity`。
- 命中直接 OK 而略 edge：`depend-hint-current-consumer-edge`。
- 禁用 fast path：`depend-hint-hit-avoids-hash-and-lookup`。
- 移除 sealed guard：`depend-hint-sealed-guard`。

每項預定執行 baseline 0／mutant 1／restored 0。只有具名 ASSERT、正常退出 1 才算 kill；編譯錯誤、crash、timeout 均不算。目前均 **UNRUN**。`GEO300_DEPEND_HINT_LOG` 可保存每個 C 子程序的完整命令、GITHUB_SHA、phase、exit、stdout、stderr。

供主代理在套用／固定候選 SHA 後執行（本代理未執行）：

```sh
GITHUB_SHA=<完整候選SHA> GEO300_DEPEND_HINT_LOG=<持久輸出>/depend-hint.jsonl python -B -m unittest -v tests.test_geo300_depend_hint
```

接著保留原 source-index、node-slot、node-hint、scope 共 63 項與 172 場景 ordered graph／原流控制，另驗 H 接點。只有實測有意義改善才考慮採入。此 API 不保證省去 edge、begin/end/provider；原調用次數不得改。

靜態核對：Python AST 解析、四個撤回 anchor 唯一、舊 API 文字未變；`STATIC_PREFLIGHT.json` 固定檔案雜湊。產品已由 W 代理獨立審查未見阻斷；新測試另送同代理子代理複核。所有編譯／正式測試由主代理統一排程。
