# K depend ordinal hint：獨立產品靜審

固定 base `1cff9d8c3deab815d5ae6562f3163c95e6f82ac9`；product.patch SHA-256
`6e5b8856ba56dd056b019a191c6dac58d6e84e37eeb195a38f9e8a13f09ec109`。
兩份候選原檔 hash 與 PRODUCT_IDENTITY.json 相符。**未見阻斷性產品缺陷；這不是測試通過或效能證據。** 沒有編譯、測量、active 寫入或 Git 操作。

## 身分與生存期

- hint 是 ordinal+1，不是 node pointer／value／edge cache。非0先做 `index<=node_count`，才讀 node；0／過界直接走原查找，避免 stale ordinal 越界。
- 命中條件仍是真 `geo_source_ref_equal`：provider token、key_size、全部 key bytes。相同 ordinal 在另一 ctx 指向不同 provider／key，或 caller 同址改 key bytes，都會 miss。K 原本已複製 key，不能因 caller key 的指標沒變而誤命中。
- 不同 ctx 即使同 ordinal、同 provider/key，也只依賴該 ctx 的現有 node。API 不讀／回傳 value、不呼叫 provider，因此不借用另一 ctx 的 candidate binding 或 cached value。
- reset 清空 nodes 與 provider；舊 hint 過界就走原路。reset後重建同 ordinal 若完整身分不同仍 miss；若身分相同，使用的是重建後該 ctx 的 node，合理。
- 函式不保留 `size_t *hint` 或 caller source.key 指標。hint storage 是 caller 的可寫輸出；像其他 C out-parameter 一樣，caller 必須提供有效、可寫的 `size_t`。把它刻意 alias 到 K 只讀 node view／opaque context 不在合法公開 API 使用範圍，不能作為本片反例。

## 失敗、started 與邊順序

- `hint==NULL` 直接呼叫原 `geo_eval_depend`，無差分。
- 非NULL時，null ctx／sealed／非零key_size但NULLkey 在讀 hint／node 之前拒絕，與原路的無副作用 INVALID 一致。
- hint miss 完整呼叫原 node，再呼叫原 edge。未知 provider＋非法 kind 仍先 MISSING；必要 node/key/array 配置失敗＋非法 kind 仍先 MEMORY；成功建立 node 後才判非法 kind，原可觀察 node insertion 保留。
- hint hit 只省 source 查找／雜湊，不省 `geo_source_edge`。合法 kind、沒有 active consumer、完整 edge 去重、scope marks、必要 edge 配置失敗與公開 edge append 順序都仍由原函式處理。失敗不把 hint 更新成新 ordinal；已存在的正確 hint 在失敗時原值保留。
- hit 未顯式重寫 `ctx->started=true` **不是可達缺漏**：公開 API 維持 `node_count>0 ⇒ started=true`；唯一 node 追加必先經 `geo_source_node` 設 started，clear/reset 同時將兩者清零。hit 必有既存 node，因此 registration 已關閉。另一代理獨立讀完整生命週期也確認此點。
- hit 不重新暖內部 node_hint 槽，可能改變未來查找工作量；不改 node／edge 結果或 allocation failure 順序，因原查到既存 node 也不新增配置。

## 採入前必要實跑（未在本審執行）

1. 同 ordinal 的跨 ctx、reset 重建、provider 不同、長度不同、尾端 key byte不同；同址可變 key 與完整64-bit collision仍需真身分判定。
2. 正常 hint hit／miss／NULL 與原 depend 比完整 ordered graph、所有 kind、重複邊及 nested／retry failure；不可只比回傳值或 edge count。
3. sealed／非法 key；非法 kind 與 MISSING、必要 node MEMORY 的優先序；既存 node 新邊配置雙失敗保持原邊／hint，重試恢復成功。
4. 工作量反證撤去新快路必具名紅，身分防線撤回必由錯圖／錯依賴的正常 assertion 紅；crash／compile error不算kill。

本 API 是通用 K source 操作，不把 W schema 或幾何語意帶進 K。公開 header 新宣告、後續 H 呼叫接線與新測試仍要依最終 source closure 更新架構／帳本，不能借本靜審宣告完整整合綠。
