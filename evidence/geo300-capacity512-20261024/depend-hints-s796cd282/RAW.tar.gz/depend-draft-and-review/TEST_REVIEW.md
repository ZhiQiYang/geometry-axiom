# depend-hint 測試最小靜態複核

結論：未發現阻斷性 fixture／具名反證錯誤。只讀 C/Python 與既有 allocator/oracle/instrumentation；沒有編譯、執行測試或修改產品。

固定 patch SHA-256：`869b013e9c3e5d6a2f786765f96218fd3f332c06ca951be0219307e9cbd7765e`。
C harness SHA-256：`ddc8543ed9751dfd11cdb7806dcda4e511858605ba216441c80edd0e20dd830b`；Python SHA-256：`3815ed3f662fa63547c72134cbf7c1a90d6171cb93f4cbc2fd4463c88d134419`。
Python AST 確認15個test methods（11正例、4撤回），不是實跑結果。

- 必要配置故障：暖第3node後 node_count=3、capacity≥4，因此第4node可先提交再於 edge grow 故障；不會被 node array 的 realloc 提前擋住。node/key 的第1/2配置、精確容量1的 node array、edge array 故障各有原狀／hint／leak斷言；清除故障後續接原路徑。
- 巢狀真 callback oracle：parent對共同source三種邊＋child邊＋自身兩種邊共6；child與另一個consumer各5，共16。callback內重複依賴不新增邊，self VALUE_REQUIRED仍走cycle；計數與獨立linear oracle一致。
- full64 collision以兩個16-byte鍵建構：第一word混合後state不同，第二word XOR補償使下一輪輸入相同；identity仍不同，fixture不靠猜測碰撞。alias修改用的是oracle已存在的refs[0]/refs[1]身分，沒有把可變alias借存成新的oracle鍵。
- 四撤回分別在full-identity、current-consumer-edge、hit-avoids-hash-and-lookup、sealed-guard具名斷言終止；這四路徑在預期失敗點前不會先由graph_equal輸出另一ASSERT。Python要求exit1、空stdout、stderr精確一行具名ASSERT並重跑恢復基準；crash/setup錯誤不當kill。

尚未驗：編譯／平台型別配置／實際15項退出碼與四組0/1/0，仍須root正式執行。本次不宣稱效能或產品已通過。
