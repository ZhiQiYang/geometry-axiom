# #348 depend-hint 固定閉包沿用核對

結論：4b17→S 的原 monolithic O0 diagnostic build 185 個實際相依葉，Git mode／OID 全同；SOURCE 原185個 blob 身份也逐一對上。172 frozen 場景逐一對固定 corpus Git 原bytes／hash，並核原 plain／trace 收據的場景／SHA／600s／16MiB pins。原172結果宣告檢查全真／exit0；本次沒有重播或重新解壓圖。

S=`796cd282693736af61c1b0d6c8ff91f03437a175`；原 graph fix execution=`4b17edac67648fb5f6048b05114a66e99eb1846a`，base=`9a8584f57be7935604c3bad4c2481945a6ec3d9f`。這份歷史 diagnostic 可帶其真實 execution 身份引用；不改標 S，不替代正在獨占的正式 H7。

| 原範圍 | 真實 execution | 原結果 | 到 S 的界線 |
|---|---|---|---|
| K63＋H22 | 4b17edac… | 85 個方法原綠；所在98整輪仍1 | 六項差異全是新增兩組測試／run_all及load-residual錨點；這85 direct suites不讀被改driver或run_all，產品及測試/helper閉包不變，可引用85，不能稱98全綠 |
| H5＋load13 | 057884a4… | 18／0、exit0 | 後續只有K15兩檔＋run_all新增，不在該direct測試輸入；可引用原18項 |
| K15 | edc57cd4… | 15／0、exit0 | 到S非evidence完全同，可引用原15項 |
| H6zero＋舊host22 | 03e42751… | 28／0、exit0 | reference_sources.inc、source.c/h、references.inc四個實際build葉已變；只能保歷史，不能憑prepare函式似同採為S完整build綠。新4b17的H22另有原綠；S的H6未在本核對宣稱已執行 |

4b17→S非evidence恰六葉：兩個新的K15檔、兩個新的H5檔、tests/run_all.py、tests/test_geo261_load_residual.py。原98唯一FAIL是never-invalidate建置前的anchor唯一性assert，原來源／exit1／98run／1failure／clean與原outer.log均保留；不冒稱產品killed或整輪綠。

裁判身份：原compare_graphs.py hash29feb8…固定，reuse compare.py／原trace文本／E18 manifest各有完整hash；trace_definition機械文字變換對上e82d2811…；原64MiB reserve、600s與16MiB仍是原收據值。模式是monolithic -O0，不是正式separated H7。SOURCE、BUILD、場景、工具及每leaf mode/OID均見REPORT.json。

限制：這次只讀固定Git與已終態小收據，不編譯、不跑測試／benchmark／graph、不讀H7。未重hash ELF或解壓graph；不把閉包證明當新執行。Git既存alternates缺目錄警告原文記錄，各固定物件指令仍exit0，不修Git。所有execution、原失敗與歷史H6身份保持。

裁判pin觀測界線：原driver與E18 manifest對上execution-time SUMMARY的固定hash；完整trace文字的機械變換對上BUILD原definition hash。reuse compare.py的hash則是本次closed command pathname觀測值，原SUMMARY沒有另存該wrapper的execution-time hash；不補造該歷史欄位，也未重播comparison。
