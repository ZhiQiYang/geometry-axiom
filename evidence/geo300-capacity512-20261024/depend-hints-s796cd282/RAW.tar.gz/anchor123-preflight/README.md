# PR #348 全 123 突變：只讀套用與閉包預檢

來源：`796cd282693736af61c1b0d6c8ff91f03437a175`。本輪預檢原程序退出碼 **0**；不是突變正式執行，也不代表 killed／crashed／equivalent 判決已更新。

- 定義 123／唯一 ID 123：115 run、5 equivalent、3 retired。
- 120 個有效／等價 mutation 的唯一錨點均存在；3 個 retired 的舊錨點均為 0。
- Core 依原 `build_mutant_source` 展開唯一 include 路徑並在記憶體替換；bridge 依原 raw bytes.count／replace 在記憶體替換。所有適用者成功，沒有 missing／duplicate／不可達閉包。
- core＋bridge 聯集閉包 185 檔，前後雜湊相同：`a160b1f246d6714e71d236bb251b7336745e29a32a2a0fc592087b432fdc9017`。
- 43 個 RESTORED 方法及所有指定 bridge 方法均有對應 AST class/method，無須 import 或執行測試。
- 正式 core `TESTS` 指定的 166 個 scene 均存在；這不是另一組 172 graph 場景的替代。

world_validation.c 的 M98、M56、M36、M37、M147、M148 各自舊錨點數皆為 1，均可依原路徑套用。全 MUTANTS 沒有使用 `memset(memo,0,sizeof *memo)` 作舊錨點；先前 LoadResidual 的雙 memset 衝突不在這份帳本重現。

為避免模組 import 可能建立 cache，只從實際 AST 取原 MUTANTS／其字串常數、原 Sources／definition_kind／build_mutant_source／輔助純函式；RESTORED 只載入原常數。第一次純 AST 取件少收 B2_TESTS 常數而 NameError，未到來源套用；補齊 B2_TESTS/S1_TEST/S2_TEST 後完整跑完。這是預檢選取問題，不是產品／測試紅燈。

未修改 active、測試、帳本、mutants、Git 或任何原件；未編譯、執行 oracle 或創造正式變異判決。只新增本目錄 JSON／說明。生成的 mutation source 僅存記憶體，JSON 留每個生成長度與 SHA-256。正式編譯、baseline、變異判決、還原及全帳本仍須由主代理執行。

完整 123 筆 old/new、expected/actual count、route、輸入與輸出 hash、43 方法與 scene 清單：`PREFLIGHT.json`。SHA-256：`6815f9fc78388af09076bd9220f26dad5354224caf0496a7d9a3960c03d4f500`。
