from pathlib import Path
import hashlib
import json

out = Path('/tmp/pr348-ledger-recovery-20261029')
base = Path('/dev/shm/pr348-ledger-7a0e6dd8')
cache = base / 'tmp/geometry-tests/mutants'
ledger = json.loads((base / 'ledger.json').read_text())
binary_rows = {r['original_path']: r for r in json.loads((out / 'ORIGINAL_ELF_MANIFEST.json').read_text())}
M = '7a0e6dd81c54066995981393925fa46a815de2f8'
records = []
streams = []
for mid, row in ledger.items():
    e = row.get('execution')
    if not e:
        assert row['verdict'] == 'retired'
        continue
    if e['schema'] == 'geometry-mutation-execution/1':
        exe = cache / mid / '_mut.exe'
        sidecar = json.loads(Path(str(exe) + '.fingerprint.json').read_text())
        assert binary_rows[str(exe)]['sha256'] == e['exe_sha256'] == sidecar['exe_sha256']
        assert binary_rows[str(cache / '_baseline/baseline.exe')]['sha256'] == e['baseline_exe_sha256']
        fp = sidecar['fingerprint']
        assert fp['mutant_sha256'] == row['mutant_sha256']
        assert fp['closure_sha256'] == row['closure_sha256']
        assert fp['compile_sha256'] == e['compile_sha256']
        records.append({'id': mid, 'backend': 'core', 'verified': True})
    else:
        assert e['schema'] == 'geometry-bridge-mutation-execution/1'
        for phase in ('baseline', 'mutant', 'restored'):
            folder = cache / '_bridge-baseline' / M if phase == 'baseline' else cache / mid
            exe = folder / 'bridge' if phase == 'baseline' else folder / ('bridge-' + phase) / 'bridge'
            identity = e[phase + '_identity']
            actual = binary_rows[str(exe)]
            assert actual['sha256'] == identity['exe_sha256']
            assert actual['sidecar_sha256'] == identity['sidecar_sha256']
            assert json.loads(Path(actual['sidecar_path']).read_text()) == identity['sidecar']
            if phase in ('baseline', 'restored'):
                assert identity['exe_sha256'] == e['baseline_identity']['exe_sha256']
            for suffix in ('', '_build'):
                run = e[phase + suffix]
                assert not run['timed_out']
                if suffix or phase in ('baseline', 'restored'):
                    assert run['exit_code'] == 0 and run['process_returncode'] == 0
                for channel in ('stdout', 'stderr'):
                    path = folder / run[channel + '_file']
                    sha = hashlib.sha256(path.read_bytes()).hexdigest()
                    assert sha == run[channel + '_sha256']
                    streams.append({'id': mid, 'phase': phase + suffix,
                                    'channel': channel, 'path': str(path), 'sha256': sha})
        assert e['byte_restored'] is True
        records.append({'id': mid, 'backend': 'bridge', 'verified': True})

assert len(records) == 120
assert len(streams) == 636
result = {'execution_sha': M, 'record_links_verified': len(records),
          'core_records': sum(r['backend'] == 'core' for r in records),
          'bridge_records': sum(r['backend'] == 'bridge' for r in records),
          'bridge_build_and_test_stream_references': len(streams),
          'bridge_unique_raw_streams': len({r['path'] for r in streams}),
          'records': records, 'streams': streams,
          'no_test_execution': True, 'no_original_mutation': True}
(out / 'EXECUTION_LINKS.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('records','streams')}))
