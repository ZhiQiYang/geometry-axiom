"""Read-only recovery of the completed original PR348 mutation run."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import stat

SOURCE = Path('/dev/shm/pr348-ledger-7a0e6dd8')
LAUNCHER = Path(str(SOURCE) + '-launcher')
OUT = Path('/tmp/pr348-ledger-recovery-20261029')
CACHE = SOURCE / 'tmp/geometry-tests/mutants'
M = '7a0e6dd81c54066995981393925fa46a815de2f8'
BUDGET = 30 * 1024 * 1024

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def describe(path, relative):
    assert path.is_file() and not path.is_symlink(), path
    s = path.stat()
    return {'original_path': str(path), 'member': relative, 'bytes': s.st_size,
            'mode': s.st_mode, 'mtime_ns': s.st_mtime_ns, 'sha256': sha(path)}

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

receipt = json.loads((SOURCE / 'receipt.json').read_text())
ledger = json.loads((SOURCE / 'ledger.json').read_text())
assert receipt['sha'] == M and receipt['exit_code'] == 0 and not receipt['errors']
assert receipt['source_before'] == receipt['source_after'] == {'head': M, 'status': ''}
assert [(s['label'], s['original_command_result']['actual_process_returncode']) for s in receipt['steps']] == [('precheck', 1), ('full-ledger', 0), ('checkafter', 0)]
assert sha(SOURCE / 'ledger.json') == receipt['ledger_sha256']
assert len(ledger) == 123 and all(r['date'] == '2026-10-29' for r in ledger.values())
assert collections.Counter(r['verdict'] for r in ledger.values()) == {'killed': 114, 'crashed': 1, 'equivalent': 5, 'retired': 3}
assert all(r.get('execution', {}).get('head') == M for r in ledger.values() if r['verdict'] != 'retired')

selected = []
for path in sorted(SOURCE.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    rel = path.relative_to(SOURCE)
    if rel.parts[0] == 'tmp':
        continue
    selected.append((path, 'originals/ledger-run/' + rel.as_posix()))
for path in sorted(LAUNCHER.rglob('*')):
    if path.is_file():
        selected.append((path, 'originals/launcher/' + path.relative_to(LAUNCHER).as_posix()))

binaries = []
for path in sorted(CACHE.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    rel = path.relative_to(CACHE)
    if rel.parts[0] == '_bridge-work':
        continue
    with path.open('rb') as handle:
        is_elf = handle.read(4) == b'\x7fELF'
    if is_elf:
        item = describe(path, 'cache/' + rel.as_posix())
        sidecar = Path(str(path) + '.fingerprint.json')
        assert sidecar.is_file(), path
        metadata = json.loads(sidecar.read_text())
        assert metadata['exe_sha256'] == item['sha256'], path
        if 'exe_size' in metadata:
            assert metadata['exe_size'] == item['bytes'] and metadata['exe_mtime_ns'] == item['mtime_ns'], path
        item['sidecar_path'] = str(sidecar)
        item['sidecar_sha256'] = sha(sidecar)
        item['copied'] = False
        binaries.append(item)
    elif path.suffix != '.lock':
        selected.append((path, 'originals/cache-text/' + rel.as_posix()))

projected = sum(p.stat().st_size for p, _ in selected)
assert projected + 2 * 1024 * 1024 < BUDGET, projected
assert shutil.disk_usage(OUT).free > projected + 64 * 1024 * 1024
manifest = []
for path, member in selected:
    row = describe(path, member)
    target = OUT / member
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        shutil.copy2(path, target)
    copied = describe(target, member)
    for key in ('bytes', 'mode', 'mtime_ns', 'sha256'):
        assert row[key] == copied[key], (path, key)
    assert row == describe(path, member), path
    manifest.append(row)

# Verify all top-level raw command streams against the original capture rows.
commands = []
for item in receipt['commands']:
    directory = Path(item['directory'])
    streams = {}
    for channel in ('stdout', 'stderr'):
        raw = directory / (channel + '.bin')
        assert sha(raw) == item[channel + '_sha256'], raw
        assert raw.stat().st_size == item[channel + '_bytes'], raw
        streams[channel] = str(raw.relative_to(SOURCE))
    commands.append({'command': item['command'], 'exit': item['actual_process_returncode'],
                     'timeout': item['timeout_expired'], 'streams': streams})

bridge_streams = []
for mid, row in ledger.items():
    execution = row.get('execution', {})
    if execution.get('schema') != 'geometry-bridge-mutation-execution/1':
        continue
    assert execution['byte_restored']
    for phase in ('baseline', 'mutant', 'restored'):
        run = execution[phase]
        assert not run['timed_out']
        for channel in ('stdout', 'stderr'):
            path = Path(run[channel + '_file'])
            if not path.is_absolute():
                path = (CACHE / '_bridge-baseline' / M if phase == 'baseline' else CACHE / mid) / path
            assert path.is_relative_to(CACHE), path
            assert sha(path) == run[channel + '_sha256'], path
            bridge_streams.append({'id': mid, 'phase': phase, 'channel': channel,
                                   'original_path': str(path), 'sha256': sha(path)})

crash = ledger['M20']['execution']
assert crash['baseline']['exit_code'] == 0 and len(crash['attempts']) == 3
summary = {
    'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'execution_sha': M, 'original_started_utc': receipt['started_utc'],
    'original_ended_utc': receipt['ended_utc'], 'original_wrapper_exit': 0,
    'source_before': receipt['source_before'], 'source_after': receipt['source_after'],
    'ledger_sha256': receipt['ledger_sha256'],
    'counts': dict(collections.Counter(r['verdict'] for r in ledger.values())),
    'coverage': len(ledger), 'special_ids': {v: sorted(k for k, r in ledger.items() if r['verdict'] == v) for v in ('crashed', 'equivalent', 'retired')},
    'commands': commands, 'copied_files': len(manifest), 'copied_bytes': projected,
    'binary_originals': len(binaries), 'binary_original_bytes': sum(x['bytes'] for x in binaries),
    'binary_sidecars_all_match': True, 'bridge_stream_references_verified': len(bridge_streams),
    'no_product_execution': True, 'no_git_write': True, 'not_published': True,
    'limitations': [
        'Core per-attempt result records and stdout/stderr hashes exist in ledger; the original mutator does not persist those individual raw streams.',
        '175 original ELF files remain in the original cache, hash-verified but not copied within this 30 MiB recovery budget.',
        'This recovery is not a new mutation run and does not change any execution SHA.',
    ],
}
write('ORIGINAL_MANIFEST.json', manifest)
write('ORIGINAL_ELF_MANIFEST.json', binaries)
write('BRIDGE_STREAM_HASHES.json', bridge_streams)
write('RESULT.json', summary)
print(json.dumps({k: summary[k] for k in ('coverage', 'counts', 'copied_files', 'copied_bytes', 'binary_originals', 'binary_original_bytes', 'bridge_stream_references_verified')}, ensure_ascii=False))
