import pathlib,json,subprocess,tarfile,hashlib,shutil,os
ROOT=pathlib.Path('/dev/shm/pr348-active')
REC=pathlib.Path('/tmp/pr348-ledger-recovery-20261029')
SRC=pathlib.Path('/dev/shm/pr348-ledger-7a0e6dd8')
M='7a0e6dd81c54066995981393925fa46a815de2f8'
PRIOR='2be7e5aa058bf5e7b14e2e33fbbf40261fe9dbc3'
BRANCH='codex/geo300-capacity512-20261024'
def digest(raw):return hashlib.sha256(raw).hexdigest()
commands=[]
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
 commands.append({'command':['git',*args],'exit':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
 (REC/'publication-commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
 p.check_returncode();return p.stdout.decode().strip()
assert git('rev-parse','HEAD')==PRIOR and not git('status','--porcelain=v1','--untracked-files=no')
receipt=json.loads((SRC/'receipt.json').read_text());assert receipt['exit_code']==0 and not receipt['errors']
assert [(s['label'],s['original_command_result']['actual_process_returncode']) for s in receipt['steps']]==[('precheck',1),('full-ledger',0),('checkafter',0)]
assert receipt['source_before']==receipt['source_after']=={'head':M,'status':''}
ledger=(SRC/'ledger.json').read_bytes();assert digest(ledger)=='812956bf480e74eda9e838e29f40f83a9cdd1f317e16e0432aaf539f33fcc569'
shutil.copy2(SRC/'ledger.json',ROOT/'tests/mutants_results.json')
git('add','--','tests/mutants_results.json');git('commit','-m','Regenerate complete mutation ledger for capacity hot paths');L=git('rev-parse','HEAD')
checkenv={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_')) and k not in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME')}
checkenv.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(SRC/'tmp'),LANG='C.UTF-8',LC_ALL='C.UTF-8')
p=subprocess.run(['python3','-B','tests/mutate.py','--check'],cwd=ROOT,env=checkenv,capture_output=True)
(REC/'adopted-check.stdout').write_bytes(p.stdout);(REC/'adopted-check.stderr').write_bytes(p.stderr)
(REC/'ADOPTION.json').write_text(json.dumps({'execution_sha':M,'ledger_commit':L,'ledger_sha256':digest(ledger),'command':['python3','-B','tests/mutate.py','--check'],'cwd':str(ROOT),'exit':p.returncode,'TMPDIR':checkenv['TMPDIR']},indent=2)+'\n');p.check_returncode()
OUT=ROOT/'evidence/geo300-capacity512-20261024/full-ledger-7a0e6dd8';OUT.mkdir(exist_ok=False)
manifest=[]
def add(tar,p,name):
 assert p.is_file() and not p.is_symlink();st=p.stat();raw=p.read_bytes();manifest.append({'path':name,'bytes':len(raw),'mode':st.st_mode,'sha256':digest(raw)});tar.add(p,arcname=name,recursive=False)
with tarfile.open(OUT/'RAW.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(REC.rglob('*')):
  if p.is_file() and p.name not in ('publication-commands.json','PUBLICATION.json'):add(tar,p,'recovery/'+p.relative_to(REC).as_posix())
 for r in json.loads((REC/'ORIGINAL_ELF_MANIFEST.json').read_text()):
  p=pathlib.Path(r['original_path']);st=p.stat();assert st.st_size==r['bytes'] and st.st_mode==r['mode'] and digest(p.read_bytes())==r['sha256'];add(tar,p,r['member'])
with tarfile.open(OUT/'RAW.tar.gz','r:gz') as tar:
 expected={r['path']:r for r in manifest}
 for m in tar:
  r=expected.pop(m.name);raw=tar.extractfile(m).read();assert len(raw)==r['bytes'] and digest(raw)==r['sha256'] and m.mode==(r['mode']&0o7777)
 assert not expected
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for name in ('README.md','RESULT.json','PEER.md','ADOPTION.json','adopted-check.stdout','adopted-check.stderr','rules-review.md'):
 shutil.copy2(REC/name,OUT/name)
raw=(OUT/'RAW.tar.gz').read_bytes();archive_hash=digest(raw)
(OUT/'DELIVERY.json').write_text(json.dumps({'execution_sha':M,'ledger_commit':L,'archive_bytes':len(raw),'archive_sha256':archive_hash,'files':len(manifest),'includes_original_elfs':175,'originals_preserved':True},indent=2)+'\n')
progress=ROOT/'evidence/geo300-capacity512-20261024/PROGRESS.md';old=progress.read_text();progress.write_text(f'''# #348 唯一 current state（全帳本已核收）

- 產品／全帳本 execution：`{M}`；全帳本採入提交：`{L}`。其後沒有改寫 execution 身分。
- 完整123筆：114 killed／1 crashed（M20）／5 equivalent／3 retired，stale／blocked／survived／unrun皆0。原 precheck=1 保留；原 full=0／checkafter=0，採入後原 `mutate.py --check`=0。
- 原697份文字與175支ELF皆封存於 `full-ledger-7a0e6dd8/RAW.tar.gz`，SHA256 `{archive_hash}`；獨立核收見同目錄 PEER.md。
- H7：真T256747c5執行8／0／0／0、1142.271674秒<1200，所有批次<600；T→M非evidence無差異。#297真M64場景2936支全接受；架構三原裁判0／0／0。原失敗與來源閉包均保留既有資料夾。
- 精確#343／#346／#347祖先已納入，與目前#347 behind0。完整census／35分鐘native／六browser仍未完成，**Draft／NOT READY**。

## 歷史紀錄（以下不是 current state）

'''+old)
git('add','--sparse','-f','--',str(OUT),str(progress));git('commit','-m','Preserve complete mutation execution and recovery evidence');E=git('rev-parse','HEAD')
git('-c','pack.window=0','-c','pack.depth=0','push','--no-thin','origin',E+':refs/heads/'+BRANCH)
assert git('ls-remote','origin','refs/heads/'+BRANCH).split()[0]==E
blob=git('rev-parse',E+':'+(OUT/'RAW.tar.gz').relative_to(ROOT).as_posix())
remote=subprocess.check_output(['gh','api','repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob,'-H','Accept: application/vnd.github.raw+json']);assert remote==raw
result={'ledger_commit':L,'evidence_commit':E,'execution_sha':M,'blob':blob,'archive_sha256':archive_hash,'archive_bytes':len(raw),'files':len(manifest),'remote_bytes_verified':True}
(REC/'PUBLICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
