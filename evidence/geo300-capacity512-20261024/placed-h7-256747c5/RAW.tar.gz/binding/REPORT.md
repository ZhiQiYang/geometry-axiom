# #348 remaining-hint 已完成原流與圖閉包核對

結論：本輪固定execution `256747c5c8f8f8934eeb08ae404dee1f67591508` 原35項＝新7＋H13＋W15，77.553515秒、exit0、0fail/error/skip、tracked前後乾淨。三個新增具名反證與舊H/W反證均由正常ASSERT偵測，未把compile/error/signal/timeout算kill。

| 新具名撤回 | 原exit | 真實hash計數 baseline→withdrawn→restored |
|---|---|---|
| remaining-definition-hint-skips-node-hash | 0/1/0 | 0→2→0，兩次真H consumer讀取保留 |
| remaining-pose-hint-skips-node-hash | 0/1/0 | 0→2→0，兩次真H consumer讀取保留 |
| remaining-collection-hint-skips-node-hash | 0/1/0 | 0→4→0，四個真W FEATURE consumer保留 |

三組baseline/restored的ELF hash與完整stdout/stderr均相同；mutant有不同具名ASSERT、原exit1，並對上commands中的正常退出原流。新13筆case raw全部核hash與來源。171次實際編譯/連結全0。

H13原74筆子執行包含53個原0、21個具名ASSERT原1；這是紅執行數，不冒稱21種獨立單故障。placement-key single-mutant-equivalent原0保留，paired defence仍明列成對前提。另3筆舊負控（unvalidated-collection、never-invalidate的move與parameter）沿用logger預設phase=positive；原欄不改，依實際command與原測試碼註明負控，沒有把它們說成baseline紅或改JSONL。

W15的8原controls＋3cached-collection controls共11組，逐讀commands原stdout/stderr與前後baseline/restored：全部精確0/1/0、mutant stdout空、stderr只有原ASSERT、exception=None。W未產生專屬JSONL，沒有偽稱存在；完整證據在原commands。兩舊py的全部test_*方法AST保持相同，僅實際hint API文字錨點／kind替換與呼叫數唯一性檢查適配。

## 622b原圖到256747的沿用界線

原graph execution=`622b665423a55b4042a638589d2cd1efff427c7e`，原base=`9a8584f57be7935604c3bad4c2481945a6ec3d9f`，172場景原exit0。BUILD實際185葉逐leaf Git mode/OID與256747全同，且SOURCE captured blob逐一對上原622b。172 frozen場景的原corpus Git bytes/hash、622b及256747 mode/OID逐一全同；裁判原driver pin保持。兩source之間非evidence恰6個tests葉（兩個新harness、新py、run_all、兩個舊py適配），沒有產品build葉差異。

因此可保原execution身分引用這份monolithic -O0圖diagnostic，不改標256747，也不替代正在執行的正式H7。原graph full gzip/ELF未重讀或重跑；reuse wrapper目前實體hash有記，原SUMMARY沒有另存wrapper execution-time hash，不補造歷史欄位。

本次僅讀固定Git及closed原件，新檔只在本目錄；未讀活動H7。所有mode/OID、raw pins、具名stderr、0/1/0對應路徑及原phase界線見REPORT.json。
