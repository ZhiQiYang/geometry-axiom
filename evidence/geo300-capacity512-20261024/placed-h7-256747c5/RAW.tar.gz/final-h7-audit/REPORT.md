# #348 最終H7／採入／N128原件核對

H7完整終態成立：execution `256747c5c8f8f8934eeb08ae404dee1f67591508`，inner **8項／0fail／0error／0skip／exit0，1142.122526秒**；原run_all外層 **exit0、1142.271674秒<1200、未timeout**。9批各原exit0、無exception，最長216.621139秒，原600／1200秒與16MiB stack均保持。tracked前後空。未重跑產品。

逐讀九批原stdin/stdout/stderr並核原hash；000的7材history為15個回覆，真新preview token2經取消舊token1後用`confirm 2`；002的512逐步／513拒絕／history為1050回覆，真token1用`confirm 1`。取消、preview未發布、confirmed delete、undo／redo、final restore與原raw一致。64 canonical兩次（004/005）及512 canonical兩次（007/008）的完整stdin/stdout/stderr逐byte相同；最後008完整原流已保留，沒有沿用上次缺尾的資料。

本地/tmp的11份lossless archives（build＋9batch＋final）各對上manifest／LOCAL原hash，逐member原bytes和mode與SHM原件相同；wrapper三檔也與SHM背景原件逐byte相同。明確限制：v7 transform連初始request checkpoint一併移除，沒有request.tar.gz；inner REQUEST與OBSERVER原bytes仍在SHM，inner RESULT包含相同request欄。最後收件須一併保全它們、wrapper與11archives；不改已執工具、不補稱原初已有archive，也不宣稱此輪已遠端出版。

正式工作分支正常merge/push的M=`7a0e6dd81c54066995981393925fa46a815de2f8`，與T之非evidence raw tree差異為零；T確為merge parent，三個原upstream a934a554／eaf15e23／8bb03593對M的ancestor讀取原0並再次固定物件確認。原普通push、ls-remote exact M及新source乾淨收據完整。可按來源閉包引用H7，但execution仍T，不改標M，也不預判活動全123或完整native通過。

M的N128 profile原exit0／gprof0，5.982724714秒；唯一原B=`9a8584f57be7935604c3bad4c2481945a6ec3d9f`之N128原exit0／gprof0，14.914534721秒。input.scene 11199B、stdout146252B、stderr0B逐byte相同；兩邊ELF／gmon／gprof原hash也對上。兩個literal stdin的loadfile絕對路徑不同，未冒稱stdin bytes相同、未正規化輸出。這是separate -O0 -pg單點診斷，不當正式效能裁判或其他N／H7結果。

舊S796的1200.106348 timeout原件保持原exit=null／timed_out=true；不同產品來源與observer的結果不可拿來宣稱純網路收益。本次只讀closed原件與固定Git，未讀活動帳本、未編譯／測試／profile／發布。
