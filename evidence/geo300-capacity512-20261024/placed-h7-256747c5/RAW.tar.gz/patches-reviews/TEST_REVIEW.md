# 剩餘三處 depend-hint：7新測試＋28既有測試定位靜審

結論：未見阻斷性 fixture／link closure／控制失效。沒有編譯、執行或改產品。方法數只由AST計算：{'test_geo261_load_residual.py': 13, 'test_geo261_contact_sources.py': 15, 'test_geo300_remaining_depend_hint.py': 7}。

固定輸入：
- tests.patch SHA-256 `98f0e3c9e5565bc17af732d5319877f7e6d4c4f2bec0f242c0c1e0bc098fb187`
- existing-anchor-adaptation.patch SHA-256 `06712a55e0cdde867b2702395528c57da8f7b5df96716ade67c0ffdc7e16e611`

舊兩檔僅定位更新：原斷言、方法與時限保留。H的if形式全域替換由1個depend＋2個hint變成0＋3，新增definition沒有漏出替換；status=pose原本不在這個if批次內，仍由獨立pose-edge／pose-kind控制覆蓋。pose-kind改成匹配新第三參數的逗號位置，產出非no-op且C參數括號正確。W三個edge/kind撤回精確覆蓋新呼叫，index==1的skip仍會丟第二FEATURE依賴，沒有撤回後仍執行舊呼叫的漏洞。

新測試：H以原copy_product_closure與PRODUCT_DEFINES編譯含真H的私有harness，只把product_objects中的唯一K source object換成計數版；原harness主函式改名不動斷言。W直接復用原fixture，其真count==4、完整9條有序邊先由舊斷言驗證。各exe的observer由各自client提供，沒有重複K或跨exe符號依賴。H第二consumer固定兩次warm read，結束清residual flag，計數只識別provider/key/id41；W begin/end只包那一次dependency，其他source hashes不納入。三撤回恢復舊API，語意原斷言仍須先過，之後各2／2／4次hash觸發各自正常具名ASSERT。Python要求完整JSON、原PASS或單一紅訊息，不把compile/crash當kill。

未驗：35項實際退出碼、三組0/1/0、平台link與執行資源、H7效能；均待root實跑。這份靜審不宣告通過。
