# 三處既有 depend-hint 接線：獨立產品靜審

固定 product.patch SHA-256 `c422183749d7768dff8829be4a2f1a466ca764758991a4308fc81a9c9484e292`。結論：未見阻斷性的身分、錯誤優先序或 graph 順序差異；沒有編譯／測試／修改產品。

1. W feature→collection 保留原 node_at 的0-based ordinal、完整provider/key/VALID/value守門；僅通過後建局部1-based hint。SIZE_MAX分支避免加一溢位；由前面的成功node_at，此極限正常本來不可達。局部hint不寫回原0-based欄位，不會令後續node_at偏移；原geo_eval_source fallback仍原位。依賴仍在讀取collection值之前，以原VALUE_REQUIRED relation執行。
2. H definition 沿用 i界限、sealed、definition_valid/id守門；新增definition_node_hint只供同一完整WoodDefinitionKey經既有K helper重驗。首次cache miss與decoder原路徑不變。ReferenceEval 的calloc、零初始化及dispose整份member_reads memset涵蓋新欄位，沒有未初始化提示。
3. H pose 與原footprint提示皆為 APP_SOURCE_MEMBER_POSE、同一uint32_t id/sizeof id。共用的是可失效ordinal，沒有共用或改寫兩份幾何快取；K完整key重驗使舊ID或不同graph的ordinal安全回退。原pose_valid/pose_id/sealed守門、relation、status診斷與寫回timber順序不變。新helper仍記錄當前consumer/kind的邊，不以hint當edge證明。

K API未改。H新增size_t欄位帶來WORLD_MAX_TIMBERS*sizeof(size_t)的結構空間增量（64-bit、512時4KiB）；沒有新增查詢配置或更動CAPACITY定義。這是源碼推理，不是成本測量。

待實跑：W非零ordinal/描述預熱/失效提示回退、H交錯pose與footprint/錯key/完整graph、必要edge故障及三組撤回；正式結果尚未取得。不得以本靜審宣告H7完成或效能改善。
