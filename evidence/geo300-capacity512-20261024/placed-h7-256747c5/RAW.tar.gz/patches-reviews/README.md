# 剩餘三處 dependency hint：私有候選與控制

產品基底：`796cd282693736af61c1b0d6c8ff91f03437a175`。
主代理已將產品採入隔離候選 `622b665423a55b4042a638589d2cd1efff427c7e`；本代理未套用 root checkout、未編譯或執行測試。

產品三處：W FEATURE 使用已證 VALID 的 collection 時，將原 0-based node ordinal 安全轉為局部 +1 hint（SIZE_MAX 回 0），原 node_at／完整 identity／state／value proof 皆保留；H definition memo 新增純 ordinal 欄位；H pose memo 共用同 APP_SOURCE_MEMBER_POSE／完整 id 的既有 footprint hint。每次仍記原 consumer／kind 的 edge，不保存新值或跨 World 結果。K 不改。64-bit 下 H 新欄位增加 512×8＝4096 bytes。

檔案：

- `product.patch`：三產品檔，SHA-256 `c422183749d7768dff8829be4a2f1a466ca764758991a4308fc81a9c9484e292`。
- `existing-anchor-adaptation.patch`：兩個舊測試的定位適配，SHA-256 `06712a55e0cdde867b2702395528c57da8f7b5df96716ade67c0ffdc7e16e611`。
- `tests.patch`：三個全新專測檔，SHA-256 `98f0e3c9e5565bc17af732d5319877f7e6d4c4f2bec0f242c0c1e0bc098fb187`。
- `candidate-with-tests.patch`：上述三份合併，從 S796 套用；SHA-256 `6b3d0b2b5aac5b7838ce917707a00457508ee9db78aac8a458a6848ad8bfad29`。**已採入 622 的工作樹只套兩份測試 patch，不重套產品。**

新測試七項，均 **UNRUN**：

1. H definition 兩個真 consumer，沿原 value／ordered graph／世界不變／sealed 斷言。
2. H pose 的兩個 consumer 使用不同 dependency kind，沿原完整斷言。
3. W 四個真 FEATURE 使用一個 collection，沿原九條精確 ordered edge 與 canonical 輸出斷言。
4. 原 collection reset 場景：舊 ordinal 指到不同 key、NEW collection 必先求值，不能誤用舊值。
5. 撤回 H definition hint：`remaining-definition-hint-skips-node-hash` 具名紅；第二 consumer 兩次讀取應由 0 變 2 次 hash。
6. 撤回 H pose hint：`remaining-pose-hint-skips-node-hash`；兩次讀取由 0 變 2。
7. 撤回 W collection hint：`remaining-collection-hint-skips-node-hash`；四個 FEATURE 由 0 變 4。

各撤回預定 baseline 0／mutant 1／restored 0；編譯錯誤、crash、timeout 不算 killed。僅計真 K hash 入口，H 僅第二 consumer、W 僅原 VALID collection 依賴呼叫範圍；沒有 wall-time 門檻。舊 harness 的斷言完全不改，main 僅在私有編譯副本改名。

舊測試適配原因：新的函式名與 hint 參數使舊字串錨點不再命中。H 13 個原方法、W 15 個原方法皆保留；MUTANTS／golden／語意斷言沒有改。H global if disconnect 從 old 1＋hint 2 改為 old 0＋hint 3，仍切掉同三處；pose 原本是 status 賦值，仍由獨立 pose-edge／pose-kind 控制覆蓋。pose-kind 的替換位置精確移到 `,relation,`，避免變成 no-op。W 三組既有 FEATURE edge／kind 控制只適配實際 API 呼叫。

純靜態預檢已確認 23 組舊控制 before 各恰一次且 after 非 no-op，新 instrumentation／撤回錨點唯一，Python AST 可解析。未聲稱編譯或測試通過；產品已有獨立 `PEER_REVIEW.md`，新增測試交同代理靜審。

供主代理固定新完整 SHA 後執行：

```sh
GITHUB_SHA=<完整SHA> GEO300_REMAINING_HINT_LOG=<持久輸出目錄> python -B -m unittest -v tests.test_geo300_remaining_depend_hint
python -B -m unittest -v tests.test_geo261_load_residual tests.test_geo261_contact_sources
```

第二行沿原所有正反例，不把新七項當舊控制替代。K 舊控制及 H7 原 600／1200 秒守門均保持；本草稿沒有新增 profiling 或執行框架。
