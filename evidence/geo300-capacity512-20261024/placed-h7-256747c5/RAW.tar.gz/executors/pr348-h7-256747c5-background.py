import pathlib,subprocess,json,time,os,sys,shutil,resource,fcntl,hashlib
lock=open('/workspace/geo337-comparison-exclusive.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-h7-256747c5-background');out.mkdir(exist_ok=False)
durable_outer=pathlib.Path('/tmp/pr348-local-h7-256747c5-wrapper');durable_outer.mkdir(exist_ok=False)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='256747c5c8f8f8934eeb08ae404dee1f67591508'
assert json.loads(pathlib.Path('/dev/shm/pr348-remaining-tests/RESULT.json').read_text())['exit']==0
assert json.loads(pathlib.Path('/dev/shm/pr348-graph-622b6654-background/RESULT.json').read_text())['exit']==0
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
assert shutil.disk_usage('/tmp').free>=96*1024*1024
assert shutil.disk_usage('/dev/shm').free>=2*1024*1024*1024
memory_current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());memory_max=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text());assert memory_max-memory_current>=2*1024*1024*1024
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
env={**os.environ,'TMPDIR':'/dev/shm/pr348-h7-256747c5-temp','PYTHONDONTWRITEBYTECODE':'1','GITHUB_SHA':sha};pathlib.Path(env['TMPDIR']).mkdir(exist_ok=False)
observer=pathlib.Path('/dev/shm/pr348-run-formal-local-v7.py');assert hashlib.sha256(observer.read_bytes()).hexdigest()=='417eca03461d3189ac0b786fd8fe0e3839dc2a777256cea501bc0820b240499d'
command=['python3','-B',str(observer),'--root',str(root),'--out','/dev/shm/pr348-h7-256747c5','--durable','/tmp/pr348-local-h7-256747c5-checkpoints','tests.test_geo261_timber_capacity_host']
record={'command':command,'source_sha':sha,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'suite_timeout_seconds':1200,'per_batch_timeout_seconds':600,'stack_bytes':16777216,'guards':'Original run_all.run_process and kill_tree; all test/build/local collection remains inside1200, no paused or extended deadline. Network publication follows terminal result.','capacity_before':{p:shutil.disk_usage(p)._asdict() for p in ('/workspace','/tmp','/dev/shm')},'memory_before':{'current':memory_current,'max':memory_max},'persistent_budget_bytes':32*1024*1024,'unchanged_reserve_bytes':64*1024*1024,'observer_sha256':hashlib.sha256(observer.read_bytes()).hexdigest()}
def save(name,data):
 raw=data if isinstance(data,bytes) else data.encode()
 for directory in (out,durable_outer):
  with (directory/name).open('wb') as file:file.write(raw);file.flush();os.fsync(file.fileno())
save('REQUEST.json',json.dumps(record,indent=2)+'\n')
sys.path.insert(0,str(root));os.chdir(root)
from tests.run_all import run_process
result=run_process(command,env,1200,cwd=root)
save('outer.log',result.out)
record.update(exit=result.code,timed_out=result.timed_out,seconds=result.seconds,reap_note=result.reap_note,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
save('RESULT.json',json.dumps(record,indent=2)+'\n')
raise SystemExit(0 if result.code==0 and not result.timed_out else 1)
