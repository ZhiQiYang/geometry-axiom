import argparse, hashlib, json, os, pathlib, resource, shutil, subprocess, sys, time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);p.add_argument('--count',type=int,default=128);a=p.parse_args()
root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root));os.environ['PYTHONDONTWRITEBYTECODE']='1'
from tests.test_geo261_native_kernel import NativeBuild
from tests.geo300_scene_generator import build
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
class ProfileBuild(NativeBuild):
    def run_build(self,args):
        args=list(args);args.insert(1,'-pg');super().run_build(args)
t=time.monotonic();b=ProfileBuild();exe=b.bridge();shutil.copy2(exe,out/'bridge-pg');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
scene,meta=build(a.count,'single');(out/'input.scene').write_text(scene);(out/'scene-meta.json').write_text(json.dumps(meta,indent=2))
command=['./bridge-pg'];payload=('loadfile '+str(out/'input.scene')+'\ndump\nobjects\nreferences\n').encode();(out/'stdin.bin').write_bytes(payload)
request={'source_sha':source,'command':command,'cwd':str(out),'timeout_seconds':600,'count':a.count,'build_seconds':time.monotonic()-t,'purpose':'O0 separately compiled gprof diagnostic; does not replace original formal tests','binary_sha256':hashlib.sha256((out/'bridge-pg').read_bytes()).hexdigest(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};(out/'REQUEST.json').write_text(json.dumps(request,indent=2))
t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
    proc=subprocess.Popen(command,cwd=out,stdin=subprocess.PIPE,stdout=so,stderr=se)
    try:proc.communicate(payload,timeout=600);timeout=False
    except subprocess.TimeoutExpired:proc.kill();proc.communicate();timeout=True
after=resource.getrusage(resource.RUSAGE_CHILDREN)
result={**request,'actual_exit':proc.returncode,'timeout':timeout,'seconds':time.monotonic()-t,'child_maxrss_kib':after.ru_maxrss,'child_user_seconds':after.ru_utime-before.ru_utime,'child_system_seconds':after.ru_stime-before.ru_stime}
if (out/'gmon.out').exists():
    r=subprocess.run(['gprof','-b',str(out/'bridge-pg'),str(out/'gmon.out')],capture_output=True);(out/'gprof.txt').write_bytes(r.stdout);(out/'gprof.stderr').write_bytes(r.stderr);result['gprof_exit']=r.returncode
for name in ('stdout.bin','stderr.bin','gmon.out','gprof.txt'):
    f=out/name
    if f.exists():result[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(out/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
sys.exit(1 if timeout or proc.returncode else 0)
