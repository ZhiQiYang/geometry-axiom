import fcntl,pathlib,subprocess,os,time,json,shutil
out=pathlib.Path('/dev/shm/pr348-graph-622b6654-background');out.mkdir(exist_ok=False)
lock=open('/workspace/geo337-comparison-exclusive.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
reuse=pathlib.Path('/dev/shm/pr348-reuse-graph-622b6654');reuse.mkdir(exist_ok=False)
old=pathlib.Path('/dev/shm/pr348-reuse-graph-4b17edac')
script=(old/'compare.py').read_text();assert script.count("FIX_SHA = '4b17edac67648fb5f6048b05114a66e99eb1846a'")==1
(reuse/'compare.py').write_text(script.replace("FIX_SHA = '4b17edac67648fb5f6048b05114a66e99eb1846a'","FIX_SHA = '622b665423a55b4042a638589d2cd1efff427c7e'"))
shutil.copy2(old/'BASE_MANIFEST.json',reuse/'BASE_MANIFEST.json')
commands=[['python3','-B','/tmp/pr348-graph-audit/compare_graphs.py','build','--root','/dev/shm/pr348-diagnostic-c754','--sha','622b665423a55b4042a638589d2cd1efff427c7e','--out','/dev/shm/pr348-graph-fix-622b6654','--optimization','O0'],['python3','-B',str(reuse/'compare.py'),'--fix','/dev/shm/pr348-graph-fix-622b6654','--out','/dev/shm/pr348-graph-result-622b6654']]
record={'source_sha':'622b665423a55b4042a638589d2cd1efff427c7e','commands':commands,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'results':[]};(out/'REQUEST.json').write_text(json.dumps(record,indent=2))
for i,command in enumerate(commands):
 t=time.monotonic()
 with (out/(str(i)+'.log')).open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'})
 record['results'].append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-t});(out/'PROGRESS.json').write_text(json.dumps(record,indent=2))
 if r.returncode:break
record.update(exit=r.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));(out/'RESULT.json').write_text(json.dumps(record,indent=2))
