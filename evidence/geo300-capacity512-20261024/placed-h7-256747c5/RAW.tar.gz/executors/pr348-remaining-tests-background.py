import fcntl,pathlib,subprocess,json,time,os
out=pathlib.Path('/dev/shm/pr348-remaining-tests-background');out.mkdir(exist_ok=False)
lock=open('/workspace/geo337-comparison-exclusive.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
root='/dev/shm/pr348-diagnostic-c754';sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='256747c5c8f8f8934eeb08ae404dee1f67591508'
env={**os.environ,'TMPDIR':'/dev/shm/pr348-remaining-tests-temp','PYTHONDONTWRITEBYTECODE':'1','GITHUB_SHA':sha,'GEO300_REMAINING_HINT_LOG':'/dev/shm/pr348-remaining-tests/hint-cases','GEO261_LOAD_RESIDUAL_EXECUTION_LOG':'/dev/shm/pr348-remaining-tests/residual-cases.jsonl'}
pathlib.Path(env['TMPDIR']).mkdir(exist_ok=False)
command=['python3','-B','/tmp/pr348-runs/run_formal_v2.py','--root',root,'--out','/dev/shm/pr348-remaining-tests','tests.test_geo300_remaining_depend_hint','tests.test_geo261_load_residual','tests.test_geo261_contact_sources']
r={'command':command,'source_sha':sha,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid()};(out/'REQUEST.json').write_text(json.dumps(r,indent=2));start=time.monotonic()
with (out/'outer.log').open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
r.update(exit=p.returncode,seconds=time.monotonic()-start,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));(out/'RESULT.json').write_text(json.dumps(r,indent=2))
