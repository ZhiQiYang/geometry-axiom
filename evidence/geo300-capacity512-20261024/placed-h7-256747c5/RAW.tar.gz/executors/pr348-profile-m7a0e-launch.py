import pathlib,subprocess,json,time,os,shutil,resource,fcntl
root=pathlib.Path('/dev/shm/pr348-final-source-7a0e6dd8'); out=pathlib.Path('/dev/shm/pr348-profile-m7a0e-n128-wrapper');out.mkdir(exist_ok=False)
heavy=open('/workspace/geo337-comparison-exclusive.lock','a+');fcntl.flock(heavy,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(); assert sha=='7a0e6dd81c54066995981393925fa46a815de2f8'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
assert shutil.disk_usage('/dev/shm').free>2*1024**3 and shutil.disk_usage('/tmp').free>64*1024**2
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
tmp=pathlib.Path('/dev/shm/pr348-profile-m7a0e-n128-tmp');tmp.mkdir(exist_ok=False)
cmd=['python3','-B','/tmp/pr348-runs/profile_capacity.py','--root',str(root),'--out','/dev/shm/pr348-profile-m7a0e-n128','--count','128']
r={'source':sha,'command':cmd,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'stack':16777216,'capacity':{p:shutil.disk_usage(p)._asdict() for p in ['/tmp','/workspace','/dev/shm']}}
(out/'REQUEST.json').write_text(json.dumps(r,indent=2));t=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 p=subprocess.run(cmd,cwd=root,env={**os.environ,'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'},stdout=so,stderr=se)
r.update(exit=p.returncode,seconds=time.monotonic()-t,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));(out/'RESULT.json').write_text(json.dumps(r,indent=2))
