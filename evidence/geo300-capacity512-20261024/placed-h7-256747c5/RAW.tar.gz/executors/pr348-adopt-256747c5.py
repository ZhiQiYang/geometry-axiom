import pathlib,subprocess,json,time,os
root=pathlib.Path('/dev/shm/pr348-active');out=pathlib.Path('/dev/shm/pr348-adopt-256747c5');out.mkdir(exist_ok=False)
parent='986feab13663b64f3e60658613916602f5b06574';candidate='256747c5c8f8f8934eeb08ae404dee1f67591508';branch='codex/geo300-capacity512-20261024'
rows=[]
def run(command,cwd=root,expected=0):
 p=subprocess.run(command,cwd=cwd,capture_output=True);i=len(rows)
 (out/f'{i:02d}.stdout').write_bytes(p.stdout);(out/f'{i:02d}.stderr').write_bytes(p.stderr)
 rows.append({'command':command,'cwd':str(cwd),'exit':p.returncode});(out/'COMMANDS.json').write_text(json.dumps(rows,indent=2))
 assert p.returncode==expected,(command,p.returncode)
 return p.stdout.decode().strip()
h=json.loads(pathlib.Path('/dev/shm/pr348-h7-256747c5-background/RESULT.json').read_text())
inner=json.loads(pathlib.Path('/dev/shm/pr348-h7-256747c5/RESULT.json').read_text())
assert h['source_sha']==candidate and h['exit']==0 and not h['timed_out'] and h['seconds']<1200
assert inner['exit']==0 and inner['tests_run']==8 and inner['failures']==inner['errors']==inner['skipped']==0
assert run(['git','rev-parse','HEAD'])==parent
assert not run(['git','status','--porcelain','--untracked-files=no'])
assert run(['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==parent
run(['git','merge','--no-ff',candidate,'-m','Integrate validated capacity hot paths and repaired upstream ancestry'])
merged=run(['git','rev-parse','HEAD'])
run(['git','diff','--exit-code',candidate,merged,'--','.',':(exclude)evidence'])
for ancestor in (candidate,'a934a554ae58f16f124f1b264523947f170b3f0b','eaf15e239324a6464a04740647afccce3a3c17c7','8bb0359331365c6f3a96872620427cf7847fcb50'):
 run(['git','merge-base','--is-ancestor',ancestor,merged])
run(['git','-c','pack.window=0','-c','pack.depth=0','push','--no-thin','origin',merged+':refs/heads/'+branch])
assert run(['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==merged
source=pathlib.Path('/dev/shm/pr348-final-source-'+merged[:8]);assert not source.exists()
run(['git','clone','--shared','--no-checkout',str(root),str(source)])
run(['git','sparse-checkout','set','--no-cone','/*','!/evidence/','!/tests/evidence/','!/tests/release-evidence/'],source)
run(['git','-c','core.autocrlf=false','checkout','--detach',merged],source)
assert run(['git','rev-parse','HEAD'],source)==merged
assert not run(['git','status','--porcelain','--untracked-files=all'],source)
result={'source_sha':merged,'candidate_execution_sha':candidate,'previous_evidence_sha':parent,'non_evidence_diff_exit':0,'upstream_ancestors_verified':True,'normal_push_verified':True,'source_checkout':str(source),'h7_original':h,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'exit':0}
(out/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
