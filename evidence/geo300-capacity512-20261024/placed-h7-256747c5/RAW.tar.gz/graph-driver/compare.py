#!/usr/bin/env python3
"""Fixed #348 graph comparison: reuse B receipts; execute only F plain/trace."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

sys.dont_write_bytecode = True
BASE_SHA = '9a8584f57be7935604c3bad4c2481945a6ec3d9f'
FIX_SHA = '622b665423a55b4042a638589d2cd1efff427c7e'
EVIDENCE_SHA = '18c0056d9004353cdd90099ff1fa93fe0d85f841'
EVIDENCE_PATH = 'evidence/geo300-capacity512-20261024/packed-index-b595e559'
EVIDENCE_URL = 'https://github.com/ZhiQiYang/geometry-axiom/tree/' + EVIDENCE_SHA + '/' + EVIDENCE_PATH
MANIFEST_SHA = 'e0bedbdb939114dd3395d89b352275f90356ffe108f4dd827a545036a86d8ad7'
ARCHIVE_SHA = '33a3b5ad029f7d084f38fca9f0453514d1608f556d1c078c02d17e22e27a025d'
DRIVER = Path('/tmp/pr348-graph-audit/compare_graphs.py')
DRIVER_SHA = '29feb8f007f864af7a94ce3e91232aae6ee5defa233cc64123dd3e775837def1'
OLD = Path('/dev/shm/pr348-graph-root-b595')
BASE_BUILD = Path('/tmp/pr348-graph-audit/build-base-v2')
MANIFEST = Path(__file__).with_name('BASE_MANIFEST.json')
RESERVE = 64 * 1024 * 1024


def digest(stream):
    h = hashlib.sha256(); count = 0
    while True:
        block = stream.read(65536)
        if not block: break
        h.update(block); count += len(block)
    return {'bytes': count, 'sha256': h.hexdigest()}


def file_identity(path):
    with path.open('rb') as stream: return digest(stream)


def read(path): return json.loads(path.read_text())


def require(ok, detail):
    if not ok: raise AssertionError(detail)


def main(a):
    out = a.out.resolve(); fix = a.fix.resolve()
    require(out.is_relative_to(Path('/dev/shm')) and fix.is_relative_to(Path('/dev/shm')),
            'New build/output must reside in SHM; no /tmp output')
    out.mkdir(parents=True, exist_ok=False)
    require(file_identity(DRIVER)['sha256'] == DRIVER_SHA, 'original driver changed')
    spec = importlib.util.spec_from_file_location('original_pr348_graph', DRIVER)
    original = importlib.util.module_from_spec(spec); spec.loader.exec_module(original)
    require(original.RESERVE == RESERVE and original.TIMEOUT == 600, 'original guards changed')
    require(file_identity(MANIFEST)['sha256'] == MANIFEST_SHA, 'E18 manifest changed')
    manifest = read(MANIFEST); by_path = {r['path']: r for r in manifest}
    require(len(by_path) == len(manifest), 'duplicate archive manifest path')
    reused = []; problems = []

    # All reused bytes must match the fixed, already-published archive manifest.
    selected = []
    for row in manifest:
        name = row['path']
        if name.startswith('graph-base-build/'):
            local = BASE_BUILD / name.removeprefix('graph-base-build/')
        elif name.startswith('graph-root172/'):
            rel = name.removeprefix('graph-root172/')
            if not (rel in ('INVENTORY.json', 'SUMMARY.json') or rel.startswith('scenes/')
                    or (rel.startswith('cases/') and '/base/' in rel)): continue
            local = OLD / rel
        else: continue
        selected.append((row, local))
        try:
            actual = file_identity(local)
            require(actual == {k: row[k] for k in ('bytes', 'sha256')}, ('archive identity', name))
            reused.append(dict(row, local_path=str(local)))
        except Exception as error: problems.append({'path': name, 'error': repr(error)})
    summary = {'base_execution_sha': BASE_SHA, 'fix_execution_sha': FIX_SHA,
               'base_reuse_evidence_sha': EVIDENCE_SHA, 'base_reuse_url': EVIDENCE_URL,
               'base_manifest_sha256': MANIFEST_SHA, 'base_archive_sha256': ARCHIVE_SHA,
               'original_driver_sha256': DRIVER_SHA, 'started_epoch': time.time(),
               'planned': 172, 'completed': 0, 'failures': problems, 'results': [],
               'state': 'PREFLIGHT', 'exit': None}
    original.save(out / 'SUMMARY.json', summary)
    original.save(out / 'REUSE_FILES.json', reused)
    require(not problems, ('published base files differ or missing', problems))
    inventory = read(OLD / 'INVENTORY.json'); previous = read(OLD / 'SUMMARY.json')
    require(len(inventory) == 172 and len({r['name'] for r in inventory}) == 172, 'original 172 scenes')
    require(previous['exit'] == 0 and previous['state'] == 'COMPLETED'
            and previous['completed'] == previous['planned'] == 172 and not previous['failures'], 'old terminal')
    require(previous['source_shas']['base'] == BASE_SHA, 'base execution source')
    old_build = read(BASE_BUILD / 'BUILD.json'); new_build = read(fix / 'BUILD.json')
    require(old_build['exit'] == new_build['exit'] == 0, 'both builds complete')
    require(old_build['source_sha'] == BASE_SHA and new_build['source_sha'] == FIX_SHA, 'build source SHA')
    require(old_build['trace_definition_sha256'] == new_build['trace_definition_sha256']
            == original.sha(original.trace_definition()), 'trace definition changed')
    pins = {'base': previous['binary_pins']['base'], 'fix': {}}
    for folder, build, role in ((BASE_BUILD, old_build, 'base'), (fix, new_build, 'fix')):
        for mode in ('plain', 'trace'):
            entries = [r for r in build['commands'] if Path(r['command'][r['command'].index('-o') + 1]).name == mode]
            require(len(entries) == 1 and entries[0]['exit'] == 0, (role, mode, 'build command'))
            entry = entries[0]; cmd = entry['command']
            require(cmd[1:3] == ['-std=c11', '-O0'] and cmd[4] == '-o' and cmd[-1] == '-lm'
                    and len(cmd) == 7, (role, mode, 'original monolithic O0 flags'))
            require(file_identity(folder / mode)['sha256'] == entry['binary_sha256'], (role, mode, 'ELF pin'))
            if role == 'base': require(entry['binary_sha256'] == pins['base'][mode], 'original base ELF pin')
            else: pins['fix'][mode] = entry['binary_sha256']
    new_source = read(fix / 'SOURCE.json')
    require(new_source['source_sha'] == FIX_SHA, 'new source manifest SHA')
    for rel, row in new_source['files'].items():
        require(file_identity(Path(new_source['root']) / rel) == {k: row[k] for k in ('bytes', 'sha256')},
                ('new build source changed', rel))
    base_runs = {}; inherited = 0
    for item in inventory:
        name = item['name']; scene = OLD / 'scenes' / name; case = OLD / 'cases' / name / 'base'
        try:
            require(Path(name).name == name and item['source_sha'] == BASE_SHA and 'external_source' not in item,
                    (name, 'root scene source'))
            require(file_identity(scene) == {k: item[k] for k in ('bytes', 'sha256')}, (name, 'scene bytes'))
            payload = ('loadfile ' + str(scene) + '\ndump\n').encode(); runs = {}
            for mode in ('plain', 'trace'):
                request = read(case / mode / 'REQUEST.json'); result = read(case / mode / 'RESULT.json')
                require(all(result.get(k) == v for k, v in request.items()), (name, mode, 'request/result identity'))
                require(request['source_sha'] == BASE_SHA and request['binary_sha256'] == pins['base'][mode]
                        and request['scene_sha256'] == item['sha256'] and request['stdin_sha256'] == original.sha(payload)
                        and request['timeout_seconds'] == 600 and request['stack_bytes'] == 16777216
                        and request['trace'] == (mode == 'trace'), (name, mode, 'original request pins'))
                require(request['command'] == [str(BASE_BUILD / mode)] and request['cwd'] == str(scene.parent),
                        (name, mode, 'original command/cwd'))
                require((case / mode / 'stdin.bin').read_bytes() == payload, (name, mode, 'stdin bytes'))
                require(result['exit'] == 0 and not result.get('stopped_reason') and not result.get('error'),
                        (name, mode, 'old execution failed'))
                for channel in ('stdout', 'stderr'):
                    require(file_identity(case / mode / (channel + '.bin')) == result[channel], (name, mode, channel))
                for key in ('LANG', 'LC_ALL'):
                    require(os.environ.get(key) == request['environment'].get(key), (name, mode, key, 'environment mismatch'))
                if mode == 'trace':
                    with gzip.open(case / mode / 'graph.bin.gz', 'rb') as stream: graph = digest(stream)
                    require(result['graph'].get('complete') and not result['graph'].get('error')
                            and graph == {k: result['graph'][k] for k in ('bytes', 'sha256')}
                            and result.get('gzip_roundtrip_verified') is True, (name, 'full gzip trace'))
                    guards = list(map(int, (case / mode / 'guards.txt').read_text().split()))
                    seals = int((case / mode / 'trace-end.txt').read_text().strip())
                    require(len(guards) == 5 and guards == result['guards'] and min(guards) >= 0
                            and seals == result['seal_count'] and seals >= 0
                            and (seals == 0) == (graph['bytes'] == 0)
                            and result['guards_present'] and result['trace_end_present'], (name, 'all seals/guards'))
                runs[mode] = result
            for channel in ('stdout', 'stderr'):
                require(original.same_file(case / 'plain' / (channel + '.bin'), case / 'trace' / (channel + '.bin')),
                        (name, 'base instrumentation', channel))
            base_runs[name] = runs; inherited += 1
        except Exception as error: problems.append({'scene': name, 'phase': 'base-preflight', 'error': repr(error)})
    require(all(os.environ.get(k) is None for k in ('GEO261_GRAPH', 'GEO261_GUARDS', 'GEO261_TRACE_END')),
            'plain process must not inherit trace output paths')
    # Planning estimate only: retained B case sizes; original 64 MiB reserve stays enforced per run.
    retained = sum(row['bytes'] for row, _ in selected if '/base/' in row['path'])
    free = shutil.disk_usage(out).free; planned = 2 * retained + 16 * 1024 * 1024
    summary.update(binary_pins=pins, base_preflight_cases=inherited,
                   storage={'mount': '/dev/shm', 'free_before': free, 'reserve_bytes': RESERVE,
                            'observed_base_case_bytes': retained, 'planned_new_retained_bytes': planned},
                   failures=problems)
    original.save(out / 'SUMMARY.json', summary)
    require(not problems, ('base preflight failed', problems))
    require(free >= RESERVE + planned, 'SHM cannot retain estimated new raw plus unchanged reserve')
    original.save(out / 'INVENTORY.json', inventory)
    original.save(out / 'NEW_BUILD.json', new_build)
    results = []; failures = []
    for item in inventory:
        name = item['name']; scene = OLD / 'scenes' / name; base = OLD / 'cases' / name / 'base'
        case = out / 'cases' / name / 'fix'; runs = {}; checks = {}; errors = []
        original.capacity(out)
        for mode in ('plain', 'trace'):
            try:
                require(file_identity(fix / mode)['sha256'] == pins['fix'][mode], (mode, 'new ELF changed'))
                runs[mode] = original.run(fix / mode, scene, case / mode, FIX_SHA, mode == 'trace')
                require(original.same_file(base / mode / 'stdin.bin', case / mode / 'stdin.bin'), 'new stdin differs')
            except Exception as error:
                errors.append({'mode': mode, 'error': repr(error)})
                receipt = case / mode / 'RESULT.json'
                if receipt.exists(): runs[mode] = read(receipt)
        if not errors:
            for channel in ('stdout', 'stderr'):
                checks['fix_instrumentation_' + channel] = original.same_file(case / 'plain' / (channel + '.bin'), case / 'trace' / (channel + '.bin'))
                checks[channel] = original.same_file(base / 'plain' / (channel + '.bin'), case / 'plain' / (channel + '.bin'))
            checks['ordered_graph_all_seals'] = original.same_graph(base / 'trace' / 'graph.bin.gz', case / 'trace' / 'graph.bin.gz')
            checks['five_guards_raw'] = original.same_file(base / 'trace' / 'guards.txt', case / 'trace' / 'guards.txt')
            checks['seal_counts'] = base_runs[name]['trace']['seal_count'] == runs['trace']['seal_count']
        failures += [{'scene': name, 'check': k} for k, v in checks.items() if not v]
        failures += [dict(scene=name, phase='new-execution', **error) for error in errors]
        results.append({'scene': name, 'base_execution_sha': BASE_SHA, 'base_receipt': str(base),
                        'fix_execution_sha': FIX_SHA, 'checks': checks, 'new_runs': runs, 'errors': errors})
        summary.update(completed=len(results), results=results, failures=failures, state='RUNNING')
        original.save(out / 'SUMMARY.json', summary)
        print('CASE', len(results), '/172', name, 'PASS' if checks and all(checks.values()) and not errors else 'FAIL', flush=True)
    summary.update(state='COMPLETED', exit=1 if failures else 0, ended_epoch=time.time())
    original.save(out / 'SUMMARY.json', summary)
    return summary['exit']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fix', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try: code = main(args)
    except Exception as error:
        path = args.out.resolve() / 'SUMMARY.json'
        if path.exists():
            current = read(path); current.update(state='FAILED', exit=1, error=repr(error), ended_epoch=time.time())
            path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + '\n')
        raise
    raise SystemExit(code)
