from pathlib import Path
import ast
import difflib
import hashlib
import importlib.util
import json
import os

BASE = Path('/workspace/geo300-capacity512-companion-draft-20261024')
OUT = Path('/workspace/geo300-capacity512-companion-static-peer-20261024')
REPO = Path('/workspace/geo300-contact-index-work')
S = '39273bc0229fbbb16565134e1f8fad3a0d598c31'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('capture', CAP)
c = importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
rec = c.Recorder(OUT / 'original-source-capture', dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), S)
checks = []
def check(name, value, detail=''):
    checks.append(dict(name=name, passed=bool(value), detail=detail))
def sha(data):
    return hashlib.sha256(data).hexdigest()
manifest = json.loads((BASE / 'MANIFEST.json').read_text())
check('fixed-source-and-four-leaf-scope', manifest['source_sha']==S and len(manifest['files'])==4)
patch = (BASE / 'COMPANION_PARTIAL.patch').read_bytes()
check('frozen-companion-patch-pin', sha(patch)==manifest['patch_sha256']=='722796a9a215eecf36553d9e5405dcb122e0db408536c3be1d305209a49cf7f8')
rebuilt = []
for item in manifest['files']:
    rel=item['path'];new=(BASE/'candidate'/rel).read_bytes()
    check('after-pin:'+rel, len(new)==item['after_bytes'] and sha(new)==item['after_sha256'])
    if item['new_file']:
        before=b''
    else:
        row, so, se = rec.run(['git','--no-optional-locks','show',f'{S}:{rel}'],cwd=REPO,
                             timeout=30,check=False,source_variant='independent-fixed-S-original')
        check('original-git-exit:'+rel,row['actual_process_returncode']==0)
        before=(Path(row['directory'])/'stdout.bin').read_bytes()
        check('original-git-bytes:'+rel,before==(BASE/'before'/rel).read_bytes())
    check('before-pin:'+rel,len(before)==item['before_bytes'] and sha(before)==item['before_sha256'])
    rebuilt.extend(difflib.unified_diff(before.decode().splitlines(True),new.decode().splitlines(True),
                                       fromfile='/dev/null' if item['new_file'] else 'a/'+rel,tofile='b/'+rel))
check('patch-exactly-rebuilds-four-candidate-leaves',''.join(rebuilt).encode()==patch)
product=Path(manifest['product_patch_dependency']).read_bytes()
check('fixed-seven-leaf-product-dependency',sha(product)==manifest['product_patch_sha256']=='f2d8202f035e334ec0033192793d0751db75ef1fa320110a903b3495b84230ae')
source_paths=[
    'geometry-templates/woodworking/native/cut_list.c',
    'geometry-templates/woodworking/native/contact_world.c',
    'geometry-templates/woodworking/native/member_declaration.c',
    'geometry-templates/woodworking/native/world_validation.c',
    'geometry-templates/woodworking/native/members.c',
    'tests/test_geo261_native_kernel.py',
]
sources={}
for rel in source_paths:
    row,so,se=rec.run(['git','--no-optional-locks','show',f'{S}:{rel}'],cwd=REPO,
                       timeout=30,check=False,source_variant='independent-fixed-S-control-and-builder')
    check('source-command-zero:'+rel,row['actual_process_returncode']==0)
    p=Path(row['directory'])/'stdout.bin';sources[rel]=dict(path=str(p),sha256=sha(p.read_bytes()))
candidate = BASE/'candidate/tests'
python=(candidate/'test_geo261_timber_capacity.py').read_text()
tree=ast.parse(python)
methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
check('seven-test-methods-ast-only',methods==manifest['methods_ast_only'] and len(methods)==7)
check('no-new-numeric-time-budget','timeout=10' in python and 'timeout=60' not in python)
check('negative-controls-require-exact-normal-exit-and-marker',
      'self.assertEqual(1 if marker else 0,result.returncode,result.stderr)' in python and
      'self.assertEqual("ASSERT:"+marker+"\\n" if marker else "",result.stderr)' in python)
check('original-nativebuild-import-and-isolated-source-use',
      'from tests.test_geo261_native_kernel import native' in python and
      'source=build.woodworking/"timber-capacity-client.c"' in python)
check('guard-controls-one-anchor-and-baseline-restoration',
      'self.assertEqual(1,source.count(before)' in python and
      'self.case(case,exe,marker);self.case(case)' in python)
check('values-only-object-links-no-W-H-object',
      'build.link("timber-capacity-values-64",[client])' in python and
      'build.link("timber-capacity-values-restored",[client])' in python and
      'finally:header.write_bytes(original)' in python)
contact_old=(BASE/'before/tests/geo261_contact_world_harness.c').read_text()
contact_new=(candidate/'geo261_contact_world_harness.c').read_text()
check('original-64-member-272-face-witness-preserved',
      contact_old.replace('WOOD_CONTACT_FACE_CAPACITY==2432','WOOD_CONTACT_FACE_CAPACITY==3328')
                 .replace('WOOD_CONTACT_MEMBER_CAPACITY==64','WOOD_CONTACT_MEMBER_CAPACITY==512')==contact_new)
report=(candidate/'geo261_report_policy_harness.c').read_text()
check('64-report-boundary-and-id63-still-explicit',
      'wood_cut_list_collect(values,64,&result)' in report and 'first+63]==63' in report)
check('true-513-input-no-one-past-fixture',
      'WoodMember values[513]' in report and 'wood_cut_list_collect(values,513,&result)' in report)
harness=(candidate/'geo261_timber_capacity_harness.c').read_text()
check('full-member-declare-only-existing-id',
      'wood_member_declare(&context,512,22,33' in harness and
      'wood_member_declare(&context,513' not in harness)
check('validation-negative-callback-stops-before-fixed-array-write',
      'fixture.calls=0;fixture.stop_first=true;context.member_count=513;' in harness and
      'if(fixture->stop_first)return false;' in harness)
check('validation-512-fixture-is-explicitly-unplaced',
      'ValidationFixture fixture={0}' in harness and
      'fixture.members[i].id=(uint32_t)(i+1)' in harness)
ids=[1000+(i*73)%513 for i in range(513)]
check('report-ids-are-distinct-and-not-monotonic',len(set(ids))==513 and ids!=sorted(ids))
check('report-independent-total-length',sum(range(1,513))==131328)
orders=[(2**64-1-i//2,i) for i in range(512)]
sorted_indices=[i for _,i in sorted(orders,key=lambda p:p[0])]
expected=[510-2*(i//2)+i%2 for i in range(512)]
check('contact-stable-uint64-order-oracle',sorted_indices==expected and sorted(expected)==list(range(512)))
fallback=[i for _,i in sorted([(2**64-1-i,i) for i in range(513)])]
check('public-fallback-reverse-oracle',fallback==list(range(512,-1,-1)))
readme=(BASE/'README.md').read_text()
check('partial-unrun-and-H-ABI-gaps-explicit','UNRUN' in readme and '尚缺：H 真 CLI' in readme and '不能冒完整 64/512 ABI 驗收' in readme)
report=dict(source_sha=S,companion_sha256=sha(patch),checks=checks,
            passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),
            findings=[],compiled=False,imported_subject=False,runtime_execution=False,
            scope='Independent static review of frozen partial external companion only',
            source_inputs=sources,
            limits=[
                'All C outcomes and named assertion paths remain unobserved until formal execution.',
                '512 validation fixture contains unplaced members; it is not full placed-world geometry validation.',
                'values-only 64 withdrawal proves constant/storage translation unit only, not mixed-H/W ABI acceptance.',
                'Host CLI/bridge, all capacity references, registry/expected/architecture and performance still require completion.',
            ])
c.dump(OUT/'REVIEW.json',report)
print(json.dumps(dict(passed=report['passed'],failed=report['failed'],findings=report['findings'],runtime_execution=False)))
raise SystemExit(bool(report['failed']))
