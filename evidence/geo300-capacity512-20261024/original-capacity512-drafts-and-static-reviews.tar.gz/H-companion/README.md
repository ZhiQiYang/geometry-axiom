# 512 H／ABI companion 外部候選；尚未套用與執行

本稿接前一份 W companion 7 方法，本稿另 5 方法；使用既有 NativeBuild、真 web_bridge translation unit 與原 BridgeSession，沒有替身 World。實際編譯、bridge、反證與 unittest discovery 都是 UNRUN。

- 真 bridge 逐筆宣告 1～512，在 64／65／511／512 分別檢完整 ID 清單，保留原 64 正例；真 513 新 ID 拒絕後完整 dump JSON（含 revision/hash）不變。
- 滿載重宣告、失敗後 undo／redo、重放 byte identity 分開驗；這裡都是未放置成員，不代表 512 支已合法放入幾何世界。
- 產品 guard 撤回後，只送 512 個合法宣告，再送缺 ID 的 `timber`。檢查原容量優先訊息；撤回時應在語法拒絕處自然返回，用指定 AssertionError 證明不同，沒有第 513 append。v2 把捕獲的原 exception message 明列為 `framework-assertion` 轉送 stdout。此 Python helper 內部預期 AssertionError 不是子程序退出碼 1；正式反證收據須分欄記錄。
- 七組 ABI control 在私有完整 quoted-include closure 改單一容量，編譯真 H：host64、timbers64、anchors64、contact64、cut-list64、span64、face少1。必須有真正非零 compiler exit 與相應具名 typedef 診斷，恢復同原 bytes 後重新編譯為0。這些是預期的編譯契約拒絕，不冒正常 runtime killed。變異 object 不連結、不執行，真 bridge 全部物件共用正常512 headers。
- 原 10 秒 C 值檢查、NativeBuild 300 秒編譯與原16MiB連結設定、BridgeSession行為原樣。未新增 wall-time 門檻。

`REGISTRY_PLAN.json` 列出後續實作的唯一新增 PY_NEEDS/expected keys；只有實際新基底上 discovery 證實7/5後才能認驗收數量。必須先一般 merge #128 P2 公開 `324034812bb6effca68e0413bc0468595337b317`，保 `test_geo261_panel_native=13`，不可把 #346 原 expected 蓋回去。合入順序為 #343 → #346 → P2 → 512。

所有 registry／架構／文件與全量帳本仍由主代理依最終來源整合，沒有以本外部草稿變更任何分支。待本稿獨立靜審及 #346 原11/9完成後，再按主代理授權開真正512分支；現階段不是可合併成果。
