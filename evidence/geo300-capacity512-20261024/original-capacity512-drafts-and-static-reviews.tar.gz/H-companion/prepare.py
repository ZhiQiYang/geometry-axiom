from pathlib import Path
import ast,difflib,hashlib,json,datetime,subprocess
BASE=Path(__file__).resolve().parent
REPO=Path('/workspace/geo300-contact-index-work')
S='39273bc0229fbbb16565134e1f8fad3a0d598c31'
P2='324034812bb6effca68e0413bc0468595337b317'
def h(data):return hashlib.sha256(data).hexdigest()
rows=[];patch=[]
for path in sorted((BASE/'candidate').rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(BASE/'candidate').as_posix();raw=path.read_bytes()
    row={'path':rel,'new_file':True,'bytes':len(raw),'sha256':h(raw)}
    if path.suffix=='.py':
        tree=ast.parse(raw);row['test_methods_ast_only']=[f.name for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')]
        assert len(row['test_methods_ast_only'])==5
    patch.extend(difflib.unified_diff([],raw.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+rel))
    rows.append(row)
raw=''.join(patch).encode();(BASE/'HOST_COMPANION.patch').write_bytes(raw)
registry={'schema':'capacity512-registration-plan/1','status':'DESIGN_ONLY_NOT_APPLIED','merge_order':['#343','#346','codex/issue128-empty-panel-rows-20261024','#300 capacity512 new branch'],
    'next_base_required_to_merge':P2,'source_for_existing_512_drafts':S,'new_modules':{
        'test_geo261_timber_capacity':{'PY_NEEDS':[],'expected':{'mode':'count','count':7,'unit':'test'}},
        'test_geo261_timber_capacity_host':{'PY_NEEDS':[],'expected':{'mode':'count','count':5,'unit':'test'}}},
    'preconditions':['Read PY_NEEDS by AST; both new keys must be absent before addition.',
        'Both new files actual unittest discovered counts must equal AST7/5 before publishing expected acceptance.',
        'Base py:test_geo261_panel_native must be 13 from P2, not overwritten back to10.',
        'Base py:test_geo261_wood_report_policy must remain11; old64 examples and all9controls remain.',
        'Every existing expected suite/value retained exactly; only add two new entries.',
        'No change to tests/mutate.py or full ledger; root owns final regeneration.',
        'Architecture3original judges/receipt input closure and final formal impact checks still required.'],
    'count_basis':'New unittest class methods only; not runtime discovery or passed tests.'}
(BASE/'REGISTRY_PLAN.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
git=[]
for rel in ['tests/_bridge.py','tests/test_geo261_wood_world_validation.py','tests/test_geo261_native_kernel.py','tests/run_all.py','tests/run_all.expected.json']:
    result=subprocess.run(['git','--no-optional-locks','show',S+':'+rel],cwd=REPO,capture_output=True)
    assert result.returncode==0
    dest=BASE/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(result.stdout)
    git.append({'argv':['git','--no-optional-locks','show',S+':'+rel],'exit':0,'stdout':str(dest),'stdout_bytes':len(result.stdout),'stdout_sha256':h(result.stdout),'stderr':result.stderr.decode()})
report={'source_sha':S,'future_base_merge':P2,'patch_sha256':h(raw),'files':rows,'source_reads':git,
    'runtime_methods_ast_only':5,'compile_contract_controls_design_only':7,'safe_bridge_withdrawal_design_only':1,
    'existing_W_partial_companion':'/workspace/geo300-capacity512-companion-draft-20261024/COMPANION_PARTIAL.patch',
    'existing_W_partial_sha256':'722796a9a215eecf36553d9e5405dcb122e0db408536c3be1d305209a49cf7f8',
    'not_run':['C compile/link','bridge declarations/transaction/replay','7 compile-contract failures','safe host normal assertion withdrawal','unittest discovery','registry edits','512 placed world','stack measurement','formal gates'],
    'safety_scope':['Withdrawn host is sent at most512 valid declarations then missing-id timber; never valid513 append.',
        'Only private cloned H closure is drifted for ABI compile controls; rejected objects never linked/run.',
        'Real bridge uses one NativeBuild512 W/H closure, normal10-second process witness/unchanged bridge helper.',
        'No SSOT, decision, performance threshold, branch or repository file change.'],
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(BASE/'MANIFEST.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(rows),'methods_ast_only':5,'compile_controls_design_only':7,'patch_sha256':h(raw),'subject':'UNRUN'}))
