from pathlib import Path
import ast,hashlib,json,difflib,subprocess
OUT=Path(__file__).resolve().parent/'registry-plan'
OUT.mkdir(exist_ok=True)
REPO=Path('/workspace/issue128-empty-panel-rows-work-20261024')
S='324034812bb6effca68e0413bc0468595337b317'
changes={};reads=[]
for path in ['tests/run_all.py','tests/run_all.expected.json']:
    result=subprocess.run(['git','--no-optional-locks','show',S+':'+path],cwd=REPO,capture_output=True)
    assert result.returncode==0
    changes[path]=[result.stdout,None]
    target=OUT/'before'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result.stdout)
    reads.append({'argv':['git','--no-optional-locks','show',S+':'+path],'exit':0,'stdout':str(target),'stderr':result.stderr.decode()})
py=changes['tests/run_all.py'][0]
marker=b"    'test_geo261_wood_report_policy': [],\n"
assert py.count(marker)==1
tree=ast.parse(py)
needs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PY_NEEDS' for t in n.targets))
for name in ['test_geo261_timber_capacity','test_geo261_timber_capacity_host']:assert name not in needs
changes['tests/run_all.py'][1]=py.replace(marker,marker+b"    'test_geo261_timber_capacity': [],\n    'test_geo261_timber_capacity_host': [],\n")
expected=json.loads(changes['tests/run_all.expected.json'][0]);before=json.loads(changes['tests/run_all.expected.json'][0])
assert expected['suites']['py:test_geo261_panel_native']['count']==13
assert expected['suites']['py:test_geo261_wood_report_policy']['count']==11
for key,count in [('py:test_geo261_timber_capacity',7),('py:test_geo261_timber_capacity_host',5)]:
    assert key not in expected['suites']
    expected['suites'][key]={'mode':'count','count':count,'unit':'test'}
expected['suites']=dict(sorted(expected['suites'].items()))
assert all(expected['suites'][key]==value for key,value in before['suites'].items())
assert {k:v for k,v in expected.items() if k!='suites'}=={k:v for k,v in before.items() if k!='suites'}
changes['tests/run_all.expected.json'][1]=(json.dumps(expected,ensure_ascii=False,indent=2)+'\n').encode()
patch=[];files=[]
for path,(old,new) in changes.items():
    target=OUT/'candidate'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(new)
    patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    files.append({'path':path,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest()})
raw=''.join(patch).encode();(OUT/'REGISTRY_ONLY.patch').write_bytes(raw)
report={'base_sha':S,'scope':'External proposed registration diff only. AST planned counts, not discovery, no source or branch changes.',
    'new_count_plans':[7,5],'P2_count13_preserved':True,'report_count11_preserved':True,'all_existing_suites_preserved':True,
    'requires':'Apply only after general-merge of actual P2 branch and runtime discovered counts verified; rederive against newer base if any sibling entry changes.',
    'files':files,'source_reads':reads,'patch_sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'MANIFEST.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'patch_sha256':report['patch_sha256'],'subject':'UNRUN'}))
