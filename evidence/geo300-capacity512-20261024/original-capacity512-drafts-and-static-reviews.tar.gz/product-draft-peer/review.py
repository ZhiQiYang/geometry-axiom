from pathlib import Path
import json,hashlib,re
D=Path(__file__).parent;P=Path('/tmp/geo300-capacity512-draft-v1-20261024');checks=[];find=[];H=lambda b:hashlib.sha256(b).hexdigest()
def ck(n,x):
 checks.append({'name':n,'passed':bool(x)})
 if not x:find.append(n)
ck('manifest-pin',H((P/'MANIFEST.json').read_bytes())=='98dad06f64d7b826eb7851cf6eff717d9805a90318e598ae4eb5d74aa00ebac2');ck('patch-pin',H((P/'PRODUCT_ONLY.patch').read_bytes())=='f2d8202f035e334ec0033192793d0751db75ef1fa320110a903b3495b84230ae');ck('plan-pin',H((P/'TEST_PLAN.md').read_bytes())=='5a58a0da4d8b7f4a63cdf2799d3bcd67e75aff838db2c8f9785dfaa4e24f3507')
m=json.loads((P/'MANIFEST.json').read_text());ck('only-seven-product-files',len(m['files'])==7 and {r['path']for r in m['files']}=={'current_geometry.c',*['geometry-templates/woodworking/native/'+s for s in ['members.h','document.h','contact_world.h','cut_list.h','member_reference.h','world_validation.c']]})
for r in m['files']:
 a=(P/'before'/r['path']).read_bytes();b=(P/'candidate'/r['path']).read_bytes();ck('before-pin:'+r['path'],H(a)==r['before_sha256']and len(a)==r['before_bytes']);ck('Git-before:'+r['path'],hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest()==r['blob_oid']);x=a
 for n,e in enumerate(r['edits']):
  old=bytes.fromhex(e['before_hex']);new=bytes.fromhex(e['after_hex']);ck('anchor-unique:'+r['path']+str(n),x.count(old)==e['matches']==1);x=x.replace(old,new,1)
 ck('exact-declared-edits:'+r['path'],x==b and H(b)==r['after_sha256'] and len(b)==r['after_bytes'])
 if r['path']=='current_geometry.c':ck('CRLF-preserved',a.count(b'\r\n')==a.count(b'\n')and b.count(b'\r\n')==b.count(b'\n'))
get=lambda n:(P/'candidate'/'geometry-templates/woodworking/native'/n).read_text();host=(P/'candidate/current_geometry.c').read_text()
ck('single-fixed-master',get('members.h').count('#define WOOD_MEMBER_CAPACITY 512')==1 and 'WOOD_MEMBER_CAPACITY ='not in get('document.h'))
for p,macro in [('contact_world.h','WOOD_CONTACT_MEMBER_CAPACITY'),('cut_list.h','WOOD_CUT_LIST_MEMBER_CAPACITY'),('member_reference.h','WOOD_MEMBER_SPAN_MEMBER_CAPACITY')]:ck('alias:'+macro,'#define '+macro+' WOOD_MEMBER_CAPACITY'in get(p))
ck('host-alias','#define WORLD_MAX_TIMBERS     WOOD_MEMBER_CAPACITY'in host);ck('seven-extra-compatible-guards',len(re.findall(r'typedef char app_timber_capacity_\w+\[',host))==7 and host.count('typedef char app_span_status_abi_check[')==1 and host.count('typedef char app_span_scratch_bound_check[')==1)
ck('guard-before-first-callback',get('world_validation.c').index('if(context->member_count>WOOD_CONTACT_MEMBER_CAPACITY)')<get('world_validation.c').index('const WoodGridState *grids=context->grids.state;'))
ck('apply-check-record-only',json.loads((P/'APPLY_CHECK.json').read_text())['exit']==0 and (P/'apply-check.stdout').read_bytes()==b''and(P/'apply-check.stderr').read_bytes()==b'')
t=(P/'TEST_PLAN.md').read_text();ck('product-only-not-ready','單獨不構成可合入補丁'in t and'UNRUN'in t);ck('original-fixtures-and-controls-preserved','n272'in t and'placed64/count64/ID63'in t and'原12 methods／41 controls 全保'in t);ck('shared-ABI-recompile','恢復後也重編，不混64/512 ABI'in t);ck('master64-runtime-independent','編譯仍合法，必由獨立512 runtime ASSERT'in t);ck('no-new-performance-threshold','N128/256/512額外比值／2MiBstackmargin均不在這個draft'in t)
# The product patch is statically scoped, but this version does not bind the host guard withdrawal to a safe no-append case.
ck('host-over-capacity-mutant-explicit-safe-pre-append-entry','host-only-capacity-sentinel'in t or '直接呼叫 wood_member_declaration_capacity'in t)
o={'scope':'Seven exact external product-only candidate files/CRLF/declared hex edits, original compatible compile guards/header include preflight already reviewed; no C/imports/patch application/source mutation. Test-plan only, no executable approval.','source_sha':m['source_sha'],'checks':checks,'findings':find,'finding_details':{'host-over-capacity-mutant-explicit-safe-pre-append-entry':'member_declaration.c wood_member_declare writes members[*count] without another capacity guard. A valid 513th full parser declaration after removing the sole admission guard can write OOB. Bind the guard control to direct capacity API result or a capacity-first malformed parser sentinel before append; valid 513th full-path negative runs fixed/restored only. World-validation safe callback is already explicit.'}};(D/'CHECKS.initial-v1.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(len(checks),len(find),H((D/'CHECKS.initial-v1.json').read_bytes()),find)
