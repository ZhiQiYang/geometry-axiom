from pathlib import Path
import ast,hashlib,importlib.util,json,os,shutil,subprocess
from urllib.parse import urlparse
HERE=Path(__file__).resolve().parent;OUT=HERE/'source-preparation'
R=Path('/workspace/geo300-capacity512-work-20261024');OWNER=Path('/workspace/issue128-empty-panel-rows-work-20261024')
BASE='6d9d46e8d16af75351924c6d47a078d3eb647cc0';MERGE='eaf15e239324a6464a04740647afccce3a3c17c7'
BR='codex/geo300-capacity512-20261024'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(v,m):
    if not v:raise RuntimeError(m)
patches=[
 ('/tmp/geo300-capacity512-draft-v1-20261024/PRODUCT_ONLY.patch','f2d8202f035e334ec0033192793d0751db75ef1fa320110a903b3495b84230ae'),
 ('/workspace/geo300-capacity512-companion-draft-20261024/COMPANION_PARTIAL.patch','722796a9a215eecf36553d9e5405dcb122e0db408536c3be1d305209a49cf7f8'),
 ('/workspace/geo300-capacity512-host-draft-20261024/HOST_COMPANION.patch','4bc379898588428579170a4776a12efe90c172a5855f41997a31e1ce4d8ca115'),
 ('/workspace/geo300-capacity512-host-draft-20261024/registry-plan/REGISTRY_ONLY.patch','125109ffaf67c1a7cb16fbc2316e0a102968027f88bf9588a6e73620f0e7551c')]
for p,pin in patches:need(h(p)==pin,'accepted patch pin '+p)
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');need(h(cap)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','recorder')
spec=importlib.util.spec_from_file_location('c387',cap);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
need(not R.exists() and not OUT.exists(),'fresh private repository');need(shutil.disk_usage('/workspace').free>=64*1024*1024,'creation disk guard')
OUT.mkdir(parents=True);r=c.Recorder(OUT,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),BASE)
def run(argv,data=None,cwd=None):return r.run(argv,cwd=cwd or R,data=data,timeout=180,source_sha=BASE,source_variant='capacity512 static source preparation; no compiler or test executed')
origin=subprocess.check_output(['git','config','--get','remote.origin.url'],cwd=OWNER).decode().strip();url=urlparse(origin)
need(url.scheme=='https' and not url.username and not url.password and url.path.endswith('/ZhiQiYang/geometry-axiom.git'),'safe origin')
run(['git','init',str(R)],cwd='/workspace')
(R/'.git/objects/info/alternates').write_text(str(OWNER/'.git/objects')+'\n')
for key,value in [('gc.auto','0'),('maintenance.auto','false'),('user.name','Codex'),('user.email','codex@openai.com'),('core.sparseCheckout','true'),('core.sparseCheckoutCone','false')]:run(['git','config',key,value])
run(['git','remote','add','origin',origin])
paths=['AGENTS.md','current_geometry.c','geometry-templates/woodworking/native/contact_world.h','geometry-templates/woodworking/native/cut_list.h','geometry-templates/woodworking/native/document.h','geometry-templates/woodworking/native/member_reference.h','geometry-templates/woodworking/native/members.h','geometry-templates/woodworking/native/world_validation.c','tests/geo261_contact_world_harness.c','tests/geo261_report_policy_harness.c','tests/geo261_timber_capacity_harness.c','tests/test_geo261_timber_capacity.py','tests/geo261_timber_capacity_host_harness.c','tests/test_geo261_timber_capacity_host.py','tests/run_all.py','tests/run_all.expected.json']
(R/'.git/info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in paths))
run(['git','checkout','-b',BR,BASE])
run(['git','merge','--no-ff','--no-edit',MERGE])
_,merge,_=run(['git','rev-parse','HEAD']);M=merge.decode().strip()
_,changes,_=run(['git','diff','--name-only',BASE,M]);need(all(p.startswith('evidence/geo300-cut-list-storage-20261024/') for p in changes.decode().splitlines()),'merge only #346 evidence beyond P2')
_,clean,_=run(['git','status','--porcelain']);need(not clean,'clean ordinary merge')
for patch,pin in patches:
    run(['git','apply','--check',patch]);run(['git','apply',patch])
run(['git','diff','--check'])
_,diff,_=run(['git','diff','--binary']);(OUT/'CANDIDATE_TRACKED.diff').write_bytes(diff)
expected=json.loads((R/'tests/run_all.expected.json').read_text())['suites']
need(expected['py:test_geo261_panel_native']['count']==13 and expected['py:test_geo261_wood_report_policy']['count']==11,'P2/report counts preserved')
methods={}
for file,n in [('tests/test_geo261_timber_capacity.py',7),('tests/test_geo261_timber_capacity_host.py',5)]:
    tree=ast.parse((R/file).read_bytes());methods[file]=sum(isinstance(f,ast.FunctionDef) and f.name.startswith('test_') for cl in tree.body if isinstance(cl,ast.ClassDef) for f in cl.body)
    need(methods[file]==n,'fixed AST method count')
need(b'\r\n' in (R/'current_geometry.c').read_bytes() and (R/'current_geometry.c').read_bytes().count(b'\n')==(R/'current_geometry.c').read_bytes().count(b'\r\n'),'host CRLF preserved')
report={'branch':BR,'base_sha':BASE,'ordinary_merge_input':MERGE,'ordinary_merge_sha':M,'patches':[{'path':p,'sha256':pin} for p,pin in patches],'candidate_files':{p:{'bytes':(R/p).stat().st_size,'sha256':h(R/p)} for p in paths if p!='AGENTS.md'},'methods_ast_only':methods,'compiled':False,'formal': 'UNRUN','ledger':'UNRUN; root only','architecture':'UNRUN','worktree':str(R),'free_after':{p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']},'commands':r.rows}
(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'merge_sha':M,'candidate_leaves':len(report['candidate_files']),'methods_ast_only':methods,'compiled':False,'free_workspace':report['free_after']['/workspace']}))
