from pathlib import Path
import hashlib,importlib.util,json,os
H=Path(__file__).resolve().parent;R=Path('/workspace/geo300-capacity512-work-20261024');OUT=H/'source-publication'
M='696f7f07846c6224775dab5736bd1dc45541a4bf';BR='codex/geo300-capacity512-20261024'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(v,m):
    if not v:raise RuntimeError(m)
peer=Path('/workspace/geo300-capacity512-applied-source-peer-20261024/REVIEW.json');need(h(peer)=='92940968f878ca9f30475c397f9bbbf61f537e135e6cb60486d2e728ee20698b','accepted exact applied peer')
manifest=json.loads((H/'source-preparation/RESULT.json').read_text());files=manifest['candidate_files']
for rel,info in files.items():need(h(R/rel)==info['sha256'],'unchanged accepted candidate '+rel)
cap=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');need(h(cap)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','recorder')
spec=importlib.util.spec_from_file_location('c387',cap);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
OUT.mkdir(exist_ok=False);rec=c.Recorder(OUT,dict(os.environ),M)
def run(argv,data=None):return rec.run(argv,cwd=R,data=data,timeout=180,source_sha=M,source_variant='accepted capacity512 candidate publication; runtime UNRUN')
report={'branch':BR,'ordinary_merge_sha':M,'peer':str(peer),'peer_sha256':h(peer),'formal':'UNRUN','compiled':False,'published':False,'commands':rec.rows}
try:
    _,head,_=run(['git','rev-parse','HEAD']);need(head.decode().strip()==M,'fixed merge parent')
    _,remote,_=run(['git','ls-remote','--heads','origin','refs/heads/'+BR]);need(not remote,'new own branch')
    run(['git','add','-f','--',*sorted(files)])
    _,names,_=run(['git','diff','--cached','--name-only','-z']);need(set(names.rstrip(b'\0').split(b'\0'))=={p.encode() for p in files},'exact accepted 15 leaves')
    run(['git','diff','--cached','--check'])
    run(['git','commit','-m','feat(GEO-300): bind timber capacity to 512 across host and template'])
    _,head,_=run(['git','rev-parse','HEAD']);S=head.decode().strip();report['product_sha']=S
    for rel,info in files.items():
        _,raw,_=run(['git','show',S+':'+rel]);need(hashlib.sha256(raw).hexdigest()==info['sha256'],'committed exact accepted bytes '+rel)
    run(['git','push','origin','refs/heads/'+BR+':refs/heads/'+BR])
    _,remote,_=run(['git','ls-remote','--heads','origin','refs/heads/'+BR]);need(remote.decode().split()==[S,'refs/heads/'+BR],'public S exact')
    _,clean,_=run(['git','status','--porcelain']);need(not clean,'clean final source')
    report.update(published=True,exit_code=0)
finally:(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'product_sha':S,'normal_push':True,'exit':0,'formal':'UNRUN'}))
