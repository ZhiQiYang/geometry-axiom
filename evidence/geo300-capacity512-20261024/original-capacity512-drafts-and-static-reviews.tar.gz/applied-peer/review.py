from pathlib import Path
import ast,hashlib,importlib.util,json,os
ROOT=Path('/workspace/geo300-capacity512-work-20261024')
OUT=Path('/workspace/geo300-capacity512-applied-source-peer-20261024')
PREP=Path('/workspace/geo300-capacity512-publication-20261024/source-preparation/RESULT.json')
M='696f7f07846c6224775dab5736bd1dc45541a4bf';P='6d9d46e8d16af75351924c6d47a078d3eb647cc0';Q='eaf15e239324a6464a04740647afccce3a3c17c7'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
rec=cap.Recorder(OUT/'original-git-r2',dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),M)
checks=[]
def check(name,value):checks.append({'name':name,'passed':bool(value)})
def git(*args):
 row,so,se=rec.run(['git',*args],cwd=ROOT,timeout=60,check=False,source_variant='read-only-independent-applied-source-review-no-subject')
 check('git-zero:'+str(args),row['actual_process_returncode']==0);return so
config={p:sha((ROOT/'.git'/p).read_bytes())for p in ('index','config','HEAD')}
prep=json.loads(PREP.read_bytes())
check('preparation-pin',sha(PREP.read_bytes())=='22175c55fa99e27bbee6062212e9b1a5b9fa3c5c05a07bdbf43f95bc644c0a29')
check('two-parent-normal-merge',git('show','-s','--format=%H %P','HEAD').decode().strip()==M+' '+P+' '+Q)
check('own-branch',git('branch','--show-current').decode().strip()=='codex/geo300-capacity512-20261024')
merged=git('diff','--name-only',P,M).decode().splitlines()
check('merge-only-added-evidence',bool(merged) and all(p.startswith('evidence/')for p in merged))
roots=[Path('/tmp/geo300-capacity512-draft-v1-20261024'),Path('/workspace/geo300-capacity512-companion-draft-20261024'),Path('/workspace/geo300-capacity512-host-draft-20261024'),Path('/workspace/geo300-capacity512-host-draft-20261024/registry-plan')]
files={}
for root in roots:
 for path in (root/'candidate').rglob('*'):
  if path.is_file():
   rel=str(path.relative_to(root/'candidate'));check('no-draft-overlap:'+rel,rel not in files);files[rel]=path.read_bytes()
check('fifteen-reviewed-leaves',len(files)==15 and set(files)==set(prep['candidate_files']))
for rel,raw in files.items():
 actual=(ROOT/rel).read_bytes();entry=prep['candidate_files'][rel]
 check('exact-reviewed-candidate:'+rel,actual==raw and sha(actual)==entry['sha256']and len(actual)==entry['bytes'])
for item in prep['patches']:check('frozen-patch:'+item['path'],sha(Path(item['path']).read_bytes())==item['sha256'])
modified=set(git('diff','--name-only').decode().splitlines())
untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
check('only-expected-15-worktree-leaves',modified|untracked==set(files)and len(untracked)==4)
check('no-staged-edits-yet',git('diff','--cached','--name-only')==b'')
git('diff','--check')
for rel in ('geometry-templates/woodworking/native/panel_layout.c','tests/geo261_panel_harness.c','tests/test_geo261_panel_native.py'):
 check('P2-source-unchanged:'+rel,git('show','324034812bb6effca68e0413bc0468595337b317:'+rel)==git('show',M+':'+rel))
before=json.loads(git('show',M+':tests/run_all.expected.json'))
after=json.loads((ROOT/'tests/run_all.expected.json').read_bytes())
new={'py:test_geo261_timber_capacity':7,'py:test_geo261_timber_capacity_host':5}
check('registry-only-new-two',set(after['suites'])-set(before['suites'])==set(new))
check('old-registry-order-and-values',[(k,v)for k,v in after['suites'].items()if k not in new]==list(before['suites'].items()))
check('preserve-P2-13-and-report-11',after['suites']['py:test_geo261_panel_native']['count']==13 and after['suites']['py:test_geo261_wood_report_policy']['count']==11)
for name,count in new.items():
 t=ast.parse((ROOT/('tests/'+name[3:]+'.py')).read_text())
 methods=[n.name for n in ast.walk(t)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')]
 check('AST-only-expected-count:'+name,len(methods)==count==after['suites'][name]['count'])
for rel in ('tests/test_geo261_contact_world.py','tests/test_geo261_wood_report_policy.py','tests/test_geo261_native_kernel.py'):
 check('existing-native-suite-unchanged:'+rel,git('diff','--',rel)==b'')
check('old-64-fixture-still-in-contact-client',all(token in (ROOT/'tests/geo261_contact_world_harness.c').read_bytes() for token in (b'WoodMember members[64];WoodContactMemberFact facts[64];',b'w.member_count=64;')))
check('legacy-64-checkpoint-real-host',b'(64,65,511,512)' in (ROOT/'tests/test_geo261_timber_capacity_host.py').read_bytes())
check('no-C-or-formal-claims',prep['compiled'] is False and prep['formal']=='UNRUN')
check('peer-left-owner-metadata-unchanged',config=={p:sha((ROOT/'.git'/p).read_bytes())for p in config})
result={'reviewed_head':M,'parents':[P,Q],'checks':checks,'passed':sum(c['passed']for c in checks),'failed':sum(not c['passed']for c in checks),'findings':[],
 'scope':'Only applied-byte and parent/registry narrow review; prior product/W/H semantic peers retained. No C compile, subject import, test, discovery or ledger.',
 'compiled':False,'runtime':'UNRUN','candidate_pins':prep['candidate_files']}
cap.dump(OUT/'REVIEW.json',result);print(json.dumps({k:result[k]for k in ('passed','failed','findings')}))
raise SystemExit(bool(result['failed']))
