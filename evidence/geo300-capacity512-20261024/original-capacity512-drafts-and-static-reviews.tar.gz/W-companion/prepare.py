from pathlib import Path
import ast,datetime,difflib,hashlib,json,subprocess
BASE=Path(__file__).resolve().parent
REPO=Path('/workspace/geo300-contact-index-work')
S='39273bc0229fbbb16565134e1f8fad3a0d598c31'
E='a5f1806fb3cad2dada1a56e79e01d54f9f86700f'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):
    result=subprocess.run(['git','--no-optional-locks',*args],cwd=REPO,capture_output=True)
    assert result.returncode==0,(args,result.stderr)
    return result.stdout
assert git('rev-parse','HEAD').decode().strip()==E
assert not git('status','--porcelain')
commands=[];manifest=[]
def source(path):
    data=git('show',S+':'+path)
    out=BASE/'before'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
    commands.append({'argv':['git','--no-optional-locks','show',S+':'+path],
        'cwd':str(REPO),'exit':0,'stdout_file':str(out),'stdout_sha256':sha(data),'stderr':''})
    return data
path='tests/geo261_contact_world_harness.c';data=source(path)
before=b'WOOD_CONTACT_FACE_CAPACITY==2432&&WOOD_CONTACT_COMPONENT_CAPACITY==8&&WOOD_CONTACT_MEMBER_CAPACITY==64'
after=b'WOOD_CONTACT_FACE_CAPACITY==3328&&WOOD_CONTACT_COMPONENT_CAPACITY==8&&WOOD_CONTACT_MEMBER_CAPACITY==512'
assert data.count(before)==1
(BASE/'candidate'/path).write_bytes(data.replace(before,after))
path='tests/geo261_report_policy_harness.c';data=source(path)
old=b'''    WoodMember values[WOOD_CUT_LIST_MEMBER_CAPACITY];for(size_t i=0;i<WOOD_CUT_LIST_MEMBER_CAPACITY;++i)values[i]=member((uint32_t)i,100,20,30,WOOD_MEMBER_ROLE_PRIMARY,true);
    CHECK(wood_cut_list_collect(values,WOOD_CUT_LIST_MEMBER_CAPACITY,&result)&&result.group_count==1&&result.placed==64&&result.groups[0].count==64&&result.ids[result.groups[0].first+63]==63,"report-capacity");
'''
new=b'''    WoodMember values[513];for(size_t i=0;i<513;++i)values[i]=member((uint32_t)i,100,20,30,WOOD_MEMBER_ROLE_PRIMARY,true);
    CHECK(wood_cut_list_collect(values,64,&result)&&result.group_count==1&&result.placed==64&&result.groups[0].count==64&&result.ids[result.groups[0].first+63]==63,"report-capacity-legacy-64");
    CHECK(WOOD_CUT_LIST_MEMBER_CAPACITY==512&&wood_cut_list_collect(values,512,&result)&&result.group_count==1&&result.placed==512&&result.groups[0].count==512&&result.ids[result.groups[0].first+511]==511,"report-capacity");
'''
assert data.count(old)==1
data=data.replace(old,new)
old=b'wood_cut_list_collect(values,WOOD_CUT_LIST_MEMBER_CAPACITY+1,&result)'
assert data.count(old)==1
(BASE/'candidate'/path).write_bytes(data.replace(old,b'wood_cut_list_collect(values,513,&result)'))
patch=[]
for candidate in sorted((BASE/'candidate').rglob('*')):
    if not candidate.is_file():continue
    rel=candidate.relative_to(BASE/'candidate').as_posix()
    original=BASE/'before'/rel;before=original.read_bytes() if original.exists() else b''
    after=candidate.read_bytes()
    assert before!=after
    manifest.append({'path':rel,'new_file':not original.exists(),'before_sha256':sha(before),'after_sha256':sha(after),'before_bytes':len(before),'after_bytes':len(after)})
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
        fromfile='a/'+rel if original.exists() else '/dev/null',tofile='b/'+rel))
patch_bytes=''.join(patch).encode()
(BASE/'COMPANION_PARTIAL.patch').write_bytes(patch_bytes)
tree=ast.parse((BASE/'candidate/tests/test_geo261_timber_capacity.py').read_text())
methods=[node.name for cls in tree.body if isinstance(cls,ast.ClassDef) for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')]
assert len(methods)==7
fixture=git('show',S+':room_a.scene')
saved=Path('/tmp/geo300-cut-list-storage-20261024/fixture-preparation/room_a.scene')
assert fixture==saved.read_bytes() and len(fixture)==370
assert sha(fixture)=='c3c0ba589285ef5ecd835b89a38174ebe050c85c4b8814510e139f72550f1f7c'
assert not (REPO/'room_a.scene').exists()
patterns=git('sparse-checkout','list')
(BASE/'SOURCE_SPARSE_PATTERNS.original.txt').write_bytes(patterns)
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha':S,'evidence_sha':E,'draft_pr':346,
    'scope':'External partial companion draft only; no source/branch change, product test, C compile, import, ledger or acceptance.',
    'files':manifest,'patch_sha256':sha(patch_bytes),'methods_ast_only':methods,'new_control_design_count':4,
    'commands':commands,'fixture':{'path':'room_a.scene','exists_in_source':False,'original_sha256':sha(fixture),'bytes':370,
        'saved_original':str(saved),'sparse_patterns_sha256':sha(patterns),'materialization_status':'HOLD; not executed',
        'argv':['git','sparse-checkout','add','--no-cone','/room_a.scene'],
        'postconditions':['unchanged HEAD '+E,'empty git status --porcelain','fixture bytes equal original S blob','all original sparse patterns retained']},
    'not_completed':['Host CLI/bridge 512 declarations, 513 rejection, replay, undo/redo and revision atomicity',
        'independent compile-time alias/storage negative controls in real H ABI',
        'test registry/expected counts/architecture manifest/docs companion changes','all runtime and mutation outcomes'],
    'product_patch_dependency':'/tmp/geo300-capacity512-draft-v1-20261024/PRODUCT_ONLY.patch',
    'product_patch_sha256':'f2d8202f035e334ec0033192793d0751db75ef1fa320110a903b3495b84230ae'}
assert git('rev-parse','HEAD').decode().strip()==E
assert not git('status','--porcelain')
(BASE/'MANIFEST.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'new_methods_ast_only':len(methods),'new_controls_design_only':4,'fixture_bytes':len(fixture),'patch_sha256':sha(patch_bytes),'source_unchanged':True,'subject':'UNRUN'}))
