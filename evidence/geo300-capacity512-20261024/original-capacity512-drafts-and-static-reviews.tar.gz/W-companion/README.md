# 512 companion 的部分候選；未套用、未編譯、未執行

依 S `39273bc0229fbbb16565134e1f8fad3a0d598c31` 與既有七產品檔草稿準備。cut-list 現為 draft #346；它的 11 方法／9 控制仍未執行，本稿不變更該分支。

四個測試檔候選保留 contact 原 64 成員／272 面 witness，僅更新已獨立登記的新容量契約；report 原 64 筆值與 ID63 保留，另用真 513 筆陣列驗 512 成功、513 原子拒絕。原 9 個 report 控制及其 Python 測試完全不變，其中 `>=` 控制仍由 `report-capacity` 的真正第 N 支條件捕捉。

新單元草稿共 7 個方法，含 5 個正例類別與 4 個局部撤回設計。world-validation 撤回時第一 callback 安全返回 false；member-declaration 撤回只呼叫准入 API，沒有有效第 513 append。唯一主值恢復為 64 的反證使用 values-only client，沒有連結其他 W/H object，不混 ABI；此反證只證獨立常數／實際型別大小，不能冒完整 64/512 ABI 驗收。

原 NativeBuild、10 秒單例限制、16 MiB stack 與正常 ASSERT 退出規則均沿用。本稿只做 Python AST、Git 原件與字串 anchor 靜態檢查。C 的預期結果、控制的預期首個 ASSERT 都還沒有觀察到，必須正式編譯後原件驗證。

尚缺：H 真 CLI／bridge 512 宣告、513 原子拒絕、滿載重宣告、dump/load、undo/redo/revision；H 真儲存別名的編譯契約控制；registry、expected、架構 manifest 與文件。`COMPANION_PARTIAL.patch` 與原產品補丁合在一起仍不構成可合入提交。

不新增性能門檻，不改公理層或決策佇列，不占全域突變編號。所有程序仍為 UNRUN。
