# 512 companion tests 草案 v2；沒有執行或修改原測試

基底為 cut-list S `39273bc0229fbbb16565134e1f8fad3a0d598c31`。`PRODUCT_ONLY.patch` 僅七個產品檔，**單獨不構成可合入補丁**：目前舊 contact/report 容量 assert 仍期待 64，需本設計的 companion tests／registry／文件跟上。正式 S392 原11/9尚待主代理時槽；此處沒有改它的 source 或收據，也沒有先開512 branch。

## 先保留哪些原件

- contact 原12 methods／41 controls 全保。`geo261_contact_world_harness.c:58–62` 原8components、8holes、64members、n272、同order穩定次序、精確fields與sentinel全原樣。唯一舊容量契約 :57 改為新獨立常數 `3328 / 8 / 512`，不是兩邊共用同一錯宏。
- report 原11 methods／9 controls 全保，包括分組、同值不同role、cut-priority不入group key、declaration-order、interleaved slices、copy-own IDs、linear storage header反證、空／缺input／原子拒絕、defaultfixity與真CLI原比對。原S392單一ID pool不再重寫。
- report 原 `limits` 的64條件要明確分成「原64場景」與「新真N場景」：保原64 members 的 placed64/count64/ID63 assert；另以獨立512預期驗原CAP入口，不可把全部原assert改成用同一可錯macro。`>`→`>=` 的既有 local control 必改用新的真N場景（同一失效原因：第N支應成功，不能被`>=`拒絕）；保原count>=的產品撤回與精確正常ASSERT，不刪此控制。
- panel oracle顯式64、member declaration已有參數化小容量測試、spec/grid/parameter depth64與其訊息不變。容量512不是其他資源512。
- 不改原timeouts、原16MiB、原NativeBuild工具或正常return/exception；client與全部相關W目的檔必共用同一套候選header後重編，恢復後也重編，不混64/512 ABI。

## 建議新增專用 harness 的 cases

用新 `tests/geo261_timber_capacity_harness.c` 與 `tests/test_geo261_timber_capacity.py`，由既有 `NativeBuild` 模式包裝，不另造runner。此處只有設計，尚未填入registry或決定方法數。

### `values`

include五實際header並以獨立512驗 `WOOD_MEMBER_CAPACITY`、其它三個W別名與host見到的world參數；檢真WoodDocument兩array長度、F=3328、span=3328。host的runtime／compile值可在另個include current_geometry 的原方式client輸出；不要為此把H include到W。所有非角材容量另列保持原值，尤其component8。

正常ASSERT名稱建議：`capacity-value-512`、`capacity-storage-timbers`、`capacity-storage-anchors`、`capacity-face-3328`、`capacity-span-3328`。這些是設計名稱，實際凍結時需和原原始輸出核對，不能先冒已觀察。

### `report-boundary`

宣告512個相同spec的placed成員，ID用非遞增而不衝突的序列，驗count512、group1、完整IDs原宣告順序、sum原精確值。再跑512個各異spec，驗group512、完整slice分割、clone後清原輸入／report仍持全部IDs。值不要超D1／INT64合法範圍。

第513輸入使用513個**真有效成員**（非array只有512卻傳513）；先保存output bytes，再要求容量拒絕且output逐byte不變。原函式先guard，本設計也不能靠未讀的OOB指標當測試。保同一次滿載的64子場景，不把它換成512。

### `contact-boundary`

512個unique ID、placed且footprint互不覆蓋，全部在同placement，反declorder／同order ties／完整uint64順序混合；兩面每人，完整1024側面和RC prefix另驗，cap小buffer的pair原子性／sentinel必保。`WoodStopFace[]` 長度由真F配置，獨立1024/3328預期防兩邊同錯。不要讓dedup自然刪面後仍只驗n而漏最後ID。

513公開facts case只證原contact collector的overflow fallback不變：使用合法獨立borrowedview與充足publicoutbuffer，原index不能入、原insertion sort/fallback仍按last/min語意完成。這與world-validation的固定scratch早拒是兩個不同API，不能互抄reject。

### `validation-boundary`

context提供空gridstate、未placedmembers、沒有placement，N512可遍歷並通過；以計數callback確認原正常回呼次序。N513先給同樣context，要求 `I33 CAPACITY`、**零callback**、output error以外所有state bytes不變。

早拒撤回時，不用讓程式繼續到axes寫越界：只在N513負例將第一個member callback設定成記錄一次後回false，故撤回可自然停在原第一段，測試以`callbacks==0`與CAPACITY精確訊息的正常ASSERT判紅。這抓的是未在入口拒絕，不拿crash／ASAN／compileerror冒語意kill。

### `parser-boundary`

真CLI/bridge走原命令，不用NativeBuild裡的66格小替身充當產品容量512。對空World逐次宣告到512（未placed與真正放置大場景分欄）；驗timber_count與最後ID。第513新ID拒絕且dump、history、revision保原；滿載重宣告既有ID仍可走原准入、尚未做role／syntax parse以前的原capacity-first優先順序保留。另測dump→load重放及undo/redo原子性，不改bridge timeout或變批提交語意。

這項不能冒512支都已合法放置，真正512 placements仍需#297探針／代表場景另跑，並原30秒能力／超時分欄。

**Host超容量guard撤回的安全路徑（v2收斂）**：fixed/restored可各測有效第513條完整宣告的原子拒絕；撤回 `count==capacity` 這一刀**禁止執行有效第513條append**。`wood_member_declare` 沒有第二道count守門，直接append會越界，不能拿它的crash當kill。這一刀只選 (a) 直接呼叫原 `wood_member_declaration_capacity`、固定count=512/new ID，正常ASSERT要求它返回false與原容量錯誤，完全不呼叫declare／append；或 (b) 用原滿載＋缺參數 `timber` 命令／`capacity-first-missing-id` sentinel，撤回後在原語法拒絕處自然停下，正常ASSERT要求仍應先回容量錯誤。實際凍結時只挑明列且已核到append前返回的一條，保原times／assertion。這不是增加第二道產品守門或更改准入次序。

## 控制與撤回／恢復矩陣

| 具名類別 | 精確撤回／故障 | 固定→撤回→恢復預期與分類 |
|---|---|---|
| 第N准入 | 原 `count>CAP` 換 `>=CAP`（report）；host容量入口對應只拒第N | 正常ASSERT 0/1/0；原第N成功條件不變 |
| 超N准入 | 原 `count==capacity` 容量拒絕改false（host）；newAPI入口guard撤回 | 正常ASSERT 0/1/0；host只跑上述direct-capacity-API或缺參數capacity-first sentinel，**撤回態不送有效第513 append**；有效513完整產品只在fixed/restored；W validation用第一callback安全停下，不以OOB或crash過關 |
| 既有ID滿載覆寫 | 撤 supplied/existing allowance | 原existing-update正例0/1/0，保准入次序 |
| report pool | 原九具名控制（ID順序／offset／layout／empty等） | 原正常ASSERT 0/1/0，全header client/cut同變異header再編與還原 |
| 五容量綁定 | 各一別名或真儲存array單獨寫回64／衍生face少1 | 編譯契約：正常compile0／違約compile非0／還原compile0；保存具名guard診斷及真正compiler exit，**不叫 killed／正常ASSERT** |
| 唯一主值 | 主值64，所有別名一起跟隨 | 編譯仍合法，必由獨立512 runtime ASSERT與512/513真產品測試紅；防靜態等式全恆真 |
| world-validation guard | 只撤新增member_count早拒 | 原指定safe callback case0/1/0，zero-callback／CAPACITY原預期不變 |
| contact快路整體 | unique資格true→false | 原八正例0/0/0等價，不是kill；原local負控制仍各正常0/1/0 |

正式控制名稱、精確anchor、首個正常ASSERT與每個compile原碼必於實際source凍結後逐項保存。這裡不占任何 M 編號、不更新全域mutation registry／ledger；全帳本仍root最後一次。

## 註冊與正式收尾

新增實際方法後才以AST真數修改registry／expected唯一相關entries，其它entry逐值不變；舊contact/report方法只加不刪。容量契約變動造成舊64 assert轉新512不是放寬判準，要有舊64例仍在、新512/513、單一主值縮回64紅與恢復綠的原streams佐證。

`ARCHITECTURE.md` 角材64說明需更新；決策／SSOT保持原字，由root記後續實作證據而不是覆寫歷史B-15。所有受改來源／新增test加原架構manifest closure、原三judge；最終完整native、六browser、帳本與已列專項按root影響矩陣跑，不借parent S證據貼綠。

原性能門檻只保原P189 N16/32/48/64每點≤2、dumpbyteexact與原16MiB。N128/256/512額外比值／2MiBstackmargin均不在這個draft，不能自採。原所有controls先跑；不因512費時裁掉controls、提高timeout／stack、或只測主值alias而不測真儲存。

**UNRUN；尚無新branch、source commit、compile或產品通過。**
