"""Prepare an external product-only capacity draft from pinned Git reads.

No checkout, source edit, compiler, product import, or test runs.
"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE = Path('/tmp/geo300-capacity512-draft-v1-20261024')
INDEX = Path('/tmp/geo300-capacity512-static-20261024/SOURCE_INDEX.json')
SHA = '39273bc0229fbbb16565134e1f8fad3a0d598c31'
data = json.loads(INDEX.read_text())
assert data['source_sha'] == SHA
source = {item['path']: item for item in data['sources']}
paths = [
    'geometry-templates/woodworking/native/members.h',
    'geometry-templates/woodworking/native/document.h',
    'geometry-templates/woodworking/native/contact_world.h',
    'geometry-templates/woodworking/native/cut_list.h',
    'geometry-templates/woodworking/native/member_reference.h',
    'current_geometry.c',
    'geometry-templates/woodworking/native/world_validation.c',
]
entries = []
for path in paths:
    item = source[path]
    before = Path(item['raw_stdout']).read_bytes()
    assert hashlib.sha256(before).hexdigest() == item['sha256']
    newline = b'\r\n' if b'\r\n' in before else b'\n'
    edits = []
    def replace(old, new):
        nonlocal_holder = None
        edits.append((old, new))
    if path.endswith('/members.h'):
        replace(b'#define GEOMETRY_WOODWORKING_MEMBERS_H' + newline,
                b'#define GEOMETRY_WOODWORKING_MEMBERS_H' + newline +
                b'/* Sole fixed member capacity; storage and W/H scratch share it. */' + newline +
                b'#define WOOD_MEMBER_CAPACITY 512' + newline)
    elif path.endswith('/document.h'):
        replace(b'    WOOD_MEMBER_CAPACITY = 64,' + newline,
                b'    /* WOOD_MEMBER_CAPACITY is declared in members.h. */' + newline)
    elif path.endswith('/contact_world.h'):
        replace(b'#define WOOD_CONTACT_MEMBER_CAPACITY 64',
                b'#define WOOD_CONTACT_MEMBER_CAPACITY WOOD_MEMBER_CAPACITY')
    elif path.endswith('/cut_list.h'):
        replace(b'#define WOOD_CUT_LIST_MEMBER_CAPACITY 64',
                b'#define WOOD_CUT_LIST_MEMBER_CAPACITY WOOD_MEMBER_CAPACITY')
    elif path.endswith('/member_reference.h'):
        replace(b'#define WOOD_MEMBER_SPAN_MEMBER_CAPACITY 64',
                b'#define WOOD_MEMBER_SPAN_MEMBER_CAPACITY WOOD_MEMBER_CAPACITY')
    elif path == 'current_geometry.c':
        replace(b'#define WORLD_MAX_TIMBERS     64',
                b'#define WORLD_MAX_TIMBERS     WOOD_MEMBER_CAPACITY')
        anchor = b'typedef char app_span_scratch_bound_check[SPAN_CUT_MAX==WOOD_MEMBER_SPAN_CUT_CAPACITY?1:-1];' + newline
        checks = [
            '/* Bind the host admission bound to real W storage and scratch. */',
            'typedef char app_timber_capacity_world_check[WORLD_MAX_TIMBERS==WOOD_MEMBER_CAPACITY?1:-1];',
            'typedef char app_timber_capacity_timbers_check[sizeof(((World *)0)->wood.timbers)/sizeof(((World *)0)->wood.timbers[0])==WORLD_MAX_TIMBERS?1:-1];',
            'typedef char app_timber_capacity_anchors_check[sizeof(((World *)0)->wood.anchors)/sizeof(((World *)0)->wood.anchors[0])==WORLD_MAX_TIMBERS?1:-1];',
            'typedef char app_timber_capacity_contact_check[WOOD_CONTACT_MEMBER_CAPACITY>=WORLD_MAX_TIMBERS?1:-1];',
            'typedef char app_timber_capacity_cut_list_check[WOOD_CUT_LIST_MEMBER_CAPACITY>=WORLD_MAX_TIMBERS?1:-1];',
            'typedef char app_timber_capacity_span_check[WOOD_MEMBER_SPAN_MEMBER_CAPACITY>=WORLD_MAX_TIMBERS?1:-1];',
            'typedef char app_timber_capacity_stop_face_check[STOP_FACE_MAX==WOOD_CONTACT_FACE_CAPACITY?1:-1];',
        ]
        replace(anchor, anchor + newline + newline.join(line.encode() for line in checks) + newline)
    elif path.endswith('/world_validation.c'):
        anchor = b'    const WoodGridState *grids=context->grids.state;' + newline
        guard = [
            '    if(context->member_count>WOOD_CONTACT_MEMBER_CAPACITY)',
            '        return validation_refuse(error,capacity,"I33 CAPACITY: member count exceeds the contact capacity");',
        ]
        replace(anchor, newline.join(line.encode() for line in guard) + newline + anchor)
    after = before
    changes = []
    for old, new in edits:
        assert after.count(old) == 1, (path, old, after.count(old))
        after = after.replace(old, new, 1)
        changes.append({'before_hex': old.hex(), 'after_hex': new.hex(), 'matches': 1})
    for side, content in [('before', before), ('candidate', after)]:
        target = HERE / side / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    entries.append({'path': path, 'source_sha': SHA, 'blob_oid': item['blob_oid'],
                    'before_sha256': hashlib.sha256(before).hexdigest(),
                    'after_sha256': hashlib.sha256(after).hexdigest(),
                    'before_bytes': len(before), 'after_bytes': len(after),
                    'edits': changes})
diff = subprocess.run(['git', 'diff', '--no-index', '--binary', '--src-prefix=a/',
                       '--dst-prefix=b/', 'before', 'candidate'], cwd=HERE,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert diff.returncode == 1, diff.returncode
(HERE / 'git-diff.stdout').write_bytes(diff.stdout)
(HERE / 'git-diff.stderr').write_bytes(diff.stderr)
patch = diff.stdout.replace(b'a/before/', b'a/').replace(b'b/candidate/', b'b/')
(HERE / 'PRODUCT_ONLY.patch').write_bytes(patch)
manifest = {'source_sha': SHA, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope': 'External product-only draft. No repository changes, compiler, product import, tests, perf or ledger.',
            'not_ready': 'Requires test/registry/document companion work and cut-list S392 formal green before a new branch; this patch alone changes old capacity expectations.',
            'files': entries, 'diff_command': {'argv': diff.args, 'cwd': str(HERE), 'exit': diff.returncode,
                'expected_exit_1_means_diff': True, 'stdout_sha256': hashlib.sha256(diff.stdout).hexdigest(),
                'stderr_sha256': hashlib.sha256(diff.stderr).hexdigest()},
            'patch': {'path': str(HERE / 'PRODUCT_ONLY.patch'), 'bytes': len(patch),
                      'sha256': hashlib.sha256(patch).hexdigest()},
            'protected_unchanged': ['公理層.md','決策佇列.md','geometry-core/kernel','tests/mutate.py','tests/run_all.expected.json'],
            'semantic_contract': {'capacity': 512, 'existing_stack_bytes': 16777216,
                                  'new_performance_threshold': None, 'tests_executed': False}}
(HERE / 'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files': len(entries), 'patch_bytes': len(patch), 'patch_sha256': manifest['patch']['sha256'],
                  'manifest_sha256': hashlib.sha256((HERE / 'MANIFEST.json').read_bytes()).hexdigest(), 'exit': 0}))
