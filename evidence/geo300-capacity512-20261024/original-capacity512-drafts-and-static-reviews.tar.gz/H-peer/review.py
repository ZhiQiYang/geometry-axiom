from pathlib import Path
import ast,difflib,hashlib,importlib.util,json,os,re
BASE=Path('/workspace/geo300-capacity512-host-draft-20261024')
OUT=Path('/workspace/geo300-capacity512-host-static-peer-20261024')
REPO=Path('/workspace/geo300-contact-index-work')
P2=Path('/workspace/issue128-empty-panel-rows-work-20261024')
PRODUCT=Path('/tmp/geo300-capacity512-draft-v1-20261024')
S='39273bc0229fbbb16565134e1f8fad3a0d598c31';PS='324034812bb6effca68e0413bc0468595337b317'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
rec=c.Recorder(OUT/'source-capture',dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),S)
checks=[]
def check(name,value,detail=''):checks.append(dict(name=name,passed=bool(value),detail=detail))
def sha(raw):return hashlib.sha256(raw).hexdigest()
manifest=json.loads((BASE/'MANIFEST.json').read_text())
check('source-and-future-base',manifest['source_sha']==S and manifest['future_base_merge']==PS)
patch=(BASE/'HOST_COMPANION.patch').read_bytes()
check('frozen-v2-H-patch',sha(patch)==manifest['patch_sha256']=='4bc379898588428579170a4776a12efe90c172a5855f41997a31e1ce4d8ca115')
diff=[]
for item in manifest['files']:
    raw=(BASE/'candidate'/item['path']).read_bytes()
    check('candidate-pin:'+item['path'],sha(raw)==item['sha256'] and len(raw)==item['bytes'])
    check('new-leaf:'+item['path'],item['new_file'])
    diff.extend(difflib.unified_diff([],raw.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+item['path']))
check('patch-reconstructs-exact-two-files',''.join(diff).encode()==patch and len(manifest['files'])==2)
for item in manifest['source_reads']:
    row,so,se=rec.run(item['argv'],cwd=REPO,timeout=30,check=False,source_variant='independent-H-draft-source-proof')
    check('source-zero:'+item['argv'][-1],row['actual_process_returncode']==0)
    check('source-exact:'+item['argv'][-1],so==Path(item['stdout']).read_bytes() and sha(so)==item['stdout_sha256'])
python=(BASE/'candidate/tests/test_geo261_timber_capacity_host.py').read_text()
tree=ast.parse(python);methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
check('five-AST-methods-not-discovery',len(methods)==5 and methods==manifest['files'][1]['test_methods_ast_only'])
check('real-original-bridge-session','from tests import _bridge' in python and 'cls.bridge=build.bridge()' in python and '_bridge.BridgeSession(self.bridge)' in python)
check('512-real-declarations-with-legacy-64','for identifier in range(1,513)' in python and '(64,65,511,512)' in python)
check('reject-complete-dump-atomicity','self.assertEqual(before,bridge.command("dump"))' in python)
check('replay-compares-text-bytes-not-new-revision','changed["text"].encode("utf-8"),restored.command("dump")["text"].encode("utf-8")' in python)
check('fixed-has-true-513-refusals','"timber 513 27 33 role primary"' in python)
sentinel=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='capacity_first_sentinel')
segment=ast.get_source_segment(python,sentinel)
check('withdrawn-sentinel-never-sends-valid-513','bridge.line("timber")' in segment and 'bridge.line("timber 513' not in segment and 'self.load_full(bridge)' in segment)
check('negative-exception-framework-output-preserved','as failure:' in python and 'failure.exception' in python and 'framework-assertion' in python)
check('restoration-recompiles-unchanged-source','restored_source.write_text(source,encoding="utf-8")' in python and 'self.capacity_first_sentinel(restored)' in python)
check('original-values-timeout','timeout=10' in python)
check('compile-contract-exact-original-build-invocation','self.assertEqual(count+1,len(build.logs)' in python and 'self.assertNotEqual(0,row["exit"])' in python and 'self.assertIn(marker,row["stdout"]+row["stderr"])' in python)
check('compile-contract-restores-every-source','finally:target.write_bytes(original)' in python and 'build.compile(harness,"capacity-host-abi-restored-"+name,PRODUCT_DEFINES)' in python)
control_method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='test_real_host_compile_contract_rejects_each_drifted_capacity')
assignment=next(n for n in control_method.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='controls' for t in n.targets))
controls=ast.literal_eval(assignment.value);check('seven-independent-compile-contract-controls',len(controls)==7)
product_c=(PRODUCT/'candidate/current_geometry.c').read_bytes()
for name,rel,before,after,marker in controls:
    raw=(PRODUCT/'candidate'/rel).read_bytes()
    check('unique-production-ABI-anchor:'+name,raw.count(before)==1 and before!=after)
    check('named-actual-host-typedef:'+name,('typedef char '+marker+'[').encode() in product_c)
declaration=(REPO/'geometry-templates/woodworking/native/member_declaration.c').read_text()
host=(REPO/'current_geometry.c').read_bytes().decode()
begin=host.index('static bool apply_timber_line(');end=host.index('static ',begin+7)
apply=host[begin:end]
check('capacity-before-syntax-has-safe-short-command-guard',apply.index('wood_member_declaration_capacity')<apply.index('if(count<5||') and 'count>=2?' in apply)
check('declaration-capacity-does-not-append',declaration[declaration.index('bool wood_member_declaration_capacity'):declaration.index('bool wood_member_declaration_role')].count('++')==1,
      'The sole ++ is the bounded existing-member scan; no count increment or member construction.')
harness=(BASE/'candidate/tests/geo261_timber_capacity_host_harness.c').read_text()
check('actual-H-included-not-substitute-World','#include "../geometry-web/web_bridge.c"' in harness and 'typedef struct' not in harness)
check('MSVC-path-keeps-existing-explicit-GDI-exclusion','#ifdef _WIN32\n#undef _WIN32' in harness)

# Read-only reproduction of the original quoted-local include walk. Missing
# bare K headers are resolved by the unchanged NativeBuild isolated K path.
virtual={item['path']:(BASE/'candidate'/item['path']).read_bytes() for item in manifest['files']}
for path in (PRODUCT/'candidate').rglob('*'):
    if path.is_file():virtual[path.relative_to(PRODUCT/'candidate').as_posix()]=path.read_bytes()
pending=['tests/geo261_timber_capacity_host_harness.c'];seen={};bare=[]
while pending:
    rel=pending.pop()
    if rel in seen:continue
    path=REPO/rel;raw=virtual.get(rel)
    if raw is None:raw=path.read_bytes()
    seen[rel]=dict(bytes=len(raw),sha256=sha(raw))
    for encoded in re.findall(rb'^\s*#\s*include\s*"([^"]+)"',raw,re.M):
        name=encoded.decode();child=(path.parent/name).resolve()
        try:child_rel=child.relative_to(REPO).as_posix()
        except ValueError:raise AssertionError('quoted include escapes root')
        if child_rel in virtual or child.is_file():pending.append(child_rel)
        else:bare.append(dict(parent=rel,include=name,kernel_path_exists=(REPO/'geometry-core/kernel'/name).is_file()))
check('all-seven-mutated-files-in-actual-quoted-closure',all(rel in seen for _,rel,_,_,_ in controls))
check('unresolved-quoted-headers-are-original-public-K-path',all(x['kernel_path_exists'] for x in bare))

reg=BASE/'registry-plan';rm=json.loads((reg/'MANIFEST.json').read_text())
check('registry-fixed-P2-base',rm['base_sha']==PS)
rp=(reg/'REGISTRY_ONLY.patch').read_bytes()
check('registry-v2-patch-pin',sha(rp)==rm['patch_sha256']=='125109ffaf67c1a7cb16fbc2316e0a102968027f88bf9588a6e73620f0e7551c')
new_names={'test_geo261_timber_capacity','test_geo261_timber_capacity_host'}
old_run=(reg/'before/tests/run_all.py').read_text();new_run=(reg/'candidate/tests/run_all.py').read_text()
def needs(text):
    t=ast.parse(text)
    for node in t.body:
        if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='PY_NEEDS' for x in node.targets):return ast.literal_eval(node.value)
    raise AssertionError('PY_NEEDS assignment missing')
o,n=needs(old_run),needs(new_run)
check('only-two-new-PY_NEEDS-empty',set(n)-set(o)==new_names and all(n[k]==[] for k in new_names) and {k:v for k,v in n.items() if k not in new_names}==o)
old_json=json.loads((reg/'before/tests/run_all.expected.json').read_bytes())
new_json=json.loads((reg/'candidate/tests/run_all.expected.json').read_bytes())
new_keys={'py:'+x for x in new_names}
check('only-two-new-expected-keys',set(new_json['suites'])-set(old_json['suites'])==new_keys)
check('all-existing-values-and-order-preserved',[(k,v) for k,v in new_json['suites'].items() if k not in new_keys]==list(old_json['suites'].items()))
check('P2-and-report-prerequisites-retained',new_json['suites']['py:test_geo261_panel_native']['count']==13 and new_json['suites']['py:test_geo261_wood_report_policy']['count']==11)
check('new-counts-7-and-5',new_json['suites']['py:test_geo261_timber_capacity']['count']==7 and new_json['suites']['py:test_geo261_timber_capacity_host']['count']==5)
for item in rm['files']:
    rel=item['path'];before=(reg/'before'/rel).read_bytes();after=(reg/'candidate'/rel).read_bytes()
    row,so,se=rec.run(['git','show',PS+':'+rel],cwd=P2,timeout=30,check=False,source_variant='independent-P2-base-registry-proof')
    check('registry-Git-base-pin:'+rel,row['actual_process_returncode']==0 and so==before and sha(before)==item['before_sha256'] and sha(after)==item['after_sha256'])
readme=(BASE/'README.md').read_text()
check('unplaced-vs-placed-and-framework-vs-OS-exit-explicit','未放置成員' in readme and '不是子程序退出碼 1' in readme and 'UNRUN' in readme)
result=dict(source_sha=S,future_base=PS,H_patch_sha256=sha(patch),registry_patch_sha256=sha(rp),
            checks=checks,passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),
            findings=[],quoted_closure=seen,include_path_resolution=bare,
            compiled=False,subject_imported=False,bridge_executed=False,
            preparation_feedback_resolved=['Preserve exact caught assertion text in suite stdout; v1 retained.','Preserve old expected-entry order and format; v1 sorting churn retained.'],
            limitations=['Static read-only review; all compiler named-diagnostic paths and bridge results remain UNRUN.',
                         '512 unplaced members do not establish valid placement of 512 members.',
                         'Quoted-closure walk is virtual read-only draft analysis, not a materialized build or MSVC run.',
                         'The expected framework AssertionError is not an independent child OS exit 1.'])
c.dump(OUT/'REVIEW.json',result)
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],compiled=False,findings=result['findings'])))
raise SystemExit(bool(result['failed']))
