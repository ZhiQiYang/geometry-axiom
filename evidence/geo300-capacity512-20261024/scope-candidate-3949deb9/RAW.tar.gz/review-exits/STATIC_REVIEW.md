# 獨立靜態複核

複核者 `/root/pr348_w_review_resume/review_extra_memo_tests`，固定 source.c SHA-256 `93b952992de5d344c8bb3efd582fd7f85318551cb12350dab95554d3e694057e`；補丁 `aee31e5b2022f67497731132c8550566eab46f5c1ba6f63f1e0c501487d501d8`。

沒有發現 baseline 或 control 的邏輯阻擋：

- heap 案 40 edges = 父 2 + 父→子 1 + 子 12×3 + 父新增 kind 1。第 9 個 distinct source 前確為 heap undo、count/capacity 8，注入實際在 realloc 分支。撤回 complete=false 後，同 source 第二 repeat 多追加一邊，應先由指定 `scope-heap-realloc-fallback-keeps-edges-once` 紅。
- invalid child 案 5 邊，provider 返回 den0 值 → K INVALID 且父端 output 不變，父繼續路徑符合原實作。
- deep512 共 1024 個 shared-source-kind edges + 511 個 parent-child edges = 1535，513 nodes；既有 oracle 容量足夠，無新增 product 容量上限。
- 原 13 個 test methods 未改。

複核者沒有編譯、執行測試或改檔。此文件只保存靜態判斷，不能作 runtime 通過證據。
