# K scope 最後三個退出／儲存邊界：未執行補充草稿

產品固定 `1616a72e42ececa4ff8f2c2544fa67e54e97c144`，source.c SHA-256 `93b952992de5d344c8bb3efd582fd7f85318551cb12350dab95554d3e694057e`。既有 13 項測試執行來源 `f84c3532685fd1a7f7e2cc7ddf9e205d48e0c0b9`。只追加既有兩個 scope 測試檔，未改產品、active 或 Git。

1. **已有 heap 8 筆後 realloc 失敗**：parent 先標記 source0/1，child 建立 8 筆 undo，確認 pointer 已不等於 inline、count/capacity 均8。第9個 distinct source、第一個kind、第一次請求才開原role故障；立刻關掉，確認正好1次失敗、舊heap/prefix保留且 proof 停用。child 全部12source×3kind完成，parent復原後重請舊kind不重邊、補新kind；精確40edges，全線性oracle、provider count與釋放核對。
2. **invalid child value**：child 真記錄依賴後返回 QUANTITY den=0、provider本身回true；K必須回INVALID且呼叫方 output sentinel不動。parent處理此失敗後再請共用source及新kind，精確5edges；child state/status/value、parent value、完整graph與釋放核對。
3. **512層 nested**：512個真provider frame，皆先請共用source0，再遞迴下一層，返回時重請同kind及另一kind。逐層確認重請沒有新增edge，max depth/退出數均512；513nodes、1535edges、512次describe/evaluate，全部值與線性ordered graph及最後mark清空。512只是依使用者規模選的測試深度，不是新增產品上限或時限。

原 Python class 的18個既有方法（含13個test methods）AST全部保留，原30秒每case不變。新增3正例方法與1反證方法，採入後scope suite應有17個test methods，但本稿沒有執行，數量是靜態定義而非通過數。

新增反證有獨立病因：撤回 optional reserve 失敗時的 complete=false。第9來源首次追加後沒有可還原mark，下一次相同請求因此被錯當新邊；應精確於 `scope-heap-realloc-fallback-keeps-edges-once` 正常assert紅，恢復後綠。invalid/deep的mark恢復防線已有原 `no-restore` 具名反證，未另造同義重覆控制。

`STATIC_PREFLIGHT.json`僅證Python AST及新mutation anchor唯一；**沒有編譯、沒有測試結果**。保持主代理效能獨占，交由其排程執行新增4項及必要回歸。
