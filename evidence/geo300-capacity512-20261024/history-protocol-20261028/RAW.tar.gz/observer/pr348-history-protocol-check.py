import hashlib,importlib.util,json,os,pathlib,resource,subprocess,sys,time,unittest
ROOT=pathlib.Path('/dev/shm/pr348-active');OUT=pathlib.Path('/dev/shm/pr348-history-protocol-check')
OUT.mkdir(exist_ok=False);os.chdir(ROOT);sys.path.insert(0,str(ROOT))
os.environ['TMPDIR']=str(OUT/'tmp');(OUT/'tmp').mkdir()
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
source=ROOT/'tests/test_geo261_timber_capacity_host.py';raw=source.read_bytes()
save(OUT/'REQUEST.json',{'command':sys.argv,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'test_sha256':hashlib.sha256(raw).hexdigest(),'product_source':'b595e55952d5d66de95024432e1b29bec7525e9b','utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'Actual small-world protocol positive and withdrawal; helper timeout tests are infrastructure only'})
(OUT/source.name).write_bytes(raw)
from tests import test_geo261_timber_capacity_host as m
original=m.run_placed_dialogue;records=[];phase='preflight'
def observed(commands,**kwargs):
    index=len(records);d=OUT/f'{index:02d}-{phase}';d.mkdir();start=time.monotonic();result=None;error=None
    try:result=original(commands,**kwargs);return result
    except BaseException as exc:error=exc;raise
    finally:
        captured=result if result is not None else getattr(error,'completed',None)
        record={'phase':phase,'command_names':[name for name,_ in commands],'timeout':kwargs.get('timeout',600),'error':type(error).__name__ if error else None,'seconds':time.monotonic()-start,'exit':captured.returncode if captured else None}
        if captured:
            for field,attr in (('stdin','stdin_bytes'),('stdout','stdout'),('stderr','stderr')):
                data=getattr(captured,attr);(d/(field+'.bin')).write_bytes(data);record[field+'_sha256']=hashlib.sha256(data).hexdigest()
        records.append(record);save(d/'RESULT.json',record)
m.run_placed_dialogue=observed
# Bounded mechanism controls: a fake child is never counted as a product pass.
fake=OUT/'fake-child';fake.write_text('#!/usr/bin/python3\nimport sys,json,time\nfor line in sys.stdin:\n s=line.strip()\n if s=="slow": time.sleep(5)\n if s=="crash": sys.stderr.write("intentional nonzero\\n");sys.exit(7)\n if s=="stderr":sys.stderr.write("x"*200000);sys.stderr.flush()\n print(json.dumps({"token":73,"echo":s}),flush=True)\n');fake.chmod(0o700)
result=observed([('a','stderr'),('b',lambda rows:'token '+str(rows['a']['token']))],bridge=fake,timeout=5)
assert result.returncode==0 and len(result.stderr)==200000 and b'token 73' in result.stdin_bytes
phase='deadline'
try:observed([('a','slow')],bridge=fake,timeout=.2)
except subprocess.TimeoutExpired as exc:
    assert exc.completed.returncode!=0 and exc.completed.stdin_bytes==b'slow\n'
else:raise AssertionError('single dialogue deadline did not fail')
phase='child-crash'
try:observed([('a','crash')],bridge=fake,timeout=5)
except m._bridge.BridgeClosed as exc:
    assert exc.completed.returncode==7 and b'intentional nonzero' in exc.completed.stderr
else:raise AssertionError('child nonzero did not fail')
phase='callback-failure'
def fail(rows):raise AssertionError('intentional-callback-failure')
try:observed([('a','first'),('b',fail)],bridge=fake,timeout=5)
except AssertionError as exc:
    assert str(exc)=='intentional-callback-failure' and exc.completed.returncode==0
    assert exc.completed.stdin_bytes==b'first\n' and b'first' in exc.completed.stdout
else:raise AssertionError('callback exception lost')
case=m.TimberCapacityHost('test_placed_history_uses_current_preview_token_and_one_undo')
m.TimberCapacityHost.setUpClass()
from tests.test_geo261_native_kernel import native
build=native();(OUT/'build-log.json').write_bytes((build.work/'build-log.json').read_bytes())
(OUT/'product-bridge').write_bytes(pathlib.Path(case.bridge).read_bytes());(OUT/'product-bridge').chmod(0o700)
control_results=[];callback=m.TimberCapacityHost.placed_delete_confirmation
for phase in ('baseline','withdrawn','restored'):
    if phase=='withdrawn':
        def withdrawn(self,rows,command):callback(self,rows,command);return 'dump'
        m.TimberCapacityHost.placed_delete_confirmation=withdrawn
    else:m.TimberCapacityHost.placed_delete_confirmation=callback
    suite=unittest.TestSuite([m.TimberCapacityHost('test_placed_history_uses_current_preview_token_and_one_undo')])
    with (OUT/(phase+'.log')).open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    failures='\n'.join(trace for _,trace in result.failures)
    row={'phase':phase,'exit':0 if result.wasSuccessful() else 1,'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped)}
    control_results.append(row)
    if phase=='withdrawn':assert row['failures']==1 and row['errors']==0 and 'placed-delete-confirm-must-commit' in failures
    else:assert row['exit']==0 and not row['skips']
save(OUT/'RESULT.json',{'exit':0,'controls':control_results,'batches':records,'test_sha256':hashlib.sha256(raw).hexdigest(),'product_source':'b595e55952d5d66de95024432e1b29bec7525e9b'})
print(json.dumps({'exit':0,'controls':control_results}),flush=True)
