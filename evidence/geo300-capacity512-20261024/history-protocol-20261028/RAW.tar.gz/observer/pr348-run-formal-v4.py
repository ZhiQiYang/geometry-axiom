import argparse,gzip,hashlib,io,json,os,pathlib,resource,shutil,subprocess,sys,tarfile,time,unittest
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);p.add_argument('--durable',required=True);p.add_argument('tests',nargs='+');a=p.parse_args()
root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();durable=pathlib.Path(a.durable).resolve()
out.mkdir(parents=True,exist_ok=False);durable.mkdir(parents=True,exist_ok=False)
assert shutil.disk_usage(out).free>=64*1024*1024
assert shutil.disk_usage('/tmp').free>=64*1024*1024,'native libc tmpfile uses actual /tmp, independently of TMPDIR'
assert shutil.disk_usage(durable).free>=512*1024,'512 KiB planned complete text checkpoint budget unavailable'
os.chdir(root);sys.path.insert(0,str(root));os.environ['GIT_NO_LAZY_FETCH']='1'
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
assert not dirty,dirty
def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
request={'command':sys.argv,'cwd':str(root),'source_sha':sha,'tracked_dirty':dirty,'tests':a.tests,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stack_bytes':16384*1024,'temporary_directory':os.environ.get('TMPDIR'),'measurement':'Original unittest methods, assertions and 600-second per-batch timeout; Popen wait4 child usage; lossless durable checkpoint after each completed batch','capacity_before':{str(x):shutil.disk_usage(x)._asdict() for x in (out,durable)}}
save(out/'REQUEST.json',request);shutil.copy2(__file__,out/'OBSERVER.py')
def checkpoint(name,paths):
 buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w:gz',compresslevel=6) as archive:
  for path in paths:archive.add(path,arcname=path.relative_to(out))
 data=buf.getvalue();target=durable/(name+'.tar.gz')
 assert shutil.disk_usage(durable).free>=len(data)+4096,'durable checkpoint physical space unavailable'
 with target.open('xb') as file:file.write(data);file.flush();os.fsync(file.fileno())
 assert digest(target.read_bytes())==digest(data)
 # Read every stored member, detecting incomplete archives independently.
 with tarfile.open(target,'r:gz') as archive:
  for member in archive:
   if member.isfile():assert len(archive.extractfile(member).read())==member.size
 save(durable/(name+'.json'),{'source_sha':sha,'archive':target.name,'bytes':len(data),'sha256':digest(data),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
checkpoint('request',[out/'REQUEST.json',out/'OBSERVER.py'])
OriginalPopen=subprocess.Popen;processes=[]
class MeasuredPopen(OriginalPopen):
 def __init__(self,*args,**kw):
  self.observed_usage=None;self.observed_cwd=str(kw.get('cwd',root));self.observed_started=time.monotonic();self.communication_calls=0
  super().__init__(*args,**kw);self.observed_index=len(processes);processes.append(self)
 def communicate(self,*args,**kwargs):
  value=None;error=None
  try:value=super().communicate(*args,**kwargs);return value
  except BaseException as exc:error=exc;raise
  finally:
   d=out/'commands'/f'{self.observed_index:04d}-{self.communication_calls}';d.mkdir(parents=True,exist_ok=False);self.communication_calls+=1
   record={'command':[str(x) for x in self.args] if not isinstance(self.args,str) else self.args,'cwd':self.observed_cwd,'source_sha':sha,'actual_exit':self.returncode,'memory':self.observed_usage,'elapsed_seconds':time.monotonic()-self.observed_started,'timeout_seconds':kwargs.get('timeout'),'exception':type(error).__name__ if error else None}
   for index,field in enumerate(('stdout','stderr')):
    data=value[index] if value is not None else getattr(error,field,None);data=data or b'';data=data.encode() if isinstance(data,str) else data;(d/(field+'.bin')).write_bytes(data);record[field+'_sha256']=digest(data)
   payload=kwargs.get('input',args[0] if args else None)
   if payload is not None:(d/'stdin.bin').write_bytes(payload.encode() if isinstance(payload,str) else payload)
   save(d/'RESULT.json',record)
 def _try_wait(self,wait_flags):
  try:
   pid,status,usage=os.wait4(self.pid,wait_flags)
   if pid:self.observed_usage={'maxrss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime}
   return pid,status
  except ChildProcessError:return self.pid,0
subprocess.Popen=MeasuredPopen
from tests import _bridge
original_once=_bridge.run_once;rows=[]
def observed_once(data,**kwargs):
 if shutil.disk_usage(out).free<64*1024*1024:raise RuntimeError('ENVIRONMENT: unchanged 64 MiB publication reserve unavailable')
 if shutil.disk_usage('/tmp').free<64*1024*1024:raise RuntimeError('ENVIRONMENT: actual native tmpfile mount below 64 MiB reserve')
 d=out/f'batch-{len(rows):03d}';d.mkdir();payload=data.encode() if isinstance(data,str) else data;(d/'stdin.bin').write_bytes(payload)
 exe=pathlib.Path(kwargs['bridge']);identity={'path':str(exe),'bytes':exe.stat().st_size,'mode':exe.stat().st_mode,'sha256':digest(exe.read_bytes())};save(d/'BINARY.json',identity)
 if not rows:
  from tests.test_geo261_native_kernel import native
  b=native();shutil.copy2(b.work/'build-log.json',out/'build-log.json');shutil.copy2(exe,out/'product-bridge')
  checkpoint('build',[out/'build-log.json',d/'BINARY.json',out/'commands'])
 fixtures=[]
 for line in payload.decode('utf-8').splitlines():
  if line.startswith('loadfile '):
   path=pathlib.Path(line[9:]);blob=path.read_bytes();name='fixture-'+str(len(fixtures))+'.scene';(d/name).write_bytes(blob);fixtures.append({'original_path':str(path),'saved':name,'bytes':len(blob),'sha256':digest(blob)})
 save(d/'FIXTURES.json',fixtures);t=time.monotonic();start=len(processes);result=None;error=None
 print(json.dumps({'batch_start':d.name,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timeout_seconds':kwargs.get('timeout',20),'binary_sha256':identity['sha256']}),flush=True)
 try:result=original_once(data,**kwargs);return result
 except BaseException as exc:error=exc;raise
 finally:
  proc=processes[-1] if len(processes)>start else None
  row={'source_sha':sha,'binary':identity,'timeout_seconds':kwargs.get('timeout',20),'seconds':time.monotonic()-t,'actual_exit':proc.returncode if proc else None,'memory':proc.observed_usage if proc else None,'exception':type(error).__name__ if error else None,'command':proc.args if proc else None}
  captured=result if result is not None else getattr(error,'completed',error)
  for field in ('stdout','stderr'):
   value=getattr(captured,field,None);value=value or b'';value=value.encode() if isinstance(value,str) else value;(d/(field+'.bin')).write_bytes(value);row[field+'_sha256']=digest(value)
  rows.append(row);save(d/'RESULT.json',row)
  paths=[d]+[path for path in (out/'commands').glob('*') if int(path.name.split('-')[0])>=start]
  checkpoint(d.name,paths);print(json.dumps({'batch_end':d.name,**row}),flush=True)
_bridge.run_once=observed_once
from tests import test_geo261_timber_capacity_host as history
original_dialogue=history.run_placed_dialogue
def observed_dialogue(commands,**kwargs):
 if shutil.disk_usage(out).free<64*1024*1024:raise RuntimeError('ENVIRONMENT: unchanged 64 MiB publication reserve unavailable')
 if shutil.disk_usage('/tmp').free<64*1024*1024:raise RuntimeError('ENVIRONMENT: actual native tmpfile mount below 64 MiB reserve')
 d=out/f'batch-{len(rows):03d}';d.mkdir()
 exe=pathlib.Path(kwargs['bridge']);identity={'path':str(exe),'bytes':exe.stat().st_size,'mode':exe.stat().st_mode,'sha256':digest(exe.read_bytes())};save(d/'BINARY.json',identity)
 if not rows:
  from tests.test_geo261_native_kernel import native
  b=native();shutil.copy2(b.work/'build-log.json',out/'build-log.json');shutil.copy2(exe,out/'product-bridge')
  checkpoint('build',[out/'build-log.json',d/'BINARY.json',out/'commands'])
 fixtures=[]
 for _,command in commands:
  if isinstance(command,str) and command.startswith('loadfile '):
   path=pathlib.Path(command[9:]);blob=path.read_bytes();name='fixture-'+str(len(fixtures))+'.scene';(d/name).write_bytes(blob);fixtures.append({'original_path':str(path),'saved':name,'bytes':len(blob),'sha256':digest(blob)})
 save(d/'FIXTURES.json',fixtures);save(d/'COMMAND_NAMES.json',[name for name,_ in commands]);t=time.monotonic();start=len(processes);result=None;error=None
 print(json.dumps({'batch_start':d.name,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timeout_seconds':kwargs.get('timeout',600),'binary_sha256':identity['sha256'],'protocol':'dynamic actual-token confirmation'}),flush=True)
 try:result=original_dialogue(commands,**kwargs);return result
 except BaseException as exc:error=exc;raise
 finally:
  proc=processes[-1] if len(processes)>start else None;captured=result if result is not None else getattr(error,'completed',None)
  row={'source_sha':sha,'binary':identity,'timeout_seconds':kwargs.get('timeout',600),'seconds':time.monotonic()-t,'actual_exit':proc.returncode if proc else None,'memory':proc.observed_usage if proc else None,'exception':type(error).__name__ if error else None,'command':proc.args if proc else None,'protocol':'dynamic actual-token confirmation'}
  for field,attr in (('stdin','stdin_bytes'),('stdout','stdout'),('stderr','stderr')):
   value=getattr(captured,attr,b'') or b'';(d/(field+'.bin')).write_bytes(value);row[field+'_sha256']=digest(value)
  row['reply_names']=getattr(captured,'reply_names',None)
  rows.append(row);save(d/'RESULT.json',row);checkpoint(d.name,[d]);print(json.dumps({'batch_end':d.name,**{k:v for k,v in row.items() if k!='reply_names'}}),flush=True)
history.run_placed_dialogue=observed_dialogue
t=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromNames(a.tests)
with (out/'unittest.log').open('w') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
record={**request,'exit':0 if result.wasSuccessful() and not result.skipped else 1,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-t,'batches':rows,'tracked_dirty_after':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)}
save(out/'RESULT.json',record);checkpoint('final',[out/'RESULT.json',out/'unittest.log']);print(json.dumps({k:v for k,v in record.items() if k!='batches'}),flush=True);raise SystemExit(record['exit'])
