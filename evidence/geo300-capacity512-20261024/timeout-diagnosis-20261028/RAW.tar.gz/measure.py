import argparse,hashlib,json,os,pathlib,resource,subprocess,threading,time
p=argparse.ArgumentParser();p.add_argument('--exe',required=True);p.add_argument('--input',required=True);p.add_argument('--out',required=True);p.add_argument('--sha',required=True);p.add_argument('--timeout',type=int,default=600);a=p.parse_args()
out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True);exe=pathlib.Path(a.exe).resolve();payload=pathlib.Path(a.input).read_bytes();(out/'stdin.bin').write_bytes(payload)
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
request={'command':[str(exe)],'cwd':str(out.resolve()),'source_sha':a.sha,'timeout_seconds':a.timeout,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stack_bytes':16384*1024};(out/'REQUEST.json').write_text(json.dumps(request,indent=2));print('START '+json.dumps(request),flush=True)
expired=[];t=time.monotonic()
with (out/'stdin.bin').open('rb') as si,(out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 proc=subprocess.Popen([str(exe)],cwd=out,stdin=si,stdout=so,stderr=se)
 def expire():
  expired.append(True)
  try:os.kill(proc.pid,9)
  except ProcessLookupError:pass
 timer=threading.Timer(a.timeout,expire);timer.start()
 pid,status,usage=os.wait4(proc.pid,0);timer.cancel();proc.returncode=os.waitstatus_to_exitcode(status)
result={**request,'actual_exit':proc.returncode,'timeout':bool(expired),'seconds':time.monotonic()-t,'maxrss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'minor_faults':usage.ru_minflt,'major_faults':usage.ru_majflt}
for name in ('stdin.bin','stdout.bin','stderr.bin'):
 f=out/name;result[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(out/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
raise SystemExit(1 if expired or proc.returncode else 0)
