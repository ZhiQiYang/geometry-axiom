import argparse,hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time,unittest
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);p.add_argument('tests',nargs='+');a=p.parse_args()
root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True);os.chdir(root);sys.path.insert(0,str(root))
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
request={'command':sys.argv,'cwd':str(root),'source_sha':sha,'tracked_dirty':dirty,'tests':a.tests,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stack_bytes':16384*1024,'measurement':'Popen original control flow; wait4 collects original child rusage; original unittest methods/assertions/timeouts unchanged'};(out/'REQUEST.json').write_text(json.dumps(request,indent=2))
OriginalPopen=subprocess.Popen;processes=[]
class MeasuredPopen(OriginalPopen):
 def __init__(self,*args,**kw):
  self.observed_usage=None;self.observed_cwd=str(kw.get('cwd',root));self.observed_started=time.monotonic();self.communication_calls=0;super().__init__(*args,**kw);self.observed_index=len(processes);processes.append(self)
 def communicate(self,*args,**kwargs):
  value=None;error=None
  try:value=super().communicate(*args,**kwargs);return value
  except BaseException as exc:error=exc;raise
  finally:
   d=out/'commands'/f'{self.observed_index:04d}-{self.communication_calls}';d.mkdir(parents=True,exist_ok=True);self.communication_calls+=1
   record={'command':[str(x) for x in self.args] if not isinstance(self.args,str) else self.args,'cwd':self.observed_cwd,'source_sha':sha,'actual_exit':self.returncode,'memory':self.observed_usage,'elapsed_seconds':time.monotonic()-self.observed_started,'timeout_seconds':kwargs.get('timeout'),'exception':type(error).__name__ if error else None}
   for index,field in enumerate(('stdout','stderr')):
    data=value[index] if value is not None else getattr(error,field,None);data=data or b'';data=data.encode() if isinstance(data,str) else data;(d/(field+'.bin')).write_bytes(data);record[field+'_sha256']=hashlib.sha256(data).hexdigest()
   payload=kwargs.get('input',args[0] if args else None)
   if payload is not None:(d/'stdin.bin').write_bytes(payload.encode() if isinstance(payload,str) else payload)
   (d/'RESULT.json').write_text(json.dumps(record,indent=2))
 def _try_wait(self,wait_flags):
  try:
   pid,status,usage=os.wait4(self.pid,wait_flags)
   if pid:self.observed_usage={'maxrss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime}
   return pid,status
  except ChildProcessError:return self.pid,0
subprocess.Popen=MeasuredPopen
from tests import _bridge
original_once=_bridge.run_once;rows=[]
def observed_once(data,**kwargs):
 d=out/f'batch-{len(rows):03d}';d.mkdir();payload=data.encode() if isinstance(data,str) else data;(d/'stdin.bin').write_bytes(payload);t=time.monotonic();start=len(processes);result=None;error=None
 try:result=original_once(data,**kwargs);return result
 except BaseException as exc:error=exc;raise
 finally:
  proc=processes[-1] if len(processes)>start else None
  row={'source_sha':sha,'timeout_seconds':kwargs.get('timeout',20),'seconds':time.monotonic()-t,'actual_exit':proc.returncode if proc else None,'memory':proc.observed_usage if proc else None,'exception':type(error).__name__ if error else None,'command':proc.args if proc else None}
  for field in ('stdout','stderr'):
   value=getattr(result,field,None) if result is not None else getattr(error,field,None)
   value=value or b'';value=value.encode() if isinstance(value,str) else value;(d/(field+'.bin')).write_bytes(value);row[field+'_sha256']=hashlib.sha256(value).hexdigest()
  (d/'RESULT.json').write_text(json.dumps(row,indent=2));rows.append(row)
_bridge.run_once=observed_once
t=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromNames(a.tests);result=unittest.TextTestRunner(verbosity=2).run(suite)
from tests.test_geo261_native_kernel import native
b=native();shutil.copy2(b.work/'build-log.json',out/'build-log.json')
for file in b.work.glob('*.scene'):shutil.copy2(file,out/file.name)
if b.bridge_exe:shutil.copy2(b.bridge_exe,out/'product-bridge')
record={**request,'exit':0 if result.wasSuccessful() and not result.skipped else 1,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-t,'batches':rows,'tracked_dirty_after':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)}
(out/'RESULT.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='batches'}),flush=True);raise SystemExit(record['exit'])
