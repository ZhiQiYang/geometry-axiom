import hashlib,json,os,pathlib,resource,shutil,signal,subprocess,sys,time
root=pathlib.Path('/tmp/pr348-work');out=pathlib.Path('/tmp/pr348-runs/baseline512');out.mkdir(exist_ok=True)
sys.path.insert(0,str(root));from tests.test_geo261_native_kernel import NativeBuild
from tests.geo300_scene_generator import build
resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root)
b=NativeBuild();exe=b.bridge();shutil.copy2(exe,out/'bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
text,meta=build(512,'single');(out/'input.scene').write_text(text);(out/'scene-meta.json').write_text(json.dumps(meta,indent=2))
payload=('loadfile '+str(out/'input.scene')+'\ndump\nobjects\nreferences\n').encode();(out/'stdin.bin').write_bytes(payload)
args=['/usr/bin/time','-v','-o',str(out/'memory.txt'),str(out/'bridge')]
request={'command':args,'cwd':str(out),'source_sha':source,'timeout_seconds':600,'build':'original NativeBuild O0 separate K/W/H objects, four original EXTERNAL defines','source_clean_before_build':True,'binary_sha256':hashlib.sha256((out/'bridge').read_bytes()).hexdigest(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};(out/'REQUEST.json').write_text(json.dumps(request,indent=2));print('BASELINE_BUILD_READY '+json.dumps(request),flush=True)
t=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 proc=subprocess.Popen(args,cwd=out,stdin=subprocess.PIPE,stdout=so,stderr=se,start_new_session=True)
 try:proc.communicate(payload,timeout=600);timeout=False
 except subprocess.TimeoutExpired:
  # Kill only this invocation's bridge, allowing GNU time to retain actual rusage.
  children=pathlib.Path('/proc')/str(proc.pid)/'task'/str(proc.pid)/'children'
  for pid in children.read_text().split():os.kill(int(pid),signal.SIGKILL)
  proc.communicate(timeout=10);timeout=True
result={**request,'actual_exit':proc.returncode,'timeout':timeout,'seconds':time.monotonic()-t}
for name in ('stdin.bin','stdout.bin','stderr.bin','memory.txt','input.scene'):
 f=out/name;result[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(out/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
sys.exit(1 if timeout or proc.returncode else 0)
