# 八項 face-run 測試的獨立靜態複核

結論：**未見阻斷，可交 root 實跑。** 僅讀測試與產品；未編譯、未執行、不改任何原件。對應產品 patch SHA-256 `8f3081f7dacf96c77ce6b9ed79b5fff52a3d80965d69b85e90b6305ec5d8e1c4`。

1. comparator counter 插在實際 `contact_face_index_before` 函式入口，只計原比較器呼叫；grouping 的 plane comparisons 不納入這個新 n−1 斷言，原 F*(levels+1) 裁判另保留。counter 宣告在使用前，現有頭檔提供 uint64_t/INT64 常數，CLIENT 附加於原 C 檔後可見 private static 型別與函式。link 沒有重複原 contact_world object，未見顯性 C/連結型別問題。
2. sorted128/127 的 `(fixed,lo)` 資料非遞減且含真 ties。每次兩個非空run合併恰有一次boundary比較；從n個singleton連成一個run，共n−1次。無右run不比較，故127的尾端也成立；empty/single均0次。copy前後比完整out bytes，rank/group/maximum檢查範圍正確。
3. unsorted 固定 expected `{3,1,5,7,2,6,0,4}` 依 INT64_MIN、-1、2、INT64_MAX 全寬 plane，再依lo穩定排序，結果正確。ordinal1/5與2/6各有相同 `(fixed,lo)`，可辨識不穩定tie；不是從產品比較器重算expected。
4. coverage 真索引先無witness，再插face0 `[0,100]@7`；face1被覆蓋、face2僅接觸不覆蓋、`4294967303` plane不等7、左右部分越界不覆蓋。再次build把maximum全部清零，沒有沿用上一輪witness。

三個撤回均能由靜態路徑推到指定具名斷言：

- `remove-skip`：sorted128走原merge，每level64次、7levels，共448次比較，不等127；首先命中 `contact-face-ordered-runs-linear-comparisons`。
- `unconditional-skip`：所有block原樣copy，unsorted最後仍0..7；在metadata檢查之前命中 `contact-face-unsorted-stable-full-coordinate-order`。
- `unstable-tie`：比較器 `<=` 改 `<`，最後merge相同key採右run，ordinal1/5與2/6反序（形成 `{3,5,1,7,6,2,0,4}`）；同一具名stable-order斷言正常紅，無需crash或timeout。

driver每組都有baseline0／mutant1與指定assertion／restored0，case不接受signal作kill。現有測試檔與其斷言未改；三個撤回只有這份產品副本。

未驗事項：C實際編譯、八項真終態、原W既有正反例及正式512/H7；本報告只證明靜態設計沒有目前可見阻斷，不等於已通過。此純索引小案例也不能代替真產品collector/provider整合結果。
