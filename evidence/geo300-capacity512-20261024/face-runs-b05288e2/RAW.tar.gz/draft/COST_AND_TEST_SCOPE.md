# 真 512 profile 與本片邊界

profile 來源為 `8b128aa7bf53b41b493dd3a0bee49f0d53391254`，檔案
`/dev/shm/pr348-profile-512-8b-recovered/gprof.txt`，SHA-256
`9b879c910b9edea63296e0402572e342058cebf3a1e2f925920fbe3eea1165eb`。
該次原執行 exit 0、wall 371.171276565 秒；stdout
`47da66d3264fbe943e01e9085d26e73f4ad7317de7e1b41d48d64fd6f4b6c784`
與正式 512 相同。以下全部是 gprof sampled self，總分母 **184.80 秒**，不是 wall time。

| 函式／歸因 | sampled self 秒 | calls | 能否由本片移除 |
|---|---:|---:|---|
| contact_face_index_before | 8.24 | 1,903,147,722 | 有序相鄰 runs 可少比較；未有序仍需原 merge |
| 該 before 呼叫的 plane_compare | 2.45 | 1,903,147,722 | 同上；保留原完整座標比較器 |
| contact_face_index_build | 6.88 | 526,882 | 僅減部分 merge scalar loop；初始化、copy、group 不消失 |
| 其餘 plane group compare | 0.35 | 271,054,478 | 本片不減 |
| contact_face_index_covered | 8.35 | 270,527,596 | 本片不減；每 query 仍 fresh witness |
| contact_order_slot | 5.34 | 856,057,668 | 本片不減 |

`index_build` 的 callgraph inclusive 是 18.17 秒，約總 sampled 9.83%；其中 before＋其 child 10.69 秒約 5.78%。這是受影響成本所在，不是可消除量、預測加速或 H7 會通過的證據。未知真實 512 runs 有序比例；快路還增加各非有序 block 的一次 boundary 比較。必須以父代理固定來源實跑判定淨收益。

原先 prepared-cache 的 immutable envelope（build、before、plane compare、min_size、member sort、order-index 與其 slot）至多歸屬 20.64 sampled 秒、11.17%；其中仍含不可省的 zero/reset/copy。N128 的忽略 exclude 等價 24,548 次，只證明可準備重用，不能乘此比例推算 N512 時間。三介面、lifecycle／nested guard／optional allocation 的風險與改動較大，因此本輪**不實作 prepared cache**。

## 本片產品靜態複核

另一代理產產品 draft，本代理逐行核對：只插入每 block 的無右 run／已整體有序判斷和原序 memcpy；獨立的 sorted、scratch 陣列不重疊。左 run 非空；右 run 缺席會短路，不讀越界。相同 `(fixed,lo)` 保持左 run 先，與原 `<=` merge 一致。沒有修改原 plane grouping、rank、maximum、public out、provider、容量或失敗路徑。沒有配置或持久狀態。

## 新增獨立 8 案（尚未執行）

`tests/test_geo300_contact_face_runs.py` 使用既有 NativeBuild 和原始收據記錄器，對複製的真產品 `contact_face_index_before` 加單純 counter，並在同 TU 呼叫真 static index／coverage 函式。未以另一份排序實作替代。

1. 128 項已排好：比較數精確 `n−1`，所有 public bytes、stable ordinal、rank、plane range、fresh maximum。
2. 127 項同上，涵蓋不完整尾 run。
3. empty／singleton：零比較。
4. 未排序且相同 key、INT64_MIN/MAX：固定預期 ordinal 與 plane metadata。
5. coverage：fresh index 無舊 witness、單一足寬 witness 成功、touching／partial／不同高 32 位 plane 失敗、重建清空舊 active。
6. 撤回 skip：原完整 merge 必須在 `contact-face-ordered-runs-linear-comparisons` 紅，恢復綠。
7. 無條件 skip：必須在 `contact-face-unsorted-stable-full-coordinate-order` 紅，恢復綠。
8. tie 改 `<`：先以 `contact-face-equal-keys-retain-original-ordinal` 獨立裁判紅，恢復綠；原完整 ordinal 比較仍保留。無條件 skip 仍保留原 ordinal 的兩組 tie 順序，因此通過此項後在完整排序裁判紅，兩種缺陷不混為同名。

`n−1` 是 n 葉合併樹內部節點數；不是新時間／性能門檻。舊 W 測試與全部 mutation anchors 原封不動，原完整 collector／bridge 對照仍應依父代理排程執行；新增 static-index 用例不冒充那些整合結果。

建議執行命令（**本代理未跑**）：

```sh
python3 -B -m unittest tests.test_geo300_contact_face_runs -v
python3 -B -m unittest tests.test_geo261_wood_contact_world -v
```

本代理只做 AST 語法解析、hash 與差異核對，沒有編譯、測試、計時、Git 操作或 active 寫入。產品收益、八案終態和原 W 反證均待實跑。
