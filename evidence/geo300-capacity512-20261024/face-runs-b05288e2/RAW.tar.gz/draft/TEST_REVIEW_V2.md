# Face-run 測試 v2：僅具名紅分離差異複核

結論：**此差異正確；兩個語意撤回現在會落在不同具名斷言。** 未編譯、未執行；保留原 TEST_REVIEW.md，不改產品或測試。

核對 test SHA-256：`b236f08fbec4a49379688a5c8180eefdf8ca1d23547f2590933da913dcabb6e9`。
父代理提供完整 patch SHA-256：`11ac0807eab964f54abad5f56a709d3114519103dfe226b357562ed6c516d684`；此輪只檢查測試差異，未另重驗整包patch。

新增的 `index.rank[1]<index.rank[5] && index.rank[2]<index.rank[6]` 在完整expected比對之前：

- 正常穩定排序 `{3,1,5,7,2,6,0,4}` 兩項皆真。
- strict-tie `<` mutant 形成 `{3,5,1,7,6,2,0,4}`，兩項皆反向；首先命中 `contact-face-equal-keys-retain-original-ordinal`，與driver新expected相同。
- unconditional-skip 留原序0..7，rank也是原序，故此新增斷言兩項皆真；接續完整expected仍命中 `contact-face-unsorted-stable-full-coordinate-order`。
- remove-skip仍由 ordered128的127次比較要求命中 `contact-face-ordered-runs-linear-comparisons`。

rank在原build最後完整賦值，這個前置斷言不讀未初始化欄位。三個具名紅分別辨識工作量、整體排序與穩定tie；沒有放寬原完整expected或其他測試。實際0/1/0仍待root執行。
