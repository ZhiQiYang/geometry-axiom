# Face merge 有序區塊快路：私有未執行草稿

只改 `contact_face_index_build` 的每個 bottom-up merge block：右run不存在，或左run最後一項依原比較器不晚於右run第一項時，將整個連續區塊 memcpy 到 scratch，再處理下一區塊。沒有反向拼接捷徑，沒有新增幾何判定或快取。

固定檔案：

- base contact_world.c SHA-256：`098e507656cbdc33db4e8b1be840e97c6145418f5740c7b798f95f89f9e7cf59`
- candidate SHA-256：`d8611bafdd674082c2f9e3a954e55d26b791b9e6cdf111a341705c5f77164b16`
- product.patch SHA-256：`8f3081f7dacf96c77ce6b9ed79b5fff52a3d80965d69b85e90b6305ec5d8e1c4`

## 靜態不變性

初始 sorted[i]=i；每輪開始時各run已依原 `(fixed,lo)` 非遞減排列。當 `before(last-left,first-right)` 為真，左右所有元素的聯集已依比較器排列；直接串接與原 merge 輸出完全相同。同 key 時原比較器 `lo<=` 選左run，串接同樣保留左run在前，因此 stable ties 不變。

`middle==end` 表示沒有右run；short-circuit 不讀 `sorted[middle]`。left<count且width>=1使左run非空；只有存在右run才讀 middle-1 和 middle。copy 來源 sorted、目的 scratch 是原兩個不同陣列；copy範圍是原block `[left,end)`。原每輪 sorted←scratch、width更新以及後續rank/plane/group/maximum初始化全部不改。

public out陣列不由此函式重排；active、Fenwick insertion/query、placement排序、容量、exclude、provider、source graph也都未改。

## 舊 plane 次數上限仍成立

令m為一個block總元素數：

- 無右run：0次比較。
- 已整體有序：1次boundary比較，m>=2，所以<=m。
- 無法走快路：1次boundary比較，加原merge至多m−1次比較，合計<=m。

同一level的block互不重疊且覆蓋F項，所以每level<=F；levels=ceil(log2F)，後續group總比較<=F−1，總和<=F*levels+F−1<=原 `F*(levels+1)`。沒有增加原門檻。

舊order-read反證只改member排序路徑，本快路不增加/減少它的order reads。舊plane-range撤回在F=128例仍對每個coverage query及先前face insertion做原二分查找；不能因少掉merge比較就把重複plane lookup偽裝成group-once。實際具名紅仍須由原測試執行確認，不能以此推算替代收據。

## 靜態預檢與撤回錨點

`STATIC_PREFLIGHT.json` 記錄：移除唯一插入區塊後完整還原原檔；`test_geo261_wood_contact_world.py` 410/413/416/422/425 的5個既有work-bound撤回anchor，在base及candidate均恰好一次。沒有修改測試。

新快路唯一條件錨點：

`if(middle==end||contact_face_index_before(out,index->sorted[middle-1],index->sorted[middle])){`

停用這個分支須讓父代理新增的排序工作量斷言具名轉紅，恢復轉綠。新增counter測試由父代理負責，尚未整合在本patch。

**未編譯、未執行、未測時、未修改active來源。** 本稿不是N512/H7通過證據；採入後依root排程跑原W正反例與新具名撤回，另由peer審查。
