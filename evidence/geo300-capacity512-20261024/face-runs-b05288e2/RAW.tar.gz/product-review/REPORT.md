# PR #348：face merge 七行捷徑對抗審查

**純靜態審查未發現 blocking。** 此 patch 可以交原 W 回歸與新具名撤回實測；本報告沒有編譯或執行產品，不能當作通過收據。

固定來源與原件：

- base：`8b128aa7bf53b41b493dd3a0bee49f0d53391254` 的 `geometry-templates/woodworking/native/contact_world.c`。
- base 檔 SHA-256：`098e507656cbdc33db4e8b1be840e97c6145418f5740c7b798f95f89f9e7cf59`。
- candidate 檔 SHA-256：`d8611bafdd674082c2f9e3a954e55d26b791b9e6cdf111a341705c5f77164b16`。
- `/dev/shm/pr348-face-merge-draft/product.patch` SHA-256：`8f3081f7dacf96c77ce6b9ed79b5fff52a3d80965d69b85e90b6305ec5d8e1c4`。
- 僅插入 7 行；從 prototype 移除該唯一區塊後，逐 byte 還原固定 base。未以已變動的 active 檔冒充基底。

## 正確性與邊界

每個 level 開始時，既有 bottom-up merge 的每個 run 都已依 `(fixed, lo)` 排序且 stable。左 run 最後一項若依原 inclusive 比較器不晚於右 run 第一項，左右 run 的直接串接就是原逐項 merge 的同一個有序、穩定結果。這只是複製已經排好的 index 區段，沒有修改 public out 或改成新幾何比較器。

- `count=0`：初始、merge、group loops 均不進入，沒有任何新增讀取。呼叫者本來也不會查不存在的 face。
- `count=1`：`sorted[0]=0`、`maximum[0]=0`；merge loop 不執行，group 正常設定 rank/scratch/plane_end。不存在未初始化 scratch 被複製的問題。
- 每個內層進入時 `left<count`、`width>=1`，所以 `middle>left`，`middle-1` 合法。`middle==end` 先短路，沒有右 run 時絕不讀 `sorted[middle]`，尤其 `middle==count` 不越界。
- 非二次方長度由 `min(width,count-left)` 與 `min(width,count-middle)` 截斷，仍覆蓋完整 `[left,end)`。兩種路徑都以 `left=end` 前進，沒有空迴圈或遺漏最後一個 run。
- `left+min(...)`、`middle+min(...)` 不超過 count；原 width 倍增前 `width>=count-width` 的守門保持。實際 caller 限定 `count<=WOOD_CONTACT_FACE_CAPACITY`，copy bytes 也在固定陣列內。
- fixed 用 `(a>b)-(a<b)`，lo 用 `<=`；不做座標相減或窄化。`INT64_MIN`／`INT64_MAX` 不新增 overflow。hi 不參與排序鍵的既有規則不變。
- 相同 fixed/lo 時 `<=` 讓左 run 先出，直接串接也是左先，因此相等鍵的原 ordinal／其他 face 欄位順序不變。

## scratch、maximum 與重用

新增 memcpy 的來源 `sorted` 與目的 `scratch` 是同 struct 裡兩個不重疊的獨立固定陣列；被複製的元素數最多是 count。每個 block 不論走 memcpy 或原 while merge，都完整寫入其 `[left,end)`。同 level 的 blocks 互不重疊且覆蓋 `[0,count)`，因此其後整段 `sorted ← scratch` 不會讀到上一輪／上一用途的殘值。

member-sort 可能先使用 index buffers，但 face-index-build 開頭仍逐項重寫全部 sorted 與 maximum=0。所有 level 完成後，原 group loop 仍為每個實際 face 重寫 rank、scratch（此時轉作 plane begin）、plane_end。maximum 的清零在任何捷徑前，未被 continue 跨過。前一次查詢的 Fenwick 值不會經本 patch 留到下次查詢。

count 之外的陣列尾部保持舊規則：不需初始化，也不應被任何 query 使用。未新增跨 query／跨 World 快取。

## 原工作量上限不需放寬

令一個 block 有 L 個元素：

- 沒右 run：新增比較為 0。
- 可以串接：只做 1 次 boundary 比較，L>=2。
- 不能串接：1 次 boundary 比較 + 原 merge 至多 L−1 次，總計至多 L。

每層 blocks 覆蓋 F 個元素，所以每層最多 F 次 plane 比較；共有 ceil(log2 F) 層。最後 grouping 仍最多 F−1 次。因此 F>=1 時總比較數至多 `F*ceil(log2 F)+F−1`，不超過原 `F*(levels+1)`。F=0 時比較為 0。另一子代理獨立檢查此算式及非二次方 scratch 覆蓋，未見反例。

新分支沒有 contact_order 讀取，原 order-read 上限不變。member-sort 以及它的原 uint64 穩定／RC prefix／duplicate fallback 路徑不變。原 plane-range 撤回仍對每次 insertion/query 重做二分查找；此七行不移除那些呼叫。其具名紅燈是否仍命中，交主代理實跑，不以靜態推算冒充 killed。

## 舊測試與前置核對

唯讀核對原 `test_geo261_wood_contact_world.py`：41 個 CONTROLS 的真實 anchor 在 base/candidate 均各 1 次；所有能命中產品原文的既有長 literal 出現次數也沒有變化，包含原 5 個 work-bound 替換片段。未修改原 tests、assertions、容量或 timeout。

前置腳本第一次直接 literal_eval 整張 CONTROLS 表時，因該表含 STOP_FILTER 的名稱與 replace 表達式而結束碼 1，未進產品。改用只含兩個常數表定義的 AST 字串求值後完成上述 41 項計數；沒有編譯或執行任何測試。這不屬於產品紅燈。

## 新測試仍需真實交付

本輪依主代理要求先審產品，未等待／未審正在編寫的新 tests。建議原計畫至少用真 comparator 計數與 independent stable oracle 覆蓋有序、交錯、相同鍵、非二次方尾段、0/1 及最大容量；撤回捷徑應保持輸出正確但由具名工作量斷言轉紅，恢復轉綠。poisoned scratch/maximum 後重建可抓初始化遺漏。已將這些範圍告知測試作者，已有覆蓋的不要重複補。

沒有實際效能取樣；不能僅以少比較推定能滿足 N512 或 H7 期限。原 K hint-tag 的 62／172 綠與無收益 pair 是主代理另批結果，不是本 W patch 的證據。未採的 K tag 不應混入本 W source 身份。
