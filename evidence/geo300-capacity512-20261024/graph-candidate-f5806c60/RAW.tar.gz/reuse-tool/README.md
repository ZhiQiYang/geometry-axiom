# #348：沿用原 B 收據，只執行新 fix 的 ordered graph 比較

這是一次固定來源的最小 wrapper，不改原 compare_graphs.py；直接使用原 `run`、`same_file`、`same_graph`。**本代理只做 AST 語法檢查與唯讀 build metadata 核對，尚未執行本 wrapper 或新比較。**

## 固定身分

- 原 base execution：`9a8584f57be7935604c3bad4c2481945a6ec3d9f`。
- 新 fix execution：`f5806c60c6067a64776f979f77981e4aba087df3`。
- 原根目錄172場景與原base兩種執行：`/dev/shm/pr348-graph-root-b595`。
- 原base build：`/tmp/pr348-graph-audit/build-base-v2`（只讀，不執行）。
- 新fix build：`/dev/shm/pr348-graph-fix-f580`（root已建置；不是本代理的執行）。
- 已發布原件：[E18c0056d packed-index-b595e559](https://github.com/ZhiQiYang/geometry-axiom/tree/18c0056d9004353cdd90099ff1fa93fe0d85f841/evidence/geo300-capacity512-20261024/packed-index-b595e559)。`BASE_MANIFEST.json` 是 root 自該固定Git提交讀出的原 MANIFEST，SHA256 `e0bedbdb939114dd3395d89b352275f90356ffe108f4dd827a545036a86d8ad7`。
- 原 RAW.tar.gz SHA256：`33a3b5ad029f7d084f38fca9f0453514d1608f556d1c078c02d17e22e27a025d`。本 wrapper 不重新複製／下載archive；逐檔與其固定manifest相核，REUSE_FILES.json保留原archive member路徑、bytes/hash和本地位置。

原 B 不是 R8 ELF，也不是新 F 的 execution。以前該包 B→b595 的 fix 收據不當成此次 f580 執行；本次只沿用同一個已完成 B。

## 入場核對與比較

1. 鎖原 driver SHA、manifest SHA、172 INVENTORY、原 SUMMARY完整exit0；核所有採用的scene、base build與base REQUEST/RESULT/streams/gzip/markers逐檔hash。
2. 每scene核來源9a、完整scenebytes、原指令/cwd、600s、16MiB stack、binary pins、exit0、完整stdout/stderr；gzip逐byte讀完重算原raw SHA/bytes，核5guards、seal count及marker存在；base plain與trace stdout/stderr必須一致。
3. 新build必須是固定f580、原monolithic C11 O0旗標、兩ELF實際hash、相同trace_definition。新source manifest的每個原輸入檔仍須吻合建置時hash。
4. 新兩子程序使用**原 scenes 的同一絕對路徑**，stdin `loadfile <path>\ndump\n` 不換路徑、不做任何輸出正規化。原 run逐子程序維持600秒/16MiB/64MiB發布reserve，完整保存新stdout/stderr/graph/guards/seals及真正execution SHA。
5. 比較新plain/trace自洽、B與F stdout/stderr逐byte、所有seal的ordered graph逐byte、原5guards文字逐byte與seal count。一般執行/比較紅收齊所有scene；只有真容量或工具不可恢復時中止，保留完成數和未跑範圍，不重試挑樣本。

只寫指定 `/dev/shm` 新OUT（不可已存在）；原B/scene/build不寫入、不重編／重跑。入場以舊base留存量兩倍加16MiB作本次工作估算，另保留原64MiB reserve；此估算不是產品判準。每次原run仍監看實際掛載free。此 wrapper不修改mount、安全設定或timeout；原生libc既有tmpfile路徑也未改。SHM為揮發性，完成後須root一次保存／推送新原件才算交付。

## root審查後的待執行命令

```sh
LANG=C.UTF-8 LC_ALL=C.UTF-8 python3 -B /dev/shm/pr348-reuse-graph/compare.py --fix /dev/shm/pr348-graph-fix-f580 --out /dev/shm/pr348-graph-reuse-f580
```

本代理沒有執行此命令。這項是原172場景的圖／串流診斷，不是分離K/W/H的正式512 H7，不替代1200s完整suite或帳本／架構。
