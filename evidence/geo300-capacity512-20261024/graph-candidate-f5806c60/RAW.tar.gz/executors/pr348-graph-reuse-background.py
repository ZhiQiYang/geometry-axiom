import pathlib,subprocess,json,time,os
out=pathlib.Path('/dev/shm/pr348-graph-reuse-background');out.mkdir(exist_ok=False)
command=['python3','-B','/dev/shm/pr348-reuse-graph/compare.py','--fix','/dev/shm/pr348-graph-fix-f580','--out','/dev/shm/pr348-graph-reuse-f580']
env={**os.environ,'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
for key in ('GEO261_GRAPH','GEO261_GUARDS','GEO261_TRACE_END'):env.pop(key,None)
record={'command':command,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid()}
(out/'REQUEST.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'outer.log').open('wb') as log:
 p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env);record['child_pid']=p.pid;code=p.wait()
record.update(exit=code,seconds=time.monotonic()-start,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
