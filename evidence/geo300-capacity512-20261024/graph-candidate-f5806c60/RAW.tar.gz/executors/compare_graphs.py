#!/usr/bin/env python3
"""PR348 ordered-seal diagnostic. New execution; never an R8/B1 receipt.

build copies only the actual quoted C closure and instruments a private copy.
compare runs four processes per case and streams trace bytes through a FIFO
into a lossless gzip artifact. Original stdout/stderr/guards are retained.
"""
import argparse, gzip, hashlib, json, os, re, resource, shutil, signal
import subprocess, sys, threading, time
from pathlib import Path

HERE=Path(__file__).resolve().parent
GUARDS=['app_world_candidate_create','app_world_candidate_seal',
        'app_world_candidate_publish','app_world_candidate_revalidate','reference_check_all']
RESERVE=64*1024*1024
TIMEOUT=600

def sha(data):return hashlib.sha256(data).hexdigest()
def save(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def capacity(p):
    if shutil.disk_usage(p).free<RESERVE:raise RuntimeError('ENVIRONMENT: below unchanged 64 MiB publication reserve')
def stack():
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
    if hard!=resource.RLIM_INFINITY and hard<16777216:raise RuntimeError('16 MiB stack unavailable')
    resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))

def closure(root,revision):
    rows={};todo=[root/'geometry-web/web_bridge.c']
    while todo:
        p=todo.pop().resolve();rel=p.relative_to(root).as_posix()
        if rel in rows:continue
        data=p.read_bytes();blob=git(root,'rev-parse',revision+':'+rel).decode().strip()
        assert sha(data)==sha(git(root,'show',revision+':'+rel)),('dirty source',rel)
        rows[rel]={'bytes':len(data),'sha256':sha(data),'git_blob':blob}
        for inc in re.findall(rb'^\s*#\s*include\s*"([^"\r\n]+)"',data,re.M):
            child=p.parent/os.fsdecode(inc)
            if child.is_file():todo.append(child)
    return rows

def trace_definition():
    s=(HERE/'ORIGINAL_TRACE.c.txt').read_text()
    s=s.replace('static unsigned long long residual_guards[5];',
        'static unsigned long long residual_guards[5], residual_seals;')
    old='    if(fclose(f))exit(93);\n}'
    new='''    if(fclose(f))exit(93);
    path=getenv("GEO261_TRACE_END");if(!path)exit(100);
    f=fopen(path,"w");if(!f)exit(100);
    fprintf(f,"%llu\\n",residual_seals);if(fclose(f))exit(100);
}'''
    assert s.count(old)==1;s=s.replace(old,new)
    old='{static int ready;if(!ready){ready=1;atexit(residual_finish);}++residual_guards[i];}'
    assert s.count(old)==1
    s=s.replace(old,'{++residual_guards[i];}\nstatic void residual_begin(void){atexit(residual_finish);}')
    old='const char *path=getenv("GEO261_GRAPH");if(!path)return;'
    assert s.count(old)==1;s=s.replace(old,old+'++residual_seals;')
    return s.encode()

def build(a):
    root=a.root.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False);capacity(out)
    revision=git(root,'rev-parse','HEAD').decode().strip();assert revision==a.sha
    rows=closure(root,revision);save(out/'SOURCE.json',{'source_sha':revision,'root':str(root),'files':rows})
    tree=out/'trace-source'
    for rel in rows:
        p=tree/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/rel).read_bytes())
    for rel,names in [('geometry-app/native/world_candidate.inc',GUARDS[:3]),
                      ('current_geometry.c',GUARDS[3:4]),('geometry-core/references.inc',GUARDS[4:]),
                      ('geometry-core/kernel/source.c',['geo_eval_seal'])]:
        p=tree/rel;s=p.read_bytes()
        for name in names:
            matches=list(re.finditer(rb'\b'+name.encode()+rb'\s*\([^;{}]*\)\s*\{',s))
            assert len(matches)==1,(name,len(matches));at=matches[0].end()
            hook=b'residual_trace_seal(ctx);' if name=='geo_eval_seal' else ('residual_guard(%d);'%GUARDS.index(name)).encode()
            s=s[:at]+hook+s[at:]
        p.write_bytes(s)
    p=tree/'geometry-web/web_bridge.c';s=p.read_bytes()
    anchor=b'int GEOMETRY_BRIDGE_ENTRYPOINT(void)\n{'
    assert s.count(anchor)==1,('bridge main anchor',s.count(anchor))
    s=s.replace(anchor,anchor+b'residual_begin();')
    prefix=b'struct GeoEvalContext;static void residual_trace_seal(const struct GeoEvalContext *);static void residual_guard(unsigned);static void residual_begin(void);\n'
    p.write_bytes(prefix+s+trace_definition())
    commands=[]
    for role,source in [('plain',root),('trace',tree)]:
        cmd=[a.cc,'-std=c11','-'+a.optimization,str(source/'geometry-web/web_bridge.c'),'-o',str(out/role),'-lm']
        start=time.time();r=subprocess.run(cmd,cwd=root,capture_output=True,timeout=300)
        (out/(role+'.build.stdout')).write_bytes(r.stdout);(out/(role+'.build.stderr')).write_bytes(r.stderr)
        row={'command':cmd,'cwd':str(root),'started_epoch':start,'seconds':time.time()-start,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}
        commands.append(row);save(out/'BUILD.json',{'source_sha':revision,'commands':commands})
        assert r.returncode==0,row
        row['binary_sha256']=sha((out/role).read_bytes())
        capacity(out)
    # gcc supplies the actual active includes, rather than trusting all textual fallback paths.
    cmd=[a.cc,'-std=c11','-'+a.optimization,'-MM',str(root/'geometry-web/web_bridge.c')]
    r=subprocess.run(cmd,cwd=root,capture_output=True,timeout=300)
    (out/'dependencies.stdout').write_bytes(r.stdout);(out/'dependencies.stderr').write_bytes(r.stderr)
    assert r.returncode==0
    deps=r.stdout.decode().replace('\\\n',' ').split(':',1)[1].split()
    actual={str(Path(d).resolve().relative_to(root)) for d in deps}
    assert actual<=set(rows),sorted(actual-set(rows))
    assert closure(root,revision)==rows,'donor changed during build'
    save(out/'BUILD.json',{'source_sha':revision,'commands':commands,'actual_dependencies':sorted(actual),
        'dependency_command':cmd,'dependency_exit':r.returncode,'trace_definition_sha256':sha(trace_definition()),
        'kind':'new PR348 monolithic diagnostic builds; not the formal separated -O0 H7 build','exit':0})
    print('BUILD',revision,a.optimization,'exit0',flush=True)

def stream_fifo(fifo,dest,state,ready):
    try:
        h=hashlib.sha256();size=0
        with open(fifo,'rb',buffering=0) as source,open(dest,'xb') as raw:
            ready.set()
            with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
                while True:
                    chunk=source.read(65536)
                    if not chunk:break
                    capacity(dest.parent);h.update(chunk);size+=len(chunk);gz.write(chunk)
        state.update(bytes=size,sha256=h.hexdigest(),complete=True)
    except BaseException as e:state['error']=repr(e)
    finally:ready.set()

def run(exe,scene,out,source_sha,trace):
    out.mkdir(parents=True,exist_ok=False);capacity(out)
    payload=('loadfile '+str(scene)+'\ndump\n').encode();(out/'stdin.bin').write_bytes(payload)
    env=os.environ.copy();fifo=out/'graph.fifo';keep=None;worker=None;state={};ready=threading.Event()
    if trace:env.update(GEO261_GRAPH=str(fifo),GEO261_GUARDS=str(out/'guards.txt'),GEO261_TRACE_END=str(out/'trace-end.txt'))
    row={'source_sha':source_sha,'command':[str(exe)],'cwd':str(scene.parent),'stdin_sha256':sha(payload),
        'binary_sha256':sha(exe.read_bytes()),'scene_sha256':sha(scene.read_bytes()),'timeout_seconds':TIMEOUT,
        'stack_bytes':16777216,'started_epoch':time.time(),'trace':trace,
        'environment':{k:env.get(k) for k in ['LANG','LC_ALL','GEO261_GRAPH','GEO261_GUARDS','GEO261_TRACE_END']}}
    save(out/'REQUEST.json',row);started=time.monotonic();reason=None;rusage=None;status=None;p=None;error=None
    process_end=None;process_end_epoch=None
    try:
        if trace:
            os.mkfifo(fifo);keep=os.open(fifo,os.O_RDWR|os.O_NONBLOCK)
            worker=threading.Thread(target=stream_fifo,args=(fifo,out/'graph.bin.gz',state,ready),daemon=True);worker.start()
            if not ready.wait(timeout=10) or state.get('error'):raise RuntimeError('FIFO reader did not become ready: '+repr(state))
        with open(out/'stdout.bin','xb') as stdout,open(out/'stderr.bin','xb') as stderr:
            p=subprocess.Popen([str(exe)],stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,cwd=scene.parent,
                env=env,preexec_fn=stack,start_new_session=True)
            p.stdin.write(payload);p.stdin.close()
            while True:
                waited,status_now,usage=os.wait4(p.pid,os.WNOHANG)
                if waited:status=status_now;rusage=usage;break
                if reason is None:
                    if time.monotonic()-started>=TIMEOUT:reason='TIMEOUT'
                    elif state.get('error'):reason='TRACE_STORAGE_ERROR'
                    elif shutil.disk_usage(out).free<RESERVE:reason='ENVIRONMENT_RESERVE'
                    if reason:os.killpg(p.pid,signal.SIGKILL)
                time.sleep(.05)
            p.returncode=os.waitstatus_to_exitcode(status)
            process_end=time.monotonic();process_end_epoch=time.time()
    except BaseException as e:
        error=repr(e);reason=reason or 'CAPTURE_EXCEPTION'
    finally:
        if p is not None and p.returncode is None:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:
                _,status,rusage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
                process_end=time.monotonic();process_end_epoch=time.time()
            except ChildProcessError:pass
        if keep is not None:os.close(keep)
        if worker:
            worker.join(timeout=30)
            if worker.is_alive():reason=reason or 'TRACE_COLLECTOR_DID_NOT_FINISH'
    row.update(seconds=process_end-started if process_end is not None else None,
        ended_epoch=process_end_epoch,capture_seconds=time.monotonic()-started,capture_ended_epoch=time.time(),
        exit=p.returncode if p is not None else None,stopped_reason=reason,error=error,
        maxrss_kib=rusage.ru_maxrss if rusage else None,user_seconds=rusage.ru_utime if rusage else None,
        system_seconds=rusage.ru_stime if rusage else None,maxrss_scope='wait4 direct bridge child; excludes gzip collector')
    for channel in ['stdout','stderr']:
        path=out/(channel+'.bin')
        if path.is_file():
            data=path.read_bytes();row[channel]={'bytes':len(data),'sha256':sha(data)}
        else:row[channel]={'present':False}
    if trace:
        row['graph']=state
        end=out/'trace-end.txt';guards=out/'guards.txt'
        row['trace_end_present']=end.is_file();row['guards_present']=guards.is_file()
        try:
            if end.is_file():row['seal_count']=int(end.read_text().strip())
            if guards.is_file():row['guards']=list(map(int,guards.read_text().split()))
        except (ValueError,OSError) as e:row['marker_error']=repr(e)
        # Gzip readback verifies retained raw bytes; a missing/incomplete artifact never becomes empty equality.
        if state.get('complete'):
            h=hashlib.sha256();n=0
            with gzip.open(out/'graph.bin.gz','rb') as f:
                while True:
                    chunk=f.read(65536)
                    if not chunk:break
                    h.update(chunk);n+=len(chunk)
            row['gzip_roundtrip_verified']=(n==state['bytes'] and h.hexdigest()==state['sha256'])
    save(out/'RESULT.json',row)
    assert reason is None and error is None and p is not None and p.returncode==0,row
    if trace:
        assert not worker.is_alive() and state.get('complete') and not state.get('error'),row
        assert not row.get('marker_error') and row['trace_end_present'] and row['guards_present'] and len(row['guards'])==5,row
        assert row['gzip_roundtrip_verified'],row
        assert (row['seal_count']==0)==(state['bytes']==0),row
    return row

def same_file(a,b):
    with open(a,'rb') as x,open(b,'rb') as y:
        while True:
            aa=x.read(65536);bb=y.read(65536)
            if aa!=bb:return False
            if not aa:return True

def same_graph(a,b):
    with gzip.open(a,'rb') as x,gzip.open(b,'rb') as y:
        while True:
            aa=x.read(65536);bb=y.read(65536)
            if aa!=bb:return False
            if not aa:return True

def _compare(a):
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=False);a.created_out=out;capacity(out)
    builds={'base':a.base.resolve(),'fix':a.fix.resolve()}
    sources={};pins={}
    for role,folder in builds.items():
        meta=json.loads((folder/'BUILD.json').read_text());assert meta.get('exit')==0,('build incomplete',role)
        assert re.fullmatch('[0-9a-f]{40}',meta['source_sha']);sources[role]=meta['source_sha'];pins[role]={}
        for mode in ['plain','trace']:
            entries=[r for r in meta['commands'] if Path(r['command'][r['command'].index('-o')+1]).name==mode]
            assert len(entries)==1 and entries[0]['exit']==0,(role,mode,'missing successful build')
            expected=entries[0]['binary_sha256'];actual=sha((folder/mode).read_bytes())
            assert expected==actual,(role,mode,'binary changed since recorded build')
            pins[role][mode]=actual
    root=a.corpus.resolve();revision=git(root,'rev-parse','HEAD').decode().strip()
    names=[n for n in git(root,'ls-tree','--name-only',revision).decode().splitlines() if n.endswith('.scene')]
    if a.only:names=[n for n in names if n in a.only]
    elif not a.all_root:
        if a.extra:names=[]
        else:raise ValueError('Choose --only, --all-root, or explicit --extra; no implicit long run')
    assert names or a.extra
    scenes=out/'scenes';scenes.mkdir();inventory=[]
    for name in sorted(names):
        data=git(root,'show',revision+':'+name);(scenes/name).write_bytes(data)
        inventory.append({'name':name,'source_sha':revision,'bytes':len(data),'sha256':sha(data)})
    for extra in a.extra:
        p=Path(extra).resolve();assert p.name not in [r['name'] for r in inventory]
        data=p.read_bytes();(scenes/p.name).write_bytes(data)
        inventory.append({'name':p.name,'external_source':str(p),'bytes':len(data),'sha256':sha(data)})
    save(out/'INVENTORY.json',inventory);results=[];failures=[]
    save(out/'SUMMARY.json',{'source_shas':sources,'binary_pins':pins,'completed':0,'planned':len(inventory),'state':'RUNNING','exit':None})
    for item in inventory:
        scene=scenes/item['name'];runs={};case=out/'cases'/scene.name
        for role,build in builds.items():
            runs[role]={}
            for mode in ['plain','trace']:
                assert sha((build/mode).read_bytes())==pins[role][mode],(role,mode,'binary changed after admission')
                run_out=case/role/mode
                runs[role][mode]=run(build/mode,scene,run_out,sources[role],mode=='trace')
            for channel in ['stdout','stderr']:
                assert same_file(case/role/'plain'/(channel+'.bin'),case/role/'trace'/(channel+'.bin')),(scene.name,role,'instrumentation changed '+channel)
            if 'external_source' in item:
                replies=[json.loads(line) for line in (case/role/'plain'/'stdout.bin').read_bytes().splitlines()]
                assert len(replies)==2 and all(reply.get('ok') is True for reply in replies),(scene.name,role,'capacity fixture load/dump must succeed',replies)
        checks={channel:same_file(case/'base'/'plain'/(channel+'.bin'),case/'fix'/'plain'/(channel+'.bin')) for channel in ['stdout','stderr']}
        checks['ordered_graph_all_seals']=same_graph(case/'base'/'trace'/'graph.bin.gz',case/'fix'/'trace'/'graph.bin.gz')
        checks['five_guards_raw']=same_file(case/'base'/'trace'/'guards.txt',case/'fix'/'trace'/'guards.txt')
        checks['seal_counts']=runs['base']['trace']['seal_count']==runs['fix']['trace']['seal_count']
        results.append({'scene':scene.name,'checks':checks,'runs':runs})
        failures += [{'scene':scene.name,'check':k} for k,v in checks.items() if not v]
        save(out/'SUMMARY.json',{'source_shas':sources,'binary_pins':pins,'completed':len(results),'planned':len(inventory),'failures':failures,'results':results,'state':'RUNNING','exit':None})
        print('CASE',len(results),'/',len(inventory),scene.name,'PASS' if all(checks.values()) else 'FAIL',flush=True)
    assert not failures,failures
    save(out/'SUMMARY.json',{'source_shas':sources,'binary_pins':pins,'completed':len(results),'planned':len(inventory),'failures':failures,'results':results,'state':'COMPLETED','exit':0})

def compare(a):
    try:_compare(a)
    except BaseException as e:
        if hasattr(a,'created_out'):
            p=a.created_out/'SUMMARY.json'
            data=json.loads(p.read_text()) if p.is_file() else {'completed':0,'planned':None}
            data.update(state='FAILED',exit=1,error=repr(e));save(p,data)
        raise

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    b=sub.add_parser('build');b.add_argument('--root',type=Path,required=True);b.add_argument('--sha',required=True);b.add_argument('--out',type=Path,required=True)
    b.add_argument('--cc',default='gcc');b.add_argument('--optimization',choices=['O0','O2'],default='O0')
    c=sub.add_parser('compare');c.add_argument('--base',type=Path,required=True);c.add_argument('--fix',type=Path,required=True);c.add_argument('--corpus',type=Path,required=True);c.add_argument('--out',type=Path,required=True)
    c.add_argument('--only',action='append',default=[]);c.add_argument('--all-root',action='store_true');c.add_argument('--extra',action='append',default=[])
    a=p.parse_args();(build if a.mode=='build' else compare)(a)
if __name__=='__main__':main()
