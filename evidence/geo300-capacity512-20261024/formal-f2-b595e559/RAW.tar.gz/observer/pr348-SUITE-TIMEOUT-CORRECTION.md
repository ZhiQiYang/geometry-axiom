原先將Suite建構子的預設900秒誤套到H7。固定F2 tests/run_all.py:530實際以PY_NEEDS[stem],1200登錄Python suites。已更正兩份私有說明為原H7 suite1200秒；未更動原runner、600秒batch或35分鐘CI時限。這是記錄更正，不能當作門檻調整。
