#!/bin/bash
set -eu
export GIT_NO_LAZY_FETCH=1
export TMPDIR=/dev/shm/pr348-run-temp
# Run only after the original two placed methods release the exclusive slot.
# Their successful receipts are not rerun by this complementary command.
python3 -B /tmp/pr348-runs/run_formal_v2.py \
  --root /dev/shm/pr348-formal-b595 \
  --out /dev/shm/pr348-post-formal-controls-b595 \
  tests.test_geo300_validation_memo \
  tests.test_geo261_wood_contact_world \
  tests.test_geo261_timber_capacity \
  tests.test_geo261_timber_capacity_host.TimberCapacityHost.test_actual_host_independent_admission_storage_and_scratch_values \
  tests.test_geo261_timber_capacity_host.TimberCapacityHost.test_each_real_declaration_retains_legacy_64_and_admits_up_to_512 \
  tests.test_geo261_timber_capacity_host.TimberCapacityHost.test_full_capacity_redeclaration_replay_and_rejected_edit_preserve_history \
  tests.test_geo261_timber_capacity_host.TimberCapacityHost.test_real_bridge_guard_withdrawal_uses_safe_incomplete_declaration_then_restores \
  tests.test_geo261_timber_capacity_host.TimberCapacityHost.test_real_host_compile_contract_rejects_each_drifted_capacity
