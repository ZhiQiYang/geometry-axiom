# F2 一次 N128 靜態剖析診斷（非正式驗收）

來源固定 `b595e55952d5d66de95024432e1b29bec7525e9b`，唯讀 checkout `/dev/shm/pr348-formal-b595`。未執行 Git/fetch，原 `.git` worktree HEAD 直接讀取得到此 SHA；全部 C/H/inc 與建置入口雜湊前後一致。建置與輸出只寫本目錄；沒有產品修改。

實際只執行一次 N128：2026-10-28T22:05:53Z 開始，10.439190711997071 秒，exit 0、timeout false，16 MiB stack、原 600 秒限制。wait4：user 10.366532 秒、system 0.070437 秒、maxrss 83,828 KiB、minor faults 43,178、major faults 0。原動態診斷的 child_maxrss 是累積 RUSAGE_CHILDREN，不能拿本次 wait4 峰值宣稱 RSS 改善。

建置沿用 NativeBuild 的所有 O0 與 pg 設定，只在 product-bridge 最終連結增加 `-static`。60 筆建置命令／原始 stdout／stderr／exit 在 build-log.json；私有路徑正規化只用於建置命令身分比較，不處理產品輸出。靜態 ELF 2,230,344 bytes，SHA256 `fa75c5a08aa00d6697731ec1a29f763fe173b53b46a71c045d18fc335f50311b`，readelf 確認無 dynamic section。

輸入直接複用原 N128 stdin（包含原 input.scene 絕對路徑），逐 byte 未改；stdout 146,252 bytes 與 stderr 0 bytes 的 cmp 均 exit 0。stdout SHA256 `a14ede9bef3dc03c850145a45a51f7b079fea958a5f0df6e4c7928fe3ae25b6a`。

## 同一份 gmon.out 的具體結果

- 一般 flat profile 的可見 self 合計 6.59 秒。
- `geo_source_index_append`：0.91 秒，11,980,478 次；仍是可見產品首位。
- `geo_source_node`：0.39 秒，15,848,086 次；`geo_source_find_node`：0.34 秒，13,274,312 次。
- libc `__memset_avx512_unaligned_erms`：0.58 秒；`__memmove_avx512_unaligned_erms`：0.56 秒；`__memcmp_evex_movbe`：0.14 秒。
- `contact_face_index_covered`：0.29 秒，7,185,332 次；`contact_order_slot`：0.22 秒，29,406,656 次；`reference_contact_facts`：0.20 秒，77,181 次；`contact_face_index_build`：約 0.19 秒，50,232 次。
- 顯式指定 `--flat-profile=__mcount_internal --time=__mcount_internal` 讀同一份 gmon，得到原一般報告排除的 2.07 秒。
- 同 ELF 的 `_mcount` 與 weak `mcount` 是同一地址 0x52e020。指定 `_mcount` 未選到 gprof 使用的別名，工具輸出落回一般 flat（原件仍保留，不能當成獨立 mcount 值）；指定 `mcount` 得到 1.05 秒。

剖析器這兩項開銷合計約 3.12 秒，是本次 user CPU 的約 30%。因此原動態 pg 報告漏計部分不可全部歸因 memcpy/calloc，也不能把 pg 耗時直接當正式 O0 耗時。memory clear/copy 約 1.14 秒確有實測自耗時，但普通 libc.a 沒有完整 pg arcs，這份結果無法唯一指定其 caller。不可只由此裁掉任一清零／快照以冒語意等價。

## 後續界線

本次已達「辨識 libc 與 mcount 隱藏成本」目的，不再加 N64/N256、不重抽樣。真正尚未解決的產品方向仍是高次數 source-index/依賴圖構造與 contact facts 路徑；本資料只供主代理評估，不提出／套用新的產品優化。

原 H7 全 suite 1200 秒與各 batch 600 秒均未變。N128 診斷不證明 N512 或完整 suite 通過；靜態連結也不是正式建置替代。

所有原始 stdout/stderr、gmon、ELF、編譯 objects、來源副本與雜湊保留。目錄在 SHM，為揮發性；需主代理依原收件流程持久化，不可把本地路徑當遠端已交付。
