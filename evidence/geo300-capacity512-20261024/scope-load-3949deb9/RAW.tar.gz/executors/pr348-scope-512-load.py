"""One actual 512 placed-load path, original generated fixture and assertions.

Not a substitute for the complete H7 suite or its 1200-second deadline.
"""
import json,os,pathlib,resource,subprocess,sys,time,unittest
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-scope-512-load');out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root));os.environ['PYTHONDONTWRITEBYTECODE']='1'
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert sha=='3949deb9e565a9e5aeca5bc475ec646e77cc6546'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
from tests.test_geo261_timber_capacity_host import TimberCapacityHost
from tests.geo300_scene_generator import build
from tests import _bridge
from tests.test_geo261_native_kernel import native
import hashlib,shutil
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
request={'source_sha':sha,'command':sys.argv,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timeout_seconds':600,'stack_bytes':16777216,'scope':'One actual H7 fixture load, not complete canonical/history/H7 acceptance'};save(out/'REQUEST.json',request)
case=TimberCapacityHost('test_real_placed_64_and_512_load_dump_and_canonical_replay');case.setUpClass()
b=native();exe=pathlib.Path(case.bridge);shutil.copy2(exe,out/'product-bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
scene,meta=build(512,'single');path=out/'input.scene';path.write_text(scene);save(out/'scene-meta.json',meta)
payload=('loadfile '+str(path)+'\ndump\nobjects\nreferences\n').encode();(out/'stdin.bin').write_bytes(payload)
save(out/'BINARY.json',{'path':str(exe),'bytes':exe.stat().st_size,'mode':exe.stat().st_mode,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()})
class Measured(subprocess.Popen):
 usage=None
 def _try_wait(self,flags):
  pid,status,u=os.wait4(self.pid,flags)
  if pid:self.usage={'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime}
  return pid,status
t=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 p=Measured([str(exe)],stdin=subprocess.PIPE,stdout=so,stderr=se)
 try:p.communicate(payload,timeout=600);timed_out=False
 except subprocess.TimeoutExpired:p.kill();p.communicate();timed_out=True
record={**request,'exit':p.returncode,'timed_out':timed_out,'seconds':time.monotonic()-t,'usage':p.usage,'finished_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stdout_sha256':hashlib.sha256((out/'stdout.bin').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'stderr.bin').read_bytes()).hexdigest()}
save(out/'RESULT.json',record);print(json.dumps(record),flush=True)
if timed_out or p.returncode:raise SystemExit(1)
rows=[json.loads(line) for line in (out/'stdout.bin').read_bytes().splitlines()]
try:
 case.assertEqual(4,len(rows));case.assertTrue(rows[0]['ok'],rows[0])
 case.assert_placed_geometry(512,scene,rows[1],rows[2],rows[3])
 record['original_placed_geometry_assertions_exit']=0
except BaseException as error:
 record['original_placed_geometry_assertions_exit']=1;record['assertion_error']=repr(error)
 save(out/'RESULT.json',record);raise
save(out/'RESULT.json',record)
