"""One post-H7 aggregate observation; never a timing sample."""
import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-exclude-observation-8b128aa7-v2');out.mkdir(exist_ok=False);(out/'tmp').mkdir()
os.environ['TMPDIR']=str(out/'tmp');os.chdir(root);sys.path.insert(0,str(root));resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='8b128aa7bf53b41b493dd3a0bee49f0d53391254'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
baseline=pathlib.Path('/dev/shm/pr348-hk-feasibility');raw=json.loads((baseline/'candidate.json').read_text());assert raw['source_sha']==source and raw['exit']==0 and not raw['timeout_triggered'];assert digest(baseline/'candidate.stdout')==raw['stdout_sha256'] and digest(baseline/'candidate.stderr')==raw['stderr_sha256']
payload=(baseline/'stdin.bin').read_bytes();(out/'stdin.bin').write_bytes(payload)
save(out/'REQUEST.json',{'source_sha':source,'argv':sys.argv,'purpose':'One aggregate observation, no new baseline sampling and no timing verdict','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'baseline_receipt':str(baseline/'candidate.json'),'baseline_stdout_sha256':raw['stdout_sha256'],'baseline_stderr_sha256':raw['stderr_sha256']})
from tests.test_geo261_native_kernel import NativeBuild
b=NativeBuild();tool=pathlib.Path('/dev/shm/pr348-exclude-equivalence-diagnostic/instrument.py');assert digest(tool)=='5469d9c57959b2217daaf24092ec6003b28a262bbf57e00e85a931d596c3e6c1'
generated=b.woodworking/'contact-sources-observe.c';command=['python3','-B',str(tool),'--input',str(root/'geometry-templates/woodworking/native/contact_sources.c'),'--output',str(generated)]
p=subprocess.run(command,capture_output=True);(out/'instrument.stdout').write_bytes(p.stdout);(out/'instrument.stderr').write_bytes(p.stderr);save(out/'instrument.json',{'command':command,'exit':p.returncode,'tool_sha256':digest(tool)});assert p.returncode==0
shutil.copy2(generated,out/'contact-sources.instrumented.c');obj=b.compile(generated,'contact-sources-observe');objects=b.product_objects();assert objects.count(b.wood_contact_sources_object)==1;objects=[obj if p==b.wood_contact_sources_object else p for p in objects]
b.bridge();exe=b.link('diagnostic-bridge',[b.bridge_object,*objects]);shutil.copy2(exe,out/'diagnostic-bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
t=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 p=subprocess.Popen([str(exe)],stdin=subprocess.PIPE,stdout=so,stderr=se)
 try:p.communicate(payload,timeout=600);expired=False
 except subprocess.TimeoutExpired:p.kill();p.communicate();expired=True
record={'source_sha':source,'command':[str(exe)],'exit':p.returncode,'timed_out':expired,'seconds_diagnostic_only':time.monotonic()-t,'binary_sha256':digest(exe),'stdout_sha256':digest(out/'stdout.bin'),'stderr_sha256':digest(out/'stderr.bin')};save(out/'EXECUTION.json',record)
prefix=b'GEO348_EXCLUDE_EQ_AGGREGATE ';lines=(out/'stderr.bin').read_bytes().splitlines(keepends=True);extra=[line for line in lines if line.startswith(prefix)];assert len(extra)==1 and extra[0].endswith(b'\n')
stats=json.loads(extra[0][len(prefix):]);assert stats['atexit_status']==0 and stats['calls']==stats['original_hits']+stats['original_misses'] and stats['original_misses']==stats['cold_misses']+stats['same_exclude_misses']+stats['changed_exclude_misses'] and stats['changed_exclude_misses']==stats['equivalent_ignoring_only_exclude']+sum(stats['first_remaining_rejection'])
remaining=b''.join(line for line in lines if not line.startswith(prefix));same=remaining==(baseline/'candidate.stderr').read_bytes() and (out/'stdout.bin').read_bytes()==(baseline/'candidate.stdout').read_bytes()
save(out/'RESULT.json',{**record,'statistics':stats,'exact_product_streams_equal':same,'not_formal_performance_acceptance':True});print(json.dumps({**record,'statistics':stats,'exact_product_streams_equal':same}),flush=True)
raise SystemExit(0 if same and p.returncode==0 and not expired else 1)
