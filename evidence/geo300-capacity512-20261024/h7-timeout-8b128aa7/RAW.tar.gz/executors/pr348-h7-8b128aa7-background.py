import pathlib,subprocess,json,time,os,sys,shutil,resource
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-h7-8b128aa7-background');out.mkdir(exist_ok=False)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='8b128aa7bf53b41b493dd3a0bee49f0d53391254'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
assert shutil.disk_usage('/tmp').free>=64*1024*1024
assert shutil.disk_usage('/dev/shm').free>=2*1024*1024*1024
memory_current=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text());memory_max=int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text());assert memory_max-memory_current>=2*1024*1024*1024
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
env={**os.environ,'TMPDIR':'/dev/shm/pr348-h7-8b128aa7-temp','PYTHONDONTWRITEBYTECODE':'1','GITHUB_SHA':sha};pathlib.Path(env['TMPDIR']).mkdir(exist_ok=False)
command=['python3','-B','/dev/shm/pr348-run-formal-remote-v6.py','--root',str(root),'--out','/dev/shm/pr348-h7-8b128aa7','--durable','/dev/shm/pr348-scope-h7-receipts/evidence/geo300-capacity512-20261024/scope-h7-3949deb9/final-8b128aa7','tests.test_geo261_timber_capacity_host']
record={'command':command,'source_sha':sha,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'suite_timeout_seconds':1200,'per_batch_timeout_seconds':600,'stack_bytes':16777216,'guards':'Original run_all.run_process and kill_tree; receipt publication time is included, no deadline extension','capacity_before':{p:shutil.disk_usage(p)._asdict() for p in ('/workspace','/tmp','/dev/shm')},'memory_before':{'current':memory_current,'max':memory_max}}
(out/'REQUEST.json').write_text(json.dumps(record,indent=2)+'\n')
sys.path.insert(0,str(root));os.chdir(root)
from tests.run_all import run_process
result=run_process(command,env,1200,cwd=root)
(out/'outer.log').write_text(result.out)
record.update(exit=result.code,timed_out=result.timed_out,seconds=result.seconds,reap_note=result.reap_note,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
raise SystemExit(0 if result.code == 0 and not result.timed_out else 1)
