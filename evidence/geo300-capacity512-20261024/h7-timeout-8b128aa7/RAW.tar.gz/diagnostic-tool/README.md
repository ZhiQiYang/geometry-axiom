# #348 exclude 以外的完整等價性：一次 aggregate 診斷

狀態：只產生私有插樁；**未編譯、未執行 C、未計時、沒有觀測結果**。未改 active、產品分支或原 `wood_contact_result_matches`。這份 probe 給 root 的既定一次 N128 診斷，不新增抽樣或性能門檻。

## 固定來源與用法

只接受 `contact_sources.c` SHA256 `394c6e5a173b3e115e5bf2ec859b226c9970d676c8e2705fd8a3b08cfe389d37`。此 leaf 在原 f580 與新 H/scope source 相同，主代理仍須綁定實際 execution SHA，不能以 leaf 相同移標來源。腳本拒絕覆寫 input 或已存在 output。

```
python3 instrument.py --input <clean-source>/geometry-templates/woodworking/native/contact_sources.c --output <new-private-path>/contact_sources.c
```

交付 `diagnostic.patch`、已產生的 `contact_sources.instrumented.c`；精確 script/output/patch hash 在 `STATIC_PREFLIGHT.json`。原 matches 全函式 SHA256 `64e508fbbc214b9d5b3085b27b366558d3e193b3a595bfcbdcdf13be72f36b95` 完整保持；移除四個精確插入會逐 byte 回到原輸入。

## 計數定義

觀測點只在原 callback／facts_valid 成功、原 `wood_contact_result_matches` 已回傳之後；`reused` 不改。沒有新增 provider、source、collection 或 cache 寫入。

- `calls/original_hits/original_misses`：原 matches 的真結果。
- `cold_misses`：原 miss 且無 memo。
- `same_exclude_misses`：原 miss、有 memo、exclude 原指標相同；不進額外全比較。
- `changed_exclude_misses`：原 miss、有 memo、exclude 原指標不同，這才是額外診斷分母。
- `equivalent_ignoring_only_exclude`：上述分母中，其餘全部原條件與完整 facts bytes／mutable member id/placed 都相同；沒有改原 miss 成 hit。
- `mismatch` 為可重疊的八槽；`first_remaining_rejection` 以相同順序分割剩餘拒絕，八槽依序為：
  1. collection 不存在、count 超原 cap、或 collection_size 不符；
  2. placement；
  3. axis；
  4. cap；
  5. **完整固定大小 facts bytes**，含 padding/unused bytes，沒有排除任何成員；
  6. snapshot shape（前後 member_count 不同，或超既有容量）；
  7. mutable member id；
  8. mutable member placed。

`facts_examined == changed_exclude_misses`。snapshot 比較只讀兩份 count 的有效共同 prefix，未初始化的舊 id/placed 尾端不讀；shape 不等獨立拒絕，絕不把短 prefix 相同當全等。`unaligned_snapshot_shape` 是這個限制的明示數量，ids/placed mismatch 在 shape 不等時只代表已觀察共同 prefix 的差異。`member_pairs_examined` 是實際比較的 pair 數，不是 query 數。

判讀自洽式：

```
calls = original_hits + original_misses
original_misses = cold_misses + same_exclude_misses + changed_exclude_misses
changed_exclude_misses = equivalent_ignoring_only_exclude + sum(first_remaining_rejection)
```

每槽 mismatch 是交集可能重疊，不能相加當 query 數。沒有新增「多少才值得做」門檻，主代理按真計數與原成本決定是否值得做 prepared 架構。

## 唯一輸出與等價要求

正常 EOF 由 `atexit` 只輸出一行：

```
GEO348_EXCLUDE_EQ_AGGREGATE { ... }
```

要求 exit 正常、行恰一、`atexit_status=0`、JSON 可解析且上述自洽式全成立。只移除此**唯一前綴且完整一行**後，剩餘 stderr 與同輸入未插樁原件逐 byte 相同；stdout 全部逐 byte 相同。不得用全域 strip／忽略一類訊息。原始 stderr 連診斷行一起保留；若缺行、黏接、crash 或退出不正常，不能稱計數完整。

額外 full-facts memcmp／id/placed pass、全域 counter、EOF stdio/atexit 都會增加工作與可能的 libc 行為；**插樁時間／RSS／配置序列不作正式效能或 allocation-failure acceptance**。限原單執行緒 CLI；不具多執行緒安全性。原程序的 geometry/provider/source 返回未改，不代表尚未執行的輸出等價已獲證明。
