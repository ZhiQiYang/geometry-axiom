#!/usr/bin/env python3
"""Private aggregate-only post-decision observer; never change memo outcome."""
import argparse
import hashlib
import json
from pathlib import Path

BASE_SHA256 = "394c6e5a173b3e115e5bf2ec859b226c9970d676c8e2705fd8a3b08cfe389d37"
HELPERS = r'''
/* Diagnostic only. Observe AFTER the original match has returned; no counter
 * feeds that decision or any product output. Full facts comparisons here are
 * extra work and must not be used as a performance sample. */
static uint64_t geo348_exclude_calls,geo348_exclude_hits,geo348_exclude_misses;
static uint64_t geo348_exclude_cold,geo348_exclude_same,geo348_exclude_changed;
static uint64_t geo348_exclude_equivalent,geo348_exclude_mismatch[8],geo348_exclude_first[8];
static uint64_t geo348_exclude_facts_examined,geo348_exclude_snapshots_examined;
static uint64_t geo348_exclude_member_pairs,geo348_exclude_unaligned_shape;
static int geo348_exclude_atexit_status=-2;
static void geo348_exclude_emit(void)
{
    fprintf(stderr,"GEO348_EXCLUDE_EQ_AGGREGATE {\"schema\":1,\"atexit_status\":%d,\"calls\":%" PRIu64 ",\"original_hits\":%" PRIu64 ",\"original_misses\":%" PRIu64 ",\"cold_misses\":%" PRIu64 ",\"same_exclude_misses\":%" PRIu64 ",\"changed_exclude_misses\":%" PRIu64 ",\"equivalent_ignoring_only_exclude\":%" PRIu64 ",\"facts_examined\":%" PRIu64 ",\"snapshots_examined\":%" PRIu64 ",\"member_pairs_examined\":%" PRIu64 ",\"unaligned_snapshot_shape\":%" PRIu64 ",\"mismatch\":[",
        geo348_exclude_atexit_status,geo348_exclude_calls,geo348_exclude_hits,geo348_exclude_misses,
        geo348_exclude_cold,geo348_exclude_same,geo348_exclude_changed,geo348_exclude_equivalent,
        geo348_exclude_facts_examined,geo348_exclude_snapshots_examined,
        geo348_exclude_member_pairs,geo348_exclude_unaligned_shape);
    for(unsigned i=0;i<8;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",geo348_exclude_mismatch[i]);
    fputs("],\"first_remaining_rejection\":[",stderr);
    for(unsigned i=0;i<8;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",geo348_exclude_first[i]);
    fputs("]}\n",stderr);
}
static void geo348_exclude_observe(const WoodContactResultMemo *memo,
    const WoodContactQuery *q,const WoodContactSourceFacts *facts,bool original_match)
{
    ++geo348_exclude_calls;
    if(original_match){++geo348_exclude_hits;return;}
    ++geo348_exclude_misses;
    if(!memo){++geo348_exclude_cold;return;}
    if(memo->request.exclude==q->request.exclude){++geo348_exclude_same;return;}
    ++geo348_exclude_changed;
    bool mismatch[8]={false};
    mismatch[0]=!memo->collection||memo->count>q->cap||
        memo->collection_size!=8+memo->count*WOOD_CONTACT_SOURCE_RECORD_SIZE;
    mismatch[1]=memo->request.placement_id!=q->request.placement_id;
    mismatch[2]=memo->request.along_v!=q->request.along_v;
    mismatch[3]=memo->cap!=q->cap;
    ++geo348_exclude_facts_examined;
    mismatch[4]=memcmp(&memo->facts,facts,sizeof *facts)!=0;
    size_t old_count=memo->facts.member_count,new_count=facts->member_count;
    mismatch[5]=old_count!=new_count||old_count>WOOD_CONTACT_MEMBER_CAPACITY||new_count>WOOD_CONTACT_MEMBER_CAPACITY;
    geo348_exclude_unaligned_shape+=mismatch[5];
    /* Snapshot arrays are initialized only through old_count. Compare only
     * that valid common prefix; a shape mismatch independently prevents an
     * equivalent verdict, so an untouched tail is never read. */
    if(old_count<=WOOD_CONTACT_MEMBER_CAPACITY&&new_count<=WOOD_CONTACT_MEMBER_CAPACITY){
        ++geo348_exclude_snapshots_examined;
        size_t n=old_count<new_count?old_count:new_count;
        for(size_t i=0;i<n;++i){
            ++geo348_exclude_member_pairs;
            if(memo->member_id[i]!=facts->members[i].member->id)mismatch[6]=true;
            if(memo->member_placed[i]!=facts->members[i].member->placed)mismatch[7]=true;
        }
    }
    bool rejected=false;
    for(unsigned i=0;i<8;++i){
        if(mismatch[i]){++geo348_exclude_mismatch[i];if(!rejected)++geo348_exclude_first[i];rejected=true;}
    }
    if(!rejected)++geo348_exclude_equivalent;
}
'''
TYPE_END = "    WoodContactResultMemo *result_memo;\n};"
MATCH = "        bool reused=wood_contact_result_matches(s->result_memo,q,facts);"
CREATE = "    if(!graph||!token||!facts)return NULL;"


def instrument(source):
    def once(before, after):
        nonlocal source
        count = source.count(before)
        if count != 1:
            raise ValueError(f"expected one anchor, got {count}: {before[:100]!r}")
        source = source.replace(before, after, 1)
    once("#include <string.h>", "#include <string.h>\n#include <stdio.h>\n#include <inttypes.h>")
    once(TYPE_END, TYPE_END + "\n" + HELPERS)
    once(MATCH, MATCH + "\n        geo348_exclude_observe(s->result_memo,q,facts,reused);")
    once(CREATE, CREATE + "\n    if(geo348_exclude_atexit_status==-2)geo348_exclude_atexit_status=atexit(geo348_exclude_emit);")
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != BASE_SHA256:
        raise SystemExit(f"input identity mismatch: {digest} != {BASE_SHA256}")
    if args.input.resolve() == args.output.resolve():
        raise SystemExit("refuse to overwrite source")
    result = instrument(raw.decode("utf-8")).encode("utf-8")
    with args.output.open("xb") as stream:
        stream.write(result)
    print(json.dumps({"input_sha256": digest, "output_sha256": hashlib.sha256(result).hexdigest(),
                      "output_bytes": len(result), "output": str(args.output)}))


if __name__ == "__main__":
    main()
