# Aggregate 插樁的獨立靜態複核

結論：**未發現阻斷，可交 root 依原排程執行一次有界診斷。** 本複核未編譯或執行 C、未執行 instrument.py、未改產品或插樁原件；只 AST parse、唯讀比對、寫本報告。

核對固定來源：

- input SHA-256：`394c6e5a173b3e115e5bf2ec859b226c9970d676c8e2705fd8a3b08cfe389d37`
- script SHA-256：`5469d9c57959b2217daaf24092ec6003b28a262bbf57e00e85a931d596c3e6c1`
- instrumented output SHA-256：`92cdd914ed5543c6464e6e520edf8b2d5cf2dfe115cc11d1775f99feab2b2f27`

獨立檢查結果：

1. `wood_contact_result_matches` 整段逐 byte 相等。反向移除四個精確插入後完整還原 input；原 reused、返回、collector、必要配置、callback/provider 呼叫均無修改。
2. observe 在原 callback 成功、facts_valid 通過、原 matches 已返回後執行。原 hit 直接計數返回，不額外 memcmp 或掃 snapshot。
3. 只對原 miss 且 exclude 不同者分類；eight slots 為 collection 結構、placement、axis、cap、完整 facts、count shape、id、placed。cold/same-exclude 分別計數，不冒充已核完整等價。
4. memo facts 原來由完整 memcpy 初始化；current facts 原來 calloc 再經 callback/valid。完整 facts memcmp 不掃超界。snapshot 比對限雙方 count 均不大於容量時的 `min(old_count,new_count)`；shape 不同獨立拒絕 equivalent，不讀舊 snapshot 未初始化尾端。
5. observe 不配置、不呼叫 provider、不修改 facts/member/memo。只更新私有 unsigned counters。現有單執行緒 CLI 使用下無新增產品狀態。
6. 唯一新增 stderr 輸出由一次 atexit 註冊的 emit 產生，prefix 為 `GEO348_EXCLUDE_EQ_AGGREGATE `，JSON 為一個換行結束的物件；每個 query 不輸出。PRIu64 欄位/參數數量與八項陣列格式靜態相符。

解讀與未驗範圍：

- 新增 memcmp 與 common-prefix snapshot 掃描是診斷成本，不能把該輪時間當產品效能樣本。
- `first_remaining_rejection` 採欄位順序，完整 facts 不同時 slot4 會先於 shape slot5，因此 shape 的 first 值可合理為零；看各 mismatch 總數判斷多重差異。
- 等價數只代表當次 callback 後，原 matches 中除 exclude 外條件全一致；不證明 prepared path 已實作、會有足夠命中率或512驗收通過。
- atexit 註冊失敗、signal/timeout/_Exit 等沒有執行 EOF handler 的情況，缺 aggregate 應明列未取得診斷，不能作零命中。未驗多執行緒使用；本插樁未宣稱 thread-safe。
- 尚未執行 stdout/stderr 等價比較。實跑後須只移除唯一指定 aggregate 行，再與相同來源未插樁輸出精確比對，保留全部原件。
