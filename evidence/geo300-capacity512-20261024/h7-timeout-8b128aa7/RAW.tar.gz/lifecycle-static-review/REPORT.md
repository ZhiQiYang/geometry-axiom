# PR #348：驗證生命週期靜態審查

審查來源：`8b128aa7bf53b41b493dd3a0bee49f0d53391254`，工作樹 `/dev/shm/pr348-diagnostic-c754`；讀取時 tracked status 為乾淨。僅唯讀原碼與既有 profile，沒有編譯、啟動產品、測試、修改 active 或 Git。H7 正式結果由主代理回收，本報告不宣告通過。

## 結論

**沒有找到可證明為「完全相同 World、相同求值狀態、同一裁判責任」的高成本整套重複驗證，可在現有限制下直接去除。** 407 次 clear 不等於 407 次完整 validation。原 N128 診斷只做了 138 次完整重驗，主要是 128 次放置各自改變世界後的必要重驗。三段 member pass 共享同一個 ReferenceEval／K graph，並沒有各自重開 source context。

唯一明顯的重複生命週期動作是對已空的 graph 再 reset；它不包含 provider 求值，原 profile 中全部 clear 合計 sampled self 僅 0.01 秒，不能解釋 512 正式 timeout，也不是值得增加分支／快取的高收益方向。檔案末尾及內建 default 的最終驗證有可能看到與最後一行相同的幾何定義，但承擔不同的完整性／最終 graph 留存責任，不能以 World 指標或看似相同的定義略過。

## 既有原件與來源邊界

- 原 profile：`/dev/shm/pr348-scope-profile-3949/gprof.txt`，SHA-256 `974ccef766a99cc0a6a497b9e6fa8b298fc1f2555f880578f31502b4f5acac22`。
- 其真正 execution source 是 `3949deb9e565a9e5aeca5bc475ec646e77cc6546`，不是本次靜態來源；`REQUEST.json` 記錄 O0、分離編譯、gprof 診斷，原上限 600 秒。不得移標或當正式效能收據。
- 原 stdin：`loadfile input.scene`、`dump`、`objects`、`references`；bridge 啟動另有內建 default。
- fixture SHA-256：`594198d1de504a4e9df7ca57d7dc9a6220f9bc041ef7f8a7e886586da07729c5`；128 支、單房，surface/grid 加上逐支 timber/place。
- `3949… → 8b128…` 的生命週期檔（transactions、references、app_candidate、world_candidate、candidate）沒有變動。current_geometry/reference_sources 的差異僅是主代理已採的 raw contact 死工作刪除，不改以下 reset／validation caller。因此舊計數可供靜態歸因，但不可直接斷言新版本時間。
- gprof 遞迴 cycle 的 child-time 分攤不是各次呼叫的實測 wall time，本報告只採用可對帳 call counts，不把其 default/load 歸屬秒數當可靠分段時間。

## 407 次 clear 的完整對帳

| 動作 | 次數 | 原件位置／真實 callsite | 是否整套重驗 |
|---|---:|---|---|
| `app_scene_file_line → geo_eval_reset` | 258 | gprof:1858–1862；transactions.inc:690 | 否，逐行收尾釋放；含 128 個新 timber 宣告，這些行不重驗 |
| `reference_sources_begin_candidate → geo_eval_reset` | 138 | gprof:1858–1862；references.inc:696 | 每次重驗開頭的 source 準備 |
| `app_default_replay_line → geo_eval_reset` | 7 | gprof:1858–1862；transactions.inc:818 | 否，固定 default 的七個可合用 frame 行收尾 |
| `geo_eval_destroy → geo_eval_clear` | 4 | gprof:1765–1767、2401–2404；source.c:245 | 終結四個有 graph 的 candidate |
| 合計 | **407** | 258 + 138 + 7 + 4 | **完整 validation 仍只有 138** |

`geo_eval_destroy` 函式本身為 8 次：4 次首次 `geo_candidate_evaluate` 對初始 NULL graph 的 destroy，不進 clear；4 次實體終結才進 clear（candidate.c:42、56、132–134，source.c:245）。`reference_sources_dispose` 遇 borrowed graph 不 destroy（references.inc:156、698）。另一子代理已獨立唯讀核對這個算式。

## 138 次完整驗證的狀態對帳

gprof:785–803、824–836：`world_revalidate`／`world_revalidate_candidate` 各 138。每次 `reference_parameters_rebuild`、`reference_rebuild`、`reference_check_all`、`world_validate_derived` 各一次。

| caller | 次數 | World／操作差異 |
|---|---:|---|
| `apply_reference_place → reference_checked` | 131 | 檔案 128 支 + default 3 支。references.inc:848–850 寫新的 anchor/order/placed，再重驗。每一支之後的已放置集合不同 |
| `apply_spec_line → reference_checked` | 1 | default 新增 named value；references.inc:741–750 |
| `apply_reference_guide → reference_checked` | 1 | default 新增 guide；references.inc:767–779 |
| `apply_surface_combined_line` | 2 | default 與檔案各新增一個 surface |
| `apply_grid_line` | 1 | 檔案新增 grid |
| `parse_scene_file` 收尾 | 1 | 全檔能力／完整性檢查後，建立最終可 seal graph |
| `app_replace_evaluate` 收尾 | 1 | default 九行完成、revision 還原後，建立可 publish 的最終 graph |
| 合計 | **138** | 131 + 1 + 1 + 2 + 1 + 1 + 1 |

檔案 258 個 eligible 行正是 surface、grid、128 個 timber、128 個 place。新 timber 宣告不重做整套驗證；`apply_timber_line` 透過 W declaration 寫入，未置放的新增物件不會進 placed pass。新 place 一定新增已放置集合，所以這 128 個 source context 不能視作不變 World 的重複。

另一個交叉核對：各主要 placed pass 的實際總 member 次數為 **8397**。檔案的逐次放置是 1+…+128=8256，收尾再掃 128，default 的既有各階段加總 13，合計 8397。`app_reference_end_faces` 為 25191=8397×3，對應推導、引用全量檢查、W 全量檢查三個既有位置，並非額外 3×128 個 World context。

## 同一候選內的真正順序

1. `app_candidate_evaluate` 先驗 before bytes，釋放舊 evaluation state，K 建新 graph（app_candidate.c:83–95；candidate.c:123–149）。
2. `world_revalidate_candidate` 在定義協調後，`reference_parameters_rebuild → reference_sources_begin_candidate` 開始唯一 shared ReferenceEval（current_geometry.c:6291–6302；references.inc:690–715）。
3. engineering、assembly、profile、finish、grid、binding 等階段仍可能寫 derived 值；`reference_rebuild` 清 guide resolved 與 placed，再依定義重建（references.inc:716–732）。它會取得已存在 evaluation_state，不重開 graph。
4. `reference_check_all` 收集全世界獨立失敗，包含 I8a 診斷；它用同一個 graph（references.inc:641–686；reference_sources.inc:685–690）。
5. PF support 與 enclosure 重建位於兩個檢查之間（current_geometry.c:6343–6352）；不能一般假定 World 位元組完全沒變。
6. `world_validate_derived → wood_world_validate_members` 驗 grid、placement probe、stop/end、同面 overlap、軸向等；不建立第二個 ReferenceEval。最後 `app_reference_sources_valid` 留存同 graph 的 version inventory，再 seal/publish。

兩個全量檢查重疊一些幾何條件，但不是可以刪一個的同義呼叫：reference pass 收完整多錯診斷、在 rebuild 失敗後仍執行；W pass 有其 grid/rule、放置 probe、primary axis 與不同錯誤優先序。原 M97／M98 分別守不同位置。此審查不建議略過 provider、縮 graph、合併或刪除任何 validation。

## 看似同 World、實際不能直接跳過的邊界

### 檔案逐行 → 最後收尾

`app_scene_file_line`（transactions.inc:669–699）先保存該行 before World，執行原 parser，describe 所有 sources／拒絕 ACTIVE node，恢復 operation bytes，釋放 evaluation_state 並 reset graph。失敗則還原該行 World。

`parse_scene_file` 收尾（current_geometry.c:10134–10164）另驗未放置、grid-card capability、source-rule highwater、assembly generation integrity、PF capability，之後才完整 revalidate。其 `g_subgrid_before` 已由每行的 before 還原到檔案外層值；最終 graph 被 retained 供 outer seal，不等同每行已銷毀的 graph。最後一行恰為 place 也不能單憑此事重用前一次 graph。沒有收集過兩個完整 World 與全部 ambient state 相等的位元組證明，也沒有更改這個安全邊界。

### default 九行 → 最後收尾

`reference_default_world_owned` 維持 fixed-lines/empty-domain gate，七行共 frame、spec/guide 仍走原 inner。`app_replace_evaluate`（web_bridge.c:201–211）在完成九行後先恢復 revision，再完整重驗以保留 outer graph。這是常數次啟動工作，不可能解釋 N512 的主成長；不建議為此改 contract。

### preview → confirm

`app_world_candidate_revalidate`（current_geometry.c:6411–6420）明確要求：current／operation seal／revision／provider stamp 全過，reopen 丟棄原 graph，再重新 evaluate/seal。after 定義可能未變，但確認的驗證時間及 provider 生命週期不同。不能把保留候選或 before/after 相等當作省略 I8a 重驗的授權。

### undo/redo 與 sequential history

`history_undo`／`history_redo`（current_geometry.c:3029–3038）直接透過受管快照回復，加 revision，沒有整套 world_revalidate。`apply_interactive_tokens`（3047–3129）對每個新 declaration/place 使用原 candidate，group 結尾僅未放置檢查。這裡沒有在每次 history 快照後再多跑一套不必要的 validation。

## 對 H7 正式測試的含義

`test_real_placed_64_and_512_load_dump_and_canonical_replay`（tests/test_geo261_timber_capacity_host.py:339–357）故意做原 fixture load、canonical fresh 第一次、canonical fresh 第二次，逐 byte 比較兩次完整回覆。它們各在獨立子程序，各有原 600 秒上限，不能合併成同程序快取以節省時間。

`test_real_placed_512_sequential_replay_and_safe_513_history`（359–404）另有 load 對照及逐行建構／拒絕／preview-confirm／undo-redo。這些是不同正式路徑，不是可以靠少執行一次產品來收掉的重複測試。本報告未更動任何內外 timeout；整 suite 的排程耗時不應誤標成單個 600 秒 gate 的結果。

## 建議與未驗界線

- 不採「每支三次同 World 全量重驗」假說；它由 clear 次數誤讀而來。
- 不新增跨候選 prepared cache 或 last-validated World shortcut。既有 graph 已在一次 validation 的三個 phase 間共用；跨 place 的 World 是不同的。
- 現有 source graph 微優化與已採 dead raw contact 修正可按原正式試驗繼續裁決。這次靜態生命週期追蹤沒有找到更高收益且可直接證為純重複的入口，不應為追求速度擴成新機制。
- 若後續仍逾時，保留當前實測來源和原 failed receipt，再以新 profile 的實際 self hot path 決定最小修正；本報告不要求新取樣，也不宣告任何效能改善。
- 原 N128 的 call counts／舊 raw 證據未重跑；H7 終態未知，以主代理收件為準。

## 讀取的產品／測試身份（SHA-256）

- `current_geometry.c`：`e2b3f48384a27abc389f33ab4916362ff4274a38d3643f360fcd8386e81f4ca5`
- `geometry-core/references.inc`：`a7b86c299b189886f5304080305363ad6ef4676595b59c10023693066ccb5f08`
- `geometry-core/transactions.inc`：`669dca3b7ce1d2e7704b5220ec2707800251f96fbbc88e95cd7683ba8f73ba01`
- `geometry-app/native/app_candidate.c`：`dd28eaa879d09599e629f0814dbe82d693847d2a66f06c2ce03b098af3824eb9`
- `geometry-app/native/world_candidate.inc`：`d2343c7d8110763d2b01d82639f72473a12790b7a306efd4d8104ab6696a8791`
- `geometry-app/native/reference_sources.inc`：`6a0dd6e667aa1175d7d1022703165cc149bceed21efffcc0c15012cbed7a8c54`
- `geometry-core/kernel/candidate.c`：`f8dd422f016d5cd12cda5bbfcddc0c09864676cc211134697b245b30b470cc77`
- `geometry-core/kernel/source.c`：`da1ad325965a9dbbf330cda0355182a06ec54dbbb530b14ffceb53ff1b7c8424`
- `geometry-web/web_bridge.c`：`e69df59bffae112e8c961f88a87f7739cc611612e7d16f1258fbeae64f7dd32c`
- `tests/test_geo261_timber_capacity_host.py`：`a6b503157d857ddcd517aecbad97c8b9a295900167372a250baaa135ab44d507`

## 新 hash withdrawal anchor 靜態複核

`8b128aa7…` 只將新測試的 hash withdrawal 由短字串（2 次）改為含 `node_index_capacity` 的完整行（1 次）。產品、原 assertions 不變；這修正了 mutant 未啟動的唯一定位錯誤。實跑裁決仍由主代理收回新 7 項結果，不把原未啟動算 killed。
