import pathlib,json,subprocess,tarfile,hashlib,shutil,collections
root=pathlib.Path('/dev/shm/pr348-active');branch='codex/geo300-capacity512-20261024';product='7a0e6dd81c54066995981393925fa46a815de2f8';prior='6061fd2b9d930b1cd233f2aabb669b943913ee3d'
def git(*args):
 p=subprocess.run(['git',*args],cwd=root,capture_output=True);p.check_returncode();return p.stdout.decode().strip()
def digest(raw):return hashlib.sha256(raw).hexdigest()
assert git('rev-parse','HEAD')==prior and not git('status','--porcelain','--untracked-files=no')
arch=pathlib.Path('/dev/shm/pr348-architecture-7a0e6dd8');probe=pathlib.Path('/dev/shm/pr348-probe297-7a0e6dd8')
ar=json.loads((arch/'receipt.json').read_text());pr=json.loads((probe/'RESULT.json').read_text());assert ar['passed'] and ar['actual_process_returncode']==0 and pr['exit_code']==0 and not pr['errors']
results=json.loads((probe/'run/results.json').read_text());scenes=results['scenes'];members=[m for s in scenes for m in s['members']]
assert len(scenes)==64 and len(members)==2936 and all(s['full_rc']==0 for s in scenes)
assert all(m['status']=='接受' and m['mode']=='原場景' and not m['omitted'] and set(m['geometry_checked'])=={'L','足跡','原點'} for m in members)
names=['product-architecture.json','product-architecture-scan.json','PRODUCT-ARCHITECTURE.md','product-architecture-receipt.json'];paths=['geometry-core/domain-decoupling/'+n for n in names]
for name,path in zip(names,paths):
 assert (root/path).read_bytes()==(arch/'refresh/previous'/name).read_bytes()
 shutil.copy2(arch/'refresh/new'/name,root/path)
git('add','--',*paths);git('commit','-m','Refresh architecture receipts for capacity hot paths');audit_sha=git('rev-parse','HEAD')
out=root/'evidence/geo300-capacity512-20261024/probe-architecture-7a0e6dd8';out.mkdir(exist_ok=False)
folders={'probe':str(probe),'probe-launcher':'/dev/shm/pr348-probe297-launcher','probe-preparation':'/dev/shm/pr348-probe297-preparation','probe-peer':'/dev/shm/pr348-probe297-peer-review','architecture':str(arch),'architecture-launcher':'/dev/shm/pr348-architecture-7a0e6dd8-launcher','architecture-peer':'/dev/shm/pr348-architecture-peer-review','product-peer':'/dev/shm/pr348-final-product-audit','architecture-object-preflight':'/dev/shm/pr348-architecture-object-preflight'}
files=['/dev/shm/pr348-run-probe297.py',__file__]
manifest=[]
with tarfile.open(out/'RAW.tar.gz','w:gz',compresslevel=6) as tar:
 for label,folder in folders.items():
  base=pathlib.Path(folder);assert base.is_dir()
  for p in sorted(base.rglob('*')):
   if not p.is_file():continue
   assert not p.is_symlink();raw=p.read_bytes();name=label+'/'+p.relative_to(base).as_posix();manifest.append({'path':name,'bytes':len(raw),'mode':p.stat().st_mode,'sha256':digest(raw)});tar.add(p,arcname=name)
 for p in map(pathlib.Path,files):
  raw=p.read_bytes();name='executors/'+p.name;manifest.append({'path':name,'bytes':len(raw),'mode':p.stat().st_mode,'sha256':digest(raw)});tar.add(p,arcname=name)
readables=['probe/RESULT.json','probe/run/summary.txt','probe/run/RESULTS.md','probe/run/build.log','probe/run/index.json','probe-peer/REPORT.md','architecture/receipt.json','architecture/refresh/RESULT.json','architecture-peer/REPORT.md','product-peer/REPORT.md'];readable_rows=[]
with tarfile.open(out/'RAW.tar.gz','r:gz') as tar:
 pending={r['path']:r for r in manifest}
 for m in tar:
  r=pending.pop(m.name);raw=tar.extractfile(m).read();assert len(raw)==r['bytes'] and digest(raw)==r['sha256'] and m.mode==(r['mode']&0o7777)
  if m.name in readables:
   raw.decode('utf-8',errors='strict');dest=out/'readable'/m.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);readable_rows.append(r)
 assert not pending and len(readable_rows)==len(readables)
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'READABLE_MEMBERS.json').write_text(json.dumps(readable_rows,indent=2)+'\n')
f1=[s for s in scenes if s['room']=='F1客廳'];status={'execution_sha':product,'architecture_artifact_commit':audit_sha,'probe':{'original_exit':0,'scenes':len(scenes),'timbers':len(members),'statuses':dict(collections.Counter(m['status'] for m in members)),'f1': [{'scene':s['scene'],'count':len(s['members']),'accepted_after_64':sum(m['id']>64 for m in s['members'])} for s in f1],'original_command_seconds':pr['steps'][-1]['result']['ended_epoch']-pr['steps'][-1]['result']['started_epoch'],'original_per_core_timeout':120},'architecture':{'original_exits':[0,0,0],'generic_tests':205,'product_tests':18,'skipped':0,'closure':'0c738c2c8b39b8cc4904bd39121f8ec9412f072cb2be6351b55e5b9f49f6fad0','inputs':604,'edges':798,'diagnostics':0},'archive_bytes':(out/'RAW.tar.gz').stat().st_size,'archive_sha256':digest((out/'RAW.tar.gz').read_bytes()),'files':len(manifest),'all_members_verified':True,'ledger_native_browser_not_claimed':True}
(out/'STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text(f'''# #297 真原生探針與 Linux 架構驗收\n\n兩項真 execution 都是 `{product}`。#297 在03:46:09–03:47:27 UTC完成，原registry core建置exit0（15.145188秒）、原probe exit0（62.550101秒）。64個完整原場景／2936支全接受；逐支L、原點、A0足跡全符，容量拒絕／規則拒絕／錯誤／幾何不符／未跑為0。\n\nF1八排法為95／97／96／98／108／110／109／111支，合824支；每場第65支以後合312支也全接受。不把未測的116支排法或512所有情境由此推成通過。512完整路徑另見已發布H7真execution256747。\n\n實際命令：`CORE_BIN=/dev/shm/pr348-probe297-7a0e6dd8/build/core TMPDIR=/dev/shm/pr348-probe297-7a0e6dd8/tmp bash geometry-core/framing-template/core-probe/run_probe.sh /dev/shm/pr348-probe297-7a0e6dd8/run`。core由同M原`tests/binaries.py` registry編譯，原O2與16MiBstack、每次核心原120秒不變；未覆寫CORE_TIMEOUT/PROBE_SCENES_DIR。capture安全環境欄未列CORE_BIN，以原build.log實際輸入路徑、固定executor及ELF/sidecar補證，沒有重跑。探針原CORE_MAX_TIMBERS=64只產生歷史capacity註記，不截斷原輸入，也不是本產品容量判決。\n\n架構03:50:27–48 UTC在同M乾淨獨立checkout跑原三條：\n\n- `python -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json`：exit0，604 inputs／334 owned／270 exclusions／798 edges／0 diagnostics。\n- `python -B tests/test_architecture_contract.py`：exit0，205／205、0 skip。\n- `python -B tests/test_product_architecture.py`：exit0，18／18、0 skip。\n\n原Linux driver重產四檔，已採入純稽核提交 `{audit_sha}`；manifest bytes保持原登記，不改政策／SSOT。receipt保真M execution，closure `0c738c2c8b39b8cc4904bd39121f8ec9412f072cb2be6351b55e5b9f49f6fad0`，不冒自指artifact commit。\n\n同伴核原probe311份raw、195build來源／185include閉包及所有L/XYZ/A0；架構核29命令、604原Gitblob與SSOT前後。另有本輪八產品檔組合靜審，未見新阻擋；這些不是另一次產品執行。原流、ELF、fixtures、命令、工具、前後四檔均在RAW.tar.gz，逐member hash/mode見MANIFEST。可讀原件在readable，複製保持原bytes、無JSON改寫，對照READABLE_MEMBERS。\n\n原件共{len(manifest)}檔，archive {status['archive_bytes']}bytes，SHA256 `{status['archive_sha256']}`。完整123帳本仍在原輪執行；census／完整native35分鐘／六browser未完成，維持Draft／NOT READY。這次不重抽舊效能、不改原H7／probe門檻、不合main／PR。\n''')
progress=root/'evidence/geo300-capacity512-20261024/PROGRESS.md';old=progress.read_text();progress.write_text(f'''# #348 唯一 current state（2026-10-29 04:00 UTC）\n\n- 產品M=`{product}`；來源鏈含精確#343 a934a554ae58f16f124f1b264523947f170b3f0b、#346 eaf15e239324a6464a04740647afccce3a3c17c7、#347 8bb0359331365c6f3a96872620427cf7847fcb50，behind0。原behind2及全部紅保留歷史。\n- H7真executionT256747c5c8f8f8934eeb08ae404dee1f67591508：8／0／0／0，1142.271674<1200，各批<600；與M非evidence差異0。原件／可讀原件在placed-h7-256747c5。\n- #297真M：64場景2936支全接受，F1共824支、原第65以後312支亦全接受，原probe0。詳probe-architecture-7a0e6dd8。\n- 架構真M三裁判0／0／0，205＋18 tests零skip；四檔純稽核採入 `{audit_sha}`。不改公理／決策／policy。\n- 新35具名反證、172圖、N128前後profile與原紅保留。完整123帳本03:00:41原輪仍進行；完整census、原35分鐘native與六browser尚未完成，**Draft／NOT READY**。\n\n## 歷史紀錄（以下不是 current state）\n\n'''+old)
git('add','--sparse','-f',str(out),str(progress));git('commit','-m','Record framing probe and architecture acceptance at fixed source');e=git('rev-parse','HEAD')
git('-c','pack.window=0','-c','pack.depth=0','push','--no-thin','origin',e+':refs/heads/'+branch);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==e
blob=git('rev-parse',e+':'+(out/'RAW.tar.gz').relative_to(root).as_posix());raw=subprocess.check_output(['gh','api','repos/ZhiQiYang/geometry-axiom/git/blobs/'+blob,'-H','Accept: application/vnd.github.raw+json']);assert raw==(out/'RAW.tar.gz').read_bytes()
result={'evidence_sha':e,'product_sha':product,'architecture_artifact_commit':audit_sha,'archive_bytes':len(raw),'archive_sha256':status['archive_sha256'],'files':len(manifest),'actual_remote_blob':blob,'remote_bytes_equal':True};pathlib.Path('/dev/shm/pr348-probe-architecture-publish-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
