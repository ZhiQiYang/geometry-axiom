import pathlib,os,sys,subprocess,hashlib,json,datetime,resource,importlib.util,fcntl,traceback,shutil
repo=pathlib.Path('/dev/shm/pr348-probe-source-7a0e6dd8');out=pathlib.Path('/dev/shm/pr348-probe297-7a0e6dd8');sha='7a0e6dd81c54066995981393925fa46a815de2f8'
out.mkdir(exist_ok=False);(out/'tmp').mkdir();(out/'tools').mkdir()
def save(name,value):(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
helper=pathlib.Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');assert hashlib.sha256(helper.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('capture',helper);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
for p in (pathlib.Path(__file__),helper):shutil.copy2(p,out/'tools'/p.name)
cleared=[k for k in os.environ if k.startswith(('GIT_','GEOMETRY_','MUTATE_')) or k in ('CORE_BIN','CORE_TIMEOUT','PROBE_SCENES_DIR','PYTHON','PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','CC','CFLAGS','CPPFLAGS','LDFLAGS','C_INCLUDE_PATH','CPATH','LIBRARY_PATH','LD_LIBRARY_PATH','LD_PRELOAD','GCC_EXEC_PREFIX','COMPILER_PATH')]
env={k:v for k,v in os.environ.items() if k not in cleared};env.update(TMPDIR=str(out/'tmp'),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8',GITHUB_SHA=sha,GITHUB_WORKSPACE=str(repo))
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
rec=capture.Recorder(out,env,sha);report={'source_sha':sha,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cleared_environment_names':cleared,'steps':[],'errors':[],'stack_bytes':16777216,'per_core_timeout_seconds':120,'scheduler':'Second of at most two heavy jobs; original ledger remains first; no performance/canvas sampling overlaps','primary_ledger_pid':305890,'cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'capacities':{str(p):shutil.disk_usage(p)._asdict() for p in (pathlib.Path('/tmp'),pathlib.Path('/dev/shm'))}}
def state():
 h=rec.run(['git','rev-parse','HEAD'],cwd=repo,timeout=30)[1].decode().strip();s=rec.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=repo,timeout=30)[1];assert h==sha and not s;return h
code=1;save('RESULT.json',report)
with open('/dev/shm/pr348-secondary-heavy.lock','a+b') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  state()
  assert report['capacities']['/tmp']['free']>67108864 and report['capacities']['/dev/shm']['free']>1073741824
  verify='import pathlib,sys,json;sys.path.insert(0,"tests");import mutate as m; x=m.Sources(pathlib.Path.cwd());print(json.dumps({"closure":x.closure,"files":x.hashes},sort_keys=True))'
  row,raw,_=rec.run([sys.executable,'-B','-c',verify],cwd=repo,timeout=30);(out/'BUILD-CLOSURE.json').write_bytes(raw)
  build='import pathlib,sys;sys.path.insert(0,"tests");import binaries;binaries.OUT_DIR=pathlib.Path(sys.argv[1]);raise SystemExit(binaries.main(["build","core"]))'
  row,_,_=rec.run([sys.executable,'-B','-c',build,str(out/'build')],cwd=repo,timeout=300);report['steps'].append({'label':'original-registry-core-build','result':row});save('RESULT.json',report)
  binary=out/'build/core';sidecar=out/'build/core.fingerprint.json';meta=json.loads(sidecar.read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==meta['exe_sha256']
  report['binary']={'path':str(binary),'bytes':binary.stat().st_size,'mode':binary.stat().st_mode,'sha256':meta['exe_sha256'],'sidecar_sha256':hashlib.sha256(sidecar.read_bytes()).hexdigest()}
  env['CORE_BIN']=str(binary)
  row,_,_=rec.run(['bash','geometry-core/framing-template/core-probe/run_probe.sh',str(out/'run')],cwd=repo,timeout=None,check=False)
  report['steps'].append({'label':'original-probe','result':row});code=row['actual_process_returncode']
  state()
 except BaseException:report['errors'].append(traceback.format_exc());code=1
 report.update(exit_code=code,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save('RESULT.json',report)
print(json.dumps({'out':str(out),'exit':code,'source':sha}));raise SystemExit(code)
