# PR348 W 接觸來源靜態對抗審查

結論：在本次限定範圍內，未發現 M 相對 B 新增、可由來源推導的功能阻擋問題。本結論是靜態審查，沒有執行或引用測試、效能數據或正式 ledger 結果。

- 固定 M：`7a0e6dd81c54066995981393925fa46a815de2f8`。
- 固定 B：`9a8584f57be7935604c3bad4c2481945a6ec3d9f`。
- 來源：`/dev/shm/pr348-active` 的指定 Git objects 與相應目前來源檔。
- 主範圍：`geometry-templates/woodworking/native/contact_sources.c`、`contact_world.c`；另讀必要型別、graph 依賴 API 與 H 呼叫端生命週期。

## 已核對的性質

1. **result memo 的完整輸入鍵與借用欄位。** `contact_sources.c:101–128` 比對 request 的 `placement_id`、`along_v`、`exclude` 原始指標、有效 cap，以及整份 `WoodContactSourceFacts` 位元組。facts 包含全部 region、成員身分指標、順序、placement、footprint 與計數；collector 對借用 `WoodMember` 另行解參照的欄位，經 `contact_world.c:21–52`、`:212–220` 核對只有 `id`、`placed`，兩者均另存並逐筆比對。`exclude` 僅用指標身分，沒有未入鍵的成員欄位。額外 padding、未參與成員或未使用欄位不同會產生保守失配，沒有因此產生假命中的路徑。

2. **callback、失敗、依賴與所有權。** `contact_sources.c:130–163` 在查 memo 前仍完成原有 facts／faces 必要配置、callback 與 facts 邊界驗證；失敗立即回傳，不可由舊成功 memo 把失敗改為成功。命中後仍另配 collection 並複製位元組，舊 query 的 borrowed value 不被改寫。memo 配置失敗只失去提示；collection 成功後才記錄 memo。`collect:224–246` 仍於全部 feature 成功後才寫 caller 輸出及 count。即使某 query 在後續 feature 階段失敗，已成功的純 collection 可留作提示；下一 query 仍必須重新執行 callback 與其依賴登記。

3. **容量與先截取、後排序／去重的語義。** `contact_sources.c:232` 的有效 cap 限制相對 B 未變；facts 驗證的最大輸出為 `8 × 32 × 9 + 512 × 2 = 3328`，即 `WOOD_CONTACT_FACE_CAPACITY`，故該上限不是新增的來源資料截斷。memo 嚴格比對有效 cap，較小 cap 的先截取結果不能套到較大 cap。`contact_world.c:193–246` 的邊與成對 member sides 收集條件未變，cap 0 仍執行 callback；direct collector 在成員數或 faces 超出索引上限時仍走既有完整退回路徑，沒有為使用新陣列而把 public caller 的資料截短。

4. **排序捷徑及完整順序寬度。** `contact_world.c:77–114` 的免排序路徑僅由 `:245–246` 的 bounded、indexed、unique-ID 分支呼叫。原始 member sides 是已過濾 declaration sequence 的子序列；全部 facts 的 order 已非遞減即可推出該子序列已排序，同序的左右兩面與成員次序保持穩定。未參與的逆序 fact 至多使捷徑失效。一般 merge path 預先保存每個 face 的 `uint64_t` order，仍以 `<=` 選左邊，沒有窄化或改變 tie 規則。重複 ID 不進入此捷徑，保留既有「排序取最後 order、遮蓋判斷取最早 order」路徑。

5. **plane-range 查詢等價性。** `contact_world.c:120–175` 先完成原有 fixed／lo 排序，再為每個 rank 寫入該 fixed plane 的起訖；每個有效 rank 均被初始化。舊的兩次 fixed 二分查找，改為同一 immutable face 的 rank 查表。所有呼叫都來自 `:177–190` 中的 `out[i]` 或有效 face index，建表後直到去重完成才於 `:264–266` 搬移 out，沒有索引對到已移動 face 的路徑。prefix 查詢、單一實際 witness 與 `hi` 比較沒有變更，仍不把多個區間合成遮蓋證據。

6. **feature 提示仍登記依賴。** `contact_sources.c:185–193` 先確認 provider、完整 key、VALID 狀態與 value，再以 ordinal+1 呼叫 `geo_eval_depend_hint`；失配回到原求值路徑。`geometry-core/kernel/source.c:403–414` 會在當前 context 再核對完整身分，並執行相同 `geo_source_edge`，因此此 call-site 沒有把 node hint 當成既有邊或值的證明。此處沒有 provider callback 介入建邊與讀 value 之間。

7. **跨 World、重設與釋放。** memo 位於每個 `WoodContactSources`，沒有全域共享；`contact_sources.c:179` 拒絕不同 graph，`:248–253` 釋放 memo 與全部 query collection。`reference_sources.inc:685–690` 依 World 指標選擇 evaluation，`:427` 建立該 evaluation 的 handle。`geometry-core/references.inc:156–173` 銷毀 contact handle；`:692–702` 先清除舊 evaluation 再 reset 並建立新 evaluation。`app_candidate.c:55–60` 確實同步呼叫舊 evaluation 的 dispose；`transactions.inc:689–690`、`:817–818` 也採相同先 dispose 後 reset 順序。新 handle 的 memo 為零，不能把舊 World／generation 的純結果帶進新 handle。保留舊 handle 直接 reset graph 的用法，在 B 與 M 的 `contact_sources.h:44–45` 均明文禁止，未宣稱支援此契約外生命週期。

## 未驗界線與程序紀錄

- 未編譯、未執行任何測試、未做配置失敗注入、動態記憶體檢查或平台堆疊壓力驗證。新增的 `plane_end` 與排序 order 陣列增加堆疊使用；本次只核對索引上限及控制流程，沒有量測平台堆疊餘裕。
- 不將此報告延伸為整個 PR 的 H／K 語義、效能、正式 ledger 或發布條件通過。callback 內部最佳化僅讀取與本次 W 生命週期、輸入組成有關的必要片段。
- Git 持續輸出 `object directory /tmp/geo337-published-archive-git-objects-20261024 does not exist` 的既有 alternate 訊息；未修復 repository，指定 M／B 來源讀取有成功結果。
- 程序偏差：一次查找必要 caller 的 `git grep` 限在 `geometry-core` 目錄，但未排除其巢狀 `domain-decoupling/evidence`，因此輸出意外帶出少量舊 evidence 命中行。已立即告知主審；沒有開啟那些檔案，也不採用其內容或結果作為本報告依據，後續僅讀確切來源路徑。本報告不聲稱「全程零 evidence 搜尋命中」。
- 未修改 checkout、未執行 Git 提交／push／API、未碰正式執行目錄 `/dev/shm/pr348-final-source-7a0e6dd8`。本代理唯一寫入為本報告。
