"""唯讀完整原件核收；不 import 或重跑 probe、generator、parser、產品。"""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = Path('/dev/shm/pr348-probe297-7a0e6dd8')
SOURCE = Path('/dev/shm/pr348-probe-source-7a0e6dd8')
run = ROOT / 'run'
read = []
def raw(path):
    data = path.read_bytes()
    read.append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return data
def load(path):
    return json.loads(raw(path))
def require(value, message):
    if not value:
        raise AssertionError(message)

result = load(ROOT / 'RESULT.json')
index = load(run / 'index.json')
parsed = load(run / 'results.json')
by_name = {x['scene']: x for x in parsed['scenes']}
indexed = {Path(x['file']).stem: x for x in index['scenes']}
actual = {x.stem for x in (run / 'scenes').glob('*.scene')}
require(len(indexed) == len(index['scenes']) == len(by_name) == len(parsed['scenes']) == 64, '64 unique scenes required')
require(set(indexed) == set(by_name) == actual, 'index / actual scene files / results set differs')
require(index['skipped'] == [], 'generator skipped inputs')
require(result['exit_code'] == 0 and not result['errors'], 'original outer did not pass')
rows, counts = [], collections.Counter()
for name in sorted(actual):
    scene = raw(run / 'scenes' / (name + '.scene')).decode('utf-8')
    members = [json.loads(x[len('# probe-member '):]) for x in scene.splitlines() if x.startswith('# probe-member ')]
    expected = {x['id']: x for x in members}
    declared = [int(m.group(1)) for m in re.finditer(r'^timber (\d+) ', scene, re.M)]
    require(len(expected) == len(members) == len(declared) == indexed[name]['timbers'], name + ': input member count differs')
    require(set(declared) == set(expected), name + ': declared member ids differ')
    bucket = run / name
    require(raw(bucket / 'full.rc') == b'0\n', name + ': full.rc nonzero or altered')
    raw(bucket / 'full.err')
    stdout = raw(bucket / 'full.out').decode('utf-8')
    chunks = re.split(r'(?=^角材 ID：\d+\n)', stdout, flags=re.M)[1:]
    observed = {}
    for chunk in chunks:
        match = re.match(r'角材 ID：(\d+)\n尺寸：L=(\d+)', chunk)
        require(match is not None, name + ': missing L')
        identifier, length = map(int, match.groups())
        require(identifier not in observed and identifier in expected, name + ': duplicate or unexpected output member')
        origin = re.search(r'^角材原點：\((-?\d+), (-?\d+), (-?\d+)\)$', chunk, re.M)
        require(origin is not None, name + ': missing xyz origin')
        a0 = re.search(r'^角材 ' + str(identifier) + r' 的 A0[^\n]*：\n((?:[ \t]+vertex\[\d+\] = \(-?\d+, -?\d+, -?\d+\)\n){4})', chunk, re.M)
        require(a0 is not None, name + ': missing four A0 vertices')
        vertices = [tuple(map(int, m)) for m in re.findall(r'vertex\[\d+\] = \((-?\d+), (-?\d+), (-?\d+)\)', a0.group(1))]
        x0, y0, x1, y1 = expected[identifier]['rect']
        origin_xyz = tuple(map(int, origin.groups()))
        footprint = [min(v[0] for v in vertices), min(v[1] for v in vertices), max(v[0] for v in vertices), max(v[1] for v in vertices)]
        require(length == max(x1-x0, y1-y0), name + ': length mismatch')
        require(origin_xyz[:2] in {(x0,y0),(x0,y1),(x1,y0),(x1,y1)}, name + ': origin mismatch')
        require(footprint == [x0,y0,x1,y1], name + ': footprint mismatch')
        observed[identifier] = length
    require(set(observed) == set(expected), name + ': incomplete raw output member set')
    recorded = by_name[name]
    require(recorded['full_rc'] == 0 and len(recorded['members']) == len(members), name + ': recorded scene differs')
    require({x['id'] for x in recorded['members']} == set(expected), name + ': parsed member set differs')
    for m in recorded['members']:
        counts[m['status']] += 1
        require(m['status'] == '接受' and m['mode'] == '原場景' and m['omitted'] == [], name + ': not unomitted acceptance')
        require(m['geometry_checked'] == ['L', '足跡', '原點'], name + ': incomplete original geometry judge')
        require(m['rect'] == expected[m['id']]['rect'] and m['core_length'] == observed[m['id']], name + ': parsed values differ from original input/raw')
    rows.append({'scene': name, 'name': indexed[name]['name'], 'members': len(members),
                 'ids_above_64': sorted(x for x in expected if x > 64),
                 'raw_L_origin_A0_complete': True, 'input_and_output_ids_equal': True,
                 'original_geometry_assertions_match': True})
require(counts == {'接受': 2936}, '2936 original accepted rows required')
for path in [run/'summary.txt', run/'RESULTS.md', run/'build.log']:
    raw(path)
require((run/'build.log').read_text() == '使用 CORE_BIN=/dev/shm/pr348-probe297-7a0e6dd8/build/core，沒有編譯\n', 'actual CORE_BIN branch not recorded')
binary = raw(ROOT / 'build/core')
sidecar = load(ROOT / 'build/core.fingerprint.json')
require(hashlib.sha256(binary).hexdigest() == sidecar['exe_sha256'] == result['binary']['sha256'], 'binary hash mismatch')
require(len(binary) == sidecar['exe_size'], 'binary size mismatch')
require((ROOT/'build/core').stat().st_mtime_ns == sidecar['exe_mtime_ns'], 'binary mtime changed')
for path in sorted((ROOT/'subcommands').glob('*/result.json')):
    record = load(path)
    require(record['actual_process_returncode'] == 0 and record['timeout_expired'] is False, 'original subcommand failed')
    for filename, key in [('stdin.bin','stdin_sha256'), ('stdout.bin','stdout_sha256'), ('stderr.bin','stderr_sha256')]:
        require(hashlib.sha256(raw(path.parent/filename)).hexdigest() == record[key], 'subcommand stream hash mismatch')
    load(path.parent/'request.json')
for path in [Path('/dev/shm/pr348-run-probe297.py'), ROOT/'tools/pr348-run-probe297.py', ROOT/'tools/capture.py',
             SOURCE/'geometry-core/framing-template/core-probe/run_probe.sh',
             SOURCE/'geometry-core/framing-template/core-probe/gen_scenes.py',
             SOURCE/'geometry-core/framing-template/core-probe/parse_results.py',
             SOURCE/'geometry-core/framing-template/oracle/oracle-golden.json', ROOT/'BUILD-CLOSURE.json',
             Path('/dev/shm/pr348-probe297-launcher/REQUEST.json'),
             Path('/dev/shm/pr348-probe297-launcher/reaper.jsonl'),
             Path('/dev/shm/pr348-probe297-launcher/stdout.bin'),
             Path('/dev/shm/pr348-probe297-launcher/stderr.bin')]:
    raw(path)
report = {'schema':'pr348-probe297-readonly-raw-audit/1', 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'execution_sha': result['source_sha'], 'original_outer_exit': result['exit_code'],
          'probe_started_epoch': result['steps'][1]['result']['started_epoch'],
          'probe_ended_epoch': result['steps'][1]['result']['ended_epoch'],
          'scenes': rows, 'members': sum(x['members'] for x in rows), 'statuses': dict(counts),
          'capacity_reject':0, 'rule_reject':0, 'errors':0, 'mismatches':0, 'unrun':0,
          'F1': [x for x in rows if x['scene'].startswith('f1-')],
          'exit_code':0, 'product_test_or_generator_rerun':False,
          'limits':'Only exact existing 64 probe scene inputs; not 512 H7, full native, performance acceptance, or all F1 variants.'}
(OUT/'RAW_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'RAW_MANIFEST.json').write_text(json.dumps(read,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'audit_exit':0,'scenes':len(rows),'members':sum(x['members'] for x in rows),'read_files':len(read)},ensure_ascii=False))
