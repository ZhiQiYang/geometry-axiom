from pathlib import Path
import hashlib,json,re,datetime,traceback
BASE=Path('/dev/shm/pr348-architecture-7a0e6dd8');OUT=Path('/dev/shm/pr348-architecture-peer-review');F='7a0e6dd81c54066995981393925fa46a815de2f8'
sha=lambda b:hashlib.sha256(b).hexdigest()
lf=lambda b:b.replace(b'\r\n',b'\n')
load=lambda p:json.loads(p.read_bytes())
r={'schema':'pr348-architecture-receipt-peer-review/1','source_sha':F,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':[],'product_tests_executed':False,'compiler_executed':False,'git_or_api_executed':False,'source_modified':False,'checks':{}}
def require(test,message):
 if not test:raise AssertionError(message)
def checked_file(info):
 p=Path(info['path']);raw=p.read_bytes();require(len(raw)==info['bytes'] and sha(raw)==info['rawSha256'] and sha(lf(raw))==info['lfSha256'],'file hash '+str(p));return raw
try:
 outer=load(BASE/'receipt.json');result=load(BASE/'refresh/RESULT.json');receipt=load(BASE/'refresh/new/product-architecture-receipt.json');commands=load(BASE/'refresh/commands.json');by={x['label']:x for x in commands};source=Path(outer['repo'])
 require(outer['schema']=='geo323-linux-architecture-refresh-outer/1' and result['schema']=='geo323-linux-architecture-refresh/1' and receipt['schema']=='geometry-product-architecture-receipt/1','schemas')
 require(outer['source_sha']==result['source_sha']==receipt['sourceBaseHead']==receipt['headObservedBefore']==receipt['headObservedAfter']==F,'fixed source')
 require(outer['actual_process_returncode']==outer['exit_code']==0 and outer['passed'] is True and not outer['errors'] and not outer['receivedSignals'],'outer terminal')
 require(result['passed'] is True and result['scan_exit_code']==0 and result['validation_exit_codes']==[0,0] and result['checkout_modified'] is False,'inner terminal')
 for tag in ['stdout','stderr']:
  info=outer[tag];raw=Path(info['path']).read_bytes();require(len(raw)==info['bytes'] and sha(raw)==info['sha256'],'outer '+tag)
 reaper=[json.loads(s) for s in (BASE/'outer/reaper.jsonl').read_text().splitlines()];require(reaper[-1]==outer['reaperCompletion'] and reaper[-1]['event']=='完成' and reaper[-1]['primary_returncode']==0,'reaper terminal')
 require(outer['stackDuring'][0]==16777216 and outer['environment']['PYTHONOPTIMIZE'] is None,'stack/asserts')
 for path,info in outer['toolSources'].items():
  snapshot=(BASE/'tools'/Path(path).name).read_bytes();require(len(snapshot)==info['bytes'] and sha(snapshot)==info['sha256'] and Path(path).read_bytes()==snapshot,'original tool snapshot '+path)
 r['checks']['outer_and_tools']=True
 for cmd in commands:
  require(cmd['exitCode']==0 and cmd['complete'] is True and cmd['interrupted'] is None and cmd['sourceBaseHead']==F and cmd['cwd']==str(source),'command terminal '+cmd['label'])
  for key in ['stdoutInfo','stderrInfo']: checked_file(cmd[key])
  if cmd['label'].startswith(('head-','status-')):
   raw=Path(cmd['stdout']).read_bytes();require(raw==(F+'\n').encode() if cmd['label'].startswith('head-') else raw==b'','source state '+cmd['label'])
 require((source/'.git/HEAD').read_text().strip()==F,'current detached HEAD')
 r['checks']['all_29_command_streams_and_source_state']=len(commands)==29
 expected={
  'final-scan':['tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json'],
  'generic-tests':['tests/test_architecture_contract.py'], 'product-tests':['tests/test_product_architecture.py']}
 actual=[]
 for label,tail in expected.items():
  cmd=by[label];require(cmd['argv']==[outer['pythonExecutable'],'-B',*tail],'original argv '+label)
  text=(Path(cmd['stdout']).read_bytes()+b'\n'+Path(cmd['stderr']).read_bytes()).decode()
  if label!='final-scan':
   count=int(re.findall(r'^Ran (\d+) tests? in [0-9.]+s$',text,re.M)[0]);require(count==({'generic-tests':205,'product-tests':18}[label]) and text.rstrip().endswith('\nOK'),'tests/count/skip '+label)
  else:count=None
  actual.append({'label':label,'argv':cmd['argv'],'exit':cmd['exitCode'],'tests':count,'skip':0 if count else None,'stdout_sha256':cmd['stdoutInfo']['rawSha256'],'stderr_sha256':cmd['stderrInfo']['rawSha256']})
 r['three_original_gates']=actual
 for group in ['outputs','previous_outputs']:
  for name,info in result[group].items():checked_file(info)
 names=['product-architecture.json','product-architecture-scan.json','PRODUCT-ARCHITECTURE.md','product-architecture-receipt.json'];new=BASE/'refresh/new';manifest=load(new/names[0]);scan=load(new/names[1]);require((new/names[0]).read_bytes()==(BASE/'refresh/previous'/names[0]).read_bytes(),'manifest unchanged')
 require(sha(lf((new/names[0]).read_bytes()))==receipt['manifestSha256'] and sha(lf((new/names[1]).read_bytes()))==receipt['scanSha256'] and sha(lf((new/names[2]).read_bytes()))==receipt['reportSha256'],'output receipt hashes')
 require((new/names[1]).read_bytes()==Path(by['final-scan']['stdout']).read_bytes(),'scan actual raw')
 require(scan['ok'] is True and scan['diagnostics']==[] and len(scan['edges'])==798 and len(scan['sources'])==334,'scan facts')
 require(len(manifest['sources'])==334 and len(manifest['exclusions'])==270,'manifest counts')
 require(set(scan['sources'])=={x['path'] for x in manifest['sources']},'owned source sets')
 require(load(BASE/'refresh/manifest-delta.json')=={'addedSources':[],'addedExclusions':[],'updatedExclusions':[],'forbiddenChanges':[],'automaticEdits':False},'unchanged policy')
 r['output_files']=result['outputs'];r['checks']['schema_manifest_scan_report_receipt_hashes']=True
 entries=load(BASE/'refresh/source-inputs.json');require(len(entries)==604 and len({x['path'] for x in entries})==604,'604 inputs unique')
 inp=[{'path':x['path'],'sha256':x['sha256']} for x in entries];rawinp=[{'path':x['path'],'sha256':x['rawSha256']} for x in entries]
 closure=sha(json.dumps(inp,ensure_ascii=False,separators=(',',':')).encode());rawclosure=sha(json.dumps(rawinp,ensure_ascii=False,separators=(',',':')).encode())
 require(entries==sorted(entries,key=lambda x:x['path']),'input path ordering')
 require(receipt['inputs']==inp,'receipt input rows')
 ci=receipt['completeInventoryVerification'];require(closure==result['inputClosureSha256']==receipt['inputClosureSha256']==ci['inputClosureSha256Before']==ci['inputClosureSha256After'],'lf closure')
 require(rawclosure==ci['rawInputClosureSha256Before']==ci['rawInputClosureSha256After'],'raw closure')
 require(set(x['path'] for x in entries)=={x['path'] for kind in ('sources','exclusions') for x in manifest[kind]},'complete manifest membership')
 suffixes=set(ci['executableSuffixes']);tracked={s.decode() for s in Path(by['tracked-inputs']['stdout']).read_bytes().split(b'\0') if s and Path(s.decode()).suffix in suffixes};require(tracked=={x['path'] for x in entries},'fixed M tree executable set')
 batch=by['frozen-input-blobs'];requests=(Path(batch['stdout']).parent/'stdin').read_bytes().splitlines();data=Path(batch['stdout']).read_bytes();at=0
 require(len(requests)==604,'604 frozen requests')
 for req,entry in zip(requests,entries):
  require(req.decode()==F+':'+entry['path'],'frozen requested SHA/path')
  newline=data.index(b'\n',at);oid,kind,size=data[at:newline].decode().split();size=int(size);start=newline+1;blob=data[start:start+size];require(data[start+size:start+size+1]==b'\n','batch boundary');at=start+size+1
  require(kind=='blob' and oid==entry['gitBlobOid'] and hashlib.sha1(b'blob '+str(size).encode()+b'\0'+blob).hexdigest()==oid,'frozen blob identity')
  current=(source/entry['path']).read_bytes();require(len(current)==entry['bytes'] and sha(current)==entry['rawSha256'] and sha(lf(current))==entry['sha256'] and lf(current)==lf(blob),'current/frozen raw+LF input '+entry['path'])
 require(at==len(data),'no extra frozen bytes');r['checks']['all_604_frozen_blobs_and_current_inputs']=True;r['closures']={'lf':closure,'raw':rawclosure}
 protected=load(BASE/'refresh/protected-ssot.json');require(protected['sourceBaseHead']==F and protected['separateFromExecutableClosure'] is True,'SSOT binding')
 require(ci['protectedSsotBefore']==ci['protectedSsotAfter']==protected['before'],'SSOT before/after')
 for i,(name,info) in enumerate(protected['before'].items()):
  current=checked_file(info);frozen=Path(by['frozen-ssot-'+str(i)]['stdout']).read_bytes();saved=(BASE/'refresh/protected-source-bytes'/name).read_bytes();require(current==saved==frozen,'SSOT actual bytes '+name)
 require(ci['toolHashesBefore']==ci['toolHashesAfter'] and ci['rawToolHashesBefore']==ci['rawToolHashesAfter'],'judge hashes unchanged')
 for rel,digest in ci['toolHashesBefore'].items():
  current=(source/rel).read_bytes();frozen=Path(by['frozen-judge-'+Path(rel).stem]['stdout']).read_bytes();require(sha(lf(current))==digest and current==frozen,'judge frozen '+rel)
 r['checks']['SSOT_and_judges_before_after_frozen_M']=True
 require(receipt['inputClosureExcludes']==['geometry-core/domain-decoupling/'+n for n in names],'only four derived exclusions')
 r['counts']=result['counts'];r['passed']=True
except BaseException:
 r['errors'].append(traceback.format_exc());r['passed']=False
r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'RESULT.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':r['passed'],'checks':r['checks'],'errors':r['errors']},ensure_ascii=False));raise SystemExit(0 if r['passed'] else 1)
