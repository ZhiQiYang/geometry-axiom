# PR #348：最小 K hint full-hash tag 對抗審查

結論：**本次純靜態審查未發現 blocking 缺陷。** 可以進入主代理原定的實跑裁決；本報告不宣稱 62 項、graph 172 或效能已通過。

審查對象：`/dev/shm/pr348-hint-tag-draft/candidate-with-tests.patch`。

- 固定 base：`8b128aa7bf53b41b493dd3a0bee49f0d53391254`。
- Patch SHA-256：`f19ee5efae5a882b95bb4df36717e61a75d91534f682bd32e8ee52d930a0d0a7`；審查前後相同，與 IDENTITY.json 一致。
- 產品 source.c SHA-256：`e891b0375d3e15a6b4ce2528d32ddf48874037ce64fb948abb11e7bf62eb3592`。
- Python suite SHA-256：`85e4eb6406b56fea03a8bcf42c3cc13109b19d1bccb436ee3ae3a814f149947a`。
- C harness SHA-256：`2961b21c5fc310cf4ee3a28722b2fa3cc43d7ec42ed5553821527177445d7911`。

只讀 patch／固定 base／prototype／既有 tests；只執行 Python 字串與 AST 前置核對，未編譯、未啟動產品、未跑測試、未改 active／Git。

## 完整 hash 碰撞與 identity

`geo_source_node` 仍先驗 ctx/index/null key，才算 hash；先確認 hint 非零且 ordinal 在 node_count 範圍，再讀 tag。tag 不同僅拒絕 optional hint，後續仍到原 finder。tag 相同仍必須經原 `geo_source_ref_equal`：provider、key_size、全部 key bytes。主 index 的探測／完整 identity 比較未變。

新 full64 collision fixture 的構造成立：兩個 16-byte keys 的第一 word 分別 0/1；經第一輪後狀態為 A/B；第二 word 設為 0/(A xor B)，讓第二輪 xor 輸入皆為 A，後續 mix 相同。word 寫入與產品讀取都用 memcpy，沒有未對齊 UB，主機端序不影響這個構造。前置會用真正 production hash 證明完整 hash 相同且原 bytes 不同。

判決沒有以 hash 當 oracle：`linear_node` 逐 byte 獨立辨識兩個節點，`graph_equal` 比 ordered identity；移除完整 identity 後，第二個不同 key 被誤認為第一個節點，應由原具名 `node-hint-collision-retains-full-identity` 拒絕。雖然此 provider 回固定 quantity 7，node count／ordered identity 檢查仍足以抓誤併，不依賴兩個值不同。這是有意義的 identity 反證，不是重複產品判式。

## 舊 low8 案例與原控制

完整舊 `typed_collision()` 函式逐字保留，包括真 placement IDs 223/256、低八位碰撞、真 frame 值、invalid-before-hash、原輸出不變及 sealed／graph 檢查。不能把新 full64 fixture 當作刪掉這個案例的理由，本 patch 沒有刪。

原 identity-withdrawal method 保留，只因新 tag 可以正確擋掉不同 full hash 的舊 low8 pair，將該單一撤回輸入升級為 full64 collision，且保留相同具名錯誤。這避免原 mutant 因新增防線存活被忽略；不放寬原值／圖／狀態斷言。

原 key 選槽撤回、重算 hash 撤回仍保留同場景／同斷言。原 source-index 29、node-slot 6、edge-scope 17 的檔案不在 patch；它們既有 literal anchors 在固定 base 與新 source 的出現次數全部相同。原 never-find-node／probe-miss／probe-hit／ignore-key controls 仍會被真主 index 碰撞路徑觸發：新增 tag 不改 finder，也不讓同完整 hash 被視為 identity。

## 新工作量反證的有效性

`hint-hash-work` 用真的 typed keys 223/256，前置先證 low8 相同、full64 不同。暖機後交替 16 次，必然每次都是另一個 key 的 hint。新 instrumentation 計數實際 `geo_source_ref_equal()` 呼叫，另計 finder 兩個真比較位置；不以 tag 值直接冒充工作結果。

它保留 `find_calls == 16`、`index_ref_reads >= 16`、`hash_calls == 16`，並要求 total ref reads == finder ref reads。撤回 tag guard 後仍完整比 key、正確回原值，但額外執行 16 次錯 hint identity compare，應由 `node-hint-wrong-full-hash-skips-ref-read` 轉紅。隨後沿原 hint_finish 檢查 ordered graph、三類 dependency、provider counts、seal。這證明少一次邏輯 ref 比較；不證明 cache-miss 減少、實際記憶體流量或特定加速倍數。

## 配置／OOM／reset／sealed

- node calloc → key malloc → nodes grow → index append 的原順序不變；失敗返回前不更新 hint/tag。finder 命中或新 node 成功提交後，才成對寫 tag/ordinal，兩次寫入間沒有 provider callback。
- 未新增 malloc/calloc/realloc 呼叫；原 optional index OOM 退線性、required memory error、UINT32 guard、scope mark/restore/dirty 全部未改。
- **成本並非零記憶體：每個 GeoEvalContext 新增 256×8＝2048 bytes payload**，原 context 的單次必要 calloc 因而變大。實際 struct padding 未編譯核量；不能宣稱極限 heap 下新舊配置可達集合完全相同。原 NULL／MEMORY 返回路徑保留。
- 原 calloc 清零 tag。reset 清所有 ordinal；tag 雖保留舊 bits，但 `hint==0` 短路後不讀 tag，不會使用舊 node/key。所有重新建立 hint 的路徑都同時寫新 tag。
- sealed describe/source 仍直接走原 finder，沒有 hint 更新／新 provider／新 allocation。sealed reset 拒絕保持。
- node/edge ordered arrays、公開 view/API 不含新 metadata，故不變更公開排序或欄位。

## 已完成的靜態前置

所有下列僅為字串處理，非測試執行：

1. 原 edge／node-slot／scope instrumentation 及新 hint instrumentation 在 prototype 均可完成。
2. old-selector、recomputed-hash、identity-ignored、hash-guard-removed 四個撤回 anchors 各恰好 1 次，套入字串後仍可完成 hint instrumentation。
3. 原 source-index、slot、scope、source-context Python 中命中產品的 literal 出現次數相對固定 base 無變化。
4. 舊 typed_collision 完整函式未改，三檔 base/candidate hash 均符合 IDENTITY。

前置核對曾用 active path 當 base，因主代理已採入 `2ac7126205f0079feda8a282663996a75ea12d87` 而在 base-hash assertion 結束碼 1；這不是產品或 test 紅。隨後改為唯讀 `git show 8b128…:<path>` 固定來源核對，三檔身份全部相符，未更動任何產物。正式收據仍應綁主代理實際 execution SHA。

## 留待實跑

原 K29／slot6／scope17＋新 hint10 是否全綠、所有 named 0/1/0、172 場景完整圖、原 ELF 對新候選的 N256 pair、記憶體與效能結果尚未由本審查者執行。此 patch 的小範圍正確性不構成時間改善證據，也不將既有 H7 timeout 改標通過。
