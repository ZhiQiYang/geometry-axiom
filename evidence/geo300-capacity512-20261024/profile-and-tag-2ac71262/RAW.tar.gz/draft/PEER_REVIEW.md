# Hint tag 候選的對抗靜態複核

結論：**未發現阻斷，可交 root 在原排程編譯與驗收。** 本報告沒有執行產品、測試或計時，沒有修改候選或 active checkout。只讀指定 patch、三份 candidate、既有 K 配置 harness，並寫本報告。

固定內容：

- base source SHA（IDENTITY.json）：`8b128aa7bf53b41b493dd3a0bee49f0d53391254`
- patch SHA-256：`f19ee5efae5a882b95bb4df36717e61a75d91534f682bd32e8ee52d930a0d0a7`
- source.c SHA-256：`e891b0375d3e15a6b4ce2528d32ddf48874037ce64fb948abb11e7bf62eb3592`
- Python test SHA-256：`85e4eb6406b56fea03a8bcf42c3cc13109b19d1bccb436ee3ae3a814f149947a`
- C harness SHA-256：`2961b21c5fc310cf4ee3a28722b2fa3cc43d7ec42ed5553821527177445d7911`

## 16-byte 完整 hash collision 成立

原 hash 每個64-bit word 的運算令 `T(x)=y xor (y>>32)`、`y=x*C mod 2^64`、`C=11400714785074694791`。兩個 key 都 provider17、長度16，共同 seed 是對 provider與長度各做原 geo_source_hash_size 的結果。

第一個 word 分別0、1，故中間狀態 h0=T(seed)、h1=T(seed xor1)。第二個 word 分別0、h0 xor h1，兩者第二次乘法前的輸入分別是 h0 xor0 與 h1 xor(h0 xor h1)，完全相同。長度正好16，沒有尾端 byte 迴圈，所以最終完整64-bit hash相同。第一個word已不同，兩個來源bytes確實不等。

fixture 用 memcpy 把uint64_t寫進byte array，原hash再用memcpy讀回同型別；不是假設 little-endian。實際C測試另先呼叫正式hash檢查相等，並用獨立linear_node/graph_equal檢查identity。這個構造用來產生碰撞，不是代替身份oracle。

## Hint/tag 生命週期與失敗點

- hash只選hint；guard遇fullhash不同跳過node/key讀取，同hash仍完整比provider/key_size/key bytes。
- 非零ordinal只有兩處寫入：finder找得現有node、或必要node/key/array配置成功並發布node後。兩處皆先寫tag、再寫ordinal，同次同步呼叫內沒有callback插入兩個寫入之間。
- hint命中不改pair；invalid、missing、node/key/array MEMORY均不發布新pair。原calloc、key malloc、array growth/exact retry、optional index失敗路徑不變。
- reset只清ordinal，不清hash，**沒有正確性缺陷**：hint==0短路，不讀tag或舊node；任何後續非零ordinal都由上述兩處重寫其tag。fresh ctx由原calloc全零初始化。這是邏輯失效，不宣稱hash bytes已被清零。
- 新增固定256個uint64_t tag，共2048B/ctx，未新增每node配置點或容量門檻。無證據支持這個成本為零；需納入真正峰值紀錄。

## Identity 計數未掩蓋指定撤回

原source中 geo_source_ref_equal 只有三個callsite：hint一處、finder的indexed/linear兩處。total在函式入口增加；finder兩處comma-expression各增加index_ref_reads且仍確實呼叫原函式。觀測區間先同時歸零，再固定16次交錯查兩個同low8／不同fullhash來源。

- 正常版本每次都走finder；`find_calls==16`及`index_ref_reads>=16`先確認真查找存在；total==index表示沒有額外hint identity讀取。
- 撤hash guard：16次都會讀錯hint的完整identity，total比index多16；獨立具名 `node-hint-wrong-full-hash-skips-ref-read` 轉紅。不是因finder比較數上升而把hint開銷沖掉。
- 撤完整identity但保留hash guard：上述不同fullhash例不應負責抓它；新full64 collision例在第二個不同key使product只有1node、獨立oracle已有2node，直接由 `node-hint-collision-retains-full-identity` 正常紅。該斷言不依工作量計數。
- 即使某個候選同時略過finder，前面的 `find_calls==16/index_ref_reads>=16` 也不會讓0==0冒充通過。

原typed-collision baseline仍保留。identity撤回改用更強的full64碰撞是必要適配：新tag本來就應拒絕只有low8相同的錯hint，原low8例無法再辨識刪去最後完整identity判斷。未放寬原來源身份要求。

## 未驗與接續

沒有C編譯、runtime結果或性能樣本。指定hash、anchor與代數靜態檢查不能代替正常0／撤回1／恢復0。仍須跑原K配置/slot/scope/ownership/reset/seal相關裁判，保留所有原失敗；完整512/H7和速度收益由root的固定來源正式結果決定。
