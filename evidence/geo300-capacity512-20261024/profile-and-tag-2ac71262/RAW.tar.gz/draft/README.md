# PR #348：固定 8b 的最小 hint full-hash 私有候選

基底 `8b128aa7bf53b41b493dd3a0bee49f0d53391254`。本草稿沒有套用 active、沒有 commit/push、沒有編譯、測試或效能取樣。是否採入，等真 512 profile 與主代理審查。本輪 H7 原 1200 s timeout 不會因這份設計被改判。

## 建議與成本

先評估這個較小方案；目前不建議同時改 main-index metadata。`geo_source_node()` 已有完整 64-bit hash；現行 256 槽 hint 不符合時仍先解一次舊 node／key 完整身分。加 `uint64_t node_hint_hash[256]`，先拒絕 hash 不同的 hint，真正 hash 相等仍完整比 provider/key_size/每個 key byte，查找未命中仍沿原 `geo_source_find_node()`。

產品只改 `geometry-core/kernel/source.c` 四個位置：新增私有陣列、hint predicate、finder 命中時成對發佈、成功追加後成對發佈。原 ordinal 表仍 uint32、256 槽數不變，原 ordered arrays／public APIs／完整 hash 算法／main-index probing／resize／optional-index fallback 不動。不新增幾何或木工語意。

額外 payload 固定 2,048 bytes/context（256 × 8；實際 struct padding 未編譯核量），context 原必要 calloc 仍一筆，但請明列其配置大小會增長，不能寫成記憶體完全不變。沒有新 malloc/calloc 呼叫，不會插入新的 fail_nth 次序；原 node calloc→key malloc→nodes grow／exact retry 保持原順序。無法保證極限實體 heap 下較大 context 必定與舊大小同樣可配置；本方案只保留必要配置失敗時的原 NULL／MEMORY 路徑，不宣稱全域 OOM 可達集合逐 bytes 相同。

預期最多省掉每次錯 hint 的一次完整 ref 比較及其參數取值。它不降低 main-index probe 次數、真正命中比較、node_hash 次數、provider 次數、ordered graph／seal 成本。因此只能由原真 512 profile 確認收益，不能先宣稱能救回 1200 s。工作量斷言只證明少一次邏輯 ref 比較，不能外推硬體 cache-miss 數或牆鐘加速倍數。

## 不變量審查

- `hint != 0`、`hint <= node_count` 在新 hash guard 前；hash 相等不等於 identity，原 `geo_source_ref_equal` 是必需條件。
- finder 命中及新 node/key/array 成功提交後才同時更新 hash／ordinal；必要配置失敗不改兩者。兩次寫入間無 provider callback，未引入跨 callback 借用 caller key。
- `geo_eval_clear()` 原本清空全部 hint ordinal；stale hash 不讀取，因 hint 為 0。未添加 reset 配置或更改封閉態 reset 拒絕。
- sealed describe/source 原本直接走 finder；本 patch 不修改 sealed 路徑、不填 hint、不新增 provider call。
- inline tag 不進 node/edge 列舉、public node view 或輸出，ordered graph 仍由原陣列決定。
- 原 packed guard、optional table OOM→linear、exact-size realloc fallback、所有 32-bit slot 控制保持原碼。若採入，原 source-index 29、node-slot 6、node-hint 原 7 與 edge-scope 原控制都須實跑；此處未跑。

## 既有反證被遮蔽的問題與補強

原 `typed-collision` 的 placement IDs 223／256 只讓 low 8 bits 相同，不保證完整 hash 相同；新的 hash guard 會先排除，不能再靠這一對殺掉「移除完整 identity」mutant。舊 `typed-collision()` 及其全部正例／invalid-before-hash／frame／closed-seal 斷言保留不改。

新增 `hint-full-collision`：兩個 16-byte keys，provider 相同、key_size 相同，第一 word 分別為 0／1。令同一真 hash seed 經第一 word 後的 state 為 A／B，第二 word 分別為 0／A xor B。第二輪 mix 的輸入即 A／B xor (A xor B)=A，故兩個完整 hash 相同但 keys 不同。這是 collision fixture 建構；進入產品測試前先用真 `geo_source_node_hash()` 斷言完整 hash 相等及 bytes 不同，identity oracle 仍為獨立的原 linear_node／graph_equal。

原移除 identity 的 mutant 僅改 predicate anchor 到新增 hash guard 的整行，仍保留 hash guard、只拿掉完整 identity，改用上述真 full64 collision。預期第二個不同 key 被誤當原節點，仍由原名 **`node-hint-collision-retains-full-identity`** 紅，不把碰撞視為相等。

新增 `hint-hash-work`：使用原真 typed IDs 223／256，前置斷言 low8 相同且 full64 不同，暖機後交替讀 16 次。私有 instrumentation 計數 `geo_source_ref_equal()` 的全部呼叫及 finder 的 indexed／linear 呼叫；兩者相等表示沒有錯 hint 的額外 ref 比較。仍要求真正 finder 被呼叫 16 次、至少 16 次 finder identity 比較、僅 16 次 hash，並沿原 hint_finish 驗 ordered graph／三類 dependency／callback／sealed。

撤回 `&&ctx->node_hint_hash[slot]==hash`，其餘完整 identity 都留著，預期具名 **`node-hint-wrong-full-hash-skips-ref-read`** 紅。這是精確工作量反證，無新時限／比例門檻。原「撤回完整 key 選槽」與「finder 重算 hash」反證也保持原斷言與場景。

## 私有產物與後續驗證

- `candidate-with-tests.patch`：三檔 unified diff。
- `prototype/geometry-core/kernel/source.c`。
- `prototype/tests/test_geo300_source_node_hint.py`。
- `prototype/tests/geo300_source_node_hint_harness.c`。
- `IDENTITY.json`：基底 SHA、每檔 base／candidate SHA-256、patch SHA-256。

Patch SHA-256：`f19ee5efae5a882b95bb4df36717e61a75d91534f682bd32e8ee52d930a0d0a7`。

尚未執行的驗證：上述所有 source controls、新 full64 fixture、tag guard 0/1/0、原 identity 0/1/0、編譯／完整 graph172／H7／記憶體與 profile。沒有更動 run_all 登錄（沿既有 suite）、沒有手改 expected。完整 census 才能更新本 suite 實際數量；不以草稿新增方法數當已跑收據。

## 未採用的 main-index parallel metadata 方案

技術上可用可選每槽高位 tag，ordinal 仍 uint32、占用仍以 ordinal 非零為準；tag 不同可跳過 node/key 解參照、相同必須完整 identity。1-byte tag 多 25% raw table payload，且要額外配置／resize／fastslot 寫入／reset／OOM 回退；需要把既有 hash 傳進 fastslot，否則破壞原 one-hash 控制。不能合併改變原 `calloc(next,sizeof uint32_t)`，不能在 node/key/array 必要配置前插入 tag allocation，不能在 sealed lookup 惰性建立，不能把 tag 失敗變 MEMORY。

它還可能遮住原 same-slot key identity mutant，需額外相同 tag／不同 identity 的精確碰撞控制。相對本次固定 2 KiB inline hint tag，改動與失敗狀態空間明顯較大。此輪不實作、不將兩種優化堆在一起，等 profile 再判斷。
