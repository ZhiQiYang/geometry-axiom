import json,pathlib,os,subprocess,time,resource,shutil,hashlib
old=pathlib.Path('/dev/shm/pr348-profile-512-8b');out=pathlib.Path('/dev/shm/pr348-profile-512-8b-recovered');out.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
assert shutil.disk_usage('/tmp').free>=64*1024*1024 and shutil.disk_usage('/dev/shm').free>=2*1024*1024*1024
r=json.loads((old/'REQUEST.json').read_text());exe=old/'bridge-pg';assert hashlib.sha256(exe.read_bytes()).hexdigest()==r['binary_sha256']
for name in ['bridge-pg','input.scene','scene-meta.json','stdin.bin','build-log.json']:shutil.copy2(old/name,out/name)
command=[str(out/'bridge-pg')];payload=(old/'stdin.bin').read_bytes();r.update(command=command,cwd=str(out),started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),recovery='reuse exact already-built ELF after original entire shell group externally SIGKILL; no completed sample discarded',pid=os.getpid());(out/'REQUEST.json').write_text(json.dumps(r,indent=2)+'\n')
class Measured(subprocess.Popen):
 usage=None
 def _try_wait(self,flags):
  pid,status,u=os.wait4(self.pid,flags)
  if pid:self.usage={'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime}
  return pid,status
t=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
 p=Measured(command,cwd=out,stdin=subprocess.PIPE,stdout=so,stderr=se)
 try:p.communicate(payload,timeout=600);timeout=False
 except subprocess.TimeoutExpired:p.kill();p.communicate();timeout=True
r.update(actual_exit=p.returncode,timeout=timeout,seconds=time.monotonic()-t,usage=p.usage,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
if (out/'gmon.out').exists():
 q=subprocess.run(['gprof','-b',str(out/'bridge-pg'),str(out/'gmon.out')],capture_output=True);(out/'gprof.txt').write_bytes(q.stdout);(out/'gprof.stderr').write_bytes(q.stderr);r['gprof_exit']=q.returncode
for name in ('stdout.bin','stderr.bin','gmon.out','gprof.txt'):
 f=out/name
 if f.exists():r[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
raise SystemExit(1 if timeout or p.returncode else 0)
