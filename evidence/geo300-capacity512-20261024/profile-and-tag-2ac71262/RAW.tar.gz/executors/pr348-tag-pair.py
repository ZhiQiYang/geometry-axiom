import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-tag-pair-256');out.mkdir(exist_ok=False);(out/'tmp').mkdir()
os.environ['TMPDIR']=str(out/'tmp');os.chdir(root);sys.path.insert(0,str(root));resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='2ac7126205f0079feda8a282663996a75ea12d87'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
assert json.loads(pathlib.Path('/dev/shm/pr348-tag-tests/RESULT.json').read_text())['exit']==0
assert json.loads(pathlib.Path('/dev/shm/pr348-graph-2ac71262-background/RESULT.json').read_text())['exit']==0
assert shutil.disk_usage('/tmp').free>=64*1024*1024 and shutil.disk_usage(out).free>=2*1024*1024*1024
save(out/'REQUEST.json',{'source_sha':source,'baseline_sha':'8b128aa7bf53b41b493dd3a0bee49f0d53391254','command':sys.argv,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'One bounded N256 feasibility pair, not formal512 or a new threshold; no repeated sampling','stack_bytes':16777216,'timeout_seconds':600})
from tests.test_geo261_native_kernel import NativeBuild
from tests.geo300_scene_generator import build
from tests.test_geo261_timber_capacity_host import TimberCapacityHost
b=NativeBuild();shutil.copy2(b.bridge(),out/'candidate-bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
shutil.copy2('/dev/shm/pr348-h7-8b128aa7/product-bridge',out/'baseline-bridge')
assert digest(out/'baseline-bridge')=='1f7b698e288b8b9fcb6f8eb0565c9cb00614753a1992341cf95cf1a169e24f10'
scene,metadata=build(256,'single');(out/'input.scene').write_text(scene);save(out/'scene-meta.json',metadata)
payload=('loadfile '+str(out/'input.scene')+'\ndump\nobjects\nreferences\n').encode();(out/'stdin.bin').write_bytes(payload)
class Measured(subprocess.Popen):
    usage=None
    def _try_wait(self,flags):
        pid,status,u=os.wait4(self.pid,flags)
        if pid:self.usage={'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime}
        return pid,status
rows=[]
for variant in ('baseline','candidate'):
    path=out/(variant+'-bridge');start=time.monotonic()
    with (out/(variant+'.stdout')).open('wb') as so,(out/(variant+'.stderr')).open('wb') as se:
        p=Measured([str(path)],stdin=subprocess.PIPE,stdout=so,stderr=se)
        try:p.communicate(payload,timeout=600);timeout=False
        except subprocess.TimeoutExpired:p.kill();p.communicate();timeout=True
    r={'variant':variant,'source_sha':source if variant=='candidate' else '8b128aa7bf53b41b493dd3a0bee49f0d53391254','command':[str(path)],'binary_sha256':digest(path),'exit':p.returncode,'timeout_triggered':timeout,'seconds':time.monotonic()-start,'usage':p.usage,'stdout_sha256':digest(out/(variant+'.stdout')),'stderr_sha256':digest(out/(variant+'.stderr'))};rows.append(r);save(out/(variant+'.json'),r)
    if p.returncode==0 and not timeout:
        replies=[json.loads(line) for line in (out/(variant+'.stdout')).read_text().splitlines()]
        assert len(replies)==4 and all(row['ok'] for row in replies)
        TimberCapacityHost().assert_placed_geometry(256,scene,*replies[1:])
        r['original_placed_geometry_assertions_exit']=0;save(out/(variant+'.json'),r)
same=all(rows[0][k]==rows[1][k] for k in ('stdout_sha256','stderr_sha256'))
good=same and all(r['exit']==0 and not r['timeout_triggered'] and r.get('original_placed_geometry_assertions_exit')==0 for r in rows)
save(out/'RESULT.json',{'rows':rows,'streams_identical':same,'not_formal_512_acceptance':True,'exit':0 if good else 1})
raise SystemExit(0 if good else 1)
