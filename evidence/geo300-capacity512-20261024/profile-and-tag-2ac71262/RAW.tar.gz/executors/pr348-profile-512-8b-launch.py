import os,pathlib,subprocess,shutil,json,time,hashlib
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-profile-512-8b-wrapper');out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='8b128aa7bf53b41b493dd3a0bee49f0d53391254'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
assert shutil.disk_usage('/tmp').free>=64*1024*1024 and shutil.disk_usage('/dev/shm').free>=2*1024*1024*1024
assert int(pathlib.Path('/sys/fs/cgroup/memory.max').read_text())-int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())>=2*1024*1024*1024
tmp=pathlib.Path('/dev/shm/pr348-profile-512-8b-tmp');tmp.mkdir(exist_ok=False)
command=['python3','-B','/tmp/pr348-runs/profile_capacity.py','--root',str(root),'--out','/dev/shm/pr348-profile-512-8b','--count','512']
r={'command':command,'source_sha':'8b128aa7bf53b41b493dd3a0bee49f0d53391254','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'One real N512 original separate-O0 gprof diagnosis after failed H7. No new baseline or performance acceptance.','capacity':{p:shutil.disk_usage(p)._asdict() for p in ['/workspace','/tmp','/dev/shm']}}
(out/'REQUEST.json').write_text(json.dumps(r,indent=2)+'\n');t=time.monotonic()
with (out/'outer.log').open('wb') as f:p=subprocess.run(command,cwd=root,env={**os.environ,'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'},stdout=f,stderr=subprocess.STDOUT)
r.update(exit=p.returncode,seconds=time.monotonic()-t,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
raise SystemExit(p.returncode)
