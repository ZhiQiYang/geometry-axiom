# 私有 Git 合流與資源計畫靜態複核

結論：未發現阻斷性的 Git 命令或資源計算錯誤。這是文件靜審，沒有 init、取件、checkout、merge、編譯或測試；不代表合流已成功。

固定輸入：
- PRIVATE_MERGE_STEPS.md SHA-256 `05b8863b181bf7d1ccc2244a54251e3e9064254b3ed729c278850faee9d9a63f`
- NECESSARY_OBJECTS.json SHA-256 `96fc87b4a895fa38efe61f25508863aac72d3e386b0c0472dd581cfd38dfad3f`

已核：全新 repo 自有 refs/index/objects，唯讀 alternates 不寫原 store；非 cone `/AGENTS.md` 規則與普通 merge 可併用。先由 eaf 合入 a934，再由 8bb 合入 M346 的方向正確；兩父 ancestor 與非 evidence diff 檢查能阻擋錯誤合流。20／34／最終固定來源淨36葉已分清，未把50聯集誤作最終淨差。每命令非0即停的要求須由實際執行器落實，不能將整段當無錯誤處理的 shell 腳本直接貼上。

metadata 重算為50個唯一 OID、全部100644、20,103,900 bytes，與先前49本地復用／唯一5,891-byte缺件相符。新 loose object 先查長度與 Git blob OID，再只寫新 repo 的流程正確。32 MiB 是安排估算，文件已保留 index extensions、merge tree/commit與收據成本及實測條件；它不是新測試門檻，也不是已證峰值。SHM 揮發性與持久化責任已明列。

執行前尚須實際確認：50 blobs 可讀不等於全部 Git 閉包可讀；四個目標 commit、merge-base／相關 trees、AGENTS blob 與實際 merge 另需讀取的既存物件仍須由私有 repo 可見。維持禁止 lazy fetch 的唯讀前置，缺件即列出，不能由49/50推論整個 repo 完整。fresh head／owner、目前可用量、私有 identity、真正來源 S、所有命令 exit 與持久交付均未在本次執行。既存 alternates 在完成與持久化前須保留，不可清走。
