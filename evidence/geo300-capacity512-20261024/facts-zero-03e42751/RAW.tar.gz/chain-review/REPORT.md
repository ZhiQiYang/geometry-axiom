# #343 → #346 → #347 → #348：只讀合流範圍

本輪只讀既有 Git objects、指定 API 原件，以及各 PR comments 一次；沒有 checkout、merge、fetch、編譯、測試或遠端寫入。精確逐 leaf 的 mode／blob OID、共同祖先、缺少提交與兩側比較在 `GIT_CLOSURE.json`。

## 真正缺少的內容

| 方向 | 共同祖先 | upstream 未納入 commits／leaves | 缺少的 product/test/judge leaves |
|---|---|---:|---:|
| #343 a934 → #346 eaf | `ccfaf057088a80c7aad4049f1c67e5eedfc2fdec` | 2／20 | **0** |
| #346 eaf → #347 8bb | `a5f1806fb3cad2dada1a56e79e01d54f9f86700f` | 1／14 | **0** |
| #347 8bb → #348 8b | `6d9d46e8d16af75351924c6d47a078d3eb647cc0` | 3／16 | **0** |

完整 head：

- #343：`a934a554ae58f16f124f1b264523947f170b3f0b`
- #346：`eaf15e239324a6464a04740647afccce3a3c17c7`
- #347：`8bb0359331365c6f3a96872620427cf7847fcb50`
- 本輪固定 #348 修復來源：`8b128aa7bf53b41b493dd3a0bee49f0d53391254`，不是目前其它性能候選的 head。

第一段缺 `03c8b4a203323d49b7f42a1775271c79021c08bf`、`a934a554…`，20 葉全在 `evidence/geo300-contact-index-20261024/`：BINDING、PROGRESS、SHA256SUMS 三檔修改，加 contact-source anchor／原紅／tuple 控制與 member-sort 原件、索引、審查等 17 檔。

第二段只缺 `eaf15e239…`，14 葉全在 `evidence/geo300-cut-list-storage-20261024/`：PROGRESS 修改，以及 formal-S392 下原件 archive、RAW_INDEX／RESULT／locator correction、peer 與 producer 記錄 13 檔。

第三段缺 `eb93fbe977b381f67afbf997623f9699d0cb0f0b`、`2e8a6ed20325aa4842dcd0f89eacd598662be598`、`8bb035933…`，16 葉全在 `evidence/issue128-empty-panel-rows-20261024/`：PROGRESS 修改，formal summary／raw index／locator／wrapper、原件 archive 與 formal-independent-peer 等 15 檔。

對每一段逐葉比較 merge-base／upstream／downstream OID：**沒有兩側同時改為不同內容的 leaf**。因此目前已知缺失均是 upstream 單側 evidence 更新；標準三方合流不應需要人工選擇產品內容。這是樹與祖先證據，尚不是 merge 已執行或成功的收據。

三段 50 葉是各段缺失的聯集，**不是最終 #348 的淨 tree 差分**：固定 8b 已包含 #346 的 14 葉，且 mode／OID 全同 eaf。修完完整祖先鏈後，#348 預期淨增加／修改只有 #343 的 20 加 #347 的 16，合計 **36 葉**；仍須保留 #346 的祖先連結，不能把內容已同當成那兩個 PR 歷史已接上。

下游原產品差異仍保留：#346 相對 ccfaf 是六葉（current_geometry.c、cut_list.c/h、report harness／Python、expected）；#347 相對 a5f 是四葉（panel_layout.c、panel harness／Python、expected）。它們已存在 #348 的祖先產品中；合流時不得改寫或取舊 upstream 版本覆蓋。

## Owner／實際存活狀態

- 指定原件 `/dev/shm/pr348-upstream-observation-0048/{343,346,347}.json` 三份存在。另指定的 `/dev/shm/pr348-upstream347.json` **不存在**；#347 實際原件為前述 `347.json`。
- 唯讀 GitHub comments 一次成功：343 共 1 則、346 共 1 則、347 共 2 則；全部是【ChatGPT 審查】，沒有執行者認領、停止、移交或活躍 writer 聲明。最新分別是 [6395515390](https://github.com/ZhiQiYang/geometry-axiom/pull/343#issuecomment-6395515390)、[6400283559](https://github.com/ZhiQiYang/geometry-axiom/pull/346#issuecomment-6400283559)、[6432307013](https://github.com/ZhiQiYang/geometry-axiom/pull/347#issuecomment-6432307013)。原 JSON 已保存。
- API assignees 均空，**不等於沒有 owner**。PR author 帳戶也不等於目前 writer。
- 目前此 Git common-dir 只有 #348 正式、#348 診斷與 H7 收據 worktree，沒有 checkout #343／346／347。`/proc` cwd 掃描找到兩個在 #348 診斷樹的程序（288544 python3、288747 candidate-bridge）；未發現上述三個 upstream 名稱的 cwd。完整快照在 `OWNER_LOCAL_OBSERVATION.json`。
- 本任務 agent 清單只有 root 與既有 #348 研究／審查線，沒有另見 upstream writer；此觀測**不能排除另一雲端／本機的 writer**。
- 目前本 repo 沒有 handoff 本地 ref，未為此下載整個 handoff；因此跨環境交接／lease 仍 **unknown**。本報告不認領任何 upstream 分支。

## 一般合流最小步驟（未執行）

1. 主代理先核已知交接與 live owner，對三個遠端 ref 做一次 fresh expected-head 核對；若任一不等上述完整 SHA，停止這次合流計畫並只對新增差異重算。不要以此報告的先前 API 值當未來 push 鎖。
2. 建立全新的私有 #346 合流 worktree／分支，從 eaf 開始，沿環境已驗證的 sparse checkout 配置排除大型 evidence 展開，不碰既有 writer worktree。普通 `git merge --no-ff a934a554ae58f16f124f1b264523947f170b3f0b`，記 M346。
3. 驗 `git merge-base --is-ancestor` 對 eaf 與 a934 均 exit 0；`git diff --exit-code eaf M346 -- . ':(exclude)evidence'` 必須 0，逐葉 blob OID 完全等同 eaf。完整變更只准是這 20 evidence leaves；若新增 conflict／非 evidence 差異，保留現場，不選 ours/theirs 蓋過。
4. 另建全新的 #347 合流 worktree／分支，從 8bb 開始，以普通 `git merge --no-ff M346`，記 M347。驗 M346／8bb 均 ancestor、非 evidence 逐葉完全等同原 8bb；合流帶入 343 的 20 與 346 的 14 evidence leaves。
5. 主代理在自己的 #348 修復分支一般 merge M347；其非 evidence tree 必須與 merge 前 #348 修復 head 逐葉相同。保留 #348 所有現有產品修復；針對固定 8b，此步淨 tree 變更應是 343 的 20 加 347 的 16、合計 36 evidence leaves。346 的 14 葉已在 8b 且內容相同，仍正常納入其祖先，不重寫或把它們算成新增檔。
6. 若要更新既有 upstream 遠端 ref，必須先確認該 ref 的現有 owner／交接與任務範圍；再次核 expected head，使用普通非 force push。任何 non-fast-forward／expected-head 不符都重新唯讀核對，不 force、不覆寫別人工作。若只推自己的整合分支，須明說 **#348 已含三頭，但 #346/#347 原遠端的歷史鏈尚未改正**，不能假稱整條 PR stack 已修好。

這是標準 Git 三方合流計畫，不以重編 product／手工 cherry-pick leaf 代替來源鏈；也不替主代理決定 upstream owner。

## 所需取件與尚缺原件

六個缺失 commit 與 trees 已在現行 publication store，可以完成本報告的 ancestor／逐葉 OID 判定。初輪該 store 的 **50 個 upstream evidence blob 內容均缺失**（`git ls-tree -l` 顯示 BAD），因此沒有重新讀過或核驗它們的 archive bytes。`GIT_CLOSURE.json` 保留初輪 mode／OID 與缺內容觀測；原可選大小讀取的 ValueError 保留在 `PRECHECK_ERROR.txt`。

後續受派只查 metadata／本地復用：GitHub 三個 tree 的 mode／OID／size 全匹配，50 個 unique blob 共 **20,103,900 bytes**。在既有 `/workspace/geo300-capacity512-work-20261024/.git`（含既有 alternates）找到 **49 個精確 OID**；34 葉另核實原路徑 regular file 的 OID／mode。唯一需新取的是 #347 PROGRESS，OID `ecc7e9fc2a0da1f70f76947514b6a9df7b4875ff`，**5,891 bytes**。詳細清單在 `NECESSARY_OBJECTS.json`、`LOCAL_REUSE.json`；本輪未下載任何 blob bytes、未寫既有 store。三大 archive 可讀本地 object 的存在與大小不代表本輪重新解包／驗收。

正式合流／push 前應由主代理重核本地49個OID仍可讀，只補該5,891-byte blob，再核私有repo所需closure。尤其三個 archive：`MEMBER_SORT_ACCEPTANCE_ORIGINALS_AND_PEER.tar.gz`、`formal-S392/original-report-suite-fixture-and-control-streams.tar.gz`、`formal-panel-native-originals.tar.gz` 可復用，不必重新下載。本報告不把 PR body 的 hash 當已回讀原件，也不宣稱 sparse tree 已具備可獨立發布closure。只在新的私有 repo／branch 操作的步驟與成本在 `PRIVATE_MERGE_STEPS.md`。

## Gates：合流本身與既有未完成項分開

以上鏈修復在預期範圍是 evidence-only，沒有新增產品／測試／裁判輸入變化；因此合流本身先做完整 leaf identity、ancestor、evidence locator/hash 與現有 `mutate.py --check`、架構三原裁判即可判別 closure。不得把 S392／S324 舊 execution SHA 改成 M346／M347；若沿用，必須保留舊來源與 leaf identity 證據，且仍受當前審查／閉包規則限制。

但這**不解除既有未跑 gates**：

- #343 B1：bounded-unique／duplicate／overflow 的 before/after、wall/calls/profile、實際 compiler frame 與原 16MiB 完整 native；B2 whole-opt 八正例完整公開欄位等價；B3 基底與完整整合。既有 R16 關切不在本輪重測或消除。
- #346：完整整合、帳本、架構仍未完成。合流後 review 六產品／測試葉；舊 11 方法／9 組 0/1/0 原件須維持 S392 身分。
- #347：PF-1／2／3、完整 native、受影響 browser、帳本、架構仍未完成；舊 13 方法與三組新反證、whole-opt 工作量 0/1/0 維持 S324 身分。
- #348：原兩個 H7 placed／replay／history 方法、固定最終來源完整 native、六 browser、專項、#297 probe、ledger／architecture；原 600／1200 秒及容量 CAPACITY 不變。目前 #348 真產品修復已改 K/W/H 與 tests，這些驗證需求來自修復本身，不能用 evidence-only 合流將其免除。

本片結論：**來源圖缺口的內容範圍很小且全部 evidence-only；合流與現有產品驗收是不同的剩餘工作。** owner 及 remote-write scope 未由本報告創設，原正式紅燈／未驗仍保留。
