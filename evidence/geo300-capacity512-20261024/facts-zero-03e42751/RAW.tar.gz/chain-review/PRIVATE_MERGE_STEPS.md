# 私有一般 merge 準備（未執行）

只供主代理審後在**全新私有 repo／checkout**執行。沒有 upstream 認領／推送步驟；既有 worktree、refs、index、objects 不寫入。最新需求清單是 `NECESSARY_OBJECTS.json`，owner 觀測仍以 REPORT 的 unknown 邊界為準。

## 必要 objects 與容量

| 類別 | 數量 | 精確 raw bytes | 目前取得方式 |
|---|---:|---:|---|
| #343 evidence | 20 | 11,600,215 | 全部本地同 OID object 可復用 |
| #346 evidence | 14 | 4,202,349 | 全部本地同 OID object 可復用 |
| #347 evidence | 16 | 4,301,336 | 15 個本地復用，1 個小 blob 待取 |
| 聯集 | 50 unique | 20,103,900 | 49 本地；只需下載 5,891 bytes |
| 對固定 #348 的淨變更 | 36 | 15,901,551 | 這是 tree 差分，非下載量 |

全部 mode **100644**；三個 Git tree API 原件合計只 20,269 bytes，未下載任何 blob payload。唯一待取物件：

```text
source: 8bb0359331365c6f3a96872620427cf7847fcb50
path: evidence/issue128-empty-panel-rows-20261024/PROGRESS.md
oid: ecc7e9fc2a0da1f70f76947514b6a9df7b4875ff
mode: 100644
bytes: 5891
```

49 個物件皆可從 `/workspace/geo300-capacity512-work-20261024/.git/objects`（包含其已存在的 alternates）唯讀取得；精確逐物件的 store／size 在 LOCAL_REUSE。不要搬走或刪除既有 object、archive 或 checkout。

採以下「私有 alternates＋單 checkout，僅展開 AGENTS.md」方式，不新增 20MB 原件副本。必要新增 payload 是 5,891-byte 暫存加其 Git loose object；Git 全樹 index 仍需預算：原三頭有 28,805／28,816／29,309 葉，包含 extended flags 的 version-2 entry 對齊模型分別 **5,026,232／5,027,704／5,114,672 bytes**。一份 index 加同時存在的 lock 約 **10,229,344 bytes**；新 merge tree／commit、index extension、原命令收據另加，不冒稱此模型等於已量測峰值。用 **32MiB 工作安排餘量**可涵蓋上述模型與小型 metadata；它不是新平台／產品准入門檻，執行時仍實測。

若主代理選擇將 50 個 blobs 另外複製到獨立 object store，以免依賴舊 alternates：Git header＋zlib compressBound 模型為 **20,111,175 bytes**，另需實際 pack 暫存；不應再保存第二份完整 raw 樹或解包 archive。這是備選成本，非必要取件。不要對整個 repo repack／下載歷史 evidence。

01:28:37Z 唯讀空間：SHM 14,813,110,272 bytes、`/tmp` 306,769,920、`/workspace` **229,376**。私有 repo／原始小回覆／操作文字收據全部放新 SHM 路徑；不要寫入接近滿載的 workspace。主代理須先核自身現用預算與真可用量。交付需沿既有持久化方法保存新 commit／文字收據，不能只依賴 SHM 留存。

## 執行前置

1. 在最新 owner／交接觀測與三個 fresh remote expected-head 值未變的前提下開始；任一 head 改變先重新核新增差異。此處沒有遠端寫入指令。
2. 確認父工作流仍用 Git **2.52.0**（本次已讀）。指定新的 `chain_dir` 必須不存在；不能用既有 checkout。下面 alternates 只新增於此私有 repo，兩個原 store 保持唯讀。
3. 設定私有 commit identity 為主代理既有合法身分，commit 訊息用英文；不重設 global config。原程序／原件不動。

## 具體命令順序

下列為待執行清單；先替換新路徑與身分。本文件沒有啟動這些命令。

```sh
chain_dir=/dev/shm/pr348-chain-private-20261029
test ! -e "$chain_dir"
git init "$chain_dir"
printf '%s\n' /dev/shm/pr348-publication.git/objects /workspace/geo300-capacity512-work-20261024/.git/objects > "$chain_dir/.git/objects/info/alternates"
git -C "$chain_dir" config core.sparseCheckout true
git -C "$chain_dir" config core.sparseCheckoutCone false
git -C "$chain_dir" config core.autocrlf false
git -C "$chain_dir" config index.version 2
printf '/AGENTS.md\n' > "$chain_dir/.git/info/sparse-checkout"
```

先以此私有 repo 的 `git cat-file --batch-check` 對 NECESSARY_OBJECTS 的 50 OID 重核；預期只缺 ecc7 那個 blob。其餘若缺不要重新整批下載，直接列實際缺件。再以 GitHub Git blobs raw media type **只取一次 ecc7** 到新的小暫存檔；例如 `gh api -X GET -H 'Accept: application/vnd.github.raw' repos/ZhiQiYang/geometry-axiom/git/blobs/ecc7e9fc2a0da1f70f76947514b6a9df7b4875ff`。回覆必須正好 5891 bytes 且 `git hash-object --no-filters` 等於 ecc7；若返回 JSON／403／不符，保存原錯誤，不把它寫成所需 object。核對後只對新私有 repo 用 `git hash-object -w --no-filters <新小檔>`。

```sh
git -C "$chain_dir" checkout -b codex/geo346-chain-private-20261029 eaf15e239324a6464a04740647afccce3a3c17c7
git -C "$chain_dir" merge --no-ff -m 'Merge current contact-index evidence into cut-list chain' a934a554ae58f16f124f1b264523947f170b3f0b
M346=$(git -C "$chain_dir" rev-parse HEAD)
git -C "$chain_dir" merge-base --is-ancestor eaf15e239324a6464a04740647afccce3a3c17c7 "$M346"
git -C "$chain_dir" merge-base --is-ancestor a934a554ae58f16f124f1b264523947f170b3f0b "$M346"
git -C "$chain_dir" diff --exit-code eaf15e239324a6464a04740647afccce3a3c17c7 "$M346" -- . ':(exclude)evidence'

git -C "$chain_dir" checkout -b codex/geo347-chain-private-20261029 8bb0359331365c6f3a96872620427cf7847fcb50
git -C "$chain_dir" merge --no-ff -m 'Merge repaired cut-list ancestry into panel-row chain' "$M346"
M347=$(git -C "$chain_dir" rev-parse HEAD)
git -C "$chain_dir" merge-base --is-ancestor 8bb0359331365c6f3a96872620427cf7847fcb50 "$M347"
git -C "$chain_dir" merge-base --is-ancestor "$M346" "$M347"
git -C "$chain_dir" diff --exit-code 8bb0359331365c6f3a96872620427cf7847fcb50 "$M347" -- . ':(exclude)evidence'
```

每條 command 保存原 exit／stdout／stderr；任一非0就保留現場，不能接下條把失敗忽略。另核 M346 的 evidence delta 精確20葉、M347相對8bb精確34葉，mode/OID與清單一致。任何非 evidence diff、意料外 conflict 或額外 leaf 都先查原因，不 `ours/theirs` 覆蓋。

最後由 root 選定真正要採入的 #348 產品 head S（效能候選仍由主線獨立判斷），仍在**這個新私有 checkout**從 S 建新的本地 branch，普通 merge M347；以 S→結果的非 evidence 逐葉身份、三頭 ancestry 與 evidence差分查核。相對固定8b預期淨36葉；若 S 更新，先重新計數，不硬套36。不得在原 #348 活躍 checkout 執行此準備步驟。

此流程只建立私有 commits。是否推哪個分支由 root 根據既有授權與 owner 調度決定；沒有 force push、upstream ref 更新或 merge PR。既有 S392／S324 execution SHA 不改標，新 M346／M347 只是 evidence ancestry 合流。
