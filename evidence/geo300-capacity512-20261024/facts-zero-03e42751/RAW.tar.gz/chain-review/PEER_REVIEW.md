# 上游鏈報告：有界只讀對抗複核

結論：三段直接來源鏈判斷正確；**合流計畫第5步的淨leaf數須更正**，不影響產品來源無變化的預期。

本輪固定讀到 REPORT.md SHA-256 `e64afa5df012192f7be859247a673c9628a6fe7570f0a07161c354ad81892242`，GIT_CLOSURE.json SHA-256 `8ac21abe1f3265525940793ca2e205608ec053dca3ce8307bfde8470da83f2b3`。

## 確認

- 只用現有 objects，禁 lazy fetch／optional locks；唯讀 merge-base、rev-list、diff --name-status --no-renames、ls-tree 與 cat-file batch-check。
- 三段缺失commit數 **2／1／3**，上游變更leaf數 **20／14／16**，與JSON一致；均在 evidence/，直接與跨段比較都沒有兩側改成不同OID的leaf。
- 343的20葉在346、347、固定348均仍等舊base；347的16葉在固定348仍等舊base。
- 50筆 upstream leaf blob引用目前仍全部missing，未讀其raw內容；沒有取件、checkout、merge、產品測試或遠端寫入。
- 未獨立重查API／跨環境writer，owner仍unknown。報告沒有以空assignees冒充無owner；來源鏈分析不授權推別人的分支。

## 唯一修正

固定 #348 `8b128aa7bf53b41b493dd3a0bee49f0d53391254` **已包含 #346 eaf的全部14個evidence leaf內容**，mode/OID相同，不是舊merge-base內容。例如：

`evidence/geo300-cut-list-storage-20261024/PROGRESS.md`

- a5f merge-base：`100644 9d8e26a7a8174c8c306354bf3daacc1fd1891f7d`
- eaf upstream：`100644 4d64e9813e4411807c780c52402cde991471b4cf`
- 8b固定348：`100644 4d64e9813e4411807c780c52402cde991471b4cf`

其餘13葉也逐筆同eaf。因此按報告順序建立M346/M347後，最後merge到固定8b的**預期淨tree差是36葉（20+16）**；50是三段上游變更聯集／需核原件引用數，不能用作最終348新增／修改leaf數。更新root修復head後，還須重新比較該head；本判定固定於8b。

請把第5步改成「閉合三段50葉來源聯集；相對固定8b淨變更36葉，346的14葉已相同」，或等價表述。其餘普通merge順序與non-evidence身份驗證可保留。

尚未實際merge，不能把零衝突候選比對寫成merge成功；也不能用tree OID可見代替50筆raw已公開、完整native/browser已跑或上游owner已移交。

## 同輪修正已核收

作者已採納本發現；本peer再唯讀核對更新後REPORT的獨立段落與步驟5，均已區分50葉聯集／14葉已相同／36葉淨差。GIT_CLOSURE新增 `transitive_into_fixed_348`，計數為unique_leaf_union50、already_equal14、net_changed_leaves36。

- 修正後 REPORT.md SHA-256：`b088fbc5431781e81cf4764899cef4b20ca30b635dca41fd42542c5625a7aa4c`
- 修正後 GIT_CLOSURE.json SHA-256：`382e4b994bde03f2ccfab55e7772cdcf613ca4e07009001e2de3fa638b6d5cf5`

此文案／closure缺口已關閉；上文保留原發現與原件身份。未新增取件、merge、raw驗證或owner認領。
