# H facts 清零減工：靜態審查與私有草稿

本報告固定來源 `1cff9d8c3deab815d5ae6562f3163c95e6f82ac9`。僅讀既有 source／profile，未編譯、執行產品、測試或重跑 profile；未改 active checkout、Git、原測試或公理。產品＋新 6 個測試草稿已交主代理排程；不將靜態 preflight 算成通過。

## 1. 可採的最小變更

`current_geometry.c:5791` 原本對整份 `AppContactFacts` 清零：header、有效邊界儲存，以及固定 512 筆 member。

草稿只改為：

```c
memset(&facts->world,0,sizeof facts->world);
memset(facts->members,0,world->wood.timber_count*sizeof *facts->members);
```

後續 placement id、callback、raw snapshot、成員迭代、配置與來源依賴均原樣保留。每次 prepare 的直接清零量由 `sizeof(AppContactFacts)` 降至 `sizeof(WoodContactWorld)+N*sizeof(WoodContactMemberFact)`；這是實際 byte work 差異，並非新的時間門檻或 cache 容量。

安全依據：

- `placement_effective_boundary`（418–429）：需要回傳 `storage` 的空 derived／自帶矩形兩路，都已完整清零 storage；其餘回傳外部 boundary 或 placement component，沒有讀取未用的 `facts.effective`。
- `reference_contact_facts`（reference_sources.inc:629–630）只從 live member prefix 複製；W 直接／索引讀取皆由 member_count 建立。沒有發現讀取未用 `AppContactFacts.members` tail 的路徑。
- 每筆 live member 必須完整清零，包含 padding、false footprint_valid 和尚未計算的 footprint。原 unplaced／excluded／deferred／無效 raw 路徑都可能保留這些 bytes；不能只清 world。
- 不改 callback 的 caller-owned `out`。原 `tests/geo261_host_facts_authority_harness.c:673,703` 以 0xa5 初始化再整包 memcmp，故失敗時未訪問 tail 必須保持原值。原 raw snapshot 捕捉時點、逐筆複製與 visited prefix 完成時點完全不動。
- `WoodContactResultMemo` 的全包 memcmp 是對另行 calloc 的 `WoodContactSourceFacts`，不是本地未使用的 AppContactFacts tail。live bytes 未變，故不改 memo 身分條件。

獨立子代理 `review_extra_memo_tests` 也唯讀確認上述讀取範圍與原 0xa5 oracle。

## 2. 清零、複製的不能省項

本次不串流直寫 callback out、不延後 snapshot 到每個 provider 返回後、不省略 live member 複製。既有 callback 可改未來成員的 UV／length／placed 或切換 current-values 模式，失敗仍須保持原訪問前綴；直寫全體或延後讀 World 都可能變動可觀察行為。

`reference_contact_facts` 的 active region 全 struct copy 也不在此次修改內。region 是來源回執，原 byte oracle 會讀整包；需要另外完整證明才能縮減，不能從 profile 的 libc 歸因直接推定安全。

`reference_host_read` 中 PlacementSurface/component 清零與複製可能另有減工，但這不是本兩行 patch 的範圍。沒有把 libc 所有 memset/memmove self time 歸給這個函式。

## 3. 新測試草稿

只新增 `tests/test_geo300_contact_facts_zero.py` 與 `tests/geo300_contact_facts_zero_harness.c`，不改 run_all 登錄或任何舊斷言。

- frozen builder 是固定來源原 `app_contact_facts_prepare` 本體，函名改為 frozen_facts_prepare；其完整 memset 保留。
- 0／1／128／512 live counts：只對實際 production prepare 函式內 memset 加 byte counter，不計 fixture 或 frozen oracle。上限由原 live 工作尺寸推導，不設定效能時間數字。
- actual／frozen 皆先填 0xa5，逐 byte 比較所有 live members；還比較完整 world view（僅正規化私有儲存位址）、有效 boundary／regions、raw snapshot 及輸入 World 不變。
- eager raw／deferred；rect／external boundary／derived nonempty／derived empty 四種儲存模式。
- 撤回成 whole memset：必須在 `facts-zero-work-scales-with-live-members` 具名紅，恢復後綠。
- 誤刪 live memset：必須在 `facts-zero-live-member-bytes-match-original` 不同具名紅，恢復後綠。
- 新測試完全不讀 inactive local tail，也不把未用尾端內容變成外部契約。

`STATIC_PREFLIGHT.json` 僅記 Python AST、兩個唯一 mutation 錨點及 variant 可替換性。尚未跑 0/1/0，需主代理實跑。原 H authority 的 rawsnapshot 22 場景和既有撤回／graph／callback／failure prefix oracle 必須原樣跑受影響回歸；本套件不取代它們，也不取代 H7 或 N512。

## 4. Profile 身分與限制

已存在 `/dev/shm/pr348-static-profile-1cff-n256/SUMMARY.json`：measure_exit 0、source_unchanged true、comparison_exits [0,0]、diagnostic_only true。父代理回報 50.108729 秒是單次 static-pg 診斷，不是新的正式效能判決。

既有 gprof 中 app_contact_facts_prepare 有 305029 calls／約 0.48 秒 self，reference_contact_facts 301629 calls／約 1.23 秒 self。libc memset 2.29、memmove 1.36、memcmp 1.16 秒不能精確全歸此處。此改動必然減少直接清零 bytes，但 wall-time 收益未知，須以主代理安排的單次同源比較決定採用。

## 5. 全成員、無 exclude 預排序的靜態評估（未實作）

在每個 query 必要 facts／faces 配置與 callback 全部完成、完整 facts bytes＋dereferenced id/placed＋placement／axis／cap 相等後，保存一份不含排除動作的 **去重前** face/order/plane 索引，理論上可重用排序；但不是現有 collection 的直接重用，也不是兩行等級的修改。

必要守門：

1. 必須證明完整 **去重前** all-member face 數量不會碰到原 cap 截斷。最終 dedup count 小於 cap 不足以證明。邊界先填、member 以兩面成對填的順序、奇數 cap 的剩餘空間都需保留；無法證明時原路 fallback。
2. 最小範圍只接受 indexed＋unique IDs。duplicate ID 的 last/minimum order 舊語意走原 fallback，不能只由 id 代替 exclude 指標身分。
3. 保存原 boundary prefix、placement-order suffix、同 order 穩定 side identity，以及 raw face 原始 ordinal。不能保存全成員的 **去重後** 結果再過濾：若 A 蓋住 B，排除 A 後 B 應恢復。
4. 每次 query 必須重新建立 active 與清空 Fenwick maximum；excluded face 在開始就 inactive、不查 coverage、不當 witness 插入。它仍可留在不可變 plane 座標索引；rank 缺口不改區間比較。先前 query 的遮蔽證據不可帶入下一 query。
5. `exclude` 比的是 member pointer，非 timber id；需能從 face 找回原完整 member identity。對 unknown exclude 指標應等價於不排除，不能誤刪 boundary/member。
6. 原 callback 的依賴、失敗、來源每 query 新身分、FEATURE 依賴與必要配置順序不變；準備 memo 的額外 OOM 只失去提示並走原 collector。callback 內 nested query 改 memo 後，外層必須用自己的當次完整 facts 重驗。
7. immutable query collection 仍深複製，由原 query 壽命持有。提示不可覆寫舊 borrowed collection，也不可跨 World／graph。

最少負例應包含：A 完整遮 B 後 exclude A 使 B 恢復；A/B equal-order 不互遮且兩 side 穩定；query A→B→A 確保 fresh Fenwick；cap 0/1/奇數／full raw 超 cap 但 dedup 小；duplicate IDs；same pointer id/placed 變更；nested callback 替換提示；callback/必要配置/optional 配置失敗；FEATURE 失敗重驗；舊 borrowed bytes 保持不變。work 反證須真正計算 sort comparison／index rebuild 次數，不能只看 cache-hit 欄位。

結論：此方案有條件可行，但至少要新增 collector 準備／query 兩階段的 W 內部介面與成員 identity 映射，還須對 cap 截斷、失敗配置序與 mutable coverage 做新的正式反證。先測本 H 局部清零；沒有證據前不承諾 10% 收益，不把本報告當可立即採入的第二產品補丁。
