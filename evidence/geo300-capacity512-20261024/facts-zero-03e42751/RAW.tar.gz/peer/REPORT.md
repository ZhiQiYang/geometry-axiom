# H facts 清零候選：唯讀對抗審查

結論：限定正式 consumer 與有效 World 容量不變量內，未發現需阻擋採入的產品／測試缺陷。這是靜態結論，未執行候選、編譯、測試或 benchmark。

- 基底：`1cff9d8c3deab815d5ae6562f3163c95e6f82ac9`；patch SHA256：`2eda549033ee48e587e6886653edad9b63f138319e7c95fbe9315ff58869c2c2`。
- `current_geometry.c:5788 app_contact_facts_prepare` 仍完整清零 WoodContactWorld 與 timber_count 個完整 WoodContactMemberFact（包括 padding、invalid footprint bytes）。未初始化區限 inactive members tail、以及未被採用的 effective storage。
- `placement_effective_boundary:418` 兩個會返回 local storage 的分支都先清零完整 SpaceBoundarySurface；其餘返回 caller boundary／placement component。正式使用只傳 .world 或讀 member_count prefix，沒有整個 AppContactFacts 的 memcpy／序列化。
- `reference_sources.inc:625–684 reference_contact_facts` 仍逐一複製 live prefix；失敗只補 visited prefix，未訪問 caller tail 原樣。此次 prepare 清零調整沒有移動 source callback 或 snapshot 時點。
- 新 harness 的 frozen_facts_prepare 經換行正規化並僅回復函式名後，與固定基底原 builder 完整相同；不是另寫幾何 oracle。
- AST 靜讀確認恰六個 test methods。restore-whole 的文字替換精確恢復原 builder；work case 先 count=0，原 sizeof(AppContactFacts) 清零會超出 header-only allowance。omit-live 的 deferred case 用 0xa5 canary，會在第一個含 footprint／padding 的 live fact 上遭原 byte comparator 拒絕。
- case() 要求正常退出碼精確 0／1、具名 ASSERT 整段 stderr 及空 stdout，編譯失敗／signal／timeout不能冒充 kill。原 NativeBuild 與完整連結 K/W objects 沿用，只有 prepare 直接 memset 被計數；frozen builder 與 placement helper 不被改寫。

界線：work 只量 prepare 直接 memset 的 byte count，不能當實際性能或 P52/P189 通過；新六項沒有新增 callback-failure 動態情境，該部分仍依既有 H authority/prefix 回歸實測。整個 AppContactFacts 的 inactive representation 刻意不等同舊版本，不應宣稱全 struct bytes 相同。derived-empty case 只驗原 builder 行為，不賦予新的可施工語意。容量沿既有 timber_count≤WORLD_MAX_TIMBERS，不替 malformed World 定義新政策。
