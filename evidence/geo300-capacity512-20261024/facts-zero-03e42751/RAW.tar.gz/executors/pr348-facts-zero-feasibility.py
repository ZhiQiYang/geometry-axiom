import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-facts-zero-feasibility');out.mkdir(exist_ok=False);(out/'tmp').mkdir()
os.environ['TMPDIR']=str(out/'tmp');os.chdir(root);sys.path.insert(0,str(root));resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='03e427510c8795e34890d731a10dd4e3f84d59c9'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
assert json.loads(pathlib.Path('/dev/shm/pr348-facts-zero-tests/RESULT.json').read_text())['exit']==0
assert shutil.disk_usage('/tmp').free>=64*1024*1024 and shutil.disk_usage(out).free>=2*1024*1024*1024
old=pathlib.Path('/dev/shm/pr348-tag-pair-256');baseline=json.loads((old/'baseline.json').read_text());assert baseline['exit']==0 and not baseline['timeout_triggered']
for stream in ('stdout','stderr'):assert digest(old/('baseline.'+stream))==baseline[stream+'_sha256']
payload=(old/'stdin.bin').read_bytes();(out/'stdin.bin').write_bytes(payload);shutil.copy2(old/'input.scene',out/'input.scene');shutil.copy2(old/'scene-meta.json',out/'scene-meta.json')
save(out/'REQUEST.json',{'source_sha':source,'baseline_reused':baseline,'baseline_original_folder':str(old),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'One new N256 candidate execution, compare existing same-input baseline; no repeated baseline, no timing acceptance threshold','stack_bytes':16777216,'timeout_seconds':600})
from tests.test_geo261_native_kernel import NativeBuild
from tests.test_geo261_timber_capacity_host import TimberCapacityHost
b=NativeBuild();shutil.copy2(b.bridge(),out/'candidate-bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
class Measured(subprocess.Popen):
    usage=None
    def _try_wait(self,flags):
        pid,status,u=os.wait4(self.pid,flags)
        if pid:self.usage={'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime}
        return pid,status
path=out/'candidate-bridge';start=time.monotonic()
with (out/'stdout.bin').open('wb') as so,(out/'stderr.bin').open('wb') as se:
    p=Measured([str(path)],stdin=subprocess.PIPE,stdout=so,stderr=se)
    try:p.communicate(payload,timeout=600);timeout=False
    except subprocess.TimeoutExpired:p.kill();p.communicate();timeout=True
r={'source_sha':source,'command':[str(path)],'binary_sha256':digest(path),'exit':p.returncode,'timeout_triggered':timeout,'seconds':time.monotonic()-start,'usage':p.usage,'stdout_sha256':digest(out/'stdout.bin'),'stderr_sha256':digest(out/'stderr.bin')};save(out/'EXECUTION.json',r)
if p.returncode==0 and not timeout:
    replies=[json.loads(line) for line in (out/'stdout.bin').read_text().splitlines()];assert len(replies)==4 and all(row['ok'] for row in replies)
    TimberCapacityHost().assert_placed_geometry(256,(old/'input.scene').read_text(),*replies[1:]);r['original_placed_geometry_assertions_exit']=0
same=all(r[stream+'_sha256']==baseline[stream+'_sha256'] for stream in ('stdout','stderr'))
good=same and r['exit']==0 and not timeout and r.get('original_placed_geometry_assertions_exit')==0
save(out/'RESULT.json',{'candidate':r,'baseline_reused':baseline,'streams_identical':same,'not_formal_512_acceptance':True,'exit':0 if good else 1})
raise SystemExit(0 if good else 1)
