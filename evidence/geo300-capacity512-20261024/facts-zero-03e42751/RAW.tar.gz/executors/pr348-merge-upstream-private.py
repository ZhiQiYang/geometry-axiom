import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/dev/shm/pr348-chain-private-20261029')
out=pathlib.Path('/dev/shm/pr348-chain-merge-receipt-20261029')
assert not root.exists() and not out.exists()
out.mkdir()
records=[]
env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GIT_NO_LAZY_FETCH':'1'}
def run(args,cwd=None):
 n=len(records);start=time.monotonic()
 p=subprocess.run(args,cwd=cwd,capture_output=True,env=env)
 (out/f'{n:03d}.stdout').write_bytes(p.stdout);(out/f'{n:03d}.stderr').write_bytes(p.stderr)
 records.append({'command':args,'cwd':str(cwd) if cwd else None,'exit':p.returncode,'seconds':time.monotonic()-start})
 (out/'COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n')
 if p.returncode:raise RuntimeError((args,p.returncode,p.stderr.decode(errors='replace')[:400]))
 return p.stdout
def git(*args):return run(['git',*args],root).decode().strip()
expected={'codex/geo300-contact-index-20261024':'a934a554ae58f16f124f1b264523947f170b3f0b','codex/geo300-cut-list-storage-20261024':'eaf15e239324a6464a04740647afccce3a3c17c7','codex/issue128-empty-panel-rows-20261024':'8bb0359331365c6f3a96872620427cf7847fcb50'}
actual=run(['git','-C','/dev/shm/pr348-active','ls-remote','origin',*[f'refs/heads/{b}' for b in expected]]).decode().splitlines()
assert {r.split()[1].removeprefix('refs/heads/'):r.split()[0] for r in actual}==expected
run(['git','init',str(root)])
(root/'.git/objects/info/alternates').write_text('/dev/shm/pr348-publication.git/objects\n/workspace/geo300-capacity512-work-20261024/.git/objects\n')
for key,value in [('core.sparseCheckout','true'),('core.sparseCheckoutCone','false'),('core.autocrlf','false'),('index.version','2')]:git('config',key,value)
for key in ['user.name','user.email']:
 value=run(['git','--git-dir=/dev/shm/pr348-publication.git','config','--get',key]).decode().strip()
 git('config',key,value)
(root/'.git/info/sparse-checkout').write_text('/AGENTS.md\n')
rows=json.loads(pathlib.Path('/dev/shm/pr348-upstream-leaf-review/NECESSARY_OBJECTS.json').read_text())['objects']
missing=[]
for r in rows:
 p=subprocess.run(['git','cat-file','-s',r['oid']],cwd=root,capture_output=True,env=env)
 if p.returncode:missing.append(r)
 else:assert int(p.stdout)==r['bytes']
assert len(missing)==1 and missing[0]['oid']=='ecc7e9fc2a0da1f70f76947514b6a9df7b4875ff'
data=run(['gh','api','-X','GET','-H','Accept: application/vnd.github.raw','repos/ZhiQiYang/geometry-axiom/git/blobs/'+missing[0]['oid']])
assert len(data)==5891
assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==missing[0]['oid']
small=out/'progress-original.bin';small.write_bytes(data)
assert git('hash-object','-w','--no-filters',str(small))==missing[0]['oid']
a,b,c=expected.values()
git('checkout','-b','codex/geo346-chain-private-20261029',b)
git('merge','--no-ff','-m','Merge current contact-index evidence into cut-list chain',a)
m346=git('rev-parse','HEAD')
for parent in (a,b):git('merge-base','--is-ancestor',parent,m346)
git('diff','--exit-code',b,m346,'--','.',':(exclude)evidence')
delta346=git('diff','--raw','--no-abbrev',b,m346).splitlines();assert len(delta346)==20
git('checkout','-b','codex/geo347-chain-private-20261029',c)
git('merge','--no-ff','-m','Merge repaired cut-list ancestry into panel-row chain',m346)
m347=git('rev-parse','HEAD')
for parent in (a,b,c,m346):git('merge-base','--is-ancestor',parent,m347)
git('diff','--exit-code',c,m347,'--','.',':(exclude)evidence')
delta347=git('diff','--raw','--no-abbrev',c,m347).splitlines();assert len(delta347)==34
(out/'RESULT.json').write_text(json.dumps({'m346':m346,'m347':m347,'original_heads':expected,'delta346':delta346,'delta347':delta347,'non_evidence_diff_exit':0,'private_only':True,'upstream_refs_modified':False,'exit':0,'finished_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2)+'\n')
print(json.dumps({'m346':m346,'m347':m347,'exit':0,'private_only':True}))
