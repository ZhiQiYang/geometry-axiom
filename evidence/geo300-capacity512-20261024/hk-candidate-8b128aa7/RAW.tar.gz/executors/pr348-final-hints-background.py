import pathlib,subprocess,json,time,os
out=pathlib.Path('/dev/shm/pr348-final-hints-background');out.mkdir(exist_ok=False)
root='/dev/shm/pr348-diagnostic-c754'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env={**os.environ,'TMPDIR':'/dev/shm/pr348-final-hints-temp','PYTHONDONTWRITEBYTECODE':'1','GITHUB_SHA':sha,'GEO300_DEAD_FACTS_LOG':'/dev/shm/pr348-final-hints-tests/cases'}
pathlib.Path(env['TMPDIR']).mkdir(exist_ok=True)
command=['python3','-B','/tmp/pr348-runs/run_formal_v2.py','--root',root,'--out','/dev/shm/pr348-final-hints-tests','tests.test_geo300_source_node_hint','tests.test_geo261_source_index','tests.test_geo300_source_node_slot','tests.test_geo300_source_edge_scope','tests.test_geo300_contact_result_memo','tests.test_geo300_dead_contact_facts','tests.test_geo261_contact_sources','tests.test_geo300_validation_memo','tests.test_geo261_wood_contact_world','tests.test_geo261_timber_capacity']
record={'command':command,'source_sha':sha,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid()}
(out/'REQUEST.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'outer.log').open('wb') as log:
 p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env);record['child_pid']=p.pid;code=p.wait()
record.update(exit=code,seconds=time.monotonic()-start,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
