import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
root=pathlib.Path('/dev/shm/pr348-diagnostic-c754');out=pathlib.Path('/dev/shm/pr348-hk-feasibility');out.mkdir(exist_ok=False);(out/'tmp').mkdir()
os.environ['TMPDIR']=str(out/'tmp');os.chdir(root);sys.path.insert(0,str(root));resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='8b128aa7bf53b41b493dd3a0bee49f0d53391254'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
save(out/'REQUEST.json',{'source_sha':source,'baseline_sha':'3949deb9e565a9e5aeca5bc475ec646e77cc6546','command':sys.argv,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'One bounded N128 feasibility pair, no threshold or extra sampling','stack_bytes':16777216,'timeout_seconds':600})
from tests.test_geo261_native_kernel import NativeBuild
b=NativeBuild();shutil.copy2(b.bridge(),out/'candidate-bridge');shutil.copy2(b.work/'build-log.json',out/'build-log.json')
shutil.copy2('/dev/shm/pr348-scope-feasibility/candidate-bridge',out/'baseline-bridge')
assert digest(out/'baseline-bridge')=='c2f0c898f2292b5e972dd14d6f4631ec4ac795365010d64e1f4eb792dfec28da'
shutil.copy2('/dev/shm/pr348-combined-diagnostic/input.scene',out/'input.scene');payload=('loadfile '+str(out/'input.scene')+'\ndump\nobjects\nreferences\n').encode();(out/'stdin.bin').write_bytes(payload)
class Measured(subprocess.Popen):
    usage=None
    def _try_wait(self,flags):
        pid,status,u=os.wait4(self.pid,flags)
        if pid:self.usage={'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime}
        return pid,status
rows=[]
for variant in ('baseline','candidate'):
    path=out/(variant+'-bridge');start=time.monotonic()
    with (out/(variant+'.stdout')).open('wb') as so,(out/(variant+'.stderr')).open('wb') as se:
        p=Measured([str(path)],stdin=subprocess.PIPE,stdout=so,stderr=se)
        try:p.communicate(payload,timeout=600);timeout=False
        except subprocess.TimeoutExpired:p.kill();p.communicate();timeout=True
    r={'variant':variant,'source_sha':source if variant=='candidate' else '3949deb9e565a9e5aeca5bc475ec646e77cc6546','command':[str(path)],'binary_sha256':digest(path),'exit':p.returncode,'timeout_triggered':timeout,'seconds':time.monotonic()-start,'usage':p.usage,'stdout_sha256':digest(out/(variant+'.stdout')),'stderr_sha256':digest(out/(variant+'.stderr'))};rows.append(r);save(out/(variant+'.json'),r);print(json.dumps(r),flush=True)
same=all(rows[0][k]==rows[1][k] for k in ('stdout_sha256','stderr_sha256'))
save(out/'RESULT.json',{'rows':rows,'streams_identical':same,'not_formal_512_acceptance':True,'exit':0 if same and all(r['exit']==0 and not r['timeout_triggered'] for r in rows) else 1})
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
raise SystemExit(0 if same and all(r['exit']==0 and not r['timeout_triggered'] for r in rows) else 1)
