# 新 H9 測試靜態審查

審查者 `/root/pr348_hotspot_scope/instrument_static_review`；未編譯／未執行。原 tests.patch v1 的 fallback count 寫 4，獨立審查與作者都確認這是新 fixture 前置錯誤：raw anchor=(0,0)，min_u=0 面被 outline u=0 完全覆蓋，原 collector 應回 3；真來源 BOX 偏移至 u30..70 才回 4。v2 改為 n==(fallback?3:4)，所有原 eager oracle 的逐面／graph／error／provider 比較保留。v1 補丁與原 harness 均保留，沒有已執行紅燈被丟棄。

其餘 Python include closure、兩個唯一撤回 anchor、C 公開型別、凍結 legacy call order、domain 零 component storage 與 mode0–3 靜態未見其他阻斷。產品對抗審查另見 PEER_REVIEW.md。實跑仍由主代理安排；本文件不是通過收據。
