# H dead-facts 私有草稿對抗審查

審查者 `/root/pr348_k_review_resume`。本輪只讀固定兩檔與原呼叫鏈，未編譯／執行測試，未改產品／Git；只新增本報告。這是允許進入隔離驗證的靜態結論，不能替代原 formal 或性能結果。

## 固定身分與結論

- 基底：`3949deb9e565a9e5aeca5bc475ec646e77cc6546`。
- product.patch SHA256：`99420ebe8f9b073343487a2b62aef3949246353c2761dfee84afe44d690a2da4`。
- current_geometry.c 候選 SHA256：`e2b3f48384a27abc389f33ab4916362ff4274a38d3643f360fcd8386e81f4ca5`。
- reference_sources.inc 候選 SHA256：`6a0dd6e667aa1175d7d1022703165cc149bceed21efffcc0c15012cbed7a8c54`。
- 結論：未發現刪除可觀察幾何、來源呼叫或違反原端面錯誤先後的靜態缺陷。兩條捷徑只略過本來不被使用的 raw member 計算；原 snapshot/failure-prefix implementation未動。**仍須正式具名撤回與source/fullgraph驗證，尚無速度通過證據。**

## collect_stop_faces

原先完整 `app_contact_facts` 先算本地domain與所有raw footprints；正常source路徑的resolver實際只從該物件讀 placement_id。新路徑用同一 `placement->id` 直接呼叫原 source adapter，handled=true成功回原count、失敗回0，不進raw fallback。

被提前跨過的 `placement_effective_boundary`、`a0_rect_uv`／`timber_a0_footprint_uv` 都是本地integer geometry與借用資料讀取：沒有provider callback、heap配置、World發布或error寫入。因此提前source呼叫沒有越過另一個可觀察來源失敗或政策拒絕。source request之placement/axis/exclude/output/cap仍相同，handledtrue仍恰一次adapter。

handled=false分支保留原prepare與 `app_contact_resolve_stops`，因此**比原版多一次純context getter**。此差異不能說成所有函式呼叫次數不變，但getter實際只選既存g_reference_active或app_candidate_evaluation_state pointer；handledfalse在callback前就返回，無provider、query、graph或error變更。原舊caller與wrapper文字斷言保持可達，沒有為避測試而改斷言。

## app_reference_end_faces 的 domain-only

`app_contact_domain_only` 重用原placement_id、effective boundary、regions規則；world struct清零使members=NULL/count=0，而不是暴露未初始化內容。

- 普通boundary：role_boundary借用原boundary，regions[0]相同。
- self-contained rectangle：placement_effective_boundary清零並填本地facts.effective；指標在整個同步W呼叫期間有效。
- derived多components：role_boundary維持原被選component（或components[0]），regions逐一借用placement.components；未換成單component。
- derived零components：原helper自行清零effective，region_count=0；與原facts的domain一致。

W `wood_contact_end_faces_with_sources` 在resolver之前只讀role_boundary與self/span，用於boundary edge及span-extension；不讀members。故原V_EXTENSION仍先於任何source callback。原 `app_reference_end_stops` 成功後一定把target.members/count設為它自己持有的完整reference_contact_facts；W後續boundary admission、owner identity、owner extension才會讀它們。source失敗時W立刻return，沒有使用空members。AppReferenceContactResolve的facts儲存與外層AppContactFacts都存活到整個同步呼叫返回。

沒有修改boundary-end-policy的另一條raw→actual路徑，也沒有拓展PF/公理。

## 原不變部分實際文字核對

以凍結original/prototype比對，以下完整函式body相同：app_contact_facts_prepare、app_contact_facts、app_contact_raw_restore、app_contact_raw_complete、app_contact_resolve_stops、timber_end_face_check、placement_effective_boundary、reference_contact_facts、app_reference_end_stops、app_contact_sources_collect、app_reference_sources_for_world。

兩檔bytes/hash均與草稿MANIFEST吻合；current_geometry原CRLF沒有全檔改寫。

## 採入前最小必要實跑

1. handledtrue成功與失敗：原source呼叫各一次；失敗不得落入raw fallback，原output/prefix/error不變。撤回早退必須由具名raw-work斷言轉紅。
2. 無context和use_current_values fallback：原面完整欄位、排序、owner指標與失敗保持；不得把多出的純getter當額外provider。
3. 原V_EXTENSION病例在resolver之前拒絕；sourcefailure不搶先、不能清掉既有error。撤回domain-only必須由不同具名raw-work紅抓到，不是compile/crash。
4. 上述普通boundary／rectangle／derived已選component／零component，加owner指標與端面優先序既有正反例。
5. source provider/graph/guards/各seal的完整同序比較及實際512受影響正式項；本審查不能代替它們。

不需要為本審查新增時限、容量門檻、豁免或公理；未找到必須先改原裁判才能成立的靜態問題。
