# H 未使用 raw facts 私有草稿

基底 `3949deb9e565a9e5aeca5bc475ec646e77cc6546`；只改兩個 H leaf。未編譯、未跑測試、未採入或推送。完整來源／補丁 hash 見 MANIFEST.json。原 13 個 consumer-scope 測試與 prototype 產品完全未動。

## A：原來源路徑先接上，未處理才保留 raw fallback

- 原 `current_geometry.c:5878–5883` 的 collect_stop_faces 先建立一整份 raw member footprints，來源路徑卻只讀其中 placement_id。
- id 原本在 `app_contact_facts_prepare:5779` 直接取 placement->id；新路徑直接取同值，沒有新增推導。
- `reference_sources.inc:805–812` 的 handled=false 分支只有 getter＋bool讀取。getter `app_candidate.c:62–63` 僅回傳既存指標；不配置、不更新World、不呼叫provider。
- 新source活躍路徑仍恰好呼叫一次原來源入口；handled=true的失敗直接回0，不能落入rawfallback。
- 為保留原ContactWorldBoundary裁判要求的 `app_contact_resolve_stops(`，handled=false分支保留原prepare＋resolver。因此此分支多一次純context查詢，**不能聲稱純wrapper次數不變**；provider、source query、ordered graph、原幾何fallback均未新增。
- raw prepare內的placement_effective_boundary、footprint僅純局部計算，沒有發布狀態或錯誤；未處理分支新增的純getter不改其輸入。沒有新增invalid-domain規則或更改原原生裁判。

穩定撤回anchor為collect的前三行：

```c
    size_t count=0;bool handled=false;
    bool source_ok=app_contact_sources_collect(world,placement->id,along_v,exclude,out,out_cap,&handled,&count);
    if(handled)return source_ok?count:0;
```

以 `size_t count=0;` 替換即可讓原raw prepare重新出現；source成功路徑的raw工作量具名斷言應紅。不能僅把編譯錯誤算kill。

## B：端面規則前僅建立原domain，members保留原resolver時點

- 新 `app_contact_domain_only` 複用原domain六行，清零只有world欄位；effective storage只有在原placement_effective_boundary真正回它時才會讀，該函式各條返回storage路徑已自行清零。
- 原 `app_contact_facts_prepare` 與 wrapper 完整byte不變，避免動到 callback 的raw capture與原文字裁判。
- `contact_world.c:435–437` 在resolver之前只讀role_boundary與self，不讀world members。`contacts.c:8–37` span-extension只用self與已給定的span/edge，原錯誤字串及先後不變。
- 原 `app_reference_end_stops:737–738` 成功後仍用真正reference_contact_facts覆寫target.members/count，之後才進入W的I19/owner/member迴圈。失敗時原W立刻返回，不讀尚未填的members。
- callback完整snapshot時點、visited-prefix、failure-suffix、來源圖和幾何全部保持。沒有把I19或source failure提前。

撤回anchor：

```c
AppContactFacts facts;app_contact_domain_only(placement,boundary,&facts);
```

換回原 `AppContactFacts facts;app_contact_facts(world,placement,boundary,&facts);`，以原raw工作量具名斷言捕獲。

## 已靜態核對、未實跑

STATIC_PREFLIGHT.json確認原prepare/wrapper、reference_contact_facts與原end resolver完整相同；原collect仍有shared resolver呼叫；兩個撤回點唯一。正式acceptance仍須parent安排：source成功/失敗、無context/current-value fallback、span錯誤先於provider、derived/domain/owner合法與拒絕、原orderedgraph、真N512；本草稿不宣告任何結果。
