from pathlib import Path
import difflib
D=Path(__file__).parent
s=(D/'original/source.c').read_text();original=s

def once(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
once('static size_t geo_source_find_node(const GeoEvalContext *ctx,GeoSourceRef source,size_t *empty_slot)',
     'static size_t geo_source_find_node(const GeoEvalContext *ctx,GeoSourceRef source,size_t *empty_slot,uint64_t hash)')
once('size_t mask=ctx->node_index_capacity-1,slot=(size_t)geo_source_node_hash(source)&mask;',
     'size_t mask=ctx->node_index_capacity-1,slot=(size_t)hash&mask;')
once('''    /* 只快取既有身分的插入序號；碰撞仍完整比對 K 持有的鍵。 */
    size_t slot=(size_t)source.provider^source.key_size;
    if(source.key_size){const unsigned char *key=source.key;slot^=(size_t)key[0]^key[source.key_size-1];}
    slot&=255;''',
'''    /* 僅以完整 hash 選既有提示槽；命中仍比對 provider、大小與全部鍵。
     * 同次 miss 將 hash 傳入原查找，不再重算；不跨呼叫借用 caller key。 */
    uint64_t hash=geo_source_node_hash(source);
    size_t slot=(size_t)hash&255;''')
once('geo_source_find_node(ctx,source,&empty_slot);','geo_source_find_node(ctx,source,&empty_slot,hash);')
assert s.count('geo_source_find_node(ctx,source,NULL);')==2
s=s.replace('geo_source_find_node(ctx,source,NULL);','geo_source_find_node(ctx,source,NULL,geo_source_node_hash(source));')
(D/'prototype/geometry-core/kernel/source.c').write_text(s)
(D/'product.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/geometry-core/kernel/source.c',tofile='b/geometry-core/kernel/source.c')))
