# #348 K node hint：最小完整 hash 重用候選

來源 `3949deb9e565a9e5aeca5bc475ec646e77cc6546`，原 source.c SHA-256 `93b952992de5d344c8bb3efd582fd7f85318551cb12350dab95554d3e694057e`。2026-10-29 UTC。此目錄只有私有草稿；**未編譯、未執行、未改 active／Git／run_all／原測試**。

## 觀測與有限收益

固定 `/dev/shm/pr348-scope-profile-3949/gprof.txt` SHA-256 `974ccef766a99cc0a6a497b9e6fa8b298fc1f2555f880578f31502b4f5acac22` 顯示：

- geo_source_node 15,848,086 次，geo_source_find_node 13,274,312 次，現 hint 約16.24%命中。
- find_node 中完整 identity 比較13,742,110次，平均每次 find 約1.035次；主表碰撞不嚴重，沒有依據另造更大表。
- flat self：node .46s、find .49s、hash .15s、hash_size .06s，合1.16/3.59s sampled self約32.3%。原 profile wall8.644s包含 -pg 成本，不能把這32.3%當正式wall比例。

目前 hint 只取 provider、key_size、首／尾 byte XOR。真 FRAME 的5-byte key及contact的17-byte結構key在中間改身分時，這個提示槽可能完全不變。全 hash 已存在於 fallback；最小可試方案是同次請求只計一次完整 hash，供 hint 與 fallback 共用。

**收益尚不確定。** 原hint命中也要新增完整hash工作，256槽仍會被大working set淘汰；不能宣稱這個候選足以解除 full H7 1200s。即使完全消除所列 sampled self，也只有約1.48倍的理論樣本上界，而且真方案不可能全部消除。主代理將只做一輪有界實測後決定是否採入。

## 產品差異

`product.patch`只修改 `geometry-core/kernel/source.c`：

1. 原合法性檢查之後計 `uint64_t hash=geo_source_node_hash(source)`，以 `hash&255` 取既有 node_hint[256]，不增槽數或公私有欄位。
2. hint命中仍以 provider、key_size、全部key bytes與K自有key比較，回傳原size_t node ordinal。
3. 原 `geo_source_find_node` 保持同函名、真正主路徑，加一個私有 hash 參數。miss不重算hash；未另繞新helper使舊never-find-node控制失效。
4. sealed兩個查找點各自行傳完整hash；原NULL key前置、sealed拒絕、返回狀態與output語意不變。
5. 不更改node插入、必要配置次序、optional索引／UINT32 fallback、edge／provider流程。原主表hash本身不改，原碰撞fixtures仍成立。

新來源SHA-256 `da1ad325965a9dbbf330cda0355182a06ec54dbbb530b14ffceb53ff1b7c8424`。全候選 `candidate.patch` 含該檔及兩個獨立新測試；以 MANIFEST 為完整hash依據。

## 指定的真 typed key／work controls

新檔 `tests/test_geo300_source_node_hint.py`、`tests/geo300_source_node_hint_harness.c`。沿用原K NativeBuild及原線性node/edge oracle，連結真 `geo_placement_source_ref`／decode，沒有把前端／W幾何放進K。provider真回 FRAME，origin隨ID而異；另有真consumer對每個來源記三種dependency kind，逐邊核順序與provider次數，並核sealed/reset/fallback。

- 8個實際 FRAME keys：IDs256/512/768/1024/1280/1536/1792/2048，首尾相同、原slot全21；完整hash低8位各異。warm後重複4輪，共32請求。測試同一產品的原selector撤回版本與新selector，兩者必先通過完整值/ordered graph；原版本實際find必32，新版本find/probes必0、hash必32。此為指定工作計數，不是新增時間或比例門檻，也不是聲稱已跑。
- force清hint後32次原真lookup：同次hash必只計32次；撤回重用、在finder重算應64次，以 `node-hint-miss-hash-reused-once` 具名紅。
- 原selector撤回應以 `node-hint-middle-bytes-avoid-full-lookup` 具名紅，語意仍正確。
- 真typed collision IDs223/256同hint slot11。撤回完整identity檢查，必由 `node-hint-collision-retains-full-identity` 紅；正常版須保留不同node及不同FRAME值。
- NULL key／非零size必在hash前INVALID且不改output；optional主表配置失敗仍由真linear路徑找身分；reset清全部提示，sealed無新provider/edges。

共7個新test methods，3組具名撤回／恢復；**靜態數量不是通過數**。記錄環境 `GEO300_NODE_HINT_LOG` 時保存每個原子命令、exit、完整stdout/stderr及GITHUB_SHA。每case原30秒，不改門檻。

## 舊測試／反證保全

全rg檢查 tests（含mutate.py）及domain-decoupling未發現硬編碼舊find_node signature；舊never-node控制動態尋找同函名，候選仍經該函式。STATIC_PREFLIGHT另外核29個原source-index／node-slot／scope的literal instrumentation/control anchor出現次數不變，兩個UINT32 guard保留；原檔完全未改。

原node-slot miss一個hash仍成立；resize現有9-node census仍為1次請求hash+9次完整rehash=10，沒有為新方案修改這些斷言。第一個無表插入會新增一次用於hint的hash，原測試沒有將這點當產品門檻；新舊配置結果不變。

實跑仍須由主代理取得原K35/scope17與新7終態；本稿沒有跨SHA沿用或架構／帳本完成宣告。
