"""Read existing local sources and receipts only; never fetch, build or execute a gate."""
from pathlib import Path
import ast,hashlib,json,os,subprocess,datetime
OUT=Path(__file__).parent
F2='b595e55952d5d66de95024432e1b29bec7525e9b';C='75481194f3b85a6b07e11896403633d7d0fa0d6f'
OLD=Path('/dev/shm/pr348-formal-b595');NEW=Path('/dev/shm/pr348-active')
GIT=['git','--git-dir=/dev/shm/pr348-publication.git'];ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def git(*args):return subprocess.run(GIT+list(args),env=ENV,capture_output=True,check=True).stdout
def sha(b):return hashlib.sha256(b).hexdigest()
def file(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def blob_oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def items(root):
 rows={}
 for line in git('cat-file','-p',root).decode().splitlines():
  ident,path=line.split('\t');mode,kind,oid=ident.split();rows[path]={'mode':mode,'kind':kind,'oid':oid}
 return rows
commits={s:git('cat-file','-p',s).decode() for s in [F2,C]}
trees={s:commits[s].splitlines()[0].split()[1] for s in commits}
root_items={s:items(trees[s]) for s in commits}
raw=git('diff','--raw','--no-abbrev','--no-renames','--no-ext-diff','--no-textconv',F2,C).decode()
(OUT/'git-diff-raw.txt').write_text(raw)
paths=[line.split('\t')[1] for line in raw.splitlines()]
save('GIT_CLOSURE.json',{'from':F2,'to':C,'commit_objects':commits,'root_tree_oids':trees,'changed_paths':paths,'non_evidence_changes':[p for p in paths if not p.startswith('evidence/')],'product_roots':{p:{'F2':root_items[F2][p],'C':root_items[C][p],'same':root_items[F2][p]==root_items[C][p]} for p in ['geometry-core','geometry-app','geometry-templates','geometry-web','current_geometry.c']},'method':'Only local cat-file and raw diff; no fetch, checkout, build or execution.'})
rel='tests/test_geo261_timber_capacity_host.py';texts=[(r/rel).read_text() for r in [OLD,NEW]]
def segments(s):
 lines=s.splitlines(keepends=True);rows={}
 for n in ast.parse(s).body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   children=n.body if isinstance(n,ast.ClassDef) else [n]
   for child in children:
    if isinstance(child,ast.FunctionDef):
     start=min([child.lineno]+[d.lineno for d in child.decorator_list]);b=''.join(lines[start-1:child.end_lineno]).encode();rows[(n.name+'.' if isinstance(n,ast.ClassDef) else '')+child.name]={'lines':[start,child.end_lineno],'bytes':len(b),'sha256':sha(b)}
 return rows
segs=[segments(s) for s in texts];names=sorted(segs[0].keys()|segs[1].keys())
save('HOST_METHODS.json',{'file':rel,'F2':file(OLD/rel),'C':file(NEW/rel),'git_blob_oids':{'F2':blob_oid((OLD/rel).read_bytes()),'C':blob_oid((NEW/rel).read_bytes())},'methods':{n:{'F2':segs[0].get(n),'C':segs[1].get(n),'same_exact_source':n in segs[0] and n in segs[1] and segs[0][n]['sha256']==segs[1][n]['sha256']} for n in names},'warning':'Whole host test module changed (imports, helper functions, second H7 method and new seven-member test); this is selective method reuse, never all-tests-closure identity.'})
files=['tests/test_geo261_native_kernel.py','tests/test_engineering_json.py','tests/_bridge.py','tests/binaries.py','tests/geo300_scene_generator.py','tests/test_geo261_wood_world_validation.py','tests/geo261_timber_capacity_host_harness.c','tests/test_geo300_validation_memo.py','tests/geo300_validation_memo_harness.c','tests/test_geo261_wood_contact_world.py','tests/test_geo261_timber_capacity.py','tests/test_geo261_source_index.py','tests/geo261_source_index_harness.c','tests/run_all.py','tests/run_all.expected.json','geometry-core/domain-decoupling/product-architecture.json']
fh=[]
for name in files:
 a=OLD/name;b=NEW/name
 if a.exists() and b.exists():fh.append({'file':name,'F2':file(a),'C':file(b),'same':a.read_bytes()==b.read_bytes()})
 else:fh.append({'file':name,'F2_exists':a.exists(),'C_exists':b.exists(),'same':None})
save('SELECTED_FILE_HASHES.json',fh)
# All materialized native-source suffixes under the four product roots; this is
# a worktree check in addition to the unchanged complete Git subtrees above.
code=[];missing=[]
for root in ['geometry-core','geometry-app','geometry-templates','geometry-web']:
 for p in (OLD/root).rglob('*'):
  if p.is_file() and p.suffix in ('.c','.h','.inc') and not any(x in p.parts for x in ('node_modules','.git')):
   rel=p.relative_to(OLD);q=NEW/rel
   if not q.is_file():missing.append(str(rel));continue
   a=p.read_bytes();b=q.read_bytes();code.append({'file':str(rel),'bytes':len(a),'F2_sha256':sha(a),'C_sha256':sha(b),'same':a==b})
for rel in ['current_geometry.c']:
 a=(OLD/rel).read_bytes();b=(NEW/rel).read_bytes();code.append({'file':rel,'bytes':len(a),'F2_sha256':sha(a),'C_sha256':sha(b),'same':a==b})
code.sort(key=lambda x:x['file']);save('MATERIALIZED_PRODUCT_CODE.json',{'roots':['geometry-core','geometry-app','geometry-templates','geometry-web','current_geometry.c'],'suffixes':['.c','.h','.inc'],'count':len(code),'missing_in_C':missing,'different':[x['file'] for x in code if not x['same']],'files':code,'scope':'Materialized native code; complete Git product subtrees are independently identical. This is not a new compiler dependency scan or claim about unrecorded toolchain state.'})
oldlog=Path('/dev/shm/pr348-formal-placed-b595-v2/build-log.json');newlog=Path('/dev/shm/pr348-history-c754-formal-v2/build-log.json')
logs=[json.loads(p.read_text()) for p in [oldlog,newlog]]
work=[str(Path(j[0]['arguments'][-1]).parent) for j in logs]
roots=[str(OLD),str(NEW)]
def normalize(args,i):return [s.replace(work[i],'<BUILD_WORK>').replace(roots[i],'<CHECKOUT>') for s in args]
normalized=[[normalize(j['arguments'],i) for j in log] for i,log in enumerate(logs)]
save('BUILD_CLOSURE.json',{'F2_log':file(oldlog),'C_log':file(newlog),'steps':[len(j) for j in logs],'all_exit_zero':[all(r['exit']==0 for r in j) for j in logs],'build_work':work,'checkout':roots,'substitutions_only':['exact build work directory → <BUILD_WORK>','exact checkout root → <CHECKOUT>'],'normalized_arguments_equal':normalized[0]==normalized[1],'differing_steps':[i for i,(a,b) in enumerate(zip(*normalized)) if a!=b],'normalized_arguments':normalized[0],'binaries':{'F2':json.loads(Path('/dev/shm/pr348-formal-placed-b595-v2/batch-000/BINARY.json').read_text()),'C':json.loads(Path('/dev/shm/pr348-history-c754-formal-v2/batch-000/BINARY.json').read_text())},'binary_warning':'ELF hashes differ. Source and command-flag equality does not establish binary byte identity. The binary difference cause is NOT determined here; no __FILE__ attribution.'})
receipts={}
for label,directory in [('F2_formal','pr348-formal-placed-b595-v2'),('F2_32_controls','pr348-post-formal-controls-b595'),('C_seven_member','pr348-history-c754-smoke'),('C_second_formal','pr348-history-c754-formal-v2')]:
 p=Path('/dev/shm')/directory;files={n:file(p/n) for n in ['REQUEST.json','RESULT.json','unittest.log'] if (p/n).exists()}
 obj={n:json.loads((p/n).read_text()) for n in ['REQUEST.json','RESULT.json'] if (p/n).exists()}
 receipts[label]={'directory':str(p),'files':files,'records':obj}
 if label=='F2_formal':
  # Record every exact fixture/input/output identity; do not copy original raw.
  receipts[label]['batches']=[{p.name:{n:file(p/n) for n in ['BINARY.json','FIXTURES.json','fixture-0.scene','stdin.bin','stdout.bin','stderr.bin','RESULT.json'] if (p/n).exists()}} for p in sorted((Path('/dev/shm')/directory).glob('batch-*'))]
save('RECEIPT_REFERENCES.json',receipts)
# Only metadata blobs already known to exist locally; do not materialize archive.
packed_manifest=json.loads(git('cat-file','-p','a7d22527484e6b36214fa078017fb3759bf2c0d0'))
packed_status=json.loads(git('cat-file','-p','7fdc8e5943ef538cd5720d09c1230ffbd35d895f'))
manifest_rows=packed_manifest if isinstance(packed_manifest,list) else packed_manifest.get('files',[])
selected=[r for r in manifest_rows if any(x in r.get('path','').lower() for x in ['result.json','request.json','observer.py','audit.py','source-index','graph','profile']) and not r.get('path','').endswith(('.gz','.bin','.o'))]
save('PACKED_F2_METADATA.json',{'fixed_commit':C,'path':'evidence/geo300-capacity512-20261024/packed-index-b595e559','status':packed_status,'manifest_file_count':len(manifest_rows),'selected_manifest_rows':selected[:100],'truncated_selection':len(selected)>100,'scope':'Read existing summary and manifest metadata only; did not rerun 29 controls, 172 graph cases or profile, and did not decode the raw archive in this audit.'})
summary={'from':F2,'to':C,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'non_evidence_changes':[p for p in paths if not p.startswith('evidence/')],'product_source_files_compared':len(code),'product_differences':[x['file'] for x in code if not x['same']],'product_missing':missing,'build_steps':len(logs[0]),'build_normalized_args_equal':normalized[0]==normalized[1],'unchanged_methods':sum(x in segs[1] and segs[0][x]['sha256']==segs[1][x]['sha256'] for x in segs[0]),'changed_or_new_methods':[x for x in names if x not in segs[0] or x not in segs[1] or segs[0][x]['sha256']!=segs[1][x]['sha256']],'no_tests_executed':True}
save('SUMMARY.json',summary)
print(json.dumps(summary,ensure_ascii=False))
