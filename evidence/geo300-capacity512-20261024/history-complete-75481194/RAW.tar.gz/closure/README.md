# #348：F2 → C 的逐項沿用邊界

F2（實際舊執行來源）：`b595e55952d5d66de95024432e1b29bec7525e9b`。
C（採入來源）：`75481194f3b85a6b07e11896403633d7d0fa0d6f`。
本報告是唯讀閉包核對，**沒有重跑產品、測試或編譯**；不將 F2 的 execution SHA 改標成 C，也不宣告整個 suite／native 已綠。觀測時間與逐項雜湊見 SUMMARY.json。

## 可沿用的範圍

| 項目 | 真實原執行與原結果 | C 的處理 |
|---|---|---|
| 第一 H7：64／512 load＋兩次 canonical replay | F2 原 unittest 明確 `...canonical_replay ... ok`；batch000–005 全部 exit0。64 三批 1.103515／1.132078／1.155056 秒；512 三批 482.595614／500.587198／529.473389 秒，各自原 timeout=600 | 保留 F2 execution，逐項沿用為來源閉包未變的既有證據；不是 C 新實跑 |
| validation memo、contact world、capacity 及其餘五個既有 host 控制，共32項 | F2 `pr348-post-formal-controls-b595/RESULT.json`：32 run／0 failure／0 error／0 skip／exit0，118.664619 秒 | 被呼叫的原函式、測試/共用helper與產品皆不變，可沿用原 F2 證據；不包含新增七支案例 |
| source index 正反控制29項 | 固定 packed-index-b595e559/STATUS.json：29／0／0／0、exit0；原 RESULT.json 在固定 RAW.tar.gz 內，manifest SHA256 `6cadbc8af7d6d012e6015f6dddf7de142af76b0d7a68dc40127bc96520f837fc` | source test/harness與產品未變，可沿用既有 F2 原件。本次僅讀既有 status/manifest，沒有重跑或重新逐筆審計整份壓縮原件 |
| 既有F2 172場景 graph/stdout/stderr/guards 與 N128 profile | 同固定 packed-index 狀態宣告172項逐byte同、profile exit0 10.398194秒；RUSAGE_CHILDREN累積峰值包含編譯，不是執行期RSS | 僅維持原證據及其原限制；Git場景/產品/原工具來源未被這次差異修改。不補成新512 profile、whole suite或新二進位相等證據 |

F2 第一 H7 原件固定發布：
`https://github.com/ZhiQiYang/geometry-axiom/tree/b872264006f400d600c801fe8c096d5679ad9013/evidence/geo300-capacity512-20261024/formal-f2-b595e559`

其 RAW.tar.gz 的 `formal/unittest.log`、`formal/batch-000`～`005` 保留真流；32項收據也在同包。PUBLISH 原件確認該 commit 已一般推送並讀回。本核對不重複發布。

F2 source29／graph／N128 固定原件：
`https://github.com/ZhiQiYang/geometry-axiom/tree/75481194f3b85a6b07e11896403633d7d0fa0d6f/evidence/geo300-capacity512-20261024/packed-index-b595e559`

上述連結固定到本地已知 commit/path，這次沒有額外網路讀回。PACKED_F2_METADATA.json 明列本輪只讀 metadata 的範圍。

## 必須保留為紅、待新實跑或仍未驗

| 項目 | 狀態 |
|---|---|
| F2 第二 H7 sequential/history | 原整輪 exit1，兩方法中1 failure；batch007 child exit0/496.086328秒不等於方法通過。原279行要求未確認delete直接成功的斷言紅，原紅永久保留 |
| C 第二 H7 | 此方法及呼叫鏈已改，不能沿用F2；`pr348-history-c754-formal-v2/REQUEST.json` 已記實際開始，截至本快照尚無 RESULT，未標通過。root 回收終態後另附新收據 |
| C 新七支案例 | 已有真正C實跑：1 run／0 failure／0 error／0 skip／exit0；6.211315秒。不能用它替代512方法；原件 `/dev/shm/pr348-history-c754-smoke/` |
| 新 dialogue/helper 的撤回、恢復與原流收件 | 新路徑必須用自身真收據；這份閉包核對不代替fake-child工具檢查或0/1/0。既有只攔run_once的observer不能冒充已觀測dialogue |
| 完整 host suite／native | 未證明通過。run_all 原 Python suite timeout=1200、CI native=35分鐘均不改；F2第一H7六批耗時總和已約1516秒，不能以每批600秒內綠外推整suite可跑完 |
| run_all.expected 登錄 | C 保留 count7，但新增七支案例使host class變8 test。必須照真實新增案例更新正式登錄並實驗證；不能寫目前完整native綠 |
| mutation ledger／architecture／上游鏈 | 本次不執行。測試檔有變，不能聲稱整份test閉包相同或舊帳本自動有效；依原規則check、必要重產。#346/#347鏈阻擋未由此核對解除 |

## 閉包證據

1. `GIT_CLOSURE.json` 與 git-diff-raw.txt：兩固定 commit 的唯一非evidence差異為 `tests/test_geo261_timber_capacity_host.py`；四個完整產品子樹及 `current_geometry.c` Git OID 相同。只使用本地 cat-file/raw diff，沒有 fetch、checkout 或物件物化。
2. `MATERIALIZED_PRODUCT_CODE.json`：兩個已有checkout的192份 `.c/.h/.inc`（四產品目錄＋current_geometry.c）逐byte相同，0缺件／0差異。這是既有實體來源交叉核對，不是新編譯器include掃描。
3. `HOST_METHODS.json`：原15個函式/方法的來源逐段相同（含setUpClass、第一H7、fixture、static batch、geometry斷言）；新增四個helper/案例及第二H7變更明列。模組整檔hash不同，**不得寫全tests閉包相同**。
4. `SELECTED_FILE_HASHES.json`：native build helper、generator、bridge I/O、host harness及另列控制檔逐byte相同。已改的host測試整檔不在此相同聲明；其原32項所用的五個host方法及呼叫閉包，僅依第3點逐段核對相同。
5. `BUILD_CLOSURE.json`：兩輪真62個compile/link步驟exit0；只將已知 checkout與build-work完整路徑別名化後，所有 arguments 順序／flags／檔案身份完全相同。沒有變動任何runtime/stdout證據的bytes。
6. `RECEIPT_REFERENCES.json`：固定原始命令、exit、時間、RSS、fixture/input/stdout/stderr檔案SHA256與路徑；原件不複製、不重封。
7. `INPUT_CLOSURE.json`：F2首方法六份實際fixture逐一記hash。C第二方法已物化的45154-byte原始512 fixture與F2 batch003逐byte相同（SHA256 `760a7169ea3577341b4b0ec1b56ea39c21c85c777434325ec906debe0a816f10`）；不冒稱C另跑過64或canonical輸入。

主要相同來源hash：

| 來源 | SHA-256 |
|---|---|
| 第一H7函式原文字節 | `eb559928f21175454cab5e86dc54f630be7237d11e2006301e191c7ce30dfbe2` |
| setUpClass含decorator | `822fd3f7850ff41aaeb6c7732c7c79199b0e9ca72ed2e7d3377908321bf523d4` |
| placed_fixture | `50e7f8b9c35454dc3b974ac1e89ff856f444cdfa0d9fde90fbd2c55f235f05cb` |
| placed_batch | `a54aea2eca568fb38d88474e5f8b2231b58945625f801009a16684f8b4529a4f` |
| assert_placed_geometry | `3b2b141454824507c51ef95133fc79a26fce0621cd94c0524ab588d878ba9f38` |
| tests/test_geo261_native_kernel.py | `81518721f7bc1ed3f4c779ab32cd437dd225b2483b3e6358bc7a55930986d4c7` |
| tests/geo300_scene_generator.py | `347142beb7aa06c39969cd5bce35bacddc0734046eb7853e84d96f1ff9ef7c91` |

## 二進位及來源環境限制

F2 ELF：`190dab7786ab0b5f5782c93b46c553d12a3f158f01bfbb1db55510fd1679a3ad`。
C ELF：`b5c8614bd264276f272aba4d62d289cac487d67c84d355c25f6a985fda3abc2a`。
兩份都是1,316,488 bytes／mode33216，但hash不同；不得宣稱ELF逐byte相同，也沒有證實差異僅來自 `__FILE__`。

F2 checkout `/dev/shm/pr348-formal-b595`，build-work `.../geo261-n1a-9kjj73g3`；C checkout `/dev/shm/pr348-active`，正式build-work `.../geo261-n1a-reegi2p1`。原執行收據均記tracked-clean與16MiB stack。以上只允許按未改來源/裁判重用原執行證據，不能捏造C的舊測試新時間、不同ELF的行為等價實跑結果或未執行的整體驗收。
