#!/usr/bin/env python3
"""Make one private aggregate-only C source; never edits its input."""
import argparse, hashlib, json
from pathlib import Path
BASE_SHA256='b00024ec0dff46b27ac4f4a50fe892f54818d110a47e8aad92e4ae723c6a54ea'
PROVIDER=r'''
typedef struct {
    uint32_t token;
    uint64_t requests,backward,backward_hits,backward_misses;
    uint64_t forward_new,backward_new,same_consumer_new;
    uint64_t recent0_hits,recent1_hits,recent_miss_found,cache_contradictions;
    uint64_t gap_max,gap_bins[7];
    uint64_t sources_with_edges,sources_ever_backward,edges_on_backward_sources;
    uint64_t finalized_sources,final_length_max,final_length_bins[7];
} GeoEdgeDiagProvider;
'''
HELPERS=r'''
/* Private diagnostic only. No counter can alter graph decisions. */
static GeoEdgeDiagProvider geo_edge_diag_providers[64],geo_edge_diag_overflow;
static size_t geo_edge_diag_provider_count;
static uint64_t geo_edge_diag_provider_overflows,geo_edge_diag_clear_calls;
static int geo_edge_diag_atexit_status=-2;
static unsigned geo_edge_diag_bin(uint64_t n)
{if(n<=1)return 0;if(n<=4)return 1;if(n<=16)return 2;if(n<=64)return 3;if(n<=256)return 4;if(n<=1024)return 5;return 6;}
static GeoEdgeDiagProvider *geo_edge_diag_provider(uint32_t token)
{
    for(size_t i=0;i<geo_edge_diag_provider_count;++i)
        if(geo_edge_diag_providers[i].token==token)return &geo_edge_diag_providers[i];
    if(geo_edge_diag_provider_count<64){GeoEdgeDiagProvider *p=&geo_edge_diag_providers[geo_edge_diag_provider_count++];p->token=token;return p;}
    ++geo_edge_diag_provider_overflows;return &geo_edge_diag_overflow;
}
static GeoEdgeDiagProvider *geo_edge_diag_for_node(GeoSourceNode *n)
{if(!n->diag_provider)n->diag_provider=geo_edge_diag_provider(n->source.provider);return n->diag_provider;}
static int geo_edge_diag_recent(const GeoSourceNode *n,size_t consumer,unsigned kind)
{for(int i=0;i<2;++i)if(n->diag_recent_kinds[i]&&n->diag_recent_consumer[i]==consumer&&(n->diag_recent_kinds[i]&kind))return i;return -1;}
static void geo_edge_diag_success(GeoSourceNode *n,size_t consumer,unsigned kind)
{
    if(n->diag_recent_kinds[0]&&n->diag_recent_consumer[0]==consumer){n->diag_recent_kinds[0]|=kind;return;}
    unsigned remembered=kind;
    if(n->diag_recent_kinds[1]&&n->diag_recent_consumer[1]==consumer)remembered|=n->diag_recent_kinds[1];
    n->diag_recent_consumer[1]=n->diag_recent_consumer[0];n->diag_recent_kinds[1]=n->diag_recent_kinds[0];
    n->diag_recent_consumer[0]=consumer;n->diag_recent_kinds[0]=remembered;
}
static void geo_edge_diag_backward(GeoSourceNode *n,size_t consumer,bool found,int recent)
{
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);++p->backward;
    if(!n->diag_had_backward){n->diag_had_backward=true;++p->sources_ever_backward;p->edges_on_backward_sources+=n->diag_edges;}
    uint64_t gap=(uint64_t)(n->edge_consumer-consumer);if(gap>p->gap_max)p->gap_max=gap;++p->gap_bins[geo_edge_diag_bin(gap)];
    if(found){++p->backward_hits;if(recent==0)++p->recent0_hits;else if(recent==1)++p->recent1_hits;else ++p->recent_miss_found;}
    else {++p->backward_misses;if(recent>=0)++p->cache_contradictions;}
}
static void geo_edge_diag_appended(GeoSourceNode *n,size_t consumer)
{
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);
    if(!n->diag_edges)++p->sources_with_edges;
    ++n->diag_edges;if(n->diag_had_backward)++p->edges_on_backward_sources;
    if(!n->edge_kinds||consumer>n->edge_consumer)++p->forward_new;
    else if(consumer<n->edge_consumer)++p->backward_new;else ++p->same_consumer_new;
}
static void geo_edge_diag_finish_node(GeoSourceNode *n)
{
    if(!n->diag_edges)return;
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);++p->finalized_sources;
    if(n->diag_edges>p->final_length_max)p->final_length_max=n->diag_edges;
    ++p->final_length_bins[geo_edge_diag_bin(n->diag_edges)];
}
static void geo_edge_diag_print_provider(const GeoEdgeDiagProvider *p)
{
    fprintf(stderr,"{\"provider\":%" PRIu32,p->token);
#define DIAG_FIELD(name) fprintf(stderr,",\"" #name "\":%" PRIu64,p->name)
    DIAG_FIELD(requests);DIAG_FIELD(backward);DIAG_FIELD(backward_hits);DIAG_FIELD(backward_misses);
    DIAG_FIELD(forward_new);DIAG_FIELD(backward_new);DIAG_FIELD(same_consumer_new);
    DIAG_FIELD(recent0_hits);DIAG_FIELD(recent1_hits);DIAG_FIELD(recent_miss_found);DIAG_FIELD(cache_contradictions);
    DIAG_FIELD(gap_max);DIAG_FIELD(sources_with_edges);DIAG_FIELD(sources_ever_backward);DIAG_FIELD(edges_on_backward_sources);
    DIAG_FIELD(finalized_sources);DIAG_FIELD(final_length_max);
#undef DIAG_FIELD
    fputs(",\"gap_bins\":[",stderr);for(unsigned i=0;i<7;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",p->gap_bins[i]);
    fputs("],\"final_length_bins\":[",stderr);for(unsigned i=0;i<7;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",p->final_length_bins[i]);fputs("]}",stderr);
}
static void geo_edge_diag_emit(void)
{
    fprintf(stderr,"GEO348_EDGE_AGGREGATE {\"schema\":1,\"atexit_status\":%d,\"clear_calls\":%" PRIu64 ",\"provider_overflows\":%" PRIu64 ",\"node_size_bytes\":%zu,\"providers\":[",geo_edge_diag_atexit_status,geo_edge_diag_clear_calls,geo_edge_diag_provider_overflows,sizeof(GeoSourceNode));
    for(size_t i=0;i<geo_edge_diag_provider_count;++i){if(i)fputc(',',stderr);geo_edge_diag_print_provider(&geo_edge_diag_providers[i]);}
    fputs("],\"overflow\":",stderr);geo_edge_diag_print_provider(&geo_edge_diag_overflow);fputs("}\n",stderr);
}
'''
def instrument(text):
    def once(old,new):
        nonlocal text
        if text.count(old)!=1:raise ValueError(f'expected unique anchor: {old[:90]!r}; got {text.count(old)}')
        text=text.replace(old,new,1)
    once('#include <string.h>','#include <string.h>\n#include <stdio.h>\n#include <inttypes.h>\n'+PROVIDER)
    once('    bool described;','''    bool described;
    GeoEdgeDiagProvider *diag_provider;
    uint64_t diag_edges;
    size_t diag_recent_consumer[2];
    unsigned diag_recent_kinds[2];
    bool diag_had_backward;''')
    once('/* 索引只保存插入序號加一，零為空槽；陣列仍是唯一的列舉順序。',HELPERS+'\n/* 索引只保存插入序號加一，零為空槽；陣列仍是唯一的列舉順序。')
    once('    GeoEvalContext *ctx=calloc(1,sizeof *ctx);','    if(geo_edge_diag_atexit_status==-2)geo_edge_diag_atexit_status=atexit(geo_edge_diag_emit);\n    GeoEvalContext *ctx=calloc(1,sizeof *ctx);')
    once('static void geo_eval_clear(GeoEvalContext *ctx)\n{','static void geo_eval_clear(GeoEvalContext *ctx)\n{\n    ++geo_edge_diag_clear_calls;')
    once('for(size_t i=0;i<ctx->node_count;++i){free((void *)ctx->nodes[i]->source.key);free(ctx->nodes[i]);}',
         'for(size_t i=0;i<ctx->node_count;++i){geo_edge_diag_finish_node(ctx->nodes[i]);free((void *)ctx->nodes[i]->source.key);free(ctx->nodes[i]);}')
    once('    unsigned kind_bit=1u<<(unsigned)kind;','    unsigned kind_bit=1u<<(unsigned)kind;\n    ++geo_edge_diag_for_node(node)->requests;')
    once('''    if(node->edge_kinds&&ctx->active<node->edge_consumer){
        if(geo_source_find_edge(ctx,edge,&empty_slot))return GEO_SOURCE_OK;
    }else if(node->edge_kinds&&ctx->active==node->edge_consumer&&
             (node->edge_kinds&kind_bit))return GEO_SOURCE_OK;''','''    if(node->edge_kinds&&ctx->active<node->edge_consumer){
        int recent=geo_edge_diag_recent(node,ctx->active,kind_bit);
        bool found=geo_source_find_edge(ctx,edge,&empty_slot);
        geo_edge_diag_backward(node,ctx->active,found,recent);
        if(found){geo_edge_diag_success(node,ctx->active,kind_bit);return GEO_SOURCE_OK;}
    }else if(node->edge_kinds&&ctx->active==node->edge_consumer&&
             (node->edge_kinds&kind_bit)){geo_edge_diag_success(node,ctx->active,kind_bit);return GEO_SOURCE_OK;}''')
    once('    ctx->edges=next;next[ctx->edge_count++]=edge;',
         '    ctx->edges=next;next[ctx->edge_count++]=edge;\n    geo_edge_diag_appended(node,ctx->active);geo_edge_diag_success(node,ctx->active,kind_bit);')
    return text

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    a=parser.parse_args();raw=a.input.read_bytes();sha=hashlib.sha256(raw).hexdigest()
    if sha!=BASE_SHA256:raise SystemExit(f'input identity mismatch: {sha} != {BASE_SHA256}')
    if a.input.resolve()==a.output.resolve():raise SystemExit('refuse to overwrite input')
    data=instrument(raw.decode()).encode()
    with a.output.open('xb') as stream:stream.write(data)
    print(json.dumps({'input_sha256':sha,'output_sha256':hashlib.sha256(data).hexdigest(),'output_bytes':len(data),'output':str(a.output)}))
if __name__=='__main__':main()
