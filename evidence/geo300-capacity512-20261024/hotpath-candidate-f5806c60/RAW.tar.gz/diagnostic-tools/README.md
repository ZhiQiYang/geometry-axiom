# #348 一次 aggregate-only 診斷插樁

目的：給主代理下一次既定 N128 診斷使用，不新增測試輪次、不把計數器接進產品分支。**未編譯、未執行 C、未計時、未取得輸出等價證據**。只已執行文字產生腳本，全部原碼 anchor 唯一且 SHA 相符。

基底 source commit `8efcc265c69aecf802854d1d80eba1893df7b8c0`，兩份輸入葉 hash 見 MANIFEST.json。原檔均未修改。`instrument.py`／`instrument_memo.py` 僅接受固定 hash，輸出必須新檔且不得覆寫輸入；若合成候選改了這兩個 leaf，必須明確重審，不能直接移除身份檢查。

交付：
- `source.instrumented.c`：K 的 backward edge 與 source 鏈長 aggregate。
- `contact_sources.instrumented.c`：可選 W memo 拒絕原因；不新增快取。
- `diagnostic.patch`：兩者對固定原 leaf 的 unified diff。
- 兩個產生腳本及本說明／manifest。

## K 計數的精確定義

所有 provider 分布依 **source.provider**（非 consumer.provider）。首次有有效 active consumer 的 edge request 才分配一個靜態 bucket，最多64個token，沒有新增動態 allocation；若 overflow非零，provider分布不可稱完整。`provider_overflows`是遇到未收錄provider的新節點次數，不是distinct provider數。

- `requests`：通過 kind 與 active 守門的 edge requests。
- `backward`／`backward_hits`／`backward_misses`：原 `active < node.edge_consumer` 分支，**原 find_edge 仍每次照跑一次**。計數不參與return或查找判斷。
- `forward_new`：首次 source 邊或 consumer 大於先前最大值；`backward_new`：consumer較小而真追加；`same_consumer_new`：同最大consumer的新kind。只在必要 edges 配置成功、原邊已追加後計數。
- `gap_max`／`gap_bins`：backward 的 `old maximum consumer ordinal - current consumer ordinal`；不是 edge 位置或實際 CPU work。
- `sources_with_edges`：曾成功追加邊的source節點；`sources_ever_backward`：至少一次 backward 查找的source節點。
- `edges_on_backward_sources`：曾 backward 的source，其整個生命週期全部成功append邊（第一次 backward 時計入先前prefix，以後逐次加）。可判斷理論上只索引這類source能省掉多少條索引維護；不是已實作稀疏索引的速度。
- `recent0_hits`／`recent1_hits`：在做原 backward 查找**之前**，最近兩個不同consumer之成功 edge requests所保留kind，是否可證該邊存在；仍執行原查找並只在真found時計入。沒有改原判斷。MRU更新涵蓋既有最大consumer快徑、真find命中、成功append；必要配置失敗不更新。evicted consumer 的未重見kind只會保守miss。
- `recent_miss_found`：原查找found，但這兩格不能證明。`cache_contradictions`預期0；非0即觀測模型有問題，不能拿其命中率決定產品修法。
- `final_length_max`／`final_length_bins`：每個 source 曾append的總邊數，僅在clear/reset/destroy節點時計入；`finalized_sources == sources_with_edges`才可稱所有相關source已收生命週期。`clear_calls`含reset。
- 兩組bins均 `[1, 2–4, 5–16, 17–64, 65–256, 257–1024, >=1025]`。沒有每筆stdout／stderr。

## W memo 計數的精確定義

原結果、原first-rejection順序、facts memcmp次數及snapshot掃描次數不變。為同時觀察axis與exclude，有memo且collection有效時額外先計算四個已初始化、非volatile scalar比較；它們沒有provider／allocation副作用。

`first_failure`八槽依次為：
1. 沒memo或沒有collection；
2. count超cap或collection_size不合法；
3. placement不等；
4. axis不等；
5. exclude **原指標**不等；
6. cap不等；
7. 原整份facts memcmp不等；
8. member id／placed snapshot不等。

`request_mismatch`四槽 `[placement,axis,exclude,cap]`為同一次已到request階段的比較，可重疊，不能相加當miss總數。`request_examined`是此分母；`memcmp_examined`只包含request四條全等者；`snapshots_examined`是進入原snapshot迴圈的query數，不是member讀取數。`calls == hits + sum(first_failure)`須成立。因保持短路，axis／exclude先不等時**不知道facts是否也相異**，不能由此直接證明多筆memo能命中。

## EOF／等價核對

正常退出由atexit各印一行，前綴分別唯一：`GEO348_EDGE_AGGREGATE `、`GEO348_MEMO_AGGREGATE `。**現在是兩個不同的唯一行**，不可用寬泛字串過濾整類stderr；原始stderr須完整保留。

主代理驗證時要求兩行各恰一、JSON可解析、各atexit_status為0，K provider_overflows及cache_contradictions為0。只移除此兩個完整、具名行後，其餘stderr必須逐byte等於未插樁同輸入原件；stdout全部逐byte相等。非正常退出缺行、原stderr沒有換行導致前綴黏接、或任一identity不等都如實保留失敗，不能猜測補行。

## 已做靜態對抗審查與限制

子代理 `instrument_static_review` 已讀兩份差異，未發現阻斷：原find_edge仍每次一次、原返回條件不由counter改寫、MRU consumer＋kind自洽、W沒有多做memcmp或快照pass。**沒有編譯／執行證據。**

K加了每node觀測欄位，sizeof會變大；atexit可有libc內部配置。兩者以及counter函式必然可能影響RSS／elapsed／配置序列；此輪只用來歸因與等價觀測，不作正式效能或allocation-failure acceptance。全域counter非執行緒安全，限原單執行緒 CLI。正式候選仍須用未插樁產品來源。
