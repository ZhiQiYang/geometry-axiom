#include "source.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

typedef struct {
    uint32_t token;
    uint64_t requests,backward,backward_hits,backward_misses;
    uint64_t forward_new,backward_new,same_consumer_new;
    uint64_t recent0_hits,recent1_hits,recent_miss_found,cache_contradictions;
    uint64_t gap_max,gap_bins[7];
    uint64_t sources_with_edges,sources_ever_backward,edges_on_backward_sources;
    uint64_t finalized_sources,final_length_max,final_length_bins[7];
} GeoEdgeDiagProvider;


typedef struct {
    GeoSourceRef source;
    GeoSourceDescriptor descriptor;
    GeoSourceValue value;
    GeoSourceState state;
    GeoSourceStatus status;
    size_t provider;
    size_t edge_consumer;
    unsigned edge_kinds;
    bool described;
    GeoEdgeDiagProvider *diag_provider;
    uint64_t diag_edges;
    size_t diag_recent_consumer[2];
    unsigned diag_recent_kinds[2];
    bool diag_had_backward;
} GeoSourceNode;
struct GeoEvalContext {
    uint64_t candidate_id,base_revision;
    GeoSourceProvider *providers;
    size_t provider_count;
    GeoSourceNode **nodes;
    size_t node_count, node_capacity;
    uint32_t *node_index;
    size_t node_index_capacity;
    size_t node_hint[256];
    GeoSourceEdge *edges;
    size_t edge_count, edge_capacity;
    uint32_t *edge_index;
    size_t edge_index_capacity;
    size_t active;
    bool started, sealed;
};

/* Private diagnostic only. No counter can alter graph decisions. */
static GeoEdgeDiagProvider geo_edge_diag_providers[64],geo_edge_diag_overflow;
static size_t geo_edge_diag_provider_count;
static uint64_t geo_edge_diag_provider_overflows,geo_edge_diag_clear_calls;
static int geo_edge_diag_atexit_status=-2;
static unsigned geo_edge_diag_bin(uint64_t n)
{if(n<=1)return 0;if(n<=4)return 1;if(n<=16)return 2;if(n<=64)return 3;if(n<=256)return 4;if(n<=1024)return 5;return 6;}
static GeoEdgeDiagProvider *geo_edge_diag_provider(uint32_t token)
{
    for(size_t i=0;i<geo_edge_diag_provider_count;++i)
        if(geo_edge_diag_providers[i].token==token)return &geo_edge_diag_providers[i];
    if(geo_edge_diag_provider_count<64){GeoEdgeDiagProvider *p=&geo_edge_diag_providers[geo_edge_diag_provider_count++];p->token=token;return p;}
    ++geo_edge_diag_provider_overflows;return &geo_edge_diag_overflow;
}
static GeoEdgeDiagProvider *geo_edge_diag_for_node(GeoSourceNode *n)
{if(!n->diag_provider)n->diag_provider=geo_edge_diag_provider(n->source.provider);return n->diag_provider;}
static int geo_edge_diag_recent(const GeoSourceNode *n,size_t consumer,unsigned kind)
{for(int i=0;i<2;++i)if(n->diag_recent_kinds[i]&&n->diag_recent_consumer[i]==consumer&&(n->diag_recent_kinds[i]&kind))return i;return -1;}
static void geo_edge_diag_success(GeoSourceNode *n,size_t consumer,unsigned kind)
{
    if(n->diag_recent_kinds[0]&&n->diag_recent_consumer[0]==consumer){n->diag_recent_kinds[0]|=kind;return;}
    unsigned remembered=kind;
    if(n->diag_recent_kinds[1]&&n->diag_recent_consumer[1]==consumer)remembered|=n->diag_recent_kinds[1];
    n->diag_recent_consumer[1]=n->diag_recent_consumer[0];n->diag_recent_kinds[1]=n->diag_recent_kinds[0];
    n->diag_recent_consumer[0]=consumer;n->diag_recent_kinds[0]=remembered;
}
static void geo_edge_diag_backward(GeoSourceNode *n,size_t consumer,bool found,int recent)
{
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);++p->backward;
    if(!n->diag_had_backward){n->diag_had_backward=true;++p->sources_ever_backward;p->edges_on_backward_sources+=n->diag_edges;}
    uint64_t gap=(uint64_t)(n->edge_consumer-consumer);if(gap>p->gap_max)p->gap_max=gap;++p->gap_bins[geo_edge_diag_bin(gap)];
    if(found){++p->backward_hits;if(recent==0)++p->recent0_hits;else if(recent==1)++p->recent1_hits;else ++p->recent_miss_found;}
    else {++p->backward_misses;if(recent>=0)++p->cache_contradictions;}
}
static void geo_edge_diag_appended(GeoSourceNode *n,size_t consumer)
{
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);
    if(!n->diag_edges)++p->sources_with_edges;
    ++n->diag_edges;if(n->diag_had_backward)++p->edges_on_backward_sources;
    if(!n->edge_kinds||consumer>n->edge_consumer)++p->forward_new;
    else if(consumer<n->edge_consumer)++p->backward_new;else ++p->same_consumer_new;
}
static void geo_edge_diag_finish_node(GeoSourceNode *n)
{
    if(!n->diag_edges)return;
    GeoEdgeDiagProvider *p=geo_edge_diag_for_node(n);++p->finalized_sources;
    if(n->diag_edges>p->final_length_max)p->final_length_max=n->diag_edges;
    ++p->final_length_bins[geo_edge_diag_bin(n->diag_edges)];
}
static void geo_edge_diag_print_provider(const GeoEdgeDiagProvider *p)
{
    fprintf(stderr,"{\"provider\":%" PRIu32,p->token);
#define DIAG_FIELD(name) fprintf(stderr,",\"" #name "\":%" PRIu64,p->name)
    DIAG_FIELD(requests);DIAG_FIELD(backward);DIAG_FIELD(backward_hits);DIAG_FIELD(backward_misses);
    DIAG_FIELD(forward_new);DIAG_FIELD(backward_new);DIAG_FIELD(same_consumer_new);
    DIAG_FIELD(recent0_hits);DIAG_FIELD(recent1_hits);DIAG_FIELD(recent_miss_found);DIAG_FIELD(cache_contradictions);
    DIAG_FIELD(gap_max);DIAG_FIELD(sources_with_edges);DIAG_FIELD(sources_ever_backward);DIAG_FIELD(edges_on_backward_sources);
    DIAG_FIELD(finalized_sources);DIAG_FIELD(final_length_max);
#undef DIAG_FIELD
    fputs(",\"gap_bins\":[",stderr);for(unsigned i=0;i<7;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",p->gap_bins[i]);
    fputs("],\"final_length_bins\":[",stderr);for(unsigned i=0;i<7;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",p->final_length_bins[i]);fputs("]}",stderr);
}
static void geo_edge_diag_emit(void)
{
    fprintf(stderr,"GEO348_EDGE_AGGREGATE {\"schema\":1,\"atexit_status\":%d,\"clear_calls\":%" PRIu64 ",\"provider_overflows\":%" PRIu64 ",\"node_size_bytes\":%zu,\"providers\":[",geo_edge_diag_atexit_status,geo_edge_diag_clear_calls,geo_edge_diag_provider_overflows,sizeof(GeoSourceNode));
    for(size_t i=0;i<geo_edge_diag_provider_count;++i){if(i)fputc(',',stderr);geo_edge_diag_print_provider(&geo_edge_diag_providers[i]);}
    fputs("],\"overflow\":",stderr);geo_edge_diag_print_provider(&geo_edge_diag_overflow);fputs("}\n",stderr);
}

/* 索引只保存插入序號加一，零為空槽；陣列仍是唯一的列舉順序。
 * 可選槽用 32 位序號；超出可表示範圍或配置失敗時退回線性查找，
 * ordered 陣列及其 size_t 身分不變，不新增 CAPACITY/MEMORY 結果。 */
static uint64_t geo_source_hash_size(uint64_t hash,size_t value)
{
    hash^=(uint64_t)value;hash*=UINT64_C(11400714785074694791);
    return hash^(hash>>32);
}
static uint64_t geo_source_node_hash(GeoSourceRef source)
{
    uint64_t hash=geo_source_hash_size(UINT64_C(14695981039346656037),source.provider);
    hash=geo_source_hash_size(hash,source.key_size);
    const unsigned char *key=source.key;size_t i=0;
    /* 雜湊只選記憶體索引槽；身分仍完整比對每個位元組。
     * memcpy 可讀未對齊的鍵；主機端序只影響碰撞排列。 */
    while(source.key_size-i>=sizeof(uint64_t)){
        uint64_t word;memcpy(&word,key+i,sizeof word);
        hash^=word;hash*=UINT64_C(11400714785074694791);hash^=hash>>32;
        i+=sizeof word;
    }
    for(;i<source.key_size;++i){hash^=key[i];hash*=UINT64_C(1099511628211);}
    return hash;
}
static uint64_t geo_source_edge_hash(GeoSourceEdge edge)
{
    uint64_t hash=geo_source_hash_size(UINT64_C(14695981039346656037),edge.consumer);
    hash=geo_source_hash_size(hash,edge.source);
    return geo_source_hash_size(hash,(size_t)edge.kind);
}
static bool geo_source_ref_equal(GeoSourceRef a,GeoSourceRef b)
{
    return a.provider==b.provider&&a.key_size==b.key_size&&
        (!a.key_size||!memcmp(a.key,b.key,a.key_size));
}
static bool geo_source_edge_equal(GeoSourceEdge a,GeoSourceEdge b)
{return a.consumer==b.consumer&&a.source==b.source&&a.kind==b.kind;}
static size_t geo_source_find_node(const GeoEvalContext *ctx,GeoSourceRef source,size_t *empty_slot)
{
    if(ctx->node_index_capacity){
        size_t mask=ctx->node_index_capacity-1,slot=(size_t)geo_source_node_hash(source)&mask;
        while(ctx->node_index[slot]){
            size_t i=ctx->node_index[slot]-1;
            if(geo_source_ref_equal(ctx->nodes[i]->source,source))return i;
            slot=(slot+1)&mask;
        }
        if(empty_slot)*empty_slot=slot;
    }else for(size_t i=0;i<ctx->node_count;++i)
        if(geo_source_ref_equal(ctx->nodes[i]->source,source))return i;
    return SIZE_MAX;
}
static bool geo_source_find_edge(const GeoEvalContext *ctx,GeoSourceEdge edge,size_t *empty_slot)
{
    if(ctx->edge_index_capacity){
        size_t mask=ctx->edge_index_capacity-1,slot=(size_t)geo_source_edge_hash(edge)&mask;
        while(ctx->edge_index[slot]){
            if(geo_source_edge_equal(ctx->edges[ctx->edge_index[slot]-1],edge))return true;
            slot=(slot+1)&mask;
        }
        *empty_slot=slot;
    }else for(size_t i=0;i<ctx->edge_count;++i)
        if(geo_source_edge_equal(ctx->edges[i],edge))return true;
    return false;
}
/* 負載最多一半；新表建好才換入。失敗後舊表不完整，須改走線性搜尋。 */
static void geo_source_index_append_at(GeoEvalContext *ctx,bool nodes,size_t empty_slot)
{
    uint32_t **table=nodes?&ctx->node_index:&ctx->edge_index;
    size_t *capacity=nodes?&ctx->node_index_capacity:&ctx->edge_index_capacity;
    size_t count=nodes?ctx->node_count:ctx->edge_count,first=count-1;
    if(count>UINT32_MAX)goto fallback;
    if(count>*capacity/2){
        size_t next=*capacity?*capacity:16;
        while(count>next/2){if(next>SIZE_MAX/2)goto fallback;next*=2;}
        if(next>SIZE_MAX/sizeof **table)goto fallback;
        uint32_t *fresh=calloc(next,sizeof *fresh);
        if(!fresh)goto fallback;
        free(*table);*table=fresh;*capacity=next;first=0;
    }else if(empty_slot!=SIZE_MAX&&empty_slot<*capacity){
        /* 身分查找已走到這個空槽；期間僅有必要的 node/key/array 配置，
         * 沒有 provider 回呼或索引改動。原序號守門先跑，擴表仍重建全表。 */
        (*table)[empty_slot]=(uint32_t)count;return;
    }
    for(size_t i=first;i<count;++i){
        uint64_t hash=nodes?geo_source_node_hash(ctx->nodes[i]->source):geo_source_edge_hash(ctx->edges[i]);
        size_t mask=*capacity-1,slot=(size_t)hash&mask;
        while((*table)[slot])slot=(slot+1)&mask;
        (*table)[slot]=(uint32_t)(i+1);
    }
    return;
fallback:
    free(*table);*table=NULL;*capacity=0;
}
/* 保留一般追加入口；沒有已驗空槽的邊及測試仍走原探測／降級。 */
static void geo_source_index_append(GeoEvalContext *ctx,bool nodes)
{geo_source_index_append_at(ctx,nodes,SIZE_MAX);}
static void *geo_source_grow(void *data,size_t count,size_t *capacity,size_t item_size)
{
    if(count<*capacity)return data;
    size_t limit=SIZE_MAX/item_size,next=*capacity?*capacity:8;
    if(next<=limit/2)next*=2;else next=limit;
    if(next>limit)next=limit;
    void *grown=realloc(data,next*item_size);
    /* 倍增失敗仍重試舊實作需要的大小，不擴大 MEMORY 的條件。 */
    if(!grown&&next!=count+1){next=count+1;grown=realloc(data,next*item_size);}
    if(grown)*capacity=next;
    return grown;
}
static char *geo_source_copy_text(const char *text)
{
    if(!text||!*text)return NULL;
    size_t length=strlen(text);char *copy=malloc(length+1);
    if(copy)memcpy(copy,text,length+1);return copy;
}
GeoEvalContext *geo_eval_create(uint64_t candidate_id,uint64_t base_revision)
{
    if(geo_edge_diag_atexit_status==-2)geo_edge_diag_atexit_status=atexit(geo_edge_diag_emit);
    GeoEvalContext *ctx=calloc(1,sizeof *ctx);
    if(ctx){ctx->candidate_id=candidate_id;ctx->base_revision=base_revision;ctx->active=SIZE_MAX;}
    return ctx;
}
static void geo_eval_clear(GeoEvalContext *ctx)
{
    ++geo_edge_diag_clear_calls;
    for(size_t i=0;i<ctx->provider_count;++i){free((void *)ctx->providers[i].name_space);free((void *)ctx->providers[i].implementation_fingerprint);}
    for(size_t i=0;i<ctx->node_count;++i){geo_edge_diag_finish_node(ctx->nodes[i]);free((void *)ctx->nodes[i]->source.key);free(ctx->nodes[i]);}
    free(ctx->providers);free(ctx->nodes);free(ctx->edges);
    free(ctx->node_index);free(ctx->edge_index);
    ctx->providers=NULL;ctx->nodes=NULL;ctx->edges=NULL;
    ctx->node_index=NULL;ctx->edge_index=NULL;
    memset(ctx->node_hint,0,sizeof ctx->node_hint);
    ctx->provider_count=ctx->node_count=ctx->edge_count=0;
    ctx->node_capacity=ctx->edge_capacity=ctx->node_index_capacity=ctx->edge_index_capacity=0;
    ctx->active=SIZE_MAX;ctx->started=false;ctx->sealed=false;
}
void geo_eval_destroy(GeoEvalContext *ctx)
{if(ctx){geo_eval_clear(ctx);free(ctx);}}
bool geo_eval_register(GeoEvalContext *ctx,const GeoSourceProvider *provider)
{return geo_eval_register_many(ctx,provider,1);}
bool geo_eval_register_many(GeoEvalContext *ctx,const GeoSourceProvider *providers,size_t count)
{
    if(!ctx||ctx->started||ctx->sealed||!providers||!count||count>SIZE_MAX/sizeof *providers-ctx->provider_count)return false;
    for(size_t n=0;n<count;++n){const GeoSourceProvider *p=&providers[n];
        if(!p->describe||!p->evaluate||!p->name_space||!*p->name_space||!p->implementation_fingerprint||!*p->implementation_fingerprint)return false;
        for(size_t i=0;i<ctx->provider_count;++i)
            if(ctx->providers[i].token==p->token||!strcmp(ctx->providers[i].name_space,p->name_space))return false;
        for(size_t i=0;i<n;++i)
            if(providers[i].token==p->token||!strcmp(providers[i].name_space,p->name_space))return false;
    }
    GeoSourceProvider *next=calloc(ctx->provider_count+count,sizeof *next);if(!next)return false;
    if(ctx->provider_count)memcpy(next,ctx->providers,ctx->provider_count*sizeof *next);
    for(size_t n=0;n<count;++n){GeoSourceProvider *p=&next[ctx->provider_count+n];*p=providers[n];
        p->name_space=geo_source_copy_text(providers[n].name_space);
        p->implementation_fingerprint=geo_source_copy_text(providers[n].implementation_fingerprint);
        if(!p->name_space||!p->implementation_fingerprint){
            for(size_t i=0;i<=n;++i){free((void *)next[ctx->provider_count+i].name_space);free((void *)next[ctx->provider_count+i].implementation_fingerprint);}
            free(next);return false;
        }
    }
    free(ctx->providers);ctx->providers=next;ctx->provider_count+=count;return true;
}
uint64_t geo_eval_candidate_id(const GeoEvalContext *ctx){return ctx?ctx->candidate_id:0;}
uint64_t geo_eval_base_revision(const GeoEvalContext *ctx){return ctx?ctx->base_revision:0;}
size_t geo_eval_provider_count(const GeoEvalContext *ctx){return ctx?ctx->provider_count:0;}
const GeoSourceProvider *geo_eval_provider_at(const GeoEvalContext *ctx,size_t i){return ctx&&i<ctx->provider_count?&ctx->providers[i]:NULL;}
static GeoSourceStatus geo_source_node(GeoEvalContext *ctx,GeoSourceRef source,size_t *index)
{
    if(!ctx||!index||(source.key_size&&!source.key))return GEO_SOURCE_INVALID;
    ctx->started=true;
    /* 只快取既有身分的插入序號；碰撞仍完整比對 K 持有的鍵。 */
    size_t slot=(size_t)source.provider^source.key_size;
    if(source.key_size){const unsigned char *key=source.key;slot^=(size_t)key[0]^key[source.key_size-1];}
    slot&=255;
    size_t hint=ctx->node_hint[slot];
    if(hint&&hint<=ctx->node_count&&geo_source_ref_equal(ctx->nodes[hint-1]->source,source)){
        *index=hint-1;return GEO_SOURCE_OK;
    }
    size_t empty_slot=SIZE_MAX;
    size_t found=geo_source_find_node(ctx,source,&empty_slot);
    if(found!=SIZE_MAX){ctx->node_hint[slot]=found+1;*index=found;return GEO_SOURCE_OK;}
    size_t provider=0;while(provider<ctx->provider_count&&ctx->providers[provider].token!=source.provider)++provider;
    if(provider==ctx->provider_count)return GEO_SOURCE_MISSING;
    if(ctx->node_count==SIZE_MAX/sizeof *ctx->nodes)return GEO_SOURCE_MEMORY;
    GeoSourceNode *node=calloc(1,sizeof *node);
    if(!node)return GEO_SOURCE_MEMORY;
    if(source.key_size){void *key=malloc(source.key_size);if(!key){free(node);return GEO_SOURCE_MEMORY;}memcpy(key,source.key,source.key_size);source.key=key;}
    else source.key=NULL;
    GeoSourceNode **next=geo_source_grow(ctx->nodes,ctx->node_count,&ctx->node_capacity,sizeof *next);
    if(!next){free((void *)source.key);free(node);return GEO_SOURCE_MEMORY;}
    ctx->nodes=next;node->source=source;node->provider=provider;node->status=GEO_SOURCE_OK;
    *index=ctx->node_count;next[ctx->node_count++]=node;
    geo_source_index_append_at(ctx,true,empty_slot);ctx->node_hint[slot]=*index+1;return GEO_SOURCE_OK;
}
static GeoSourceStatus geo_source_edge(GeoEvalContext *ctx,size_t source,GeoDependencyKind kind)
{
    if(kind<GEO_DEPENDENCY_VALUE_REQUIRED||kind>GEO_DEPENDENCY_EVALUATE_BEFORE)return GEO_SOURCE_INVALID;
    if(ctx->active==SIZE_MAX)return GEO_SOURCE_OK;
    GeoSourceEdge edge={ctx->active,source,kind};
    GeoSourceNode *node=ctx->nodes[source];
    unsigned kind_bit=1u<<(unsigned)kind;
    ++geo_edge_diag_for_node(node)->requests;
    size_t empty_slot=SIZE_MAX;
    /* 每個 source 只記已成功追加的最大 consumer 及其 kind。
     * 更大的 consumer 尚無邊；同一個 consumer 可直接判斷 kind；
     * 巢狀回呼返回較早 consumer 時仍由完整索引判斷，不省略任何邊。 */
    if(node->edge_kinds&&ctx->active<node->edge_consumer){
        int recent=geo_edge_diag_recent(node,ctx->active,kind_bit);
        bool found=geo_source_find_edge(ctx,edge,&empty_slot);
        geo_edge_diag_backward(node,ctx->active,found,recent);
        if(found){geo_edge_diag_success(node,ctx->active,kind_bit);return GEO_SOURCE_OK;}
    }else if(node->edge_kinds&&ctx->active==node->edge_consumer&&
             (node->edge_kinds&kind_bit)){geo_edge_diag_success(node,ctx->active,kind_bit);return GEO_SOURCE_OK;}
    if(ctx->edge_count==SIZE_MAX/sizeof *ctx->edges)return GEO_SOURCE_MEMORY;
    GeoSourceEdge *next=geo_source_grow(ctx->edges,ctx->edge_count,&ctx->edge_capacity,sizeof *next);
    if(!next)return GEO_SOURCE_MEMORY;
    ctx->edges=next;next[ctx->edge_count++]=edge;
    geo_edge_diag_appended(node,ctx->active);geo_edge_diag_success(node,ctx->active,kind_bit);
    /* 查找已取得空槽；兩步間只有 edges 配置，不會改動索引或呼叫 provider。
     * 不需擴表時直接寫入同槽，避免對新邊再雜湊與探測一次。
     * 無索引、擴表及配置失敗的降級仍由原路徑處理。 */
    if(empty_slot!=SIZE_MAX&&ctx->edge_count<=UINT32_MAX&&ctx->edge_count<=ctx->edge_index_capacity/2)
        ctx->edge_index[empty_slot]=(uint32_t)ctx->edge_count;
    else geo_source_index_append(ctx,false);
    /* 必須晚於必要的 edges 配置／追加；MEMORY 不能留下不存在的邊提示。 */
    if(!node->edge_kinds||ctx->active>node->edge_consumer){
        node->edge_consumer=ctx->active;node->edge_kinds=kind_bit;
    }else if(ctx->active==node->edge_consumer)node->edge_kinds|=kind_bit;
    return GEO_SOURCE_OK;
}
static bool geo_source_descriptor_valid(const GeoSourceDescriptor *d)
{
    return d->kind>=GEO_SOURCE_QUANTITY&&d->kind<=GEO_SOURCE_DEFINITION&&
        (d->unit==GEO_UNIT_SCALAR||d->unit==GEO_UNIT_LENGTH)&&
        d->context.axis>=-1&&d->context.axis<=2&&
        (!d->context_from_value||d->kind==GEO_SOURCE_AXIS_POSITION);
}
static bool geo_source_context_equal(GeoSourceContext a,GeoSourceContext b)
{
    return a.has_placement==b.has_placement&&a.axis==b.axis&&(!a.has_placement||a.placement==b.placement);
}
static bool geo_source_value_matches(const GeoSourceDescriptor *d,const GeoSourceValue *v)
{
    if(v->kind!=d->kind)return false;
    if(v->kind==GEO_SOURCE_QUANTITY)return v->as.quantity.den>0&&v->as.quantity.unit==d->unit;
    if(v->kind==GEO_SOURCE_AXIS_POSITION)return d->context_from_value?
        v->as.position.context.axis>=0&&v->as.position.context.axis<=2:
        geo_source_context_equal(d->context,v->as.position.context);
    if(v->kind==GEO_SOURCE_REGION_SET)return !v->as.regions.count||v->as.regions.regions!=NULL;
    if(v->kind==GEO_SOURCE_FEATURE)return !v->as.feature.key_size||v->as.feature.key!=NULL;
    if(v->kind==GEO_SOURCE_DEFINITION)return v->as.definition.schema&&*v->as.definition.schema&&
        (!v->as.definition.content_size||v->as.definition.content!=NULL);
    return true;
}
GeoSourceStatus geo_eval_describe(GeoEvalContext *ctx,GeoSourceRef source,GeoSourceDescriptor *out)
{
    if(!ctx||!out||(source.key_size&&!source.key))return GEO_SOURCE_INVALID;
    size_t index=0;
    if(ctx->sealed){
        index=geo_source_find_node(ctx,source,NULL);
        if(index==SIZE_MAX||!ctx->nodes[index]->described)return GEO_SOURCE_INVALID;
    }else{
        GeoSourceStatus status=geo_source_node(ctx,source,&index);
        if(status!=GEO_SOURCE_OK)return status;
    }
    GeoSourceNode *node=ctx->nodes[index];
    if(!node->described){
        GeoSourceProvider *provider=&ctx->providers[node->provider];
        GeoSourceDescriptor descriptor={0};
        if(!provider->describe(provider->candidate_state,&node->source,&descriptor))return GEO_SOURCE_MISSING;
        if(!geo_source_descriptor_valid(&descriptor))return GEO_SOURCE_INVALID;
        node->descriptor=descriptor;node->described=true;
    }
    if(!geo_source_descriptor_valid(&node->descriptor))return GEO_SOURCE_INVALID;
    *out=node->descriptor;return GEO_SOURCE_OK;
}
GeoSourceStatus geo_eval_depend(GeoEvalContext *ctx,GeoSourceRef source,GeoDependencyKind kind)
{
    if(ctx&&ctx->sealed)return GEO_SOURCE_INVALID;
    size_t index;GeoSourceStatus result=geo_source_node(ctx,source,&index);
    if(result!=GEO_SOURCE_OK)return result;
    return geo_source_edge(ctx,index,kind);
}
GeoSourceStatus geo_eval_source(GeoEvalContext *ctx,GeoSourceRef source,GeoDependencyKind kind,GeoSourceValue *out)
{
    if(!out)return GEO_SOURCE_INVALID;
    if(ctx&&ctx->sealed){
        if((source.key_size&&!source.key)||kind<GEO_DEPENDENCY_VALUE_REQUIRED||kind>GEO_DEPENDENCY_EVALUATE_BEFORE)return GEO_SOURCE_INVALID;
        size_t i=geo_source_find_node(ctx,source,NULL);
        if(i==SIZE_MAX||ctx->nodes[i]->state!=GEO_NODE_VALID)return GEO_SOURCE_INVALID;
        *out=ctx->nodes[i]->value;return GEO_SOURCE_OK;
    }
    size_t index;GeoSourceStatus result=geo_source_node(ctx,source,&index);
    if(result!=GEO_SOURCE_OK)return result;
    result=geo_source_edge(ctx,index,kind);if(result!=GEO_SOURCE_OK)return result;
    GeoSourceNode *node=ctx->nodes[index];
    if(node->state==GEO_NODE_ACTIVE)return GEO_SOURCE_CYCLE;
    if(node->state==GEO_NODE_VALID){*out=node->value;return GEO_SOURCE_OK;}
    if(node->state==GEO_NODE_FAILED&&(!node->described||!node->descriptor.retry_failure))return node->status;
    GeoSourceProvider *provider=&ctx->providers[node->provider];
    if(!node->described){
        node->described=provider->describe(provider->candidate_state,&node->source,&node->descriptor);
        if(!node->described||!geo_source_descriptor_valid(&node->descriptor)){
            node->state=GEO_NODE_FAILED;node->status=node->described?GEO_SOURCE_INVALID:GEO_SOURCE_MISSING;return node->status;}
    }
    if(!geo_source_descriptor_valid(&node->descriptor))return GEO_SOURCE_INVALID;
    size_t previous=ctx->active;ctx->active=index;node->state=GEO_NODE_ACTIVE;
    GeoSourceValue value={0};bool ok=provider->evaluate(provider->candidate_state,ctx,&node->source,&value);
    ctx->active=previous;node->state=GEO_NODE_FAILED;node->status=GEO_SOURCE_FAILED;
    if(!ok)return node->status;
    if(!geo_source_value_matches(&node->descriptor,&value)){node->status=GEO_SOURCE_INVALID;return node->status;}
    if(node->descriptor.context_from_value){node->descriptor.context=value.as.position.context;node->descriptor.context_from_value=false;}
    node->value=value;node->state=GEO_NODE_VALID;node->status=GEO_SOURCE_OK;
    *out=node->value;return GEO_SOURCE_OK;
}
size_t geo_eval_node_count(const GeoEvalContext *ctx){return ctx?ctx->node_count:0;}
bool geo_eval_node_at(const GeoEvalContext *ctx,size_t i,GeoSourceNodeView *out)
{
    if(!ctx||i>=ctx->node_count||!out)return false;
    const GeoSourceNode *node=ctx->nodes[i];
    *out=(GeoSourceNodeView){node->source,node->descriptor,node->state,node->status,node->state==GEO_NODE_VALID?&node->value:NULL,node->described};return true;
}
size_t geo_eval_edge_count(const GeoEvalContext *ctx){return ctx?ctx->edge_count:0;}
bool geo_eval_edge_at(const GeoEvalContext *ctx,size_t i,GeoSourceEdge *out)
{if(!ctx||i>=ctx->edge_count||!out)return false;*out=ctx->edges[i];return true;}
bool geo_eval_seal(GeoEvalContext *ctx)
{
    if(!ctx)return false;
    for(size_t i=0;i<ctx->node_count;++i)if(ctx->nodes[i]->state==GEO_NODE_ACTIVE)return false;
    ctx->sealed=true;ctx->started=true;return true;
}
bool geo_eval_is_sealed(const GeoEvalContext *ctx){return ctx&&ctx->sealed;}
bool geo_eval_reset(GeoEvalContext *ctx)
{
    if(!ctx||ctx->sealed||ctx->active!=SIZE_MAX)return false;
    geo_eval_clear(ctx);return true;
}
