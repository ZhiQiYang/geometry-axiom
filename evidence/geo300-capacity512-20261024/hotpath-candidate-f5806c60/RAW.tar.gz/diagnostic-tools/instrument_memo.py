#!/usr/bin/env python3
"""Optional first-rejection counters; no extra facts memcmp or snapshot pass."""
import argparse,hashlib,json
from pathlib import Path
BASE_SHA256='394c6e5a173b3e115e5bf2ec859b226c9970d676c8e2705fd8a3b08cfe389d37'
HELPERS=r'''
/* Private counters: same first-rejection order; four harmless scalar
 * comparisons are observed together, without extra memcmp or snapshot scans. */
static uint64_t geo348_memo_calls,geo348_memo_hits,geo348_memo_first[8];
static uint64_t geo348_memo_request_mismatch[4],geo348_memo_request_examined;
static uint64_t geo348_memo_memcmp_examined,geo348_memo_snapshots_examined;
static int geo348_memo_atexit_status=-2;
static void geo348_memo_emit(void)
{
    fprintf(stderr,"GEO348_MEMO_AGGREGATE {\"schema\":1,\"atexit_status\":%d,\"calls\":%" PRIu64 ",\"hits\":%" PRIu64 ",\"request_examined\":%" PRIu64 ",\"memcmp_examined\":%" PRIu64 ",\"snapshots_examined\":%" PRIu64 ",\"first_failure\":[",geo348_memo_atexit_status,geo348_memo_calls,geo348_memo_hits,geo348_memo_request_examined,geo348_memo_memcmp_examined,geo348_memo_snapshots_examined);
    for(unsigned i=0;i<8;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",geo348_memo_first[i]);
    fputs("],\"request_mismatch\":[",stderr);for(unsigned i=0;i<4;++i)fprintf(stderr,"%s%" PRIu64,i?",":"",geo348_memo_request_mismatch[i]);fputs("]}\n",stderr);
}
'''
OLD='''    if(!memo||!memo->collection||memo->count>q->cap||
       memo->collection_size!=8+memo->count*WOOD_CONTACT_SOURCE_RECORD_SIZE||
       memo->request.placement_id!=q->request.placement_id||
       memo->request.along_v!=q->request.along_v||memo->request.exclude!=q->request.exclude||
       memo->cap!=q->cap||memcmp(&memo->facts,facts,sizeof *facts))return false;'''
NEW='''    ++geo348_memo_calls;
    if(!memo||!memo->collection){++geo348_memo_first[0];return false;}
    if(memo->count>q->cap||memo->collection_size!=8+memo->count*WOOD_CONTACT_SOURCE_RECORD_SIZE){++geo348_memo_first[1];return false;}
    ++geo348_memo_request_examined;
    bool diagnostic_placement=memo->request.placement_id!=q->request.placement_id;
    bool diagnostic_axis=memo->request.along_v!=q->request.along_v;
    bool diagnostic_exclude=memo->request.exclude!=q->request.exclude;
    bool diagnostic_cap=memo->cap!=q->cap;
    geo348_memo_request_mismatch[0]+=diagnostic_placement;
    geo348_memo_request_mismatch[1]+=diagnostic_axis;
    geo348_memo_request_mismatch[2]+=diagnostic_exclude;
    geo348_memo_request_mismatch[3]+=diagnostic_cap;
    if(diagnostic_placement){++geo348_memo_first[2];return false;}
    if(diagnostic_axis){++geo348_memo_first[3];return false;}
    if(diagnostic_exclude){++geo348_memo_first[4];return false;}
    if(diagnostic_cap){++geo348_memo_first[5];return false;}
    ++geo348_memo_memcmp_examined;
    if(memcmp(&memo->facts,facts,sizeof *facts)){++geo348_memo_first[6];return false;}
    ++geo348_memo_snapshots_examined;'''
def instrument(text):
    def once(old,new):
        nonlocal text
        if text.count(old)!=1:raise ValueError(f'expected unique anchor: {old[:90]!r}; got {text.count(old)}')
        text=text.replace(old,new,1)
    once('#include <string.h>','#include <string.h>\n#include <stdio.h>\n#include <inttypes.h>\n'+HELPERS)
    once(OLD,NEW)
    once('''           memo->member_placed[i]!=facts->members[i].member->placed)return false;
    return true;
}''','''           memo->member_placed[i]!=facts->members[i].member->placed){++geo348_memo_first[7];return false;}
    ++geo348_memo_hits;return true;
}''')
    once('    if(!graph||!token||!facts)return NULL;','    if(!graph||!token||!facts)return NULL;\n    if(geo348_memo_atexit_status==-2)geo348_memo_atexit_status=atexit(geo348_memo_emit);')
    return text

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    a=parser.parse_args();raw=a.input.read_bytes();sha=hashlib.sha256(raw).hexdigest()
    if sha!=BASE_SHA256:raise SystemExit(f'input identity mismatch: {sha} != {BASE_SHA256}')
    if a.input.resolve()==a.output.resolve():raise SystemExit('refuse to overwrite input')
    data=instrument(raw.decode()).encode()
    with a.output.open('xb') as stream:stream.write(data)
    print(json.dumps({'input_sha256':sha,'output_sha256':hashlib.sha256(data).hexdigest(),'output_bytes':len(data),'output':str(a.output)}))
if __name__=='__main__':main()
