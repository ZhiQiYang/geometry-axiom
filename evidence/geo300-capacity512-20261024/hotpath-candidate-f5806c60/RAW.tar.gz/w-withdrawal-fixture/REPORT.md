# #348 W indexed-unique-facts 存活：私有唯讀診斷

來源：實跑 `8efcc265c69aecf802854d1d80eba1893df7b8c0`；原結果 `/dev/shm/pr348-kw-test-background/outer.log`：34 methods，1 failure、0 errors/skip；`indexed-unique-facts` mutant returncode 0。此存活是真測試覆蓋缺口，**不是等價突變，不可寫 killed**。原紅保留。

## 根因

原 guard 把任一重複 member ID 判成 `orders.unique=false`，改走原 legacy sort/live-set dedup。此 mutant 將這個 guard 改成永遠不置 false，錯誤使用 indexed 算法。

現有 `indexed-dedup` fixture 中三筆 facts 的 declaration order 為 `[51@1,52@2,filtered51@3]`；最後一筆雖無輸出面，仍提供 ID51 的最後排序 order=3 與最小遮蓋 order=1。正確 legacy 算法先將 ID52 排前，但允許後面的 ID51 以 minimum1 遮掉它，留下 ID51 的兩側。

新增產品的 monotonic fastpath 在 mutant 內也看見原 facts order `[1,2,3]`，直接保留可見面順序 ID51→ID52。錯誤 indexed dedup 此時剛好能把前面的 ID51 插入 prefix 並遮掉 ID52，因而得到相同終態，舊單一場景失去敏感性。沒有證據顯示正確產品改變公開語意。

## 最小追加（未實跑）

`fixture-only.patch` 只在原具名 assertion 之後追加 9 行，原任何 assertion、控制錨點、時限與預期值不變。將相同三筆 facts 排列 `[f0,f2,f1]`，其順序是 `[51@1,filtered51@3,52@2]`。借用 local array 只在同步 public collector 呼叫期間，回來恢復 w.members=f。

- 可見面仍是 ID51、ID52；完整 member/fixity/coordinate/side 欄位相同。
- order index 的 ID51 last3/min1 也不變。
- 唯一新增條件是 `[1,3,2]` 並非單調，因此 mutant 的新快路徑必須保守退回穩定 sort。
- 正確 legacy 預期仍留下 ID51 的兩側，原具名 `indexed-filtered-duplicate-order` 及全部九個 face 欄位逐值確認。
- 錯誤 indexed 預期先處理 ID52，不能讓尚未處理的 ID51 以較小 minimum 反向遮蓋它；接著 ID52 反過來遮掉 ID51，留下 ID52，命中同一既有具名紅。

這些是對實際 C 路徑的靜態推演，**不是新的 exit 收據**。主代理應在乾淨候選來源實跑原整套 W 控制：baseline0→原 indexed-unique-facts mutant正常exit1且命中指定ASSERT→restored0。其他控制仍保持原fixture與先前assertion順序。不得以編譯錯誤、crash或timeout代替kill。

## 完整性

只新增本目錄的 patch、manifest、report；未修改 active、候選 checkout、Git、產品或原測試，未編譯、未跑任何測試。原 source/原紅收據未變。patch/候選檔身分見 MANIFEST.json。
