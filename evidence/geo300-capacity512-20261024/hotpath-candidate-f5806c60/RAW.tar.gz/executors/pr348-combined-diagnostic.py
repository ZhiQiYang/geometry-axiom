"""One fixed N128 feasibility pair plus an explicitly separate instrumented run."""
import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
ROOT=pathlib.Path('/dev/shm/pr348-diagnostic-c754')
OUT=pathlib.Path('/dev/shm/pr348-combined-diagnostic')
OUT.mkdir(exist_ok=False);(OUT/'tmp').mkdir();os.environ['TMPDIR']=str(OUT/'tmp')
os.chdir(ROOT);sys.path.insert(0,str(ROOT));resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
save(OUT/'REQUEST.json',{'source_sha':source,'baseline_sha':'75481194f3b85a6b07e11896403633d7d0fa0d6f','argv':sys.argv,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'One N128 feasibility pair; third run has diagnostic counters and is not a timing verdict','timeout_per_child':600,'stack_bytes':16777216})
from tests.test_geo261_native_kernel import NativeBuild
b=NativeBuild();candidate=b.bridge()
shutil.copy2(candidate,OUT/'candidate-bridge')
baseline=pathlib.Path('/dev/shm/pr348-contact-memo-diagnostic/baseline-bridge');shutil.copy2(baseline,OUT/'baseline-bridge')
input_src=pathlib.Path('/dev/shm/pr348-contact-memo-diagnostic/input.scene')
shutil.copy2(input_src,OUT/'input.scene')
payload=('loadfile '+str(OUT/'input.scene')+'\ndump\nobjects\nreferences\n').encode();(OUT/'stdin.bin').write_bytes(payload)
instrument=pathlib.Path('/dev/shm/pr348-edge-diagnostic/instrument.py')
diag_source=b.kernel/'source-diagnostic.c'
command=['python3','-B',str(instrument),'--input',str(ROOT/'geometry-core/kernel/source.c'),'--output',str(diag_source)]
r=subprocess.run(command,capture_output=True);(OUT/'instrument.stdout').write_bytes(r.stdout);(OUT/'instrument.stderr').write_bytes(r.stderr)
save(OUT/'instrument.json',{'command':command,'exit':r.returncode,'tool_sha256':sha(instrument)})
if r.returncode:raise SystemExit(r.returncode)
shutil.copy2(diag_source,OUT/'source.instrumented.c');obj=b.compile(diag_source,'source-diagnostic')
objects=b.product_objects();assert objects.count(b.source_object)==1
objects=[obj if p==b.source_object else p for p in objects]
wood_tool=pathlib.Path('/dev/shm/pr348-edge-diagnostic/instrument_memo.py')
if wood_tool.exists():
    wood_source=b.woodworking/'contact-sources-diagnostic.c'
    command=['python3','-B',str(wood_tool),'--input',str(ROOT/'geometry-templates/woodworking/native/contact_sources.c'),'--output',str(wood_source)]
    r=subprocess.run(command,capture_output=True);(OUT/'memo-instrument.stdout').write_bytes(r.stdout);(OUT/'memo-instrument.stderr').write_bytes(r.stderr)
    save(OUT/'memo-instrument.json',{'command':command,'exit':r.returncode,'tool_sha256':sha(wood_tool)})
    if r.returncode:raise SystemExit(r.returncode)
    shutil.copy2(wood_source,OUT/'contact-sources.instrumented.c');wo=b.compile(wood_source,'contact-sources-diagnostic')
    assert objects.count(b.wood_contact_sources_object)==1
    objects=[wo if p==b.wood_contact_sources_object else p for p in objects]
diag=b.link('diagnostic-bridge',[b.bridge_object,*objects]);shutil.copy2(diag,OUT/'diagnostic-bridge')
shutil.copy2(b.work/'build-log.json',OUT/'build-log.json')
class Measured(subprocess.Popen):
    usage=None
    def _try_wait(self,flags):
        pid,status,usage=os.wait4(self.pid,flags)
        if pid:self.usage={'maxrss_kib':usage.ru_maxrss,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime}
        return pid,status
rows=[]
for variant in ('baseline','candidate','diagnostic'):
    exe=OUT/(variant+'-bridge');start=time.monotonic()
    with (OUT/(variant+'.stdout')).open('wb') as so,(OUT/(variant+'.stderr')).open('wb') as se:
        p=Measured([str(exe)],stdin=subprocess.PIPE,stdout=so,stderr=se)
        try:p.communicate(payload,timeout=600);timeout=False
        except subprocess.TimeoutExpired:p.kill();p.communicate();timeout=True
    row={'variant':variant,'command':[str(exe)],'execution_source_sha':source if variant!='baseline' else '75481194f3b85a6b07e11896403633d7d0fa0d6f','binary_sha256':sha(exe),'exit':p.returncode,'timeout_triggered':timeout,'seconds':time.monotonic()-start,'usage':p.usage,'stdout_sha256':sha(OUT/(variant+'.stdout')),'stderr_sha256':sha(OUT/(variant+'.stderr'))}
    rows.append(row);save(OUT/(variant+'.json'),row);print(json.dumps(row),flush=True)
stdout_equal=len({row['stdout_sha256'] for row in rows})==1
stderr_equal=(OUT/'baseline.stderr').read_bytes()==(OUT/'candidate.stderr').read_bytes()
diagnostic_lines=(OUT/'diagnostic.stderr').read_bytes().splitlines(keepends=True)
extra=[line for line in diagnostic_lines if line.startswith((b'GEO348_EDGE_AGGREGATE ',b'GEO348_MEMO_AGGREGATE '))]
remaining=b''.join(line for line in diagnostic_lines if line not in extra)
save(OUT/'RESULT.json',{'source_sha':source,'rows':rows,'stdout_equal':stdout_equal,'unmodified_stderr_equal':stderr_equal,'diagnostic_product_stderr_equal':remaining==(OUT/'candidate.stderr').read_bytes(),'diagnostic_lines':[s.decode() for s in extra],'not_formal_acceptance':True})
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True)
raise SystemExit(0 if stdout_equal and stderr_equal and remaining==(OUT/'candidate.stderr').read_bytes() and all(x['exit']==0 and not x['timeout_triggered'] for x in rows) else 1)
