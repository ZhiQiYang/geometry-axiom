import pathlib,subprocess,json,time,os
out=pathlib.Path('/dev/shm/pr348-combined-background');out.mkdir(exist_ok=False)
command=['python3','-B','/dev/shm/pr348-combined-diagnostic.py']
record={'command':command,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid()}
(out/'REQUEST.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'outer.log').open('wb') as log:
 p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);record['child_pid']=p.pid;code=p.wait()
record.update(exit=code,seconds=time.monotonic()-start,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
