# #348 contact-result memo：三個未覆蓋邊界的補充測試草稿

基底產品：`1c4bf857b378e21a373e9ca2a21c9ecb081a22ed`。`contact_sources.c` SHA-256 `394c6e5a173b3e115e5bf2ec859b226c9970d676c8e2705fd8a3b08cfe389d37`。只修改兩個既有測試檔，產品、active、Git 與原草稿皆未動。

原測試已涵蓋 hit deep copy、callback／必要配置失敗、所有 key 變化及成功 FEATURE 輸出變換，但沒有以下三個完整情境，因此新增 3 個正例方法及 1 個遍歷 3 控制的方法。原 6 個方法的 AST 完全未改，原 25 正例與 5 撤回控制仍保留；新增 hook 在預設情況只計數並返回 false。

1. **真 nested callback**：先 warm outer axis=false；第二次 outer 的真 facts callback 呼叫同一 handle 的 inner axis=true，更新單筆 memo；返回後 outer 須重新核對當時 memo。比對 outer 與初始完整 face bytes，以及另個 memo-off handle 的全部 node/value/edge 順序；驗證內層確有執行且與外層結果不同。
   - 負例模擬錯誤的 callback 前 key 決定：先記 request 命中，nested callback 更新 live memo 後仍沿用該 bool，應只由 `result-memo-nested-outer-result-matches-reference` 具名紅。
2. **真 FEATURE provider 失敗與後續重驗**：第二次 query 的 collection 命中後，第一個 FEATURE evaluate 由測試副本 hook 返回 false；檢查外部 output 與 count 不變。第三個新 query 重驗全部 6 個 FEATURE 並恢復完整結果；collector 仍只算一次，callback 執行 3 次，FEATURE 真評估 6+1+6 次。
   - 負例把真 `free(result);return false` 錯改為 success，應由 `result-memo-feature-failure-keeps-output` 具名紅。這是實際 provider 失敗傳播，不是模擬 adapter 回傳。
3. **兩次 memo miss 後 borrowed lifetime**：保留 query1 的 collection 與 FEATURE metadata，再變更 member id 造成 query2 miss，接著再改 id 造成 query3 miss。每次確認舊 owner 活著期間 borrowed bytes 不變、新 collection 為不同自有儲存。
   - 負例在 remember 時錯誤覆寫先前 memo 指向的舊 query buffer；應由 `result-memo-miss-keeps-prior-borrowed-value` 紅。被寫入的 buffer 是仍存活 malloc，測試不靠 UAF／crash 抓錯。

每個控制仍嚴格檢查 `(exit 1, stdout empty, stderr exactly named ASSERT)`；compile failure、crash、timeout 不能算 kill。恢復執行使用同版正常 executable，不改產品來源。

## 交付與狀態

- `supplemental.patch`：可套於原 P 兩個測試檔，完整候選在 `tests/`，原 bytes 在 `original/`。
- `MANIFEST.json`：補丁及兩檔 hash。
- `STATIC_PREFLIGHT.json`：所有 hook 與額外控制 anchor 唯一、原方法 AST 保留。
- **未編譯、未執行**；主代理統一排程。不存在可宣稱的新 runtime 綠燈或已殺 mutants。
- 若採入最終 source，需其餘原 contact source 與產品回歸；本片只封閉三個具體缺口，不替代 full graph／native／512 正式驗收。
