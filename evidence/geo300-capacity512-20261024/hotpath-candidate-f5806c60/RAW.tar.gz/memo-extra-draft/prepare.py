from pathlib import Path
import ast,difflib,hashlib,json
D=Path(__file__).parent

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)

p=(D/'original/test_geo300_contact_result_memo.py').read_text()
p=once(p,'void contact_test_transform_feature(GeoSegment3 *);','void contact_test_transform_feature(GeoSegment3 *);\nbool contact_test_reject_feature(void);')
p=once(p,'(FEATURE_RETURN, "contact_test_transform_feature(&segment);" + FEATURE_RETURN),','(FEATURE_RETURN, "if(contact_test_reject_feature())return false;contact_test_transform_feature(&segment);" + FEATURE_RETURN),')
insert='''
# Separate additional failure modes; the original five controls are unchanged.
EXTRA_CONTROLS = (
    ("nested-premature-match", "nested", "result-memo-nested-outer-result-matches-reference", (
        ("        if(!s->facts(s->user,s->graph,&q->request,facts)||!wood_contact_source_facts_valid(facts)){",
         "        bool premature_match=s->result_memo&&s->result_memo->request.placement_id==q->request.placement_id&&"
         "s->result_memo->request.along_v==q->request.along_v&&s->result_memo->request.exclude==q->request.exclude;\\n"
         "        if(!s->facts(s->user,s->graph,&q->request,facts)||!wood_contact_source_facts_valid(facts)){"),
        ("bool reused=wood_contact_result_matches(s->result_memo,q,facts);",
         "bool reused=premature_match||wood_contact_result_matches(s->result_memo,q,facts);"),
    )),
    ("feature-failure-success", "feature-failure", "result-memo-feature-failure-keeps-output", (
        ("            free(result);return false;", "            free(result);return true;"),
    )),
    ("overwrite-borrowed-on-miss", "borrowed-miss", "result-memo-miss-keeps-prior-borrowed-value", (
        ("    memo->collection=q->collection;memo->collection_size=q->collection_size;",
         "    if(s->result_memo&&memo->collection&&memo->collection_size==q->collection_size)"
         "memcpy((unsigned char *)memo->collection,q->collection,q->collection_size);\\n"
         "    memo->collection=q->collection;memo->collection_size=q->collection_size;"),
    )),
)
'''
p=once(p,'\n\ndef once(source, before, after):',insert+'\n\ndef once(source, before, after):')
newmethods='''
    def test_nested_facts_callback_memo_update_keeps_outer_values_and_ordered_graph(self):
        self.pass_case("nested")

    def test_feature_failure_is_atomic_and_a_later_query_rechecks_every_feature(self):
        self.pass_case("feature-failure")

    def test_two_memo_misses_preserve_prior_borrowed_collection_and_feature_bytes(self):
        self.pass_case("borrowed-miss")

    def test_nested_feature_failure_and_borrowed_miss_controls_fail_distinct_assertions(self):
        for name, case, marker, replacements in EXTRA_CONTROLS:
            with self.subTest(control=name):
                self.pass_case(case, phase="baseline", control=name)
                changed = self.source
                for before, after in replacements:
                    changed = once(changed, before, after)
                exe = self.build_provider(name, changed)
                result = self.run_case(case, exe=exe, phase="mutant", control=name, marker=marker)
                self.assertEqual((1, "", "ASSERT:" + marker + "\\n"),
                                 (result.returncode, result.stdout, result.stderr))
                self.pass_case(case, phase="restored", control=name)
'''
p=once(p,'\n\nif __name__ == "__main__":',newmethods+'\n\nif __name__ == "__main__":')
(D/'tests/test_geo300_contact_result_memo.py').write_text(p)

c=(D/'original/geo300_contact_result_memo_harness.c').read_text()
c=once(c,'static bool transform_features;','static bool transform_features;\nstatic unsigned feature_evaluations,feature_fail_remaining;\nbool contact_test_reject_feature(void)\n{++feature_evaluations;if(feature_fail_remaining){--feature_fail_remaining;return true;}return false;}')
c=once(c,'    bool fail,invalid;','    bool fail,invalid;\n    bool nested,in_nested;\n    unsigned nested_calls;\n    WoodStopFace nested_out[16];\n    size_t nested_count;')
c=once(c,'    memcpy(out,f->facts,sizeof *out);','''    if(f->nested&&!f->in_nested){
        WoodContactSourceRequest inner=*request;inner.along_v=!request->along_v;
        f->in_nested=true;++f->nested_calls;
        bool ok=wood_contact_sources_collect(f->contacts,&inner,f->nested_out,16,&f->nested_count);
        f->in_nested=false;if(!ok)return false;
    }
    memcpy(out,f->facts,sizeof *out);''')
newcases='''
/* Re-enter the actual source handle from its facts callback. The inner query
 * has the opposite axis and replaces the one-entry hint before outer returns.
 * A pre-callback key decision must not be applied to the new hint's bytes. */
static int nested_case(void)
{
    Fixture a,b;CHECK("setup-a",setup(&a)==0);CHECK("setup-b",setup(&b)==0);
    WoodContactSourceRequest r={7,false,NULL};WoodStopFace initial[16],av[16],bv[16];size_t initial_n=0,an=0,bn=0;
    CHECK("result-memo-nested-prime",collect(&a,&r,initial,16,&initial_n)&&initial_n==6);
    a.nested=true;
    CHECK("result-memo-nested-outer-query",collect(&a,&r,av,16,&an));a.nested=false;
    CHECK("result-memo-nested-outer-result-matches-reference",an==initial_n&&!memcmp(initial,av,an*sizeof *av));
    CHECK("result-memo-nested-callback-really-ran",a.nested_calls==1&&a.facts_calls==3&&a.nested_count==6);
    CHECK("result-memo-nested-inner-and-outer-are-distinct",memcmp(a.nested_out,av,an*sizeof *av)!=0);
    CHECK("result-memo-nested-outer-rechecks-current-hint",collector_calls==3);
    contact_test_disable_memo=true;
    CHECK("result-memo-nested-reference-prime",collect(&b,&r,bv,16,&bn));b.nested=true;
    CHECK("result-memo-nested-reference-query",collect(&b,&r,bv,16,&bn));b.nested=false;
    CHECK("result-memo-nested-exact-ordered-graph",equal_graphs(a.graph,b.graph)&&an==bn&&!memcmp(av,bv,an*sizeof *av)&&
        a.nested_count==b.nested_count&&!memcmp(a.nested_out,b.nested_out,a.nested_count*sizeof *a.nested_out));
    dispose(&a,true);dispose(&b,false);return 0;
}
/* Fail the real W FEATURE provider, after a successful pure collection hint.
 * This does not mock the adapter return. New query IDs must evaluate FEATURE
 * again; the failed call remains atomic and cannot become a cached success. */
static int feature_failure_case(void)
{
    Fixture f;CHECK("setup",setup(&f)==0);WoodContactSourceRequest r={7,false,NULL};
    WoodStopFace initial[16],out[16],saved[16];size_t initial_n=0,n=999;
    CHECK("result-memo-feature-failure-prime",collect(&f,&r,initial,16,&initial_n)&&initial_n==6&&feature_evaluations==6);
    memset(out,0x5a,sizeof out);memcpy(saved,out,sizeof saved);feature_fail_remaining=1;
    CHECK("result-memo-feature-failure-keeps-output",!collect(&f,&r,out,16,&n)&&n==999&&!memcmp(out,saved,sizeof out));
    CHECK("result-memo-feature-failure-hit-still-evaluates",feature_evaluations==7&&feature_fail_remaining==0&&collector_calls==1&&f.facts_calls==2);
    CHECK("result-memo-feature-failure-next-query-recovers",collect(&f,&r,out,16,&n)&&n==initial_n&&!memcmp(out,initial,n*sizeof *out));
    CHECK("result-memo-feature-failure-next-query-rechecks-all",feature_evaluations==13&&f.facts_calls==3&&collector_calls==1);
    dispose(&f,true);return 0;
}
/* A hit-only ownership check is insufficient: replace the memo twice and
 * keep borrowed definitions plus one FEATURE metadata pointer from before
 * the first miss alive throughout. No stale pointer is dereferenced after
 * destruction; all owners remain alive until the last comparison. */
static int borrowed_miss_case(void)
{
    Fixture f;CHECK("setup",setup(&f)==0);WoodContactSourceRequest r={7,false,NULL};WoodStopFace out[16];size_t n=0;
    CHECK("result-memo-miss-prime",collect(&f,&r,out,16,&n)&&n==6);
    GeoSourceValue first,second,third,feature;
    CHECK("result-memo-miss-first-value",collection(&f,1,&first));
    WoodContactSourceKey key;
    CHECK("result-memo-miss-borrowed-feature",geo_eval_source(f.graph,
        wood_contact_source_ref(CONTACT_TOKEN,WOOD_CONTACT_SOURCE_FEATURE,1,2,&key),
        GEO_DEPENDENCY_VALUE_REQUIRED,&feature)==GEO_SOURCE_OK&&feature.kind==GEO_SOURCE_FEATURE);
    unsigned char first_bytes[8+16*48],second_bytes[8+16*48],feature_bytes[24];
    size_t first_size=first.as.definition.content_size;memcpy(first_bytes,first.as.definition.content,first_size);
    CHECK("result-memo-miss-feature-size",feature.as.feature.key_size==sizeof feature_bytes);
    memcpy(feature_bytes,feature.as.feature.key,sizeof feature_bytes);GeoSegment3 segment=feature.as.feature.segment;
    f.members[0].id=141;
    CHECK("result-memo-miss-second-query",collect(&f,&r,out,16,&n)&&n==6&&collection(&f,2,&second));
    CHECK("result-memo-miss-keeps-prior-borrowed-value",first.as.definition.content_size==first_size&&
        !memcmp(first_bytes,first.as.definition.content,first_size)&&!memcmp(feature_bytes,feature.as.feature.key,sizeof feature_bytes)&&
        !memcmp(&segment,&feature.as.feature.segment,sizeof segment));
    size_t second_size=second.as.definition.content_size;memcpy(second_bytes,second.as.definition.content,second_size);
    CHECK("result-memo-miss-second-value-owned-and-changed",first.as.definition.content!=second.as.definition.content&&
        first_size==second_size&&memcmp(first_bytes,second_bytes,first_size)!=0&&collector_calls==2);
    f.members[0].id=241;
    CHECK("result-memo-miss-third-query",collect(&f,&r,out,16,&n)&&n==6&&collection(&f,3,&third));
    CHECK("result-memo-miss-keeps-both-prior-values",!memcmp(first_bytes,first.as.definition.content,first_size)&&
        !memcmp(second_bytes,second.as.definition.content,second_size)&&!memcmp(feature_bytes,feature.as.feature.key,sizeof feature_bytes)&&
        third.as.definition.content!=second.as.definition.content&&collector_calls==3);
    dispose(&f,false);return 0;
}
'''
c=once(c,'\nint main(int argc,char **argv)',newcases+'\nint main(int argc,char **argv)')
c=once(c,'    else if(!strcmp(argv[1],"feature"))result=feature_case();','    else if(!strcmp(argv[1],"feature"))result=feature_case();\n    else if(!strcmp(argv[1],"nested"))result=nested_case();\n    else if(!strcmp(argv[1],"feature-failure"))result=feature_failure_case();\n    else if(!strcmp(argv[1],"borrowed-miss"))result=borrowed_miss_case();')
(D/'tests/geo300_contact_result_memo_harness.c').write_text(c)

ast.parse(p)
patch=[]
for name in ('test_geo300_contact_result_memo.py','geo300_contact_result_memo_harness.c'):
 original=(D/'original'/name).read_text();changed=(D/'tests'/name).read_text()
 patch.extend(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='a/tests/'+name,tofile='b/tests/'+name))
(D/'supplemental.patch').write_text(''.join(patch))
files={str(x.relative_to(D)):{'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in [D/'supplemental.patch',D/'tests/test_geo300_contact_result_memo.py',D/'tests/geo300_contact_result_memo_harness.c']}
(D/'MANIFEST.json').write_text(json.dumps({'base_product_sha':'1c4bf857b378e21a373e9ca2a21c9ecb081a22ed','files':files,'runtime':'UNRUN; no compiler or test execution by draft author'},indent=2)+'\n')
print(json.dumps(files,indent=2))
