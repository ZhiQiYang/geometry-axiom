# 獨立靜態複核

複核者：`/root/pr348_w_review_resume/review_extra_memo_tests`。
固定 patch SHA-256：`2524f485db0846a9bf5502f00cafbff4a5087b4acb2491f1ce2097e4151fb368`。

複核回報未發現 baseline 或負例邏輯阻擋：

- nested 真重入同 handle，axis 反轉更新 memo；premature-match mutant 會把內層 e0/e2 collection 當外層 e1/e3，應在指定 outer-result marker 紅。
- FEATURE 真 provider false 應傳播為原子失敗，下一個新 query 預期 6+1+6=13 次 FEATURE 評估；錯誤回 success 的 mutation 命名斷言可達。
- borrowed miss 只覆寫仍活著的舊 malloc buffer，不靠 UAF／crash 作 kill，舊 bytes 命名斷言可達。
- 原 25 正例／5 控制保留；新增 hook 預設只計數，不改傳回值。

此為只讀推理，複核者未編譯、未執行測試。沿用原 harness 對完整 WoodStopFace 的 memcmp 慣例；跨編譯器 padding 可作後續可靠度注意，未作為本次候選特有阻擋。
