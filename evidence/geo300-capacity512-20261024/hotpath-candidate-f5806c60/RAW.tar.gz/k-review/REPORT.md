# #348 K 空槽重用私有草稿：唯讀對抗審查

檢查時間：2026-10-28 UTC。審查者：`/root/pr348_k_review_resume`。
只讀產品／草稿／既有原件，未編譯、未執行產品或突變、未修改 active、Git、門檻或既有測試。唯一新增產物是本報告。

## 結論與來源

目前未找到需要否決此最小 K 草稿的語意錯誤；可進入隔離來源的原 29 項加新 6 項實跑。這是靜態審查意見，不是正式驗收通過，也不能宣告解決完整 H7 的 1200 秒。

- active HEAD：`0cd9739e7701293a42e244dcf2b2f51e71ea7216`；來源產品仍 F2 `b595e55952d5d66de95024432e1b29bec7525e9b`，測試來源 C `75481194f3b85a6b07e11896403633d7d0fa0d6f`。
- 基底 source.c SHA256：`369a714c873428e6befb6ed3f733d6dcce1b1e2938fa476dcf04132f53fcbcd4`。
- 草稿 source.c SHA256：`b00024ec0dff46b27ac4f4a50fe892f54818d110a47e8aad92e4ae723c6a54ea`。
- 草稿 `candidate-with-tests.patch` SHA256：`42520f3f33bcb43ddc5b2980160181217227bff7938375e4dc145b8c98b07f28`。
- 已讀：草稿 README／STATIC_PREFLIGHT／完整 patch；active 原 source.c、source-index Python/C harness、H7/run_all.py；既有 F2 static-pg 與兩次正式結果原件。

## 語意、失敗與索引安全

1. 新空槽來自原 `geo_source_find_node` 在同一張 node_index 的實際探測終點。lookup 到 append 之間只有 provider 陣列唯讀搜尋與 node/key/ordered-array 必要配置，沒有 provider callback、index 寫入或 resize。必要配置失敗會直接返回，不發布節點，也不使用空槽。
2. `geo_source_index_append_at` 先檢查原 `count > UINT32_MAX`，再處理負載／resize。發生 resize 時重建整張表，不用舊 mask 下的 slot；只有不 resize 且 slot < capacity 才直接寫新 ordinal。無索引時 count>capacity/2 必然走建立表，SIZE_MAX 初值不會被使用。
3. packed index 溢位與 calloc 失敗仍丟棄不完整的 optional index、回原線性；沒有新增 CAPACITY 或縮窄權威 size_t。原 ordered nodes/edges、source key 全 byte 相等、provider status 與公開列舉未改。
4. `geo_source_find_node` 的三處 caller 全部改到：node append 傳 slot，sealed describe/source 傳 NULL。原 node_hint 命中路徑未改。empty_slot 僅在真正 miss 時寫回；命中無須輸出。
5. 薄 `geo_source_index_append` wrapper 保留舊 edge 與原 C harness 的介面。O0 下多一次 wrapper call 可能抵銷部分收益，須由實測決定是否採入；不能以碼路徑推導省掉 123 hashes 就宣告端到端加速。

## 舊反證與新測試

- 原 `never-find-node` 找到的仍是實際 lookup 定義；沒有另開旁路繞過它。NODE_PROBE 的停止／假命中仍修改真搜尋，原 full-byte key、uint32 兩守門、edge work anchors 仍唯一。
- 原 packed-node-overflow 反證移除 append guard 後，新的快槽仍在守門後，會保持 index 而由原具名錯誤抓到；未發現必然變成 compile error 的注入。
- **以上只證明原測試仍接線，尚未實跑，不能寫成 29 項或舊 mutants 已 killed。**
- 新 `wrong-ordinal` 在首次插入時不破壞 ordered 陣列；測試清 hint 後回查可導致重複新節點，預期會在 `node-miss-committed-slot-points-to-new-ordinal` 命名失敗。新 `removed` 應增加第二次 hash，預期會命中 `node-miss-one-hash`。仍須真 0/1/0 原件，不採靜態推測代替。
- 新 required-allocation case 明確測 node/key 兩點，沒有單獨強迫 node array 成長失敗；**原 `growth` case 有 node exact-size retry、node-growth-memory、retry 與 edge-memory 控制**，因此採入時必須一起跑原 29 項，不能僅跑新 6 項。
- 新 growth case 覆蓋 16→32 rehash、九 key 再查；原 nodes case 覆蓋 1536 多次擴表、故意碰撞、不同 provider/長度與空 key、sealed；兩者互補。
- 原 fallback case 已涵蓋無表以及已有表擴表配置失敗，恢復後重建；新的小 packed-limit case確定守門先於快槽。沒有刪除／放寬原控制的理由。

## 完整 H7 時間與更大熱點

`tests/run_all.py:530` 對每個 Python suite 固定 1200 秒；不是每 method 1200。H7 第一方法原六批耗時合計 **1516.046849611 秒**（含三個 N64）；只該方法已超過 suite 預算。C 修正 history 方法整體 **966.209439336 秒**（load 468.402912680、動態 history 491.646997819）。所以兩方法固定原樣累加約 2482 秒；小控制與建置另計。不能因每 batch <600 就標完整 native 綠，也不能靠拆 suite 或刪重播來掩蓋。

既有 F2 的 N128 static-pg 原件：`/dev/shm/pr348-static-profile-b595/REPORT.md` 與 `gprof.stdout`。11,980,478 次 index_append、15,848,086 次 source_node、13,274,312 次 find_node；77,181 次 reference_contact_facts、50,382 次 source collect；一般 flat profile 中 append self 0.91秒。另 mcount 共約3.12秒必須分開，不能把 profiler 開銷當可省產品工作。

因此此 K 改法是有根據的小常數修正，並非可證 2.1倍加速。真正支配工作量是每次放置重驗當前世界，contact facts 每個 query 記每個 member 的來源依賴，再產生 feature nodes；隨序列長度累加。已批准 ordered graph/stdout/guards 必須全等，不能跳過 provider call 或刪 dependency。可繼續的具體方向：

- 先讓目前 K/W/contact-result 三份互不競寫草稿各通過舊／新具名控制，再只做一次固定輸入的合併候選 feasibility，並保留原始值；不要逐筆加樣本到看見綠。
- 若仍不足，應量化 **N512 未剖析正式 O0** 中的 node/edge 新增量及保留成本，再選單一資料結構熱點，而非從 N128 pg 百分比線性外推 512收益。已有 pg 原件不必重抽。
- `reference_contact_facts` 的 callback/依賴讀取不能直接 memo-skip。若研究資料準備重用，必須保留每 consumer 的原 geo_eval_depend 呼叫、原 facts callback、失敗順序及 snapshot/current 切換；避免以整塊 mutable member pointer 當不變值。這是後續研究界線，並非本輪新增實作或批准。

本審查沒有發現可以只改三五行就保證滿足1200的根因修法；不假稱有此證據。保持既有 600/1200/35min 與全部原件。
