# PR #348 剩餘熱點：唯讀核對（2026-10-28）

此報告只讀既有原件及 active 原碼；**沒有編譯、測試、重抽樣、產品修改或 Git 操作**。來源以 active C/F2 的實際葉片為準；profiling 原件固定 F2 `b595e55952d5d66de95024432e1b29bec7525e9b`。本報告不能證明任何新候選較快，也不更改 600／1200／35 分鐘時限。

## 判斷

完整 H7 還需要約兩倍改善，不能從新 node 空槽或 W 排序小優化推稱已解決。既有 N128 的主要剩餘量是**每次 world candidate 重建、每個 contact query 對每支已放置角材保留的兩組有序來源依賴**。callback 及有序 graph 不可跳過，collector memo 自然不消除此部分。

同一 `gprof.stdout` 的實際計數：

| 動作 | 次數／self |
|---|---|
| `geo_eval_depend` | 14,089,763 次 |
| `geo_source_edge` | 15,848,086 次 |
| 新 edge 的 `index_append` | 10,701,397 次；self 0.81 秒 |
| 新 node 的 `index_append` | 1,279,081 次；self 0.10 秒 |
| `geo_source_find_edge` | 776,745 次 |
| `geo_source_find_node` | 13,274,312 次；self 0.34 秒 |
| `reference_contact_facts` | 77,181 次；self 0.20 秒 |
| callback 的 placement 依賴 | 5,422,582 次 |
| callback 的 pose 依賴 | 5,422,582 次 |
| `wood_contact_sources_collect` | 50,382 次 |
| 真 contact collector | 50,510 次，其中 50,232 次 indexed dedup |
| `world_validate_derived`／`reference_check_all` | 各 138 次 |

`geo_source_index_append` 的 0.91 秒主要是 edge，不是 node。因此目前 K node miss-slot 候選省的是小分支，應保留作已知小省工，但不值得獨自再跑一輪 512 正式驗收。`contact_member_index_sort` self 0.12 秒；W monotone fast path 也不能單獨支撐兩倍宣稱。

原單筆 collector memo feasibility：原 7.443851066 秒，候選 6.286121455 秒；50,382 query／16,796 hit。僅一個 N128 診斷，不是抽樣 acceptance。其 callback、K node／edge、FEATURE 流程仍全跑，因此只能省 sort/dedup/encode；它並未解決 cubic graph construction 的來源。

## 不應採用的捷徑

- 不因 contact facts 相同直接跳 callback 或兩條依賴：每個 COLLECTION consumer 的 ordered edges 不同。
- 不直接沿用上一 query 的 FEATURE／query ID，不省 `geo_eval_source`／provider，也不將內部未跑當已驗。
- 不把 `reference_check_all` 與 `wood_world_validate_members` 合併跳過：兩者錯誤先後與來源回呼尚未證等價。
- 不拿 static-pg elapsed 10.439 秒當正式 O0 或把 1.14 秒 memset/memmove 全歸某 caller。原報告同一 gmon 的 mcount 約 3.12 秒；libc 缺 caller arcs。
- 不以拆開測試 suite、減少 canonical 次數或增時限來達成 1200。

## 下一個有界且可保留語意的產品方向

### 第一順位：避免替「已知新邊」持續建立不被使用的完整 edge 查找索引

目前 `geo_source_edge` 已憑 source 的最大成功 consumer／kind 證明絕大部分邊是新邊，只有 776,745 次走 `geo_source_find_edge`；仍為 10,701,397 次 append 維護全域 hash index，擴表也重 hash 全部舊邊。這是比 node 空槽更值得處理的確切矛盾。

**可行研究範圍，不是已證可採入實作**：索引仍屬 optional，ordered `GeoSourceEdge[]` 仍權威；只為真正需要向較早 consumer 查重的來源建立索引，或將索引重建延遲至實際需要。任何方案都要保持每筆邊追加、配置失敗返回與原列舉順序。單純全域延遲 catch-up 若每隔幾筆就向後查，可能仍 index 全部、毫無收益；單純每來源鏈表可能退化平方，不能盲目改。

最小下一次鑑別應附在原計畫的一次 N128 候選診斷，**只記 aggregate 整數，不逐次打印**：向後查找按來源 provider 分布、涉及多少不同 source ordinal、距離上次 index catch-up 的追加筆數、實際 duplicate 命中，以及每來源鏈的最大長度。它回答是否能在保持 ordered graph 下移除大部分 index 維護。沒有這幾個計數，不推薦為了看似新方向直接引入一套稀疏索引。

### 第二順位：修正 node hint 的可證碰撞，保留完整 key 比對

當前 hint 僅 `provider ^ key_size ^ key[0] ^ key[last] & 255`。對 little-endian 4-byte MEMBER_POSE id，id 1 與 257 使用相同 first/last；對 5-byte big-endian placement definition，id 1 與 257 同樣只看最後低 byte。512 角材相較 128 會固定衝突，且 contact FEATURE identity 的 17-byte key 中 query id 的中間 bytes 根本不參與 hint。

可在 K 私有 context 用更能覆蓋 opaque key 的小型 set-associative hint；每次仍完整 `geo_source_ref_equal`，miss 回原完整 index，不新增命中語意、不跨 reset。這是相對低風險，但 flat self 所示 node lookup 不足以單獨證兩倍；也不可藉這個理由把 capacity 256 常數直接改成 4096，宣稱新數字足量。

### 第三順位：H 中間 facts／host 大複製，只省真正不可觀察的局部工作

`current_geometry.c:5776` 的 `app_contact_facts_prepare` 每次清整個 `AppContactFacts`，`reference_contact_facts` 先建全份 local facts，再逐 prefix 複製到回呼輸出；`reference_host_read` 每回合又拷貝完整 placement/components。這些確有重複 bytes，但 libc profile 無 caller arcs，不能把全部 1.14 秒指給它。

尤其原失敗路徑保留**未訪問輸出 suffix 不變**，raw snapshot 必須在可能改變 candidate 的 provider 回呼之前拍好；不能改成預先直接填滿 out，也不能移後 snapshot。若調整，只限不再清零永不讀取的 local 尾端，或 caller-specific borrowed view，且要原 raw restore／failure-prefix 負例。不得改 W 已明定每次 callback 的 facts 是 zero-initialized。

## 建議主代理的收斂方式

先收 K/W 已寫草稿的原控制與反證，把它們與 memo 合成**一個**固定私有候選，只做一次原輸入 N128 的有界 feasibility；同次帶上 edge backward-lookup aggregate 計數供下一步決定，保留非 instrumented 產品來源和 raw。若收益遠不足 1200 需要，不提前宣告新的 formal 512 要跑，也不要堆更多無關微優化。真正能跳過大段 index 維護的方案若成立，再做 ordered graph、allocation/fallback、nested lower consumer、reset/seal、超界 ordinal 的完整正反證，才推到新的正式來源。

目前**沒有任何已知靜態推導足以保證兩倍**。不能把這個未知包裝成已修完；既有每批 600 秒通過仍成立，完整 native 時限阻擋保留。
