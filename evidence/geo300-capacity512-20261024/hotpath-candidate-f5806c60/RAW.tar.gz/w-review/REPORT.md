# PR #348 W 單調順序快路徑：獨立靜態對抗審查

日期：2026-10-28 UTC。僅唯讀靜態檢查，未編譯、未執行產品或測試、未修改 active/Git/原草稿。主代理另行安排真實執行，本文件不得冒充其收據。

## 固定來源與結論

- 原產品 F2：`b595e55952d5d66de95024432e1b29bec7525e9b`；active `contact_world.c` SHA-256 `4011443c9d428c055678f3200256dedc5184de3d96d3398c7fe12a0c067626d5`。
- 私有 patch：`/dev/shm/pr348-w-sort-draft/candidate.patch`，SHA-256 `09991233680a7db16d8f5457cd92b2ba38ebfd5b29bf6522082e5329c7af6003`。
- 草稿產品 SHA-256 `098e507656cbdc33db4e8b1be840e97c6145418f5740c7b798f95f89f9e7cf59`；新 C harness 與 Python 測試亦逐檔符合原 MANIFEST。
- 沒有發現阻止進入執行驗證的產品語意缺陷。可以進行原 W、容量及新 7 項測試；尚不能宣告合入或任何效能門檻已通過。
- 發現一項靜態證據標示錯誤，已在本目錄另存正確 `STATIC_PREFLIGHT.json`，原件保留。

## 產品路徑推導

1. 真正 caller 只在 `compact && orders.indexed && orders.unique && first<count` 進入 indexed dedup。每個 member ID 唯一時，`contact_order()` 的 last-ID 語意就是該 fact 自己的完整 `uint64_t order`；不會把 duplicate 的最早／最後順序混為一談。
2. 產生 member faces 是 facts 宣告順序的子序列，各 member 的兩側依 0、1 追加。全部 facts 的 order 非遞減，足以保證通過 placed／exclude／placement／footprint／capacity 篩選後的 suffix 也已非遞減。相等值完全保留宣告及兩側穩定性。
3. 比較為 `world->members[i-1].order > world->members[i].order`，沒有減法、縮窄為 32 位或有號轉型。新 harness 含 UINT64_MAX、2^63、2^32 及低位／有號回繞反例。
4. 快路徑只跳 member sort；不移動 RC／hole prefix，不改 dedup 或 capacity admission。後續 `contact_face_index_build` 重新初始化 sorted/maximum，完成 scratch/rank/plane_end；沒有讀取因跳 sort 而未初始化的 metadata。
5. duplicate IDs、超過 member 索引容量、超過 face buffer 的 legacy fallback 條件完全未改。快路徑沒有新配置或容量，I33 原失敗路徑不受這 8 行影響。
6. filtered facts 仍參與單調性檢查，例如最後一個 unplaced order=0 會保守 miss。這僅少省工作、不改輸出；不得以本草稿推論實際 512 場景已有足夠速度改善。原生 callback 確實保留所有 timber facts；P-189 generator 逐支宣告／放置，應以實際候選執行量測命中率與總時間。

## 舊反證及 workcount 不會因快路徑全被旁路

- `ordering` 第一個 witness 的 facts 順序是 `[30,10,10,20]`，新 guard 為 false，因此 `placement-order`、`stable-ties` 仍會走被突變的原 comparator。
- 舊 workcount client 是 `UINT64_MAX-i` 的逆序；原 order prefetch 撤回與 plane range 撤回仍經原路徑及原命名工作量斷言，沒有改閾值。
- `indexed-sort` 的 cycle `[30,10,20]`、非 2 次冪排列及完整 uint64 逆序仍 fallback。equal-order positive 可以改走新快路徑，但原 unstable-ties 反證在前述 mixed order witness 仍有效。
- `sort-rc-prefix` 突變把 first 改 0 時，out[0] 是 RC 而非 MEMBER_SIDE，因此新 guard 不會提早 return，仍會暴露原錯排；這是具體路徑判斷，不能由 anchor 存在本身推定 kill。
- legacy duplicate 與 overflow guards 原碼未改，原測試仍有明確 numeric witness。
- 新撤回將 `if(ordered)return` 關閉，應在輸出仍相同時由 `contact-order-sorted-no-merge` 捕捉；錯誤無條件 skip 應由 `contact-order-unsorted-byte-oracle` 捕捉。實際 0/1/0 待主代理執行。

## 靜態證據錯誤與更正

原 `static_delivery.py` 對兩個不同 tuple schema 都用了 `control[1]`。在 `test_geo261_contact_sources.py`，該欄是 `contact_world` 或 `contact_sources` 模組名，真 before anchor 是 `[4]`；因此原 MANIFEST 列出的 0→0 或模組名稱 1→1 不能算該檔 mutation anchor 已核實。

本審查依 module 篩選後核對三個真正 `contact_world` 控制：`return left<=right;`、`index->last[slot]=i+1;`、`world->members[i].order<index->minimum[slot]`，原稿與候選皆各 1 次。連同原 W 控制及 5 個 replace_one 片段，共 49 個真正 anchor 均為 1→1；完整 literal 與來源路徑記於 `STATIC_PREFLIGHT.json`。未改原 MANIFEST，不將此更正描述為產品修復或 runtime 通過。

## 必須保留的未驗項

- 所有編譯、原 W／容量／contact source 與新 7 項真實退出碼及具名 0/1/0，均由主代理收件。
- 原 W 的 32/64 位排序、duplicate、larger public buffer、CAPACITY 尾端完整性斷言不能省略；本草稿新 oracle 以逐欄 bytes 比對，不比 padding，符合原公開欄位契約。
- 新 oracle 無單獨 tail sentinel；舊 suite 已有多個 sentinel 測試，應一起跑而非宣稱新 7 項獨自涵蓋所有容量尾端安全。
- 新快路徑的實際命中率及對 512 load/replay/history 的改善未證。單純 64 個有序 facts 比較次數為零，不等於 full H7 的 1200 秒整體預算解除。
- 未做 SSOT、圖順序、完整 native／browser、帳本或架構驗收；此靜態審查不取代那些 gate。
