from pathlib import Path
import datetime,fcntl,hashlib,json,os,shutil,stat,sys,time,traceback
SRC=Path('/tmp/geometry-tests');LOGS=SRC/'run_all-logs';OUT=Path('/dev/shm/pr348-native-cache-preservation-20261029');PLAN=Path('/dev/shm/pr348-final-gate-plan/S796_CACHE_DIRECT_FILES.json')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def h(p):
 z=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):z.update(b)
 return z.hexdigest()
def meta(p):
 s=p.lstat();return dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),type=stat.S_IFMT(s.st_mode),uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,atime_ns=s.st_atime_ns)
def stable(m):return {k:v for k,v in m.items()if k!='atime_ns'}
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def enumerate_scope(expected):
 direct={p.name for p in SRC.iterdir()if p.is_file()and not p.is_symlink()}
 extra=sorted(direct-set(expected));missing=sorted(set(expected)-direct);paths=[SRC/n for n in expected if n in direct];dirs=[];special=[]
 assert LOGS.is_dir()and not LOGS.is_symlink()
 for parent,children,files in os.walk(LOGS,followlinks=False):
  d=Path(parent);dirs.append({'relative':d.relative_to(SRC).as_posix(),'metadata':meta(d)})
  for n in list(children):
   if (d/n).is_symlink():special.append(str(d/n));children.remove(n)
  for n in files:
   p=d/n
   if stat.S_ISREG(p.lstat().st_mode):paths.append(p)
   else:special.append(str(p))
 return paths,dict(direct_count=len(direct),extra_direct_files=extra,missing_expected_direct_files=missing,log_directories=dirs,unexpected_log_nodes=special)
def consumers(keys):
 hits=[];unknown=[];seen=0;selfpid=os.getpid();root=str(SRC)
 def match(pid,field,value):
  if root in value:hits.append({'pid':pid,'field':field,'matched_scope':root})
 for d in Path('/proc').iterdir():
  if not d.name.isdecimal()or int(d.name)==selfpid:continue
  pid=int(d.name);seen+=1
  try:status=(d/'status').read_text();uid=[x for x in status.splitlines()if x.startswith('Uid:')]
  except OSError as e:unknown.append({'pid':pid,'field':'status','error':type(e).__name__});uid=[];status=''
  if any(x.startswith('State:')and '\tZ'in x for x in status.splitlines()):continue
  for n in ['cwd','exe']:
   try:
    match(pid,n,os.readlink(d/n));s=(d/n).stat()
    if (s.st_dev,s.st_ino)in keys:hits.append({'pid':pid,'field':n,'matching_selected_inode':keys[(s.st_dev,s.st_ino)]})
   except OSError as e:unknown.append({'pid':pid,'field':n,'error':type(e).__name__,'uid_record':uid})
  try:match(pid,'cmdline',(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'))
  except OSError as e:unknown.append({'pid':pid,'field':'cmdline','error':type(e).__name__,'uid_record':uid})
  try:fds=list((d/'fd').iterdir())
  except OSError as e:unknown.append({'pid':pid,'field':'fd','error':type(e).__name__,'uid_record':uid});fds=[]
  for f in fds:
   try:
    match(pid,'fd:'+f.name,os.readlink(f));s=f.stat()
    if (s.st_dev,s.st_ino)in keys:hits.append({'pid':pid,'field':'fd:'+f.name,'matching_selected_inode':keys[(s.st_dev,s.st_ino)]})
   except OSError as e:unknown.append({'pid':pid,'field':'fd:'+f.name,'error':type(e).__name__,'uid_record':uid})
  try:
   for line in (d/'maps').read_text().splitlines():
    cols=line.split(None,5)
    if len(cols)>5:match(pid,'maps',cols[5])
    if len(cols)>=5:
     a,b=cols[3].split(':');key=(os.makedev(int(a,16),int(b,16)),int(cols[4]))
     if key in keys:hits.append({'pid':pid,'field':'maps','matching_selected_inode':keys[key]})
  except OSError as e:unknown.append({'pid':pid,'field':'maps','error':type(e).__name__,'uid_record':uid})
 return {'pid_count':seen,'self_excluded':selfpid,'hits':hits,'unreadable_unknown':unknown,'unknown_count':len(unknown),'all_process_visibility_proven':not unknown,'scope':'Accessible cwd/exe/cmdline/fd/maps and selected inode matches. All unreadable fields unknown; no arbitrary process arguments copied.'}
assert not OUT.exists();assert SRC.is_dir()and not SRC.is_symlink();plan=json.loads(PLAN.read_text());expected=sorted(x['name']for x in plan['files']);assert len(expected)==28 and len(set(expected))==28
OUT.mkdir(mode=0o700);shutil.copy2(__file__,OUT/'COLLECTOR.py');shutil.copy2(PLAN,OUT/'ORIGINAL_PLAN.json')
result={'schema':'pr348-native-direct-cache-preservation/1','started_utc':now(),'command':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'environment':{k:os.environ.get(k)for k in ['PATH','LANG','LC_ALL','TMPDIR']},'source_sha_attribution':'unknown; build fingerprints do not establish execution SHA','plan_source_sha':plan['source_sha'],'source':str(SRC),'destination':str(OUT),'source_deletion':False,'source_overwrite':False,'build_or_test_executed':False,'cache_mutants_recursive_scan':False,'copied_files':[],'unknown_files':[],'exit_code':1,'errors':[]};locks=[]
try:
 paths,scope=enumerate_scope(expected);result['scope_before']=scope;before={p.relative_to(SRC).as_posix():meta(p)for p in paths};keys={(m['device'],m['inode']):n for n,m in before.items()};dump(OUT/'SOURCE_METADATA_BEFORE.json',before)
 for n in ['run_all.lock','build.lock']:
  p=SRC/n;s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1 and not p.is_symlink();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW);assert(os.fstat(fd).st_dev,os.fstat(fd).st_ino)==(s.st_dev,s.st_ino);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(fd)
 cb=consumers(keys);dump(OUT/'CONSUMERS_BEFORE.json',cb);result['known_consumer_hits_before']=len(cb['hits']);result['unreadable_proc_fields_before']=cb['unknown_count']
 assert not cb['hits'],'observed cache consumer: preserve original, no copy attempt'
 assert not scope['extra_direct_files']and not scope['missing_expected_direct_files']and not scope['unexpected_log_nodes'],'scope differs: preserve unknown originals'
 logical=sum(x['size']for x in before.values());free=shutil.disk_usage(OUT).free;result['cost']={'selected_logical_bytes':logical,'selected_file_count':len(paths),'selected_page_rounded_bytes':sum((x['size']+4095)//4096*4096 for x in before.values()),'shm_free_before':free,'historical_plan_logical_bytes':plan['direct_file_bytes']+plan['logs_snapshot']['direct_file_bytes']};assert free>=logical+64*1024**2
 target=OUT/'snapshot';target.mkdir()
 for p in paths:
  n=p.relative_to(SRC).as_posix();row={'relative':n,'before_metadata':before[n],'state':'unknown'};dest=target/n;dest.parent.mkdir(parents=True,exist_ok=True)
  try:
   b=meta(p);assert stable(b)==stable(before[n]);sha=h(p);assert stable(meta(p))==stable(b);row['before_sha256']=sha;assert not dest.exists();shutil.copy2(p,dest,follow_symlinks=False);dm=meta(dest);assert stat.S_ISREG(dm['type']);dh=h(dest);after=meta(p);ah=h(p);row.update(after_metadata=after,after_sha256=ah,destination_metadata=dm,destination_sha256=dh)
   assert stable(b)==stable(after)and sha==ah==dh and dm['mode']==b['mode']and dm['size']==b['size']and dm['mtime_ns']==b['mtime_ns']and(dm['device'],dm['inode'])!=(b['device'],b['inode']);row['state']='copy2_verified';result['copied_files'].append(row)
  except BaseException as e:row['error']=repr(e);result['unknown_files'].append(row)
  dump(OUT/'MANIFEST.partial.json',result['copied_files']+result['unknown_files'])
 afterpaths,afterscope=enumerate_scope(expected);result['scope_after']=afterscope;assert {p.relative_to(SRC).as_posix()for p in afterpaths}==set(before),'scope changed during copy'
 ca=consumers(keys);dump(OUT/'CONSUMERS_AFTER.json',ca);result['known_consumer_hits_after']=len(ca['hits']);result['unreadable_proc_fields_after']=ca['unknown_count'];result['all_process_visibility_proven']=cb['all_process_visibility_proven']and ca['all_process_visibility_proven']
 final=[]
 for p in paths:
  n=p.relative_to(SRC).as_posix();m=meta(p);sha=h(p);row=next((x for x in result['copied_files']if x['relative']==n),None);same=row is not None and stable(m)==stable(before[n])and sha==row['before_sha256'];final.append({'relative':n,'metadata':m,'sha256':sha,'same_original':same})
 dump(OUT/'SOURCE_FINAL.json',final);result['all_source_mode_size_sha_stable']=all(x['same_original']for x in final);result['accessible_consumer_hits_empty']=not cb['hits']and not ca['hits'];result['copy2_all_selected_complete']=len(result['copied_files'])==len(paths)and not result['unknown_files']and result['all_source_mode_size_sha_stable']and result['accessible_consumer_hits_empty'];result['exit_code']=0 if result['copy2_all_selected_complete']else 1
 result['cost']['shm_free_after_payload']=shutil.disk_usage(OUT).free
except BaseException:result['errors'].append(traceback.format_exc())
finally:
 for fd in reversed(locks):fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
 result['finished_utc']=now();result['limitations']=['No provenance execution SHA inferred from old cache or sidecars.','Unreadable proc fields remain unknown; empty accessible hits is not all-system visibility.','Copy only; original files/cache/mutants retained. Root must archive and verify remote bytes before next native build.','Source atime may change from reads; mode/size/hash and stable metadata exclude atime explicitly.','Any partial copy remains under fresh OUT and is never overwritten or deleted.'];dump(OUT/'MANIFEST.json',result['copied_files']+result['unknown_files']);dump(OUT/'RESULT.json',result)
print(json.dumps({k:result.get(k)for k in ['exit_code','copy2_all_selected_complete','all_source_mode_size_sha_stable','accessible_consumer_hits_empty','all_process_visibility_proven','known_consumer_hits_before','known_consumer_hits_after','unreadable_proc_fields_before','unreadable_proc_fields_after','cost','errors']},ensure_ascii=False));sys.exit(result['exit_code'])
