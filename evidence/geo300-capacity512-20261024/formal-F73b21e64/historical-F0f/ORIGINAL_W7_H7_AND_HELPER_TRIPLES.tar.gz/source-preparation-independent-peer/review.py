"""Read-only peer of source preparation, never execute the reviewed tool."""
import ast,hashlib,json,subprocess
from pathlib import Path
P=Path('/workspace/geo348-formal-tools-20261024/prepare_source.py')
O=Path(__file__).parent
code=P.read_text();tree=ast.parse(code);checks=[]
def check(label,value):
    checks.append({'check':label,'passed':bool(value)})
    if not value:raise AssertionError(label)
def digest(b):return hashlib.sha256(b).hexdigest()
check('valid Python source',isinstance(tree,ast.Module))
needles={
 'pinned source':'0f695866c0ba12d2c70dfd7d40628d0fda0f905f',
 'fresh root and output':'not ROOT.exists() and not OUT.exists()',
 'original100MiB guard':"free>=100*1024*1024",
 'original capture pin':'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',
 'exact Git commit exists':"['cat-file','-e',S+'^{commit}']",
 'input dir closure':"'geometry-core/kernel','geometry-app/native','geometry-templates/woodworking/native'",
 'quoted include closure':"child=normalize(str(PurePosixPath(n).parent),raw.decode())",
 'unresolved quote disclosure':"unresolved.append(",
 'fresh local shared clone':"['clone','--shared','--no-checkout',str(ORIGIN),str(ROOT)]",
 'sparse original stdin':"'sparse-checkout','set','--no-cone','--stdin'",
 'detached exact source':"['checkout','--detach',S]",
 'head exact':"decode().strip()==S",
 'clean source':"['status','--porcelain=v1','--untracked-files=all']",
 'index exact':"['diff','--cached','--exit-code','--name-status','HEAD']",
 'actual bytes equal Git':"(ROOT/n).read_bytes()==b",
 'fixture original370':"stat().st_size==370",
 'no subject credit':"'compiled':False,'subject_run':False",
 'preserve partial result':"finally:(OUT/'RESULT.json').write_text",
 'source escapes blocked':"need(bool(parts),'quote escapes repository')",
 'Git inherited env removed':"if k.startswith('GIT_'):env.pop(k)",
}
for label,needle in needles.items():check(label,needle in code)
check('no push/rebase/merge/test execution string',not any(x in code for x in ["'push'","'rebase'","'merge'","'run_all.py'","'cc'","'gcc'","'pytest'"]))
seeds=None
for node in ast.walk(tree):
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='seeds' for t in node.targets):seeds=ast.literal_eval(node.value)
check('literal finite seeds',isinstance(seeds,set))
repo='/workspace/geo300-capacity512-work-20261024';s='0f695866c0ba12d2c70dfd7d40628d0fda0f905f';commands=[]
for relative in sorted(seeds):
    argv=['git','show',s+':'+relative]
    result=subprocess.run(argv,cwd=repo,capture_output=True)
    commands.append({'argv':argv,'exit':result.returncode,'stdout_sha256':digest(result.stdout),'stdout_bytes':len(result.stdout),'stderr_hex':result.stderr.hex()})
    check('seed exists in exact F: '+relative,result.returncode==0)
    if relative.endswith('.py'):
        imports=[]
        for node in ast.walk(ast.parse(result.stdout)):
            if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('tests.'):
                imported=node.module.replace('.','/')+'.py';check('Python import closure '+relative+' -> '+imported,imported in seeds)
            elif isinstance(node,ast.ImportFrom) and node.module=='tests':
                for name in node.names:
                    imported='tests/'+name.name+'.py';check('Python from-tests closure '+relative+' -> '+imported,imported in seeds)
check('no tooling/source mutations executed by review',True)
report={'subject':str(P),'subject_sha256':digest(P.read_bytes()),'checks':checks,'passed':len(checks),'failed':0,
 'findings':[],'original_read_commands':commands,'executed_reviewed_tool':False,'compiled_or_product_test_run':False,
 'scope':'Static publisher/closure preparation only. Runtime unresolved includes remain disclosed; actual materialization must still verify bytes/clean state and budget before C.'}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'failed':0,'subject_sha256':report['subject_sha256'],'report_sha256':digest((O/'REVIEW.json').read_bytes())}))
