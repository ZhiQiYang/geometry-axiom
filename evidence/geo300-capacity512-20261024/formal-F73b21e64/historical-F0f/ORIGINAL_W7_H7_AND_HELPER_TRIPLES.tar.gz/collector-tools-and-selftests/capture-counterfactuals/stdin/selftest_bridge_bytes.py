"""Collector-only fake-child comparisons; no compiler or product test runs."""
from __future__ import annotations
import argparse
import importlib.util
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tempfile
import types
import shutil
from observe_bridge_bytes import Observer, sha, write_json
from retain_native_inputs import install as install_native_inputs, ABI_RELATIVE

CHILD = r'''
import json,os,sys,time
mode=MODE
line=sys.stdin.buffer.readline()
if mode=='split':
    payload='{"value":"字"}\n'.encode()
    cut=payload.index('字'.encode())+1
    os.write(1,payload[:cut]);time.sleep(.01);os.write(1,payload[cut:])
elif mode=='crlf':os.write(1,b'{"value":1}\r\n')
elif mode=='ahead':os.write(1,b'{"value":1}\n{"value":2}\n');sys.stdin.buffer.readline()
elif mode=='extra':os.write(1,b'{"value":1}\n'+b'extra-unread\x00\xff'*5000)
elif mode=='stderr':os.write(2,b'original stderr\x00\xff\r\n');os.write(1,b'{"value":1}\n')
elif mode=='nonzero':os.write(2,b'original failure\xff\n');os.write(1,b'{"value":1}\n');sys.exit(7)
elif mode=='eof':sys.exit(0)
elif mode=='invalid_utf8':os.write(1,b'\xff\n')
elif mode=='invalid_json':os.write(1,b'not-json\n')
elif mode=='timeout':
    os.write(1,b'{"value":1}\n')
    while True:time.sleep(1)
else:os.write(1,b'{"value":1}\n')
sys.stdin.buffer.read()
'''


def load_bridge(root):
    sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location('_collector_selftest_original_bridge', root/'tests/_bridge.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compare(mode, base, module, root):
    script = base/(mode+'.py')
    # extra uses small output below pipe capacity to avoid changing stop semantics.
    source = CHILD.replace('MODE', repr(mode)).replace('*5000', '*100')
    if mode == 'brokenpipe': source = 'import sys\nsys.exit(7)\n'
    script.write_text('#!'+sys.executable+'\n'+source)
    script.chmod(0o700)
    results=[]
    for observed in (False, True):
        observer = Observer(base/(mode+'-capture'), 'collector-selftest-not-product', root) if observed else None
        if observer: observer.install_class(module.BridgeSession)
        session = module.BridgeSession(script, stop_timeout=.05)
        text_id, buffer_id = id(session.process.stdout), id(session.process.stdout.buffer)
        result={'values':[], 'exceptions':[]}
        if mode=='brokenpipe':session.process.wait(timeout=5)
        try:
            for request in (['第一', 'second'] if mode=='ahead' else ['第一']):
                result['values'].append(session.command(request))
        except BaseException as exc:
            result['exceptions'].append({'operation':'command','type':type(exc).__name__,'repr':repr(exc)})
        finally:
            try:session.stop()
            except BaseException as exc:
                result['exceptions'].append({'operation':'stop','type':type(exc).__name__,'repr':repr(exc)})
        result['actual_returncode']=session.process.returncode
        result['stream_objects_identical']=text_id==id(session.process.stdout) and buffer_id==id(session.process.stdout.buffer)
        results.append(result)
        if observer:
            receipt=observer.finish();observer.uninstall()
            assert receipt['observer_complete'], receipt
            captured=observer.sessions[0]
            expected_in=b'' if mode=='brokenpipe' else ('第一\n'+('second\n' if mode=='ahead' else '')).encode()
            assert (base/(mode+'-capture/session-000001/stdin.bin')).read_bytes()==expected_in,mode
            expected_out={
                'split':'{"value":"字"}\n'.encode(),'crlf':b'{"value":1}\r\n',
                'ahead':b'{"value":1}\n{"value":2}\n','extra':b'{"value":1}\n'+b'extra-unread\x00\xff'*100,
                'eof':b'','brokenpipe':b'','invalid_utf8':b'\xff\n','invalid_json':b'not-json\n',
            }.get(mode,b'{"value":1}\n')
            assert (base/(mode+'-capture/session-000001/stdout.bin')).read_bytes()==expected_out,mode
            expected_err={'stderr':b'original stderr\x00\xff\r\n','nonzero':b'original failure\xff\n'}.get(mode,b'')
            assert (base/(mode+'-capture/session-000001/stderr.bin')).read_bytes()==expected_err,mode
            assert captured['actual_returncode']==result['actual_returncode']
            if mode=='timeout':
                assert result['actual_returncode']==-9
                assert len(captured['kill_events'])==1
                assert [r['kwargs'] for r in captured['wait_events']]==[{'timeout':.05},{}]
                assert captured['wait_events'][0]['exception']['type']=='TimeoutExpired'
    assert results[0]==results[1], {'mode':mode,'original':results[0],'observed':results[1]}
    return {'mode':mode,'equal_original_semantics':True,'raw_bytes_exact':True,'outcome':results[1]}


def run_observer_cases(base,root):
    observer=Observer(base/'run-capture','collector-selftest-not-product',root)
    observer.install_run()
    cases=[]
    body=b'\x00\xff\r\nutf8 '+ '字'.encode()
    argv=[sys.executable,'-B','-c','import sys;sys.stdout.buffer.write(sys.stdin.buffer.read());sys.stderr.buffer.write(b"err\\xff")']
    result=subprocess.run(argv,input=body,capture_output=True,timeout=5)
    assert result.returncode==0 and result.stdout==body and result.stderr==b'err\xff'
    first=observer.commands[0]
    assert (observer.out/'command-000001/input.bin').read_bytes()==body
    assert first['input']['representation']=='original-bytes'
    cases.append({'case':'binary-input-output-stderr','exact':True})
    try:subprocess.run([sys.executable,'-B','-c','import sys;sys.stdout.buffer.write(b"raw\\xff");sys.exit(9)'],capture_output=True,check=True)
    except subprocess.CalledProcessError as exc:
        assert exc.returncode==9 and exc.stdout==b'raw\xff'
    else:raise AssertionError('missing original CalledProcessError')
    cases.append({'case':'check-true-original-nonzero','returncode':9})
    try:subprocess.run([sys.executable,'-B','-u','-c','import time;print("partial",flush=True);time.sleep(10)'],capture_output=True,timeout=.05)
    except subprocess.TimeoutExpired as exc:assert exc.stdout==b'partial\n'
    else:raise AssertionError('missing original TimeoutExpired')
    cases.append({'case':'timeout-original-partial-bytes','timeout':.05})
    old_tmp=os.environ.get('TMPDIR')
    try:
        os.environ['TMPDIR']=str(base)
        script=base/'lf.py'
        direct=subprocess.run([str(script)],input=b'first\n',capture_output=True,timeout=5)
        assert direct.returncode==0
        binary=observer.commands[-1]['executable']
        assert binary['retained'] and binary['sha256']==sha(script.read_bytes()) and binary['bytes']==script.stat().st_size
    finally:
        if old_tmp is None:os.environ.pop('TMPDIR',None)
        else:os.environ['TMPDIR']=old_tmp
    cases.append({'case':'exact-private-executable-at-run','retained':True})
    receipt=observer.finish();observer.uninstall()
    assert receipt['observer_complete'],receipt
    return cases


def exact_identity_cases(base,root):
    original=subprocess.run
    argv=['original-argv-object'];input_body=b'input\x00\xff';env={'LANG':'C'}
    result=subprocess.CompletedProcess(argv,23,b'out\xff',b'err\x00')
    failure=subprocess.TimeoutExpired(argv,17,output=b'partial\xff')
    mode=['return'];calls=[]
    def standin(*args,**kwargs):
        calls.append((args,kwargs))
        assert args[0] is argv and kwargs['input'] is input_body and kwargs['env'] is env
        assert kwargs['timeout']==17
        if mode[0]=='raise':raise failure
        return result
    subprocess.run=standin
    observer=Observer(base/'identity-capture','collector-selftest-not-product',root)
    try:
        observer.install_run()
        assert subprocess.run(argv,input=input_body,env=env,timeout=17) is result
        mode[0]='raise'
        try:subprocess.run(argv,input=input_body,env=env,timeout=17)
        except subprocess.TimeoutExpired as caught:assert caught is failure
        else:raise AssertionError('original exception not propagated')
        assert len(calls)==2
        assert observer.finish()['observer_complete']
    finally:
        observer.uninstall();subprocess.run=original
    return {'case':'CompletedProcess-and-exception-identity','original_calls':2,'passed':True}


def partial_raw_cases(base,root):
    # Minimal fake raw endpoints test the exact closures installed by attach,
    # including None, partial I/O and the identity of an already-raised error.
    class Raw:
        def __init__(self):self.closed=False;self.writes=0;self.reads=0
        def write(self,data):
            self.writes+=1
            if self.writes==1:return 2
            if self.writes==2:return None
            raise sentinel
        def readinto(self,buffer):
            self.reads+=1
            if self.reads==1:buffer[:3]=b'abc';return 3
            if self.reads==2:return None
            if self.reads==3:return 0
            raise sentinel
        def read(self,*args):return b''
        def readall(self):return b''
        def close(self):self.closed=True
    sentinel=BrokenPipeError('original sentinel')
    raw_in,raw_out=Raw(),Raw()
    binary=base/'fake-binary-description';binary.write_bytes(b'not an executable, never run')
    err=tempfile.TemporaryFile('w+b')
    process=types.SimpleNamespace(args=['never-run'],pid=-1,returncode=0,
        stdin=types.SimpleNamespace(buffer=types.SimpleNamespace(raw=raw_in)),
        stdout=types.SimpleNamespace(buffer=types.SimpleNamespace(raw=raw_out)),
        wait=lambda *a,**k:0,kill=lambda *a,**k:None)
    session=types.SimpleNamespace(process=process,stderr=err,bridge=binary,stop_timeout=10)
    observer=Observer(base/'partial-raw-capture','collector-selftest-not-product',root)
    observer.attach(session,{})
    assert raw_in.write(b'abcdef')==2
    assert raw_in.write(b'never-accepted') is None
    try:raw_in.write(b'never-accepted')
    except BrokenPipeError as caught:assert caught is sentinel
    else:raise AssertionError('missing original partial-write exception')
    buf=bytearray(9)
    assert raw_out.readinto(buf)==3 and buf[:3]==b'abc'
    assert raw_out.readinto(buf) is None
    assert raw_out.readinto(buf)==0
    try:raw_out.readinto(buf)
    except BrokenPipeError as caught:assert caught is sentinel
    else:raise AssertionError('missing original read exception')
    err.close();report=observer.finish();observer.uninstall()
    assert report['observer_complete']
    assert (observer.out/'session-000001/stdin.bin').read_bytes()==b'ab'
    assert (observer.out/'session-000001/stdout.bin').read_bytes()==b'abc'
    assert raw_in.writes==3 and raw_out.reads==4
    return {'case':'partial-None-exception-raw-contract','write_calls':3,'read_calls':4,'passed':True}


def compiler_event_cases(base,root):
    temporary=base/'private-tmp';temporary.mkdir()
    build=temporary/'geo261-n1a-synthetic';build.mkdir()
    closure=build/'capacity-host-abi-closure';closure.mkdir()
    source=closure/'tests/harness.c';source.parent.mkdir();source.write_bytes(b'/* synthetic C bytes, no compiler */\n')
    for relative in ABI_RELATIVE:
        target=closure/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'original '+relative.encode()+b'\n')
    observer=Observer(base/'compiler-event-capture','collector-selftest-not-product',root)
    captured=install_native_inputs(observer,temporary)
    original=(closure/'current_geometry.c').read_bytes()
    for phase in ('fixed','withdrawn','restored'):
        data=b'synthetic withdrawn\n' if phase=='withdrawn' else original
        (closure/'current_geometry.c').write_bytes(data)
        # Explicit synthetic audit event; never invokes a compiler or Popen.
        sys.audit('subprocess.Popen','never-run',['never-run','-c',str(source),'-o','never.o'],str(build),None)
        row=captured['compiler_snapshots'][-1]
        found=next(r for r in row['inputs'] if r['original']==str(closure/'current_geometry.c'))
        assert Path(found['retained']).read_bytes()==data
    assert len(captured['compiler_snapshots'])==3
    (build/'build-log.json').write_text(json.dumps([{'arguments':[str(source)],'exit':0,'stdout':'synthetic','stderr':''}]))
    shutil.rmtree(build)
    assert len(captured['cleanup_snapshots'])==1
    assert observer.finish()['observer_complete'];observer.uninstall()
    return {'case':'synthetic-precompile-header-and-before-cleanup-retention','compiler_executed':False,'snapshots':3,'passed':True}


def import_hook_cases(base,root):
    observer=Observer(base/'import-hook-capture','collector-selftest-not-product',root)
    original_popen=subprocess.Popen
    observer.install_imports()
    try:
        for name in ('tests._bridge','_bridge'):
            module=importlib.import_module(name)
            assert Path(module.__file__).resolve()==root/'tests/_bridge.py'
            with module.BridgeSession(base/'lf.py') as session:assert session.command('第一')=={'value':1}
        assert len(observer.sessions)==2 and subprocess.Popen is original_popen
        assert observer.finish()['observer_complete']
    finally:observer.uninstall()
    return {'case':'both-original-bridge-module-names','sessions':2,'global-Popen-unchanged':True,'passed':True}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=False)
    module=load_bridge(args.root.resolve())
    modes=['lf','crlf','split','ahead','extra','stderr','nonzero','eof','invalid_utf8','invalid_json','brokenpipe','timeout']
    rows=[]
    for mode in modes:
        rows.append(compare(mode,args.out,module,args.root.resolve()))
        print('PASS fake-child '+mode,flush=True)
    runs=run_observer_cases(args.out,args.root.resolve())
    units=[exact_identity_cases(args.out,args.root.resolve()),partial_raw_cases(args.out,args.root.resolve()),compiler_event_cases(args.out,args.root.resolve()),import_hook_cases(args.out,args.root.resolve())]
    report={'scope':'collector-only; no C compiler, no product suite, no gate credit',
            'original_bridge_sha256':sha((args.root/'tests/_bridge.py').read_bytes()),
            'observer_sha256':sha(Path(__file__).with_name('observe_bridge_bytes.py').read_bytes()),
            'bridge_cases':rows,'run_cases':runs,'unit_cases':units,'passed':True}
    write_json(args.out/'SELFTEST.json',report)
    print(json.dumps({'bridge_cases':len(rows),'run_cases':len(runs),'unit_cases':len(units),'passed':True}),flush=True)


if __name__=='__main__':main()
