# H7 原始管線收集器（外部工具）

本目錄只含收集器與自驗，沒有改產品、測試、門檻或正式 runner。它尚須交叉審查後才可啟正式 H7/W7。

`observe_bridge_bytes.py` 只在真正 `tests._bridge`／`_bridge` 載入後包裝其 BridgeSession。Popen、TextIOWrapper、BufferedReader、BufferedWriter 及其 raw 物件都保留；原 raw.readinto/read/readall/write 每次恰呼叫一次，原值與例外不改。寫入只記錄原作業確實接受的前 n bytes；None／部分寫入／BrokenPipe 不補送。原 UTF-8 decoder 之前的 stdout、實際送出的 stdin 逐 bytes 留存，不把 JSON 重新 dumps。

stdout 非阻塞 drain 只發生在原 caller 已呼叫 stdout.close、其原 raw.close 即將執行時，而且原 process.returncode 已是整數。此時 caller 已放棄再讀；不額外 poll／wait／kill，不延長逾時。若未見 EOF 或仍 EAGAIN 就明列 incomplete。stderr 在原 caller 關閉 TemporaryFile 之前、原 child 已終態時以 pread 保原 bytes，不移動原 file offset。原 stop_timeout、wait、kill、傳回值、例外保持，真 child status 不由 Python AssertionError 推測。

`subprocess.run` 仍接收原參數物件，回傳原 CompletedProcess 同一物件、重拋原例外同一物件；另存 binary input.bin，原 binary stdout／stderr 原樣留存；private TMPDIR／source 中的實際 executable 在原 run 前記錄 byte count 與 hash（不複製 ELF payload）。**原 text=True 的 compiler／其他 run 輸出是呼叫者既有 decoded text，再 UTF-8 保存，明列 original-decoded-text-encoded-utf8；不能稱其為 pre-decode OS bytes。** 它包含 NativeBuild 本來觀察到的完整 compiler diagnostics，這項限制不套用 BridgeSession 的原 pipe bytes 或 run_once(text=False)。沒有全域取代 Popen 或改 compiler。

`retain_native_inputs.py` 以原 subprocess.Popen audit event（launch 前）保存當時 C input。H ABI closure 每次保存當時的 current_geometry.c、members.h、document.h、contact_world.h、cut_list.h、member_reference.h 與原 harness；W 私有 members.h 同時保留。相同內容用 SHA256 blob 共用，不刪任何原 input。原 NativeBuild `shutil.rmtree` audit event 前保 build-log 與當時 C sources；不呼叫額外 cleanup、不保留可重建 ELF payload 冒成必要原流。七個 ABI compiler 非零仍各依原具名 diagnostic 裁判，不能概稱所有 compiler 0。

## 呼叫契約

```text
python3 -B run_observed_original.py --root PRIVATE_ROOT --sha F --out NEW_OUT --manifest PHASE_MANIFEST -- tests/_unittest_runner.py ORIGINAL_ARGUMENTS
python3 -B run_observed_original.py --root PRIVATE_ROOT --sha F --out NEW_OUT --manifest PHASE_MANIFEST -- -m unittest -v ORIGINAL_TEST_METHOD
```

cwd 必為 PRIVATE_ROOT；TMPDIR 必是已建立的私有目錄。manifest 是 `{"source_sha":"完整 F","source_variant":"fixed|withdrawn|restored","files":{"repo/path":"sha256"}}`，至少涵蓋兩個 capacity suite、tests/_bridge.py、tests/binaries.py、tests/test_geo261_native_kernel.py 及原入口。所有列檔必符當時 bytes；fixed/restored 逐 bytes 等 F，withdrawn 僅允許明列的 host 測試檔不同。工具不產生或還原變體。manifest 本身、Git HEAD/status 原輸出與檔案前後 hashes 保留；withdrawn 不冒乾淨 F。

finalizer 在原 suite import 前註冊，所以 NativeBuild 原 atexit 清理先執行，之後才寫 ORIGINAL_ENTRY.json、OBSERVATION.json。**外層 launcher 必核兩檔存在、兩者 observer_complete=true、source_sha/variant 正確，並另留真正 child OS exit；缺檔或 observation false 是收據環境紅。** atexit 不改原程序退出碼，因此 child OS exit0 單獨不等於完整驗收。原 failure/skip 的判定仍由原 runner JSON、原 stderr 和原 OS exit 決定。

## 自驗範圍

`selftest_bridge_bytes.py` 用假 Python children 比較原介面與觀察介面：12 種 LF/CRLF、UTF-8 分段、預讀、未讀尾端、stderr、非零退出、EOF、非法 UTF-8／JSON、BrokenPipe、原 timeout；另驗 binary input、CalledProcessError、TimeoutExpired、CompletedProcess／例外 identity、partial/None raw I/O、兩個 import 名稱、synthetic compiler audit 與原 cleanup audit。synthetic audit 沒有呼叫 compiler。

`selftest_original_entry.py` 只在新建的 synthetic Git fixture 驗原入口包裝，包含真正 _unittest_runner.py 對合成 Python case 的原 exit1、單方法 exit0／exit1，與 atexit 原 cleanup 先於收據。fixture 的容量檔是明示 synthetic placeholder，沒有以此宣稱 F 的 H7／W7 或任何產品 gate 已跑。

完整 selftest 各次 stdout/stderr、命令、真 exit 留在 `*-launch/`；所有歷史保留。最後固定 pins 與結果列於 TOOL_PINS.json。
