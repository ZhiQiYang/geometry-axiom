from pathlib import Path
import ast,json,hashlib
B=Path('/workspace/geo300-capacity512-h-pipe-capture-20261024');P=json.loads((B/'TOOL_PINS.json').read_text());C=[]
def ck(n,b):C.append({'name':n,'pass':bool(b)})
def sha(b):return hashlib.sha256(b).hexdigest()
ck('fixed final pins',sha((B/'TOOL_PINS.json').read_bytes())=='0d7cdc2ef7bcce382f5a02bc38effcec695326358d40c2f2c156be09b702c033')
for name,p in P['tools'].items():
 body=(B/name).read_bytes();ck('toolpin '+name,len(body)==p['bytes'] and sha(body)==p['sha256'])
 if name.endswith('.py'):ast.parse(body);ck('AST '+name,True)
S=json.loads((B/'selftest-r5/SELFTEST.json').read_text());E=json.loads((B/'entry-selftest-r4/SELFTEST.json').read_text())
ck('selftest20 onlyfake',S['passed'] and len(S['bridge_cases'])==12 and len(S['run_cases'])==4 and len(S['unit_cases'])==4)
for x in S['bridge_cases']:ck('original semantics+bytes '+x['mode'],x['equal_original_semantics'] and x['raw_bytes_exact'] and x['outcome']['stream_objects_identical'])
ck('toolpin actual selftest',S['observer_sha256']==P['tools']['observe_bridge_bytes.py']['sha256'])
for label in ['selftest-r5','entry-selftest-r4']:
 l=B/(label+'-launch');r=json.loads((l/'RESULT.json').read_text());ck(label+' outer0',r['actual_exit']==0)
 ck(label+' stdout exists',bool((l/'stdout.bin').read_bytes()));ck(label+' stderr empty',(l/'stderr.bin').read_bytes()==b'')
ck('entry four exits',[x['actual_exit'] for x in E['cases']]==[1,0,1,2])
for name in ['path','module-pass','module-fail','path-exit2']:
 # Names are taken from actual fixed selftest output directories.
 pass
entries=sorted((B/'entry-selftest-r4').glob('*-observation/ORIGINAL_ENTRY.json'))
ck('entry4 complete original',[json.loads(x.read_text())['original_exit'] for x in entries].count(2)==1 and len(entries)==4)
for p in entries:
 r=json.loads(p.read_text());ck('entrycomplete '+p.parent.name,r['observer_complete'] and r['source_files_before']==r['source_files_after'])
 o=json.loads((p.parent/'OBSERVATION.json').read_text());ck('observation complete '+p.parent.name,o['observer_complete'] and not o['observation_errors'] and not o['incomplete_sessions'])
# Recheck every fake child observed stream against retained receipt pins, no re-execution.
for p in (B/'selftest-r5').glob('*-capture/session-*/receipt.json'):
 r=json.loads(p.read_text());ck('sessioncomplete '+str(p.relative_to(B)),r['complete'] and isinstance(r['actual_returncode'],int))
 for n,x in r['streams'].items():
  body=Path(x['path']).read_bytes();ck('sessionbytes '+str(p.relative_to(B))+n,len(body)==x['bytes'] and sha(body)==x['sha256'])
s=(B/'observe_bridge_bytes.py').read_text();e=(B/'run_observed_original.py').read_text();a=(B/'retain_native_inputs.py').read_text()
for name,needle in [('raw accepted prefix',"memoryview(data)[:result]"),('raw original read count',"result = original_readinto(buffer)"),('EOF required',"row['stdout_eof'] and row['stderr_retained']"),('drain only original terminal',"if type(process.returncode) is not int:"),('nonblocking no wait',"os.set_blocking(fd, False)"),('stderr offset preserved',"os.pread(fd, min(65536, size - offset), offset)"),('original subprocess returned',"result = original(*args, **kwargs)\n                return result"),('compiler text honest',"original-decoded-text-encoded-utf8"),('private binary before run',"run-original-executable-hash")]:ck(name,needle in s)
ck('no global Popen replacement','self.patch(subprocess, \'Popen\'' not in s and 'subprocess.Popen =' not in s)
ck('all original integer exit2 preserved',"exc.code if isinstance(exc.code,int) else 1" in e)
ck('original raised exception retained','        raise\n    finally:' in e)
ck('finalizer before imports',e.index('atexit.register(finalize)')<e.index('observer.install_imports()'))
ck('only host withdrawn',"relative!='tests/test_geo261_timber_capacity_host.py'" in e)
ck('phase source beforeafter exact',"if after!=before" in e)
ck('compiler prelaunch event',"event=='subprocess.Popen'" in a)
ck('cleanup before rmtree',"event=='shutil.rmtree'" in a)
ck('six ABIheaders snapshot',len(ast.literal_eval(next(x.value for x in ast.parse(a).body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ABI_RELATIVE' for t in x.targets))))==6)
report={'tool_pins_sha256':sha((B/'TOOL_PINS.json').read_bytes()),'checks_total':len(C),'failed_checks':sum(not x['pass'] for x in C),'checks':C,'findings':[],'manual_review':['Popen/TextIOWrapper/BufferedReader/raw identities unchanged; no detach/retry/reencode JSON; raw calls once with original return/exception','postterminal drain only at original raw.close; no new wait/poll/kill, EAGAIN marks incomplete; stderr pread does not move original offset','original wait/kill args and exceptions retained; selftest timeout preserves -9 and exact original wait sequence','subprocess.run result/exception identity and original timeout unchanged; run_once binary input/output preserved, text compiler limitation explicit','beforecompile ABI six closure files +actualC snapshots and W adjacent members snapshot; audit failures are separate observer errors','original NativeBuild cleanup runs before observer finalizer; launcher must reject missing/false complete independently of true OS exit','observer adds I/O overhead and is for correctness receipts, not performance timing; no change to original product assertion or timeout'], 'limits':['Independent static and original synthetic selftest raw review only; no product C/H7/W7 was executed by this peer','Fixed/restored private checkout must be clean by launcher; manifest includes exact closure; only host test may be intentionally dirty for withdrawals','Manifest per-file Git output stores full source bytes as hex and increases disk budget; launcher must account rather than assume tiny overhead','Synthetic exit2 is wrapper propagation check, not real product import-error acceptance']}
q=Path(__file__).with_name('REVIEW.json');q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['checks_total'],report['failed_checks']);raise SystemExit(bool(report['failed_checks']))
