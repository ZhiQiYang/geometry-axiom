"""Static review of original capacity suites and exact helper control wrapper."""
from pathlib import Path
import ast,hashlib,json
H=Path('/workspace/geo348-formal-tools-20261024')
OUT=Path(__file__).resolve().parent
driver=H/'run_formal.py';launch=H/'launch_formal.py'
D='0ee0496ec3b71927d9665dae55a42e6a22a6de194730cb8d73e524899fbfc4cc'
L='9a5c4bbc9628b6a4a11579359a0e07d999127c5cd8f61e6afe98372e31400ba2'
W='48bf7a7cacc8f3de143a1903210b14ad43aa17d8bf69edcda71e6e94419613cc'
checks=[]
def check(name,value):
    checks.append({'check':name,'passed':bool(value)})
    if not value:raise AssertionError(name)
def sha(raw):return hashlib.sha256(raw).hexdigest()
s=driver.read_text();t=launch.read_text()
check('frozen final driver',sha(s.encode())==D)
check('frozen final launcher',sha(t.encode())==L)
check('both parse without importing subject',bool(ast.parse(s).body) and bool(ast.parse(t).body))
withdraw=Path('/workspace/geo300-capacity512-publication-20261024/host-v5-draft/EXACT_WITHDRAWALS.json')
check('exact reviewed v5 withdrawal bytes',sha(withdraw.read_bytes())==W)
w=json.loads(withdraw.read_text())
check('only three independent original helper controls',set(w)=={'count','population','unplaced_replay'})
host=Path('/workspace/geo300-capacity512-publication-20261024/host-v5-draft/candidate/tests/test_geo261_timber_capacity_host.py').read_text()
for name,part in w.items():
    check('unique accepted helper anchor '+name,host.count(part['after'])==1)
    changed=host.replace(part['after'],part['before'])
    check('one complete exact withdrawal with clean restoration '+name,changed!=host and changed.count(part['before'])==1 and changed.replace(part['before'],part['after'])==host)
for name,text in [
 ('fixed F source',"S='0f695866c0ba12d2c70dfd7d40628d0fda0f905f'"),
 ('preparation actual real head',"prep['exit_code']==0 and prep['source_sha']==S and prep['real_execution_head']==S"),
 ('100MiB unchanged resource guard','MIN_FREE=100*1024*1024'),
 ('nonblocking secondary lock',"lock=Path('/tmp/g261r3/secondary.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)"),
 ('private tmp',"TMP=Path('/workspace/geo348-F0f695866-formal-tmp')"),
 ('no aggregate or ledger falseclaim',"'full_native':False,'ledger_regenerated':False,'performance':False"),
 ('same execution Git SHA',"git('rev-parse','HEAD').decode().strip()==S"),
 ('only host leaf may be dirty',"wanted=b'' if variant!='withdrawn' else (' M '+HOST+'\\n').encode()"),
 ('no staged mutation',"git('diff','--cached','--name-only')==b''"),
 ('full phase source fingerprints',"for name,pin in prep['entries'].items():need(sha((ROOT/name).read_bytes())==(sha(expected) if name==HOST else pin['sha256'])"),
 ('both unchanged W7/H7 before mutations',"for label,target in [('W7','tests/test_geo261_timber_capacity.py'),('H7',HOST)]:"),
 ('suite original strict runner7',"['tests/_unittest_runner.py',target,'--json-out','{OUT}/runner.json','--log','{OUT}/unittest.log'],7)"),
 ('exact count total run pass',"detail['total']==detail['run']==detail['passed']==count"),
 ('no skipped failures blocked or expected failures',"['failed','skipped','extra_errors','blocked_by_error','expected_failed']"),
 ('import error rejects',"detail['import_error'] is None"),
 ('two observation completeness fields',"observed['observer_complete'] is True and terminal['observer_complete'] is True"),
 ('observer exit tied actual OS exit',"terminal['original_exit']==row['actual_process_returncode']"),
 ('source same before after including variant',"terminal['source_variant']==variant and terminal['source_files_before']==terminal['source_files_after']==files"),
 ('unmodified original entry has no new outer timeout','check=False,timeout=None'),
 ('normal helper failure exit1 not crash',"row['actual_process_returncode']==1 and normal and 'FAILED (failures=1)' in text"),
 ('helper failure is assertion not error',"'AssertionError:' in text and 'ERROR:' not in text and 'skipped=' not in text"),
 ('normal positive exit0',"row['actual_process_returncode']==0 and normal and bool(re.search(r'^OK$',text,re.M))"),
 ('population and replay real I9 stream',"sessions=list((where/'observed').glob('session-*/stdout.bin'));found=any(b'I9' in p.read_bytes() for p in sessions)"),
 ('each original before mutating',"phase(control+'-fixed','fixed',original,entry)"),
 ('only original exact before change',"need((ROOT/HOST).read_bytes()==original,'original before helper withdrawal');(ROOT/HOST).write_bytes(changed)"),
 ('finally restores only expected dirty bytes',"finally:\n    need((ROOT/HOST).read_bytes()==changed,'do not overwrite unexpected helper drift');(ROOT/HOST).write_bytes(original)"),
 ('each restored actually reruns',"phase(control+'-restored','restored',original,entry)"),
 ('all11 actual phases required',"len(report['phases'])==11 and all(x['passed'] for x in report['phases'])"),
 ('exact withdrawal artifact pinned',W),
 ('launcher pins current driver',D),
 ('launcher pins original reaper',"7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760"),
 ('launcher verifies real reaper integer primary exit',"if type(primary) is not int:raise RuntimeError('integer original primary exit required')"),
 ('launcher verifies signal mapping',"mapped=primary if primary>=0 else 128-primary"),
 ('launcher requires unique terminal event',"if len(ends)!=1:raise RuntimeError('unique completed reaper event required')")]:
    check(name,text in (t if name.startswith('launcher') else s))
# Static new wrappers neither edit original limits nor substitute a test/golden.
check('driver has no write to subject other than exact host helper variants',s.count('(ROOT/HOST).write_bytes(')==2)
check('no user performance threshold introduced',all(term not in s for term in ['fix/main','1.3','4.5']))
result={'driver_sha256':D,'launcher_sha256':L,'checks_passed':len(checks),'findings':[],
 'scope':'Static wrapper/control-source review only; no C, generator, observer import, source mutation or runtime execution',
 'timelimits':'Original subject case/compile limits retained; original suite wrapper has no added total timeout.',
 'resolved_note':'Exact already-reviewed v5 withdrawal JSON now pinned before all phases; content unchanged.',
 'unrun':['W7/H7 actual runtime','nine helper phase actual exits','true placed512 cost/stack beyond stated test assertions'],
 'exit':0}
(OUT/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
(OUT/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
