"""Run unchanged W7, H7, then three independent helper withdrawal triples."""
from pathlib import Path
import datetime,difflib,fcntl,hashlib,importlib.util,json,os,re,resource,shutil,sys,traceback
S='0f695866c0ba12d2c70dfd7d40628d0fda0f905f';ROOT=Path('/workspace/geo348-F0f695866-source');PREP=Path('/workspace/geo348-F0f695866-preparation/RESULT.json');OUT=Path('/workspace/geo348-F0f695866-formal');TMP=Path('/workspace/geo348-F0f695866-formal-tmp')
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');OBS=Path('/workspace/geo300-capacity512-h-pipe-capture-20261024');WITHDRAW=Path('/workspace/geo300-capacity512-publication-20261024/host-v5-draft/EXACT_WITHDRAWALS.json');HOST='tests/test_geo261_timber_capacity_host.py';MIN_FREE=100*1024*1024

def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def readj(p):return json.loads(p.read_bytes())

def main():
 need(not OUT.exists() and not TMP.exists(),'fresh formal output and TMP')
 need(shutil.disk_usage('/workspace').free>=MIN_FREE,'original100MiB environment guard')
 prep=readj(PREP);need(prep['exit_code']==0 and prep['source_sha']==S and prep['real_execution_head']==S,'actual prepared fixedF')
 pins=readj(OBS/'TOOL_PINS.json');need(sha((OBS/'TOOL_PINS.json').read_bytes())=='0d7cdc2ef7bcce382f5a02bc38effcec695326358d40c2f2c156be09b702c033','accepted collector pins')
 for name,pin in pins['tools'].items():need(sha((OBS/name).read_bytes())==pin['sha256'],'frozen collector '+name)
 need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original capture')
 lock=Path('/tmp/g261r3/secondary.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 OUT.mkdir();TMP.mkdir();before_stack=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,before_stack[1]))
 env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_')) and k not in {'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}}
 env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LANG='C.UTF-8',LC_ALL='C.UTF-8')
 spec=importlib.util.spec_from_file_location('cap',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT,env,S)
 report={'source_sha':S,'root':str(ROOT),'started_utc':utc(),'formal_methods':{'W7':7,'H7':7},'phases':[],'source_clean_after':False,'stack_before':before_stack,'stack_after':resource.getrlimit(resource.RLIMIT_STACK),'secondary_lock':'/tmp/g261r3/secondary.lock','accepted':False,'exit_code':None,'full_native':False,'ledger_regenerated':False,'performance':False,'errors':[]}
 original=(ROOT/HOST).read_bytes();need(sha(original)==prep['entries'][HOST]['sha256'],'fixed original host source')
 need(sha(WITHDRAW.read_bytes())=='48bf7a7cacc8f3de143a1903210b14ad43aa17d8bf69edcda71e6e94419613cc','accepted v5 exact withdrawal specification')
 withdrawals=readj(WITHDRAW);dump(OUT/'WITHDRAWALS.json',withdrawals)
 def git(*args):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=ROOT,source_sha=S)[1]
 def source_guard(variant,expected):
  need(git('rev-parse','HEAD').decode().strip()==S,'execution HEAD mustF')
  status=git('status','--porcelain=v1','--untracked-files=all');wanted=b'' if variant!='withdrawn' else (' M '+HOST+'\n').encode()
  need(status==wanted,'exact original/one-leaf variant dirty state')
  need(git('diff','--cached','--name-only')==b'','no staged variants')
  for name,pin in prep['entries'].items():need(sha((ROOT/name).read_bytes())==(sha(expected) if name==HOST else pin['sha256']),'phase source mismatch '+name)
 def phase(label,variant,expected,entry,count=1,negative=None):
  if shutil.disk_usage('/workspace').free<MIN_FREE:
   result={'label':label,'variant':variant,'state':'UNRUN_ENVIRONMENT','reason':'original100MiB disk guard','passed':False};report['phases'].append(result);dump(OUT/'PROGRESS.json',report);return
  where=OUT/label;where.mkdir();source_guard(variant,expected)
  (where/'host-source.py').write_bytes(expected)
  if variant=='withdrawn':(where/'withdrawal.diff').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),expected.decode().splitlines(True),fromfile=HOST+'@F',tofile=HOST+'@withdrawn')),encoding='utf-8')
  files={name:(sha(expected) if name==HOST else pin['sha256']) for name,pin in prep['entries'].items()};manifest={'source_sha':S,'source_variant':variant,'files':files};dump(where/'manifest.json',manifest)
  actual_entry=[x.replace('{OUT}',str(where)) for x in entry]
  argv=[sys.executable,'-B',str(OBS/'run_observed_original.py'),'--root',str(ROOT),'--sha',S,'--out',str(where/'observed'),'--manifest',str(where/'manifest.json'),'--',*actual_entry]
  row,stdout,stderr=rec.run(argv,cwd=ROOT,check=False,timeout=None,source_sha=S,source_variant=variant+':'+label)
  result={'label':label,'variant':variant,'state':'COMPLETED','argv':argv,'original_argv':[sys.executable,'-B',*actual_entry],'actual_exit':row['actual_process_returncode'],'original_expected_methods':count,'command_directory':row['directory'],'passed':False,'observation_complete':False,'negative':negative}
  try:
   observed=readj(where/'observed/OBSERVATION.json');terminal=readj(where/'observed/ORIGINAL_ENTRY.json')
   result['observation_complete']=observed['observer_complete'] is True and terminal['observer_complete'] is True and observed['source_sha']==terminal['source_sha']==S and terminal['source_variant']==variant and terminal['source_files_before']==terminal['source_files_after']==files and terminal['original_exit']==row['actual_process_returncode'] and terminal['original_completed'] is True
   result['observation']=observed;result['entry']=terminal
   if actual_entry[0]=='tests/_unittest_runner.py':
    detail=readj(where/'runner.json');result['runner']=detail
    verdict=row['actual_process_returncode']==0 and detail['total']==detail['run']==detail['passed']==count and all(detail.get(k,0)==0 for k in ['failed','skipped','extra_errors','blocked_by_error','expected_failed']) and detail['import_error'] is None
   else:
    text=stderr.decode('utf-8',errors='replace');normal=bool(re.search(r'^Ran 1 test in ',text,re.M))
    if negative is None:verdict=row['actual_process_returncode']==0 and normal and bool(re.search(r'^OK$',text,re.M))
    else:
     verdict=row['actual_process_returncode']==1 and normal and 'FAILED (failures=1)' in text and 'AssertionError:' in text and 'ERROR:' not in text and 'skipped=' not in text
     markers={'count':['in assert_count','self.assertEqual(list(range(1,count+1)),[item["id"] for item in response["timbers"]])'],'population':['in populate_full','self.assertTrue(response["ok"],response)'],'unplaced_replay':['self.assertTrue(restored.command("loadfile "+str(replay))["ok"])']}
     result['named_failure_markers']={m:m in text for m in markers[negative]};verdict=verdict and all(result['named_failure_markers'].values())
     if negative in ('population','unplaced_replay'):
      sessions=list((where/'observed').glob('session-*/stdout.bin'));found=any(b'I9' in p.read_bytes() for p in sessions);result['original_I9_response_captured']=found;verdict=verdict and found
   source_guard(variant,expected);result['source_exact_after']=True;result['passed']=verdict and result['observation_complete']
  except BaseException:result['observation_or_gate_error']=traceback.format_exc()
  report['phases'].append(result);dump(where/'RESULT.json',result);dump(OUT/'PROGRESS.json',report)
  print(json.dumps({'phase':label,'actual_exit':result['actual_exit'],'passed':result['passed'],'observation_complete':result['observation_complete']},ensure_ascii=False),flush=True)
 try:
  rec.run(['df','-B1','/workspace','/tmp'],cwd=ROOT)
  source_guard('fixed',original)
  # Collect both complete suites before any helper mutation, even if either is red.
  for label,target in [('W7','tests/test_geo261_timber_capacity.py'),('H7',HOST)]:
   phase(label,'fixed',original,['tests/_unittest_runner.py',target,'--json-out','{OUT}/runner.json','--log','{OUT}/unittest.log'],7)
  methods={'count':'test_each_real_declaration_retains_legacy_64_and_admits_up_to_512','population':'test_full_capacity_redeclaration_replay_and_rejected_edit_preserve_history','unplaced_replay':'test_full_capacity_redeclaration_replay_and_rejected_edit_preserve_history'}
  for control,method in methods.items():
   change=withdrawals[control];before,after=change['before'].encode(),change['after'].encode();need(original.count(after)==1,'unique exact helper anchor '+control);changed=original.replace(after,before)
   entry=['-m','unittest','-v','tests.test_geo261_timber_capacity_host.TimberCapacityHost.'+method]
   phase(control+'-fixed','fixed',original,entry)
   try:
    need((ROOT/HOST).read_bytes()==original,'original before helper withdrawal');(ROOT/HOST).write_bytes(changed)
    phase(control+'-withdrawn','withdrawn',changed,entry,negative=control)
   finally:
    need((ROOT/HOST).read_bytes()==changed,'do not overwrite unexpected helper drift');(ROOT/HOST).write_bytes(original)
   phase(control+'-restored','restored',original,entry)
  source_guard('restored',original);report['source_clean_after']=True
  report['accepted']=len(report['phases'])==11 and all(x['passed'] for x in report['phases']);report['exit_code']=0 if report['accepted'] else 1
 except BaseException:
  report['errors'].append(traceback.format_exc());report['exit_code']=1
 finally:
  report['ended_utc']=utc();report['workspace_free_after']=shutil.disk_usage('/workspace').free;dump(OUT/'RESULT.json',report);fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
 return report['exit_code']
if __name__=='__main__':raise SystemExit(main())
