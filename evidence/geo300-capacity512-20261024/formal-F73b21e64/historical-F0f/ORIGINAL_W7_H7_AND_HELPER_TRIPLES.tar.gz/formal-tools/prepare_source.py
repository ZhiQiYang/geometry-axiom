"""Materialize only the pinned capacity acceptance closure; no compilation/tests."""
from pathlib import Path,PurePosixPath
import hashlib,importlib.util,json,os,re,shutil,sys
S='0f695866c0ba12d2c70dfd7d40628d0fda0f905f';ORIGIN=Path('/workspace/geo300-capacity512-work-20261024');ROOT=Path('/workspace/geo348-F0f695866-source');OUT=Path('/workspace/geo348-F0f695866-preparation');CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
need(not ROOT.exists() and not OUT.exists(),'fresh private source/preparation');need(shutil.disk_usage('/workspace').free>=100*1024*1024,'original100MiB minimum environment guard')
need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original capture')
spec=importlib.util.spec_from_file_location('cap',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);OUT.mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
for k in list(env):
 if k.startswith('GIT_'):env.pop(k)
rec=cap.Recorder(OUT,env,S)
def git(args,cwd=ORIGIN,check=True):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=cwd,check=check,source_sha=S,source_variant='fixed acceptance source preparation only')
report={'source_sha':S,'source_root':str(ROOT),'compiled':False,'subject_run':False,'exit_code':None}
try:
 rec.run(['df','-B1','/workspace','/tmp'],cwd=ORIGIN)
 git(['cat-file','-e',S+'^{commit}'])
 _,listing,_=git(['ls-tree','-r','-z',S,'--','geometry-core/kernel','geometry-app/native','geometry-templates/woodworking/native'])
 seeds={'.gitattributes','.gitignore','AGENTS.md','room_a.scene','tests/__init__.py','tests/_unittest_runner.py','tests/_bridge.py','tests/binaries.py','tests/test_geo261_native_kernel.py','tests/test_engineering_json.py','tests/test_geo261_wood_world_validation.py','tests/test_geo261_timber_capacity.py','tests/test_geo261_timber_capacity_host.py','tests/geo261_timber_capacity_harness.c','tests/geo261_timber_capacity_host_harness.c','tests/geo261_exact_harness.c','tests/geo300_scene_generator.py','geometry-web/web_bridge.c'}
 for row in listing.rstrip(b'\0').split(b'\0'):
  meta,name=row.split(b'\t',1);n=name.decode()
  if n.endswith(('.c','.h','.inc')):seeds.add(n)
 bodies={};unresolved=[];pending=list(sorted(seeds))
 def normalize(parent,relative):
  parts=[]
  for p in (PurePosixPath(parent)/relative).parts:
   if p=='..':
    need(bool(parts),'quote escapes repository');parts.pop()
   elif p!='.':parts.append(p)
  return '/'.join(parts)
 while pending:
  n=pending.pop()
  if n in bodies:continue
  _,body,_=git(['show',S+':'+n]);bodies[n]=body
  if n.endswith(('.c','.h','.inc')):
   for raw in re.findall(rb'^\s*#\s*include\s*"([^"]+)"',body,re.M):
    child=normalize(str(PurePosixPath(n).parent),raw.decode())
    if child in bodies or child in pending:continue
    row,_,_=git(['cat-file','-e',S+':'+child],check=False)
    if row['actual_process_returncode']==0:pending.append(child)
    else:unresolved.append({'including':n,'literal':raw.decode(),'local_candidate':child,'reason':'No tracked file at quoted local path; public isolated include paths or inactive platform branch remain original'})
 entries={n:{'bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()} for n,b in sorted(bodies.items())}
 pattern=''.join('/'+n+'\n' for n in sorted(entries)).encode();(OUT/'SPARSE_STDIN.txt').write_bytes(pattern)
 report.update(entries=entries,source_bytes=sum(len(b) for b in bodies.values()),unresolved_local_quotes=unresolved)
 git(['clone','--shared','--no-checkout',str(ORIGIN),str(ROOT)])
 rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','set','--no-cone','--stdin'],cwd=ROOT,data=pattern,source_sha=S)
 git(['checkout','--detach',S],cwd=ROOT)
 need(git(['rev-parse','HEAD'],cwd=ROOT)[1].decode().strip()==S,'real detached F')
 need(git(['status','--porcelain=v1','--untracked-files=all'],cwd=ROOT)[1]==b'','fresh source clean')
 need(git(['diff','--cached','--exit-code','--name-status','HEAD'],cwd=ROOT)[1]==b'','source index exact')
 for n,b in bodies.items():need((ROOT/n).read_bytes()==b,'actual materialized Git bytes '+n)
 need((ROOT/'room_a.scene').stat().st_size==370,'original fixture370B')
 report.update(exit_code=0,closure_files=len(entries),real_execution_head=S,scope='No C/generator/test run; quote closure and NativeBuild input directories only')
finally:(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['entries','unresolved_local_quotes']},ensure_ascii=False))
