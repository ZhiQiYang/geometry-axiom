# 下一輪 H 原 loadfile 輸入保全（v2 外部草稿）

本目錄是獨立新版本，不改已執行的 `/workspace/geo300-capacity512-h-pipe-capture-20261024` 或其原收據。本輪 F0f 的四份 .scene supplement 是事後保全，不能由這個新工具追認成事前捕捉。

保留 v1 `observe_bridge_bytes.py` 與 `retain_native_inputs.py` 原 bytes；入口只改成使用 `FixtureObserver`，並把新增工具列入工具 pin。原 BridgeSession 物件、管線讀寫、wait／kill／timeout、subprocess 的參數與回傳／例外、原 atexit 次序均沿用。工具不編譯、不改測試、不改 source、不刪任何 fixture。

新增的 `loadfile-inputs/SNAPSHOTS.json` 在原 `BridgeSession.command` 呼叫前，以及原 `subprocess.run(input=...)` 呼叫前，讀取原指令明確引用的實體 scene。它沿 bridge 的第一個 ASCII 空白分隔規則保留完整路徑餘字，不 trim、展開或去引號。普通 H 輸入是 UTF-8／原 binary bytes。NUL／過長命令明列不完整，不自行模擬其他 parser 結果。

只允許原 source 或獨立 private TMPDIR 內的一般檔案；拒絕 final symlink、FIFO、device 或逃出根目錄。snapshot 保原路徑、原指令 bytes 的 hash、stat 前後、實體原 bytes 的內容定址副本。讀取前後 inode／大小／mtime／ctime 不一致會列 observation error。原 absent path 只記不存在，不猜原 child 結果。保全失敗不代換原 return／exception，但獨立 observer_complete 必須紅，外層不得把缺件宣稱完整。

這是 **原呼叫前的 snapshot**，不是 child 已執行 loadfile 或已讀到同 bytes 的證明。一次 run 的多個 loadfile 都在該次原呼叫前取樣；child 可能尚未執行、提早結束，或執行期間有另方改檔。原結果與完整 input／stdout／stderr 仍須另核。額外讀取會影響檔案 cache，因此本工具限功能驗收，不能充當效能量測工具。

`selftest_loadfile_inputs.py` 是純小 fixture／synthetic Python 測試；`selftest_bridge_bytes.py` 只把原 Observer import 換成新 subclass，以原20項檢查回歸（v1 原稿另保 `.v1.py.txt`）；`selftest_original_entry.py` 保留原 bytes，使用本目錄的新入口做原4項檢查。尚未執行任何 C、正式 W7／H7 或重跑產品。正式啟用前須先完成獨立自驗、撤回／恢復與另一代理對抗審。
