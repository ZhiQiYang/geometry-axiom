"""Capture real compiler inputs before launch and NativeBuild logs before cleanup.

External audit hooks only; never alter compiler argv, return codes or cleanup.
Content-addressed retained bytes avoid copying the same headers per invocation.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
from observe_bridge_bytes import sha, serial, write_json

ABI_RELATIVE = ('current_geometry.c',
    'geometry-templates/woodworking/native/members.h',
    'geometry-templates/woodworking/native/document.h',
    'geometry-templates/woodworking/native/contact_world.h',
    'geometry-templates/woodworking/native/cut_list.h',
    'geometry-templates/woodworking/native/member_reference.h')


def install(observer, private_tmp):
    private_tmp = Path(private_tmp).resolve()
    root, out = observer.root, observer.out/'native-inputs'
    out.mkdir()
    blobs = out/'bytes'
    blobs.mkdir()
    compiles, cleanups = [], []

    def retain(path):
        path = path.resolve()
        if not (path.is_relative_to(root) or path.is_relative_to(private_tmp)):
            raise ValueError('compiler input outside original source/private TMPDIR: '+str(path))
        body = path.read_bytes()
        digest = sha(body)
        target = blobs/digest
        if not target.exists(): target.write_bytes(body)
        return {'original':str(path),'bytes':len(body),'sha256':digest,'retained':str(target)}

    def compiler(argv, cwd):
        if not isinstance(argv,(list,tuple)): return
        argv = [os.fsdecode(value) for value in argv]
        # Only actual compile invocations, never execution of a compiled client.
        if '-c' not in argv and '/c' not in argv: return
        inputs = []
        for value in argv:
            if value.endswith('.c'):
                candidate=Path(value)
                if not candidate.is_absolute():candidate=Path(cwd or os.getcwd())/candidate
                if candidate.is_file():inputs.append(candidate.resolve())
        if not inputs:return
        selected = set(inputs)
        roles=[]
        for source in inputs:
            if 'capacity-host-abi-closure' in source.parts:
                index=source.parts.index('capacity-host-abi-closure')
                closure=Path(*source.parts[:index+1])
                selected.update(closure/path for path in ABI_RELATIVE)
                roles.append('actual-H-ABI-closure-at-compile')
            # W's values-only control mutates this exact adjacent header.
            if source.is_relative_to(private_tmp) and (source.parent/'members.h').is_file():
                selected.add(source.parent/'members.h')
                roles.append('private-W-members-header-at-compile')
        row={'event':'subprocess.Popen-before-launch','argv':serial(argv),'cwd':serial(cwd),
             'roles':roles,'inputs':[retain(path) for path in sorted(selected)]}
        compiles.append(row)
        write_json(out/'compiler-input-snapshots.json',compiles)

    def cleanup(value):
        path=Path(os.fsdecode(value))
        if not path.is_absolute():return
        path=path.resolve()
        if not path.is_relative_to(private_tmp) or not path.name.startswith('geo261-n1a-'):return
        log=path/'build-log.json'
        if not log.is_file():return
        body=log.read_bytes()
        row={'event':'shutil.rmtree-before-cleanup','original':str(path),'build_log':retain(log),
             'compiled_sources':[]}
        seen=set()
        for command in json.loads(body):
            for value in command['arguments']:
                source=Path(value)
                if source.suffix=='.c' and source.is_absolute() and source.is_relative_to(path) and source.is_file() and source not in seen:
                    row['compiled_sources'].append(retain(source));seen.add(source)
        cleanups.append(row)
        write_json(out/'cleanup-retention.json',cleanups)

    def audit(event,values):
        if not observer.active:return
        if event=='subprocess.Popen' and len(values)>=3:
            observer.safe(lambda:compiler(values[1],values[2]),'compiler-input-audit')
        elif event=='shutil.rmtree' and values:
            observer.safe(lambda:cleanup(values[0]),'NativeBuild-before-cleanup-audit')
    sys.addaudithook(audit)
    return {'compiler_snapshots':compiles,'cleanup_snapshots':cleanups}
