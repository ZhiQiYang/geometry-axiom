raise SystemExit(2)
