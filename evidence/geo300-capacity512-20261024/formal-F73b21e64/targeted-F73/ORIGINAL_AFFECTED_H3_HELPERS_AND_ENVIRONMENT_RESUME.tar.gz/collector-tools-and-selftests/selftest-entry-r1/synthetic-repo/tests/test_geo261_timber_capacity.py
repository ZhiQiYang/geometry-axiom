# Synthetic manifest placeholder, never imported or claimed as a product test.
