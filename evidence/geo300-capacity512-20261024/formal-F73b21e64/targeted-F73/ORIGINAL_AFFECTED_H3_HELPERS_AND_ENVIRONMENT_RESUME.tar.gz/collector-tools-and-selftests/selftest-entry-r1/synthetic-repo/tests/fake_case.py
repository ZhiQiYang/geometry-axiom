import atexit,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
class FakeCase(unittest.TestCase):
    def test_fake(self):
        directory=Path(tempfile.mkdtemp(prefix="geo261-n1a-",dir=os.environ["TMPDIR"]))
        source=directory/"fake.c";source.write_text("/* never compiled */\n")
        (directory/"build-log.json").write_text(json.dumps([{"arguments":[str(source)],"exit":0,"stdout":"synthetic","stderr":""}]))
        atexit.register(shutil.rmtree,directory)
        result=subprocess.run([sys.executable,"-B","-c","import sys;sys.stdout.buffer.write(sys.stdin.buffer.read())"],input=b"binary\x00\xff",capture_output=True,timeout=5)
        self.assertEqual(result.stdout,b"binary\x00\xff")
    def test_fake_failure(self):
        self.fail("synthetic original assertion")
