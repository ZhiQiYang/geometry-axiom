"""Synthetic Git source exercises wrapper entry/finalizer, never product C."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=False)
    fixture=args.out/'synthetic-repo';fixture.mkdir()
    copied=['tests/_bridge.py','tests/binaries.py','tests/test_geo261_native_kernel.py',
            'tests/test_geo261_timber_capacity.py','tests/test_geo261_timber_capacity_host.py','tests/_unittest_runner.py']
    for relative in copied:
        target=fixture/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if relative in ('tests/test_geo261_timber_capacity.py','tests/test_geo261_timber_capacity_host.py'):
            target.write_text('# Synthetic manifest placeholder, never imported or claimed as a product test.\n')
        else:shutil.copyfile(args.root/relative,target)
    (fixture/'tests/__init__.py').write_text('')
    (fixture/'tests/synthetic_exit_two.py').write_text('raise SystemExit(2)\n')
    (fixture/'tests/fake_case.py').write_text('''import atexit,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
class FakeCase(unittest.TestCase):
    def test_fake(self):
        directory=Path(tempfile.mkdtemp(prefix="geo261-n1a-",dir=os.environ["TMPDIR"]))
        source=directory/"fake.c";source.write_text("/* never compiled */\\n")
        (directory/"build-log.json").write_text(json.dumps([{"arguments":[str(source)],"exit":0,"stdout":"synthetic","stderr":""}]))
        atexit.register(shutil.rmtree,directory)
        result=subprocess.run([sys.executable,"-B","-c","import sys;sys.stdout.buffer.write(sys.stdin.buffer.read())"],input=b"binary\\x00\\xff",capture_output=True,timeout=5)
        self.assertEqual(result.stdout,b"binary\\x00\\xff")
    def test_fake_failure(self):
        self.fail("synthetic original assertion")
''')
    gitlog=[]
    def git(*argv):
        result=subprocess.run(['git',*argv],cwd=fixture,capture_output=True)
        gitlog.append({'argv':['git',*argv],'exit':result.returncode,'stdout_hex':result.stdout.hex(),'stderr_hex':result.stderr.hex()})
        if result.returncode:raise RuntimeError(result.stderr)
        return result.stdout.decode().strip()
    git('init','-q');git('add','tests');git('-c','user.name=Collector selftest','-c','user.email=collector-selftest@example.invalid','commit','-qm','Create synthetic collector-only source fixture')
    source_sha=git('rev-parse','HEAD')
    files={str(path.relative_to(fixture)):hashlib.sha256(path.read_bytes()).hexdigest() for path in (fixture/'tests').glob('*.py')}
    manifest={'source_sha':source_sha,'source_variant':'fixed','files':files}
    manifest_path=args.out/'manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    temporary=args.out/'private-tmp';temporary.mkdir()
    rows=[]
    for label,entry,expected in (
        ('path',['tests/_unittest_runner.py','tests/fake_case.py','--json-out',str(args.out/'original-runner.json')],1),
        ('module-pass',['-m','unittest','-v','tests.fake_case.FakeCase.test_fake'],0),
        ('module-fail',['-m','unittest','-v','tests.fake_case.FakeCase.test_fake_failure'],1),
        ('path-exit2',['tests/synthetic_exit_two.py'],2)):
        outer=args.out/(label+'-launch');outer.mkdir();observation=args.out/(label+'-observation')
        argv=[sys.executable,'-B',str(Path(__file__).with_name('run_observed_original.py')),
              '--root',str(fixture),'--sha',source_sha,'--out',str(observation),'--manifest',str(manifest_path),'--',*entry]
        env=dict(os.environ,TMPDIR=str(temporary),PYTHONDONTWRITEBYTECODE='1')
        started=time.time()
        with (outer/'stdout.bin').open('wb') as stdout,(outer/'stderr.bin').open('wb') as stderr:
            result=subprocess.run(argv,cwd=fixture,env=env,stdout=stdout,stderr=stderr,timeout=20)
        row={'argv':argv,'actual_exit':result.returncode,'expected_original_exit':expected,'started_epoch':started,'ended_epoch':time.time()}
        (outer/'RESULT.json').write_text(json.dumps(row,indent=2)+'\n')
        assert result.returncode==expected,(label,row,(outer/'stderr.bin').read_text())
        terminal=json.loads((observation/'ORIGINAL_ENTRY.json').read_bytes())
        assert terminal['original_exit']==expected and terminal['observer_complete'],terminal
        assert terminal['source_files_before']==terminal['source_files_after']
        if label in ('path','module-pass'):assert terminal['cleanup_snapshots']==1,terminal
        rows.append(row)
        print('PASS synthetic original entry '+label,flush=True)
    (args.out/'SELFTEST.json').write_text(json.dumps({'scope':'synthetic source, no product gate/no compiler','source_sha':source_sha,'git_commands':gitlog,'cases':rows,'passed':True},indent=2)+'\n')


if __name__=='__main__':main()
