#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3

import json,os,sys,time
mode='crlf'
line=sys.stdin.buffer.readline()
if mode=='split':
    payload='{"value":"字"}\n'.encode()
    cut=payload.index('字'.encode())+1
    os.write(1,payload[:cut]);time.sleep(.01);os.write(1,payload[cut:])
elif mode=='crlf':os.write(1,b'{"value":1}\r\n')
elif mode=='ahead':os.write(1,b'{"value":1}\n{"value":2}\n');sys.stdin.buffer.readline()
elif mode=='extra':os.write(1,b'{"value":1}\n'+b'extra-unread\x00\xff'*100)
elif mode=='stderr':os.write(2,b'original stderr\x00\xff\r\n');os.write(1,b'{"value":1}\n')
elif mode=='nonzero':os.write(2,b'original failure\xff\n');os.write(1,b'{"value":1}\n');sys.exit(7)
elif mode=='eof':sys.exit(0)
elif mode=='invalid_utf8':os.write(1,b'\xff\n')
elif mode=='invalid_json':os.write(1,b'not-json\n')
elif mode=='timeout':
    os.write(1,b'{"value":1}\n')
    while True:time.sleep(1)
else:os.write(1,b'{"value":1}\n')
sys.stdin.buffer.read()
