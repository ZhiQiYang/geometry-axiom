"""Run an unchanged original Python entry with separate raw observation receipt.

Usage: ... --root ROOT --sha F --out NEW --manifest MANIFEST -- path ARGS...
   or: ... --root ROOT --sha F --out NEW --manifest MANIFEST -- -m unittest ARGS...

The owner supplies an exact phase manifest; withdrawals remain labelled dirty
source variants. This tool creates no mutations, compilers or test verdicts.
"""
from __future__ import annotations
import argparse
import atexit
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time
from observe_bridge_bytes import error_record, sha, write_json
from retain_loadfile_inputs import FixtureObserver as Observer
from retain_native_inputs import install as install_native_inputs


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('original',nargs=argparse.REMAINDER)
    args=parser.parse_args()
    root=args.root.resolve();out=args.out.resolve()
    if root!=Path.cwd().resolve():raise ValueError('original cwd required')
    if out.is_relative_to(root) or out.exists():raise ValueError('fresh external output required')
    if sys.flags.optimize:raise ValueError('original assertions require non-optimized Python')
    if len(args.sha)!=40 or any(c not in '0123456789abcdef' for c in args.sha):raise ValueError('full source SHA required')
    private_tmp=Path(os.environ['TMPDIR']).resolve()
    if private_tmp==Path('/tmp') or not private_tmp.is_dir():raise ValueError('existing private TMPDIR required')
    manifest_raw=args.manifest.read_bytes();manifest=json.loads(manifest_raw)
    if manifest['source_sha']!=args.sha:raise ValueError('phase manifest source mismatch')
    if manifest['source_variant'] not in ('fixed','withdrawn','restored'):raise ValueError('explicit phase variant required')
    files=manifest['files']
    mandatory={'tests/_bridge.py','tests/binaries.py','tests/test_geo261_native_kernel.py',
               'tests/test_geo261_timber_capacity.py','tests/test_geo261_timber_capacity_host.py'}
    if not mandatory.issubset(files):raise ValueError('phase manifest missing original observer/judge inputs')
    original=args.original[1:] if args.original[:1]==['--'] else args.original
    if not original:raise ValueError('original Python entry required')
    is_module=original[:1]==['-m']
    if is_module and (len(original)<2 or original[1]!='unittest'):raise ValueError('only original unittest module entry supported')
    if not is_module and original[0] not in files:raise ValueError('original entry must be in exact phase manifest')
    original_run=subprocess.run
    checks=[]
    def git(argv):
        result=original_run(['git',*argv],cwd=root,capture_output=True,check=False)
        checks.append({'argv':['git',*argv],'actual_exit':result.returncode,
                       'stdout_hex':result.stdout.hex(),'stderr_hex':result.stderr.hex()})
        return result
    head=git(['rev-parse','HEAD'])
    if head.returncode or head.stdout!=(args.sha+'\n').encode():raise ValueError('original HEAD mismatch')
    before={}
    for relative,expected in files.items():
        path=(root/relative).resolve()
        if not path.is_relative_to(root):raise ValueError('manifest escapes source')
        body=path.read_bytes();digest=sha(body)
        if digest!=expected:raise ValueError('phase source bytes mismatch: '+relative)
        committed=git(['show',args.sha+':'+relative])
        if committed.returncode:raise ValueError('phase source absent in F: '+relative)
        if body!=committed.stdout:
            if manifest['source_variant']!='withdrawn' or relative!='tests/test_geo261_timber_capacity_host.py':
                raise ValueError('unexpected original source variant: '+relative)
        before[relative]=digest
    status=git(['status','--porcelain=v1','--untracked-files=all'])
    if status.returncode:raise ValueError('original git status failed')
    observer=Observer(out,args.sha,root)
    write_json(out/'REQUEST.json',{'original_argv':original,'source_sha':args.sha,
        'source_variant':manifest['source_variant'],'phase_manifest':manifest,
        'manifest_sha256':sha(manifest_raw),'source_preflight_commands':checks,
        'root':str(root),'private_tmp':str(private_tmp),'started_epoch':time.time(),
        'observer_tools':{name:sha(Path(__file__).with_name(name).read_bytes()) for name in
          ('observe_bridge_bytes.py','retain_native_inputs.py','retain_loadfile_inputs.py','run_observed_original.py')},
        'stream_scope':'BridgeSession predecode bytes; subprocess.run original binary streams or explicitly decoded text, including input.bin'})
    native=install_native_inputs(observer,private_tmp)
    state={'original_exit':None,'original_completed':False,'original_exception':None}
    def finalize():
        try:
            after={}
            for relative in files:
                observer.safe(lambda p=relative: after.update({p:sha((root/p).read_bytes())}), 'source-after-read')
            if after!=before:observer.errors.append({'where':'source-after-integrity','before':before,'after':after})
            final_head=original_run(['git','rev-parse','HEAD'],cwd=root,capture_output=True,check=False)
            final_status=original_run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,capture_output=True,check=False)
            if final_head.returncode or final_head.stdout!=head.stdout or final_status.returncode or final_status.stdout!=status.stdout:
                observer.errors.append({'where':'source-git-postflight-mismatch'})
            observation=observer.finish()
            write_json(out/'ORIGINAL_ENTRY.json',{**state,'source_sha':args.sha,
                'source_variant':manifest['source_variant'],'source_files_before':before,'source_files_after':after,
                'postflight_head':{'exit':final_head.returncode,'stdout_hex':final_head.stdout.hex(),'stderr_hex':final_head.stderr.hex()},
                'postflight_status':{'exit':final_status.returncode,'stdout_hex':final_status.stdout.hex(),'stderr_hex':final_status.stderr.hex()},
                'observer_complete':observation['observer_complete'],
                'compiler_snapshots':len(native['compiler_snapshots']),'cleanup_snapshots':len(native['cleanup_snapshots']),
                'requirement':'Outer launcher must independently reject missing/false observer_complete; original child OS exit is not rewritten by atexit.'})
        except BaseException as exc:
            print('OBSERVATION_FINALIZATION_FAILED '+repr(exc),file=sys.stderr,flush=True)
        finally:observer.uninstall()
    # Registered before imports: original NativeBuild atexit handlers therefore
    # run first. No explicit cleanup, extra wait or changed original exit.
    atexit.register(finalize)
    observer.install_imports();observer.install_run()
    oldargv,oldpath=sys.argv,sys.path[:]
    original_exit=None;failure=None;completed=False
    try:
        if is_module:
            sys.argv=[original[1],*original[2:]]
            sys.path[0]=str(root)
            runpy.run_module(original[1],run_name='__main__',alter_sys=True)
        else:
            sys.argv=original
            sys.path[0]=str((root/original[0]).parent)
            runpy.run_path(str(root/original[0]),run_name='__main__')
        original_exit=0;completed=True
    except BaseException as exc:
        failure=exc
        if isinstance(exc,SystemExit):
            completed=True
            original_exit=0 if exc.code is None else exc.code if isinstance(exc.code,int) else 1
        elif isinstance(exc,KeyboardInterrupt):original_exit=130
        else:original_exit=1
        raise
    finally:
        sys.argv,sys.path[:]=oldargv,oldpath
        # Explicit cleanup is not added. NativeBuild normally uses atexit, which
        # must run before the observer's final receipt (registered below).
        state.update(original_exit=original_exit,original_completed=completed,
                     original_exception=error_record(failure) if failure is not None else None)

    # Subject success that returns without SystemExit is equivalent to original0.


if __name__=='__main__':main()
