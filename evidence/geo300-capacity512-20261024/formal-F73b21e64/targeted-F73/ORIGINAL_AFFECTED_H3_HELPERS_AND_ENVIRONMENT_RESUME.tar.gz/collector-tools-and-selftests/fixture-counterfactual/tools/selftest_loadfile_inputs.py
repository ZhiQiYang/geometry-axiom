"""Synthetic small-fixture observer checks; never compile or load product code."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
from retain_loadfile_inputs import FixtureObserver


def main():
    out = Path(sys.argv[1]).resolve()
    out.mkdir(exist_ok=False)
    root, private = out / 'source', out / 'private'
    root.mkdir(); private.mkdir()
    previous = os.environ.get('TMPDIR')
    os.environ['TMPDIR'] = str(private)
    checks = []
    def check(name, value):
        checks.append({'name': name, 'passed': bool(value)})
        assert value, name
    observer = FixtureObserver(out / 'observation', '1' * 40, root)
    try:
        scene = private / '原始 fixture.scene'
        payload = b'\xff\x00original scene\r\n'
        scene.write_bytes(payload)
        original_stat = scene.stat()
        command = 'loadfile ' + str(scene)
        observer.capture_loadfiles(command, root, 'synthetic-command', 'one')
        ref = observer.fixture_events[-1]['references'][0]
        check('actual input bytes including NUL preserved', Path(ref['retained']).read_bytes() == payload)
        check('original fixture not rewritten', scene.read_bytes() == payload and scene.stat().st_mtime_ns == original_stat.st_mtime_ns)
        check('real binary hash', ref['sha256'] == hashlib.sha256(payload).hexdigest())
        check('not child consumption claim', ref['child_consumption_not_proven'] is True)
        spaced = root / ' a scene with spaces.scene'
        spaced.write_bytes(b'leading filename space\n')
        observer.capture_loadfiles(b'loadfile  a scene with spaces.scene\r\ndump\n', root, 'synthetic-batch', 'two')
        check('first-space remainder is not stripped', observer.fixture_events[-1]['references'][0]['original_path'] == str(spaced))
        check('relative cwd resolves to original fixture', Path(observer.fixture_events[-1]['references'][0]['retained']).read_bytes() == spaced.read_bytes())
        before_events = len(observer.fixture_events)
        observer.capture_loadfiles(b'line loadfile ignored.scene\n loadfile ignored.scene\n', root, 'synthetic-noncommands', 'three')
        check('non-loadfile commands do not invent references', len(observer.fixture_events) == before_events)
        observer.capture_loadfiles(b'loadfile missing.scene\n', root, 'synthetic-missing', 'four')
        check('missing input absence recorded without predicting child', observer.fixture_events[-1]['references'][0]['status'] == 'absent-before-original-call')
        check('expected absent file not observer failure', not observer.errors)

        sentinel = object()
        class FakeSession:
            def __init__(self): pass
            def command(self, text):
                captured = observer.fixture_events[-1]['references'][0]
                check('session capture before original command', Path(captured['retained']).read_bytes() == payload)
                scene.write_bytes(b'changed-by-original-call\n')
                return sentinel
            send = command
            def stop(self): pass
            close = stop
        observer.install_class(FakeSession)
        session = object.__new__(FakeSession)
        session._original_bytes_observation = {'cwd': str(root), 'folder': 'synthetic-session'}
        check('original command result identity preserved', session.command(command) is sentinel)
        check('later change does not rewrite prior snapshot', Path(observer.fixture_events[-1]['references'][0]['retained']).read_bytes() == payload)

        original_run = subprocess.run
        cp = subprocess.CompletedProcess(['synthetic'], 7, b'original-out', b'original-err')
        call_input = ('loadfile ' + str(scene) + '\n').encode()
        argv = ['synthetic']
        passed = {'input': call_input, 'cwd': root, 'capture_output': True, 'timeout': 600}
        calls = []
        def fake_run(*args, **kwargs):
            calls.append((args, kwargs))
            check('run snapshot before original body', Path(observer.fixture_events[-1]['references'][0]['retained']).read_bytes() == b'changed-by-original-call\n')
            check('original input and argv identity preserved', args[0] is argv and kwargs['input'] is call_input)
            scene.unlink()
            return cp
        subprocess.run = fake_run
        try:
            observer.install_run()
            check('original CompletedProcess identity and nonzero preserved', subprocess.run(argv, **passed) is cp)
            check('original run called once with original timeout', len(calls) == 1 and calls[0][1]['timeout'] == 600)
            check('snapshot survives original fixture deletion', Path(observer.fixture_events[-1]['references'][0]['retained']).read_bytes() == b'changed-by-original-call\n')
        finally:
            observer.uninstall()
            subprocess.run = original_run
        failure = subprocess.TimeoutExpired(['synthetic'], 600, output=b'partial', stderr=b'failure')
        failed_calls = []
        def fake_failed_run(*args, **kwargs):
            failed_calls.append((args, kwargs))
            raise failure
        subprocess.run = fake_failed_run
        try:
            observer.install_run()
            try:
                subprocess.run(argv, **passed)
            except subprocess.TimeoutExpired as got:
                check('same original timeout exception identity', got is failure)
            else:
                raise AssertionError('original timeout exception swallowed')
            check('failed original called once without timeout alteration', len(failed_calls) == 1 and failed_calls[0][1]['timeout'] == 600)
        finally:
            observer.uninstall()
            subprocess.run = original_run
        result = observer.finish()
        check('ordinary observer remains complete', result['observer_complete'])
    finally:
        observer.uninstall()

    invalid = FixtureObserver(out / 'invalid-observation', '1' * 40, root)
    try:
        outside = out / 'outside.scene'; outside.write_bytes(b'not allowed')
        invalid.capture_loadfiles('loadfile ' + str(outside), root, 'synthetic-outside', 'five')
        check('outside source/private TMP rejected', invalid.fixture_events[-1]['references'][0]['status'] == 'snapshot-failed')
        target = root / 'target.scene'; target.write_bytes(b'target')
        link = root / 'linked.scene'; link.symlink_to(target)
        invalid.capture_loadfiles('loadfile ' + str(link), root, 'synthetic-link', 'six')
        check('symlink refused without changing original link', invalid.fixture_events[-1]['references'][0]['status'] == 'snapshot-failed' and link.is_symlink())
        fifo = root / 'fifo.scene'; os.mkfifo(fifo)
        invalid.capture_loadfiles('loadfile ' + str(fifo), root, 'synthetic-fifo', 'seven')
        check('FIFO refused without blocking read', invalid.fixture_events[-1]['references'][0]['status'] == 'snapshot-failed')
        invalid.capture_loadfiles(b'loadfile target.scene\x00ignored\n', root, 'synthetic-NUL-command', 'eight')
        check('NUL command not falsely claimed captured', invalid.fixture_events[-1]['references'][0]['status'] == 'unsupported-NUL-or-overlong-command')
        invalid.capture_loadfiles(b'loadfile ' + b'x' * 4096 + b'\n', root, 'synthetic-overlong-command', 'nine')
        check('overlong command not parser-reinterpreted', invalid.fixture_events[-1]['references'][0]['status'] == 'unsupported-NUL-or-overlong-command')
        check('invalid observation is incomplete without subject verdict', not invalid.finish()['observer_complete'])
    finally:
        invalid.uninstall()
        if previous is None: os.environ.pop('TMPDIR', None)
        else: os.environ['TMPDIR'] = previous
    result = {'checks': len(checks), 'failures': [c for c in checks if not c['passed']],
              'exit_code': 0, 'C_executed': False, 'product_tests_executed': False, 'details': checks}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('checks', 'failures', 'exit_code')}))


if __name__ == '__main__':
    main()
