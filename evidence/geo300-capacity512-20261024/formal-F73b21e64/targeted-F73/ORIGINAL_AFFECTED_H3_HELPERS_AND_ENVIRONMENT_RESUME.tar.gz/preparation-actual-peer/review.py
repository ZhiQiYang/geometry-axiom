#!/usr/bin/env python3
import hashlib,json,os,stat,subprocess,base64
from pathlib import Path
B=Path('/workspace/geo348-F73b21e64-preparation');P=Path('/workspace/train337-canvas-peer-resume');R=Path('/workspace/geo348-F73b21e64-source');S='73b21e64dce72f0d16ca29e18559c51815b9724d'
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
def need(v,n):checks.append({'check':n,'passed':bool(v)})
r=j(B/'RESULT.json');need(h((B/'RESULT.json').read_bytes())=='59dd899ff50fe3dabb492723a397001bd4c2168e27b5b43609ae6227b326af83','fixed original preparation result')
need(r['exit_code']==0 and r['source_sha']==r['real_execution_head']==S and not r['compiled'] and not r['subject_run'],'preparation0 only no subject')
need(len(r['entries'])==r['closure_files']==204 and r['source_bytes']==2367578,'exact204 inputs2367578 bytes')
rows=j(B/'subcommands.json');need(len(rows)==297,'297 original preparation commands')
unresolved={S+':'+x['local_candidate'] for x in r['unresolved_local_quotes']};seen={};negative=[]
for row in rows:
 d=Path(row['directory']);need(j(d/'result.json')==row,'original row '+d.name)
 need(type(row['actual_process_returncode']) is int and not row['timeout_expired'],'original terminal '+d.name)
 for n in ['stdout','stderr']:
  raw=(d/(n+'.bin')).read_bytes();need(len(raw)==row[n+'_bytes'] and h(raw)==row[n+'_sha256'],'full '+n+' '+d.name)
 need(row['acceptance_sha']==row['source_sha']==S,'original source binding '+d.name)
 if row['actual_process_returncode']:
  negative.append(row);need('cat-file' in row['command'] and '-e' in row['command'] and row['command'][-1] in unresolved,'only declared unresolved quote probe nonzero '+d.name)
 if 'show' in row['command'] and row['command'][-1].startswith(S+':'):seen[row['command'][-1][41:]]=(d/'stdout.bin').read_bytes()
need(set(seen)==set(r['entries']),'all204 exact source Gitshow outputs')
need({x['command'][-1] for x in negative}==unresolved,'unresolved quote probe list complete')
for name,pin in r['entries'].items():
 raw=seen[name];p=R/name
 need(len(raw)==pin['bytes'] and h(raw)==pin['sha256'],'Git content pinned '+name)
 need(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin['git_blob'],'original Git blob '+name)
 need(stat.S_ISREG(p.lstat().st_mode) and p.read_bytes()==raw and p.stat().st_nlink==1,'fresh independent regular source '+name)
need((R/'room_a.scene').stat().st_size==370,'original fixture370 bytes')
need((B/'SPARSE_STDIN.txt').read_bytes()==''.join('/'+x+'\n' for x in sorted(r['entries'])).encode(),'exact sparse stdin204')
fresh=[]
for args,wanted in [(['rev-parse','HEAD'],(S+'\n').encode()),(['status','--porcelain=v1','--untracked-files=all'],b''),(['diff','--cached','--exit-code','--name-status','HEAD'],b'')]:
 cmd=['git','-c','gc.auto=0','-c','maintenance.auto=false',*args];z=subprocess.run(cmd,cwd=R,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),capture_output=True)
 fresh.append({'command':cmd,'cwd':str(R),'exit':z.returncode,'stdout_base64':base64.b64encode(z.stdout).decode(),'stderr_base64':base64.b64encode(z.stderr).decode()});need(z.returncode==0 and z.stdout==wanted,'fresh source guard '+args[0])
failed=[x['check'] for x in checks if not x['passed']];o=P/'GEO348_F73_PREPARATION_ACTUAL_PEER.json';o.write_text(json.dumps({'scope':'Actual F73 preparation only; no C execution','checks':len(checks),'exit_code':int(bool(failed)),'findings':failed,'source_sha':S,'source_entries':204,'original_command_count':len(rows),'original_nonzero_quote_checks':len(negative),'fresh_git_reads':fresh,'limitations':['Unresolved local include probes are explicit original cat-file negatives, not compiler/test results.','Formal partial13 phases still unrun; two512 original failures not accepted.'],'check_details':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(o),'sha256':h(o.read_bytes()),'checks':len(checks),'exit_code':int(bool(failed)),'findings':failed}));raise SystemExit(bool(failed))
