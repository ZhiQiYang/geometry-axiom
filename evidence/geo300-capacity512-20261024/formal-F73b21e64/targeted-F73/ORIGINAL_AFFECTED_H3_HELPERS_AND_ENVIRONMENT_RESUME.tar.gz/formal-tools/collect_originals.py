"""Archive the terminal affected H3 and original controls, including reds; never rerun or repair."""
from pathlib import Path
import datetime,hashlib,io,json,shutil,tarfile
S='73b21e64dce72f0d16ca29e18559c51815b9724d'
R=Path('/workspace/geo348-F73b21e64-formal');L=Path('/workspace/geo348-F73b21e64-formal-launch')
O=Path('/workspace/geo348-F73b21e64-formal-package');HERE=Path(__file__).resolve().parent
roots={'formal':R,'outer':L,'source-preparation':Path('/workspace/geo348-F73b21e64-preparation'),
 'formal-tools':HERE,'collector-tools-and-selftests':Path('/workspace/geo300-capacity512-h-pipe-capture-v2-20261024'),
 'collector-independent-peer':Path('/workspace/geo348-h-v2-peer-specials-20261024')}
# Only these four small files from the shared reviewer directory, never its other lanes.
individual={
 'partial-tools-peer/REVIEW.json':Path('/workspace/train337-canvas-peer-resume/GEO348_F73_PARTIAL_TOOLS_STATIC_PEER.json'),
 'partial-tools-peer/review.py':Path('/workspace/train337-canvas-peer-resume/review_geo348_F73_partial_tools.py'),
 'preparation-actual-peer/REVIEW.json':Path('/workspace/train337-canvas-peer-resume/GEO348_F73_PREPARATION_ACTUAL_PEER.json'),
 'preparation-actual-peer/review.py':Path('/workspace/train337-canvas-peer-resume/review_geo348_F73_preparation.py')}

def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def read(p):return json.loads(p.read_bytes())
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
 need(not O.exists(),'fresh package only')
 result=read(R/'RESULT.json');outer=read(L/'receipt.json')
 need(result['source_sha']==S and type(result['exit_code'])is int,'original formal terminal SHA/exit')
 need(outer['source']==S and outer['primary_returncode']==result['exit_code'] and outer['launcher_exit']==result['exit_code'] and not outer['metadata_problems'],'original outer/primary/reaper same real terminal')
 need(shutil.disk_usage('/workspace').free>=50*1024*1024,'small packaging resource guard; no product threshold')
 O.mkdir();items={}
 for prefix,root in roots.items():
  need(root.is_dir(),'missing original root '+str(root))
  for p in sorted(root.rglob('*')):
   if p.is_file():
    need(not p.is_symlink(),'unexpected original symlink '+str(p));name=prefix+'/'+str(p.relative_to(root));need(name not in items,'duplicate archive name');items[name]=p
 for name,p in individual.items():
  need(p.is_file() and not p.is_symlink(),'required original peer '+str(p));need(name not in items,'duplicate individual');items[name]=p
 # No workspace checkout, Git objects, NativeBuild temp ELF, or existing archive payloads.
 need(all(p.read_bytes()[:4]!=b'\x7fELF' for p in items.values()),'scope contains metadata/source/streams, no transient ELF')
 archive=O/'ORIGINAL_AFFECTED_H3_HELPER_AND_SENTINEL_TRIPLES.tar.gz';rows=[]
 with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
  for name,p in sorted(items.items()):
   raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw));rows.append({'member':name,'source':str(p),'bytes':len(raw),'sha256':sha(raw)})
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();need(len(members)==len(rows),'roundtrip count')
  for row,member in zip(rows,members):
   raw=tf.extractfile(member).read();need(member.name==row['member'] and sha(raw)==row['sha256'] and raw==Path(row['source']).read_bytes(),'roundtrip original mismatch '+row['member'])
 index={'source_sha':S,'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'member_count':len(rows),'files':rows};dump(O/'RAW_INDEX.json',index)
 summary={k:v for k,v in index.items()if k!='files'};summary.update(original_exit=result['exit_code'],original_accepted=result['accepted'],source_clean_after=result['source_clean_after'],phases=[{k:p.get(k)for k in ('label','variant','state','actual_exit','passed','observation_complete')}for p in result['phases']],roundtrip_all_bytes_equal=True,original_bytes=sum(x['bytes']for x in rows),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['Only affected original H3, three helper triples and sentinel-fix triple; not full W7/H7, either unresolved512 method, native/browser/ledger/architecture or performance.','Original compiler text=True outputs retain decoded-text representation; original binary run/Bridge pipes captured before decoding.','Original subprocess TimeoutExpired may have no CompletedProcess returncode or output; do not invent a child exit.','V2 fixture observer captures actual loadfile input bytes before command send; this is not proof the child consumed those bytes. No old F0f fixture is retroactively reconstructed.','Original NativeBuild cleanup retained unchanged; source/command/ELF hashes are not retained ELF payloads.'])
 dump(O/'SUMMARY.json',summary);print(json.dumps({k:summary[k]for k in ['source_sha','original_exit','member_count','archive_bytes','archive_sha256']}))
if __name__=='__main__':main()
