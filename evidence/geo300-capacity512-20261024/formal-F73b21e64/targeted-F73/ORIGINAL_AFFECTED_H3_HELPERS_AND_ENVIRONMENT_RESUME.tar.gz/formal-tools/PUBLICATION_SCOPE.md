# F73 定向驗收的出版界線

產品／測試來源固定 `73b21e64dce72f0d16ca29e18559c51815b9724d`。本輪唯一來源變更是 host 測試的安全不完整宣告入口與其獨立反證；branch/source 仍由 combined owner 寫入。

執行範圍為原 H3 受影響方法、三個原 helper 的 fixed/withdrawn/restored、sentinel 修正 fixed/withdrawn/restored，共 13 phases。原三個 helper 的撤回只改精確規格 `48bf7a7cacc8f3de143a1903210b14ad43aa17d8bf69edcda71e6e94419613cc`。sentinel 撤回只把 `INCOMPLETE_DECLARATION="timber 513 27 33"` 改回 `"timber"`。撤回須正常 assertion exit1、原具名失敗、無 crash/setup ERROR；時限、golden、斷言不變。

結果一律以原 RESULT/receipt 真終態填入；本檔不預寫通過。F0f 舊 W7/H7 及三 helper 的紅燈全保留為歷史原件。F73 沒有重跑完整 W7/H7，尤其兩個真 placed512 的 600秒逾時仍是未解問題；H3 宣告容量通過也不能代替 placed512。完整 native、六 browser、突變帳本、架構與效能均非本輪執行範圍。

本輪 observer v2 在 loadfile 送出前保留當時實體檔案 bytes；該快照不等於子程序一定已讀取。不可回填成舊 F0f 執行時就有的捕捉。

本輪結束後先保真 tool completion、原 source clean guard，再封完整 raw/package。原始 reaper/process exit 與觀察完整性分欄。部分通過不標 READY-TO-MERGE；公開 source/evidence/body 各 SHA 分欄，避免把舊 F0f 或未跑的 final union gate 改綁成 F73。
