from pathlib import Path
import ast, difflib, hashlib, json
B=Path('/workspace/geo348-F73-sentinel-resume-tools-20261024');O=Path('/workspace/train337-canvas-peer-resume');checks=0;findings=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(v,n):
 global checks
 checks+=1
 if not v:findings.append(n)
def functions(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
pins={'run_formal.py':'1d2accf8e1ba2be0cdfb2a13d07b450123dacde780fcbed317640a3eac917cd5','launch_formal.py':'86e8a1c9fc334e383898cddd1b5a0dbc919236f301a6e6f6d670286ff197ac52','collect_originals_with_resume.py':'33e39ecbdf07a402760798c59b6a9a1e807567ec1c430245b8b089bddb200729'}
for n,p in pins.items():ck(h(B/n)==p,'fixed tool '+n)
old=(B/'run_formal.original.py.txt').read_text();new=(B/'run_formal.py').read_text();a=functions(old);b=functions(new)
for n in a:
 if n!='main':ck(a[n]==b[n],'unchanged exact function AST '+n)
ck(new[new.index('  fix_after='):new.index('  report[\'accepted\']')]==old[old.index('  fix_after='):old.index('  report[\'accepted\']')],'unchanged entire original sentinel triple and restoration')
for phrase in ["MIN_FREE=100*1024*1024","fcntl.LOCK_EX|fcntl.LOCK_NB","(16*1024*1024,before_stack[1])","timeout=None","'full_H7_executed':False","'unfixed_512_methods_rerun':False","'prior_ten_phases_rerun':False","len(report['phases'])==3"]:ck(phrase in new,'preserved scope/guard '+phrase)
ck('affected=[' not in new and 'methods={' not in new,'completed first ten phase calls removed')
prior=Path('/workspace/geo348-F73b21e64-formal/RESULT.json');r=json.loads(prior.read_bytes())
ck(h(prior)=='23119c194be860059362672980d984c805838f5227c83788c3d2522b7fbc29c0','original immutable prior result')
ck(r['source_sha']=='73b21e64dce72f0d16ca29e18559c51815b9724d' and r['exit_code']==1 and r['source_clean_after'] is True and r['errors']==[],'original sameF environment terminal1')
ck(len(r['phases'])==13 and all(p['passed'] for p in r['phases'][:10]),'original first ten complete accepted')
ck(all(p['state']=='UNRUN_ENVIRONMENT' and p['reason']=='original100MiB disk guard' for p in r['phases'][10:]),'only last three originally environmental unrun')
launch=(B/'launch_formal.py').read_text();lo=(B/'launch_formal.original.py.txt').read_text()
normalized=launch.replace('geo348-F73b21e64-sentinel-resume-launch','geo348-F73b21e64-formal-launch').replace('geo348-F73-sentinel-resume-tools-20261024','geo348-F73-partial-tools-20261024').replace(pins['run_formal.py'],'07cbcac3f82b7349174db226485da13250199b06717eb7efffc10d6e7bdfd171').replace('geo348-F73-environment-only-sentinel-resume-top-launch/1','geo348-F73-affected-H3-original-controls-top-launch/1').replace('only original three sentinel-fix phases blocked by100MiB guard; prior ten phases not rerun','affected H3 then three original helper triples then sentinel fix triple')
ck(normalized==lo,'outer exact original bytes after path/pin/scope literals only')
c=(B/'collect_originals_with_resume.py').read_text();co=(B/'collect_originals_with_resume.original.py.txt').read_text()
ck(h(B/'collect_originals_with_resume.original.py.txt')=='ac0766dc6c6d5ef651ee57e070b1cb00fbc1533431f08d6588de15f234fed1a6','original accepted collector bytes')
ca=functions(co);cb=functions(c)
for n in ca:
 if n!='main':ck(ca[n]==cb[n],'collector unchanged helper '+n)
start=" with tarfile.open(archive,'w:gz',compresslevel=6) as tf:"
end=" summary={"
ck(c[c.index(start):c.index(end)]==co[co.index(start):co.index(end)],'exact tar/inventory/complete byte roundtrip original code')
ck("'sentinel-resume':RESUME" in c and "'sentinel-resume-outer':RESUME_LAUNCH" in c and "'sentinel-resume-tools':Path(__file__).resolve().parent" in c,'three additional original roots only')
ck("sha((R/'RESULT.json').read_bytes())==resume['prior_partial_sha256']=='23119c194be860059362672980d984c805838f5227c83788c3d2522b7fbc29c0'" in c,'fixed immutable original-to-resume linkage')
ck("resume_outer['primary_returncode']==resume['exit_code']" in c and "resume_outer['launcher_exit']==resume['exit_code']" in c and "not resume_outer['metadata_problems']" in c,'true resume terminal outer exit enforced')
ck("original_partial_exit=result['exit_code']" in c and "environment_resume_exit=resume['exit_code']" in c and 'aggregate' not in c,'original partial1 separate from resume; no invented aggregate0')
ck("free>=50*1024*1024" in c,'unchanged packaging guard')
result={'schema':'geo348-environment-only-resume-tools-static-peer/1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'pins':pins,'original_result_sha256':h(prior),'limitations':['Static tools review only; no C, subject, performance or package collection run by reviewer.','Original partial batch exit1 and final-three UNRUN_ENVIRONMENT retained; only same-source final three selected.','Resume actual outputs separately reviewed by another agent, not credited by this static report.','Two unresolved 512-load timeout methods and full native/browser/ledger/architecture remain outside this partial receipt.']}
q=O/'GEO348_SENTINEL_RESUME_TOOLS_STATIC_PEER.json';q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':result['exit_code'],'findings':findings}));raise SystemExit(result['exit_code'])
