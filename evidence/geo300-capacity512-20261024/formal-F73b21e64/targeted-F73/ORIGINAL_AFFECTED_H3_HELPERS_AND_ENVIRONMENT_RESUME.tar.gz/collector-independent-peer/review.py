from pathlib import Path
import ast,hashlib,json,datetime
B=Path('/workspace/geo300-capacity512-h-pipe-capture-v2-20261024');OLD=Path('/workspace/geo300-capacity512-h-pipe-capture-20261024');O=Path(__file__).resolve().parent;checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,v):checks.append({'check':n,'passed':bool(v)})
pins=json.loads((B/'TOOL_PINS.json').read_bytes());summary=json.loads((B/'SELFTEST_SUMMARY.json').read_bytes())
ck('pins_final',sha((B/'TOOL_PINS.json').read_bytes())=='c922d920d196103a4a308f4636c3df59da8954b6fd8777431262d4d181417b76')
ck('summary_final',sha((B/'SELFTEST_SUMMARY.json').read_bytes())==pins['selftest_summary_sha256']=='94bd8812b4ef1a4a21efae6e3bbba37b5b6b0f2fdab9f475e7bccd8789eba2be')
for name,pin in pins['files'].items():
 raw=(B/name).read_bytes();ck('pin_'+name,sha(raw)==pin)
 if name.endswith('.py'):ast.parse(raw);ck('syntax_'+name,True)
for name in ('observe_bridge_bytes.py','retain_native_inputs.py','selftest_original_entry.py'):ck('v1_bytes_'+name,(B/name).read_bytes()==(OLD/name).read_bytes())
entry=(OLD/'run_observed_original.py').read_text().replace('from observe_bridge_bytes import Observer, error_record, sha, write_json','from observe_bridge_bytes import error_record, sha, write_json\nfrom retain_loadfile_inputs import FixtureObserver as Observer').replace("('observe_bridge_bytes.py','retain_native_inputs.py','run_observed_original.py')","('observe_bridge_bytes.py','retain_native_inputs.py','retain_loadfile_inputs.py','run_observed_original.py')")
ck('entry_only_subclass_and_toolpin',entry==(B/'run_observed_original.py').read_text())
s=(B/'retain_loadfile_inputs.py').read_text();readme=(B/'README.md').read_text()
ck('original_pipeline_subclass','class FixtureObserver(Observer)'in s and 'super().install_class(cls)'in s and 'super().install_run()'in s)
ck('no_rewrite_input_or_timeout','return original_command(session, *args, **kwargs)'in s and 'return original_run(*args, **kwargs)'in s)
ck('snapshot_before_original',s.index('self.safe(lambda: self.capture_loadfiles(payload')<s.index('return original_command(session'))
ck('read_only_nonblocking_nofollow','os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK'in s)
ck('root_private_scope','resolved.is_relative_to(self.root) or resolved.is_relative_to(self.fixture_private)'in s)
ck('regular_files_only','stat.S_ISREG(before.st_mode)'in s and 'stat.S_ISREG(opened.st_mode)'in s)
ck('file_identity_before_open_after','stat_record(opened) != stat_record(before)'in s and 'stat_record(before) != stat_record(after_path)'in s and 'len(body) != before.st_size'in s)
ck('missing_not_predicted',"status='absent-before-original-call', child_result_not_predicted=True"in s)
ck('literal_path_remainder',"line[len(b'loadfile '):]"in s and 'os.fsdecode(path_bytes)'in s)
ck('NUL_long_incomplete',"len(original_line) >= 4095"in s and "row['complete'] = False"in s and "'unsupported-NUL-or-overlong-command'"in s)
ck('preserve_bytes_addressed',"target.write_bytes(body)"in s and "sha(target.read_bytes()) != digest"in s)
ck('snapshot_failure_original_still_called','self.errors.append'in s and 'self.safe(lambda: self.capture_loadfiles'in s)
ck('not_child_consumption','child_consumption_not_proven=True'in s and '不是 child 已執行'in readme)
ck('functional_not_performance','不能充當效能量測工具'in readme)
ck('v1_not_backdated','不能由這個新工具追認成事前捕捉'in readme)
for name in ('fixture-selftest-r1-launch','pipes-selftest-r1-launch','entry-selftest-r1-launch'):
 r=json.loads((B/name/'RESULT.json').read_bytes());ck('outer0_'+name,r['actual_exit']==0);ck('raw_present_'+name,(B/name/'stdout.bin').is_file() and (B/name/'stderr.bin').is_file())
f=json.loads((B/'selftest-fixtures-r1/RESULT.json').read_bytes());ck('26_original_fixture_checks',f['checks']==len(f['details'])==26 and f['exit_code']==0 and not f['failures'] and all(x['passed']for x in f['details']))
p=json.loads((B/'selftest-pipes-r1/SELFTEST.json').read_bytes());ck('20_original_pipe_run_unit',len(p['bridge_cases'])==12 and len(p['run_cases'])==4 and len(p['unit_cases'])==4 and all(x['equal_original_semantics']and x['raw_bytes_exact']for x in p['bridge_cases']) and all(x['passed']for x in p['unit_cases']))
e=json.loads((B/'selftest-entry-r1/SELFTEST.json').read_bytes());ck('4_original_entry_exits',e['passed'] and [x['actual_exit']for x in e['cases']]==[1,0,1,2])
cf=json.loads((B/'fixture-counterfactual/RESULT.json').read_bytes());ck('counterfactual_summary_pin',sha((B/'fixture-counterfactual/RESULT.json').read_bytes())==summary['fixture_counterfactual']['result_sha256']);ck('counterfactual_0_1_0',[x['actual_exit']for x in cf['phases']]==[0,1,0] and cf['passed'] and cf['exit_code']==0)
for x in cf['phases']:
 q=B/'fixture-counterfactual'/(x['phase']+'-launch');r=json.loads((q/'RESULT.json').read_bytes());ck('phase_original_'+x['phase'],r==x);ck('phase_streams_'+x['phase'],sha((q/'stdout.bin').read_bytes())==x['stdout_sha256'] and sha((q/'stderr.bin').read_bytes())==x['stderr_sha256'])
negative=(B/'fixture-counterfactual/withdrawn-launch/stderr.bin').read_text();ck('exact_negative_assertion','AssertionError: actual input bytes including NUL preserved'in negative and 'SyntaxError'not in negative)
f=(B/'fixture-counterfactual/fixed-retain_loadfile_inputs.py.txt').read_bytes();n=(B/'fixture-counterfactual/withdrawn-retain_loadfile_inputs.py.txt').read_bytes();r=(B/'fixture-counterfactual/restored-retain_loadfile_inputs.py.txt').read_bytes();ck('withdrawal_only_payload',f==r==(B/'retain_loadfile_inputs.py').read_bytes() and n==f.replace(b'target.write_bytes(body)',b"target.write_bytes(b'')") and f.count(b'target.write_bytes(body)')==1)
for path in sorted((B/'selftest-fixtures-r1').rglob('SNAPSHOTS.json')):
 data=json.loads(path.read_bytes())
 for i,event in enumerate(data['events']):
  for j,ref in enumerate(event['references']):
   if ref['captured']:
    raw=Path(ref['retained']).read_bytes();ck('retained_'+path.parent.parent.name+'_'+str(i)+'_'+str(j),len(raw)==ref['bytes'] and sha(raw)==ref['sha256'] and ref['snapshot_before_original_call'] and ref['child_consumption_not_proven'])
report={'role':'Final v2 observer static and existing small-raw review; no selftest/C/product rerun','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pins_sha256':sha((B/'TOOL_PINS.json').read_bytes()),'checks':checks,'passed':sum(x['passed']for x in checks),'failed':sum(not x['passed']for x in checks),'limitations':['Ordinary controlled source/private TMP fixture paths only; no claim to withstand malicious concurrent parent-directory replacement between path resolution and opening.','Snapshot proves pre-call retained bytes, not child consumption; batched loadfile commands may not be reached.','Additional reads affect file cache, so this observer cannot be used for the performance lane.','Existing 26+20+4 and0/1/0 records were inspected, not rerun. Complete next product run/package still needs original-source/exit/output verification.','Previous F0f evidence remains the original v1 capture and point-in-time supplements; v2 does not retroactively fill its missing fixture bytes.']}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'failed':report['failed'],'sha256':sha((O/'REVIEW.json').read_bytes())}));raise SystemExit(bool(report['failed']))
