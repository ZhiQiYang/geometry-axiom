#!/usr/bin/env python3
import ast,hashlib,json
from pathlib import Path
B=Path('/workspace/geo348-F73-partial-tools-20261024');A=Path('/workspace/geo348-formal-tools-20261024');P=Path('/workspace/train337-canvas-peer-resume')
checks=[]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,n):checks.append({'check':n,'passed':bool(v)})
mp=B/'TOOL_CHANGES.json';m=json.loads(mp.read_text());need(h(mp)=='299f1f6a43537c0fca662e8be5d1423f94d3a018db6ef634040c9fc5f3d208fc','fixed exact edit manifest')
for name,meta in m['files'].items():
 before=(A/name).read_text();after=(B/name).read_text();expected=before
 for edit in meta['edits']:
  need(expected.count(edit['before'])==edit['count'],'exact change count '+name+' '+edit['before'][:45]);expected=expected.replace(edit['before'],edit['after'])
 need(expected==after,'no unlisted changes '+name);need(h(B/name)==meta['sha256'],'frozen candidate pin '+name);ast.parse(after)
s=(B/'run_formal.py').read_text();a=ast.parse(s)
main=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name=='main')
values={}
for n in ast.walk(main):
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('affected','methods'):
  values[n.targets[0].id]=ast.literal_eval(n.value)
need(values['affected']==['test_each_real_declaration_retains_legacy_64_and_admits_up_to_512','test_full_capacity_redeclaration_replay_and_rejected_edit_preserve_history','test_real_bridge_guard_withdrawal_uses_safe_incomplete_declaration_then_restores'],'exact three affected methods only')
need(set(values['methods'])=={'count','population','unplaced_replay'},'exact three existing helper triples')
need(1+3*len(values['methods'])+3==13 and "len(report['phases'])==13 and all(x['passed'] for x in report['phases'])" in s,'13 required phases and all must pass')
need("'full_H7_executed':False,'unfixed_512_methods_rerun':False" in s,'no full-H7 or512 rerun claim')
need("MIN_FREE=100*1024*1024" in s and "(16*1024*1024,before_stack[1])" in s,'original100MiB and16MiB stack unchanged')
need("lock=Path('/tmp/g261r3/secondary.lock')" in s and 'fcntl.LOCK_EX|fcntl.LOCK_NB' in s,'exclusive secondary correctness lease')
need("TMP=Path('/workspace/geo348-F73b21e64-formal-tmp')" in s and 'TMPDIR=str(TMP)' in s,'fresh private temp not global cache')
need("'48bf7a7cacc8f3de143a1903210b14ad43aa17d8bf69edcda71e6e94419613cc'" in s,'original exact helper withdrawals pinned')
need("fix_after=b'INCOMPLETE_DECLARATION=\"timber 513 27 33\"';fix_before=b'INCOMPLETE_DECLARATION=\"timber\"'" in s,'only accepted safe sentinel fix removed/restored')
need("'sentinel_fix':['host-capacity-first-incomplete-declaration']" in s,'specific product assertion required for sentinel kill')
need("'FAILED (failures=1)' in text and 'AssertionError:' in text and 'ERROR:' not in text and 'skipped=' not in text" in s,'negative rejects errors skips or multiple failures')
need("r'^Ran '+str(count)+r' tests? in '" in s and "r'^OK$'" in s,'normal methods count3/1 and exact OK')
need("'do not overwrite unexpected sentinel drift');(ROOT/HOST).write_bytes(original)" in s and "'do not overwrite unexpected helper drift');(ROOT/HOST).write_bytes(original)" in s,'both withdrawal scopes exact finally restore')
need("observed['observer_complete'] is True and terminal['observer_complete'] is True" in s and "terminal['original_exit']==row['actual_process_returncode']" in s,'complete observer and true original exit mandatory')
need("terminal['source_files_before']==terminal['source_files_after']==files" in s,'all source bytes bound before after each phase')
need("source_guard('restored',original);report['source_clean_after']=True" in s,'whole final source clean guard')
need('check=False,timeout=None' in s,'original exits captured without new wrapper timeout')
obs=Path('/workspace/geo300-capacity512-h-pipe-capture-v2-20261024/TOOL_PINS.json');need(h(obs)=='c922d920d196103a4a308f4636c3df59da8954b6fd8777431262d4d181417b76','accepted observer v2 pins')
for f,pin in json.loads(obs.read_text())['files'].items():need(h(obs.parent/f)==pin,'observer actual file pin '+f)
peer=json.loads(Path('/workspace/geo348-h-v2-peer-specials-20261024/REVIEW.json').read_text());need(peer.get('passed')==59 and all(x.get('passed') for x in peer['checks']),'observer independent59 checks')
need("timeout=None" in (B/'launch_formal.py').read_text() and "7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760" in (B/'launch_formal.py').read_text(),'original reaper and no new outer deadline')
failed=[x['check'] for x in checks if not x['passed']];o=P/'GEO348_F73_PARTIAL_TOOLS_STATIC_PEER.json';o.write_text(json.dumps({'scope':'Exact partial H3+9 helper phases+3 sentinel phases wrapper static review','source_sha':m['source_sha'],'checks':len(checks),'exit_code':int(bool(failed)),'findings':failed,'tools':{k:v['sha256'] for k,v in m['files'].items()},'limitations':['No preparation, C compile or subject execution; genuine source preparation and source guard still required.','Unfixed two512/600s methods remain previous failures and are not accepted by this partial receipt.','No full native/browser/ledger/architecture credit.','Original600s assertions live in unchanged original selected methods; wrapper has no new timeout.'],'check_details':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(o),'sha256':h(o),'checks':len(checks),'exit_code':int(bool(failed)),'findings':failed}));raise SystemExit(bool(failed))
