"""Archive the terminal affected H3 and original controls, including reds; never rerun or repair."""
from pathlib import Path
import datetime,hashlib,io,json,os,shutil,stat,tarfile
S='73b21e64dce72f0d16ca29e18559c51815b9724d'
R=Path('/workspace/geo348-F73b21e64-formal');L=Path('/workspace/geo348-F73b21e64-formal-launch')
O=Path('/workspace/geo348-F73b21e64-formal-with-resume-package-r2');HERE=Path('/workspace/geo348-F73-partial-tools-20261024');RESUME=Path('/workspace/geo348-F73b21e64-sentinel-resume');RESUME_LAUNCH=Path('/workspace/geo348-F73b21e64-sentinel-resume-launch')
roots={'original-packaging-rejection':Path('/workspace/geo348-F73b21e64-formal-with-resume-package'),'partial-actual-independent-peer':Path('/workspace/geo348-F73-partial-actual-peer-backlog-20261024'),'formal':R,'outer':L,'sentinel-resume':RESUME,'sentinel-resume-outer':RESUME_LAUNCH,'sentinel-resume-tools':Path(__file__).resolve().parent,'source-preparation':Path('/workspace/geo348-F73b21e64-preparation'),
 'formal-tools':HERE,'collector-tools-and-selftests':Path('/workspace/geo300-capacity512-h-pipe-capture-v2-20261024'),
 'collector-independent-peer':Path('/workspace/geo348-h-v2-peer-specials-20261024')}
# Only these four small files from the shared reviewer directory, never its other lanes.
individual={
 'partial-tools-peer/REVIEW.json':Path('/workspace/train337-canvas-peer-resume/GEO348_F73_PARTIAL_TOOLS_STATIC_PEER.json'),
 'partial-tools-peer/review.py':Path('/workspace/train337-canvas-peer-resume/review_geo348_F73_partial_tools.py'),
 'preparation-actual-peer/REVIEW.json':Path('/workspace/train337-canvas-peer-resume/GEO348_F73_PREPARATION_ACTUAL_PEER.json'),
 'preparation-actual-peer/review.py':Path('/workspace/train337-canvas-peer-resume/review_geo348_F73_preparation.py'),
 'resume-tools-static-peer/REVIEW.json':Path('/workspace/train337-canvas-peer-resume/GEO348_SENTINEL_RESUME_TOOLS_STATIC_PEER.json'),
 'resume-tools-static-peer/review.py':Path('/workspace/train337-canvas-peer-resume/review_geo348_sentinel_resume.py')}

def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def read(p):return json.loads(p.read_bytes())
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
 need(not O.exists(),'fresh package only')
 result=read(R/'RESULT.json');outer=read(L/'receipt.json')
 need(result['source_sha']==S and type(result['exit_code'])is int,'original formal terminal SHA/exit')
 need(outer['source']==S and outer['primary_returncode']==result['exit_code'] and outer['launcher_exit']==result['exit_code'] and not outer['metadata_problems'],'original outer/primary/reaper same real terminal')
 resume=read(RESUME/'RESULT.json');resume_outer=read(RESUME_LAUNCH/'receipt.json')
 need(resume['source_sha']==S and type(resume['exit_code'])is int,'resume exact same source and true terminal')
 need(resume_outer['source']==S and resume_outer['primary_returncode']==resume['exit_code'] and resume_outer['launcher_exit']==resume['exit_code'] and not resume_outer['metadata_problems'],'resume true original outer terminal')
 need(sha((R/'RESULT.json').read_bytes())==resume['prior_partial_sha256']=='23119c194be860059362672980d984c805838f5227c83788c3d2522b7fbc29c0','immutable original environment receipt linkage')
 need(shutil.disk_usage('/workspace').free>=50*1024*1024,'small packaging resource guard; no product threshold')
 special_file=Path('/workspace/geo348-F73-sentinel-resume-tools-20261024/V2_SELFTEST_SPECIAL_FIXTURES.json');need(sha(special_file.read_bytes())=='88c148644f0db9f3f14492b638b4f9c3b477e5a6e6510610be3cb384ee4e96eb','fixed six intentional selftest special fixtures');special_rows=read(special_file);expected_special={r['path']:r for r in special_rows};need(len(special_rows)==len(expected_special)==6 and sum(r['kind']=='symlink'for r in special_rows)==sum(r['kind']=='fifo'for r in special_rows)==3,'exact three links and three FIFOs only');special_seen={}
 O.mkdir();items={}
 for prefix,root in roots.items():
  need(root.is_dir(),'missing original root '+str(root))
  for p in sorted(root.rglob('*')):
   st=p.lstat()
   if stat.S_ISDIR(st.st_mode):continue
   if stat.S_ISREG(st.st_mode):
    name=prefix+'/'+str(p.relative_to(root));need(name not in items,'duplicate archive name');items[name]=p
   else:
    need(prefix=='collector-tools-and-selftests' and str(p) in expected_special,'unexpected nonregular original entry '+str(p))
    expected=expected_special[str(p)];kind='symlink'if stat.S_ISLNK(st.st_mode)else'fifo'if stat.S_ISFIFO(st.st_mode)else'other'
    need(kind==expected['kind']and st.st_mode==expected['mode'],'intentional fixture kind/mode changed')
    link=os.readlink(os.fsencode(p))if kind=='symlink'else None
    need(link==(os.fsencode(expected['link_target'])if kind=='symlink'else None),'intentional symlink original target changed')
    special_seen[str(p)]={'original_path':str(p),'original_kind':kind,'mode':st.st_mode,'readlink_bytes_hex':None if link is None else link.hex(),'representation':'Metadata only; symlink target never followed and FIFO stream never opened.'}
 need(set(special_seen)==set(expected_special),'all six intentional special fixtures represented')
 descriptor=O/'SPECIAL_FIXTURE_ENTRIES.json';dump(descriptor,{'entries':[special_seen[k]for k in sorted(special_seen)],'not_claimed':'No symlink target content or FIFO byte stream is represented as a regular original file.'});items['selftest-special-fixture-metadata/SPECIAL_FIXTURE_ENTRIES.json']=descriptor
 for name,p in individual.items():
  need(p.is_file() and not p.is_symlink(),'required original peer '+str(p));need(name not in items,'duplicate individual');items[name]=p
 # No workspace checkout, Git objects, NativeBuild temp ELF, or existing archive payloads.
 need(all(p.read_bytes()[:4]!=b'\x7fELF' for p in items.values()),'scope contains metadata/source/streams, no transient ELF')
 archive=O/'ORIGINAL_AFFECTED_H3_HELPERS_AND_ENVIRONMENT_RESUME.tar.gz';rows=[]
 with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
  for name,p in sorted(items.items()):
   raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw));rows.append({'member':name,'source':str(p),'bytes':len(raw),'sha256':sha(raw)})
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();need(len(members)==len(rows),'roundtrip count')
  for row,member in zip(rows,members):
   raw=tf.extractfile(member).read();need(member.name==row['member'] and sha(raw)==row['sha256'] and raw==Path(row['source']).read_bytes(),'roundtrip original mismatch '+row['member'])
 index={'source_sha':S,'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'member_count':len(rows),'files':rows};dump(O/'RAW_INDEX.json',index)
 summary={k:v for k,v in index.items()if k!='files'};summary.update(original_exit=result['exit_code'],original_accepted=result['accepted'],source_clean_after=result['source_clean_after'],phases=[{k:p.get(k)for k in ('label','variant','state','actual_exit','passed','observation_complete')}for p in result['phases']],roundtrip_all_bytes_equal=True,original_bytes=sum(x['bytes']for x in rows),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['Only affected original H3, three helper triples and sentinel-fix triple; not full W7/H7, either unresolved512 method, native/browser/ledger/architecture or performance.','Original compiler text=True outputs retain decoded-text representation; original binary run/Bridge pipes captured before decoding.','Original subprocess TimeoutExpired may have no CompletedProcess returncode or output; do not invent a child exit.','V2 fixture observer captures actual loadfile input bytes before command send; this is not proof the child consumed those bytes. No old F0f fixture is retroactively reconstructed.','Original NativeBuild cleanup retained unchanged; source/command/ELF hashes are not retained ELF payloads.'])
 summary.update(original_partial_exit=result['exit_code'],original_partial_accepted=result['accepted'],environment_resume_exit=resume['exit_code'],environment_resume_accepted=resume['accepted'],environment_resume_phases=[{k:p.get(k)for k in ('label','variant','state','actual_exit','passed','observation_complete')}for p in resume['phases']],environment_resume_source_clean=resume['source_clean_after'])
 summary['limits'].append('The original13-phase batch retains exit1 with last3 ENV_UNRUN; separate sameF resume runs only those3. This package does not rewrite the original exit or rerun the first10.')
 summary['intentional_selftest_special_entries']={'count':6,'symlinks':3,'fifos':3,'descriptor_member':'selftest-special-fixture-metadata/SPECIAL_FIXTURE_ENTRIES.json','representation':'Exact readlink bytes in hex and original lstat kind/mode, no follow/no stream read.'}
 summary['limits'].append('The v2 rejection selftests deliberately contain three symlink and three FIFO fixtures. These six entries are represented as explicit metadata, while all regular source/raw files preserve exact original bytes. The initial strict-symlink packaging rejection remains archived.')
 dump(O/'SUMMARY.json',summary);print(json.dumps({k:summary[k]for k in ['source_sha','original_exit','member_count','archive_bytes','archive_sha256']}))
if __name__=='__main__':main()
