# #344 真完整 canvas 三態（準備，未執行）

產品S7b，撤回proof-variant V082f（單親S、唯一app clearline撤回，其餘所有blob/mode同），恢復S。V已普通push且可解析；不能把V當S或正式acceptance SHA。原driver clean-head/status validator整段不改，不用dirty checkout前置78冒kill。

三個副本相對57f3原driver只有HTTP埠、CDP/profile環境及其收據可見性機械差異，PORT_PATH_BINDING.diff全列。HTTP19681/2/3，CDP9731/2/3，每phase獨立scratch/TMP/profile；原job canvas、default全套、35min/3倍只收集、workflow/golden/斷言/時限全保，無selector與額外skip。flock heavy＋scratch原鎖均保，root仍必獨占排程。

真正source/fixtures/runtime/ELF/disk尚未物化，REQUEST裡repo明確placeholder，不是可立即跑的完整checkout。不能用目前五檔薄source硬跑missingfiles，不動root L，不把root L綠轉標本件。先peer本窄diff，再由root原preparer固定完整私有source與預算，記全原streams/exit/env/SHA後才run。

fixed/restored需完整matched；V需三具名stale-error正常assert，且全部原協定／dump／source／1600等診斷正確。原sectionPass下降的golden mismatch是衍生證據，不新增總fail門檻，也不能以fatal/前置/timeout代kill。Node9 VM只維持原VM身份。
