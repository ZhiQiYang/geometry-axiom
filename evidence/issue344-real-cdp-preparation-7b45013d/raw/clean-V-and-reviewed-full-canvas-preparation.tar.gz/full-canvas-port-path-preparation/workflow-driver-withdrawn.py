#!/usr/bin/env python3
"""逐項執行固定 GEO-261 SHA 的原 workflow；不重跑、不豁免失敗。"""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import fcntl
import glob
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import selectors
import shlex
import shutil
import signal
import subprocess
import sys
import time
import traceback

import yaml

REPO = None
SHA = None
ENV_ROOT = Path('/workspace/geo261-environment')
CHROME = ENV_ROOT / 'bin/google-chrome'
ORDER = ['native', 'canvas', 'assembly', 'documents', 'grid', 'space', 'timber']
WORKFLOW = '.github/workflows/integration-tests.yml'
SCHEMA = 'geo261-cloud-workflow/1'


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def simple(argv, *, cwd=None, env=None):
    result = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    if result.returncode:
        raise RuntimeError('前置指令失敗：' + shlex.join(map(str, argv)) + '\n' +
                           result.stderr.decode('utf-8', 'replace'))
    return result.stdout


def checkout_state():
    return {
        'head': simple(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip(),
        'root': simple(['git', 'rev-parse', '--show-toplevel'], cwd=REPO).decode().strip(),
        'status': simple(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=REPO).decode('utf-8', 'replace'),
    }


def validate_checkout(state):
    if state['head'] != SHA or Path(state['root']).resolve() != REPO.resolve() or state['status']:
        raise RuntimeError('固定 SHA 或乾淨工作樹檢查失敗：' + json.dumps(state, ensure_ascii=False))


def matrix_substitute(value, matrix):
    def replace(match):
        expression = match.group(1).strip()
        key = re.fullmatch(r'matrix\.(\w+)', expression)
        if not key or key[1] not in matrix:
            raise RuntimeError('不支援的 workflow 運算式：' + expression)
        return str(matrix[key[1]])
    return re.sub(r'\$\{\{(.*?)\}\}', replace, str(value))


def mechanically_rewrite(value, tmp, port):
    value = re.sub(r'(?<![\w/.\-])/tmp/', str(tmp) + '/', value)
    return re.sub(r'(?<!\d)18839(?!\d)', str(port), value)


def condition_applies(expression, matrix):
    if expression is None:
        return True
    expression = str(expression).strip()
    expression = re.sub(r"matrix\.(\w+)\s*==\s*'([^']*)'",
                        lambda m: str(str(matrix.get(m[1])) == m[2]), expression)
    expression = expression.replace('always()', 'True').replace('success()', 'True')
    expression = expression.replace('&&', ' and ').replace('||', ' or ')
    tree = ast.parse(expression, mode='eval')
    if any(not isinstance(node, (ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.Constant))
           for node in ast.walk(tree)):
        raise RuntimeError('不支援的 workflow 條件：' + str(expression))
    return bool(eval(compile(tree, '<workflow-condition>', 'eval'), {'__builtins__': {}}, {}))


def kill_owned_group(pid):
    try:
        os.killpg(pid, signal.SIGTERM)
    except ProcessLookupError:
        return False
    time.sleep(0.15)
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return True


def capture(argv, prefix, *, cwd, env, timeout):
    """分開保留原始串流；combined 只作閱讀用，不取代原始 stdout/stderr。"""
    prefix.parent.mkdir(parents=True, exist_ok=True)
    started, start = now(), time.monotonic()
    record = {'command': list(map(str, argv)), 'cwd': str(cwd), 'started': started,
              'stdout': str(prefix) + '.stdout', 'stderr': str(prefix) + '.stderr',
              'combined': str(prefix) + '.combined.log', 'timeout_seconds': timeout}
    timed_out = False
    cleaned = False
    process = None
    try:
        with open(record['stdout'], 'wb') as stdout, open(record['stderr'], 'wb') as stderr, \
                open(record['combined'], 'wb') as combined:
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       start_new_session=True)
            selector = selectors.DefaultSelector()
            selector.register(process.stdout, selectors.EVENT_READ, stdout)
            selector.register(process.stderr, selectors.EVENT_READ, stderr)
            try:
                while selector.get_map():
                    if time.monotonic() - start >= timeout and process.poll() is None:
                        timed_out = True
                        cleaned = kill_owned_group(process.pid) or cleaned
                    if process.poll() is not None and not cleaned:
                        cleaned = kill_owned_group(process.pid)
                    for key, _ in selector.select(timeout=0.2):
                        chunk = os.read(key.fileobj.fileno(), 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                        else:
                            key.data.write(chunk)
                            key.data.flush()
                            combined.write(chunk)
                            combined.flush()
                actual = process.wait()
            finally:
                selector.close()
    except BaseException:
        if process is not None:
            kill_owned_group(process.pid)
            process.wait()
        raise
    record.update(ended=now(), seconds=time.monotonic() - start,
                  actual_process_returncode=actual, exit_code=124 if timed_out else actual,
                  watchdog_expired=timed_out, owned_process_group_cleanup=cleaned)
    write_json(Path(str(prefix) + '.command.json'), record)
    return record


def file_inventory(root):
    result = {}
    if root.is_dir():
        for path in sorted(root.rglob('*')):
            if path.is_file() and not path.is_symlink():
                raw = path.read_bytes()
                result[str(path.relative_to(root))] = {
                    'bytes': len(raw), 'sha256': sha256(raw), 'mtime_ns': path.stat().st_mtime_ns,
                }
    return result


def copy_safe(source, destination, permitted_root):
    if not source.resolve().is_relative_to(permitted_root.resolve()):
        raise RuntimeError('拒絕收集越界的產物：' + str(source))
    if source.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        for child in source.iterdir():
            copy_safe(child, destination / child.name, permitted_root)
    elif source.is_file():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def installed_packages(run, prefix, env):
    lines = [line.strip() for line in run.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    if not lines or any('apt-get' not in line for line in lines):
        raise RuntimeError('套件步驟混有其他操作，拒絕推定已完成')
    packages = []
    for line in lines:
        if re.search(r'\binstall\b', line):
            packages.extend(word for word in shlex.split(line.split('install', 1)[1]) if not word.startswith('-'))
    if not packages:
        raise RuntimeError('套件步驟沒有可辨識的安裝清單')
    checks = []
    for index, package in enumerate(packages):
        row = capture(['dpkg-query', '-W', '-f=${Status} ${Version}\n', package],
                      prefix.with_name(prefix.name + '-package-' + str(index)),
                      cwd=REPO, env=env, timeout=30)
        checks.append(row)
        if row['exit_code'] != 0 or not Path(row['stdout']).read_text().startswith('install ok installed '):
            raise RuntimeError('必要套件尚未安裝：' + package)
    return packages, checks


def execute(args, out, scratch):
    started, start = now(), time.monotonic()
    tmp = scratch / 'tmp' / out.parent.name / args.job
    tmp.mkdir(parents=True, exist_ok=False)
    port = 19681 + ORDER.index(args.job)
    state = checkout_state()
    validate_checkout(state)
    raw = simple(['git', 'show', SHA + ':' + WORKFLOW], cwd=REPO)
    (out / 'workflow.yml.txt').write_bytes(raw)
    driver = Path(__file__).read_bytes()
    (out / 'driver.py.txt').write_bytes(driver)
    workflow = yaml.safe_load(raw)
    if args.job == 'native':
        key, job, matrix = 'native', workflow['jobs']['native'], {}
    else:
        key, job = 'browser', workflow['jobs']['browser']
        matrix = next(item for item in job['strategy']['matrix']['include'] if item['suite'] == args.job)
    limit = int(matrix_substitute(job['timeout-minutes'], matrix))
    deadline = start + limit * 60 * 3
    env = {name: value for name, value in os.environ.items() if not name.startswith('GEOMETRY_')}
    inherited_node = shutil.which('node', path=os.environ.get('PATH'))
    if inherited_node is None:
        raise RuntimeError('繼承的 Node.js 不存在')
    paths = [str(ENV_ROOT / 'bin'), str(Path(inherited_node).parent), *env.get('PATH', '').split(os.pathsep)]
    env['PATH'] = os.pathsep.join(dict.fromkeys(paths))
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8',
               PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(tmp), CI='true', GITHUB_ACTIONS='true',
               RUNNER_OS='Linux', GITHUB_SHA=SHA, GITHUB_WORKSPACE=str(REPO), TERM='dumb',
               XDG_DATA_HOME=str(ENV_ROOT / 'xdg-data'), XDG_CACHE_HOME=str(tmp / 'xdg-cache'), npm_config_cache=str(tmp / 'npm-cache'))
    for name in ('XDG_DATA_HOME', 'XDG_CACHE_HOME'):
        Path(env[name]).mkdir(parents=True, exist_ok=True)
    original_env = {name: matrix_substitute(value, matrix) for name, value in (job.get('env') or {}).items()}
    for name, value in original_env.items():
        env[name] = mechanically_rewrite(value, tmp, port)
    if args.job != 'native':
        env['GEOMETRY_CHROME'] = str(CHROME)
        env['GEOMETRY_SCHEDULE_SCREENSHOT_DIR'] = str(tmp / 'geometry-schedule-screens')
        env['GEOMETRY_CDP_PORT'] = '9732'
        env['GEOMETRY_CHROME_PROFILE'] = str(tmp / 'chrome-profile')
    safe_names = {'PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'TMPDIR',
                  'CI', 'GITHUB_ACTIONS', 'RUNNER_OS', 'GITHUB_SHA', 'GITHUB_WORKSPACE', 'TERM',
                  'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'npm_config_cache', 'GEOMETRY_SCHEDULE_SCREENSHOT_DIR', 'GEOMETRY_CDP_PORT', 'GEOMETRY_CHROME_PROFILE', *original_env}
    receipt = {'schema': SCHEMA, 'sha': SHA, 'job': args.job, 'workflow_job_key': key, 'matrix': matrix,
               'started': started, 'checkout_before': state, 'status': '執行中', 'exit_code': None,
               'workflow_sha256': sha256(raw), 'driver_sha256': sha256(driver),
               'workflow_environment': original_env,
               'environment': {name: env[name] for name in sorted(safe_names) if name in env},
               'cleared_inherited_geometry_names': sorted(name for name in os.environ if name.startswith('GEOMETRY_')),
               'platform': {'platform': platform.platform(), 'machine': platform.machine(),
                            'python_driver': sys.version, 'python_driver_executable': sys.executable,
                            'logical_cpus': os.cpu_count(), 'pyyaml': yaml.__version__},
               'temporary_directory': str(tmp), 'server_port': None if args.job == 'native' else port,
               'ci_timeout_minutes': limit, 'watchdog_factor': 3, 'versions': [], 'steps': [],
               'notes': ['逐項串行，任何失敗都不自動重跑；沒有 flaky 豁免。',
                         '原 run 僅替換矩陣、/tmp 路徑及服務埠；Chrome 路徑另明列環境覆寫。',
                         'stdout/stderr 分別保留原始 bytes；combined 檔只作閱讀。']}
    write_json(out / 'receipt.json', receipt)
    native_logroot = Path('/tmp/geometry-tests/run_all-logs')
    if args.job == 'native':
        write_json(out / 'native-logs-before.json', file_inventory(native_logroot))
    code = 70
    try:
        commands = [['google-chrome', '--version'], ['node', '--version'], ['python3', '--version'],
                    ['cc', '--version'], ['dpkg-query', '-W', '-f=${Status} ${Version}\n', 'fonts-noto-cjk']]
        for index, command in enumerate(commands):
            row = capture(command, out / 'versions' / str(index), cwd=REPO, env=env, timeout=30)
            receipt['versions'].append(row)
            if row['exit_code']:
                raise RuntimeError('環境版本檢查失敗：' + shlex.join(command))
        node = Path(receipt['versions'][1]['stdout']).read_text().strip()
        if not node.startswith('v24.'):
            raise RuntimeError('本次驗收要求 Node 24，實際為：' + node)
        chrome = Path(receipt['versions'][0]['stdout']).read_text().strip()
        if not chrome.startswith('Google Chrome '):
            raise RuntimeError('本次驗收要求 Google Chrome，實際為：' + chrome)
        code = 0
        failed = False
        for index, step in enumerate(job['steps']):
            name = step.get('name') or step.get('uses') or str(index)
            row = {'index': index, 'name': name, 'original_step': step}
            receipt['steps'].append(row)
            prefix = out / 'steps' / f'{index:02d}'
            prefix.parent.mkdir(parents=True, exist_ok=True)
            if 'uses' in step:
                if step['uses'].startswith('actions/checkout'):
                    row['outcome'] = '以現有乾淨固定 SHA checkout 取代，未執行 GitHub action'
                elif step['uses'].startswith('actions/upload-artifact'):
                    row['outcome'] = '未上傳至 GitHub；改為本機保存原產物'
                    row['condition_applies'] = condition_applies(step.get('if'), matrix)
                    copied = []
                    if row['condition_applies']:
                        patterns = mechanically_rewrite(matrix_substitute(step['with']['path'], matrix), tmp, port)
                        for pattern in patterns.splitlines():
                            for item in sorted(glob.glob(pattern)):
                                source = Path(item)
                                destination = out / 'artifacts' / f'{index:02d}' / source.name
                                copy_safe(source, destination, tmp)
                                copied.append(str(destination.relative_to(out)))
                    row['saved_artifacts'] = copied
                else:
                    raise RuntimeError('不支援的 GitHub action：' + step['uses'])
                write_json(out / 'receipt.json', receipt)
                continue
            if failed:
                row['outcome'] = '未執行：先前步驟失敗'
                continue
            if not condition_applies(step.get('if'), matrix):
                row['outcome'] = '未執行：原 workflow 條件不成立'
                continue
            original = step['run']
            run = mechanically_rewrite(matrix_substitute(original, matrix), tmp, port)
            prefix.with_suffix('.original.sh.txt').write_text(original, encoding='utf-8')
            script = prefix.with_suffix('.executed.sh')
            script.write_text(run if run.endswith('\n') else run + '\n', encoding='utf-8')
            row.update(original_run=original, executed_run=run, script_sha256=sha256(script.read_bytes()))
            senv = dict(env)
            for name, value in (step.get('env') or {}).items():
                if not name.startswith('GEOMETRY_'):
                    raise RuntimeError('需明確審查的額外 step 環境名稱：' + name)
                senv[name] = mechanically_rewrite(matrix_substitute(value, matrix), tmp, port)
            print(f'開始 {args.job}：{name}', flush=True)
            if re.search(r'\bsudo\b|\bapt(?:-get)?\b', run):
                packages, checks = installed_packages(run, prefix, senv)
                row.update(outcome='必要套件已安裝；未重複執行原 apt 指令', packages=packages, checks=checks)
            else:
                command = (['bash', '--noprofile', '--norc', '-eo', 'pipefail', str(script)]
                           if step.get('shell') == 'bash' else ['bash', '-e', str(script)])
                result = capture(command, prefix, cwd=REPO, env=senv, timeout=max(1, deadline - time.monotonic()))
                row.update(result=result, outcome='成功' if result['exit_code'] == 0 else '失敗')
                if result['exit_code'] != 0:
                    code = result['exit_code']
                    failed = True
                print(f'結束 {args.job}：{name}；退出碼 {result["exit_code"]}；{result["seconds"]:.1f} 秒', flush=True)
            write_json(out / 'receipt.json', receipt)
        receipt['status'] = '完成' if not failed else '失敗'
    except KeyboardInterrupt:
        code = 130
        receipt['status'] = '中斷'
        receipt['error'] = '收到中斷；未自動重跑。'
    except Exception:
        code = 70
        receipt['status'] = '環境或 driver 受阻'
        receipt['error'] = traceback.format_exc()
        (out / 'driver-error.log').write_text(receipt['error'], encoding='utf-8')
        print('驗收受阻：' + receipt['error'], file=sys.stderr, flush=True)
    finally:
        if args.job == 'native' and native_logroot.is_dir():
            copy_safe(native_logroot, out / 'run_all-logs', Path('/tmp/geometry-tests'))
            write_json(out / 'native-logs-after.json', file_inventory(native_logroot))
        receipt['checkout_after'] = checkout_state()
        try:
            validate_checkout(receipt['checkout_after'])
        except Exception as error:
            receipt['source_integrity_error'] = str(error)
            code = 70
        receipt.update(ended=now(), seconds=time.monotonic() - start, exit_code=code,
                       over_ci_timeout=time.monotonic() - start > limit * 60)
        receipt['files'] = file_inventory(out)
        receipt['files'].pop('receipt.json', None)
        write_json(out / 'receipt.json', receipt)
        (out / 'receipt.sha256').write_text(sha256((out / 'receipt.json').read_bytes()) + '  receipt.json\n')
    print(f'{args.job} 最終退出碼：{code}；收據：{out / "receipt.json"}', flush=True)
    return code


def main():
    global REPO, SHA
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--job', choices=ORDER, required=True)
    parser.add_argument('--out-root', type=Path, required=True)
    args = parser.parse_args()
    REPO, SHA = args.repo.resolve(), args.sha
    if len(SHA) != 40:
        parser.error('必須使用完整受驗 SHA')
    out_root = args.out_root.resolve()
    if not out_root.is_relative_to(Path('/tmp')) or out_root.is_relative_to(REPO):
        parser.error('輸出根目錄必須在 /tmp 且位於 repository 外')
    scratch = out_root.parent
    scratch.mkdir(parents=True, exist_ok=True)
    with (scratch / 'heavy.lock').open('a+b') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('拒絕啟動：本次 scratch 的重型工作鎖已被持有。', file=sys.stderr)
            return 78
        try:
            validate_checkout(checkout_state())
            # 最新使用者規則：前項紅燈不阻擋下一項，順序由外層 round 記錄。
            out = out_root / args.job
            out.mkdir(parents=True, exist_ok=False)
            return execute(args, out, scratch)
        except Exception:
            print('拒絕啟動或前置檢查失敗：' + traceback.format_exc(), file=sys.stderr, flush=True)
            return 78


if __name__ == '__main__':
    raise SystemExit(main())
