"""Create only the explicit single-line clean Git proof variant; no subject run."""
from pathlib import Path
import hashlib, importlib.util, json, os

B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
S = '7b45013da647b791acda8f5977475e4123d5f8c4'
E = 'dfdf88e33e21d9ac06c58af80929a8b7a9b9301f'
BRANCH = 'codex/issue320-connection-recovery-withdrawal-20261024'
O = B / 'controlled-withdrawal-source-publication'
C = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H = lambda b: hashlib.sha256(b).hexdigest()
assert H(C.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not O.exists()
O.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', C)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env.update(PYTHONDONTWRITEBYTECODE='1', LC_ALL='C.UTF-8')
rec = cap.Recorder(O, env, S)
cap.dump(O / 'REQUEST.json', {'productSHA': S, 'productEvidenceHEAD': E, 'variantBranch': BRANCH, 'variantParentExactly': S, 'driverSHA256': H(Path(__file__).read_bytes()), 'scope': 'explicit single app-clear withdrawal Git source only; no Chrome/Node/C/build/test; product worktree untouched', 'rootAuthorization': 'root accepted published clean V to preserve original formal driver clean-SHA guard'})
def run(argv, data=None, check=True):
    return rec.run(argv, cwd=W, timeout=120, data=data, check=check, source_sha=S, source_variant='create-public-clean-controlled-variant; not CDP execution')
_, before, _ = run(['git', 'rev-parse', 'HEAD'])
_, status, _ = run(['git', 'status', '--porcelain=v1', '--untracked-files=all'])
assert before.decode().strip() == E and status == b''
exists, _, _ = run(['git', 'show-ref', '--verify', '--quiet', 'refs/heads/' + BRANCH], check=False)
assert exists['actual_process_returncode'] == 1
_, app, _ = run(['git', 'show', S + ':geometry-web/app.js'])
old = b'    connection.phase = "ready"; connection.known = true; connection.error = "";'
new = b'    connection.phase = "ready"; connection.known = true;'
assert app.count(old) == 1 and H(app) == 'c5f055915a039d90138824248b146552776286beb7544380c279a5586707ab60'
variant_app = app.replace(old, new, 1)
assert H(variant_app) == 'e248c162d4f0da633a0fd3314402af96e0f9c1a05d3224d90f7e5ffcabace7f1'
(O / 'app-original.js.txt').write_bytes(app)
(O / 'app-withdrawn.js.txt').write_bytes(variant_app)
_, blob, _ = run(['git', 'hash-object', '-w', '--stdin'], data=variant_app)
blob = blob.decode().strip()
_, web, _ = run(['git', 'ls-tree', '-z', S + ':geometry-web'])
def replace_tree_entry(raw, name, object_type, new_blob):
    rows = []
    found = 0
    for row in raw.split(b'\0'):
        if not row:
            continue
        info, path = row.split(b'\t', 1)
        mode, kind, oid = info.split()
        if path == name:
            assert kind == object_type
            row = mode + b' ' + kind + b' ' + new_blob.encode() + b'\t' + path
            found += 1
        rows.append(row)
    assert found == 1
    return b'\0'.join(rows) + b'\0'
new_web = replace_tree_entry(web, b'app.js', b'blob', blob)
_, web_tree, _ = run(['git', 'mktree', '-z'], data=new_web)
_, root, _ = run(['git', 'ls-tree', '-z', S])
new_root = replace_tree_entry(root, b'geometry-web', b'tree', web_tree.decode().strip())
_, tree, _ = run(['git', 'mktree', '-z'], data=new_root)
_, variant, _ = run(['git', 'commit-tree', tree.decode().strip(), '-p', S, '-m', 'test: freeze controlled connection error-clear withdrawal'])
V = variant.decode().strip()
_, parent, _ = run(['git', 'show', '--format=%P', '--no-patch', V])
assert parent.decode().strip() == S
_, changed, _ = run(['git', 'diff-tree', '-r', '--raw', '--no-renames', S, V])
changes = changed.decode().splitlines()
assert len(changes) == 1 and changes[0].startswith(':100644 100644 ') and changes[0].endswith('\tgeometry-web/app.js')
_, patch, _ = run(['git', 'diff', '--no-ext-diff', S, V, '--', 'geometry-web/app.js'])
(O / 'WITHDRAW_ONLY_CLEAR.patch').write_bytes(patch)
run(['git', 'update-ref', 'refs/heads/' + BRANCH, V, '0'*40])
run(['git', 'push', 'origin', 'refs/heads/' + BRANCH + ':refs/heads/' + BRANCH])
_, remote, _ = run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + BRANCH])
assert remote.decode().split()[0] == V
_, after, _ = run(['git', 'rev-parse', 'HEAD'])
_, status, _ = run(['git', 'status', '--porcelain=v1', '--untracked-files=all'])
assert before == after and status == b''
cap.dump(O / 'RESULT.json', {'productSHA': S, 'productEvidenceHEAD': E, 'variantExecutionSHA': V, 'variantBranch': BRANCH, 'variantParentExactly': S, 'onlyChangedPath': 'geometry-web/app.js', 'modeUnchanged': True, 'allOtherTrackedBlobsAndModesIdentical': True, 'onlyEdit': 'remove unique success-ready connection.error clear; retain ready and known', 'originalAppSHA256': H(app), 'variantAppSHA256': H(variant_app), 'patchSHA256': H(patch), 'normalPushExit': 0, 'remoteEqual': True, 'productWorktreeHEADUnchanged': E, 'productWorktreeClean': True, 'ChromeNodeCompilerOrSubjectExecuted': False, 'CDPFixedWithdrawRestored': 'UNRUN/UNRUN/UNRUN', 'limits': ['V is an explicit counterexample execution SHA, not product S and not a final acceptance SHA.', 'Original workflow clean-check and original assertions/golden/timeouts remain unchanged.', 'No source checkout, index or product branch was changed; Git objects/ref for this dedicated variant branch only.']})
print(json.dumps({'productSHA': S, 'variantExecutionSHA': V, 'variantBranch': BRANCH, 'normalPushAndRemoteSame': True, 'sourceWorktreeUnchanged': E}))
