from pathlib import Path
import hashlib, importlib.util, io, json, os, tarfile

B=Path('/workspace/issue320-20261024')
R=Path('/workspace/issue320-work-20261024')
D=Path('/workspace/issue320-prbody-work-20261024')
S='7b45013da647b791acda8f5977475e4123d5f8c4'
V='082feb0662fea32131f3f7fb8ca451679ab6421d'
E0='dfdf88e33e21d9ac06c58af80929a8b7a9b9301f'
D0='dd5cbca6f0e46e783c4b22ff8ee9df535b6f8468'
BR='codex/issue320-connection-recovery-20261024'
PREFIX='evidence/issue344-real-cdp-preparation-7b45013d'
O=B/'reviewed-canvas-preparation-publication'
C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not O.exists()and H(C)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
O.mkdir();spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8');env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None)
rec=cap.Recorder(O,env,S)
def git(args,cwd=R):return rec.run(['git',*args],cwd=cwd,timeout=180,source_sha=S,source_variant='own reviewed preparation publication only; no subject execution')[1]
cap.dump(O/'REQUEST.json',{'productSHA':S,'controlledVariantSHA':V,'priorEvidence':E0,'priorBody':D0,'publicationOnly':True,'driverSHA256':H(__file__)})
for root,head in [(R,E0),(D,D0)]:
 assert git(['rev-parse','HEAD'],root).decode().strip()==head and git(['status','--porcelain=v1','--untracked-files=all'],root)==b''
vp=Path('/tmp/issue344-clean-v-phase-kernel-peer/REVIEW.json');pp=Path('/tmp/issue344-7b45013d-public-body-peer/CHECKS.json')
assert H(vp)=='437571db71f813fde9318ced568e79ee1274f914309bb6a77a551d5610ac39c6'
assert H(pp)=='e56c04c816a86a0a32e0993b632b871d9020d4fd71d1d3e2627a51719d8d9883'
originals={}
for label,root in [('controlled-V-publication',B/'controlled-withdrawal-source-publication'),('full-canvas-port-path-preparation',B/'full-canvas-three-phase-preparation'),('peer/V-and-three-phases-static',vp.parent),('peer/prior-VM-publication',pp.parent)]:
 for p in sorted(root.rglob('*')):
  if p.is_file():originals[label+'/'+p.relative_to(root).as_posix()]=p
for name in ['publish_clean_withdrawal_variant.py','prepare_full_canvas_three_phases.py','publish_reviewed_canvas_preparation.py']:
 originals['tools/'+name]=B/name
originals['peer/VM_COUNT_FIELD_NOTE.json']=Path('/tmp/issue320-vm-7b45013d-kernel-peer-r2/COUNT_FIELD_NOTE.json')
originals['peer/review_issue344_v_phase_preparation.py']=Path('/tmp/review_issue344_v_phase_preparation.py')
originals['tools/capture.py']=C
dest=R/PREFIX;assert not dest.exists();(dest/'raw').mkdir(parents=True)
inventory=[{'member':n,'originalPath':str(p),'bytes':p.stat().st_size,'sha256':H(p)}for n,p in sorted(originals.items())]
archive=dest/'raw/clean-V-and-reviewed-full-canvas-preparation.tar.gz'
with tarfile.open(archive,'w:gz')as tf:
 for row in inventory:
  raw=Path(row['originalPath']).read_bytes();info=tarfile.TarInfo(row['member']);info.mode=0o644;info.mtime=0;info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as tf:
 assert len(tf.getmembers())==len(inventory)
 for row in inventory:
  raw=tf.extractfile(row['member']).read();assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']and raw==Path(row['originalPath']).read_bytes()
cap.dump(dest/'RAW_INVENTORY.json',inventory)
cap.dump(dest/'PACKAGE.json',{'productSHA':S,'controlledVariantSHA':V,'archive':archive.relative_to(dest).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSHA256':H(archive),'members':len(inventory),'inventorySHA256':H(dest/'RAW_INVENTORY.json'),'roundtripOriginalBytes':True,'newSubjectExecutions':0})
cap.dump(dest/'CURRENT_STATE.json',{'productSHA':S,'controlledVariantSHA':V,'variantSoleParent':S,'variantOnlyEdit':'remove unique app success-ready error clear; all other blobs/modes identical','variantBranch':'codex/issue320-connection-recovery-withdrawal-20261024','variantOrdinaryPushAndRemoteEqual':True,'fullCanvasThreePhases':['UNRUN','UNRUN','UNRUN'],'phaseCleanHeads':[S,V,S],'phasePorts':{'HTTP':[19681,19682,19683],'CDP':[9731,9732,9733]},'original35minGoldenDefaultAndCleanValidatorUnchanged':True,'sourceRuntimeAndDiskMaterializationReady':False,'phasePreparationStaticPeer':{'checks':226,'exit':0,'path':str(vp),'sha256':H(vp)},'priorNewSNodeExecution':[0,1,0],'priorNodeVMOnly':True,'priorPublicPeer1585':{'path':str(pp),'sha256':H(pp)},'globalLedgerOrArchitectureDone':False,'newSubjectExecutions':0})
(dest/'PROGRESS.md').write_text('''# #344 真 CDP 反證準備

產品S7b與新Node9真0/1/0保原身份；本輪只固定並一般push公開撤回V082f（唯一parent S，唯一app success-ready clear撤回），原產品工作樹未改。V是反證專用來源，不冒S或正式acceptance SHA。

原完整canvas三phase固定S／V／S、HTTP19681/2/3、CDP9731/2/3、獨立TMP/profile與原兩鎖。原57f3 driver只有port/path/環境可見性機械差異，clean SHA guard／35min／3倍只收集／default全套／golden／全部原協定斷言均保。獨立226靜審0及此前VM公開1585核對0完整封存；它們不是browser測試。

真正完整source、fixtures、私有runtime／ELF與磁碟未物化，三phase全UNRUN，待root獨占排程。不用五檔薄checkout硬跑缺件，不借rootL綠，不放寬原validator。fixed/restored須完整matched；撤回須三具名正常stale-error斷言且全部協定dump/source/1600診斷正確，不能拿前置78/fatal/timeout/golden衍生不符當唯一kill。没有新總fail門檻或skip。

原9VM peer計數欄釐清note此次入庫：tests每階段9，pass9/6/9；原report不改。下一步root以既有完整browser preparer供本S/V精確私有source及預算，再按已審原CLI實跑，完整封存SHA／env／exit／原streams。
''',encoding='utf-8')
cap.dump(dest/'MANIFEST.json',{'selfExcluded':True,'files':[{'path':p.relative_to(dest).as_posix(),'bytes':p.stat().st_size,'sha256':H(p)}for p in sorted(dest.rglob('*'))if p.is_file()]})
git(['add','--force','--sparse','--',PREFIX]);staged=git(['diff','--cached','--name-only']).decode().splitlines();assert staged and all(p.startswith(PREFIX+'/')for p in staged)
git(['diff','--cached','--check']);git(['commit','-m','evidence: publish clean withdrawal variant and reviewed canvas plan'])
E=git(['rev-parse','HEAD']).decode().strip();git(['push','origin','HEAD:refs/heads/'+BR]);assert git(['ls-remote','--exit-code','origin','refs/heads/'+BR]).decode().split()[0]==E
body=git(['show',D0+':PR_BODY.md']).decode()
old='| Evidence head | E=`'+E0+'` |';assert old in body;body=body.replace(old,'| Evidence head | E=`'+E+'` |',1)
needle='| 真 P53／P61 與完整 canvas | **UNRUN** |';assert needle in body
body=body.replace(needle,'| 受控撤回來源／三phase準備 | V=`'+V+'`；靜審226／0 | V單親S且僅clearline差異，三phase clean S／V／S；不是CDP實跑或正式驗收通過 |\n'+needle,1)
old_paragraph='下一步先機械綁定三次原 full canvas 的獨立 port／TMP／profile、完整35min與 golden，交獨立 peer 後等 root 獨占時槽。'
assert old_paragraph in body
body=body.replace(old_paragraph,'三次原 full canvas 的獨立 port／TMP／profile、完整35min與 golden 已機械綁定，並獨立靜審226／0；真正完整source／fixtures／runtime與磁碟尚未物化，全部CDP仍UNRUN，下一步等root獨占時槽與原preparer完成來源準備。',1)
old_end='原正式 driver 要求 clean SHA；dirty variant 在前置即被擋的結果不能當真 CDP 證明，精確受控變體 binding 尚待準備／審查。'
assert old_end in body
body=body.replace(old_end,'原正式 driver 要求 clean SHA，沒有修改該validator；撤回專用公開V以S為唯一parent，只有app clearline差異，全部其餘Git blobs／modes相同。三phase真execution SHA分別S／V／S，V不能冒S或產品驗收SHA；dirty前置被擋也不能冒真CDP反證。HTTP19681/2/3、CDP9731/2/3與獨立scratch/profile全列原binding。',1)
body+='\n本輪準備／公開V原18命令／原patch／三driver完整diff／226靜審／前次1585公開核對與計數釐清note，見 `'+PREFIX+'/`；小包逐成員bytes/hash roundtrip。這批沒有新增Node、Chrome、C、HTTP或產品測試執行。\n'
assert body.count('唯一 current-state 矩陣')==1
(O/'PR_BODY.md').write_text(body,encoding='utf-8')
git(['merge','--no-edit',E],D);(D/'PR_BODY.md').write_text(body,encoding='utf-8');git(['add','--force','--sparse','--','PR_BODY.md'],D);assert git(['diff','--cached','--name-only'],D).decode().splitlines()==['PR_BODY.md']
git(['diff','--cached','--check'],D);git(['commit','-m','docs: pin controlled browser variant and pending full-canvas phases'],D)
DD=git(['rev-parse','HEAD'],D).decode().strip();git(['push','origin','HEAD:refs/heads/'+BR+'-prbody'],D);assert git(['ls-remote','--exit-code','origin','refs/heads/'+BR+'-prbody'],D).decode().split()[0]==DD
cap.dump(O/'PR_REQUEST.json',{'head':BR,'base':'codex/train-337-continue-20261024','title':'fix: 成功恢復連線後清除過時錯誤 (#320)','body_ref':BR+'-prbody','body_path':'PR_BODY.md'})
cap.dump(O/'RESULT.json',{'productSHA':S,'variantSHA':V,'evidenceSHA':E,'bodySHA':DD,'bodySHA256':H(O/'PR_BODY.md'),'prefix':PREFIX,'normalBothPushExit':0,'bothRemoteEqual':True,'members':len(inventory),'archiveSHA256':H(archive),'newSubjectExecutions':0})
print(json.dumps({'productSHA':S,'variantSHA':V,'evidenceSHA':E,'bodySHA':DD,'bodySHA256':H(O/'PR_BODY.md'),'members':len(inventory),'newSubjectExecutions':0}))
