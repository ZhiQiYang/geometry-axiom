"""Freeze port/path-only original driver bindings; do not execute or check out."""
from pathlib import Path
import ast, difflib, hashlib, json, sys

B = Path('/workspace/issue320-20261024/full-canvas-three-phase-preparation')
D = Path('/tmp/browser-readonly-layout-plan-9a05ae78/workflow-driver-storage.py')
S = '7b45013da647b791acda8f5977475e4123d5f8c4'
V = '082feb0662fea32131f3f7fb8ca451679ab6421d'
SHA = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not B.exists()
assert SHA(D) == '57f3a2d8932572a8d6b54ed3238a3f1c1c5056783973529077f4ddeb2320bc1d'
B.mkdir()
original = D.read_text()
source_publication = Path('/workspace/issue320-20261024/controlled-withdrawal-source-publication/RESULT.json')
variant = json.loads(source_publication.read_bytes())
assert variant['productSHA'] == S and variant['variantExecutionSHA'] == V and variant['variantParentExactly'] == S
assert variant['allOtherTrackedBlobsAndModesIdentical'] and variant['normalPushExit'] == 0 and variant['remoteEqual']
entries, diffs = [], []
for phase, execution_sha, http, cdp in [('fixed', S, 19681, 9731), ('withdrawn', V, 19682, 9732), ('restored', S, 19683, 9733)]:
    destination = B / ('workflow-driver-' + phase + '.py')
    changes = [
      ('port = 19080 + ORDER.index(args.job)', 'port = ' + str(http - 1) + ' + ORDER.index(args.job)'),
      ("        env['GEOMETRY_SCHEDULE_SCREENSHOT_DIR'] = str(tmp / 'geometry-schedule-screens')", "        env['GEOMETRY_SCHEDULE_SCREENSHOT_DIR'] = str(tmp / 'geometry-schedule-screens')\n        env['GEOMETRY_CDP_PORT'] = '"+str(cdp)+"'\n        env['GEOMETRY_CHROME_PROFILE'] = str(tmp / 'chrome-profile')"),
      ("'GEOMETRY_SCHEDULE_SCREENSHOT_DIR', *original_env}", "'GEOMETRY_SCHEDULE_SCREENSHOT_DIR', 'GEOMETRY_CDP_PORT', 'GEOMETRY_CHROME_PROFILE', *original_env}"),
    ]
    bound = original
    for old, new in changes:
        assert bound.count(old) == 1
        bound = bound.replace(old, new, 1)
    ast.parse(bound)
    destination.write_text(bound)
    diffs.extend(difflib.unified_diff(original.splitlines(True), bound.splitlines(True), fromfile=str(D), tofile=str(destination)))
    scratch = '/tmp/issue344-cdp-7b45013d/' + phase
    out = scratch + '/original'
    tmp = scratch + '/tmp/original/canvas'
    entry = {
      'phase': phase, 'productSHA': S, 'executionSHA': execution_sha, 'status': 'UNRUN',
      'isControlledVariant': phase == 'withdrawn', 'cleanHEADRequired': execution_sha,
      'driver': str(destination), 'driverSHA256': SHA(destination), 'driverOriginal': str(D), 'driverOriginalSHA256': SHA(D),
      'literalEdits': [{'before': old, 'after': new} for old,new in changes],
      'argvTemplate': ['flock','--nonblock','--conflict-exit-code','75','/tmp/g261r3/heavy.lock','env','-u','PYTHONOPTIMIZE','-u','NODE_OPTIONS',sys.executable,'-B',str(destination),'--repo','<ROOT_MATERIALIZED_EXACT_INDEPENDENT_PHASE_SOURCE>','--sha',execution_sha,'--job','canvas','--out-root',out],
      'nodeArgv': ['node','geometry-web/cdp_test.js'], 'scopeFlags': [],
      'environmentOverrides': {'GEOMETRY_TEST_URL': 'http://127.0.0.1:'+str(http)+'/', 'GEOMETRY_CDP_PORT':str(cdp),'GEOMETRY_CHROME_PROFILE':tmp+'/chrome-profile','TMPDIR':tmp,'GEOMETRY_CHROME':'/workspace/geo261-environment/bin/google-chrome'},
      'independentHTTPport':http,'independentCDPport':cdp,'freshScratch':scratch,'originalCIMinutes':35,'watchdogFactorCollectionOnly':3,
      'expectedOriginalNodeExit':1 if phase=='withdrawn' else 0,
      'expectedOriginalWorkflowExit':1 if phase=='withdrawn' else 0,
      'fixedRestoredGolden':'matched' if phase!='withdrawn' else 'original section mismatch expected from precisely three semantic stale-error failures; never UPDATE_GOLDEN',
      'originalGoldenPassCounts':{'total':2267,'P53':28,'P57':56},
      'normalSemanticFailuresRequired': ['P53-3 重試只讀取，不重送修改','P61-10 載入未送達時，重試連線保留原幾何與來源','P61-11 載入已送達但回應遺失時，核對核心後恢復正確來源'] if phase=='withdrawn' else [],
      'noExactTotalFailureCountInvented':True,
      'sourceAndRuntimeMaterialized':False,
      'runtimePoolOrELFsVerifiedForThisSource':False,
    }
    (B/(phase+'.REQUEST.json')).write_text(json.dumps(entry,ensure_ascii=False,indent=2)+'\n')
    entries.append(entry)
(B/'PORT_PATH_BINDING.diff').write_text(''.join(diffs))
plan = {
  'role':'frozen original full-canvas three-phase preparation; no browser/HTTP/C/Node test executed',
  'productSHA':S,'controlledVariantSHA':V,'variantBranch':variant['variantBranch'],'variantOnlyParent':S,
  'variantSourcePublication':{'path':str(source_publication),'sha256':SHA(source_publication)},
  'variantOriginalAppSHA256':variant['originalAppSHA256'],'variantWithdrawnAppSHA256':variant['variantAppSHA256'],
  'allOtherTrackedBlobsAndModesIdentical':True,'testsGoldenWorkflowUnchangedBetweenSAndV':True,
  'originalCleanGuardUnmodified':True,
  'threePhases':entries,
  'sourcePlan':'Use one separately prepared exact private full-canvas source sequentially clean S -> clean V -> clean S, or root-reviewed private phase copies. No new checkout was built here. Root must assign complete source/fixtures/runtime/disk budget before launch; thin five-file product worktree is insufficient. Never mutate root L or borrow L receipts/binaries without verified source closure.',
  'ordering':'fixed -> withdrawal -> restoration; preserve a red and proceed independent next phase only per root scheduler; never automatically retry a failure',
  'exclusive':'all three original full canvases each require root exclusive CPU/browser/performance window plus original /tmp/g261r3/heavy.lock and original scratch lock; busy75/78 means no product test, never kill',
  'strictProofInterpretation':[
    'Fixed and restored must meet the complete original workflow/35min/golden and normal exception rules; floor2267/P53=28/P57=56 remain original, no new skip.',
    'V has a different explicit execution SHA from product S; cannot claim same HEAD or acceptance result. It exists only to keep the original clean-check validator intact.',
    'Withdrawn must retain real403 reload/Retry pointer and two original upload-confirm fetch fault protocols, nonempty error-phase seeds, recovery ready, exact dump/source/PDF/1600/scene checks. Only error emptiness can explain the three named assertion failures.',
    'GEO320_RECOVERY_PROOF must show confirmIntercepted, nonempty seed/error phase and every original dump/source property; response-lost additionally actual response received/ok. Source/setup/import/timeout/driver-clean failures are not kills.',
    'Expected reduced sectionPass can cause the original two section golden mismatches; do not require mutant matched or total failed==3, and do not edit/normalize golden.',
    'Real loading-owner-guard specific case was not newly added; nine prior VM substitutes cannot be represented as real guard/HTTP coverage.',
  ],
  'allOriginalStreamsRequired':'prelaunched outer argv/request/env/SHA and process exit; workflow version/build/fonts/serve/probe/fullNode/artifacts/feedback/wait/transport logs and complete stdout/stderr hashes; source before/after clean HEAD/modes/blobs; no hidden short selector or partial mode',
  'peerCountClarification':{'path':'/tmp/issue320-vm-7b45013d-kernel-peer-r2/COUNT_FIELD_NOTE.json','sha256':SHA('/tmp/issue320-vm-7b45013d-kernel-peer-r2/COUNT_FIELD_NOTE.json'),'original9VMTests':[9,9,9],'passCounts':[9,6,9]},
  'subjectExecutions':0,'preparedButNotRuntimeReady':True,
}
(B/'PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
(B/'README.md').write_text('''# #344 真完整 canvas 三態（準備，未執行）

產品S7b，撤回proof-variant V082f（單親S、唯一app clearline撤回，其餘所有blob/mode同），恢復S。V已普通push且可解析；不能把V當S或正式acceptance SHA。原driver clean-head/status validator整段不改，不用dirty checkout前置78冒kill。

三個副本相對57f3原driver只有HTTP埠、CDP/profile環境及其收據可見性機械差異，PORT_PATH_BINDING.diff全列。HTTP19681/2/3，CDP9731/2/3，每phase獨立scratch/TMP/profile；原job canvas、default全套、35min/3倍只收集、workflow/golden/斷言/時限全保，無selector與額外skip。flock heavy＋scratch原鎖均保，root仍必獨占排程。

真正source/fixtures/runtime/ELF/disk尚未物化，REQUEST裡repo明確placeholder，不是可立即跑的完整checkout。不能用目前五檔薄source硬跑missingfiles，不動root L，不把root L綠轉標本件。先peer本窄diff，再由root原preparer固定完整私有source與預算，記全原streams/exit/env/SHA後才run。

fixed/restored需完整matched；V需三具名stale-error正常assert，且全部原協定／dump／source／1600等診斷正確。原sectionPass下降的golden mismatch是衍生證據，不新增總fail門檻，也不能以fatal/前置/timeout代kill。Node9 VM只維持原VM身份。
''',encoding='utf-8')
manifest={p.relative_to(B).as_posix():{'bytes':p.stat().st_size,'sha256':SHA(p)}for p in sorted(B.rglob('*'))if p.is_file()}
(B/'FROZEN_INVENTORY.json').write_text(json.dumps({'preparedOnly':True,'selfExcluded':True,'files':manifest},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'directory':str(B),'productSHA':S,'variantSHA':V,'planSHA256':SHA(B/'PLAN.json'),'frozenSHA256':SHA(B/'FROZEN_INVENTORY.json'),'allCDP':'UNRUN','sourceNotMaterialized':True}))
