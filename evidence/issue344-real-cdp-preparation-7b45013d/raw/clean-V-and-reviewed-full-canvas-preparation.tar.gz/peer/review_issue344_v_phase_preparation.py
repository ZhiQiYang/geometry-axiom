"""Read-only preparation/source peer. No Node/Chrome/compiler/judge execution."""
from pathlib import Path
import ast,datetime,difflib,hashlib,importlib.util,json,os,re

B=Path('/workspace/issue320-20261024');PREP=B/'full-canvas-three-phase-preparation';PUB=B/'controlled-withdrawal-source-publication'
OUT=Path('/tmp/issue344-clean-v-phase-kernel-peer');OUT.mkdir()
S='7b45013da647b791acda8f5977475e4123d5f8c4';V='082feb0662fea32131f3f7fb8ca451679ab6421d'
checks=[];pins={}
def h(raw):return hashlib.sha256(raw).hexdigest()
def read(p):
 p=Path(p);raw=p.read_bytes();pins[str(p)]=h(raw);return raw
def j(p):return json.loads(read(p))
def c(name,value):checks.append({'name':name,'passed':bool(value)})
plan=j(PREP/'PLAN.json');freeze=j(PREP/'FROZEN_INVENTORY.json');pub=j(PUB/'RESULT.json');rows=j(PUB/'subcommands.json')
c('plan-pin',pins[str(PREP/'PLAN.json')]=='da7990df6facb6a090db34281e8a6e7f3e74059acbe2199be9c0212293a374b5')
c('public-variant-pin',pins[str(PUB/'RESULT.json')]==plan['variantSourcePublication']['sha256'])
for n,x in freeze['files'].items():
 raw=read(PREP/n);c(n+':frozen-bytes-and-hash',len(raw)==x['bytes'] and h(raw)==x['sha256'])
c('exact-three-phase-identities',[(x['phase'],x['executionSHA'],x['cleanHEADRequired']) for x in plan['threePhases']]==[('fixed',S,S),('withdrawn',V,V),('restored',S,S)])
c('all-unrun-not-ready',plan['subjectExecutions']==0 and plan['preparedButNotRuntimeReady'] and all(x['status']=='UNRUN' and not x['sourceAndRuntimeMaterialized'] and not x['runtimePoolOrELFsVerifiedForThisSource'] for x in plan['threePhases']))
base=read('/tmp/browser-readonly-layout-plan-9a05ae78/workflow-driver-storage.py')
c('original-workflow-driver-pin',h(base)=='57f3a2d8932572a8d6b54ed3238a3f1c1c5056783973529077f4ddeb2320bc1d')
for i,p in enumerate(plan['threePhases']):
 raw=read(p['driver']);expected=base.decode()
 for edit in p['literalEdits']:
  c(p['phase']+':unique-literal:'+edit['before'][:35],expected.count(edit['before'])==1)
  expected=expected.replace(edit['before'],edit['after'])
 c(p['phase']+':only-three-storage-port-edits',expected.encode()==raw and len(p['literalEdits'])==3 and h(raw)==p['driverSHA256'])
 ast.parse(raw)
 c(p['phase']+':full-default-node',p['nodeArgv']==['node','geometry-web/cdp_test.js'] and p['scopeFlags']==[])
 c(p['phase']+':original-35-min-and-collection-factor',p['originalCIMinutes']==35 and p['watchdogFactorCollectionOnly']==3 and p['noExactTotalFailureCountInvented'])
 argv=p['argvTemplate'];c(p['phase']+':original-exclusive-resource-guards',argv[:6]==['flock','--nonblock','--conflict-exit-code','75','/tmp/g261r3/heavy.lock','env'])
 c(p['phase']+':unset-opt-and-node-options',argv[6:10]==['-u','PYTHONOPTIMIZE','-u','NODE_OPTIONS'])
 c(p['phase']+':real-python-no-selector',argv[10:13]==['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3','-B',p['driver']] and argv[13:]==['--repo','<ROOT_MATERIALIZED_EXACT_INDEPENDENT_PHASE_SOURCE>','--sha',p['executionSHA'],'--job','canvas','--out-root',f'/tmp/issue344-cdp-7b45013d/{p["phase"]}/original'])
 port=19681+i;cdp=9731+i;tmp=Path(argv[-1]).parent/'tmp'/Path(argv[-1]).name/'canvas';env=p['environmentOverrides']
 c(p['phase']+':port-and-private-path-calculation',p['independentHTTPport']==port and p['independentCDPport']==cdp and env['GEOMETRY_TEST_URL']==f'http://127.0.0.1:{port}/' and env['GEOMETRY_CDP_PORT']==str(cdp) and env['TMPDIR']==str(tmp) and env['GEOMETRY_CHROME_PROFILE']==str(tmp/'chrome-profile'))
 c(p['phase']+':normal-expected-exit',p['expectedOriginalNodeExit']==p['expectedOriginalWorkflowExit']==(1 if i==1 else 0))
 c(p['phase']+':no-new-golden-floor',p['originalGoldenPassCounts']=={'total':2267,'P53':28,'P57':56})
 c(p['phase']+':full-clear-inherited-geometry',b"if not name.startswith('GEOMETRY_')" in raw)
 c(p['phase']+':original-clean-validator-kept',b"state['head'] != SHA" in raw and b"or state['status']" in raw)
 c(p['phase']+':no-golden-update-override',set(env)=={'GEOMETRY_TEST_URL','GEOMETRY_CDP_PORT','GEOMETRY_CHROME_PROFILE','TMPDIR','GEOMETRY_CHROME'})
 c(p['phase']+':request-identical-to-phase',j(PREP/(p['phase']+'.REQUEST.json'))==p)
c('withdraw-all-three-semantic-failures-required',len(plan['threePhases'][1]['normalSemanticFailuresRequired'])==3)
c('fixed-restored-original-golden-matched',all(plan['threePhases'][i]['fixedRestoredGolden']=='matched' for i in [0,2]))
c('variant-not-product-sha',plan['controlledVariantSHA']==pub['variantExecutionSHA']==V and plan['productSHA']==pub['productSHA']==pub['variantParentExactly']==S and plan['originalCleanGuardUnmodified'])
c('publication-exact-record-count',len(rows)==18)
for i,row in enumerate(rows,1):
 d=PUB/'subcommands'/f'{i:06d}';request=j(d/'request.json');result=j(d/'result.json')
 c(str(i)+':exact-original-result',row==result and row['directory']==str(d))
 c(str(i)+':original-request-fields',request['actual_process_returncode'] is None and all(row.get(k)==v for k,v in request.items() if k!='actual_process_returncode'))
 c(str(i)+':expected-terminal-exit',row['actual_process_returncode']==(1 if i==3 else 0) and row['ended_epoch']>=row['started_epoch'] and not row['timeout_expired'])
 for stream in ['stdin','stdout','stderr']:
  raw=read(d/(stream+'.bin'));c(str(i)+':'+stream+'-sha',h(raw)==row[stream+'_sha256'])
  if stream!='stdin':c(str(i)+':'+stream+'-bytes',len(raw)==row[stream+'_bytes'])
def stream(i,name='stdout'):return read(PUB/'subcommands'/f'{i:06d}'/(name+'.bin'))
fixed=read(PUB/'app-original.js.txt');withdrawn=read(PUB/'app-withdrawn.js.txt')
needle=b'connection.phase = "ready"; connection.known = true; connection.error = "";';short=b'connection.phase = "ready"; connection.known = true;'
c('one-clear-line-only',fixed.count(needle)==1 and fixed.replace(needle,short)==withdrawn)
c('original-and-variant-app-sha',h(fixed)==pub['originalAppSHA256']==plan['variantOriginalAppSHA256']=='c5f055915a039d90138824248b146552776286beb7544380c279a5586707ab60' and h(withdrawn)==pub['variantAppSHA256']==plan['variantWithdrawnAppSHA256']=='e248c162d4f0da633a0fd3314402af96e0f9c1a05d3224d90f7e5ffcabace7f1')
c('original-show-and-write-object-input-exact',stream(4)==fixed and stream(5,'stdin')==withdrawn)
old_oid=hashlib.sha1(b'blob '+str(len(fixed)).encode()+b'\0'+fixed).hexdigest();new_oid=hashlib.sha1(b'blob '+str(len(withdrawn)).encode()+b'\0'+withdrawn).hexdigest()
c('written-new-app-git-id',stream(5)==(new_oid+'\n').encode())
oldweb=stream(6);newweb=stream(7,'stdin');line=('100644 blob '+old_oid+'\tapp.js\0').encode();newline=('100644 blob '+new_oid+'\tapp.js\0').encode()
c('geometry-tree-only-app-blob-change',oldweb.count(line)==1 and oldweb.replace(line,newline)==newweb)
oldroot=stream(8);newroot=stream(9,'stdin');newweb_oid=stream(7).decode().strip();oldweb_line=next(x for x in oldroot.split(b'\0') if x.endswith(b'\tgeometry-web'))
c('root-tree-only-geometry-subtree-change',oldroot.replace(oldweb_line,b'040000 tree '+newweb_oid.encode()+b'\tgeometry-web')==newroot)
c('tree-and-commit-parent-command',rows[9]['command']==['git','commit-tree',stream(9).decode().strip(),'-p',S,'-m','test: freeze controlled connection error-clear withdrawal'] and stream(10)==(V+'\n').encode() and stream(11)==(S+'\n').encode())
expected_diff=f':100644 100644 {old_oid} {new_oid} M\tgeometry-web/app.js\n'.encode()
c('raw-diff-only-app-mode-unchanged',stream(12)==expected_diff)
c('patch-raw-saved-identical',stream(13)==read(PUB/'WITHDRAW_ONLY_CLEAR.patch') and h(stream(13))==pub['patchSHA256'])
c('normal-push-no-force',rows[14]['command']==['git','push','origin','refs/heads/'+pub['variantBranch']+':refs/heads/'+pub['variantBranch']] and pub['normalPushExit']==0)
c('original-remote-equals-v',stream(16)==(V+'\trefs/heads/'+pub['variantBranch']+'\n').encode() and pub['remoteEqual'])
c('original-product-worktree-stayed-clean-at-evidence-head',stream(1)==stream(17)==(pub['productEvidenceHEAD']+'\n').encode() and stream(2)==stream(18)==b'' and pub['productWorktreeClean'])
c('source-publication-subject-unrun',pub['ChromeNodeCompilerOrSubjectExecuted'] is False and pub['CDPFixedWithdrawRestored']=='UNRUN/UNRUN/UNRUN')
cap_path=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');spec=importlib.util.spec_from_file_location('cap',cap_path);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
rec=cap.Recorder(OUT,dict(os.environ),'review only; no product gate')
_,commit,_=rec.run(['git','cat-file','commit',V],cwd='/workspace/issue320-work-20261024',timeout=60,source_variant='immutable variant commit read only')
c('immutable-v-commit-object-sha',hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==V)
c('immutable-v-single-parent-and-new-root',re.findall(rb'^parent ([0-9a-f]{40})$',commit,re.M)==[S.encode()] and ('tree '+stream(9).decode()).encode() in commit)
c('all-original-inputs-remain-same-sha',all(h(Path(p).read_bytes())==v for p,v in pins.items()))
findings=[x['name'] for x in checks if not x['passed']]
report={'sourceS':S,'controlledVariantV':V,'checks':len(checks),'exit_code':1 if findings else 0,'findings':findings,'scope':'Static phase driver binding plus original variant publication records; never original CDP runtime acceptance.','subjectRerun':False,'newReviewerCommands':'One git cat-file commit of immutable V only. No Chrome/Node/compiler/HTTP/judge executed.','limits':['Three complete canvas phases remain UNRUN; source/fixtures/runtime/disk not materialized or verified.','V is a distinct controlled execution SHA whose only product difference is unique error-clear removal. It must never be represented as product S acceptance.','Parent must allocate an exclusive window and exact clean independent source before execution; readonly L source/binaries cannot be assumed reusable for S/V.','Real loading-owner guard case was not newly added; VM substitutes remain limited.','Fixed/restored must match original golden. Mutant requires three normal named stale-error failures with full conjunct diagnostics; expected golden differences do not imply an exact total failcount3.','No immutable permission boundary is claimed for same-owner readonly files.'],'pins':pins,'details':checks,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['checks','exit_code','findings']}));raise SystemExit(report['exit_code'])
