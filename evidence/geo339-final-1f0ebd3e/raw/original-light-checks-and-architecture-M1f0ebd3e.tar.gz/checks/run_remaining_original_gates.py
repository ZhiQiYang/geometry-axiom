"""Materialize exact original judge inputs in existing M checkout; run three original gates."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat

OUT=Path('/tmp/geo339-light-gates-M1f0ebd3e-preflight')
ROOT=Path('/tmp/geo324-faces-work-20261024')
M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H=lambda raw:hashlib.sha256(raw).hexdigest()
assert H(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap339remaining',CAP)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ)
for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','MUTATE_RESULTS','MUTATE_CACHE'):
    env.pop(key,None)
TMP=OUT/'remaining-tmp';TMP.mkdir(exist_ok=False)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8',TMPDIR=str(TMP),GITHUB_SHA=M,GITHUB_WORKSPACE=str(ROOT))
rec=cap.Recorder(OUT,env,M);rec.rows=json.loads((OUT/'subcommands.json').read_text())
def run(argv,check=True,data=None,variant='original-input-preparation'):
    return rec.run(argv,cwd=ROOT,timeout=None,check=check,data=data,source_sha=M,source_variant=variant)
git=['git','-c','gc.auto=0','-c','maintenance.auto=false']
_,identity,_=run(git+['rev-parse','HEAD','HEAD^{tree}']);assert identity.decode().splitlines()[0]==M
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
run(['df','-B1','/tmp','/workspace'])
manifest=json.loads((OUT/'subcommands/000005/stdout.bin').read_bytes())
product_paths={entry['path'] for kind in ('sources','exclusions') for entry in manifest[kind]}
assert len(product_paths)==604
extra={'tests/architecture_contract.py','tests/test_architecture_contract.py','tests/test_product_architecture.py',
       'tests/mutate.py','tests/mutation_bridge.py','tests/run_tests.py','tests/mutants_results.json',
       'geometry-core/domain-decoupling/product-architecture.json',
       'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',
       'geometry-core/domain-decoupling/product-architecture-scan.json',
       'geometry-core/domain-decoupling/product-architecture-receipt.json'}
def parse_tree(raw):
    result={}
    for item in raw.split(b'\0'):
        if not item:continue
        metadata,name=item.split(b'\t',1);mode,kind,blob,size=metadata.split()
        if kind==b'blob':result[name.decode()]={'mode':mode.decode(),'blob':blob.decode(),'bytes':int(size)}
    return result
test_tree=parse_tree((OUT/'subcommands/000029/stdout.bin').read_bytes())
oracle_paths={name for name in test_tree if (name.count('/')==1 and name.endswith(('.py','.c'))) or (name.startswith('tests/fixtures/') and name.endswith('.scene'))}
_,root_tree,_=run(git+['ls-tree','-l','-z',M])
oracle_paths.update(name for name in parse_tree(root_tree) if '/' not in name and name.endswith('.scene'))
paths=sorted(product_paths|extra|oracle_paths)
_,raw,_=run(git+['ls-tree','-r','-l','-z',M,'--']+paths)
tree=parse_tree(raw)
assert set(tree)==set(paths),{'missingGitInputs':sorted(set(paths)-set(tree))}
missing=[name for name in paths if not (ROOT/name).is_file()]
budget={'role':'Exact original product/generic/ledger input materialization plan; no assertions changed',
        'source':M,'manifestOwned':len(manifest['sources']),'manifestExcluded':len(manifest['exclusions']),
        'productInputs':len(product_paths),'allInputs':len(paths),'missingCount':len(missing),
        'missingLogicalBytes':sum(tree[name]['bytes'] for name in missing),
        'missingAllocated4kEstimate':sum(((tree[name]['bytes']+4095)//4096)*4096 for name in missing),
        'privateProductSnapshot4kEstimate':sum(((tree[name]['bytes']+4095)//4096)*4096 for name in product_paths),
        'oracleSelection':'Exact original mutation_bridge.oracle_hash globs: tests/*.py, tests/*.c, tests/fixtures/**/*.scene, root *.scene; includes original core TESTS root scenes.',
        'missing':[{ 'path':name,**tree[name]} for name in missing],
        'correctedDerivedNames':'Original dot-separated guessed scan/receipt names in first preflight are not tracked; real original schema uses product-architecture-scan.json and product-architecture-receipt.json. First report remains preserved.'}
(OUT/'MATERIALIZATION_PLAN.json').write_text(json.dumps(budget,ensure_ascii=False,indent=2)+'\n')
space=os.statvfs('/tmp');free=space.f_bavail*space.f_frsize
assert free>budget['missingAllocated4kEstimate']+budget['privateProductSnapshot4kEstimate']+8*1024*1024,{'tmpFree':free,'budget':budget['missingAllocated4kEstimate']+budget['privateProductSnapshot4kEstimate']}
_,gitdir,_=run(git+['rev-parse','--absolute-git-dir'])
pattern=Path(gitdir.decode().strip())/'info/sparse-checkout'
old=pattern.read_bytes();(OUT/'REMAINING_SPARSE_BEFORE.bin').write_bytes(old)
lines=old.decode().splitlines()
for name in paths:
    pattern_name='/'+name
    if pattern_name not in lines:lines.append(pattern_name)
run(git+['sparse-checkout','set','--no-cone','--stdin'],data=('\n'.join(lines)+'\n').encode(),variant='exact-original-604-plus-actual-ledger-oracle-inputs')
(OUT/'REMAINING_SPARSE_AFTER.bin').write_bytes(pattern.read_bytes())
inputs=[]
for name in paths:
    p=ROOT/name;assert p.is_file() and not p.is_symlink()
    raw=p.read_bytes();item=tree[name]
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert len(raw)==item['bytes'] and blob==item['blob'],name
    inputs.append({'path':name,**item,'sha256':H(raw),'lfSha256':H(raw.replace(b'\r\n',b'\n')),'productArchitectureInput':name in product_paths})
(OUT/'M_INPUT_IDENTITY_BEFORE.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n')
_,before,_=run(git+['rev-parse','HEAD','HEAD^{tree}']);assert before==identity
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
for argv in (['python3','--version'],['node','--version'],['/workspace/geo261-environment/bin/google-chrome','--version'],['uname','-a']):run(argv)
requests=[
    ('architecture-contract',['python3','-B','tests/architecture_contract.py','--root','.','--manifest','geometry-core/domain-decoupling/product-architecture.json']),
    ('product-architecture-tests',['python3','-B','tests/test_product_architecture.py']),
    ('mutation-check',['python3','-B','tests/mutate.py','--check']),
]
facts=[]
for gate,argv in requests:
    row,stdout,stderr=run(argv,check=False,variant=gate+'-original-judge')
    facts.append({'gate':gate,'executionSHA':M,'actualCommand':row,'originalExit':row['actual_process_returncode']})
    (OUT/'REMAINING_PROGRESS.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
_,after,_=run(git+['rev-parse','HEAD','HEAD^{tree}'])
_,after_status,_=run(git+['status','--porcelain=v1','--untracked-files=all'])
assert after==before and not after_status
for item in inputs:assert H((ROOT/item['path']).read_bytes())==item['sha256'],item['path']
run(['df','-B1','/tmp','/workspace'])
generic=json.loads((OUT/'GENERIC_ACTUAL.json').read_text())
result={'role':'Actual four original non-compiling checks on true clean M; no ledger regeneration',
        'executionSHA':M,'rows':[{'gate':'architecture-tests','originalExit':generic['originalExit'],'executionSHA':M,'receipt':str(OUT/'GENERIC_ACTUAL.json')},*facts],
        'sourceBefore':before.decode().splitlines(),'sourceAfter':after.decode().splitlines(),'sourceBeforeClean':not status,'sourceAfterClean':not after_status,
        'inputCount':len(inputs),'allOriginalGitBytesBeforeAfterSame':True,'inputIdentity':str(OUT/'M_INPUT_IDENTITY_BEFORE.json'),
        'allFourOriginalExitZero':generic['originalExit']==0 and all(row['originalExit']==0 for row in facts),
        'ledgerRegenerated':False,'testsAssertionsProductChanged':False,'newCloneCreated':False,
        'remainingFormalUnrun':['native-and-full-expected','canvas','assembly','documents','grid','space','timber']}
(OUT/'FOUR_ORIGINAL_CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'receipt':str(OUT/'FOUR_ORIGINAL_CHECKS.json'),'sha256':H((OUT/'FOUR_ORIGINAL_CHECKS.json').read_bytes()),'rows':[{'gate':row['gate'],'exit':row['originalExit']} for row in result['rows']],'sourceBeforeAfterClean':True,'materializedMissingBytes':budget['missingLogicalBytes'],'inputCount':len(inputs)},ensure_ascii=False))
