"""Read metadata for missing original architecture inputs; no judge runs."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

OUT=Path('/tmp/geo339-light-gates-M1f0ebd3e-preflight')
ROOT=Path('/tmp/geo324-faces-work-20261024')
M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest()=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap339preflight',CAP)
capture=importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
rec=capture.Recorder(OUT,env,M)
rec.rows=json.loads((OUT/'subcommands.json').read_text())
git=['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT)]
_,raw,_=rec.run(git+['show',M+':geometry-core/domain-decoupling/product-architecture.json'],cwd='/workspace')
manifest=json.loads(raw)
paths={entry['path'] for kind in ('sources','exclusions') for entry in manifest[kind]}
paths.update(['tests/architecture_contract.py','tests/test_architecture_contract.py','tests/test_product_architecture.py',
              'geometry-core/domain-decoupling/product-architecture.json',
              'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',
              'geometry-core/domain-decoupling/product-architecture.scan.json',
              'geometry-core/domain-decoupling/product-architecture.receipt.json'])
paths=sorted(paths)
_,raw,_=rec.run(git+['ls-tree','-r','-l','-z',M,'--']+paths,cwd='/workspace')
tree={}
for item in raw.split(b'\0'):
    if not item:continue
    metadata,name=item.split(b'\t',1)
    mode,kind,blob,size=metadata.split()
    tree[name.decode()]={'mode':mode.decode(),'blob':blob.decode(),'bytes':int(size)}
missing=[{'path':name,**tree.get(name,{'notTrackedAtM':True})} for name in paths if not (ROOT/name).is_file()]
result={'role':'Input completeness/disk preflight only; no judge executed',
        'currentHEAD':'dcdf22655e0cf8ed47cd0b7f66d89f3a7beca694','requestedExecutionSHA':M,
        'manifestSources':len(manifest['sources']),'manifestExclusions':len(manifest['exclusions']),
        'requestedInputs':len(paths),'missing':missing,'missingCount':len(missing),
        'missingKnownBytes':sum(item.get('bytes',0) for item in missing),
        'missingKnownRounded4k':sum(((item.get('bytes',0)+4095)//4096)*4096 for item in missing),
        'notTrackedRequested':[item['path'] for item in missing if item.get('notTrackedAtM')],
        'sourceMutationOrJudgesExecuted':False,
        'historicalToolFailure':'An initial shell-quoted metadata helper hit Python SyntaxError before execution; no Git reads or subject ran from that command. Its tool-thread stdout/stderr/exit remains original.'}
target=OUT/'INPUT_COMPLETENESS.json'
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='missing'},ensure_ascii=False))
print('sha256',hashlib.sha256(target.read_bytes()).hexdigest())
