"""Run only the original generic architecture judge after preserving evidence copies."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat

OUT=Path('/tmp/geo339-light-gates-M1f0ebd3e-preflight')
ROOT=Path('/tmp/geo324-faces-work-20261024')
M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
E='dcdf22655e0cf8ed47cd0b7f66d89f3a7beca694'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
H=lambda raw:hashlib.sha256(raw).hexdigest()
assert H(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('cap339generic',CAP)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ)
for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','MUTATE_RESULTS','MUTATE_CACHE'):
    env.pop(key,None)
TMP=OUT/'generic-tmp';TMP.mkdir(exist_ok=False)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8',TMPDIR=str(TMP),GITHUB_SHA=M,GITHUB_WORKSPACE=str(ROOT))
rec=cap.Recorder(OUT,env,M);rec.rows=json.loads((OUT/'subcommands.json').read_text())
actual=E
def run(parts,check=True,data=None,variant='generic-preparation'):
    return rec.run(parts,cwd=ROOT,timeout=None,check=check,data=data,source_sha=actual,source_variant=variant)
git=['git','-c','gc.auto=0','-c','maintenance.auto=false']
_,head,_=run(git+['rev-parse','HEAD']);assert head.decode().strip()==E
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
_,raw,_=run(git+['diff','--name-only','-z',M,E])
paths=[item.decode() for item in raw.split(b'\0') if item]
assert paths and all(p.startswith('evidence/') and '..' not in Path(p).parts for p in paths)
preserved=OUT/'preserved-publication-copies-E';preserved.mkdir(exist_ok=False)
assert ROOT.stat().st_dev==preserved.stat().st_dev
manifest=[]
for name in paths:
    path=ROOT/name
    assert path.is_file() and not path.is_symlink()
    s=path.stat();raw=path.read_bytes()
    manifest.append({'path':name,'original':str(path),'preserved':str(preserved/name),'bytes':len(raw),'sha256':H(raw),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns})
(OUT/'E_PUBLICATION_PRESERVATION_BEFORE.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
events=[]
for item in manifest:
    source=Path(item['original']);target=Path(item['preserved']);target.parent.mkdir(parents=True,exist_ok=True)
    os.rename(source,target)
    s=target.stat();assert (s.st_dev,s.st_ino,s.st_mode,s.st_mtime_ns,s.st_size)==(item['device'],item['inode'],item['mode'],item['mtime_ns'],item['bytes'])
    assert H(target.read_bytes())==item['sha256']
    events.append({'original':str(source),'preserved':str(target),'sameInodeAndBytes':True})
    (OUT/'E_PUBLICATION_PRESERVATION_EVENTS.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
# Only E->M differences are the fully preserved evidence paths. This restores
# the target index/worktree without overwriting any product/test input.
run(git+['read-tree','--reset','-u',M],variant='preserved-pure-evidence-index-transition-E-to-M')
run(git+['checkout','--detach',M],variant='ordinary-detached-checkout-M-after-exact-preservation')
actual=M
_,head,_=run(git+['rev-parse','HEAD','HEAD^{tree}']);assert head.decode().splitlines()[0]==M
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
_,gitdir,_=run(git+['rev-parse','--absolute-git-dir'])
pattern=Path(gitdir.decode().strip())/'info/sparse-checkout'
old=pattern.read_bytes();(OUT/'SPARSE_BEFORE.bin').write_bytes(old)
lines=old.decode().splitlines()
for name in ('/tests/architecture_contract.py','/tests/test_architecture_contract.py'):
    if name not in lines:lines.append(name)
data=('\n'.join(lines)+'\n').encode()
run(git+['sparse-checkout','set','--no-cone','--stdin'],data=data,variant='only-two-original-generic-judge-inputs-added')
(OUT/'SPARSE_AFTER.bin').write_bytes(pattern.read_bytes())
inputs=[]
for name in ('tests/architecture_contract.py','tests/test_architecture_contract.py'):
    _,raw,_=run(git+['show',M+':'+name]);physical=(ROOT/name).read_bytes();assert physical==raw
    inputs.append({'path':name,'bytes':len(raw),'sha256':H(raw)})
_,before_head,_=run(git+['rev-parse','HEAD','HEAD^{tree}'])
_,before_status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not before_status
row,stdout,stderr=run(['python3','-B','tests/test_architecture_contract.py'],check=False,variant='original-generic-architecture-contract-suite')
_,after_head,_=run(git+['rev-parse','HEAD','HEAD^{tree}'])
_,after_status,_=run(git+['status','--porcelain=v1','--untracked-files=all'])
assert before_head==after_head and not after_status
for item in inputs:assert H((ROOT/item['path']).read_bytes())==item['sha256']
result={'role':'Actual original generic architecture judge only; other three items remain pending input materialization',
        'executionSHA':M,'actualCommand':row,'originalExit':row['actual_process_returncode'],
        'sourceBefore':before_head.decode().splitlines(),'sourceAfter':after_head.decode().splitlines(),
        'sourceBeforeClean':not before_status,'sourceAfterClean':not after_status,'originalInputs':inputs,
        'preservedPublicationCopies':{'sourceE':E,'count':len(manifest),'bytes':sum(x['bytes'] for x in manifest),'method':'same-filesystem per-file rename, no payload duplication or byte loss','manifest':str(OUT/'E_PUBLICATION_PRESERVATION_BEFORE.json')},
        'remainingUnrun':['architecture-contract','product-architecture-tests','mutation-check'],
        'noTestsAssertionsOrProductChanged':True,'noNewCloneOrRootLiveAccess':True}
(OUT/'GENERIC_ACTUAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'originalExit':row['actual_process_returncode'],'stdout':stdout.decode(),'stderr':stderr.decode(),'receipt':str(OUT/'GENERIC_ACTUAL.json'),'sha256':H((OUT/'GENERIC_ACTUAL.json').read_bytes())},ensure_ascii=False))
raise SystemExit(row['actual_process_returncode'])
