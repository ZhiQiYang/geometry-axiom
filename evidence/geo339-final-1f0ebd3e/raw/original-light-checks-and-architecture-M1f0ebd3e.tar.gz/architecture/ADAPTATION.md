# #339 原 Linux 四檔 schema 的單一 W 輸入刷新

受驗與封存來源都是乾淨 `1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599`；未在本輪產生／改標其它 execution SHA。原三條直接 OS CLI 已跑 0/0/0，generic205、product18；原 `mutate.py --check` 的 exit1、107 stale／3 retired／13 unrun 保留，不重產帳本。

沿 ec8 已採用的 `geometry-product-architecture-receipt/1`，四檔名稱、LF 規則、path-sorted compact JSON closure serialization、四個 derived path 排除與 receipt 不 hash 自身全部保留。原 manifest 的 root、owned/exclusion/layer/reason/route/W-guard/policy bytes 都沒有改。334 owned＋270 excluded 共604 Git／實體 executable inventory 均核；並額外對 Git 的完整五個來源根與三個 standalone file 清點，避免 sparse 隱藏未登錄可執行來源。

相對原 ec8 receipt，604 個 path set 相同，唯一 LF hash 差異精確為 `geometry-templates/woodworking/geometry_woodworking/model_sources.py`。此白名單外的任何差異都會拒絕。三個原 judge bytes 同原收據；原 scan stdout 仍逐 bytes 相同，798 edges／0 diagnostics。這不等於完整 LF closure 相同，因此新 receipt 使用本輪 M／新 closure，不延伸舊 same-closure 敘述。

原 P17 的 manifest digest 反證只作歷史。為本輪來源另實跑原相同控制：已保存的 M baseline0、唯一 `run_axiom_mutations.py` exclusion digest 被撤回的外部原 manifest1、同原 baseline argv restored0。撤回沒有改產品或原測試，只使用既有原外部 manifest；原唯一紅仍是 EXCLUSION_DIGEST。完整 argv、原 streams／exit、SHA／環境均在 c387 原件。

這是 repo 外收據 adapter，不是新裁判。它讀已實跑的三原 judge rows，逐 row／stream hash 核對；使用已對 Git M blob 核過的完整1119必要輸入 inventory。相對先前 ec8 driver，省去重複輸出604個source的22MB Git batch payload；改為核每個實體 byte 的原 Git blob oid，並保 raw／LF hashes。HEAD／clean、604完整實體 inventory、四原 derived bytes、原 judge bytes 初末守門保留。未改 tests、斷言、容量、時限或任何產品 source。

manifest 與 scan 新產物 byte-identical，實際 derived diff 只有 report／receipt。原四檔、舊 schema 的歷史欄位與當前／歷史角色都保留；未新作 Windows supplemental 或928／55詞彙完整性盤點。完整 native／expected 和六 browser 仍 UNRUN。本輪未寫 checkout 或安裝四檔，待獨立 peer 後才由 owner 正常提交／推送自己的分支。
