"""One-owned-W-input adaptation of the existing Linux four-artifact receipt schema."""
import collections
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
ROOT=Path('/tmp/geo324-faces-work-20261024')
EVIDENCE=Path('/tmp/geo339-light-gates-M1f0ebd3e-preflight')
OUT=Path('/tmp/geo339-architecture-four-M1f0ebd3e')
ART='geometry-core/domain-decoupling'
FILES=('product-architecture.json','product-architecture-scan.json','PRODUCT-ARCHITECTURE.md','product-architecture-receipt.json')
JUDGES=('tests/architecture_contract.py','tests/test_architecture_contract.py','tests/test_product_architecture.py')
ONLY_CHANGED='geometry-templates/woodworking/geometry_woodworking/model_sources.py'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAP_PIN='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
WITHDRAWN=Path('/workspace/train337-architecture-original-17b35764/withdrawn-product-architecture.json')
WITHDRAWN_PIN='d787df610824282c305a616731759d900f81619b68419c04d63e66bf04402499'
SUFFIXES={'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}
H=lambda raw:hashlib.sha256(raw).hexdigest()
LF=lambda raw:raw.replace(b'\r\n',b'\n')
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def info(path):
    raw=path.read_bytes();return {'bytes':len(raw),'rawSha256':H(raw),'lfSha256':H(LF(raw))}

assert not OUT.exists() and H(CAP.read_bytes())==CAP_PIN
assert not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0')
OUT.mkdir();(OUT/'new').mkdir();(OUT/'previous').mkdir();(OUT/'tools').mkdir()
(OUT/'tools'/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
(OUT/'tools'/'capture.py').write_bytes(CAP.read_bytes())
spec=importlib.util.spec_from_file_location('cap339four',CAP)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ)
for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS'):env.pop(key,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',LANG='C.UTF-8',LC_ALL='C.UTF-8',GITHUB_SHA=M,GITHUB_WORKSPACE=str(ROOT))
rec=cap.Recorder(OUT,env,M)
def run(argv,check=True):return rec.run(argv,cwd=ROOT,timeout=None,check=check,source_sha=M,source_variant='original-linux-four-schema-one-owned-W-input-adaptation')
git=['git','-c','gc.auto=0','-c','maintenance.auto=false']
_,identity,_=run(git+['rev-parse','HEAD','HEAD^{tree}']);assert identity.decode().splitlines()[0]==M
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
old_four={name:(ROOT/ART/name).read_bytes() for name in FILES}
for name,raw in old_four.items():(OUT/'previous'/name).write_bytes(raw)
prior=json.loads(old_four[FILES[3]]);manifest=json.loads(old_four[FILES[0]])
assert prior['schema']=='geometry-product-architecture-receipt/1'
assert H(LF(old_four[FILES[0]]))=='80f44b8c870e097413e395d30ba029199ba66b7302985c0f325d4f446d0ce525'
assert (len(manifest['sources']),len(manifest['exclusions']))==(334,270)
assert (len(manifest['policy']['forbiddenIdentifiers']),len(manifest['policy']['forbiddenStrings']))==(928,55)
declared=sorted(entry['path'] for kind in ('sources','exclusions') for entry in manifest[kind])
_,tracked,_=run(git+['ls-tree','-r','-z','--name-only',M,'--',*manifest['sourceRoots'],*manifest['sourceFiles']])
tracked_executables=sorted(name for name in tracked.decode().split('\0') if name and Path(name).suffix.lower() in SUFFIXES)
assert tracked_executables==declared and len(declared)==604,'Sparse checkout must not hide an undeclared executable'
def snapshot():
    paths=set(manifest['sourceFiles'])
    for root in manifest['sourceRoots']:
        for parent,dirs,files in os.walk(ROOT/root,followlinks=False):
            assert all(not (Path(parent)/name).is_symlink() for name in dirs)
            for name in files:
                path=Path(parent)/name
                if path.suffix.lower() in SUFFIXES:
                    assert path.is_file() and not path.is_symlink();paths.add(path.relative_to(ROOT).as_posix())
    assert sorted(paths)==declared
    return [{'path':name,**info(ROOT/name)} for name in declared]
before=snapshot()
git_inputs={item['path']:item for item in json.loads((EVIDENCE/'M_INPUT_IDENTITY_BEFORE.json').read_bytes())}
for item in before:
    raw=(ROOT/item['path']).read_bytes();git_item=git_inputs[item['path']]
    assert H(raw)==git_item['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==git_item['blob']
inputs=[{'path':item['path'],'sha256':item['lfSha256']} for item in before]
old_inputs={item['path']:item['sha256'] for item in prior['inputs']}
assert set(old_inputs)==set(declared)
changed=[item for item in inputs if old_inputs[item['path']]!=item['sha256']]
assert [item['path'] for item in changed]==[ONLY_CHANGED],'Only authorized W face-binding input may differ'
closure=H(json.dumps(inputs,ensure_ascii=False,separators=(',',':')).encode())
raw_rows=json.loads((EVIDENCE/'subcommands.json').read_bytes())
by_variant={row.get('source_variant'):row for row in raw_rows}
def checked_row(row):
    directory=Path(row['directory']);actual=json.loads((directory/'result.json').read_bytes())
    assert actual==row and row['source_sha']==M and not row.get('timeout_expired') and 'exception' not in row
    for stream in ('stdin','stdout','stderr'):assert H((directory/(stream+'.bin')).read_bytes())==row[stream+'_sha256']
    return row,(directory/'stdout.bin').read_bytes(),(directory/'stderr.bin').read_bytes()
results=[checked_row(by_variant[key]) for key in ('architecture-contract-original-judge','original-generic-architecture-contract-suite','product-architecture-tests-original-judge')]
expected=[['python3','-B',JUDGES[0],'--root','.','--manifest',ART+'/'+FILES[0]],['python3','-B',JUDGES[1]],['python3','-B',JUDGES[2]]]
for result,argv in zip(results,expected):assert result[0]['actual_process_returncode']==0 and result[0]['command']==argv and Path(result[0]['cwd'])==ROOT
assert results[0][1]==old_four[FILES[1]]
assert H(WITHDRAWN.read_bytes())==WITHDRAWN_PIN
withdrawn_manifest=json.loads(WITHDRAWN.read_bytes())
delta=[(a,b) for a,b in zip(manifest['exclusions'],withdrawn_manifest['exclusions']) if a!=b]
assert len(delta)==1 and delta[0][0]['path']=='geometry-core/card-reference/run_axiom_mutations.py'
restored_manifest=json.loads(WITHDRAWN.read_bytes());restored_manifest['exclusions']=manifest['exclusions']
assert restored_manifest==manifest,'Historical control must change only the known exclusion digest'
withdrawn_row,withdrawn_out,_=run(['python3','-B',JUDGES[0],'--root','.','--manifest',str(WITHDRAWN)],check=False)
assert withdrawn_row['actual_process_returncode']==1
diagnostics=json.loads(withdrawn_out)['diagnostics']
assert len(diagnostics)==1 and diagnostics[0]['code']=='EXCLUSION_DIGEST' and diagnostics[0]['path']=='geometry-core/card-reference/run_axiom_mutations.py'
restored_row,restored_out,_=run(expected[0],check=False)
assert restored_row['actual_process_returncode']==0 and restored_out==results[0][1]
proof=[{'phase':phase,'exit':row['actual_process_returncode'],'directory':row['directory']} for phase,row in [('baseline',results[0][0]),('withdrawn',withdrawn_row),('restored',restored_row)]]
tool_hashes={name:info(ROOT/name)['lfSha256'] for name in JUDGES}
assert tool_hashes==prior['completeInventoryVerification']['toolHashesAfter']
validations=[]
for result,count in zip(results[1:],[205,18]):
    row,stdout,stderr=result;text=(stdout+b'\n'+stderr).decode()
    match=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M)
    assert len(match)==1 and int(match[0][0])==count and text.rstrip().endswith('OK')
    validations.append({**row,'command':' '.join(row['command']),'exitCode':0,'tests':count,'passed':count,'failed':0,'skipped':0,'unittestSeconds':float(match[0][1])})
scan=json.loads(results[0][1]);assert scan['ok'] is True and scan['diagnostics']==[]
counts={**prior['counts'],'executableFiles':604,'ownedSources':334,'exclusions':270,'edges':len(scan['edges']),'diagnostics':0,
        'layers':dict(sorted(collections.Counter(item['layer'] for item in manifest['sources']).items())),
        'languages':dict(sorted(collections.Counter(item['language'] for item in manifest['sources']).items()))}
assert counts==prior['counts']
report=(f'# Product architecture — #339 Linux 固定來源收據\n\n'
        f'三原裁判真在乾淨 Git HEAD `{M}` 執行，原 exit0/0/0；generic205／product18，無skip。'
        f'manifest分類、根範圍、exclusion、policy、928/55原字不變；604inputs、334owned／270excluded、798edges／0diagnostics。\n\n'
        f'相對原ec8收據，只有 owned W `{ONLY_CHANGED}` 的LF hash改變；其餘603輸入與三judge相同。'
        f'新 LF closure `{closure}`。原scan stdout逐bytes不變不等於LF closure不變，收據以本次M／604原Git blob重綁。\n\n'
        '原manifest digest反證已在本次M重跑0/1/0，唯一正常紅是run_axiom_mutations.py的EXCLUSION_DIGEST；'
        '只改外部manifest參數，不改source/test/斷言。舊P17反證保持歷史身份，不改標M。\n\n'
        '同M原帳本check仍exit1：table123／records110／stale107／retired3／unrun13；本次不重產帳本。'
        '完整native／expected及六browser仍UNRUN。604架構範圍不涵蓋全部tests/*.py，三條綠不代語意／runtime驗收。\n\n'
        '四檔只在repo外重產；manifest及scan bytes均不變，實際衍生diff只report／receipt。receipt不hash自身。'
        '以下原報告只保留歷史角色。\n\n'+LF(old_four[FILES[2]]).decode())
(OUT/'new'/FILES[0]).write_bytes(old_four[FILES[0]])
(OUT/'new'/FILES[1]).write_bytes(results[0][1])
(OUT/'new'/FILES[2]).write_text(report)
receipt=json.loads(old_four[FILES[3]])
receipt.update(headBinding='三原裁判與manifest 0/1/0實際在同一乾淨M執行；完整604raw/LF/Git blob及Git HEAD初末不變。只讀來源，四檔寫repo外。',
    createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),basis='沿原Linux schema；唯一owned W face-binding LF hash改變，原三judge和manifest政策不改；使用本次M真raw，不繼承舊execution。',
    sourceBaseHead=M,headObservedBefore=M,headObservedAfter=M,
    manifestSha256=H(LF(old_four[FILES[0]])),scannerSha256=tool_hashes[JUDGES[0]],scanSha256=H(LF(results[0][1])),
    reportSha256=H(LF((OUT/'new'/FILES[2]).read_bytes())),inputClosureSha256=closure,counts=counts,scanPassed=True,
    actualCliScan={**results[0][0],'exitCode':0},validation=validations,inputs=inputs)
receipt['manifestRefresh'].update(previousOutputs={name:info(OUT/'previous'/name) for name in FILES},sourceReceiptEvidenceDirectory=str(EVIDENCE),
    originalThreeGateExits=[0,0,0],manifestProof=proof,
    inheritedManifestProof={**prior['manifestRefresh']['inheritedManifestProof'],'basis':'只保留原P17歷史身份；本輪新604 LF closure不同，不能沿用其same-closure推論；本輪M的真manifest反證另列manifestProof。'},
    originalReceiptRawRows=[{'directory':row['directory'],'resultSha256':H((Path(row['directory'])/'result.json').read_bytes()),'command':row['command'],'actualExit':row['actual_process_returncode']} for row,_,_ in results],
    note='本輪M三原judge0/0/0與真manifest0/1/0；唯一owned W hash改變，manifest/policy/分類/exclusion均不改。')
receipt['completeInventoryVerification'].update(filesBefore=604,filesAfter=604,allRawAndLfInputsUnchanged=True,toolHashesBefore=tool_hashes,toolHashesAfter=tool_hashes,inputClosureSha256Before=closure,inputClosureSha256After=closure)
receipt['refreshDriver']={**info(Path(__file__)),'path':str(Path(__file__)),'argv':sys.argv,'recorderSha256':CAP_PIN,'runDirectory':str(OUT)}
receipt['environment']={'safeVariables':{key:env.get(key) for key in ('PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','PYTHONOPTIMIZE','TMPDIR')},'clearedInheritedEnvironmentNames':[],'python':sys.version}
receipt['uncertainties']=['未重產帳本；完整native/expected及六browser仍未跑。','未由owner安裝提交推送前，此四檔僅repo外產物；不宣稱新的execution SHA。','未新作928/55詞彙完整性或Windows supplemental驗收。']
save(OUT/'new'/FILES[3],receipt)
save(OUT/'source-inputs.json',before)
assert snapshot()==before
assert all((ROOT/ART/name).read_bytes()==old_four[name] for name in FILES)
_,after,_=run(git+['rev-parse','HEAD','HEAD^{tree}']);assert after==identity
_,status,_=run(git+['status','--porcelain=v1','--untracked-files=all']);assert not status
result={'role':'Original Linux four-artifact schema adaptation, not runtime/ledger acceptance','sourceSHA':M,'sourceBeforeAfterClean':True,
        'originalGateExits':[0,0,0],'manifestProofExits':[0,1,0],'inputCount':604,'changedPriorReceiptInputs':changed,
        'originalPriorReceiptSource':prior['sourceBaseHead'],'manifestBytesUnchanged':True,'scanBytesUnchanged':True,'actualDerivedDiffCount':2,
        'counts':counts,'inputClosureSHA256':closure,'outputs':{name:info(OUT/'new'/name) for name in FILES},'sourceCheckoutModified':False,'ledgerOriginalExit':1,'ledgerRegenerated':False}
save(OUT/'RESULT.json',result)
print(json.dumps({'result':str(OUT/'RESULT.json'),'sha256':H((OUT/'RESULT.json').read_bytes()),'originalGateExits':[0,0,0],'manifestProofExits':[0,1,0],'changedPriorInputs':[ONLY_CHANGED],'actualDerivedDiffCount':2},ensure_ascii=False))
