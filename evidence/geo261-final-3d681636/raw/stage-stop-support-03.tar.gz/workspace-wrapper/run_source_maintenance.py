"""Record authorized completed-checkout maintenance; no product execution."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback

BASE = Path('/workspace/geo288-p73-owner-20261023')
TOOLS = BASE / 'sparse-retirement-tools'
OUT = BASE / 'source-maintenance-execution'
COMMON_SHA = 'f3ccfe0fc23953028fe2d4d4dfc8842ded8fda579c5416efdb3bf1579a4d7e5c'
PACKAGE_SHA = '87cea0ea1724da7c6beb8a91999de37ffc8b72fad0e587796747ff335068f6e7'
CASES = [('p73source', BASE / 'source-3d681636'),
         ('p73probe', BASE / 'probe-source-3d681636')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    if sys.flags.optimize:
        raise RuntimeError('Optimized execution is prohibited')
    OUT.mkdir(exist_ok=False)
    report = {'schema': 'geo288-p73-source-maintenance-execution/1',
              'started_utc': now(), 'argv': sys.argv, 'cwd': os.getcwd(),
              'maintenance_lock': '/tmp/geo261-completed-checkout-maintenance.lock',
              'original_R3_changed': False,
              'environment': {k: os.environ.get(k) for k in
                              ('PATH', 'LANG', 'LC_ALL', 'PYTHONOPTIMIZE',
                               'PYTHONPATH', 'GIT_OPTIONAL_LOCKS')},
              'commands': [], 'cases': [], 'errors': [], 'accepted': False}

    def save():
        (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

    def command(argv, name):
        row = {'argv': argv, 'cwd': os.getcwd(), 'started_utc': now(),
               'exit_code': None, 'completed': False,
               'environment_delta': {'GIT_OPTIONAL_LOCKS': '0'},
               'stdout_file': str(OUT / (name + '.stdout')),
               'stderr_file': str(OUT / (name + '.stderr'))}
        report['commands'].append(row)
        save()
        p = None
        caught = None
        start = time.monotonic()
        with Path(row['stdout_file']).open('wb') as out, Path(row['stderr_file']).open('wb') as err:
            try:
                p = subprocess.Popen(argv, stdout=out, stderr=err,
                                     env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
                row['pid'] = p.pid
                save()
                p.wait()
            except BaseException as e:
                caught = e
                row['interruption'] = {'type': type(e).__name__, 'message': str(e)}
                if p is not None and p.poll() is None:
                    p.kill()
                    p.wait()
                    row['own_child_killed'] = True
        stdout = Path(row['stdout_file']).read_bytes()
        stderr = Path(row['stderr_file']).read_bytes()
        row.update({'exit_code': None if p is None else p.returncode,
                    'completed': p is not None and p.returncode is not None,
                    'elapsed_seconds': time.monotonic() - start,
                    'ended_utc': now(), 'stdout_sha256': sha(stdout),
                    'stderr_sha256': sha(stderr),
                    'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr)})
        save()
        if caught is not None:
            raise caught
        return row, stdout

    try:
        for name, expected in [('retire_guarded.py', COMMON_SHA), ('PACKAGE.json', PACKAGE_SHA)]:
            actual = sha((TOOLS / name).read_bytes())
            if actual != expected:
                raise RuntimeError('Reviewed tool changed: ' + name)
        report['reviewed_tool_hashes'] = {'retire_guarded.py': COMMON_SHA, 'PACKAGE.json': PACKAGE_SHA}
        old = BASE / 'source-sparse-retirement-p73source'
        archived = BASE / 'source-sparse-retirement-p73source-original-busy75'
        original_files = {str(p.relative_to(old)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                          for p in old.rglob('*') if p.is_file()}
        busy = json.loads((old / 'receipt.json').read_text())
        if busy['exit_code'] != 75 or busy['commands'] or busy['materialization_attempted'] or busy['index_metadata_refresh_attempted']:
            raise RuntimeError('Original output is not the untouched busy75 attempt')
        if archived.exists():
            raise RuntimeError('Busy75 archive already exists; do not overwrite')
        report['busy75_archive'] = {'original_path': str(old), 'preserved_path': str(archived),
                                    'files': original_files, 'original_exit_code': 75,
                                    'rename_completed': False}
        save()
        old.rename(archived)
        after_files = {str(p.relative_to(archived)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                       for p in archived.rglob('*') if p.is_file()}
        if after_files != original_files:
            raise RuntimeError('Busy75 archive bytes differ')
        report['busy75_archive']['rename_completed'] = True
        report['busy75_archive']['all_file_bytes_unchanged'] = True
        save()
        for label, repo in CASES:
            row = {'label': label, 'repo': str(repo), 'accepted': False, 'errors': []}
            report['cases'].append(row)
            before = None
            try:
                refs_argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                             '-C', str(repo), 'for-each-ref', '--format=%(refname)%00%(objectname)']
                ref_command, before = command(refs_argv, label + '-refs-before')
                if ref_command['exit_code'] != 0:
                    raise RuntimeError('Initial refs command failed')
                row['refs_before_sha256'] = sha(before)
                driver, _ = command([sys.executable, '-B', str(TOOLS / ('retire-' + label + '.py'))], label + '-driver')
                row['driver_exit_code'] = driver['exit_code']
                receipt = BASE / ('source-sparse-retirement-' + label) / 'receipt.json'
                raw = receipt.read_bytes()
                data = json.loads(raw)
                row['driver_receipt'] = str(receipt)
                row['driver_receipt_sha256'] = sha(raw)
                row['driver_passed'] = data.get('passed')
                row['materialization_effective'] = data.get('tracked_materialization_effective')
                row['parent_raw_verified_unchanged'] = data.get('parent_raw_verified_unchanged')
                row['freed_available_bytes'] = data.get('freed_available_bytes')
                if driver['exit_code'] != 0 or data.get('exit_code') != 0 or data.get('passed') is not True:
                    raise RuntimeError('Retirement driver did not pass; preserve original failure')
                if data.get('tracked_materialization_effective') is not True or data.get('parent_raw_verified_unchanged') is not True:
                    raise RuntimeError('Materialization or parent raw hard guard incomplete')
            except BaseException as e:
                row['errors'].append({'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()})
            finally:
                try:
                    ref_command, after = command(refs_argv, label + '-refs-after')
                    row['refs_after_sha256'] = sha(after)
                    row['refs_unchanged'] = before is not None and before == after and ref_command['exit_code'] == 0
                    if not row['refs_unchanged']:
                        row['errors'].append({'type': 'RefGuardError', 'message': 'Refs differ or are unverified'})
                except BaseException as e:
                    row['errors'].append({'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()})
                row['accepted'] = not row['errors']
                save()
        report['accepted'] = len(report['cases']) == 2 and all(x['accepted'] for x in report['cases'])
    except BaseException as e:
        report['errors'].append({'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()})
    finally:
        report['ended_utc'] = now()
        report['exit_code'] = 0 if report['accepted'] and not report['errors'] else 1
        save()
        print(json.dumps({'exit_code': report['exit_code'], 'accepted': report['accepted'],
                          'cases': report['cases'], 'receipt': str(OUT / 'receipt.json')}))
    return report['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
