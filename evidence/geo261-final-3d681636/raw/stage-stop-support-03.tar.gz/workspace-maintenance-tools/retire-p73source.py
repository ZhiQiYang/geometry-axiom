import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from retire_guarded import run
raise SystemExit(run('p73source'))
