"""Losslessly package one captured command stream; never remove its original."""
import argparse
import datetime
import gzip
import hashlib
import json
from pathlib import Path


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', type=Path, required=True)
    parser.add_argument('--stream', choices=('stdin', 'stdout', 'stderr'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result_path = args.result.resolve(strict=True)
    result_bytes = result_path.read_bytes()
    result = json.loads(result_bytes)
    source = result_path.parent / (args.stream + '.bin')
    if source.is_symlink() or not source.is_file():
        raise RuntimeError('Original stream must be a regular file, not a symlink')
    expected_hash = result[args.stream + '_sha256']
    expected_bytes = result.get(args.stream + '_bytes')
    before = source.stat()
    if expected_bytes is not None and before.st_size != expected_bytes:
        raise RuntimeError('Original stream size differs from recorded command result')
    if digest(source) != expected_hash:
        raise RuntimeError('Original stream hash differs from recorded command result')
    out = args.out.resolve()
    if out.exists() or out.is_relative_to(result_path.parent):
        raise RuntimeError('Package requires a new directory outside the original capture')
    out.mkdir(parents=True)
    (out / 'original-result.json').write_bytes(result_bytes)
    manifest = {
        'schema': 'geometry-lossless-command-stream/1',
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_result_path': str(result_path),
        'original_result_sha256': hashlib.sha256(result_bytes).hexdigest(),
        'original_stream_path': str(source),
        'original_stream_sha256': expected_hash,
        'original_stream_bytes': before.st_size,
        'source_sha': result.get('source_sha'),
        'original_process_exit': result.get('actual_process_returncode'),
        'representation': 'ordered independently gzipped raw byte ranges',
        'chunk_limit_bytes': 64 * 1024 * 1024,
        'parts': [],
        'original_deleted': False,
        'verification_complete': False,
    }
    manifest_path = out / 'MANIFEST.json'
    save = lambda: manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    save()
    whole = hashlib.sha256()
    offset = 0
    with source.open('rb') as original:
        while offset < before.st_size:
            count = min(manifest['chunk_limit_bytes'], before.st_size - offset)
            path = out / f'{args.stream}.part-{len(manifest["parts"]):04d}.gz'
            part_hash = hashlib.sha256()
            remaining = count
            with path.open('xb') as stored:
                with gzip.GzipFile(filename='', fileobj=stored, mode='wb', compresslevel=1, mtime=0) as compressed:
                    while remaining:
                        block = original.read(min(1024 * 1024, remaining))
                        if not block:
                            raise RuntimeError('Original stream ended during packaging')
                        compressed.write(block)
                        part_hash.update(block)
                        whole.update(block)
                        remaining -= len(block)
            if path.stat().st_size >= 80 * 1024 * 1024 - 2048:
                raise RuntimeError('Compressed part exceeds publication per-file limit')
            manifest['parts'].append({
                'file': path.name, 'offset': offset, 'raw_bytes': count,
                'raw_sha256': part_hash.hexdigest(),
                'compressed_bytes': path.stat().st_size,
                'compressed_sha256': digest(path),
            })
            offset += count
            save()
        if original.read(1):
            raise RuntimeError('Original stream grew during packaging')
    if whole.hexdigest() != expected_hash:
        raise RuntimeError('Packaged stream differs from original command result')
    restored = hashlib.sha256()
    restored_bytes = 0
    for part in manifest['parts']:
        current = hashlib.sha256()
        count = 0
        with gzip.open(out / part['file'], 'rb') as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b''):
                restored.update(block)
                current.update(block)
                count += len(block)
        if count != part['raw_bytes'] or current.hexdigest() != part['raw_sha256']:
            raise RuntimeError('Decompressed part failed exact byte verification')
        if part['offset'] != restored_bytes:
            raise RuntimeError('Part offsets are not contiguous')
        restored_bytes += count
    after = source.stat()
    if (restored_bytes != before.st_size or restored.hexdigest() != expected_hash
            or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or digest(source) != expected_hash
            or result_path.read_bytes() != result_bytes):
        raise RuntimeError('Round-trip or original preservation verification failed')
    manifest.update(verification_complete=True, restored_bytes=restored_bytes,
                    restored_sha256=restored.hexdigest(),
                    ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    commands = ' '.join(part['file'] for part in manifest['parts'])
    (out / 'README.md').write_text(
        '# 原始命令串流的無損分塊\n\n'
        '這是既有原始輸出的封存表示，不是重新執行命令。原件保留。'
        '每塊依 MANIFEST 的 offset 排序；所有解壓 bytes 串接後已與原命令收據逐位元組雜湊核對。\n\n'
        f'還原（在本目錄，指定一個不存在的新輸出檔）：\n\n```sh\n'
        f'gzip -dc {commands} > restored-{args.stream}.bin\n'
        f'sha256sum restored-{args.stream}.bin\n```\n\n'
        f'預期 bytes：{before.st_size}；SHA-256：`{expected_hash}`。\n')
    print(json.dumps({'package': str(out), 'parts': len(manifest['parts']),
                      'original_bytes': before.st_size, 'sha256': expected_hash,
                      'verification_complete': True, 'original_deleted': False}))


if __name__ == '__main__':
    main()
