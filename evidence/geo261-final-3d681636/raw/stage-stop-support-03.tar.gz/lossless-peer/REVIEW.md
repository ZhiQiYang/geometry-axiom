# #323 大型原 stdout 無損分塊工具靜審

有限接受列明工具hash用於這一個已存在的正長度stdout；未見可確立的資料保全／重建阻擋。只讀小工具與原result.json、做AST與整數分塊推算，沒有讀取/hash 205MB原stream、import或執行packer，也沒有跑任何test／大型解壓。

原命令是歷史 `git diff --cached --binary --full-index`，原exit0、來源戳307a18ec、stdout205,298,659bytes，原SHA256為778f023db9aba56fa84bd85b8ff32c016aec5bb0d9470b445653b0bd3989e174；包裝不可以把這筆歷史戳改成新的產品final。依64MiB上限會得到4個獨立gzip，offset依序0／67,108,864／134,217,728／201,326,592，前三各67,108,864bytes，最後3,972,067bytes，總和精確等原長度。

原source只rb讀，拒symlink／非regular／原長度或hash不符；新out不得已存在或位於原capture之內，chunk用xb。沒有unlink／rm／rename／replace原件的路徑。原result完整bytes另存，原expected hash是其原stdout hash。每段保存offset／raw bytes+hash／gzip bytes+hash；原讀取出現EOF提前或grow都拒，packaged whole hash仍須等原收據。

隨後完整逐段解壓重算每段raw hash與長度，檢查offset連續，串接總長與整體hash再對原stdout。最後還核原source dev/ino/size/mtime、重hash原source、原result bytes不變，全部成立才將verification_complete設true。原件不刪。64MiB原段的gzip即使不可壓縮仍遠低於generic80MiB單檔容量，這個已授權positive stream不落入上限邊緣。

未完成中途例外會非0，未完成manifest旗標保持false；最後README或stdout寫入若失敗，process仍非0，即使bytes驗證已完成，呼叫端也必須同時要求**實際退出0＋最終verification_complete=true**才採為成功（flag是資料驗證狀態，不取代process exit）。README還原範例按明列offset順序使用gzip -dc，多個獨立member可直接串接；使用者應照其文字指定不存在的新輸出檔，還原另核長度與原SHA，不能拿sha256sum僅列印當自動比較。

原manifest寫入不採原子替換，所以容量／中斷可留下partial JSON；這會解析失敗而非被本工具印成成功。發布方必須取真終態原receipt並解析完整flag，不發布半成品。靜審不聲稱實際4個gzip／原件hash或space已驗；原stdout完全沒被本review讀取。
