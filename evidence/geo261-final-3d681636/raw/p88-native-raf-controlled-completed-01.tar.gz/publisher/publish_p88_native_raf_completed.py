"""Publish the completed P88 controlled proof without relabeling diagnostics as gates."""
from pathlib import Path
import hashlib
import json
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
P = B / 'p88-priority'
F = '3d681636902371ecc528b20f51eea33e272581c9'
R = Path('/workspace/geometry-axiom')
proof = Path('/tmp/g288p88r/receipt.json')
summary = P / 'NATIVE_RAF_FINAL_SUMMARY.json'
expected = {
    proof: 'd80653fc15a3726a9a8bc115d556fbf8dd6c532e506dc49c09727323958fb5fa',
    summary: '15895280cc898f852d8076a07a60ed5a4944446936881984a73a50036f88b6ae',
    P / 'native-raf-diagnostic-archive/NATIVE_RAF_RAW.tar.gz': '3f107c0424c62844eaeac3ab6086ea75b7ebc6cc3c9e829dd61c34eedcb52e4a',
}
for path, digest in expected.items():
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise RuntimeError('Completed input differs: ' + str(path))
s = json.loads(summary.read_text())
if s['sha'] != F or not s['proof_passed'] or not s['ended_utc']:
    raise RuntimeError('Missing completed proof')
if [r['original_node_exit'] for r in s['phases']] != [0, 1, 0]:
    raise RuntimeError('Unexpected actual original exits')
peer = Path('/tmp/geo323-merge-20261023')
inputs = {
    'full_raw_archive': P / 'native-raf-diagnostic-archive',
    'final_summary': summary,
    'visibility_analysis': P / 'P88_NATIVE_RAF_VISIBILITY_ANALYSIS_final.md',
    'independent_attribution': Path('/workspace/kernel-no-wood-prep/p88-attribution'),
    'fixed_peer': peer / 'P88_NATIVE_RAF_FIXED_ACTUAL_PEER_REVIEW.json',
    'withdrawn_peer': peer / 'P88_NATIVE_RAF_WITHDRAWN_ACTUAL_PEER_REVIEW.json',
    'restored_peer': peer / 'P88_NATIVE_RAF_RESTORED_ACTUAL_PEER_REVIEW.json',
    'three_phase_peer_report': peer / 'P88_NATIVE_RAF_THREE_PHASE_ACTUAL_PEER_REVIEW.md',
    'three_phase_peer_checks': peer / 'P88_NATIVE_RAF_THREE_PHASE_ACTUAL_PEER_REVIEW.json',
    'latest_review': B / 'review-refresh-20261023T1247',
    'latest_review_fetch': B / 'review-refresh-20261023T1247-fetch',
    'publisher': Path(__file__),
}
for label, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing completed input: ' + label)
command = ['python3', '-B', str(B / 'record_command.py'),
    '--out', str(B / 'p88-native-raf-completed-publication'), '--sha', F,
    '--cwd', str(R), '--variant', 'completed-native-raf-proof-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py',
    '--repo', str(R), '--branch', 'architecture/geo261-integration-20261016',
    '--issue', '261', '--sha', F, '--label', 'p88-native-raf-controlled-completed',
    '--result', 'P88原生rAF受控反證原exit為0/1/0，driver/outer/launcher各0；撤回是原refGuideMode焦點25秒等待fatal，實際錯點來源比例，非工具前提或transport假紅。完整349原件封包與三phase獨立審查保留；診斷只選完整P88，不冒正式grid/canvas。未確立按壓中位移的新產品缺陷，也未證像素可見性或歷史自然紅唯一因果。',
    '--next', '完成同F grid與四組native partial，再獨占跑P52及剩餘P73/Chromium154/oracle；舊無效query實驗保歷史。',
    '--receipt', str(proof)]
for label, path in inputs.items():
    command += ['--input', label + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=R).returncode)
