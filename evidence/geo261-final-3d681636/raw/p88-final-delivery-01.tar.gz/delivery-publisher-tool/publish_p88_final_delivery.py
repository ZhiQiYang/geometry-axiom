"""Record final body delivery separately from the immutable acceptance snapshot."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
B=Path('/workspace/geo288-main-merge-20261023')
F='3d681636902371ecc528b20f51eea33e272581c9'
E='5a76d815c843d7ffb06bd1be769d4c5255c72b66'
D='e008dc52510d8cdb34fe07c796835f2667e0ebaa'
body=B/'body-final-3d681636-completed-reviewed/PR_BODY.md'
expected='77fad4a11a92827d4b5d2b95423215c98dc13ecccce5c33e8c70e156c688e1f8'
assert hashlib.sha256(body.read_bytes()).hexdigest()==expected
assert body.read_bytes()==subprocess.check_output(['git','show',D+':PR_BODY.md'],cwd='/workspace/geo288-prbody-20261023')
load=lambda p:json.loads(p.read_text())
assert load(B/'p88-completed-prbody-publication-retry1/receipt.json')['exit_code']==0
peer=load(B/'p88-priority/final-body-completed-peer/CHECKS.json')
assert peer['review_exit']==0 and peer['failures']==[] and peer['body_sha256']==expected
branches=['codex/geo261-final-prbody-20261023','codex/geo288-p73-final-20261023','codex/geo288-p73-final-20261023-prbody','codex/geo288-oracle-final-20261023','codex/geo288-oracle-final-20261023-prbody']
observed=subprocess.check_output(['git','ls-remote','--heads','origin',*branches],cwd='/workspace/geometry-axiom')
heads={line.split()[1].removeprefix('refs/heads/'):line.split()[0] for line in observed.decode().splitlines()}
assert heads[branches[0]]==D
out=B/'p88-final-delivery';out.mkdir(exist_ok=False)
(out/'REMOTE_HEADS.txt').write_bytes(observed)
(out/'SUMMARY.json').write_text(json.dumps({'schema':'geo288-final-reviewed-delivery/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tested_product_sha':F,'complete_acceptance_evidence_snapshot':E,'prbody_branch':branches[0],'prbody_commit':D,'prbody_sha256':expected,'body_peer_checks':35,'body_peer_exit':0,'current_state_matrix_rows':32,'observed_child_heads':heads,'live_pr_body_updated':False,'pr_merged':False,'force_push_used':False,'scope':'All affected gates completed. F13/F2 inherited gates retain their actual execution SHA and closures in the only current-state matrix. This commit adds delivery metadata only, and does not relabel evidence commits as tested product SHA.','remaining_project_work':['#323 baseline has two negative-control failures and original N32/base and source-call scaling thresholds unmet; collecting all remaining gates before fixes','#314, combined #299/#316, #318, noWood source branches prepared; remaining dynamic acceptance follows scheduling and forward merge order'],'most_uncertain':['Historical natural P88 failure has no complete pointer trace; controlled stale-coordinate proof does not establish its unique cause or every possible human interaction','Inherited Cperf ratio1.970798 is close to2 with only the original three samples; no resampling or relaxed threshold'],'publication_metadata_failure':'First final-body preflight used the wrong peer field name; no body copied, publisher clean-tree guard exit1. Original capture retained; exact failures/review_exit schema verified, unchanged accepted body normal push exit0.'},ensure_ascii=False,indent=2)+'\n')
inputs={
 'delivery-summary':out,
 'final-body':body.parent,
 'final-body-peer':B/'p88-priority/final-body-completed-peer',
 'body-generation':B/'p88-completed-body-generation',
 'body-refinement':B/'p88-completed-body-refinement',
 'body-generator-tool':B/'write_p88_completed_prbody.py',
 'body-refinement-tool':B/'refine_p88_completed_prbody.py',
 'body-first-publication-failure':B/'p88-completed-prbody-publication',
 'body-publication-success':B/'p88-completed-prbody-publication-retry1',
 'body-publication-correction':B/'FINAL_BODY_PUBLICATION_CORRECTION.md',
 'body-publisher-tool':B/'publish_completed_prbody.py',
 'oracle-final-root-publication':B/'p88-final-oracle-root-publication',
 'latest-review-refresh':Path('/workspace/geo318-review-refresh-20261023-141051'),
 'p73-final-child-delivery':Path('/workspace/geo288-p73-owner-20261023/FINAL_DELIVERY_INDEX.json'),
 'delivery-publisher-tool':Path(__file__),
}
for name,path in inputs.items():assert path.exists(),str(path)
argv=['python3','-B','/workspace/geo261-environment/publish_followup_progress.py','--repo','/workspace/geometry-axiom','--branch','architecture/geo261-integration-20261016','--issue','261','--sha',F,'--label','p88-final-delivery','--result','本輪列定受影響正式項與反證全完成；完整驗收證據快照E='+E+'，唯一32列current-state正文35項獨審0，已一般推送prbody D='+D+'。正文逐列保留F13/F2真實沿用SHA、允許Windows GDI skip、P88因果及原Cperf樣本限制；新F沒有仍紅或未跑的列定受影響gate。此項僅交付metadata，未API編輯live PR、未合併PR、未force push。首次正文publisher metadata guard失敗1及原輸出保留，原已審正文不變正常續推0。','--next','接續#323收齊原基線全部紅再集中修；依323→314→299/316→318→noWood順序合流來源與完成各自驗收/正文，不合併PR。']
for name,path in inputs.items():argv+=['--input',name+'='+str(path)]
raise SystemExit(subprocess.run(argv,cwd='/workspace/geometry-axiom').returncode)
