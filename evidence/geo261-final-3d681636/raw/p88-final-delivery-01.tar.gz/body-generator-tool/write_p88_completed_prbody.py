"""Build one current-state matrix from completed, published original receipts."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
B=Path('/workspace/geo288-main-merge-20261023')
R=Path('/workspace/geometry-axiom')
F='3d681636902371ecc528b20f51eea33e272581c9'
E='5a76d815c843d7ffb06bd1be769d4c5255c72b66'
D='b48d3e0dce8fd6d898286a4fb1826d6476b53f33'
load=lambda p:json.loads(p.read_text())
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=B/'body-final-3d681636-grid-native-p52/PR_BODY.md'
assert original.read_bytes()==subprocess.check_output(['git','show',D+':PR_BODY.md'],cwd='/workspace/geo288-prbody-20261023')
for name in ['p52-final-runtime-completed-publication','p88-final-p73-root-publication','p88-final-chromium154-root-publication','p88-final-oracle-root-publication']:
 assert load(B/name/'receipt.json')['exit_code']==0,name
assert all(x.startswith('evidence/geo261-final-3d681636/') for x in subprocess.check_output(['git','diff','--name-only',F,E],cwd=R).decode().splitlines())
text=original.read_text().replace('fb95bf03868442fc02dff0d029a0a683a2b6bdae',E)
text=text.replace('P88 點擊定位修正與新 SHA 驗收','P88 點擊定位修正與最終驗收')
text=text.replace('grid、native四套補驗與P52亦通過；runtime、P73、Chromium154與oracle仍待結案，目前不宣告可合併。','grid、native四套補驗、P52及runtime、P73、Chromium154與oracle皆完成並通過獨立原件／公開封包審查。本輪列定項沒有仍紅或未跑項，可供複審；尚未合併PR。')
text=text.replace('其餘列定同F gate仍按下表逐項完成。原runtime反證在F13已關閉，但新P88來源改動影響RuntimeSnapshot輸入，仍安排F重驗。','列定同F gate已完成，原命令、exit、完整輸出與source hash均已封存。新P88來源改動影響RuntimeSnapshot輸入，P52／runtime與四組native已在F重驗；其餘沿用項仍列真實歷史SHA。')
url='https://github.com/ZhiQiYang/geometry-axiom/blob/'+E+'/evidence/geo261-final-3d681636/receipts/'
def row(prefix,value):
 global text
 old=[s for s in text.splitlines() if s.startswith(prefix)]
 assert len(old)==1,prefix
 text=text.replace(old[0],value)
row('| 額外P73 controlled |','| 額外P73 controlled | F 原fixed/withdrawn/restored 0/1/0；driver/outer/top皆0 | 原predicate在callback前皆true；撤回唯一guard到舊.hidden後，恰一次真產品callback使原具名斷言紅、exception0，恢復綠。731完整runtime inputs同F；受控callback反證不冒完整自然workflow。 | [新F原收據]('+url+'p88-final-p73-reviewed.json) |')
row('| 額外P52 runtime |','| 額外P52 runtime | F 原baseline/withdrawn/restored 0/1/0；driver/outer/launcher/parent皆0 | ratios0.889796209710257/1.0337406540912426/0.8462365083581334；原四區塊、每側16筆、≤1門檻、五freshness控制保留，沒有重抽樣。舊F13結果僅歷史。 | [新F原收據]('+url+'p88-final-p52-runtime-complete-raw.json) |')
row('| 額外Chromium154 P73 |','| 額外Chromium154 P73 | F 原driver/outer/top 0/0/0 | 固定154版本原P73 69/0 partial，proof_expectation_matches=true；84.124749832秒≤35min、exception0。唯一UIUX_FIX_ONLY，原golden未比較；不冒154撤回反證、fullcanvas或舊產品曾綠。 | [新F原收據]('+url+'p88-final-chromium154-reviewed.json) |')
oracle='[新F八階段原收據]('+url+'p88-final-oracle-reviewed.json)'
row('| oracle/probe 1 selftest --quick |','| oracle/probe 1 selftest --quick | F 原0，386.294秒 | 原39850建構/掃描、579凹角房×8與odd矩形1872；保原golden、不write-expected。原P182-t4已知C11_MAIN_NOT_BUTTED6次文字照留，非新assert紅；F仍原step528/1056政策，閱讀A變更在#318另分支。 | '+oracle+' |')
row('| oracle/probe 2 test_gen_scenes |','| oracle/probe 2 test_gen_scenes | F 原0 | 真Ran60/OK完整unittest；85個輸入、68個fixtures及source前後同F；不冒native真probe或歷史159mutants。 | '+oracle+' |')
row('| oracle/probe 3 C4 |','| oracle/probe 3 C4 | F 原0/1/0 | 具名C4NEG bad8/0/8，原單一撤回及逐bytes恢復；不是setup/crash紅。 | '+oracle+' |')
row('| oracle/probe 4 core_limits |','| oracle/probe 4 core_limits | F 原0/1/0 | 原具名方法；撤回為正常AssertionError 2!=1、errors0，恢復綠。 | '+oracle+' |')
text=text.replace('runtime完整補包有1633列冊檔（713實際入包、920可重建cache排除），272份原命令streams/log引用全覆蓋；第一不完整包沒有刪掉。','F13 runtime完整補包有1633列冊檔（713實際入包、920可重建cache排除），272份原命令streams/log引用全覆蓋；第一不完整包沒有刪掉。新F另完成獨立runtime封包：828個公開成員；1633個stage列冊檔中的713入包、920cache明列排除，連outer／launch／execution共286份原輸出與log全覆蓋。')
text=text.replace('尚未結案項目已在唯一矩陣逐項標示。P88已有新F三次完整canvas綠與同序列有效0/1/0反證；','本輪列定正式項與反證已完成；唯一矩陣仍明列F13／F2沿用範圍，沒有將舊執行改標新F。P88已有新F三次完整canvas綠與同序列有效0/1/0反證；')
text=text.replace('全部普通push；不force push、不合併PR。','全部普通push；不force push、不合併PR。#323已在自己的分支接續新基線驗收，其兩項測試反證紅與≤1.3門檻另案處理，不混入#288的結案結果。')
assert text.count('| Gate |')==1
matrix=[s for s in text.splitlines() if s.startswith('| ')][2:]
assert len(matrix)==32,len(matrix)
assert not any('待跑' in s or '執行中' in s or '尚無終態' in s for s in matrix)
links=[]
for sha,path in re.findall(r'https://github\.com/ZhiQiYang/geometry-axiom/blob/([0-9a-f]{40})/([^\s)]+)',text):
 if path.startswith('handoff/'):
  continue
 subprocess.run(['git','cat-file','-e',sha+':'+path],cwd=R,check=True)
 links.append({'sha':sha,'path':path})
out=B/'body-final-3d681636-completed';out.mkdir(exist_ok=False)
(out/'PR_BODY.md').write_text(text)
(out/'BINDING.json').write_text(json.dumps({'product_sha':F,'evidence_head':E,'prior_body_commit':D,'prior_body_sha256':h(original),'body_sha256':h(out/'PR_BODY.md'),'matrix_rows':len(matrix),'verified_immutable_git_links':links,'live_pr_updated':False,'scope':'Current affected gates complete; inherited gates retain their real historical execution SHA'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'body':str(out/'PR_BODY.md'),'sha256':h(out/'PR_BODY.md'),'product_sha':F,'evidence_head':E,'matrix_rows':len(matrix),'git_links_checked':len(links)},ensure_ascii=False))
