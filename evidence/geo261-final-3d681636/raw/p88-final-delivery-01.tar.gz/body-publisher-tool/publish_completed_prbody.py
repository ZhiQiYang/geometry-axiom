"""Normally commit and push the reviewed current-state PR body only."""
from pathlib import Path
import json
import subprocess

repo = Path('/workspace/geo288-prbody-20261023')
branch = 'codex/geo261-final-prbody-20261023'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()
assert git('branch', '--show-current') == branch
assert git('status', '--porcelain=v1', '--untracked-files=all') == 'M PR_BODY.md'
assert git('diff', '--name-only') == 'PR_BODY.md'
for command in (['git', 'add', '--', 'PR_BODY.md'], ['git', 'diff', '--cached', '--check'], ['git', 'commit', '-m', 'Document completed GEO-261 final acceptance'], ['git', 'push', 'origin', 'HEAD:refs/heads/' + branch]):
    subprocess.run(command, cwd=repo, check=True)
head = git('rev-parse', 'HEAD')
assert git('ls-remote', '--heads', 'origin', branch).split()[0] == head
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
print(json.dumps({'branch': branch, 'head': head, 'file': 'PR_BODY.md', 'live_pr_updated': False}))
