"""Clarify the formal-baseline controls and record the fresh review read."""
from pathlib import Path
import hashlib
import json
B=Path('/workspace/geo288-main-merge-20261023')
source=B/'body-final-3d681636-completed/PR_BODY.md'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(source)=='dbe9d9c8ff826e4ef1d5fa19f608bcb880d9c06a7263b880805ac0900bc4c81f'
text=source.read_text()
old='原四區塊、每側16筆、≤1門檻、五freshness控制保留，沒有重抽樣。'
new='runtime兩phase各保原四區塊、每側16筆及≤1門檻；五freshness控制由同F正式P52 baseline提供，沒有重抽樣。'
assert text.count(old)==1;text=text.replace(old,new)
old='已重新fetch並讀[handoff最新審查全文]'
assert text.count(old)==1;text=text.replace(old,'已於2026-10-23T14:10:51Z重新fetch並讀[handoff最新審查全文]')
out=B/'body-final-3d681636-completed-reviewed';out.mkdir(exist_ok=False)
(out/'PR_BODY.md').write_text(text)
binding=json.loads((source.parent/'BINDING.json').read_text())
binding.update(prior_draft_sha256=h(source),body_sha256=h(out/'PR_BODY.md'),narrow_changes=['Runtime five controls are supplied by the exact same-F formal baseline; two runtime timing phases remain separate','Fresh authoritative review fetch time; same acd commit and ee28481 comment'],fresh_review_record='/workspace/geo318-review-refresh-20261023-141051/SOURCE.json')
(out/'BINDING.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'body':str(out/'PR_BODY.md'),'sha256':h(out/'PR_BODY.md')}))
