"""Publish completed independent reviews before the single sequence publisher starts."""
from pathlib import Path
import json
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
repo = Path('/workspace/geometry-axiom')
peer = Path('/workspace/geo299316-refresh-20261023/p88-input-closure-review')
inputs = {
    'architecture_peer': B / 'p88-architecture-peer-final-3d681636',
    'scan_correction_review': peer / 'SCAN_IDENTITY_CORRECTION_REVIEW.md',
    'scan_correction_checks': peer / 'SCAN_IDENTITY_CORRECTION_CHECKS.json',
    'scan_execution_review': peer / 'SCAN_IDENTITY_CORRECTED_EXECUTION_ADDENDUM.md',
    'scan_execution_checks': peer / 'SCAN_IDENTITY_CORRECTED_EXECUTION_CHECKS.json',
    'latest_review': B / 'p88-latest-review.md',
    'review_handoff_sha': B / 'p88-latest-review-sha.txt',
    'query_observation_v1': B / 'p88-priority/ACTUAL_QUERY_OBSERVATIONS.json',
    'query_observation_v2': B / 'p88-priority/ACTUAL_QUERY_OBSERVATIONS_v2.json',
    'final_checkout': B / 'p88-priority/final-checkout-3d681636',
    'final_sparse': B / 'p88-priority/final-sparse-3d681636',
    'final_launch_request': B / 'p88-priority/final-3d681636-launch.request.json',
    'final_driver_peer': Path('/tmp/geo323-merge-20261023/P88_FINAL_THREE_CANVAS_STATIC_REVIEW.json'),
    'publisher_original': B / 'publish_p88_final_sequence.before-peer.py.txt',
    'publisher_current': B / 'publish_p88_final_sequence.py',
    'publisher_peer': peer / 'FINAL_CANVAS_PUBLISHER_REVIEW.md',
    'publisher_peer_checks': peer / 'FINAL_CANVAS_PUBLISHER_CHECKS.json',
    'metadata_publisher': Path(__file__),
}
summary = B / 'P88_FINAL_PEER_METADATA.json'
summary.write_text(json.dumps({
    'schema': 'geo288-p88-final-peer-metadata/1', 'tested_sha': F,
    'review_handoff_sha': '7bd61a43210bbad0abf95709e1a0205cd8760cac',
    'review_head': '1999cbc', 'review_utc': '2026-10-23T10:40:30Z',
    'architecture_original_exits': [0, 0, 0], 'architecture_unittest_counts': [205, 18],
    'scan_bytes_unchanged': True, 'input_identity_metadata_corrected_exit': 0,
    'query_diagnostic_exits': [1, 1, 1], 'query_diagnostic_valid_counterproof': False,
    'v2_correction': 'parsed_json_unchanged is true; this does not claim wire bytes identity',
    'canvas_sequence': 'running; no completed results inferred',
    'remaining': ['three complete canvas runs', 'grid', 'four original native partial suites',
                  'P52 formal/verifier/runtime', 'P73', 'Chromium154', 'oracle',
                  'trace-supported original-rAF P88 withdrawal/restoration proof'],
}, ensure_ascii=False, indent=2) + '\n')
command = ['python3', '-B', str(B / 'record_command.py'), '--out', str(B / 'p88-final-peer-publication'),
    '--sha', F, '--cwd', str(repo), '--variant', 'completed-peer-metadata-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py', '--repo', str(repo),
    '--branch', 'architecture/geo261-integration-20261016', '--issue', '261', '--sha', F,
    '--label', 'p88-final-independent-reviews',
    '--result', '新F架構實跑0/0/0與205/18個原測試經獨立核對；scan重產bytes相同，修正metadata假設後identity0。最新審查head1999cbc已讀；P88舊三輪1/0/0、query診斷1/1/1無效反證均保留。新F三輪原canvas仍執行中，未宣告通過。',
    '--next', '逐輪自動封存canvas所有終態；補完同F受影響gates與原rAF撤回反證，改寫唯一current-state正文。',
    '--receipt', str(summary)]
for label, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing evidence: ' + str(path))
    command += ['--input', label + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=repo).returncode)
