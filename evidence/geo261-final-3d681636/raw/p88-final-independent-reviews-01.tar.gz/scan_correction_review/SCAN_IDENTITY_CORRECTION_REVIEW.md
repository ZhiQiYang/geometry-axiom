# P88 input-delta scan 身分補正靜審

受審新 F：`3d681636902371ecc528b20f51eea33e272581c9`。原 collector SHA256 ca2628c092f32c43363fde75340d840dcacf18e5037db9d50d5a6103e0f849a8 的 metadata 執行確為 exit1：八個原 Git 子命令均0，失敗點是要求四份衍生檔全部必須出現在 diff。原失敗收據仍是 passed_identity_guards=false，沒有把它改成通過。

候選補正 SHA256：`f3dfdec4a5b5ed4b3467452636788bcf080e3c8320457bb032adf5b301c611f4`；已從保存的 ca262 原bytes獨立按兩個唯一錨點重建候選，hash與BINDING一致，correction.patch逐bytes可重建。除了精確path集合／scan硬同一性與將較早依賴審查標成historical以外，無其他改動，原native四套範圍、退出與原來源身分標示不變。

未見本次修正掩蓋來源變更。獨立 Git diff核得 F13→新 F（排除唯一既有出版prefix）只有 P88 driver、architecture manifest、receipt、MD 四path；scan在兩個tree均100644/blob/72a42be8a319b9f43c38d5c1362d5bcd765485d0。候選仍用四path精確集合相等，不是允許subset；任何額外來源／測試／policy／fixture path都會紅。另對scan整個mode/type/oid字典硬相等，scan內容、種類、模式的任何變更均會紅。P88 mode/blob與其餘出版守門都保留。

此靜審只證tracked Git identity、候選差分與原失敗身分，不靠collector證明四檔生成已執行，更不代替新F裁判／完整產品驗收。檢查時live collect_p88_input_delta.py仍為原ca262；接受的是可重建f3df候選，不宣稱已安裝或執行候選。未import／執行任何受審collector、產品、scan、編譯、測試或Chrome。
