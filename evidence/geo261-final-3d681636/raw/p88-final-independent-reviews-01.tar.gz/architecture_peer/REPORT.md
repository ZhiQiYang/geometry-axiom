# P88 Linux 架構重產與安裝：獨立唯讀核對

核對完成，未見本輪已列範圍中的新阻擋。只讀既有收據／原stdout與stderr／四份衍生Git blobs；沒有掃描601產品來源、重跑judge、import產品、編譯或執行瀏覽器。原始核對與read-only Git紀錄在同目錄，最終機器原件為 `FINAL_REVIEW.json`，SHA256 `10a8aa580417b0030b13eeffa62991af6d55c2d32036c258312dfd5ed5a0aeda`。

| 階段 | 原來源與結果 |
|---|---|
| 舊manifest原preflight | S=`4b588fb63c9cc8fe5ba7570618f353c0d00d3816`，原exit1／0／5；scanner只報指定P88 EXCLUSION_DIGEST；product為setUpClass拒絕且Ran0，沒有冒成跑過18方法 |
| Linux重產後外部完整驗證樹 | 真sourceBaseHead仍S，外部cwd如實記錄、沒有冒獨立Git SHA；原三條exit0／0／0；generic205、product18，raw正常OK |
| 安裝及普通出版 | F=`3d681636902371ecc528b20f51eea33e272581c9`，唯一parent為S；原commit／push／ls-remote為0、遠端F核同，沒有force push |
| 新F正式原三裁判 | 同F前後clean，原三條exit0／0／0；原argv、source_sha／acceptance_sha、cwd、環境、raw bytes／hash均核同；generic205、product18，raw正常OK |

manifest唯一byte替換是既有 `geometry-web/grid_rule_lines_test.js` LF digest：`c47259607a3299d49e1044f3d4d6e5561c0601e0f2295fb7ec5f2255261f4e8c` → `8106476b6eb2271111caa835a863b72eced4bab3b2ef77244f28534d83ca0a52`。還原這一欄後，manifest全部bytes／語意、333 owned登記、policy、root、layer、reason、routes與其他分類均保原值；601 inputs中也只有此一LF hash變。counts完整等前份sealed receipt：601 executable、333 owned、268 excluded、796 edges、0 diagnostics，W guard920 identifiers／55 strings。

四個產物檔案的bytes／hash均驗原RESULT、主receipt封值、安裝紀錄及F實際Git blob。scan重產raw bytes與舊版相同，SHA256為 `1feb5b2899a20e2a7ba0f1be2ecac8195fbc444111dba304671cacfb7d75bdb1`；因此實際staged與Git diff都只有manifest、report、receipt三檔，符合預期，沒有把scan未入diff當成未重產。

前份sealed receipt、新外部樹與新F的原suite數量皆205／18。先前11／57是準備工具的require-call計數，不能當unittest數量或另立驗收門檻。本peer不外推native、ledger、canvas、grid或其他專項的結果；grid仍待root三輪canvas後的獨占時槽。
