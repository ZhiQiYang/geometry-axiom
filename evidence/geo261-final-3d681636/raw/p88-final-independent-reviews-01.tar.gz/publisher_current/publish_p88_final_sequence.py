"""Root-only publication of each terminal new-F canvas round, including failures."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
source = B / 'p88-priority/final-3d681636'
repo = Path('/workspace/geometry-axiom')
out = B / 'p88-final-sequence-publication'
out.mkdir(exist_ok=False)
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def publish(label, result, inputs, receipt, directory):
    command = ['python3', '-B', str(B / 'record_command.py'), '--out', str(directory),
        '--sha', F, '--cwd', str(repo), '--variant', 'evidence-only-publication', '--',
        'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py', '--repo', str(repo),
        '--branch', 'architecture/geo261-integration-20261016', '--issue', '261', '--sha', F,
        '--label', label, '--result', result,
        '--next', '依固定新F收齊三次canvas，再跑grid、四native partial與列定反證；所有紅燈保留，未完成項不算通過。',
        '--receipt', str(receipt)]
    for key, path in inputs.items():
        command += ['--input', key + '=' + str(path)]
    with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
        result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
    return result.returncode

for index in (1, 2, 3):
    while True:
        try:
            sequence = json.loads((source / 'sequence-receipt.json').read_text())
            row = next(r for r in sequence['runs'] if r['index'] == index)
            if row.get('ended_utc'):
                break
        except (FileNotFoundError, json.JSONDecodeError, StopIteration):
            pass
        time.sleep(10)
    if sequence['sha'] != F or row['sha'] != F:
        raise RuntimeError('Unexpected sequence source')
    snapshot = out / ('run-' + str(index) + '-snapshot')
    snapshot.mkdir()
    (snapshot / 'sequence-at-completion.json').write_text(json.dumps(sequence, ensure_ascii=False, indent=2) + '\n')
    (snapshot / 'terminal-row.json').write_text(json.dumps(row, ensure_ascii=False, indent=2) + '\n')
    for name in ('run_canvas_workflow.py', 'sequence-driver.py', 'BINDING.json',
                 'driver-binding.diff', 'original_run_workflow_round.py.txt',
                 'run-' + str(index) + '.stdout', 'run-' + str(index) + '.stderr'):
        path = source / name
        shutil.copy2(path, snapshot / name)
    for path in source.glob('before-*'):
        if path.is_file():
            shutil.copy2(path, snapshot / path.name)
    shutil.copy2(B / 'p88-priority/final-3d681636-launch.request.json', snapshot / 'sequence-launch.request.json')
    shutil.copy2(__file__, snapshot / 'publisher.py.txt')
    inputs = {'snapshot': snapshot}
    scratch = Path('/tmp/g288p88f' + str(index))
    outer = source / 'outers' / ('p88-final-3d681636-canvas-' + str(index))
    if scratch.exists():
        inputs['run'] = scratch
    if outer.exists():
        inputs['outer'] = outer
    receipt = Path(row['receipt']) if row.get('receipt') else snapshot / 'terminal-row.json'
    if row.get('receipt') and digest(receipt) != row['receipt_sha256']:
        raise RuntimeError('Sealed original receipt changed')
    result = (f"新F完整canvas第{index}/3：process_completed={row.get('process_completed')}，"
        f"receipt_verified={row.get('completed')}，accepted={row.get('accepted')}；"
        f"launcher/outer/workflow/node原exit={row.get('launcher_exit')}/{row.get('outer_exit')}/"
        f"{row.get('original_workflow_exit')}/{row.get('original_node_exit')}，"
        f"seconds={row.get('seconds')}，over_ci_timeout={row.get('over_ci_timeout')}。原35min與golden未改，全部結果保留。")
    label = 'p88-final-canvas-run-' + str(index)
    exit_code = publish(label, result, inputs, receipt, out / ('run-' + str(index) + '-publisher'))
    record = {'index': index, 'original_run': row, 'publication_exit': exit_code,
              'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()}
    (out / ('run-' + str(index) + '-publication.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)
    if exit_code:
        raise SystemExit(exit_code)

while True:
    sequence = json.loads((source / 'sequence-receipt.json').read_text())
    if sequence.get('driver_exit_code') is not None:
        break
    time.sleep(2)
final = out / 'final-summary'
final.mkdir()
shutil.copy2(source / 'sequence-receipt.json', final / 'sequence-receipt.json')
for path in source.glob('after-*'):
    if path.is_file():
        shutil.copy2(path, final / path.name)
result = '新F三輪canvas全收齊；原workflow exits=' + '/'.join(str(r.get('original_workflow_exit')) for r in sequence['runs']) + '；all_three_accepted=' + str(sequence['all_three_accepted']) + '；driver_exit=' + str(sequence['driver_exit_code']) + '。逐輪原收據已封存；其他受影響項與反證仍須各自結案。'
exit_code = publish('p88-final-canvas-three-summary', result, {'summary': final}, final / 'sequence-receipt.json', out / 'summary-publisher')
(out / 'summary-publication.json').write_text(json.dumps({'publication_exit': exit_code,
    'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()}, indent=2) + '\n')
print(result, flush=True)
raise SystemExit(exit_code)
