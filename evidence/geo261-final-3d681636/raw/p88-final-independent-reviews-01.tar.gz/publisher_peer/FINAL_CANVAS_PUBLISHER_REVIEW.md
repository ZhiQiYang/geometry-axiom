# 新 F 三輪 canvas root publisher 靜審

初版8ae8749d的狀態判斷核對原sequence producer：每row只有完成原程序及收據檢核（或保存error）後才寫ended_utc，producer以tmp→replace原子寫JSON。publisher等ended_utc而非completed/accepted，所以收據錯誤／原測試紅都能封存；process_completed、completed（receipt_verified）、accepted分列，launcher／outer／workflow／node四退出原樣留在row與結果文字。publisher的exit只代表publication，沒有用它覆蓋產品結果。

初版有確立封存缺口：只copy兩個before stdout，漏before-index完整Git輸出及原command/stderr、sequence driver與綁定原件。root已補成最終SHA256 `af30087a6661e097a9adbd83ed22e58140011c5281a158165edddd7ca4efdf81`。獨立逆向唯一snapshot block後精確還原原8ae8749d hash，故其他等待／判決／publish邏輯不變；所有before-*、實際sequence-driver、BINDING、driver diff、原workflow source與top launch request均納入。當前固定輸入全存在，包括3,890,741bytes的before-index stdout。每輪收據hash若變則fail closed，不改造收據。

限定範圍未見剩餘阻擋。每輪使用原record_command/c387與publish_followup_progress、同一新F/geo261-final-3d681636 prefix、一般git push；三輪依序發布，再等driver_exit_code有終值才發布包含after-*的全三summary。紅燈不被篩掉，已驗證／接受仍依原row；若receipt缺失用terminal-row保存失敗身分及存在的raw，而非補造綠。輸出目錄fresh要求防重複啟動；root仍須保持唯一integration index writer。出版失敗時保原publication exit後停止，需root修環境接續，不能當產品綠。

這是只讀AST／文字／hash審查，未啟publisher、未commit/push integration、未跑測試／scan／編譯／Chrome。它不證明尚未終態的三輪已完整封包、遠端已接受push或產品全綠；每輪終態後仍依原收據、封包inventory、真publish exit/remote核對。本次一次讀取誤用不存在的run_three_canvas.py路徑所產sed exit2只是閱讀定位失誤，已讀正確sequence-driver.py，不屬產品紅或被隱藏的驗收輸出。
