"""Prepare the root-authorized independent maintenance lock; no retirement."""
from pathlib import Path
import ast,difflib,hashlib,json,os
BASE=Path('/workspace/kernel-no-wood-prep/completed-checkout-retirement')
TOOLS=BASE/'tools'
old=TOOLS/'retire_guarded.py';new=TOOLS/'retire_guarded_maintenance.py'
h=lambda raw:hashlib.sha256(raw).hexdigest()
original=old.read_bytes();assert h(original)=='5d2de090e34a65f51fab9c054ead5b06425d38361d330de2dd741eae52c8310c'
before=b"HEAVY_LOCK = Path('/tmp/g261r3/heavy.lock')"
after=b"HEAVY_LOCK = Path('/tmp/geo261-completed-checkout-maintenance.lock')"
assert original.count(before)==1 and not new.exists()
raw=original.replace(before,after,1);ast.parse(raw);new.write_bytes(raw)
patch=''.join(difflib.unified_diff(original.decode().splitlines(True),raw.decode().splitlines(True),
 fromfile='guarded-current3-R3-original.py',tofile='guarded-current3-maintenance.py'))
(TOOLS/'maintenance-lock-only.patch').write_text(patch)
runner=TOOLS/'run_maintenance.py'
runner.write_text("from pathlib import Path\nimport sys\nimport retire_guarded_maintenance as tool\ntool.BASE=Path('/workspace/kernel-no-wood-prep/completed-checkout-retirement/executions-maintenance')\ntool.BASE.mkdir(exist_ok=True)\nif __name__=='__main__':\n    if len(sys.argv)!=2 or sys.argv[1] not in tool.CASES: raise SystemExit('Only the three reviewed fixed case labels are accepted')\n    raise SystemExit(tool.run(sys.argv[1]))\n")
lock=Path('/tmp/geo261-completed-checkout-maintenance.lock')
if not lock.exists():
 fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
assert lock.is_file() and not lock.is_symlink() and lock.resolve()==lock
preflight=json.loads((BASE/'PREFLIGHT.json').read_text())
assert not preflight['errors'] and all(case['passed'] for case in preflight['cases'])
binding=dict(schema='root-authorized-completed-checkout-maintenance-lock-only/1',
 root_authorization='Slot2 only for three completed tmp checkouts, then pass same maintenance lock to owner299. Original native/R3 remains untouched.',
 original_v3_path='/workspace/geo288-main-merge-20261023/cold-checkout-retirement-tools-v3/retire_guarded.py',
 original_v3_sha256=preflight['original_v3_sha256'],
 fixed_three_original_R3_tool=str(old),fixed_three_original_R3_sha256=h(original),
 maintenance_tool=str(new),maintenance_tool_sha256=h(raw),maintenance_wrapper=str(runner),maintenance_wrapper_sha256=h(runner.read_bytes()),
 diff=str(TOOLS/'maintenance-lock-only.patch'),diff_sha256=h(patch.encode()),
 original_v3_to_fixed_cases_diff=str(TOOLS/'fixed-case-adaptation.patch'),
 raw_guard_input=str(TOOLS/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json'),
 raw_guard_input_sha256=h((TOOLS/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json').read_bytes()),
 preflight=str(BASE/'PREFLIGHT.json'),preflight_sha256=h((BASE/'PREFLIGHT.json').read_bytes()),
 maintenance_lock=str(lock),original_R3='/tmp/g261r3/heavy.lock',original_R3_modified=False,
 failed_original_attempt_receipt=str(BASE/'executions/cold-checkout-retirement-v3-canvas/receipt.json'),
 failed_original_attempt_exit=75,original_attempt_materialization_changed=False,
 cases=preflight['cases'],retirement_executed=False,
 preserved_guards=['HEAD/tree/root/gitdir','index stages','refs','no non-evidence product delta',
  'exact original sparse-pattern SHA256','ignored/untracked/empty/special node rejection',
  'independent readable cwd/cmdline consumers','five original raw receipts before/after',
  'actual only AGENTS tracked node after retirement','Git objects/refs/raw no deletion'])
(BASE/'MAINTENANCE_PREPARATION.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:binding[key] for key in ('maintenance_tool','maintenance_tool_sha256','maintenance_wrapper','maintenance_wrapper_sha256','diff','diff_sha256','maintenance_lock')},ensure_ascii=False))
