"""Root-authorized fixed three-case retirement; original v3 resource lock stays."""
from pathlib import Path
import sys
import retire_guarded

retire_guarded.BASE=Path('/workspace/kernel-no-wood-prep/completed-checkout-retirement/executions')
retire_guarded.BASE.mkdir(exist_ok=True)
if __name__=='__main__':
    if len(sys.argv)!=2 or sys.argv[1] not in retire_guarded.CASES:
        raise SystemExit('Only the three reviewed fixed case labels are accepted')
    raise SystemExit(retire_guarded.run(sys.argv[1]))
