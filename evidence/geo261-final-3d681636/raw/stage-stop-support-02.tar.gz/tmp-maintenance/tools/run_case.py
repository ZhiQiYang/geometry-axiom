from retire_guarded import run
import sys
if __name__=='__main__':
    raise SystemExit(run(sys.argv[1]))
