from pathlib import Path
import sys
import retire_guarded_maintenance as tool
tool.BASE=Path('/workspace/kernel-no-wood-prep/completed-checkout-retirement/executions-maintenance')
tool.BASE.mkdir(exist_ok=True)
if __name__=='__main__':
    if len(sys.argv)!=2 or sys.argv[1] not in tool.CASES: raise SystemExit('Only the three reviewed fixed case labels are accepted')
    raise SystemExit(tool.run(sys.argv[1]))
