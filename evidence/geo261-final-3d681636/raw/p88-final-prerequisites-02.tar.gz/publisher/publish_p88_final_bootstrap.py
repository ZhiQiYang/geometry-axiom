"""Archive actual P88 final prerequisites, including unsuccessful diagnostic evidence."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
S = '4b588fb63c9cc8fe5ba7570618f353c0d00d3816'
repo = Path('/workspace/geometry-axiom')
package = B / 'p88-architecture-refresh-package'
shutil.copytree('/tmp/g288p88arch-one-4b588fb6', package,
                ignore=shutil.ignore_patterns('validation-tree', 'tmp', '__pycache__'))
(package / 'REBUILDABLE_EXCLUSIONS.json').write_text(json.dumps({
    'excluded': ['refresh/validation-tree/', 'refresh/tmp/'],
    'reason': 'Rebuildable validation source copies and scratch only; original commands/streams, original/new four artifacts, complete source identity and binding retained.'}, indent=2) + '\n')
arch = json.loads((B / 'p88-final-architecture/receipt.json').read_text())
ledger = json.loads((B / 'p88-final-ledger/receipt.json').read_text())
delta = json.loads((B / 'p88-input-delta-scan-corrected-3d681636/receipt.json').read_text())
if arch['sha'] != F or ledger['sha'] != F or arch['exit_code'] != 0 or ledger['exit_code'] != 0:
    raise RuntimeError('Original prerequisite result is not complete and green')
exits = [x['original_command_result']['actual_process_returncode'] for x in arch['steps']]
if exits != [0, 0, 0] or not delta['passed_identity_guards']:
    raise RuntimeError('Original architecture or input identity guard failed')
summary = {'schema': 'geo288-p88-final-prerequisites/1', 'tested_sha': F,
    'architecture_source_sha': S, 'candidate_source_sha': '8bce9239c014f070740455556c8ee1176c500af3',
    'ledger_check_exit': ledger['exit_code'], 'ledger_regenerated': False,
    'architecture_original_exits': exits,
    'changed_nonpublication_paths': delta['nonpublication_changed_paths'],
    'four_architecture_files_regenerated': True, 'scan_bytes_unchanged': True,
    'input_delta_original_metadata_exit': 1, 'input_delta_corrected_metadata_exit': 0,
    'metadata_error': 'Original collector wrongly required the regenerated scan to change; corrected exact path set additionally requires unchanged scan mode/blob. Not a product test assertion change.',
    'old_original_canvas': {'sha': '13d02c1db7022145a52ee063286a558e595eb212', 'exits': [1, 0, 0], 'classification': 'intermittent'},
    'query_diagnostic': {'base_sha': '13d02c1db7022145a52ee063286a558e595eb212',
        'variant': 'explicit in-memory v5/original/v5 with observation/scheduling tools',
        'original_test_exits': [1, 1, 1], 'driver_exit': 2, 'valid_counterproof': False,
        'reason': 'Controlled query did not produce the requested wrong-target displacement; tool precondition failure, not original focus assertion. No natural single-cause proof.'},
    'remaining': ['three consecutive full canvas rounds (running)', 'grid',
        'original partial native: test_local_launcher/test_modeling_transport/test_serve/node:tests-js',
        'P52 formal/verifier/runtime withdrawal', 'P73 controlled', 'Chromium154 P73 subset', 'oracle counterproofs'],
    'original_full_native_and_four_unaffected_browsers_execution_sha': '13d02c1db7022145a52ee063286a558e595eb212',
    'nine_inherited_specials_execution_sha': '8f76f2b7d6f669670e5834310bfc26495b4a4aa6',
    'status': 'Prerequisites passed; final affected dynamic gates remain pending.'}
summary_path = B / 'P88_FINAL_PREREQUISITES.json'
summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
inputs = {
    'architecture_refresh': package, 'architecture_refresh_outer': B / 'p88-architecture-refresh-outer',
    'architecture_install': B / 'p88-architecture-install-publication',
    'architecture_installer': B / 'install_p88_architecture_final.py',
    'architecture_installer_binding': B / 'p88-final-install-binding.json',
    'source_merge': B / 'p88-source-merge', 'source_merge_outer': B / 'p88-source-merge-outer',
    'source_immutable_peer': Path('/tmp/geo323-merge-20261023/P88_V5_IMMUTABLE_8bce9239_REVIEW.json'),
    'final_source': B / 'P88_FINAL_SOURCE.json', 'ledger': B / 'p88-final-ledger',
    'ledger_outer': B / 'p88-final-ledger-outer', 'architecture': B / 'p88-final-architecture',
    'architecture_outer': B / 'p88-final-architecture-outer',
    'input_delta_original': B / 'p88-input-delta-3d681636',
    'input_delta_correction': B / 'input-delta-scan-identity-correction',
    'input_delta_corrected': B / 'p88-input-delta-scan-corrected-3d681636',
    'input_delta_corrected_tool': B / 'collect_p88_input_delta_scan_identity.py',
    'fixture_identity': B / 'p88-fixtures-3d681636',
    'native_fixture_identity': B / 'p88-native-identity-3d681636',
    'diagnostic_raw_archive': B / 'p88-priority/query-diagnostic-archive',
    'diagnostic_fixed_peer_md': Path('/tmp/geo323-merge-20261023/P88_QUERY_FIXED_TRACE_REVIEW.md'),
    'diagnostic_fixed_peer_json': Path('/tmp/geo323-merge-20261023/P88_QUERY_FIXED_TRACE_REVIEW.json'),
    'diagnostic_remaining_peer_md': Path('/tmp/geo323-merge-20261023/P88_QUERY_REMAINING_PHASES_REVIEW.md'),
    'diagnostic_remaining_peer_json': Path('/tmp/geo323-merge-20261023/P88_QUERY_REMAINING_PHASES_REVIEW.json'),
    'q38_checkout_materialization': B / 'q38-materialization-retirement',
    'q38_checkout_materialization_outer': B / 'q38-materialization-retirement-outer',
    'publisher': Path(__file__),
}
command = ['python3', '-B', str(B / 'record_command.py'), '--out', str(B / 'p88-final-bootstrap-publication'),
    '--sha', F, '--cwd', str(repo), '--variant', 'final-prerequisite-evidence-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py', '--repo', str(repo),
    '--branch', 'architecture/geo261-integration-20261016', '--issue', '261', '--sha', F,
    '--label', 'p88-final-prerequisites', '--result', '新F可解析；帳本原check0仍fresh、架構原0/0/0；P88單檔修正與Linux四檔已提交。舊原三輪1/0/0確認間歇；真query診斷三phase1/1/1、driver2為位移前提不成立，不冒有效反證。新F三次完整canvas已啟，其餘受影響項待跑。',
    '--next', '收齊新F三次完整canvas後執行grid、四native partial與四組反證；每輪保留原exit/streams/hash，更新唯一current-state正文。',
    '--receipt', str(summary_path)]
for label, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing raw evidence: ' + str(path))
    command += ['--input', label + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=repo).returncode)
