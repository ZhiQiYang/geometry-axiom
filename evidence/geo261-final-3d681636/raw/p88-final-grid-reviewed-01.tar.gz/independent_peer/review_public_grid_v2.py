"""Verify immutable public grid blobs and the archive against original records."""
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
REPORT = HERE / 'PUBLIC_GRID_CHECKS_v2.json'
assert not REPORT.exists(), 'Preserve earlier attempts'
REPO = '/tmp/g288-final-grid-checkout-3d681636'
F = '3d681636902371ecc528b20f51eea33e272581c9'
E = 'b12172860c59fe091c0e490630b548281b2eb53a'
PREFIX = 'evidence/geo288-final-3d681636/'
report = {'schema': 'geo288-grid-publication-peer/1', 'product_sha': F, 'evidence_sha': E,
          'commands': [], 'checks': [], 'exit_code': None}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(args):
    p = subprocess.run(['git', *args], cwd=REPO, capture_output=True)
    report['commands'].append({'argv': ['git', *args], 'cwd': REPO, 'exit_code': p.returncode,
                              'stdout_bytes': len(p.stdout), 'stdout_sha256': sha(p.stdout),
                              'stderr_bytes': len(p.stderr), 'stderr_sha256': sha(p.stderr)})
    assert p.returncode == 0, args
    return p.stdout

def blob(path):
    return git(['show', E + ':' + PREFIX + path])

def check(name, condition, detail=None):
    report['checks'].append({'name': name, 'passed': bool(condition), 'detail': detail})
    assert condition, name

try:
    files = git(['ls-tree', '-r', '--name-only', E, '--', PREFIX]).decode().splitlines()
    changed = git(['diff', '--name-only', F, E]).decode().splitlines()
    check('F-to-E only own evidence prefix', changed and all(p.startswith(PREFIX) for p in changed))
    sum_rows = [row.split('  ', 1) for row in blob('SHA256SUMS').decode().splitlines()]
    check('SHA256SUMS covers all public files except itself', {p for _, p in sum_rows} == {p[len(PREFIX):] for p in files if p != PREFIX + 'SHA256SUMS'})
    saved = {}
    for digest, path in sum_rows:
        data = blob(path)
        check('public Git blob hash ' + path, sha(data) == digest)
        saved[path] = data
    inventory = json.loads(saved['raw/grid-final-01.tar.gz.inventory.json'])
    archive_bytes = saved['raw/grid-final-01.tar.gz']
    check('public archive binding', len(archive_bytes) == inventory['bytes'] == 1416655
          and sha(archive_bytes) == inventory['sha256'] == '862c9f2f96960dc1dfc6073e3f489957ee32d557a4e094cf7e3bc34a5a3f5229')
    expected = {row['path']: row for row in inventory['members']}
    check('archive inventory unique', len(expected) == len(inventory['members']) == 540)
    roots = {
        'grid-job': Path('/tmp/g288-final-grid-3d681636/workflow/grid'),
        'grid-job-temp': Path('/tmp/g288-final-grid-3d681636/tmp/workflow/grid'),
        'grid-outer': Path('/workspace/geo288-main-merge-20261023/grid-final-outer/p88-final-grid-3d681636'),
        'grid-input-before': Path('/tmp/g288-final-grid-3d681636/inputs-before'),
        'grid-input-after': Path('/tmp/g288-final-grid-3d681636/inputs-after'),
        'grid-tools': Path('/workspace/geo288-main-merge-20261023/grid-final-tools'),
        'grid-binding-and-capture': Path('/workspace/geo314-owner-20261023/grid-final-3d681636'),
        'grid-original-index': Path('/tmp/g288-final-grid-3d681636'),
        'independent-original-peer': HERE,
    }
    inside = {}
    original_paths = {}
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        for member in archive:
            parts = PurePosixPath(member.name).parts
            check('regular safe unique member ' + member.name, member.isfile() and '..' not in parts
                  and not PurePosixPath(member.name).is_absolute() and member.name not in inside)
            data = archive.extractfile(member).read()
            item = expected[member.name]
            check('member byte/hash ' + member.name, len(data) == item['bytes'] and sha(data) == item['sha256'])
            original = roots[parts[0]].joinpath(*parts[1:])
            check('member equals original bytes ' + member.name, original.read_bytes() == data)
            original_paths[str(original)] = member.name
            inside[member.name] = data
    check('all 540 listed files present', set(inside) == set(expected))
    check('standalone receipt original bytes', saved['receipts/grid-final.json'] == inside['grid-job/receipt.json'])
    local_review = json.loads((HERE / 'ORIGINAL_GRID_CHECKS.json').read_text())
    check('public receipt equals independently reviewed receipt', sha(saved['receipts/grid-final.json']) == local_review['original_hashes']['/tmp/g288-final-grid-3d681636/workflow/grid/receipt.json'])
    workflow = json.loads(inside['grid-job/receipt.json'])
    for relative, row in workflow['files'].items():
        data = inside['grid-job/' + relative]
        check('workflow inventory covered by public archive ' + relative, len(data) == row['bytes'] and sha(data) == row['sha256'])
    # Original command receipts reference their raw stdout/stderr/log files by path.
    references = []
    missing = []
    def walk(node, context):
        if isinstance(node, dict):
            for key, value in node.items():
                if key in ['stdout', 'stderr', 'combined', 'stdout_file', 'stderr_file'] and isinstance(value, str) and value.startswith('/'):
                    references.append({'record': context, 'key': key, 'original_path': value, 'archive_path': original_paths.get(value)})
                    if value not in original_paths:
                        missing.append(references[-1])
                else:
                    walk(value, context)
        elif isinstance(node, list):
            for value in node:
                walk(value, context)
    for path, data in inside.items():
        if path.endswith('.json'):
            walk(json.loads(data), path)
    check('all referenced command streams archived', not missing, {'references': len(references), 'missing': missing})
    excluded = json.loads(saved['raw/grid-final-excluded.json'])
    check('excluded paths are separately declared and disjoint', all(row['path'] not in inside and row['reason'] for row in excluded), len(excluded))
    note = saved['PUBLICATION_NOTE.md'].decode()
    check('original publication exit1 and narrow force-add retained', 'exit1' in note and '不涉及force push' in note
          and saved['publication-original-attempt/subcommands/000001/stderr.bin'])
    progress = saved['PROGRESS.md'].decode()
    check('public progress preserves original partial scope', all(s in progress for s in ['partial', 'not compared (partial mode)', '0/0/0', '356/0', '473.79222212699824']))
    report['archive_files'] = len(inside)
    report['excluded_files'] = len(excluded)
    report['command_stream_references'] = references
    report['original_result'] = local_review['original_result']
    report['scope'] = 'Read-only published bytes verification plus prior independent original-record review; no rerun, no added golden/count gate.'
    report['exit_code'] = 0
except Exception as error:
    report['error'] = repr(error)
    report['exit_code'] = 2
finally:
    report['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'exit_code': report['exit_code'], 'checks': len(report['checks']), 'files': report.get('archive_files'),
                      'excluded': report.get('excluded_files'), 'error': report.get('error')}, ensure_ascii=False))
raise SystemExit(report['exit_code'])
