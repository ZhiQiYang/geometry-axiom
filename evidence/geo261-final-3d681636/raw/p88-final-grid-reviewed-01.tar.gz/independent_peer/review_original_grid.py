"""Read original terminal grid records; never execute or modify the tested checkout."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SHA = '3d681636902371ecc528b20f51eea33e272581c9'
REPO = '/tmp/g288-final-grid-checkout-3d681636'
RUN = Path('/tmp/g288-final-grid-3d681636')
JOB = RUN / 'workflow/grid'
OUTER = Path('/workspace/geo288-main-merge-20261023/grid-final-outer/p88-final-grid-3d681636/receipt.json')
REPORT = HERE / 'ORIGINAL_GRID_CHECKS.json'
assert not REPORT.exists(), 'Preserve earlier review attempts'
report = {'schema': 'geo288-original-grid-peer/1', 'sha': SHA, 'checks': [], 'exit_code': None}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def check(name, condition, detail=None):
    report['checks'].append({'name': name, 'passed': bool(condition), 'detail': detail})
    assert condition, name

try:
    data = json.loads((JOB / 'receipt.json').read_text())
    check('original workflow actually terminal', data.get('ended') is not None and data.get('exit_code') is not None)
    outer = json.loads(OUTER.read_text())
    check('original outer actually terminal', outer['outer_process']['actual_process_returncode'] is not None)
    before = json.loads((RUN / 'inputs-before/receipt.json').read_text())
    after = json.loads((RUN / 'inputs-after/receipt.json').read_text())
    index = json.loads((RUN / 'ORIGINAL_GRID_INDEX.json').read_text())
    check('F and dedicated checkout original binding', data['sha'] == outer['sha'] == before['sha'] == after['sha'] == SHA
          and outer['cwd'] == REPO and data['checkout_before']['root'] == data['checkout_after']['root'] == REPO)
    check('original source before/after clean', all(data[x]['head'] == SHA and data[x]['status'] == '' for x in ['checkout_before', 'checkout_after']))
    check('explicit input recorder before/after completed', before['metadataComplete'] is True and after['metadataComplete'] is True
          and before['errors'] == after['errors'] == [] and after['sameExplicitInputsBeforeAfter'] is True
          and before['files'] == after['files'])
    check('unchanged workflow and reviewed port-only driver', data['workflow_sha256'] == 'b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d'
          and data['driver_sha256'] == '96a5511b8e05ba6b418bec91fbff1ab36e8ed311efe707969e16004a95c761bc')
    check('original grid CI limit 15min retained', data['ci_timeout_minutes'] == 15 and data['matrix'] == {'suite': 'grid', 'timeout': 15})
    for row in before['files']:
        raw = subprocess.check_output(['git', 'show', SHA + ':' + row['path']], cwd=REPO)
        check('explicit Git F input ' + row['path'], len(raw) == row['bytes'] and digest(raw) == row['sha256'])
    for path, item in data['files'].items():
        file = JOB / path
        check('recorded workflow file within job ' + path, file.resolve().is_relative_to(JOB.resolve()))
        raw = file.read_bytes()
        check('recorded workflow bytes/hash ' + path, len(raw) == item['bytes'] and digest(raw) == item['sha256'])
    original_stdout = (JOB / 'steps/03.stdout').read_text()
    footer_rows = [json.loads(row[len('CDP_RESULT '):]) for row in original_stdout.splitlines() if row.startswith('CDP_RESULT ')]
    check('one original CDP footer', len(footer_rows) == 1)
    footer = footer_rows[0]
    browser = next(step['result'] for step in data['steps'] if step['index'] == 3)
    check('index retains original facts, not new gate', index['originalReceiptValidated'] is True and index['errors'] == []
          and index['originalCDPFooter'] == footer and index['browserOriginalExit'] == browser['actual_process_returncode']
          and index['originalJobExit'] == data['exit_code'] and index['originalOuterExit'] == outer['outer_process']['actual_process_returncode'])
    check('actual requested ports and original partial scope', data['server_port'] == 19784 and footer['scope']['cdpPort'] == 9634
          and footer['scope']['url'] == 'http://127.0.0.1:19784/' and footer['scope']['mode'] == 'partial'
          and footer['scope']['filters'] == ['GEOMETRY_GRID_SYSTEM_ONLY'] and footer['scope']['modifiers'] == [])
    report['original_result'] = {'outer_exit': outer['outer_process']['actual_process_returncode'],
                                 'workflow_exit': data['exit_code'], 'node_exit': browser['actual_process_returncode'],
                                 'browser_watchdog_expired': browser['watchdog_expired'], 'seconds': data['seconds'],
                                 'original_ci_timeout_minutes': data['ci_timeout_minutes'], 'over_ci_timeout': data['over_ci_timeout'],
                                 'footer': footer}
    report['original_hashes'] = {str(path): digest(path.read_bytes()) for path in [JOB / 'receipt.json', OUTER,
        RUN / 'inputs-before/receipt.json', RUN / 'inputs-after/receipt.json', RUN / 'ORIGINAL_GRID_INDEX.json',
        JOB / 'steps/03.stdout', JOB / 'steps/03.stderr', JOB / 'steps/03.command.json']}
    report['version_outputs'] = {row['command'][0]: Path(row['stdout']).read_text().strip() for row in data['versions']}
    report['scope_limit'] = 'This independently verifies original records only. Partial grid is not full canvas/native; no golden or count threshold is introduced.'
    report['exit_code'] = 0
except Exception as error:
    report['exit_code'] = 2
    report['error'] = repr(error)
finally:
    report['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'exit_code': report['exit_code'], 'checks': len(report['checks']), 'original_result': report.get('original_result'), 'error': report.get('error')}, ensure_ascii=False))
raise SystemExit(report['exit_code'])
