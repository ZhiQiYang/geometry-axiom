# 新 F 正式 grid 公開封包獨立審查

結論：公開封包核對通過。證據提交 `b12172860c59fe091c0e490630b548281b2eb53a` 相對受驗 F `3d681636902371ecc528b20f51eea33e272581c9` 只增加 `evidence/geo288-final-3d681636/`；原 grid 仍為 outer／workflow／Node 0／0／0、473.79222212699824 秒，原 15 分鐘內，partial 356／0、P88=143、golden 原文未比較。本審查沒有重跑測試或新增門檻。

實際從公開 Git blob 讀取 `raw/grid-final-01.tar.gz`，1,416,655 bytes，SHA-256 `862c9f2f96960dc1dfc6073e3f489957ee32d557a4e094cf7e3bc34a5a3f5229`。完整 540 成員均為安全、唯一的普通檔案，與 inventory 的 bytes/hash 相符，並與原磁碟原件逐 bytes 相同；archive 成員集合與 inventory 精確相同。所有公開檔案（SHA256SUMS 自身除外）均有 checksum 且核符。另有 339 個 cache/profile 等排除項逐項明列，沒有冒稱其已收進包內。

公開獨立 grid receipt、封包內 receipt 與前次獨立審查的原 receipt 逐 bytes 相同。原 workflow inventory 的 44 個檔案全部包含在公開封包，命令 JSON 引用的 stdout／stderr／combined 原輸出也全覆蓋。完整來源前後 binding、13 份凍結工具、原 outer、版本與環境、原命令和 full streams、原 validator/index、原 artifact 都保留。

原通用 publisher 因 `.gitignore` 阻擋此證據前綴而 exit 1，失敗的原命令／stdout／stderr 收在 `publication-original-attempt/`，PUBLICATION_NOTE 解釋只使用精確 evidence 前綴的 force-add；沒有 force push 或產品／ignore 變更。這是出版環境／路徑問題，原測試 0／0／0 沒有重跑或改判。

本審查器第一次 exit 2 也完整保留：在最後一個 `independent-original-peer/ORIGINAL_GRID_CHECKS.json` 成員，已核 bytes/hash，但審查器缺少其磁碟來源 label 對應，造成 KeyError。第一次已記 1637 項通過核對，不能冒作完整審查 exit 0。修正版只補該來源 label 並使用新的輸出檔名，原腳本、原 report 與精確差分都保留；在主代理明確釋放 P52 formal 短窗口後才執行，完成 1689 checks，exit 0。沒有改被審封包、原 receipt、產品、測試或任何接受門檻。

完整記錄：`ORIGINAL_GRID_CHECKS.json` 為原收據 114 checks／exit 0；`PUBLIC_GRID_CHECKS.json` 為首輪審查工具 exit 2；`PUBLIC_GRID_CHECKS_v2.json` 為公開封包 1689 checks／exit 0；`review_public_grid_v1-v2.diff` 精確保留補正。此次只驗正式 grid 的公開收據，不能外推其他尚在執行的 #288 gate 或宣稱整份 PR 已可合併。
