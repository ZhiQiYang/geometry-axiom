# 新 F 正式 grid 原件獨立審查

原件核對通過：原 outer／workflow／Node 退出碼均為 0；耗時 473.79222212699824 秒，未超過原 15 分鐘，browser watchdog 未觸發。受驗來源為 `3d681636902371ecc528b20f51eea33e272581c9`，獨立乾淨 checkout、HTTP 19784、CDP 9634、專用 TEMP 與 Chrome profile。前後 HEAD 相同、status 空，16 份明列輸入前後逐 bytes 相同且與 Git F 原 blob 相符。

原 footer 是 `partial`／`GEOMETRY_GRID_SYSTEM_ONLY`，completed=true、356 pass／0 fail、skip=[]、uncaught exceptions=0；P70=121、P71=9、P78=23、P87=60、P88=143。保留原 `goldenCompare: not compared (partial mode)`，沒有改寫成完整 canvas、全量 golden 比對或新增數字門檻。

13 份凍結工具的 bytes/hash 均符合開跑前 binding。與原工作流程 driver 的逐行差異只設定獨立 HTTP 埠及 CDP 埠；原 workflow hash `b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d`，已審 port-only driver hash `96a5511b8e05ba6b418bec91fbff1ab36e8ed311efe707969e16004a95c761bc`。沒有修改受驗來源、原斷言、CI 時限或 partial 行為。

本次實際核 44 份 workflow inventory 檔案 bytes/hash，含完整步驟命令、stdout/stderr、版本命令、環境、原收據關聯；原結果索引與原 outer／workflow／Node 結果相符，errors/unknown 均空。原版本為 Google Chrome 156.0.8078.47、Node v24.19.0，fonts-noto-cjk 已安裝，版本命令 exit 0。

原 workflow receipt SHA256 `db8d3b1d49a1a86973e59e5deef58c7c4dd60f6c9358c6f5f55f3692bffd04b6`；原 stdout SHA256 `e61179f88dad670839b183aee83fe02c89c8d22fe34bc19d353a1191f4599223`。唯讀核對程式 `review_original_grid.py` 完成 114 checks，exit 0；`ORIGINAL_GRID_CHECKS.json` SHA256 `9e9d401d2ebd099d5d83bbfd5cb550b2fcffdf7310c4142ac87312624134efc5`。工具準備靜態核對另保存在 `PREPARATION_CHECKS.json`。

此報告驗原終態收據，不提前宣稱尚未完成的公開封包驗證；公開 Git blob／archive 的逐檔核對另出補件。這次沒有啟動測試、開瀏覽器或寫入受驗 checkout／整合分支。
