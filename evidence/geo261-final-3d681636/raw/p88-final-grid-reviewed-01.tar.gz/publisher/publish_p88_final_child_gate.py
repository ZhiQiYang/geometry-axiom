"""Root imports immutable child evidence; only the integration evidence prefix changes."""
from pathlib import Path
import argparse
import hashlib
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
R = Path('/workspace/geometry-axiom')
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('gate', choices=('grid', 'native'))
a = p.parse_args()
if a.gate == 'grid':
    child = Path('/tmp/g288-final-grid-checkout-3d681636')
    E = 'b12172860c59fe091c0e490630b548281b2eb53a'
    receipt = Path('/tmp/g288-final-grid-3d681636/workflow/grid/receipt.json')
    expected_hash = 'db8d3b1d49a1a86973e59e5deef58c7c4dd60f6c9358c6f5f55f3692bffd04b6'
    inputs = {
        'child_public_evidence': child / 'evidence/geo288-final-3d681636',
        'independent_peer': B / 'p88-priority/grid-final-peer',
        'child_publication_completion': Path('/workspace/geo314-owner-20261023/grid-final-publication-completion-3d681636'),
        'child_prbody_publication': Path('/workspace/geo314-owner-20261023/grid-final-prbody-publication-3d681636'),
    }
    result = '新F正式grid原outer/workflow/Node皆0，473.79222212699824秒在原15min內；partial356/0、P88=143、skip=[]、原golden未比較、exception0。獨立原件及Git封包審查保真；原出版1是新證據路徑被ignore，精確add-f後一般push0，未改產品或gitignore。'
else:
    child = Path('/tmp/g288-final-native-checkout-3d681636')
    E = 'c7214307d5ffc6a867089c8d832fef4bc94ae27c'
    receipt = Path('/tmp/g288-final-native-3d681636/receipt.json')
    expected_hash = '21676d4ab5fd03f2733569d7e69373257d8604ad0cc6bd80f25375a69e4a2fa5'
    inputs = {
        'child_public_evidence': child / 'evidence/geo288-final-3d681636',
        'independent_peer': Path('/workspace/geo314-owner-20261023/review-native-four-3d681636'),
        'original_publication': Path('/tmp/g288-final-native-publication-3d681636'),
        'publication_resume': Path('/tmp/g288-final-native-publication-resume-3d681636'),
        'prbody_publication': Path('/tmp/g288-final-native-prbody-record-3d681636'),
    }
    result = '新F原run_all四組partial原primary/reaper/outer/launch皆0，17/3/51/737合計808pass、0fail、0skip；不冒完整native重跑。原runner確認三binary fresh/reused；完整Git index與14輸入前後同F，三個真gcanvas fixtures按原blob物化，其他稀疏限制保留。獨立原件及Git封包審查、原publication ignore失敗1及精確prefix正常續推0都保留。'
if hashlib.sha256(receipt.read_bytes()).hexdigest() != expected_hash:
    raise RuntimeError('Original receipt differs')
actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=child).decode().strip()
if actual != E or subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=child):
    raise RuntimeError('Expected the exact clean published child evidence head')
branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=child).decode().strip()
if subprocess.check_output(['git', 'ls-remote', '--heads', 'origin', branch], cwd=child).decode().split()[0] != E:
    raise RuntimeError('Child evidence is not the published branch head')
inputs['publisher'] = Path(__file__)
for name, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing completed input: ' + name + '=' + str(path))
command = ['python3', '-B', str(B / 'record_command.py'),
    '--out', str(B / ('p88-final-' + a.gate + '-root-publication')), '--sha', F,
    '--cwd', str(R), '--variant', 'reviewed-child-original-gate-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py',
    '--repo', str(R), '--branch', 'architecture/geo261-integration-20261016',
    '--issue', '261', '--sha', F, '--label', 'p88-final-' + a.gate + '-reviewed',
    '--result', result + ' 子分支證據E=' + E + '。',
    '--next', '繼續同F P52、P73、Chromium154與oracle反證，完成項依真退出更新唯一正文矩陣。',
    '--receipt', str(receipt)]
for name, path in inputs.items():
    command += ['--input', name + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=R).returncode)
