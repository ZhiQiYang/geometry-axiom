# 歷史工作副本精簡 v2（僅準備，未執行）

原 `cold-checkout-retirement-tools/` 全部檔案保留原 bytes。此包修補原版未查 ignored／nontracked、未實際核對五份 parent raw 的缺口；沒有執行任何候選或大檔雜湊。

只由 root 在三次完整 canvas 與 P88 native-rAF 反證全部結束、且沒有 P52 量測的窗口執行。工具必須取得 R3 非阻塞獨占鎖；忙時退出 75，不檢查或更動候選，不算 skip／通過。兩個入口固定 allowlist，不接受覆寫路徑或略過 guard 的參數：

```text
python3 -B /workspace/geo288-main-merge-20261023/cold-checkout-retirement-tools-v2/retire-a12d184e.py
python3 -B /workspace/geo288-main-merge-20261023/cold-checkout-retirement-tools-v2/retire-fe863b03.py
```

執行前核 literal realpath、獨立 `.git`／common-dir、固定 HEAD/tree、cached diff 空與完整 index stage bytes。Git 分別枚舉一般與 ignored 未追蹤項目；另以不跟隨 symlink 的 `lstat` 盤點補抓空目錄與特殊檔。任何未追蹤檔／目錄／symlink／特殊節點或 tracked 類型改變，都拒絕候選而不精簡。這可能讓存在舊 cache 的候選無法精簡；不得為取得空間放寬 guard、刪 cache、reset 或 clean。

所有可讀 `/proc/*/cwd` 與 `cmdline` 分開檢查兩候選真路徑及舊 `/tmp` alias；讀不到 cwd 不得跳過同一程序的 cmdline。保存未讀欄位限制與命中 PID，不輸出命令列中的憑證值。兩次 guard 之間再核新增的 nontracked 節點與 index，精簡前最後再做一次完整 status。這些檢查不是原子鎖，不能宣稱消除全部 TOCTOU；R3 與 root 停止其他工作仍是必要窗口。

五份 parent raw 的原 bytes/hash allowlist 有固定輸入 hash，實際逐份檢查，而非寫死 `raw_receipts_removed=false`。前後都核全部五份；單份失敗仍收齊其餘四份，任何差異即失敗。只讀預期大小的小型 receipt，若大小改變即拒絕，不進行大檔 hash。原 raw 永遠留在 clone 外的原位置；out 另存比對副本，不搬移原檔。

唯一 checkout 寫操作為 `git sparse-checkout set --no-cone /AGENTS.md`。Git 另停用自動 gc／maintenance；不執行 rm、reset、clean、gc、repack，不刪 Git object、manifest、原 raw 或外部 alternates。精簡後硬核 HEAD/tree/index stage bytes 與 clean 狀態、五份原 raw；若 sparse 本身失敗，仍做 raw 與 identity 後查，保存部分 materialization 可能已變的狀態，絕不重試或 reset。

原指令 argv／exit／完整 stdout、stderr 原 bytes／環境／工具 hash、guard 結果與實際 available bytes 差保存在固定新 out `cold-checkout-retirement-v2-<label>/`，不覆蓋 v1 結果。Git 原 stream 直接寫檔，中斷也保留原 prefix 與真子程序 exit（若未啟動則明列未知）；只終止本工具自己尚未退出的 Git child。外層捕捉 KeyboardInterrupt／SystemExit 並做保全後查，KeyboardInterrupt 的實際 driver exit 與收據均為 130。每次最後 raw 檢查前清為 pending／None，僅該次五份全部成功才再宣告未變；後查失敗不沿用較早的成功布林。已有同名 out 時拒絕重跑；由 root 保存原失敗後另準備新版本。

目前只有 AST／小型工具 hash 的準備收據；靜態對抗審查完成也不等於任何候選已執行或已回收空間。
