# v2 對抗審查修訂（仍未執行）

第一候選 PACKAGE `0a1cb7094ad055717cb74cd28c4b619b9aedaa0e105134abe7a5d72820276153`、common `0a044a35ea1536d258a099326d753e341841c571195887a860a6b1a9461f06ef` 保存在 `.review1` 檔案，沒有覆寫第一候選原 bytes。原 v1 目錄全部原樣。

combined 靜態審查指出並已修補：

- materialization 後的 KeyboardInterrupt／SystemExit 必走保全後查。外層改接 BaseException，記錄中斷身分與真 driver exit；KeyboardInterrupt 為 130，未完成 guard 的意外 SystemExit(0) 改列 driver failure 1 並保原碼。
- 最後一次 raw 檢查失敗，不能沿用較早成功布林。每次 after 檢查前立即清 pending／None，只有該次五份全部通過才回 verified／False。
- 第二次 filesystem/index guard 後再做一次 status，補查最早 status 之後的 tracked 內容變動。明列非原子檢查仍有 TOCTOU，不能用這些 guard 取代 root 的無其他工作窗口。
- 中斷時的 Git 命令也須留 argv/原 streams。改為 Popen 直接寫 stdout/stderr 原檔，預先落命令列，再記真 child exit／未啟動與異常；只停止本工具自己尚未退出的 Git child，等待後才檢查 materialization。

僅 AST、原工具 bytes 與小型工具 hash 檢查；沒有 import／執行任何 retire driver、沒有 synthetic case、沒有查大型候選內容或回收。
