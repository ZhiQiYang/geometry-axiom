"""Fixed allowlisted historical checkout; root must provide the scheduled window."""
import sys
sys.dont_write_bytecode = True
from retire_guarded import run

if __name__ == '__main__':
    if len(sys.argv) != 1:
        raise SystemExit('This fixed driver accepts no path, label, or guard bypass arguments')
    raise SystemExit(run('fe863b03'))
