"""Finalize only metadata/AST of the prepared tools. Never import their module."""
from pathlib import Path
import ast,datetime,hashlib,json,os,platform,sys
HERE=Path(__file__).resolve().parent;OLD=HERE.parent/'cold-checkout-retirement-tools'
def sha(raw):return hashlib.sha256(raw).hexdigest()
first=json.loads((HERE/'PREPARATION.json').read_text())
if not (HERE/'PREPARATION.initial.json').exists():
 (HERE/'PREPARATION.initial.json').write_bytes((HERE/'PREPARATION.json').read_bytes())
original={p.name:sha(p.read_bytes()) for p in OLD.iterdir() if p.is_file()}
if original!=first['original_tools_sha256']:raise RuntimeError('Original v1 tools changed')
parsed={}; trees={}
for p in sorted(HERE.glob('*.py')):
 tree=ast.parse(p.read_text());trees[p.name]=tree;parsed[p.name]={'sha256':sha(p.read_bytes()),'ast_parsed':True}
common=trees['retire_guarded.py']
def literal(name):return next(ast.literal_eval(n.value) for n in common.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id==name for v in n.targets))
inputs=(HERE/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json').read_bytes()
if literal('RAW_INPUT_SHA256')!=sha(inputs):raise RuntimeError('Raw input hash pin mismatch')
if literal('RAW_PATHS')!={v['path'] for v in json.loads(inputs)} or len(json.loads(inputs))!=5:raise RuntimeError('Five-path pin mismatch')
operations=[]
for n in ast.walk(common):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='git':operations.append([ast.literal_eval(a) for a in n.args])
allowed={'rev-parse','diff-index','ls-files','status','sparse-checkout'}
if any(a[0] not in allowed for a in operations):raise RuntimeError('Unexpected Git operation')
if [a for a in operations if a[0]=='sparse-checkout']!=[['sparse-checkout','set','--no-cone','/AGENTS.md']]:raise RuntimeError('Sparse mutation is not unique and fixed')
for n in ast.walk(common):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'unlink','rmdir','remove','rmtree','system'}:raise RuntimeError('Unexpected filesystem deletion/system call')
for label in literal('CASES'):
 tree=trees['retire-'+label+'.py'];calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='run']
 if len(calls)!=1 or len(calls[0].args)!=1 or ast.literal_eval(calls[0].args[0])!=label:raise RuntimeError('Wrapper label differs')
report={'scope':'Final AST/small-tool-hash preparation only; no driver imported/executed, no candidate inspection or mutation','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':sys.argv,'cwd':os.getcwd(),'exit_code':0,'stdout':'AST/hash-only finalization passed; original v1 bytes unchanged; no checkout action','stderr':'','environment':{'platform':platform.platform(),'python':sys.version,**{k:os.environ.get(k) for k in ('PATH','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE')}},'executed_retirement':False,'large_hash_or_full_disk_scan':False,'original_tools_sha256':original,'parsed_sources':parsed,'literal_git_calls':operations,'all_five_raw_receipts_bound_by_input_sha256':sha(inputs),'runtime_nontracked_guards':['Git others','Git ignored others','lstat metadata every node including empty dirs and special types','tracked type mismatch refused'],'runtime_raw_flag_requires_actual_after_verification':True,'runtime_raw_failures_collect_all_five':True,'runtime_failed_sparse_still_checks_raw_and_identity':True}
(HERE/'PREPARATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='PACKAGE.json'}
(HERE/'PACKAGE.json').write_text(json.dumps({'scope':'Prepared v2 static candidate identity; no case executed','files':files},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'prepared_only':True,'executed':False,'package_sha256':sha((HERE/'PACKAGE.json').read_bytes()),'common_sha256':sha((HERE/'retire_guarded.py').read_bytes()),'original_v1_unchanged':True},indent=2))
