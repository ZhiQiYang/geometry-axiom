"""Guarded historical materialization retirement; prepare only until root runs it.

The only checkout mutation permitted by this module is the exact sparse command
below. Refuse every nontracked node, including ignored files and empty folders.
No reset/clean/rm/gc/repack, no deletion of original raw or Git object storage.
"""
from __future__ import annotations

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import time
import traceback

BASE = Path('/workspace/geo288-main-merge-20261023')
TOOLS = BASE / 'cold-checkout-retirement-tools-v2'
RAW_INPUT = TOOLS / 'PARENT_RAW_RECEIPT_GUARD_INPUTS.json'
RAW_INPUT_SHA256 = 'd2bea3d75153f618d53606f0a0b974ea8929dd64176fb01aef8a50963cc1b3d6'
HEAVY_LOCK = Path('/tmp/g261r3/heavy.lock')
CASES = {
    'a12d184e': {
        'repo': '/workspace/geo261-cold/g261a1/source-final',
        'alias': '/tmp/g261a1/source-final',
        'head': 'a12d184ec1865ad078700cea2387ac69e82ab62a',
        'tree': '46462e26ef7179844f49c6a980dc59e0eccafe6b',
    },
    'fe863b03': {
        'repo': '/workspace/geo261-cold/g261r2/source-final',
        'alias': '/tmp/g261r2/source-final',
        'head': 'fe863b0374eafd9f1e57ec5107e28a1101804b56',
        'tree': '7d4820c18346e9f71576bd14bacefbaec6b78a3a',
    },
}
RAW_PATHS = {
    '/workspace/geo261-cold/g261a1/seven-final/canvas/receipt.json',
    '/workspace/geo261-cold/g261a1/seven-final/timber/receipt.json',
    '/workspace/geo261-cold/g261r2/seven-final/canvas/receipt.json',
    '/workspace/geo261-cold/g261r2/seven-final/timber/receipt.json',
    '/workspace/geo261-cold/g261r2/seven-final/native/receipt.json',
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class Recorder:
    def __init__(self, label):
        if label not in CASES:
            raise RuntimeError('Label is outside the fixed reviewed allowlist')
        self.case = CASES[label]
        self.repo = Path(self.case['repo'])
        self.out = BASE / ('cold-checkout-retirement-v2-' + label)
        self.out.mkdir(exist_ok=False)
        (self.out / 'commands').mkdir()
        self.result = {
            'schema': 'geo288-guarded-cold-retirement/2',
            'argv': sys.argv,
            'cwd': os.getcwd(),
            'started_utc': now(),
            'case': self.case,
            'environment': {
                'platform': platform.platform(), 'python': sys.version,
                'uid': os.getuid(), 'gid': os.getgid(),
                **{k: os.environ.get(k) for k in
                   ('PATH', 'LANG', 'LC_ALL', 'PYTHONPATH', 'PYTHONOPTIMIZE',
                    'GIT_OPTIONAL_LOCKS', 'GIT_CONFIG_SYSTEM', 'GIT_CONFIG_GLOBAL')},
            },
            'tool_sha256': {p.name: sha(p.read_bytes()) for p in TOOLS.iterdir()
                            if p.is_file() and p.suffix in ('.py', '.json')},
            'commands': [], 'events': [], 'passed': False,
            'materialization_attempted': False,
            'raw_receipts_removed': None, 'parent_raw_verified_unchanged': False,
            'git_objects_removed': False,
            'historical_results_changed': False,
        }
        self.save()

    def save(self):
        (self.out / 'receipt.json').write_text(
            json.dumps(self.result, ensure_ascii=True, indent=2) + '\n')

    def event(self, name, value):
        self.result['events'].append({'utc': now(), 'name': name, 'value': value})
        self.save()

    def git(self, *args):
        argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                '-C', str(self.repo), *args]
        env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
        i = len(self.result['commands'])
        prefix = self.out / 'commands' / ('%02d' % i)
        row = {
            'argv': argv, 'cwd': os.getcwd(), 'exit_code': None,
            'started_utc': now(), 'completed': False,
            'stdout_file': str(prefix.with_suffix('.stdout')),
            'stderr_file': str(prefix.with_suffix('.stderr')),
            'environment_delta': {'GIT_OPTIONAL_LOCKS': '0'},
        }
        self.result['commands'].append(row)
        self.save()
        process = None
        caught = None
        start = time.monotonic()
        # Write original streams while the child runs, retaining even an
        # interrupted command's actual prefix instead of losing pipe output.
        with prefix.with_suffix('.stdout').open('wb') as stdout_file, \
                prefix.with_suffix('.stderr').open('wb') as stderr_file:
            try:
                process = subprocess.Popen(argv, stdout=stdout_file, stderr=stderr_file, env=env)
                row['child_pid'] = process.pid
                self.save()
                process.wait()
            except BaseException as error:
                caught = error
                row['interruption_or_launch_error'] = {
                    'type': type(error).__name__, 'message': str(error)}
                # Only our own not-yet-exited Git child can be terminated.
                # Wait before post-checking partially changed materialization.
                if process is not None and process.poll() is None:
                    process.kill()
                    row['own_git_child_killed_after_interrupt'] = True
                    try:
                        process.wait()
                    except BaseException as cleanup:
                        row['child_wait_error'] = {
                            'type': type(cleanup).__name__, 'message': str(cleanup)}
        stdout = prefix.with_suffix('.stdout').read_bytes()
        stderr = prefix.with_suffix('.stderr').read_bytes()
        row.update({
            'exit_code': process.returncode if process is not None else None,
            'elapsed_seconds': time.monotonic() - start,
            'ended_utc': now(),
            'completed': process is not None and process.returncode is not None,
            'stdout': stdout.decode('utf-8', 'replace'),
            'stderr': stderr.decode('utf-8', 'replace'),
            'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
        })
        self.save()
        if caught is not None:
            raise caught
        if row['exit_code']:
            raise RuntimeError('Git command failed, exit %s: %r' % (row['exit_code'], argv))
        return stdout


def identity(rec):
    repo = rec.repo
    if repo.is_symlink() or repo.resolve(strict=True) != repo:
        raise RuntimeError('Candidate path is not its reviewed literal real directory')
    if not (repo / '.git').is_dir() or (repo / '.git').is_symlink():
        raise RuntimeError('Candidate must have its own real .git directory')
    values = rec.git('rev-parse', '--show-toplevel', '--absolute-git-dir',
                     'HEAD', 'HEAD^{tree}').decode().strip().splitlines()
    if values != [str(repo), str(repo / '.git'), rec.case['head'], rec.case['tree']]:
        raise RuntimeError('HEAD/tree/root/gitdir differs from reviewed allowlist')
    common = rec.git('rev-parse', '--path-format=absolute', '--git-common-dir').decode().strip()
    if Path(common).resolve() != repo / '.git':
        raise RuntimeError('Linked/shared worktree index is not allowed')
    cached = rec.git('diff-index', '--cached', '--name-status', 'HEAD')
    if cached:
        raise RuntimeError('Index contains staged work')
    stage = rec.git('ls-files', '--stage', '-z')
    rec.event('identity', {'head': values[2], 'tree': values[3],
                           'index_stage_sha256': sha(stage), 'entries': stage.count(b'\0')})
    return stage


def no_nontracked_nodes(rec, stage):
    # Git enumeration alone omits empty ignored directories and some special
    # nodes. Retain its complete raw result, then additionally lstat every node.
    others = rec.git('ls-files', '--others', '--exclude-standard', '-z', '--directory')
    ignored = rec.git('ls-files', '--others', '--ignored', '--exclude-standard',
                      '-z', '--directory')
    tracked = set()
    expected_kind = {}
    parents = {''}
    for row in stage.split(b'\0'):
        if not row:
            continue
        meta, raw_path = row.split(b'\t', 1)
        mode, _oid, entry_stage = meta.split()
        if entry_stage != b'0' or mode not in (b'100644', b'100755', b'120000'):
            raise RuntimeError('Unsupported index stage/gitlink/mode; refuse candidate')
        name = os.fsdecode(raw_path)
        tracked.add(name)
        expected_kind[name] = 'symlink' if mode == b'120000' else 'regular'
        parent = Path(name).parent
        while str(parent) != '.':
            parents.add(str(parent)); parent = parent.parent
    found = []
    inventory = []
    pending = [rec.repo]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for e in entries:
                path = Path(e.path)
                rel = str(path.relative_to(rec.repo))
                if rel == '.git':
                    continue  # Preserve complete Git metadata/object storage.
                st = e.stat(follow_symlinks=False)
                directory_node = stat.S_ISDIR(st.st_mode)
                kind = ('directory' if directory_node else 'symlink' if stat.S_ISLNK(st.st_mode)
                        else 'regular' if stat.S_ISREG(st.st_mode) else 'special')
                nontracked = rel not in (parents if directory_node else tracked)
                invalid_tracked_type = rel in expected_kind and kind != expected_kind[rel]
                item = {'path': rel, 'kind': kind, 'mode': st.st_mode,
                        'bytes': st.st_size, 'nontracked': nontracked,
                        'invalid_tracked_type': invalid_tracked_type}
                inventory.append(item)
                if nontracked or invalid_tracked_type:
                    found.append(item)
                if directory_node:
                    pending.append(path)  # Never follow symlinks.
    stamp = len([e for e in rec.result['events'] if e['name'] == 'filesystem_inventory'])
    target = rec.out / ('filesystem-inventory-%d.json' % stamp)
    target.write_text(json.dumps(inventory, ensure_ascii=True, indent=2) + '\n')
    rec.event('filesystem_inventory', {'path': str(target), 'sha256': sha(target.read_bytes()),
              'entries': len(inventory), 'git_other_bytes': len(others),
              'git_ignored_bytes': len(ignored), 'nontracked_nodes': found})
    if others or ignored or found:
        raise RuntimeError('Candidate contains nontracked/ignored files, directories or special nodes')


def no_consumers(rec):
    roots = [Path(v['repo']) for v in CASES.values()]
    patterns = [v[k].encode() for v in CASES.values() for k in ('repo', 'alias')]
    active = []
    unreadable = []
    checked = 0
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        checked += 1
        reasons = []
        try:
            cwd = (p / 'cwd').resolve(strict=True)
            if any(cwd == root or root in cwd.parents for root in roots):
                reasons.append('cwd')
        except (OSError, RuntimeError) as e:
            unreadable.append({'pid': int(p.name), 'field': 'cwd', 'error': type(e).__name__})
        # This check must not be skipped merely because cwd was unreadable.
        try:
            command = (p / 'cmdline').read_bytes()
            if any(pattern in command for pattern in patterns):
                reasons.append('cmdline real path or old alias')
        except OSError as e:
            unreadable.append({'pid': int(p.name), 'field': 'cmdline', 'error': type(e).__name__})
        if reasons:
            active.append({'pid': int(p.name), 'reasons': reasons})
    rec.event('consumer_guard', {'checked': checked, 'active': active,
                                 'unreadable_fields': unreadable,
                                 'note': 'All readable cwd/cmdline checked independently; unreadable fields not claimed read'})
    if active:
        raise RuntimeError('Historical clone or alias has active consumers')


def raw_receipts(rec, phase):
    if phase != 'before':
        # A later failure must not leave an earlier successful observation
        # presented as the final verification state.
        rec.result['parent_raw_verified_unchanged'] = False
        rec.result['raw_receipts_removed'] = None
        rec.event('parent_raw_verification_pending', {'phase': phase})
    raw_input = RAW_INPUT.read_bytes()
    if sha(raw_input) != RAW_INPUT_SHA256:
        raise RuntimeError('Pinned raw-receipt guard input changed')
    items = json.loads(raw_input)
    if len(items) != 5 or {v['path'] for v in items} != RAW_PATHS:
        raise RuntimeError('The five parent raw guards differ from the reviewed allowlist')
    checked = []
    errors = []
    for i, v in enumerate(items):
        p = Path(v['path'])
        result = {'path': str(p), 'expected_bytes': v['bytes'],
                  'expected_sha256': v['sha256']}
        try:
            st = p.lstat()
            if not v['outside_clone'] or p.is_symlink() or not stat.S_ISREG(st.st_mode):
                raise RuntimeError('Parent raw must be the original regular file')
            resolved = p.resolve(strict=True)
            if any(resolved == Path(c['repo']) or Path(c['repo']) in resolved.parents for c in CASES.values()):
                raise RuntimeError('Parent raw receipt is inside a candidate')
            if st.st_size != v['bytes']:
                result['stat_bytes'] = st.st_size
                raise RuntimeError('Original parent raw receipt size changed; refuse without large read')
            with p.open('rb') as stream:
                raw = stream.read(v['bytes'] + 1)
            result.update({'bytes': len(raw), 'sha256': sha(raw)})
            if len(raw) != v['bytes'] or sha(raw) != v['sha256']:
                raise RuntimeError('Original parent raw receipt bytes/hash changed')
            (rec.out / ('parent-raw-%s-%d.json' % (phase, i))).write_bytes(raw)
            result['passed'] = True
        except (OSError, RuntimeError) as error:
            result['passed'] = False
            result['error'] = {'type': type(error).__name__, 'message': str(error)}
            errors.append(result)
        checked.append(result)
        rec.event('raw_receipt_' + phase, result)
    if errors:
        raise RuntimeError('Parent raw receipt guard failed for %d of all five checked inputs' % len(errors))
    return checked



def run(label):
    rec = Recorder(label)
    lock = None
    rc = 1
    try:
        lock = HEAVY_LOCK.open('a')
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            rc = 75
            raise RuntimeError('R3 is busy; no candidate inspection/mutation permitted now')
        rec.event('resource_lock', {'path': str(HEAVY_LOCK), 'mode': 'exclusive nonblocking'})
        before_stage = identity(rec)
        no_consumers(rec)
        no_nontracked_nodes(rec, before_stage)
        if rec.git('status', '--porcelain=v1', '--untracked-files=all'):
            raise RuntimeError('Historical checkout has local work')
        pre_raw = raw_receipts(rec, 'before')
        rec.result['parent_raw_before_verified'] = True
        no_consumers(rec)
        # Refuse a file/folder/special node created during any earlier check.
        no_nontracked_nodes(rec, before_stage)
        if identity(rec) != before_stage:
            raise RuntimeError('Index stages changed during guards')
        if rec.git('status', '--porcelain=v1', '--untracked-files=all'):
            raise RuntimeError('Tracked/untracked worktree changed during guards')
        space = os.statvfs(rec.repo)
        rec.result['available_bytes_before'] = space.f_bavail * space.f_frsize
        rec.result['materialization_attempted'] = True
        rec.save()
        rec.git('sparse-checkout', 'set', '--no-cone', '/AGENTS.md')
        rec.result['sparse_command_exit'] = 0
        post_errors = []
        # Always hard-check all five original parent raw receipts after the
        # sparse command. The outer exception path also repeats these guards.
        post_raw = raw_receipts(rec, 'after')
        if post_raw != pre_raw:
            post_errors.append('Parent raw before/after metadata differs')
        else:
            rec.result['parent_raw_verified_unchanged'] = True
            rec.result['raw_receipts_removed'] = False
        if identity(rec) != before_stage:
            post_errors.append('Index stages or HEAD/tree changed')
        if rec.git('status', '--porcelain=v1', '--untracked-files=all'):
            post_errors.append('Checkout no longer clean')
        if post_errors:
            raise RuntimeError('; '.join(post_errors))
        space = os.statvfs(rec.repo)
        rec.result['available_bytes_after'] = space.f_bavail * space.f_frsize
        rec.result['freed_available_bytes'] = (rec.result['available_bytes_after']
                                              - rec.result['available_bytes_before'])
        rec.result['passed'] = True
        rc = 0
    except BaseException as e:
        rec.result['passed'] = False
        if isinstance(e, KeyboardInterrupt):
            rc = 130
        elif isinstance(e, SystemExit):
            original = e.code
            normalized = (original if isinstance(original, int) else
                          0 if original is None else 1) & 255
            rc = normalized if normalized else 1
            rec.result['system_exit_identity'] = {
                'original_code': repr(original), 'normalized_process_exit': normalized,
                'driver_exit': rc,
                'note': 'Unexpected zero SystemExit cannot mark an unfinished guard as success.'}
        rec.result['error'] = {'type': type(e).__name__, 'message': str(e),
                               'traceback': traceback.format_exc()}
        if rec.result['materialization_attempted']:
            # A failed sparse command may have partially changed tracked
            # materialization; inspect rather than reset or silently retry.
            errors = []
            for name, check in [('parent_raw_after_failure', lambda: raw_receipts(rec, 'after-failure')),
                                ('identity_after_failure', lambda: identity(rec))]:
                try:
                    value = check()
                    if name == 'identity_after_failure' and value != before_stage:
                        raise RuntimeError('Index stage snapshot changed')
                    if name == 'parent_raw_after_failure' and value == pre_raw:
                        rec.result['parent_raw_verified_unchanged'] = True
                        rec.result['raw_receipts_removed'] = False
                    rec.event(name, {'passed': True})
                except BaseException as post:
                    if isinstance(post, KeyboardInterrupt):
                        rc = 130
                    elif isinstance(post, SystemExit):
                        original = post.code
                        normalized = (original if isinstance(original, int) else
                                      0 if original is None else 1) & 255
                        rc = normalized if normalized else 1
                        rec.result.setdefault('post_system_exit_identities', []).append({
                            'original_code': repr(original), 'normalized_process_exit': normalized,
                            'driver_exit': rc})
                    errors.append({'guard': name, 'type': type(post).__name__, 'message': str(post)})
            rec.result['post_failure_guard_errors'] = errors
    finally:
        if lock is not None:
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        rec.result['ended_utc'] = now()
        rec.result['exit_code'] = rc
        rec.result['note'] = 'Only index sparse flags and tracked working materialization may change; never rewrite historical results.'
        rec.save()
        print(json.dumps({'exit_code': rc, 'passed': rec.result['passed'],
                          'materialization_attempted': rec.result['materialization_attempted'],
                          'receipt': str(rec.out / 'receipt.json')}, ensure_ascii=True))
    return rc
