"""Prepare and AST-audit only. Never import or invoke a retirement driver."""
from pathlib import Path
import ast,datetime,hashlib,json,os,platform,sys
BASE=Path('/workspace/geo288-main-merge-20261023');old=BASE/'cold-checkout-retirement-tools';out=BASE/'cold-checkout-retirement-tools-v2'
source=Path('/workspace/geo318-storage-prep/plan-20261023T113933Z/PARENT_RAW_RECEIPT_GUARD_INPUTS.json')
def sha(raw):return hashlib.sha256(raw).hexdigest()
original={p.name:sha(p.read_bytes()) for p in old.iterdir() if p.is_file()}
raw=source.read_bytes();items=json.loads(raw)
if len(items)!=5 or len({v['path'] for v in items})!=5:raise RuntimeError('Expected five distinct raw guard inputs')
(out/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json').write_bytes(raw)
p=out/'retire_guarded.py';body=p.read_text()
if body.count('__RAW_INPUT_SHA256__')!=1:raise RuntimeError('Raw guard binding marker is not unique')
body=body.replace('__RAW_INPUT_SHA256__',sha(raw));p.write_text(body)
case_values=next(ast.literal_eval(n.value) for n in ast.parse(body).body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='CASES' for x in n.targets))
for label in case_values:
 wrapper='''"""Fixed allowlisted historical checkout; root must provide the scheduled window."""
import sys
sys.dont_write_bytecode = True
from retire_guarded import run

if __name__ == '__main__':
    if len(sys.argv) != 1:
        raise SystemExit('This fixed driver accepts no path, label, or guard bypass arguments')
    raise SystemExit(run(%r))
''' % label
 (out/('retire-'+label+'.py')).write_text(wrapper)
plan={'schema':'geo288-historical-work-copy-retirement-preparation/2','prepared_only':True,'executed':False,'replaces_without_modifying':str(old),'required_window':json.loads((old/'PLAN.json').read_text())['required_window'],'heavy_lock':'/tmp/g261r3/heavy.lock','resource_busy_exit':75,'parent_raw_guards':str(out/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json'),'parent_raw_guards_sha256':sha(raw),'parent_raw_count':5,'cases':case_values,'policy':'Abort on ANY nontracked file/directory/symlink/special node, including ignored and empty directories. Verify all five pinned external original raw receipts before and after; preserve HEAD/tree/index-stage bytes; only sparse materialization. No reset/clean/rm/gc/repack.','git_commands_disable_optional_index_writes_and_automatic_gc':True,'full_command_streams_and_environment_recorded':True,'original_tools_sha256':original}
(out/'PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
parsed={}
for f in sorted(out.glob('*.py')):
 tree=ast.parse(f.read_text());parsed[f.name]={'sha256':sha(f.read_bytes()),'ast_parsed':True}
# Static AST only: enumerate actual literal git calls and reject surprise mutators.
tree=ast.parse(body);git_calls=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='git':
  vals=[ast.literal_eval(a) for a in node.args]
  git_calls.append(vals)
allowed={'rev-parse','diff-index','ls-files','status','sparse-checkout'}
if any(v[0] not in allowed for v in git_calls):raise RuntimeError(('Unexpected Git operation',git_calls))
mutators=[v for v in git_calls if v[0]=='sparse-checkout']
if mutators!=[['sparse-checkout','set','--no-cone','/AGENTS.md']]:raise RuntimeError('Exactly one fixed sparse mutation call required')
if {p.name:sha(p.read_bytes()) for p in old.iterdir() if p.is_file()}!=original:raise RuntimeError('Original v1 tools changed')
result={'scope':'Preparation, AST and small-tool hash only; no imports of driver/retirement execution','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':sys.argv,'cwd':os.getcwd(),'exit_code':0,'stdout':'Prepared v2 only; original tools preserved; AST and static call allowlist checked','stderr':'','environment':{'platform':platform.platform(),'python':sys.version,**{k:os.environ.get(k) for k in ('PATH','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE')}},'driver_cases_executed':False,'checkout_mutations':False,'large_hash_or_full_disk_scan':False,'original_tools_sha256':original,'parsed_sources':parsed,'literal_git_calls':git_calls,'one_fixed_materialization_mutator':mutators}
(out/'PREPARATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
files={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
(out/'PACKAGE.json').write_text(json.dumps({'scope':'Immutable hash identity of the prepared v2 candidate, pending adversarial review','files':files},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'prepared_only':True,'executed':False,'out':str(out),'package_sha256':sha((out/'PACKAGE.json').read_bytes()),'common_sha256':sha(p.read_bytes())},ensure_ascii=False,indent=2))
