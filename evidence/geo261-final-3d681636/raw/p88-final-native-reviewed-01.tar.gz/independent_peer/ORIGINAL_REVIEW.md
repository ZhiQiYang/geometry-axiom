新 F native 四組 partial 的原件審查完成，60 項 metadata 核對全部符合，未見可確立的新阻擋。產品 SHA 為 `3d681636902371ecc528b20f51eea33e272581c9`，公開 evidence E 為 `c7214307d5ffc6a867089c8d832fef4bc94ae27c`；本次沒有執行產品、編譯、Chrome 或修改任何分支。

原 native／run_all／reaper／outer exit 全為 0，inner 原 stdout、stderr、stdin 與 result row bytes／hash 相符；最外層 launch 的原 request、result、streams 也相符。argv 只選原四個 `--only`：test_local_launcher、test_modeling_transport、test_serve、node:tests-js。原輸出及各 sidecar 分別為 17、3、51、737 pass，合計 808 pass／0 fail／0 skip；Node 原 footer 無 cancelled／todo。原 stdout 明寫「部分／示範執行，不可當完整驗收」，receipt 的 complete_native=false 保留。

`--build` 真正執行了原 binaries.py 的來源／binary freshness 判定，三個 binary 的原輸出是 reused／fresh，並保有 fingerprint 快照；沒有把它描述為本輪重新編譯。14 個明列來源前後 bytes／Git mode/blob 一致，原前後 HEAD 都是 F、branch 正確、clean，index hash 都是 `41e0e47b1b7f6b166c56b9983b8ac64893272ffd0525a112d9c52fddef8b4f6d`。

新 sparse checkout 精確補回下列三個原 fixture，各檔真 bytes／SHA256 與 F 的 Git blob 完全相符；稀疏規則只宣稱這三檔實體化，沒有冒稱整棵 worktree bytes 相同：

- `tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas`
- `tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas`
- `tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas`

原 receipt SHA256 為 `21676d4ab5fd03f2733569d7e69373257d8604ad0cc6bd80f25375a69e4a2fa5`，原 run stdout SHA256 為 `a5b076d148c2a1a708b79ce1f212f816605d57e06c70d7605d83a535217ee27b`。公開 E 的 receipt 與實際原件逐 bytes 相同，F→E 只有指定 evidence 前綴差異。公開 inventory 宣告 493 members、4,021,573 bytes；這階段只核其 metadata，尚未重讀 Git archive 全 bytes／解壓逐 member。

目前 root 正在 P52 獨占量測，因此公開封包的 Git roundtrip 留待其結束後的短窗口；這個未完成項不記成通過。原件詳細核對、具名輸入 hash 與只讀 Git 命令 raw 在 `ORIGINAL_NATIVE_CHECKS.json` 及 `subcommands/`。本審查的 metadata exit 0 不增加產品 gate，也不取代原 process exit。
