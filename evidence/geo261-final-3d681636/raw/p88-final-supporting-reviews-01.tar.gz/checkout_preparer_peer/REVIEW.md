# P52 checkout 與冷 checkout 回收工具靜審

兩項都未執行。本代理只核原bytes／AST／宣告hash／差分；未clone、build、測試或回收任何工作樹。root已確認原回收工具暫不執行，由#318在新目錄準備v2，待交叉審。

P52 preparer sha256 43c2fe4a45f032af6afc74ffef6c4e8d5ccaf4bfa7b4b0f44ac5a685cd1b012c，限定準備範圍未見直接阻擋：固定已公開F3d681636，fresh dest/out、原c387 hash/no-opt守門、只clone/shared/sparse/detach，source前後clean/head/full stage identity與dest精確相等；沒有import產品／執行build/test。shared只共享Git objects，checkout/index獨立；原物件供應來源仍須保留。這份收據只證Git準備，不另外證完整RuntimeSnapshot輸入相等、版本或任何P52 gate，後續原正式driver須照原協定核輸入。canvas3＋rAF真終態後由root排程，不能現在啟動。

cold原兩candidate與原Q38工具的保存patch可逐bytes重建、allowlist head/tree有加入；但有兩項確立計畫落差，所以不接受原版直接回收：

1. 兩driver第27行只有git status --porcelain --untracked-files=all，仍不列ignored檔，第46行就縮成只AGENTS.md。這不能支持PLAN宣告的ignored原輸出保留；sparse改整個目錄時ignored檔有被清除的可能。第51行raw_receipts_removed:false是常值，未經ignored／非tracked檔前後測量。至少應在任何修改前列出ignored與非tracked檔並拒絕有物件的候選，或以已核保全流程處理，不能在事後才發現丟失。
2. PLAN的parent_raw_guards指向五件原父層receipt，但driver完全未載入該檔，也沒前後bytes/hash守門。原receipt的引用streams亦應有明確保全範圍；不能只靠head/tree不變就宣稱raw證據不動。父層在repo外，正常sparse不應碰它，但目前結果宣告仍未量測此保全條件。

其餘已有head/tree/clean/獨立.git與程序cwd/argv檢查；不把它們當所有ignored檔／原raw完整性的替代。PLAN指定的canvas3+rAF後時窗也只寫在計畫，不是driver自行檢核，需root維持正式排程。v2應保原版及差分，先補事前拒絕與真原raw前後核驗，再做限定靜審；不改任何產品裁判或門檻。本審未聲稱原候選曾執行或曾造成資料損失。

曾嘗試讀不存在README／本機Git sparse man檔只得到閱讀定位失敗，沒有執行產品或回收工具；此處只用可見原程式與PLAN確立守門缺口。
