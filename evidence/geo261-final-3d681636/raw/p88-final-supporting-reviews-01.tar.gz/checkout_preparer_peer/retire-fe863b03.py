"""Release only tracked historical checkout copies; keep Git and all raw receipts."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

repo = Path('/workspace/geo261-cold/g261r2/source-final')
out = Path('/workspace/geo288-main-merge-20261023/cold-checkout-retirement-fe863b03')
out.mkdir(exist_ok=False)
rows = []

def git(*args):
    p = subprocess.run(['git', '-C', str(repo), *args], capture_output=True)
    row = {'argv': ['git', '-C', str(repo), *args], 'exit': p.returncode,
           'stdout': p.stdout.decode(), 'stderr': p.stderr.decode()}
    rows.append(row)
    (out / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    if p.returncode:
        raise RuntimeError(row)
    return p.stdout.decode().strip()

head = git('rev-parse', 'HEAD')
tree = git('write-tree')
if head != 'fe863b0374eafd9f1e57ec5107e28a1101804b56' or tree != '7d4820c18346e9f71576bd14bacefbaec6b78a3a':
    raise RuntimeError('Historical checkout identity differs from reviewed allowlist')
status = git('status', '--porcelain=v1', '--untracked-files=all')
if status:
    raise RuntimeError('Historical checkout has local work; keep it intact')
if Path(git('rev-parse', '--absolute-git-dir')).resolve() != repo / '.git':
    raise RuntimeError('Not an independent historical clone')
active = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit() or int(entry.name) == os.getpid():
        continue
    try:
        cwd = (entry / 'cwd').resolve()
        command = (entry / 'cmdline').read_bytes()
        if cwd == repo or cwd.is_relative_to(repo) or str(repo).encode() in command:
            active.append(int(entry.name))
    except (OSError, RuntimeError):
        pass
if active:
    raise RuntimeError('Historical checkout has active consumers: ' + repr(active))
before = os.statvfs(repo)
git('sparse-checkout', 'set', '--no-cone', '/AGENTS.md')
if git('rev-parse', 'HEAD') != head or git('write-tree') != tree or git('status', '--porcelain=v1', '--untracked-files=all'):
    raise RuntimeError('Checkout identity changed')
after = os.statvfs(repo)
record = {'operation': 'sparsify only clean historical acceptance clone, retain complete Git objects',
          'head': head, 'tree': tree, 'raw_receipts_removed': False,
          'git_objects_removed': False, 'historical_results_changed': False,
          'freed_available_bytes': (after.f_bavail - before.f_bavail) * after.f_frsize,
          'note': 'Index sparse flags and working materialization changed; historical execution did not.',
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
