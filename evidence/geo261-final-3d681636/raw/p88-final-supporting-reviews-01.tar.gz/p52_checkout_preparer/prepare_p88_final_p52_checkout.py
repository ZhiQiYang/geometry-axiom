"""Prepare only a clean independent P52 checkout at the already public final F."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
source = Path('/tmp/g288p88final-3d681636')
dest = B / 'p52-final-source-3d681636'
out = B / 'p52-final-checkout-3d681636'
capture_path = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE') not in (None, '', '0'):
    raise RuntimeError('No optimized execution')
if hashlib.sha256(capture_path.read_bytes()).hexdigest() != 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':
    raise RuntimeError('Original recorder changed')
if dest.exists() or out.exists():
    raise RuntimeError('All preparation outputs must be fresh')
out.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', capture_path)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
r = capture.Recorder(out, env, F)
report = {'schema': 'geo288-p88-final-p52-checkout/1', 'sha': F, 'source': str(source),
          'dest': str(dest), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'test_executed': False, 'build_executed': False, 'exit_code': None}
def git(repo, *args):
    return r.run(['git', *args], cwd=repo, timeout=120, source_sha=F,
                 source_variant='clean-final-checkout-preparation-only')[1]
def snapshot(repo):
    return {'head': git(repo, 'rev-parse', 'HEAD').decode().strip(),
            'status': git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(),
            'index_sha256': hashlib.sha256(git(repo, 'ls-files', '--stage', '-z')).hexdigest()}
try:
    before = snapshot(source)
    report['source_before'] = before
    if before['head'] != F or before['status']:
        raise RuntimeError('Expected a clean final source')
    r.run(['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(source), str(dest)],
          cwd=source, timeout=120, source_sha=F, source_variant='clean-final-checkout-preparation-only')
    git(dest, 'sparse-checkout', 'init', '--no-cone')
    git(dest, 'sparse-checkout', 'set', '--no-cone', '/*', '!/evidence/', '!/tests/evidence/')
    git(dest, '-c', 'core.autocrlf=false', 'checkout', '--detach', F)
    after = snapshot(dest)
    report['destination_after'] = after
    report['source_after'] = snapshot(source)
    if after != before or report['source_after'] != before:
        raise RuntimeError('Full stage identities or clean source differ')
    report['exit_code'] = 0
except Exception:
    report.update(exit_code=1, error=traceback.format_exc())
finally:
    report.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=r.rows)
    shutil.copy2(__file__, out / 'preparer.py.txt')
    shutil.copy2(capture_path, out / 'capture.py.txt')
    capture.dump(out / 'receipt.json', report)
print(json.dumps({k: v for k, v in report.items() if k != 'commands'}))
raise SystemExit(report['exit_code'])
