"""Root-only publication of completed supporting audits after the sequence publisher."""
from pathlib import Path
import json
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
repo = Path('/workspace/geometry-axiom')
summary = B / 'p88-final-sequence-publication/summary-publication.json'
terminal = json.loads(summary.read_text())
if terminal['publication_exit'] != 0:
    raise RuntimeError('The root sequence publisher must finish first')
peer = Path('/workspace/geo299316-refresh-20261023/p88-input-closure-review')
peer323 = Path('/tmp/geo323-merge-20261023')
inputs = {
    'canvas_run1_peer': peer / 'canvas-run1-public',
    'canvas_run2_peer': peer / 'canvas-run2-public',
    'canvas_run1_second_peer': peer323 / 'P88_NEW_F_CANVAS_ROUND1_PEER_REVIEW.json',
    'canvas_run2_second_peer': peer323 / 'P88_NEW_F_CANVAS_ROUND2_PEER_REVIEW.json',
    'first_green_body': B / 'body-final-3d681636-first-green',
    'first_green_body_peer': peer / 'FIRST_GREEN_PRBODY_REVIEW.md',
    'first_green_body_checks': peer / 'FIRST_GREEN_PRBODY_CHECKS.json',
    'first_green_body_publication': B / 'p88-first-green-prbody-publication',
    'source_and_verifier_peer': Path('/workspace/geo314-owner-20261023/review-nowood-9b201164-verifier-3d681636'),
    'p73_new_binding': Path('/workspace/geo288-p73-owner-20261023/binding-final-3d681636'),
    'new_bound_tools': B / 'bound-3d681636',
    'new_verifier_tools': B / 'verifier-tools-3d681636',
    'p52_checkout_preparer': B / 'prepare_p88_final_p52_checkout.py',
    'checkout_preparer_peer': peer / 'checkout-retirement-static',
    'p52_launcher': B / 'run_p88_final_p52_phase.py',
    'p52_launcher_peer': peer323 / 'P88_FINAL_P52_PHASE_LAUNCHER_STATIC_REVIEW.json',
    'historical_observer_retirement': B / 'old-ledger-observer-retirement',
    'latest_review_fetch': B / 'review-refresh-20261023T1226-fetch',
    'latest_review_snapshot': B / 'review-refresh-20261023T1226',
    'publisher': Path(__file__),
}
for label, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing completed input: ' + label + '=' + str(path))
seq = json.loads((B / 'p88-final-sequence-publication/final-summary/sequence-receipt.json').read_text())
record = B / 'P88_FINAL_SUPPORTING_METADATA.json'
if record.exists():
    raise RuntimeError('Publication summary must be new')
record.write_text(json.dumps({
    'schema': 'geo288-p88-final-supporting-reviews/1', 'tested_sha': F,
    'canvas_terminal_original_exits': [r.get('original_workflow_exit') for r in seq['runs']],
    'canvas_all_three_accepted': seq['all_three_accepted'],
    'review_scope': 'Independent raw audits of rounds 1 and 2 plus completed preparatory peer reviews; not new product test execution',
    'first_green_prbody_commit': 'eb5697693a21bf494f3ad8f2525112567eade63e',
    'live_pr_updated': False,
    'old_observer': 'Only obsolete PID712402 was stopped by pidfd identity; historical source, ledger and raw were retained; the reason for its continued polling is not established',
    'cold_retirement_original': 'Not executed: peer found missing ignored-file and parent-raw guards; its preparation remains historical, corrected tools are separate',
    'p52_checkout_launcher_and_bound_tools': 'Prepared and statically reviewed, not yet executed',
    'pending_dynamic_items': ['P88 withdrawal/restoration proof', 'grid', 'four original native partial suites',
                              'P52 formal/verifier/runtime', 'P73', 'Chromium154', 'oracle'],
}, ensure_ascii=False, indent=2) + '\n')
command = ['python3', '-B', str(B / 'record_command.py'),
    '--out', str(B / 'p88-supporting-reviews-publication'), '--sha', F,
    '--cwd', str(repo), '--variant', 'completed-supporting-review-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py',
    '--repo', str(repo), '--branch', 'architecture/geo261-integration-20261016',
    '--issue', '261', '--sha', F, '--label', 'p88-final-supporting-reviews',
    '--result', '新F前兩輪canvas原件與公開封包經獨立逐檔核對，四層exit0、2267/0、85段golden與預期exception1均保真；另封存已完成的PR正文、工具準備及維護審查。這些靜審不是新動態測試結果。',
    '--next', '持續完成P88撤回／恢復及其餘受影響gates；每項另記原命令、退出碼與完整raw。',
    '--receipt', str(record)]
for label, path in inputs.items():
    command += ['--input', label + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=repo).returncode)
