# 新 F 第2輪 canvas 已公開證據對抗核驗

受驗F：3d681636902371ecc528b20f51eea33e272581c9；已公開E：ee28481b1ba62885cc38e305ebf5c4e420c8b3dd，ls-remote實際核同，F→E只有新F evidence prefix。限定本輪未見可確立阻擋。原launcher／outer／workflow／browser-command四退出均0，前後原checkout完整F且clean；1748.520241597秒小於原35分鐘，無CI超時／watchdog。

原CDP_RESULT唯一、full且filter／modifier／skip空、completed=true、2267／0；85段section map逐欄等F原golden、goldenCompare=matched。uncaughtBrowserExceptions原1保留；原stdout唯一[EXPECTED EXCEPTION] Error: fb-auto-probe，無[UNEXPECTED EXCEPTION]，同F的P38預期負控來源已在第一輪核定，沒有冒0exceptions。

公開Git archive與本地出版bytes全同，壓縮包sha256 26464918613afe9a3a0569e7a42ce388173784b130f4ca2ec70ca57f183b97c1；177member以單次向前讀取全部核bytes/hash，沒有extract到產品。公開receipt、原tmp receipt與包內receipt逐bytes同；45份原receipt files、24個原絕對stdout/stderr/combined引用與outer15個原stdin/stdout/stderr引用皆有完整包內映射。原workflow與F Git blob同，driver為已審8a4e69c9；before-index3,890,741bytes/hash、before三組commands/streams、兩driver／binding／diff／原workflow／top launch request均封入，outer reaper終態primary0。publication原exit0與原streams/hash核同。

第3輪已啟、all_three_accepted仍false、sequence driver尚未終態；本結論只接受第2輪，不冒三輪確定性或其他專項已過。本代理只執行自有只讀封包核驗程式（退出0），沒有重跑任何產品、scan、編譯、Chrome或publisher，未寫整合branch/index。完整映射及原hash見CHECKS.json。
