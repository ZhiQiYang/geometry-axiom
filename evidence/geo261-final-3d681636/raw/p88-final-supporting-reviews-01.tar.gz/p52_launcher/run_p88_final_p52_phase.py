"""Launch one original final-F P52 phase, preserving every original exit and stream."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
REPO = B / 'p52-final-source-3d681636'
MAIN = B / 'reference/main'
OUTER = Path('/workspace/geo261-environment/execute_f_extra.py')
FORMAL = Path('/tmp/g288pff')
OUTS = {
    'formal': FORMAL,
    'verifier': B / 'p52-verifier-3d681636',
    'runtime': Path('/tmp/g288prf'),
}

def h(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('phase', choices=OUTS)
a = p.parse_args()
if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE') not in (None, '', '0'):
    raise RuntimeError('Original assertions must remain enabled')
if h(OUTER) != '68256d90e597fe52807637e3603b7392dd09e9a5342909adc54d21fa4cba2928':
    raise RuntimeError('Original outer recorder differs')
sequence_path = B / 'p88-priority/final-3d681636/sequence-receipt.json'
proof_path = B / 'p88-priority/native-raf-controlled-v2-launch.exit.json'
sequence = json.loads(sequence_path.read_text())
proof = json.loads(proof_path.read_text())
if sequence['sha'] != F or proof['sha'] != F or not sequence.get('ended_utc') or not proof.get('ended_utc'):
    raise RuntimeError('Canvas and controlled P88 proof must have genuinely terminated')
if type(sequence.get('driver_exit_code')) is not int or type(proof.get('launcher_exit_code')) is not int:
    raise RuntimeError('Terminal status must have actual exits, whether red or green')
if sequence.get('all_three_completed') is not True or len(sequence.get('runs', [])) != 3:
    raise RuntimeError('All three formal canvas processes must really have run')
if {row.get('index') for row in sequence['runs']} != {1, 2, 3} or not all(
        row.get('process_completed') is True and row.get('ended_utc') for row in sequence['runs']):
    raise RuntimeError('A canvas setup failure cannot stand in for three completed processes')
if proof.get('heavy_process_started') is not True or type(proof.get('actual_process_returncode')) is not int:
    raise RuntimeError('The controlled P88 proof process must have genuinely started and ended')
checkout = B / 'p52-final-checkout-3d681636/receipt.json'
prepared = json.loads(checkout.read_text())
if prepared['sha'] != F or prepared['exit_code'] != 0 or Path(prepared['dest']) != REPO:
    raise RuntimeError('Independent final checkout is not prepared')
out = OUTS[a.phase]
launch = B / ('p52-final-' + a.phase + '-launch')
if out.exists() or launch.exists():
    raise RuntimeError('Every phase output must be new; no resampling or overwrite')
commands = {
    'formal': ['python3', '-B', str(B / 'bound-3d681636/p52-formal.py'),
               '--repo', str(REPO), '--sha', F, '--main-repo', str(MAIN),
               '--out', str(FORMAL), '--heavy-lock', '/tmp/g261r3/heavy.lock'],
    'verifier': ['python3', '-B', str(B / 'verifier-tools-3d681636/run.py'),
                 '--sha', F, '--formal-out', str(FORMAL), '--out', str(out)],
    'runtime': ['python3', '-B', str(B / 'bound-3d681636/p52-runtime/run.py'),
                '--repo', str(REPO), '--scratch', str(out), '--heavy-lock', '/tmp/g261r3/heavy.lock',
                '--baseline-receipt', str(FORMAL / 'receipt.json'), '--main-repo', str(MAIN),
                '--fix-clone', str(B / 'runtime-isolation/fix-3d681636')],
}
command = ['env', '-u', 'NODE_OPTIONS', '-u', 'PYTHONOPTIMIZE', 'python3', '-B', str(OUTER),
           '--label', 'p88-final-p52-' + a.phase, '--sha', F, '--repo', str(REPO),
           '--outer-root', str(B / 'p52-final-outers'), '--',
           'env', '-u', 'NODE_OPTIONS', '-u', 'PYTHONOPTIMIZE', *commands[a.phase]]
launch.mkdir()
frozen = launch / 'tools'
frozen.mkdir()
inputs = [Path(__file__), OUTER]
for folder in (B / 'bound-3d681636', B / 'verifier-tools-3d681636'):
    inputs += sorted(q for q in folder.rglob('*') if q.is_file() and '__pycache__' not in q.parts)
tool_files = []
for index, path in enumerate(inputs):
    raw = path.read_bytes()
    target = frozen / (str(index).zfill(3) + '-' + path.name)
    target.write_bytes(raw)
    tool_files.append({'source': str(path), 'frozen': str(target), 'sha256': h(target), 'bytes': len(raw)})
request = {'schema': 'geo288-p88-final-p52-phase-launch/1', 'sha': F, 'phase': a.phase,
           'command': command, 'cwd': str(REPO), 'started_utc': utc(),
           'environment_input': {k: os.environ.get(k) for k in ('PATH', 'LANG', 'LC_ALL', 'NODE_OPTIONS', 'PYTHONOPTIMIZE')},
           'environment_removals': ['NODE_OPTIONS', 'PYTHONOPTIMIZE'],
           'prerequisites': {str(q): h(q) for q in (sequence_path, proof_path, checkout)},
           'frozen_tools': tool_files, 'actual_process_returncode': None,
           'policy': 'One original phase; no retry, assertion changes, new threshold, or reclassification of original exits.'}
save(launch / 'request.json', request)
with (launch / 'stdout').open('xb') as stdout, (launch / 'stderr').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr)
    request['pid'] = process.pid
    save(launch / 'request.json', request)
    code = process.wait()
result = dict(request, ended_utc=utc(), actual_process_returncode=code,
              stdout_sha256=h(launch / 'stdout'), stderr_sha256=h(launch / 'stderr'),
              tools_unchanged=all(h(q['source']) == q['sha256'] for q in tool_files))
result['launcher_exit_code'] = code if result['tools_unchanged'] else 2
save(launch / 'exit.json', result)
print(json.dumps({k: result[k] for k in ('sha', 'phase', 'actual_process_returncode', 'launcher_exit_code', 'ended_utc', 'tools_unchanged')}))
raise SystemExit(result['launcher_exit_code'])
