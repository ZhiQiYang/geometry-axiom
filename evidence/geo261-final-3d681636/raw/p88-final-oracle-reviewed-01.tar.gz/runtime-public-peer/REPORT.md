# P52 runtime 公開封包獨立審查

來源固定 `3d681636902371ecc528b20f51eea33e272581c9`，公開證據 head `b74f9a2ae7ade1555b9be45283adecc097fb76e3`。獨立工具只讀原件與 Git blob，未重跑產品測試、編譯或瀏覽器，也未修改 Git。

真執行結果為 7923 項 metadata／位元組核對、exit 0、findings 空、publicRoundtripComplete=true。這些數量是封存核對數，並非新增產品裁判。

公開 archive 共 15,983,722 bytes、828 成員，SHA256 `2dd7245370fc089f52a8ec6e69027d0da066c08403b098802bd3a014e9a41576`。全部成員實際解碼並核對 bytes/hash；Git blob 與原發布包一致。1633 個 stage 列冊檔案中，713 個真入包、920 個 cache 明列排除；PACKAGING 另計。更早排除的 8 個 profile 與 8 個 socket/symlink 仍有記錄，不宣稱其內容已封存。

129 個 command 的 request/result/stdin/stdout/stderr 均可在包內定位。258 個 command 輸出、26 個補充 probe/server/reaper log、2 個 launch 輸出，合計 286 個輸出/log 路徑全入包。原 272 是 runtime 內部 subset；未硬套舊數量。696 個 precheck 原件中 695 個入包，唯一外部 formal baseline 以原 formal 分包與 runtime exactcopy 對照。原 receipt SHA256 `5cf3c1e1dc2586f129d06af0afe2c330db6179ad32391a411017bb4e9ead27d8` 與公開 receipt 逐位元組相同。

原 precheck v1 真 exit 2、v2 更正、差分、路徑錯誤 caveat 與追加更正均保留在包內。沒有將 metadata checker 的成功當成產品 gate，也沒有重新解釋 323 已審的 actual runtime 反證。

本輪已 hash 全部公開 payload；沒有再次 hash 原 82MB 全樹。920 個 cache 的排除以真 stage coverage、manifest 與排除理由對照，不宣稱 cache bytes 入包。只核本 dataset 在全域 SHA256SUMS 的條目，未重讀此前大型 canvas/formal 封包。

機器報告：`CHECKS.json`，SHA256 `8cd00b7f172b2da2a05b8c1e7043f8493b2fc9c2c20e1bacdbcba1d27065e97f`。原 command、exit、stdout/stderr、環境與 SHA 保存在同目錄 subcommands。
