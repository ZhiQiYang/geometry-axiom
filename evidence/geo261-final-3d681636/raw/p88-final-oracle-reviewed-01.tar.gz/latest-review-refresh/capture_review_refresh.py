"""Capture authoritative review files in this agent's bare repo, no worktree writes."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/geo318-reading-a-prep')
GIT_DIR = ROOT / 'meta.git'
PREVIOUS = Path('/workspace/geo318-review-refresh-20261023-130127')
REF = 'refs/remotes/origin/handoff/codex-takeover-20261021'
BRANCH = 'handoff/codex-takeover-20261021'
NUMBERS = (288, 323, 318, 314)
started = datetime.datetime.now(datetime.timezone.utc)
OUT = Path('/workspace') / ('geo318-review-refresh-' + started.strftime('%Y%m%d-%H%M%S'))
OUT.mkdir(mode=0o700)
(OUT / 'streams').mkdir(mode=0o700)
os.umask(0o077)
env = dict(os.environ)
env['GIT_OPTIONAL_LOCKS'] = '0'
rows = []
receipt = {
    'started_utc': started.isoformat(),
    'scope': 'ordinary handoff fetch and four small review blobs, no integration/worktree changes',
    'environment': {
        'platform': platform.platform(), 'python': sys.version,
        'cwd': str(ROOT),
        'selected_environment': {k: env[k] for k in ('PATH', 'LANG', 'LC_ALL', 'LC_CTYPE', 'GIT_OPTIONAL_LOCKS') if k in env},
    },
    'commands': rows,
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save_receipt():
    (OUT / 'FETCH.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')

def run(args):
    argv = ['git', '--git-dir=' + str(GIT_DIR)] + args
    i = len(rows) + 1
    t0 = time.monotonic()
    p = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    streams = {}
    for label, raw in (('stdout', p.stdout), ('stderr', p.stderr)):
        target = OUT / 'streams' / ('%02d.%s' % (i, label))
        target.write_bytes(raw)
        streams[label] = {'path': str(target), 'bytes': len(raw), 'sha256': sha(raw)}
    rows.append({'argv': argv, 'exit_code': p.returncode, 'elapsed_seconds': time.monotonic() - t0, **streams})
    save_receipt()
    if p.returncode != 0:
        raise RuntimeError('Git command %d failed with exit %d; see raw streams' % (i, p.returncode))
    return p.stdout

def comments(raw):
    parts = re.split(r'(?m)^### (\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ) ([^\n]+)\n', raw.decode('utf-8'))
    result = []
    for i in range(1, len(parts), 3):
        date, author, body = parts[i:i+3]
        title = next((s.strip() for s in body.splitlines() if s.strip()), '')
        heads = re.findall(r'\bhead\s*[=:]?\s*`?([0-9a-f]{7,40})\b', body, flags=re.I)
        result.append({'date': date, 'author': author, 'title': title, 'heads_mentioned': heads, 'body': body})
    return result

def meta(c):
    return {k: v for k, v in c.items() if k != 'body'}

try:
    run(['--version'])
    before = run(['rev-parse', REF]).decode().strip()
    run(['fetch', '--no-tags', 'origin', BRANCH + ':' + REF])
    current = run(['rev-parse', REF]).decode().strip()
    run(['show', '-s', '--format=fuller', current])
    previous_source = json.loads((PREVIOUS / 'SOURCE.json').read_text())
    previous = previous_source['source_sha']
    run(['log', '--format=fuller', previous + '..' + current, '--'] + ['handoff/pr-reviews/%s.md' % n for n in NUMBERS])
    source = {
        'source_branch': BRANCH, 'source_sha': current, 'ref_before_fetch': before,
        'baseline_source_sha': previous, 'baseline_directory': str(PREVIOUS),
        'fetch_utc': started.isoformat(), 'files': {},
    }
    result = {'source_sha': current, 'baseline_source_sha': previous, 'items': {}}
    for n in NUMBERS:
        path = 'handoff/pr-reviews/%s.md' % n
        blob = run(['rev-parse', current + ':' + path]).decode().strip()
        raw = run(['show', current + ':' + path])
        (OUT / ('%s.md' % n)).write_bytes(raw)
        old = (PREVIOUS / ('%s.md' % n)).read_bytes()
        old_comments, now_comments = comments(old), comments(raw)
        old_keys = {(c['date'], c['author'], c['body']) for c in old_comments}
        changed_comments = [c for c in now_comments if (c['date'], c['author'], c['body']) not in old_keys]
        chat = [c for c in now_comments if c['title'].startswith('【ChatGPT')]
        old_chat = [c for c in old_comments if c['title'].startswith('【ChatGPT')]
        (OUT / ('%s.latest-comment.md' % n)).write_text(now_comments[-1]['body'])
        if chat:
            (OUT / ('%s.latest-chatgpt.md' % n)).write_text(chat[-1]['body'])
        diff = ''.join(difflib.unified_diff(old.decode('utf-8').splitlines(True), raw.decode('utf-8').splitlines(True), fromfile='baseline-acd/%s.md' % n, tofile='fresh/%s.md' % n))
        (OUT / ('%s.since-acd.diff' % n)).write_text(diff)
        (OUT / ('%s.new-comments.md' % n)).write_text('\n'.join('### %s %s\n%s' % (c['date'], c['author'], c['body']) for c in changed_comments))
        source['files'][str(n)] = {'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob, 'baseline_sha256': sha(old)}
        result['items'][str(n)] = {
            'raw_changed': raw != old,
            'comment_count_before': len(old_comments), 'comment_count_now': len(now_comments),
            'latest_comment': meta(now_comments[-1]),
            'latest_chatgpt': meta(chat[-1]) if chat else None,
            'baseline_latest_chatgpt': meta(old_chat[-1]) if old_chat else None,
            'new_or_edited_comments': [meta(c) for c in changed_comments],
            'new_chatgpt_after_previous': [meta(c) for c in changed_comments if c['title'].startswith('【ChatGPT')],
        }
    result['has_new_288_review_after_123532_head_ee28481'] = any(c['date'] > '2026-10-23T12:35:32Z' for c in comments((OUT / '288.md').read_bytes()) if c['title'].startswith('【ChatGPT'))
    (OUT / 'SOURCE.json').write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'REVIEW_METADATA.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt['exit_code'] = 0
    save_receipt()
    print(json.dumps({'output': str(OUT), 'source_sha': current, 'baseline_sha': previous, 'new_288_review': result['has_new_288_review_after_123532_head_ee28481'], 'items': {n: {'changed': r['raw_changed'], 'latest': r['latest_comment'], 'new_comments': len(r['new_or_edited_comments'])} for n, r in result['items'].items()}}, ensure_ascii=False, indent=2))
except BaseException as exc:
    receipt['exception_type'] = type(exc).__name__
    receipt['exception'] = str(exc)
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt['exit_code'] = 1
    save_receipt()
    raise
