# cold v3 實際終態對抗審

結論：兩件真終態均接受，未發現可確立阻擋。a12d184e 與 fe863b03 各 wrapper／driver／refresh／reapply 退出碼皆 0；每件 26 條原 Git 命令與 52 份原 stdout/stderr 的完整 bytes/hash 全核。兩個變動命令精確只有 update-index --refresh、sparse-checkout reapply；它們原 stdout/stderr 都空，沒有沿用 v2 警告冒成功。

兩件實際工具記錄均為已審 PACKAGE33dc5440…／commonab191bec…；原固定 HEAD/tree、own gitdir/common-dir 與四次完整 index-stage bytes 前後、對 v2 全同，staged/worktree/nontracked/ignored 相關原輸出空。兩次變動前 metadata 庫存皆無非追蹤或型別錯誤；三次 consumer guards active=[]，R3 獨占事件有原紀錄，不外推不可讀 proc。

真正 materialization goal 各為 retained_AGENTS_regular=true、existing_tracked_nodes=1、remaining_non_AGENTS_tracked_nodes=[]，goal pending→完整成功流程相符。因此本次不只命令退出0，而有工具逐筆原 index lstat 的實際達標收據。本審查沒有自行重掃產品樹，依已審 frozen driver 與原 goal metadata 判定。

前後兩批各五份原 parent raw receipts，event／pin／原副本／目前小型原receipt bytes/hash 全相符，raw_receipts_removed=false 與 parent_raw_verified_unchanged=true 有完整保全證據。v2 原 receipt 與 sparse 警告原檔 hash 都仍與先前審查相同，負空間差歷史保留。

v3 觀測可用空間增加分別 1,244,446,720 與 1,350,230,016 bytes（合計 2,594,676,736 bytes）；它們是檔案系統區間觀測，不作所有移除位元組的獨占歸因。無原子 TOCTOU 或全 /proc 可見宣稱。這是環境維護終態接受，不代替產品 gate。

獨立審查器 exit0，只讀 metadata、原命令串流、原 inventory metadata、五份小 parent receipt；未執行 driver／candidate／產品測項，也未重 hash 產品大樹或寫整合分支。原各 receipt/tool/stream SHA 與完整限制見 CHECKS.json。
