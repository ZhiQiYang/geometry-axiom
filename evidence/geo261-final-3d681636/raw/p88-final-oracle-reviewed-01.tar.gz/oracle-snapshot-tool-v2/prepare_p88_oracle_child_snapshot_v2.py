"""Snapshot immutable published child evidence without reading its mutable worktree."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import io
B=Path('/workspace/geo288-main-merge-20261023')
R=Path('/workspace/kernel-no-wood-prep/metadata.git')
F='3d681636902371ecc528b20f51eea33e272581c9'
E='9dfdac7bbded443ff5d9624d1c8fdfa7adc0ccac'
prefix='evidence/geo288-oracle-final-3d681636/'
preparation_prefix='evidence/geo288-oracle-preparation-3d681636/'
allowed=(prefix,preparation_prefix)
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse',E+'^{commit}').decode().strip()==E
changed=git('diff','--name-only',F,E).decode().splitlines()
assert changed and all(n.startswith(allowed) for n in changed)
remote=git('ls-remote','--heads','origin','codex/geo288-oracle-final-20261023').decode().split()[0]
subprocess.run(['git','merge-base','--is-ancestor',E,remote],cwd=R,check=True)
out=B/'oracle-child-immutable-9dfdac7b';out.mkdir(exist_ok=False)
rows=git('ls-tree','-r','-z',E,'--',prefix,preparation_prefix).split(b'\0')
files=[]
for row in rows:
 if not row:continue
 header,name=row.split(b'\t',1);mode,kind,blob=header.decode().split();name=name.decode()
 assert mode=='100644' and kind=='blob' and name.startswith(allowed)
 data=git('cat-file','blob',blob)
 destination=out/name
 destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
 files.append({'git_path':name,'git_blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'SOURCE.json').write_text(json.dumps({'sha':F,'child_evidence_head':E,'observed_remote_head':remote,'all_changed_paths':changed,'files':files,'scope':'Immutable child Git blobs; no acceptance rerun and no source import'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'child_evidence_head':E,'files':len(files),'snapshot':str(out)}))
