native 四組 partial 的公開 Git 封包對抗審已完成，875 項封包／metadata 核對全部符合，未見可確立的新阻擋。原件 60 項核對的凍結結果仍保留；這些數字是審查核對數，不是新增產品測試數。

產品 F 為 `3d681636902371ecc528b20f51eea33e272581c9`，公開 E 為 `c7214307d5ffc6a867089c8d832fef4bc94ae27c`。Git blob 中的 `raw/native-partial-four-01.tar.gz` 為 4,021,573 bytes，SHA256 `7b0dffbfe1809d90b52fd87960fffecda0cd5e2cfbad3cae2638157c824942c8`；與原本機封包及公開 inventory 相同。

493 個成員（原始總計 21,412,328 bytes）按公開 inventory 的原順序逐一核 bytes／SHA256，並逐 bytes 比對原 publication request 明列的六組實際來源。六個 label 全覆蓋；全部 72 個 native 命令的 request、result、stdin、stdout、stderr 及 outer 命令的原件都在包中。公開 SHA256SUMS 除本身外覆蓋全部證據檔，逐項 hash 均相符；原 excluded 清單為空。原 native receipt 在 E 中與實際原件完全相同，遠端 branch head 也核為 E。

原產品結果仍是四個 selectors 的 PARTIAL：17＋3＋51＋737＝808 pass／0 fail／0 skip，原 native、run_all、reaper、outer exits 全 0。`--build` 原輸出如實為三個 binary reused／fresh；沒有聲稱本輪重新編譯。原前後 clean F、index、14 輸入及精確補回的三個 .gcanvas fixture 身份已在凍結原件審查確認。未把這 808 項外推為完整 native，也未與歷史完整 native 加總。

原通用 publisher 的 gitignore 路徑拒絕 exit1 與精確 evidence 前綴 force-add 後的一般 commit／push 0，保留在 `/tmp/g288-final-native-publication-3d681636/` 及 `/tmp/g288-final-native-publication-resume-3d681636/`；這兩組出版 metadata 是獨立原始根，供 root 一併封存，沒有把它們誤分類成 native 產品紅燈或刪去。沒有改 .gitignore、產品或測試，沒有 force push。

公開審查於 root 明示 P52 formal 結束後的短窗口執行，僅做原件讀取、Git blob 讀取與封包解碼；沒有 build、測試、瀏覽器或分支 mutation。原先 `ORIGINAL_REVIEW.md` 的「公開 roundtrip 待窗口」是當時狀態，該原件未覆寫；本檔與 `public-roundtrip/PUBLIC_NATIVE_CHECKS.json` 記本次完成結果。包已全核，P52 runtime 期間不再重讀。

`PUBLIC_NATIVE_CHECKS.json` SHA256：`c97d5779bb2d124a81017de712b1fda7ce255d43c54d189b7d13b32625cf95c3`。最主要限制仍是原四組 partial 範圍與其他正式 gates 各有其原收據；本審查不宣告整個 #288 可合併。
