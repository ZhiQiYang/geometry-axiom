"""Publish reviewed oracle originals and completed cross-audits, without source changes."""
from pathlib import Path
import hashlib
import json
import subprocess
B=Path('/workspace/geo288-main-merge-20261023')
F='3d681636902371ecc528b20f51eea33e272581c9'
load=lambda p:json.loads(p.read_text())
receipt=Path('/tmp/g288o-3d681636/receipt.json')
assert hashlib.sha256(receipt.read_bytes()).hexdigest()=='6795ae26520b2620ab14e51516cc6399db7ef7e660243437819e7d972dc9d889'
r=load(receipt)
assert r['acceptance_sha']==F and r['exit_code']==0 and r['all_steps_completed'] and not r['errors'] and r['ended_utc']
assert [s['original_command_result']['actual_process_returncode'] for s in r['steps']]==[0,0,0,1,0,0,1,0]
assert all(s['ok'] for s in r['steps'])
peer=Path('/workspace/geo314-owner-20261023/review-oracle-actual-public-3d681636')
a=load(peer/'CHECKS.json');assert a['sourceSHA']==F and a['exitCode']==0 and not a['findings'] and a['publicRoundtripComplete']
rt=load(Path('/workspace/geo314-owner-20261023/review-runtime-public-b74f9a2a/CHECKS.json'));assert rt['sourceSHA']==F and not rt['findings'] and rt['publicRoundtripComplete']
inputs={
 'oracle-child-git-snapshot':B/'oracle-child-immutable-9dfdac7b',
 'oracle-original-and-public-peer':peer,
 'oracle-child-publication':Path('/workspace/kernel-no-wood-prep/oracle-new-f/execution-publication-3d681636'),
 'oracle-snapshot-first-failure':B/'oracle-child-snapshot-record',
 'oracle-snapshot-second-failure':B/'oracle-child-snapshot-record-v2',
 'oracle-snapshot-success':B/'oracle-child-snapshot-record-v3',
 'oracle-snapshot-tool-v1':B/'prepare_p88_oracle_child_snapshot.py',
 'oracle-snapshot-tool-v2':B/'prepare_p88_oracle_child_snapshot_v2.py',
 'oracle-snapshot-tool-v3':B/'prepare_p88_oracle_child_snapshot_v3.py',
 'oracle-snapshot-correction':B/'ORACLE_SNAPSHOT_CORRECTION.md',
 'runtime-public-peer':Path('/workspace/geo314-owner-20261023/review-runtime-public-b74f9a2a'),
 'runtime-precheck-correction-peer':Path('/workspace/geo314-owner-20261023/review-runtime-precheck-correction'),
 'runtime-root-publication':B/'p52-final-runtime-completed-publication',
 'formal-original-peer':Path('/tmp/geo323-merge-20261023/P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.json'),
 'formal-original-peer-report':Path('/tmp/geo323-merge-20261023/P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.md'),
 'formal-peer-preliminary-counting-error':Path('/tmp/geo323-merge-20261023/P52_FINAL_FORMAL_ACTUAL_PEER_REVIEW.preliminary-counted-version.json'),
 'formal-verifier-public-peer':Path('/tmp/geo323-merge-20261023/P52_FINAL_PUBLIC_ROUNDTRIP'),
 'formal-root-publication':B/'p52-final-formal-publication',
 'verifier-root-publication':B/'p52-final-verifier-publication',
 'p73-root-publication':B/'p88-final-p73-root-publication',
 'legacy-root-publication':B/'p88-final-chromium154-root-publication',
 'grid-root-publication':B/'p88-final-grid-root-publication',
 'native-root-publication':B/'p88-final-native-root-publication',
 'native-public-report':Path('/workspace/geo314-owner-20261023/review-native-four-3d681636/PUBLIC_REVIEW.md'),
 'cold-v3-actual-peer':Path('/workspace/geo299316-refresh-20261023/p88-input-closure-review/cold-v3-actual'),
 'latest-review-refresh':Path('/workspace/geo318-review-refresh-20261023-134623'),
 'previous-current-body':B/'body-final-3d681636-grid-native-p52',
 'previous-body-generation':B/'p88-grid-native-p52-body-generation',
 'previous-body-peer':Path('/workspace/geo314-owner-20261023/review-prbody-grid-native-p52'),
 'previous-body-publication':B/'p88-grid-native-p52-prbody-publication',
 'publisher-wrapper':Path(__file__),
}
for name,path in inputs.items():assert path.exists(),name+'='+str(path)
result='新F oracle八階段原退出0/0/0/1/0/0/1/0、driver/outer/top皆0；原quick0、probe完整Ran60/OK、C4具名bad8/0/8及core_limits正常AssertionError2!=1反證0/1/0。85source/68fixture前後同，原判官/時限/expected未改；獨立actual+公開包peer2214項無finding。另完成P52原件845/1267及formal/verifier公開5840、runtime公開7923項審查，原streams/cache排除與歷史metadata錯誤都保留。本輪所有列定受影響正式項/反證已通過，沒有把歷史沿用項冒稱F重跑。F3d仍按原政策處理step_core528/step_mirror_core1056，閱讀A變更只在#318另分支；oracle原P182-t4已知C11_MAIN_NOT_BUTTED6次文字保留，非新assert紅。'
argv=['python3','-B','/workspace/geo261-environment/publish_followup_progress.py','--repo','/workspace/geometry-axiom','--branch','architecture/geo261-integration-20261016','--issue','261','--sha',F,'--label','p88-final-oracle-reviewed','--result',result,'--next','完成唯一current-state正文與SHA連結核對後推prbody分支；#323已接續原基線驗收，維持不merge PR、不force push。','--receipt',str(receipt)]
for name,path in inputs.items():argv+=['--input',name+'='+str(path)]
raise SystemExit(subprocess.run(argv,cwd='/workspace/geometry-axiom').returncode)
