"""Install exactly the validated four architecture outputs and publish the new final source."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import traceback

base = Path('/workspace/geo288-main-merge-20261023')
repo = Path('/workspace/geometry-axiom')
S = '4b588fb63c9cc8fe5ba7570618f353c0d00d3816'
M = 'c1320a7ad41530252a6f335aaab372154a0e2bf2'
main = '4ccced59315d0bcf01084ad89c760bb43d8b363b'
branch = 'architecture/geo261-integration-20261016'
refresh = Path('/tmp/g288p88arch-one-4b588fb6/refresh')
names = ['product-architecture.json', 'product-architecture-scan.json', 'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json']
relative = Path('geometry-core/domain-decoupling')
out = base / 'p88-architecture-install-publication'
assert not out.exists()
out.mkdir()
spec = importlib.util.spec_from_file_location('capture', Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'))
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
r = cap.Recorder(out, dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0'), S)
receipt = {'schema': 'geo288-post-p88-architecture-final-source/1', 'architecture_actual_source_sha': S,
           'ordinary_main_merge_sha': M, 'p88_source_merge_sha': S, 'main_sha': main, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'branch': branch, 'files': [], 'product_or_test_source_edited': False, 'force_push': False}

def git(*args):
    return r.run(['git', *args], cwd=repo, timeout=120, source_variant='validated-architecture-artifact-publication')[1].decode().strip()

try:
    result = json.loads((refresh / 'RESULT.json').read_text())
    outer = json.loads(Path('/tmp/g288p88arch-one-4b588fb6/receipt.json').read_text())
    assert result['source_sha'] == outer['source_sha'] == S and result['passed'] and outer['passed']
    assert outer['actual_process_returncode'] == 0 and not outer['errors']
    assert result['scan_exit_code'] == 0 and result['validation_exit_codes'] == [0, 0]
    assert result['originalManifestPreflightExitCodes'] == [1, 0, 5]
    assert git('branch', '--show-current') == branch and git('rev-parse', 'HEAD') == S
    assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
    before = (repo / relative / names[0]).read_bytes()
    expected = before
    assert len(result['updatedExclusions']) == 1
    for row in result['updatedExclusions']:
        old, new = row['previousSha256'].encode(), row['sha256'].encode()
        assert expected.count(old) == 1
        expected = expected.replace(old, new, 1)
    assert expected == (refresh / 'new' / names[0]).read_bytes()
    generated_receipt = json.loads((refresh / 'new' / names[3]).read_text())
    assert generated_receipt['sourceBaseHead'] == S
    for name in names:
        src, dst = refresh / 'new' / name, repo / relative / name
        data = src.read_bytes()
        receipt['files'].append({'path': str(relative / name), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        shutil.copy2(src, dst)
    git('add', '--', *[str(relative / name) for name in names])
    staged = git('diff', '--cached', '--name-only').splitlines()
    assert staged and set(staged) <= {str(relative / name) for name in names}
    git('diff', '--cached', '--check')
    git('commit', '-m', 'Refresh GEO-261 architecture receipts for P88 input stabilization')
    F = git('rev-parse', 'HEAD')
    assert git('rev-list', '--parents', '-n', '1', F).split() == [F, S]
    git('merge-base', '--is-ancestor', main, F)
    assert git('rev-parse', F + ':決策佇列.md') == git('rev-parse', main + ':決策佇列.md')
    assert git('rev-parse', F + ':公理層.md') == git('rev-parse', M + ':公理層.md')
    receipt['created_final_source_sha'] = F
    cap.dump(out / 'receipt.json', dict(receipt, commands=r.rows))
    git('push', 'origin', 'HEAD:refs/heads/' + branch)
    assert git('ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch).split() == [F, 'refs/heads/' + branch]
    assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
    receipt.update(final_source_sha=F, exit_code=0, acceptance_state='new final SHA published; affected formal gates still pending')
except Exception:
    receipt.update(exit_code=1, error=traceback.format_exc())
finally:
    receipt.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=r.rows)
    cap.dump(out / 'receipt.json', receipt)
    if receipt.get('exit_code') == 0:
        cap.dump(base / 'P88_FINAL_SOURCE.json', receipt)
print(json.dumps({k: v for k, v in receipt.items() if k != 'commands'}, ensure_ascii=False))
raise SystemExit(receipt['exit_code'])
