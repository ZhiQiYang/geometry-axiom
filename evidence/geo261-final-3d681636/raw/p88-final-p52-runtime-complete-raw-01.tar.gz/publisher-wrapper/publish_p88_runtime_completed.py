"""Publish completed original runtime proof with the reviewed path correction."""
from pathlib import Path
import hashlib
import json
import subprocess
import argparse
B=Path('/workspace/geo288-main-merge-20261023')
F='3d681636902371ecc528b20f51eea33e272581c9'
P=B/'p88-priority'
p=argparse.ArgumentParser();p.add_argument('--coverage',type=Path,required=True);a=p.parse_args()
load=lambda p:json.loads(p.read_text())
assert load(B/'runtime-final-staging-record/receipt.json')['exit_code']==0
r=load(Path('/tmp/g288prf/receipt.json'));assert r['sha']==F and r['passed'] and not r['errors'] and r['ended_utc']
assert [v['receipt']['gate_exit'] for v in r['phases']]==[1,0]
package=load(Path('/tmp/g288prf-publication-complete/PACKAGING.json'))
assert package['source']=='/tmp/g288prf' and package['original_receipt_sha256']==hashlib.sha256(Path('/tmp/g288prf/receipt.json').read_bytes()).hexdigest()
assert a.coverage.is_file()
coverage=load(a.coverage)
assert coverage['product_sha']==F and coverage['exit_code']==0 and coverage['passed'] is True and coverage['errors']==[]
argv=load(P/'runtime-final-packaging-path-correction/ACTUAL_PATHS_AND_ARGV.json')['publisher_argv_template_with_correct_actual_input_paths']
argv[argv.index('--result')+1]='新F正式baseline／撤回runtime修正／放回修正原gate為0/1/0，ratio依序0.889796209710257／1.0337406540912426／0.8462365083581334；每phase保原main/fix/fix/main四區塊、每側16筆、原≤1門檻，無重抽樣。runtime driver／outer／launcher／parentcapture皆0，原source/runtime before-after與restore核同；獨立原件審查1267項無finding。原完整stage1633檔、81,821,566 bytes；實際封包與排除逐項列inventory，正式baseline完整streams在另formal包。封存原錯路徑與metadata checker v1錯誤照留、更正分開記錄。'
argv[argv.index('--next')+1]='完成新F P73／Chromium154及oracle8phase，逐項peer與更新唯一正文矩陣；所有歷史未受影響gate保留實際SHA。'
inputs={
 'preflight':B/'runtime-final-root-preflight',
 'stage-wrapper':B/'stage_p88_final_runtime_verified.py',
 'precheck-v1':P/'runtime-final-prechecks',
 'precheck-v2':P/'runtime-final-prechecks-v2',
 'precheck-tool-v1':P/'check_runtime_prepublication.py',
 'precheck-tool-v2':P/'check_runtime_prepublication_v2.py',
 'precheck-correction':P/'RUNTIME_PRECHECK_CORRECTION.md',
 'precheck-diff':P/'runtime-precheck-v2.diff',
 'independent-original-peer':Path('/tmp/geo323-merge-20261023/P52_FINAL_RUNTIME_ACTUAL_PEER_REVIEW.json'),
 'staging-static-and-path-peer':Path('/workspace/geo314-owner-20261023/review-runtime-final-packaging-preparation'),
 'staging-stream-coverage':a.coverage,
 'staging-coverage-tool':P/'check_runtime_stage_coverage.py',
 'publisher-wrapper':Path(__file__),
}
for label,path in inputs.items():
 assert path.exists(),str(path)
 argv+=['--input',label+'='+str(path)]
for i,v in enumerate(argv):
 if v=='--input':assert Path(argv[i+1].split('=',1)[1]).exists(),argv[i+1]
assert not any(v.startswith('<') for v in argv)
raise SystemExit(subprocess.run(argv,cwd='/workspace/geometry-axiom').returncode)
