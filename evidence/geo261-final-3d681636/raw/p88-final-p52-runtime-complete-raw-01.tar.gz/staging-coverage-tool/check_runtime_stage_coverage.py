"""Read-only original/stage/inclusion checks; never invokes stage or publisher."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

B = Path('/workspace/geo288-main-merge-20261023')
D = B / 'p88-priority'
RAW = Path('/tmp/g288prf')
STAGE = Path('/tmp/g288prf-publication-complete')
F = '3d681636902371ecc528b20f51eea33e272581c9'
OUT = D / 'runtime-final-stage-coverage'
OUT.mkdir(exist_ok=False)
checks, errors, dispositions, mapped = [], [], [], []

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def ck(label, value):
    checks.append({'label': label, 'passed': bool(value)})
    if not value:
        errors.append(label)

def exclusion(rel, p):
    # Exact current original publisher path/ELF predicate; hash binding below.
    if any(part in ('.git', '__pycache__', 'node_modules', 'geometry-runtime', 'profile', 'chrome-profile', 'node-compile-cache') or part.startswith(('geometry-cdp-', 'geometry-documents-chrome-', 'com.google.Chrome.')) for part in rel.parts):
        return 'rebuildable-cache-by-original-publisher'
    with p.open('rb') as f:
        if f.read(4) == b'\x7fELF':
            return 'rebuildable-ELF-by-original-publisher'
    return None

summary = {}
try:
    publisher = Path('/workspace/geo261-environment/publish_followup_progress.py')
    ck('publisher-frozen-original', digest(publisher) == 'c2fdeb5eb9174549c5a80726bdd37266b22f0f75ff94d744fdc82c0f384a14d2')
    pre = json.loads((D / 'runtime-final-prechecks-v2/CHECKS.json').read_text())
    ck('precheck-exact-accepted-v2', digest(D / 'runtime-final-prechecks-v2/CHECKS.json') == 'ce43c2fb406a09e4f46e8ed48b3ef56c3240cea060fa587db39b24f7a80d0c07' and pre['passed'] is True and pre['exit_code'] == 0)
    stage_receipt = json.loads((B / 'runtime-final-staging-record/receipt.json').read_text())
    command = stage_receipt['original_command_result']
    ck('stage-actual-exit0-terminal-F', stage_receipt['sha'] == F and stage_receipt['exit_code'] == 0 and command['actual_process_returncode'] == 0 and command['ended_epoch'] is not None and command['timeout_expired'] is False)
    command_dir = Path(command['directory'])
    for stream in ('stdin', 'stdout', 'stderr'):
        p = command_dir / (stream + '.bin')
        ck('stage-' + stream + '-original-hash', digest(p) == command[stream + '_sha256'])
    packaging = json.loads((STAGE / 'PACKAGING.json').read_text())
    ck('packaging-raw-binding', packaging['source'] == str(RAW) and packaging['original_receipt_sha256'] == digest(RAW / 'receipt.json') == pre['summary']['source_receipt_sha256'])
    rows = packaging['files']
    bypath = {r['path']: r for r in rows}
    ck('packaging-unique-paths', len(bypath) == len(rows))
    observed = {p.relative_to(STAGE).as_posix() for p in STAGE.rglob('*') if p.is_file() and not p.is_symlink()}
    ck('stage-regular-exact-set', observed == set(bypath) | {'PACKAGING.json'})
    for row in rows:
        rel = Path(row['path'])
        original, staged = RAW / rel, STAGE / rel
        ck(row['path'] + ':safe-regular', not rel.is_absolute() and '..' not in rel.parts and original.is_file() and staged.is_file() and not original.is_symlink() and not staged.is_symlink())
        a, b = original.stat(), staged.stat()
        ck(row['path'] + ':same-original-hardlink-size', a.st_dev == b.st_dev and a.st_ino == b.st_ino and a.st_size == b.st_size == row['bytes'])
        ck(row['path'] + ':actual-complete-bytes-hash', digest(staged) == row['sha256'])
        reason = exclusion(rel, staged)
        dispositions.append({'source_relative': row['path'], 'archive_member': 'runtime-complete/' + row['path'], 'bytes': row['bytes'], 'sha256': row['sha256'], 'predicted_disposition': 'excluded' if reason else 'included', 'exclusion_reason': reason})
    predicted = {r['source_relative']: r for r in dispositions}
    inputs = [
        (RAW, 'runtime-complete', STAGE),
        (B / 'p52-final-outers/p88-final-p52-runtime', 'outer', B / 'p52-final-outers/p88-final-p52-runtime'),
        (B / 'p52-final-runtime-launch', 'launch', B / 'p52-final-runtime-launch'),
        (B / 'p52-final-runtime-execution', 'execution', B / 'p52-final-runtime-execution'),
    ]
    for row in pre['files']:
        p = Path(row['path'])
        if row['kinds'] == ['external-formal-baseline']:
            ck(str(p) + ':explicit-separate-formal-package', digest(p) == row['sha256'])
            mapped.append(dict(row, destination='separate-formal-package; exact copy also retained in runtime stage'))
            continue
        matches = [(root, label, target) for root, label, target in inputs if p.is_relative_to(root)]
        ck(str(p) + ':unique-explicit-input', len(matches) == 1)
        root, label, target = matches[0]
        rel = p.relative_to(root)
        target_file = target / rel
        ck(str(p) + ':included-not-cache-or-ELF', exclusion(rel, target_file) is None)
        ck(str(p) + ':complete-prechecked-bytes-unchanged', target_file.stat().st_size == row['bytes'] and digest(target_file) == row['sha256'])
        if root == RAW:
            ck(str(p) + ':packaging-entry-included', rel.as_posix() in predicted and predicted[rel.as_posix()]['predicted_disposition'] == 'included')
        mapped.append(dict(row, destination=(Path(label) / rel).as_posix()))
    summary = {'staged_listed_files': len(rows), 'staged_listed_bytes': sum(r['bytes'] for r in rows), 'stage_excluded_paths': len(packaging['excluded']), 'predicted_stage_members_included': sum(r['predicted_disposition'] == 'included' for r in dispositions), 'predicted_stage_members_excluded': sum(r['predicted_disposition'] == 'excluded' for r in dispositions), 'additional_stage_PACKAGING_member': 1, 'original_precheck_files_mapped': len(mapped), 'all_stage_bytes_hashed': True, 'all_original_command_streams_predicted_included': True, 'PACKAGING_sha256': digest(STAGE / 'PACKAGING.json'), 'stage_receipt_sha256': digest(B / 'runtime-final-staging-record/receipt.json')}
except Exception as exc:
    errors.append(type(exc).__name__ + ': ' + str(exc))
report = {'schema': 'geo288-runtime-stage-original-stream-coverage/1', 'utc': datetime.now(timezone.utc).isoformat(), 'product_sha': F, 'exit_code': 0 if not errors else 2, 'passed': not errors, 'errors': errors, 'checks': checks, 'summary': summary, 'stage_dispositions': dispositions, 'prechecked_file_mapping': mapped, 'scope': 'Actual original/stage complete bytes and hardlinks checked; exact original publisher filtering predicted and every stream included. No publisher, gzip, archive readback or Git publication ran here. Public archive roundtrip remains required.', 'stage_executed_by_this_tool': False, 'publisher_executed': False}
(OUT / 'CHECKS.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': report['exit_code'], 'passed': report['passed'], 'errors': errors, 'checks': len(checks), 'summary': summary}, ensure_ascii=False))
sys.exit(report['exit_code'])
