"""Hardlink complete closed raw output, excluding only recorded Chrome caches."""
import hashlib
import json
import os
from pathlib import Path

source = Path('/tmp/g288prf')
target = Path('/tmp/g288prf-publication-complete')
assert not target.exists()
receipt = json.loads((source / 'receipt.json').read_text())
assert receipt['passed'] is True and receipt['errors'] == []
assert [p['receipt']['gate_exit'] for p in receipt['phases']] == [1, 0]
profile_paths = set()
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'GEOMETRY_CHROME_PROFILE' and isinstance(item, str):
                path = Path(item)
                if path.is_relative_to(source):
                    profile_paths.add(path)
            collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
collect(receipt)
expected = {source / phase / 'work' / 'tmp' / ('chrome-' + str(i)) for phase in ('withdrawn', 'restored') for i in range(4)}
assert profile_paths == expected, profile_paths
target.mkdir()
files, excluded = [], []
for directory, subdirs, names in os.walk(source, followlinks=False):
    directory = Path(directory)
    for name in list(subdirs):
        child = directory / name
        if child in profile_paths or child.is_symlink() or child.name.startswith('com.google.Chrome.'):
            subdirs.remove(name)
            excluded.append({'path': str(child), 'reason': 'recorded rebuildable Chrome profile' if child in profile_paths else 'symlink; no original stream removed'})
    destdir = target / directory.relative_to(source)
    destdir.mkdir(parents=True, exist_ok=True)
    for name in names:
        child = directory / name
        if child.is_symlink() or not child.is_file():
            excluded.append({'path': str(child), 'reason': 'symlink; no original stream removed'})
            continue
        os.link(child, destdir / name)
        files.append({'path': child.relative_to(source).as_posix(), 'bytes': child.stat().st_size, 'sha256': hashlib.sha256(child.read_bytes()).hexdigest()})
(target / 'PACKAGING.json').write_text(json.dumps({'source': str(source), 'original_receipt_sha256': hashlib.sha256((source / 'receipt.json').read_bytes()).hexdigest(), 'purpose': 'publication hardlinks, original outputs untouched; only recorded Chrome caches excluded', 'files': files, 'excluded': excluded}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(files), 'bytes': sum(f['bytes'] for f in files), 'excluded': len(excluded), 'staged': str(target)}))
