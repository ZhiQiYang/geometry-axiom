# P52 runtime 封存路徑更正

原凍結 `PUBLICATION_REQUEST.json` 把 launch／execution 兩個實際目錄誤套成 outer 的同層命名，根代理於 runtime 執行期間指出。原十檔準備包及審查均保留，不覆寫。

實際存在的路徑為：

- `launch=/workspace/geo288-main-merge-20261023/p52-final-runtime-launch`
- `execution=/workspace/geo288-main-merge-20261023/p52-final-runtime-execution`

`outer=/workspace/geo288-main-merge-20261023/p52-final-outers/p88-final-p52-runtime` 原值正確。`INPUT_PATHS.diff` 只列原 argv 的兩條路徑更正。新 JSON 另附原方法檔與本更正目錄作為出版 inputs，以保留錯誤與更正原件。

這是路徑與 argv 準備，沒有執行 stage、collector、publisher 或測試，也不宣稱 runtime 已終態。完整 argv 的 result／next 仍是明列待填欄位；根代理須取得真終態、實際 stage exit 0、全 streams 覆蓋等原先驗條件後才填入真結果並執行，不得以本檔當作自動串接工具。未改原 stage 四個 assertion、任何結果判決、任何封存排除或受驗 SHA。
