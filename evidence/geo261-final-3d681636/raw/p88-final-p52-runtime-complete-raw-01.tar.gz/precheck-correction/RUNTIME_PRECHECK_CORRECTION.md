# 封存前 checker 更正

第一版 checker 真退出碼為 2，六個 result-versus-list 整物件相等檢查失敗；全部 129 個原命令終態、258 份 stdout/stderr、26 份補充 log 與已記錄 hash 檢查均通過。原 driver 不是紅燈。

原 `tools/capture.py:37` 先寫 result.json 與 subcommands.json，接著 `tools/phase.py:45` 在原 row 補上 `effective_environment`；之後下一次 capture 寫列表時會包含該後補欄，原 result.json 則保留先前原件。因此每個 phase 最後一個 Node 之前的三份 row 均有這一項已知差異。

v2 僅將完全相等改成：result 必須逐欄完全等於去除唯一 `effective_environment` 欄後的 row；若有後補欄，row 必須完整等於同 phase receipt 中唯一對應 node_commands 原件，且 row 相較 result 的額外 key 恰為該欄。輸出另存新目錄，第一版程式、輸出及 exit 2 全保留。沒有修改任何 runtime 原件、產品、測試或其 gate。
