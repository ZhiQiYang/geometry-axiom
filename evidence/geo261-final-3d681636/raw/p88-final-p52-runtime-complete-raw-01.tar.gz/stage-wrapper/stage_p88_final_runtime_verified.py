"""Verify terminal original runtime records before invoking the frozen stager."""
from pathlib import Path
import hashlib
import json
import subprocess
B=Path('/workspace/geo288-main-merge-20261023')
F='3d681636902371ecc528b20f51eea33e272581c9'
source=Path('/tmp/g288prf')
load=lambda p:json.loads(p.read_text())
r=load(source/'receipt.json')
assert r['sha']==F and r['ended_utc'] and r['passed'] is True and r['errors']==[]
assert [x['receipt']['gate_exit'] for x in r['phases']]==[1,0]
outer=load(B/'p52-final-outers/p88-final-p52-runtime/receipt.json')
assert outer['sha']==F and outer['outer_process']['actual_process_returncode']==0 and outer['outer_process']['ended_epoch']
launch=load(B/'p52-final-runtime-launch/exit.json')
assert launch['sha']==F and launch['ended_utc'] and launch['actual_process_returncode']==0 and launch['launcher_exit_code']==0
execution=load(B/'p52-final-runtime-execution/receipt.json')
assert execution['sha']==F and execution['exit_code']==0 and execution['original_command_result']['ended_epoch']
rows=[]
for directory in [source,source/'withdrawn',source/'restored']:
 p=directory/'subcommands.json'
 data=load(p)
 assert isinstance(data,list) and data
 assert all(x.get('ended_epoch') is not None and x.get('actual_process_returncode') is not None and Path(x['directory']).is_dir() for x in data)
 rows.append({'path':str(p),'rows':len(data),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
stager=B/'p88-priority/runtime-final-packaging-preparation/stage_runtime_final.py'
assert hashlib.sha256(stager.read_bytes()).hexdigest()=='9ce8bcd86fd8fea4058f9ecb56fe89a284044cf311b75f4fe615a40df88a5e34'
out=B/'runtime-final-root-preflight'
out.mkdir(exist_ok=False)
(out/'CHECKS.json').write_text(json.dumps({'sha':F,'runtime_receipt_sha256':hashlib.sha256((source/'receipt.json').read_bytes()).hexdigest(),'ended_utc':r['ended_utc'],'terminal_recorders':rows,'outer_launch_execution_exits':[0,0,0],'stage_executed_at_this_record':False},ensure_ascii=False,indent=2)+'\n')
argv=['env','-u','NODE_OPTIONS','-u','PYTHONOPTIMIZE','python3','-B',str(stager)]
raise SystemExit(subprocess.run(argv,cwd=B).returncode)
