"""Read-only checks of closed original runtime records; never stages or publishes."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/workspace/geo288-main-merge-20261023')
RAW = Path('/tmp/g288prf')
F = '3d681636902371ecc528b20f51eea33e272581c9'
OUT = BASE / 'p88-priority/runtime-final-prechecks'
OUT.mkdir(exist_ok=False)
checks, files, errors = [], {}, []

def check(label, condition, detail=None):
    checks.append({'label': label, 'passed': bool(condition), 'detail': detail})
    if not condition:
        errors.append(label)

def file(path, kind, expected_hash=None, expected_bytes=None):
    path = Path(path)
    check(str(path) + ':regular-original', path.is_file() and not path.is_symlink())
    data = path.read_bytes()
    value = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'kinds': []}
    value = files.setdefault(str(path), value)
    if kind not in value['kinds']:
        value['kinds'].append(kind)
    if expected_hash is not None:
        check(str(path) + ':recorded-hash', value['sha256'] == expected_hash)
    if expected_bytes is not None:
        check(str(path) + ':recorded-bytes', value['bytes'] == expected_bytes)
    return data

def read(path):
    return json.loads(file(path, 'metadata'))

summary = {}
try:
    receipt = read(RAW / 'receipt.json')
    check('runtime-final-sha-and-terminal', receipt['sha'] == F and bool(receipt.get('ended_utc')))
    check('original-success-guards', receipt['passed'] is True and receipt['errors'] == [])
    check('original-phase-gates', [p['receipt']['gate_exit'] for p in receipt['phases']] == [1, 0])
    check('stage-target-fresh', not Path('/tmp/g288prf-publication-complete').exists())
    baseline = receipt['baseline']
    baseline_bytes = file(baseline['path'], 'external-formal-baseline', baseline['sha256'])
    check('baseline-exact-copy', file(RAW / 'formal-baseline-receipt.json', 'baseline-copy') == baseline_bytes)
    profiles = set()
    def profile_scan(value):
        if isinstance(value, dict):
            for k, v in value.items():
                if k == 'GEOMETRY_CHROME_PROFILE' and isinstance(v, str) and Path(v).is_relative_to(RAW):
                    profiles.add(Path(v))
                profile_scan(v)
        elif isinstance(value, list):
            for v in value:
                profile_scan(v)
    profile_scan(receipt)
    expected_profiles = {RAW / p / 'work/tmp' / ('chrome-' + str(i)) for p in ('withdrawn', 'restored') for i in range(4)}
    check('original-eight-profile-exclusions', profiles == expected_profiles)
    for label in ('source-before', 'source-after', 'restored-after'):
        matches = [g for g in receipt['guards'] if g['label'] == label]
        check('clean-guard:' + label, len(matches) == 1 and matches[0]['head'] == F and matches[0]['status'] == '')
    for path, digest in receipt['tool_snapshot_hashes'].items():
        file(path, 'tool-snapshot', digest)

    lists = [RAW / 'subcommands.json', RAW / 'withdrawn/subcommands.json', RAW / 'restored/subcommands.json', BASE / 'p52-final-outers/p88-final-p52-runtime/subcommands.json', BASE / 'p52-final-runtime-execution/subcommands.json']
    seen, counts, command_streams = set(), {}, set()
    for listing in lists:
        rows = read(listing)
        counts[str(listing)] = len(rows)
        for row in rows:
            d = Path(row['directory'])
            check(str(d) + ':unique', str(d) not in seen)
            seen.add(str(d))
            check(str(d) + ':terminal-F', isinstance(row.get('actual_process_returncode'), int) and row.get('ended_epoch') is not None and row.get('timeout_expired') is False and row['acceptance_sha'] == F)
            result = read(d / 'result.json')
            request = read(d / 'request.json')
            check(str(d) + ':result-original-row', result == row)
            check(str(d) + ':request-command-binding', all(request[k] == row[k] for k in ('command', 'cwd', 'acceptance_sha', 'source_sha', 'source_variant')))
            for stream in ('stdout', 'stderr'):
                p = d / (stream + '.bin')
                file(p, 'command-stream', row[stream + '_sha256'], row[stream + '_bytes'])
                command_streams.add(str(p))
            file(d / 'stdin.bin', 'command-stdin', row['stdin_sha256'])
            for p in d.glob('*timeout*'):
                if p.is_file():
                    file(p, 'timeout-partial')

    supplementary = set()
    for name in ('withdrawn', 'restored'):
        phase = read(RAW / name / 'receipt.json')
        check(name + ':complete-clean-F', phase['completed'] is True and phase['errors'] == [] and phase['sha'] == F)
        for record in phase['records']:
            p = Path(record['log'])
            file(p, 'probe-log')
            supplementary.add(str(p))
        for server in phase['servers']:
            check(server['log'] + ':server-terminal', isinstance(server.get('actual_process_returncode'), int) and server.get('ended_epoch') is not None and server['acceptance_sha'] == F)
            file(server['log'], 'server-log', server['log_sha256'], server['log_bytes'])
            supplementary.add(server['log'])
            p = server['environment']['GEO261_REAPER_LOG']
            file(p, 'server-reaper-log')
            supplementary.add(p)
        p = RAW / name / 'phase-reaper.jsonl'
        file(p, 'phase-reaper-log')
        supplementary.add(str(p))

    outer = read(BASE / 'p52-final-outers/p88-final-p52-runtime/receipt.json')
    check('outer-original-exit0', outer['sha'] == F and outer['outer_process']['actual_process_returncode'] == 0 and outer['outer_process'].get('ended_epoch') is not None)
    file(BASE / 'p52-final-outers/p88-final-p52-runtime/reaper.jsonl', 'outer-reaper-log')
    launch = read(BASE / 'p52-final-runtime-launch/exit.json')
    check('launch-original-exit0', launch['sha'] == F and launch['actual_process_returncode'] == 0 and launch['launcher_exit_code'] == 0 and bool(launch.get('ended_utc')) and launch['tools_unchanged'] is True)
    for stream in ('stdout', 'stderr'):
        file(BASE / 'p52-final-runtime-launch' / stream, 'launch-stream', launch[stream + '_sha256'])
    execution = read(BASE / 'p52-final-runtime-execution/receipt.json')
    check('execution-original-exit0', execution['sha'] == F and execution['exit_code'] == 0 and execution['original_command_result']['actual_process_returncode'] == 0)
    for path, record in files.items():
        p = Path(path)
        if p.is_relative_to(RAW):
            check(path + ':planned-stage-inclusion', not any(p == profile or p.is_relative_to(profile) for profile in profiles) and not any(part.startswith('com.google.Chrome.') for part in p.relative_to(RAW).parts))
    summary = {'recorder_rows': counts, 'terminal_unique_command_rows': len(seen), 'command_stdout_stderr_paths': len(command_streams), 'runtime_probe_server_reaper_logs': len(supplementary), 'all_original_bytes_read_and_hashed': True, 'hashed_unique_files': len(files), 'hashed_bytes': sum(v['bytes'] for v in files.values()), 'source_receipt_sha256': files[str(RAW / 'receipt.json')]['sha256'], 'phase_gates': [p['receipt']['gate_exit'] for p in receipt['phases']], 'phase_ratios': [p['receipt']['timing']['ratio'] for p in receipt['phases']]}
except Exception as exc:
    errors.append(type(exc).__name__ + ': ' + str(exc))
result = {'schema': 'geo288-runtime-prepublication-original-records/1', 'utc': datetime.now(timezone.utc).isoformat(), 'product_sha': F, 'passed': not errors, 'exit_code': 0 if not errors else 2, 'errors': errors, 'checks': checks, 'summary': summary, 'files': list(files.values()), 'scope': 'Read-only pre-stage original record, complete command stream and supplemental log checks. Stage, PACKAGING-to-original hardlink/inventory, archive coverage and public Git roundtrip have NOT run and remain required. Baseline commands remain in the separate formal package.', 'stage_executed': False, 'publication_executed': False}
(OUT / 'CHECKS.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'exit_code': result['exit_code'], 'errors': errors, 'checks': len(checks), 'summary': summary}, ensure_ascii=False))
sys.exit(result['exit_code'])
