# 新 F runtime 封存準備：沿用完整補包方法

受驗 F：`3d681636902371ecc528b20f51eea33e272581c9`。本文件只準備封存，不執行 runtime、stage、hash 全樹、gzip、Git 提交或 push。原 runtime 正在獨占執行時，只能讀這些小工具與 metadata。

原工具確實存在，沒有必要重新發明測試或更動裁判：`BASE/stage_runtime_publication.py`、`BASE/complete_runtime_publication.py`，通用 publisher 是 `/workspace/geo261-environment/publish_followup_progress.py`，其中 BASE=`/workspace/geo288-main-merge-20261023`。F13 正式完整補包是 `fbdde3de95f82b3c5d3b5bbe8754187512473899` 的 `postmerge-runtime-complete-raw`；首次 `c3fec08f` 遇 Chrome socket 的 staging exit 1 與後續錯誤出版不完整包仍為保留歷史，不能回頭稱首包完整。

準備包 `p88-priority/runtime-final-packaging-preparation/` 已保存原 stage、原修正 wrapper、原 publisher、原完整覆蓋審查與原 publication request。將原 wrapper 三個既有補正原樣展開後，新 stage 僅有兩行差異：source `/tmp/g288pr`→`/tmp/g288prf`，target `/tmp/g288pr-publication-complete`→`/tmp/g288prf-publication-complete`。精確差分為 `F13-to-final-path-bindings.diff`；原 passed/errors、phase exits `[1,0]`、八個明列 Chrome profiles、symlink／非一般檔及 `com.google.Chrome.*` 排除守門全未更動。原 wrapper 尾端描述 F13 首包事故的 STAGING_CORRECTION 文字保存在原 wrapper，不偽稱新 F 又發生同一事故。

凍結 PREPARATION SHA256：`dd98bde333e23d6f7c784772a3a1ff34b11c27087a2668bf08b3fd189cfb0602`。新 stage 僅 AST 解析 0，尚未執行。`PUBLICATION_REQUEST.json` 逐項列新 F、stage、三層 outer／launch／execution 路徑與 publisher argv；其中結果／下一步是明列占位，必須用實際終態填寫，不得直接當成可發布的綠燈文案。

## 執行順序與失敗保留

1. 等 runtime driver、外層 `p88-final-p52-runtime`、`-launch`、`-execution` 全部真正終態；核 source receipt 的 F 與 `ended_utc`，各 recorder 的結果完整，且正式 baseline receipt 雜湊與已公開同 F formal P52 原收據相同。不能只看到 `passed=true` 就在程序尚未退出時 hardlink 活檔。
2. 等主代理釋放 hash／封包窗口，才以原 recorder 錄製 `stage_runtime_final.py` 的完整 argv、環境、退出碼、stdout/stderr；使用全新 stage 目錄，不覆寫任何原件或舊失敗 stage。只有 stage 的**實際退出碼 0** 才能往下走。
3. 依下節逐路徑核對 PACKAGING 與全命令 streams；任何缺件都保原錯誤並停止「宣稱完整」的 publication，不刪原件、不改產品結果。禁止再次使用「staging 失敗但 shell 下一行仍執行 publisher」的流程。用明確 `subprocess.run(..., check=True)` 或主代理逐步判讀 exit，不能靠上一行印出的成功字樣。
4. 由主代理獨占整合分支寫入，使用原 publisher 和 `PUBLICATION_REQUEST.json` 的新 F／路徑綁定；輸入包含完整 stage、staging recorder、工具與計畫、三個原 outer recorder。分別保存原測試判決與封存／出版退出碼。
5. 出版後再次核 inventory／excluded／Git blob，依下節驗全 streams 真在 archive 內；先前 F13 數量是歷史值，不強迫新 F 碰巧相同。若 root 暫時要進下一項效能量測，推遲大檔 hash／解包，明列尚未完成的審查範圍。

這個原 stage 是**成功反證專用**，保留其原 `passed=true` 與 `[1,0]` 守門。若新 runtime 紅燈或只跑到一部分，不能移除守門讓工具「綠」；應照實收集所有紅結果與已關閉 streams，另用明列範圍的 failure archive。此準備包不是失敗封存替代工具，也不允許因 stage 拒絕而丟掉 raw 或停止其餘獲授權工作。

## 全命令 stream 覆蓋核對方法

原獨立覆蓋審查沒有找到另外存下的 Python checker；其完整結果與逐路徑 JSON 已保存在準備包的 `historical-RUNTIME_COMPLETE_STREAM_REVIEW.*`。新輪可按以下最小方法做同等核對，不需要重跑任何測試：

1. 讀新 raw 根目錄及 withdrawn／restored 各自的 `subcommands.json`。用 `directory` 去重，每筆必須已有 `ended_epoch`、真退出／exception 終態、`request.json`、`result.json` 與完整 `stdout.bin`／`stderr.bin`；stdin.bin（含空輸入）及 timeout-partial 檔如果存在也列入。`acceptance_sha` 必須為 F；`source_sha` 依 main／withdrawn／restored 原角色保留，不能硬改 main 成 F。
2. 每個 stdout/stderr 路徑必須落在原 source 內，其相對路徑在 `PACKAGING.json.files` 唯一存在；recorded bytes/hash、PACKAGING bytes/hash、原檔與 hardlink stage 的 device/inode/size 一致。可在封包窗口計算所有 stream 真 SHA256；若只核小檔，必須分欄列哪些較大 streams 僅依原 recorded hash＋manifest＋hardlink identity 核合，不冒稱全檔重算。
3. 對每個 phase receipt 的 `records[].log`、`servers[].log`、server 原環境 `GEO261_REAPER_LOG` 與 phase 的 `phase-reaper.jsonl` 作同樣覆蓋。遞迴核已記錄的 stdout/stderr/combined/log 路徑；不能只看主 recorder，漏掉兩個 phase recorder 或 server logs。F13 原例是主 95＋兩 phase 各14＝123命令、246 stdout/stderr，再加26 logs；新 F 依實際 metadata 重算，不拿 272 作硬編接受門檻。
4. 原根 receipt、兩 phase receipts、三份 subcommands metadata 與正式 baseline receipt 都逐 bytes 比 staging；PACKAGING 的 `original_receipt_sha256` 必須符。另讀 root 三個 outer recorder 的 subcommands／streams，用各自 input label 做同樣覆蓋，不把 runtime 根目錄封完就冒稱 launch／execution 也封完。
5. 出版後對每個 stage 相對路徑，加上 `runtime-complete/` label，要求它在 archive inventories 或 excluded list **恰好一處**。所有原命令 streams 與上述 logs 必須在 **archived members**，不得落入 cache exclusion；bytes/hash 與 PACKAGING／原 recorder 相符。其餘已列冊 cache 可以明列排除，但每一筆都要交代，不能漏記。
6. 最後逐件驗 archive 本體 hash、成員 regular/unique、安全路徑、bytes/hash 與公開 Git blob。published receipt 必須與原根 receipt 逐 bytes 相同。核對程式退出碼與產品 gate 分欄，工具問題不得冒作產品紅；第一次工具失敗與修正版差分都保留。

## 數量與證明範圍

F13 的 PACKAGING 是 **1633 筆逐 hash 列冊**，其中 **713 份 stage 原 bytes 真入 tar、920 份 cache 明列排除**；公開 archive 總數760另包含工具／外層 metadata，不能與713互換。stage 更早已排除八個 Chrome profiles／八個 `com.google.Chrome.*` 項目；不能把「1633」寫成「1633 份所有 runtime bytes 全封包」。原272 streams均真入包，所以 cache 排除不影響原輸出完整性。

新 F 正式 baseline 的原 commands/streams 已由獨立 formal P52 包保存。runtime 包的 `formal-baseline-receipt.json` 是精確引用，withdrawn／restored 才是本輪新測；不能把引用寫成又重跑正式五 controls，或宣稱本 runtime 包已包含 formal 包的所有原 bytes。原版本、SHA、計時值、原 gate exit、Node 真退出、例外與清理程序 exit 均照原 metadata 保留。
