"""Run three unchanged full canvas workflows on one explicitly supplied final SHA."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback

HERE = Path(__file__).resolve().parent
BOUND = HERE / 'run_canvas_workflow.py'
BOUND_HASH = '8a4e69c915ae770afc59829f3658639af0febbd2b16c20495f7ecee7f62685fb'
P88_HASH = '8106476b6eb2271111caa835a863b72eced4bab3b2ef77244f28534d83ca0a52'
OUTER = Path('/workspace/geo261-environment/execute_f_extra.py')
OUTER_HASH = '68256d90e597fe52807637e3603b7392dd09e9a5342909adc54d21fa4cba2928'
UNCHANGED_INPUTS = {
    '.github/workflows/integration-tests.yml':'b491142a6767e78588710f90bf0ea03b9b5af9ef6eb851cd9e28d32f0c262d6d',
    'geometry-web/cdp_sections.golden.json':'de99e9d0073b57e0b80856823cb4c49eb48c3c1629d57b7134bd3311197ad86f',
}

def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--sha', required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--run-prefix', type=Path, required=True)
    a = p.parse_args()
    repo, out, prefix = a.repo.resolve(), a.out.resolve(), a.run_prefix.resolve()
    need(re.fullmatch('[0-9a-f]{40}', a.sha) is not None, 'An explicit full final SHA is required')
    need(repo.is_dir() and not out.exists() and out.parent.is_dir(), 'Existing final checkout and fresh output required')
    need(prefix.parent == Path('/tmp') and re.fullmatch('[A-Za-z0-9_-]{1,30}', prefix.name), 'Short fresh /tmp run prefix required')
    need(not out.is_relative_to(repo) and not repo.is_relative_to(out), 'Output must be outside source')
    need(h(BOUND) == BOUND_HASH and h(OUTER) == OUTER_HASH, 'Reviewed workflow binding or recorder changed')
    need(h(repo / 'geometry-web/grid_rule_lines_test.js') == P88_HASH, 'Final P88 bytes differ from reviewed v5')
    for relative, expected in UNCHANGED_INPUTS.items():
        need(h(repo / relative)==expected, 'Original workflow limit or golden changed: '+relative)
    for index in (1, 2, 3):
        need(not Path(str(prefix) + str(index)).exists(), 'Every round must have fresh output/profile')
    out.mkdir()
    tool = out / 'run_canvas_workflow.py'
    tool.write_bytes(BOUND.read_bytes())
    (out / 'sequence-driver.py').write_bytes(Path(__file__).read_bytes())
    for name in ('BINDING.json','driver-binding.diff','original_run_workflow_round.py.txt'):
        (out / name).write_bytes((HERE / name).read_bytes())
    report = {'schema':'geo288-p88-final-three-full-canvas/1', 'sha':a.sha, 'source':str(repo),
        'started_utc':utc(), 'policy':'All three original full canvas rounds run serially with independent ports/tmp/profiles; every outcome retained. Original assertions/golden and 35-minute CI limit unchanged.',
        'publication_status':'This runner records source identity only; GitHub publication is separately verified by root.',
        'launcher_environment':{key:os.environ.get(key) for key in ('PATH','LANG','LC_ALL','NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONDONTWRITEBYTECODE')},
        'python_version':sys.version,'python_optimize_flag':sys.flags.optimize,'unchanged_workflow_and_golden':UNCHANGED_INPUTS,
        'tool_hashes':{str(BOUND):BOUND_HASH,str(OUTER):OUTER_HASH,str(Path(__file__).resolve()):h(Path(__file__).resolve())},
        'p88_source_sha256':P88_HASH, 'source_before':None, 'source_after':None,
        'runs':[], 'errors':[], 'all_three_completed':False, 'all_receipts_verified':False, 'all_three_accepted':False, 'driver_exit_code':None}
    def save():
        report['all_three_completed'] = len(report['runs'])==3 and all(row['process_completed'] for row in report['runs'])
        report['all_receipts_verified'] = len(report['runs'])==3 and all(row['completed'] for row in report['runs'])
        temporary = out / 'sequence-receipt.json.tmp'
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        temporary.replace(out / 'sequence-receipt.json')
    def guard(label):
        result = {}
        for name, command in [('head',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1','--untracked-files=all']),('index',['git','ls-files','--stage','-z'])]:
            process = subprocess.run(command,cwd=repo,capture_output=True)
            base = out / (label + '-' + name)
            base.with_suffix('.stdout').write_bytes(process.stdout)
            base.with_suffix('.stderr').write_bytes(process.stderr)
            base.with_suffix('.command.json').write_text(json.dumps({'command':command,'cwd':str(repo),'sha':a.sha,'actual_process_returncode':process.returncode},indent=2)+'\n')
            need(process.returncode == 0, 'Source identity command failed: ' + name)
            result[name] = h(base.with_suffix('.stdout')) if name=='index' else process.stdout.decode().strip()
        need(result['head']==a.sha and result['status']=='', 'Final checkout must stay clean at the exact supplied SHA')
        need(h(repo / 'geometry-web/grid_rule_lines_test.js')==P88_HASH, 'Final P88 bytes changed')
        for relative, expected in UNCHANGED_INPUTS.items():
            need(h(repo / relative)==expected, 'Original workflow limit or golden changed: '+relative)
        return result
    save()
    code = 2
    try:
        report['source_before'] = guard('before')
        for index in (1, 2, 3):
            scratch = Path(str(prefix) + str(index))
            label = 'p88-final-' + a.sha[:8] + '-canvas-' + str(index)
            command = ['env','-u','NODE_OPTIONS','-u','PYTHONOPTIMIZE','python3','-B',str(OUTER),
                '--label',label,'--sha',a.sha,'--repo',str(repo),'--outer-root',str(out/'outers'),'--',
                'flock','-n','/tmp/g261r3/heavy.lock','python3','-B',str(tool),
                '--repo',str(repo),'--sha',a.sha,'--job','canvas','--out-root',str(scratch/'workflow'),
                '--port',str(19890+index),'--cdp-port',str(9690+index)]
            row = {'index':index,'sha':a.sha,'command':command,'cwd':str(repo),
                'http_port':19890+index,'cdp_port':9690+index,'scratch':str(scratch),
                'environment_input':{key:os.environ.get(key) for key in ('PATH','LANG','LC_ALL','NODE_OPTIONS','PYTHONOPTIMIZE')},
                'environment_removals':['NODE_OPTIONS','PYTHONOPTIMIZE'],'started_utc':utc(),'process_completed':False,'completed':False,'accepted':False}
            report['runs'].append(row)
            save()
            try:
                need(not scratch.exists(), 'Round output ceased to be fresh')
                need(h(tool)==BOUND_HASH and h(OUTER)==OUTER_HASH, 'Runner or recorder changed during sequence')
                with (out / ('run-'+str(index)+'.stdout')).open('xb') as stdout, (out / ('run-'+str(index)+'.stderr')).open('xb') as stderr:
                    process = subprocess.run(command,cwd=repo,stdout=stdout,stderr=stderr)
                row['launcher_exit'] = process.returncode
                row['process_completed'] = True
                raw = scratch / 'workflow/canvas'
                workflow = json.loads((raw/'receipt.json').read_text())
                outer = json.loads((out/'outers'/label/'receipt.json').read_text())
                need(workflow['driver_sha256']==BOUND_HASH and workflow['workflow_sha256']==UNCHANGED_INPUTS['.github/workflows/integration-tests.yml']
                     and workflow['ci_timeout_minutes']==35, 'Workflow driver/input/CI identity mismatch')
                need(outer['sha']==a.sha and Path(outer['cwd']).resolve()==repo, 'Outer wrapper SHA/checkout mismatch')
                verified = {}
                for relative in ('steps/03.stdout','steps/03.stderr','steps/03.command.json'):
                    data = (raw/relative).read_bytes()
                    pin = workflow['files'][relative]
                    need(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Original stream/command differs from workflow file manifest: '+relative)
                    verified[relative] = data
                row['verified_original_files'] = {relative:workflow['files'][relative] for relative in verified}
                node = json.loads(verified['steps/03.command.json'])
                results = [json.loads(line[len('CDP_RESULT '):]) for line in verified['steps/03.stdout'].decode().splitlines() if line.startswith('CDP_RESULT ')]
                need(len(results)==1, 'Original unique CDP_RESULT missing')
                result = results[0]
                exits = [process.returncode,outer['outer_process']['actual_process_returncode'],workflow['exit_code'],node['actual_process_returncode']]
                row.update(outer_exit=exits[1],original_workflow_exit=exits[2],original_node_exit=exits[3],
                    over_ci_timeout=workflow['over_ci_timeout'],seconds=workflow['seconds'],cdp_result=result,
                    workflow_status=workflow['status'],
                    receipt=str(raw/'receipt.json'),receipt_sha256=h(raw/'receipt.json'),
                    stdout_sha256=h(raw/'steps/03.stdout'),stderr_sha256=h(raw/'steps/03.stderr'))
                need(workflow['sha']==a.sha and workflow['job']=='canvas', 'Workflow receipt source identity mismatch')
                for key in ('checkout_before','checkout_after'):
                    need(workflow[key]['head']==a.sha and workflow[key]['status']=='', 'Workflow checkout identity changed')
                row['completed'] = True
                row['accepted'] = (exits==[0,0,0,0] and workflow['status']=='完成' and not workflow['over_ci_timeout']
                    and not node['watchdog_expired'] and result['scope']['mode']=='full'
                    and result['scope']['filters']==[] and result['scope']['modifiers']==[]
                    and result['scope']['url']=='http://127.0.0.1:'+str(19890+index)+'/'
                    and result['scope']['cdpPort']==9690+index
                    and result['scope']['browserProfile']==str(scratch/'tmp/workflow/canvas/chrome-profile')
                    and result['completed'] is True and result['failedAssertions']==0
                    and result['goldenCompare']=='matched')
            except BaseException:
                row['error'] = traceback.format_exc()
                report['errors'].append('run '+str(index)+': '+row['error'])
            row['ended_utc'] = utc()
            save()
            print(json.dumps({'index':index,'sha':a.sha,'completed':row['completed'],'accepted':row['accepted'],
                'workflow_exit':row.get('original_workflow_exit'),'receipt':row.get('receipt'),'error':row.get('error')},ensure_ascii=False),flush=True)
        save()
        report['source_after'] = guard('after')
        need(report['source_before']['index']==report['source_after']['index'], 'Final staged entries changed')
        report['all_three_accepted'] = report['all_three_completed'] and report['all_receipts_verified'] and all(row['accepted'] for row in report['runs']) and not report['errors']
        code = 0 if report['all_three_accepted'] else 2
    except BaseException:
        report['errors'].append(traceback.format_exc())
    report.update(ended_utc=utc(),driver_exit_code=code)
    save()
    print(json.dumps({'sha':a.sha,'all_three_accepted':report['all_three_accepted'],'driver_exit_code':code,
        'receipt':str(out/'sequence-receipt.json')},ensure_ascii=False),flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
