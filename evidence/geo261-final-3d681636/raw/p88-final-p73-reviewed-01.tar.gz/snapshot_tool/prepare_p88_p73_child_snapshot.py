"""Snapshot immutable published child evidence without reading its mutable worktree."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import io
B=Path('/workspace/geo288-main-merge-20261023')
R=Path('/workspace/geo288-p73-owner-20261023/publication')
F='3d681636902371ecc528b20f51eea33e272581c9'
E='3f590c0882507965d953fdcc38e829f3ee52fa55'
prefix='evidence/geo261-final-3d681636/'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse',E+'^{commit}').decode().strip()==E
changed=git('diff','--name-only',F,E).decode().splitlines()
assert changed and all(n.startswith(prefix) for n in changed)
remote=git('ls-remote','--heads','origin','codex/geo288-p73-final-20261023').decode().split()[0]
subprocess.run(['git','merge-base','--is-ancestor',E,remote],cwd=R,check=True)
out=B/'p73-child-immutable-3f590c08';out.mkdir(exist_ok=False)
rows=git('ls-tree','-r','-z',E,'--',prefix).split(b'\0')
files=[]
for row in rows:
 if not row:continue
 header,name=row.split(b'\t',1);mode,kind,blob=header.decode().split();name=name.decode()
 assert mode=='100644' and kind=='blob' and name.startswith(prefix)
 data=git('cat-file','blob',blob)
 destination=out/'evidence'/name[len(prefix):]
 destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
 files.append({'git_path':name,'git_blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'SOURCE.json').write_text(json.dumps({'sha':F,'child_evidence_head':E,'observed_remote_head':remote,'all_changed_paths':changed,'files':files,'scope':'Immutable child Git blobs; no acceptance rerun and no source import'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'child_evidence_head':E,'files':len(files),'snapshot':str(out)}))
