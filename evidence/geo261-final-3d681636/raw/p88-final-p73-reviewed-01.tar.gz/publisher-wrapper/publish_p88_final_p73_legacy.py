"""Import independently reviewed immutable P73/legacy evidence into integration."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
B=Path('/workspace/geo288-main-merge-20261023')
F='3d681636902371ecc528b20f51eea33e272581c9'
O=Path('/workspace/geo288-p73-owner-20261023')
p=argparse.ArgumentParser();p.add_argument('gate',choices=['p73','legacy']);a=p.parse_args()
load=lambda p:json.loads(p.read_text())
inputs={'publisher-wrapper':Path(__file__)}
if a.gate=='p73':
 receipt=Path('/tmp/gp7-3d681636/receipt.json')
 expected='9fee99803279168c071257133f68d20fef11befe3a8d057d194bbabb367c670f'
 label='p88-final-p73-reviewed'
 result='新F P73 controlled原fixed/withdrawn/restored退出0/1/0，driver/outer/top皆0；callback前predicate都true，撤回僅app唯一guard回到舊.hidden，恰一次真產品callback後原具名P73 assertion紅、exception0，放回綠。731完整runtime輸入同F；獨立原件與公開封包審查通過；範圍僅受控callback反證，不冒完整P73 workflow。'
 inputs.update(child_public_snapshot=B/'p73-child-immutable-3f590c08',snapshot_record=B/'p73-child-snapshot-record',snapshot_tool=B/'prepare_p88_p73_child_snapshot.py',independent_peer=Path('/workspace/geo318-p73-legacy-peer-20261023'),original_p73_publication=O/'publication-p73-controlled-final-3d681636',original_legacy_publication=O/'publication-chromium154-p73-final-3d681636')
else:
 receipt=Path('/tmp/gl7-3d681636/p73-proof/c154-fixed/receipt.json')
 expected='17114e471ddfd48187f08bb6aca1737f83e0f3f30ed28a5a7823f1f2fa04f8d4'
 label='p88-final-chromium154-reviewed'
 result='新F Chromium154原fixed P73 69項partial真0，proof_expectation_matches=true，driver/outer/top皆0；84.124749832秒在原35分鐘內，exception/network/transport0，only GEOMETRY_UIUX_FIX_ONLY，原golden未比較。僅此fixed相容性子集，不冒154撤回反證/fullcanvas/舊產品曾綠。完整原命令streams在同F之前p88-final-p73-reviewed封包的immutable child E3f590c08內，這項另提供原receipt可直接連結。'
 publication=load(B/'p88-final-p73-root-publication/receipt.json')
 assert publication['exit_code']==0
 reference=B/'p73-legacy-public-source-reference.json'
 rawhead=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/geometry-axiom').decode().strip()
 reference.write_text(json.dumps({'product_sha':F,'root_evidence_head_containing_complete_child_raw':rawhead,'child_evidence_head':'3f590c0882507965d953fdcc38e829f3ee52fa55','complete_child_raw_label':'p88-final-p73-reviewed','original_legacy_receipt_sha256':expected,'scope':'Reference to already published complete original Chromium154 streams; this small archive does not independently repeat the full raw'},ensure_ascii=False,indent=2)+'\n')
 inputs.update(complete_raw_reference=reference,original_receipt=receipt,independent_legacy_peer=Path('/workspace/geo318-p73-legacy-peer-20261023/legacy-actual'))
assert hashlib.sha256(receipt.read_bytes()).hexdigest()==expected
assert load(receipt)['sha']==F
for n,path in inputs.items():assert path.exists(),str(path)
command=['python3','-B','/workspace/geo261-environment/publish_followup_progress.py','--repo','/workspace/geometry-axiom','--branch','architecture/geo261-integration-20261016','--issue','261','--sha',F,'--label',label,'--result',result,'--next','完成同F oracle8phase與公開封包審查，更新唯一current-state正文；#323在自己分支繼續。','--receipt',str(receipt)]
for n,path in inputs.items():command+=['--input',n+'='+str(path)]
raise SystemExit(subprocess.run(command,cwd='/workspace/geometry-axiom').returncode)
