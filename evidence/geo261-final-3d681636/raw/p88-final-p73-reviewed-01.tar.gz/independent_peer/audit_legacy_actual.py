"""Read-only audit of the terminal Chromium154 P73 supplemental receipts."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
import yaml
F='3d681636902371ecc528b20f51eea33e272581c9'
BASE=Path('/workspace/geo318-p73-legacy-peer-20261023')
OUT=BASE/'legacy-actual';OUT.mkdir(mode=0o700,exist_ok=False)
P=Path('/tmp/gl7-3d681636/p73-proof/c154-fixed')
OP=Path('/workspace/geo288-main-merge-20261023/p73-final-outers/chromium154-p73-final-3d681636')
TP=Path('/workspace/geo288-p73-owner-20261023/launch-chromium154-p73-final-3d681636')
GD=Path('/workspace/geo318-reading-a-prep/meta.git')
checks=[];files={};cmds=[]
def h(raw):return hashlib.sha256(raw).hexdigest()
def record(path):
 path=Path(path);raw=path.read_bytes();files[str(path)]={'bytes':len(raw),'sha256':h(raw)};return raw
def j(path):return json.loads(record(path))
def need(value,label):
 checks.append({'check':label,'passed':bool(value)})
 if not value:raise AssertionError(label)
def git(args):
 argv=['git','--git-dir='+str(GD)]+args;t=time.monotonic();p=subprocess.run(argv,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 row={'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-t,'environment':{'GIT_OPTIONAL_LOCKS':'0'}}
 for name,raw in (('stdout',p.stdout),('stderr',p.stderr)):
  path=OUT/('%02d.%s.bin'%(len(cmds)+1,name));path.write_bytes(raw);row[name]={'path':str(path),'bytes':len(raw),'sha256':h(raw)}
 cmds.append(row);need(p.returncode==0,'metadata Git exit0 '+str(len(cmds)));return p.stdout
def capture(row):
 for name in ('stdout','stderr','combined'):record(row[name])
 command_path=Path(row['stdout']).with_suffix('.command.json')
 need(j(command_path)==row,'capture original command row '+str(command_path))
 need(row['actual_process_returncode']==row['exit_code']==0 and not row['watchdog_expired'],'original actual child exit0 and no watchdog '+str(command_path))
def outercapture(row):
 d=Path(row['directory']);need(j(d/'result.json')==row,'outer original result agrees '+str(d));record(d/'request.json')
 for name in ('stdin','stdout','stderr'):
  raw=record(d/(name+'.bin'));need(h(raw)==row[name+'_sha256'],'outer '+name+' hash '+str(d))
  if name!='stdin':need(len(raw)==row[name+'_bytes'],'outer '+name+' bytes '+str(d))
 need(row['actual_process_returncode']==0 and not row['timeout_expired'] and row['source_sha']==row['acceptance_sha']==F,'outer metadata child true exit0/F/no timeout '+str(d))

result={'scope':'Chromium154 supplemental original P73 69-assertion subset, not full canvas or golden comparison','tested_sha':F,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'files':files,'metadata_commands':cmds,'accepted':False}
try:
 r=j(P/'receipt.json');outer=j(OP/'receipt.json');top=j(TP/'request.json')
 need(r['sha']==outer['sha']==top['sha']==F and r['actual_exit_code']==r['expected_exit_code']==0 and r['proof_expectation_matches'] is True,'terminal supplemental raw exit0 and pinned F')
 need(top['actual_process_returncode']==0 and top['completed'] is True and top['top_recorder_python_optimize']==0 and outer['outer_process']['actual_process_returncode']==0,'top/outer actual exit0 and assertions enabled')
 need(top['command'][:7]==['env','-u','NODE_OPTIONS','-u','PYTHONOPTIMIZE','-u','GEO261_P73_UNDER_REAPER'],'actual env-u launch')
 for name in ('stdout','stderr'):
  row=top[name];raw=record(row['path']);need(h(raw)==row['sha256'] and len(raw)==row['bytes'],'top raw '+name)
 need(h(record(TP/'BINDING.json'))==top['binding_sha256'] and h(record(TP/'launcher.py.txt'))==top['recorder_sha256'],'frozen binding and launcher bytes')
 for row in outer['subcommands']:outercapture(row)
 for path,digest in outer['tool_hashes'].items():need(h(record(path))==digest,'outer tool frozen '+path)
 for rel,row in r['files'].items():
  need(not Path(rel).is_absolute() and '..' not in Path(rel).parts,'inventory path is relative '+rel)
  raw=record(P/rel);need(h(raw)==row['sha256'] and len(raw)==row['bytes'],'original artifact inventory hash/bytes '+rel)
 for name,field in (('driver.py.txt','driver_sha256'),('capture-driver.py.txt','capture_driver_sha256'),('reaper.py.txt','reaper_driver_sha256'),('runtime-inventory.py.txt','runtime_inventory_driver_sha256')):
  need(h(record(P/name))==r[field],'frozen driver original '+name)
 need(r['source_before']==r['source_after'] and r['source_before']['head']==F and r['source_before']['status']=='','source complete identity before/after equal and clean F')
 src=r['source_before'];pi=j(Path('/tmp/gp7-3d681636/source-runtime-inputs.json'))
 inv=src['runtime_complete_inputs'];need(inv==pi,'supplemental full runtime input inventory exactly same F as controlled source')
 need(inv['source_set_complete'] is True and inv['actual_count']==inv['expected_count']==731,'731 complete source inputs')
 p73=j(BASE/'p73-actual/CHECKS.json');need(p73['accepted'] is True,'independent controlled source audit accepted')
 for rel,digest in json.loads(Path('/tmp/gp7-3d681636/receipt.json').read_text())['original_inputs'].items():
  if rel in src['tests_sha256']:need(src['tests_sha256'][rel]==digest,'shared protected judge hash agrees '+rel)
 need(src['app_js_sha256']=='e248c162d4f0da633a0fd3314402af96e0f9c1a05d3224d90f7e5ffcabace7f1','served app raw F hash')
 workflow=git(['show',F+':.github/workflows/integration-tests.yml'])
 need(record(P/'workflow.yml.txt')==workflow and h(workflow)==r['workflow_sha256'],'original workflow exactly immutable F')
 spec=yaml.safe_load(workflow)['jobs']['browser'];matrix=next(x for x in spec['strategy']['matrix']['include'] if x['suite']=='canvas')
 sub=lambda text:re.sub(r'\$\{\{\s*matrix\.(\w+)\s*\}\}',lambda m:str(matrix[m[1]]),str(text))
 tmp=r['temporary_directory'];port=r['ports']['service']
 rewrite=lambda text:re.sub(r'(?<!\d)18839(?!\d)',str(port),re.sub(r'(?<![\w/.\-])/tmp/',tmp+'/',text))
 need(r['workflow_environment']=={k:sub(v) for k,v in spec['env'].items()},'original workflow matrix environment exact')
 need(len(r['steps'])==len(spec['steps']),'all workflow steps explicitly represented')
 for row,original in zip(r['steps'],spec['steps']):
  need(row['original_step']==original,'original workflow step '+str(row['index']))
  if 'run' in original:
   i=row['index'];raw=record(P/'steps'/('%02d.executed.sh'%i));original_text=record(P/'steps'/('%02d.original.sh.txt'%i))
   need(original_text.decode()==original['run'] and row['original_run']==original['run'],'original step bytes '+str(i))
   need(row['executed_run']==rewrite(sub(original['run'])) and raw.decode()==row['executed_run'].rstrip('\n')+'\n' and h(raw)==row['script_sha256'],'only tmp/port/matrix mechanical rewrite '+str(i))
   if 'result' in row:capture(row['result'])
   else:
    need('fonts-noto-cjk' in original['run'] and row['outcome']=='字型已安裝；未重複執行原 apt 指令','package skip is explicit installed-font substitution')
    capture(row['check']);need(record(row['check']['stdout']).startswith(b'install ok installed '),'actual font install status')
  else:need('未執行 GitHub' in row['outcome'],'checkout/artifact action explicitly local substitution '+str(row['index']))
 for row in r['versions']:capture(row)
 versions=[record(row['stdout']).decode().strip() for row in r['versions']]
 need(versions[0].startswith('Chromium 154.') and versions[1].startswith('v24.') and versions[4].startswith('install ok installed '),'actual Chromium154/Node24/font raw versions')
 need(r['ci_timeout_minutes']==int(sub(spec['timeout-minutes']))==35 and r['seconds']<35*60 and r['over_ci_timeout'] is False,'actual complete 84-second run within original 35-minute limit, not watchdog allowance')
 browser=next(row for row in r['steps'] if row['index']==3)
 logs=record(browser['result']['stdout']).decode().splitlines()
 results=[json.loads(x[len('CDP_RESULT '):]) for x in logs if x.startswith('CDP_RESULT ')]
 need(results==r['cdp_results'] and len(results)==1,'exact one terminal CDP_RESULT in original stdout')
 cdp=results[0];scope=cdp['scope'];golden=git(['show',F+':geometry-web/cdp_sections.golden.json'])
 need(h(golden)==src['tests_sha256']['geometry-web/cdp_sections.golden.json'],'original golden F raw hash')
 need(cdp['completed'] is True and cdp['passedAssertions']==69 and cdp['failedAssertions']==0 and cdp['sections']=={'P73':json.loads(golden)['sections']['P73']} and cdp['sections']['P73']==69,'original P73 69/0 and exact F section count')
 need(scope['mode']=='partial' and scope['filters']==['GEOMETRY_UIUX_FIX_ONLY'] and scope['modifiers']==[] and cdp['goldenCompare']=='not compared (partial mode)','explicit original subset and no full-golden claim')
 need(cdp['uncaughtBrowserExceptions']==0 and cdp['firstNetworkFailure'] is None and cdp['firstTransportFailure'] is None and cdp['skipped']==[],'no exception/transport/network failure or hidden skip')
 need(r['environment']['GITHUB_SHA']==F and r['environment']['GEOMETRY_CHROME']=='/usr/bin/chromium' and r['environment']['GEOMETRY_UIUX_FIX_ONLY']=='1','actual environment exact browser/subset/F')
 need(scope['url']==r['environment']['GEOMETRY_TEST_URL'] and str(scope['cdpPort'])==r['environment']['GEOMETRY_CDP_PORT'] and scope['browserProfile']==r['environment']['GEOMETRY_CHROME_PROFILE'],'actual CDP runtime URL/port/profile match launch')
 need(len(top['reaper_files_sealed_after_command_terminal'])==2,'two final-sealed original reapers')
 child_events=None
 for row in top['reaper_files_sealed_after_command_terminal']:
  raw=record(row['path']);events=[json.loads(x) for x in raw.splitlines()]
  need(h(raw)==row['sha256'] and len(raw)==row['bytes'] and events[-1]==row['last_event'] and events[-1]['event']=='完成' and events[-1]['primary_returncode']==0,'sealed reaper original bytes/exit0 '+row['path'])
  need(events[0]['event']=='啟用子程序回收' and events[0]['pr_get_child_subreaper']==1,'real subreaper enabled '+row['path'])
  if row['path']==r['reaper_events']:child_events=events
 need(child_events is not None and any(x.get('event')=='回收' and x.get('pid')==scope['browserPid'] for x in child_events),'actual browser pid reaped')
 result.update(accepted=True,seconds=r['seconds'],ci_timeout_minutes=r['ci_timeout_minutes'],versions=versions,source_test_hash_count=len(src['tests_sha256']),runtime_count=731,artifacts=len(r['files']),assertions={'passed':69,'failed':0,'scope':scope},public_git_roundtrip='pending owner publication')
except BaseException as exc:result['failure']={'type':type(exc).__name__,'text':str(exc)}
finally:
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'accepted':result['accepted'],'output':str(OUT/'CHECKS.json'),'failure':result.get('failure'),'checks':len(checks),'files':len(files)},ensure_ascii=False))
if not result['accepted']:raise SystemExit(1)
