"""Audit immutable, independently fetched evidence tarballs without extracting them."""
from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,tarfile,time
F='3d681636902371ecc528b20f51eea33e272581c9'
E1='2e1764132e0b5448fa3e013887a26f77ec343e2a'
E2='3f590c0882507965d953fdcc38e829f3ee52fa55'
GD='/workspace/geo318-reading-a-prep/meta.git'
BASE=Path('/workspace/geo318-p73-legacy-peer-20261023')
OUT=BASE/'public-git-r2';OUT.mkdir(mode=0o700,exist_ok=False)
PREFIX='evidence/geo261-final-3d681636/'
cmds=[];checks=[];blobfiles={};packages={}
def h(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,label):
 checks.append({'check':label,'passed':bool(ok)})
 if not ok:raise AssertionError(label)
def git(args,expected=0):
 argv=['git','--git-dir='+GD]+args;t=time.monotonic();p=subprocess.run(argv,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 row={'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-t,'environment':{'GIT_OPTIONAL_LOCKS':'0'}}
 for name,raw in (('stdout',p.stdout),('stderr',p.stderr)):
  path=OUT/('%03d.%s.bin'%(len(cmds)+1,name));path.write_bytes(raw);row[name]={'path':str(path),'bytes':len(raw),'sha256':h(raw)}
 cmds.append(row);need(p.returncode==expected,'public metadata command exit '+str(len(cmds)));return p.stdout
def blob(commit,rel):return git(['show',commit+':'+PREFIX+rel])
def audit_package(label,actual_dir,actual_receipt,outer_dir,top_dir,actual_checks):
 inventory=json.loads(blobfiles['raw/'+label+'-01.tar.gz.inventory.json'])
 raw=blobfiles['raw/'+label+'-01.tar.gz']
 need(h(raw)==inventory['sha256'] and len(raw)==inventory['bytes'],'public compressed archive identity '+label)
 wanted=inventory['members'];need(len({x['path'] for x in wanted})==len(wanted),'inventory paths unique '+label)
 observed={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as handle:
  members=handle.getmembers();need(len(members)==len(wanted),'exact tar member count '+label)
  for member,row in zip(members,wanted):
   need(member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts,'safe regular member '+member.name)
   value=handle.extractfile(member).read()
   need(member.name==row['path'] and len(value)==row['bytes'] and h(value)==row['sha256'],'all public member bytes/hash '+member.name)
   observed[member.name]={'bytes':len(value),'sha256':h(value)}
 need(blobfiles['receipts/'+label+'.json']==actual_receipt.read_bytes(),'top-level public receipt exactly original '+label)
 roots=[(str(actual_dir)+'/', 'proof/'),(str(outer_dir)+'/', 'outer/'),(str(top_dir)+'/', 'launch/'),('/workspace/geo288-main-merge-20261023/bound-3d681636/','binding/')]
 audited=json.loads(actual_checks.read_text());need(audited['accepted'] is True,'independent actual audit accepted '+label)
 coverage=[]
 for path,row in audited['files'].items():
  target=None
  for start,prefix in roots:
   if path.startswith(start):target=prefix+path[len(start):];break
  if target:
   need(target in observed and observed[target]==row,'every directly audited original file preserved in public archive '+target)
   coverage.append({'original':path,'public_member':target,**row})
 need(observed['proof/'+actual_receipt.relative_to(actual_dir).as_posix()]=={'bytes':len(actual_receipt.read_bytes()),'sha256':h(actual_receipt.read_bytes())},'archived inner receipt exactly original '+label)
 excluded=json.loads(blobfiles['raw/'+label+'-excluded.json'])
 need(not any(x['path'] in observed for x in excluded),'excluded items not falsely listed as archived '+label)
 for row in excluded:
  if row['reason'].startswith('可重建 ELF'):
   need('sha256' in row and row['bytes']>0,'rebuildable ELF exclusions retain original hash '+row['path'])
 packages[label]={'archive_bytes':len(raw),'expanded_bytes':sum(x['bytes'] for x in wanted),'members':len(wanted),'coverage':coverage,'excluded_count':len(excluded),'all_member_hashes_verified':True}

r={'scope':'independent ordinary remote fetch plus immutable Git archive roundtrip; no activity worktree reads, no test rerun','tested_sha':F,'p73_evidence_sha':E1,'both_evidence_sha':E2,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metadata_commands':cmds,'checks':checks,'packages':packages,'accepted':False}
try:
 fetch=json.loads((BASE/'public-git/FETCH.json').read_text());need(fetch['exit_code']==0,'independent ordinary remote fetch exit0')
 head=git(['rev-parse','refs/remotes/origin/codex/geo288-p73-final-20261023']).decode().strip()
 git(['merge-base','--is-ancestor',E2,head]);git(['merge-base','--is-ancestor',E1,E2]);git(['merge-base','--is-ancestor',F,E1])
 need(all(p.startswith(PREFIX) for p in git(['diff','--name-only',F,E2]).decode().splitlines()),'published evidence descendants change only exact evidence prefix')
 tree=git(['ls-tree','-r','-z',E2,'--',PREFIX]);paths=[]
 for line in tree.split(b'\0'):
  if line:
   meta,path=line.split(b'\t',1);need(meta.split()[1]==b'blob','published entries are blobs');paths.append(path.decode()[len(PREFIX):])
 need(len(paths)==11,'exact immutable 11-blob evidence snapshot')
 for rel in paths:blobfiles[rel]=blob(E2,rel)
 need(json.loads(blobfiles['PROGRESS.json'])['tested_sha']==F,'public progress tested SHA pinned')
 progress=json.loads(blobfiles['PROGRESS.json'])
 need([x['label'] for x in progress['entries']]==['p73-controlled-final-3d681636','chromium154-p73-final-3d681636'],'public progress exact two true scopes')
 checksum_rows=blobfiles['SHA256SUMS'].decode().splitlines()
 for line in checksum_rows:
  digest,rel=line.split('  ',1);need(rel in blobfiles and h(blobfiles[rel])==digest,'all published SHA256SUMS '+rel)
 need(len(checksum_rows)==len(paths)-1,'SHA256SUMS covers all other ten immutable blobs')
 for rel in paths:
  if rel.startswith(('raw/p73-controlled-','receipts/p73-controlled-')):
   need(blob(E1,rel)==blobfiles[rel],'P73 first evidence E2e preserved byte-for-byte in E3f '+rel)
 audit_package('p73-controlled-final-3d681636',Path('/tmp/gp7-3d681636'),Path('/tmp/gp7-3d681636/receipt.json'),Path('/workspace/geo288-main-merge-20261023/p73-final-outers/p73-controlled-final-3d681636'),Path('/workspace/geo288-p73-owner-20261023/launch-p73-controlled-final-3d681636'),BASE/'p73-actual/CHECKS.json')
 audit_package('chromium154-p73-final-3d681636',Path('/tmp/gl7-3d681636'),Path('/tmp/gl7-3d681636/p73-proof/c154-fixed/receipt.json'),Path('/workspace/geo288-main-merge-20261023/p73-final-outers/chromium154-p73-final-3d681636'),Path('/workspace/geo288-p73-owner-20261023/launch-chromium154-p73-final-3d681636'),BASE/'legacy-actual/CHECKS.json')
 r.update(accepted=True,fetched_remote_head=head,git_blob_count=len(paths),compressed_archive_bytes=sum(p['archive_bytes'] for p in packages.values()),original_coverage_files=sum(len(p['coverage']) for p in packages.values()),safe_no_extract=True)
except BaseException as exc:r['failure']={'type':type(exc).__name__,'text':str(exc)}
finally:
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'CHECKS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'accepted':r['accepted'],'failure':r.get('failure'),'checks':len(checks),'packages':{k:{n:v for n,v in row.items() if n!='coverage'} for k,row in packages.items()},'output':str(OUT/'CHECKS.json')},ensure_ascii=False))
if not r['accepted']:raise SystemExit(1)
