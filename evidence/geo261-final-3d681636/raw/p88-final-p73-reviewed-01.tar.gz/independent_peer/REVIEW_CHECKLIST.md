# P73／Chromium154 獨立審查準備

固定來源 F `3d681636902371ecc528b20f51eea33e272581c9`。此檔只是讀已凍結工具後的審查清單，不代表任何正式結果已通過；沒有讀 owner 執行中 scratch、import driver 或跑 case。綁定檔列出的 p73／legacy 八份小工具 SHA 全部獨立核合，數值在 STATIC_PREP.json。

P73 controlled callback 與 Chromium154 正式 P73 子集的 scope 必須分欄：前者是真 app、原具名 predicate、一次明確 production sync callback 的因果反證，不能稱完整 workflow；後者按同 F workflow 的 canvas 步驟跑 FIX_ONLY 原 P73 子集，也不能稱完整 canvas 或完整 golden。Chrome156 完整 canvas 另由 root 的正式收據支持。

待 actual 收據到齊後逐項核對：

1. launch 的 argv／環境／F／工具 bytes／真 wrapper exit，R3 排程與獨立埠、暫存目錄、Chrome profile；Chrome156 與 Chromium154、Node24 的原版本 stdout。
2. 每個 request/result 對上的 stdin／stdout／stderr 完整 bytes 與 hash；原程序退出不能由 expected_exit 或 proof boolean 替代。timeout、infra exit2、未啟動、reaper 缺終態均不能當負控制成功。
3. controlled fixed／withdrawn／restored 真 0/1/0；只把 app.js 的 attribute guard 撤成原 SVG .hidden 一處，F 與原裁判 bytes 保持；三階段前後及來源末尾完整 runtime 輸入 hash、clean 狀態一致。撤回後的單一 app 差分必須可驗。
4. 三階段 before 原 predicate 必為 true；真 callback invocation=1；uncaughtBrowserExceptions=0、callbackSourceUnchanged；withdrawn 只能由原 P73 具名斷言失敗，且 hasNoShape=false、memberCount=0、empty/action 仍在，不能是 infra 或其他 assertion。
5. Node 與 server reaper 原 events 最後為完成；Node primary_returncode 對應原0/1/0；server 有真清理退出／原 streams，沒有 cleanup_timeout、殘存程序或遺失末尾。
6. Chromium154 的 workflow 原文件 hash、matrix／環境機械替換、套件已裝的真檢查與略過 actions 理由；每 phase 原 step exit、完整 CDP_RESULT。正例 completed／failedAssertions0／P73 count 等於同 F golden，負例原 exit1／精確 fatal／僅P73一錯；partial filters 明確是 FIX_ONLY。
7. Chromium154 每 phase 與整體時間必須讀實際 seconds、CI timeout 與 over_ci_timeout，不能因 driver 允許3倍 watchdog 就冒稱正式時限內；before／after source、test／golden bytes 和完整 runtime inventory 要一致。
8. owner 宣告總表要和實際 exit／scope 一致；受驗 product F、evidence head、inherited／本輪、仍紅或未跑分清楚。工具原 guard 不代表 actual 已滿足，所有條件均待終態證據。

收據若揭露產品／裁判缺陷，保紅並回 owner／root，不改其工具、不放寬 gate。此準備沒有新增產品或測試變更，也不是 #318 動態驗收。
