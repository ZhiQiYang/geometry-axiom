# P73／Chromium154 公開 Git roundtrip 對抗審查

接受 immutable 公開 evidence **E1 `2e1764132e0b5448fa3e013887a26f77ec343e2a`** 的 P73，與其後 **E2 `3f590c0882507965d953fdcc38e829f3ee52fa55`** 聯集；未見可確立阻擋。受驗產品仍固定 **F `3d681636902371ecc528b20f51eea33e272581c9`**，不是在 evidence commit 重測產品。

本代理從 GitHub 普通 fetch 到自有 bare metadata repo exit0；F→E1→E2 ancestry核合，E2相對F的變更完全限於指定 `evidence/geo261-final-3d681636/`。全程只讀明確 immutable Git objects，沒有讀活動 publication 工作樹。11個公開 blobs、SHA256SUMS對其餘10檔、兩個 top-level receipt與原件bytes相同；E1的P73 raw／receipt在E2逐位元組保留。

2783項 metadata檢查成立。兩個 gzip封包真讀回，未解壓寫入：P73 **5,509,309 bytes／831個regular成員**，154 **2,336,559 bytes／141個regular成員**。每個成員 path/type/bytes/SHA256逐項對其公開inventory，無絕對路徑、`..`、重名或special member。兩包內已審的 inner／outer／top 原 receipt、每份 request/result、完整 stdin/stdout/stderr、phase server／browser／reaper、原diff及bound工具，逐一由原實跑檔案 hash對公共member，沒有只核表格或只保摘要。實際 coverage筆數在 CHECKS.json。

P73三個可重建ELF排除時仍保原bytes/SHA256；154的331個排除僅明列Chrome profile暫存，不會拿它們代替原命令輸出。更早staging跨掛載EXDEV環境失敗保歷史原件，沒有把它當產品紅燈或重寫兩份產品結果。本peer第一版工具誤把154巢狀收據當 `proof/receipt.json` 而KeyError退出1；原CHECKS與工具完整保在 ../public-git/ 及 ../audit_public_git.attempt1.py.txt，r2只修正metadata查找為原巢狀路徑後真0，沒有重測產品／重封producer包。

兩項actual獨立審查另見 ../p73-actual/REVIEW.md 和 ../legacy-actual/REVIEW.md：Chrome156 controlled真Node0/1/0與具名P73原因成立；Chromium154固定版原69條partial子集真0/69/0、84.1秒內完成。scope不能外推完整P73／canvas／fullgolden或154撤回恢復；也不代表 #288 全清單與P88已結案。

已靜讀 owner 的PR_BODY草稿（本目錄保存reviewed完整bytes）：唯一兩row矩陣、F／E分欄、最新ee28481審查、controlled／154 partial限制、環境skip／時限與最不確定界線均正確，未見誇大。owner後續只需把publicpeer pending改接受、填本報告hash及最後metadata evidence head，不能把metadata head當受驗F。正文與peer最終commit／-prbody仍由owner正常push，主代理可另收immutable E2原11blob快照，無需重複產品測試。

審查沒有import／執行產品或driver、compiler/browser/benchmark、修改SSOT／決策／帳本／integration。Git與tar工具的完整argv、exit、原streams、hash及逐項檢查均在 CHECKS.json／兄弟FETCH.json。接受只限列明 immutable bytes與scope。
