"""Independent read-only P73 receipt audit. Never imports or runs a test driver."""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, sys, time

F='3d681636902371ecc528b20f51eea33e272581c9'
BASE=Path('/workspace/geo318-p73-legacy-peer-20261023')
OUT=BASE/'p73-actual'
OUT.mkdir(mode=0o700,exist_ok=False)
P=Path('/tmp/gp7-3d681636')
OP=Path('/workspace/geo288-main-merge-20261023/p73-final-outers/p73-controlled-final-3d681636')
TP=Path('/workspace/geo288-p73-owner-20261023/launch-p73-controlled-final-3d681636')
GD=Path('/workspace/geo318-reading-a-prep/meta.git')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
checks=[];files={};cmds=[]
def h(raw):return hashlib.sha256(raw).hexdigest()
def record(path):
 path=Path(path);raw=path.read_bytes();files[str(path)]={'bytes':len(raw),'sha256':h(raw)};return raw
def j(path):return json.loads(record(path))
def need(value,label):
 checks.append({'check':label,'passed':bool(value)})
 if not value:raise AssertionError(label)
def cmd(args):
 i=len(cmds)+1;t=time.monotonic();p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 row={'argv':args,'exit_code':p.returncode,'seconds':time.monotonic()-t,'environment':{'GIT_OPTIONAL_LOCKS':'0'}}
 for label,raw in (('stdout',p.stdout),('stderr',p.stderr)):
  path=OUT/('%02d.%s.bin'%(i,label));path.write_bytes(raw);row[label]={'path':str(path),'bytes':len(raw),'sha256':h(raw)}
 cmds.append(row);need(p.returncode==0,'metadata Git command %d exit0'%i);return p.stdout
def source(rel):return cmd(['git','--git-dir='+str(GD),'show',F+':'+rel])
def verify_capture(row):
 d=Path(row['directory'])
 need(j(d/'result.json')==row,'recorded result agrees '+str(d))
 req=j(d/'request.json')
 need(all(req[k]==row[k] for k in req if k not in ('actual_process_returncode','ended_epoch','stdout_sha256','stderr_sha256','stdout_bytes','stderr_bytes')),'request static fields agree '+str(d))
 for field,name in (('stdin','stdin.bin'),('stdout','stdout.bin'),('stderr','stderr.bin')):
  raw=record(d/name)
  need(h(raw)==row[field+'_sha256'],'raw '+field+' hash '+str(d))
  if field!='stdin':need(len(raw)==row[field+'_bytes'],'raw '+field+' length '+str(d))
 need(row['source_sha']==F and row['acceptance_sha']==F and not row['timeout_expired'],'capture pinned F and no timeout '+str(d))
 return record(d/'stdout.bin'),record(d/'stderr.bin')

result={'scope':'P73 controlled callback receipt/stream audit only; not full workflow and no case rerun','tested_sha':F,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'files':files,'metadata_commands':cmds,'accepted':False}
try:
 r=j(P/'receipt.json');outer=j(OP/'receipt.json');top=j(TP/'request.json')
 need(r['sha']==F and r['passed'] is True and r['errors']==[] and 'ended_utc' in r,'terminal P73 receipt true/errors empty/pinned F')
 need(top['sha']==outer['sha']==F and top['actual_process_returncode']==0 and top['completed'] is True,'top and outer pinned/terminal top0')
 need(top['command'][:7]==['env','-u','NODE_OPTIONS','-u','PYTHONOPTIMIZE','-u','GEO261_P73_UNDER_REAPER'],'actual env-u argv')
 need(top['top_recorder_python_optimize']==0 and r['stack_during'][0]==16777216,'assertions enabled and 16MiB stack')
 for label in ('stdout','stderr'):
  row=top[label];raw=record(row['path']);need(h(raw)==row['sha256'] and len(raw)==row['bytes'],'top '+label+' raw')
 need(h(record(TP/'BINDING.json'))==top['binding_sha256'],'top frozen binding hash')
 need(h(record(TP/'launcher.py.txt'))==top['recorder_sha256'],'top recorder frozen bytes')
 for path,digest in r['tool_hashes'].items():
  need(h(record(path))==digest,'P73 frozen tool '+path)
  need(h(record(P/'tools'/Path(path).name))==digest,'P73 saved tool copy '+Path(path).name)
 for path,digest in outer['tool_hashes'].items():need(h(record(path))==digest,'outer tool '+path)
 inner_rows=j(P/'subcommands.json')
 all_rows=inner_rows+outer['subcommands']
 streams={}
 for row in all_rows:streams[row['directory']]=verify_capture(row)
 need(outer['outer_process']['actual_process_returncode']==0 and outer['outer_process'] in outer['subcommands'],'outer original driver exit0')
 bootstrap_result=json.loads(streams[outer['outer_process']['directory']][0])
 need(bootstrap_result['passed'] is True and bootstrap_result['errors']==[],'original driver stdout agrees with receipt')
 original={rel:source(rel) for rel in r['original_inputs']}
 need({rel:h(raw) for rel,raw in original.items()}==r['original_inputs'],'seven protected raw input hashes independently agree immutable F')
 app=original['geometry-web/app.js']
 fixed=("  const svg=$('spacePlanSvg');\n"+'  // SVG 沒有 HTML 元素的 hidden 反射屬性；與 renderSpacePlan 共用 attribute 狀態。\n'+"  if(!svg||svg.hasAttribute('hidden'))return;\n"+'  const matrix=svg.getScreenCTM();if(!matrix)return;\n').encode()
 old=b"  const svg=$('spacePlanSvg'),matrix=svg?.getScreenCTM();if(!svg||svg.hidden||!matrix)return;\n"
 need(app.count(fixed)==1 and app.count(old)==0,'precise production guard is unique at F')
 mutant=app.replace(fixed,old,1)
 mutant_sha=h(mutant)
 oid=lambda raw:hashlib.sha1(('blob %d\0'%len(raw)).encode()+raw).hexdigest()
 patch=record(P/'withdrawn-before.patch')
 need(record(P/'withdrawn-after.patch')==patch and ('index '+oid(app)+'..'+oid(mutant)+' 100644').encode() in patch,'withdrawal before/after patches agree full old/new Git blob IDs')
 expected_diff_lines=['-'+x for x in fixed.decode().splitlines()]+['+'+x for x in old.decode().splitlines()]
 actual_diff_lines=[line for line in patch.decode().splitlines() if line.startswith(('+','-')) and not line.startswith(('+++','---'))]
 need(actual_diff_lines==expected_diff_lines and patch.count(b'diff --git ')==1,'withdrawal changes only the approved guard bytes, no tests')
 for g in r['guards']:
  withdrawn=g['label'].startswith('withdrawn-');expected=dict(r['original_inputs'])
  if withdrawn:expected['geometry-web/app.js']=mutant_sha
  need(g['head']==F and g['inputs']==expected and g['status']==(' M geometry-web/app.js\n' if withdrawn else ''),'guard immutable source/tests '+g['label'])
  raw=record(P/(g['label']+'.patch'))
  need(h(raw)==g['diff_sha256'] and (raw==patch if withdrawn else raw==b''),'guard exact diff '+g['label'])
 line=[x for x in original['geometry-web/uiux_review_test.js'].decode().splitlines() if "check('空空間不畫假邊界，提供加入成員入口',await read(`" in x]
 need(len(line)==1,'immutable F original assertion unique')
 parsed=re.fullmatch(r"\s*check\('([^']+)',await read\(`([^`]+)`\)\);\s*",line[0])
 need(parsed is not None,'immutable original predicate parsed, no alternate predicate')
 runtime=[j(P/name) for name in ('source-runtime-inputs.json','clone-runtime-inputs.json','source-after-runtime-inputs.json')]
 canon=lambda inv:{k:v for k,v in inv.items() if k!='root'}
 need(all(canon(x)==canon(runtime[0]) for x in runtime),'all three complete runtime inventories exactly equal except root')
 inv=runtime[0];paths=[row['path'] for row in inv['inputs']]
 need(inv['source_sha']==F and inv['source_set_complete'] is True and inv['expected_count']==inv['actual_count']==len(paths)==len(set(paths)),'runtime input membership count/uniqueness')
 tree_raw=cmd(['git','--git-dir='+str(GD),'ls-tree','-r','-z',F,'--']+paths)
 tree={}
 for row in tree_raw.split(b'\0'):
  if row:
   head,path=row.split(b'\t',1);mode,kind,oid_=head.decode().split();tree[path.decode()]={'mode':mode,'blob_oid':oid_,'kind':kind}
 need(set(tree)==set(paths) and all(tree[row['path']]['kind']=='blob' and tree[row['path']]['mode']==row['mode'] and tree[row['path']]['blob_oid']==row['blob_oid'] for row in inv['inputs']),'all 731 recorded input blob IDs/modes independently match immutable F tree')
 versions={}
 for row in inner_rows:
  if '--version' in row['command']:
   need(row['actual_process_returncode']==0,'version command exit0')
   versions[row['command'][0]]=streams[row['directory']][0].decode().strip()
 need(any(x.startswith('Google Chrome 156.') for x in versions.values()) and versions.get('node','').startswith('v24.'),'actual Chrome156 and Node24 raw versions')
 phases=[];ports=[];profiles=[]
 for phase,expected in zip(r['phases'],(0,1,0)):
  name=phase['phase'];p=P/name;a=j(p/'result.json');ext=j(p/'extracted-assertion.json')
  need(a==phase['probe_result'] and a['sha']==F and a['variant']==name,'phase actual result matches driver '+name)
  need(a['assertion_line']==line[0] and a['predicate']==parsed.group(2) and a['message']==parsed.group(1),'original immutable F assertion/predicate '+name)
  need(a['test_sha256']==r['original_inputs']['geometry-web/uiux_review_test.js'] and a['cdp_test_sha256']==r['original_inputs']['geometry-web/cdp_test.js'],'original judge hashes '+name)
  need(a['app_sha256']==(mutant_sha if expected else h(app)),'actual served app hash '+name)
  callback=re.search(r'function syncSpacePlanAnnotations\(\)\{.*?\n\}',(mutant if expected else app).decode(),re.S).group()
  need(a['before']['callbackSource']==a['after']['callbackSource']==callback,'actual callback exactly original variant bytes '+name)
  need(a['callbackInvocations']==1 and a['callbackSourceUnchanged'] is True and a['uncaughtBrowserExceptions']==0 and a['completed'] is True,'one callback, no injected source or exception '+name)
  before=a['before'];after=a['after']
  need(before['originalPredicate'] is True and before['hasNoShape'] is True and before['hiddenAttribute'] is True and before['hiddenPropertyType']=='undefined' and before['ctm'] is not None,'real Chrome156 SVG causal preconditions '+name)
  need(a['predicateValue'] is (expected==0) and after['originalPredicate'] is (expected==0) and after['hasNoShape'] is (expected==0),'exact original predicate outcome '+name)
  need(after['hiddenAttribute'] is True and after['memberCount']=='0' and after['hasEmpty'] and after['emptyHasAction'],'empty-space UI remains, false shape is isolated cause '+name)
  if expected:need(a['assertionError']=='P73 assertion failed: '+parsed.group(1)+' false','withdrawal is precise named assertion, no infra')
  cr=phase['command_result'];need(cr['actual_process_returncode']==a['actualProbeExit']==expected,'real node exit '+name)
  logs=streams[cr['directory']][0].decode().splitlines();actual_rows=[json.loads(x[len('P73_CONTROLLED_RESULT '):]) for x in logs if x.startswith('P73_CONTROLLED_RESULT ')]
  need(actual_rows==[a],'full original stdout contains exact one terminal P73 result '+name)
  need(not any(x.startswith('P73_CONTROLLED_INFRA ') for x in logs),'no infra hidden in original stdout '+name)
  reapers={}
  for kind in ('node','server'):
   events=[json.loads(x) for x in record(p/(kind+'-reaper.jsonl')).splitlines()]
   need(events[0]['event']=='啟用子程序回收' and events[0]['pr_get_child_subreaper']==1 and events[-1]['event']=='完成','subreaper genuinely started and terminal '+name+'/'+kind)
   exp=expected if kind=='node' else -15
   need(events[-1]['primary_returncode']==exp and len([x for x in events if x.get('event')=='回收' and x.get('primary') is True and x.get('returncode')==exp])==1,'reaper true primary exit '+name+'/'+kind)
   reapers[kind]=events
  need(any(x.get('pid')==a['chrome']['pid'] and x.get('event')=='回收' for x in reapers['node']),'actual Chrome pid reaped '+name)
  server=j(p/'server-result.json');request=j(p/'server-request.json')
  need(server['actual_process_returncode']==143 and not server.get('cleanup_timeout') and all(server[k]==request[k] for k in request),'server deliberate SIGTERM cleanup, no timeout '+name)
  for fname,data in server['streams'].items():
   raw=record(p/fname);need(h(raw)==data['sha256'] and len(raw)==data['bytes'],'server original stream '+name+'/'+fname)
  record(p/'generated-probe.cjs');record(p/'after-callback.png')
  ports += [phase['environment']['GEOMETRY_TEST_URL'],phase['environment']['GEOMETRY_CDP_PORT']]
  profiles.append(phase['environment']['GEOMETRY_CHROME_PROFILE'])
  phases.append({'phase':name,'actual_exit':expected,'before_predicate':before['originalPredicate'],'after_predicate':after['originalPredicate'],'hidden_attribute':before['hiddenAttribute'],'hidden_property_type':before['hiddenPropertyType'],'callback_count':a['callbackInvocations'],'exceptions':a['uncaughtBrowserExceptions'],'server_wrapper_exit':server['actual_process_returncode']})
 need([x['phase'] for x in phases]==['fixed','withdrawn','restored'] and len(ports)==len(set(ports)) and len(set(profiles))==3,'exact 3 phases and isolated ports/profiles')
 for row in top['reaper_files_sealed_after_command_terminal']:
  raw=record(row['path']);events=[json.loads(x) for x in raw.splitlines()]
  need(h(raw)==row['sha256'] and len(raw)==row['bytes'] and events[-1]==row['last_event'] and events[-1]['event']=='完成','terminal-sealed reaper hash '+row['path'])
 need(len(top['reaper_files_sealed_after_command_terminal'])==7,'all seven terminal reaper files sealed')
 readiness=[row for row in inner_rows if '--probe' in row['command']]
 for port in ('19960','19961','19962'):
  proberows=[row for row in readiness if row['command'][-1]==port]
  need(proberows and proberows[-1]['actual_process_returncode']==0,'readiness eventually succeeded '+port)
 for row in inner_rows:
  if row['actual_process_returncode']!=0:
   need(row['actual_process_returncode']==1 and ('--probe' in row['command'] or row==r['phases'][1]['command_result']),'nonzero raw commands classified, no hidden product failure')
 result.update(accepted=True,phases=phases,versions=versions,runtime_count=len(paths),inner_subcommands=len(inner_rows),outer_subcommands=len(outer['subcommands']),hashed_original_stream_bytes=sum(row.get('stdout_bytes',0)+row.get('stderr_bytes',0) for row in all_rows),readiness_exit1_count=sum(x['actual_process_returncode']==1 for x in readiness),public_git_roundtrip='pending owner publication',limit='No new test/browser/build, no 731-file checkout rehash; verified recorded inventory equality and each blob/mode against immutable Git tree, plus seven raw source blobs.')
except BaseException as exc:
 result['failure']={'type':type(exc).__name__,'text':str(exc)}
finally:
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'accepted':result['accepted'],'output':str(OUT/'CHECKS.json'),'failure':result.get('failure'),'checks':len(checks),'files':len(files)},ensure_ascii=False))
if not result['accepted']:raise SystemExit(1)
