# P73 controlled callback 獨立對抗審查

接受這份已終態的 controlled callback 反證，沒有發現可確立的收據阻擋。固定產品 F 為 `3d681636902371ecc528b20f51eea33e272581c9`；原 driver、outer、最外 env-u launcher 都是真 exit 0，三個 Node phase 的原退出為 **0／1／0**，沒有把預期紅改寫為綠。正式終態時間是 2026-10-23T13:49:43Z。

獨立小型 metadata 驗證共 1178 項成立，原 inner118＋outer5 指令的 stdin/stdout/stderr、request/result 全核 hash／bytes，另核最外原 streams；來源七個受保護 blob 的 raw hash 直接對不可變 F。三份 runtime 清單除 root 路徑外逐欄相同，731 個 input 的 blob ID／mode 逐一對 F 的 Git tree（沒有再大樹重 hash checkout）。原工具與保存副本 hash 一致、Python assertions 開、16MiB stack、Chrome **156.0.8078.47**、Node **24.19.0** 原版本 stdout 均核合。

撤回 patch 的 old/new 完整 Git blob ID 及逐行差分證明只把 app.js 的唯一 attribute guard 還原為原 SVG `.hidden` 判定，未改測試。三個 phase 執行 callback 前原 predicate 都為 true；`hidden` attribute=true、`.hidden` type=`undefined`，且 getScreenCTM 存在。撤回後一次實際 `syncSpacePlanAnnotations()` 使 SVG 新增格線，`hasNoShape` 由 true 變 false，原具名「空空間不畫假邊界，提供加入成員入口」斷言真 exit1；memberCount仍0、empty／加入成員入口仍在，uncaughtBrowserExceptions=0。恢復後原 predicate 為 true、真 exit0。實際 callback source 逐字等於對應 F／撤回 variant，沒有注入改寫 callback。

七份 reaper 在最外命令真終態後的 hash／bytes／最後完成事件均核合；三個 Chrome PID 皆有回收事件。server 主程序因正常清理 SIGTERM 為 -15、wrapper為143，這是明列的服務清理，不是測試退出碼。54個 readiness exit1 都是服務編譯啟動前探測，三個埠最後皆 probe0；唯一其他非零是具名 P73 撤回 exit1，沒有藏 infra2 或 timeout。

限制：這是真 app＋原 predicate＋一次明確 production callback 的因果反證，**不是完整 P73 workflow／完整 canvas**。Chrome156 的完整 canvas 另由 root 的正式三輪收據支持；Chromium154 的原69條子集另審。本報告沒有重跑任何 case／browser／build，未變更任何 source／index／integration。Git 公開包 roundtrip 尚待 owner 出版後續核，不由本地收據冒稱已公開。

原收據：`/tmp/gp7-3d681636/receipt.json`；outer：`/workspace/geo288-main-merge-20261023/p73-final-outers/p73-controlled-final-3d681636/receipt.json`；top：`/workspace/geo288-p73-owner-20261023/launch-p73-controlled-final-3d681636/request.json`。所有檢查、明確檔案 hash、metadata Git argv／原 streams 在 CHECKS.json 與本目錄。實際審查工具 ../audit_p73_actual.py 是純讀取，不 import 產品或測試 driver。
