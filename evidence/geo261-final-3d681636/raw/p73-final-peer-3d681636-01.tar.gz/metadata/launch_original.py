"""Record complete outer argv/environment, then invoke unchanged original proof CLI."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

F = '3d681636902371ecc528b20f51eea33e272581c9'
OWNER = Path('/workspace/geo288-p73-owner-20261023')
REPO = OWNER / 'source-3d681636'
BOUND = Path('/workspace/geo288-main-merge-20261023/bound-3d681636')
OUTER_ROOT = Path('/workspace/geo288-main-merge-20261023/p73-final-outers')
EXTRA = Path('/workspace/geo261-environment/execute_f_extra.py')
digest = lambda raw: hashlib.sha256(raw).hexdigest()

if len(sys.argv) != 2 or sys.argv[1] not in ['p73', 'legacy'] or sys.flags.optimize:
    raise RuntimeError('Expected p73 or legacy without Python optimize')
kind = sys.argv[1]
label = ('p73-controlled-final-' if kind == 'p73' else 'chromium154-p73-final-') + F[:8]
out = OWNER / ('launch-' + label)
out.mkdir(exist_ok=False)
bindings_raw = (BOUND / 'BINDING.json').read_bytes()
bindings = json.loads(bindings_raw)
if bindings['sha'] != F or digest(EXTRA.read_bytes()) != '68256d90e597fe52807637e3603b7392dd09e9a5342909adc54d21fa4cba2928':
    raise RuntimeError('Original binding/outer driver differs')
for row in bindings['files']:
    raw = (BOUND / row['path']).read_bytes()
    if len(raw) != row['bytes'] or digest(raw) != row['sha256']:
        raise RuntimeError('Frozen binding bytes changed: ' + row['path'])
(out / 'BINDING.json').write_bytes(bindings_raw)
(out / 'launcher.py.txt').write_bytes(Path(__file__).read_bytes())
prefix = ['env', '-u', 'NODE_OPTIONS', '-u', 'PYTHONOPTIMIZE', '-u', 'GEO261_P73_UNDER_REAPER', 'python3', '-B', str(EXTRA), '--label', label, '--sha', F, '--repo', str(REPO), '--outer-root', str(OUTER_ROOT), '--']
if kind == 'p73':
    proof = ['python3', '-B', str(BOUND / 'p73/run.py'), '--repo', str(REPO), '--sha', F, '--scratch', '/tmp/gp7-' + F[:8], '--heavy-lock', '/tmp/g261r3/heavy.lock', '--clone-dir', str(OWNER / ('probe-source-' + F[:8])), '--service-port', '19960', '--cdp-port', '9600']
else:
    proof = ['flock', '-n', '/tmp/g261r3/heavy.lock', 'python3', '-B', str(BOUND / 'legacy/run_p73_subset_chromium154.py'), '--repo', str(REPO), '--sha', F, '--scratch', '/tmp/gl7-' + F[:8], '--label', 'c154-fixed', '--port', '19964', '--cdp-port', '9604', '--expected-exit', '0']
command = prefix + proof
names = ['PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'NODE_OPTIONS', 'PYTHONOPTIMIZE', 'GEO261_P73_UNDER_REAPER', 'PYTHONPATH', 'PYTHONSTARTUP', 'LD_PRELOAD', 'TMPDIR', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'C_INCLUDE_PATH', 'CPATH', 'LIBRARY_PATH', 'LD_LIBRARY_PATH', 'GCC_EXEC_PREFIX', 'COMPILER_PATH']
names += sorted(k for k in os.environ if k.startswith('GEOMETRY_'))
environment = {name: os.environ.get(name) for name in dict.fromkeys(names)}
post = dict(environment)
for key in ['NODE_OPTIONS', 'PYTHONOPTIMIZE', 'GEO261_P73_UNDER_REAPER']:
    post[key] = None
request = {'schema': 'geo288-p73-complete-top-launch/1', 'sha': F, 'kind': kind, 'label': label, 'command': command, 'cwd': str(REPO), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'environment_observed_in_top_recorder': environment, 'actual_env_u_removals': ['NODE_OPTIONS', 'PYTHONOPTIMIZE', 'GEO261_P73_UNDER_REAPER'], 'environment_after_exact_env_u_command': post, 'top_recorder_python': sys.version, 'top_recorder_python_optimize': sys.flags.optimize, 'stack_before_outer': resource.getrlimit(resource.RLIMIT_STACK), 'original_execute_sets_stack_bytes': 16384 * 1024, 'binding_sha256': digest(bindings_raw), 'frozen_binding_files_verified': len(bindings['files']), 'outer_driver_sha256': digest(EXTRA.read_bytes()), 'recorder_sha256': digest(Path(__file__).read_bytes()), 'actual_process_returncode': None, 'completed': False, 'reaper_files_sealed_after_command_terminal': []}


def save():
    (out / 'request.json').write_text(json.dumps(request, ensure_ascii=False, indent=2) + '\n')


save()
with (out / 'stdout.bin').open('xb') as stdout, (out / 'stderr.bin').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=REPO, stdout=stdout, stderr=stderr)
    request['pid'] = process.pid
    save()
    code = process.wait()
request['actual_process_returncode'] = code
request['completed'] = True
request['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
for stream in ['stdout', 'stderr']:
    raw = (out / (stream + '.bin')).read_bytes()
    request[stream] = {'path': str(out / (stream + '.bin')), 'bytes': len(raw), 'sha256': digest(raw)}
scratch = Path('/tmp/gp7-' + F[:8]) if kind == 'p73' else Path('/tmp/gl7-' + F[:8])
reaper_paths = list(scratch.rglob('*reaper*.jsonl')) if scratch.exists() else []
reaper_paths += list((OUTER_ROOT / label).glob('reaper.jsonl'))
for path in sorted(set(reaper_paths)):
    raw = path.read_bytes()
    events = [json.loads(line) for line in raw.splitlines()]
    request['reaper_files_sealed_after_command_terminal'].append({'path': str(path), 'bytes': len(raw), 'sha256': digest(raw), 'last_event': events[-1] if events else None})
save()
print(json.dumps({'kind': kind, 'label': label, 'exit': code, 'request': str(out / 'request.json'), 'outer': str(OUTER_ROOT / label), 'reaper_files': len(reaper_paths)}, ensure_ascii=False), flush=True)
raise SystemExit(code)
