"""Stage immutable original outputs and normally publish one terminal item."""
import datetime
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

F = '3d681636902371ecc528b20f51eea33e272581c9'
OWNER = Path('/workspace/geo288-p73-owner-20261023')
BOUND = Path('/workspace/geo288-main-merge-20261023/bound-3d681636')
OUTER = Path('/workspace/geo288-main-merge-20261023/p73-final-outers')
PUB = OWNER / 'publication'
BRANCH = 'codex/geo288-p73-final-20261023'
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def retain_file(source, destination):
    try:
        os.link(source, destination)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        shutil.copy2(source, destination)
    if digest(source.read_bytes()) != digest(destination.read_bytes()):
        raise RuntimeError('Cross-filesystem raw staging changed bytes')

if len(sys.argv) != 2 or sys.argv[1] not in ['p73', 'legacy']:
    raise RuntimeError('Expected p73 or legacy')
kind = sys.argv[1]
label = ('p73-controlled-final-' if kind == 'p73' else 'chromium154-p73-final-') + F[:8]
stage = OWNER / ('stage-' + label)
record = OWNER / ('publication-' + label)
stage.mkdir(exist_ok=False)
record.mkdir(exist_ok=False)
inputs = {}
if kind == 'p73':
    proof = Path('/tmp/gp7-' + F[:8])
    excluded = []
    def link_tree(source, dest):
        dest.mkdir(parents=True, exist_ok=True)
        for path in source.iterdir():
            if path.is_symlink():
                raise RuntimeError('Unexpected symlink in immutable raw output')
            if path.is_dir():
                link_tree(path, dest / path.name)
            elif path.is_file():
                retain_file(path, dest / path.name)
    rawstage = stage / 'proof'
    rawstage.mkdir()
    for path in proof.iterdir():
        if path.name == 'tmp':
            for tmp_child in path.iterdir():
                if tmp_child.name == 'native-runtime':
                    link_tree(tmp_child, rawstage / 'tmp' / tmp_child.name)
                elif tmp_child.is_dir() and (tmp_child / 'feedback').is_dir():
                    link_tree(tmp_child / 'feedback', rawstage / 'tmp' / tmp_child.name / 'feedback')
                    excluded.append({'path': str(tmp_child / 'chrome'), 'reason': 'Reconstructible dedicated browser profile; never an original command stream'})
                else:
                    excluded.append({'path': str(tmp_child), 'reason': 'Reconstructible dedicated temporary cache; original commands/streams retained outside tmp'})
        elif path.is_dir():
            link_tree(path, rawstage / path.name)
        elif path.is_file():
            retain_file(path, rawstage / path.name)
    (stage / 'STAGING_EXCLUSIONS.json').write_text(json.dumps(excluded, ensure_ascii=False, indent=2) + '\n')
    receipt = proof / 'receipt.json'
    x = json.loads(receipt.read_bytes())
    if x.get('ended_utc') is None or not x['passed'] or x['errors']:
        raise RuntimeError('P73 original acceptance did not pass; preserve separately before publication')
    phases = x['phases']
    if [p['command_result']['actual_process_returncode'] for p in phases] != [0, 1, 0]:
        raise RuntimeError('P73 original exits differ')
    result = 'P73 controlled 真終態原0/1/0；fixed/withdrawn/restored 原predicate=true/false/true，原具名P73斷言反證，before皆true/唯一callback/額外例外0，731個完整runtime輸入同一F；僅受控callback反證，不冒完整canvas。'
    inputs['proof'] = rawstage
    inputs['staging'] = stage / 'STAGING_EXCLUSIONS.json'
else:
    proof = Path('/tmp/gl7-' + F[:8])
    receipt = proof / 'p73-proof/c154-fixed/receipt.json'
    x = json.loads(receipt.read_bytes())
    if x.get('ended') is None or x['actual_exit_code'] != 0 or not x['proof_expectation_matches'] or x['source_before'] != x['source_after']:
        raise RuntimeError('Legacy original acceptance did not pass; preserve separately before publication')
    result = 'Chromium154固定F原P73完整子集真終態0，proof_expectation_matches=true；69/0/partial僅GEOMETRY_UIUX_FIX_ONLY，golden不比較、例外0、84.125s小於原35分鐘；不冒Chrome156完整canvas或舊產品曾綠。'
    inputs['proof'] = proof
inputs.update(outer=OUTER / label, launch=OWNER / ('launch-' + label), binding=BOUND)
if kind == 'p73':
    inputs.update(source_preparation=OWNER / 'source-preparation', publication_preparation=OWNER / 'publication-preparation', preparer=OWNER / 'prepare_source.py')
    inputs['publication_staging_attempt1'] = OWNER / 'publication-staging-attempt1'
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
if digest(helper.read_bytes()) != 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':
    raise RuntimeError('Original capture changed')
spec = importlib.util.spec_from_file_location('geo288_p73_pub_capture', helper)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
env.pop('PYTHONOPTIMIZE', None)
r = cap.Recorder(record, env, F)
command = ['python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py', '--repo', str(PUB), '--branch', BRANCH, '--issue', '261', '--sha', F, '--label', label, '--result', result, '--next', '兩項原件與公開封包交318獨立對抗審；只交root整合證據，不合併PR、不重產帳本', '--receipt', str(receipt)]
for key, path in inputs.items():
    command += ['--input', key + '=' + str(path)]
request = {'schema': 'geo288-p73-item-publication/1', 'sha': F, 'label': label, 'branch': BRANCH, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'original_receipt_sha256': digest(receipt.read_bytes()), 'command': command, 'commands': r.rows, 'publisher_script_sha256': digest(Path('/workspace/geo261-environment/publish_followup_progress.py').read_bytes()), 'exit_code': None}
try:
    row, stdout, stderr = r.run(command, cwd=PUB, timeout=600, check=False, source_sha=F, source_variant='p73-evidence-only-publication')
    request['exit_code'] = row['actual_process_returncode']
    if request['exit_code']:
        raise RuntimeError('Original normal evidence publication failed')
    request['head_after'] = r.run(['git', 'rev-parse', 'HEAD'], cwd=PUB, timeout=30)[1].decode().strip()
    request['remote_after'] = r.run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + BRANCH], cwd=PUB, timeout=60)[1].decode().split()[0]
    if request['remote_after'] != request['head_after']:
        raise RuntimeError('Normal push remote identity mismatch')
finally:
    request['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (record / 'receipt.json').write_text(json.dumps(request, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in request.items() if k not in ['commands', 'command']}, ensure_ascii=False), flush=True)
