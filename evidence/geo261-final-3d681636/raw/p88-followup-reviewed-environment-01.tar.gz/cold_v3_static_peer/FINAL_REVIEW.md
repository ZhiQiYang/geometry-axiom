# cold v3 最終窄差分對抗審

結論：精確 PACKAGE `33dc5440b4753244720b059248e6457778b9a446e3198659c0da4348c40e3b05`／common `ab191bec08c2d52fdd56af87bfb2c0d1baae763874a11c2f1743be58c45cbb79` 靜態審查未見可確立阻擋，可由 root 在指定窗口執行。工具執行前仍核此 hash，接受不等於工具實跑或空間已回收。

已逐一核 PACKAGE 小檔 bytes/hash 及 Python AST；固定 wrappers、五 raw guard input 與 v2 全同。identity、no_nontracked_nodes、no_consumers、raw_receipts 與 Recorder 的 save/event/git 全 AST 相同，因此原 ignored/nontracked/empty dir/special/type、own gitdir/common-dir、HEAD/tree/stage、Popen 原始串流、中斷與末次 raw pending 保全都保留。v2 原 PACKAGE/common 亦精確未變，原實跑警告／負空間差不被覆寫。

唯一新增變動是全部前置條件通過後明確 `update-index --refresh`；它開始前即標 metadata attempted，非零/中斷進失敗後五 raw＋identity 保全，不能因 sparse 尚未 attempted 漏查。refresh 後必核原 stage bytes／HEAD/tree 及完整 clean，才 `sparse-checkout reapply` 既有精確 `/AGENTS.md` patterns；沒有 force/reset/clean/rm/gc/repack。原 R3 非阻塞鎖跨全程，readonly proc 的不可讀邊界與非原子 TOCTOU 仍保留。

成功新增硬裁判：逐筆原 index 路徑 lstat，除了 regular AGENTS 外所有 tracked 節點必須真不存在；sparse stderr 非空直接失敗，不因命令 exit0 或空間差冒成功。失敗也全做五 raw／identity，且另收 materialization goal。第一次候選 b1d27ac6/common b1103d3f 的原 bytes 已保 review1；最終 common 相對它精確只加兩行 goal pending reset：每次先 effective=false＋pending event，僅當次完整檢查成功才 true，避免上一輪成功旗標殘留。

本審查只 read/AST/小工具 hash，獨立檢查器 exit 0；沒有 import/執行 driver、synthetic、候選 inspection、掃描／hash 產品樹或任何測試。真正執行的 exit／全部原串流、實際 materialization、五 raw／identity 及可用空間結果，仍待 root 個別收據，不以本靜審替代。檢查範圍與所有小檔 hash 見 FINAL_CHECKS.json。
