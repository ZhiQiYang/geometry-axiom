"""Patch the new v3 text only; never import/execute a retirement driver."""
from pathlib import Path
p=Path(__file__).resolve().parent/'retire_guarded.py';s=p.read_text()
s=s.replace("'materialization_attempted': False, 'index_metadata_refresh_attempted': False,","'materialization_attempted': False, 'index_metadata_refresh_attempted': False,\n            'tracked_materialization_effective': False,")
marker='def run(label):'
helper='''def materialization_effective(rec, stage):
    """Require actual absence of every tracked path except retained AGENTS.md.

    Git exit zero and space deltas alone do not prove sparse patterns applied.
    lstat never follows a retained tracked symlink.
    """
    remaining = []
    agents_regular = False
    count = 0
    for row in stage.split(b'\\0'):
        if not row:
            continue
        name = os.fsdecode(row.split(b'\\t', 1)[1])
        try:
            node = (rec.repo / name).lstat()
        except FileNotFoundError:
            continue
        if name == 'AGENTS.md':
            agents_regular = stat.S_ISREG(node.st_mode)
        else:
            remaining.append({'path': name, 'mode': node.st_mode, 'bytes': node.st_size})
        count += 1
    rec.event('materialization_goal', {'retained_AGENTS_regular': agents_regular,
              'existing_tracked_nodes': count, 'remaining_non_AGENTS_tracked_nodes': remaining})
    if remaining or not agents_regular:
        raise RuntimeError('Sparse materialization ineffective: tracked nodes remain or AGENTS is missing')
    rec.result['tracked_materialization_effective'] = True
    return True


'''
if s.count(marker)!=1:raise RuntimeError('run anchor not unique')
s=s.replace(marker,helper+marker)
old='''        space = os.statvfs(rec.repo)
        rec.result['available_bytes_before'] = space.f_bavail * space.f_frsize
        rec.result['materialization_attempted'] = True
        rec.save()
        rec.git('sparse-checkout', 'set', '--no-cone', '/AGENTS.md')
        rec.result['sparse_command_exit'] = 0
'''
new='''        patterns = rec.repo / '.git' / 'info' / 'sparse-checkout'
        if patterns.read_bytes() != b'/AGENTS.md\\n':
            raise RuntimeError('Existing sparse patterns differ; do not overwrite them')
        space = os.statvfs(rec.repo)
        rec.result['available_bytes_before'] = space.f_bavail * space.f_frsize
        # Cold relocation changed dev/inode/ctime despite clean bytes/mtime.
        # Optional-lock-free status did not persist the stat-cache update.
        rec.result['index_metadata_refresh_attempted'] = True
        rec.save()
        rec.git('update-index', '--refresh')
        rec.result['index_metadata_refresh_exit'] = 0
        if identity(rec) != before_stage:
            raise RuntimeError('Stat refresh changed index stages or allowlisted identity')
        if rec.git('status', '--porcelain=v1', '--untracked-files=all'):
            raise RuntimeError('Checkout is not clean after stat-cache refresh')
        no_consumers(rec)
        rec.result['materialization_attempted'] = True
        rec.save()
        rec.git('sparse-checkout', 'reapply')
        rec.result['sparse_command_exit'] = 0
        sparse_stderr = rec.result['commands'][-1]['stderr']
        materialization_effective(rec, before_stage)
        if sparse_stderr:
            raise RuntimeError('Sparse reapply emitted stderr; inspect original output rather than treating exit zero as completion')
'''
if s.count(old)!=1:raise RuntimeError('sparse anchor not unique')
s=s.replace(old,new)
s=s.replace("if rec.result['materialization_attempted']:\n            # A failed sparse command", "if rec.result['materialization_attempted'] or rec.result['index_metadata_refresh_attempted']:\n            # A failed sparse command")
old="""            for name, check in [('parent_raw_after_failure', lambda: raw_receipts(rec, 'after-failure')),
                                ('identity_after_failure', lambda: identity(rec))]:
"""
new="""            checks = [('parent_raw_after_failure', lambda: raw_receipts(rec, 'after-failure')),
                      ('identity_after_failure', lambda: identity(rec))]
            if rec.result['materialization_attempted']:
                checks.append(('materialization_after_failure', lambda: materialization_effective(rec, before_stage)))
            for name, check in checks:
"""
if s.count(old)!=1:raise RuntimeError('failure anchor not unique')
s=s.replace(old,new)
p.write_text(s)
print('Prepared v3 text only; no import or execution of any driver')
