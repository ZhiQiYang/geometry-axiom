"""AST/small-tool hash preparation only; do not import or execute drivers."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,os,platform,sys
T=Path(__file__).resolve().parent;V2=T.parent/'cold-checkout-retirement-tools-v2'
def sha(raw):return hashlib.sha256(raw).hexdigest()
if sha((V2/'PACKAGE.json').read_bytes())!='b44c85d8f23aa38efd0a26235136977207deb3452d7fd42a14d940a03b0b30f2':raise RuntimeError('Frozen v2 package changed')
old=(V2/'retire_guarded.py').read_text();new=(T/'retire_guarded.py').read_text();tree=ast.parse(new)
operations=[]
for n in ast.walk(tree):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='git':operations.append([ast.literal_eval(a) for a in n.args])
allowed={'rev-parse','diff-index','ls-files','status','update-index','sparse-checkout'}
if any(a[0] not in allowed for a in operations):raise RuntimeError('Unexpected Git command')
mutators=[a for a in operations if a[0] in ('update-index','sparse-checkout')]
if mutators!=[['update-index','--refresh'],['sparse-checkout','reapply']]:raise RuntimeError(('Unexpected mutators',mutators))
for p in sorted(T.glob('*.py')):ast.parse(p.read_text())
(T/'V2_TO_V3.patch').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile=str(V2/'retire_guarded.py'),tofile=str(T/'retire_guarded.py'))))
plan=json.loads((V2/'PLAN.json').read_text());plan.update({'schema':'geo288-historical-work-copy-retirement-preparation/3','prepared_only':True,'executed':False,'replaces_without_modifying':str(V2),'parent_raw_guards':str(T/'PARENT_RAW_RECEIPT_GUARD_INPUTS.json'),'policy':'All v2 guards remain. Only explicit index stat-cache update-index --refresh, prove same stages/HEAD/tree and clean, then reapply existing exact /AGENTS.md patterns. Require all non-AGENTS tracked nodes absent plus retained regular AGENTS, sparse stderr empty. No force/reset/hard deletion/gc.','extra_mutator_scope':'Index stat-cache metadata only; no blob or stage changes allowed','materialization_goal_is_hard_gate':True})
(T/'PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
report={'scope':'AST and small source-tool hashes only; no driver imports/execution or candidate content hash','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':sys.argv,'exit_code':0,'stdout':'Prepared minimal v3 stat refresh/reapply and hard materialization guard; frozen v2 unchanged','stderr':'','environment':{'platform':platform.platform(),'python':sys.version,**{k:os.environ.get(k) for k in ('PATH','LANG','LC_ALL')}},'literal_git_calls':operations,'mutators':mutators,'v2_package_sha256':sha((V2/'PACKAGE.json').read_bytes()),'common_sha256':sha((T/'retire_guarded.py').read_bytes()),'retirement_executed':False,'index_or_checkout_modified':False,'diagnosis':str(T.parent/'cold-checkout-retirement-v3-diagnosis/READ_ONLY_DIAGNOSIS.json')}
(T/'PREPARATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(T.iterdir()) if p.is_file() and p.name!='PACKAGE.json'}
(T/'PACKAGE.json').write_text(json.dumps({'scope':'v3 static candidate only; not executed','files':files},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'package_sha256':sha((T/'PACKAGE.json').read_bytes()),'common_sha256':report['common_sha256'],'executed':False},indent=2))
