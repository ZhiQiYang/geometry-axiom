# 歷史工作副本精簡 v3（只準備，未執行）

v2 原退出0與所有原件保留，但實際出現 not up to date 警告且可用空間為負增量，不能代表去物化完成。只讀診斷證實三個小型警告檔的 blob 都等index，mtime/size相同，但 cold 搬移後dev/inode/ctime不同；OPTIONAL_LOCKS=0的status沒有寫回stat cache。

v3保全部v2拒ignored/nontracked/空dir/special、固定HEAD/tree/index stage、五份原raw真核、proc真路徑/alias、Popen原stream、中斷保全與R3非阻塞鎖。root僅在grid終態後、P52之前的指定空檔使用；不可移除鎖或同時啟動其他重工作。

唯一新增的寫操作為 `git update-index --refresh`：在全部前置拒絕條件通過後只刷新index stat cache，命令非0立即拒絕；必須核blob/stage/HEAD/tree原樣與完整clean，才對既有精確`/AGENTS.md` patterns執行 `git sparse-checkout reapply`。不用force/reset/clean/rm/hard/gc，不覆寫原patterns。refresh開始就標記metadata attempted，所以尚未sparse的refresh非0／中斷也必做五raw與identity後查。

成功另需每一筆原index追蹤路徑除AGENTS外都真實不存在、AGENTS仍是regular file，以及sparse stderr為空；不以Git exit0或可用空間差冒成功。materialization guard失敗仍必走最後五raw與identity後查。結果與真可用bytes差保新`cold-checkout-retirement-v3-<label>/`，不覆寫v2。

執行入口（僅root到指定窗口後；本包未執行）：

```
python3 -B /workspace/geo288-main-merge-20261023/cold-checkout-retirement-tools-v3/retire-a12d184e.py
python3 -B /workspace/geo288-main-merge-20261023/cold-checkout-retirement-tools-v3/retire-fe863b03.py
```

這些guard不是原子鎖，仍需root停止其他consumer並核執行窗口。PACKAGE／PREPARATION只證工具身份及AST，正式執行結果尚不存在。
