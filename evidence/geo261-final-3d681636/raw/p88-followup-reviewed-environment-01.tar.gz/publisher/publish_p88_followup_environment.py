"""Publish supporting audits and actual environment preparation without calling them product gates."""
from pathlib import Path
import json
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
R = Path('/workspace/geometry-axiom')
inputs = {
    'p88_published_raw_peer': B / 'p88-priority/root-native-publication-peer',
    'p88_proof_publication': B / 'p88-native-raf-completed-publication',
    'p88_public_identity': B / 'p88-native-raf-public-identity.json',
    'prbody': B / 'body-final-3d681636-p88-proven',
    'prbody_generation': B / 'p88-proven-body-generation',
    'prbody_publication': B / 'p88-proven-prbody-publication',
    'prbody_generator': B / 'write_p88_proven_prbody.py',
    'p52_checkout': B / 'p52-final-checkout-3d681636',
    'p52_checkout_outer': B / 'p52-final-checkout-execution',
    'cold_v2_actual_peer': Path('/workspace/geo299316-refresh-20261023/p88-input-closure-review/cold-v2-execution-publication-inputs'),
    'cold_v3_diagnosis': B / 'cold-checkout-retirement-v3-diagnosis',
    'cold_v3_tools': B / 'cold-checkout-retirement-tools-v3',
    'cold_v3_static_peer': B / 'cold-checkout-retirement-v3-static-review',
    'publisher': Path(__file__),
}
results = {}
for version in (2, 3):
    for label in ('a12d184e', 'fe863b03'):
        inner = B / f'cold-checkout-retirement-v{version}-{label}'
        outer = B / f'cold-retirement-v{version}-{label}-execution'
        inputs[f'cold_v{version}_{label}_inner'] = inner
        inputs[f'cold_v{version}_{label}_outer'] = outer
        d = json.loads((inner / 'receipt.json').read_text())
        e = json.loads((outer / 'receipt.json').read_text())
        if not d.get('ended_utc') or type(e.get('exit_code')) is not int:
            raise RuntimeError('Maintenance must have truly completed')
        results[f'v{version}_{label}'] = {
            'driver_exit': d['exit_code'], 'outer_exit': e['exit_code'],
            'passed': d['passed'], 'available_bytes_delta': d.get('freed_available_bytes'),
            'parent_raw_verified_unchanged': d.get('parent_raw_verified_unchanged'),
            'scope': 'Environment maintenance only; v2 zero exits did not establish space recovery; v3 separately verifies materialization',
        }
for label, path in inputs.items():
    if not path.exists():
        raise RuntimeError('Missing completed input: ' + label)
record = B / 'P88_FOLLOWUP_ENVIRONMENT_COMPLETED.json'
if record.exists():
    raise RuntimeError('Summary must be new')
record.write_text(json.dumps({'schema': 'geo288-p88-followup-environment/1',
    'tested_product_sha': F, 'product_tests_run_by_this_publication': False,
    'maintenance': results, 'p52_checkout_exit': 0, 'p52_measurement_executed': False,
    'prbody_head': '474011863fe5215f523a81d2d7c85fd4a92e40dd', 'live_pr_updated': False,
}, ensure_ascii=False, indent=2) + '\n')
command = ['python3', '-B', str(B / 'record_command.py'),
    '--out', str(B / 'p88-followup-environment-publication'), '--sha', F,
    '--cwd', str(R), '--variant', 'supporting-environment-and-peer-publication', '--',
    'python3', '-B', '/workspace/geo261-environment/publish_followup_progress.py',
    '--repo', str(R), '--branch', 'architecture/geo261-integration-20261016',
    '--issue', '261', '--sha', F, '--label', 'p88-followup-reviewed-environment',
    '--result', 'P88公開封包外23/內349原件經獨立771核全一致，最新正文47401186已一般push。P52獨立乾淨F checkout準備0，未開始量測。冷checkout v2兩次exit0卻有保留檔案警告且容量未增加，原件照留；v3顯式刷新Git搬移後stat cache再sparse reapply，兩次原exit0、五parent raw與HEAD/tree/stage不變，實際釋出1244446720及1350230016 bytes。這是環境維護，不冒產品gate。',
    '--next', '完成同F grid與native4證據出版，之後P52正式與runtime獨占量測。',
    '--receipt', str(record)]
for label, path in inputs.items():
    command += ['--input', label + '=' + str(path)]
raise SystemExit(subprocess.run(command, cwd=R).returncode)
