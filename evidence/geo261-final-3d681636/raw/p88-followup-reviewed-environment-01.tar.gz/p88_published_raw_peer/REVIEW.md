# P88 公開封包與 PR 正文對抗審查

結論：沒有發現阻擋。主代理公開證據提交 `1ccfbd69be022afd1effcc66070ca8c9d06435d0` 的外層 23 檔及內層 349 檔，逐一核對原 bytes／SHA-256 全部相同；771 項機械核對完成，程式 exit 0。沒有寫入整合分支、受驗來源或開啟瀏覽器。

外層 Git blob 為 22,330,294 bytes，SHA-256 `6b8968c726f8752a250cf3ebbe277968a75c6ce52292546aa03a5fff3ad9b69c`。其中完整反證原包為 22,446,502 bytes，SHA-256 `3f107c0424c62844eaeac3ab6086ea75b7ebc6cc3c9e829dd61c34eedcb52e4a`。內層 349 原件及全部 16 份工具準備檔均實際解壓串流核雜湊，並非只比對壓縮包名稱或先前 ROUNDTRIP 聲明；未將大型 trace 解壓寫回磁碟。

公開的獨立 receipt 與內層 `raw/receipt.json` 逐 bytes 相同。三階段原 workflow／原 Node 與原 proof 資料互相一致：固定 0、撤回 1、恢復 0；來源前後為 F `3d681636902371ecc528b20f51eea33e272581c9`，status 空、index 相同。固定與恢復原 footer 各完成 P88 143 斷言；撤回至 P88 99，原 `failedAssertions=0` 保留，因精確 `document.activeElement===document.querySelector("#refGuideMode")` predicate 逾時而 fatal，沒有冒成 assertion counter 增一。三階段皆未超原 15 分鐘診斷 job 時限，撤回沒有 transport/network 失敗。

診斷明列 partial／只跑原 P88，沒有比全 job golden，不能充作完整 grid 或 canvas。外層排除清單空代表其選定封裝輸入無排除；內層 manifest 仍明確說各 phase/tmp 全樹（含 feedback、cache、profile、編譯產物）未收進內包，未被覆寫成「所有 runtime bytes 都封存」。舊無效 query 實驗的歷史分類也保留。

正文精確綁定 `body-final-3d681636-p88-proven/PR_BODY.md`，SHA-256 `b4a44dd300e10306ecbdfde2c0816393edc92cfb2b8e6dbe47ebf83f0792bae4`。只有一張 current-state 矩陣，共 32 列；grid、四個 native partial、P52、P73、Chromium154 與四項 oracle 仍逐項標待跑，沒有因 P88 反證通過而提升其他 gate。正文正確區別「第一次真點擊之前重測」與「錯點後再次點擊」，保留同序列有效反證、原自然紅唯一原因尚未證成，以及沒有 Paint/compositor／全部真人交錯安全證據。沒有宣稱 live PR 已更新或 #288 可合併。

歷史段落的「最後 click」應理解為失敗快照記錄的 last-click 欄位；後文已明確說原三輪沒有 pointer trace。若要更精確，可改寫成「失敗快照記錄最後 click」，避免讀者將快照誤認為新取得的可信 pointerdown 證據。這是措辭建議，不影響已明列限制或本次受控 0／1／0。

審查範圍：本代理是原 P88 執行者，此次核的是另一代理公開封裝及正文對原件的一致性；動態反證本身另有 `audit_oracle_main_merge` 的獨立三階段對抗審，產品歸因另有 `own_kernel_no_wood` 的獨立審查。其他繼承 closure 與非 P88 gate 在此僅核其正文未冒稱新 F 實跑，沒有重審全部底層測試。

可重現的唯讀核對程式為上一層 `review_root_native_publication.py`，完整 771 項及 Git 讀取 argv／exit／輸出雜湊保存在 `CHECKS.json`。唯一後續是主代理照原排程完成其他受影響驗收。
