# 冷 checkout v2 實際執行與 P52 Git 準備對抗審

結論：兩件 v2 實際命令及保全裁判未見可確立阻擋；這只表示固定允許範圍的保全檢查通過，不能聲稱空間已回收。

已核真終態 `a12d184ec1865ad078700cea2387ac69e82ab62a` 與 `fe863b0374eafd9f1e57ec5107e28a1101804b56`：outer wrapper／driver／sparse 命令均 exit 0；實際 receipt 記錄的 PACKAGE b44c85d8…、common e890d1cc… 精確對已審 frozen 工具。每件 20 條原 Git 命令的 argv、結束碼、stdout/stderr 原檔與記錄 hash 全部核過。只有一條變動命令，精確是 `git sparse-checkout set --no-cone /AGENTS.md`；沒有 reset/clean/rm/gc/repack。完整原 HEAD/tree/獨立 gitdir/common-dir 與三次 `ls-files --stage -z` bytes 皆一致，三次 staged 差分與 tracked/untracked status 為空。

每件兩次『變動前』metadata 庫存，分別 a12d 29,732 個、fe863 29,824 個節點，原檔 hash 與 events 一致；Git 一般／ignored others 原輸出皆空，庫存 nontracked/type-invalid 都是 false。這兩份是前置檢查，不能冒充變動後完整樹庫存。兩次 consumer guard 均 active=[]，不可讀 proc 欄位仍有明確記錄，不能宣稱全系統所有程序皆可見。保全前與後的五份原 parent raw receipts，皆核 event、guard pin、保全副本及目前小型原 receipt 的完整 bytes/hash 相符；raw_receipts_removed=false、parent_raw_verified_unchanged=true 有實證。沒有讀取、掃描或重 hash 產品大樹。

兩條 sparse 原 stderr 都是 4,177 bytes，均含 `not up to date and were left despite sparse patterns` 警告，原檔未改。可用空間變化分別 -8,142,848 與 -8,159,232 bytes；因此退出 0 不能外推成功縮減 materialization 或已回收空間。本審查不自行重試或改變工具。

P52 Git 專用 checkout 準備也已真終態：source SHA `3d681636902371ecc528b20f51eea33e272581c9`；outer 與 driver 皆 0，13 條原 Git 命令均 0，完整原 stdout/stderr bytes/hash 全核。實際 source-before／destination-after／source-after 的 HEAD=F、status 空、完整 stage hash 相同；原 `clone --shared --no-hardlinks --no-checkout`、sparse 排除 evidence、core.autocrlf=false detach F 步驟一致。專用 index／工作目錄隔離，但 Git objects 仍透過共享 alternates 倚賴原來源；不可因準備成功就刪原來源 objects。工具目前 hash 43c2fe4a… 與先前靜審相符，outer 收據保留實際工具路徑；此 checkout receipt 沒有自行記錄 launch 當時的工具 bytes hash，不能把目前 hash 說成獨立的當時位元組封存證據。

P52 準備明記 build_executed=false、test_executed=false。它只證 Git 準備完成，不等於 P52 量測通過或 runtime snapshot 已由正式 P52 裁判確認。

本獨立證據檢查器 exit 0。只讀原 metadata、原命令串流、固定小工具、五份小型 parent receipt；未 import/執行 retire/preparer、未操作候選、未編譯或啟 Chrome，也未寫整合分支。詳細 SHA、全部命令串流與保全批次見 CHECKS.json；TOCTOU 與 proc 可讀性邊界沿原文件保留。
