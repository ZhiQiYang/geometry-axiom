"""Advance only completed P88 evidence and the authoritative review snapshot."""
from pathlib import Path
import hashlib
import json
import subprocess

B = Path('/workspace/geo288-main-merge-20261023')
F = '3d681636902371ecc528b20f51eea33e272581c9'
E = '1ccfbd69be022afd1effcc66070ca8c9d06435d0'
original = B / 'body-final-3d681636-three-rounds/PR_BODY.md'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if sha(original) != '427c5cf055f0ed879187aad7372f61b3bfc8325e86a945d0089f8e771f06a3bf':
    raise RuntimeError('Reviewed previous body differs')
publication = json.loads((B / 'p88-native-raf-completed-publication/receipt.json').read_text())
if publication['exit_code'] != 0:
    raise RuntimeError('Proof publication did not complete')
summary_path = B / 'p88-priority/NATIVE_RAF_FINAL_SUMMARY.json'
s = json.loads(summary_path.read_text())
if s['sha'] != F or [r['original_node_exit'] for r in s['phases']] != [0, 1, 0] or not s['proof_passed']:
    raise RuntimeError('Unexpected original proof result')
repo = Path('/workspace/geometry-axiom')
if subprocess.check_output(['git', 'ls-remote', '--heads', 'origin', 'architecture/geo261-integration-20261016'], cwd=repo).decode().split()[0] != E:
    raise RuntimeError('The selected evidence snapshot is not the current published branch head')
text = original.read_text().replace('fdf731e28257c50873cb38e030eed273eeee97fc', E)
text = text.replace('三次完整 canvas 皆通過；其餘受影響項與反證尚未結案',
                    '三次完整 canvas 皆通過，P88受控撤回／恢復反證為0/1/0；grid、native補驗與其他專項仍待結案')
start = text.index('已重新fetch並讀')
end = text.index('\n\n', start)
text = text[:start] + ('已重新fetch並讀[handoff最新審查全文](https://github.com/ZhiQiYang/geometry-axiom/blob/acd1289228d490c68a139cf17e02fdc1f3cb247c/handoff/pr-reviews/288.md)：同步SHA `acd1289228d490c68a139cf17e02fdc1f3cb247c`，最新審查2026-10-23T12:35:32Z／head `ee28481`。本次補上第三輪完整canvas與同序列P88舊座標反證；其餘列定同F gate仍按下表逐項完成。原runtime反證在F13已關閉，但新P88來源改動影響RuntimeSnapshot輸入，仍安排F重驗。本檔推prbody分支供套用，沒有宣稱live PR正文已更新。') + text[end:]
text = text.replace('撤回／恢復反證仍另列待結案。', '另列P88受控反證已完成0/1/0。')
row = next(line for line in text.splitlines() if line.startswith('| P88撤回／恢復反證 |'))
new = ('| P88撤回／恢復反證 | F 原0/1/0；driver/outer/launcher各0 | 完整P88-only診斷；fixed/restored各143 checks通過；withdrawn到99後原refGuideMode焦點25秒wait fatal，failedAssertions仍原0。原partial/golden未比較，不冒正式grid；舊query 1/1/1、driver2仍屬無效反證歷史。 | [原收據及完整封包](https://github.com/ZhiQiYang/geometry-axiom/blob/' + E + '/evidence/geo261-final-3d681636/receipts/p88-native-raf-controlled-completed.json) |')
text = text.replace(row, new)
start = text.index('本次採用的修復假說是')
end = text.index('\n\n', start)
text = text[:start] + ('本次有效受控反證支持**測試量測座標過期**：三phase皆由真query成功回覆觸發原renderer及原生rAF，原量測先得到(293.75,627.5)，原callback將parent scroll 0恢復為25後，舊點命中來源比例label。撤回補丁時真mousePressed/released仍用627.5，原焦點wait轉紅；fixed/restored在第一次真點擊之前重新穩定並量測，第一次mousePressed即用602.5命中refGuideMode，原完整P88通過。這不是錯點後重點擊。三phase維持同一個原callback、原this/args與guards，各執行一次；未改原量測回傳值、產品app.js、golden或時限。原source/index前後同F且乾淨。\n\n此控制實驗沒有觀測到目標pointerdown到pointerup期間的位移：撤回時callback先完成8.5ms才pointerdown，已錄各輸入快照的rect/scroll相同。它沒有Paint/compositor連續畫面，不能證明所有真人交錯安全；F13自然1/0/0也沒有pointertrace，不能把本次query認定為歷史自然紅唯一根因。目前證據未確立另一個產品按壓中位移缺陷。舊query診斷三phase均在未產生預期錯位的工具前提失敗（1/1/1、driver2），完整原件照留，不倒改為有效反證。') + text[end:]
old = '尚未結案項目已在唯一矩陣逐項標示。最大不確定處仍是P88自然間歇紅的精確事件順序與修復有效性，需新F連續canvas及有效反證共同回答；Cperf繼承值1.970798接近2×且僅原三筆，保留此限制，不另抽樣或改門檻。全部普通push；不force push、不合併PR。'
new = '尚未結案項目已在唯一矩陣逐項標示。P88已有新F三次完整canvas綠與同序列有效0/1/0反證；最大剩餘不確定處是歷史自然紅的唯一因果與未觀測的真人可見交錯，不能由受控診斷外推。Cperf繼承值1.970798接近2×且僅原三筆，保留此限制，不另抽樣或改門檻。全部普通push；不force push、不合併PR。'
if text.count(old) != 1:
    raise RuntimeError('Expected the previous limitations paragraph')
text = text.replace(old, new)
out = B / 'body-final-3d681636-p88-proven'
out.mkdir(exist_ok=False)
(out / 'PR_BODY.md').write_text(text)
(out / 'BINDING.json').write_text(json.dumps({'source_sha': F, 'evidence_head': E,
    'prior_body_sha256': sha(original), 'body_sha256': sha(out / 'PR_BODY.md'),
    'proof_summary_sha256': sha(summary_path), 'original_proof_exits': [0, 1, 0],
    'review_snapshot_sha': 'acd1289228d490c68a139cf17e02fdc1f3cb247c',
    'scope': 'Completed P88 proof and current review only; other pending gates remain pending; not a live PR edit'}, ensure_ascii=False, indent=2) + '\n')
print(str(out / 'PR_BODY.md'))
