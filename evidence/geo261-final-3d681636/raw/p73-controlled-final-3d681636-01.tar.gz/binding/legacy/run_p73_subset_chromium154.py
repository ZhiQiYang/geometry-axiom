#!/usr/bin/env python3
"""以原 workflow 與正式 P73 子集驗證固定／撤回／恢復；原退出碼不因預期紅而改寫。"""
from __future__ import annotations

import argparse
import difflib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback

import yaml
import run_workflow as workflow_tools
from runtime_inventory import complete_runtime_inventory

ENV_ROOT = Path('/workspace/geo261-environment')
WORKFLOW_PATH = '.github/workflows/integration-tests.yml'
REAPER = Path(__file__).resolve().parent / 'reap_children.py'
REAPER_FLAG = 'GEO261_P73_UNDER_REAPER'
FAILURE = 'P73 assertion failed: 空空間不畫假邊界，提供加入成員入口 false'


def git(repo, *args):
    return workflow_tools.simple(['git', *args], cwd=repo)


def identity(repo):
    paths = sorted((repo / 'tests').glob('*.py'))
    paths += [repo / 'geometry-web' / name for name in (
        'cdp_test.js', 'uiux_review_test.js', 'cdp_helpers.js', 'cdp_floor.js',
        'cdp_evaluation.js', 'cdp_navigation.js', 'transport_failure_trace.js',
        'grid_workspace_draft_test.js', 'cdp_sections.golden.json')]
    return {
        'head': git(repo, 'rev-parse', 'HEAD').decode().strip(),
        'runtime_complete_inputs': complete_runtime_inventory(repo, git(repo, 'rev-parse', 'HEAD').decode().strip(), lambda *v: git(repo, *v)),
        'status': git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode('utf-8', 'replace'),
        'app_js_sha256': workflow_tools.sha256((repo / 'geometry-web/app.js').read_bytes()),
        'tests_sha256': {str(path.relative_to(repo)): workflow_tools.sha256(path.read_bytes()) for path in paths},
        'test_hash_scope': '根目錄 tests/*.py，加正式 P73 harness、helpers、navigation/evaluation/transport、grid-draft 子模組及 golden 原始 bytes。',
    }


def save_receipt(out, receipt):
    workflow_tools.write_json(out / 'receipt.json', receipt)


def launch(args):
    repo, scratch = args.repo.resolve(), args.scratch.resolve()
    out = scratch / 'p73-proof' / args.label
    tmp = scratch / 'tmp' / ('p73-' + args.label)
    if out.exists() or tmp.exists():
        raise RuntimeError('拒絕覆蓋既有 P73 證據或暫存目錄')
    out.mkdir(parents=True)
    tmp.mkdir(parents=True)
    before = identity(repo)
    if before['head'] != args.sha:
        raise RuntimeError('受驗 HEAD 不等於必填 final SHA')
    if Path(git(repo, 'rev-parse', '--show-toplevel').decode().strip()).resolve() != repo:
        raise RuntimeError('repo 必須是實際 Git 根目錄')
    raw = git(repo, 'show', before['head'] + ':' + WORKFLOW_PATH)
    spec = yaml.safe_load(raw)['jobs']['browser']
    matrix = next(item for item in spec['strategy']['matrix']['include'] if item['suite'] == 'canvas')
    formal_minutes = int(workflow_tools.matrix_substitute(spec['timeout-minutes'], matrix))
    started, start = workflow_tools.now(), time.monotonic()
    deadline = start + formal_minutes * 60 * 3
    env = {name: value for name, value in os.environ.items() if not name.startswith('GEOMETRY_')}
    node = shutil.which('node', path=env.get('PATH'))
    if not node:
        raise RuntimeError('Node.js 不存在')
    prefix = [str(ENV_ROOT / 'bin'), str(Path(node).parent), *env.get('PATH', '').split(os.pathsep)]
    env.update(PATH=os.pathsep.join(dict.fromkeys(prefix)), LANG='C.UTF-8', LC_ALL='C.UTF-8',
               PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(tmp),
               CI='true', GITHUB_ACTIONS='true', RUNNER_OS='Linux', GITHUB_SHA=before['head'],
               GITHUB_WORKSPACE=str(repo), XDG_DATA_HOME=str(ENV_ROOT / 'xdg-data'),
               XDG_CACHE_HOME=str(ENV_ROOT / 'xdg-cache'))
    original_env = {name: workflow_tools.matrix_substitute(value, matrix)
                    for name, value in spec.get('env', {}).items()}
    for name, value in original_env.items():
        env[name] = workflow_tools.mechanically_rewrite(value, tmp, args.port)
    env.update(GEOMETRY_CHROME='/usr/bin/chromium',
               GEOMETRY_UIUX_FIX_ONLY='1', GEOMETRY_CDP_PORT=str(args.cdp_port),
               GEOMETRY_CHROME_PROFILE=str(tmp / 'chrome-profile'),
               GEOMETRY_UIUX_SCREENSHOT_DIR=str(tmp / 'screens'),
               GEOMETRY_REPAIR_SCREENSHOT_DIR=str(tmp / 'screens'))
    for name in ('XDG_DATA_HOME', 'XDG_CACHE_HOME'):
        Path(env[name]).mkdir(parents=True, exist_ok=True)
    names = {'PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE', 'TMPDIR',
             'CI', 'GITHUB_ACTIONS', 'RUNNER_OS', 'GITHUB_SHA', 'GITHUB_WORKSPACE',
             'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'GEO261_REAPER_LOG'}
    names.update(name for name in env if name.startswith('GEOMETRY_'))
    receipt = {
        'schema': 'geo261-p73-withdrawal-proof/1', 'sha': args.sha, 'label': args.label,
        'started': started, 'source_before': before, 'source_after': None,
        'workflow_sha256': workflow_tools.sha256(raw), 'driver_sha256': workflow_tools.sha256(Path(__file__).read_bytes()),
        'capture_driver_sha256': workflow_tools.sha256(Path(workflow_tools.__file__).read_bytes()),
        'reaper_driver_sha256': workflow_tools.sha256(REAPER.read_bytes()),
        'runtime_inventory_driver_sha256': workflow_tools.sha256((Path(__file__).resolve().parent / 'runtime_inventory.py').read_bytes()),
        'workflow_environment': original_env,
        'environment': {name: env[name] for name in sorted(names) if name in env},
        'ports': {'service': args.port, 'cdp': args.cdp_port}, 'temporary_directory': str(tmp),
        'scope': 'Chromium154附加對照：固定受驗SHA原P73完整子集；不是正式Chrome156產品job，不是完整canvas，也不比較完整golden。',
        'expected_exit_code': args.expected_exit, 'expected_failure': FAILURE if args.expected_exit else None,
        'actual_exit_code': None, 'proof_expectation_matches': False,
        'ci_timeout_minutes': formal_minutes, 'watchdog_factor': 3, 'versions': [], 'steps': [],
        'reaper_events': env.get('GEO261_REAPER_LOG'),
        'notes': ['保留原 test 與原 workflow run，不改斷言；只機械替換埠/tmp，另明列 Chrome/P73/profile/截圖環境。',
                  '預期紅燈的原退出碼仍為 1，不改寫成 0。',
                  '外層 subreaper 在本 driver 結束後繼續回收並追加完成事件；事件最終 hash 應由呼叫端於整支命令結束後保存。'],
    }
    (out / 'workflow.yml.txt').write_bytes(raw)
    for name, path in [('driver.py.txt', Path(__file__)), ('capture-driver.py.txt', Path(workflow_tools.__file__)),
                       ('reaper.py.txt', REAPER), ('runtime-inventory.py.txt', Path(__file__).resolve().parent / 'runtime_inventory.py')]:
        (out / name).write_bytes(path.read_bytes())
    save_receipt(out, receipt)
    code = 70
    try:
        for index, argv in enumerate((['/usr/bin/chromium', '--version'], ['node', '--version'],
                                      ['python3', '--version'], ['cc', '--version'],
                                      ['dpkg-query', '-W', '-f=${Status} ${Version}\n', 'fonts-noto-cjk'])):
            row = workflow_tools.capture(argv, out / 'versions' / str(index), cwd=repo, env=env, timeout=30)
            receipt['versions'].append(row)
            if row['exit_code']:
                raise RuntimeError('版本檢查失敗：' + ' '.join(argv))
        chrome = Path(receipt['versions'][0]['stdout']).read_text().strip()
        node_version = Path(receipt['versions'][1]['stdout']).read_text().strip()
        if not chrome.startswith('Chromium 154.') or not node_version.startswith('v24.'):
            raise RuntimeError('本附加對照須使用 Chromium 154 及 Node 24')
        code = 0
        for index, step in enumerate(spec['steps']):
            name = step.get('name') or step.get('uses') or str(index)
            row = {'index': index, 'name': name, 'original_step': step}
            receipt['steps'].append(row)
            if 'uses' in step:
                row['outcome'] = ('既有 checkout；未執行 GitHub checkout action' if step['uses'].startswith('actions/checkout')
                                  else '未執行 GitHub artifact upload；本地 tmp 與證據原件保留')
                continue
            original = step['run']
            run = workflow_tools.mechanically_rewrite(workflow_tools.matrix_substitute(original, matrix), tmp, args.port)
            prefix = out / 'steps' / f'{index:02d}'
            prefix.parent.mkdir(parents=True, exist_ok=True)
            prefix.with_suffix('.original.sh.txt').write_text(original, encoding='utf-8')
            script = prefix.with_suffix('.executed.sh')
            script.write_text(run if run.endswith('\n') else run + '\n', encoding='utf-8')
            prefix.with_suffix('.diff.txt').write_text(''.join(difflib.unified_diff(
                original.splitlines(keepends=True), script.read_text().splitlines(keepends=True),
                fromfile='原 workflow run', tofile='本輪執行 run')), encoding='utf-8')
            row.update(original_run=original, executed_run=run, script_sha256=workflow_tools.sha256(script.read_bytes()))
            print(f'開始 P73 {args.label}：{name}', flush=True)
            if re.search(r'\bsudo\b|\bapt(?:-get)?\b', run):
                lines = [line.strip() for line in run.splitlines() if line.strip() and not line.lstrip().startswith('#')]
                if any('apt-get' not in line for line in lines) or 'fonts-noto-cjk' not in run:
                    raise RuntimeError('套件步驟有未辨識內容，不能宣稱已安裝')
                check = workflow_tools.capture(['dpkg-query', '-W', '-f=${Status} ${Version}\n', 'fonts-noto-cjk'],
                                               prefix.with_name(prefix.name + '-package'), cwd=repo, env=env, timeout=30)
                row.update(outcome='字型已安裝；未重複執行原 apt 指令', check=check)
                if check['exit_code'] or not Path(check['stdout']).read_text().startswith('install ok installed '):
                    raise RuntimeError('CJK 字型尚未安裝')
            else:
                argv = (['bash', '--noprofile', '--norc', '-eo', 'pipefail', str(script)]
                        if step.get('shell') == 'bash' else ['bash', '-e', str(script)])
                result = workflow_tools.capture(argv, prefix, cwd=repo, env=env, timeout=max(1, deadline - time.monotonic()))
                row.update(result=result, outcome='成功' if result['exit_code'] == 0 else '原指令非零退出')
                code = result['exit_code']
                print(f'結束 P73 {args.label}：{name}；原退出碼 {code}', flush=True)
                if code:
                    save_receipt(out, receipt)
                    break
            save_receipt(out, receipt)
        result_file = out / 'steps' / '03.stdout'
        results = []
        if result_file.is_file():
            for line in result_file.read_text(encoding='utf-8', errors='replace').splitlines():
                if line.startswith('CDP_RESULT '):
                    results.append(json.loads(line[len('CDP_RESULT '):]))
        receipt['cdp_results'] = results
        if len(results) == 1:
            result = results[0]
            scope = result.get('scope', {})
            scope_ok = scope.get('mode') == 'partial' and scope.get('filters') == ['GEOMETRY_UIUX_FIX_ONLY']
            if args.expected_exit == 0:
                expected_p73 = json.loads((repo / 'geometry-web/cdp_sections.golden.json').read_text())['sections']['P73']
                receipt['expected_p73_passed'] = expected_p73
                matches = code == 0 and result.get('completed') is True and result.get('failedAssertions') == 0 \
                    and result.get('sections', {}).get('P73') == expected_p73
            else:
                matches = code == 1 and result.get('completed') is False and result.get('failedAssertions') == 1 \
                    and result.get('fatal') == FAILURE and result.get('sectionsFailed') == {'P73': 1}
            receipt['proof_expectation_matches'] = bool(scope_ok and matches)
    except KeyboardInterrupt:
        code = 130
        receipt['error'] = '使用者中斷；不是產品負控制成功。'
    except Exception:
        code = 70
        receipt['error'] = traceback.format_exc()
        (out / 'driver-error.log').write_text(receipt['error'], encoding='utf-8')
        print(receipt['error'], file=sys.stderr, flush=True)
    finally:
        receipt['source_after'] = identity(repo)
        if receipt['source_after'] != before:
            receipt['source_integrity_error'] = '執行期間 HEAD、工作樹狀態、產品或裁判 hash 有變動。'
            receipt['proof_expectation_matches'] = False
        server_log = tmp / 'geometry-integration-server.log'
        if server_log.is_file():
            shutil.copy2(server_log, out / 'server.log')
        screens = tmp / 'screens'
        if screens.is_dir():
            shutil.copytree(screens, out / 'screens')
        receipt.update(ended=workflow_tools.now(), seconds=time.monotonic() - start,
                       actual_exit_code=code, over_ci_timeout=time.monotonic() - start > formal_minutes * 60)
        receipt['files'] = workflow_tools.file_inventory(out)
        receipt['files'].pop('receipt.json', None)
        save_receipt(out, receipt)
        (out / 'receipt.sha256').write_text(workflow_tools.sha256((out / 'receipt.json').read_bytes()) + '  receipt.json\n')
    print(f'P73 {args.label}：原退出碼 {code}；預期 {args.expected_exit}；反證期望符合={receipt["proof_expectation_matches"]}；{out}', flush=True)
    return code if code >= 0 else 128 - code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--cdp-port', type=int, required=True)
    parser.add_argument('--expected-exit', type=int, choices=(0, 1), required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{40}', args.sha):
        parser.error('sha 必須是可解析的完整小寫40字元SHA')
    if not re.fullmatch(r'[A-Za-z0-9._-]+', args.label):
        parser.error('label 僅可使用英數字、點、底線及連字號')
    scratch = args.scratch.resolve()
    if not scratch.is_relative_to(Path('/tmp')) or scratch.is_relative_to(args.repo.resolve()):
        parser.error('scratch 必須在 /tmp、位於 repo 外')
    if any(not 1024 <= port <= 65535 for port in (args.port, args.cdp_port)) or args.port == args.cdp_port:
        parser.error('服務埠與 CDP 埠必須不同，且在 1024–65535')
    scratch.mkdir(parents=True, exist_ok=True)
    if os.environ.get(REAPER_FLAG) != '1':
        events = scratch / 'control' / ('p73-' + args.label + '-reaper.jsonl')
        if events.exists():
            raise RuntimeError('拒絕覆蓋既有 subreaper 事件')
        env = dict(os.environ, GEO261_REAPER_LOG=str(events), **{REAPER_FLAG: '1'})
        command = [sys.executable, str(REAPER), sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]]
        os.execve(sys.executable, command, env)
    with (scratch / 'heavy.lock').open('a+b') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('重型工作鎖已被持有，未啟動 P73。', file=sys.stderr)
            return 78
        return launch(args)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('P73 driver 前置失敗：' + traceback.format_exc(), file=sys.stderr, flush=True)
        raise SystemExit(78)
