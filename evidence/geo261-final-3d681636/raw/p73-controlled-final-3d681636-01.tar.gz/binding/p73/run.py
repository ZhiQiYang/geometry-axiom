#!/usr/bin/env python3
"""F 真 app 單次 controlled callback，fixed / withdrawn / restored；不改原測試。"""
from __future__ import annotations
import argparse, datetime, fcntl, hashlib, json, os, platform, resource, signal, socket, subprocess, sys, time, traceback
from pathlib import Path
import capture
from runtime_inventory import complete_runtime_inventory, same_runtime_identity

F='3d681636902371ecc528b20f51eea33e272581c9'
CAPTURE='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
REAPER='7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
APP='geometry-web/app.js'
FIXED=("  const svg=$('spacePlanSvg');\n"
       '  // SVG 沒有 HTML 元素的 hidden 反射屬性；與 renderSpacePlan 共用 attribute 狀態。\n'
       "  if(!svg||svg.hasAttribute('hidden'))return;\n"
       '  const matrix=svg.getScreenCTM();if(!matrix)return;\n').encode()
OLD=b"  const svg=$('spacePlanSvg'),matrix=svg?.getScreenCTM();if(!svg||svg.hidden||!matrix)return;\n"
INPUTS=('geometry-web/app.js','geometry-web/uiux_review_test.js','geometry-web/cdp_test.js',
        'geometry-web/cdp_helpers.js','geometry-web/start_local.py','geometry-web/serve.py','geometry-web/runtime_version.py')
SAFE=('PATH','LANG','LC_ALL','TMPDIR','GITHUB_SHA','GITHUB_WORKSPACE','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING',
      'GEOMETRY_TEST_URL','GEOMETRY_FEEDBACK_DIR','GEOMETRY_CHROME','GEOMETRY_CHROME_FLAGS','GEOMETRY_CHROME_PROFILE',
      'GEOMETRY_CDP_PORT','GEO261_REAPER_LOG','P73_VARIANT','CC','CFLAGS','CPPFLAGS','LDFLAGS')
def h(raw):return hashlib.sha256(raw).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--repo',required=True,type=Path);p.add_argument('--scratch',required=True,type=Path)
 p.add_argument('--sha',required=True);p.add_argument('--heavy-lock',required=True,type=Path)
 p.add_argument('--clone-dir',type=Path)
 p.add_argument('--chrome',default='/workspace/geo261-environment/bin/google-chrome',type=Path)
 p.add_argument('--reaper',default='/workspace/geo261-environment/reap_children.py',type=Path)
 p.add_argument('--service-port',type=int,default=19920);p.add_argument('--cdp-port',type=int,default=9560)
 a=p.parse_args();repo=a.repo.resolve();out=a.scratch.resolve();base=Path(__file__).resolve().parent
 need(a.sha==F and not sys.flags.optimize,'本工具只綁定 F，禁止 Python optimize')
 need(repo.is_dir() and not out.exists() and out.parent.is_dir(),'需要既有來源與全新 scratch')
 need(not out.is_relative_to(repo) and not repo.is_relative_to(out),'scratch 必須在來源外')
 need(out.is_relative_to(Path('/tmp')),'scratch 必須在 /tmp；Chrome 與 feedback 使用專用 TEMP')
 need(a.heavy_lock.is_file(),'需要既有正式 F 共用 heavy lock')
 need(1024<=a.service_port<=65533 and 1024<=a.cdp_port<=65533,'三階段埠須有效')
 need(not set(range(a.service_port,a.service_port+3))&set(range(a.cdp_port,a.cdp_port+3)),'服務與 CDP 埠不可重疊')
 need(h((base/'capture.py').read_bytes())==CAPTURE and Path(capture.__file__).resolve()==base/'capture.py','capture 來源不符')
 need(h(a.reaper.read_bytes())==REAPER,'subreaper 原碼不符')
 out.mkdir();(out/'tmp').mkdir();(out/'tools').mkdir()
 frozen={}
 for path in [base/'run.py',base/'probe.cjs',base/'capture.py',base/'runtime_inventory.py',a.reaper]:
  raw=path.read_bytes();frozen[str(path)]=h(raw);(out/'tools'/path.name).write_bytes(raw)
 env=dict(os.environ);cleared=[]
 for key in list(env):
  if key.startswith('GEOMETRY_') or key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','P73_COMPILE_ONLY','LD_PRELOAD'):
   cleared.append(key);env.pop(key)
 env.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',
            GITHUB_SHA=F,GITHUB_WORKSPACE=str(repo),TMPDIR=str(out/'tmp'))
 soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
 need(hard==resource.RLIM_INFINITY or hard>=16384*1024,'hard stack 不足 16MiB')
 resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
 recorder=capture.Recorder(out,env,F);clone=a.clone_dir.resolve() if a.clone_dir else out/'checkout';fixed=None
 need(not clone.exists() and not clone.is_relative_to(repo) and not repo.is_relative_to(clone),'隔離clone必須全新且在來源外')
 need(clone.is_relative_to(Path('/workspace')) or clone.is_relative_to(Path('/tmp')),'隔離clone只用workspace/tmp')
 phases=[];guards=[];errors=[]
 receipt={'schema':'geo261-final-F-P73-controlled-proof/1','sha':F,'repo':str(repo),'clone':str(clone),
  'scope':'real app, original P73 predicate, exactly one explicit production sync callback; not full P73 workflow',
  'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:env.get(k) for k in SAFE},
  'platform':platform.platform(),'python':sys.version,'python_executable':sys.executable,'tool_hashes':frozen,
  'cleared_environment_names':cleared,'stack_before':[soft,hard],'stack_during':[16384*1024,hard],
  'phases':phases,'guards':guards,'errors':errors,'passed':False}
 save(out/'receipt.json',receipt)
 def cmd(argv,cwd=repo,check=True,variant=None,timeout=120):
  return recorder.run(list(map(str,argv)),cwd=cwd,check=check,timeout=timeout,source_sha=F,source_variant=variant)
 def git(path,*args):return cmd(['git',*args],path)[1]
 original={}
 def guard(path,label,withdrawn=False):
  head=git(path,'rev-parse','HEAD').decode().strip();status=git(path,'status','--porcelain=v1','--untracked-files=all').decode()
  diff=git(path,'diff','--binary','--full-index','--no-ext-diff','--no-color','HEAD')
  row={'label':label,'head':head,'status':status,'inputs':{rel:h((path/rel).read_bytes()) for rel in INPUTS},'diff_sha256':h(diff)}
  guards.append(row);(out/(label+'.patch')).write_bytes(diff)
  need(head==F and status==(' M '+APP+'\n' if withdrawn else ''),label+': 非預期工作樹變更')
  need(not git(path,'diff','--cached','--name-only'),label+': 有 staged 差分')
  if original:
   expected=dict(original)
   if withdrawn:expected[APP]=h(fixed.replace(FIXED,OLD,1))
   need(row['inputs']==expected,label+': 原測試或非預期來源 bytes 變動')
 def free_port(port):
  with socket.socket() as sock:sock.bind(('127.0.0.1',port))
 def phase(index,name,withdrawn):
  phaseout=out/name;phaseout.mkdir();tmp=out/'tmp'/name;tmp.mkdir();(tmp/'feedback').mkdir()
  serverport=a.service_port+index;cdpport=a.cdp_port+index;free_port(serverport);free_port(cdpport)
  child=dict(env,GITHUB_WORKSPACE=str(clone),GEOMETRY_TEST_URL=f'http://127.0.0.1:{serverport}/',
   GEOMETRY_FEEDBACK_DIR=str(tmp/'feedback'),GEOMETRY_CHROME=str(a.chrome.resolve()),GEOMETRY_CHROME_FLAGS='--no-sandbox',
   GEOMETRY_CHROME_PROFILE=str(tmp/'chrome'),GEOMETRY_CDP_PORT=str(cdpport),P73_VARIANT=name)
  row={'phase':name,'expected_exit':1 if withdrawn else 0,'environment':{k:child.get(k) for k in SAFE},'passed':False}
  phases.append(row);process=None;streams=[];started=time.time()
  guard(clone,name+'-before',withdrawn)
  server_env=dict(child,GEO261_REAPER_LOG=str(phaseout/'server-reaper.jsonl'))
  argv=[sys.executable,'-B',out/'tools'/a.reaper.name,sys.executable,'-u',clone/'geometry-web/start_local.py',
        '--port',str(serverport),'--binary-dir',out/'tmp'/'native-runtime']
  server={'command':list(map(str,argv)),'cwd':str(clone),'sha':F,'variant':name,'started_epoch':started,
          'environment':{k:server_env.get(k) for k in SAFE}}
  save(phaseout/'server-request.json',server)
  try:
   streams=[(phaseout/'server.stdout.bin').open('wb'),(phaseout/'server.stderr.bin').open('wb')]
   process=subprocess.Popen(list(map(str,argv)),cwd=clone,env=server_env,stdin=subprocess.DEVNULL,stdout=streams[0],stderr=streams[1],start_new_session=True)
   recorder.env=child;ready=False
   for attempt in range(300):
    need(process.poll() is None,name+': server 提前結束')
    result,stdout,stderr=cmd([sys.executable,'-B',clone/'geometry-web/runtime_version.py','--probe',str(serverport)],clone,check=False,variant=name,timeout=10)
    if result['actual_process_returncode']==0:ready=True;break
    time.sleep(1)
   need(ready,name+': 原 runtime probe 未就緒')
   recorder.env=dict(child,GEO261_REAPER_LOG=str(phaseout/'node-reaper.jsonl'))
   row['node_environment']={k:recorder.env.get(k) for k in SAFE}
   result,stdout,stderr=cmd([sys.executable,'-B',out/'tools'/a.reaper.name,'node',out/'tools'/'probe.cjs',clone,phaseout],clone,check=False,variant=name,timeout=240)
   row['command_result']=result
   need((phaseout/'result.json').is_file(),name+': 缺 controlled result；不能當有效負控')
   actual=json.loads((phaseout/'result.json').read_text());row['probe_result']=actual
   reaped=[json.loads(x) for x in (phaseout/'node-reaper.jsonl').read_text().splitlines()]
   need(reaped[-1].get('event')=='完成' and reaped[-1].get('primary_returncode')==row['expected_exit'],name+': Node reaper 未完整回收或主退出碼不符')
   need(result['actual_process_returncode']==row['expected_exit'] and actual.get('actualProbeExit')==row['expected_exit'],name+': 真退出碼不符 0/1/0')
   need(actual.get('completed') is True and actual['callbackInvocations']==1 and actual['before']['originalPredicate'] is True,name+': callback 因果條件不成立')
   need(actual['uncaughtBrowserExceptions']==0 and actual['callbackSourceUnchanged'],name+': 額外例外或 callback 被改寫')
   need(actual['predicateValue'] is (not withdrawn),name+': 原 predicate 未呈現指定結果')
   if withdrawn:
    need(actual.get('assertionError')=='P73 assertion failed: '+actual['message']+' false',name+': 不是原具名斷言紅')
    need(actual['after']['hasNoShape'] is False and actual['after']['memberCount']=='0' and actual['after']['hasEmpty'] and actual['after']['emptyHasAction'],name+': 非原 SVG 假邊界病因')
   row['passed']=True
  finally:
   recorder.env=env
   if process is not None:
    if process.poll() is None:
     try:os.killpg(process.pid,signal.SIGTERM)
     except ProcessLookupError:pass
    try:process.wait(timeout=30)
    except subprocess.TimeoutExpired:
     server['cleanup_timeout']=True
     try:os.killpg(process.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     process.wait(timeout=10)
    server['actual_process_returncode']=process.returncode
   for stream in streams:stream.close()
   server['ended_epoch']=time.time()
   server['streams']={n:{'sha256':h((phaseout/n).read_bytes()),'bytes':(phaseout/n).stat().st_size} for n in ('server.stdout.bin','server.stderr.bin') if (phaseout/n).exists()}
   save(phaseout/'server-result.json',server);save(out/'receipt.json',receipt)
  reaped=[json.loads(x) for x in (phaseout/'server-reaper.jsonl').read_text().splitlines()]
  need(not server.get('cleanup_timeout') and reaped[-1].get('event')=='完成',name+': server reaper 未完整回收')
  guard(clone,name+'-after',withdrawn)
 lock=a.heavy_lock.open('a+b')
 try:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  guard(repo,'original-before');original.update({rel:h((repo/rel).read_bytes()) for rel in INPUTS})
  source_runtime=complete_runtime_inventory(repo,F,lambda *v:git(repo,*v));save(out/'source-runtime-inputs.json',source_runtime)
  fixed=git(repo,'show',F+':'+APP)
  need(h(fixed)==original[APP] and fixed.count(FIXED)==1 and fixed.count(OLD)==0,'固定 guard bytes 不符')
  receipt['original_inputs']=dict(original)
  for argv in ([str(a.chrome.resolve()),'--version'],['node','--version'],[sys.executable,'--version'],['cc','--version']):cmd(argv)
  clone.parent.mkdir(parents=True,exist_ok=True)
  cmd(['git','clone','--shared','--no-hardlinks','--no-checkout',repo,clone],out)
  git(clone,'sparse-checkout','init','--no-cone')
  git(clone,'sparse-checkout','set','--no-cone','/*','!/evidence/','!/tests/evidence/')
  git(clone,'checkout','--detach',F);guard(clone,'clone-created')
  clone_runtime=complete_runtime_inventory(clone,F,lambda *v:git(clone,*v));save(out/'clone-runtime-inputs.json',clone_runtime)
  need(same_runtime_identity(source_runtime,clone_runtime),'稀疏clone不得遺失或改變任一RuntimeSnapshot輸入')
  for index,(name,withdrawn) in enumerate((('fixed',False),('withdrawn',True),('restored',False))):
   (clone/APP).write_bytes(fixed.replace(FIXED,OLD,1) if withdrawn else fixed)
   phase(index,name,withdrawn)
  receipt['passed']=all(x['passed'] for x in phases) and len(phases)==3
 except BaseException:
  errors.append(traceback.format_exc())
 finally:
  if fixed is not None and clone.is_dir():
   try:
    need((clone/APP).is_file(),'clone checkout 未完成，沒有 APP 可還原')
    (clone/APP).write_bytes(fixed)
    guard(clone,'clone-restored-final')
   except BaseException:errors.append(traceback.format_exc())
  try:
   guard(repo,'original-after')
   final_runtime=complete_runtime_inventory(repo,F,lambda *v:git(repo,*v));save(out/'source-after-runtime-inputs.json',final_runtime)
   need(same_runtime_identity(source_runtime,final_runtime),'來源RuntimeSnapshot輸入在執行中改變')
  except BaseException:errors.append(traceback.format_exc())
  for path,digest in frozen.items():
   if h(Path(path).read_bytes())!=digest:errors.append('工具執行時變動：'+path)
  receipt['passed']=receipt['passed'] and not errors
  receipt['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'receipt.json',receipt)
  resource.setrlimit(resource.RLIMIT_STACK,(soft,hard));lock.close()
 print(json.dumps({'passed':receipt['passed'],'scope':receipt['scope'],'receipt':str(out/'receipt.json'),'errors':errors},ensure_ascii=False))
 return 0 if receipt['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
