"""Prepare one fresh sparse historical main checkout; never build or measure it."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import traceback

from runtime_inventory import complete_runtime_inventory

MAIN = 'adbaebf9c73ea6801d7b4d5214e4b846b132923b'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
CAPTURE_HASH = 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--acceptance-sha', required=True)
p.add_argument('--dest', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
source, dest, out = a.source.resolve(), a.dest.resolve(), a.out.resolve()
assert re.fullmatch('[0-9a-f]{40}', a.acceptance_sha)
assert source.is_dir() and not dest.exists() and not out.exists() and dest.name == 'main'
assert not dest.is_relative_to(source) and not source.is_relative_to(dest)
assert not out.is_relative_to(source) and not out.is_relative_to(dest)
assert hashlib.sha256(CAPTURE.read_bytes()).hexdigest() == CAPTURE_HASH
out.mkdir(parents=True)
spec = importlib.util.spec_from_file_location('original_capture', CAPTURE)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
r = capture.Recorder(out, env, a.acceptance_sha)
report = {'schema': 'geo288-fixed-main-sparse-preparation/1', 'acceptance_sha': a.acceptance_sha,
          'reference_sha': MAIN, 'source': str(source), 'destination': str(dest),
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'build_executed': False, 'test_executed': False, 'benchmark_executed': False,
          'sparse_exclusions': ['evidence/', 'tests/evidence/'], 'exit_code': None}

def git(repo, *args):
    return r.run(['git', *args], cwd=repo, timeout=120, source_sha=MAIN if repo == dest else a.acceptance_sha,
                 source_variant='main-reference-preparation-only')[1]

def snapshot():
    head = git(source, 'rev-parse', 'HEAD').decode().strip()
    status = git(source, 'status', '--porcelain=v1', '--untracked-files=all')
    index = git(source, 'ls-files', '--stage', '-z')
    return {'head': head, 'status': status.decode(), 'index_sha256': hashlib.sha256(index).hexdigest()}

try:
    before = snapshot()
    report['source_before'] = before
    assert before['head'] == a.acceptance_sha and before['status'] == ''
    assert git(source, 'rev-parse', MAIN + '^{commit}').decode().strip() == MAIN
    dest.parent.mkdir(parents=True, exist_ok=True)
    r.run(['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(source), str(dest)],
          cwd=source, timeout=120, source_variant='main-reference-preparation-only')
    git(dest, 'sparse-checkout', 'init', '--no-cone')
    git(dest, 'sparse-checkout', 'set', '--no-cone', '/*', '!/evidence/', '!/tests/evidence/')
    git(dest, '-c', 'core.autocrlf=false', 'checkout', '--detach', MAIN)
    inventory = complete_runtime_inventory(dest, MAIN, lambda *args: git(dest, *args))
    capture.dump(out / 'MAIN_RUNTIME_INPUTS.json', inventory)
    report['main_runtime_input_count'] = inventory['actual_count']
    report['main_runtime_source_version'] = inventory['source_version']
    report['source_after'] = snapshot()
    assert report['source_after'] == before
    report.update(exit_code=0, prepared=True,
                  classification='only clone/checkout and read-only input identity checks; no build or acceptance result')
except Exception:
    report.update(exit_code=1, error=traceback.format_exc())
finally:
    tools = out / 'tools'
    tools.mkdir(exist_ok=True)
    for path in [Path(__file__).resolve(), Path(__file__).resolve().parent / 'runtime_inventory.py', CAPTURE]:
        shutil.copy2(path, tools / path.name)
    report.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=r.rows)
    capture.dump(out / 'receipt.json', report)
print(json.dumps({k: v for k, v in report.items() if k != 'commands'}, ensure_ascii=False))
raise SystemExit(report['exit_code'])
