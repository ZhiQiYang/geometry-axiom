"""Record isolated final-F source preparation with the original c387 recorder."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

F = '3d681636902371ecc528b20f51eea33e272581c9'
OWNER = Path('/workspace/geo288-p73-owner-20261023')
ORIGINAL = Path('/tmp/g288p88final-3d681636')
DEST = OWNER / 'source-3d681636'
OUT = OWNER / 'source-preparation'
CAPTURE = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
digest = lambda raw: hashlib.sha256(raw).hexdigest()
if DEST.exists() or OUT.exists():
    raise RuntimeError('Preparation paths must be fresh')
if digest(CAPTURE.read_bytes()) != 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':
    raise RuntimeError('Original c387 capture changed')
OUT.mkdir()
spec = importlib.util.spec_from_file_location('geo288_p73_source_capture', CAPTURE)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
for key in ['NODE_OPTIONS', 'PYTHONOPTIMIZE', 'GEO261_P73_UNDER_REAPER']:
    env.pop(key, None)
r = cap.Recorder(OUT, env, F)
receipt = {'schema': 'geo288-p73-final-source-preparation/1', 'sha': F, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': str(ORIGINAL), 'dest': str(DEST), 'commands': r.rows, 'build_executed': False, 'test_executed': False, 'capture_sha256': digest(CAPTURE.read_bytes()), 'source_preparer_sha256': digest(Path(__file__).read_bytes()), 'exit_code': None}


def run(argv, cwd=ORIGINAL):
    return r.run(list(map(str, argv)), cwd=cwd, timeout=180, source_sha=F, source_variant='p73-isolated-source-preparation')[1]


def identity(repo):
    head = run(['git', 'rev-parse', 'HEAD'], repo).decode().strip()
    status = run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], repo)
    stage = run(['git', 'ls-files', '--stage', '-z'], repo)
    if head != F or status:
        raise RuntimeError('Fixed source must be clean')
    return {'head': head, 'status': status.decode(), 'index_sha256': digest(stage), 'index_bytes': len(stage)}


try:
    receipt['source_before'] = identity(ORIGINAL)
    for label, path in [('tmp', '/tmp'), ('workspace', '/workspace')]:
        v = os.statvfs(path)
        receipt[label + '_available_bytes_before'] = v.f_bavail * v.f_frsize
    run(['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', ORIGINAL, DEST], OWNER)
    run(['git', 'sparse-checkout', 'init', '--no-cone'], DEST)
    run(['git', 'sparse-checkout', 'set', '--no-cone', '/*', '!/evidence/', '!/tests/evidence/'], DEST)
    run(['git', '-c', 'core.autocrlf=false', 'checkout', '--detach', F], DEST)
    run(['git', 'remote', 'set-url', 'origin', 'https://github.com/ZhiQiYang/geometry-axiom.git'], DEST)
    receipt['destination_after'] = identity(DEST)
    receipt['source_after'] = identity(ORIGINAL)
    if not receipt['source_before'] == receipt['source_after'] == receipt['destination_after']:
        raise RuntimeError('Independent checkout changed final source/index')
    receipt['working_materialization_bytes'] = int(run(['du', '-sb', '--exclude=.git', DEST], OWNER).decode().split()[0])
    # Capacity observation, not a replacement for original subject guards.
    for label, path in [('tmp', '/tmp'), ('workspace', '/workspace')]:
        v = os.statvfs(path)
        receipt[label + '_available_bytes_after'] = v.f_bavail * v.f_frsize
    receipt['exit_code'] = 0
except BaseException as error:
    receipt['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    receipt['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ['commands', 'error']}, ensure_ascii=False))
