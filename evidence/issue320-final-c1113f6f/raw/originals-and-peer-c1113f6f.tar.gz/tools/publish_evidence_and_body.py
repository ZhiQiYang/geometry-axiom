from pathlib import Path
import hashlib, importlib.util, io, json, os, tarfile, time

B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
S = 'c1113f6fd6c52a55d7df1a30ecd1684fe87b661c'
BRANCH = 'codex/issue320-connection-recovery-20261024'
PREFIX = 'evidence/issue320-final-c1113f6f'
O = B / 'evidence-publication'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', H)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TMPDIR'] = str(B / 'tmp')
rec = cap.Recorder(O, env, S)
sha = lambda b: hashlib.sha256(b).hexdigest()
proof = json.loads((B / 'fixed-source-proof-c1113f6f/RESULT.json').read_bytes())
assert proof['sourceSHA'] == S and proof['proofAccepted'] and proof['originalExits'] == [0, 1, 0]
peer_path = B / 'ACTUAL_PEER_PATH.json'
peer_binding = json.loads(peer_path.read_bytes())
peer_report = Path(peer_binding['path'])
assert sha(peer_report.read_bytes()) == peer_binding['sha256']
peer = json.loads(peer_report.read_bytes())
assert not peer.get('findings')
cap.dump(O / 'REQUEST.json', {'sourceSHA': S, 'branch': BRANCH, 'evidencePrefix': PREFIX, 'driverSHA256': sha(Path(__file__).read_bytes()), 'publicationOnly': True, 'subjectTestExecution': False, 'peerBinding': peer_binding})
_, raw, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
assert raw.decode().strip() == S
_, status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert status == b''

originals = {}
for directory in ['preparation', 'preparation-r2', 'preparation-r3', 'source-publication', 'source-publication-r2', 'fixed-source-proof-c1113f6f']:
    for path in (B / directory).rglob('*'):
        if path.is_file():
            originals['originals/' + directory + '/' + path.relative_to(B / directory).as_posix()] = path
for name in ['prepare_thin.py', 'materialize_thin_r2.py', 'complete_preparation_r3.py', 'commit_source.py', 'resume_source_publication_r2.py', 'run_fixed_source_proof.py', 'publish_evidence_and_body.py']:
    originals['tools/' + name] = B / name
originals['tools/capture.py'] = H
originals['authority/issue-320.json'] = Path('/tmp/geo324-owner-20261024/open-issues-triage-r2/batch-01/issue-320.json')
originals['peer/ACTUAL_PEER.json'] = peer_report
originals['peer/ACTUAL_PEER_PATH.json'] = peer_path
for path in peer_report.parent.rglob('*'):
    if path.is_file():
        originals['peer/actual/' + path.relative_to(peer_report.parent).as_posix()] = path
static_peer = Path('/workspace/cache-terminal-preflight-20261023/issue320-static-peer/REVIEW.json')
if static_peer.is_file():
    originals['peer/CANDIDATE_STATIC_PEER.json'] = static_peer
inventory = [{'member': name, 'originalPath': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for name, path in sorted(originals.items())]
dest = W / PREFIX
(dest / 'raw').mkdir(parents=True)
archive = dest / 'raw/originals-and-peer-c1113f6f.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for name, path in sorted(originals.items()):
        payload = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        info.mtime = 0
        tf.addfile(info, io.BytesIO(payload))
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(inventory)
    for item in inventory:
        payload = tf.extractfile(item['member']).read()
        assert len(payload) == item['bytes'] and sha(payload) == item['sha256'] and payload == Path(item['originalPath']).read_bytes()
cap.dump(dest / 'RAW_INVENTORY.json', inventory)
cap.dump(dest / 'PACKAGE.json', {'sourceSHA': S, 'archive': archive.relative_to(dest).as_posix(), 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive.read_bytes()), 'members': len(inventory), 'inventorySHA256': sha((dest / 'RAW_INVENTORY.json').read_bytes()), 'roundtripAllOriginalBytes': True, 'notGlobalAcceptance': True})
current = {'productSHA': S, 'executionSHA': S, 'originalNodeCommand': ['node', '--test', '--test-reporter=spec', 'tests/test_connection_recovery.js'], 'originalNodeExits': [0, 1, 0], 'originalMethodCountEachPhase': 9, 'originalSkippedEachPhase': 0, 'withdrawnNormalAssertionFailures': 3, 'proofReceiptSHA256': sha((B / 'fixed-source-proof-c1113f6f/RESULT.json').read_bytes()), 'unitProof': 'PASS; exact original function spans with explicit substitutes, not browser', 'P53P61RealBrowser': 'UNRUN', 'fullCanvas': 'UNRUN', 'otherFiveBrowserJobs': 'UNRUN', 'fullNative': 'UNRUN', 'mutationCheck': 'UNRUN; root owns final complete ledger', 'architectureOriginalThreeAndDerivedFour': 'UNRUN; root owns final source impact/refresh', 'goldenEdited': False, 'fullLedgerWrittenByThisOwner': False, 'peer': peer_binding, 'outerCaptureLimit': 'Proof driver process0 came from original host exec result; no separate prelaunched outer c387 stream. All three Node CLI streams and original exits are separately captured.'}
cap.dump(dest / 'CURRENT_STATE.json', current)
(dest / 'PROGRESS.md').write_text(
    '# #320 進度' + chr(10) * 2 +
    '產品／原實跑 SHA：`' + S + '`。成功恢復時清除舊錯誤；失敗路徑與 P53/P61 原守門保留，三原 browser predicates 只加強 error 空值，golden／計數／時限未改。' + chr(10) * 2 +
    '定向 9 原函式 VM 單元：原 Node exits 0／1／0；撤回精確唯一產品 clear 後 3 個正常具名 ERR_ASSERTION，前後各 9 pass，全部 0 skip。完整 source、17 個 proof 命令／stdout／stderr／環境、五 Git inputs、source diff 與還原驗證已封；獨立 actual peer 見 CURRENT_STATE。' + chr(10) * 2 +
    '原 setup sparse literal\\n、feedback import、首次 git add sparse 拒絕等原失敗完整保留，並由限定補正完成；不冒產品測試通過。' + chr(10) * 2 +
    '未跑：真 P53/P61 UI、full canvas／其餘 browser、完整 native、mutate --check、架構三原裁判／四檔重產。此 owner 未產全帳本，完整 canvas 待 root 獨占排程；VM collaborators 是明示替身，不能代實際瀏覽器。' + chr(10) * 2 +
    '下一步：root 合流此固定產品來源、按 closure 更新原帳本／架構與正式裁判；保本單原 execution SHA，不能冒後續 evidence head 已重新實測。' + chr(10), encoding='utf-8')
manifest = [{'path': p.relative_to(dest).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(dest.rglob('*')) if p.is_file()]
cap.dump(dest / 'MANIFEST.json', {'scope': 'All other files in this prefix; excludes this MANIFEST.json to avoid self-index recursion', 'files': manifest})
rec.run(['git', 'add', '--force', '--sparse', '--', PREFIX], cwd=W)
_, staged, _ = rec.run(['git', 'diff', '--cached', '--name-only'], cwd=W)
assert staged and all(p.startswith(PREFIX + '/') for p in staged.decode().splitlines())
rec.run(['git', 'diff', '--cached', '--check'], cwd=W)
rec.run(['git', 'commit', '-m', 'evidence: archive issue 320 recovery proof and pending gates'], cwd=W)
_, raw, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
evidence = raw.decode().strip()
rec.run(['git', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH], cwd=W)
_, raw, _ = rec.run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + BRANCH], cwd=W)
assert raw.decode().split()[0] == evidence
cap.dump(O / 'RESULT.json', {'sourceSHA': S, 'evidenceSHA': evidence, 'branch': BRANCH, 'normalPushExit': 0, 'remoteEqual': True, 'prefix': PREFIX, 'archiveSHA256': sha(archive.read_bytes()), 'peerBinding': peer_binding})
print(json.dumps({'sourceSHA': S, 'evidenceSHA': evidence, 'prefix': PREFIX, 'archiveSHA256': sha(archive.read_bytes())}))
