from pathlib import Path
import ast, hashlib, importlib.util, json, os
B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
O = B / 'source-publication'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', H)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
base = '2d1570691e4a29aafebdc0a4e739787d3fcdddaa'
branch = 'codex/issue320-connection-recovery-20261024'
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TMPDIR'] = str(B / 'tmp')
rec = cap.Recorder(O, env, base)
paths = ['geometry-web/app.js', 'geometry-web/cdp_test.js', 'tests/test_connection_recovery.js', 'tests/run_all.py', 'tests/run_all.expected.json']
cap.dump(O / 'REQUEST.json', {'baseSHA': base, 'branch': branch, 'paths': paths, 'driverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'kind': 'source syntax/limited-diff/normal commit and push; no semantic test execution'})
_, raw, _ = rec.run(['git', 'show', base + ':tests/run_all.expected.json'], cwd=W)
before = json.loads(raw)
after = json.loads((W / 'tests/run_all.expected.json').read_bytes())
assert after['suites'].pop('node:connection_recovery') == {'mode': 'count', 'count': 9, 'unit': 'node test'}
assert after == before
ast.parse((W / 'tests/run_all.py').read_text())
for name in ['geometry-web/app.js', 'geometry-web/cdp_test.js', 'tests/test_connection_recovery.js']:
    rec.run(['node', '--check', name], cwd=W)
rec.run(['git', 'diff', '--check'], cwd=W)
rec.run(['git', 'diff', '--stat'], cwd=W)
rec.run(['git', 'diff', '--', *paths], cwd=W)
rec.run(['git', 'add', '--', *paths], cwd=W)
_, staged, _ = rec.run(['git', 'diff', '--cached', '--name-only'], cwd=W)
assert set(staged.decode().splitlines()) == set(paths)
rec.run(['git', 'commit', '-m', 'fix: clear stale connection errors after successful recovery'], cwd=W)
_, raw, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
source = raw.decode().strip()
_, status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert status == b''
rec.run(['git', 'push', 'origin', 'HEAD:refs/heads/' + branch], cwd=W)
_, raw, _ = rec.run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch], cwd=W)
assert raw.decode().split()[0] == source
cap.dump(O / 'RESULT.json', {'sourceSHA': source, 'baseSHA': base, 'normalPushExit': 0, 'remoteEqual': True, 'sourceClean': True, 'semanticProof': 'UNRUN pending fixed-source baseline/withdraw/restore', 'fullCanvas': 'UNRUN', 'fullLedgerWritten': False})
print(json.dumps({'sourceSHA': source, 'branch': branch, 'remoteEqual': True, 'semanticProof': 'UNRUN'}))
