from pathlib import Path
import hashlib, importlib.util, json, os
B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
O = B / 'source-publication-r2'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', H)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TMPDIR'] = str(B / 'tmp')
base = '2d1570691e4a29aafebdc0a4e739787d3fcdddaa'
branch = 'codex/issue320-connection-recovery-20261024'
r = cap.Recorder(O, env, base)
cap.dump(O / 'REQUEST.json', {'baseSHA': base, 'kind': 'Resume exact authorized five-file source publication; initial git add rejected new test outside sparse pattern; original exit1 retained, no subject test ran', 'driverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
r.run(['git', 'sparse-checkout', 'add', '--stdin'], cwd=W, data=('/tests/test_connection_recovery.js' + chr(10)).encode())
paths = ['geometry-web/app.js', 'geometry-web/cdp_test.js', 'tests/test_connection_recovery.js', 'tests/run_all.py', 'tests/run_all.expected.json']
r.run(['git', 'add', '--sparse', '--', *paths], cwd=W)
_, raw, _ = r.run(['git', 'diff', '--cached', '--name-only'], cwd=W)
assert set(raw.decode().splitlines()) == set(paths)
r.run(['git', 'diff', '--cached', '--check'], cwd=W)
r.run(['git', 'commit', '-m', 'fix: clear stale connection errors after successful recovery'], cwd=W)
_, raw, _ = r.run(['git', 'rev-parse', 'HEAD'], cwd=W)
source = raw.decode().strip()
_, status, _ = r.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert status == b''
r.run(['git', 'push', 'origin', 'HEAD:refs/heads/' + branch], cwd=W)
_, raw, _ = r.run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch], cwd=W)
assert raw.decode().split()[0] == source
cap.dump(O / 'RESULT.json', {'sourceSHA': source, 'baseSHA': base, 'normalPushExit': 0, 'remoteEqual': True, 'sourceClean': True, 'semanticProof': 'UNRUN pending fixed-source baseline/withdraw/restore', 'fullCanvas': 'UNRUN', 'fullLedgerWritten': False})
print(json.dumps({'sourceSHA': source, 'branch': branch, 'remoteEqual': True, 'semanticProof': 'UNRUN'}))
