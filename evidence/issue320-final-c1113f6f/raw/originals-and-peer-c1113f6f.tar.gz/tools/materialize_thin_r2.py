from pathlib import Path
import hashlib, importlib.util, json, os, time

B = Path('/workspace/issue320-20261024')
O = B / 'preparation-r2'
W = Path('/workspace/issue320-work-20261024')
BASE = '2d1570691e4a29aafebdc0a4e739787d3fcdddaa'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', H)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['LC_ALL'] = 'C.UTF-8'
env['TMPDIR'] = str(B / 'tmp')
r = cap.Recorder(O, env, BASE)
paths = ['AGENTS.md', '.gitignore', 'package.json', 'geometry-web/app.js',
         'geometry-web/cdp_test.js', 'geometry-web/cdp_sections.golden.json',
         'tests/run_all.py', 'tests/run_all.expected.json',
         'geometry-web/feedback_cli.py', 'geometry-guide/PRODUCT-VISION.md']
patterns = (chr(10).join('/' + p for p in paths) + chr(10)).encode()
cap.dump(O / 'REQUEST.json', {
    'source': BASE,
    'correction': 'First sparse pattern payload used literal backslash-n, selected no files; original source/commands retained. This run supplies actual newline bytes and guards all selected files.',
    'driverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'selectedPaths': paths,
})
r.run(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=W, data=patterns)
r.run(['git', 'read-tree', '-mu', 'HEAD'], cwd=W)
inventory = []
for path in paths:
    row, raw, err = r.run(['git', 'show', BASE + ':' + path], cwd=W)
    actual = (W / path).read_bytes()
    assert actual.replace(bytes([13, 10]), bytes([10])) == raw.replace(bytes([13, 10]), bytes([10])), path
    inventory.append({'path': path, 'physicalBytes': len(actual), 'physicalSHA256': hashlib.sha256(actual).hexdigest(), 'gitSHA256': hashlib.sha256(raw).hexdigest()})
row, head, err = r.run(['git', 'rev-parse', 'HEAD'], cwd=W)
assert head.decode().strip() == BASE
row, status, err = r.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert status == b''
r.run(['python3', '-B', 'geometry-web/feedback_cli.py', 'list'], cwd=W)
cap.dump(O / 'RESULT.json', {'source': BASE, 'endedEpoch': time.time(), 'inventory': inventory, 'sourceClean': True, 'subjectTestExecuted': False})
print(json.dumps({'source': BASE, 'paths': len(inventory), 'sourceClean': True, 'actualReadExits': [x['actual_process_returncode'] for x in r.rows]}))
