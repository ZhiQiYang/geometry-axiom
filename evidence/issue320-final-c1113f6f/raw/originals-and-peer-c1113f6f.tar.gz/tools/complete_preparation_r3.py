from pathlib import Path
import hashlib, importlib.util, json, os
B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
O = B / 'preparation-r3'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s = importlib.util.spec_from_file_location('cap', H)
c = importlib.util.module_from_spec(s)
s.loader.exec_module(c)
e = dict(os.environ)
e.pop('PYTHONOPTIMIZE', None)
e.pop('NODE_OPTIONS', None)
e['PYTHONDONTWRITEBYTECODE'] = '1'
e['TMPDIR'] = str(B / 'tmp')
base = '2d1570691e4a29aafebdc0a4e739787d3fcdddaa'
r = c.Recorder(O, e, base)
r.run(['git', 'sparse-checkout', 'add', '--stdin'], cwd=W, data=('/geometry-web/feedback_store.py' + chr(10)).encode())
_, raw, _ = r.run(['git', 'show', base + ':geometry-web/feedback_store.py'], cwd=W)
assert (W / 'geometry-web/feedback_store.py').read_bytes() == raw
_, stdout, _ = r.run(['python3', '-B', 'geometry-web/feedback_cli.py', 'list'], cwd=W)
_, status, _ = r.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert status == b''
c.dump(O / 'RESULT.json', {'source': base, 'sourceClean': True, 'feedbackCLIActualExit': r.rows[2]['actual_process_returncode'], 'feedbackCLIScope': 'This isolated thin cloud worktree only; does not assert private user feedback is empty.', 'subjectTestsExecuted': False, 'preservedSetupHistory': ['preparation', 'preparation-r2'], 'helperOnlyAddition': 'geometry-web/feedback_store.py'})
print(stdout.decode())
print('PREPARATION_R3_COMPLETE')
