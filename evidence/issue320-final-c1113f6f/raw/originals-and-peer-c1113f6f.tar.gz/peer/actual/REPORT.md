# #320 source 與定向原輸出獨立審查

固定來源 c1113f6fd6c52a55d7df1a30ecd1684fe87b661c，281 項 metadata/Git/原始串流檢查，checker exit 0、findings=[]。未執行任何 subject、Node test 或 driver。

核實 Git 單親為 train 2d157069，commit 僅五個指定檔案。產品唯一修改是在 recoverConnection 完成各讀取且未有 error 後清空舊 connection.error；原失敗 return/catch 與 latch finally 未變。P53/P61 只追加 error 空字串斷言，原 browser check census、幾何與來源條件原樣；registry 僅新增 pure Node suite、expected 僅新增九例，其餘逐值相同。

原 17 個 c387 commands 的 request/result/stdin/stdout/stderr 全量 hash/size 與 SHA 綁定吻合；五個 source 完整 bytes 等於固定 Git。三個 Node 真退出 0/1/0，原測試 9/9→6/9→9/9、零 skip/cancel。撤回檔精確等於僅去掉唯一 ready 清 error 語句，三個失敗各為具名正常 ERR_ASSERTION；baseline/restored app hash 相同、前後 HEAD/stage/clean 原紀錄均相同。

限制：這是執行真原函式 span 的 VM 單元測試，DOM、transport 與工作區 collaborators 為明示替身；不能當作 browser/HTTP/native/full-canvas/full-ledger 通過。producer 最外層只有工具觀察到 exit 0，沒有獨立 c387 outer streams；17 個 child 原 streams 完整。publication 僅核 producer 原結果普通 push/remoteEqual，不聲稱本 reviewer 自發重新連網。

reviewer 首版 checker 對 P53/P61 做了過廣字串替換，導致自身一項 false finding、exit 1；INITIAL_CHECKS.json 與初版 script 保留。後續精確限定 P53 anchor 與兩個 P61 指定 occurrence，checker 0；不改 subject，不重測。中間第二次 checker 同 finding 的工具退出 1 僅在對話記錄，沒有獨立 pipe capture。最初啟動 exec transport disconnected，未建立檔案，另於對話保留。
