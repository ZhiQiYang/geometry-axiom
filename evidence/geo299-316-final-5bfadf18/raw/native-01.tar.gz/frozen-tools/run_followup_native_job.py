"""Run the unchanged native workflow job at one fixed follow-up SHA, retaining its original result."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import traceback

ENV = Path('/workspace/geo261-environment')
JOBS = ('native',)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--sha', required=True)
parser.add_argument('--out', required=True, type=Path)
parser.add_argument('--heavy-lock', required=True, type=Path)
parser.add_argument('--publication-repo', type=Path)
parser.add_argument('--publication-branch')
parser.add_argument('--issue')
args = parser.parse_args()
repo, out = args.repo.resolve(), args.out.resolve()
assert len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha)
assert out.is_relative_to(Path('/tmp')) and not out.is_relative_to(repo) and not out.exists()
assert os.environ.get('PYTHONOPTIMIZE') in (None, '', '0')
assert bool(args.publication_repo) == bool(args.publication_branch) == bool(args.issue)
out.mkdir(parents=True)
(out / 'tools').mkdir()
(out / 'launch').mkdir()
hashfile = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = [Path(__file__).resolve(), ENV / 'run_workflow_round.py', ENV / 'reap_children.py', ENV / 'run_acceptance_seven_configured.py']
if args.publication_repo:
    paths.append(ENV / 'publish_followup_progress.py')
frozen = {p.name: hashfile(p) for p in paths}
for p in paths:
    shutil.copy2(p, out / 'tools' / p.name)
spec = importlib.util.spec_from_file_location('original_receipt_validator', out / 'tools/run_acceptance_seven_configured.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
resource.setrlimit(resource.RLIMIT_STACK, (16777216, hard))
report = {'schema': 'geometry-followup-native-workflow/1', 'source_sha': args.sha, 'repo': str(repo), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tool_hashes': frozen, 'stack_before': [soft, hard], 'stack_during': resource.getrlimit(resource.RLIMIT_STACK), 'jobs': [], 'policy': 'One original native workflow job; preserve its failure, original CI limit and complete command streams. Six browser jobs are recorded separately at the same SHA. No automatic retry or product edits.'}
(out / 'run-context.json').write_text(json.dumps(dict(report, publication_repo=str(args.publication_repo) if args.publication_repo else None, publication_branch=args.publication_branch, issue=args.issue), ensure_ascii=False, indent=2) + '\n')
def save():
    p = out / 'receipt.json.writing'
    p.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    p.replace(out / 'receipt.json')
save()
with args.heavy_lock.open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    # Preserve the completed predecessor cache before the original native runner starts.
    previous = Path('/tmp/geometry-tests')
    retained = Path('/tmp') / ('geometry-tests-pre-followup-' + str(args.issue or 'local') + '-' + args.sha[:8])
    inventory = []
    if previous.exists():
        assert previous.is_dir() and not previous.is_symlink() and not retained.exists()
        for path in sorted(previous.rglob('*')):
            if path.is_file() and not path.is_symlink():
                inventory.append({'path': path.relative_to(previous).as_posix(), 'bytes': path.stat().st_size, 'sha256': hashfile(path)})
        previous.rename(retained)
    cache = {'action': 'rename completed predecessor cache; original retained without deletion', 'from': str(previous), 'to': str(retained) if inventory else None, 'files': inventory, 'source_sha': args.sha}
    (out / 'native-cache-isolation.json').write_text(json.dumps(cache, ensure_ascii=False, indent=2) + '\n')
    for job in JOBS:
        row = {'job': job, 'sha': args.sha, 'exit_code': None, 'derived_pass': False, 'errors': []}
        report['jobs'].append(row)
        launch = out / 'launch'
        command = ['python3', '-B', str(out / 'tools/reap_children.py'), 'python3', '-B', str(out / 'tools/run_workflow_round.py'), '--repo', str(repo), '--sha', args.sha, '--job', job, '--out-root', str(out / 'workflow')]
        row.update(command=command, cwd=str(repo), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), receipt=str(out / 'workflow' / job / 'receipt.json'))
        save()
        try:
            assert all(hashfile(p) == frozen[p.name] for p in paths)
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GEO261_REAPER_LOG=str(launch / f'{job}-reaper.jsonl'))
            with (launch / f'{job}.stdout').open('xb') as stdout, (launch / f'{job}.stderr').open('xb') as stderr:
                result = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
            row['exit_code'] = result.returncode
            raw = json.loads(Path(row['receipt']).read_text())
            validator.validate_receipt(raw, row, repo, args.sha, job, frozen)
            row.update(receipt_validated=True, inner_exit_code=raw['exit_code'], seconds=raw['seconds'], ci_timeout_minutes=raw['ci_timeout_minutes'], over_ci_timeout=raw['over_ci_timeout'], status=raw['status'])
            row['derived_pass'] = result.returncode == 0 and raw['exit_code'] == 0 and raw['status'] == '完成' and not raw['over_ci_timeout']
        except Exception:
            row['errors'].append(traceback.format_exc())
        row['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        if args.publication_repo:
            pub = ['python3', '-B', str(out / 'tools/publish_followup_progress.py'), '--repo', str(args.publication_repo), '--branch', args.publication_branch, '--issue', args.issue, '--sha', args.sha, '--label', job,
                   '--result', f"原退出{row['exit_code']}；原收據有效={row.get('receipt_validated', False)}；超CI時限={row.get('over_ci_timeout')}；衍生通過={row['derived_pass']}",
                   '--next', '繼續剩餘原工作項；收齊全部紅燈後集中分類，沒有自動重抽',
                   '--input', 'context=' + str(out / 'run-context.json'), '--input', 'frozen-tools=' + str(out / 'tools'), '--input', 'native-cache-isolation=' + str(out / 'native-cache-isolation.json')]
            candidates = [('job', out / 'workflow' / job), ('job-temp', out / 'tmp/workflow' / job), ('launch-stdout', launch / f'{job}.stdout'), ('launch-stderr', launch / f'{job}.stderr'), ('reaper', launch / f'{job}-reaper.jsonl')]
            for label, path in candidates:
                if path.exists():
                    pub += ['--input', label + '=' + str(path)]
            if Path(row['receipt']).is_file():
                pub += ['--receipt', row['receipt']]
            row['publication_command'] = pub
            try:
                with (launch / f'{job}.publish.stdout').open('xb') as stdout, (launch / f'{job}.publish.stderr').open('xb') as stderr:
                    published = subprocess.run(pub, cwd=args.publication_repo, stdout=stdout, stderr=stderr)
                row['progress_publish_exit'] = published.returncode
            except Exception:
                row['progress_publish_exit'] = None
                row['errors'].append(traceback.format_exc())
            save()
        print(json.dumps({'job': job, 'actual_process_returncode': row['exit_code'], 'derived_pass': row['derived_pass'], 'errors': row['errors']}, ensure_ascii=False), flush=True)
report['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report['exit_code'] = int(not all(row['derived_pass'] and not row['errors'] and (not args.publication_repo or row.get('progress_publish_exit') == 0) for row in report['jobs']))
save()
raise SystemExit(report['exit_code'])
