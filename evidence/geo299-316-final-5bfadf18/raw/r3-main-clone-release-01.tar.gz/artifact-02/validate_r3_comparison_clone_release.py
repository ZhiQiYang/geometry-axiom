"""Validate one completed comparison clone; delete only with explicit --release.

The default invocation never removes or moves anything.  It preserves the same
receipt layout as the earlier cold comparison clone release and adds complete
public-reachability and live process/fd guards.  No product test is executed.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import traceback

REPO = Path('/tmp/g261r3/work/p52-main/main')
RUNTIME = REPO.parent
ROUND = Path('/tmp/g261r3')
PUBLIC = Path('/workspace/geometry-axiom')
EXPECTED = 'adbaebf9c73ea6801d7b4d5214e4b846b132923b'
BRANCH = 'architecture/geo261-integration-20261016'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def below(path, root):
    return path == str(root) or path.startswith(str(root) + '/')


def inventory(roots):
    rows = []
    for root in roots:
        assert root.is_dir() and not root.is_symlink(), str(root)
        for directory, dirs, files in os.walk(root, followlinks=False):
            dirs.sort()
            for name in sorted(dirs + files):
                path = Path(directory) / name
                before = path.lstat()
                row = {'path': str(path), 'mode': stat.S_IMODE(before.st_mode)}
                if path.is_symlink():
                    row['symlink'] = os.readlink(path)
                elif path.is_file():
                    data = path.read_bytes()
                    row.update(bytes=len(data), sha256=digest(data))
                else:
                    assert path.is_dir(), str(path)
                    row['directory'] = True
                after = path.lstat()
                assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
                    after.st_ino, after.st_size, after.st_mtime_ns), str(path)
                rows.append(row)
    return rows


def process_users():
    """Fail closed when any live process's cwd/exe/fd cannot be inspected."""
    own_pid = os.getpid()
    matches, denied, inspected, zombies, vanished = [], [], 0, 0, 0
    for proc in sorted(Path('/proc').iterdir(), key=lambda p: p.name):
        if not proc.name.isdigit() or int(proc.name) == own_pid:
            continue
        pid = int(proc.name)
        try:
            state = (proc / 'stat').read_text().rsplit(') ', 1)[1][0]
            if state == 'Z':
                zombies += 1
                continue
            cmd = (proc / 'cmdline').read_bytes().split(b'\0')
            command_matches = [os.fsdecode(arg) for arg in cmd
                               if os.fsencode(str(REPO)) in arg]
            if command_matches:
                matches.append({'pid': pid, 'kind': 'command-argument',
                                'matching_arguments': command_matches})
            for kind in ('cwd', 'exe'):
                target = os.readlink(proc / kind)
                if below(target.removesuffix(' (deleted)'), REPO):
                    matches.append({'pid': pid, 'kind': kind, 'target': target})
            for fd in sorted((proc / 'fd').iterdir(), key=lambda p: p.name):
                try:
                    target = os.readlink(fd)
                except FileNotFoundError:
                    continue
                if below(target.removesuffix(' (deleted)'), REPO):
                    matches.append({'pid': pid, 'kind': 'fd', 'fd': fd.name,
                                    'target': target})
            inspected += 1
        except (FileNotFoundError, ProcessLookupError):
            vanished += 1
        except PermissionError as exc:
            denied.append({'pid': pid, 'error': str(exc)})
    return {'matches': matches, 'permission_denied': denied,
            'fully_inspected_live_processes': inspected,
            'zombies_ignored': zombies, 'processes_vanished_during_scan': vanished,
            'own_pid_excluded': own_pid,
            'complete': not denied, 'no_active_users': not matches and not denied}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--release', action='store_true',
                        help='Explicitly remove ONLY the fixed clone after all guards pass.')
    args = parser.parse_args()
    out = args.out.resolve()
    assert not out.exists() and not out.is_relative_to(ROUND)
    out.mkdir(parents=True)
    shutil.copy2(Path(__file__).resolve(), out / 'tool.py.txt')
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
    routing = {'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE',
               'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
               'GIT_NAMESPACE', 'GIT_SHALLOW_FILE', 'GIT_REPLACE_REF_BASE',
               'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT', 'GIT_CONFIG',
               'GIT_CONFIG_SYSTEM', 'GIT_CONFIG_GLOBAL'}
    unsafe = sorted(key for key, value in env.items() if value and (
        key in routing or key.startswith(('GIT_CONFIG_KEY_', 'GIT_CONFIG_VALUE_'))))
    row = {'repo': str(REPO), 'expected_sha': EXPECTED, 'started_utc': utc(),
           'released': False, 'all_guards_passed': False}
    report = {'schema': 'geo261-completed-cold-comparison-clone-release/1',
              'started_utc': utc(), 'authorised_scope': [str(REPO)],
              'tool_sha256': digest(Path(__file__).read_bytes()),
              'mode': 'release' if args.release else 'validate-only',
              'clones': [row], 'rejected_git_environment_names': unsafe,
              'policy': 'Only one completed clean comparison clone is eligible. '
                        'No product, tests, raw runtime, parent tmp or active cache may change.'}

    def save():
        write(out / 'receipt.json', report)

    def run(label, argv, cwd=None, check=True):
        dest = out / 'commands' / label
        dest.mkdir(parents=True, exist_ok=False)
        result = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
        (dest / 'stdout.bin').write_bytes(result.stdout)
        (dest / 'stderr.bin').write_bytes(result.stderr)
        write(dest / 'command.json', {
            'command': argv, 'cwd': str(cwd) if cwd else None,
            'actual_process_returncode': result.returncode,
            'stdout_bytes': len(result.stdout), 'stdout_sha256': digest(result.stdout),
            'stderr_bytes': len(result.stderr), 'stderr_sha256': digest(result.stderr),
            'ended_utc': utc()})
        if check:
            assert result.returncode == 0, (label, result.returncode, result.stderr[:1000])
        return result.stdout

    def git(label, *argv):
        return run(label, ['git', *argv], REPO)

    code = 1
    save()
    try:
        assert not unsafe, unsafe
        assert REPO.is_dir() and not REPO.is_symlink()
        assert (REPO / '.git').is_dir() and not (REPO / '.git').is_symlink()
        assert REPO.resolve() == REPO and RUNTIME.resolve() == RUNTIME
        run('df-before', ['df', '-B1', '/workspace', '/tmp'])
        public = run('github-public-head', [
            'git', 'ls-remote', 'https://github.com/ZhiQiYang/geometry-axiom.git',
            'refs/heads/' + BRANCH], PUBLIC).decode().strip().split()
        assert len(public) == 2 and public[1] == 'refs/heads/' + BRANCH
        public_sha = public[0]
        report['github_public_head'] = public_sha
        run('public-head-commit', ['git', 'cat-file', '-t', public_sha], PUBLIC)
        assert git('head', 'rev-parse', 'HEAD').decode().strip() == EXPECTED
        assert not git('status', 'status', '--porcelain=v1', '--untracked-files=all')
        assert not git('untracked', 'ls-files', '--others', '--exclude-standard', '-z')
        assert not git('ignored', 'ls-files', '--others', '--ignored', '--exclude-standard', '-z')
        assert not git('unpublished', 'rev-list', '--all', '--not', '--remotes=origin')
        worktrees = git('worktrees', 'worktree', 'list', '--porcelain').decode()
        assert worktrees.count('worktree ') == 1 and f'worktree {REPO}\n' in worktrees
        flags = git('index-flags', 'ls-files', '-v', '-z')
        assert all(part.startswith(b'H ') for part in flags.split(b'\0') if part)
        git('diff-index', 'diff-index', '--exit-code', 'HEAD', '--')
        git('refs', 'show-ref')
        git('reflogs', 'reflog', 'show', '--all', '--format=%H %gD %gs')
        local_reachable = set(git('all-reachable', 'rev-list', 'HEAD', '--all', '--reflog').splitlines())
        public_reachable = set(run('public-all-reachable', ['git', 'rev-list', public_sha], PUBLIC).splitlines())
        unpublished = sorted(local_reachable - public_reachable)
        write(out / 'reachable-not-public.json', [part.decode() for part in unpublished])
        assert not unpublished, unpublished[:10]
        row.update(origin_tip_public_ancestry_verified=True,
                   all_head_ref_and_reflog_reachable_commits_public=True,
                   locally_reachable_commit_count=len(local_reachable),
                   public_reachable_commit_count=len(public_reachable))
        raw_index = git('index', 'ls-files', '--stage', '-z')
        raw_tree = git('tree', 'ls-tree', '-rz', 'HEAD')
        index, tree = {}, {}
        for record in raw_index.split(b'\0'):
            if record:
                meta, path = record.split(b'\t', 1)
                mode, oid, stage = meta.split()
                assert stage == b'0'
                index[path] = (mode.decode(), oid.decode())
        for record in raw_tree.split(b'\0'):
            if record:
                meta, path = record.split(b'\t', 1)
                mode, kind, oid = meta.split()
                assert kind == b'blob'
                tree[path] = (mode.decode(), oid.decode())
        assert index == tree
        tracked = []
        for path, (mode, oid) in sorted(index.items()):
            actual = REPO / os.fsdecode(path)
            before = actual.lstat()
            if mode == '120000':
                assert actual.is_symlink()
                data = os.fsencode(os.readlink(actual))
            else:
                assert mode in ('100644', '100755') and actual.is_file() and not actual.is_symlink()
                assert bool(before.st_mode & 0o111) == (mode == '100755')
                data = actual.read_bytes()
            after = actual.lstat()
            assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
                after.st_ino, after.st_size, after.st_mtime_ns)
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            assert blob == oid, ('raw-bytes-differ-from-public-Git-blob', os.fsdecode(path))
            tracked.append({'path': os.fsdecode(path), 'mode': mode, 'git_blob': oid,
                            'bytes': len(data), 'sha256': digest(data)})
        write(out / 'tracked-bytes-and-modes.json', tracked)
        row.update(tracked_files=len(tracked), tracked_bytes=sum(item['bytes'] for item in tracked),
                   tracked_git_blobs_all_match=True)
        roots = [RUNTIME / 'tmp', ROUND / 'p52-main-preparation']
        completed = []
        for label in ('p52-prepare-main', 'p52', 'p52-verifier'):
            root = ROUND / 'special' / label
            roots.append(root)
            path = root / 'receipt.json'
            data = path.read_bytes()
            original = json.loads(data)
            assert original.get('ended') and original.get('exit_code') is not None
            assert original.get('status') != '執行中'
            (out / f'original-{label}-receipt.json').write_bytes(data)
            completed.append({'path': str(path), 'sha256': digest(data), 'ended': original['ended'],
                              'status': original['status'], 'original_exit_code': original['exit_code']})
        row['completed_original_receipts'] = completed
        preserved = inventory(roots)
        write(out / 'preserved-runtime-raw-before.json', preserved)
        row['preserved_raw_roots'] = [str(root) for root in roots]
        allocation = {'allocated_bytes': 0, 'exclusive_file_allocated_bytes': 0,
                      'multiply_linked_file_allocated_bytes': 0, 'file_count': 0}
        for directory, dirs, files in os.walk(REPO, followlinks=False):
            allocation['allocated_bytes'] += Path(directory).lstat().st_blocks * 512
            for name in files:
                st = (Path(directory) / name).lstat()
                allocation['file_count'] += 1
                allocation['allocated_bytes'] += st.st_blocks * 512
                key = ('exclusive_file_allocated_bytes' if st.st_nlink == 1 else
                       'multiply_linked_file_allocated_bytes')
                allocation[key] += st.st_blocks * 512
        row['allocation'] = allocation
        processes = process_users()
        write(out / 'active-process-and-fd-users.json', processes)
        row['process_audit_complete'] = processes['complete']
        row['no_active_process_or_fd_users'] = processes['no_active_users']
        assert git('final-head', 'rev-parse', 'HEAD').decode().strip() == EXPECTED
        assert not git('final-status', 'status', '--porcelain=v1', '--untracked-files=all')
        assert not git('final-ignored', 'ls-files', '--others', '--ignored', '--exclude-standard', '-z')
        assert git('final-index', 'ls-files', '--stage', '-z') == raw_index
        assert git('final-flags', 'ls-files', '-v', '-z') == flags
        preserved_after_validation = inventory(roots)
        write(out / 'preserved-runtime-raw-after-validation.json', preserved_after_validation)
        assert preserved_after_validation == preserved
        row['preserved_runtime_raw_unchanged_during_validation'] = True
        assert processes['complete'], 'Cannot certify no active fd users: process audit permission denied.'
        assert processes['no_active_users'], 'The clone still has live process or fd users.'
        row['all_guards_passed'] = True
        write(out / 'receipt-before-delete.json', row)
        if args.release:
            final_processes = process_users()
            write(out / 'active-process-and-fd-users-immediately-before-delete.json', final_processes)
            assert final_processes['complete'] and final_processes['no_active_users']
            before = shutil.disk_usage('/tmp').free
            shutil.rmtree(REPO)
            assert not REPO.exists() and RUNTIME.is_dir() and (RUNTIME / 'tmp').is_dir()
            after = shutil.disk_usage('/tmp').free
            preserved_after = inventory(roots)
            write(out / 'preserved-runtime-raw-after-release.json', preserved_after)
            assert preserved_after == preserved
            row.update(released=True, free_before_bytes=before, free_after_bytes=after,
                       free_delta_bytes=after-before, preserved_runtime_raw_unchanged=True)
        code = 0
    except BaseException:
        row['error'] = traceback.format_exc()
    row['ended_utc'] = utc()
    report.update(ended_utc=utc(), released_count=int(row['released']), exit_code=code)
    save()
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'exit_code': code,
                      'mode': report['mode'], 'released': row['released'],
                      'all_guards_passed': row['all_guards_passed'],
                      'error': row.get('error')}, ensure_ascii=False), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
