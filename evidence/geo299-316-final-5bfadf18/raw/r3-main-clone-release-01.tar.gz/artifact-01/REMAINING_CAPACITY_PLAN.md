# 後續驗收容量計畫（唯讀分析與單一路徑工具準備）

本檔由子 agent 整理；子 agent 沒有刪除、搬移或壓縮 clone，沒有執行產品測試或編譯。root 隨後已完成精準 r2 校驗與釋放，兩者原退出 0；唯一候選 clone 現在已不存在。正式結果以 `/workspace/geo261-environment/R3-comparison-clone-bounded-release-r2/receipt.json` 與其 launch 原始輸出為準。

## 容量觀測與排程

2026-10-23 02:05 UTC 左右，`df -B1`：

| 檔案系統 | Available bytes | 備註 |
| --- | ---: | --- |
| /workspace | 1,961,537,536 | 32 GB overlay；#314 帳本／封包仍會增加 |
| /tmp | 1,213,079,552 | 17 GB 的獨立掛載；新 #314 worktree 與 browser tmp 都會使用 |

當時活作業為 #314 新 S `c4aad5d7bb98ea864639f9e6d85c99bb2613c24b` 的完整 mutation oracle，正在編 bridge；其 `geo314-core-fixed-c4aad5d7` cache、舊編譯 provenance、source branch 與所有 raw 都不得碰。combined 正式 native 已原退出 0；其 active detached F `5bfadf187e615ba0fb8466753b63ce3044ef7d1c` worktree `/tmp/g261-final299316-5bfadf18-r2` 實佔 319,315,968 bytes，仍需六個 browser job；不得回收。

觀測到的既有 F2 六 browser/native TEMP 合計約 89,280,512 bytes，現任 global native cache 約 6.9 MB。這只是容量參考，不是新測試門檻或保證。新 #314 固定 F worktree 預期與 combined 這個 319 MB 精簡 worktree 接近；保留逐項收據及失敗原輸出會持續增加。browser 與其他重型作業仍應串行，不以移除 raw 來解容量。

## 唯一建議優先釋放的 clone

精確候選：`/tmp/g261r3/work/p52-main/main`。只回收此 Git 比較 clone，保留父 runtime 的 `tmp`、P52 收據與所有原始輸出；不回收整個 `g261r3`。

原純校驗收據：`/workspace/geo261-environment/R3-comparison-clone-release-validation-r1/receipt.json`。

- HEAD 為公開 main `adbaebf9c73ea6801d7b4d5214e4b846b132923b`；single detached worktree、untracked/ignored 空、index flags 全 H。
- 17,786 個 tracked files，共 948,370,623 raw bytes，index/tree/mode/raw Git blob 與 SHA256 全部核對一致。
- HEAD、refs、reflog 全部 2,163 個 reachable commits，都屬 GitHub 上可解析整合 E `4b665fae21ab63aaffb7d84f6a32d5a469ba1675` 的 2,201 個祖先集合；沒有未公開 reachable commit。
- 分配大小為 994,189,312 bytes；17,812 個一般檔案的所有分配區塊均 nlink=1，沒有已觀測的多連結檔案分配區塊。實際 free delta 仍應以 root 刪除後 `disk_usage('/tmp')` 收據為準。
- 原 `p52-prepare-main`、`p52`、`p52-verifier` 三收據均原退出 0，最後完成時間 2026-10-22 21:18:53 UTC。
- 父五個 raw roots：runtime/tmp、round/p52-main-preparation、三個 special/P52 roots，已逐檔記 mode/bytes/hash/symlink，純校驗前後完全一致。相關原 Git 命令、原 stdout/stderr、退出碼、完整 tracked inventory 都保存於上述 validation-r1 目錄。

root 已執行精準釋放：實際回收 994,189,312 bytes，父 raw before/after 完全一致，沒有反向 alternates 借用者。該 clone 現在不存在；父 runtime/tmp 與其原收據、輸出仍在。root 回報釋放後 /tmp 約 2.1 GiB、/workspace 約 1.8 GiB 可用；這是稍後時點的觀測，不將不同檔案系統的其他並行變動算進本次 free delta。

## 活動性稽核限制與 namespace 修復

一般 sandbox 對其他活程序的 cwd/fd 讀取大多 PermissionError；原嚴格工具因此原退出 1，`released=false`、`all_guards_passed=false`。此紅燈完整保留，不能稱完整無 fd 使用者已核定。

宿主視角只讀掃描已保存於 `/workspace/geo261-environment/R3-comparison-clone-process-host-audit-r1/`：所有可讀程序沒有指向候選的 cwd/exe/fd/命令；僅 PID208 dockerd 與 PID260 containerd 的 cwd/fd 不可讀。sudo 不存在，原 probe 退出 127，沒有用它執行其他作業。

正常 sandbox 將這兩個宿主 UID0 程序顯示為 UID65534。兩種 namespace 的目錄 stat、status 四個 UID 原欄位、自身 uid_map/gid_map，以及 comm/cmdline 原 bytes，都另存在 `/workspace/geo261-environment/R3-comparison-clone-daemon-namespace-audit/{normal,host}/`。兩個 namespace 的 comm/cmdline hash 完全一致；宿主四 UID 皆 0，sandbox 四 UID 皆 65534。

root 已明確決定可基於全部公開可重建、原工作已終態、父 raw 完整，對這兩個已固定身份的 Docker 基礎程序採用有限維護例外；其他未知 deny 或任何候選活動使用者都必須拒。此為環境容量判斷，不放寬任何產品／測試斷言。

## 工具與精確下一步

保留的原嚴格工具：`validate_r3_comparison_clone_release.py`，SHA256 `65fc493ca9a03971626bebeecdfba3d7b04612479812beea0c2714d1eedfc011`。其 default validation 原 1 的原因只有 sandbox process audit 不完整；沒有刪除。

第一個 bounded 工具 `bounded_release_r3_comparison_clone.py`，SHA256 `af82535e756bdf635e98c3497fa56ec2f1d72fcce374876917fbf06460383245`。root 的 bounded-validation-r1 原 1，原因是其預期 sandbox UID65534、實際宿主 UID0；原工具、收據與輸出都保留。

精準 r2 工具：`/workspace/geo261-environment/bounded_release_r3_comparison_clone_r2.py`，22,105 bytes，SHA256 `219ff64fed947027be43d94618915eaa39faf7416e2325a4e2702c2c4b273548`。AST PASS，獨立子 agent 靜態審核 READY。僅修 expected UID 為宿主 0、附兩 namespace 原 receipt hash 與原因；其他守門未變。

root 已以 `require_escalated` 宿主視角完成純校驗：

```text
python3 -B /workspace/geo261-environment/bounded_release_r3_comparison_clone_r2.py --out /workspace/geo261-environment/R3-comparison-clone-bounded-validation-r2
```

此 argv 沒有 `--release`，原退出 0、沒有刪。root 隨後使用全新 output 目錄 `R3-comparison-clone-bounded-release-r2` 加 `--release`，原退出 0；原精準命令、完整 stdout/stderr 與結束碼保存在 `/workspace/geo261-environment/R3-comparison-clone-bounded-release-r2-launch/` 的 c387 Recorder 收據。前輪原 1 均保留，沒有覆寫。

r2 已重查完整公開 reachable、所有 tracked blob/index/mode、原工作終態、父 raw 前後、反向 Git alternates 引用，以及立即刪除前活動性。只允精確兩 PID、宿主 UID0、comm/cmdline 原 hash 與恰當 cwd PermissionError。正式 release 收據仍保留原 `complete=false`、`no_active_users=false`、`all_guards_passed=false`；`release_conditions_passed=true` 與有限例外理由另列，沒有冒稱完整全球 fd 稽核。工具明確拒 Python -O/PYTHONOPTIMIZE，刪除後立即記錄實際 released 狀態。

## 不作本輪清理的目錄

- /tmp/g261r3 的 Q38 clone、source-final、P52 fix clone 與所有 raw；雖部分 clean 且可重建，沒有本輪精準釋放授權與完整相依核對。
- /tmp/g261htmlseal、g261p3、舊 P73 resume：包含原紅／診斷／稽核資料，不能按名稱整目錄回收。
- /workspace/geo261-cold（當時 20,363,776,000 bytes）：保存既有原輪；已釋放的三個 main 子 clone 不能再列為可回收。
- #314 的所有活 cache／來源、尚待安裝的 proof／ledger raw；#323 原來源與公開收據；combined publication/source/workflow roots。

其他候選全部未動。子 agent 沒有修改產品或測試、沒有重跑驗收，也沒有 commit/push；root 僅回收上述唯一比較 clone。正式 validation/release 新收據優先於本檔的早期容量觀測。此後不再執行任何 runtime 或清理。
