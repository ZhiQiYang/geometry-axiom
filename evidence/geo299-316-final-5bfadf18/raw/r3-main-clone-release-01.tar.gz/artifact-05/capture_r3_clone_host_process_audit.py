"""Record a read-only host process-reference audit for one fixed cold clone."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

OUT = Path('/workspace/geo261-environment/R3-comparison-clone-process-host-audit-r1')
OUT.mkdir(exist_ok=False)
sha = lambda value: hashlib.sha256(value).hexdigest()
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
tool = Path(__file__).resolve()
(OUT / 'tool.py.txt').write_bytes(tool.read_bytes())
rows = []
commands = [
    ('host-process-references', ['python3', '-B', '-c',
        'import json,runpy; scope=runpy.run_path("/workspace/geo261-environment/validate_r3_comparison_clone_release.py"); '
        'print(json.dumps(scope["process_users"](),ensure_ascii=False,indent=2))']),
    ('denied-process-identities', ['ps', '-p', '208,260', '-o', 'pid,uid,comm,args']),
    ('sudo-noninteractive-probe', ['bash', '-lc', 'sudo -n true']),
]
for label, argv in commands:
    dest = OUT / label
    dest.mkdir()
    started = utc()
    result = subprocess.run(argv, cwd='/workspace', capture_output=True)
    (dest / 'stdout.bin').write_bytes(result.stdout)
    (dest / 'stderr.bin').write_bytes(result.stderr)
    row = {'label': label, 'command': argv, 'cwd': '/workspace', 'started_utc': started,
           'ended_utc': utc(), 'actual_process_returncode': result.returncode,
           'stdout_bytes': len(result.stdout), 'stdout_sha256': sha(result.stdout),
           'stderr_bytes': len(result.stderr), 'stderr_sha256': sha(result.stderr)}
    (dest / 'command.json').write_text(json.dumps(row, ensure_ascii=False, indent=2) + '\n')
    rows.append(row)
audit = json.loads((OUT / 'host-process-references/stdout.bin').read_bytes())
report = {'schema': 'geo261-readonly-comparison-clone-host-process-audit/1',
          'tool_sha256': sha(tool.read_bytes()), 'commands': rows, 'audit': audit,
          'policy': 'Read-only /proc path references and identities; no environments or process output files read. '
                    'Capture exit zero is not a complete/no-active-users certification.',
          'ended_utc': utc()}
(OUT / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT / 'receipt.json'), 'capture_exit': 0,
                  'process_audit_complete': audit['complete'],
                  'no_active_users_certified': audit['no_active_users'],
                  'permission_denied_pids': [row['pid'] for row in audit['permission_denied']],
                  'matches': audit['matches']}))
