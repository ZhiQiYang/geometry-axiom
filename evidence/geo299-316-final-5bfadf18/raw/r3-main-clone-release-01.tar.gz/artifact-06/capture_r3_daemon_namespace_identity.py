"""Read fixed daemon identities and UID namespace maps; never inspect the clone."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--view', choices=('normal', 'host'), required=True)
args = parser.parse_args()
out = Path('/workspace/geo261-environment/R3-comparison-clone-daemon-namespace-audit') / args.view
out.mkdir(parents=True, exist_ok=False)
tool = Path(__file__).resolve()
(out / 'tool.py.txt').write_bytes(tool.read_bytes())
digest = lambda data: hashlib.sha256(data).hexdigest()
raws = []


def capture(source, label, data=None):
    if data is None:
        data = Path(source).read_bytes()
    (out / label).write_bytes(data)
    raws.append({'source': str(source), 'output': label, 'bytes': len(data), 'sha256': digest(data)})
    return data


def uid_line(proc):
    with (proc / 'status').open('rb') as stream:
        for line in stream:
            if line.startswith(b'Uid:'):
                return line
    raise RuntimeError('Missing kernel Uid status line: ' + str(proc))


capture('/proc/self/uid_map', 'self.uid_map.bin')
capture('/proc/self/gid_map', 'self.gid_map.bin')
capture('/proc/self/status', 'self.Uid-line.bin', uid_line(Path('/proc/self')))
rows = []
for pid in (208, 260):
    proc = Path('/proc') / str(pid)
    before = proc.stat()
    uid_raw = capture(proc / 'status', f'{pid}.Uid-line.bin', uid_line(proc))
    comm = capture(proc / 'comm', f'{pid}.comm.bin')
    cmdline = capture(proc / 'cmdline', f'{pid}.cmdline.bin')
    after = proc.stat()
    assert (before.st_ino, before.st_uid, before.st_gid) == (after.st_ino, after.st_uid, after.st_gid)
    rows.append({'pid': pid, 'proc_directory_uid': before.st_uid, 'proc_directory_gid': before.st_gid,
                 'status_uid_real_effective_saved_filesystem': [int(value) for value in uid_raw.split()[1:]],
                 'comm': comm.decode().strip(), 'comm_sha256': digest(comm),
                 'cmdline_bytes': len(cmdline), 'cmdline_sha256': digest(cmdline)})
report = {'schema': 'geo261-readonly-daemon-uid-namespace-audit/1', 'view': args.view,
          'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'self_uid': os.getuid(), 'self_euid': os.geteuid(), 'self_gid': os.getgid(),
          'self_egid': os.getegid(), 'tool_sha256': digest(tool.read_bytes()), 'rows': rows, 'raw_files': raws,
          'policy': 'Read only fixed PID208/PID260 UID status line, directory stat, comm/cmdline and self UID/GID maps. '
                    'No clone inspection, environment read, test, deletion or movement.'}
(out / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
