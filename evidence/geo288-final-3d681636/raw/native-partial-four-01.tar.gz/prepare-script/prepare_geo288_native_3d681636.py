import ast,hashlib,importlib.util,json,os,sys
from pathlib import Path
F='3d681636902371ecc528b20f51eea33e272581c9'
SOURCE=Path('/workspace/geometry-axiom')
REPO=Path('/tmp/g288-final-native-checkout-3d681636')
OUT=Path('/tmp/g288-native-preparation-3d681636')
TOOL=Path('/workspace/geo288-main-merge-20261023/native-final-tools')
if REPO.exists() or OUT.exists():raise RuntimeError('Require fresh clone and preparation output')
OUT.mkdir()
spec=importlib.util.spec_from_file_location('original_capture',TOOL/'capture.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1')
rec=mod.Recorder(OUT,env,F)
def run(argv,cwd=SOURCE):return rec.run(argv,cwd=cwd,timeout=600)[1]
run(['df','-B1','/tmp','/workspace'])
tree=ast.parse((SOURCE/'tests/run_all.py').read_text())
nodefiles=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE_TEST_FILES' for t in n.targets))
direct=['tests/test_local_launcher.py','tests/test_modeling_transport.py','tests/test_serve.py','tests/_bridge.py','tests/binaries.py','tests/test_section_profile_modeling.py','geometry-web/start_local.py','geometry-web/serve.py','geometry-web/runtime_version.py']
refs=[]
for rel in direct+nodefiles:
 for number,line in enumerate((SOURCE/rel).read_text().splitlines(),1):
  if 'evidence/' in line and ('__dirname' in line or 'tests/evidence' in line):refs.append({'path':rel,'line':number,'text':line})
fixtures=['tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas','tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas','tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas']
mod.dump(OUT/'DEPENDENCY_SCOPE.json',{'source_sha':F,'method':'AST-only original NODE_TEST_FILES list; static direct path review, no module imported or test run; exact original fixtures retained','direct_entry_and_support_files':direct,'original_node_files':nodefiles,'direct_evidence_references':refs,'required_materialized_fixtures':fixtures,'node_bootstrap':'Original node-test branch invokes Node executable and suite.cmd directly; write_node_shim is only node-canvas branch, not selected','scope_limit':'Not a full transitive runtime closure proof; original suite remains authoritative'})
run(['git','rev-parse',F+'^{commit}'])
run(['git','clone','--shared','--no-hardlinks','--no-checkout',str(SOURCE),str(REPO)])
run(['git','config','core.sparseCheckout','true'],REPO)
run(['git','config','core.sparseCheckoutCone','false'],REPO)
run(['git','config','index.sparse','false'],REPO)
patterns=['/*','!/evidence/','!/tests/evidence/','/tests/evidence/','!/tests/evidence/*','/tests/evidence/k2a-collection-capacity-20261012/','!/tests/evidence/k2a-collection-capacity-20261012/*',*['/'+p for p in fixtures[:2]],'/tests/evidence/k2a-boundary-review-20261012/','!/tests/evidence/k2a-boundary-review-20261012/*','/tests/evidence/k2a-boundary-review-20261012/legacy/','!/tests/evidence/k2a-boundary-review-20261012/legacy/*','/'+fixtures[2]]
(REPO/'.git/info/sparse-checkout').write_text('\n'.join(patterns)+'\n')
(OUT/'sparse-checkout').write_text('\n'.join(patterns)+'\n')
run(['git','checkout','-b','codex/geo288-p88-final-native-20261023',F],REPO)
run(['git','remote','set-url','origin','https://github.com/ZhiQiYang/geometry-axiom.git'],REPO)
head=run(['git','rev-parse','HEAD'],REPO).decode().strip()
status=run(['git','status','--porcelain=v1','--untracked-files=all'],REPO)
if head!=F or status:raise RuntimeError('Dedicated source identity/clean guard failed')
index=run(['git','ls-files','--stage','-z'],REPO)
fullindex=run(['git','ls-tree','-r','--full-tree',F],REPO)
skip=run(['git','ls-files','-v'],REPO)
for fixture in fixtures:
 data=(REPO/fixture).read_bytes()
 if data!=run(['git','show',F+':'+fixture],REPO):raise RuntimeError('Fixture identity mismatch')
run(['df','-B1','/tmp','/workspace'])
mod.dump(OUT/'PREPARATION_RESULT.json',{'source_sha':F,'head':head,'status':status.decode(),'index_sha256':hashlib.sha256(index).hexdigest(),'full_tree_sha256':hashlib.sha256(fullindex).hexdigest(),'tracked_index_entry_count':index.count(b'\x00'),'index_is_sparse':False,'sparse_patterns':patterns,'materialized_required_fixtures':fixtures,'unmaterialized_scope':'Root evidence/ and tests/evidence/ except three original fixture files; complete Git objects/history/index retained, no assertion of complete worktree byte equality','skip_worktree_listing_sha256':hashlib.sha256(skip).hexdigest(),'commands':rec.rows})
print(json.dumps({'prepared':True,'repo':str(REPO),'sha':F,'out':str(OUT)}))
