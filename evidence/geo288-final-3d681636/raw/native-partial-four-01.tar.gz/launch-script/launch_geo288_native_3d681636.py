import datetime,hashlib,importlib.util,json,os
from pathlib import Path
TOOLS=Path('/workspace/geo288-main-merge-20261023/native-final-tools')
F='3d681636902371ecc528b20f51eea33e272581c9'
OUT=Path('/tmp/g288-final-native-launch-3d681636')
if OUT.exists():raise RuntimeError('Require fresh outer launch record')
OUT.mkdir()
expected={'run_partial_native.py':'83d3eedf438ff25fa3cbc7ab7707f1594e031206dd52e23f0125f6f64d8f12f4','PREPARATION.json':'2fb9e203a486a589603e8d582e1e4b06109f06e9c05ec497bcb558e1b53dd9a2','capture.py':'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'}
for name,value in expected.items():
 if hashlib.sha256((TOOLS/name).read_bytes()).hexdigest()!=value:raise RuntimeError('Frozen tool mismatch: '+name)
spec=importlib.util.spec_from_file_location('original_outer_capture',TOOLS/'capture.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
env=dict(os.environ)
env.pop('NODE_OPTIONS',None);env.pop('PYTHONOPTIMIZE',None)
argv=['env','-u','NODE_OPTIONS','-u','PYTHONOPTIMIZE','python3','-B',str(TOOLS/'run_partial_native.py'),'--repo','/tmp/g288-final-native-checkout-3d681636','--sha',F,'--out','/tmp/g288-final-native-3d681636']
request={'source_sha':F,'argv':argv,'cwd':'/tmp/g288-final-native-checkout-3d681636','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_outer_environment':{key:env.get(key) for key in ['PATH','LANG','LC_ALL','NODE_OPTIONS','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','TMPDIR','CC']},'frozen_tool_hashes':expected,'native_scope':'Original four suites only; PARTIAL, not full native','source_preparation':'/tmp/g288-native-preparation-3d681636/PREPARATION_RESULT.json'}
mod.dump(OUT/'TOP_REQUEST.json',request)
rec=mod.Recorder(OUT,env,F)
row,stdout,stderr=rec.run(argv,cwd=request['cwd'],timeout=None,check=False)
mod.dump(OUT/'LAUNCH_RESULT.json',{'source_sha':F,'request':request,'original_outer_process_exit':row['actual_process_returncode'],'command':row,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'exit':row['actual_process_returncode'],'stdout_tail':stdout[-3500:].decode('utf-8','replace'),'stderr_tail':stderr[-2000:].decode('utf-8','replace')}))
raise SystemExit(row['actual_process_returncode'])
