# 新 F 的四項原 native suites（只有準備，未執行）

尚未收到真 F／root 執行時槽，沒有建立 checkout、沒有執行本工具／collector／原測試，也沒有編譯或開 Chrome。驗收分支預留 `codex/geo288-p88-final-native-20261023`，正文另用同名 `-prbody`。不寫 integration、產品、tests、index 或 HEAD。

原命令保持：

```bash
python3 tests/run_all.py --build \
  --only test_local_launcher --only test_modeling_transport \
  --only test_serve --only node:tests-js
```

原登錄四個 suite 為 17／3／51／737。工具先核真 F 的 `tests/run_all.expected.json` 沒有改動這四個原條目，再把原命令交給 byte-identical 原 reaper。原 `run_all.py` 仍自行選 suite、檢查 registry、建 stale／missing binaries、清 GEOMETRY 子環境及按原 expected 判決；沒有自行組 Node 環境／preload／shim、沒有 `--allow-skip`／`--update-expected`、沒有新數字門檻。原命令自己會明說 PARTIAL；這四項不冒稱完整 native／全數瀏覽器綠。

待 root 提供 `ACTUAL_NEW_F_FULL_SHA`、`ACTUAL_NATIVE_CHECKOUT`、`F8` 與執行槽後，原樣執行：

```bash
env -u NODE_OPTIONS -u PYTHONOPTIMIZE \
python3 -B /workspace/geo288-main-merge-20261023/native-final-tools/run_partial_native.py \
  --repo ACTUAL_NATIVE_CHECKOUT --sha ACTUAL_NEW_F_FULL_SHA \
  --out /tmp/g288-final-native-F8
```

三個佔位不是已執行結果。checkout 必須在預留驗收分支、HEAD 精確等已推且 GitHub 可解析的新 F，前後 clean、Git index 與 14 個具名測試／runtime 入口 bytes 一致。這 14 檔是窄的輸入綁定，不替代 root 的完整 closure 或所有 node files 登錄。`source_sha` 永遠保真 F，不改標成出版 E。

工具沿原 c387 Recorder 保存每個 argv／cwd／環境／退出／stdin／完整 stdout／stderr bytes/hash，stack 設 16 MiB 並記 before／during；原 reaper 使用明設的 `GEO261_REAPER_LOG=<fresh-out>/reaper.jsonl`，路徑／bytes／hash保存，唯一 terminal 的 `primary_returncode` 保真原命令結束碼，與 reaper 程序退出分列。清外殼 NODE_OPTIONS／PYTHONOPTIMIZE 並在 receipt 明列，其他 Node 子環境仍由原 run_all 決定。版本會真查 Chrome、Node 24、Python、cc、CJK 套件，原輸出完整保存。沒有偷偷加 Chrome 或其他瀏覽器測項。

原 `tests/binaries.py` 在 Linux 固定 `/tmp/geometry-tests`，自帶 `run_all`／`build` 兩把原鎖；本工具不改 OUT_DIR。原 grid 的 start_local 則使用其專屬 TMP／`geometry-runtime/<repo-key>`，不是同一組 build outputs。root 僅在原三輪 canvas 終態後安排 native＋grid 最多兩項；本工具不自行接續／排程／搶鎖，也不在性能量測期間啟動。若原鎖忙，保原環境退出，不自動重試。

只保存四套原固定路徑的十個 suite logs，先記 before bytes/hash/stat，再原樣複製 after 並標 `prior_same_identity`；沒有把其他歷史 suite 日誌裝作本輪。若原命令未跑／受阻，可能存在的舊日誌只保原身份，不能由它們推定通過。`core`／`bridge`／`model-base` 原 fingerprint JSON 另保存；不重建或改寫原收據。原完整 F13 native 證據繼續保 F13，這四套補驗單獨列新 F。

receipt 的 `original_run_exit` 與 `metadata_complete`／`outer_exit` 分列。metadata 完整不等測試通過；原測試紅時保原結束碼與所有輸出。metadata 出問題則 outer 2，仍留原測試真 exit。所有 before／after 都在 finally 嘗試保存，不因紅燈覆蓋或自動重跑。

root 整合前，使用既有 `publish_followup_progress.py` 指定自己的 clean 驗收 repo／分支、`--issue 288 --sha 真F --label native-partial-four`，輸入整個 `/tmp/g288-final-native-F8` 與本工具凍結目錄，`--receipt` 用原 receipt；先核封包逐檔 bytes/hash，再正常 commit／push。正文寫自己的 `-prbody` 分支，唯一 current-state 表分真 F／evidence E／四原 suite exit/count 與 PARTIAL scope。不得 force push、合併 PR 或改 SSOT。
