#!/usr/bin/env python3
"""Record the four original affected native suites; never claim full native."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import sys
import traceback

HERE = Path(__file__).resolve().parent
BRANCH = 'codex/geo288-p88-final-native-20261023'
ORIGINAL_TOOL_HASHES = {
    'capture.py': 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',
    'reap_children.py': '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760',
}
SELECTORS = ('test_local_launcher', 'test_modeling_transport', 'test_serve', 'node:tests-js')
ORIGINAL_EXPECTED = {
    'py:test_local_launcher': 17, 'py:test_modeling_transport': 3,
    'py:test_serve': 51, 'node:tests-js': 737,
}
INPUTS = ('tests/run_all.py', 'tests/run_all.expected.json', 'tests/binaries.py',
          'tests/_unittest_runner.py', 'tests/test_local_launcher.py',
          'tests/test_modeling_transport.py', 'tests/test_serve.py',
          'geometry-web/start_local.py', 'geometry-web/serve.py',
          'geometry-web/runtime_version.py', 'geometry-web/grid_rule_lines_test.js',
          'geometry-web/cdp_test.js', 'geometry-web/cdp_helpers.js',
          'geometry-web/cdp_sections.golden.json')
LOG_ROOT = Path('/tmp/geometry-tests/run_all-logs')
LOG_NAMES = tuple(name.replace(':', '_') + suffix
                  for name in ORIGINAL_EXPECTED
                  for suffix in (('.log', '.json', '.unittest.log')
                                 if name.startswith('py:') else ('.log',)))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    if (not re.fullmatch('[0-9a-f]{40}', args.sha) or not repo.is_dir()
            or out.exists() or not out.is_relative_to(Path('/tmp'))
            or out.is_relative_to(repo) or repo.is_relative_to(out)):
        raise RuntimeError('Require actual full F, existing checkout and fresh external /tmp output')
    if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE') not in (None, '', '0'):
        raise RuntimeError('Do not disable original Python assertions')
    for name, expected in ORIGINAL_TOOL_HASHES.items():
        if sha((HERE / name).read_bytes()) != expected:
            raise RuntimeError('Original recorder/reaper changed: ' + name)
    out.mkdir(parents=True)
    (out / 'tools').mkdir()
    for name in ('run_partial_native.py', *ORIGINAL_TOOL_HASHES):
        shutil.copy2(HERE / name, out / 'tools' / name)
    env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8',
               PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1',
               GEO261_REAPER_LOG=str(out / 'reaper.jsonl'))
    inherited_path = env.get('PATH', '')
    inherited_node = shutil.which('node', path=inherited_path)
    if inherited_node is None:
        raise RuntimeError('Inherited original Node executable is unavailable')
    paths = ['/workspace/geo261-environment/bin', str(Path(inherited_node).parent),
             *inherited_path.split(os.pathsep)]
    env['PATH'] = os.pathsep.join(dict.fromkeys(paths))
    cleared = {name: env.pop(name, None) for name in ('NODE_OPTIONS', 'PYTHONOPTIMIZE')}
    spec = importlib.util.spec_from_file_location('native_original_capture', HERE / 'capture.py')
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    recorder = capture.Recorder(out, env, args.sha)
    report = {'schema': 'geo288-p88-affected-native-partial/1', 'source_sha': args.sha,
              'scope': 'Original run_all.py --build with exactly four --only selectors; PARTIAL, never full native or browser acceptance',
              'started_utc': now(), 'repo': str(repo), 'required_branch': BRANCH,
              'original_expected_counts': ORIGINAL_EXPECTED, 'selectors': SELECTORS,
              'source_before': None, 'source_after': None, 'input_before': [], 'input_after': [],
              'original_run': None, 'metadata_errors': [], 'commands': recorder.rows,
              'outer_environment': {key: env.get(key) for key in (
                  'PATH', 'LANG', 'LC_ALL', 'PYTHONIOENCODING', 'PYTHONDONTWRITEBYTECODE',
                  'NODE_OPTIONS', 'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONSTARTUP', 'TMPDIR', 'CC',
                  'GEO261_REAPER_LOG')},
              'cleared_environment_names': sorted(name for name, value in cleared.items() if value is not None),
              'inherited_PATH': inherited_path,
              'PATH_binding': 'Same existing environment bin and inherited Node parent ordering as original workflow driver; no new Node environment or preload',
              'node_environment': 'Original run_all child_env and Node argv only; no custom Node environment or shim',
              'tool_hashes': {name: sha((HERE / name).read_bytes())
                              for name in ('run_partial_native.py', *ORIGINAL_TOOL_HASHES)},
              'log_root': str(LOG_ROOT), 'logs_before': {}, 'logs_after': {},
              'reaper_log': None, 'native_primary_exit': None,
              'binary_receipts': [], 'complete_native': False,
              'metadata_complete': False}

    def run(argv, *, check=True, variant='native-source-identity', timeout=120):
        return recorder.run(argv, cwd=repo, timeout=timeout, check=check,
                            source_sha=args.sha, source_variant=variant)

    def git(*parts):
        return run(['git', *parts])[1]

    def guard():
        state = {'head': git('rev-parse', 'HEAD').decode().strip(),
                 'branch': git('branch', '--show-current').decode().strip(),
                 'root': git('rev-parse', '--show-toplevel').decode().strip(),
                 'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
                 'index_sha256': sha(git('ls-files', '--stage', '-z'))}
        if state['head'] != args.sha or state['branch'] != BRANCH or state['root'] != str(repo) or state['status']:
            raise RuntimeError('Dedicated branch must be clean at actual full F: ' + json.dumps(state))
        return state

    def inputs():
        rows = []
        for relative in INPUTS:
            raw = (repo / relative).read_bytes()
            if raw != git('show', args.sha + ':' + relative):
                raise RuntimeError('Tracked input bytes differ: ' + relative)
            rows.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw),
                         'git_tree': git('ls-tree', '-z', args.sha, '--', relative).decode().rstrip('\0')})
        return rows

    def logs(copy=False):
        rows = {}
        for name in LOG_NAMES:
            path = LOG_ROOT / name
            if not path.is_file():
                rows[name] = None
                continue
            stat = path.stat()
            raw = path.read_bytes()
            rows[name] = {'source': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                          'mtime_ns': stat.st_mtime_ns, 'device': stat.st_dev, 'inode': stat.st_ino}
            if copy:
                target = out / 'selected-suite-logs' / name
                target.parent.mkdir(exist_ok=True)
                target.write_bytes(raw)
                rows[name]['snapshot'] = str(target)
                rows[name]['prior_same_identity'] = all(
                    (report['logs_before'].get(name) or {}).get(key) == rows[name][key]
                    for key in ('bytes', 'sha256', 'mtime_ns', 'device', 'inode'))
        return rows

    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    report['stack_before'] = [soft, hard]
    try:
        if hard != resource.RLIM_INFINITY and hard < 16777216:
            raise RuntimeError('Stack hard limit below original 16MiB')
        resource.setrlimit(resource.RLIMIT_STACK, (16777216, hard))
        report['stack_during'] = list(resource.getrlimit(resource.RLIMIT_STACK))
        report['source_before'] = guard()
        report['input_before'] = inputs()
        original_expected = json.loads((repo / 'tests/run_all.expected.json').read_bytes())['suites']
        for name, expected in ORIGINAL_EXPECTED.items():
            if original_expected[name] != {'mode': 'count', 'count': expected,
                                          'unit': 'test' if name.startswith('py:') else 'node test'}:
                raise RuntimeError('Original fixed expected registration changed; do not relax: ' + name)
        report['logs_before'] = logs()
        for command in (['google-chrome', '--version'], ['node', '--version'],
                        ['python3', '--version'], ['cc', '--version'],
                        ['dpkg-query', '-W', '-f=${Status} ${Version}\n', 'fonts-noto-cjk']):
            row, stdout, _ = run(command, variant='native-environment-version', timeout=30)
            if command[0] == 'node' and not stdout.startswith(b'v24.'):
                raise RuntimeError('Original environment requires Node24')
            if command[0] == 'google-chrome' and not stdout.startswith(b'Google Chrome '):
                raise RuntimeError('Original environment requires Google Chrome')
            if command[0] == 'dpkg-query' and not stdout.startswith(b'install ok installed '):
                raise RuntimeError('Required fonts-noto-cjk package is not installed')
        argv = [sys.executable, '-B', str(HERE / 'reap_children.py'),
                'python3', 'tests/run_all.py', '--build']
        for selector in SELECTORS:
            argv += ['--only', selector]
        report['original_run'] = run(argv, check=False,
                                      variant='four-original-native-suites-PARTIAL', timeout=None)[0]
    except BaseException:
        report['metadata_errors'].append(traceback.format_exc())
    finally:
        try:
            reaper_log = out / 'reaper.jsonl'
            if report['original_run'] is not None:
                raw = reaper_log.read_bytes()
                events = [json.loads(line) for line in raw.splitlines()]
                terminal = [event for event in events if event.get('event') == '完成']
                if len(terminal) != 1 or type(terminal[0].get('primary_returncode')) is not int:
                    raise RuntimeError('Original reaper did not record exactly one terminal primary exit')
                report['native_primary_exit'] = terminal[0]['primary_returncode']
                report['reaper_log'] = {'path': str(reaper_log), 'bytes': len(raw), 'sha256': sha(raw)}
                mapped_exit = report['native_primary_exit']
                if mapped_exit < 0:
                    mapped_exit = 128 - mapped_exit
                if report['original_run']['actual_process_returncode'] != mapped_exit:
                    raise RuntimeError('Original reaper process exit does not match its terminal primary exit')
        except BaseException:
            report['metadata_errors'].append(traceback.format_exc())
        try:
            report['logs_after'] = logs(copy=True)
            for name in ('core', 'bridge', 'model-base'):
                path = Path('/tmp/geometry-tests') / (name + '.fingerprint.json')
                if path.is_file():
                    raw = path.read_bytes()
                    target = out / ('original-binary-receipt-' + path.name)
                    target.write_bytes(raw)
                    report['binary_receipts'].append({'source': str(path), 'bytes': len(raw),
                                                      'sha256': sha(raw), 'snapshot': str(target)})
        except BaseException:
            report['metadata_errors'].append(traceback.format_exc())
        try:
            report['source_after'] = guard()
            report['input_after'] = inputs()
            if report['source_before'] != report['source_after'] or report['input_before'] != report['input_after']:
                raise RuntimeError('Source/index/input identity changed during execution')
        except BaseException:
            report['metadata_errors'].append(traceback.format_exc())
        try:
            for name, expected in report['tool_hashes'].items():
                if sha((HERE / name).read_bytes()) != expected or sha((out / 'tools' / name).read_bytes()) != expected:
                    raise RuntimeError('Tool/snapshot changed during execution: ' + name)
        except BaseException:
            report['metadata_errors'].append(traceback.format_exc())
        resource.setrlimit(resource.RLIMIT_STACK, (soft, hard))
        report['metadata_complete'] = not report['metadata_errors'] and report['original_run'] is not None
        report['ended_utc'] = now()
        original_exit = report['native_primary_exit']
        report['original_run_exit'] = original_exit
        report['reaper_process_exit'] = (report['original_run'] or {}).get('actual_process_returncode')
        report['outer_exit'] = report['reaper_process_exit'] if report['metadata_complete'] else 2
        capture.dump(out / 'receipt.json', report)
    print(json.dumps({'source_sha': args.sha, 'scope': 'PARTIAL four original native suites',
                      'original_run_exit': original_exit, 'metadata_complete': report['metadata_complete'],
                      'outer_exit': report['outer_exit'], 'receipt': str(out / 'receipt.json')}))
    return report['outer_exit']


if __name__ == '__main__':
    raise SystemExit(main())
