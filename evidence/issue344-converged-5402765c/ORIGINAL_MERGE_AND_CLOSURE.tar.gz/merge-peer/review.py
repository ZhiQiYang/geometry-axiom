from pathlib import Path
import hashlib,json,re,traceback
P=Path('/workspace/geo344-F2bbe-normal-merge-20261024')
OUT=Path(__file__).resolve().parent
checks=[]
def read(p):return json.loads(p.read_bytes())
def check(ok,label):
    checks.append({'name':label,'passed':bool(ok)})
    if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def raw(row):
    d=Path(row['directory']);check(d.is_relative_to(P),'original command belongs to this merge')
    check(read(d/'result.json')==row,'actual row identity')
    check(row['timeout_expired'] is False and row['ended_epoch']>=row['started_epoch'],'actual terminal no timeout')
    for stream in ['stdin','stdout','stderr']:
        f=d/(stream+'.bin');check(sha(f)==row[stream+'_sha256'],'original full '+stream+' hash')
        if stream!='stdin':check(f.stat().st_size==row[stream+'_bytes'],'original full '+stream+' length')
    return (d/'stdout.bin').read_bytes()
try:
    r=read(P/'RESULT.json');rows=read(P/'subcommands.json');w=read(P/'WHITESPACE_CLASSIFICATION.json')
    E='42790be40eee56efada08de84ab2acb1681df981';F='2bbe54f19b2d19e8a816530f0c4edca950629a34';S='5402765c795769a77a7b249de1e3db80045a41de'
    check((r['old_branch_head'],r['train_product'],r['source_sha'])==(E,F,S),'exact fixed source triple')
    check(r['exit']==0 and r['merge_actual_exit']==0 and r['source_pushed'] is False,'local ordinary merge0, not published')
    check(len(rows)==39,'39 original commands')
    blobs=[raw(row) for row in rows]
    check([row['actual_process_returncode'] for row in rows]==[2 if i==22 else 0 for i in range(39)],'only original full whitespace check2; all other actual exits0')
    check(blobs[1].decode().strip()==E and blobs[2].decode().strip()==E,'old local and fresh fetched source match')
    check(blobs[3].decode().strip()==r['branch'] and blobs[4]==b'','owned branch clean before')
    check(rows[9]['command'][6:]==['merge','--no-ff','--no-commit',F],'normal merge exact target')
    check(blobs[10]==blobs[11]==blobs[13]==b'' and blobs[12].decode().strip()==F,'real automatic merge has no unmerged stages')
    expected=read(P/'F-registry-original.json');old=read(P/'E0-registry-original.json');merged=read(P/'merged-registry.json')
    check(expected==json.loads(blobs[7]) and old==json.loads(blobs[8]),'registry originals match exact Git stdout')
    check('node:connection_recovery' not in expected['suites'],'train lacked this one row')
    check(old['suites']['node:connection_recovery']=={'mode':'count','count':9,'unit':'node test'},'original nine count not softened')
    expected['suites']['node:connection_recovery']=old['suites']['node:connection_recovery']
    check(merged==expected,'all train registry entries and metadata plus exact original nine row')
    controlled={'geometry-web/app.js','geometry-web/cdp_test.js','tests/run_all.py','tests/run_all.expected.json','tests/test_connection_recovery.js'}
    for i in range(14,22,2):check(blobs[i]==blobs[i+1],'source staged blob equals original #344 leaf')
    check(blobs[26].decode().strip()==S and blobs[27].decode().split()==[E,F],'new local exact SHA and ordered ordinary parents')
    check((P/'FINAL_VS_TRAIN.raw').read_bytes()==blobs[28],'complete original raw tree difference retained')
    delta={}
    for line in blobs[28].decode().splitlines():
        meta,name=line.split('\t',1);fields=meta.split();delta[name]=fields
        check(fields[1]=='100644','new file mode unchanged ordinary regular source/evidence')
    check({n for n in delta if not n.startswith('evidence/')}==controlled,'exact five non-evidence changes; no SSOT/native/golden/workflow change')
    check(sorted(delta)==sorted(r['relative_to_train_changed_paths'])==sorted(blobs[29].decode().splitlines()),'full final changed-path closure')
    registry_bytes=(P/'merged-registry.json').read_bytes();registry_blob=hashlib.sha1(b'blob '+str(len(registry_bytes)).encode()+b'\0'+registry_bytes).hexdigest()
    check(delta['tests/run_all.expected.json'][3]==registry_blob,'actual committed registry blob equals preserved merged bytes')
    for name,i in [('geometry-web/app.js',14),('geometry-web/cdp_test.js',16),('tests/run_all.py',18),('tests/test_connection_recovery.js',20)]:
        check(delta[name][3]==blobs[i].decode().strip(),'actual committed source blob retains #344 fix/test '+name)
    for i in range(30,38,2):check(blobs[i]==blobs[i+1],'protected SSOT/workflow/golden original blob preserved')
    check(blobs[38]==b'' and r['source_clean'] is True,'actual final checkout clean')
    check(r['full_merge_whitespace_exit']==w['full_merge_diff_check_actual_exit']==2,'original whitespace2 never relabeled0')
    check(r['full_merge_whitespace_command']==w['original_command']==rows[22],'original whitespace diagnostic linkage')
    warnings=sorted(set(re.findall(r'^(evidence/.*?):\d+:',blobs[22].decode(),re.M)))
    check(len(warnings)==48,'exact48 historical evidence warning paths')
    proof=w['proof_command'];pairs=raw(proof).decode().splitlines();args=proof['command'][3:]
    check(proof['actual_process_returncode']==0 and len(args)==len(pairs)==96,'original preservation read has exact96 OIDs')
    for i,name in enumerate(warnings):
        check(args[2*i:2*i+2]==[F+':'+name,S+':'+name],'exact original/final historical path pair')
        check(pairs[2*i]==pairs[2*i+1] and re.fullmatch('[0-9a-f]{40}',pairs[2*i]) is not None,'warned original blob identical; no evidence cleanup')
    check(rows[23]['actual_process_returncode']==0 and set(rows[23]['command'][10:])==controlled,'only five controlled sources whitespace check0')
    check(r['C_or_browser_executed'] is False and r['ledger_regenerated'] is False and r['new_formal_status']=='UNRUN','no current-source validation claims')
    report={'exit':0,'checks':len(checks),'findings':[],'source_sha':S,'parents':[E,F],'source_pushed':False,'commands_verified':40,'scope':'Original local merge receipts and exact Git blob IDs only; no new Git/network/C/Node/browser execution.','limitations':['Not push evidence; original local merge only.','All current-source node/canvas/ledger/architecture gates remain UNRUN.','Whole merge diff--check really exited2 for48 unchanged historical evidence blobs; five controlled source leaves separately exited0.']}
except BaseException:report={'exit':1,'checks':len(checks),'error':traceback.format_exc()}
(OUT/'CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False));raise SystemExit(report['exit'])
