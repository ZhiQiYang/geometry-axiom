# #344 與新列車的一般合流計畫（尚未執行）

本檔只準備本人所屬 `codex/issue320-connection-recovery-20261024`。不修改主列車，不合併 PR，不執行 C／Node／Chrome。主代理排定 R6 終態與其帳本／native 時槽之後，再執行以下合流。既有三階段 PLAN `da7990df6facb6a090db34281e8a6e7f3e74059acbe2199be9c0212293a374b5`、原測試／golden／35 分鐘時限不改。

來源固定：

| 角色 | SHA／路徑 |
|---|---|
| #344 已推分支 head E0 | `42790be40eee56efada08de84ab2acb1681df981` |
| #344 原產品 S0 | `7b45013da647b791acda8f5977475e4123d5f8c4` |
| 這次要納入的 train product F | `2bbe54f19b2d19e8a816530f0c4edca950629a34` |
| 唯一 merge base B | `2d1570691e4a29aafebdc0a4e739787d3fcdddaa` |
| #344 專用既有 clean sparse worktree | `/workspace/issue320-work-20261024` |
| 新合流來源 S1／新撤回來源 V1 | 尚未產生，禁止用 S0／V0 代填 |

原只讀 `ls-remote` 已核 #344 真公開 head 為 E0；初次查不存在的 origin tracking ref 得 128，原命令／stderr 保留，沒有 Git 寫入。再次只讀查遠端成功；正式合流前仍須 fresh fetch 和相同 head 守門。

B→E0 共 23 路徑：18 個本線舊 evidence、`geometry-web/app.js`、`geometry-web/cdp_test.js`、`tests/run_all.py`、`tests/run_all.expected.json`、`tests/test_connection_recovery.js`。B→F 共 4447 路徑；唯一共同變動路徑是 `tests/run_all.expected.json`。這是語意衝突預判，不冒稱已跑 Git merge 或保證沒有文字衝突。

#344 對 registry 的唯一變更是新增 `node:connection_recovery = {"mode":"count","count":9,"unit":"node test"}`；F 尚沒有這列。主列車其他 registry entries／counts 必全數保留。`tests/run_all.py` 在 B→F 沒有變動，#344 只新增 NODE_PURE_TEST_FILES 的對應路徑；app、cdp 與 node test 亦沒有同路徑雙方修改。若 Git 正常自動合流，仍要核合成 registry 等於 F 全部 entries 加上述原 9-count 列；若唯一 JSON 路徑衝突，按相同內容解決，不可整檔採舊分支而回退 train counts。任何超出已知一個路徑的衝突先保全部 index／raw，再依原三方內容解決，不更改公理或鎖定決定。

原正式指令準備如下；本檔沒有執行它們：

```bash
git -C /workspace/issue320-work-20261024 fetch origin refs/heads/codex/issue320-connection-recovery-20261024:refs/remotes/origin/codex/issue320-connection-recovery-20261024 refs/heads/codex/train-337-continue-20261024:refs/remotes/origin/codex/train-337-continue-20261024
git -C /workspace/issue320-work-20261024 rev-parse HEAD
git -C /workspace/issue320-work-20261024 symbolic-ref --short HEAD
git -C /workspace/issue320-work-20261024 status --porcelain=v1 --untracked-files=all
git -C /workspace/issue320-work-20261024 diff --cached --quiet
git -C /workspace/issue320-work-20261024 merge-base --is-ancestor 2bbe54f19b2d19e8a816530f0c4edca950629a34 refs/remotes/origin/codex/train-337-continue-20261024
git -C /workspace/issue320-work-20261024 merge --no-ff --no-commit 2bbe54f19b2d19e8a816530f0c4edca950629a34
```

必把前三項真輸出 assert 成 E0、本人分支、空 status，且 origin 本分支仍是 E0；不能把 `git status` 的 exit 0 當乾淨。fresh fetch 若 head 已前進，先重讀新提交後更新本計畫，不 force、不 reset。合流後保原 exit／MERGE_HEAD／unmerged stages。`git ls-files -u` 必最終為空，`git diff --cached --check` 必為 0；再以正常英文 commit 建立 S1：

```bash
git -C /workspace/issue320-work-20261024 commit -m "Merge current integration train into connection recovery fix"
git -C /workspace/issue320-work-20261024 show -s --format=%P HEAD
git -C /workspace/issue320-work-20261024 push origin HEAD:refs/heads/codex/issue320-connection-recovery-20261024
```

S1 必須正好以 E0、F 為父（依序），保持所有歷史收據與 fixtures；不可縮減 sparse index 變成 tracked deletion。S1 相對 F 的非 evidence 差異預期恰為上列五檔；S1 的 app.js／cdp_test.js／node JS／run_all.py 必保 E0 內容，registry 保 F+原9列。`公理層.md`、`決策佇列.md`、所有 C/H/inc 及原 golden/workflow 相對 F 不變；用 tracked path/mode/blob closure 核，不靠檔名猜測。一般 push 後保 ls-remote exact S1，才可稱可解析來源。

接著建立新獨立控制分支 `codex/issue320-connection-recovery-withdrawal-f2bbe-20261024`（若同名存在則先核身分，不覆寫）。V1 的唯一 parent 為公開 S1，且只把 app.js 內唯一：

```js
connection.phase = "ready"; connection.known = true; connection.error = "";
```

撤成：

```js
connection.phase = "ready"; connection.known = true;
```

固定字串須各自唯一，撤回後逆替換逐 byte 等 S1 app.js。完整 Git tree 比較只能有 app.js blob 改變，其 mode 不變，其他每個 tracked path/mode/blob 全等（尤其 cdp、node test、registry、golden、workflow）。以 `git worktree add --no-checkout -b` 開本人新 sparse checkout，使用原已核 fresh-index `sparse-checkout set --no-cone --stdin`＋`read-tree --dry-run -m -u S1`／`read-tree -m -u S1` 初始化，不 reset。正常英文 commit 與普通 push 建立 V1；此為測試用控制來源，禁止合入主列車。S0/V0 原歷史不改。

三階段 source 映射固定為 **S1 → V1 → S1**，使用新 fresh scratch。各原 driver 只改 SHA/root/out 的執行綁定，原 full `node geometry-web/cdp_test.js`、無 scope flags、HTTP19681/19682/19683、CDP9731/9732/9733、各 profile/TMPDIR 分離。固定／恢復原 Node 和 workflow 必 0 且原 golden 相符；撤回須真正常1及原 P53-3/P61-10/P61-11 三個具名語意紅與完整 GEO320_RECOVERY_PROOF，不能以 compile、timeout、環境失敗當 kill。每階段原35分鐘不變，3倍 watchdog僅保全原流，`over_ci_timeout=true` 即使 exit0亦不算綠。

合流與 control 來源建立只需現有 sparse source/index 的小量 Git 空間；執行前 fresh df、index/object 增量與主代理預留另記，不挪用正式瀏覽器預算。完整 canvas 所需 source／fixture closure、三支 core/bridge/model-base 原 freshness 與 compiler、Chrome、screenshots、原流的實際預算尚未配置；這份計畫不聲稱現有 thin checkout/runtime 可直接跑。實跑須 root 獨占兩個 heavy slots，子 driver 仍自己持 primary，外層只安排 secondary lease，避免同一 primary 重入。

S1 改動 JS 與 tests/run_all.py，mutate --check、架構 manifest 內 H／exclusion closure 和所有受影響正式項要依原規則判定；本線不自重產全 ledger，最後統一來源由 root 重產。新三相 full canvas 全部仍 UNRUN，原9／6／9 VM不代 Chrome證據。原F2bbe的 wall／架構／其他來源收據不移標 S1。
