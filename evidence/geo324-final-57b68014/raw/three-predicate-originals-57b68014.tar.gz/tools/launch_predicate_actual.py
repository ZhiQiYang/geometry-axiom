#!/usr/bin/env python3
"""Record the authorized unchanged v2 predicate run on a fresh sparse shared clone."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

B=Path('/tmp/geo324-owner-20261024');O=B/'predicate-actual-launch-57b68014'
SOURCE=Path('/tmp/geo324-predicate-source-57b68014');PROOF=Path('/tmp/geo324-predicate-proof-57b68014')
S='57b680140da2c6b77ab0d362a72029d8d7c9334b'
DRIVER=B/'preparation/run_face_predicate_proofs_v2.py';DRIVER_SHA='4b5c05f1a2d7a5cf24c1e2b4d21641c560a7fe7a25db1109a6127d315ddd406d'
HELPER=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');HELPER_SHA='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
if O.exists() or SOURCE.exists() or PROOF.exists():raise SystemExit('refuse overwrite any actual run path')
if sha(DRIVER)!=DRIVER_SHA or sha(HELPER)!=HELPER_SHA:raise SystemExit('original frozen driver/helper drifted')
O.mkdir();spec=importlib.util.spec_from_file_location('capture',str(HELPER));cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for name in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','PYTHONHOME','NODE_OPTIONS'):env.pop(name,None)
env['PYTHONDONTWRITEBYTECODE']='1'
request={'schema':'geo324.predicate-actual-launch.v1','sourceSHA':S,'source':str(SOURCE),'out':str(PROOF),'driver':str(DRIVER),'driverSHA256':DRIVER_SHA,'helperSHA256':HELPER_SHA,'launcherSHA256':sha(__file__),'R3':'not used by unchanged pure-Python driver; no lock bypass or formal-tool change','productCompilerBrowserPerfExecuted':False,'originalPerPhaseTimeoutSeconds':60,'workerCommand':[sys.executable,'-B',str(DRIVER),'--repo',str(SOURCE),'--expected-head',S,'--out',str(PROOF)],'effectiveExplicitClearedEnvironment':{k:env.get(k) for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','PYTHONHOME','NODE_OPTIONS')},'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
cap.dump(O/'REQUEST.json',request);rec=cap.Recorder(O,env,S)
result={'request':request,'exitCode':None,'errors':[],'proofAccepted':False}
def run(argv,cwd='/tmp',timeout=180,check=True):return rec.run(argv,cwd=cwd,timeout=timeout,check=check,source_sha=S,source_variant='geo324-authorized-original-three-predicate-actual')
try:
    run(['df','-B1','/tmp','/workspace'])
    run(['git','clone','--shared','--no-checkout','/workspace/geometry-axiom',str(SOURCE)])
    patterns=['/AGENTS.md','/geometry-core/geometry_kernel/','/geometry-core/modeling/','/geometry-app/geometry_app/','/geometry-templates/woodworking/geometry_woodworking/','/tests/test_geometry_host_sources.py','/tests/test_geometry_kernel_runtime.py','/tests/test_geometry_source_runtime.py']
    run(['git','sparse-checkout','set','--no-cone',*patterns],SOURCE)
    run(['git','-c','core.autocrlf=false','checkout','--detach',S],SOURCE)
    run([sys.executable,'--version'],SOURCE)
    _,head,_=run(['git','rev-parse','HEAD'],SOURCE);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'],SOURCE)
    if head.decode().strip()!=S or clean:raise RuntimeError('fresh subject not exact clean S')
    command,_,_=run(request['workerCommand'],SOURCE,timeout=600,check=False)
    result['originalDriverExit']=command['actual_process_returncode'];result['originalDriverTimeout']=command['timeout_expired']
    if not (PROOF/'receipt.json').is_file():raise RuntimeError('original driver did not produce receipt')
    inner=json.loads((PROOF/'receipt.json').read_text());result['originalReceiptSHA256']=sha(PROOF/'receipt.json');result['originalReceipt']=str(PROOF/'receipt.json')
    _,head,_=run(['git','rev-parse','HEAD'],SOURCE);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'],SOURCE)
    result['sourceAfter']={'head':head.decode().strip(),'porcelain':clean.decode()}
    result['originalRows']=[{'predicate':x['predicate'],'originalExitCodes':x['originalExitCodes'],'proofAccepted':x['proofAccepted'],'byteRestored':x['byteRestored']} for x in inner.get('rows',[])]
    result['proofAccepted']=command['actual_process_returncode']==0 and not command['timeout_expired'] and inner.get('proofAccepted') is True and inner.get('sourceSHA')==S and result['sourceAfter']=={'head':S,'porcelain':''}
    result['exitCode']=0 if result['proofAccepted'] else 1
except BaseException as error:result['errors'].append(repr(error));result['exitCode']=2
finally:
    result['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['commandCount']=len(rec.rows);cap.dump(O/'RESULT.json',result);print(json.dumps(result,ensure_ascii=False))
raise SystemExit(result['exitCode'])
