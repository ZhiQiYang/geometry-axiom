#!/usr/bin/env python3
"""Run original binaries.main with a private call-time OUT_DIR; no source changes."""
import hashlib
import importlib.util
from pathlib import Path
import sys
repo,cache=map(lambda p:Path(p).resolve(),sys.argv[1:3])
p=repo/'tests/binaries.py'
if hashlib.sha256(p.read_bytes()).hexdigest()!=sys.argv[3]:raise SystemExit('original binaries.py bytes mismatch')
spec=importlib.util.spec_from_file_location('binaries',p);b=importlib.util.module_from_spec(spec);sys.modules['binaries']=b;spec.loader.exec_module(b)
b.OUT_DIR=cache
for name in ('bridge','model-base'):
 if b.BY_NAME[name].path!=cache/b.BY_NAME[name].exe or b.BY_NAME[name].sidecar!=cache/(b.BY_NAME[name].exe+b.SIDECAR_SUFFIX):raise SystemExit('private call-time paths mismatch')
print('EXTERNAL_BINDING: original binaries.main([build,bridge,model-base]); private OUT_DIR='+str(cache),flush=True)
raise SystemExit(b.main(['build','bridge','model-base']))
