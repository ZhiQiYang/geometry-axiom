#!/usr/bin/env python3
"""Capture one frozen original partial native run under the scheduler's secondary lock."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import sys
D=Path(__file__).resolve().parent
O=Path('/tmp/geo324-native43-launch-57b68014-r1')
S='57b680140da2c6b77ab0d362a72029d8d7c9334b'
PIN='5b98988806f9ccf64ded7901b627674be074d6ee8913ed9fc57ceca4a7a41b56'
P=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
if O.exists():raise SystemExit('refuse overwrite')
if hashlib.sha256(P.read_bytes()).hexdigest()!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise SystemExit('capture mismatch')
manifest=D/'FROZEN_MANIFEST.json'
if hashlib.sha256(manifest.read_bytes()).hexdigest()!=PIN:raise SystemExit('manifest mismatch')
for name,row in json.loads(manifest.read_bytes())['files'].items():
 raw=(D/name).read_bytes()
 if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise SystemExit('frozen tool mismatch: '+name)
O.mkdir();env=dict(os.environ)
for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP'):env.pop(k,None)
env.update(PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
limit_before=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,limit_before[1]));limit_after=resource.getrlimit(resource.RLIMIT_STACK)
spec=importlib.util.spec_from_file_location('capture',P);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
argv=['flock','--nonblock','--conflict-exit-code','75','/tmp/g261r3/secondary.lock','env','-u','PYTHONOPTIMIZE','-u','PYTHONPATH','-u','PYTHONHOME','-u','PYTHONSTARTUP',sys.executable,'-B',str(D/'run_native_importers.py')]
req={'sourceSHA':S,'command':argv,'driverManifestSha256':PIN,'launcherSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'diskBefore':{p:shutil.disk_usage(p)._asdict() for p in ('/tmp','/workspace')},'stackLimitBefore':limit_before,'stackLimitAfter':limit_after,'scope':'Original native30/default13 module partial; no browser/performance/full-native.','secondaryLock':'nonblocking original scheduler path; busy75 is no subject execution'}
c.dump(O/'REQUEST.json',req);r=c.Recorder(O,env,S);row,out,err=r.run(argv,cwd=Path('/workspace'),timeout=5000,check=False,source_variant='fixed-S57-original-native-importer-43-partial')
c.dump(O/'RESULT.json',row);print(json.dumps(row,ensure_ascii=False),flush=True);print(out.decode('utf-8','replace'),flush=True);print(err.decode('utf-8','replace'),flush=True)
raise SystemExit(row['actual_process_returncode'])
