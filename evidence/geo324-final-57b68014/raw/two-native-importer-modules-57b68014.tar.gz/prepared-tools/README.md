僅準備，原subject尚未執行。固定S57b68014，擴既有clean薄source而不fullclone。479原計畫另補root公理層.md與已物化pure99 inputs；INPUT_MATERIALIZATION_PLAN.json為精確Git blob/mode清單，物化後逐bytes核，初末HEAD/status/index/input hash守門。

外層按root排程持 /tmp/g261r3/secondary.lock，未取得不可啟動；不取R3或改原工具鎖。argv：env -u PYTHONOPTIMIZE -u PYTHONPATH -u PYTHONHOME -u PYTHONSTARTUP python3 -B /tmp/geo324-owner-20261024/native43-preparation/run_native_importers.py。

原host_native30先跑，原_unittest_runner.py --json-out/--log；它的真fallback編譯60s原限不改。然後外部helper僅將binaries.OUT_DIR綁新私目錄並呼叫原main(build,bridge,model-base)；原每compile900s不改，build外收集上限2100s。default_native13再跑，明設兩個fresh覆寫，原require_fresh和全部assert保留，兩module1200s原限不改。原default13會核真source/ELF及frozenpackages，0skip才可收。

約6.5MB source/input plan（保守總預留60MiB含原Gitbatchraw、ELF與cc scratch）；未實跑前不是綠。原程序公開stdout/stderr全封，內部既有capture_output管線只封其實際公開輸出，不冒逐筆另封。非全native、非browser、非全importer。
