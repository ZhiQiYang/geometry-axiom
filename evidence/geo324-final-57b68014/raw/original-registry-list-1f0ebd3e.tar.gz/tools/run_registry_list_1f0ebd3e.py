#!/usr/bin/env python3
"""Original registry/discovery list only at merged M; no build, browser or test method."""
import ast,hashlib,importlib.util,json,os,sys
from pathlib import Path
B=Path('/tmp/geo324-owner-20261024');O=B/'registry-list-1f0ebd3e';R=Path('/tmp/geo324-predicate-source-57b68014');M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599';OLD='57b680140da2c6b77ab0d362a72029d8d7c9334b'
H=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(b):return hashlib.sha256(b).hexdigest()
if O.exists() or sha(H.read_bytes())!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise SystemExit('output/capture mismatch')
O.mkdir();sp=importlib.util.spec_from_file_location('capture',H);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);env=dict(os.environ)
for k in [k for k in env if k.startswith('GEOMETRY_')]+['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP']:env.pop(k,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=M)
rec=cap.Recorder(O,env,M);cap.dump(O/'REQUEST.json',{'sourceSHA':M,'reusedCheckoutBefore':OLD,'actualCommand':[sys.executable,'-B','tests/run_all.py','--list'],'driverSHA256':sha(Path(__file__).read_bytes()),'captureSHA256':sha(H.read_bytes()),'meaning':'Original registry/discovery list; does not execute test methods, build C, launch browser or compare full expected contract.','originalSourceArtifactsPreserved':'All S57 original raw/input Gitbatch/ELF/receipts already committed and pushed; this checkout now follows normal M source.'})
report={'sourceSHA':M,'errors':[],'originalExit':None,'exitCode':None,'testMethodsExecuted':False,'buildOrBrowser':False}
def run(a,data=None,check=True):return rec.run(a,cwd=R,data=data,timeout=180,check=check,source_sha=M,source_variant='original-registry-list-only')
try:
 _,head,_=run(['git','rev-parse','HEAD']);_,status,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
 if head.decode().strip()!=OLD or status:raise RuntimeError('original thin source drift')
 run(['git','checkout','--detach',M])
 _,source,_=run(['git','show',M+':tests/run_all.py']);tree=ast.parse(source);values={}
 for node in tree.body:
  if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
   name=node.targets[0].id
   if name in {'NODE_TEST_FILES','NODE_SCRIPT_FILE','NODE_DOCUMENT_SCRIPT_FILES','NODE_PURE_TEST_FILES','NODE_EXCLUDED','REQUIRED_OWNER_GATES','REQUIRED_BROWSER_GATES'}:values[name]=ast.literal_eval(node.value)
 wanted=set()
 for name,value in values.items():
  if isinstance(value,str):wanted.add(value)
  elif isinstance(value,dict):wanted.update(value.values() if name in {'NODE_DOCUMENT_SCRIPT_FILES','NODE_PURE_TEST_FILES'} else value.keys())
  else:wanted.update(value)
 _,top,_=run(['git','ls-tree','-z',M+':tests'])
 for entry in top.split(b'\0'):
  if not entry:continue
  header,name=entry.split(b'\t',1)
  if header.split()[1]==b'blob' and Path(name.decode()).suffix in ('.py','.js','.cjs','.mjs'):wanted.add('tests/'+name.decode())
 wanted.update(('tests/run_all.py','tests/binaries.py','tests/__init__.py'));paths=sorted(wanted)
 run(['git','sparse-checkout','add','--stdin'],data=('\n'.join('/'+p for p in paths)+'\n').encode())
 _,batch,_=run(['git','cat-file','--batch'],data=''.join(M+':'+p+'\n' for p in paths).encode());pos=0;inputs=[]
 for p in paths:
  end=batch.index(b'\n',pos);header=batch[pos:end].split();size=int(header[2]);start=end+1;raw=batch[start:start+size];pos=start+size+1
  if header[1]!=b'blob' or (R/p).read_bytes()!=raw:raise RuntimeError('registry input Git bytes differ: '+p)
  inputs.append({'path':p,'gitBlob':header[0].decode(),'bytes':size,'sha256':sha(raw)})
 if pos!=len(batch):raise RuntimeError('batch tail')
 cap.dump(O/'INPUTS.json',inputs)
 _,first,_=run(['git','ls-files','--stage','-z'])
 row,_,_=run([sys.executable,'-B','tests/run_all.py','--list'],check=False);report['originalExit']=row['actual_process_returncode'];report['originalRowDirectory']=row['directory']
 _,head,_=run(['git','rev-parse','HEAD']);_,status,_=run(['git','status','--porcelain=v1','--untracked-files=all']);_,last,_=run(['git','ls-files','--stage','-z'])
 same=all(sha((R/x['path']).read_bytes())==x['sha256'] for x in inputs);report['sourceAfter']={'head':head.decode().strip(),'porcelain':status.decode(),'inputHashesEqualBefore':same,'stagePrintedBytesEqual':first==last}
 report['exitCode']=0 if row['actual_process_returncode']==0 and not row['timeout_expired'] and report['sourceAfter']=={'head':M,'porcelain':'','inputHashesEqualBefore':True,'stagePrintedBytesEqual':True} else 1
except BaseException as e:report['errors'].append(repr(e));report['exitCode']=2
finally:report['commandCount']=len(rec.rows);cap.dump(O/'receipt.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
raise SystemExit(report['exitCode'])
