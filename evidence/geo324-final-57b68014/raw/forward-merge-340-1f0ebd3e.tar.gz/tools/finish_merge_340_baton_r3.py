#!/usr/bin/env python3
"""Finish read-only closure checks after committed merge; sparse evidence read by Git blob."""
import hashlib,importlib.util,json,os
from pathlib import Path
B=Path('/tmp/geo324-owner-20261024');O=B/'merge-340-4d3a17c3-r3';R=Path('/tmp/geo324-faces-work-20261024')
M='1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599';S='57b680140da2c6b77ab0d362a72029d8d7c9334b';BR='codex/geo324-faces-20261024';P=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def sha(raw):return hashlib.sha256(raw).hexdigest()
if O.exists() or sha(P.read_bytes())!='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762':raise SystemExit('out/pin mismatch')
O.mkdir();sp=importlib.util.spec_from_file_location('capture',P);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);rec=cap.Recorder(O,env,S)
cap.dump(O/'REQUEST.json',{'sourceHead':M,'originalExecutionSHA':S,'reason':'r1 no incoming object; r2 merge0 then metadata FileNotFoundError for sparse-unmaterialized own evidence. Read exact Git blob instead; no source/test change or rerun.','driverSha256':sha(Path(__file__).read_bytes())})
report={'sourceHead':M,'originalExecutionSHA':S,'errors':[],'exitCode':None,'testsExecuted':False}
def run(a,data=None):return rec.run(a,cwd=R,timeout=180,data=data,source_sha=S,source_variant='finish-ordinary-forward-baton-no-product-rerun')
try:
 _,h,_=run(['git','rev-parse','HEAD']);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
 if h.decode().strip()!=M or clean:raise RuntimeError('merged source drifted')
 prior=B/'merge-340-4d3a17c3-r2';original=json.loads(Path('/tmp/geo324-native43-57b68014-r1/INPUTS_BEFORE.json').read_bytes());rows=json.loads((prior/'subcommands.json').read_bytes())
 batchrow=next(x for x in rows if x['command'][:3]==['git','cat-file','--batch']);batch=(Path(batchrow['directory'])/'stdout.bin').read_bytes()
 if sha(batch)!=batchrow['stdout_sha256']:raise RuntimeError('prior raw batch drift')
 pos=0;changed=[]
 for item in original:
  end=batch.index(b'\n',pos);header=batch[pos:end].split();size=int(header[2]);start=end+1;raw=batch[start:start+size];pos=start+size+1
  if sha(raw)!=item['rawSha256']:changed.append({'path':item['path'],'oldSha256':item['rawSha256'],'newSha256':sha(raw),'oldGitBlob':item['gitBlob'],'newGitBlob':header[0].decode()})
 if pos!=len(batch) or any(x['path'] not in {'tests/test_rectangular_template.py','tests/run_all.expected.json','tests/test_geo261_mutation_migration.py','tests/test_geo261_wood_contact_world.py'} for x in changed):raise RuntimeError('broad493input unexpected change')
 productrow=rows[-1];raw=(Path(productrow['directory'])/'stdout.bin').read_bytes()
 if productrow['command'][:4]!=['git','diff','--name-only',S] or productrow['actual_process_returncode']!=0 or raw!=b'' or sha(raw)!=productrow['stdout_sha256']:raise RuntimeError('prior product-tree equality not proven')
 index=json.loads(run(['git','show',M+':evidence/geo324-final-57b68014/receipts/importers-nine-modules.json'])[1]);old=json.loads(run(['git','show',S+':tests/run_all.expected.json'])[1]);new=json.loads(run(['git','show',M+':tests/run_all.expected.json'])[1])
 if len(index['rows'])!=9 or any(old['suites']['py:'+x['suite']]!=new['suites']['py:'+x['suite']] for x in index['rows']):raise RuntimeError('nine selected contracts differ')
 report['closure']={'fullProductFourRootsAndCurrentCBytesEqualOriginalS':True,'original493InputSupersetChangedOnly':changed,'specifiedNineModuleContractsEqualOriginalS':True,'originalExecutionShaStill':S,'original142NotRerun':True,'notClaimed':['new source reran142','changed mutation-migration test acceptance','changed wood-contact test acceptance','changed noWood13 test acceptance at merge','full native/expected aggregate','browser','architecture receipts for faces W leaf','mutation ledger for merged source'],'basis':'原493物化集合廣於執行依賴；變更三個非target test葉不在九target/helper的執行路徑，expected九selected contract JSON相同；產品四根與currentC同S。架構衍生四檔與非執行FIELD-RULES另排除，不冒實測覆蓋。'}
 run(['git','push','origin','refs/heads/'+BR+':refs/heads/'+BR]);_,remote,_=run(['git','ls-remote','--exit-code','origin','refs/heads/'+BR]);report['remoteSourceHead']=remote.decode().split()[0]
 if report['remoteSourceHead']!=M:raise RuntimeError('remote mismatch')
 report['exitCode']=0
except BaseException as error:report['errors'].append(repr(error));report['exitCode']=1
finally:cap.dump(O/'receipt.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
raise SystemExit(report['exitCode'])
