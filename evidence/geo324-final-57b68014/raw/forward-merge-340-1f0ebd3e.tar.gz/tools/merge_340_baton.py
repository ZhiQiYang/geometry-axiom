#!/usr/bin/env python3
"""Ordinary forward merge; retain original acceptance SHA and record exact code closure."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
B=Path('/tmp/geo324-owner-20261024');O=B/'merge-340-4d3a17c3';R=Path('/tmp/geo324-faces-work-20261024')
S='57b680140da2c6b77ab0d362a72029d8d7c9334b';BEFORE='cfdfa078abb38a46bda72e10056ddcc0ef74fb42';INCOMING='4d3a17c306cad42057589c5cfd964f1c32b755c4';BR='codex/geo324-faces-20261024'
P=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');HP='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
def sha(raw):return hashlib.sha256(raw).hexdigest()
if O.exists():raise SystemExit('refuse overwrite')
if sha(P.read_bytes())!=HP:raise SystemExit('capture changed')
O.mkdir();spec=importlib.util.spec_from_file_location('capture',P);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1';rec=cap.Recorder(O,env,S)
cap.dump(O/'REQUEST.json',{'beforeHead':BEFORE,'incoming':INCOMING,'originalExecutionShaPreserved':S,'sourceBranch':BR,'operation':'ordinary merge --no-ff; no rebase/force push/PR merge','driverSHA256':sha(Path(__file__).read_bytes())})
report={'sourceBefore':BEFORE,'incoming':INCOMING,'originalExecutionSHA':S,'errors':[],'exitCode':None,'productTestsExecuted':False}
def run(argv,check=True,data=None):return rec.run(argv,cwd=R,timeout=180,check=check,data=data,source_sha=S,source_variant='ordinary-forward-340-baton-to-339')
try:
 _,h,_=run(['git','rev-parse','HEAD']);_,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
 if h.decode().strip()!=BEFORE or clean:raise RuntimeError('own source drift')
 run(['git','show','--no-patch','--format=%H %P',INCOMING]);run(['git','diff','--name-status',BEFORE,INCOMING,'--',':!evidence'])
 row,_,_=run(['git','merge','--no-ff',INCOMING,'-m','Merge no-woodworking validation branch into faces integration'],check=False)
 report['mergeProcessExit']=row['actual_process_returncode']
 if row['actual_process_returncode']!=0:raise RuntimeError('ordinary merge needs conflict resolution; original stream preserved')
 _,h,_=run(['git','rev-parse','HEAD']);M=h.decode().strip();report['sourceHead']=M
 _,parents,_=run(['git','rev-list','--parents','-n','1',M])
 if parents.decode().strip().split()!=[M,BEFORE,INCOMING]:raise RuntimeError('unexpected parents')
 _,delta,_=run(['git','diff','--name-status',INCOMING,M,'--',':!evidence']);report['incomingToMergeNameStatus']=delta.decode()
 if [line.split('\t')[-1] for line in delta.decode().splitlines()]!=['geometry-templates/woodworking/geometry_woodworking/model_sources.py','tests/run_all.expected.json','tests/test_geometry_host_sources.py']:raise RuntimeError('scope beyond original faces three files')
 for path in ['geometry-templates/woodworking/geometry_woodworking/model_sources.py','tests/test_geometry_host_sources.py']:
  _,a,_=run(['git','show',S+':'+path]);_,b,_=run(['git','show',M+':'+path])
  if a!=b:raise RuntimeError('faces original leaf changed')
 before=json.loads(run(['git','show',INCOMING+':tests/run_all.expected.json'])[1]);current=json.loads(run(['git','show',M+':tests/run_all.expected.json'])[1]);expected=json.loads(json.dumps(before));expected['suites']['py:test_geometry_host_sources']['count']=45
 if current!=expected or current['suites']['py:test_rectangular_template']['count']!=13:raise RuntimeError('expected union differs from only faces39to45/noWood13')
 for p in ['公理層.md','決策佇列.md']:
  if run(['git','show',M+':'+p])[1]!=run(['git','show',INCOMING+':'+p])[1]:raise RuntimeError('protected source bytes not incoming')
 original=json.loads(Path('/tmp/geo324-native43-57b68014-r1/INPUTS_BEFORE.json').read_bytes());paths=[x['path'] for x in original]
 _,batch,_=run(['git','cat-file','--batch'],data=''.join(M+':'+p+'\n' for p in paths).encode());pos=0;changed=[]
 for item in original:
  end=batch.index(b'\n',pos);header=batch[pos:end].split();length=int(header[2]);start=end+1;raw=batch[start:start+length];pos=start+length+1
  if sha(raw)!=item['rawSha256']:changed.append({'path':item['path'],'oldSha256':item['rawSha256'],'newSha256':sha(raw),'oldGitBlob':item['gitBlob'],'newGitBlob':header[0].decode()})
 if pos!=len(batch):raise RuntimeError('Git batch trailing data')
 allowed={'tests/test_rectangular_template.py','tests/run_all.expected.json','tests/test_geo261_mutation_migration.py','tests/test_geo261_wood_contact_world.py'}
 if any(x['path'] not in allowed for x in changed):raise RuntimeError('original493superset unexpected input change')
 _,product_changes,_=run(['git','diff','--name-only',S,M,'--','current_geometry.c','geometry-core','geometry-app','geometry-templates','geometry-web',':!geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',':!geometry-core/domain-decoupling/product-architecture.json',':!geometry-core/domain-decoupling/product-architecture-scan.json',':!geometry-core/domain-decoupling/product-architecture-receipt.json',':!geometry-templates/woodworking/FIELD-RULES.md'])
 if product_changes:raise RuntimeError('product/runtime/native source closure changed')
 module_names=[x['suite'] for x in json.loads((R/'evidence/geo324-final-57b68014/receipts/importers-nine-modules.json').read_bytes())['rows']]
 old_expected=json.loads(run(['git','show',S+':tests/run_all.expected.json'])[1])
 if any(old_expected['suites']['py:'+n]!=current['suites']['py:'+n] for n in module_names):raise RuntimeError('selected nine contracts changed')
 report['closure']={'fullProductFourRootsAndCurrentCBytesEqualOriginalS':True,'original493InputSupersetChangedOnly':changed,'specifiedNineModuleContractsEqualOriginalS':True,'originalExecutionShaStill':S,'notClaimed':['new source reran142','changed mutation-migration test acceptance','changed wood-contact test acceptance','changed noWood13 test acceptance at merge','full native/expected aggregate','browser','architecture receipts for faces W leaf','mutation ledger for merged source'],'basis':'原493是廣於實際執行的物化集合；變更的三個非target test葉不由九target modules/原helper/原mutationcontrols讀取；expected全檔有其他suite更新，但九selected contracts逐JSON相同。產品四根與currentC全部同S，原C fingerprints不讀tests葉。'}
 _,clean,_=run(['git','status','--porcelain=v1','--untracked-files=all'])
 if clean:raise RuntimeError('merge not clean')
 run(['git','push','origin','refs/heads/'+BR+':refs/heads/'+BR]);_,remote,_=run(['git','ls-remote','--exit-code','origin','refs/heads/'+BR]);report['remoteSourceHead']=remote.decode().split()[0]
 if report['remoteSourceHead']!=M:raise RuntimeError('remote merge mismatch')
 report['exitCode']=0
except BaseException as error:report['errors'].append(repr(error));report['exitCode']=1
finally:
 report['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['commandCount']=len(rec.rows);cap.dump(O/'receipt.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)
raise SystemExit(report['exitCode'])
