"""Capture the reviewed ten #339 source commands after an explicit source lease."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/geo324-predicate-source-57b68014')
PRIOR = '1f0ebd3e2108d6a4af6b436b5dd3f604df4b8599'
FINAL = '38da31bcac91db631e6325e40b228f8604810e82'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')

def digest(body):
    return hashlib.sha256(body).hexdigest()

def need(value, message):
    if not value:
        raise RuntimeError(message)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--root-source-lease', action='store_true', required=True)
    args = parser.parse_args()
    need(args.root_source_lease and not sys.flags.optimize, 'explicit source lease and active assertions required')
    command_bytes = (HERE / 'COMMANDS.json').read_bytes()
    need(digest(command_bytes) == '6e32c6d04f07d8c239aae013d816dc22d6858707fbceca6d0183f353039fdee9', 'reviewed original command pin')
    commands = json.loads(command_bytes)
    patterns = (HERE / 'EXACT_498_SOURCE.patterns').read_bytes()
    need(digest(patterns) == '0983e0d533995e4c1d03e2a6c376e734f5c8a32ab710d22bc8cd6fb9652b4374', 'reviewed exact498 stdin pin')
    need(digest(CAP.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'capture pin before import')
    need(commands['F'] == FINAL and commands['source'] == str(SOURCE), 'reviewed source identity')
    need(SOURCE.is_dir() and not SOURCE.is_symlink() and (SOURCE / '.git').is_dir()
         and not (SOURCE / '.git').is_symlink(), 'independent original source checkout required')
    out = args.out.absolute()
    need(out.parent.is_dir() and not out.exists() and out.is_relative_to(Path('/workspace')),
         'fresh workspace capture path required')
    need(not out.is_relative_to(SOURCE) and not SOURCE.is_relative_to(out)
         and not out.is_relative_to(HERE) and not HERE.is_relative_to(out), 'capture/source/tool must be disjoint')
    spec = importlib.util.spec_from_file_location('geo339_source_capture', CAP)
    cap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cap)
    env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
    for key in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
        env.pop(key, None)
    env.update(PYTHONDONTWRITEBYTECODE='1', LANG='C.UTF-8', LC_ALL='C.UTF-8', GIT_OPTIONAL_LOCKS='0')
    out.mkdir()
    recorder = cap.Recorder(out, env, FINAL)
    cap.dump(out / 'REQUEST.json', {
        'role': 'source materialization only; no compiler/test/subject',
        'sourceSHA': FINAL, 'requiredPriorSHA': PRIOR, 'source': str(SOURCE),
        'commandsSHA256': digest(command_bytes), 'patternsSHA256': digest(patterns),
        'driverSHA256': digest(Path(__file__).read_bytes()), 'argv': sys.argv,
        'freeBefore': {path: shutil.disk_usage(path).free for path in ('/tmp', '/workspace')},
        'rootSourceLeaseExplicit': True, 'subjectExecutions': 0,
    })
    result = {'sourceSHA': FINAL, 'requiredPriorSHA': PRIOR, 'commands': recorder.rows,
              'errors': [], 'subjectExecutions': 0, 'exitCode': 2}
    try:
        argv_list = commands['sourceMaterializationCommands']
        need(len(argv_list) == 10 and commands['sparseSetCommandIndex1Based'] == 6, 'original command layout')
        for index, argv in enumerate(argv_list):
            row, stdout, stderr = recorder.run(argv, cwd='/workspace', timeout=None, check=False,
                data=patterns if index == 5 else None, source_sha=PRIOR if index < 4 else FINAL,
                source_variant='reviewed-339-source-materialization-only')
            need(row['actual_process_returncode'] == 0, 'original Git command failed at index ' + str(index))
            if index in (0, 6):
                need(stdout.decode().strip() == (PRIOR if index == 0 else FINAL), 'exact original HEAD requirement')
            if index in (1, 7):
                need(stdout == b'', 'dirty or untracked source refused; no reset/clean performed')
            if index in (2, 3, 8, 9):
                need(stdout == b'', 'unexpected tracked source or index diff')
        result.update(exitCode=0, originalTenCommandsComplete=True, cleanFinalHEAD=FINAL)
    except BaseException:
        result['errors'].append(traceback.format_exc())
    finally:
        cap.dump(out / 'RESULT.json', result)
    print(json.dumps({key: value for key, value in result.items() if key != 'commands'}, ensure_ascii=False))
    return result['exitCode']

if __name__ == '__main__':
    raise SystemExit(main())
