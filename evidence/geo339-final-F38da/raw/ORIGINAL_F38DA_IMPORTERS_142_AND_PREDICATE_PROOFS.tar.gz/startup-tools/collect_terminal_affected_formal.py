"""Preserve terminal F38da importer/predicate originals without rerunning any subject."""
from pathlib import Path
import hashlib
import json
import stat
import tarfile

F = '38da31bcac91db631e6325e40b228f8604810e82'
DEST = Path('/workspace/geo339-F38da-affected-terminal-collection-20261024')
ROOTS = {
    'source-materialization': Path('/workspace/geo339-F38da-source-materialization-20261024'),
    'execution-capture': Path('/workspace/geo339-F38da-affected-formal-capture-20261024'),
    'predicates': Path('/tmp/geo339-three-predicates-F38da31bc'),
    'pure65': Path('/tmp/geo339-pure65-F38da31bc'),
    'pure18': Path('/tmp/geo339-pure18-F38da31bc'),
    'domain16': Path('/tmp/geo339-domain16-F38da31bc'),
    'native43': Path('/tmp/geo339-native43-F38da31bc'),
    'native43-launch': Path('/tmp/geo339-native43-launch-F38da31bc'),
}

def need(value, message):
    if not value:
        raise RuntimeError(message)

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def hfile(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

need(not DEST.exists(), 'fresh collection directory required')
material = read(ROOTS['source-materialization'] / 'RESULT.json')
outer = read(ROOTS['execution-capture'] / 'RESULT.json')
predicate = read(ROOTS['predicates'] / 'receipt.json')
groups = {name: read(ROOTS[name] / 'receipt.json') for name in ('pure65', 'pure18', 'domain16', 'native43')}
need(material['sourceSHA'] == F and material['exitCode'] == 0 and material['cleanFinalHEAD'] == F,
     'original successful source materialization required')
need(outer['sourceSHA'] == F and outer['completeFiveCommands'] is True and len(outer['commands']) == 5
     and type(outer['exitCode']) is int, 'real terminal five-command capture required')
need(predicate['sourceSHA'] == F and predicate.get('endedUTC') and type(predicate['exitCode']) is int,
     'real fixed-F predicate terminal required')
for name, value in groups.items():
    need(value['request']['sourceSHA'] == F and value.get('endedUTC') and type(value['exitCode']) is int,
         'real fixed-F terminal required: ' + name)
need(predicate['checkoutBefore']['head'] == predicate['checkoutAfter']['head'] == F
     and predicate['checkoutBefore']['status'] == predicate['checkoutAfter']['status'] == '',
     'predicate original source guard must restore')
for name, value in groups.items():
    after = value['sourceAfter']
    need(after['head'] == F and after['porcelain'] == '', 'original clean final source required: ' + name)
need(groups['native43']['sourceAfter']['inputsEqualBefore'] is True
     and groups['native43']['sourceAfter']['indexEqualBefore'] is True, 'native input/index restoration required')
DEST.mkdir()
rows, excluded, streams = [], [], []

def add(path, name, allow_elf=False):
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode), 'nonregular evidence refused: ' + str(path))
    with path.open('rb') as stream:
        elf = stream.read(4) == b'\x7fELF'
    row = {'name': name, 'source_path': str(path), 'bytes': info.st_size, 'sha256': hfile(path)}
    if elf:
        need(allow_elf, 'unexpected executable outside original native output')
        row['reason'] = 'Executable payload excluded from archive only; original executable retained at source_path'
        excluded.append(row)
    else:
        rows.append(row)

for label, root in ROOTS.items():
    for path in sorted(root.rglob('*')):
        if stat.S_ISDIR(path.lstat().st_mode):
            continue
        add(path, label + '/' + path.relative_to(root).as_posix(), allow_elf=(label == 'native43'))
    for row in read(root / 'subcommands.json'):
        directory = Path(row['directory'])
        need(directory.is_relative_to(root) and read(directory / 'result.json') == row,
             'original captured command result mismatch')
        for key in ('stdout', 'stderr'):
            path = directory / (key + '.bin')
            need(path.stat().st_size == row[key + '_bytes'] and hfile(path) == row[key + '_sha256'],
                 'full original captured stream required: ' + key)
        need(hfile(directory / 'stdin.bin') == row['stdin_sha256'] and (directory / 'request.json').is_file(),
             'original stdin/request required')
        streams.append({'directory': str(directory), 'actual_exit': row['actual_process_returncode'],
                        'timeout': row['timeout_expired'], 'source_sha': row['source_sha']})

for label, root in [('startup-tools', Path(__file__).parent),
                    ('original-frozen-tools', Path('/tmp/geo339-final-F38da-original-revalidation-preparation'))]:
    for path in sorted(root.rglob('*')):
        if not stat.S_ISDIR(path.lstat().st_mode):
            add(path, label + '/' + path.relative_to(root).as_posix())
for path in [Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py'),
             Path('/tmp/geo324-owner-20261024/preparation/run_face_predicate_proofs_v2.py')]:
    add(path, 'external-tools/' + path.name)
for path in [Path('/workspace/train337-canvas-peer-resume/geo339-startup/REVIEW.json'),
             Path('/workspace/train337-canvas-peer-resume/GEO339_MATERIALIZER_STATIC_PEER.json')]:
    add(path, 'preparation-peers/' + path.parent.name + '-' + path.name)

suite_rows = [row for value in groups.values() for row in value['rows']]
summary = {
    'schema': 'geo339-original-F38da-affected-terminal-collection/1', 'sourceSHA': F,
    'scope': 'Specified importer nine modules and three predicate proofs only; not aggregate native, six browsers, ledger, or architecture.',
    'outer_exit': outer['exitCode'],
    'original_group_exits': {name: value['exitCode'] for name, value in groups.items()},
    'predicate_exit': predicate['exitCode'], 'predicate_proof_accepted': predicate['proofAccepted'],
    'original_predicate_rows': predicate['rows'],
    'original_importer_rows': suite_rows,
    'observed_original_module_count': len(suite_rows),
    'observed_original_method_total': sum(row['originalResult']['total'] for row in suite_rows if row['originalResult']),
    'observed_original_method_run': sum(row['originalResult']['run'] for row in suite_rows if row['originalResult']),
    'observed_original_method_passed': sum(row['originalResult']['passed'] for row in suite_rows if row['originalResult']),
    'observed_original_method_failed': sum(row['originalResult']['failed'] for row in suite_rows if row['originalResult']),
    'observed_original_method_skipped': sum(row['originalResult']['skipped'] for row in suite_rows if row['originalResult']),
    'source_guards': {name: value['sourceAfter'] for name, value in groups.items()},
    'original_native_build_exit': groups['native43']['buildOriginalProcessExit'],
    'original_native_build_timeout': groups['native43']['buildTimeout'],
    'original_capture_rows': streams,
    'elf_payload_excluded_count': len(excluded), 'elf_payload_excluded_bytes': sum(row['bytes'] for row in excluded),
    'no_subject_executed_by_collector': True, 'no_existing_file_deleted': True,
    'limitations': ['Original exposed pipes only; internally unexposed subprocess pipes are not invented.',
                   'Existing ELF payloads remain unchanged at original paths and are represented here by hashes.',
                   'Original same-F terminal guards are used; live checkout/global native cache is not read.',
                   'Source-preparation first four commands correctly record priorM as source_sha; tested five phases use F.'],
}
save(DEST / 'SUMMARY.json', summary)
save(DEST / 'EXCLUDED_ELF_PAYLOADS.json', excluded)
for path in sorted(DEST.iterdir()):
    add(path, 'collection/' + path.name)
need(len({row['name'] for row in rows}) == len(rows), 'unique archive member names')
inventory = {'sourceSHA': F, 'members': rows, 'regular_file_count': len(rows),
             'logical_original_bytes': sum(row['bytes'] for row in rows)}
save(DEST / 'RAW_INVENTORY.json', inventory)
archive = DEST / 'ORIGINAL_F38DA_IMPORTERS_142_AND_PREDICATE_PROOFS.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6, dereference=True) as stream:
    for row in rows:
        stream.add(row['source_path'], arcname=row['name'], recursive=False)
    stream.add(DEST / 'RAW_INVENTORY.json', arcname='RAW_INVENTORY.json', recursive=False)
expected, seen = {row['name']: row for row in rows}, set()
with tarfile.open(archive, 'r:gz') as stream:
    for member in stream:
        need(member.isfile() and member.name not in seen, 'unique ordinary archive member required')
        seen.add(member.name)
        body = stream.extractfile(member).read()
        if member.name == 'RAW_INVENTORY.json':
            need(body == (DEST / 'RAW_INVENTORY.json').read_bytes(), 'inventory roundtrip')
        else:
            row = expected[member.name]
            need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
                 and hfile(Path(row['source_path'])) == row['sha256'], 'exact original byte roundtrip')
need(seen == set(expected) | {'RAW_INVENTORY.json'}, 'exact archive coverage')
package = {'sourceSHA': F, 'archive': {'path': str(archive), 'bytes': archive.stat().st_size,
           'sha256': hfile(archive), 'members': len(seen)},
           'inventory': {'path': str(DEST / 'RAW_INVENTORY.json'), 'sha256': hfile(DEST / 'RAW_INVENTORY.json')},
           'all_selected_original_bytes_roundtrip': True, 'existing_original_elf_files_retained': True,
           'subject_executions': 0, 'published': False}
save(DEST / 'PACKAGE.json', package)
print(json.dumps(package))
