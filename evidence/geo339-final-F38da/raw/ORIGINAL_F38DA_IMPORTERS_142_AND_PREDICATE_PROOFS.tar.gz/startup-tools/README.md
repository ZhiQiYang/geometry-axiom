#339 F38da 原142方法／三predicate反證啟動補充；未物化、未執行。

沿用 /tmp/geo339-final-F38da-original-revalidation-preparation/ 全部已備工具，SOURCE仍 /tmp/geo324-predicate-source-57b68014。不建新clone、不動root、ledger或browsercache。COMMANDS.json列精確Git物化及五個原launcher argv。全部Git指令須原c387事前REQUEST與完整輸出，先驗source仍clean M1f0；不符即保現況，不reset/clean。只有root給磁碟及自己的source lease後才checkout --detach F38da，再用EXACT_498_SOURCE.patterns作sparse set stdin。未動原frozen493plan或任何測試／門檻／時限。

此補充修正先前『493即可涵所有pure source guard』的不足。493是完整native輸入plan；原predicate/pure wrapper對整個package作git ls-tree，還會核geometry_kernel/README.md及rule_cases的Markdown。因此精確物化498=原493＋保留既有5個tracked MD（含AGENTS）。原native43只拒未知 .py/.json/.c/.h/.inc，這5個MD不放寬它。現在SOURCE有614檔，額外121是5MD/98JS/15CJS/3PY；那3個額外PY會被原native43守門拒絕，不能直接執行。精確sparse set將額外可重建tracked來源de-materialize，沒有evidence/fixtures/raw在此額外範圍；Git物件／歷史收據仍保。不授刪unknown/untracked/dirty檔；初始status非空即停物化，保原raw後分類處理。

實際現況僅stat：source已占10,174,464 allocatedB，private Git已占5,558,272B，皆已存在於/tmp，不是新需求。選498 logical7,000,974B／4096估計8,093,696B；原selected493全已在，並無新完整source snapshot。checkout/sparse重寫index仍可能暫需約5,405,585B（現index大小），故不能在root native r2僅剩1.86MB餘裕時執行。物化c387 metadata可寫WS，不把/tmp128MiB原起始需求再算第二次。

predicate原37個tracked inputs共354,973B，三份保留隔離copy payload1,064,919B，另有原Gitshow、完整streams、JSON/logs；這不是峰值上界。三pure wrapper原65＋18＋16=99、native43原30＋13=43，共142，predicate三控制另外記，不計成145方法。原native43臨時輸出預算60MiB是已備估計，不是裁判門檻／硬上界，另算source/index/outer streams。

路徑限制原樣：predicate --out明限resolve後/tmp；三pure及native43原frozen OUT常數也在/tmp，native43內部TMPDIR=OUT/tmp。此計畫沒有把它們悄悄搬WS、沒有產新adapter或放寬原判官；若未來TMP不足須root另授最小純path adaptation再peer。聚合fullnative／6browser不在這份142/predicate來源預算，仍UNRUN，不能冒此SOURCE已可跑全native。

按COMMANDS原順序三predicate→pure65→pure18→domain16→native43逐項收raw；pure sparse add會修改同一SOURCE的sparse metadata，不可並行。native43沿原secondary.lock非阻塞與原16MiB/1200/2100/5000原時限，忙75不是已執行gate。每個原script保真紅，收齊獨立項後分類；不放寬斷言。歷史142/三predicate仍舊S57，四gate仍M1f0，不回填新F綠。
