"""Capture the five frozen #339 partial acceptance commands; preserve every exit."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import sys

F = '38da31bcac91db631e6325e40b228f8604810e82'
HERE = Path(__file__).resolve().parent
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(CAP.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
raw = (HERE / 'COMMANDS.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '6e32c6d04f07d8c239aae013d816dc22d6858707fbceca6d0183f353039fdee9'
request = json.loads(raw)
assert request['F'] == F
material = json.loads(Path('/workspace/geo339-F38da-source-materialization-20261024/RESULT.json').read_bytes())
assert material['exitCode'] == 0 and not material['errors'] and material['cleanFinalHEAD'] == F
pins = [
    '4b5c05f1a2d7a5cf24c1e2b4d21641c560a7fe7a25db1109a6127d315ddd406d',
    '66ef361bd56b8a15094a72f05a2b0db1b1eee62c219fc28f7560d1b37cc8b751',
    '790a1b63bd828c072908330bdf26ffe262c439b701e30de04292dca060167738',
    '2a37794cf4d64896eb802b59ff70014cdcce2fc9fa970876db8ffb94302baaed',
    'aaf933498945bce69f87733e1bd593dfaf648eb2368486237fe2b4157a4347d3',
]
argvs = request['launchOriginalCommands']
assert len(argvs) == len(pins) == 5
for argv, pin in zip(argvs, pins):
    assert hashlib.sha256(Path(argv[2]).read_bytes()).hexdigest() == pin
out = Path('/workspace/geo339-F38da-affected-formal-capture-20261024')
out.mkdir()
spec = importlib.util.spec_from_file_location('capture', CAP)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for key in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'NODE_OPTIONS'):
    env.pop(key, None)
rec = c.Recorder(out, env, F)
c.dump(out / 'REQUEST.json', {
    'sourceSHA': F, 'argvs': argvs, 'driverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'originalDriverPins': pins, 'sourceMaterialization': '/workspace/geo339-F38da-source-materialization-20261024',
    'freeBefore': {p: shutil.disk_usage(p).free for p in ('/tmp', '/workspace')},
    'scope': 'Original importer partial142 and three independent predicate proofs; not aggregate native, browser, ledger or architecture.',
    'originalJudgesCountsTimeoutsUnchanged': True, 'outerTimeout': None,
    'continueIndependentAfterRed': True, 'privateNativeSecondaryLock': '/tmp/g261r3/secondary.lock',
})
result = {'sourceSHA': F, 'commands': rec.rows, 'exitCode': None, 'completeFiveCommands': False}
for index, argv in enumerate(argvs):
    row, stdout, stderr = rec.run(argv, cwd='/workspace', timeout=None, check=False,
        source_variant='original-F38da-affected-importer-partial-phase-' + str(index + 1))
    c.dump(out / 'RESULT.json', result)
    print(json.dumps({'phase': index + 1, 'actualProcessExit': row['actual_process_returncode']}, ensure_ascii=False), flush=True)
result.update(exitCode=0 if all(row['actual_process_returncode'] == 0 for row in rec.rows) else 1,
              completeFiveCommands=True)
c.dump(out / 'RESULT.json', result)
raise SystemExit(result['exitCode'])
