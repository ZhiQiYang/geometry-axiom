import json,hashlib
from pathlib import Path
O=Path('/workspace/geo340-339-L-normal-merges-20261024-r2');R=json.loads((O/'RESULT.json').read_text());A=json.loads((O/'subcommands.json').read_text());C=[]
def ck(n,b):C.append({'name':n,'pass':bool(b)})
def stdout(x):return (Path(x['directory'])/'stdout.bin').read_bytes()
def find(cmd):return [x for x in A if x['command'][5:]==cmd]
def one(cmd):
 a=find(cmd);ck('unique '+str(cmd),len(a)==1);return stdout(a[0])
ck('result expected pin',hashlib.sha256((O/'RESULT.json').read_bytes()).hexdigest()=='70c6e67901095d6ee4c0f7b377a5c78b3a3d97bfb80dbe4e0f824284b33fee78')
ck('terminal success',R['exitCode']==0 and not R['errors'] and R['kernelPushed'] and R['facesPushed'])
ck('138 Git commands',len(A)==138 and all(x['command'][0]=='git' for x in A))
for i,x in enumerate(A):
 ck(f'child{i} zero+no timeout',x['actual_process_returncode']==0 and not x['timeout_expired'])
 for stream in ['stdout','stderr','stdin']:
  b=(Path(x['directory'])/(stream+'.bin')).read_bytes();ck(f'child{i} {stream} hash',hashlib.sha256(b).hexdigest()==x[stream+'_sha256'])
 cmd=x['command'][5:]
 if cmd[0]=='status' or (cmd[0]=='diff' and '--exit-code' in cmd):ck(f'child{i} clean raw',stdout(x)==b'')
K=R['newKernelSource'];F=R['newFacesSource'];L=R['incomingL'];S=R['kernelParent'];E=R['facesBranchParent']
ck('kernel actual parents',one(['show','-s','--format=%P',K]).decode().split()==[S,L])
ck('faces actual parents',one(['show','-s','--format=%P',F]).decode().split()==[E,K])
for ref,sha in [('codex/kernel-without-woodworking-20261023',K),('codex/geo324-faces-20261024',F)]:
 rows=find(['ls-remote','--heads','origin','refs/heads/'+ref]);ck('final remote '+ref,stdout(rows[-1]).decode().split()==[sha,'refs/heads/'+ref]);ck('ordinary push '+ref,len(find(['push','origin','refs/heads/'+ref+':refs/heads/'+ref]))==1)
ledger='tests/mutants_results.json';expected=one(['ls-tree','-z',L,'--',ledger])
for sha in [K,F]:ck('ledger exact '+sha,one(['ls-tree','-z',sha,'--',ledger])==expected)
for path in R['originalElevenKernelGitEntries']:
 original=one(['ls-tree','-z',S,'--',path])
 for sha in [K,F]:ck('11 closure '+sha+path,one(['ls-tree','-z',sha,'--',path])==original)
for sha,host in [(K,39),(F,45)]:
 data=json.loads(one(['show',sha+':tests/run_all.expected.json']))
 # Registry is schema plus suite map.
 rows=data['suites'];ck('registry230 '+sha,len(rows)==230);ck('kernel13 '+sha,rows['py:test_rectangular_template']['count']==13);ck('host '+sha,rows['py:test_geometry_host_sources']['count']==host)
ck('dryrun before actual',A.index(find(['read-tree','--dry-run','-m','-u',S])[0])<A.index(find(['read-tree','-m','-u',S])[0]))
old=[x for x in A if x['cwd']=='/workspace/kernel-no-wood-work' and x['command'][5:]==['rev-parse','HEAD']]
ck('old bfb before and after raw',len(old)>=2 and all(stdout(x).decode().strip()==R['originalKernelCheckout']['head'] for x in old))
r1=json.loads(Path(R['originalEnvironmentFailureRetained']).read_text());ck('r1 environmental1 retained',r1['exitCode']==1 and not r1['kernelPushed'] and not r1['facesPushed'])
ck('formal flags absent',not any(R[x] for x in ['ledgerRegenerated','subjectTestsRun','sevenJobsRun','sourceEditsOtherThanOrdinaryMerges','largePayloadCopied']))
out={'scope':'Original R2 child raw hashes and semantic Git outputs, small metadata only; no Git mutation/C/whole tar reread','checks_total':len(C),'failed_checks':sum(not x['pass'] for x in C),'checks':C,'findings':[],'limit':'Stored source_sha=L is recorder provenance, not execution acceptance. New K/F formal remains UNRUN. Outer exit0 follows terminal RESULT and owner tool return.'}
Path(__file__).with_name('ACTUAL_MERGE_PEER.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['checks_total'],out['failed_checks']);raise SystemExit(bool(out['failed_checks']))
