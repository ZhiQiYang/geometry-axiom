from pathlib import Path
import json,hashlib
O=Path('/workspace/geo340-S175-selected-aggregate-20261024');L=Path('/workspace/geo340-S175-selected-aggregate-launch-20261024');R=json.loads((O/'RESULT.json').read_text());C=[]
def ck(n,b):C.append({'name':n,'pass':bool(b)})
def h(b):return hashlib.sha256(b).hexdigest()
ck('result pin',h((O/'RESULT.json').read_bytes())=='71efa5fc4c75f0afd592d2f9c2e6f45b80968c9d2f87ca6cd6c74eacd2c0f400');ck('actual terminal+subject0',R['exitCode']==R['subjectExit']==0 and not R['errors'])
for root in [O,L]:
 a=json.loads((root/'subcommands.json').read_text())
 for i,x in enumerate(a):
  ck(f'{root.name}child{i}exit',x['actual_process_returncode']==0 and not x['timeout_expired'])
  for stream in ['stdout','stderr','stdin']:ck(f'{root.name}child{i}{stream}',h((Path(x['directory'])/(stream+'.bin')).read_bytes())==x[stream+'_sha256'])
ck('outer0',json.loads((L/'RESULT.json').read_text())['actual_process_returncode']==0)
d=json.loads((O/'new-row-logs/py_test_rectangular_template.json').read_text());ck('13 strict counts',d['total']==d['run']==d['passed']==13 and d['failed']==d['skipped']==d['extra_errors']==0 and d['import_error'] is None);ck('exact original detail',d==R['originalUnittestDetail'])
b=json.loads((O/'before-source.json').read_text());a=json.loads((O/'after-source.json').read_text());ck('329 same source entries',len(b)==329 and b==a)
ck('globalcache raw metadata equal',(O/'GLOBAL_CACHE_BEFORE.json').read_bytes()==(O/'GLOBAL_CACHE_AFTER.json').read_bytes())
prior=json.loads((O/'PRIOR_ROW_LOGS.json').read_text())
for name,x in prior.items():
 z=(O/'prior-row-logs'/name).read_bytes();ck('preserved original '+name,len(z)==x['bytes'] and h(z)==x['sha256']);ck('shared restored '+name,Path(x['path']).read_bytes()==z)
n=json.loads((O/'NATIVE_LOG.json').read_text())['commands'];ck('35 native31zero4one',len(n)==35 and sum(x['exit']==0 for x in n)==31 and sum(x['exit']==1 for x in n)==4)
f=[x for x in n if x['exit']==1];ck('divisibility named failure','FRACTIONAL_CELL_ACCEPTED' in f[0]['stderr']);ck('quoted normal assertion','quoted-one-k-to-template-include'==f[1]['isolation_gate'] and 'AssertionError:' in f[1]['stderr'] and 'FAILED (failures=1)' in f[1]['stderr']);ck('angle normal assertion','angled-one-k-to-template-include'==f[2]['isolation_gate'] and 'AssertionError:' in f[2]['stderr'] and 'FAILED (failures=1)' in f[2]['stderr']);ck('expected missing grid symbol','undefined reference to `geo_interval_subdivide' in f[3]['stderr'])
ck('not full acceptance',R['fullAggregate']==R['sevenJobsRun']==R['ledgerRegenerated']==False)
r={'checks_total':len(C),'failed_checks':sum(not x['pass'] for x in C),'checks':C,'findings':[],'limits':['Original selected aggregate row at S175, not full native/CI/general readiness.','Compiler/runtime text logs retain original capture limitations; no new C execution or raw byte capture invented.','329 before/after manifests compared, original wrapper validates each Gitblob; peer did not rehash entire closure.','Shared log restoration checks are as observed now; subsequent legitimate runners may update them.']};Path(__file__).with_name('GEO340_AGGREGATE_ACTUAL_PEER.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['checks_total'],r['failed_checks']);raise SystemExit(bool(r['failed_checks']))
