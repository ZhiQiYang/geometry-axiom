"""Ordinary source-only owner merges after root releases performance exclusivity."""
from pathlib import Path
import argparse
import ast
import datetime
import hashlib
import importlib.util
import json
import os
import re

ap = argparse.ArgumentParser()
ap.add_argument('--root-performance-released', action='store_true', required=True)
args = ap.parse_args()
R = Path('/tmp/geo324-faces-work-20261024')
K = Path('/tmp/geo340-L-merge-work-20261024')
OLD_K = Path('/workspace/kernel-no-wood-work')
O = Path('/workspace/geo340-339-L-normal-merges-20261024')
B340 = 'codex/kernel-without-woodworking-20261023'
B339 = 'codex/geo324-faces-20261024'
L = '7af8c5d80d34cb4f49d01ba67deb78a3a6d725db'
S = '4d3a17c306cad42057589c5cfd964f1c32b755c4'
F = '38da31bcac91db631e6325e40b228f8604810e82'
E339 = '1d94ab77ab29952d5b73ec5b262dfd239819fe25'
OLD = 'bfbab207a92a809fca50fefcefb3fa4b2af05ea9'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
NEED_WS = 30 * 1024 * 1024  # 20 MiB merge planning reserve plus root's 10 MiB collector reserve.
NEED_TMP = 16 * 1024 * 1024

def need(value, message):
    if not value:
        raise RuntimeError(message)

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

need(hashlib.sha256(CAP.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'original capture pin')
O.mkdir()
spec = importlib.util.spec_from_file_location('cap', CAP)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')
for key in ('PYTHONOPTIMIZE', 'GIT_INDEX_FILE', 'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR'):
    env.pop(key, None)
rec = cap.Recorder(O, env, L)
report = {'schema': 'geo340-339-ordinary-L-source-merges/1', 'incomingL': L, 'kernelParent': S,
          'facesProductParent': F, 'facesBranchParent': E339, 'newKernelSource': None,
          'newFacesSource': None, 'kernelPushed': False, 'facesPushed': False,
          'originalKernelCheckout': {'path': str(OLD_K), 'head': OLD},
          'ledgerRegenerated': False, 'subjectTestsRun': False, 'sevenJobsRun': False,
          'sourceEditsOtherThanOrdinaryMerges': False, 'largePayloadCopied': False,
          'errors': [], 'spaceObservations': [], 'exitCode': None,
          'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat()}

def run(argv, cwd=R, data=None, allowed=(0,)):
    command = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *argv]
    row, out, err = rec.run(command, cwd=cwd, data=data, timeout=None, check=False,
        source_sha=L, source_variant='ordinary-source-merges-only-no-formal-execution')
    need(row['actual_process_returncode'] in allowed, 'Git command failed: ' + str(row['directory']))
    return out, row['actual_process_returncode']

def git(*argv, cwd=R, data=None):
    return run(list(argv), cwd=cwd, data=data)[0]

def head(cwd):
    value = git('rev-parse', 'HEAD', cwd=cwd).decode().strip()
    need(re.fullmatch('[0-9a-f]{40}', value), 'full real HEAD')
    return value

def clean(cwd, expected, branch=None):
    need(head(cwd) == expected, 'unexpected checkout HEAD: ' + str(cwd))
    if branch:
        need(git('symbolic-ref', '--short', 'HEAD', cwd=cwd).decode().strip() == branch, 'wrong owner branch')
    need(git('status', '--porcelain=v1', '--untracked-files=all', cwd=cwd) == b'', 'dirty checkout refused')
    need(git('diff', '--cached', '--exit-code', '--name-status', 'HEAD', cwd=cwd) == b'', 'index differs from HEAD')
    need(git('diff', '--exit-code', '--name-status', cwd=cwd) == b'', 'tracked checkout differs from index')

def remote(branch):
    lines = git('ls-remote', '--heads', 'origin', 'refs/heads/' + branch).splitlines()
    need(len(lines) == 1 and lines[0].split(b'\t')[1] == ('refs/heads/' + branch).encode(), 'one exact remote branch')
    return lines[0].split(b'\t')[0].decode()

def space(stage):
    values = {p: os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ('/workspace', '/tmp')}
    report['spaceObservations'].append({'stage': stage, 'availableBytes': values})
    dump(O / 'LIVE.json', report)
    need(values['/workspace'] >= NEED_WS and values['/tmp'] >= NEED_TMP,
         'ENV_SPACE: preserve 20 MiB WS merge plus 10 MiB collector and 16 MiB TMP reserves; no guard reduction')

def entry(ref, path):
    raw = git('ls-tree', '-z', ref, '--', path)
    rows = raw.split(b'\0')
    need(len(rows) == 2 and not rows[1], 'one exact tree entry: ' + path)
    meta, found = rows[0].split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    need(found.decode() == path and mode == '100644' and kind == 'blob', 'regular exact source entry: ' + path)
    return {'mode': mode, 'type': kind, 'blob': oid}

def non_evidence(a, b):
    raw = git('diff', '--name-only', '-z', a, b)
    paths = [x.decode() for x in raw.split(b'\0') if x]
    return sorted(x for x in paths if not x.startswith('evidence/'))

def expected(ref, host_count):
    obj = json.loads(git('show', ref + ':tests/run_all.expected.json'))['suites']
    need(len(obj) == 230, 'unchanged 230 suite registry at this two-line convergence')
    need(obj['py:test_rectangular_template'] == {'mode':'count','count':13,'unit':'unittest'}, 'retain kernel 13')
    need(obj['py:test_geometry_host_sources'] == {'mode':'count','count':host_count,'unit':'test'}, 'retain host count')
    return {'suiteEntries': len(obj), 'kernel': obj['py:test_rectangular_template'], 'host': obj['py:test_geometry_host_sources']}

try:
    space('before-any-source-mutation')
    clean(R, E339, B339)
    clean(OLD_K, OLD, B340)
    need(not K.exists(), 'new kernel worktree path must be absent')
    need(git('config', '--get', 'extensions.worktreeConfig').decode().strip() == 'true', 'existing per-worktree config required; do not alter shared sparse settings')
    _, branch_exit = run(['show-ref', '--verify', '--quiet', 'refs/heads/' + B340], allowed=(0,1))
    need(branch_exit == 1, 'new common-repo kernel branch must be absent')
    need(remote(B340) == S and remote(B339) == E339, 'remote source drift; reanalyse before fetching or writing')
    for value in (L, S, F):
        git('cat-file', '-e', value + '^{commit}')
    need(non_evidence(F, E339) == [], 'latest faces branch only evidence after F')
    common_base = git('merge-base', '--all', L, S).decode().strip()
    need(common_base == '9a05ae785846446ce8982379b4cb66f4ffde6e5c', 'fixed merge base')
    need(non_evidence(common_base, L) == ['tests/mutants_results.json'], 'L changes only ledger outside evidence')
    need(non_evidence(common_base, S) == ['tests/run_all.expected.json','tests/test_rectangular_template.py'], 'fixed kernel delta')
    kernel_request = json.loads(Path('/tmp/nowood-bfbab207-prepared-20261023/REQUEST_SLOT2.json').read_text())
    original_inputs = kernel_request['immutable_inputs']
    need(len(original_inputs) == 11, 'eleven original kernel inputs')
    kernel_entries = {x['path']: entry(S, x['path']) for x in original_inputs}
    for path, value in kernel_entries.items():
        need(entry(OLD, path) == value, 'original 11 inputs retained at S')
    ledger = entry(L, 'tests/mutants_results.json')
    report['incomingLedgerGitEntry'] = ledger
    report['originalElevenKernelGitEntries'] = kernel_entries
    patterns = ''.join('/' + x['path'] + '\n' for x in original_inputs)
    patterns += '/AGENTS.md\n/.gitattributes\n/.gitignore\n/geometry-guide/PRODUCT-VISION.md\n/tests/run_all.expected.json\n'
    (O / 'KERNEL_SPARSE_STDIN.txt').write_text(patterns)
    git('worktree', 'add', '--no-checkout', '-b', B340, str(K), S)
    git('sparse-checkout', 'set', '--no-cone', '--stdin', cwd=K, data=patterns.encode())
    clean(K, S, B340)
    need(not (K/'tests/mutants_results.json').exists(), 'new small kernel checkout does not copy 10 MB ledger')
    space('before-kernel-normal-merge')
    git('merge', '--no-ff', '-m', 'Merge final train ledger into isolated kernel acceptance branch', L, cwd=K)
    s1 = head(K)
    report['newKernelSource'] = s1
    need(git('show', '-s', '--format=%P', s1).decode().split() == [S,L], 'kernel exact ordinary parents')
    clean(K, s1, B340)
    need(non_evidence(S, s1) == ['tests/mutants_results.json'], 'kernel merge adds only L ledger outside evidence')
    need(non_evidence(L, s1) == ['tests/run_all.expected.json','tests/test_rectangular_template.py'], 'kernel exact delta over L')
    need(entry(s1, 'tests/mutants_results.json') == ledger, 'kernel exact L ledger blob/mode')
    for path, value in kernel_entries.items():
        need(entry(s1, path) == value, 'kernel input preserved after merge')
    report['kernelExpected'] = expected(s1, 39)
    kernel_ast = ast.parse(git('show', s1 + ':tests/test_rectangular_template.py'))
    need(sum(isinstance(x, ast.FunctionDef) and x.name.startswith('test_') for x in ast.walk(kernel_ast)) == 13, 'kernel static 13 methods; not runtime pass')
    clean(OLD_K, OLD, B340)
    git('push', 'origin', 'refs/heads/' + B340 + ':refs/heads/' + B340, cwd=K)
    need(remote(B340) == s1, 'published exact new kernel source')
    report['kernelPushed'] = True
    dump(O / 'KERNEL_TERMINAL.json', report)
    space('before-faces-normal-merge')
    clean(R, E339, B339)
    need(remote(B339) == E339, 'faces remote has not changed during first merge')
    git('merge', '--no-ff', '-m', 'Merge refreshed isolated kernel branch into faces validation', s1)
    f1 = head(R)
    report['newFacesSource'] = f1
    need(git('show', '-s', '--format=%P', f1).decode().split() == [E339,s1], 'faces exact ordinary parents')
    clean(R, f1, B339)
    need(non_evidence(F, f1) == ['tests/mutants_results.json'], 'faces merge preserves every F non-evidence source except incoming L ledger')
    need(entry(f1, 'tests/mutants_results.json') == ledger, 'faces exact L ledger blob/mode')
    report['facesExpected'] = expected(f1, 45)
    for path, value in kernel_entries.items():
        need(entry(f1, path) == value, 'kernel input preserved in faces merge')
    git('merge-base', '--is-ancestor', s1, f1)
    git('merge-base', '--is-ancestor', L, f1)
    clean(OLD_K, OLD, B340)
    git('push', 'origin', 'refs/heads/' + B339 + ':refs/heads/' + B339)
    need(remote(B339) == f1, 'published exact new faces source')
    report['facesPushed'] = True
    clean(K, s1, B340)
    clean(R, f1, B339)
    clean(OLD_K, OLD, B340)
    report.update(exitCode=0, formalResultsAtNewSources='UNRUN; no old execution SHA relabelled',
                  sourceOnlyOrdinaryPushes=True, globalLedgerDeferredToRoot=True)
except BaseException:
    import traceback
    report['errors'].append(traceback.format_exc())
    report['exitCode'] = 1
finally:
    report['endedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    dump(O / 'RESULT.json', report)
print(json.dumps(report, ensure_ascii=False))
raise SystemExit(report['exitCode'])
