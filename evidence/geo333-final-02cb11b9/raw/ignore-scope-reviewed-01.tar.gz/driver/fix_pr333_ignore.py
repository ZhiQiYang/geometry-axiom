"""Narrow PR333 to its tracked document and prove the ignore-policy correction."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path

BASE = Path('/workspace/geo333-field-rules')
REPO = Path('/workspace/geo333-field-rules-work')
SOURCE = '3d9bd9476b5eda05e1cb92338ee741b90019dff2'
BRANCH = 'grok/woodworking-field-rules-20261023'
FIELD = 'geometry-templates/woodworking/FIELD-RULES.md'
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('capture', helper)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
BASE.mkdir()
r = capture.Recorder(BASE, dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1'), SOURCE)

def cmd(args, cwd=REPO, **kwargs):
    row, out, err = r.run(args, cwd=cwd, **kwargs)
    return row, out, err

def git(*args, **kwargs):
    return cmd(['git', *args], **kwargs)[1].decode().strip()

assert not REPO.exists()
assert git('ls-remote', 'https://github.com/ZhiQiYang/geometry-axiom.git', 'refs/heads/' + BRANCH,
           cwd=Path('/workspace/geometry-axiom')).split()[0] == SOURCE
cmd(['git', 'clone', '--shared', '--no-checkout', '/workspace/geometry-axiom', str(REPO)], cwd=Path('/workspace'))
git('remote', 'set-url', 'origin', 'https://github.com/ZhiQiYang/geometry-axiom.git')
git('config', 'core.autocrlf', 'false')
git('sparse-checkout', 'set', '--no-cone', '--stdin',
    data=b'/.gitignore\n/AGENTS.md\n/geometry-templates/woodworking/FIELD-RULES.md\n')
git('switch', '-c', BRANCH, SOURCE)
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
field_before = (REPO / FIELD).read_bytes()
old = (REPO / '.gitignore').read_bytes()
needle = '# 平釘下角材現場規則單頁。允許清單沒有這層時，新目錄不會進 git。\n!/geometry-templates/\n'.encode()
assert old.count(needle) == 1
fixed = old.replace(needle, b'', 1)
(REPO / '.gitignore').write_bytes(fixed)
assert git('diff', '--name-only') == '.gitignore'
git('diff', '--', '.gitignore')
git('add', '--', '.gitignore')
git('diff', '--cached', '--check')
git('commit', '-m', 'Keep field rules within the existing ignore allowlist')
final = git('rev-parse', 'HEAD')
git('push', 'origin', 'HEAD:refs/heads/' + BRANCH)
assert git('ls-remote', '--heads', 'origin', BRANCH).split()[0] == final
r.sha = final
receipt = {'source_sha': final, 'parent_sha': SOURCE, 'branch': BRANCH,
           'field_rules_sha256': hashlib.sha256(field_before).hexdigest(),
           'phases': [], 'acceptance_exit': None,
           'scope': 'ignore policy only; no product, axiom, reader, golden, test, or threshold edits'}
capture.dump(BASE / 'receipt.json', receipt)
try:
    for name, content, expected in [('fixed', fixed, 0), ('withdrawn', old, 1), ('restored', fixed, 0)]:
        (REPO / '.gitignore').write_bytes(content)
        row, stdout, stderr = cmd(['git', '-c', 'core.excludesFile=/dev/null', 'check-ignore', '--no-index',
            '-v', 'geometry-templates/woodworking/notes.txt'], check=False, source_sha=final,
            source_variant='ignore-policy-' + name)
        actual = row['actual_process_returncode']
        if actual not in (0, 1):
            raise RuntimeError('Ignore checker failed before policy evaluation')
        policy_exit = actual
        message = ('PASS: untracked woodworking sibling is ignored' if policy_exit == 0
                   else 'ASSERT_FIELD_RULES_ALLOWLIST: untracked woodworking sibling escaped the root allowlist')
        (BASE / (name + '-assertion.txt')).write_text(message + '\n')
        print(name + ': ' + message)
        git('ls-files', '--error-unmatch', '--', FIELD, source_sha=final, source_variant='ignore-policy-' + name)
        assert (REPO / FIELD).read_bytes() == field_before
        receipt['phases'].append({'name': name, 'policy_exit': policy_exit, 'expected_exit': expected,
            'original_git_exit': actual, 'command_result': row, 'assertion': message,
            'gitignore_sha256': hashlib.sha256(content).hexdigest(), 'tracked_field_unchanged': True})
        capture.dump(BASE / 'receipt.json', receipt)
        if policy_exit != expected:
            raise RuntimeError('Policy phase did not match the required fixed/withdrawn/restored behavior')
finally:
    (REPO / '.gitignore').write_bytes(fixed)
    receipt['restored_bytes_equal'] = (REPO / '.gitignore').read_bytes() == fixed
    receipt['field_bytes_equal'] = (REPO / FIELD).read_bytes() == field_before
    receipt['final_head'] = git('rev-parse', 'HEAD', source_sha=final)
    receipt['final_status'] = git('status', '--porcelain=v1', '--untracked-files=all', source_sha=final)
    capture.dump(BASE / 'receipt.json', receipt)
assert receipt['final_head'] == final and receipt['final_status'] == ''
assert [p['policy_exit'] for p in receipt['phases']] == [0, 1, 0]
receipt['acceptance_exit'] = 0
receipt['commands'] = r.rows
capture.dump(BASE / 'receipt.json', receipt)
print(json.dumps({'source_sha': final, 'proof': [0, 1, 0], 'acceptance_exit': 0, 'branch': BRANCH}))
