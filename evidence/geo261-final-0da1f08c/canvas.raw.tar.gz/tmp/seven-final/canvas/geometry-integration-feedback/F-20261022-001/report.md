# F-20261022-001 · 不符預期 · 2026-10-22 09:19:09

- 狀態:**open**
- 使用者說:P38 測試:這裡怪怪的
- 指到的元素:`button.fi-tab[data-fi-tab="components"] < nav#faceInspectorTabs` 「構件」 位置 [1216, 62, 71, 33](元素用途查 geometry-web/docs/DOM-CONTRACT.md)
- 畫面:面工作區 · 面 1(工具 select)
- 狀態快照:`{"oc": {"on": true, "tool": "select", "drawTool": null, "focus": {"t": "face", "id": 1}, "stack": [], "sel": null, "zoom": 1, "counts": {"faces": 1, "spaces": 0, "columns": 0, "beams": 0}}, "fe": {"tool": "select", "fiTab": "prop", "draftPts": 0, "lenBuf": ""}, "threeView": {"open": false, "tool": "view"}, "pendingSlot": null, "dialogs": [], "bodyClass": "", "activeElement": "textarea#fbNote"}`
- 視窗:1382×900 @1x;場景:room_a.scene(/workspace/geometry-axiom/room_a.scene)
- 程式版本:0da1f08c

## 回報前的操作(最後 40 筆,時間相對於按下回報)

-    -2.8s api ✓ `boundary 1`
-    -2.8s api ✓ `section-profile-read`
-    -2.8s api ✓ `line canvas-pos boundary 1 60 60`
-    -2.8s api ✓ `boundary 1`
-    -2.7s api ✓ `obstacles 1`
-    -2.7s api ✓ `references`
-    -2.7s api ✓ `dump`
-    -2.7s api ✓ `source-inspect`
-    -2.7s 狀態列 工具：選取
-    -2.7s 狀態列 面 1 · 選取
-    -2.7s api ✓ `dump`
-    -2.7s 點 button#refParameterOpen
-    -2.7s api ✓ `references`
-    -2.5s 改值 select#paramSpec = "主支中線"
-    -2.5s 點 input#paramSpecValue
-    -2.3s 鍵 Ctrl+a（input#paramSpecValue）
-    -2.2s api ✓ `dump`
-    -2.0s 點 button#paramSpecSave
-    -2.0s 改值 input#paramSpecValue = "900"
-    -1.9s api ✗ `line spec 主支中線 900` → line 734: I8a: impact preview required; inspect preview, then confirm token (World unchanged)
-    -1.7s 鍵 Escape（button.btn < div.impact-actions < dialog.reference-impact < body < html）
-    -1.7s api ✓ `line cancel-preview`
-    -1.7s 狀態列 ✗ 已取消；場景保持原狀
-    -1.7s toast[error] 已取消；場景保持原狀
-    -1.5s api ✓ `dump`
-    -1.4s api ✓ `default`
-    -1.4s api ✓ `objects`
-    -1.4s api ✓ `surfaces`
-    -1.4s api ✓ `boundary 1`
-    -1.4s api ✓ `section-profile-read`
-    -1.4s api ✓ `line canvas-pos boundary 1 60 60`
-    -1.3s api ✓ `boundary 1`
-    -1.3s api ✓ `obstacles 1`
-    -1.3s api ✓ `references`
-    -1.3s api ✓ `dump`
-    -1.3s api ✓ `source-inspect`
-    -1.3s 狀態列 工具：選取
-    -1.3s 狀態列 面 1 · 選取
-    -1.2s api ✗ `line place 999 on 1 at-line guide 1` → line 737: 欄位數不對，用法：place 角材id on 承載面id at-line guide 線id｜grid 網id u|v 索引 或 at-face e索引｜h孔e邊｜t角材，可加 through 座標 或 between 擋面 擋面）
-    -0.7s api ✓ `dump`

## 附件

`world.scene`、`events.jsonl`、`page.html`

重現:`python geometry-web/feedback_cli.py replay F-20261022-001`
