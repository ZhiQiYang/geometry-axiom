#!/usr/bin/env python3
"""經鎖執行，沿 fix_verify.sh/scale_compare2.py 的三方方法，額外嚴格核對原始證據。"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / ('p189-' + sys.argv[1][:8])
WORK = Path('/tmp/geo261-cloud-0da1f08c-20261022T0827/work/p189-' + sys.argv[1][:8])
REPO = '/workspace/geometry-axiom'
TOOLS = Path('/tmp/geo261-cloud-0da1f08c-20261022T0827/tools')
GEN = Path('/tmp/geo261-cloud-0da1f08c-20261022T0827/tools/gen_scene.py')
SHAS = {'main': 'adbaebf9c73ea6801d7b4d5214e4b846b132923b',
        'base': '3e600772076465fc65a26ac09055028301c0fb0b',
        'fix': sys.argv[1]}
ENV = dict(os.environ, PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
           LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')


def run(argv, *, cwd=None, data=None, timeout=1200):
    p = subprocess.run(argv, cwd=cwd, env=ENV, input=data, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f'指令失敗 {p.returncode}: {argv}\n{p.stderr[-1000:]!r}')
    return p


def git(*args):
    return run(['git', '-c', 'safe.directory=*', '-C', REPO, *args]).stdout


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUT.exists() or WORK.exists():
        raise RuntimeError('拒絕覆蓋既有收據或工作目錄')
    OUT.mkdir(parents=True)
    WORK.mkdir(parents=True)
    started = time.time()
    provenance = {'shas': SHAS, 'compiler': run(['gcc', '--version']).stdout.decode().splitlines()[0],
                  'generator_sha256': digest(GEN.read_bytes()),
                  'verification_script_sha256': digest(Path(__file__).read_bytes()),
                  'timing_script_sha256': digest((TOOLS / 'scale_compare2.py').read_bytes()),
                  'binaries_sha256': {},
                  'method': 'gcc -std=c11 -O2 geometry-web/web_bridge.c -o bridge -lm; stack=16384; N=16,32,48,64; 3 rounds; order main/base/fix then reverse'}
    (OUT / 'provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
    for label, sha in SHAS.items():
        assert git('rev-parse', sha).decode().strip() == sha
        target = WORK / label
        target.mkdir()
        root_names = set(git('ls-tree', '-z', '--name-only', sha).decode().split('\0'))
        paths = [p for p in ('current_geometry.c', 'geometry-core', 'geometry-app', 'geometry-templates', 'geometry-web') if p in root_names]
        assert {'current_geometry.c', 'geometry-web'} <= set(paths)
        args = ['archive', '--format=tar', sha, '--', *paths,
                ':(exclude)geometry-core/domain-decoupling', ':(exclude)geometry-web/docs', ':(exclude)geometry-web/prototypes',
                ':(exclude)geometry-web/vendor', ':(exclude)geometry-web/node_modules']
        archive = git(*args)
        with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
            tar.extractall(target, filter='data')
        cmd = ['gcc', '-std=c11', '-O2', 'geometry-web/web_bridge.c', '-o', 'bridge', '-lm']
        p = run(cmd, cwd=target)
        (OUT / f'build-{label}.log').write_bytes(p.stdout + p.stderr)
        provenance['binaries_sha256'][label] = digest((target / 'bridge').read_bytes())
        (OUT / 'provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
        print(f'{label} {sha} 建置完成', flush=True)
    scenes = []
    for n in (16, 32, 48, 64):
        data = run(['python3', str(GEN), str(n), '--family', 'single']).stdout
        scenes.append((f's{n}.scene', data))
    for name in git('ls-tree', '-z', '--name-only', SHAS['base']).decode().split('\0'):
        if name.endswith('.scene'):
            scenes.append(('repo-' + name, git('show', SHAS['base'] + ':' + name)))
    dumps = []
    for name, data in scenes:
        scene = WORK / name
        scene.write_bytes(data)
        raw = {}
        for label in ('base', 'fix'):
            p = run(['bash', '-c', 'ulimit -s 16384; exec "$1"', 'x', str(WORK / label / 'bridge')],
                    cwd=WORK, data=f'loadfile {scene}\ndump\n'.encode(), timeout=900)
            (OUT / f'{name}-{label}.stdout').write_bytes(p.stdout)
            (OUT / f'{name}-{label}.stderr').write_bytes(p.stderr)
            lines = p.stdout.splitlines()
            assert len(lines) == 2, (name, label, lines[:2])
            responses = [json.loads(line) for line in lines]
            assert all(isinstance(r, dict) for r in responses), (name, label)
            assert isinstance(responses[0].get('ok'), bool) and responses[1].get('ok') is True, (name, label, responses)
            # repo-root 包含刻意拒絕的回歸場景；沿原腳本比較完整 load 回覆及 dump，
            # 分開記錄拒絕，不冒充成功載入。四個生成效能場景必須確實載入成功。
            if not name.startswith('repo-'):
                assert responses[0]['ok'] is True, (name, label, responses[0])
            raw[label] = p.stdout
        assert raw['base'] == raw['fix'], f'dump 不同：{name}'
        dumps.append({'scene': name, 'scene_sha256': digest(data), 'bytes': len(raw['base']), 'stdout_sha256': digest(raw['base']),
                      'load_ok': responses[0]['ok'], 'load_response': responses[0], 'dump_ok': True, 'identical': True})
        print(f'{name} loadfile+dump 逐位元組相同', flush=True)
    (OUT / 'dump-equivalence.json').write_text(json.dumps(dumps, ensure_ascii=False, indent=2) + '\n')
    timing = ['python3', str(TOOLS / 'scale_compare2.py'), str(WORK), str(OUT),
              *[f'{label}={WORK / label}' for label in SHAS], '--ns', '16,32,48,64', '--reps', '3', '--gen', str(GEN)]
    p = run(timing, timeout=1800)
    (OUT / 'timing.log').write_bytes(p.stdout + p.stderr)
    print(p.stdout.decode(), flush=True)
    with (OUT / 'samples.tsv').open() as stream:
        rows = list(csv.DictReader(stream, delimiter='\t'))
    assert len(rows) == 36, len(rows)
    assert all(r['status'] == 'ok' and r['ok'] == 'True' for r in rows), rows
    ratios = []
    for n in (16, 32, 48, 64):
        medians = {}
        for label in SHAS:
            selected = [r for r in rows if r['n'] == str(n) and r['side'] == label]
            assert {r['round'] for r in selected} == {'0', '1', '2'} and len(selected) == 3
            medians[label] = statistics.median(float(r['seconds']) for r in selected)
        ratio = medians['fix'] / medians['main']
        ratios.append({'n': n, 'medians': medians, 'fix_main': ratio, 'pass': ratio <= 2})
    receipt = {'schema': 'geo261-p189-final/1', **provenance, 'dump_count': len(dumps), 'samples': len(rows),
               'ratios': ratios, 'pass': all(r['pass'] for r in ratios), 'seconds': time.time() - started}
    (OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    if not receipt['pass']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
