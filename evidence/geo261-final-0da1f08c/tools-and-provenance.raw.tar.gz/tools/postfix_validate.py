#!/usr/bin/env python3
"""經鎖驗固定修正 SHA：原 main／修正交錯量測，以及真瀏覽器等待負對照。"""
import hashlib
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time
import p52_measure as shared

HERE=Path(__file__).resolve().parent
SHA=sys.argv[1]
OUT=HERE/('postfix-'+SHA[:8])
WORK=Path('/tmp/geo261-cloud-0da1f08c-20261022T0827/work')/('codex-geo261-'+SHA[:8])
ENV=dict(shared.ENV,TMPDIR=str(WORK/'tmp'))


def one(repo,label,sha,mode,index,script):
    out=OUT/label;out.mkdir()
    port=18960+index
    env=dict(ENV,GEOMETRY_FEEDBACK_DIR=str(WORK/'tmp'/f'feedback-{index}'),GEOMETRY_TEST_URL=f'http://127.0.0.1:{port}/',
             GEOMETRY_CHROME='/workspace/geo261-environment/bin/google-chrome',GEOMETRY_CHROME_FLAGS='--no-sandbox',GEOMETRY_CDP_PORT=str(9400+index),
             GEOMETRY_CDP_FROM_P31='1',GEOMETRY_CHROME_PROFILE=str(WORK/'tmp'/f'chrome-{index}'),P52_OUT=str(out),
             P52_SHA=sha,P52_CASE_MODE=mode,P52_REPS='8')
    with (out/'server.log').open('wb') as log:
        server=subprocess.Popen(['python3','-u','geometry-web/start_local.py','--port',str(port)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            end=time.monotonic()+90
            while time.monotonic()<end:
                if server.poll() is not None:raise RuntimeError('隔離服務提前結束')
                p=subprocess.run(['python3','geometry-web/runtime_version.py','--probe',str(port)],cwd=repo,env=env,capture_output=True)
                if p.returncode==0:
                    (out/'runtime.json').write_bytes(p.stdout);break
                time.sleep(1)
            else:raise RuntimeError('隔離服務版本檢查逾時')
            try:
                shared.command(['node',str(HERE/script),str(repo)],out/'probe.log',cwd=repo,env=env,timeout=1200)
                rc=0
            except RuntimeError:
                rc=1
            result_file=out/('samples.json' if script=='p52_probe.cjs' else 'result.json')
            if not result_file.exists():raise RuntimeError('測試未留下結果，不能當成功或 killed：'+str(out))
            result=json.loads(result_file.read_text())
            return {'label':label,'sha':sha,'mode':mode,'exit':rc,'result':result,'log':str(out/'probe.log')}
        finally:
            try:os.killpg(server.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:server.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()


def main():
    if OUT.exists() or WORK.exists():raise RuntimeError('拒絕覆蓋舊收據／checkout')
    OUT.mkdir();(WORK/'tmp').mkdir(parents=True)
    repo=WORK/'repo'
    shared.command(['git','-c','safe.directory=*','clone','-q','--no-checkout','/workspace/geometry-axiom',str(repo)],OUT/'clone.log')
    shared.command(['git','-c','core.autocrlf=false','-c','advice.detachedHead=false','checkout','-q',SHA],OUT/'checkout.log',cwd=repo)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==SHA
    shared.command(['npm','run','build'],OUT/'build.log',cwd=repo,env=ENV)
    records=[]
    for i,label in enumerate(['main','fix','fix','main']):
        source=shared.WORK/'main' if label=='main' else repo
        sha=shared.SHAS['main'] if label=='main' else SHA
        script='p52_probe.cjs' if label=='main' else 'p52_cases.cjs'
        row=one(source,f'{i}-{label}',sha,'measure',i,script);records.append(row)
        assert row['exit']==0 and row['result']['failed']==0 and row['result']['exceptions']==0
    samples={}
    for row in records:
        label='main' if row['sha']==shared.SHAS['main'] else 'fix'
        samples.setdefault(label,[]).extend(s['appearedMs'] for s in row['result']['samples'])
    medians={label:statistics.median(v) for label,v in samples.items()}
    timing={'shas':{'main':shared.SHAS['main'],'fix':SHA},'medians_ms':medians,'ratio':medians['fix']/medians['main'],
            'ranges_ms':{k:[min(v),max(v)] for k,v in samples.items()},'count':{k:len(v) for k,v in samples.items()},
            'no_regression':medians['fix']<=medians['main']}
    (OUT/'timing.json').write_text(json.dumps(timing,ensure_ascii=False,indent=2)+'\n')
    print('修正後交錯量測 '+json.dumps(timing,ensure_ascii=False),flush=True)
    controls=[]
    title='P52-5 真實放置的 cross 足跡(核心) = 預示帶範圍 1987..2014'
    for i,mode in enumerate(['normal','delay','revert-delay','wrong','missing'],4):
        row=one(repo,'control-'+mode,SHA,mode,i,'p52_cases.cjs');r=row['result']
        log=Path(row['log']).read_text()
        if mode in ('normal','delay'):
            valid=row['exit']==0 and r['passed']==5 and r['failed']==0 and r['exceptions']==0 and not r.get('fatal')
        elif mode in ('revert-delay','wrong'):
            lines=[line for line in log.splitlines() if line.startswith(title+' ✗')]
            valid=row['exit']==1 and r['passed']==4 and r['failed']==1 and r['exceptions']==0 and not r.get('fatal') and len(lines)==1
            if mode=='revert-delay':valid=valid and any(e.get('injected')=='place-before-send-900ms' for e in r['events'])
            else:valid=valid and any(e.get('injected')=='A28' for e in r['events'])
        else:
            valid=row['exit']==1 and r.get('fatal','').startswith('P52-5 ') and '上限 5000ms' in r.get('fatal','') and any(e.get('injected')=='omit-place' for e in r['events'])
        row['expected_behavior_proved']=bool(valid);controls.append(row)
        (OUT/'controls.json').write_text(json.dumps(controls,ensure_ascii=False,indent=2)+'\n')
        print('等待反證 '+mode+' '+str(valid),flush=True)
        assert valid,mode
    result={'sha':SHA,'timing':timing,'controls':controls,'records':records,
            'drivers_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ['postfix_validate.py','p52_cases.cjs','p52_probe.cjs','p52_measure.py']}}
    (OUT/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    raise SystemExit(0 if timing['no_regression'] else 1)


if __name__=='__main__':main()
