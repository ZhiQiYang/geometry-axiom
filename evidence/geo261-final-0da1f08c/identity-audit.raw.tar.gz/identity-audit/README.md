# GEO-261 獨立靜態身分稽核

這個目錄保存實際執行過的純檔案／Git 物件核對，不執行、import 或修改產品／測試模組。沒有執行 native、`tests/mutate.py --check`、瀏覽器、編譯、服務或架構裁判；不能把 26 個靜態核對寫成動態驗收通過。

固定受驗來源是 `0da1f08c75a411442a2e4a431e72459563b8b9a2`。腳本從原始 bytes（原生來源採 CRLF→LF）獨立重算 include closure、core oracle、bridge oracle、工具 closure、架構 inputs／產物 hash。bridge 的 `RESTORED` 由有限 AST 常數解讀取得，再對照帳本，不是直接信任帳本保存的清單。沒有 `eval` 或執行來源中的函式。

## 產物

- `audit_identity.py`、根目錄的 `stdout.log`／`stderr.log`／`result.json`／`receipt.json`：初版時點核對。遠端分支 tip 必須恰為固定來源；它刻意保存本輪觀察，之後分支前進時不適合作為持續重現入口。
- `audit_identity_reachable.py` 與 `reachable-ref/`：可重現版本與其實際完整輸出／退出碼／環境收據。唯一邏輯差異是允許遠端 tip 在固定來源後追加提交，但固定受驗來源必須仍是該遠端 tip 的祖先；不把新 tip 當成已驗產品。其餘來源與雜湊核對不變。
- 兩輪原始輸出與原始退出碼都保留；`receipt.json` 記錄腳本前後 hash、argv、安全版本資訊與檔案 hash。`result.json` 包含完整 Git 命令輸出（包括帳本 bytes 讀回），因此檔案較大。

未記錄或輸出 process environment、token、憑證、Git config 或 credential file。環境資訊只有 OS／核心／架構與軟體版本命令的安全結果。

## 重現

使用乾淨 checkout，HEAD 必須是上述固定受驗 SHA。先讓本地 Git 有遠端整合 tip 的物件，才能驗證固定來源仍可由遠端分支到達。輸出檔必須尚不存在；腳本拒絕覆蓋。執行：

```sh
python3 -B audit_identity_reachable.py --repo /path/to/clean-fixed-sha-checkout --output /tmp/new-geo261-identity-result.json
```

若封存為 `.py.txt`，可直接把相同命令的腳本參數改為該 `.py.txt` 路徑，不需改內容。稽核的每個核對、完整 Git 子命令與其退出碼在新 result 中；程序退出 0 表示此有限靜態稽核全部成立。

遠端來源已改寫／不可讀、固定 SHA 不可解析、產品／裁判內容變動、來源 hash 不符或工作樹不乾淨，都應據實失敗。禁止改帳本 head 或 hash 來使核對轉綠。
