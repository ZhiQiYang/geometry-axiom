#!/usr/bin/env python3
"""獨立、純讀取的 GEO-261 來源身分與雜湊稽核；不載入或執行產品／測試模組。"""
from __future__ import annotations

import argparse
import ast
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

SOURCE = '52b951940f570011b257cd207741ba0a7f6d7ce9'
LEDGER_COMMIT = '0548c05cccbb7b35def6bbc3d6b285004be676e5'
AUDIT_COMMIT = '60425b629aee9f74f4e62ea88af9882bc8968881'
FINAL = '0da1f08c75a411442a2e4a431e72459563b8b9a2'
REMOTE_REF = 'refs/heads/architecture/geo261-integration-20261016'
EXPECTED = {
    'ledger_raw_sha256': 'bd9c88f598b8bd1a82cd2f561b1953ba034837cc44e66d49556dd246c8bc4c73',
    'native_closure_sha256': '2687273d14975d972af51afe15a74b8e8b56f045f24acfa14fc38feceb26dfff',
    'core_oracle_sha256': 'f8222a4ac7ae76339cfb7536634f98e572ecd2bb0d649ce3395d6d452e2fa306',
    'tool_closure_sha256': '24c391b89880b8abc36cf4b7431afd1bb5486982cb9d41a6a0d975ac7c3c6387',
    'architecture_input_closure_sha256': '64f6f66b7d80a3a36c6ad4f2e2dc15b6921d209a44f216fb37910474c0df29ad',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def normalized(path):
    return path.read_bytes().replace(b'\r\n', b'\n')


def static_value(node, names):
    """只解讀常數／串接／有限 list comprehension，絕不 eval、import 或呼叫來源函式。"""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return names[node.id]
    if isinstance(node, (ast.List, ast.Tuple)):
        result = []
        for part in node.elts:
            if isinstance(part, ast.Starred):
                result.extend(static_value(part.value, names))
            else:
                result.append(static_value(part, names))
        return tuple(result) if isinstance(node, ast.Tuple) else result
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return static_value(node.left, names) + static_value(node.right, names)
    if isinstance(node, ast.ListComp):
        assert len(node.generators) == 1, '拒絕複雜 comprehension'
        gen = node.generators[0]
        assert isinstance(gen.target, ast.Name) and not gen.ifs and not gen.is_async
        return [static_value(node.elt, dict(names, **{gen.target.id: item}))
                for item in static_value(gen.iter, names)]
    raise ValueError('來源的靜態常數含不支援語法：' + type(node).__name__)


def assignment(path, name, names=None):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    matches = [n.value for n in tree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    assert len(matches) == 1, '靜態常數必須恰好定義一次：' + name
    return static_value(matches[0], names or {})


def audit(root):
    commands = []
    checks = []

    def git(*args):
        command = ['git', '-C', str(root), *args]
        p = subprocess.run(command, capture_output=True)
        commands.append({'argv': command, 'exit_code': p.returncode,
                         'stdout': p.stdout.decode('utf-8', 'replace'),
                         'stderr': p.stderr.decode('utf-8', 'replace')})
        return p

    def require(label, value, **details):
        checks.append({'name': label, 'passed': bool(value), **details})
        return bool(value)

    before = git('rev-parse', 'HEAD').stdout.decode().strip()
    status_before = git('status', '--porcelain=v1', '--untracked-files=all').stdout.decode()
    require('受驗 HEAD 固定', before == FINAL, expected=FINAL, actual=before)
    require('稽核前工作樹乾淨', status_before == '', status=status_before)
    remote = git('ls-remote', 'origin', REMOTE_REF)
    expected_line = FINAL + '\t' + REMOTE_REF
    require('Git 協定可讀遠端整合 ref 且固定候選一致', remote.returncode == 0 and remote.stdout.decode().strip() == expected_line,
            limitation='僅使用 Git 協定讀取 ref，未聲稱 GitHub API 或網頁 commit endpoint 已可讀。')
    ancestry = []
    for name, value in [('產品與裁判／帳本執行來源', SOURCE), ('帳本產物／架構執行來源', LEDGER_COMMIT),
                        ('架構產物提交', AUDIT_COMMIT), ('唯一最終受驗來源', FINAL)]:
        kind = git('cat-file', '-t', value)
        ancestor = git('merge-base', '--is-ancestor', value, FINAL)
        entry = {'role': name, 'sha': value, 'resolves_as_commit': kind.returncode == 0 and kind.stdout.strip() == b'commit',
                 'ancestor_of_final': ancestor.returncode == 0}
        ancestry.append(entry)
        require('祖先可解析：' + name, entry['resolves_as_commit'] and entry['ancestor_of_final'])

    ledger_path = root / 'tests/mutants_results.json'
    ledger = json.loads(ledger_path.read_text(encoding='utf-8'))
    active = {k: v for k, v in ledger.items() if v['verdict'] != 'retired'}
    counts = dict(collections.Counter(v['verdict'] for v in ledger.values()))
    schemas = dict(collections.Counter(v['execution']['schema'] for v in active.values()))
    require('帳本分類與原交接一致', counts == {'killed': 70, 'equivalent': 4, 'crashed': 1, 'retired': 3}, counts=counts)
    require('75 筆 active execution head 固定公開祖先', len(active) == 75 and all(v['execution']['head'] == SOURCE for v in active.values()))
    require('57 core／18 bridge execution schema', schemas == {'geometry-mutation-execution/1': 57, 'geometry-bridge-mutation-execution/1': 18}, schemas=schemas)
    ledger_hash = sha(ledger_path.read_bytes())
    require('帳本原始 bytes 與交接一致', ledger_hash == EXPECTED['ledger_raw_sha256'], computed=ledger_hash)
    ledger_at_commit = git('show', LEDGER_COMMIT + ':tests/mutants_results.json')
    require('現行帳本與帳本產物 commit 逐 byte 相同', ledger_at_commit.returncode == 0 and ledger_at_commit.stdout == ledger_path.read_bytes())

    included = {}
    include_pattern = re.compile(r'^[ \t]*#[ \t]*include[ \t]+"([^"]+)"', re.M)

    def visit(path):
        path = path.resolve()
        try:
            rel = path.relative_to(root).as_posix()
        except ValueError:
            return
        if rel in included:
            return
        data = normalized(path)
        included[rel] = sha(data)
        for name in include_pattern.findall(data.decode('utf-8')):
            target = path.parent / name
            if target.is_file():
                visit(target)

    visit(root / 'current_geometry.c')
    visit(root / 'geometry-web/web_bridge.c')
    native_closure = sha('\n'.join(f'{p} {included[p]}' for p in sorted(included)).encode())
    require('184 檔 include 聯集 closure', len(included) == 184 and native_closure == EXPECTED['native_closure_sha256'], files=len(included), computed=native_closure)
    require('全部 active record 的 closure 與現行來源相符', all(v['closure_sha256'] == native_closure for v in active.values()))
    source_mismatches = [k for k, v in active.items() if sha(normalized(root / v['source_file'])) != v['source_sha256']]
    require('全部 active record 的來源檔雜湊相符', not source_mismatches, mismatches=source_mismatches)
    tool = normalized(root / 'tests/mutate.py') + b'\0mutation_bridge.py\0' + normalized(root / 'tests/mutation_bridge.py')
    tool_hash = sha(tool)
    require('工具 closure 與全部 active execution 相符', tool_hash == EXPECTED['tool_closure_sha256'] and all(v['execution']['tool_sha256'] == tool_hash for v in active.values()), computed=tool_hash)

    runner = root / 'tests/run_tests.py'
    tests = ast.literal_eval(next(n.value for n in ast.parse(runner.read_text(encoding='utf-8')).body
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'TESTS' for t in n.targets)))
    scene_names = sorted({entry['scene'] for entry in tests})
    scene_rows = [name + ' ' + (sha(normalized(root / name)) if (root / name).is_file() else 'MISSING') for name in scene_names]
    core_oracle = sha((sha(normalized(runner)) + '\n' + '\n'.join(scene_rows)).encode())
    core_records = {k: v for k, v in active.items() if v['execution']['schema'] == 'geometry-mutation-execution/1'}
    require('57 core oracle 與現行裁判／夾具相符', core_oracle == EXPECTED['core_oracle_sha256'] and all(v['oracle_sha256'] == core_oracle for v in core_records.values()), computed=core_oracle, scene_count=len(scene_names))
    backend = root / 'tests/mutation_bridge.py'
    prefix = assignment(backend, 'PREFIX')
    restored = assignment(backend, 'RESTORED', {'PREFIX': prefix})
    oracle_files = sorted([*root.glob('tests/*.py'), *root.glob('*.scene')])
    oracle_rows = [(p.relative_to(root).as_posix(), sha(normalized(p))) for p in oracle_files]
    bridge_rows = []
    for key, item in active.items():
        e = item['execution']
        if e['schema'] != 'geometry-bridge-mutation-execution/1':
            continue
        digest = sha(json.dumps([e['methods'], restored, oracle_rows], ensure_ascii=False, separators=(',', ':')).encode())
        matched = e['restored_methods'] == restored and item['oracle_sha256'] == e['oracle_sha256'] == digest
        bridge_rows.append({'id': key, 'computed': digest, 'restored_methods_equal_current_static_source': e['restored_methods'] == restored, 'passed': matched})
    require('18 bridge oracle 與現行靜態 restored 常數／裁判／夾具相符', len(bridge_rows) == 18 and all(row['passed'] for row in bridge_rows))

    architecture_dir = root / 'geometry-core/domain-decoupling'
    receipt = json.loads((architecture_dir / 'product-architecture-receipt.json').read_text(encoding='utf-8'))
    artifact_files = ['product-architecture.json', 'product-architecture-scan.json', 'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json']
    artifacts = {name: {'raw_sha256': sha((architecture_dir / name).read_bytes()), 'lf_sha256': sha(normalized(architecture_dir / name))} for name in artifact_files}
    for name, field in [('product-architecture.json', 'manifestSha256'), ('product-architecture-scan.json', 'scanSha256'), ('PRODUCT-ARCHITECTURE.md', 'reportSha256')]:
        require('架構產物符合 receipt：' + name, artifacts[name]['lf_sha256'] == receipt[field])
    inputs = receipt['inputs']
    mismatches = [entry['path'] for entry in inputs if sha(normalized(root / entry['path'])) != entry['sha256']]
    architecture_closure = sha(json.dumps(inputs, ensure_ascii=False, separators=(',', ':')).encode())
    require('601 架構輸入與現行 LF bytes 相符', len(inputs) == 601 and not mismatches, mismatches=mismatches)
    require('架構 input closure 重算一致', architecture_closure == receipt['inputClosureSha256'] == EXPECTED['architecture_input_closure_sha256'], computed=architecture_closure)
    require('架構實際執行來源為帳本產物祖先', all(receipt[name] == LEDGER_COMMIT for name in ('sourceBaseHead', 'headObservedBefore', 'headObservedAfter')))
    paths = git('diff', '--name-only', SOURCE, FINAL).stdout.decode().splitlines()
    allowed_audit = {'.gitignore', '.gitattributes', 'tests/mutants_results.json',
                     'geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',
                     'geometry-core/domain-decoupling/product-architecture-receipt.json'}
    unexpected = [p for p in paths if p not in allowed_audit and not p.startswith('evidence/geo261-cloud-')]
    require('產品／裁判凍結至最終來源僅有資料與稽核差異', not unexpected, unexpected=unexpected)
    after = git('rev-parse', 'HEAD').stdout.decode().strip()
    status_after = git('status', '--porcelain=v1', '--untracked-files=all').stdout.decode()
    require('稽核後同一固定 HEAD 且工作樹仍乾淨', after == before == FINAL and status_after == '', actual=after, status=status_after)
    return {'schema': 'geo261-independent-static-identity-audit/1',
            'executed_tests': False, 'compiled_artifacts': False, 'started_services': False,
            'did_not_run': ['tests/mutate.py --check', 'native 回歸', '瀏覽器驗收', '架構裁判命令', '突變執行或判決重產'],
            'scope': '純讀取來源／常數／Git 物件，獨立重算已保存 ledger 與 architecture 的部分身分雜湊；不等於完整 freshness 裁判或動態驗收。',
            'source_sha': SOURCE, 'ledger_commit_sha': LEDGER_COMMIT, 'architecture_commit_sha': AUDIT_COMMIT,
            'tested_sha': FINAL, 'head_before': before, 'head_after': after, 'ancestry': ancestry,
            'checks': checks, 'pass': all(c['passed'] for c in checks),
            'ledger_verdict_counts': counts, 'execution_schemas': schemas,
            'computed': {'ledger_raw_sha256': ledger_hash, 'native_closure_sha256': native_closure,
                         'tool_closure_sha256': tool_hash, 'core_oracle_sha256': core_oracle,
                         'architecture_input_closure_sha256': architecture_closure},
            'native_include_inputs': [{'path': p, 'sha256': included[p]} for p in sorted(included)],
            'bridge_oracles': bridge_rows, 'architecture_artifacts': artifacts,
            'changed_paths_source_to_final': paths, 'git_commands': commands}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), '拒絕覆蓋既有稽核輸出'
    result = audit(args.repo.resolve())
    result['created_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'schema': result['schema'], 'tested_sha': FINAL, 'pass': result['pass'],
                      'passed_checks': sum(c['passed'] for c in result['checks']), 'total_checks': len(result['checks']),
                      'computed': result['computed'], 'executed_tests': False}, ensure_ascii=False))
    return 0 if result['pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
