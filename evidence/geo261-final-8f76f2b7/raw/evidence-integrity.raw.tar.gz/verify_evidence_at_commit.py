"""從固定 Git blobs 驗證封存資料，避免進度分支持續更新造成讀取競態。"""
import argparse
import hashlib
import io
import json
from pathlib import PurePosixPath
import subprocess
import tarfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',required=True)
p.add_argument('--commit',required=True)
p.add_argument('--directory',action='append',required=True)
p.add_argument('--out')
a=p.parse_args()
def git(*parts):return subprocess.check_output(['git','-C',a.repo,*parts])
commit=git('rev-parse',a.commit+'^{commit}').decode().strip()
def blob(path):return git('show',commit+':'+path)
def digest(raw):return hashlib.sha256(raw).hexdigest()
summaries=[]
for directory in a.directory:
    paths=git('ls-tree','-r','--name-only',commit,'--',directory).decode().splitlines()
    assert paths,directory
    total_members=0;total_bytes=0;archives=0
    root=PurePosixPath(directory)
    for line in blob(str(root/'SHA256SUMS')).decode().splitlines():
        expected,name=line.split('  ',1)
        assert digest(blob(str(root/name)))==expected,(directory,name)
    for path in paths:
        if not path.endswith('.inventory.json') and not path.endswith('/ARCHIVE_INVENTORY.json'):continue
        data=json.loads(blob(path))
        rows={str(PurePosixPath(path).parent/data['archive']):{'sha256':data['sha256'],'bytes':data['bytes'],'files':data['members']}} if 'archive' in data else {str(root/name):entry for name,entry in data.items()}
        for archive,record in rows.items():
            raw=blob(archive)
            assert len(raw)==record['bytes'] and digest(raw)==record['sha256'],archive
            expected={row['path']:row for row in record['files']}
            assert len(expected)==len(record['files']),archive
            with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
                members=tar.getmembers()
                assert len(members)==len(expected),archive
                seen=set()
                for member in members:
                    assert member.isfile() and member.name not in seen
                    assert not member.name.startswith('/') and '..' not in PurePosixPath(member.name).parts
                    seen.add(member.name)
                    content=tar.extractfile(member).read();row=expected[member.name]
                    assert len(content)==member.size==row['bytes']
                    assert digest(content)==row['sha256'],(archive,member.name)
                    total_members+=1;total_bytes+=len(content)
            archives+=1
    summaries.append({'directory':directory,'tracked_files':len(paths),'archives':archives,'verified_members':total_members,'uncompressed_bytes':total_bytes,'status':'verified'})
result={'commit':commit,'verification':'Git blob SHA256SUMS及每個封存member的bytes/hash/安全相對路徑','results':summaries}
if a.out:
    from pathlib import Path
    Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
