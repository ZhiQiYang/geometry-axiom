# F2 正式17項實際數據（已凍結）

唯一來源 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`；凍結 `2026-10-22T21:40:03.009714+00:00`。17項原退出均0、全部publisher原0；七項均在各正式CI時限內。這個快照只涵蓋17項，額外同F2修正自證由root另補，沒有宣告所有驗收要求已完成。

| 項目 | 原退出 | 耗時秒 | 正式CI分鐘 |
|---|---:|---:|---:|
| native | 0 | 1749.342535 | 35 |
| canvas | 0 | 1720.939091 | 35 |
| assembly | 0 | 191.268495 | 15 |
| documents | 0 | 61.912708 | 10 |
| grid | 0 | 455.096624 | 15 |
| space | 0 | 213.333134 | 15 |
| timber | 0 | 127.109133 | 20 |
| mutation-check-final | 0 | 1.873092 | — |
| p52-prepare-main | 0 | 31.230827 | — |
| p52 | 0 | 377.196304 | — |
| p52-verifier | 0 | 0.122654 | — |
| q38 | 0 | 292.236421 | — |
| card-reference | 0 | 649.412512 | — |
| p189 | 0 | 177.100433 | — |
| architecture-contract | 0 | 5.123246 | — |
| architecture-judge-tests | 0 | 0.599428 | — |
| architecture-product-tests | 0 | 12.774723 | — |

- native：224 suites，5185＝5184pass＋GDI1允許skip。replay為同F2 native內6/6；原JSON／unittest.log105B／主log0B照存，範圍為root說明的13scenes×2mode等價與3成本見證，非P189175組。32組／96紀錄raw-index補件375aee12只作native參照，不增新job、不重audit。
- canvas：唯一full CDP_RESULT，2267pass／0fail／0skip，85段golden matched、P73=69；例外總數原1＝預期P38探針1，非預期0。firstTransportFailure／firstNetworkFailure原trace保留。
- assembly／grid保留workflow指定partial及not compared(partial)；documents原RESULT沒有completed欄；space／timber保留原scope、omitted與各group完整性。
- P52：16+16次，main243.980630ms／fix179.233603ms、ratio0.73462226489，5控制達預期；verifier原9節點、exit／driver／無timeout-crash檢查均綠。
- Q38：42＝41killed＋SPM24equivalent；native27／model20 baseline全綠；SPM38／40因果ModelError不改叫AssertionError。
- §7：雙report都綁F2。53＝50產品＋3裁判，53皆killed/restore0；另一report V01–V05均red1／恢復44綠。只在17項正式完成後串流指定兩個report，未整包解壓。
- P189：原main/base/F2三方36樣本，四點均≤2；175dump原記錄全同（75接受＋100拒絕），36樣本原rc0/load_ok。詳METRICS精確ratios；不是額外撤回自證，也不是source-index14方法。
- 架構三條都在F2獨立原執行0；333owned／796edges／diag0，generic205、product18，skip0；未以P3重產或native結果替代。

兩段原outer退出為seven0／all-specials0；未搬入舊F的grid publication1與修復。原收據、topitem、必要streams／versions及小inner在items；完整大原始包仍由原publisher封存，來源參照在各item。未複製work／binary，未新增gate、重測或publish。
