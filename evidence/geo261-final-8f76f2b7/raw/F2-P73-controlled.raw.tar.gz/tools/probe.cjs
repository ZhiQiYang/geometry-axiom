/* 真 app 的單次 controlled callback；不執行完整 P73 workflow。 */
'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),crypto=require('node:crypto');
const [repo,out]=process.argv.slice(2);
if(!repo||!out)throw Error('需要 repo 與 phase output');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const filename=path.join(repo,'geometry-web/cdp_test.js');
const raw=fs.readFileSync(filename),source=raw.toString('utf8').replace(/\r\n/g,'\n');
const testpath=path.join(repo,'geometry-web/uiux_review_test.js'),test=fs.readFileSync(testpath);
const lines=test.toString('utf8').split(/\r?\n/).filter(x=>x.includes("check('空空間不畫假邊界，提供加入成員入口',await read(`"));
if(lines.length!==1)throw Error('原 P73 assertion 必須唯一');
const matched=lines[0].match(/^\s*check\('([^']+)',await read\(`([^`]+)`\)\);\s*$/);
if(!matched)throw Error('原 P73 assertion 格式改變；拒絕另造 predicate');
const anchor='  if (!process.env.GEOMETRY_ROOM_OUTLINE_ONLY) {';
if(source.split(anchor).length!==2||!source.startsWith('/* CDP'))throw Error('CDP bootstrap 錨點改變');
const bootstrap=source.slice(0,source.indexOf(anchor));
const metadata={schema:'geo261-P73-controlled-callback/1',scope:'real app, explicit one syncSpacePlanAnnotations call; not full P73 workflow',
 sha:process.env.GITHUB_SHA,variant:process.env.P73_VARIANT,testpath,test_sha256:hash(test),assertion_line:lines[0],
 message:matched[1],predicate:matched[2],cdp_test_sha256:hash(raw),bootstrap_sha256:hash(bootstrap),
 app_sha256:hash(fs.readFileSync(path.join(repo,'geometry-web/app.js'))),callbackInvocations:0};
const body=`
  const p73=${JSON.stringify(metadata)};
  p73.chrome={pid:scope.browserPid,profile:scope.browserProfile,command:[CHROME,'--headless=new','--disable-gpu','--no-first-run','--remote-debugging-port='+PORT,'--window-size=1400,900','--user-data-dir='+scope.browserProfile,...EXTRA_FLAGS,'about:blank']};
  const save=()=>fs.writeFileSync(path.join(${JSON.stringify(out)},'result.json'),JSON.stringify(p73,null,2)+'\\n');
  const snapshot=async()=>eval_(\`(()=>{const s=$('spacePlanSvg'),m=s.getScreenCTM();return {
    originalPredicate:(\${p73.predicate}),memberCount:$('spaceMemberCount').textContent,
    hasNoShape:!s.querySelector('polygon,rect,path'),hasEmpty:!!$('spacePlanEmpty'),emptyHasAction:/加入|成員/.test($('spacePlanEmpty').textContent),
    hiddenAttribute:s.hasAttribute('hidden'),hiddenPropertyType:typeof s.hidden,hiddenPropertyValue:s.hidden===undefined?'undefined':s.hidden,
    computedDisplay:getComputedStyle(s).display,ctm:m?{a:m.a,b:m.b,c:m.c,d:m.d,e:m.e,f:m.f}:null,
    outerHTML:s.outerHTML,callbackSource:syncSpacePlanAnnotations.toString()};})()\`);
  await send('Emulation.setDeviceMetricsOverride',{width:1382,height:804,deviceScaleFactor:1,mobile:false});
  await eval_(\`(async()=>{const r=await api('line space 990');if(!r.ok)throw Error(JSON.stringify(r));await renderObjects();await enterFocus('space',990);return true;})()\`);
  await clickControl('[data-ss-tab="plan"]');
  await eval_(\`new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))\`);
  p73.before=await snapshot();save();
  if(p73.before.originalPredicate!==true)throw Error('controlled callback 前原 predicate 已非 true；不能作本負控因果證據');
  p73.callbackInvocations++;
  await eval_('syncSpacePlanAnnotations();true');
  p73.after=await snapshot();
  p73.callbackSourceUnchanged=p73.before.callbackSource===p73.after.callbackSource;
  if(!p73.callbackSourceUnchanged)throw Error('實際 app callback 原碼被改寫');
  const shot=await send('Page.captureScreenshot',{format:'png'});
  fs.writeFileSync(path.join(${JSON.stringify(out)},'after-callback.png'),Buffer.from(shot.result.data,'base64'));
  p73.predicateValue=await eval_(p73.predicate);p73.uncaughtBrowserExceptions=excN;
  let exit=0;
  try {cdp.makeCheck({prefix:'P73 ',throwOnFail:true})(p73.message,p73.predicateValue);p73.assertionPassed=true;}
  catch(error){p73.assertionPassed=false;p73.assertionError=error.message;exit=1;}
  p73.completed=true;p73.actualProbeExit=exit;save();
  _log('P73_CONTROLLED_RESULT '+JSON.stringify(p73));chrome?.kill();process.exit(exit);
}
async function p73Infra(error){
  _log('P73_CONTROLLED_INFRA '+String(error?.stack||error));
  try{if(ws?.readyState===1){const r=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(${JSON.stringify(out)},'infra-failure.png'),Buffer.from(r.result.data,'base64'));}}catch(e){_log('P73_CAPTURE_FAILED '+String(e));}
  chrome?.kill();process.exit(2);
}
async function fatal(error){return p73Infra(error);}
try{scope=runConfiguration();scope.mode='controlled-callback-only';console.log=recordLog;
  (async()=>{await assertPortAvailable(PORT);chrome=startBrowser();chrome.on('error',p73Infra);_log('P73_CONTROLLED_SCOPE '+JSON.stringify(scope));await main();})().catch(p73Infra);
}catch(error){p73Infra(error);}
`;
const generated=bootstrap+body;
fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(out,'generated-probe.cjs'),generated);
fs.writeFileSync(path.join(out,'extracted-assertion.json'),JSON.stringify(metadata,null,2)+'\n');
if(process.env.P73_COMPILE_ONLY==='1'){
  new Function(generated);console.log('僅完成擷取與語法檢查；沒有啟動 Chrome／服務或執行產品');
}else{
  const target=new Module(filename,module);target.filename=filename;target.paths=Module._nodeModulePaths(path.dirname(filename));
  target._compile(generated,filename);
}
