# F2 native 控制索引

固定來源 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。正式 native 已執行；本次僅讀取原始 JSONL，沒有再執行產品或測試。

32 組既有控制（27 新增＋5 舊有）、96 筆原 execution，全為 baseline 0／mutant 1／restored 0，無 timeout；每個 mutant 是原具名 ASSERT。逐控制的原檔、行號與 ASSERT 見 INDEX.json；附入原 log 位元組，不以重新序列化資料取代原輸出。

這不是32個 unittest方法或96個mutants；不聲稱 source-index 的8個舊控制已逐phase印出完整raw。原 suite 總計及環境仍以同F2正式native收據為準。
