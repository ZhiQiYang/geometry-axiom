"""Index existing F2 native raw control executions; never executes product code."""
import datetime
import hashlib
import json
from pathlib import Path

F2 = '8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
BASE = Path('/tmp/g261r3/seven-final/native')
OUT = Path('/workspace/geo261-environment/F2-native-control-index')
GROUPS = (
    ('py_test_geo261_definition_sources', 12),
    ('py_test_geo261_host_facts_authority', 8),
    ('py_test_geo261_placement_definition', 12),
)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    OUT.mkdir(exist_ok=False)
    receipt = json.loads((BASE/'receipt.json').read_text())
    assert receipt['sha'] == F2 and receipt['exit_code'] == 0
    controls, inputs = [], []
    for stem, count in GROUPS:
        path = BASE/'run_all-logs'/(stem+'.log')
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        assert len(rows) == count*3
        for offset in range(0, len(rows), 3):
            triple = rows[offset:offset+3]
            assert [row['phase'] for row in triple] == ['baseline', 'mutant', 'restored']
            assert [row['exitCode'] for row in triple] == [0, 1, 0]
            assert len({row['control'] for row in triple}) == 1
            assert not any(row['timedOut'] for row in triple)
            assert triple[1]['stdout'] == '' and triple[1]['stderr'].startswith('ASSERT:')
            assert all(row['stdout'] == '' and row['stderr'] == '' for row in (triple[0],triple[2]))
            controls.append({'suite': stem, 'control': triple[0]['control'],
                'raw_lines_1_based': list(range(offset+1,offset+4)),
                'exits': [row['exitCode'] for row in triple],
                'mutant_assertion': triple[1]['stderr'].strip()})
        for suffix in ('.log','.unittest.log','.json'):
            original = BASE/'run_all-logs'/(stem+suffix)
            inputs.append({'path': str(original), 'bytes': original.stat().st_size,
                           'sha256': sha(original)})
    assert len(controls) == 32
    report = {'schema': 'geo261-f2-native-control-index/1', 'source_sha': F2,
        'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'analysis_only': True, 'product_or_tests_executed_by_this_script': False,
        'native_receipt': {'path': str(BASE/'receipt.json'), 'sha256': sha(BASE/'receipt.json')},
        'scope': '32 existing controls (27 new plus 5 older); 96 original execution records from completed formal native',
        'not_claimed': 'No fresh execution, no source-index per-phase full-raw claim; not 32 unittest methods or 96 mutants',
        'groups': [{'suite': stem,'controls':count} for stem,count in GROUPS],
        'original_files': inputs, 'controls': controls}
    (OUT/'INDEX.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'README.md').write_text('# F2 native 控制索引\n\n'
        '固定來源 `'+F2+'`。正式 native 已執行；本次僅讀取原始 JSONL，沒有再執行產品或測試。\n\n'
        '32 組既有控制（27 新增＋5 舊有）、96 筆原 execution，全為 baseline 0／mutant 1／restored 0，無 timeout；每個 mutant 是原具名 ASSERT。'
        '逐控制的原檔、行號與 ASSERT 見 INDEX.json；附入原 log 位元組，不以重新序列化資料取代原輸出。\n\n'
        '這不是32個 unittest方法或96個mutants；不聲稱 source-index 的8個舊控制已逐phase印出完整raw。'
        '原 suite 總計及環境仍以同F2正式native收據為準。\n')
    print(json.dumps({'source_sha':F2,'controls':32,'original_execution_records':96,'product_executed':False}))

if __name__ == '__main__':
    main()
