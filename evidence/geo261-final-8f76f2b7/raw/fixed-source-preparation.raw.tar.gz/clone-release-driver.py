"""釋放已完整封存且乾淨、可由公開 SHA 重建的隔離 clone；不刪原始輸出。"""
import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

F = 'fe863b0374eafd9f1e57ec5107e28a1101804b56'
OUT = Path('/workspace/geo261-environment/completed-clone-release')
OUT.mkdir(exist_ok=False)
ROOT = Path('/workspace/geometry-axiom')
PAIRS = [
    ('checker', '/tmp/g261Fchecker/checkout', 'F-checker-proof'),
    ('perf', '/tmp/g261Fperf/source-counterfactual', 'F-cumulative-perf-proof'),
    ('reader', '/tmp/g261freader2/source', 'F-reader-proof'),
    ('p73-subset', '/workspace/geo261-cold/g261-p73-F/source-proof', 'F-p73-subset-proof'),
    ('reader-path-failure', '/workspace/geo261-cold/g261freader/source', 'F-reader-tool-path-failure'),
]
report = {'scope': 'Only disposable completed clean clones; raw receipts, tools, stdout/stderr, patches and original final source checkout retained.',
          'public_source_sha': F, 'started_epoch': time.time(), 'clones': []}
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
def run(args, cwd, folder, label):
    r = subprocess.run(args, cwd=cwd, capture_output=True)
    (folder / (label + '.stdout')).write_bytes(r.stdout)
    (folder / (label + '.stderr')).write_bytes(r.stderr)
    (folder / (label + '.json')).write_text(json.dumps({'argv': args, 'cwd': str(cwd), 'actual_exit': r.returncode}) + '\n')
    assert r.returncode == 0, (label, r.returncode)
    return r.stdout
for name, literal, archive_label in PAIRS:
    clone = Path(literal)
    assert clone.is_dir() and not clone.is_symlink() and (clone / '.git').is_dir(), literal
    folder = OUT / name
    folder.mkdir()
    raw = ROOT / 'evidence/geo261-final-fe863b03/raw' / (archive_label + '.raw.tar.gz')
    assert raw.is_file()
    run(['git', 'merge-base', '--is-ancestor', F, 'HEAD'], ROOT, folder, 'public-source-ancestor')
    assert run(['git', 'rev-parse', 'HEAD'], clone, folder, 'head-before').decode().strip() == F
    assert run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], clone, folder, 'status-before') == b''
    assert run(['git', 'ls-files', '--others', '--ignored', '--exclude-standard', '-z'], clone, folder, 'ignored') == b''
    paths = run(['git', 'ls-files', '-z'], clone, folder, 'tracked').decode().split('\0')
    inventory = []
    for relative in filter(None, paths):
        p = clone / relative
        assert p.is_relative_to(clone)
        if p.is_symlink():
            inventory.append({'path': relative, 'kind': 'symlink', 'target': os.readlink(p)})
        else:
            assert p.is_file(), relative
            digest = hashlib.sha256()
            with p.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            inventory.append({'path': relative, 'kind': 'regular', 'bytes': p.stat().st_size, 'sha256': digest.hexdigest()})
    (folder / 'tracked-sha256.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
    assert run(['git', 'rev-parse', 'HEAD'], clone, folder, 'head-after').decode().strip() == F
    assert run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], clone, folder, 'status-after') == b''
    row = {'name': name, 'clone': literal, 'sha': F, 'raw_archive_retained': str(raw),
           'raw_archive_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
           'tracked_files': len(inventory), 'tracked_bytes': sum(x.get('bytes', 0) for x in inventory),
           'verified_clean': True, 'removed': False}
    report['clones'].append(row)
    save()
    shutil.rmtree(clone)
    row['removed'] = True
    save()
    print(json.dumps(row, ensure_ascii=False), flush=True)
report['finished_epoch'] = time.time()
save()
