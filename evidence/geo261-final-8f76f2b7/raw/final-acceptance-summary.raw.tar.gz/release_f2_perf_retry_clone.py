"""Use the unchanged completed-clone release process for the successful retry."""
import importlib.util
from pathlib import Path

original = Path('/workspace/geo261-environment/F2-clone-release-preparation/release_one_f2_clone.py')
spec = importlib.util.spec_from_file_location('completed_clone_release', original)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ALLOW = {
    'perf': (
        '/tmp/g261F2perf-retry1/source-counterfactual',
        'F2-Cperf-retry1',
        '/tmp/g261F2perf-retry1/receipt.json',
    ),
}
raise SystemExit(module.main())
