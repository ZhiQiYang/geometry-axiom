# F2 Cperf retry1 封存定位副本

只準備metadata，尚未執行helper、產品、Git或publisher；未掃描未完成retry輸出，也不預填proof通過。原attempt1 ENOSPC紀錄已由root通知正常push，E=`be90acece0352d5fc971fb9802ebedfb5e5388c8`；本次未另查Git。

EXECUTION_PLAN只保留原計畫Cperf單列，原16個selectors、完整subcommands（含所有Git archive stdout）、timing、preflight、工具原凍結包及原ELF/source clone排除均保留。唯一字串mapping：`/tmp/g261F2perf`→`/tmp/g261F2perf-retry1`，`F2-Cperf`→`F2-Cperf-retry1`（含outer label/path）。原SHA/F2、工具、formal來源、命令其餘參數與判準不變。MAPPING.patch及MAPPING_DIFF.json列出全部精確差分，反向mapping回原row完全相同；原檔hash保存在PROVENANCE，原helper與原計畫未改。

本目錄prepare_publication.py是輕wrapper。root將來呼叫時才import原F2-extras-orchestration/prepare_publication.py，僅把module.BASE指向本目錄，再呼叫原main；helper行為、選檔／ELF排除／preview／publisher argv生成邏輯全用原版本。準備時只AST parse wrapper，未import或呼叫原helper。

retry完成後，root依真inner receipt結果填 `--result`，用全新metadata out執行（本準備未執行）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B   /workspace/geo261-environment/F2-Cperf-retry-publication-tools/prepare_publication.py   --phase Cperf   --out /tmp/g261F2publication-Cperf-retry1   --result '<依原inner真結果與限制填寫>'   --next '<實際下一步>'   --preview-archive
```

原row的next欄照原文保留；真正生成publisher用本次CLI的`--next`，不要據舊欄重跑已公開native32。原helper僅選檔並生成preview／inventory／publisher.sh，不自動發佈；root核原inner rc/完整raw、preview大小後，再執行生成的publisher.sh作正常push。這是同一原封存流程的路徑定位，不是新產品gate或review。
