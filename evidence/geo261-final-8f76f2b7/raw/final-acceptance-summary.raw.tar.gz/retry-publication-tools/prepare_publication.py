#!/usr/bin/env python3
"""只將原metadata封存helper的BASE指到本retry定位包；不改原helper。"""
from pathlib import Path
import importlib.util

ORIGINAL=Path('/workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py')

def main():
    spec=importlib.util.spec_from_file_location('geo261_original_publication_helper_for_retry',ORIGINAL)
    if spec is None or spec.loader is None:
        raise ImportError('原publication helper無法載入')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.BASE=Path(__file__).resolve().parent
    return module.main()

if __name__=='__main__':
    raise SystemExit(main())
