# F2 額外證據實際矩陣（已凍結）

固定來源 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。本目錄只讀既有原始收據，未執行產品、測試、編譯、效能、Git 或 publisher；不更動已凍結的正式 17 項 metrics（公開證據 commit `78500160d918d992a2929bcf0027891121694a6e`）。9 phase 已收齊並凍結；各 phase 在自身明列範圍內符合預期。原預期紅燈與 Cperf 首次環境失敗均保留實際退出碼。9 phase 為 8 既定新增執行 phase 加上 legacy Chromium 154；native32-raw 是另列補充，不佔 phase。

| Phase | 原 outer exit | 實際觀察 | 出版證據 |
| --- | ---: | --- | --- |
| P73-controlled | 0 | fixed／withdrawn／restored 原 0／1／0；before predicate 三 true、after true／false／true；各 callback 1 次、IDL undefined、hidden attribute true、CTM 非 null、未捕捉例外 0；最後原來源與 clone 皆 clean | 0978a341 |
| P52-runtime | 0 | withdrawn 原 gate 1（ratio 1.0567294487）、restored 原 gate 0（ratio 0.8547843058）；各 phase 四 Node 原0、每 side16、失敗／例外0，最後 clean | f2ea3457 |
| reader | 0 | 原 canonical-reader 一個具名方法 fixed／withdrawn／restored 原0／1／0、無 timeout；撤回為 I11 trace facts／facts_prepare AssertionError，SSOT／test／generator不變、最後clean | 3bba83cb |
| checker | 0 | 原 static-checker 一個具名方法0／1／0；僅撤test三行、產品3input不變；原 Regex AssertionError，最後clone/source clean | 5118a5df |
| parser-prepare | 0 | 準備完成；14input/context hashes前後同、sourceBaseHead F2 clean；compiled=false／testsRun=false，未跑 differential | 915ed86d |
| parser-o2 | 0 | compile／run原0、stderr空；PASS raw-equivalence，199810 comparisons／無報告issue；14hash前後同、F2clean | cfe132e9 |
| parser-sanitized | 0 | 原ASan/UBSan compile／run0、stderr空；199810comparisons／PASS，counts與transcript同O2；14hash前後同、F2clean | e60c7c0a |
| Cperf | 原 attempt1=1（環境）；新retry=0 | attempt1 ENOSPC且尚未compile/semantic/perf，原截斷JSON保留；retry9timing原0/load_ok、三方dump與formal F同bytes；withdrawn/main2.564916＞2、restored/main1.970798≤2，最後F2clean | attempt1: be90acec；retry: 84c511fc |
| legacy-chromium154-p73-fixed | 0 | Chromium154.0.8037.57／Node24.19.0，69pass／0fail／0skip／0exceptions；原P73 fixed-only、partial未比較完整golden；79.997s＜35min、source F2clean | 6c7cc5a4 |

P73 是控制時序下明確呼叫同一 production callback 一次，使用原 P73 predicate；不是舊自然 subset，也不是重新跑完整 P73 workflow。withdrawn 的原 exit 1 保留，proof 符合預期與程序 exit 分欄。P73 inner／outer 原 JSON 另存於 `P73-controlled/`，其內保留完整命令、cwd、SHA、環境、時間、stdout／stderr 原位置與 hash；完整 raw 由 root publisher 封存。本矩陣的出版 commit 依 root 完成通知記錄，collector 未執行 Git 查驗遠端。

同 F2 native32 既有 raw 索引補件公開於 `375aee120677cd9b8da972d159218ab972842750`：root 已核 32 controls／96 records 的 0／1／0；本 collector 未重稽核 96 records，沒有新執行，也不新增正式第 18 項。

Cperf 額外反證只測 N64 的全組6C省工撤回，main／withdrawn／restored 各3輪；不宣稱單component必要，也不替代正式四點36樣本／175dump。額外 restored/main **1.9707983193277312 接近2**，保留原樣本，未重抽樣；正式同F2 N64比值為1.8232505215247488。attempt1環境失敗與retry成功分欄，原1不抹去。

9 phase 的成功均有實際原收據與公開證據 commit。首次 outer 為8項0、Cperf環境項1；新scratch Cperf retry原0後，9 phase的最終範圍內結果皆符合。原 ENOSPC 截斷 JSON bytes／outer1 完整保留，沒有重寫成綠。native32 仍另列補充。`SHA256SUMS` 覆蓋本目錄除該清單本身外的全部檔案；完整原raw請依各phase公開證據與原收據路徑追溯。
