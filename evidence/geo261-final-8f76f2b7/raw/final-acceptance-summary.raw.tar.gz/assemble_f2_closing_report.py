"""Combine completed frozen evidence; this script runs no product or test."""
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/geo261-environment')
OUT = BASE / 'F2-closing-summary'
F2 = '8f76f2b7d6f669670e5834310bfc26495b4a4aa6'

def read(name):
    path = BASE / name / 'METRICS.json'
    raw = path.read_bytes()
    return json.loads(raw), {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

formal, formal_ref = read('F2-actual-metrics')
extra, extra_ref = read('F2-extra-metrics')
assert formal['source_sha'] == extra['source_sha'] == F2
assert formal['frozen'] and formal['completed_topitems'] == formal['expected_topitems'] == 17
assert formal['formal_17_topitems_all_passed'] is True
assert extra['frozen'] and extra['completed_new_execution_phases'] == extra['expected_phases'] == 9
assert extra['pending_phases'] == 0 and extra['all_scoped_phase_expectations_matched'] is True
OUT.mkdir()
result = {
    'schema': 'geo261-final-F2-closing-evidence-summary/1',
    'sha': F2,
    'assembled_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'activity': 'Only combines previously completed original evidence; no product/test/compile/performance execution.',
    'formal_snapshot': formal_ref,
    'extra_snapshot': extra_ref,
    'formal_17_passed': True,
    'extra_9_scoped_expectations_matched': True,
    'all_acceptance_requirements_passed': True,
    'original_frozen_snapshots_modified': False,
    'source_roles': {
        'ledger_execution_product_P': 'b6646d10751a0d85a2f03f5d24fbe1073cb78980',
        'ledger_artifact_L': 'aa02a65e9d3923cc14c13340f05ed16c8b7d4fce',
        'canonical_reader_product_P2': '8a80abc1402b0c4c394969025c93a6019b4bb91d',
        'latest_product_and_architecture_execution_P3': '55b9fb6479485361d9e2283a95e4355f5fca76db',
        'architecture_artifact_A3': F2,
        'final_acceptance_source_F2': F2,
        'last_individual_evidence_E': '84c511fc404c2f5156ddd4ee6ea3f650a6331a2f',
    },
    'environment': {
        'execution': 'Cloud Linux only; no user computer execution.',
        'formal_browser': 'Google Chrome 156.0.8078.47',
        'node': 'v24.19.0',
        'legacy_supplement': 'Chromium 154.0.8037.57 (Debian GNU/Linux 13)',
        'fonts': 'fonts-noto-cjk installed; original version/package commands retained per job.',
        'original_version_command_results': 'Each original command/output/exit is in its per-job receipt and raw archive.',
    },
    'environment_attempt_preserved': {
        'item': 'Cperf', 'attempt1_outer_original_exit': 1,
        'classification': 'ENOSPC during clone/checkout/recording; no performance result.',
        'attempt1_evidence': 'be90acece0352d5fc971fb9802ebedfb5e5388c8',
        'truncated_json_repaired': False,
        'retry_outer_original_exit': 0,
        'retry_evidence': '84c511fc404c2f5156ddd4ee6ea3f650a6331a2f',
        'only_failed_environment_item_rerun': True,
    },
    'not_executed_in_cloud': [
        'The pre-existing allowed Windows GDI case: native records 5184 passed, 0 failed, 1 skipped on Linux.',
        'GitHub Actions itself remains billing-blocked; the locked cloud-equivalent seven-job ruling is used.',
    ],
    'material_uncertainties': [
        'Extra N64 Cperf restored/main=1.9707983193277312 is close to the existing <=2 threshold; three original samples per side are retained without resampling. Formal N64 is separately 1.8232505215247488.',
        'P52 timings depend on machine load. Formal ratio=.7346222648904547 and runtime-only withdrawn/restored ratios=1.0567294486663636/.854784305780079 are original distinct runs.',
        'P73 mutation proof explicitly invokes the real callback once using the original predicate; historical natural-subset withdrawal did not kill and remains recorded. Chromium154 fixed-only 69/0 does not prove the unmodified old product was green.',
    ],
    'review_authority': {
        'branch': 'handoff/codex-takeover-20261021',
        'sha': '804afbb4c5fa38b6023087d6dcb150f40c5978e6',
        'path': 'handoff/pr288-latest-review-20261022.md',
        'sha256': 'ef18e0a9fbcffece2bf31dd0a667ebb70d87a48e75212ce363928fb01123e0bd',
        'live_PR_comments_claimed_read': False,
    },
    'merge_or_force_push_performed': False,
    'evidence_integrity': 'Verified separately against the fixed published snapshot after this summary is published.',
}
(OUT / 'FINAL_RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'README.md').write_text(
    '# GEO-261 最終 F2 驗收彙總\n\n'
    f'固定來源 `{F2}`：正式17項全綠，9個額外phase在明列scope內皆符合預期。'
    '本檔只合併已完成收據，不是新執行，也不改寫兩份凍結快照。\n\n'
    'Cperf首次ENOSPC原退出1與中斷JSON完整保留；新scratch只重跑該項原0。'
    '所有負控制原紅與恢復綠分列，不將預期紅改寫成退出0。'
    'Linux允許Windows GDI一項略過；六個Chrome156 job都實際跑完。'
    'Actions計費沿已鎖定的雲端等價裁判，不宣稱GitHub Actions本身已綠。\n\n'
    '最不確定：額外Cperf恢復比值1.970798接近原2×門檻、每側原3筆；P52受負載影響；'
    'P73自證為受控真callback一次，舊自然subset不足自證歷史保留。'
    '完整數據、SHA角色及權威審查見FINAL_RESULT.json及兩份原METRICS。\n'
)
(OUT / 'SHA256SUMS').write_text(''.join(
    hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name + '\n'
    for path in sorted(OUT.iterdir())
))
print(json.dumps({'output': str(OUT), 'sha': F2, 'all_acceptance_requirements_passed': True}))
