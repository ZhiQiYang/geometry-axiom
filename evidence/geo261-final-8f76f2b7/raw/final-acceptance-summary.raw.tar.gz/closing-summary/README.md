# GEO-261 最終 F2 驗收彙總

固定來源 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`：正式17項全綠，9個額外phase在明列scope內皆符合預期。本檔只合併已完成收據，不是新執行，也不改寫兩份凍結快照。

Cperf首次ENOSPC原退出1與中斷JSON完整保留；新scratch只重跑該項原0。所有負控制原紅與恢復綠分列，不將預期紅改寫成退出0。Linux允許Windows GDI一項略過；六個Chrome156 job都實際跑完。Actions計費沿已鎖定的雲端等價裁判，不宣稱GitHub Actions本身已綠。

最不確定：額外Cperf恢復比值1.970798接近原2×門檻、每側原3筆；P52受負載影響；P73自證為受控真callback一次，舊自然subset不足自證歷史保留。完整數據、SHA角色及權威審查見FINAL_RESULT.json及兩份原METRICS。
