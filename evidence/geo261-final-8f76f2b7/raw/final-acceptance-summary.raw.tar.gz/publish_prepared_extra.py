"""Run one reviewed prepared publisher argv and preserve its original output."""
import json
from pathlib import Path
import subprocess
import sys
import time

folder = Path(sys.argv[1])
argv_file = sys.argv[2] if len(sys.argv) > 2 else 'publisher-argv.json'
argv = json.loads((folder / argv_file).read_text())
if not isinstance(argv, list):
    raise ValueError('publisher-argv.json must contain a command array')
if (folder / 'publish.result.json').exists():
    raise FileExistsError('Publication already attempted; preserve original result')
started = time.time()
with (folder / 'publish.stdout').open('xb') as stdout, (folder / 'publish.stderr').open('xb') as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr)
(folder / 'publish.result.json').write_text(json.dumps({
    'argv': argv, 'actual_process_returncode': result.returncode,
    'started_epoch': started, 'ended_epoch': time.time(),
}, ensure_ascii=False, indent=2) + '\n')
print('publisher original returncode:', result.returncode)
print((folder / 'publish.stdout').read_text()[-3000:])
print((folder / 'publish.stderr').read_text()[-1500:])
raise SystemExit(result.returncode)
