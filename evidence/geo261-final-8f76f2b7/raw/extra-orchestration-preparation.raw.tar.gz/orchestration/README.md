# F2 額外證據串行準備包

本包可直接交 root 接線，只有準備結果。未執行 proof driver、產品、Chrome、服務、編譯、測試、效能、Git 或 publisher；未改主 repo、正式來源、任何舊 frozen 工具或收據。只執行了本包檔案複製／字面替換／JSON命令稿生成與 AST 靜態語法檢查。

固定 F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`；P3：`55b9fb6479485361d9e2283a95e4355f5fca76db`；來源 `/tmp/g261r3/source-final`；共用 lock `/tmp/g261r3/heavy.lock`；外層錄製 root `/workspace/geo261-environment/F2-extra-outer`。正式17項結束後才開始本包 proof，不與正式串行爭CPU。

- `COMMANDS.md`：可讀的逐項確切原 argv、inner核對點與publish操作。
- `EXECUTION_PLAN.json`：9項機讀清單、全部明傳新F2外層參數、每項輸入白名單、排除tree與binary清單。
- `prepare_publication.py`：準備白名單逐檔argv/inventory、missing與ELF排除資料；不執行Git或publisher。加 `--preview-archive` 可在該phase結束後估壓縮大小。此 helper 尚未實際執行，僅AST parse；要發佈仍需明確執行其輸出 `publisher.sh`。
- `checker-f2-tools/`：唯一需要的新F2工具副本；只改 `DESIGN_SHA` 一行。完整舊包在 history；原/新hash、字面diff、AST只差該literal證明皆保留。新run SHA256 `a79a797e7417d6b81b5e07e6427ab0915bfa506f2ab09610b47a151bbbc11f3a`。
- `hard-binding-audit.md`：reader/parser/Cperf/P52/P73實際程式的固定SHA／CLI限制查核，並非只看argv。P52與parser沒有`--sha`；P52本身釘F2、parser由每phase outer的真HEAD/clean綁F2。Cperf是動態final＋P3設計source，reader動態SHA；P73固定F2且需傳相同SHA。
- `parser-native32-notes.md`：三個parser phase、14來源hash與既有native32/96 execution原紀錄索引。
- `SOURCE_HASHES.json`／`STATIC_SANITY.json`：此次實讀工具hash與純JSON／AST準備檢查；沒有把語法通過當runtime通過。

順序：P73 controlled → P52 runtime → reader → checker → parser prepare → parser O2 → parser ASan/UBSan → Cperf。native32已由root正常封存／push：commit `375aee120677cd9b8da972d159218ab972842750`、label `native-control-raw-index`；只保留原索引，不執行或重推重複label。

P52 runtime只在同F2正式P52 baseline真綠（四Node、五控制齊）後執行；Cperf只在同F2正式P189四點36 load／175dump真綠後執行。未達前置的項目記pending，繼續不相依項。額外自證結果現在皆未知；P73 controlled的明確一次callback scope不等於原自然subset，P52撤回是否能穩定轉紅仍需真實量測，不挑樣本或重跑找綠。

F1不可直接改標F2。固定產品與test input相同性引用已實際執行的P3 raw Git audit：`/workspace/geo261-environment/F2-perf-preparation/source-rebind/P3-binding-review-execution-r2/AUDIT.json` SHA256 `5a16fefe0d2a1c3f4de6ee92c801ccee3404161711bd5f687e47e25ca71045d0`；它記錄F1→P3 owned/input只runtime_version.py變、P3→F2 inputs同，15851 tests path/mode/blob同。此輪未再次Git驗證，未把P2approved覆蓋P3真review。若root要補獨立Git側錄，精確argv在plan的future_source_binding_git_commands_not_executed；原proof自身仍會執行既有來源guard，沒有新增approvalgate。

每phase run一次、核真inner、按白名單保全原stdout/stderr/環境/SHA/指令/真rc與還原狀態，再publish普通push完成才下個phase。異常同樣公開已有raw，missing如實列出。ELF、sourceclone、Chrome profile與暫存build不推；必要原source snapshots與Git archive stdout仍完整保留。publisher沒有自動排一般ELF／clone，沒有單檔大小防護，所以不能整棵scratch丟入。大raw按phase／原資料類型拆label，不截原streams。

本包完成後設唯讀並以根SHA256SUMS凍結。所有原工具history與內層原SHA256SUMS也逐bytes留存；freeze不代表待跑proof通過。
