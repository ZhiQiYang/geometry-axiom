# F2 額外自證工具的實際 SHA 綁定（唯讀備忘）

本檔只讀現有原碼、JSON、README 與已存在的 P3 審查紀錄並計算檔案 hash，未執行 Git、連網、import任何工具、AST解析、driver、編譯、產品、測試或 benchmark。沒有重新驗 Git source，沒有新增審查 gate，沒有修改 frozen 工具／既有收據。checker由父 agent另外處理，不在本次範圍。

共同身分：F1=`fe863b0374eafd9f1e57ec5107e28a1101804b56`；P3=`55b9fb6479485361d9e2283a95e4355f5fca76db`；F2=`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。

## 接線結論

| 工具 | 實際原碼是否硬寫 F1/F2 | F2編排要明列的限制 |
|---|---|---|
| reader Linux wrapper | 沒有 F1/F2 SHA 常數，依必填 `--sha` 動態綁定 | 傳F2完整40碼；保留獨立oldA/blob；不能跑原未修Linux路徑解析的副本 |
| parser recorder | 沒有 F1/F2 Git SHA 常數，**沒有 `--sha` CLI**；固定K c/h的64碼raw hash | 每phase outer前後另核F2/clean；明傳F2 repo與r3 lock；新out；14個raw hash不可縮水 |
| 累積Cperf P3 bundle | `--sha` 是動態 final SHA；硬綁P3 design及333個raw hash，非直接硬寫F2常數 | 明傳F2，禁止用P3代替；F2正式P189完整原收據必同sha；333raw必等P3 |
| F2P52 runtime proof | **硬寫F2，沒有 `--sha` CLI** | 不能用通用argv模板額外加 `--sha`；baseline必是F2正式P52完整綠收據 |
| F2P73 controlled | **硬寫F2，且必填 `--sha` 必須精確等F2** | 不可沿用F1run；只撤app guard片段；不把controlled視為原自然subset已被殺死 |

下列 CLI 都只是供串行候選使用，未因本備忘執行。`--repo`取 `/tmp/g261r3/source-final`、共用鎖取 `/tmp/g261r3/heavy.lock`，所有scratch必須全新。各工具自行持既有共用鎖，outer不可重複持同鎖。

## 1. Reader Linux wrapper

實際入口 `/workspace/geo261-environment/final-f-reader-linux-tools/run_reader_counterfactual.py`。

原碼必填 `--repo --scratch --shared-lock --out --sha --old-a-sha --old-reader-blob --python --node`。三個SHA/blob參數皆要求完整40碼；沒有預設F1或F2。source/head/clone checkout與各phase均核 `head==a.sha`；source必clean，withdrawn只准canonical HTML一檔dirty，protected五檔hash與staged/untracked守門均保留。執行時另fetch固定integration ref驗 `a.sha`可由已公開tip解析，不把本次純讀當成做過該網路驗證。

F2候選應用：

```text
python3 -B /workspace/geo261-environment/final-f-reader-linux-tools/run_reader_counterfactual.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --old-a-sha a12d184ec1865ad078700cea2387ac69e82ab62a --old-reader-blob 8d2e5e987a850c487cf71315bd2eaa0327490662 --scratch /tmp/g261F2reader --out /tmp/g261F2reader/proof --shared-lock /tmp/g261r3/heavy.lock --python /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 --node /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node
```

oldA `a12d184...` 與blob `8d2e5e...` 用於**唯一canonical trace撤回**；不是F1/F2 baseline，也不能改成P3 parent。原碼驗oldA是final祖先、oldA:path等明列blob、final HTML恰為oldA bytes唯一 `app_contact_facts`→`app_contact_facts_prepare`，且原SSOT/plain、test、sync、axiom_matrix五檔完全相同。原具名judge固定0/正常1/0，不自動sync、不改test。Linux副本只將 dirty/staged name parser改成 `git diff --name-only -z`＋NUL split，解決Unicode路徑quote，未新增SHA常數或改判準。

hash：

| 檔案（環境根目錄相對路徑） | SHA256 |
|---|---|
| `final-f-reader-linux-tools/run_reader_counterfactual.py` | `c54ed39f46cb62d85c7f3bdef2611f59372632051a7c03bf4e65b79e9be29016` |
| `final-f-reader-linux-tools/linux-path-parsing.patch` | `f2c1c42598c756607453a7523c9230357ed70eed71ff226b5a8a5a788500e7a6` |
| `final-f-reader-counterfactual-tools/run_reader_counterfactual.py`（歷史原副本，不應拿來跑Linux） | `5d97e9f95e9a85a0887f227693c2a1543d862629259d8a7427c754e4eab4aadd` |
| `final-f-reader-counterfactual-tools/README.md`（歷史準備說明） | `95406e0312cbcd49f7a6f5882d32d766c3ffe7f5af6bb971c1c664a20c661b52` |

## 2. Parser recorder

實際入口 `/workspace/geo261-environment/record_placement_header_equivalence.py`。CLI只有 `--repo --out --phase {prepare,o2,sanitized} --cc --expected-source-sha256 --expected-header-sha256 --lock`，**不得傳 `--sha`**。它的預設repo是root workspace，F2編排必須明傳r3受驗checkout，不可依賴預設。

硬綁的是K來源bytes：c=`45e754f4260e15679797b8f44c8c6a25132b199d47a7239da1e2045a8a814c31`，h=`9c11cb94b20231dabf746c6f23480b5c3d324fc9d268b0140a3e01fab4781aa8`。prepare保存當時HEAD、7個kernel inputs與7個context共14hash；O2/SAN要求14hash與prepared一致，並驗client/recorder/snapshot不變，但**不會把HEAD硬比某一F2常數，也不拒錄到dirty status**。因此外層每phase前後必核完整F2 HEAD與clean；fresh out不能以歷史F1 prepared替代。

沒有old Git SHA作撤回。prepare從當時HEAD讀同一placement_sources.c，驗原encoder/full decoder函式逐bytes仍相等，作同檔oracle。七個source snapshot與精確片段不可因排clone而被排掉。完整三phase CLI及ELF白名單已另寫 `parser-native32-notes.md`，不在此重複。

| 檔案 | SHA256 |
|---|---|
| `record_placement_header_equivalence.py` | `609e9426665adb4ec6617d66d0229000fb1b0fd819aab15df84c33349d52816c` |
| `placement_header_equivalence.c` | `98c1d348be49e00be980035a5a3b0c22d53be47b1ecb11fa505ec873ad050594` |

## 3. 累積C性能自證：本次P3 bundle

實際入口 `/workspace/geo261-environment/F2-perf-preparation/source-rebind/bundle/run.py`。

CLI必填 `--repo --scratch --heavy-lock --formal-receipt --sha`，另有 `--formal-tools --published-repo`。`--sha`只核完整40碼且不得等designP3，不直接比較policy的requested_final_F2欄；因此編排仍要明傳F2。即使亂傳F1，後續333owned exact raw必等新P3（含runtime P3修正），不能靠換label繞過。

來源守門是：輸入repo HEAD/clean等參數sha；公開remote可解析；原F2正式P189 receipt的main/base/fix shas必等 `adbaebf9.../3e600772.../a.sha`、36原樣本與各streams真0/無timeout、四點各≤2、完整dump依固定BASE scene清單逐bytes相等；設計333pathset及所有raw等P3；六個C原值與撤回template hash；兩public header保持；restored binary與正式fix binary exact。不能拿F1 formal receipt或P3設計SHA代替F2正式驗收。

硬綁design P3=`55b9fb...`。舊SHA用途：

- main=`adbaebf9c73ea6801d7b4d5214e4b846b132923b`、base=`3e600772076465fc65a26ac09055028301c0fb0b`：原正式P189參照，不改成新main。
- old algorithm reference=`f2c8837aeba3c49eacbd77b5161f07c819204263`：累積純C性能撤回設計來源，不是受驗final。
- 原設計P=`b6646d10751a0d85a2f03f5d24fbe1073cb78980`、previous P2=`8a80abc1402b0c4c394969025c93a6019b4bb91d`：設計沿革，舊包完整留在previous-P2-bundle；既有P3中介資料檢查核現在的P3 review/四工具/六template，不能沿用舊review改名。
- F1=`fe863b...`：historical-F1-counterproof原收據/公開archive證據，既有review明列只屬F1歷史，不能作F2 runtime。

候選命令：

```text
python3 -B /workspace/geo261-environment/F2-perf-preparation/source-rebind/bundle/run.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --scratch /tmp/g261F2perf --heavy-lock /tmp/g261r3/heavy.lock --formal-receipt /tmp/g261r3/tools/p189-8f76f2b7/receipt.json --formal-tools /tmp/g261r3/tools --published-repo /workspace/geometry-axiom
```

下列檔案hash均從現檔重算；P3 source/601/tests/SSOT/C6/header成立的依據是**既有**P3獨立audit，本次沒有重跑其Git核對。

| bundle內檔案 | SHA256 |
|---|---|
| `run.py` | `3c80aac969cdcbbc8df691c63223eb68273f2c3af2f4e2f3dd13c1c7db82bc8c` |
| `capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| `validate.py` | `f85871fbfa37552a80c40cd1d3f89ba43f8c33f7d02e2773839a120bd8e1d429` |
| `rebind_gate.py`（既有P3中介資料接線） | `0e77d9092fe1e134fdada8ae8527812b77253cf98fe2a7faeedaf37adc520b01` |
| `counterfactual-design.json` | `49ee1caa85506b6df2f26937a0efdd425eb3177c2f8b8e5304907ed78f410efc` |
| `P3_BINDING_REVIEW.json` | `996d69f43c2b210f14202bf06f18403f0c142408c50ede1c3bde4516b4378d47` |
| `P3_BINDING_REVIEW.md` | `6273a9ef316e94cd916866b931bdadc0f77996627c873ed710150499530283e8` |

引用既有原紀錄：`F2-perf-preparation/source-rebind/P3-binding-review-execution-r2/AUDIT.json` SHA256=`5a16fefe0d2a1c3f4de6ee92c801ccee3404161711bd5f687e47e25ca71045d0`；其原內容為P2/F1/P3/F2四組共2404 raw、每組601＝333+268、15851 tests path/mode/blob、16條Git原退出0及103247 metadata核對、issues=[]；product/network/build/test/benchmark均false。本次只讀該JSON與hash，不聲稱重新執行這些Git命令。先前本agent的44journal/220檔/previous34檔純讀輔助紀錄 `P3-source-journal-bytes-peer-readonly-20261022.json` SHA256=`dcfb810c7faab8dcfe2e6ed6e3c380c8592e516c5c02b1e553b7807b663b96e9`；仍是既有分工，不另構成新approval。

## 4. F2 P52 runtime-only 撤回／恢復

實際入口 `/workspace/geo261-environment/final-f2-p52-runtime-proof-tools/run.py`。

原碼明列F2、OLD=F1、P3、MAIN四個完整40碼常數；**沒有 `--sha` CLI**。必填 `--repo --scratch --heavy-lock --baseline-receipt`，選填 `--protocol-dir`（預設r3 tools）與 `--reaper`。F2身份由內部hard constant、source/head/status、clone guard與baseline.sha強制，不需/不接受通用 `--sha`。

正式baseline必sha=F2、no_regression=true、main/fix各16、四Node原退出0、五原控制expected_behavior_proved=true、四protocol hash exact。本工具只引用baseline，額外跑withdrawn/restored兩phase，各自保持原main/fix/fix/main。OLD=F1僅供**runtime_version.py單檔blob撤回**：run從Git讀F2/OLD該檔，比對固定64hash，並核P3 parent該檔=OLD、P3該檔=F2且P3只改這一檔；不是整份F1 checkout冒當F2。

runtime固定raw：F2 `1cafc0868554e9f4028de3c6851d12cb8d9716fec18a6fe379afbbd2e3b14274`；OLD F1 `5b7261519e70e51f952264c56d0a7cf18e7d4fdeeb8bb033fc391f08339468ea`。main常數=`adbaebf9...`。`protocol/p52_measure.py`也明列 SHAS.final=F2；phase.py把原postfix module.SHA與輸出/工作目錄接到request F2，使用原one與原timing AST，未執行該measure.main歷史入口。

```text
python3 -B /workspace/geo261-environment/final-f2-p52-runtime-proof-tools/run.py --repo /tmp/g261r3/source-final --scratch /tmp/g261F2p52runtime --heavy-lock /tmp/g261r3/heavy.lock --baseline-receipt /tmp/g261r3/tools/postfix-8f76f2b7/receipt.json --protocol-dir /tmp/g261r3/tools
```

| 工具包內檔案 | SHA256 |
|---|---|
| `run.py` | `27d502abe6398f23d1900d46b9a52cfc27f22c4e6e2fa64350f76ffb15f4f0a6` |
| `phase.py` | `3a79d8fe5e7ef561a59a1c6499c27f8b4221ad15362909fc137365c02d7bff9c` |
| `capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| `protocol/postfix_validate.py` | `b9fbcca0eb12e2e25fb5d84eda01038bf8406d1c3a533fa5dfd842e330cf8c5f` |
| `protocol/p52_measure.py` | `738a36b0417e7f5cfa1dcf57fc0d14664650b8285484f866b8ceb0d3a2c8f1a4` |
| `protocol/p52_probe.cjs` | `8c3b4b14ad35082679e4faf229bd66d65a500bd53669c13d8f41e0603e066970` |
| `protocol/p52_cases.cjs` | `6ca75996223e94be0a503e646d58ed928b046854eb0102af309482dc4ac60f66` |

## 5. F2 P73 controlled callback

實際入口 `/workspace/geo261-environment/final-f2-p73-controlled-tools/run.py`。

原碼 `F='8f76f2b7d6f669670e5834310bfc26495b4a4aa6'`，必填 `--repo --scratch --sha --heavy-lock`，硬核 `a.sha==F`。選填Chrome/reaper與三階段服務/CDP起點；預設服務19920–19922、CDP9560–9562，外部占埠時拒絕，不停止他人程序。

來源/head/status必等F2，原七個INPUTS逐phase hash相同；withdrawn只准app.js dirty。它不從F1撤整份app，而以 `FIXED` 精確片段唯一replace成內嵌 `OLD` 的SVG.hidden guard；撤回/恢復仍留F2 HEAD與明確dirty variant，原test不改、原predicate從F2 uiux_review_test.js擷取。schema名字中的 `final-F` 是歷史能力名，不代表受驗SHA為F1。

```text
python3 -B /workspace/geo261-environment/final-f2-p73-controlled-tools/run.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --scratch /tmp/g261F2p73controlled --heavy-lock /tmp/g261r3/heavy.lock
```

本次純bytes比較確認：`history/original-F-tools/run.py` 中恰一處F1常數換成F2，所得bytes完全等現在run.py；未import、AST或run它。INPUT_BINDING.json亦保留F1→F2的來源準備說明（唯一runtime檔差），不是F2產品執行。history/舊自然subset撤回原0維持歷史；controlled即使取得正常0/1/0，仍不能改稱原自然subset已轉紅。

| 工具包內檔案 | SHA256 |
|---|---|
| `run.py` | `57c5e2e50cccf414dfd07386da747ecc4984f64190943353c8f8e4edcd249a21` |
| `probe.cjs` | `d664b5d0452aed5a90a991d6f2ee5218d1cd5afad78b6d45aef7bb300c4c7fb9` |
| `capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| `INPUT_BINDING.json` | `af0820599a3e6cb3215d58d26175904ef1cbfcb2854f957c9adf0a82c586641d` |
| `history/original-F-tools/run.py`（僅歷史） | `07316599969e991720e9ba3732708542ba28a90d9b9cc0b5c2f1f40f3c5fe614` |

## 執行與歷史邊界

本檔核的是目前工具code的來源綁定，不代表任何F2 proof已跑。實際結果只由後續root串行執行的原argv/退出碼/完整streams/SHA與恢復紀錄更新；PREPARATION、舊F1 receipts、audit通過與工具命名都不能替代新runtime。若正式17項尚未全部結束，按root原排程等待，不在此平行啟動產品。所有上述code/JSON均保留原檔，本備忘只是新notes。
