# 最終 F 單一 contact checker 自證（準備稿，尚未執行）

只執行原方法 `tests.test_geo261_wood_contact_world.ContactWorldBoundary.test_five_real_main_consumers_delegate_and_keep_original_member_identity`。此 class 的 AST 只有兩個test方法、沒有setup；所選方法只讀current_geometry.c並做靜態assert。W公用兩檔由另一個未選方法讀取，本工具只對它們額外核hash。NativeBuild只是module匯入的class定義，所選方法不呼叫它，也不執行WoodContactWorld的20個舊控制。不改產品、不放寬判準、不commit/push；舊identity/boundary asserts均保留，撤回只移除本次新增的wrapper assertEqual及helper定位。

F 固定為 `fe863b0374eafd9f1e57ec5107e28a1101804b56`。原checker的9535 Git blob與F blob各釘SHA256，且工具要求整份F test bytes只做本次三行→一行的exact替換就等於舊blob。附patch供審查；runtime用鎖定Git blob，並另保存實際full-index withdrawal patch。

順序是fixed0 → withdrawn-old-checker1 → restored0，各階段完全同一具名原argv；child使用工具相同sys.executable，原 `-B -m unittest -v <method>` 參數不變，避免版本記錄與實際child不符。紅必須是同一方法的FAIL、原Regex didn't match與wrapper呼叫的既知病因，且恰一failure；ERROR、skip、crash、timeout、其他病因都標紅。每個子命令原argv/cwd、真process rc、完整stdout/stderr bytes、時間、stdin、hash都由原已審capture.py封存。capture.py原碼未改，SHA256為c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762。120秒僅為外層infra watchdog，超時永遠不能當有效withdrawn紅，沒有給產品設新門檻。

全新scratch的獨立clone使用local shared object database，建立獨立working tree；不改來源repo，正式F來源clone須保留到本工具完成。來源repo前後均核F/clean；每階段核整棵tracked tree的status/diff只能是該test-file，另逐bytes hash實際三個產品輸入。withdrawn receipt明列test-only variant及dirty checker hash，不冒稱該階段是乾淨F工作樹。inner與outer finally均精確回寫F test bytes，再核clone與來源；失敗現場保留，不自動重試挑綠。

root應在正式seven/special pipeline結束後，先封存本工具包原碼，再以既有外層收據/子程序回收器執行（本準備流程未執行）：

```bash
python3 -B /workspace/geo261-environment/final-f-contact-checker-proof-tools/run_final_checker_proof.py \
  --repo /tmp/g261r2/source-final \
  --sha fe863b0374eafd9f1e57ec5107e28a1101804b56 \
  --scratch /tmp/g261Fchecker \
  --heavy-lock /tmp/g261r2/heavy.lock
```

scratch父目錄須已存在，scratch本身不得存在；必填heavy lock必須是正式F同一把現存鎖，工具以nonblocking flock排他。不得外層再次持有同一把鎖。工具自身凍結run/capture/patch原碼到scratch/tools並前後核hash。Python optimize被拒，child清除PYTHONOPTIMIZE/PYTHONPATH/PYTHONSTARTUP/NODE_OPTIONS和GEOMETRY_*覆寫，明列有效環境與清除的變數名稱，設定child真GITHUB_SHA/WORKSPACE、獨立TMPDIR與16MiB soft stack。全三階段不自動retry。

本工具是針對本輪test-checker修正的短負控收據，不新增approval gate，不取代正式native或任何舊控制。`PREPARATION.json`的靜態準備通過不表示runtime自證已綠。
