# Checker F2 最小綁定副本（只準備，未執行）

此副本只把 run_final_checker_proof.py 的 DESIGN_SHA 從 F1 換為 F2；執行路徑、原具名 unittest、0/1/0 判準、原 checker hashes、撤回來源 9535fcf、產品 inputs、guard、timeout、還原與錄製全部保留。原 frozen 工具整包逐 bytes 存於 history/original-F1-tools/，原路徑未改。

F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。正式來源 `/tmp/g261r3/source-final`。舊 F1 與 F2 不相同：P3 `55b9fb6479485361d9e2283a95e4355f5fca76db` 只改 geometry-web/runtime_version.py；test 與 checker 產品 input bytes 的相同性引用已完成的 P3 raw Git audit，而非本次重新 Git 查核。本次沒有執行 Git／產品／測試；沒有把原 F1 receipt 改綁成 F2 receipt。

採用時的唯一新執行命令由上層 F2 EXECUTION_PLAN.json / COMMANDS.md 提供，必外套 execute_f_extra.py 明傳 F2/repo/outer-root。此腳本自己的 source／clone guard 仍要求真 F2 HEAD、全 tree status、FIXED_HASH、原 OLD_HASH 與三個產品 input 的執行前後原 bytes。歷史 OLD_SHA 9535fcf 是僅撤回 checker 三行的來源，不是受驗 SHA。

AST 靜態檢查只 parse 新舊 source，不 import、不執行。把新 AST 的 DESIGN_SHA literal 還原 F1 後，整棵 AST 與舊版相同；字面差分亦恰一行且前後等長。這不是 runtime proof，三 phase 結果仍待真正執行。

來源綁定依據：`/workspace/geo261-environment/F2-perf-preparation/source-rebind/P3-binding-review-execution-r2/AUDIT.json` SHA256 `5a16fefe0d2a1c3f4de6ee92c801ccee3404161711bd5f687e47e25ca71045d0`；其原 Git 2404 份 source blob／601 inputs each、333 owned／268 excluded、15851 tests path/mode/blob，確認 F1→P3 owned/input 唯一 runtime_version.py，P3→F2 inputs 同；原 review 仍留在 P3 bundle，未挪用 P2 approved。
