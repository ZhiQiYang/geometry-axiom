# F2 額外證據串行命令（尚未執行）

所有命令使用 F2 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`，必在既定17項結束後逐項執行。每項執行完核inner，再封存／一般push，等push結束才下一項。此稿不自動執行、不新增門檻，不把prepared視為綠。

每個proof自行持同一heavy lock；outer只錄製與reaper，不再外套同鎖。scratch與outer label須全新；失敗保留現場、真rc、missing檔，先復原，再處理其它不受影響項。

## 1. F2-P73-controlled

真 F2 app 同一 sync callback 明確呼叫一次、原 P73 predicate；不是自然 subset。

- 前置：正式17項結束且無產品/效能/壓縮競爭；scratch/outer label全新。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-P73-controlled --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/final-f2-p73-controlled-tools/run.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --scratch /tmp/g261F2p73controlled --heavy-lock /tmp/g261r3/heavy.lock
```

原inner receipt：`/tmp/g261F2p73controlled/receipt.json`。

- outer actual_process_returncode=0；inner sha=F2、passed=true、errors=[]、原來源/clone還原clean。
- phases fixed/withdrawn/restored 順序與真 Node/reaper exit 恰0/1/0；三phase.passed=true。
- probe callbackInvocations=1，before.originalPredicate=true；原assert exact，只有撤回guard後原predicate紅；無額外exception/timeout；server/node reaper都完整完成。
- 不得把原F1自然subset撤回0/restored0 outer1改寫成成功。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase P73-controlled --out /tmp/g261F2publication-P73-controlled --result '在此填入真inner結果與任何限制' --next F2-P52-runtime
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 2. F2-P52-runtime

P3 runtime_version.py 單檔撤回／恢復；引用同F2正式P52baseline，額外只做原timing四block，不重跑原五控制。

- 前置：正式17項結束。
- 前置：同F2正式P52原收據先真綠且原四Node/五控制全齊；否則標前置未達/pending，繼續不相依項。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-P52-runtime --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/final-f2-p52-runtime-proof-tools/run.py --repo /tmp/g261r3/source-final --scratch /tmp/g261F2p52runtime --heavy-lock /tmp/g261r3/heavy.lock --baseline-receipt /tmp/g261r3/tools/postfix-8f76f2b7/receipt.json --protocol-dir /tmp/g261r3/tools
```

原inner receipt：`/tmp/g261F2p52runtime/receipt.json`。

- 先讀正式baseline：sha=F2、timing.no_regression=true、count main16/fix16、records4全exit0、controls5全expected_behavior_proved=true、drivers_sha256等原PROTOCOL。
- inner sha=F2、passed=true、errors=[]；兩phase withdrawn/restored，真原gate exit=1/0、phase.passed=true；Node四block各真0才可把gate1當性能紅。
- 每phase completed=true、errors=[]、每side16、trial0..7各block齊、failed/exceptions/fatal皆無、reaper完成/primary_rc等真gate；finally固定來源與cloneclean。
- withdrawn若gate仍0：如實自證未符，仍執行一次restored；不抽樣重跑、不挑綠、不改P52原門檻。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase P52-runtime --out /tmp/g261F2publication-P52-runtime --result '在此填入真inner結果與任何限制' --next F2-reader
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 3. F2-reader

只跑原 canonical reader 一個具名方法；fixed0／舊A HTML trace1／restored0，不冒稱再跑完整51。

- 前置：正式17項結束；使用Linux NUL路徑版，明列所有SHA/blob與Python/Node，不使用舊F1 argv。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-reader --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/final-f-reader-linux-tools/run_reader_counterfactual.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --old-a-sha a12d184ec1865ad078700cea2387ac69e82ab62a --old-reader-blob 8d2e5e987a850c487cf71315bd2eaa0327490662 --scratch /tmp/g261F2reader --out /tmp/g261F2reader/proof --shared-lock /tmp/g261r3/heavy.lock --python /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 --node /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node
```

原inner receipt：`/tmp/g261F2reader/proof/receipt.json`。

- outer真0、inner sha=F2、passed=true、errors=[]；phases fixed/withdrawn/restored各actual_exit=0/1/0、expected_verdict_matched=true、timeout_expired=false。
- 原具名FAIL病因是I11 facts/facts_prepare trace；原Git舊A/blob、protected裁判/SSOT/生成器hash、published ancestor均原工具實核；最後clone/source clean。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase reader --out /tmp/g261F2publication-reader --result '在此填入真inner結果與任何限制' --next F2-checker
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 4. F2-checker

原 static checker 一個具名方法；僅撤回test三行，產品C始終不變；不替代20個舊controls。

- 前置：正式17項結束；必須用本包checker-f2-tools，原frozen run硬釘F1會拒絕F2。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-checker --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/checker-f2-tools/run_final_checker_proof.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --scratch /tmp/g261F2checker --heavy-lock /tmp/g261r3/heavy.lock
```

原inner receipt：`/tmp/g261F2checker/receipt.json`。

- outer真0、inner sha=F2、passed=true、errors=[]；phases fixed/withdrawn/restored真exit0/1/0、passed=true。
- 紅是原方法唯一FAIL與Regex wrapper/prepare病因，不能ERROR/skip/crash/timeout/compileerror；FIXED_HASH/OLD_HASH與3產品input執行前後皆原工具核，source/clone最後clean。
- 本F2副本只更換DESIGN_SHA；原F1 receipts與歷史PREPARATION不修改、不改綁。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase checker --out /tmp/g261F2publication-checker --result '在此填入真inner結果與任何限制' --next F2-parser-prepare
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 5. F2-parser-prepare

同 actual placement_sources.c 完整decoder oracle／private headerreader的外部差分；非mutation、非正式整套驗收。

- 前置：正式17項結束；prepare用全新out，O2/SAN沿同prepared out；每phase獨立outer與先publish後下一phase。
- 前置：原工具沒有--sha，不能僅換argv假稱新綁定；依outer真F2HEAD/clean和既有P3 K-source等價audit；必傳r3 lock，工具自己持鎖。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-parser-prepare --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase prepare --cc gcc --lock /tmp/g261r3/heavy.lock
```

原inner receipt：`/tmp/g261F2parser/prepare-record/receipt.json`。

- outer每phase真0且前後HEAD=F2/status全空；inner sourceBaseHead=F2、exitCode0、passResult=true、sourceBytesUnchanged=true；14input/context原hash前後相同。
- prepared.compiled=false、testsRun=false；4筆Git原輸出全0，不稱runtime差分綠。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase parser-prepare --out /tmp/g261F2publication-parser-prepare --result '在此填入真inner結果與任何限制' --next F2-parser-o2
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 6. F2-parser-o2

同 actual placement_sources.c 完整decoder oracle／private headerreader的外部差分；非mutation、非正式整套驗收。

- 前置：正式17項結束；prepare用全新out，O2/SAN沿同prepared out；每phase獨立outer與先publish後下一phase。
- 前置：原工具沒有--sha，不能僅換argv假稱新綁定；依outer真F2HEAD/clean和既有P3 K-source等價audit；必傳r3 lock，工具自己持鎖。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-parser-o2 --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase o2 --cc gcc --lock /tmp/g261r3/heavy.lock
```

原inner receipt：`/tmp/g261F2parser/o2-record/receipt.json`。

- outer每phase真0且前後HEAD=F2/status全空；inner sourceBaseHead=F2、exitCode0、passResult=true、sourceBytesUnchanged=true；14input/context原hash前後相同。
- 原compile與run真0、run stderr空、stdout末行PASS placement-header-raw-equivalence；原199810 observations／零issue；SAN原ASAN/UBSAN env不改。不可用wrapper0或編譯失敗代替差分。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase parser-o2 --out /tmp/g261F2publication-parser-o2 --result '在此填入真inner結果與任何限制' --next F2-parser-sanitized
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 7. F2-parser-sanitized

同 actual placement_sources.c 完整decoder oracle／private headerreader的外部差分；非mutation、非正式整套驗收。

- 前置：正式17項結束；prepare用全新out，O2/SAN沿同prepared out；每phase獨立outer與先publish後下一phase。
- 前置：原工具沒有--sha，不能僅換argv假稱新綁定；依outer真F2HEAD/clean和既有P3 K-source等價audit；必傳r3 lock，工具自己持鎖。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-parser-sanitized --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase sanitized --cc gcc --lock /tmp/g261r3/heavy.lock
```

原inner receipt：`/tmp/g261F2parser/sanitized-record/receipt.json`。

- outer每phase真0且前後HEAD=F2/status全空；inner sourceBaseHead=F2、exitCode0、passResult=true、sourceBytesUnchanged=true；14input/context原hash前後相同。
- 原compile與run真0、run stderr空、stdout末行PASS placement-header-raw-equivalence；原199810 observations／零issue；SAN原ASAN/UBSAN env不改。不可用wrapper0或編譯失敗代替差分。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase parser-sanitized --out /tmp/g261F2publication-parser-sanitized --result '在此填入真inner結果與任何限制' --next F2-Cperf
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 8. F2-Cperf

原同F2 P189 36交錯／175dump作前置；額外N64 main/withdrawn/restored各3輪，全組C省工負控，不宣稱單component必要性。

- 前置：正式17項結束。
- 前置：同F2正式P189四點36/175dump先真綠；否則標前置未達/pending，繼續不相依項。
- 前置：既有P3binding review/gate原已完成，不增加新審查gate；必保全subcommands中的Git archive原stdout，不能用排sourceclone為由刪raw。

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/execute_f_extra.py --label F2-Cperf --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --repo /tmp/g261r3/source-final --outer-root /workspace/geo261-environment/F2-extra-outer -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-perf-preparation/source-rebind/bundle/run.py --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 --scratch /tmp/g261F2perf --heavy-lock /tmp/g261r3/heavy.lock --formal-receipt /tmp/g261r3/tools/p189-8f76f2b7/receipt.json --formal-tools /tmp/g261r3/tools --published-repo /workspace/geometry-axiom
```

原inner receipt：`/tmp/g261F2perf/receipt.json`。

- formal()先核正式F2四點36原load、各≤2、原175dump及全部raw/環境/工具hash，不造新門檻。
- outer真0、inner sha=F2、status完成、exit_code0、errors=[]、proof_matched=true、semantic_equivalence=true、restored_green=true。
- 三side編譯/loadfile+dump真0、dump逐bytes相同；原9個timing子程序真0、actual load command/workingdir/scene/stdin可核；withdrawn/main>2、restored/main≤2。
- design_source_sha=P3、333owned input核原P3audit，runtime修正保留，僅原6Ctemplates撤回；finally source/clone還原F2clean；不把P2approved覆蓋P3review。

核對後，只準備publisher argv／清單（此helper不執行Git或publisher）：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/F2-extras-orchestration/prepare_publication.py --phase Cperf --out /tmp/g261F2publication-Cperf --result '在此填入真inner結果與任何限制' --next F2-native32-raw
```

再依生成 `publisher.sh` 的單一命令進行一般publish。`--result`必填真結果，模板文字不能直接發佈。不存在的原輸出只列missing，helper不假造；真實失敗同樣封存已存在raw。

## 9. F2-native32-raw

只封既有F2 native 32控制／96次原execution JSONL，並非32個unittest方法；27新增＋5既有，三suite原輸出不重序列化冒充原件。

- 前置：正式17項結束後純封存；沒有command、沒有新outer、沒有新control execution。

此項不執行產品／控制，只封存原native紀錄。

原inner receipt：`/tmp/g261r3/seven-final/native/receipt.json`。

- 正式native原receipt sha=F2/exit_code0/前後clean；三suite9/9、19/19、19/19。
- definition12×3=36、host8×3=24、placement12×3=36；各control baseline/mutant/restored原0/1/0、timedOut=false、具名ASSERT，全文stdout/stderr原bytes嵌三log。
- 索引內9個原檔SHA256須對當時已完成F2native；不重跑、不編譯，不把source-index另8控的缺raw宣稱已補齊。

已公開：commit `375aee120677cd9b8da972d159218ab972842750`，label `native-control-raw-index`；本項不再執行、不重推。原96筆索引與九檔hash見 parser-native32-notes.md。

## 既有 publisher 使用界線

`publish_progress.py`會立即打包、更新PROGRESS、英文commit並普通push；沒有dry-run。它不會排除一般ELF／sourceclone，也無100MB大小防護。必用EXECUTION_PLAN白名單，保留完整stdout/stderr與原Git archive stdout.tar；若預壓縮接近host單檔限制，按原phase/raw類型拆不同label，不截斷raw。

`prepare_publication.py`只讀白名單，生成逐檔publisher argv、SHA/bytes inventory、missing/omitted列表；不copy source、不execute產品/Git/publisher。執行後先看產物是否確實含本phase全部raw，再跑publisher.sh。它不是新的產品判準或approvalgate。ELF排除清單只記錄實際存在的binary bytes/hash，不遞迴複製／散列sourceclone。

publisher環境/auth出錯：保留原退出1，修復環境後用普通push與獨立修復收據公開，不重跑該proof、不改原rc。不可並行publisher或force push。

每個phase的結果都仍待真正執行；只有native32原紀錄已完成，引用明列原F2native receipt而無新執行。
