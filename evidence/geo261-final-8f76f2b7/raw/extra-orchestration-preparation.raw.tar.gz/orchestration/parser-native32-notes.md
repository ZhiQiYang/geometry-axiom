# F2 parser 三 phase 與既有 native32 原始輸出接線備忘

本檔只讀既有工具／說明與已完成 F2 native 小型輸出；未執行 driver、Git、產品、編譯、測試或 benchmark，未改 frozen 工具、repository、既有收據。這是 root 已授權的串行編排候選之資料，不新增審查 gate，也不把命令稿當成執行結果。

F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`；既有乾淨受驗 checkout `/tmp/g261r3/source-final`；共用鎖 `/tmp/g261r3/heavy.lock`。

## Parser：確切原 CLI 與生命週期

以下僅將舊 execution map 的 F1 repo/out/lock 換成 F2 的候選位置；`/tmp/g261F2parser` 執行時必須全新，若 root 主候選另選新路徑，可一致替換三個 `--out`。三項各自 outer／reaper，串行執行：

```text
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase prepare --cc gcc --lock /tmp/g261r3/heavy.lock
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase o2 --cc gcc --lock /tmp/g261r3/heavy.lock
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/geo261-environment/record_placement_header_equivalence.py --repo /tmp/g261r3/source-final --out /tmp/g261F2parser --phase sanitized --cc gcc --lock /tmp/g261r3/heavy.lock
```

原工具沒有 `--sha`。outer 必須在**每 phase 前後**核 HEAD=F2、完整 porcelain status 空；工具自己的 status 用 `--porcelain=v1` 且只錄不拒 dirty，不能以該欄取代 outer guard。prepare 的 `out.mkdir(exist_ok=False)`、每 phase 的 `<phase>-record.mkdir(exist_ok=False)` 都不可重用；O2/SAN 沿同一份 prepared out。

原工具自行以 `flock(LOCK_EX|LOCK_NB)` 持 `--lock`；outer 只錄製＋reaper，不再持同鎖，不包會持同鎖的 run_special_round。呼叫端設定 soft stack=16MiB、hard不降；不使用 `-O`／PYTHONOPTIMIZE。工具本身只錄 stack，沒有主動調整 stack。

原 CLI 的預期來源 hash（不能默默跳過／覆成當場讀值）：

- `placement_sources.c`：`45e754f4260e15679797b8f44c8c6a25132b199d47a7239da1e2045a8a814c31`
- `placement_sources.h`：`9c11cb94b20231dabf746c6f23480b5c3d324fc9d268b0140a3e01fab4781aa8`

共 **7個 kernel INPUTS＋7個 CONTEXT＝14個 raw hash**，不是總共7個：INPUTS=`placement_sources.c/.h, placements.h, regions.h, geometry.h, types.h, source.h`；CONTEXT=`current_geometry.c, kernel/source.c, reference_sources.inc, woodworking/definition_sources.c/.h, woodworking/contact_sources.c, geometry-web/app.js`。prepare 拍下7個 kernel input；另保留 HEAD 原 full source、encoder/完整decoder 原函式與 actual 逐byte相同證明及新 header-reader exact 片段。C client直接 include snapshot `placement_sources.c`，完整原 decoder 是同檔 oracle，非複製新 parser。

prepare 只取得四個 Git 原輸出（head/status/diff/head-oracle-source），建立 snapshot／`prepared.json`，**不編譯、不測試**。其成功只有該 phase 的 `passResult=true, exitCode=0`，而 prepared 的 `compiled=false, testsRun=false` 必須保留。

O2/SAN 各有三個 Git 原輸出＋compiler version／python version／compile／run，正常各7筆 commands。O2 原 flags：

```text
gcc -std=c11 -O2 -ffunction-sections -fdata-sections -I <out>/snapshots/kernel <out>/client.c -Wl,--gc-sections -o <out>/o2-record/client
```

SAN 原 flags 用 `-std=c11 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer` 取代 O2 的兩個旗標，餘相同，輸出 `<out>/sanitized-record/client`。原 SAN env=`ASAN_OPTIONS=detect_leaks=1:abort_on_error=1`、`UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`，不得改。compile timeout180s、run timeout900s；版本各30s。

每一 phase inner receipt 應讀 `<out>/<phase>-record/receipt.json`，outer真0不能代替：須保留 `exitCode`／`passResult`、`sourceBaseHead`、來源前後14hash與 `sourceBytesUnchanged`。O2/SAN另需 build原退出0、compiler/python version原退出0、run原退出0、run stderr空、stdout最後一行 `PASS placement-header-raw-equivalence`。若launch/timeout，原`actualProcessReturncode`與衍生124/125分列，不能冒稱正常紅或通過。receipt原 `notFinalSourceAcceptance=true` 不改、不以此取代正式17項。

## Parser：每 phase 即時封存白名單

每 phase採全新 label，只收當時已存在檔案，另加該 phase完整 outer（request/receipt、c387 subcommands原stdin/stdout/stderr、reaper.jsonl）。白名單：

- `<out>/prepared.json, client.c, recorder.py.txt, SHA256SUMS`
- `<out>/commands/`（當時所有原argv/receipt/stdout/stderr；prepare4筆，正常O2累積11筆、SAN累積18筆）
- `<out>/snapshots/`、`<out>/oracle-reference/`（這些小型原始碼與 exact 片段是必要證據，不能把所有 `.c` 一律排除）
- 已完成 phase 的 `<phase>-record/receipt.json` 與 `<phase>-record/full-checkout.patch`。

排除 `<out>/o2-record/client`、`<out>/sanitized-record/client` 兩個 ELF與 `*-record/tmp/`，**不能整收 `<phase>-record/`**。執行後才為實際存在的排除檔建立小 inventory（path/bytes/SHA，binary hash可對receipt）；不修改原SHA256SUMS來刪ELF條目。prepare後/O2後/SAN後工具會重產out根SHA256SUMS，封存每個label當時版本，不覆舊label。

不收 `/tmp/g261r3/source-final` 或其他 source clone／`.git`，不收整棵 parser scratch 的未篩選版本。publisher不會自動排一般clone/ELF，也沒有100MB限制檢查；按白名單預壓縮核實大小，再一般push。失敗也收當時outer/phase receipt與已有raw，缺檔如實記，不以不存在路徑呼publisher。

## Native32：不再執行，沿用正式 F2 native 的96筆原紀錄

原 native receipt `/tmp/g261r3/seven-final/native/receipt.json`：sha=F2、exit_code=0，checkout_before/after均HEAD=F2、status空。SHA256=`ff9551e7387a75b01f9b06843577623b95bbd98479f94990806239a9fa65ceb0`。

完整正式命令的原收據位置為 `steps[1].result`：`bash -e /tmp/g261r3/seven-final/native/steps/01.executed.sh`，actual_process_returncode=0、exit_code=0、watchdog_expired=false；完整原輸出路徑 `steps/01.stdout, 01.stderr, 01.combined.log`。不需再執行控制或編譯client。

原始96次執行的 `command, exitCode, timedOut, stdout, stderr` **嵌入以下三個原 `.log` 的JSONL**；並非96個獨立stdout/stderr檔案。應逐bytes複製這三份原log，不把抽出的摘要或重新序列化JSON冒充原輸出。每個control依序佔3行 baseline/mutant/restored；以下實讀皆為0/1/0、timedOut=false、正常具名`ASSERT:`，沒有compile error/crash/timeout充當mutant紅。

根目錄 `NATIVE_LOGS=/tmp/g261r3/seven-final/native/run_all-logs`：

| 原檔 | 方法數 | 控制／原執行 | bytes | SHA256 |
|---|---:|---:|---:|---|
| `py_test_geo261_definition_sources.log` | 9/9 | 12／36 | 11154 | `55c9de9a79c657053095e21af6d30b463205f6c49fb539adc8511a4b4ded8b9e` |
| `py_test_geo261_host_facts_authority.log` | 19/19 | 8／24 | 7738 | `b12bd75c006c2f9066fb7d3967234efb48cc058659a7f152d30dc2591374a0d2` |
| `py_test_geo261_placement_definition.log` | 19/19 | 12／36 | 11665 | `01da9d30696452f1c48aa7085cca6982c56321f135933fe9b5eae028bd836176` |

三組相加32個控制、96筆原execution；這與 suite 方法總數不同，不能稱「32個 unittest方法」或「96個負控」。

### 原 JSONL 行號索引

每個range三行依次為baseline/mutant/restored，mutant行為中間那行。

| definition_sources控制 | 原log行 |
|---|---|
| contact-host-offset | 1–3 |
| contact-direction-offset | 4–6 |
| contact-order-offset | 7–9 |
| contact-trailing | 10–12 |
| contact-text0-bound | 13–15 |
| contact-text1-bound | 16–18 |
| contact-text2-bound | 19–21 |
| literal-value | 22–24 |
| literal-edge | 25–27 |
| RC-room-edge | 28–30 |
| UV-cache | 31–33 |
| fixity-value | 34–36 |

| host_facts_authority控制 | 原log行 |
|---|---|
| snapshot-uv | 1–3 |
| live-length | 4–6 |
| failure-current-only | 7–9 |
| pose-flush | 10–12 |
| foreign-valid | 13–15 |
| face-false-lost | 16–18 |
| phase-materialize | 19–21 |
| tail-precopy | 22–24 |

| placement_definition控制 | 原log行 |
|---|---|
| header-domain | 1–3 |
| header-region | 4–6 |
| header-tail | 7–9 |
| header-id | 10–12 |
| header-domain-bound | 13–15 |
| header-component-bound | 16–18 |
| header-hole-bound | 19–21 |
| header-vertex-bound | 22–24 |
| header-schema | 25–27 |
| header-atomic | 28–30 |
| header-edge-kind | 31–33 |
| header-binding | 34–36 |

### Native32封存方式

用原native receipt作SHA/命令/環境接線，額外label按明確9個檔案收原log＋對應 `.unittest.log`＋`.json`；亦可收 native 的上述4個step原檔作自足上下文，不必整包 `run_all-logs`。例如只列input候選，不在本檔執行publisher：

```text
--receipt /tmp/g261r3/seven-final/native/receipt.json
--input native-receipt.json=/tmp/g261r3/seven-final/native/receipt.json
--input definition-controls.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_definition_sources.log
--input definition-unittest.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_definition_sources.unittest.log
--input definition-summary.json=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_definition_sources.json
--input host-controls.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_host_facts_authority.log
--input host-unittest.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_host_facts_authority.unittest.log
--input host-summary.json=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_host_facts_authority.json
--input placement-controls.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_placement_definition.log
--input placement-unittest.log=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_placement_definition.unittest.log
--input placement-summary.json=/tmp/g261r3/seven-final/native/run_all-logs/py_test_geo261_placement_definition.json
```

其餘6個小原檔hash：definition `.unittest.log`=`0fc778393741a3ed06c83ec3f70cce13495fa672ea685a2a813b27a98f20d858`、`.json`=`5531fb436658ef29b9401f069ab89d58f4a899ed1bd938b7878c70278929e1b3`；host `.unittest.log`=`1e44dafa4151f514185ddff8eac3bc203f61961a1ca3b2fc3b2e33396be6383b`、`.json`=`a55afc775046cc37f362b65b87ee629658b28f129bc5a44e28aee8427e5e9ec2`；placement `.unittest.log`=`89cd5b54cd21c7efd312d0daf93912dfb8b17a6b1d7a4aad7bfc0b026c96a1f2`、`.json`=`b26966b5335440710380b67f5710df8ca721ef1ad9aa1e338dbb58b427bc7539`。

原JSONL中的 `/tmp/g261r3/tmp/seven-final/native/geometry-tests/geo261-n1a-*` 是當時binary argv，不要求把這些ELF或編譯暫存source-tree封存，也不要重建同路徑冒充原物。既有native正式raw封存若已含9檔，可用新的小label補可讀索引與原bytes連結，不讀大tar來重跑／重取控制。

## 本次讀取的工具／說明hash

- `record_placement_header_equivalence.py`（15220bytes）：`609e9426665adb4ec6617d66d0229000fb1b0fd819aab15df84c33349d52816c`
- `placement_header_equivalence.c`（15372bytes）：`98c1d348be49e00be980035a5a3b0c22d53be47b1ecb11fa505ec873ad050594`
- `final-f-extra-execution-map.md`（13261bytes）：`00e9cc77aac02263421c1665bc5e2483d1a9330699b24f82bdfd4698843a732b`。內容固定F1/r2，不可原字面當成F2CLI。
- `placement-header-independent-preparation/README.md`（3573bytes）：`c390fd314a949d74a5579c687a12134b5a9241b74de6a42903099d784b409d5d`。它是舊永久回歸設計準備文字，並非F2 parser runtime收據，不以其歷史「未執行」描述改寫新結果。
