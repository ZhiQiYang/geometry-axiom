#!/usr/bin/env python3
"""只按F2已列白名單準備publisher argv與inventory；不執行Git／產品／publisher。"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shlex
import sys
import tarfile

BASE=Path(__file__).resolve().parent
PY='/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3'
PUBLISHER='/workspace/geo261-environment/publish_progress.py'
F2='8f76f2b7d6f669670e5834310bfc26495b4a4aa6'

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--phase',required=True)
 p.add_argument('--out',required=True,type=Path)
 p.add_argument('--result',required=True)
 p.add_argument('--next',required=True)
 p.add_argument('--preview-archive',action='store_true',help='可選：準備白名單preview.gz以估大小，不發佈')
 a=p.parse_args()
 plan_path=BASE/'EXECUTION_PLAN.json'
 plan=json.loads(plan_path.read_text())
 if plan['sha']!=F2:raise ValueError('此候選只接受明列F2計畫')
 matches=[r for r in plan['phases'] if r['id']==a.phase]
 if len(matches)!=1:raise ValueError('未知或不唯一phase')
 phase=matches[0]
 if phase['mode']=='already-published-archive-index':raise ValueError('native32已正常公開，依計畫不用重推重複label')
 out=a.out.resolve()
 if not out.is_relative_to(Path('/tmp')) or out.exists():raise ValueError('out須是全新/tmp路徑；不覆舊selection')
 # 此處只產metadata；caller先核inner真結果，--result不由工具預填通過。
 out.mkdir(parents=True)
 selected=[];missing=[];skipped=[];aliases=set()
 def add(alias,path):
  path=Path(path)
  if path.is_symlink():skipped.append({'path':str(path),'reason':'symlink not archived'});return
  if not path.is_file():missing.append({'alias':alias,'path':str(path)});return
  parts=Path(alias).parts
  if any(x in ('.git','__pycache__','geometry-runtime') or x.startswith(('geometry-cdp-','geometry-documents-chrome-','com.google.Chrome.','profile-')) or x in ('profile','chrome-profile','node-compile-cache') for x in parts):
   skipped.append({'path':str(path),'alias':alias,'reason':'publisher original exclusions'});return
  if not parts or '..' in parts or Path(alias).is_absolute():raise ValueError('非法archive alias')
  with path.open('rb') as stream:magic=stream.read(4)
  if magic==b'\x7fELF':
   skipped.append({'path':str(path),'alias':alias,'reason':'ELF excluded; original raw streams/receipts remain','bytes':path.stat().st_size,'sha256':digest(path)});return
  if alias in aliases:raise ValueError('duplicate archive alias: '+alias)
  aliases.add(alias)
  selected.append({'alias':alias,'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)})
 for selector in phase['publication_selectors']:
  kind=selector['kind']
  if kind=='file':add(selector['alias'],selector['path'])
  elif kind=='directory':
   root=Path(selector['path'])
   if not root.is_dir():missing.append({'alias':selector['alias'],'path':str(root),'kind':'directory'});continue
   for path in sorted(root.rglob('*')):
    if path.is_file() or path.is_symlink():add(str(Path(selector['alias'])/path.relative_to(root)),path)
  elif kind=='glob-files':
   root=Path(selector['root']);paths=sorted(root.glob(selector['pattern'])) if root.is_dir() else []
   if not paths:missing.append({'root':str(root),'pattern':selector['pattern'],'kind':'glob-files'});continue
   for path in paths:
    if path.is_file():add(str(Path(selector['alias'])/path.relative_to(root)),path)
  else:raise ValueError('未知selector kind')
 # 包含具體原binary的排除metadata，但不遞迴讀source clone或native build tree。
 excluded=[]
 import glob
 for pattern in phase['excluded_file_patterns']:
  for name in sorted(glob.glob(pattern)):
   path=Path(name)
   if path.is_file() and not path.is_symlink():excluded.append({'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path),'reason':'declared ELF/binary exclusion'})
 omitted=[{'path':q,'exists':Path(q).exists(),'recursiveContentRead':False} for q in phase['omitted_trees']]
 receipt=Path(phase['inner_receipt'])
 argv=[PY,'-B',PUBLISHER,'--sha',F2,'--label',phase['label'],'--result',a.result,'--next',a.next]
 if receipt.is_file():argv.extend(['--receipt',str(receipt)])
 else:missing.append({'path':str(receipt),'reason':'inner receipt absent; keep failure raw, do not invent receipt'})
 for item in selected:argv.extend(['--input',item['alias']+'='+item['path']])
 index={'schema':'geo261-F2-extra-publication-selection/1','preparedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase['id'],'label':phase['label'],'sha':F2,'planSha256':digest(plan_path),'commandExecuted':False,'productGitPublisherExecuted':False,'callerSuppliedResult':a.result,'callerSuppliedNext':a.next,'selected':selected,'missingOrNotApplicable':missing,'skipped':skipped,'excludedFiles':excluded,'omittedTrees':omitted,'rawBytes':sum(x['bytes'] for x in selected),'publisherArgv':argv,'note':'missing includes expected alternatives such as samples/result; judge actual phase outcome from original receipt, not this selection. No test result is inferred here.'}
 if a.preview_archive:
  preview=out/'preview.raw.tar.gz'
  with tarfile.open(preview,'w:gz',compresslevel=6,format=tarfile.PAX_FORMAT) as tar:
   for item in selected:tar.add(item['path'],arcname=item['alias'],recursive=False)
  index['previewArchive']={'path':str(preview),'bytes':preview.stat().st_size,'sha256':digest(preview),'notPublished':True}
 (out/'publication-selection.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
 # inventory自身也入原archive，使ELF排除與missing範圍可核；不複製source或改任何原檔。
 argv.extend(['--input','publication-selection.json='+str(out/'publication-selection.json')])
 (out/'publisher-argv.json').write_text(json.dumps(argv,ensure_ascii=False,indent=2)+'\n')
 (out/'publisher.sh').write_text('#!/bin/sh\n# 準備稿：以下一行會真的commit/push；本工具沒有執行它。\n'+shlex.join(argv)+'\n')
 print(json.dumps({'phase':phase['id'],'selection':str(out/'publication-selection.json'),'publisherCommand':str(out/'publisher.sh'),'files':len(selected),'missingOrNotApplicable':len(missing),'executed':False},ensure_ascii=False))
 return 0
if __name__=='__main__':raise SystemExit(main())
