# Cperf attempt1：ENOSPC環境失敗封存與原工具重試

只準備，未執行Git、publisher、產品、compile、benchmark或retry，未讀取/散列source clone。本包所有原raw逐bytes封存，沒有修中斷JSON。

真實結果：outer有效收據為F2、原rc1；原stderr有 `[Errno 28] No space left on device`。inner receipt原28,672 bytes且JSON截斷，bootstrap-failure.json原0 bytes。最後完整落盤子命令是git clone --no-checkout真rc0；不能因此斷言尚未checkout，root已觀察source clone有產品/evidence entries，checkout可能已開始或完成。沒有可用compile/perf原執行證據，沒有性能量測結果；本次是環境失敗，不算產品或性能紅。

`attempt1-selected-raw.tar.gz` 是已實際預壓縮並逐member驗bytes/SHA256的完整選取包，實際大小見SUMMARY，低於90,000,000 bytes。收進原scratch除source-counterfactual/tmp以外所有原檔（含subcommands完整原stdin/stdout/stderr、所有中斷JSON、formal來源與tools-frozen）、完整outer、原frozen工具bundle。兩個排除樹從os.walk的第一層就剪除，不進入clone/.git、不散列產品source。

同包補保空間復原原證據：coldmove wrapper、實際原mover、stdout/stderr、完成report與兩份完整manifest；只核既存manifest自身hash，不重新散列forensic clone。原attempt完整冷存於 `/workspace/geo261-cold/g261F2perf`，原 `/tmp/g261F2perf` 是保留原bytes/path的symlink。另收新增reader/checker釋放的兩完整record dirs、其外層stdout/stderr及tracking-refresh-before-reader-checker完整dir；不重收之前首兩個release紀錄。

root可先正常publish環境失敗（本準備未執行）：

```bash
sh /workspace/geo261-environment/F2-Cperf-environment-failure-publication/publisher.sh
```

label固定 `F2-Cperf-environment-attempt1`；`--receipt` 指向原有效outer，沒有拿中斷inner冒作有效收據。發布單一已壓縮raw包加本metadata，仍保留完整395個原檔而不依賴日後原scratch清理。

正常publish完成且空間可用後，root自行執行：

```bash
sh /workspace/geo261-environment/F2-Cperf-environment-failure-publication/retry.sh
```

retry exact argv由原EXECUTION_PLAN與實際outer.argv核對產生，只換兩個值：scratch `/tmp/g261F2perf-retry1`、outer label `F2-Cperf-retry1`；同F2、同工具、同原參數、formal baseline、heavy lock及判準不變。新scratch/outer label必全新；原argv與逐項literal差分在COMMANDS.json。此處不執行重試、不新增產品gate、不改任何原工具／收據。
