# P3／F2 累積C性能自證工具：本次實際來源綁定覆核

審查者 `/root/node_hash_audit`，實際核對新P3 `55b9fb6479485361d9e2283a95e4355f5fca76db` 與預定F2 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。**本次P3綁定已完成獨立純讀核對，未發現來源阻擋；可交既有metadata gate確認。** 這是對這個新包的實際檢查，不是把P2的approved改名，也不是F2編譯、性能自證或完整驗收結果。

完整獨立稽核在 `P3-binding-review-execution-r2/`：AUDIT.json SHA256 `5a16fefe0d2a1c3f4de6ee92c801ccee3404161711bd5f687e47e25ca71045d0`，103247個實際metadata／來源核對點、issues=[]，腳本真退出0，16條本次Git唯讀命令皆0；每條argv、cwd、時間、真exit與完整stdout／stderr在commands。沒有執行產品、native、scanner、Chrome、服務、compile、測試或benchmark，沒有修改root repo。這次不連網；公開性使用原ls-remote的完整raw與本次真Git祖先關係核對，不能稱本次又查了遠端新留言。

## 新P3差異逐項實證

1. 另讀P2／F1／P3／F2四個固定Git tree，將原四份archive內 **4×601＝2404個來源raw** 各自重算Git blob OID及SHA256，再與本次讀到的固定Git object比對。沒有只接受準備器填好的SHA欄。601實際可執行inventory＝333owned＋268excluded，pathset、casefold唯一性、普通Git mode／kind全一致；manifest raw仍 `0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6`，920政策未改。
2. P2 `8a80abc1402b0c4c394969025c93a6019b4bb91d`→F1 `fe863b0374eafd9f1e57ec5107e28a1101804b56`：完整601 raw全同。F1→P3：owned333與完整601都只有 **geometry-web/runtime_version.py** 改變。P3→F2：完整601 raw全同，F2直接parent為P3，提交只改架構report／receipt。這沒有把runtime排除或把333縮成subset。
3. P3實際單親 `425cabd628257db3d3f97f7ca03cd7a9e7e8498c`，相對parent只改runtime；其exact binary diff SHA256 `64da8341969b4580f483e5a0310f511a20454a7d435dc29cd3032e37ce5fae0d`，與policy、evidence、原subcommand14及bundle patch逐bytes相符。F1→P3的其他路徑只有evidence，沒有隱藏產品差異。
4. F1／P3／F2完整 **15851個tests路徑／mode／blob** 全同；兩SSOT（公理層與決策佇列）有完整原raw且綁真Git blob，raw與mode未變。P73 app.js、canonical HTML、兩個新public headers亦保持原P2值。P3架構LF closure `303ee650da50d92a0397a5556bdf5b94c3066c941f1e5f850a79ea83638493dd` 已從601 raw獨立重算，完全等F2架構receipt的inputs、inputClosureSha256及sourceBaseHead=P3。
5. 六個實際C實作hash仍等設計expected_F_raw_sha256；六份撤回模板逐bytes等前一已審P2包與request，兩public headers保持新API。F2撤回只替換這六個C實作，runtime的P3/P52修正保持，不能把這次稱為runtime修正個別必要性的反證。

## 既有原始證據與工具完整性

原來源準備有 **44條Git命令，全為真exit0、timeout=false**，000001..000044目錄完整；SOURCE_CHECK_COMMANDS、subcommands.json、receipt.commands與bundle副本四份表示相等。各request/result與stdin/stdout/stderr的220個檔案raw hash／長度已核，journal SHA256 `8fe00231f70e8f02b765d867d208bcbdbf8e87dc247655a7a2ba7c2d70ae3c61`。輔助純讀觀察JSON完整保存在本次audit目錄，原SHA256 `dcfb810c7faab8dcfe2e6ed6e3c380c8592e516c5c02b1e553b7807b663b96e9`；這是本次既有check的分工，不是新增approval流程。

`previous-P2-bundle/` exact34檔／8,223,820bytes（原32加P2兩份review）與原inventory完全相等；原P2 review與approved沒有被改寫。原pending新包59項SHA256SUMS逐檔核對，清單本身仍是 `052f96e6c0d2b2371df8ec43bf20edb3f41e9188e009836180b93911c335d4c5`。新review只新增本MD／JSON，原59檔及全部歷史bytes保留，原P3_REVIEW_REQUEST與PREPARATION的pending狀態仍作準備歷史，不改成假執行。

新design只有design_source_sha、owned runtime單項、previous_design_source_sha、rebind evidence／policy hashes及status六個綁定欄位有差；所有C設計、performance_groups、old algorithm來源、patch、guard與threshold欄位保持。`run.py` 相對P2只把一處錯誤文字「不能用設計P2冒充」換成P3；既有rebind_gate只把本次schema／P2綁定欄與檔名機械重定為P3。capture.py、validate.py原bytes完全不變，沒有新增gate。

原N64三側各三筆、原timing交錯／2×判準、真exit／load_ok／175dump前置與逐byte比較、編譯／EOF／timeout不可當性能紅、333owned exact gate、源test／SSOT／新API／canonical守衛、withdrawn後精確恢復及cleanup均未改。原F1公開receipt真0與raw archive身份已再對固定公開Git object，withdrawn/main約2.4676、restored/main約1.7712仍只標F1歷史；**沒有F2性能結果**。

## 來源核對的錯誤假設也保留

最初純metadata audit把tar materialization權限誤要求等Git mode 100644；原git archive實際是0664，該次腳本exit1／完整stderr與原腳本仍在source-rebind。這不是產品紅或來源變更。修正的是稽核器對archive權限的錯誤假設：Git原mode已從真tree精確核對，tar另核普通檔與executable bit；raw OID／SHA256／601 mode一致性全部保留。最後完整r2 audit真exit0，未改任何來源、模板、原收據或產品斷言，沒有把首輪stderr刪除或重標綠。

## 本次review綁定與使用範圍

本次request的design SHA256 `49ee1caa85506b6df2f26937a0efdd425eb3177c2f8b8e5304907ed78f410efc`，rebind evidence `1009b6938d76582c488de3fa3ecd5ac6540229e7f2b7c08898690a1b6875b780`，policy `b73f6589f72fb5608d7b6e25138f2852edc9208231425a7d7388e22543373544`；四份工具與六模板的完整hash在新P3_BINDING_REVIEW.json，不借舊P2 approval替代。

既有gate只讀metadata的實際命令、exit與原streams在本次audit的GATE_EXECUTION.json及gate.stdout／gate.stderr；沒有呼叫run.py或validate的runtime入口。仍須由root在公開乾淨F2、exact333等P3且正式F2四點P189原收據通過後，依原工具真正執行N64累積撤回／恢復，才能宣稱F2性能自證。本review不新增門檻、不聲稱各等價微優化個別必要，也不替代F2全清單。
