"""P2 新來源綁定必須另經獨立靜態審查；不能沿用原 P 的 READY。"""
import hashlib,json
from pathlib import Path
def _hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _require(value,message):
 if not value:raise RuntimeError(message)
def verify_rebind_review(directory,design):
 directory=Path(directory)
 _require(not (directory/'NOT_READY.json').exists(),'準備未完成或來源保護失敗；不得執行')
 _require(design.get('rebind_review_required') is True,'缺少新 P2 綁定審查要求')
 approval_path=directory/'P2_BINDING_REVIEW.json'
 _require(approval_path.is_file(),'新 P2 綁定尚未獨立審查；不得執行 F 反事實量測')
 approval=json.loads(approval_path.read_text())
 _require(approval.get('schema')=='geo261-P2-binding-static-review/1' and
  approval.get('status')=='approved-for-future-F-runtime' and
  approval.get('actual_independent_P2_binding_review_completed') is True,'新 P2 審查未核准')
 _require(approval.get('design_source_sha')==design['design_source_sha'],'審查綁錯 P2')
 _require(approval.get('design_sha256')==_hash(directory/'counterfactual-design.json'),'設計在審查後改變')
 _require(approval.get('rebind_evidence_sha256')==design['rebind_evidence_sha256']==_hash(directory/'REBIND_EVIDENCE.json'),'重綁證據在審查後改變')
 evidence=json.loads((directory/'REBIND_EVIDENCE.json').read_text())
 _require(evidence.get('P2')==design['design_source_sha'],'重綁證據綁錯 P2')
 _require(evidence.get('source_check_command_journal_sha256')==_hash(directory/'SOURCE_CHECK_COMMANDS.json'),'來源檢查 journal 已遺失或改變')
 _require(all(_hash(directory/'PREPARER_SOURCE'/name)==value for name,value in evidence['preparer_source_sha256'].items()),'重綁工具／政策原始快照已遺失或改變')
 _require(approval.get('rebind_policy_sha256')==design['rebind_policy_sha256']==_hash(directory/'rebind-policy.json'),'唯一允許差分政策已變')
 code={name:_hash(directory/name) for name in ('run.py','capture.py','validate.py','rebind_gate.py')}
 _require(approval.get('tool_source_sha256')==code,'審查未綁實際四份工具來源')
 templates={item['path']:_hash(directory/'counterfactual-templates'/item['path']) for item in design['changed_implementations']}
 _require(approval.get('counterfactual_template_sha256')==templates,'審查未綁實際六份撤回模板')
 _require(all(templates[item['path']]==item['counterfactual_raw_sha256'] for item in design['changed_implementations']),'撤回模板偏離設計')
 reviewer=approval.get('reviewer');_require(isinstance(reviewer,str) and bool(reviewer.strip()),'缺少獨立審查者')
 review=directory/'P2_BINDING_REVIEW.md'
 _require(review.is_file() and approval.get('review_markdown_sha256')==_hash(review),'缺少該次新 P2 的實際審查原文')
