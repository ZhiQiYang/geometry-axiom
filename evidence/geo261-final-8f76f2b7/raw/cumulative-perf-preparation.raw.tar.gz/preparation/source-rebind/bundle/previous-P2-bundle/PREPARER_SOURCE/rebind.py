#!/usr/bin/env python3
"""只讀真正已公開 P2，產生另待獨立審查的新反事實工具包；不建置或量測。"""
import argparse,ast,difflib,io,json,os,re,shutil,subprocess,sys,tarfile,traceback
from pathlib import Path
from rebind_capture import Recorder,digest,dump,filehash
HERE=Path(__file__).resolve().parent
SUFFIXES={'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}
if sys.flags.optimize:raise SystemExit('拒絕最佳化 Python；重綁 guard 必須生效')
def require(value,message):
 if not value:raise RuntimeError(message)
def check_original(directory,policy):
 require(filehash(directory/'SHA256SUMS')==policy['original_ready_manifest_sha256'],'原 READY manifest 已變；不得套用重綁')
 rows={}
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  value,name=line.split('  ',1);relative=Path(name)
  require(re.fullmatch('[0-9a-f]{64}',value) and not relative.is_absolute() and '..' not in relative.parts,'不安全 manifest path')
  require(name not in rows,'重複 manifest path');rows[name]=value
 require({str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}==set(rows)|{'SHA256SUMS'},'原 READY 檔案集合已變')
 for name,wanted in rows.items():
  path=directory/name;require(not path.is_symlink() and filehash(path)==wanted,'原 READY bytes 已變：'+name)
 require(filehash(directory/'counterfactual-design.json')==policy['original_design_json_sha256'],'原 design 已變')
 return {**rows,'SHA256SUMS':filehash(directory/'SHA256SUMS')}
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','scratch'):ap.add_argument('--'+name,type=Path,required=True)
 ap.add_argument('--p2-sha',required=True)
 ap.add_argument('--original-tools',type=Path,default=Path('/workspace/geo261-environment/final-f-p189-counterfactual-tools'))
 ap.add_argument('--published-repo',type=Path,default=Path('/workspace/geometry-axiom'))
 a=ap.parse_args();repo=a.repo.resolve();out=a.scratch.resolve();original=a.original_tools.resolve();published=a.published_repo.resolve()
 require(bool(re.fullmatch('[0-9a-f]{40}',a.p2_sha)),'P2 必須是完整 SHA')
 require(out.is_relative_to(Path('/tmp')) and not out.exists() and not out.is_relative_to(repo) and not out.is_relative_to(original),'scratch 必須是 repo／原包以外的新 /tmp 目錄')
 out.mkdir(parents=True);env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','PYTHONOPTIMIZE','GIT_CURL_VERBOSE') and not k.startswith('GIT_TRACE')}
 rec=Recorder(out,env,a.p2_sha)
 report={'schema':'geo261-P2-counterfactual-rebind/1','status':'執行中','P2':a.p2_sha,'acceptance_execution':False,
  'product_build_or_execution':False,'bundle_ready_for_F_runtime':False,'errors':[]}
 bundle=out/'bundle';source_before=None;original_hashes=None;preparer_raw=None
 def verify_preparer():
  if preparer_raw is not None:
   require(all((HERE/name).read_bytes()==raw for name,raw in preparer_raw.items()),'準備工具／政策／gate／README於重綁期間改變')
 def git(*args,sha=None,where=repo,check=True):return rec.run(['git','-C',str(where),*args],cwd=HERE,check=check,source_sha=sha or a.p2_sha)
 def state():return {'head':git('rev-parse','HEAD')[1].decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all')[1].decode()}
 def tree(sha,prefix):
  raw=git('ls-tree','-r','-z',sha,'--',prefix,sha=sha)[1];result={}
  for record in raw.split(b'\0'):
   if not record:continue
   descriptor,path=record.split(b'\t',1);mode,kind,oid=descriptor.decode().split()
   require(mode in ('100644','100755') and kind=='blob','保護集合含非一般檔案')
   result[path.decode()]={'mode':mode,'blob_id':oid}
  return result
 def blobs(sha,paths):
  raw=git('archive','--format=tar',sha,'--',*sorted(paths),sha=sha)[1];result={}
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   for item in archive:
    if item.isdir():continue
    require(item.isfile() and item.name in paths,'archive 來源含非預期檔案')
    result[item.name]=archive.extractfile(item).read()
  require(set(result)==set(paths),'archive 來源集合不全');return result
 try:
  preparer_raw={name:(HERE/name).read_bytes() for name in ('rebind.py','rebind_capture.py','rebind_gate.py.txt','rebind-policy.json','NEW_BUNDLE_README.md.txt')}
  frozen=out/'preparer-source';frozen.mkdir()
  for name,raw in preparer_raw.items():(frozen/name).write_bytes(raw)
  report['preparer_source_sha256']={name:digest(raw) for name,raw in preparer_raw.items()}
  policy=json.loads(preparer_raw['rebind-policy.json']);P=policy['original_design_P'];target=policy['target_owned_path']
  require(a.p2_sha!=P,'P2 尚不存在時不得以原 P 代替')
  original_hashes=check_original(original,policy);design=json.loads((original/'counterfactual-design.json').read_text())
  require(design['design_source_sha']==P and len(design['owned_product_hashes'])==policy['owned_count'],'原設計來源／owned count 不符')
  source_before=state();report['source_before']=source_before
  require(Path(git('rev-parse','--show-toplevel')[1].decode().strip()).resolve()==repo,'repo 必須是 checkout 根目錄')
  require(source_before=={'head':a.p2_sha,'status':''},'必須使用乾淨固定 P2 checkout')
  require(git('rev-parse',a.p2_sha+'^{commit}')[1].decode().strip()==a.p2_sha,'P2 不可解析')
  git('merge-base','--is-ancestor',P,a.p2_sha)
  parents=git('rev-list','--parents','-n','1',a.p2_sha)[1].decode().split()
  require(len(parents)==2 and parents[0]==a.p2_sha,'P2 必須是新的單親提交');parent=parents[1]
  changes=git('diff','--no-renames','--name-only','-z',parent,a.p2_sha)[1].decode().split('\0')
  require([p for p in changes if p]==policy['required_P2_parent_diff_paths'],'P2 相對其 parent 必須僅改指定 canonical HTML')
  report['P2_parent']=parent
  # 不複製 remote URL 原文；保留 hash，避免認證值進證據。遠端 refs 全 raw 另錄。
  remote=subprocess.run(['git','-C',str(published),'remote','get-url','origin'],capture_output=True,env=env)
  report['remote_url_check']={'command':['git','-C',str(published),'remote','get-url','origin'],'cwd':str(HERE),'actual_process_returncode':remote.returncode,
   'stdout_sha256':digest(remote.stdout),'stderr_sha256':digest(remote.stderr),'raw_url_suppressed_to_protect_injected_credentials':True}
  dump(out/'remote-url-check.json',report['remote_url_check'])
  require(remote.returncode==0 and remote.stdout.decode().strip().startswith(('https://','http://','ssh://','git@')),'published-repo 不是可讀網路 remote')
  refs=git('ls-remote','--refs','origin',where=published)[1].decode().splitlines();public=None
  for line in refs:
   oid,name=line.split(None,1)
   if oid==a.p2_sha:public={'ref':name,'tip':oid,'relationship':'exact'};break
   result=git('merge-base','--is-ancestor',a.p2_sha,oid,where=published,check=False)[0]
   if result['actual_process_returncode']==0:public={'ref':name,'tip':oid,'relationship':'ancestor'};break
  require(public is not None,'P2 尚不能由網路遠端 ref 解析');report['published_P2']=public
  wanted=design['owned_product_hashes'];paths=set(wanted)
  all_paths=None;input_modes={}
  for sha in (P,parent,a.p2_sha):
   manifest_bytes=git('show',sha+':geometry-core/domain-decoupling/product-architecture.json',sha=sha)[1];manifest=json.loads(manifest_bytes)
   require({item['path'] for item in manifest['sources']}==paths and len(manifest['sources'])==policy['owned_count'],'owned inventory 已變')
   if sha!=P:require(digest(manifest_bytes)==policy['required_P2_and_parent_manifest_sha256'],'P2／parent 不符已核 A manifest；不得帶政策改動')
   declared=[item['path'] for item in manifest['sources']+manifest['exclusions']]
   require(len(declared)==len(set(declared))==policy['all_architecture_inputs'] and len(manifest['exclusions'])==policy['excluded_count'],'完整 inputs inventory 已變')
   if all_paths is None:all_paths=set(declared)
   require(set(declared)==all_paths,'完整 inputs 路徑集合已變')
   inventory=set();input_modes[sha]={}
   raw=git('ls-tree','-r','-z',sha,sha=sha)[1]
   for record in raw.split(b'\0'):
    if not record:continue
    descriptor,name=record.split(b'\t',1);path=name.decode()
    if not (path in manifest['sourceFiles'] or any(path.startswith(root+'/') for root in manifest['sourceRoots'])):continue
    if Path(path).suffix.lower() not in SUFFIXES:continue
    mode,kind,oid=descriptor.decode().split();require(mode in ('100644','100755') and kind=='blob','完整 inputs 含非一般 source')
    inventory.add(path);input_modes[sha][path]=mode
   require(inventory==all_paths and len({path.casefold() for path in inventory})==len(inventory),'真 Git executable inventory 不等於完整601 inputs')
  require(input_modes[P]==input_modes[parent]==input_modes[a.p2_sha],'601 inputs 的 Git mode 不得改變，含 canonical HTML')
  old_all=blobs(P,all_paths);previous_all=blobs(parent,all_paths);actual_all=blobs(a.p2_sha,all_paths)
  require(previous_all==old_all,'P2 parent 的完整601來源偏離原 P')
  require(sorted(path for path in all_paths if old_all[path]!=actual_all[path])==[target],'完整601來源只能有指定HTML一項差分')
  old={path:old_all[path] for path in paths};actual={path:actual_all[path] for path in paths}
  old_hashes={path:digest(value) for path,value in old.items()};actual_hashes={path:digest(value) for path,value in actual.items()}
  require(old_hashes==wanted,'原 P 真 Git blobs 不符原 READY 設計')
  changed=sorted(path for path in paths if old[path]!=actual[path]);require(changed==[target],'333 owned 只能有指定 HTML 一項差分')
  before=old[target];old_trace=policy['old_unique_full_trace_utf8'].encode();new_trace=policy['new_unique_full_trace_utf8'].encode()
  require(digest(before)==policy['original_HTML_sha256'] and before.count(old_trace)==1 and before.count(new_trace)==0,'原 HTML 唯一完整 I11 trace 不符')
  at=before.index(old_trace);start=before.rfind(b'<article',0,at);end=before.find(b'>',start)
  require(start>=0 and re.search(rb'\bid="I11"',before[start:end+1]) is not None,'唯一 trace 不在 I11 article')
  expected=before.replace(old_trace,new_trace,1)
  require(actual[target]==expected and digest(expected)==policy['expected_P2_HTML_sha256'] and len(expected)-len(before)==policy['expected_byte_delta'],'P2 不等於唯一已審 byte 替換')
  expected_patch=git('diff','--binary',parent,a.p2_sha,'--',target)[1];(out/'actual-P2-sync.patch').write_bytes(expected_patch)
  protected={}
  for item in design['changed_implementations']:
   require(actual_hashes[item['path']]==item['expected_F_raw_sha256'],'六實現檔偏離原 P')
   protected[item['path']]=actual_hashes[item['path']]
  for path in design['new_public_headers_kept']+['geometry-web/app.js']:
   require(actual_hashes[path]==wanted[path],'headers／P73 偏離原 P');protected[path]=wanted[path]
  for path in ('公理層.md','決策佇列.md'):
   left=git('show',P+':'+path,sha=P)[1];right=git('show',a.p2_sha+':'+path)[1]
   require(left==right and tree(P,path)==tree(a.p2_sha,path),'SSOT raw／mode 偏離原 P：'+path);protected[path]=digest(right)
  tests_before=tree(P,'tests');tests_after=tree(a.p2_sha,'tests')
  require(bool(tests_before) and set(tests_before)==set(tests_after),'tests tracked path set 已變或意外零匹配')
  test_changes=sorted(path for path in tests_before if tests_before[path]!=tests_after[path])
  allowed=policy['only_allowed_changed_test_artifact_from_P']
  require(set(test_changes)<= {allowed},'測試或 expected JSON 偏離原 P；只准先前衍生 ledger')
  report.update(status='來源重綁已核，尚待新獨立 peer review',source_after=state(),original_design_P=P,
   original_READY_hashes=original_hashes,owned_original_raw_sha256=old_hashes,owned_P2_raw_sha256=actual_hashes,
   all_601_original_raw_sha256={path:digest(value) for path,value in old_all.items()},all_601_P2_raw_sha256={path:digest(value) for path,value in actual_all.items()},
   actual_changed_owned=changed,protected_explicit_raw_sha256=protected,tests_P_blob_ids=tests_before,tests_P2_blob_ids=tests_after,
   tests_changed_from_P=test_changes,tests_difference_kind='only prior generated mutation ledger allowed; all tracked test modes and content identifiers otherwise identical',input_modes=input_modes,
   exact_HTML_byte_delta=len(expected)-len(before),actual_HTML_patch_sha256=digest(expected_patch),rebind_policy_sha256=digest(preparer_raw['rebind-policy.json']))
  require(report['source_after']==source_before,'讀取期間原 checkout 有變')
  require(check_original(original,policy)==original_hashes,'重綁期間原 READY 包有變')
  verify_preparer()
  shutil.copy2(out/'subcommands.json',out/'SOURCE_CHECK_COMMANDS.json')
  report['source_check_command_journal_sha256']=filehash(out/'SOURCE_CHECK_COMMANDS.json');dump(out/'REBIND_EVIDENCE.json',report)
  # 原 READY 包保留原地；新包保留歷史稿但以新 P2 binding 與 gate 為準。
  # 從第一個 byte 起就沒有可執行舊入口；copytree 明確略過 root run.py。
  bundle.mkdir()
  dump(bundle/'NOT_READY.json',{'status':'incomplete P2 preparation; do not execute','F_runtime_ready':False})
  def ignore_root_run(directory,names):return {'run.py'} if Path(directory).resolve()==original and 'run.py' in names else set()
  shutil.copytree(original,bundle,dirs_exist_ok=True,ignore=ignore_root_run)
  shutil.copy2(original/'run.py',bundle/'run.py.pending')
  history=bundle/'original-P';history.mkdir()
  for name in ('README.md','PREPARATION.json','PEER_REVIEW.md','counterfactual-design.json','SHA256SUMS'):
   (bundle/name).replace(history/name)
  shutil.copy2(out/'REBIND_EVIDENCE.json',bundle/'REBIND_EVIDENCE.json');(bundle/'rebind-policy.json').write_bytes(preparer_raw['rebind-policy.json'])
  shutil.copy2(out/'SOURCE_CHECK_COMMANDS.json',bundle/'SOURCE_CHECK_COMMANDS.json')
  shutil.copytree(frozen,bundle/'PREPARER_SOURCE')
  (bundle/'rebind_gate.py').write_bytes(preparer_raw['rebind_gate.py.txt'])
  run=bundle/'run.py';old_run=(bundle/'run.py.pending').read_text();text=old_run;anchor='from validate import MAIN,BASE,formal,samples\n'
  require(text.count(anchor)==1,'run import anchor 不唯一')
  text=text.replace(anchor,anchor+'from rebind_gate import verify_rebind_review\n',1)
  anchor=" design=json.loads((TOOLS/'counterfactual-design.json').read_text());assert a.sha!=design['design_source_sha'],'必須填正式新F，不能用設計P冒充'"
  require(text.count(anchor)==1,'run design anchor 不唯一')
  text=text.replace(anchor," design=json.loads((TOOLS/'counterfactual-design.json').read_text());verify_rebind_review(TOOLS,design)\n assert a.sha!=design['design_source_sha'],'必須填正式新F，不能用設計P2冒充'",1);run.write_text(text)
  (bundle/'run.py.pending').replace(history/'run.py')
  (bundle/'P2_GATE_ADAPTATION.patch').write_text(''.join(difflib.unified_diff(old_run.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='original-P/run.py',tofile='run.py')))
  design.update(design_source_sha=a.p2_sha,owned_product_hashes=actual_hashes,original_design_source_sha=P,
   rebind_review_required=True,rebind_policy_sha256=filehash(bundle/'rebind-policy.json'),rebind_evidence_sha256=filehash(bundle/'REBIND_EVIDENCE.json'),
   status='P2 rebound source prepared; independent new P2 binding review pending; no runtime')
  dump(bundle/'counterfactual-design.json',design)
  code={}
  for name in ('run.py','capture.py','validate.py','rebind_gate.py'):
   ast.parse((bundle/name).read_bytes(),filename=str(bundle/name));code[name]=filehash(bundle/name)
  template_hashes={item['path']:filehash(bundle/'counterfactual-templates'/item['path']) for item in design['changed_implementations']}
  request={'schema':'geo261-P2-binding-static-review/1','status':'pending-independent-review','actual_independent_P2_binding_review_completed':False,
   'design_source_sha':a.p2_sha,'design_sha256':filehash(bundle/'counterfactual-design.json'),
   'rebind_evidence_sha256':design['rebind_evidence_sha256'],'rebind_policy_sha256':design['rebind_policy_sha256'],
   'tool_source_sha256':code,'counterfactual_template_sha256':template_hashes,'reviewer':None,'review_markdown_sha256':None}
  dump(bundle/'P2_REVIEW_REQUEST.json',request)
  dump(bundle/'PREPARATION.json',{'schema':'geo261-P2-rebound-tool-preparation/1','status':'PEER REVIEW PENDING; runtime gate closed',
   'design_source_sha':a.p2_sha,'original_design_source_sha':P,'source_hashes':code,'independent_P2_binding_review_completed':False,
   'product_build_or_execution':False,'performance_verdict':None,'source_rebind_execution_only':True,
   'all_333_future_F_owned_raw_hashes_must_equal_P2':True,'unchanged_six_templates':template_hashes})
  readme=preparer_raw['NEW_BUNDLE_README.md.txt'].decode().replace('{{P2}}',a.p2_sha).replace('{{ORIGINAL_P}}',P)
  (bundle/'README.md').write_text(readme)
  (bundle/'NOT_READY.json').unlink()
  (bundle/'SHA256SUMS').write_text(''.join(filehash(p)+'  '+str(p.relative_to(bundle))+'\n' for p in sorted(bundle.rglob('*')) if p.is_file() and p!=bundle/'SHA256SUMS'))
  report.update(bundle=str(bundle),new_design_sha256=filehash(bundle/'counterfactual-design.json'),new_tool_manifest_sha256=filehash(bundle/'SHA256SUMS'),
   status='重綁準備完成；新 peer review pending；F runtime blocked',exit_code=0)
 except BaseException:
  report.update(status='重綁失敗；不得使用未完成新包',exit_code=1,traceback=traceback.format_exc())
  if bundle.exists():
   if (bundle/'run.py').exists():(bundle/'run.py').replace(bundle/'run.py.failed')
   dump(bundle/'NOT_READY.json',{'status':'failed P2 preparation; do not execute','F_runtime_ready':False})
 finally:
  try:
   if source_before is not None:require(state()==source_before,'原 checkout 前後有變')
   if original_hashes is not None:require(check_original(original,policy)==original_hashes,'原 READY 包前後有變')
   verify_preparer()
  except BaseException:
   report.update(status='來源保護失敗',exit_code=1,source_protection_error=traceback.format_exc())
   if bundle.exists():
    if (bundle/'run.py').exists():(bundle/'run.py').replace(bundle/'run.py.failed')
    dump(bundle/'NOT_READY.json',{'status':'source protection failed; do not execute','F_runtime_ready':False})
  report['commands']=rec.rows;dump(out/'receipt.json',report)
 print(json.dumps({'status':report['status'],'exit_code':report['exit_code'],'receipt':str(out/'receipt.json'),'bundle':str(bundle),
  'P2':a.p2_sha,'F_runtime_ready':False,'product_executed':False},ensure_ascii=False));return report['exit_code']
if __name__=='__main__':raise SystemExit(main())
