# 最終 F 的 P-189 全組性能撤回工具

此工具包目前僅完成來源閱讀、參數化實作與 Python AST 解析，**沒有建置、執行產品、跑 mock 或量測**。設計來源為已推送的 P `b6646d10751a0d85a2f03f5d24fbe1073cb78980`，不是最終 F 的通過收據。最後仍須提供新的完整 F SHA、乾淨來源 checkout 及該 F 已完成且四點全綠的正式 P-189 收據，才能執行。

此額外負控制只比較 N64 的 main／全組撤回／恢復各三輪。正式 F 的原三方 main／base／fix、N16／32／48／64、175 場景 dump 全套仍由原驗收執行；本工具不取代該清單，也不宣稱每個等價性能元件各自必須使裁判變紅。

## 執行方式（命令稿，尚未執行）

```sh
GEO261_REAPER_LOG=/tmp/geo261-final-F-counterfactual-reaper.jsonl \
python3 /workspace/geo261-environment/reap_children.py \
python3 /workspace/geo261-environment/final-f-p189-counterfactual-tools/run.py \
  --repo /tmp/geo261-final-F/source-final \
  --sha <F完整40字元SHA> \
  --scratch /tmp/geo261-final-F-p189-counterfactual \
  --heavy-lock /tmp/geo261-final-F/heavy.lock \
  --formal-receipt /tmp/geo261-final-F/tools/p189-<F8>/receipt.json \
  --formal-tools /tmp/geo261-final-F/tools \
  --published-repo /workspace/geometry-axiom
```

`--repo`、`--sha`、`--scratch`、`--heavy-lock` 與 `--formal-receipt` 都必填。`--formal-receipt` 是 schema `geo261-p189-final/1` 的內層 P-189 收據，不是外層專項 runner 的 receipt。若未提供 `--formal-tools`，以該收據的父目錄的父目錄為工具目錄。scratch 必須全新且位於 `/tmp`；heavy-lock 必須與正式驗收共用且位於既存 `/tmp` 目錄，不得位於新 scratch 內。工具自己取得該鎖，**不能在外層再取得同一把鎖**。reaper 只是外層收尾，不取代鎖。

## 原始來源與精確撤回範圍

工具先核 F checkout 的 HEAD／clean status，從 Git blobs 及實際 checkout 核對 P 的 333 個 owned 產品來源 bytes 完全相同，並核 F manifest 的 owned path set 相同。F 可以另有 ledger、架構四檔、expected census 與 evidence 產物；若產品 bytes 有任何新差異，拒絕使用這組模板，不能自動擴充撤回範圍。網路 `git ls-remote` 必須證明 F 是公開 ref 的 tip 或可證祖先，沒有公開身分便不建置。

只在隔離 clone 的六個實現檔撤除本輪五組純性能省工：

- `current_geometry.c` 與 `reference_sources.inc`：恢復 f2 的 raw facts、full definition consumers 與原計算時點。
- `source.c`：恢復 f2 的原 hash／identity lookup，撤除 word hash 與 256-slot hint；原索引、guard、來源呼叫及必要配置保留。
- `contact_sources.c`：恢復 f2 的 faces `calloc`；其他分配、鍵、容量與策略不變。
- `definition_sources.c` 與 `placement_sources.c`：新小 API 保留，但改成呼叫原 full accessor 後投影欄位的 wrapper。full accessor 的 schema／id／完整 canonical 解析／失敗輸出保留契約不變。

兩個新 public headers、P73 修正、所有 tests、帳本、架構、SSOT 都不撤回。六檔模板、各自原／撤回 hash、原 f2→P 八檔差異與精確撤回 patch 都在本包。新 private decoder helper 可以保留於實現檔，但新 accessor wrapper 不使用它；無跨 consumer cache。這是全組性能反事實，不是公理語意改動。

## 判決與完整原始記錄

先重核正式 F 的 36 筆原 timing TSV、每筆原 loadfile argv／真 rc0／load-ok／stdin／stdout／stderr bytes 與 hash、原 timing 原始秒數對 TSV 的四位小數、四點中位數與原 2 倍判準；並核正式 dump 的 base／fix 原 stdout 相同。正式 timing／generator 工具 bytes 必須等收據 hash。

以原 `gcc -std=c11 -O2 geometry-web/web_bridge.c ... -lm` 建置 withdrawn、恢復 F 與固定 main `adbaebf9c73ea6801d7b4d5214e4b846b132923b`；恢復 F 與 main binary hash 各自必須等正式 F 收據。所有產品建置／loadfile 以 16 MiB stack 執行。任何建置錯誤、signal、timeout、EOF、bad JSON、loadfile 失敗或 dump 不同均是失敗，不能當性能負控制的紅燈。

三側先跑 N64 loadfile＋dump，撤回／恢復必須與正式 F 原 stdout 逐 bytes 相同。再用正式 F 同一個 timing driver bytes、原交錯順序、N64、3 輪與原計時邊界執行。原 timing 子程序 rc0、撤回／main >2，以及恢復／main ≤2 分開記錄；只有全部成立才 `proof_matched=true`／工具退出0。撤回仍綠或恢復紅都照實退出1，不調門檻或重試挑樣。

每個直接子命令保存 argv、cwd、acceptance SHA／來源 SHA／variant、時間、stdin、完整 stdout／stderr、真退出碼、環境白名單與各 raw hash。timeout 保存 exception partial 與 kill／wait 後完整 streams 為不同檔案，不拼接冒稱原輸出。原 timing driver 內部 bridge 每次完整 raw 由其原 sample journal 保存，另外產生 `timing-bridge-provenance.json` 連回每側來源、binary、撤回 patch、共用環境與 F。原 driver 內部 generator 沿原程式執行，成功才繼續；同一次生成內容另外獨立錄製並核原 driver 生成的 scene bytes 相同。沒有更改原 timing 起訖、排序、取樣、TSV 精度或 2 倍判準。

前置只讀 Git 命令也保留完整 raw。唯一安全抑制例外是 `git remote get-url origin` 的 URL 原文：只留真退出碼、傳輸類型與 stdout hash，避免複製環境可能注入的認證值；其後網路 ls-remote 的 refs 全 raw 保存。環境只寫必要非敏感白名單，不複製憑證。

所有更動僅在隔離 clone；內外兩層 finally 還原六檔並核 source hash／clean HEAD。無論成功、錯誤或中斷，都再次核原 repo 完全未變。工具不 commit、不 push、不 merge。本包已完成獨立靜態互審及修正；尚無 runtime 自檢通過聲明，只有取得新 F 與正式 F 收據後才可排程執行。
