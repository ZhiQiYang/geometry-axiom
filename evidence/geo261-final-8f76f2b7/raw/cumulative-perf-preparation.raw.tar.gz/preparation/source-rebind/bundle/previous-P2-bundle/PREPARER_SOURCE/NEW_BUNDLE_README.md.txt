# P2 重綁的 F P-189 反事實工具：獨立審查待完成

設計來源為真正已公開的 P2 `{{P2}}`，原性能設計來源 P `{{ORIGINAL_P}}` 與舊 f2 演算法模板另行保留。此包只完成來源重綁與 AST 解析；沒有建置、執行產品、量測或驗收 F。原 P 的 READY／靜態審查僅存 `original-P/` 作歷史證據，不能當成新 P2 綁定已審。

`REBIND_EVIDENCE.json` 保存公開 P2 身分、601 全來源與 333 owned raw hashes、唯一 I11 完整 trace byte 替換、P2 parent 僅改指定 HTML、tests／SSOT／P73／六實現與兩 header 不變，以及原工具包完整 hash。`SOURCE_CHECK_COMMANDS.json` 是不可變的來源檢查 journal 快照；完整 Git stdin／stdout／stderr raw 位於外層 rebinder scratch `subcommands/`，必須連同外層 `receipt.json` 一起封存，不能只打包本目錄而丟掉原始證據。

所有未來 F 仍須為新的公開乾淨 SHA，333 owned 來源逐 bytes **完全等於本 P2**。正式 F 四點 P-189 收據仍須同 SHA 完整全綠；原 counterfactual 的原 driver、N64 三輪、2× 判準、完整 raw 與錯誤恢復流程均保留。新增 gate 只驗新 P2 綁定獨立審查，沒有放寬任何來源或產品判準。

## 新 P2 審查 gate

`run.py` 本身會呼叫 `rebind_gate.py`；目前缺 `P2_BINDING_REVIEW.json`，所以禁止 F runtime。不得把 `original-P/PEER_REVIEW.md` 改名當成本次審查，也不得把 `P2_REVIEW_REQUEST.json` 的 pending 自動改成 approved。

真正獨立審查者須閱讀此 P2 的全部新來源綁定、精確差異／原始來源證據及當前四份工具來源，再撰寫 `P2_BINDING_REVIEW.md`。審查完成後，以 `P2_REVIEW_REQUEST.json` 的固定 hash 值為基礎另寫 `P2_BINDING_REVIEW.json`；只有如實填入以下欄位才能打開 gate：

- `status`: `approved-for-future-F-runtime`。
- `actual_independent_P2_binding_review_completed`: `true`。
- `reviewer`: 實際獨立審查者。
- `review_markdown_sha256`: 本次新 `P2_BINDING_REVIEW.md` 的精確 hash。

其餘 schema、P2 SHA、design／rebind evidence／policy hash、四份工具與六模板 hash 必須保留並對實際檔案再次核對。審查若要修程式，先重算該 source hash／AST 與 request，重新審查實際新版本，不能沿舊值。核准後另更新 PREPARATION 的真實狀態與完整 SHA256SUMS，保留原 pending metadata／manifest 的歷史副本；這仍只代表工具可執行，不能填入未跑的 F 通過結果。

## 完成新審查後的未執行命令稿

```sh
GEO261_REAPER_LOG=/tmp/<F-round>/counterfactual-reaper.jsonl \
python3 /workspace/geo261-environment/reap_children.py \
python3 -B /path/to/this/bundle/run.py \
  --repo /tmp/<F-round>/source-final --sha <F完整40字元SHA> \
  --scratch /tmp/<F-new-counterfactual-scratch> \
  --heavy-lock /tmp/<F-round>/heavy.lock \
  --formal-receipt /tmp/<F-round>/tools/p189-<F8>/receipt.json \
  --formal-tools /tmp/<F-round>/tools \
  --published-repo /workspace/geometry-axiom
```

工具自己取得共用鎖，勿在外層再鎖同一把。正式收據是 `geo261-p189-final/1` 的內層收據；原 P2 不可冒稱最終 F。獨立來源重綁成功不能外推性能負控制已紅／恢復已綠，亦不證明每個等價性能元件個別必要。
