# F P-189 全組撤回工具：獨立純靜態互審

審查者為 `round2_tool_preparation`，審查範圍是 repo 外 `final-f-p189-counterfactual-tools/`。已閱讀 `run.py`、`capture.py`、`validate.py`、README、design JSON、六實現檔撤回 patch，並對照原 `p189_verify.py`、`scale_compare2.py` 與既有 raw capture 片段。只做文字閱讀與靜態 Git blob／SHA256 核對；沒有 import 或執行待審工具，沒有跑 AST、mock、編譯、產品、Chrome、native、mutation、census 或性能量測，沒有改 root repository。

最終程式靜態未見阻擋，可交主代理封存為待執行工具；這不是 runtime 通過或負控制已轉紅的聲明。審查的三份程式精確 SHA256：

| 程式 | SHA256 |
|---|---|
| `run.py` | `01a2e184bfe9589890394c63187b5b3e3a3868b1253e07d71ee375c2ae62b1a4` |
| `capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| `validate.py` | `f85871fbfa37552a80c40cd1d3f89ba43f8c33f7d02e2773839a120bd8e1d429` |

`counterfactual-design.json` 為 `4760aa3615ea76fa6df7bee7e2502afc43704690485eb272d54e0ad96cada451`，撤回 patch 為 `f2e20b2763ef4b5d95bac1d41f3eacab889d0b63f5b685bc2e86241caeaf149e`。工具作者會另做最終 AST／PREPARATION／SHA256SUMS 更新；舊 metadata 中的舊程式 hash 不可用作這份版本的封存身分。

## 同源與撤回範圍

runtime 必須明填新完整 F，且拒絕把設計 P `b6646d10751a0d85a2f03f5d24fbe1073cb78980` 當 F。正式來源 checkout 必須正確 top-level、HEAD 等 F 且乾淨；網路 remote refs 須證明 F 可解析為 ref tip 或其祖先。clone 的 manifest owned path set、Git blobs 與實際 checkout bytes 都要符合設計 P 的 333 owned 來源。這是明確的模板適用條件，若後續產品另改，不能沿用模板。

六實現檔撤五組純性能工作，兩個新 public headers、P73、tests 及其他產品來源保持 F；變異檔名必須恰為六項。`current_geometry.c`、`reference_sources.inc`、`source.c`、`contact_sources.c` 的完整撤回模板 raw hashes，已用唯讀 `git show f2c8837a...:<path> | sha256sum` 核對與原 f2 blobs 一致。兩個新 accessor 改成原 full accessor 再投影欄位的 wrapper，未刪新 API、未加入 consumer cache，保留原 canonical schema／id／完整格式／失敗輸出／dependency 請求契約。未見這份 patch 擴大到公理語意或未列產品範圍。

## 原裁判與原始證據

正式 F 必須先有 schema `geo261-p189-final/1` 的 main／base／fix 收據，四個 N 各三輪、36 個原樣本均依原交錯順序、真 rc0、非 timeout、load_ok 真。每筆必備 stdin／stdout／stderr 原檔及 bytes／hash；原未捨入 seconds 必須對應 TSV 的 `%.4f`，中位數仍從原 TSV 計算，四點 fix/main 仍逐點 ≤2。

正式 timing 的唯一原子命令會對回原 WORK／OUT／三側 argv／ns／reps／generator、cwd、真 rc0 與完整 stdout／stderr；36 個子 bridge 的完整 argv、side、scene、cwd、stdin bytes 都會對回該命令。正式 dump 場景清單從固定 BASE 根 `.scene` 加四個原生成場景取得，保留原順序、拒絕重複與缺漏，不手寫或猜測 175；base／fix 原 stdout 逐位元組相同並核正式 hash。

額外撤回自證僅 N64 的 main／withdrawn／restored 各三輪。它沿同一正式 timing driver bytes 與原計時起訖、交錯順序、取樣數、TSV 精度；實測 bridge 副本、generator／timing 副本都前後核原 hash，恢復 F／main binary 分別須等正式收據的 fix／main binary。撤回／恢復 N64 loadfile＋dump 必須等正式 F 的原 stdout bytes。只有 withdrawn/main >2 且 restored/main ≤2 才自證吻合；compile error、timeout、signal、EOF、bad JSON、load 失敗或 dump 差異皆是失敗，不會被當性能負控制紅燈。

直接產品命令把 acceptance F 與實際 main／F source SHA、variant 分欄；撤回另有精確 patch hash。Recorder 保存真退出碼、stdin、完整原 stdout／stderr、必要環境與時間；timeout partial 和 kill/wait 後完整 streams 分檔，不拼接冒稱。原 timing 內部 bridge raw 另由原 journal 保留並建立 provenance。

## 錯誤與還原

只有共享排他鎖內可建置及執行產品。原 repo 不寫入，產品變異只在隔離 clone；內層 finally 在 partial write／build 錯誤後仍還原，外層 finally 再核原六檔與全部 owned hashes、clone clean HEAD、原 repo 前後一致。counterfactual 建置錯後仍會嘗試恢復／main identity；未把建置錯當成性能紅。

前置失敗先核新 scratch 安全範圍，再由 entry 保存 bootstrap failure 與已執行早期 Git 的完整原始輸出；不重用既有 scratch，不對未核安全的路徑補寫。`HEAVY_STARTED` 區分產品是否已開始。對 remote URL 原文的抑制有明確原因與 hash，避免把可能注入認證的 URL 複製進證據；其後遠端 refs 原輸出完整保留。

## 本輪找到並已修的缺口

1. 正式 36 raw 起初只核數量／順序／hash，未核 argv／side／scene／cwd／stdin；已補唯一原 timing capture 與逐筆精確對照。
2. sample files 起初可缺 stdin／stderr；已要求三份必備 streams。
3. 實測 bridge、timing／generator 副本起初只由 copy 推論身分；已補前後 hash。
4. out 建立前的正式收據／前置 guard 失敗會遺失暫存 EARLY_GIT 原輸出；已補安全 bootstrap flush。
5. 正式 dump 起初只要求非空、count 自洽及含 s64，可能漏場景；已按固定 BASE 的真場景清單加四生成場景要求原序完全相同及無重複。

以上修正都已逐行靜態覆核，未改原性能判準。仍未做 runtime 自檢；正式執行才會確定相同 compiler 的 binary reproducibility、實際資料都符合嚴格 schema，以及本環境 N64 全組撤回確實 >2、恢復確實 ≤2。這份全組負控制不證明每一個等價性能元件單獨撤回都必超過門檻，也不取代 F 的完整四點 P-189 或其餘正式清單。
