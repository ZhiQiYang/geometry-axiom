# 真 P2 counterfactual 綁定：獨立實際來源覆核

本輪實際覆核 P2 `8a80abc1402b0c4c394969025c93a6019b4bb91d` 與 `/tmp/g261p2bind2/bundle`。結論是 **實際 P2 綁定已完成獨立核對，未見阻擋，可由 root 依本次 request 的固定 hashes 封存 gate**。這不是 F 驗收或性能負控制結果；審查者沒有修改 bundle、寫入 approval、import／執行 gate 或 counterfactual 工具，也沒有執行產品、scanner、建置、native、Chrome 或 benchmark。

審查者：`/root/round2_tool_preparation`。本次獨立純讀核對共 2776 checks、0 issues；實際稽核程式退出 0，完整結果與 Git 原始讀取記錄位於 `/workspace/geo261-environment/actual-P2-binding-audit/`。`AUDIT.json` schema 為 `geo261-actual-P2-binding-independent-audit/1`，SHA256 為 `ed7c0deadba0e1884edf7deedfeef16607279bcf5cd29bec5098f4f60cb9bb0e`。這一輪另讀真 Git blobs 與 mode，沒有只沿用準備器先前的靜態 peer review。

## 真退出與完整原始記錄

- 第二輪外層收據 `/workspace/geo261-environment/p2-rebind-launch-attempt2/receipt.json` 的真退出碼為 0，沒有 timeout，stderr 真為 0 bytes；argv 明確使用 frozen `preparer/rebind.py`、`-B`、真 P2 與 `/tmp/g261p2bind2` 新 scratch。
- 內層 `/tmp/g261p2bind2/receipt.json` 真退出 0，`acceptance_execution=false`、`product_build_or_execution=false`、`bundle_ready_for_F_runtime=false`，沒有把來源準備稱作性能驗收。
- 最終 39 筆子命令的 request／result／stdin／完整 stdout／stderr／hash／真退出皆已核對，全部是 Git。6 筆 rc1 是唯讀 `merge-base --is-ancestor` 的否定查詢，原始 rc1 原樣保留；其餘命令 rc0，不是被改寫的產品紅燈。source-check journal 為前 37 筆的精確不可變快照，最後兩筆 source HEAD/status guard 在外層完整 receipt／raw，沒有遺漏。
- 實際 preparer、capture、gate、policy、README 五份 frozen raw snapshots，與 launch／scratch／bundle 三處及內外收據 hashes 相符；原 READY 完整檔案集合與每檔 raw hash、準備器前後守衛均核對。新包的 SOURCE_CHECK_COMMANDS 與 PREPARER_SOURCE hash 鏈完整。

首輪因 `/tmp` 100% 的 ENOSPC 中止，仍保留在冷存與 frozen archive。其 `ENOSPC_PRESERVATION.json` 如實記外層真退出 1、`complete=false`、內層退出碼未知、stderr 不完整、沒有重建輸出、`accepted_source_result=false`。本審查沒有把首輪缺失資料補造完整，也沒有當作產品來源缺陷；成功結論只來自釋放空間後的第二輪真記錄。

## 獨立來源核對

P2 的真 parent 為 `7e7574a1f2ca67e7813004314306d6892e135b6e`，為單親提交；相對 parent 的完整 diff 只含 `geometry-guide/公理層-閱讀器.html`。P2 是原 P `b6646d10751a0d85a2f03f5d24fbe1073cb78980` 的後代。原始 `ls-remote` raw 確有整合分支 tip `c9e6b45492e6016a1b5c91934fa3c9a674435431`，並已另用只讀 Git 核對 P2 是該 tip 的祖先；公開身分不是只憑本機 P2 物件存在。

另從真 Git 逐一讀取 P、parent、P2 的 601 inputs：manifest／true Git executable inventory 路徑集合相同，沒有新增、刪除、symlink、submodule 或大小寫衝突，601 Git modes 全同。parent 的 601 raw 全等原 P；P2 恰好一個 HTML raw 改變，其餘 600 raw 全同。333 owned map 由真 P2 blobs 重新計算，與新 design、evidence、inner receipt 完全相符；沒有排除 HTML 或放寬成 subset。

HTML 的全檔等於原 P 在 I11 article 內唯一完整 trace row 的一次 exact byte 替換：

```text
app_contact_facts → app_contact_facts_prepare
```

這是完整 row／完整檔案的驗證，不是全域函式名稱替換或只看 +8 長度。原 HTML hash `3979f9858fa581df1d9c8f2ba0c21b471ebc0553464b1c1f7f2aa8c87952062a`、新 HTML hash `563da7a100e9053f3b23b87b04edec219ad223a0063d2509a380c2286a18482b`，實際恰增 8 bytes。P2 與 parent manifest raw 都是已核 A 的 `0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6`，保留 920 guards，沒有引入新政策。

15851 個 tracked tests 路徑與 modes／blob IDs 已對照 P，只有先前衍生 `tests/mutants_results.json` 有差異；expected JSON 與測試來源沒有改。兩 SSOT 的 raw／mode、P73 app.js、六實現與兩 public headers 都保持原 P。原 repo 前後與本次獨立核對後都仍為乾淨 P2。

## 本次核對的包身分

| 項目 | SHA256 |
|---|---|
| design | `ce563dcba16ac19818a3b1dbe5aec65e540fce1d89810a39905673d928aef505` |
| rebind evidence | `8dd22711f75cc0a8e04ab5f70af67c96bba897d1e94eb1c4eda0cd45d635be8c` |
| policy | `82c5b3b6b108e9fc78826afddaecb48c6fec8e598a6857e86aa00df0320a48dd` |
| source-check journal | `79f4636f8ebe2ce438463caab18d6de792d42b882d951598a8087c9af907ca1b` |
| pending bundle SHA256SUMS | `055a7f82a1d76feab40e74170751f1852949f75b33320460eb24d601b8f1fd4f` |
| run.py | `658ce5622bebfbf04e44de19d86127669d5ec899f887693d4125c0c662f231e2` |
| capture.py | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| validate.py | `f85871fbfa37552a80c40cd1d3f89ba43f8c33f7d02e2773839a120bd8e1d429` |
| rebind_gate.py | `2b71fff98014522b1758da8518d42da7002294a14d618650bcaea6e4ae2c8eb3` |

六份 counterfactual templates 逐檔符合 `P2_REVIEW_REQUEST.json`、design 與未修改的原 READY 包；新包對 runtime 的變更恰好只有 gate import 與 design 載入後呼叫 gate 的兩個 anchor，以及 P2 描述文字。capture／validate bytes 不變，原 N64 三輪、交錯、完整 raw、2×、compile／timeout 不算性能負控紅與恢復流程都沒有改。

新 design 僅新增／修改已審的 P2 綁定欄位，future F 仍須 exact333 raw 等 P2。gate 會核新的實際審查／design／policy／evidence／journal／準備器快照／四來源／六模板／審查原文 hash，拒 NOT_READY。當前 pending request 沒有被自動改成 approval，bundle 也沒有 NOT_READY／failed marker；本審查沒有寫任何 gate approval 檔。

封存的 pending 全包 `FREEZE.json` 與各 group 檔案 hashes 已核，149 MB raw tar 實際 SHA256 為 `fdfd39d0188bc3f6b21f5df8fc1cbe3ee91cd1f7cd87a00d29bff9ae76f0b47a`，與紀錄一致，包含首輪不完整現場。gate 封存後的 metadata 改動應保留這份 pending manifest 歷史，不能改四份已審來源或六模板而沿用本結論。

## 結論的界線

root 可以使用本次實際 P2 審查原文與 request 的固定 hashes 封存新的 binding approval；本稿不是先前 preparer review 改名。之後仍須新公開乾淨 F、exact333 等 P2、同 F 的完整正式四點 P-189 收據，以及真正執行 N64 全組撤回 >2／恢復 ≤2 才能宣稱性能自證。F 的完整清單正在另行執行，本次來源審查沒有替它提供綠燈，也沒有核准新門檻或聲稱每個性能元件個別必要。
