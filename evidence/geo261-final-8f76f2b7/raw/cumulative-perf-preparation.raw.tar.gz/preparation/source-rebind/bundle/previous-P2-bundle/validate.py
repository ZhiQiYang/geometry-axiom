"""重核已存在的正式F收據與原timing raw；不執行產品或測試。"""
import csv,json,statistics
from pathlib import Path
from capture import digest,filehash
MAIN='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
BASE='3e600772076465fc65a26ac09055028301c0fb0b'
def samples(directory,labels,ns):
 directory=Path(directory);rows=list(csv.DictReader((directory/'samples.tsv').open(),delimiter='\t'))
 wanted={(str(n),str(r),side) for n in ns for r in range(3) for side in labels}
 order=[(str(n),str(r),side) for n in ns for r in range(3) for side in (labels if r%2==0 else labels[::-1])]
 assert len(rows)==len(wanted) and [(r['n'],r['round'],r['side']) for r in rows]==order
 assert all(r['status']=='ok' and r['ok']=='True' for r in rows)
 raw=json.loads((directory/'loadfile-samples.json').read_text());assert len(raw)==len(wanted)
 assert [(str(r['n']),str(r['round']),r['side']) for r in raw]==order
 for row,tsv in zip(raw,rows):
  assert type(row['actual_process_returncode']) is int and row['actual_process_returncode']==0 and row['timeout_expired'] is False and row['load_ok'] is True
  assert {'stdin.bin','stdout.bin','stderr.bin'}<=set(row['files'])
  for value in row['files'].values():
   path=(directory/value['path']).resolve();assert path.is_relative_to(directory.resolve())
   assert path.stat().st_size==value['bytes'] and filehash(path)==value['sha256']
  output=directory/row['files']['stdout.bin']['path'];response=json.loads(output.read_bytes().splitlines()[0]);assert response.get('ok') is True
  assert format(row['seconds'],'.4f')==tsv['seconds']
 medians={n:{side:statistics.median(float(r['seconds']) for r in rows if r['n']==str(n) and r['side']==side) for side in labels} for n in ns}
 return rows,medians
def formal(path,sha,tools,expected_dump_scenes):
 path=Path(path);tools=Path(tools);r=json.loads(path.read_text())
 assert r['schema']=='geo261-p189-final/1' and r['shas']=={'main':MAIN,'base':BASE,'fix':sha}
 assert r['pass'] is True and r['samples']==36
 rows,medians=samples(path.parent,('main','base','fix'),(16,32,48,64))
 captures=[]
 for result in sorted((path.parent/'subcommands').glob('*/result.json')):
  item=json.loads(result.read_text());command=item.get('command',[])
  if len(command)>1 and command[1]==str(tools/'scale_compare2.py'):captures.append((result,item))
 assert len(captures)==1,'正式收據必須保留唯一的原 timing run 子命令'
 capture_path,capture=captures[0];command=capture['command'];work=Path(command[2]);cwd=Path(capture['cwd'])
 assert work.is_absolute() and cwd.is_absolute()
 assert command==[command[0],str(tools/'scale_compare2.py'),str(work),str(path.parent),
  'main='+str(work/'main'),'base='+str(work/'base'),'fix='+str(work/'fix'),'--ns','16,32,48,64','--reps','3','--gen',str(tools/'gen_scene.py')]
 assert type(capture['actual_process_returncode']) is int and capture['actual_process_returncode']==0 and capture['timeout_expired'] is False
 for stream in ('stdout','stderr'):
  payload=(capture_path.parent/(stream+'.bin')).read_bytes()
  assert len(payload)==capture[stream]['bytes'] and digest(payload)==capture[stream]['sha256']
 raw=json.loads((path.parent/'loadfile-samples.json').read_text())
 for sample in raw:
  scene=work/('s'+str(sample['n'])+'.scene')
  assert sample['command']==['bash','-c','ulimit -c 0; ulimit -S -s 16384 || exit 126; exec "$@"','x',str(work/sample['side']/'bridge')]
  assert sample['cwd']==str(cwd) and sample['scene']==str(scene)
  assert (path.parent/sample['files']['stdin.bin']['path']).read_bytes()==('loadfile '+str(scene)+'\n').encode()
 assert len(r['ratios'])==4 and {x['n'] for x in r['ratios']}=={16,32,48,64}
 for n in (16,32,48,64):
  row=next(x for x in r['ratios'] if x['n']==n);assert row['medians']==medians[n]
  ratio=medians[n]['fix']/medians[n]['main'];assert row['fix_main']==ratio and row['pass'] is True and ratio<=2
 dumps=json.loads((path.parent/'dump-equivalence.json').read_text());assert len(dumps)==r['dump_count'] and len(dumps)>0
 assert [x['scene'] for x in dumps]==expected_dump_scenes and len(set(expected_dump_scenes))==len(expected_dump_scenes)
 assert all(x['identical'] is True and x['dump_ok'] is True for x in dumps)
 for item in dumps:
  base=(path.parent/(item['scene']+'-base.stdout')).read_bytes();fix=(path.parent/(item['scene']+'-fix.stdout')).read_bytes()
  assert base==fix and len(fix)==item['bytes'] and digest(fix)==item['stdout_sha256']
  assert json.loads(fix.splitlines()[0]).get('ok') is item['load_ok']
  assert json.loads(fix.splitlines()[1]).get('ok') is True
  for side in ('base','fix'):assert (path.parent/(item['scene']+'-'+side+'.stderr')).is_file()
 n64=next(x for x in dumps if x['scene']=='s64.scene');assert n64['load_ok'] is True
 assert filehash(tools/'scale_compare2.py')==r['timing_script_sha256']
 assert filehash(tools/'gen_scene.py')==r['generator_sha256']
 assert filehash(tools/'p189_verify.py')==r['verification_script_sha256']
 return r,{'receipt_sha256':filehash(path),'samples_tsv_sha256':filehash(path.parent/'samples.tsv'),
  'raw_samples_sha256':filehash(path.parent/'loadfile-samples.json'),'dump_equivalence_sha256':filehash(path.parent/'dump-equivalence.json'),
  'n64_formal':n64,'formal_tools':str(tools.resolve()),'timing_run_capture_path':str(capture_path),
  'timing_run_capture_sha256':filehash(capture_path),'timing_work':str(work),'timing_cwd':str(cwd),'timing_environment':capture['environment'],
  'expected_dump_scenes_from_fixed_BASE':expected_dump_scenes}
