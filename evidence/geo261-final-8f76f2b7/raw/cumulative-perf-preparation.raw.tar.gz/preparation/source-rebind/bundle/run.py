#!/usr/bin/env python3
"""F全組純性能撤回的N64負控制；不修改原repo、不取代正式四點P189。"""
import argparse,fcntl,io,json,os,platform,re,resource,shutil,subprocess,sys,tarfile,time,traceback
from pathlib import Path
from capture import Recorder,digest,dump,filehash
from validate import MAIN,BASE,formal,samples
from rebind_gate import verify_rebind_review
TOOLS=Path(__file__).resolve().parent
if sys.flags.optimize:raise SystemExit('拒絕以最佳化 Python 執行；完整驗收 guard 必須生效')
SCOPES=('current_geometry.c','geometry-core','geometry-app','geometry-templates','geometry-web')
EARLY_GIT=[]
ACTIVE_RECORDER=None
SAFE_FAILURE_OUT=None
SAFE_FAILURE_SHA=None
OWN_OUT=False
HEAVY_STARTED=False
def local_git(repo,*args):
 command=['git','-C',str(repo),*args]
 if ACTIVE_RECORDER is not None:return ACTIVE_RECORDER.run(command,cwd=Path.cwd())[1]
 start=time.time();result=subprocess.run(command,capture_output=True)
 EARLY_GIT.append({'command':command,'cwd':str(Path.cwd()),'started_epoch':start,'ended_epoch':time.time(),
  'actual_process_returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 if result.returncode:raise RuntimeError('前置Git命令非零')
 return result.stdout
def state(repo):return {'head':local_git(repo,'rev-parse','HEAD').decode().strip(),'status':local_git(repo,'status','--porcelain=v1','--untracked-files=all').decode()}
def flush_early(out,sha):
 preflight=[]
 for index,row in enumerate(EARLY_GIT):
  target=out/'preflight-git'/f'{index:06d}';target.mkdir(parents=True,exist_ok=True)
  for name in ('stdout','stderr'):(target/(name+'.bin')).write_bytes(row[name])
  metadata={k:v for k,v in row.items() if k not in ('stdout','stderr')};metadata.update(source_sha=sha,stdin_provided=False,
   stdout_sha256=digest(row['stdout']),stderr_sha256=digest(row['stderr']),directory=str(target),
   environment={k:os.environ[k] for k in ('PATH','LANG','LC_ALL') if k in os.environ})
  dump(target/'result.json',metadata);preflight.append(metadata)
 dump(out/'preflight-git.json',preflight);return preflight
def owned_hashes(repo,sha,paths,rec):
 _,raw,_=rec.run(['git','-C',str(repo),'archive','--format=tar',sha,'--',*paths],cwd=repo)
 result={}
 with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
  for member in archive:
   if member.isfile():result[member.name]=digest(archive.extractfile(member).read())
 assert set(result)==set(paths);return result
def main():
 global ACTIVE_RECORDER,SAFE_FAILURE_OUT,SAFE_FAILURE_SHA,OWN_OUT
 ap=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','scratch','heavy-lock','formal-receipt'):ap.add_argument('--'+name,type=Path,required=True)
 ap.add_argument('--sha',required=True);ap.add_argument('--formal-tools',type=Path)
 ap.add_argument('--published-repo',type=Path,default=Path('/workspace/geometry-axiom'))
 a=ap.parse_args();repo=a.repo.resolve();out=a.scratch.resolve();lockpath=a.heavy_lock.resolve();pub=a.published_repo.resolve()
 assert re.fullmatch('[0-9a-f]{40}',a.sha)
 assert out.is_relative_to(Path('/tmp')) and not out.exists() and not out.is_relative_to(repo)
 assert lockpath.is_relative_to(Path('/tmp')) and lockpath.parent.is_dir() and not lockpath.is_relative_to(out)
 SAFE_FAILURE_OUT=out;SAFE_FAILURE_SHA=a.sha
 design=json.loads((TOOLS/'counterfactual-design.json').read_text());verify_rebind_review(TOOLS,design)
 assert a.sha!=design['design_source_sha'],'必須填正式新F，不能用設計P3冒充'
 assert Path(local_git(repo,'rev-parse','--show-toplevel').decode().strip()).resolve()==repo
 assert local_git(repo,'rev-parse',a.sha+'^{commit}').decode().strip()==a.sha and state(repo)=={'head':a.sha,'status':''}
 formal_path=a.formal_receipt.resolve();formal_tools=(a.formal_tools or formal_path.parent.parent).resolve()
 expected_dump_scenes=['s'+str(n)+'.scene' for n in (16,32,48,64)]
 expected_dump_scenes+=['repo-'+name for name in local_git(repo,'ls-tree','-z','--name-only',BASE).decode().split('\0') if name.endswith('.scene')]
 original,baseline=formal(formal_path,a.sha,formal_tools,expected_dump_scenes)
 out.mkdir(parents=True);OWN_OUT=True;(out/'tmp').mkdir();clone=out/'source-counterfactual';main_source=out/'source-main'
 env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','AXIOM_ONLY','GIT_CURL_VERBOSE','PYTHONOPTIMIZE') and not k.startswith(('GEOMETRY_','GEO261_PC_','GEO261_MEM_','GIT_TRACE'))}
 env.update(PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(out/'tmp'))
 soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
 record={'schema':'geo261-final-performance-withdrawal/1','sha':a.sha,'status':'執行中','formal_acceptance':False,'scope':'N64 main/withdrawn/restored各3輪；全組純性能負控制，非完整四點P189',
  'source_before':state(repo),'formal_F_baseline':baseline,'design_source_sha':design['design_source_sha'],'shared_heavy_lock':str(lockpath),
  'platform':platform.platform(),'python':{'executable':sys.executable,'version':sys.version,'optimize':sys.flags.optimize},
  'stack_limit_bytes':resource.getrlimit(resource.RLIMIT_STACK),'errors':[],'commands':[],'semantic_red':False,'proof_matched':False}
 rec=Recorder(out,env,a.sha);ACTIVE_RECORDER=rec
 record['preflight_git']=flush_early(out,a.sha)
 frozen=out/'tools-frozen';shutil.copytree(TOOLS,frozen)
 record['tool_hashes']={str(p.relative_to(frozen)):filehash(p) for p in sorted(frozen.rglob('*')) if p.is_file()}
 formal_copy=out/'formal-tools';formal_copy.mkdir()
 for name in ('scale_compare2.py','gen_scene.py'):shutil.copy2(formal_tools/name,formal_copy/name)
 assert filehash(formal_copy/'scale_compare2.py')==original['timing_script_sha256'] and filehash(formal_copy/'gen_scene.py')==original['generator_sha256']
 shutil.copy2(formal_path,out/'formal-F.receipt.json');dump(out/'receipt.json',record)
 originals={};mutated=False;builds={};binary=out/'bin';binary.mkdir()
 def git(*args,check=True):return rec.run(['git','-C',str(clone),*args],cwd=out,check=check)
 def verify_f():
  assert state(clone)=={'head':a.sha,'status':''}
  for path,wanted in design['owned_product_hashes'].items():assert filehash(clone/path)==wanted,path
 def restore():
  for path,data in originals.items():(clone/path).write_bytes(data)
  if originals:verify_f()
 def build(label,source):
  global HEAVY_STARTED
  HEAVY_STARTED=True
  args=['gcc','-std=c11','-O2','geometry-web/web_bridge.c','-o',str(binary/label),'-lm']
  row,_,_=rec.run(args,cwd=source,check=False,source_sha=MAIN if label=='main' else a.sha,
   source_variant=label);builds[label]=row
  if row['actual_process_returncode']!=0 or row['timeout_expired']:raise RuntimeError(label+'建置失敗；不是性能負控制紅')
  record.setdefault('binaries_sha256',{})[label]=filehash(binary/label)
 def error(stage):record['errors'].append({'stage':stage,'traceback':traceback.format_exc()});dump(out/'receipt.json',record)
 try:
  with lockpath.open('a+b') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   # 網路remote查核只讀；URL不入收據，避免複製任何注入的認證值。
   remote_result=subprocess.run(['git','-C',str(pub),'remote','get-url','origin'],capture_output=True)
   assert remote_result.returncode==0
   remote=remote_result.stdout.decode().strip();assert remote.startswith(('https://','http://','ssh://','git@'))
   record['remote_transport_validation']={'command':['git','-C',str(pub),'remote','get-url','origin'],'actual_process_returncode':remote_result.returncode,
    'network_transport':True,'stdout_sha256':digest(remote_result.stdout),'raw_url_suppressed_to_protect_injected_credentials':True}
   row,refs,_=rec.run(['git','-C',str(pub),'ls-remote','--refs','origin'],cwd=pub)
   visible=[line.split(None,1) for line in refs.decode().splitlines() if line.strip()]
   visible.sort(key=lambda x:0 if x[1]=='refs/heads/architecture/geo261-integration-20261016' else 1)
   published=None
   for oid,name in visible:
    if oid==a.sha:published={'ref':name,'tip':oid,'relationship':'exact'};break
    check,_,_=rec.run(['git','-C',str(pub),'merge-base','--is-ancestor',a.sha,oid],cwd=pub,check=False)
    if check['actual_process_returncode']==0:published={'ref':name,'tip':oid,'relationship':'ancestor'};break
   assert published,'不能證明F可由網路remote解析；不執行負控制'
   record['published_F']=published
   rec.run(['git','clone','--no-hardlinks','--no-checkout',str(repo),str(clone)],cwd=out)
   git('checkout','--detach',a.sha);verify_f()
   f_manifest=json.loads(local_git(clone,'show',a.sha+':geometry-core/domain-decoupling/product-architecture.json'))
   assert {x['path'] for x in f_manifest['sources']}==set(design['owned_product_hashes'])
   assert owned_hashes(clone,a.sha,sorted(design['owned_product_hashes']),rec)==design['owned_product_hashes']
   record['owned_product_hashes']=design['owned_product_hashes']
   compiler=rec.run(['gcc','--version'],cwd=out)[1].decode().splitlines()[0];assert compiler==original['compiler']
   record['compiler']=compiler;targets=design['changed_implementations']
   for item in targets:
    path=item['path'];originals[path]=(clone/path).read_bytes();assert digest(originals[path])==item['expected_F_raw_sha256']
   try:
    for item in targets:
     data=(frozen/'counterfactual-templates'/item['path']).read_bytes();assert digest(data)==item['counterfactual_raw_sha256']
     (clone/item['path']).write_bytes(data)
    mutated=True
    actual=git('diff','--name-only')[1].decode().splitlines();assert actual==sorted(originals)
    patch=git('diff','--binary')[1];(out/'withdrawal.patch').write_bytes(patch);record['counterfactual_patch_sha256']=digest(patch)
    record['counterfactual_hashes']={path:filehash(clone/path) for path in originals}
    build('withdrawn',clone)
   except Exception:error('counterfactual-build')
   finally:
    try:restore();mutated=False;record['restored_after_counterfactual']=state(clone)
    except BaseException:error('restore-after-counterfactual')
   try:
    verify_f();build('restored',clone)
    assert record['binaries_sha256']['restored']==original['binaries_sha256']['fix'],'F恢復binary與正式F不相同，不能冒稱同一受驗程式'
   except Exception:error('restored-build-and-identity')
   try:
    main_source.mkdir();root_names=set(local_git(repo,'ls-tree','-z','--name-only',MAIN).decode().split('\0'))
    paths=[p for p in SCOPES if p in root_names]
    args=['git','-C',str(repo),'archive','--format=tar',MAIN,'--',*paths,':(exclude)geometry-core/domain-decoupling',':(exclude)geometry-web/docs',':(exclude)geometry-web/prototypes',':(exclude)geometry-web/vendor',':(exclude)geometry-web/node_modules']
    raw=rec.run(args,cwd=repo)[1];(out/'main-source.tar').write_bytes(raw)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:archive.extractall(main_source,filter='data')
    record['main_source_archive_sha256']=digest(raw);build('main',main_source)
    assert record['binaries_sha256']['main']==original['binaries_sha256']['main'],'main binary與正式F P189 baseline不相同'
   except Exception:error('main-build')
   if record['errors']:raise RuntimeError('建置/恢復/身分有錯；未把compile error當性能紅')
   scene=rec.run([sys.executable,'-B',str(formal_copy/'gen_scene.py'),'64','--family','single'],cwd=out)[1]
   assert digest(scene)==baseline['n64_formal']['scene_sha256'];scene_path=out/'s64.scene';scene_path.write_bytes(scene)
   dumps={}
   for label in ('main','withdrawn','restored'):
    row,stdout,stderr=rec.run(['bash','-c','ulimit -c 0; ulimit -S -s 16384 || exit 126; exec "$@"','x',str(binary/label)],cwd=out,data=('loadfile '+str(scene_path)+'\ndump\n').encode(),timeout=900,check=False,
     source_sha=MAIN if label=='main' else a.sha,source_variant=label)
    assert row['actual_process_returncode']==0 and row['timeout_expired'] is False
    lines=stdout.splitlines();assert len(lines)==2;responses=[json.loads(x) for x in lines]
    assert all(x.get('ok') is True for x in responses);dumps[label]=stdout
   assert digest(dumps['withdrawn'])==digest(dumps['restored'])==baseline['n64_formal']['stdout_sha256']
   dump(out/'n64-dump-equivalence.json',{'formal_F_sha':a.sha,'withdrawn_restored_formal_F_identical':True,'main_identical_to_F':dumps['main']==dumps['restored'],
    'stdout_sha256':{k:digest(v) for k,v in dumps.items()},'scene_sha256':digest(scene)})
   timing=out/'timing';timing_work=out/'timing-work';timing_work.mkdir()
   # 原driver要求每側srcdir/bridge；每個目錄只放對應的原binary副本。
   sides={}
   for label in ('main','withdrawn','restored'):
    target=out/'timing-binaries'/label;target.mkdir(parents=True);shutil.copy2(binary/label,target/'bridge');sides[label]=target
    assert filehash(target/'bridge')==record['binaries_sha256'][label]
   args=[sys.executable,'-B',str(formal_copy/'scale_compare2.py'),str(timing_work),str(timing),*[label+'='+str(path) for label,path in sides.items()],
      '--ns','64','--reps','3','--gen',str(formal_copy/'gen_scene.py')]
   rec.run(args,cwd=out,timeout=1800,source_variant='mixed-main-withdrawn-restored')
   for label,target in sides.items():assert filehash(target/'bridge')==record['binaries_sha256'][label]
   rows,medians=samples(timing,tuple(sides),(64,));m=medians[64]
   bridge_provenance=[]
   for row in json.loads((timing/'loadfile-samples.json').read_text()):
    assert Path(row['command'][-1]).resolve()==(sides[row['side']]/'bridge').resolve()
    assert Path(row['cwd']).resolve()==out and Path(row['scene']).resolve()==(timing_work/'s64.scene').resolve()
    assert (timing/row['files']['stdin.bin']['path']).read_bytes()==('loadfile '+str(timing_work/'s64.scene')+'\n').encode()
    bridge_provenance.append({'original_sample':row,'acceptance_sha':a.sha,'source_sha':MAIN if row['side']=='main' else a.sha,
     'source_variant':row['side'],'binary_sha256':record['binaries_sha256'][row['side']],
     'source_patch_sha256':record['counterfactual_patch_sha256'] if row['side']=='withdrawn' else None,
     'environment':{k:env[k] for k in ('PATH','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','TMPDIR')},
     'environment_inherited_from_recorded_original_timing_driver':True})
   dump(out/'timing-bridge-provenance.json',bridge_provenance)
   assert filehash(timing_work/'s64.scene')==digest(scene)
   withdrawn=m['withdrawn']/m['main'];restored=m['restored']/m['main']
   record.update(medians=m,withdrawn_main=withdrawn,restored_main=restored,semantic_red=withdrawn>2,
     semantic_equivalence=True,restored_green=restored<=2,proof_matched=withdrawn>2 and restored<=2,
     gate='原P189 <=2；此為N64局部負控制，原timing子程序退出0與門檻判決分列')
   verify_f();assert state(repo)==record['source_before']
   assert filehash(formal_path)==baseline['receipt_sha256']
   assert filehash(formal_tools/'scale_compare2.py')==original['timing_script_sha256'] and filehash(formal_tools/'gen_scene.py')==original['generator_sha256']
   assert filehash(formal_copy/'scale_compare2.py')==original['timing_script_sha256'] and filehash(formal_copy/'gen_scene.py')==original['generator_sha256']
   record.update(status='完成',exit_code=0 if record['proof_matched'] else 1)
 except BaseException as exception:
  error('orchestration');record.update(status='中斷' if isinstance(exception,KeyboardInterrupt) else '失敗',exit_code=130 if isinstance(exception,KeyboardInterrupt) else 1,proof_matched=False)
 finally:
  try:
   if originals:restore()
   assert state(repo)==record['source_before'];record['source_after']=state(repo)
   if clone.exists():record['final_clone_state']=state(clone)
  except BaseException:error('final-source-restore');record.update(status='失敗',exit_code=1,proof_matched=False)
  record['commands']=rec.rows;record['full_suite_acceptance_not_run_by_this_tool']=True;dump(out/'receipt.json',record)
 print(json.dumps({'sha':a.sha,'status':record['status'],'exit_code':record['exit_code'],'proof_matched':record['proof_matched'],'receipt':str(out/'receipt.json')},ensure_ascii=False));return record['exit_code']
def entry():
 global OWN_OUT
 try:return main()
 except BaseException as exception:
  # 安全 scratch 驗證先於任何 Git 命令；此前的 argparse／無效路徑只由外層原 streams 記錄。
  if SAFE_FAILURE_OUT is not None:
   if not OWN_OUT:SAFE_FAILURE_OUT.mkdir(parents=True);OWN_OUT=True
   report={'schema':'geo261-counterfactual-bootstrap-failure/1','sha':SAFE_FAILURE_SHA,'status':'失敗',
    'actual_exception':repr(exception),'traceback':traceback.format_exc(),'product_build_or_execution_started':HEAVY_STARTED,
    'preflight_git':flush_early(SAFE_FAILURE_OUT,SAFE_FAILURE_SHA)}
   dump(SAFE_FAILURE_OUT/'bootstrap-failure.json',report)
  raise
if __name__=='__main__':raise SystemExit(entry())
