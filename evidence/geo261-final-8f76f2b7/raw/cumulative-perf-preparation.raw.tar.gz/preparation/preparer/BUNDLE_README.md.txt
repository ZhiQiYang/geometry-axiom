# F2 的累積 C 性能撤回／恢復工具

本包設計來源 P3=`55b9fb6479485361d9e2283a95e4355f5fca76db`，預定完整受驗 F2=`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。只完成 Git 固定來源準備與 AST，尚未建置、量測或驗收 F2。

舊 P2 工具／核准原封不動置於 `previous-P2-bundle/`，不是本輪 P3 核准。原 F1 counterproof 真0收據獨立保存在 `historical-F1-counterproof.receipt.json`：withdraw/main約2.4676、restored/main約1.7712，原raw公開於 commit `7f8185e5d53b3227cd5d36c2cab142069adaa46e:evidence/geo261-final-fe863b03/raw/F-cumulative-perf-proof.raw.tar.gz`。那是 F1 歷史，不是 F2 結果。

來源差分嚴格限定：P2／F1 601來源同；F1→P3全部非evidence只有runtime_version.py，333 owned只改此檔；P3→F2只架構report/receipt、601來源全同。六C實作／六撤回模板、兩個新API header、完整F1/P3/F2 tests、SSOT、P73與canonicalHTML皆未改。架構closure為 `303ee650da50d92a0397a5556bdf5b94c3066c941f1e5f850a79ea83638493dd`。

`SOURCE_CHECK_COMMANDS.json` 是純Git來源準備journal，對應完整stdin/stdout/stderr在準備out的 `subcommands/`；不可只收本bundle而漏原raw。`P3_TOOL_ADAPTATION.patch` 只機械更新原既有binding review名詞／schema，沒有新增gate。須由另一agent對實際P3綁定一次純讀核對，依 `P3_REVIEW_REQUEST.json` 寫本次 `P3_BINDING_REVIEW.md/json`；不能沿舊P2 approved。完成本次review後即可用原機制，不增加多輪審批。

正式F2四點P189同SHA已完整通過後，使用全新scratch：

```bash
GEO261_REAPER_LOG=/workspace/geo261-environment/F2-perf-preparation/runtime-reaper.jsonl \
python3 /workspace/geo261-environment/reap_children.py \
python3 -B /workspace/geo261-environment/F2-perf-preparation/source-rebind/bundle/run.py \
  --repo /tmp/g261r3/source-final --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 \
  --scratch /tmp/g261F2perf --heavy-lock /tmp/g261r3/heavy.lock \
  --formal-receipt /tmp/g261r3/tools/p189-8f76f2b7/receipt.json \
  --formal-tools /tmp/g261r3/tools --published-repo /workspace/geometry-axiom
```

工具自己拿共用鎖，outer不得double-lock。原capture／validate、六templates、新API與canonical守門、N64 main/withdrawn/restored各三筆、原timing／2×判準全保留；withdrawn僅撤六C性能省工，runtime_version.py 的 P52 修正保留。任意compile/error/EOF不算有效性能紅；load/dump逐byte同、真rc0才判性能。原333未放寬：runtime F2必須公開乾淨且全部owned raw exact P3；新包仍不代替正式四點與完整清單，不聲稱每個等價component個別必要。
