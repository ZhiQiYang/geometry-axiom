#!/usr/bin/env python3
"""固定 Git 來源純讀重綁 P3；不建置、不測試、不量測。"""
import argparse,ast,copy,difflib,io,json,os,re,shutil,sys,tarfile,traceback
from pathlib import Path
from capture import Recorder,digest,dump,filehash
HERE=Path(__file__).resolve().parent
P2='8a80abc1402b0c4c394969025c93a6019b4bb91d'
F1='fe863b0374eafd9f1e57ec5107e28a1101804b56'
P3='55b9fb6479485361d9e2283a95e4355f5fca76db'
F2='8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
TARGET='geometry-web/runtime_version.py'
MANIFEST='geometry-core/domain-decoupling/product-architecture.json'
ARCH_RECEIPT='geometry-core/domain-decoupling/product-architecture-receipt.json'
EXPECTED_CLOSURE='303ee650da50d92a0397a5556bdf5b94c3066c941f1e5f850a79ea83638493dd'
EXPECTED_PATCH='64da8341969b4580f483e5a0310f511a20454a7d435dc29cd3032e37ce5fae0d'
OLD_PUBLIC_COMMIT='7f8185e5d53b3227cd5d36c2cab142069adaa46e'
OLD_PUBLIC_PREFIX='evidence/geo261-final-fe863b03/'
SUFFIXES={'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}
def require(value,message):
 if not value:raise RuntimeError(message)
def inventory(directory):
 rows={}
 for path in sorted(directory.rglob('*')):
  if path.is_file():
   require(not path.is_symlink(),'工具包不能含 symlink')
   rows[str(path.relative_to(directory))]={'sha256':filehash(path),'bytes':path.stat().st_size}
 return rows

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','out','previous-bundle','previous-receipt'):ap.add_argument('--'+name,type=Path,required=True)
 a=ap.parse_args();repo=a.repo.resolve();out=a.out.resolve();previous=a.previous_bundle.resolve();oldreceipt=a.previous_receipt.resolve()
 require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0'),'不能停用 assert')
 require(out.is_relative_to(Path('/workspace/geo261-environment/F2-perf-preparation')) and not out.exists(),'需要本任務目錄下全新 out')
 require(not out.is_relative_to(repo) and not out.is_relative_to(previous),'輸出不能在來源或舊包內')
 out.mkdir();env=dict(os.environ,LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
 rec=Recorder(out,env,F2);bundle=out/'bundle';before=inventory(previous);source=inventory(HERE)
 report={'schema':'geo261-P3-counterfactual-rebind/1','P3':P3,'requested_final_F2':F2,'previous_design_P2':P2,'previous_final_F1':F1,
  'acceptance_execution':False,'product_build_or_execution':False,'performance_verdict':None,'status':'執行中','errors':[]}
 def git(*args,sha=F2,check=True):return rec.run(['git','-C',str(repo),*args],cwd=HERE,check=check,source_sha=sha)
 def tree(sha):
  raw=git('ls-tree','-r','-z',sha,sha=sha)[1];values={}
  for item in raw.split(b'\0'):
   if not item:continue
   descriptor,path=item.split(b'\t',1);mode,kind,oid=descriptor.decode().split()
   values[path.decode()]={'mode':mode,'kind':kind,'blob_id':oid}
  return values
 def blobs(sha,paths):
  raw=git('archive','--format=tar',sha,'--',*sorted(paths),sha=sha)[1];values={}
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   for item in archive:
    if item.isdir():continue
    require(item.isfile() and item.name in paths and item.name not in values,'archive含額外／重複／非一般檔')
    values[item.name]=archive.extractfile(item).read()
  require(set(values)==set(paths),'archive缺來源');return values
 try:
  design=json.loads((previous/'counterfactual-design.json').read_bytes())
  require(design['design_source_sha']==P2 and len(design['owned_product_hashes'])==333,'不是已知 P2 設計')
  approved=json.loads((previous/'P2_BINDING_REVIEW.json').read_bytes())
  require(approved['status']=='approved-for-future-F-runtime' and approved['actual_independent_P2_binding_review_completed'] is True,'缺舊 P2 真實審查')
  require(approved['design_sha256']==filehash(previous/'counterfactual-design.json'),'舊 P2 設計已偏離審查')
  require(approved['tool_source_sha256']=={n:filehash(previous/n) for n in ('run.py','capture.py','validate.py','rebind_gate.py')},'舊 P2 工具已偏離審查')
  require(approved['review_markdown_sha256']==filehash(previous/'P2_BINDING_REVIEW.md'),'舊 P2 審查原文不符')
  report['observed_checkout_before']={'head':git('rev-parse','HEAD')[1].decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all')[1].decode()}
  for sha in (P2,F1,P3,F2):require(git('rev-parse',sha+'^{commit}',sha=sha)[1].decode().strip()==sha,'固定 SHA 不可解析')
  for older,newer in ((P2,F1),(F1,P3),(P3,F2)):
   git('merge-base','--is-ancestor',older,newer,sha=newer)
  parents=git('rev-list','--parents','-n','1',P3,sha=P3)[1].decode().split();require(len(parents)==2,'P3須單親')
  require(git('diff','--no-renames','--name-only',parents[1],P3,sha=P3)[1].decode().splitlines()==[TARGET],'P3不是單一runtime修正')
  require(git('rev-list','--parents','-n','1',F2)[1].decode().split()==[F2,P3],'F2不是P3的直接單親架構提交')
  require(git('diff','--no-renames','--name-only',P3,F2)[1].decode().splitlines()==['geometry-core/domain-decoupling/PRODUCT-ARCHITECTURE.md',ARCH_RECEIPT],'F2只准架構report/receipt')
  patch=git('diff','--binary','--no-ext-diff','--no-color',parents[1],P3,'--',TARGET,sha=P3)[1]
  require(digest(patch)==EXPECTED_PATCH,'P3 runtime exact patch不符')
  (out/'actual-P3-runtime.patch').write_bytes(patch)
  non_evidence=git('diff','--no-renames','--name-only',F1,P3,sha=P3)[1].decode().splitlines()
  require([p for p in non_evidence if not p.startswith('evidence/')]==[TARGET],'F1到P3有額外非evidence差分')
  refs=git('ls-remote','--refs','origin','refs/heads/architecture/geo261-integration-20261016')[1].decode().splitlines()
  require(len(refs)==1,'公開整合ref不唯一');tip,ref=refs[0].split(None,1)
  for sha in (P2,F1,P3,F2,OLD_PUBLIC_COMMIT):git('merge-base','--is-ancestor',sha,tip,sha=sha)
  report['published_source']={'ref':ref,'tip':tip,'P3_and_F2_and_old_archive_commit_are_ancestors':True}
  trees={sha:tree(sha) for sha in (P2,F1,P3,F2)};manifests={};allpaths=None
  for sha in trees:
   raw=git('show',sha+':'+MANIFEST,sha=sha)[1];m=json.loads(raw);manifests[sha]=m
   require(digest(raw)=='0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6','manifest raw已改')
   declared={i['path'] for i in m['sources']+m['exclusions']}
   require(len(m['sources'])==333 and len(m['exclusions'])==268 and len(declared)==601,'601/333/268集合不符')
   require({i['path'] for i in m['sources']}==set(design['owned_product_hashes']),'333集合已改')
   found={p for p in trees[sha] if Path(p).suffix.lower() in SUFFIXES and (p in m['sourceFiles'] or any(p.startswith(r+'/') for r in m['sourceRoots']))}
   require(found==declared and len({p.casefold() for p in found})==601,'Git真實可執行inventory非601')
   require(all(trees[sha][p]['mode'] in ('100644','100755') and trees[sha][p]['kind']=='blob' for p in found),'來源含非一般檔')
   if allpaths is None:allpaths=declared
   require(allpaths==declared,'601 pathset已改')
  rawsets={sha:blobs(sha,allpaths) for sha in (P2,F1,P3,F2)}
  hashes={sha:{p:digest(v) for p,v in rawsets[sha].items()} for sha in rawsets}
  wanted=design['owned_product_hashes'];owned=set(wanted)
  require({p:hashes[P2][p] for p in owned}==wanted,'P2真Git來源不等於舊design')
  require(hashes[P2]==hashes[F1],'P2/F1完整601不同')
  require([p for p in sorted(allpaths) if hashes[F1][p]!=hashes[P3][p]]==[TARGET],'F1/P3完整601必須僅runtime不同')
  require(hashes[P3]==hashes[F2],'P3/F2完整601不相同')
  require({p:trees[P2][p]['mode'] for p in allpaths}=={p:trees[F1][p]['mode'] for p in allpaths}=={p:trees[P3][p]['mode'] for p in allpaths}=={p:trees[F2][p]['mode'] for p in allpaths},'601 mode已變')
  tests={sha:{p:v for p,v in trees[sha].items() if p.startswith('tests/')} for sha in (F1,P3,F2)}
  require(bool(tests[F1]) and tests[F1]==tests[P3]==tests[F2],'F1/P3/F2完整tests path/mode/blob不相同')
  protected={}
  for p in ('公理層.md','決策佇列.md'):
   vals={sha:git('show',sha+':'+p,sha=sha)[1] for sha in (F1,P3,F2)}
   require(vals[F1]==vals[P3]==vals[F2] and trees[F1][p]==trees[P3][p]==trees[F2][p],'SSOT raw/mode/blob不同')
   protected[p]=digest(vals[F2])
  for item in design['changed_implementations']:
   p=item['path'];require(hashes[F2][p]==item['expected_F_raw_sha256'],'六C實作已改')
   require(filehash(previous/'counterfactual-templates'/p)==item['counterfactual_raw_sha256'],'六撤回template已改')
  for p in design['new_public_headers_kept']+['geometry-web/app.js','geometry-guide/公理層-閱讀器.html']:
   require(hashes[F2][p]==wanted[p],'新API/P73/HTML已改');protected[p]=hashes[F2][p]
  arch=json.loads(git('show',F2+':'+ARCH_RECEIPT)[1])
  inputs=[{'path':p,'sha256':digest(rawsets[F2][p].replace(b'\r\n',b'\n'))} for p in sorted(allpaths)]
  closure=digest(json.dumps(inputs,ensure_ascii=False,separators=(',',':')).encode())
  require(closure==EXPECTED_CLOSURE==arch['inputClosureSha256'] and inputs==arch['inputs'] and arch['sourceBaseHead']==P3,'F2架構closure/source綁定不符')
  oldraw=oldreceipt.read_bytes();old=json.loads(oldraw)
  require(old['sha']==F1 and old['exit_code']==0 and old['status']=='完成' and old['proof_matched'] is True and old['semantic_equivalence'] is True and old['errors']==[],'歷史F1原counterproof不是完整真0')
  oldpublic=git('show',OLD_PUBLIC_COMMIT+':'+OLD_PUBLIC_PREFIX+'receipts/F-cumulative-perf-proof.json',sha=F1)[1]
  require(oldpublic==oldraw,'歷史receipt與公開原件不同')
  oldarchive=git('ls-tree',OLD_PUBLIC_COMMIT,'--',OLD_PUBLIC_PREFIX+'raw/F-cumulative-perf-proof.raw.tar.gz',sha=F1)[1].decode().strip();require(bool(oldarchive),'歷史公開raw archive不存在')
  report.update(status='固定來源已核；等待本輪一次獨立純讀審查',source_P3_parent=parents[1],actual_changed_owned=[TARGET],actual_changed_all_601=[TARGET],
   all_601_raw_sha256=hashes,owned_P3_raw_sha256={p:hashes[P3][p] for p in owned},input_modes={p:trees[F2][p]['mode'] for p in sorted(allpaths)},
   tests_F1_blob_ids=tests[F1],tests_P3_blob_ids=tests[P3],tests_F2_blob_ids=tests[F2],protected_explicit_raw_sha256=protected,
   architecture_closure_sha256=closure,architecture_source_P3=P3,exact_runtime_patch_sha256=digest(patch),
   previous_bundle_inventory=before,preparer_source_sha256={p:v['sha256'] for p,v in source.items()},
   historical_F1_counterproof={'sha':F1,'receipt_sha256':digest(oldraw),'public_commit':OLD_PUBLIC_COMMIT,'public_receipt_path':OLD_PUBLIC_PREFIX+'receipts/F-cumulative-perf-proof.json','public_raw_archive_tree_entry':oldarchive,'withdrawn_main':old['withdrawn_main'],'restored_main':old['restored_main'],'not_F2_execution':True})
  report['observed_checkout_after']={'head':git('rev-parse','HEAD')[1].decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all')[1].decode()}
  require(inventory(previous)==before and inventory(HERE)==source,'準備期間舊包或preparer有變')
  shutil.copy2(out/'subcommands.json',out/'SOURCE_CHECK_COMMANDS.json');report['source_check_command_journal_sha256']=filehash(out/'SOURCE_CHECK_COMMANDS.json')
  dump(out/'REBIND_EVIDENCE.json',report)
  bundle.mkdir();dump(bundle/'NOT_READY.json',{'status':'incomplete P3 source preparation'})
  shutil.copytree(previous,bundle/'previous-P2-bundle')
  for n in ('capture.py','validate.py','design-counterfactual.patch','design-product-performance-diff.patch'):shutil.copy2(previous/n,bundle/n)
  shutil.copytree(previous/'counterfactual-templates',bundle/'counterfactual-templates')
  shutil.copytree(HERE,bundle/'PREPARER_SOURCE')
  for n in ('REBIND_EVIDENCE.json','SOURCE_CHECK_COMMANDS.json'):shutil.copy2(out/n,bundle/n)
  shutil.copy2(out/'actual-P3-runtime.patch',bundle/'actual-P3-runtime.patch')
  (bundle/'historical-F1-counterproof.receipt.json').write_bytes(oldraw)
  policy={'schema':'geo261-P3-rebind-policy/1','previous_design_P2':P2,'previous_final_F1':F1,'design_P3':P3,'requested_final_F2':F2,'only_changed_owned_path':TARGET,'exact_P3_parent_patch_sha256':EXPECTED_PATCH,'owned_count':333,'all_architecture_inputs':601,'exclusions':268,'architecture_closure_sha256':closure,'new_gate_added':False,'existing_binding_review_retargeted_once':True,'timing_or_threshold_changed':False}
  dump(bundle/'rebind-policy.json',policy)
  oldgate=(previous/'rebind_gate.py').read_text();newgate=oldgate.replace('P2','P3')
  (bundle/'rebind_gate.py').write_text(newgate)
  oldrun=(previous/'run.py').read_text();newrun=oldrun.replace('不能用設計P2冒充','不能用設計P3冒充')
  require(oldrun.count('不能用設計P2冒充')==1,'原run anchor不唯一')
  (bundle/'run.py').write_text(newrun)
  (bundle/'P3_TOOL_ADAPTATION.patch').write_text(''.join(difflib.unified_diff(oldrun.splitlines(keepends=True),newrun.splitlines(keepends=True),fromfile='previous-P2-bundle/run.py',tofile='run.py'))+''.join(difflib.unified_diff(oldgate.splitlines(keepends=True),newgate.splitlines(keepends=True),fromfile='previous-P2-bundle/rebind_gate.py',tofile='rebind_gate.py')))
  updated=copy.deepcopy(design);updated.update(design_source_sha=P3,previous_design_source_sha=P2,owned_product_hashes={p:hashes[P3][p] for p in wanted},rebind_policy_sha256=filehash(bundle/'rebind-policy.json'),rebind_evidence_sha256=filehash(bundle/'REBIND_EVIDENCE.json'),status='P3 source prepared; one current binding review pending; no F2 runtime')
  dump(bundle/'counterfactual-design.json',updated)
  code={n:filehash(bundle/n) for n in ('run.py','capture.py','validate.py','rebind_gate.py')}
  for n in code:ast.parse((bundle/n).read_bytes(),filename=str(bundle/n))
  templates={i['path']:filehash(bundle/'counterfactual-templates'/i['path']) for i in updated['changed_implementations']}
  require(templates==approved['counterfactual_template_sha256'],'新包六template與舊真審查不同')
  request={'schema':'geo261-P3-binding-static-review/1','status':'pending-independent-review','actual_independent_P3_binding_review_completed':False,'design_source_sha':P3,'design_sha256':filehash(bundle/'counterfactual-design.json'),'rebind_evidence_sha256':updated['rebind_evidence_sha256'],'rebind_policy_sha256':updated['rebind_policy_sha256'],'tool_source_sha256':code,'counterfactual_template_sha256':templates,'reviewer':None,'review_markdown_sha256':None}
  dump(bundle/'P3_REVIEW_REQUEST.json',request)
  dump(bundle/'PREPARATION.json',{'schema':'geo261-F2-P3-rebound-tool-preparation/1','status':'one independent P3 binding review pending; F2 runtime not executed','source_P3':P3,'requested_final_F2':F2,'source_hashes':code,'AST_parsed':True,'product_build_or_execution':False,'performance_verdict':None,'new_gate_added':False,'historical_F1_only':report['historical_F1_counterproof']})
  (bundle/'README.md').write_text((HERE/'BUNDLE_README.md.txt').read_text())
  (bundle/'NOT_READY.json').unlink()
  (bundle/'SHA256SUMS').write_text(''.join(filehash(p)+'  '+str(p.relative_to(bundle))+'\n' for p in sorted(bundle.rglob('*')) if p.is_file() and p!=bundle/'SHA256SUMS'))
  require(inventory(previous)==before and inventory(HERE)==source,'完成時舊包或preparer有變')
  report.update(status='P3來源準備完成；本輪一次獨立純讀審查pending；未量測F2',exit_code=0,bundle=str(bundle),bundle_sha256sums=filehash(bundle/'SHA256SUMS'),runtime_tool_hashes=code)
 except BaseException:
  report.update(status='來源準備失敗；不可執行新包',exit_code=1,traceback=traceback.format_exc())
  if bundle.exists():dump(bundle/'NOT_READY.json',{'status':'failed P3 source preparation; do not execute'})
 finally:
  try:require(inventory(previous)==before and inventory(HERE)==source,'舊包/preparer來源保護失敗')
  except BaseException:
   report.update(status='來源保護失敗',exit_code=1,source_protection_error=traceback.format_exc())
   if bundle.exists():dump(bundle/'NOT_READY.json',{'status':'source protection failed; do not execute'})
  report['commands']=rec.rows;dump(out/'receipt.json',report)
 print(json.dumps({k:report.get(k) for k in ('status','exit_code','bundle','bundle_sha256sums')},ensure_ascii=False));return report['exit_code']
if __name__=='__main__':raise SystemExit(main())
