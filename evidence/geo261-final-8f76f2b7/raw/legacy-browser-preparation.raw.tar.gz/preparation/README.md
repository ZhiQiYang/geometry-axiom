# F2 舊 Chromium154 P73 原子集對照（只準備，未執行）

固定 F2 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`，只跑原 P73 完整子集、原 uiux assertion／predicate 與 golden 的 P73 count。使用 `/usr/bin/chromium`，不撤產品修正、不要求舊版撤回紅、不呼叫額外 controlled callback、不改數值門檻。這是舊版相容性的附加對照，不取代六個正式 Chrome156 browser job，也不是完整 canvas／full golden。

純讀確認 `/usr/bin/chromium` **不是 symlink**，而是 5064-byte Debian shell launcher，最後 exec `/usr/lib/chromium/chromium`。舊原始版本命令退出0，stdout為 `Chromium 154.0.8037.57 built on Debian GNU/Linux 13 (trixie)`；本次未啟動瀏覽器，執行時仍須重新記真版本。

原 runner `final-f-p73-proof-tools/run_p73_proof_adapted.py` 本來接受動態 `--sha`，因此 F2 不需要改 SHA 常數。新副本只做五個 literal 替換：Chrome 路徑、版本命令、brand/version 前置核對、對應環境錯誤訊息，以及附加對照 scope。原 `run_workflow.py`／reaper bytes全保留；原 UI 測試、predicate、workflow、期望結果與 timeout 不改。差異在 `browser-only-adaptation.patch`，原 runner 在 `ORIGINAL_RUNNER.py.txt`；原 frozen 包沒有修改。

**只在正式17項及既定8個 extras全部完成後，由 root 串行執行一次**；scratch與label必須全新：

```bash
python3 -B /workspace/geo261-environment/execute_f_extra.py \
  --label legacy-chromium154-p73-fixed \
  --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 \
  --repo /tmp/g261r3/source-final \
  --outer-root /workspace/geo261-environment/F2-extra-outer -- \
  flock -n /tmp/g261r3/heavy.lock \
  python3 -B /workspace/geo261-environment/F2-legacy-browser-preparation/run_p73_subset_chromium154.py \
  --repo /tmp/g261r3/source-final \
  --sha 8f76f2b7d6f669670e5834310bfc26495b4a4aa6 \
  --scratch /tmp/g261F2legacy \
  --label chromium154-fixed --port 19940 --cdp-port 9580 --expected-exit 0
```

外層 `flock` 使用既有 F2 共用 heavy.lock；driver原本的專用scratch鎖與reaper不改，不要外層再持同一把共用鎖。既有 `execute_f_extra` 保存真argv／退出／完整stdout stderr／版本／F2 clean前後狀態；runner內保存原workflow、各步命令差異、實際Chromium版本與環境、test/app hashes、原CDP結果及截圖。服務會依原 start_local 自動建置或驗鮮；現在沒有啟動。

主要原結果在 `/tmp/g261F2legacy/p73-proof/chromium154-fixed/receipt.json`。除了真退出0，還必須核 `proof_expectation_matches=true`、`source_before==source_after`、partial filter恰 `GEOMETRY_UIUX_FIX_ONLY`、completed=true、failedAssertions=0、P73 count恰等 F2 原golden，且沒有超正式35分鐘。固定原版本的 P73目前應為69，以執行時原golden讀值為準。不能只看最外層0就宣布相容；失敗依原raw分類，不因是optional就填通過。

## 舊 `--dump-dom` 失敗能說什麼

原 `svg_compat_probe.py` 在2026-10-22T10:19:06Z以 Chromium154執行隔離 HTML 的 **original** 函式，30.007916879秒後 watchdog退出124、真程序被SIGKILL為−9，stdout為0 bytes，沒有產生可解析的SVG observation。迴圈在 assert處停止，**Chromium154 fixed階段沒有執行**。完整命令、版本與stderr已複製至 `existing-failed-raw/`。

stderr含 crashpad `mkdir: No such file or directory`／`--database is required`、DBus連線與renderer OOM score權限訊息。這些是實際觀察，**尚未確證30秒不退出的根因**，也不能用它們推導 Chromium154 的 `hidden`／CTM 行為或產品失敗。此次改用原真app/CDP子集，不重跑那個隔離dump-dom、不調長它的timeout，也不事先宣稱已排除其原因。

`PREPARATION.json` 明列未執行，`COMMAND.json` 保存確切argv，`SHA256SUMS`包含新副本、原件、literal diff與既有raw。本包僅為執行準備，不新增產品實作或驗收gate。
