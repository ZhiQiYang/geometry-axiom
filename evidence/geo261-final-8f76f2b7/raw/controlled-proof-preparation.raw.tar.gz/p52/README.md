# F2 P52 runtime 效能修正額外撤回／恢復（尚未執行）

來源固定 F2 `8f76f2b7d6f669670e5834310bfc26495b4a4aa6`，產品修正 P3 `55b9fb6479485361d9e2283a95e4355f5fca76db`。本工具引用同 F2 正式 P52 綠收據作 fixed baseline；其四個 Node 與五個原控制須完整，原工具雜湊須和本包相同。正式收據尚未產生，因此目前沒有量測結果。

額外只跑兩階段：隔離 F2 clone 將 `geometry-web/runtime_version.py` 精確換成 old F `fe863b0374eafd9f1e57ec5107e28a1101804b56` 的 Git blob，再精確還原 F2 blob。每階段各完整原 main／fix／fix／main，每區塊八筆，各組十六筆，真服務、Chrome 與 profile 都重新建立。獨立 main clone 固定 `adbaebf9c73ea6801d7b4d5214e4b846b132923b`。不改原 tests 或 UI predicate，不挑樣本，不增加效能門檻，不自動重跑。

`phase.py` 直接調用本輪 r3 原 `postfix_validate.one`；使用同原 `p52_probe.cjs`（main）及 `p52_cases.cjs` measure（fix）、同原 `P52_REPS=8`。timing 彙總直接從原 `main` 的 AST 擷取 samples／迴圈／medians／timing 四個節點，原判準逐字為 `medians['fix'] <= medians['main']`。各 phase 的真程序退出碼 0／1 僅由這個原 gate 決定；工具／啟動／瀏覽器錯誤為 2。另以原 capture 保存所有 Node 真退出碼；四個 Node 必須真 0、無 failed／exceptions／fatal、每塊 trial 0..7 完整，才可接受 timing 結果。原 `one` 將非零折成 1 的方便值不會被當成 gate 紅。

正式 baseline 預期 0；額外 withdrawn 預期 gate1、restored 預期 gate0。**撤回若仍綠，原始 gate0 如實保存，整份 proof 失敗，仍做恢復階段一次；不把它改成紅、不換門檻或補抽樣。** 這只嘗試證明整項 P3 runtime 修正對此既定 gate 的因果效果，不宣稱每個純效能 component 各自必要。正式完整清單與原五個控制不被這份額外收據取代。

兩個 runtime blob已純讀核對：F2 10,179 bytes／SHA256 `1cafc0868554e9f4028de3c6851d12cb8d9716fec18a6fe379afbbd2e3b14274`；old F 9,588 bytes／SHA256 `5b7261519e70e51f952264c56d0a7cf18e7d4fdeeb8bb033fc391f08339468ea`。P3只改此檔，P3 parent blob也恰等 old F；執行時再從Git驗一次，避免整檔撤回夾帶別項修正。

來源 repo 全程不改；隔離 clone withdrawn 唯一 dirty 檔須為 runtime，完整全樹 status／index 身分、full-index patch、runtime bytes/hash 各階段前後落盤；finally 一律還原 F2 runtime並核來源 repo F2/clean。沿原 capture.py c387 與既有 Linux reaper，保留完整原命令、實際 rc、stdout/stderr、server合併原串流、安全環境、Chrome／Node／Python／cc 真版本、原生 build 原 stdout 與來源 SHA／variant。只設 stack soft16MiB，hard 不降。工具與 baseline 原 bytes/hash 也封存，不 dump 環境秘密。原 `start_local.py` 自行建置／驗鮮原生執行檔，沒有另寫產品 build 流程。

整個 phase 由原 subreaper 包覆，server另用原 reaper；Node直接由原capture啟動獨立session，讓既有timeout的killpg確實涵蓋Node與Chrome，不在Node前再隔一層另開session的reaper。phase內1800秒僅是infra watchdog，會先展開原server finally再結束；外層capture2400秒較晚。任何watchdog都標infra錯誤，不作有效timing紅，沒有改產品效能gate。

正式 F2 全套完成後，root 串行執行；scratch 不得存在，勿外層持同一把鎖：

```bash
python3 -B /workspace/geo261-environment/final-f2-p52-runtime-proof-tools/run.py \
  --repo /tmp/g261r3/source-final \
  --scratch /tmp/g261F2p52runtime \
  --heavy-lock /tmp/g261r3/heavy.lock \
  --baseline-receipt /tmp/g261r3/tools/postfix-8f76f2b7/receipt.json \
  --protocol-dir /tmp/g261r3/tools
```

`/tmp/g261r3/heavy.lock` 須由本輪原 runner建立，工具不另外建立或選另一把鎖。各 block 沿原服務埠18960–18963、CDP9400–9403；同一時間只能執行一個 phase，既有服務占埠會由原入口拒絕，不停止無關程序。主 `<scratch>/receipt.json` 明列兩個 phase 真 rc、原 timing、個別 gate／proof 結果。`PREPARATION.json` 只證明靜態準備，沒有產品執行結果。
