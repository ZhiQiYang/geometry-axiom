#!/usr/bin/env python3
"""正式F2 baseline引用後，隔離撤回runtime一檔／恢復原P52交錯gate。"""
import argparse,datetime,fcntl,hashlib,json,os,platform,resource,sys,traceback
from pathlib import Path
import capture
F2='8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
OLD='fe863b0374eafd9f1e57ec5107e28a1101804b56'
P3='55b9fb6479485361d9e2283a95e4355f5fca76db'
MAIN='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
REL='geometry-web/runtime_version.py'
HASHES={F2:'1cafc0868554e9f4028de3c6851d12cb8d9716fec18a6fe379afbbd2e3b14274',OLD:'5b7261519e70e51f952264c56d0a7cf18e7d4fdeeb8bb033fc391f08339468ea'}
PROTOCOL={'postfix_validate.py':'b9fbcca0eb12e2e25fb5d84eda01038bf8406d1c3a533fa5dfd842e330cf8c5f',
 'p52_measure.py':'738a36b0417e7f5cfa1dcf57fc0d14664650b8285484f866b8ceb0d3a2c8f1a4',
 'p52_probe.cjs':'8c3b4b14ad35082679e4faf229bd66d65a500bd53669c13d8f41e0603e066970',
 'p52_cases.cjs':'6ca75996223e94be0a503e646d58ed928b046854eb0102af309482dc4ac60f66'}
SAFE=('PATH','LANG','LC_ALL','TMPDIR','GITHUB_SHA','GITHUB_WORKSPACE','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','GEO261_REAPER_LOG','CC','CFLAGS','CPPFLAGS','LDFLAGS')
def h(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 for key in ('repo','scratch','heavy-lock','baseline-receipt'):parser.add_argument('--'+key,type=Path,required=True)
 parser.add_argument('--protocol-dir',type=Path,default=Path('/tmp/g261r3/tools'))
 parser.add_argument('--reaper',type=Path,default=Path('/workspace/geo261-environment/reap_children.py'))
 a=parser.parse_args();repo=a.repo.resolve();out=a.scratch.resolve();base=Path(__file__).resolve().parent
 need(not sys.flags.optimize,'禁止 Python optimize')
 need(repo.is_dir() and not out.exists() and out.parent.is_dir() and out.is_relative_to(Path('/tmp')),'需要既有來源與全新 /tmp scratch')
 need(not out.is_relative_to(repo) and not repo.is_relative_to(out) and a.heavy_lock.is_file(),'scratch須在repo外，使用既有共用lock')
 need(h((base/'capture.py').read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','原capture不符')
 need(h(a.reaper.read_bytes())=='7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760','原reaper不符')
 for name,want in PROTOCOL.items():
  need(h((base/'protocol'/name).read_bytes())==want and h((a.protocol_dir/name).read_bytes())==want,'原本輪protocol bytes不符：'+name)
 raw_baseline=a.baseline_receipt.read_bytes();baseline=json.loads(raw_baseline)
 need(baseline['sha']==F2 and baseline['timing']['no_regression'] is True and baseline['timing']['count']=={'main':16,'fix':16},'須引用本F2正式完整P52綠收據')
 need(len(baseline['records'])==4 and all(r['exit']==0 for r in baseline['records']),'正式baseline原四Node未全0')
 need(len(baseline['controls'])==5 and all(r.get('expected_behavior_proved') is True for r in baseline['controls']),'正式baseline五原控制未齊')
 need(baseline['drivers_sha256']==PROTOCOL,'正式baseline工具與本包不相同')
 out.mkdir();(out/'tmp').mkdir();(out/'tools').mkdir()
 frozen={};snapshots={}
 for path in [base/'run.py',base/'phase.py',base/'capture.py',a.reaper,*[base/'protocol'/n for n in PROTOCOL]]:
  rel=Path('protocol')/path.name if path.parent.name=='protocol' else Path(path.name)
  target=out/'tools'/rel;target.parent.mkdir(exist_ok=True);raw=path.read_bytes();target.write_bytes(raw);frozen[str(path)]=h(raw);snapshots[str(target)]=h(raw)
 (out/'formal-baseline-receipt.json').write_bytes(raw_baseline)
 env=dict(os.environ);cleared=[]
 for key in list(env):
  if key.startswith('GEOMETRY_') or key.startswith('P52_') or key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD'):
   cleared.append(key);env.pop(key)
 env.update(PATH='/workspace/geo261-environment/bin:/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
            LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',
            GITHUB_SHA=F2,GITHUB_WORKSPACE=str(repo),TMPDIR=str(out/'tmp'))
 soft,hard=resource.getrlimit(resource.RLIMIT_STACK);need(hard==resource.RLIM_INFINITY or hard>=16384*1024,'hard stack不足')
 resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard));recorder=capture.Recorder(out,env,F2)
 fix=out/'fix';mainrepo=out/'main';fixed=None;phases=[];errors=[];guards=[]
 receipt={'schema':'geo261-F2-P52-runtime-withdrawal-proof/1','sha':F2,'product_P3':P3,'withdrawal_source':OLD,'main':MAIN,
  'scope':'formal baseline reference + withdrawn/restored original timing gate; not individual necessity of every pure perf component',
  'baseline':{'path':str(a.baseline_receipt.resolve()),'sha256':h(raw_baseline),'timing':baseline['timing']},
  'environment':{k:env.get(k) for k in SAFE},'cleared_environment_names':cleared,'platform':platform.platform(),
  'python':sys.version,'python_executable':sys.executable,'stack_before':[soft,hard],'stack_during':[16384*1024,hard],
  'tool_hashes':frozen,'tool_snapshot_hashes':snapshots,'guards':guards,'phases':phases,'errors':errors,'passed':False}
 save(out/'receipt.json',receipt)
 def cmd(argv,cwd=repo,check=True,variant=None,timeout=120):
  return recorder.run(list(map(str,argv)),cwd=cwd,check=check,timeout=timeout,source_sha=F2,source_variant=variant)
 def git(path,*parts):return cmd(['git',*parts],path)[1]
 def guard(path,label,sha,withdrawn=False):
  head=git(path,'rev-parse','HEAD').decode().strip();status=git(path,'status','--porcelain=v1','--untracked-files=all').decode()
  diff=git(path,'diff','--binary','--full-index','--no-ext-diff','--no-color','HEAD');(out/(label+'.patch')).write_bytes(diff)
  row={'label':label,'path':str(path),'head':head,'status':status,'tree_index_sha256':h(git(path,'ls-files','--stage','-z')),
       'runtime_sha256':h((path/REL).read_bytes()),'diff_sha256':h(diff)};guards.append(row)
  need(head==sha and status==(' M '+REL+'\n' if withdrawn else '') and not git(path,'diff','--cached','--name-only'),label+':非預期全樹變更')
  if sha==F2:need(row['runtime_sha256']==HASHES[OLD if withdrawn else F2],label+':runtime bytes不符')
  return row
 lock=a.heavy_lock.open('a+b')
 try:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);guard(repo,'source-before',F2)
  fixed=git(repo,'show',F2+':'+REL);old=git(repo,'show',OLD+':'+REL)
  need(h(fixed)==HASHES[F2] and h(old)==HASHES[OLD],'兩個Git runtime blob不符')
  changed=git(repo,'diff-tree','--no-commit-id','--name-only','-r',P3).decode().splitlines()
  need(changed==[REL] and git(repo,'show',P3+'^:'+REL)==old and git(repo,'show',P3+':'+REL)==fixed,'整檔撤回並非恰只撤P3')
  (out/'runtime-F2.py.txt').write_bytes(fixed);(out/'runtime-old-F.py.txt').write_bytes(old)
  for argv in (['/workspace/geo261-environment/bin/google-chrome','--version'],['node','--version'],[sys.executable,'--version'],['cc','--version']):cmd(argv)
  for name,sha,path in (('fix',F2,fix),('main',MAIN,mainrepo)):
   cmd(['git','clone','--shared','--no-hardlinks','--no-checkout',repo,path],out)
   git(path,'-c','core.autocrlf=false','checkout','--detach',sha);guard(path,name+'-created',sha)
  for index,(name,withdrawn) in enumerate((('withdrawn',True),('restored',False))):
   (fix/REL).write_bytes(old if withdrawn else fixed);guard(fix,name+'-before',F2,withdrawn);guard(mainrepo,name+'-main-before',MAIN)
   phaseout=out/name;phaseout.mkdir()
   request={'sha':F2,'variant':name+'-runtime-only','out':str(phaseout),'tmp':str(phaseout/'work'/'tmp'),
            'protocol':str(out/'tools'/'protocol'),'reaper':str(out/'tools'/a.reaper.name),'main_repo':str(mainrepo),'fix_repo':str(fix)}
   save(phaseout/'request.json',request)
   child=dict(env,GEO261_REAPER_LOG=str(phaseout/'phase-reaper.jsonl'));recorder.env=child
   try:
    row,stdout,stderr=cmd([sys.executable,'-B',out/'tools'/a.reaper.name,sys.executable,'-B',out/'tools'/'phase.py',phaseout/'request.json'],out,check=False,variant=request['variant'],timeout=2400)
   finally:recorder.env=env
   phase={'phase':name,'expected_gate_exit':1 if withdrawn else 0,'command_result':row,'passed':False};phases.append(phase)
   actual=json.loads((phaseout/'receipt.json').read_text());phase['receipt']=actual
   reaped=[json.loads(s) for s in (phaseout/'phase-reaper.jsonl').read_text().splitlines()]
   valid=actual.get('completed') is True and not actual['errors'] and row['actual_process_returncode'] in (0,1) and row['actual_process_returncode']==actual['gate_exit']
   need(valid and reaped[-1].get('event')=='完成' and reaped[-1].get('primary_returncode')==row['actual_process_returncode'],name+':infra/Node錯誤不能作gate結果')
   phase['passed']=row['actual_process_returncode']==phase['expected_gate_exit']
   if not phase['passed']:errors.append(name+':原gate真退出碼不符合自證預期；不重跑/改門檻/挑樣本')
   guard(fix,name+'-after',F2,withdrawn);guard(mainrepo,name+'-main-after',MAIN);save(out/'receipt.json',receipt)
  receipt['passed']=len(phases)==2 and all(p['passed'] for p in phases) and not errors
 except BaseException:errors.append(traceback.format_exc())
 finally:
  try:
   if fixed is not None and (fix/REL).is_file():(fix/REL).write_bytes(fixed);guard(fix,'fix-final-restored',F2)
  except BaseException:errors.append(traceback.format_exc())
  try:guard(repo,'source-after',F2)
  except BaseException:errors.append(traceback.format_exc())
  for path,digest in frozen.items():
   if h(Path(path).read_bytes())!=digest:errors.append('工具bytes執行中改變：'+path)
  for path,digest in snapshots.items():
   if h(Path(path).read_bytes())!=digest:errors.append('實際執行工具snapshot改變：'+path)
  if h(a.baseline_receipt.read_bytes())!=h(raw_baseline):errors.append('正式baseline收據執行中改變')
  receipt['passed']=receipt['passed'] and not errors;receipt['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  save(out/'receipt.json',receipt);resource.setrlimit(resource.RLIMIT_STACK,(soft,hard));lock.close()
 print(json.dumps({'passed':receipt['passed'],'phases':[(p['phase'],p['command_result']['actual_process_returncode'],p['passed']) for p in phases],'errors':errors},ensure_ascii=False))
 return 0 if receipt['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
