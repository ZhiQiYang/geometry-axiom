# P73 真 app controlled callback 自證（尚未執行）

本工具只驗 F `fe863b0374eafd9f1e57ec5107e28a1101804b56` 的一個受控 callback 時點。它不是完整 P73 workflow，也不取代正式 canvas、原 subset 或舊 isolated SVG 診斷。先前 F subset 的撤回仍為 0，沒有證明原 bug 被該 workflow 殺死；本工具不更寫那份紅收據。

`probe.cjs` 擷取同 F `geometry-web/cdp_test.js` 的原 CDP bootstrap，沿用真 Chrome 啟動、埠占用／擁有權檢查、頁面 ready 與可信滑鼠輸入。由同 F `uiux_review_test.js:219` 精確抽取唯一原訊息與 predicate，使用同 F `cdp_helpers.makeCheck({prefix:'P73 ',throwOnFail:true})` 執行，不改原測試檔或 predicate。

每階段啟全新真服務與 Chrome profile，以真 `api('line space 990')` → `renderObjects()` → `enterFocus('space',990)` 建空間，可信點 `[data-ss-tab="plan"]`，等待兩次 RAF，再**明確呼叫一次實際全域 `syncSpacePlanAnnotations()`**。不複製函式作 actual、不替換函式、不改 hidden／viewBox／樣式／SVG 子節點來造紅。會保存 callback 前後的原 predicate、四項診斷值、hidden attribute／property／computed display／CTM、完整 SVG、實際 callback 原碼、Chrome argv 與截圖。若 callback 前 predicate 已紅，或自然時序未能在明確 callback 後造成原具名紅，工具如實失敗，不另加等待／改 DOM／重跑挑綠。自然 app 回呼仍照原樣執行；「一次」指本工具顯式呼叫次數，不宣稱整段生命週期只發生一次 callback。

順序為 fixed0 → withdrawn1 → restored0，各服務／CDP 埠相異。撤回僅將 `0c1bbf99` 的原四行 SVG hidden guard 精確換回原一行 `svg.hidden`，原 scale 防護與其他 app 原碼都不變；完整 full-index patch 及每階段 app/test/helper hash 會落盤。原來源 repo 前後必須 F 且 clean；隔離 clone 的 withdrawn 階段明列 `geometry-web/app.js` dirty，最後 finally 一律精確還原 F app bytes。

新工具重用未改原 `capture.py`（SHA256 `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762`）記所有子命令 argv/cwd/真 rc/完整 stdout stderr/時間/安全環境/來源 F 與 dirty variant。server 長期程序另存 command、真 rc、raw streams、原 subreaper 日誌；Node 亦包同 subreaper。只設 16MiB soft stack，保留 hard limit。工具保存 Chrome／Node／Python／cc 真版本。環境只列 allowlist，不 dump credentials。所有 watchdog 僅是工具上限，不能當有效產品失敗或新的 P73 判準。

`start_local.py` 是 CI 的真 Linux 入口；會依原 registry 建置或沿用並驗鮮 core／bridge／model-base，不必另跑 npm。三階段共用 checkout 外專用 native 產物目錄；web guard 變動仍由每個全新服務各自計 runtime 來源版本。每個 ready probe 都使用原 `runtime_version.py --probe`，完整輸出均保留。這些程序目前**沒有執行**。

root 在正式工作結束後串行執行；不要外層先持有同一把 lock：

```bash
python3 -B /workspace/geo261-environment/final-f-p73-controlled-tools/run.py \
  --repo /tmp/g261r2/source-final \
  --sha fe863b0374eafd9f1e57ec5107e28a1101804b56 \
  --scratch /tmp/g261Fp73controlled \
  --heavy-lock /tmp/g261r2/heavy.lock
```

scratch 必須不存在。預設服務埠 19920/19921/19922、CDP 埠 9560/9561/9562；可經 `--service-port`／`--cdp-port` 指定另一組起點，已有 listener 時會拒絕，不停止其他服務。Chrome 預設 `/workspace/geo261-environment/bin/google-chrome`。外層仍可用既有 run_recorded 封存整條指令；工具內部自行使用既有 reaper，不需要新等待器或審查 gate。

主收據 `<scratch>/receipt.json` 的 `passed` 只在真 0/1/0、唯一原訊息紅、錯因為新增 SVG shape、無額外 browser 例外、reaper 完整結束、來源／工具 guard 均成立時為 true。未實際執行前的 `PREPARATION.json` 僅代表工具靜態準備。
