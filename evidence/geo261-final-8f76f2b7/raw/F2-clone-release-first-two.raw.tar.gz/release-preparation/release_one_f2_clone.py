#!/usr/bin/env python3
"""候選：每次只釋放一個已公開封存、乾淨可重建的固定 F2 clone；本檔準備時未執行。"""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import traceback

F2='8f76f2b7d6f669670e5834310bfc26495b4a4aa6'
ROOT=Path('/workspace/geometry-axiom')
SOURCE_FINAL=Path('/tmp/g261r3/source-final')
LOCK=Path('/tmp/g261r3/heavy.lock')
OUTPUT_ROOT=Path('/workspace/geo261-environment/F2-clone-release-records')
REMOTE_REF='refs/remotes/origin/architecture/geo261-integration-20261016'
EVIDENCE=PurePosixPath('evidence/geo261-final-8f76f2b7')
# 路徑取自 frozen proof actual source，不接受任意 --clone／--label。
ALLOW={
 'p73':('/tmp/g261F2p73controlled/checkout','F2-P73-controlled','/tmp/g261F2p73controlled/receipt.json'),
 'p52':('/tmp/g261F2p52runtime/fix','F2-P52-runtime','/tmp/g261F2p52runtime/receipt.json'),
 'reader':('/tmp/g261F2reader/source','F2-reader','/tmp/g261F2reader/proof/receipt.json'),
 'checker':('/tmp/g261F2checker/checkout','F2-checker','/tmp/g261F2checker/receipt.json'),
 'perf':('/tmp/g261F2perf/source-counterfactual','F2-Cperf','/tmp/g261F2perf/receipt.json'),
}

def require(ok,message):
 if not ok:raise RuntimeError(message)

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def filehash(path):
 value=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
 return value.hexdigest()

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--proof',required=True,choices=sorted(ALLOW))
 parser.add_argument('--published-commit',required=True,help='該 label 已正常 push 的完整 commit；不從準備稿猜填')
 parser.add_argument('--out',type=Path,required=True,help='全新 /workspace/geo261-environment/F2-clone-release-records/ 子目錄')
 args=parser.parse_args()
 require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE') in (None,'','0'),'不可用 Python optimize')
 require(re.fullmatch('[0-9a-f]{40}',args.published_commit) is not None,'須明列實際已 push 的40碼 commit')
 literal,label,inner_literal=ALLOW[args.proof]
 clone=Path(literal);inner=Path(inner_literal);out=args.out.resolve()
 require(args.out.is_absolute() and out.is_relative_to(OUTPUT_ROOT) and out!=OUTPUT_ROOT and not out.exists(),'out須是固定records root下全新獨立子目錄')
 require(clone!=SOURCE_FINAL and clone!=ROOT and clone.resolve()==clone and not clone.is_symlink(),'clone路徑不得改指其他樹')
 require(clone.is_dir() and (clone/'.git').is_dir() and not (clone/'.git').is_symlink() and not os.path.ismount(clone),'需要完整獨立clone，拒絕symlink/mount/worktree')
 require(LOCK.is_file(),'須保留既有r3 heavy lock')
 require(inner.is_file(),'原proof收據不存在')
 # 不由此候選推論 proof 通過；只要求原工具已結束且原結果正常公開，紅也不改寫。
 original_receipt=inner.read_bytes();proof=json.loads(original_receipt)
 require(proof.get('sha')==F2,'原收據不是F2')
 terminal=(proof.get('status') in ('完成','失敗','中斷') and 'exit_code' in proof) if args.proof=='perf' else bool(proof.get('ended_utc') or proof.get('finished_utc'))
 require(terminal,'原proof尚未留下完整終態，不得釋放')
 out.mkdir(parents=True)
 git_env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
 report={'schema':'geo261-F2-one-completed-clone-release/1','status':'驗證中','sha':F2,'proof':args.proof,'clone':literal,'label':label,'published_commit':args.published_commit,'output':str(out),'started_utc':now(),'commands':[],'removed':False,'deletion_attempted':False,'errors':[],'scope':'Only the single fixed disposable clone; original proof raw/tools/outputs and source-final remain. No product result is changed.'}
 def save():
  (out/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 def run(argv,cwd,tag):
  folder=out/'commands'/('%03d-'%len(report['commands'])+tag);folder.mkdir(parents=True)
  row={'argv':list(map(str,argv)),'cwd':str(cwd),'started_utc':now()};report['commands'].append(row);save()
  process=None
  try:
   with (folder/'stdout.bin').open('wb') as stdout,(folder/'stderr.bin').open('wb') as stderr:
    process=subprocess.Popen(row['argv'],cwd=cwd,env=git_env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
    row['timeout_expired']=False
    try:process.wait(timeout=300)
    except subprocess.TimeoutExpired:
     row['timeout_expired']=True;process.kill();process.wait()
  finally:
   row.update(actual_exit=None if process is None else process.returncode,finished_utc=now(),stdout=str(folder/'stdout.bin'),stderr=str(folder/'stderr.bin'),stdin='empty',cleared_inherited_git_environment_names=[k for k in os.environ if k.startswith('GIT_')])
   (folder/'command.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');save()
  require(row['actual_exit']==0 and not row['timeout_expired'],tag+': Git原命令非0或逾時')
  return (folder/'stdout.bin').read_bytes()
 def git(cwd,tag,*parts):return run(['git',*parts],cwd,tag)
 def clean(tag):
  require(clone.resolve()==clone and clone.is_dir() and not clone.is_symlink() and not os.path.ismount(clone),'clone路徑已改變')
  require(git(clone,tag+'-head','rev-parse','HEAD').decode().strip()==F2,tag+': HEAD不是F2')
  require(git(clone,tag+'-status','-c','core.fsmonitor=false','-c','core.untrackedCache=false','status','--porcelain=v1','--untracked-files=all')==b'',tag+': 整棵status非空')
  require(git(clone,tag+'-ignored','ls-files','--others','--ignored','--exclude-standard','-z')==b'',tag+': ignored檔非空')
 def published(tag):
  raw_rel=EVIDENCE/'raw'/(label+'.raw.tar.gz')
  normalized_rel=EVIDENCE/'receipts'/(label+'.json')
  raw=ROOT/str(raw_rel)
  require(raw.is_file() and not raw.is_symlink(),tag+': 原raw archive不存在')
  git(ROOT,tag+'-F2-ancestor','merge-base','--is-ancestor',F2,'HEAD')
  git(ROOT,tag+'-publish-in-root','merge-base','--is-ancestor',args.published_commit,'HEAD')
  # 正常push會更新origin tracking ref；此處驗已記錄公開關係，不發送網路或push。
  git(ROOT,tag+'-publish-in-origin','merge-base','--is-ancestor',args.published_commit,REMOTE_REF)
  progress=json.loads(git(ROOT,tag+'-progress','show','HEAD:'+str(EVIDENCE/'PROGRESS.json')))
  require(progress.get('tested_sha')==F2 and any(x.get('label')==label and x.get('archive')=='raw/'+label+'.raw.tar.gz' for x in progress.get('entries',[])),tag+': root HEAD缺對應已封存progress')
  git(ROOT,tag+'-raw-readable','cat-file','-e','HEAD:'+str(raw_rel))
  current_blob=git(ROOT,tag+'-raw-head-blob','rev-parse','HEAD:'+str(raw_rel)).decode().strip()
  published_blob=git(ROOT,tag+'-raw-published-blob','rev-parse',args.published_commit+':'+str(raw_rel)).decode().strip()
  local_blob=git(ROOT,tag+'-raw-local-blob','hash-object','--no-filters',str(raw)).decode().strip()
  require(current_blob==published_blob==local_blob,tag+': 原raw與root HEAD／已push commit不是同一bytes')
  saved_receipt=git(ROOT,tag+'-published-receipt','show','HEAD:'+str(normalized_rel))
  require(saved_receipt==original_receipt and inner.read_bytes()==original_receipt,tag+': 原收據與已公開copy不符／變動')
  receipt_blob=git(ROOT,tag+'-published-receipt-blob','rev-parse',args.published_commit+':'+str(normalized_rel)).decode().strip()
  require(receipt_blob==git(ROOT,tag+'-head-receipt-blob','rev-parse','HEAD:'+str(normalized_rel)).decode().strip(),tag+': receipt不屬明列已push commit')
  return {'path':str(raw),'relative_path':str(raw_rel),'git_blob':current_blob,'bytes':raw.stat().st_size,'sha256':filehash(raw),'receipt_sha256':hashlib.sha256(saved_receipt).hexdigest(),'normal_push_evidence':'caller-specified actual publish commit reachable from recorded origin branch and root HEAD; no fresh network query'}
 save()
 with LOCK.open('a+b') as lock:
  try:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   report['published_before']=published('before');clean('before-inventory')
   paths=git(clone,'tracked','ls-files','-z').split(b'\0')
   inventory=[]
   for raw_relative in filter(None,paths):
    relative=os.fsdecode(raw_relative);parts=PurePosixPath(relative)
    require(not parts.is_absolute() and '..' not in parts.parts,'tracked相對路徑不可越界')
    path=clone/relative;mode=path.lstat().st_mode
    if stat.S_ISLNK(mode):
     target=os.readlink(path);body=os.fsencode(target)
     row={'path':relative,'kind':'symlink','target':target,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    else:
     require(stat.S_ISREG(mode),'tracked非regular/symlink；保留現場')
     require(path.resolve().is_relative_to(clone),'tracked實體檔不可經父層symlink越界')
     row={'path':relative,'kind':'regular','bytes':path.stat().st_size,'sha256':filehash(path)}
    row['mode']=stat.S_IMODE(mode);inventory.append(row)
   inventory_file=out/'tracked-sha256.json'
   inventory_file.write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
   report.update(tracked_files=len(inventory),tracked_bytes=sum(x['bytes'] for x in inventory),tracked_inventory=str(inventory_file),tracked_inventory_sha256=filehash(inventory_file));save()
   # 原流程的完整tracked實體bytes數與hash已落盤；再核同一source/ignored/公開raw。
   clean('after-inventory');report['published_after']=published('after')
   require(report['published_before']==report['published_after'],'原raw或已公開收據在盤點期間改變')
   require(SOURCE_FINAL.is_dir(),'正式source-final不可缺失')
   report.update(status='已核對單clone，開始釋放',deletion_attempted=True);save()
   shutil.rmtree(clone)
   require(not clone.exists(),'clone未完整移除')
   report.update(removed=True,status='完成：僅固定單clone已移除',finished_utc=now(),source_final_retained=SOURCE_FINAL.is_dir(),original_raw_retained=Path(report['published_after']['path']).is_file(),original_proof_receipt_retained=inner.is_file());save()
   print(json.dumps(report,ensure_ascii=False));return 0
  except BaseException:
   report['errors'].append(traceback.format_exc());report.update(status='未完成；保留原始輸出與所有已錄raw',finished_utc=now());save()
   print(json.dumps({'receipt':str(out/'receipt.json'),'removed':report['removed'],'deletion_attempted':report['deletion_attempted'],'errors':report['errors']},ensure_ascii=False),file=sys.stderr)
   return 1
  finally:
   fcntl.flock(lock,fcntl.LOCK_UN)
if __name__=='__main__':raise SystemExit(main())
