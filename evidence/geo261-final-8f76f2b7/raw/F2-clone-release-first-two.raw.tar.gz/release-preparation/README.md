# F2 已完成 clone 單項釋放候選

僅準備，尚未執行。現在不執行 Git、tracked來源散列、刪除或產品；供 extras 日後已公開且 `/tmp` 餘裕不足時由 root 使用。原 `/workspace/geo261-environment/release_completed_clones.py` 不改。本候選沒有 publish、push、force push、產品測試或新的產品判準。

固定 F2：`8f76f2b7d6f669670e5834310bfc26495b4a4aa6`。每次只選以下一個，獨立全新 out：

| --proof | 唯一可移除 clone | 已公開 label |
|---|---|---|
| p73 | `/tmp/g261F2p73controlled/checkout` | `F2-P73-controlled` |
| p52 | `/tmp/g261F2p52runtime/fix` | `F2-P52-runtime` |
| reader | `/tmp/g261F2reader/source` | `F2-reader` |
| checker | `/tmp/g261F2checker/checkout` | `F2-checker` |
| perf | `/tmp/g261F2perf/source-counterfactual` | `F2-Cperf` |

P52 的 frozen `final-f2-p52-runtime-proof-tools/run.py:54,82` 實際是 `fix`，不是 `checkout`；`main` clone 保留。其餘四個路徑已由各 frozen run 實際程式和 `F2-extras-orchestration/EXECUTION_PLAN.json` 唯讀核對，沒有猜目錄。若 root 最終實際 publisher label 與計畫不同，本候選會拒絕；先改新候選的固定mapping，不對既有標籤造假。

候選沿既有 release 流程，將來執行時才做：

1. 原 proof 收據須為 F2 且已有原工具終態；不把紅燈改綠，也不要求新產品 gate。取得同一把 `/tmp/g261r3/heavy.lock`，忙碌就保留 clone 返回。
2. root 必須填該項真實正常 push 的完整 commit。驗它與 F2 都可由 root HEAD 到達，且該 publish commit 已在記錄的 origin 整合分支 ancestry。這是已有 push 的本機 tracking 證據，不是假稱新查網路；本工具不 fetch、不 push。
3. 原 raw archive 必須仍在 root evidence；root HEAD 的 PROGRESS、normalized receipt 與同 label archive 都存在，原 receipt 逐 bytes 相同。`cat-file -e HEAD:<raw>` 驗物件可讀，`rev-parse`／`hash-object --no-filters` 比對 root HEAD、明列已 push commit 與本機完整 archive 的同一 Git blob，另錄原 archive SHA256／bytes。
4. clone 必須原固定實體目錄、非symlink／mount、HEAD=F2、整棵 tracked/untracked status空、ignored空。`git ls-files -z` 的所有 tracked regular檔／symlink，逐項保存 bytecount、SHA256、mode（symlink另保存target）到獨立 out 的 `tracked-sha256.json`。這與既有流程相同，是完整 tracked inventory，並不額外複製整個可由公開 F2 重建的 source tree。
5. inventory 落盤後，再核 HEAD／整棵 status／ignored 全空，且公開原 raw／收據未變，才只對該一個固定 clone 呼叫 `shutil.rmtree`。原 raw、tools、proof output、source-final、main參照 clone、bin/tmp 等其餘樹一律保留。所有 Git argv／cwd／真 rc／stdout／stderr 與刪除前後狀態另錄；拒絕或中途失敗保留原輸出，不刪其它樹。

範例只作命令稿，**現在不要執行**；`<實際正常push的40碼commit>` 必須換成當項已公開真值，不能填未 push commit：

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B \
  /workspace/geo261-environment/F2-clone-release-preparation/release_one_f2_clone.py \
  --proof p73 \
  --published-commit '<實際正常push的40碼commit>' \
  --out /workspace/geo261-environment/F2-clone-release-records/p73-unique
```

其餘四項只換 `--proof`、實際 publish commit 與全新 out；不接受任意 clone/path/label。不要在正在使用該 clone 的 proof、正式驗收或其它重型工作期間執行；此候選會持同一 heavy lock。它不更新舊收據或自動發佈釋放記錄。
