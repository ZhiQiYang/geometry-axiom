# F2 首兩個 clone 釋放：單一progress發佈準備

只準備，尚未執行Git／publisher／產品，也未遞迴讀取或散列產品source。原資料不改。

已真讀原收據、完整原launcher stdout/stderr與Git command metadata：

- `p73-2158`：origin tracking ancestry守門原Git rc1，`removed=false`、`deletion_attempted=false`；原3筆command的0/0/1及全部raw保留。
- `tracking-refresh-2159`：原fetch真rc0，原argv／stdout／stderr保留。
- `p73-refreshed-2159`、`p52-2201`：各29筆Git command真rc0，無timeout；原最終receipt `removed=true`、errors=[]，完整原stdout JSON與receipt相同、stderr空；各24,012個tracked、1,478,874,125 bytes，inventory自身hash吻合原收據。只以exists確認兩個目標clone已不在，沒有掃描剩餘產品clone。

原proof raw／tools／output與正式source-final按兩份成功收據保留；這是磁碟維護收據，沒有新產品測試或產品結果。本次 `--receipt` 使用原F2 P52釋放成功receipt，不冒充產品收據。`--next F2-checker`。

`publisher-argv.json`及`publisher.sh`是同一個確切publisher命令，label固定 `F2-clone-release-first-two`。輸入逐檔明列原release腳本/README兩檔及目前release-records全部195檔，包含首次失敗、fetch、兩次成功、所有Git raw及兩份tracked inventory，共197個原檔；加本準備包metadata。原資料沒有篩掉任何檔案，inventory記錄每檔bytes/SHA256。用逐檔argv避免日後其它release新檔混入此固定清單。

root待reader正常push結束後，可自行執行唯一命令（本準備工作未執行）：

```bash
sh /workspace/geo261-environment/F2-clone-release-publication-prepared/publisher.sh
```

此命令會真的打包、更新同F2 PROGRESS、英文commit並普通push；不新增approval gate。發佈前若原資料被改動，不要覆寫本inventory，另保留新版本。此準備包不自動執行Git、不重跑產品、不刪除資料。
