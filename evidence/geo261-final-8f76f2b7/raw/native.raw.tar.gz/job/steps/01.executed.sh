ulimit -s 16384
# The Windows GDI harness is unavailable on Linux; the runner reports it.
python3 tests/run_all.py --build
