import argparse, datetime, gzip, hashlib, json, os, pathlib, resource, subprocess, time, signal
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--root',default='/tmp/r02-ui1');p.add_argument('--seconds',type=int);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
cmd=a.command
if cmd and cmd[0]=='--':cmd=cmd[1:]
if not cmd:raise SystemExit('command required')
out=pathlib.Path('/workspace/r02-ui1-evidence')/a.name;out.mkdir(parents=True,exist_ok=False)
def git(*args):return subprocess.check_output(['git','-C',a.root,*args]).decode().strip()
patch=subprocess.check_output(['git','-C',a.root,'diff','--binary','HEAD'])
if patch:
    with gzip.open(out/'source.patch.gz','wb') as f:f.write(patch)
meta={'command':cmd,'cwd':a.root,'sha':git('rev-parse','HEAD'),'status':git('status','--porcelain'),'patchSha256':hashlib.sha256(patch).hexdigest(),'startUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeoutSeconds':a.seconds,'environment':{k:v for k,v in os.environ.items() if k.startswith('GEOMETRY_') or k in ['CC','TMPDIR','LANG','LC_ALL']},'uname':list(os.uname()),'stackBytes':16777216}
(out/'result.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
def child():resource.setrlimit(resource.RLIMIT_STACK,(16777216,resource.getrlimit(resource.RLIMIT_STACK)[1]))
start=time.monotonic()
with gzip.open(out/'stdout.gz','wb') as stdout,gzip.open(out/'stderr.gz','wb') as stderr:
    proc=subprocess.Popen(cmd,cwd=a.root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=child,start_new_session=True)
    import threading
    def drain(source,target):
        while True:
            block=source.read1(65536)
            if not block:break
            target.write(block);target.flush()
    threads=[threading.Thread(target=drain,args=(proc.stdout,stdout)),threading.Thread(target=drain,args=(proc.stderr,stderr))]
    for t in threads:t.start()
    try:code=proc.wait(timeout=a.seconds)
    except subprocess.TimeoutExpired:
        meta['timeout']=True;code=124
        os.killpg(proc.pid,signal.SIGINT)
        try:proc.wait(timeout=15)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    for t in threads:t.join()
meta.update(exit=code,elapsedSeconds=time.monotonic()-start,endUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
meta['rawSha256']={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['stdout.gz','stderr.gz']}
(out/'result.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'receipt':str(out),'sha':meta['sha'],'exit':code,'seconds':meta['elapsedSeconds']}),flush=True)
for n in ['stdout.gz','stderr.gz']:
    with gzip.open(out/n,'rt',errors='replace') as f:lines=f.readlines()
    print(n+':\n'+''.join(lines[-16:]))
raise SystemExit(code)
