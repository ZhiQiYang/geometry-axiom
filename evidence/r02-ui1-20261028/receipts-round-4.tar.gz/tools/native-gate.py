"""Run the unchanged native census and durably collect each completed suite log."""
import datetime,gzip,hashlib,io,json,os,pathlib,signal,subprocess,sys,tarfile,threading,time
root=pathlib.Path.cwd();out=pathlib.Path('/workspace/r02-ui1-evidence/native-final-support');out.mkdir(exist_ok=False)
logs=pathlib.Path('/tmp/geometry-tests/run_all-logs')
if logs.exists() and any(logs.iterdir()):raise SystemExit('Refuse to overwrite previous native suite logs')
command=['python3','tests/run_all.py','--build','--update-expected'];stop=threading.Event();files={};errors=[]
started=time.monotonic();meta={'command':command,'sha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'startUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeoutSeconds':2100,'environment':{k:v for k,v in os.environ.items() if k.startswith(('GEOMETRY_','MUTATE_')) or k in ('LANG','LC_ALL','PYTHONUNBUFFERED')},'logCollection':'Original completed suite logs, JSON and unittest logs appended once to one persistent gzip tar; no assertions or source changes.'}
(out/'started.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
def collect():
 try:
  with gzip.open(out/'suite-logs.tar.gz','wb') as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
   def add(p):
    if p.name in files or not p.is_file():return
    raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=int(p.stat().st_mtime);tar.addfile(info,io.BytesIO(raw));files[p.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};gz.flush()
   seen={}
   while not stop.wait(1):
    for p in logs.glob('*.log'):
     if p.name.endswith('.unittest.log') or p.name in files:continue
     stamp=(p.stat().st_size,p.stat().st_mtime_ns)
     if seen.get(p.name)==stamp:
      add(p);add(p.with_suffix('.json'));add(p.with_suffix('.unittest.log'))
     else:seen[p.name]=stamp
   for p in sorted(logs.glob('*')):add(p)
 except BaseException as e:errors.append(repr(e))
t=threading.Thread(target=collect);t.start();child=subprocess.Popen(command,start_new_session=True);code=1
try:
 try:code=child.wait(timeout=2100)
 except (subprocess.TimeoutExpired,KeyboardInterrupt) as e:
  meta['timeout']=isinstance(e,subprocess.TimeoutExpired);meta['interrupted']=isinstance(e,KeyboardInterrupt)
  os.killpg(child.pid,signal.SIGINT)
  try:child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  code=124 if meta['timeout'] else 130
finally:
 stop.set();t.join();meta.update(exit=code,processExit=child.returncode,elapsedSeconds=time.monotonic()-started,endUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),collectionErrors=errors,files=files)
 archive=out/'suite-logs.tar.gz'
 if archive.exists():meta['archiveSha256']=hashlib.sha256(archive.read_bytes()).hexdigest();meta['archiveBytes']=archive.stat().st_size
 (out/'receipt.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print('R02_NATIVE_GATE '+json.dumps({k:v for k,v in meta.items() if k not in ('files','environment')},ensure_ascii=False),flush=True)
raise SystemExit(code if not errors else 2)
