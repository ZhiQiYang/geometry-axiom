#!/usr/bin/env python3
"""Prepare finite R02 metadata outside the source tree; never run or alter a judge."""
import argparse
import ast
import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

DIR = 'geometry-core/domain-decoupling/'
TOOLS = ['tests/architecture_contract.py', 'tests/test_architecture_contract.py', 'tests/test_product_architecture.py']
H = {
    'geometry-web/panel-fill-adapter.js': 'UI-1 native wire and candidate lifecycle host adapter; delegates geometry to the native engine',
    'geometry-web/panel-fill-workspace.js': 'UI-1 existing face inspector definitions form and native result presentation host',
}
TEST = 'geometry-web/panel_fill_workflow_test.js'
REFRESH = {'geometry-web/cdp_test.js', 'geometry-web/room_outline_test.js', 'geometry-web/space_model_test.js'}
ARTIFACTS = ['product-architecture.json', 'product-architecture-scan.json', 'PRODUCT-ARCHITECTURE.md', 'product-architecture-receipt.json']

def need(condition, text):
    if not condition: raise ValueError(text)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def lf(raw): return raw.replace(b'\r\n', b'\n')
def write(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])
def closure(rows): return sha(json.dumps(rows, ensure_ascii=False, separators=(',', ':')).encode())

def inspect(root, source_sha):
    need(len(source_sha)==40 and all(c in '0123456789abcdef' for c in source_sha), 'Full lowercase source SHA required')
    need(git(root,'rev-parse','HEAD').decode().strip()==source_sha, 'HEAD differs from requested source SHA')
    manifest_raw=(root/DIR/'product-architecture.json').read_bytes()
    need(lf(manifest_raw)==lf(git(root,'show',source_sha+':'+DIR+'product-architecture.json')), 'Manifest differs from fixed Git blob')
    manifest=json.loads(manifest_raw)
    tree=ast.parse((root/TOOLS[0]).read_text())
    suffixes=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LANGUAGES' for t in n.targets))
    discovered=set(manifest.get('sourceFiles',[]))
    for directory in manifest['sourceRoots']:
        for path in (root/directory).rglob('*'):
            need(not path.is_symlink(), 'Source alias encountered: '+str(path))
            if path.is_file() and path.suffix.lower() in suffixes: discovered.add(path.relative_to(root).as_posix())
    tracked=set(git(root,'ls-tree','-r','-z','--name-only',source_sha,'--',*manifest['sourceRoots'],*manifest.get('sourceFiles',[])).decode().strip('\0').split('\0'))
    tracked={x for x in tracked if Path(x).suffix.lower() in suffixes}
    need(discovered==tracked, 'Disk/Git executable inventory mismatch')
    rows=[]
    for name in sorted(discovered):
        raw=(root/name).read_bytes()
        need(lf(raw)==lf(git(root,'show',source_sha+':'+name)), 'Source differs from fixed Git blob: '+name)
        rows.append({'path':name,'sha256':sha(lf(raw))})
    tools={}
    for name in TOOLS:
        raw=(root/name).read_bytes()
        need(lf(raw)==lf(git(root,'show',source_sha+':'+name)), 'Judge differs from Git blob: '+name)
        tools[name]={'rawSha256':sha(raw),'lfSha256':sha(lf(raw))}
    need(git(root,'rev-parse','HEAD').decode().strip()==source_sha, 'HEAD changed during inventory')
    return manifest,rows,tools

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['prepare','seal']);p.add_argument('--repo',required=True,type=Path)
    p.add_argument('--sha',required=True);p.add_argument('--out',required=True,type=Path)
    p.add_argument('--gate',action='append',default=[],type=Path,help='seal: three /tmp/r02-run.py result.json paths, CLI/generic/product order')
    p.add_argument('--report-path',default='evidence/r02-ui1-20261028/architecture/REPORT.md')
    a=p.parse_args();root=a.repo.resolve();out=a.out.resolve()
    report_path=PurePosixPath(a.report_path)
    need(bool(report_path.parts) and not report_path.is_absolute() and '..' not in report_path.parts and '\\' not in a.report_path and report_path.parts[0]=='evidence' and report_path.suffix=='.md', 'Report must be a repository-relative evidence/*.md path; historical PRODUCT-ARCHITECTURE.md is preserved')
    need(root not in out.parents and root!=out, 'Output must be outside source checkout')
    need(not out.exists(), 'Refuse to overwrite an output directory')
    manifest,inputs,tools=inspect(root,a.sha)
    out.mkdir(parents=True)
    if a.mode=='prepare':
        before=json.loads(json.dumps(manifest));changes=[]
        present={e['path']:e for e in manifest['sources']+manifest['exclusions']}
        for name,purpose in H.items():
            need(name not in present, 'R02 source already registered; review instead of repeating: '+name)
            manifest['sources'].append({'path':name,'layer':'H','language':'javascript','purpose':purpose})
            changes.append({'path':name,'change':'register-owned-H'})
        need(TEST not in present, 'R02 UI test already registered; review instead of repeating')
        manifest['exclusions'].append({'path':TEST,'reason':'Dedicated UI-1 CDP acceptance driver; invoked by cdp_test.js, never by a product runtime entry point.','sha256':sha(lf((root/TEST).read_bytes())),'hashMode':'lf'})
        changes.append({'path':TEST,'change':'register-test-exclusion'})
        for entry in manifest['exclusions']:
            digest=sha(lf((root/entry['path']).read_bytes())) if entry.get('hashMode','raw')=='lf' else sha((root/entry['path']).read_bytes())
            if digest!=entry['sha256']:
                need(entry['path'] in REFRESH, 'Unapproved stale exclusion: '+entry['path'])
                changes.append({'path':entry['path'],'change':'reviewed-test-digest','before':entry['sha256'],'after':digest});entry['sha256']=digest
        # Preserve existing manifest order; only append the three new entries.
        need({r['path'] for r in inputs}=={r['path'] for r in manifest['sources']+manifest['exclusions']}, 'Proposed manifest leaves an omission or extra entry')
        for key in before:
            if key not in ['sources','exclusions']:need(before[key]==manifest[key], 'Policy/routes changed unexpectedly')
        write(out/'product-architecture.json',manifest)
        write(out/'PLAN.json',{'sourceSha':a.sha,'changes':changes,'inputClosureSha256':closure(inputs),'toolHashes':tools,'sourceCount':len(inputs),'owned':len(manifest['sources']),'excluded':len(manifest['exclusions'])})
        print(json.dumps({'prepared':str(out),'sourceSha':a.sha,'changes':len(changes),'inputs':len(inputs)}))
        return
    need(len(a.gate)==3, 'Three actual judge receipts required')
    need(not git(root,'status','--porcelain').strip(), 'Sealing requires a clean committed source tree')
    commands=[['python3','-B',TOOLS[0],'--root','.','--manifest',DIR+'product-architecture.json'],['python3','-B',TOOLS[1]],['python3','-B',TOOLS[2]]]
    records=[];scan=None
    for n,path in enumerate(a.gate):
        record=json.loads(path.read_text())
        need(record['sha']==a.sha and record['exit']==0 and record['command']==commands[n], 'Judge source/command/exit does not match: '+str(path))
        need(record.get('status')=='' and not record.get('timeout',False), 'Judge execution source was dirty or timed out: '+str(path))
        need(Path(record['cwd']).resolve()==root, 'Judge ran against a different source root')
        for stream in ['stdout.gz','stderr.gz']:
            raw=(path.parent/stream).read_bytes()
            need(sha(raw)==record['rawSha256'][stream], 'Raw judge output hash mismatch: '+stream)
        if n==0:
            scanraw=gzip.decompress((path.parent/'stdout.gz').read_bytes());scan=json.loads(scanraw)
            need(scan.get('ok') is True and not scan.get('diagnostics'), 'CLI scan is not green')
            (out/'product-architecture-scan.json').write_bytes(scanraw)
        records.append(record)
    need({r['path'] for r in inputs}=={r['path'] for r in manifest['sources']+manifest['exclusions']}, 'Final manifest inventory differs')
    need(set(scan['sources'])=={e['path'] for e in manifest['sources']}, 'CLI source set differs')
    need(all(x.get('patchSha256')==sha(b'') for x in records), 'Judge was executed with tracked modifications; use a committed final source')
    report=f'# R02 UI-1 架構驗收\n\n固定來源：`{a.sha}`。三條原裁判均 exit 0；完整命令、原始流與環境見 receipt。\n\n本輪只證明靜態來源／依賴契約，未外推 native、瀏覽器、帳本或 UI15。保留 PRODUCT-ARCHITECTURE.md 歷史原文；本報告為本片獨立記錄。\n'
    (out/'REPORT.md').write_text(report)
    counts={'executableFiles':len(inputs),'ownedSources':len(manifest['sources']),'exclusions':len(manifest['exclusions']),'edges':len(scan['edges']),'diagnostics':len(scan['diagnostics']),'layers':dict(collections.Counter(e['layer'] for e in manifest['sources'])),'languages':dict(collections.Counter(e['language'] for e in manifest['sources']))}
    receipt={'schema':'geometry-product-architecture-receipt/1','sourceBaseHead':a.sha,'headObservedBefore':a.sha,'headObservedAfter':git(root,'rev-parse','HEAD').decode().strip(),'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hashMode':'sha256 after CRLF-to-LF normalization','inputClosureHashSerialization':'SHA-256 of UTF-8 JSON for path-sorted inputs array, ensure_ascii=false, separators=(comma,colon), no trailing newline','inputClosureExcludes':[DIR+x for x in ARTIFACTS],'inputClosureExclusionReason':'Non-executable derived audit metadata; sourceRoots/sourceFiles executable inventory is unchanged by publishing evidence.','manifestSha256':sha(lf((root/DIR/'product-architecture.json').read_bytes())),'scannerSha256':tools[TOOLS[0]]['lfSha256'],'scanSha256':sha(lf(scanraw)),'reportPath':a.report_path,'reportSha256':sha(lf((out/'REPORT.md').read_bytes())),'inputClosureSha256':closure(inputs),'counts':counts,'scanPassed':True,'actualCliScan':records[0],'validation':records[1:],'inputs':inputs,'toolHashes':tools,'artifactsPresentBeforeSeal':{x:sha((root/DIR/x).read_bytes()) for x in ARTIFACTS},'notClaimed':['native execution','mutation ledger freshness','browser acceptance','UI15 dependency integration','Windows probes'],'legacyReportUnchanged':sha((root/DIR/'PRODUCT-ARCHITECTURE.md').read_bytes())}
    need(receipt['headObservedAfter']==a.sha, 'HEAD changed before sealing')
    write(out/'product-architecture-receipt.json',receipt)
    print(json.dumps({'sealed':str(out),'sourceSha':a.sha,'inputs':len(inputs),'counts':counts}))

if __name__=='__main__':main()
