import ctypes, gzip, os, pathlib, signal, subprocess, sys, tempfile, threading, time, urllib.request
root=pathlib.Path.cwd(); kind=sys.argv[1] if len(sys.argv)>1 else 'pf'
scratch=pathlib.Path(tempfile.mkdtemp(prefix='r02-'+kind+'-'))
evidence=pathlib.Path(os.environ.get('R02_BROWSER_EVIDENCE','/workspace/r02-ui1-evidence/browser-support'))
evidence.mkdir(parents=True,exist_ok=True)
tag=os.environ.get('GEOMETRY_PANEL_FILL_MUTATION_CASE',str(int(time.time())))
env=dict(os.environ,GEOMETRY_CHROME=os.environ.get('GEOMETRY_CHROME','/tmp/r02-chrome/opt/google/chrome/google-chrome'),XDG_CONFIG_HOME=str(scratch/'config'),XDG_CACHE_HOME=str(scratch/'cache'),GEOMETRY_CHROME_PROFILE=str(scratch/'chrome'),GEOMETRY_FEEDBACK_DIR=str(scratch/'feedback'),GEOMETRY_TEST_URL='http://localhost:18928/',GEOMETRY_CDP_PORT='9392',GEOMETRY_TEST_SCREENSHOT=str(scratch/'shell.png'),GEOMETRY_BRIDGE='/tmp/geometry-tests/bridge',GEOMETRY_TEST_BRIDGE='/tmp/geometry-tests/bridge',GEOMETRY_TEST_CORE='/tmp/geometry-tests/core',GEOMETRY_MODEL_BASE='/tmp/geometry-tests/model-base',GEOMETRY_PANEL_FILL_ARTIFACT_DIR=str(evidence/'packages'))
if kind=='pf':env['GEOMETRY_PANEL_FILL_ONLY']='1'
else:env.pop('GEOMETRY_PANEL_FILL_ONLY',None)
if kind=='grid':env['GEOMETRY_GRID_SYSTEM_ONLY']='1'
for key in ['GEOMETRY_WAIT_TRACE','GEOMETRY_WAIT_TRACE_RUN_ID','GEOMETRY_CDP_UPDATE_GOLDEN']:env.pop(key,None)
for key in ['GEOMETRY_GRID_SYSTEM_SCREENSHOT_DIR','GEOMETRY_GRID_RULE_SCREENSHOT_DIR','GEOMETRY_UIUX_SCREENSHOT_DIR','GEOMETRY_REPAIR_SCREENSHOT_DIR','GEOMETRY_ROOM_SCREENSHOT_DIR','GEOMETRY_ENGINEERING_DOWNLOAD_DIR']:
    directory=scratch/key.lower();directory.mkdir();env[key]=str(directory)
# Preserve the existing Chrome sandbox. A subreaper only reaps this runner's
# orphaned test children; it does not alter namespaces or system settings.
ctypes.CDLL(None).prctl(36,1,0,0,0)
def stop_owned(signum,frame):
    raise SystemExit(124)
signal.signal(signal.SIGTERM,stop_owned)
print('R02_BROWSER_ENV '+str({k:v for k,v in env.items() if k.startswith('GEOMETRY_')}),flush=True)
print('R02_SOURCE '+subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),flush=True)
server=subprocess.Popen([sys.executable,'-u','geometry-web/start_local.py','--port','18928','--binary-dir','/tmp/geometry-tests'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
def capture():
    with gzip.open(evidence/(tag+'-server.log.gz'),'wb') as f:
        while True:
            chunk=server.stdout.read1(65536)
            if not chunk:break
            f.write(chunk);f.flush()
t=threading.Thread(target=capture);t.start();exit_code=1
try:
    deadline=time.monotonic()+180
    while True:
        if server.poll() is not None:raise RuntimeError('isolated server exited '+str(server.returncode))
        try:
            with urllib.request.urlopen('http://127.0.0.1:18928/runtime',timeout=1) as response:
                if response.status==200:break
        except (OSError,TimeoutError):pass
        if time.monotonic()>deadline:raise RuntimeError('isolated server startup failed')
        threading.Event().wait(.25)
    probe=subprocess.run([sys.executable,'geometry-web/runtime_version.py','--probe','18928'],env=env)
    if probe.returncode:raise RuntimeError('runtime identity probe failed')
    test=['node','geometry-web/space_model_test.js'] if kind=='space' else ['node','geometry-web/cdp_test.js']
    exit_code=subprocess.run(test,env=env).returncode
finally:
    try:os.killpg(server.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    server.wait();t.join()
    if kind=='canvas':
        archive=subprocess.run([sys.executable,'geometry-web/archive_wait_trace.py',str(scratch/'wait-trace-artifact')],env=env)
        if exit_code==0 and archive.returncode:exit_code=archive.returncode
    while True:
        try:
            if os.waitpid(-1,os.WNOHANG)[0]==0:break
        except ChildProcessError:break
print('R02_BROWSER_EXIT '+str(exit_code),flush=True)
raise SystemExit(exit_code)
