# 最小套用順序（尚未執行）

`prepare.py` 不寫 source checkout、不跑裁判或帳本。只允許兩個新 H JavaScript、一個真 CDP 測試 exclusion、三個既有測試的 digest 更新。表單單元已移至 `tests/test_panel_fill_ui_contract.js`，不能再登記舊 web 路徑。

1. UI 測試與產品定案並 commit。固定完整 SHA，先依原流程正常 push。
2. `python3 /tmp/r02-architecture-prep/prepare.py prepare --repo /tmp/r02-ui1 --sha <完整來源SHA> --out /tmp/r02-arch-manifest-final`
3. 審核 PLAN.json，將單一 `product-architecture.json` 複製到 repository 同名路徑，commit/push。新的完整 F 為三條裁判 execution SHA。不要改 PRODUCT-ARCHITECTURE.md。
4. 在 `/tmp/r02-ui1` 依序以既有 `/tmp/r02-run.py` 保存以下三條真命令。必須採已 commit 的乾淨最終版本；不可把 `tests/mutants_results.json` 仍 dirty 的帳本生成中狀態封成 final。

```text
python3 -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json
python3 -B tests/test_architecture_contract.py
python3 -B tests/test_product_architecture.py
```

5. 三條結果確實 exit 0，再執行：

```text
python3 /tmp/r02-architecture-prep/prepare.py seal --repo /tmp/r02-ui1 --sha <三條受驗完整F> --out /tmp/r02-arch-receipt-final --gate <CLI/result.json> --gate <generic/result.json> --gate <product/result.json>
```

6. 將 scan/receipt 放原架構 JSON 路徑，REPORT.md 放 `evidence/r02-ui1-20261028/architecture/REPORT.md`。連同原三條完整文字收據及工具原件提交；這是 evidence head，不改寫 execution SHA。若報告另放他處，seal 用 `--report-path` 指定真實 repository 相對路徑。

目前僅 AST 解析及 help 檢查。prepare/seal 還沒在正式來源執行，不是三條 gate 通過收據。舊 report 保留原樣，receipt 明列獨立 reportPath 與其 hash，沒有把歷史報告冒作本輪報告。

已經第二代理只讀對抗審查，修正兩項：每份原執行收據也須 `status` 空（空 diff 不能證明沒有 untracked 檔案），reportPath 只允許 repository 相對 `evidence/*.md`，不能指向歷史報告或越出目錄。這是工具靜態審查，不是正式架構 gate。
