"""Retract only the complete navigation/create ownership fix, using original UI13 judge."""
import hashlib,importlib.util,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[sys.argv.index('--root')+1]).resolve()
spec=importlib.util.spec_from_file_location('original_ui13',root/'tests/panel_fill_ui_mutations.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old_execute=m.execute
def variants(root):
    p=root/'geometry-web/parameters.js';original=p.read_bytes()
    fixed=subprocess.check_output(['git','show','a7a05ecf13076f0dcf5fd89d1ef6c8a9118ac836:geometry-web/parameters.js'],cwd=root)
    before=subprocess.check_output(['git','show','0f37836d524c1314b26246b9d557110c21e2124a:geometry-web/parameters.js'],cwd=root)
    if original!=fixed or original==before:raise ValueError('Expected exact reviewed owner fix, refusing broader retraction')
    return [('d44-preparation-owner','UI05_D44_PREPARATION_OWNER',p,original,before)]
def execute(root,out,label,command,timeout,source_sha):
    digest=hashlib.sha256((root/'geometry-web/parameters.js').read_bytes()).hexdigest()
    receipt,text=old_execute(root,out,label,command,timeout,source_sha)
    receipt['sourceFiles']['geometry-web/parameters.js']=digest
    (out/label/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    return receipt,text
m.variants,m.execute=variants,execute
sys.exit(m.main())
