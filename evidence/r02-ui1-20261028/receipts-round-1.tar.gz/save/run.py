import gzip, hashlib, json, pathlib, platform, subprocess, sys, time
root = pathlib.Path('/tmp/r02-ui1-save')
dest = pathlib.Path(__file__).parent
name = sys.argv[1]
cmd = sys.argv[2:]
started = time.time()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
patch = subprocess.check_output(['git', 'diff', 'HEAD'], cwd=root)
if patch:
    (dest / (name + '.patch.gz')).write_bytes(gzip.compress(patch))
result = subprocess.run(cmd, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
raw = result.stdout
(dest / (name + '.log.gz')).write_bytes(gzip.compress(raw))
receipt = {'command':cmd,'cwd':str(root),'head':head,'working_diff_sha256':hashlib.sha256(patch).hexdigest(),'started_unix':started,'finished_unix':time.time(),'exit':result.returncode,'output_sha256':hashlib.sha256(raw).hexdigest(),'output_bytes':len(raw),'node':subprocess.check_output(['node','--version'],text=True).strip()}
receipt['environment'] = {'platform':platform.platform(),'python':sys.version}
(dest / (name + '.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(raw.decode('utf-8',errors='replace'))
print(json.dumps(receipt,ensure_ascii=False))
sys.exit(result.returncode)
