# R02 UI-1 保存分工

- 分支：`codex/r02-ui1-save-20261028`（僅本地，未推送）
- 基底：`405f8c5e1a637a16cbe47470faf5ae1fa02b8676`
- 最新 head：`037bda6abb2dba1c91388c1ae6eb03f675ac1aab`，工作樹乾淨。
- 實作檔案：`geometry-web/project-store.js`、`geometry-web/reference-workspace.js`；新增 `tests/test_panel_fill_project_store.js`，經 root 指派更新 `tests/test_scenario_project_store.js` 的精確格式清單。
- 指定 main 與 `scan/feat/r01-grid-card-entry-20261027` 當次核對最高均為 `/18`，本片分配 `/19`，沒有改舊格式語意。

PF 的三種 definition-only scene records 保存至正式 archive；不存派生板片、候選或未提交表單。確認沿共用 history/dirty/operation tracking，一次成功一筆，no-op 無新增。PF pending 阻擋正式保存、recovery 更新與專案切換。匯入仍先經隔離原生候選，檢查能力與原生 canonical PF 定義，再原子換入。

全域 `capabilities` 不宣告完整 PF。讀取 `/19` 必須核 `panel_fill_reader` 精確契約（schema、capability、三筆 record 集合、`complete:false`）；原生端由另一分支 d467c781afddd083f519864652a239acf10daa74 提供。缺少或假造 scoped reader 不得提交。

## 已實跑

所有 `.json` 都記命令、完整 head、dirty patch SHA256、退出碼與輸出 SHA256；`.log.gz` 為完整原始 stdout/stderr；突變 `.patch.gz` 為精確撤回補丁。由 `run.py` 執行，不需要重跑取回原件。

| 收據 | 結果 |
|---|---|
| pf-save-final-regression | 最新 head：105 過／0 敗／24 個原生環境 skip，exit 0；含 PF 11 項全過、舊保存九套回歸 |
| pf-workspace-races | ab8e52a56a859355bf98d81437d9f10502980af3：77 過／0 敗／1 原生 HTTP skip，exit 0，39.25 秒 |
| pf-history-withdrawn | PF_HISTORY_ONCE：0≠1，exit 1 |
| pf-pending-withdrawn | PF_SAVE_PENDING_GUARD：Missing expected rejection，exit 1 |
| pf-candidate-withdrawn | PF_SAVE_ATOMIC_REJECTION：不應到達 confirm 卻到達，exit 1 |
| pf-save-restored | 前三項恢復：PF 10＋scenario 6，exit 0 |
| pf-scoped-reader-withdrawn | PF_SAVE_SCOPED_READER_IMPORT：拔掉 receipt 接線後正例不能提交，exit 1 |
| pf-save-final-regression | scoped reader 接線恢復，PF 11 項全過 |

保留失敗：`pf-save-regression-1` 是舊測試寫死格式總數 18（實際 19）；改成精確 `/1..19` 後恢復。`pf-scoped-reader-baseline` 是本次新增測試仍假設全域缺 PF 就必拒，與已核可 scoped reader 契約不符；改測缺 `engineering-spec/1` prerequisite，另獨立測缺 scoped reader，並未放寬產品守門。

## 未驗／界線

- 本分工只跑 Node archive 與 VM scheduling；未跑真 UI、真 native source 缺項拒收、fresh-profile 重開、UI13、UI15，不以 mocks 當作通過。
- §8 的輪廓／片鍵／縫鍵／宿主邊鍵／警告與角材定義，需整合真 UI 在保存前後讀原生值比對；目前僅驗證 archive 保存定義與 candidate 不得 silent-drop PF 定義。
- 24＋1 skip 皆為原測試需要 `GEOMETRY_TEST_BRIDGE`／`GEOMETRY_ENGINEERING_BRIDGE`／`GEOMETRY_MODEL_BASE`，本分工未設，不算通過。
- 含 PF 的 scenario leaf 仍受既有 `scenario_verify.py` 與 `scenario-snapshots.js` 舊能力契約阻擋；fail closed，未宣稱支援。需要額外 owner 接線與真 native 驗收才能擴及此組合。

## 對抗審查

保存產出已由 native agent 唯讀審查；發現舊 advertised capabilities 故意不宣告全功能 PF，正式重開會 fail closed。已與 root／native owner 協調獨立 reader 契約修復，不修改舊全域 capability 語意。

本代理唯讀檢查 native 200b686c807f7520813226b6093d10cb6e2a3b2e 的 exact writer、error collector、scope union、newid wrap，及 d467c781 的 reader shape。未發現新的確證靜態阻擋。診斷容器最多 before/after 三類各 FS_MAX 加交易一筆，第一錯誤即使 dedup 仍令完整性為 false；bounded IDs 不轉型，int64 派生數字走新版字串，legacy 路徑保留數字。仍待真編譯與原生測試證明，不把靜態審查當正式通過。
