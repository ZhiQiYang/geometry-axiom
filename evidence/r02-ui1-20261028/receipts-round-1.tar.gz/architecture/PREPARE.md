# R02 UI-1 架構／帳本唯讀預檢

觀測來源：`24562d8801adb89fc88c0dceadb894d464cff4a4`。本次沒有修改任何產品、manifest、裁判或帳本；未執行重測試。

## 已執行

| 指令 | exit | 實際結果 |
|---|---:|---|
| `python3 -B tests/mutate.py --check` | 1 | 78 筆：stale 75、retired 3；有效 killed/crashed/equivalent 均 0。include closure、部分裁判及 bridge sidecar 身分過期。不是突變重產結果。 |
| `python3 -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json` | 1 | 第一個診斷為 `EXCLUSION_DIGEST geometry-web/room_outline_test.js`。裁判先遇到此錯，不代表只有此錯。 |

各指令的完整原始 stdout/stderr gzip、起迄、環境、完整 SHA、exit 均在同目錄的 `mutate-check-preflight/` 與 `scanner-preflight/`。

## 最小 manifest 更新

以最後整合來源重新枚舉 `sourceRoots` 與 `sourceFiles`；副檔名必須取原 `tests/architecture_contract.py:LANGUAGES`，不能只掃 C/JS。與 manifest 的 sources＋exclusions 逐檔集合相等，亦須與固定 Git tree 相等。

本次已觀測的新增項：

| 路徑 | 登記 |
|---|---|
| geometry-web/panel-fill-adapter.js | H、javascript；UI-1 原生 wire／候選生命週期轉接，不含幾何求值 |
| geometry-web/panel-fill-workspace.js | H、javascript；既有面屬性檢查器的完成面表單及原生結果呈現 |
| geometry-web/panel-fill-ui-contract-test.js | 專用測試 exclusion，明列理由及最終 LF SHA256 |

UI 測試合入後，預期另登記 `geometry-web/panel_fill_workflow_test.js` 為專用測試 exclusion，並更新 `geometry-web/cdp_test.js` 的 LF digest。這兩項目前尚未在本次來源，不能預先記成已核。

已觀測過期 exclusion：

- `geometry-web/room_outline_test.js`：LF SHA256 `212b14a5ffaf05a256e090c0d3e9faa2f7d4aaf05d96133b2eae4e88d987a27a`。
- `geometry-web/space_model_test.js`：LF SHA256 `0ab10984837d323084364b0be4d9ad9512c285e93170627e4b50a5eb237be13c`。

只審核並更新實際改動的 test digest，不能重新計算全部排除項而掩蓋無關變動。非 vendor 的 owned H source 不得新增 immutable sha256 欄位。CSS 不在原裁判執行性副檔名清單，維持原規則，不為此擴張或縮小 scanner。

`index.html` 新增的兩個 script 是同目錄真檔案，原 scanner 可直接解析；不需要也不應新增虛構 `htmlScriptRoutes`。既有該欄僅處理 `templates/woodworking.js` 與 `application.js` 的服務路由。

## 最終三條原裁判

在所有產品與測試修改整合、manifest 最小更新並固定完整來源 SHA 後，依序跑：

```text
python3 -B tests/architecture_contract.py --root . --manifest geometry-core/domain-decoupling/product-architecture.json
python3 -B tests/test_architecture_contract.py
python3 -B tests/test_product_architecture.py
```

使用原 CLI 的 stdout 作為 `product-architecture-scan.json`，保存 stderr 和 exit；不能只呼叫 helper 就宣稱原 CLI 通過。裁判與來源執行前後須雜湊一致；來源若變動，這輪只能是其真實 execution SHA 的收據。

## Linux 產物與收據

現有 schema 是 `geometry-product-architecture-receipt/1`，沒有必須 Windows 的步驟。三條原裁判不讀或驗 `PRODUCT-ARCHITECTURE.md`／receipt；因此可遵守本次文件限制，保留該歷史 report 原文不改，把新報告放 `evidence/r02-ui1-20261028/`，在新 receipt 明列 reportPath 並雜湊該新報告，不冒稱舊 report 已更新。

最小重產需保留：schema、sourceBaseHead／headObservedBefore／headObservedAfter、前版產物 hash、manifestSha256、scannerSha256、scanSha256、新 reportPath/reportSha256、inputClosureSha256、counts、actualCliScan、validation、完整 inputs、inventory 核對、環境及未驗範圍。所有 exit/count 必須取這輪原始結果；不可帶用舊 receipt 的綠燈或 supplemental probes。

inputs 是依 path 排序的 `{path,sha256}`，hash 先將 CRLF→LF；closure 是該陣列以 `json.dumps(...,ensure_ascii=False,separators=(',',':'))` UTF-8 編碼、不含尾換行的 SHA256。來源為所有 sourceRoots 與 sourceFiles 的執行性檔案；三個裁判另記原始與 LF hash。manifest／scan／report／receipt 是衍生資料，分別綁 hash，不放入 executable closure，不雜湊 receipt 自己。

已找到兩支 Linux 歷史 driver：`/workspace/geo261-environment/refresh_architecture_w_linux.py`、`refresh_architecture_canonical_html_linux.py`。**不能直接拿來跑本片**：前者限舊 W 變更且拒新增來源，後者只准 canonical HTML；兩者都會產生修改過的 PRODUCT-ARCHITECTURE.md。可參照其收據欄位，不能放寬其來源守門後冒稱原工具可直接驗 R02。

帳本由主代理待最終來源固定後整份重產一次，再以原 `--check` 驗新鮮度。本次僅證明舊帳本過期，不是原生、瀏覽器或 UI15 收據。
