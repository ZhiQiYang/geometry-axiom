import datetime,hashlib,json,os,pathlib,signal,subprocess,zlib
root=pathlib.Path('/tmp/r02-d44-mutations');base=pathlib.Path('/workspace/r02-ui1-evidence')
F='74d638686edc9861e9ed9d3409af4adf02350f8e'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()==F
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain']).strip()
old=base/'owner-final-canvas';r=json.loads((old/'result.json').read_text());assert 'exit' not in r
assert not (base/'owner-final-canvas-recovery').exists()
files={}
for p in sorted(old.iterdir()):
    if p.is_file():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
raw=zlib.decompressobj(31);text=raw.decompress((old/'stdout.gz').read_bytes()).decode(errors='replace')
assert not raw.eof and 'CDP_RESULT ' not in text
record={'schema':'r02-ui1-environment-interruption/1','observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executionSha':F,'toolSession':99685,'toolError':'write_stdin failed: Unknown process id 99685','testExit':None,'timeoutObserved':False,'resultMissingTerminal':True,'gzipComplete':False,'lastOutputMtimeUtc':datetime.datetime.fromtimestamp((old/'stdout.gz').stat().st_mtime,datetime.timezone.utc).isoformat(),'lastSection':'P77','cgroupMemoryEvents':pathlib.Path('/sys/fs/cgroup/memory.events').read_text(),'classification':'Environment/process interruption; cause not established. No completed full result and no inferred exit code. Original files unchanged.','originalFiles':files}
p=old/'INTERRUPTION.json';assert not p.exists();p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
# Stop only the abandoned browser from this exact incomplete run; no profile deletion.
pid=177796;proc=pathlib.Path('/proc')/str(pid)
if proc.exists():
    cmdline=(proc/'cmdline').read_bytes().decode().replace('\0',' ')
    assert '--user-data-dir=/tmp/r02-canvas-84wm_3io/chrome ' in cmdline and '--remote-debugging-port=9392' in cmdline
    os.kill(pid,signal.SIGTERM)
env=dict(os.environ,R02_BROWSER_EVIDENCE=str(base/'owner-final-canvas-recovery-support'),GEOMETRY_BROWSER_SUITE='canvas')
cmd=['python3',str(base/'tools/gate-run.py'),'--root',str(root),'--seconds','2100','owner-final-canvas-recovery','--','python3',str(base/'tools/r02-browser-run-v2.py'),'canvas']
log=base/'owner-final-canvas-recovery-launch.log';assert not log.exists()
with log.open('wb') as f:
    child=subprocess.Popen(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
launch={'pid':child.pid,'launchedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executionSha':F,'command':cmd,'stdoutStderr':str(log),'timeoutSeconds':2100,'isolation':'new process session; same original test and time limit'}
(base/'owner-final-canvas-recovery-launch.json').write_text(json.dumps(launch,indent=2)+'\n')
print(json.dumps(launch))
