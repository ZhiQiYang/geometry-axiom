"""Use the unchanged UI13 runner for three wiring and two D44 retractions."""
import hashlib,importlib.util,json,pathlib,sys
root=pathlib.Path(sys.argv[sys.argv.index('--root')+1]).resolve()
spec=importlib.util.spec_from_file_location('original_ui13',root/'tests/panel_fill_ui_mutations.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old_variants,old_execute=m.variants,m.execute
def variants(root):
    selected=old_variants(root)[:3]
    for name,assertion,relative,old,new in [
        ('d44-proposal-eight','UI03_D44_SOURCE_8','geometry-web/parameters.js',b"input:preparation?'8':'0'",b"input:'0'"),
        ('d44-support-red','UI04_D44_SUPPORT_RED','geometry-web/panel-fill-workspace.css',b'.pf-seams line[data-supported="false"]{stroke:#c21f30;stroke-width:3}',b'.pf-seams line[data-supported="false"]{stroke:#185d96;stroke-width:3}')]:
        path=root/relative;original=path.read_bytes()
        selected.append((name,assertion,path,original,m.replace_once(original,old,new)))
    return selected
def execute(root,out,label,command,timeout,source_sha):
    extra={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['geometry-web/parameters.js','geometry-web/panel-fill-workspace.css']}
    receipt,text=old_execute(root,out,label,command,timeout,source_sha)
    receipt['sourceFiles'].update(extra)
    (out/label/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    return receipt,text
m.variants,m.execute=variants,execute
sys.exit(m.main())
