# D44 修補與原始失敗

規格：base `405f8c5e1a637a16cbe47470faf5ae1fa02b8676` 公理層.md 874–879；#128 設計 §3 來源準備與 §5.0 UI-1。未改 SSOT、原生幾何或既有斷言。

- `85aad255218ed4497330ee570b6b10c27b86bd65`：真 UI 359／0／0，exit0，197.702秒，`d44-baseline-1`。新來源只開既有參數卡草稿；確認前 dump／history 不變，來源確認獨立一次；不足子段使用原生 supported/range/left/right。
- `4376d236675beba8178026699c355d602b2127ac`：368／1，exit1，202.987秒，`d44-baseline-2`。新增 `UI11_D44_SOURCE_REOPEN` 誤用 legacy `state.panelFills[].derived.threshold`。`panel_layout_bridge.inc:42` 只在 g_pf_ui_exact 分支輸出 threshold，正確契約是 `uiContract.state`；不是允許 legacy 缺值冒充精確值。該次 gcanvas 保留新參數91欄1之8mm字面值及鋪排2的91:1引用；原 dump、references、state 與精確 uiContract 保存重開比較皆通過。失敗斷言與完整輸出保留，沒有改原生或放寬期望8/1。
- `cf58aeb61b25c55262b55193a0511f5bb2c8e516`：377／0／0，exit0，192.075秒，`d44-baseline-3`。改驗正確版本化精確view；另從零 dimension 欄位開始，證明真正新建8mm來源、取消零變更、獨立Undo/Redo、改選既有17/2、真ParameterRef保存fresh BrowserContext重開。PF05／23／24所有原生子段精確座標、左右實寬、supported紅藍及合法不足可確認均核對。

上述皆 P128 partial，不冒稱完整canvas。其後 `a66b2022aa9603b5b2a6fc7b201d6b68a0d54bc6` 僅登記最新 UI test exclusion hash 與 P128實跑377計數；原85段golden完全不變。固定F之五組具名撤回與新版完整canvas尚待終態，UI15仍受上游來源鏈未閉合限制。

新撤回工具 `tools/d44-ui-mutations.py` 只沿用未變原runner，選原三UI13加preset8→0、false支撐紅→藍，要求各自具名exit1、無timeout並恢復exit0。工具已經唯讀對抗審查，尚不代表正式自證完成。
