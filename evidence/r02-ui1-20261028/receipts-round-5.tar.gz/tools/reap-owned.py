"""Run an unchanged command while reaping only its orphaned descendants.

Container PID 1 does not reap killed grandchildren. This process-local
subreaper supplies that missing init behavior without changing the test,
its process groups, /proc assertions, timeouts, or system configuration.
"""
import ctypes
import os
import subprocess
import sys
import threading

libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER")
command = sys.argv[1:]
if not command:
    raise SystemExit("command required")
child = subprocess.Popen(command)
done = threading.Event()
adopted = []

def reap():
    while not done.is_set():
        # This kernel omits /proc/<pid>/task/<tid>/children. waitid selects
        # only this process's own exited children without consuming status.
        # Preserve the main child's status for subprocess.wait().
        try:
            pending = os.waitid(os.P_ALL, 0, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            if pending is not None and pending.si_pid != child.pid:
                result, status = os.waitpid(pending.si_pid, os.WNOHANG)
                if result:
                    adopted.append({'pid': result, 'waitStatus': status})
        except ChildProcessError:
            pass
        done.wait(0.01)

thread = threading.Thread(target=reap)
thread.start()
try:
    code = child.wait()
finally:
    done.set()
    thread.join()
print('OWNED_ORPHAN_REAP ' + repr(adopted), flush=True)
raise SystemExit(code)
