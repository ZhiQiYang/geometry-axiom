#!/usr/bin/env python3
"""Read an ended native census and run the unchanged count comparator; execute no suite."""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

sys.dont_write_bytecode=True

def need(ok,message):
    if not ok:raise ValueError(message)

def digest(raw):return hashlib.sha256(raw).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def load(path):return json.loads(path.read_text())
def match(pattern,text,label):
    result=re.search(pattern,text,re.M)
    need(result is not None,'Missing raw summary: '+label)
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--source-sha',required=True)
    parser.add_argument('--outer',required=True,type=Path,help='native-full-final directory')
    parser.add_argument('--support',required=True,type=Path,help='native-final-support directory')
    parser.add_argument('--targeted-recovery',type=Path,help='Optional separately retained assembly environment retest; never replaces original census result')
    a=parser.parse_args();root=a.repo.resolve();source=a.source_sha
    need(re.fullmatch('[0-9a-f]{40}',source),'Full source SHA required')
    outer=load(a.outer/'result.json');support=load(a.support/'receipt.json')
    original_exit=outer.get('exit')
    need(original_exit in (0,1) and support.get('exit')==support.get('processExit')==original_exit,'Census is not a completed ordinary exit 0/1; retain and diagnose its original result')
    need(outer['sha']==support['sha']==source,'Census source SHA mismatch')
    need(Path(outer['cwd']).resolve()==root and outer['command']==['python3','/workspace/r02-ui1-evidence/tools/native-gate.py'],'Unexpected outer command or checkout')
    need(outer['status']=='' and outer['patchSha256']==digest(b''),'Census did not start from clean committed source')
    need(outer['stackBytes']==16777216,'Native did not use the original 16 MiB stack')
    need(support['command']==['python3','tests/run_all.py','--build','--update-expected'],'Unexpected actual census command')
    need(support['timeoutSeconds']==2100 and not support.get('timeout') and not support.get('interrupted'),'Native 35-minute gate was not met')
    need(not support.get('collectionErrors'),'Original suite collection failed')
    need(set(outer['rawSha256'])=={'stdout.gz','stderr.gz'},'Missing or unexpected outer streams')
    for name,want in outer['rawSha256'].items():need(digest((a.outer/name).read_bytes())==want,'Outer stream hash mismatch: '+name)
    stdout=gzip.decompress((a.outer/'stdout.gz').read_bytes()).decode('utf-8')
    need('==== 部分／示範執行，不可當完整驗收 ====' not in stdout and re.search(r'^exit '+str(original_exit)+'：',stdout,re.M),'Missing complete original census terminal')
    terminal=json.loads(match(r'^R02_NATIVE_GATE (.*)$',stdout,'persistent native collector terminal')[1])
    need(terminal=={k:v for k,v in support.items() if k not in ('files','environment')},'Original outer stream and collector terminal receipt disagree')
    need('--update-expected 拒絕執行' not in stdout and re.search(r'^已重寫 .*/tests/run_all.expected.json：$',stdout,re.M),'Original judge did not accept a complete count census')
    archive=a.support/'suite-logs.tar.gz';raw=archive.read_bytes()
    need(digest(raw)==support['archiveSha256'] and len(raw)==support['archiveBytes'],'Original suite archive hash mismatch')
    files={}
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            need(member.isfile() and member.name not in files,'Nonregular or duplicate original suite member')
            data=tar.extractfile(member).read();want=support['files'].get(member.name)
            need(want and len(data)==want['bytes'] and digest(data)==want['sha256'],'Original suite member hash mismatch: '+member.name)
            files[member.name]=data
    need(set(files)==set(support['files']),'Original suite archive inventory mismatch')
    pins={}
    for name in ['tests/run_all.py','tests/binaries.py','tests/_unittest_runner.py','tests/test_panel_fill_ui_contract.py','tests/test_panel_fill_ui_contract.js','tests/test_panel_fill_project_store.js','tests/test_assembly_mutation_check.py']:
        original=git(root,'show',source+':'+name);current=(root/name).read_bytes()
        need(current.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),'Judge or approved test module changed: '+name)
        pins[name]=digest(original)
    sys.path.insert(0,str(root/'tests'))
    spec=importlib.util.spec_from_file_location('r02_original_run_all',root/'tests/run_all.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    need(not module.check_registry(),'Actual source registry is inconsistent')
    suites=module.build_suites();by_name={s.name:s for s in suites}
    original_expected_raw=git(root,'show',source+':tests/run_all.expected.json')
    original_expected=json.loads(original_expected_raw);approved=copy.deepcopy(original_expected)
    entries=approved['suites']
    need(len(entries)==224 and entries['node:tests-js']=={'mode':'count','unit':'node test','count':737},'Original count basis differs from reviewed R02 basis')
    additions={'py:test_panel_fill_ui_contract':9,'node:panel_fill_ui_contract':21}
    need(not(set(additions)&set(entries)),'New test suites were already in the original baseline')
    entries['node:tests-js']['count']=748
    for name,count in additions.items():entries[name]={'mode':'count','unit':module.UNIT.get(by_name[name].kind,''),'count':count}
    need(len(suites)==226 and set(by_name)==set(entries),'Complete suite census differs from the reviewed 224→226 change')
    table={};table_started=False;aggregate=None
    pattern=r'^(\S+)\s+(\d+|-)\s+(\d+|ok|-)\s+(\d+|FAIL|-)\s+(\d+|-)\s+(\d+(?:\.\d+)?)\s*(.*)$'
    for line in stdout.splitlines():
        if not table_started:
            if re.fullmatch(r'suite\s+測試數\s+pass\s+fail\s+skip\s+秒\s+備註',line):table_started=True
            continue
        if re.fullmatch(r'-+',line):continue
        found=re.match(pattern,line)
        need(found is not None,'Unparsed line in original summary table: '+line)
        if found[1]=='合計(已執行、有計數者)':aggregate=found.groups()[1:];break
        need(found[1] in by_name,'Unknown suite in original summary table: '+found[1])
        need(found[1] not in table,'Duplicate original table row: '+found[1]);table[found[1]]=found.groups()[1:]
    need(aggregate is not None,'Missing original complete summary table aggregate')
    need(set(table)==set(by_name),'Original stdout table has missing or extra suite rows')
    rows=[];observations=[];original_failures=[]
    for suite in suites:
        name=suite.name;stem=name.replace(':','_');text=files[stem+'.log'].decode('utf-8');row=module.Row(name,suite.counted);row.ran=True
        total,passed,failed,skipped,seconds,note=table[name]
        need(failed.isdigit() if suite.counted else failed=='-','Original table has an uncounted failure or invalid count: '+name)
        if suite.kind=='unittest':
            data=json.loads(files[stem+'.json'])
            need(not data.get('import_error') and not data.get('blocked_by_error'),'Original unittest did not complete: '+name)
            row.total,row.passed,row.failed,row.skipped=[data[k] for k in ['total','passed','failed','skipped']]
            row.allowed_skips=module.classify_skips(name,data)
            if row.failed:original_failures.append({'suite':name,'failed':row.failed,'details':data.get('failures',[]),'rawJsonSha256':digest(files[stem+'.json'])})
        elif suite.kind=='node-test':need(module.parse_node_spec(text,row),'Missing Node summary: '+name)
        elif suite.kind=='integrity':
            found=match(r'(\d+)/(\d+) integrity checks passed',text,name);row.passed,row.total=map(int,found.groups());row.failed=row.total-row.passed
        elif suite.kind=='run_tests':
            data=json.loads(match(r'^GEOMETRY_TEST_RESULT (.*)$',text,name)[1]);row.total=data['total'];row.passed=data['counts']['pass'];row.failed=data['counts']['fail'];need(data['counts']['infrastructure']==0,'Core infrastructure failures')
        elif suite.kind=='node-canvas':
            found=match(r'(\d+) pass / (\d+) fail',text,name);row.passed,row.failed=map(int,found.groups());row.total=row.passed+row.failed
        else:
            need(not suite.counted and total==skipped=='-','Unexpected counted/exit-only mode: '+name)
            need(passed=='ok' or suite.kind=='mutation-check' and 'exit 0' in note,'Exit-only suite not proven green: '+name)
            row.passed=int(passed=='ok')
        if suite.counted:
            need(total.isdigit() and (row.total,row.passed,row.failed,row.skipped)==tuple(map(int,[total,passed,failed,skipped])),'Raw suite and original table disagree: '+name)
            need(row.total>0 and row.skipped==row.allowed_skips,'Zero discovery or unapproved skip: '+name)
            if row.failed and suite.kind!='unittest':original_failures.append({'suite':name,'failed':row.failed,'rawLogSha256':digest(files[stem+'.log'])})
        rows.append(row);observations.append({'suite':name,'mode':'count' if suite.counted else 'exit-code-only','count':row.total if suite.counted else None,'passed':row.passed,'failed':row.failed,'skipped':row.skipped,'allowedSkips':row.allowed_skips,'rawLogSha256':digest(files[stem+'.log'])})
    problems=module.compare_expected(rows,suites,approved,'',True)
    need(not problems,'Original strict comparator failed: '+repr(problems))
    need(tuple(map(int,aggregate[:4]))==tuple(sum(getattr(r,field) for r in rows if r.counted) for field in ('total','passed','failed','skipped')),'Original summary aggregate and raw suite counts disagree')
    need(bool(original_failures)==bool(original_exit),'Original terminal exit and raw failed suite counts disagree')
    # This file is compared last; it was never the source of observed counts.
    regenerated_raw=(root/'tests/run_all.expected.json').read_bytes();regenerated=json.loads(regenerated_raw)
    need(regenerated['suites']==entries,'Generated expected contains an unreviewed change beyond 9/21/+11')
    recovery=None
    if a.targeted_recovery:
        receipt=load(a.targeted_recovery/'result.json')
        need(receipt['sha']==source and receipt['status']=='' and receipt['patchSha256']==digest(b''),'Recovery source identity differs')
        need(Path(receipt['cwd']).resolve()==root,'Recovery checkout differs')
        need(receipt['exit']==0 and not receipt.get('timeout') and not receipt.get('interrupted'),'Recovery did not complete exit 0')
        need(receipt['command']==['python3','/workspace/r02-ui1-evidence/tools/reap-owned.py','python3','-B','tests/test_assembly_mutation_check.py'],'Unexpected targeted recovery command')
        need(set(receipt['rawSha256'])=={'stdout.gz','stderr.gz'},'Missing or unexpected recovery streams')
        for name,want in receipt['rawSha256'].items():need(digest((a.targeted_recovery/name).read_bytes())==want,'Recovery stream hash mismatch: '+name)
        recovered_text='\n'.join(gzip.decompress((a.targeted_recovery/name).read_bytes()).decode('utf-8') for name in ('stdout.gz','stderr.gz'))
        need(re.search(r'^Ran 12 tests in [0-9.]+s$',recovered_text,re.M) and re.search(r'^OK$',recovered_text,re.M),'Recovery original output is not 12 tests OK')
        recovery={'suite':'py:test_assembly_mutation_check','path':str(a.targeted_recovery),'receiptSha256':digest((a.targeted_recovery/'result.json').read_bytes()),'sourceSha':receipt['sha'],'command':receipt['command'],'exit':receipt['exit'],'elapsedSeconds':receipt['elapsedSeconds'],'rawSha256':receipt['rawSha256'],'doesNotReplaceOriginalFullNative':True}
    print(json.dumps({'schema':'r02-native-census-count-audit/1','ok':True,'outcome':'count-only-no-product-verdict','scope':'count audit only; original native failure and targeted recovery remain separate','originalFullNativeExit':original_exit,'originalFullNativePassed':original_exit==0,'originalFailures':original_failures,'targetedRecovery':recovery,'sourceSha':source,'observedCurrentHead':git(root,'rev-parse','HEAD').decode().strip(),'actualCensusCommand':support['command'],'notASecondNativeExecution':True,'comparison':'original compare_expected over original stdout table cross-checked with raw suite logs; regenerated expected is comparison target only','originalSuiteCount':224,'actualSuiteCount':len(suites),'approvedChanges':{'py:test_panel_fill_ui_contract':{'added':9},'node:panel_fill_ui_contract':{'added':21},'node:tests-js':{'before':737,'after':748}},'sourcePins':pins,'originalExpectedSha256':digest(original_expected_raw),'regeneratedExpectedSha256':digest(regenerated_raw),'originalArchiveSha256':support['archiveSha256'],'originalOuterStreams':outer['rawSha256'],'scriptSha256':digest(Path(__file__).read_bytes()),'originalComparatorProblems':problems,'rows':observations},ensure_ascii=False,indent=2))

if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,OSError,tarfile.TarError,json.JSONDecodeError) as error:
        print(json.dumps({'schema':'r02-native-census-count-audit/1','ok':False,'error':str(error),'notASecondNativeExecution':True},ensure_ascii=False));raise SystemExit(1)
