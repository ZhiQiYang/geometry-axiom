"""Run an unchanged command while reaping only its orphaned descendants.

Container PID 1 does not reap killed grandchildren. This process-local
subreaper supplies that missing init behavior without changing the test,
its process groups, /proc assertions, timeouts, or system configuration.
"""
import ctypes
import os
from pathlib import Path
import subprocess
import sys
import threading

libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER")
command = sys.argv[1:]
if not command:
    raise SystemExit("command required")
child = subprocess.Popen(command)
done = threading.Event()
adopted = []

def reap():
    while not done.is_set():
        # The command's main child is waited by subprocess, never this thread.
        # Linux may assign an adopted child to any live thread in the
        # subreaper's thread group, not necessarily its group leader.
        children = set()
        for path in Path('/proc/self/task').glob('*/children'):
            try:
                children.update(map(int, path.read_text().split()))
            except FileNotFoundError:
                pass
        for pid in children:
            if pid == child.pid:
                continue
            try:
                result, status = os.waitpid(pid, os.WNOHANG)
                if result:
                    adopted.append({'pid': result, 'waitStatus': status})
            except ChildProcessError:
                pass
        done.wait(0.01)

thread = threading.Thread(target=reap)
thread.start()
try:
    code = child.wait()
finally:
    done.set()
    thread.join()
print('OWNED_ORPHAN_REAP ' + repr(adopted), flush=True)
raise SystemExit(code)
