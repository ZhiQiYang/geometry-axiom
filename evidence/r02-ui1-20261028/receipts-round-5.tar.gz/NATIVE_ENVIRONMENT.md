# R02 native 環境失敗與局部恢復

受驗來源：`ffa22ad9245021c17c0a827847270bc5882cbb69`，產品與測試未修改。

完整 census 的 `test_assembly_mutation_check.AssemblyMutationCheck.test_run_logged_kills_the_whole_group_and_records_that_nothing_is_left` 在原 `self.assertEqual([], group['afterKill'])` 失敗。原件 `py_test_assembly_mutation_check.unittest.log` 指出 PID 64398、PGID/session 64396 的 `sleep` 留在 Z 狀態；另讀 `/proc/64398/stat` 確認 PPID=1。這是容器 PID 1 未回收已死亡孤兒程序，不能把 zombie 忽略或刪掉原斷言。

只在證據工具加入 process-local subreaper，既有測試的 kill、/proc 觀察、五秒清空期限與斷言完全不變。前兩次包裝依賴此核心未提供的 `/proc/<pid>/task/<tid>/children`，仍然失敗；原 stdout/stderr/result 分別保留在 `native-assembly-environment-retest` 與 `native-assembly-environment-retest-v2`。第三版改用 `waitid(P_ALL, WEXITED|WNOHANG|WNOWAIT)` 查自己的已死亡子程序，排除主 command PID，僅 `waitpid` 回收本包裝採納的孤兒。沒有修改全域 init、mount、quota、權限或任何系統安全設定，也沒有處理其他人的程序。

`native-assembly-environment-retest-v3`：實際命令 `python3 tools/reap-owned.py python3 -B tests/test_assembly_mutation_check.py`（完整絕對路徑見 result.json），exit 0，3.885354 秒，12 tests／0 failures／0 skips；確實回收兩個 waitStatus=9 的孤兒。此為已診斷環境問題的局部恢復，**不是第二次完整 native 通過**。完整 census 的原始終態另據原件記錄，不移標、不覆寫。

`--update-expected` 只更新測試發現數；原裁判明定有 assertion fail 仍可記錄完整 census 數量。核收只接受原 224 suites 加兩個具名 suites（Python 9、Node 21），及既有 Node aggregate 新增保存模組的 11 項（737→748）；其餘 count／mode 必須逐項全等。數量核收不代替產品通過。

原完整 census 終態：exit 1，1942.532594 秒，226 suites、5221 pass／4 fail／1 個原允許 GDI skip。四個 fail 屬三 suites：assembly 1、archive mutation anchor 2、Node aggregate 1。後兩者分別是兩個舊 guard 字串錨點、及舊測試仍把本片已採納的 /19 視為未知格式。

數量核收首輪擋下生成器額外把 rectangular-template 的說明單位從 `unittest` 正規化成 `test`；原生成 JSON 完整保存為 `native-final-support/generated-expected.json.gz`。恢復舊單位文字、保留舊縮排後，`native-count-audit-final` exit 0，使用原 stdout table 與原 suite logs 核收，只有上述三項數量變動，沒有更改任何既有 count。它不是第二次 native 執行。

修復後來源 `79049d7e0c4a60f7a5e2ff4c7023cd713f0c387f` 的 `native-affected-final`：`python3 tests/run_all.py --build --only py:test_assembly_mutation_check --only py:test_mutation_anchors --only node:tests-js`，由上述同一 process-local reaper 包裝，128.443543 秒、exit 0，763 pass／0 fail／0 skip；原 expected 嚴格數量比較啟用。原完整 log 目錄保全至 `/tmp/geometry-tests/run_all-logs-r02-ffa22ad9-original`，其持久逐檔原件已在 `native-final-support/suite-logs.tar.gz`；局部複驗原流在 `native-affected-support/original-logs.tar.gz`。不宣稱完整 native 重新執行或 exit 0。

Archive 原六案均具名 0/1/0；格式測試增加已知 /19 正向斷言，原未知版本負例改為 /20，999、原型字串、null、數值與降版／缺能力斷言不變，撤回／恢復為 1/0。修復未改產品碼；最終帳本 check 仍 exit 0、0 stale。
