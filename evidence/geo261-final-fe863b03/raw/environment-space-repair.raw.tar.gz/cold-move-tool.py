#!/usr/bin/env python3
"""逐檔驗證已結束 scratch 的跨裝置冷存；核對完成才刪原拷貝、保留 /tmp symlink。"""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import stat
import time

COLD = Path('/workspace/geo261-cold')
NAMES = ('g261a1', 'g261seal')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def progress(phase, **values):
    print(json.dumps({'utc': now(), 'phase': phase, **values}, ensure_ascii=False), flush=True)


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_size, info.st_mtime_ns, info.st_nlink)


def snapshot(root, phase):
    result, hardlinks = [], collections.defaultdict(list)
    todo = [root]
    last = time.monotonic()
    while todo:
        path = todo.pop()
        info = path.lstat()
        relative = path.relative_to(root).as_posix()
        row = {'path': relative, 'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid,
               'gid': info.st_gid, 'mtime_ns': info.st_mtime_ns}
        if stat.S_ISDIR(info.st_mode):
            row['kind'] = 'directory'
            todo.extend(sorted((Path(item.path) for item in os.scandir(path)), reverse=True))
        elif stat.S_ISREG(info.st_mode):
            row.update(kind='regular', bytes=info.st_size, sha256=sha(path), nlink=info.st_nlink)
            require(fingerprint(info) == fingerprint(path.lstat()), '讀取中原檔改變：' + str(path))
            if info.st_nlink > 1:
                hardlinks[(info.st_dev, info.st_ino)].append(relative)
        elif stat.S_ISLNK(info.st_mode):
            row.update(kind='symlink', target=os.readlink(path))
        elif stat.S_ISSOCK(info.st_mode):
            row['kind'] = 'socket'
        elif stat.S_ISFIFO(info.st_mode):
            row['kind'] = 'fifo'
        else:
            raise RuntimeError('未授權複製的特殊節點：' + str(path))
        result.append(row)
        if time.monotonic() - last >= 15:
            progress(phase, entries=len(result), regular_files=sum(r['kind'] == 'regular' for r in result))
            last = time.monotonic()
    return sorted(result, key=lambda row: row['path']), sorted(sorted(paths) for paths in hardlinks.values())


def preserve_metadata(source, destination, row):
    if destination.lstat().st_uid != row['uid'] or destination.lstat().st_gid != row['gid']:
        os.chown(destination, row['uid'], row['gid'], follow_symlinks=False)
    shutil.copystat(source, destination, follow_symlinks=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name', choices=NAMES, required=True)
    args = parser.parse_args()
    source, destination = Path('/tmp') / args.name, COLD / args.name
    backup = source.with_name('.' + args.name + '-verified-cold-original')
    require(source.is_dir() and not source.is_symlink(), '來源不是原始實體目錄')
    require(not destination.exists() and not destination.is_symlink(), '拒絕覆寫冷存目的地')
    require(not backup.exists() and not backup.is_symlink(), '拒絕覆寫原件保留路徑')
    COLD.mkdir(exist_ok=True)
    report_path = COLD / (args.name + '-move.json')
    require(not report_path.exists(), '拒絕覆寫既有移轉報告')
    report = {'schema': 'geo261-verified-cold-scratch-move/1', 'started_utc': now(),
              'source': str(source), 'destination': str(destination), 'state': 'started',
              'product_or_tests_executed': False, 'git_commands_executed': False,
              'original_removed': False, 'verified': False,
              'scope': '只處理指定已完成 scratch；不掃描或修改其他 source/newproof 路徑。'}
    write(report_path, report)
    try:
        progress('source-inventory-start', source=str(source))
        before, original_hardlinks = snapshot(source, 'source-inventory')
        require(not original_hardlinks, '出現初查未見的 hardlinks；停止，原件不刪')
        counts = dict(collections.Counter(row['kind'] for row in before))
        regular_bytes = sum(row.get('bytes', 0) for row in before)
        source_manifest = COLD / (args.name + '-source-manifest.json')
        write(source_manifest, {'root': str(source), 'files': before, 'hardlink_groups': original_hardlinks})
        report.update(state='source-inventoried', node_counts=counts, regular_bytes=regular_bytes,
                      source_manifest=str(source_manifest), source_manifest_sha256=sha(source_manifest))
        write(report_path, report)
        progress('copy-start', entries=len(before), regular_files=counts.get('regular', 0), regular_bytes=regular_bytes)
        last = time.monotonic()
        copied_files = copied_bytes = 0
        for row in before:
            old, new = source / row['path'], destination / row['path']
            kind = row['kind']
            if kind == 'directory':
                new.mkdir(mode=0o700, parents=True, exist_ok=True)
                continue
            new.parent.mkdir(parents=True, exist_ok=True)
            if kind == 'regular':
                original_info = old.lstat()
                value, size = hashlib.sha256(), 0
                with old.open('rb') as incoming, new.open('xb') as outgoing:
                    for chunk in iter(lambda: incoming.read(1024 * 1024), b''):
                        outgoing.write(chunk)
                        value.update(chunk)
                        size += len(chunk)
                require(size == row['bytes'] and value.hexdigest() == row['sha256'], '複製途中 bytes/hash 不同：' + str(old))
                require(fingerprint(original_info) == fingerprint(old.lstat()), '複製途中原檔變動：' + str(old))
                copied_files += 1
                copied_bytes += size
            elif kind == 'symlink':
                os.symlink(row['target'], new)
            elif kind == 'socket':
                previous_cwd = os.getcwd()
                try:
                    os.chdir(new.parent)
                    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as handle:
                        handle.bind(new.name)
                finally:
                    os.chdir(previous_cwd)
            elif kind == 'fifo':
                os.mkfifo(new, row['mode'])
            else:
                raise RuntimeError('未知種類')
            preserve_metadata(old, new, row)
            if time.monotonic() - last >= 15:
                progress('copy', regular_files=copied_files, regular_bytes=copied_bytes)
                last = time.monotonic()
        for row in reversed(before):
            if row['kind'] == 'directory':
                preserve_metadata(source / row['path'], destination / row['path'], row)
        progress('destination-full-sha-start')
        actual, actual_hardlinks = snapshot(destination, 'destination-verification')
        require(actual == before and actual_hardlinks == original_hardlinks, '冷存 pathset/lstat種類/mode/owner/time/link/全部regular SHA 不同，原件保留')
        target_manifest = COLD / (args.name + '-destination-manifest.json')
        write(target_manifest, {'root': str(destination), 'files': actual, 'hardlink_groups': actual_hardlinks})
        progress('source-final-full-sha-start')
        final, final_hardlinks = snapshot(source, 'source-final-verification')
        require(final == before and final_hardlinks == original_hardlinks, '驗證期間原目錄變動，原件保留')
        report.update(state='fully-verified-before-removal', verified=True, verified_at_utc=now(),
                      verified_regular_files=counts.get('regular', 0), verified_bytes=regular_bytes,
                      verified_pathset=True, verified_lstat_kinds=True, verified_modes_owner_times=True,
                      verified_symlink_targets=True, verified_hardlink_groups=True,
                      destination_manifest=str(target_manifest), destination_manifest_sha256=sha(target_manifest),
                      socket_nodes_recreated_without_data=counts.get('socket', 0),
                      socket_binding='以目的節點 parent 為 cwd，bind basename；close 後保留同名 socket 節點，不複製活連線。')
        write(report_path, report)
        progress('fully-verified-install-symlink', regular_files=counts.get('regular', 0), regular_bytes=regular_bytes)
        source.rename(backup)
        try:
            source.symlink_to(destination, target_is_directory=True)
        except BaseException:
            backup.rename(source)
            raise
        require(source.is_symlink() and os.readlink(source) == str(destination) and source.resolve() == destination.resolve(), '原路徑 symlink 核對失敗；backup保留')
        report.update(state='symlink-installed-original-retained', original_backup=str(backup))
        write(report_path, report)
        shutil.rmtree(backup)
        report.update(state='completed', original_removed=True, original_removed_only_after_full_verification=True,
                      source_preserved_as_symlink=True, symlink_target=os.readlink(source),
                      finished_utc=now())
        write(report_path, report)
        progress('completed', source=str(source), destination=str(destination),
                 regular_files=counts.get('regular', 0), regular_bytes=regular_bytes,
                 sockets=counts.get('socket', 0), report=str(report_path))
        return 0
    except BaseException as error:
        report.update(state='failed', error_type=type(error).__name__, error=str(error), failed_utc=now())
        write(report_path, report)
        raise


if __name__ == '__main__':
    raise SystemExit(main())
