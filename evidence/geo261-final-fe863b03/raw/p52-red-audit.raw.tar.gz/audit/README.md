# F P52 紅燈：純讀稽核備忘

**結論：原 P52／verifier exit1 有效，分類為「現行相對效能驗收失敗，根因未證」。** 不能因差9.299ms就歸環境，也不能用A曾綠改寫F。沒有重跑產品、修改門檻、挑樣本或啟動新量測。

固定F：`fe863b0374eafd9f1e57ec5107e28a1101804b56`；對照A：`a12d184ec1865ad078700cea2387ac69e82ab62a`；main：`adbaebf9c73ea6801d7b4d5214e4b846b132923b`。原收據與streams複本在 `raw/`，逐檔來源與hash見 `RAW_INVENTORY.json`；本備忘是純檔案分析，不是另一輪測試收據。

## 1. 真正來源邊界：730檔相同，canonical HTML不同

`postfix_validate.py:58–69` 建乾淨fix clone、npm build，依序main/fix/fix/main；main讀 `/tmp/g261r2/work/p52-main/main`，fix讀 `/tmp/g261r2/work/codex-geo261-fe863b03/repo`。每塊8次、獨立server/Chrome profile/port。Node直接讀該repo的 `geometry-web/cdp_test.js`，擷取原P52/viewport/setup/bootstrap；main用 `p52_probe.cjs`，fix用 `p52_cases.cjs` measure，均量實點擊至輪詢references取得timber3。測時包含瀏覽器/CDP/API與25ms輪詢等待，不是純native CPU時間。

A→F的產品路徑Git差異只有canonical reader HTML、架構report/receipt、expected三個count；其餘為evidence。幾何C、host Python、web JS/CSS、原P52與相關外部Node工具均未改，但**不能推成整個量測輸入逐bytes相同**。

`geometry-web/serve.py:525–537` 對非readonly POST執行 `RUNTIME.fresh()`；references/dump/source-inspect在readonly allowlist內。實點擊的 `line timber`／`line place` 等mutation仍走此檢查。`runtime_version.py:26–34` 的static catalog包含 `/axioms`→canonical HTML；`:160–184` freshness逐檔讀完整內容，前後各完整盤點，不能把這個HTML視為不讀的說明檔。

按未改source_files/static_files規則，以純檔案方式重建實際clone清單與runtime version：兩邊皆731檔，相同pathset；730檔raw hash相同，唯一不同為 `geometry-guide/公理層-閱讀器.html`，A=7,006,717bytes、F=7,006,725bytes（+8）。整組讀取量A=22,423,648bytes、F=22,423,656bytes。重建version逐字符合原runtime.json：A `a8237b597f8a90a0a9462387634740aebdcf3b27bf77c68e300be9a77ec4b2a0`，F `cd81de63bf434ea48424aa1a8df8cfcd556b76f4b621a6a2d221fa47d75e35e3`；兩輪main均 `6487bf2445a1ea63a74b949df3f9cbe7d55678db1ec988c51c52457a5dced21c`。完整逐檔hash見 `runtime-inputs.json`。

這證明HTML在放置守門路徑的bytes不同，**不證明多8bytes造成9.299ms**。expected JSON、架構md/json與evidence不在此731檔。此核對沒有另讀native ELF或把編譯環境說成逐bytes相同。A目前已冷存，這是事後內容核對；原A量測時仍在/tmp，不能用目前冷存讀速解釋舊樣本。

## 2. 全部既有樣本與400ms觀察

| 輪次／block，每塊8筆 | min–max ms | median ms |
|---|---:|---:|
| F 0-main | 207.115–250.935 | 241.630 |
| F 1-fix | 220.567–264.379 | 250.057 |
| F 2-fix | 232.210–297.066 | 262.696 |
| F 3-main | 222.530–361.323 | 243.407 |
| A 0-main | 175.575–270.176 | 255.942 |
| A 1-fix | 199.326–287.546 | 235.037 |
| A 2-fix | 184.069–241.574 | 232.664 |
| A 3-main | 217.050–307.282 | 234.362 |

F合併main16筆median243.0916735ms，fix16筆252.3903700ms，ratio **1.03825180997**，原no_regression=false。A合併main242.3152350ms、fix232.6639955ms，ratio0.960170727606。沒有刪除任何尾端、首筆或outlier；明細保存在 `sample-analysis.json`。

F32筆與A32筆都觀察到appearedMs<400，F最大為main361.323／fix297.066ms；每筆pre.busy=false、命中g:2:v。兩輪所有實際geometry都一致：surface1、A27/B33、centerline2000、length2946、u2014/v27、+v/+n、origin[2014,27,2500]，原足跡1987..2014斷言全綠。這只是既有樣本在400ms內取得g的觀察；measure是10秒上限輪詢，不是重跑原sleep400版本，也不取消獨立相對median gate。

5個等待控制全部證明：normal/delay原Node0，revert-delay/wrong/missing原Node1，expected_behavior_proved均true。900ms delay能被有界等待接住、撤回等待則原足跡紅、wrong幾何紅、missing在5000ms具名等待失敗。它們證明等待與幾何裁判敏感度，不能直接證明相對效能沒有退化。P52與verifier外層均實際exit1、無watchdog timeout。

原browser transcript的純相減顯示fix側A/F `line place 3` median85.65/95.10ms、`line timber 3`53.65/56.80ms；只是已有觀測，request會重疊、部分未完，不相加推CPU或歸因。詳 `A-request-durations.json`／`F-request-durations.json`。

## 3. ≤1.0 gate的版本來源

handoff分支 `804afbb4…:handoff/HANDOFF.md:80–82` 要求量main與7dae並分類產品退化或fixed sleep，該段沒有另訂數值相對gate。後來本次接手必讀的整合分支交接 **`0da1f08c75a411442a2e4a431e72459563b8b9a2:evidence/geo261-cloud-handoff-20261022.md:143`** 明文：「要求fix中位數≤main」。Git歷史顯示該文字由0da交接commit帶入。

同commit的 `evidence/geo261-cloud-postfix_validate.py.txt:77` 已有 `medians['fix']<=medians['main']`，`:101`據此退出0或1；`geo261-cloud-verify_postfix_receipt.py.txt:29`已assert no_regression true。此gate不是F新加。F的postfix_validate與該版本逐字diff只有WORK、Chrome與clone路徑；p52_measure另有固定SHA及環境路徑適配，沒有改取樣或相對gate。Node兩工具與verifier的原hash不變。原件/current及精確diff在 `source/` 與 `*.exact-adaptation.diff`，hash在 `tool-provenance.json`。

可見的使用者原始請求要求P52耗時與依交接做法，沒有直接另給數字容忍；以上只證明交接與既有工具已鎖此gate，不冒稱找到了更早的使用者逐字授權或可自行放寬的例外。

## 4. 可支持的分類、不能代決的改法

- 現行相對門檻確實未過；不是timeout、缺結果、控制失效或工具才新增門檻。足跡及有界等待控制另行通過，不補相對gate。
- A/F核心運算碼相同與A曾綠，只能限制新增產品碼的歸因範圍。731輸入並非全相同；樣本range重疊與9ms差額也不足以證明環境。沒有OS/負載/caller profile可判定此次差額的根因。
- 若改用≤400ms絕對上限、例如1.05容許比率、統計容忍區間或追加樣本後挑綠，都會改變現有驗收規則；本稽核沒有採用。需要新判準才能把現有1.038判為綠時，必須由使用者明示決策並保留原紅，不能在此備忘內代決。
- 另一條仍可行的路徑是找出可驗證的產品成本、修正後重新固定來源與依規則重產/完整驗收。純讀線索是freshness每次完整掃描/讀取約22.4MB，reader約7MB，且放置過程多個mutation會各經守門；raw transcript顯示line place是本次較長端點之一。這只是後續定位範圍，尚無caller profile證明瓶頸，不能刪/搬公開canonical route、減少守門次數、加TTL或先省來源讀取。

本備忘不阻擋既有formal pipeline收集其餘項目；P52紅燈須在最終結果中原樣列出。沒有重跑量測、產品服務、測試、編譯或改任何repo檔案。
