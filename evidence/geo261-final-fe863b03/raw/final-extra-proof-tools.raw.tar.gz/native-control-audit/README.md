# F native 控制原始輸出獨立核對

本份為純讀稽核，受驗 F=`fe863b0374eafd9f1e57ec5107e28a1101804b56`，原 clone `/tmp/g261r2/source-final` 於稽核時 HEAD 正確且乾淨。沒有執行測試、編譯器、scanner 或產品。

`AUDIT.json` 的 `passed` 只表示本次核對通過，不能當作完整 native job 已結束。稽核時原 native receipt 仍標示「執行中」；原 job 完成後將自行封存整份 run_all-logs。本包只保存小份派生核對及96筆 JSON，不複製大樹。

已核對五個 suite 摘要全部通過、0 skip，並以原 job 啟動時間、開始時 SHA/乾淨狀態、GITHUB_SHA/WORKSPACE、before-inventory 與各 log 更新時間，以及每筆 binary 的本輪暫存路徑，排除沿用舊輪日誌。

| Suite | 本輪實際保存情況 |
| --- | --- |
| definition_sources | 全12控 ×3，36筆完整命令、真退出0/1/0、stdout/stderr文字 |
| host_facts_authority | 新8個 raw snapshot 控制 ×3，24筆完整紀錄；舊13控與hole-index未列印捕捉流 |
| placement_definition | 新12個header控制 ×3，36筆完整紀錄；舊20控未列印捕捉流 |
| source_index | 8個舊突變只印退出1與strip後ASSERT摘要；基準/恢復原流不完整 |
| wood_contact_world | 20個舊native控及額外owner-extension整合控捕捉但不列印；主log為0 bytes |

32控96筆全核對 exact control names、baseline/mutant/restored 順序、真退出0/1/0、timedOut=false、空stdout、具名ASSERT及原尾端換行、綠階段空stderr。`CONTROL_RECORDS.json` 是原主log每行JSON的派生解析；原log SHA256/大小/mtime與suite摘要逐項記於AUDIT，並保留來源路徑。主 `.log` 有紀錄，`.unittest.log` 只有摘要，二者不可混稱。

`CHECKER_DETAILS.json` 及三份patch定位 W checker 唯一修改。方法為 `ContactWorldBoundary.test_five_real_main_consumers_delegate_and_keep_original_member_identity`，原方法把 app_contact_facts 薄wrapper當成原member迴圈；修正後先要求wrapper精確委派prepare，再在prepare保留原member identity/boundary斷言。9535→P 只有此差分，P→F空；不新增子程序負控。

已找到早期真紅綠原raw並複製小檔供定位：原b3b08214封存的 `targeted-native-rawsnapshot` 為退出1（該方法具名FAIL，另有缺limits.h的ERROR）；fixed為退出0、該方法ok、82tests全過。這是歷史dirty來源的先紅後綠，不是F受控withdrawal，不能取代F同SHA自證。原archive/member/hash/來源與真退出保存在CHECKER_DETAILS。

尚未發現 F-bound old-checker 撤回/還原原raw。最小補證建議：fresh isolated F，產品來源不變，僅套 `checker-withdraw-F-to-9535.patch`；依序對同一具名原static方法 fixed0 / withdrawn1 / restored0，完整保存原命令與兩串流。單一方法不呼叫NativeBuild，也不執行舊20控；其所在class無setUpClass。新recorder由root另授權準備，未在此稽核執行。

沒有找到現成source-index 8控或contact-world 20控全原流driver。舊9535dirty targeted紀錄也只提供相同96筆JSON與index摘要。`record_node_hash_equivalence.py` 驗舊新0/0等價，不能冒充8控0/1/0。這些舊控界線不外推為本輪具有完整raw之32控的缺口；32控包含W舊5控＋新7控、H新8控及K新12控。
