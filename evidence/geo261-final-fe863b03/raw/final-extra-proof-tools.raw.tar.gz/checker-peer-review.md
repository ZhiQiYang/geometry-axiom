# F contact static checker 三輪自證：獨立純靜態互審

審查者為 `next_work_323_audit`。只讀候選程式、capture、README、PREPARATION、撤回 patch、實際原方法與其 lazy import／class 設定，並以唯讀 Git blob／SHA256 核對 F 與舊 checker。沒有 import、執行錄製器、AST、mock、unittest、scanner、編譯、產品或性能量測，沒有修改 repository 或候選工具。

最終審查來源：

| 檔案 | SHA256 |
|---|---|
| `run_final_checker_proof.py` | `80e85be64adb003e1c85a2f7fc723157d78c37d90a40036d0edac1da517453bb` |
| `capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |

靜態未見阻擋，可交 root 封存並在正式 F pipeline 結束、共用鎖可用後執行。這不是 fixed／withdrawn／restored 已執行或自證已通過的聲明。

## 原來源與最小撤回

工具明確限定最終 F `fe863b0374eafd9f1e57ec5107e28a1101804b56`，要求原 checkout 的 HEAD／clean 與 clone HEAD 相同。F 的 `tests/test_geo261_wood_contact_world.py` SHA256 為 `ca028800aa8d614fa34749b32b3e819d9dc6c351b8b4f09d7fd091f95402d181`，舊 `9535fcfcec9d1fc8ddd4b149f499bd4e2312f255` 同檔 SHA256 為 `5a73d425e113284924f2a842c3760012affe15e9735d1d6da3eb074bd531da48`；本次已從真 Git blobs 核對這兩個值。

runtime 還會要求 F 的唯一三行 wrapper／新增 delegation assertEqual／prepare 定位，精確改回一行舊 wrapper 定位後，整檔 bytes 等於舊 Git blob。原 member identity regex、boundary 與 resolver asserts 保留；撤回移除的是本次新增 wrapper assertEqual 與 helper 定位，不把此範圍泛稱為完全不改任何 assert。變異僅在新 scratch 的獨立 working tree，來源 repo 不寫入。整棵 tracked status／diff／index 檢查只准該 test file unstaged 差分，另核實際三個產品輸入 raw hashes。

## 原單一方法與判準

三輪均只呼叫 `tests.test_geo261_wood_contact_world.ContactWorldBoundary.test_five_real_main_consumers_delegate_and_keep_original_member_identity`。該 class 沒有會編譯 native 的 setup；匯入的 NativeBuild 是 lazy 定義，所選方法不呼叫 native()、bridge lookup 或 WoodContactWorld 的 setup／20 控制。所選方法只讀 current_geometry.c；W 公用兩檔是錄製器額外做 bytes guard，不能宣稱它們的另一方法 assertions 本輪也有執行。

fixed／restored 必須真 rc0、stdout 空、原 Ran 1 test、乾淨 OK。withdrawn 必須真 rc1、同一完整具名 FAIL、原 Regex didn't match、既知 wrapper body，且摘要恰為 FAILED (failures=1)。本方法唯一 positive assertRegex 是鎖定的 timber identity pattern，因此加上舊整檔 hash 與特定 wrapper body 的檢查，可將紅燈綁回原 helper 定位病因。實際 wrapper 是單行 `{app_contact_facts_prepare(...);}`，既知 failure body 不含額外換行／縮排；候選 literal 對此一致。

ERROR、skip、crash、timeout、stdout 異常或其他 failure 皆不算有效撤回紅。120 秒是 infra watchdog，沒有成為新的產品門檻。child 改用 sys.executable，與記錄版本一致；三階段 argv 完全相同。

## 原始證據與還原

必填的是同一正式 F 既存 heavy lock，非阻塞 flock；不得在外層再次鎖同一把。每個子命令保存真 argv／cwd／SHA／variant／退出碼、stdin、完整 stdout／stderr 與 hash；timeout partial 與 kill/wait 後 streams 分開保存。phase environment 記 clone 的實際 GITHUB_WORKSPACE，withdrawn 標記 test-only dirty checker variant，沒有冒稱乾淨 F。

三輪一般紅燈會收齊；mutation setup 錯誤仍經 inner finally 回寫 F，接著嘗試 restored。outer finally 再還原並核 clone、原 repo 與工具來源；任何錯誤使整體 passed=false，不以 compile／ERROR 當負控紅，也不自動重試挑綠。新 scratch 與原命名固定 F，沒有舊結果或舊 SHA 的覆寫路徑。

本輪提出兩項小修均已採納：README 精確區分所選方法實讀 current 與額外 W hash guard，並說明撤回的新增 assertEqual；child 使用 sys.executable。未要求放寬 regex、測試或來源斷言。runtime 真結果、實際磁碟空間與環境仍須由 root 後續執行收據證明。
