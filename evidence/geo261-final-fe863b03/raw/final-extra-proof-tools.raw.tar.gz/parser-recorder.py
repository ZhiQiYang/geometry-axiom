#!/usr/bin/env python3
"""錄製實際 K placement source 的完整 decoder／header reader 差分；prepare 不編譯。"""
from __future__ import annotations

import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import shlex
import shutil
import signal
import subprocess
import sys
import time
import traceback

INPUTS = ('geometry-core/kernel/placement_sources.c',
          'geometry-core/kernel/placement_sources.h',
          'geometry-core/kernel/placements.h', 'geometry-core/kernel/regions.h',
          'geometry-core/kernel/geometry.h', 'geometry-core/kernel/types.h',
          'geometry-core/kernel/source.h')
CONTEXT = ('current_geometry.c', 'geometry-core/kernel/source.c',
           'geometry-app/native/reference_sources.inc',
           'geometry-templates/woodworking/native/definition_sources.c',
           'geometry-templates/woodworking/native/definition_sources.h',
           'geometry-templates/woodworking/native/contact_sources.c',
           'geometry-web/app.js')
CLIENT = Path('/workspace/geo261-environment/placement_header_equivalence.c')
EXPECTED_SOURCE = '45e754f4260e15679797b8f44c8c6a25132b199d47a7239da1e2045a8a814c31'
EXPECTED_HEADER = '9c11cb94b20231dabf746c6f23480b5c3d324fc9d268b0140a3e01fab4781aa8'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def function_bytes(content, name):
    """Exact byte slice, skipping C comments/quoted text while matching braces."""
    pattern = rb'^(?:static[ \t]+)?(?:bool|size_t)[ \t]+'+re.escape(name.encode())+rb'[ \t]*\([^;{}]*\)[ \t\r\n]*\{'
    matches = list(re.finditer(pattern, content, flags=re.M))
    if len(matches) != 1:
        raise ValueError(f'原函式 {name} 宣告數={len(matches)}，必須恰一')
    match = matches[0]
    at = match.end()-1
    depth = 0
    state = 'code'
    quote = 0
    while at < len(content):
        byte = content[at]
        pair = content[at:at+2]
        if state == 'line':
            if byte == 10:
                state = 'code'
        elif state == 'block':
            if pair == b'*/':
                state = 'code'
                at += 2
                continue
        elif state == 'quote':
            if byte == 92:
                at += 2
                continue
            if byte == quote:
                state = 'code'
        elif pair == b'//':
            state = 'line'
            at += 2
            continue
        elif pair == b'/*':
            state = 'block'
            at += 2
            continue
        elif byte in (34,39):
            state = 'quote'
            quote = byte
        elif byte == 123:
            depth += 1
        elif byte == 125:
            depth -= 1
            if not depth:
                return content[match.start():at+1]
        at += 1
    raise ValueError('函式未閉合：'+name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path('/workspace/geometry-axiom'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--phase', choices=('prepare','o2','sanitized'), required=True)
    parser.add_argument('--cc', default='gcc')
    parser.add_argument('--expected-source-sha256', default=EXPECTED_SOURCE)
    parser.add_argument('--expected-header-sha256', default=EXPECTED_HEADER)
    parser.add_argument('--lock', type=Path, default=Path('/tmp/g261r1/heavy.lock'))
    args = parser.parse_args()
    repo = args.repo.resolve()
    out = args.out.resolve()
    assert out.is_relative_to(Path('/tmp')) or out.is_relative_to(Path('/workspace'))
    assert out != repo and not out.is_relative_to(repo), '輸出須在 repository 外'
    if args.phase == 'prepare':
        out.mkdir(parents=True, exist_ok=False)
    else:
        assert (out/'prepared.json').is_file()
    commands = out/'commands'
    commands.mkdir(exist_ok=True)
    phase_dir = out/(args.phase+'-record')
    phase_dir.mkdir(exist_ok=False)
    before = {path:digest((repo/path).read_bytes()) for path in (*INPUTS,*CONTEXT)}
    env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8',
               PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
    env['TMPDIR'] = str(phase_dir/'tmp')
    Path(env['TMPDIR']).mkdir()
    if args.phase == 'sanitized':
        env.update(ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    safe_names = ('PATH','CC','LANG','LC_ALL','TMPDIR','ASAN_OPTIONS','UBSAN_OPTIONS',
                  'PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING')
    safe_env = {name:env[name] for name in safe_names if name in env}
    records = []
    head = None
    summary = {'schema':'geo261-placement-header-raw-differential/1', 'phase':args.phase,
               'notFinalSourceAcceptance':True, 'oracleSourceSameFile':True,
               'noCopiedProductionParserCompiled':True,
               'sourceHashesBefore':before,'environment':safe_env,
               'platform':platform.platform(),'pythonVersion':platform.python_version(),
               'stackSoftHardBytes':list(resource.getrlimit(resource.RLIMIT_STACK)),
               'recorderSha256':digest(Path(__file__).read_bytes()),
               'clientCurrentSha256':digest(CLIENT.read_bytes()),
               'heavyLock':str(args.lock),'records':records,
               'passResult':False,'exitCode':1,'startedUtc':now()}
    write_json(phase_dir/'receipt.json',summary)

    def run(label, argv, timeout=120):
        directory = commands/f'{len(list(commands.iterdir())):03d}-{args.phase}-{label}'
        directory.mkdir()
        row = {'label':label,'argv':argv,'cwd':str(repo),'startedUtc':now(),
               'sourceBaseHead':head,'sourceHashesBefore':before,'environment':safe_env,
               'stdout':str(directory/'stdout'),'stderr':str(directory/'stderr'),
               'timeoutSeconds':timeout}
        started = time.monotonic()
        with (directory/'stdout').open('xb') as stdout, (directory/'stderr').open('xb') as stderr:
            try:
                process = subprocess.Popen(argv,cwd=repo,env=env,stdout=stdout,
                                           stderr=stderr,start_new_session=True)
                code = process.wait(timeout=timeout)
                row['actualProcessReturncode'] = code
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
                code = 124
                row.update(timeoutExpired=True,actualProcessReturncode=process.returncode)
            except OSError as error:
                code = 125
                row.update(launchError=str(error),actualProcessReturncode=None)
        row.update(exitCode=code,seconds=time.monotonic()-started,finishedUtc=now())
        for stream in ('stdout','stderr'):
            raw = Path(row[stream]).read_bytes()
            row[stream+'Sha256'] = digest(raw)
            row[stream+'Bytes'] = len(raw)
        write_json(directory/'receipt.json',row)
        records.append(row)
        write_json(phase_dir/'receipt.json',summary)
        print(json.dumps({'label':label,'exitCode':code,'stdout':row['stdout'],
                          'stderr':row['stderr']},ensure_ascii=False),flush=True)
        return row

    def git(label,*parts):
        row = run(label,['git','-C',str(repo),*parts])
        if row['exitCode']:
            raise RuntimeError('Git 前置失敗，原 streams 已保存：'+label)
        return Path(row['stdout']).read_bytes()

    success = False
    try:
        head = git('head','rev-parse','HEAD').decode().strip()
        summary['sourceBaseHead'] = head
        summary['checkoutStatus'] = git('status','status','--porcelain=v1').decode()
        summary['candidateIsDirty'] = bool(summary['checkoutStatus'])
        patch = git('full-checkout-diff','diff','--binary')
        (phase_dir/'full-checkout.patch').write_bytes(patch)
        summary['fullCheckoutDiffSha256'] = digest(patch)
        assert before[INPUTS[0]]==args.expected_source_sha256, 'placement_sources.c 實際候選 hash 不符'
        assert before[INPUTS[1]]==args.expected_header_sha256, 'placement_sources.h 實際候選 hash 不符'
        client = CLIENT.read_bytes()
        include = rb'^[ \t]*#[ \t]*include[ \t]+"placement_sources\.c"[ \t]*(?:\r?\n|$)'
        assert len(re.findall(include,client,flags=re.M))==1, 'client 必須直接 include snapshot placement_sources.c'
        if args.phase == 'prepare':
            kernel = out/'snapshots'/'kernel'
            kernel.mkdir(parents=True)
            for path in INPUTS:
                raw = (repo/path).read_bytes()
                assert digest(raw)==before[path], '準備時來源移動：'+path
                (kernel/Path(path).name).write_bytes(raw)
            shutil.copy2(CLIENT,out/'client.c')
            shutil.copy2(Path(__file__),out/'recorder.py.txt')
            oracle_dir = out/'oracle-reference'
            oracle_dir.mkdir()
            head_source = git('head-oracle-source','show',head+':'+INPUTS[0])
            (oracle_dir/'HEAD-placement_sources.c.txt').write_bytes(head_source)
            current = (kernel/'placement_sources.c').read_bytes()
            oracle_hashes = {}
            for name in ('geo_placement_definition_encode','geo_placement_definition_decode'):
                old = function_bytes(head_source,name)
                actual = function_bytes(current,name)
                (oracle_dir/(name+'-HEAD.c.txt')).write_bytes(old)
                (oracle_dir/(name+'-actual.c.txt')).write_bytes(actual)
                assert old==actual, '原 encoder／完整 decoder 已改，不能當未改 oracle：'+name
                oracle_hashes[name] = {'headSha256':digest(old),'actualSha256':digest(actual),
                                       'bytesEqual':old==actual}
            header_reader = function_bytes(current,'geo_pd_definition_header')
            (oracle_dir/'actual-header-reader.c.txt').write_bytes(header_reader)
            prepared = {'schema':'geo261-placement-header-raw-preparation/1',
                        'candidateBaseHead':head,'candidateSourceHashes':before,
                        'snapshotKernelHashes':{path:before[path] for path in INPUTS},
                        'headFullSourceSha256':digest(head_source),
                        'unchangedOriginalOracleFunctions':oracle_hashes,
                        'headerReaderSha256':digest(header_reader),
                        'clientSha256':digest((out/'client.c').read_bytes()),
                        'recorderSha256':digest((out/'recorder.py.txt').read_bytes()),
                        'fullCheckoutDiffSha256':digest(patch),'preparedUtc':now(),
                        'compiled':False,'testsRun':False,
                        'purpose':'真實同一 source.c 中未改 full decoder 對 private header reader；非 stub、非 parser mirror、非最終驗收'}
            write_json(out/'prepared.json',prepared)
            summary['preparation'] = prepared
            success = True
        else:
            prepared = json.loads((out/'prepared.json').read_text())
            summary['preparation'] = prepared
            assert prepared['candidateSourceHashes']==before, 'root 產品 bytes 已改，須另建診斷目錄'
            assert prepared['clientSha256']==digest((out/'client.c').read_bytes()), 'prepared client 已改'
            assert prepared['recorderSha256']==digest(Path(__file__).read_bytes()), 'recorder 已改，須另建診斷目錄'
            kernel = out/'snapshots'/'kernel'
            for path,value in prepared['snapshotKernelHashes'].items():
                assert digest((kernel/Path(path).name).read_bytes())==value, 'kernel source snapshot 已改：'+path
            compiler = shlex.split(args.cc)
            version = run('compiler-version',[*compiler,'--version'],timeout=30)
            python_version = run('python-version',[sys.executable,'--version'],timeout=30)
            flags = ['-std=c11','-O2'] if args.phase=='o2' else [
                '-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
            binary = phase_dir/'client'
            command = [*compiler,*flags,'-ffunction-sections','-fdata-sections',
                       '-I',str(kernel),str(out/'client.c'),'-Wl,--gc-sections','-o',str(binary)]
            build = run('compile',command,timeout=180)
            summary['build'] = build
            if not build['exitCode']:
                summary['binarySha256'] = digest(binary.read_bytes())
                tested = run('run',[str(binary)],timeout=900)
                summary['run'] = tested
                stdout = Path(tested['stdout']).read_bytes()
                stderr = Path(tested['stderr']).read_bytes()
                lines = stdout.splitlines()
                checks = {'compilerVersionExitZero':version['exitCode']==0,
                          'pythonVersionExitZero':python_version['exitCode']==0,
                          'runExitZero':tested['exitCode']==0,'stderrEmpty':not stderr,
                          'completion':bool(lines) and lines[-1].startswith(b'PASS placement-header-raw-equivalence')}
                summary['checks'] = checks
                summary['stdoutLines'] = len(lines)
                success = all(checks.values())
    except Exception as error:
        summary['fatalError'] = {'type':type(error).__name__,'message':str(error),
                                 'traceback':traceback.format_exc()}
        print(summary['fatalError']['traceback'],file=sys.stderr,flush=True)
    after = {path:digest((repo/path).read_bytes()) for path in (*INPUTS,*CONTEXT)}
    summary.update(sourceHashesAfter=after,sourceBytesUnchanged=before==after,
                   completedUtc=now(),passResult=success and before==after,
                   exitCode=0 if success and before==after else 1)
    write_json(phase_dir/'receipt.json',summary)
    sums = ''.join(digest(path.read_bytes())+'  '+path.relative_to(out).as_posix()+'\n'
                   for path in sorted(out.rglob('*')) if path.is_file() and path.name!='SHA256SUMS')
    (out/'SHA256SUMS').write_text(sums)
    print(json.dumps({'phase':args.phase,'exitCode':summary['exitCode'],
                      'passResult':summary['passResult'],'receipt':str(phase_dir/'receipt.json')},
                     ensure_ascii=False),flush=True)
    return summary['exitCode']


if __name__=='__main__':
    lock_parser = argparse.ArgumentParser(add_help=False)
    lock_parser.add_argument('--lock',type=Path,default=Path('/tmp/g261r1/heavy.lock'))
    lock_args,_ = lock_parser.parse_known_args()
    lock_args.lock.parent.mkdir(parents=True,exist_ok=True)
    with lock_args.lock.open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        raise SystemExit(main())
