# F 正式17項實際數據（已凍結）

唯一來源 `fe863b0374eafd9f1e57ec5107e28a1101804b56`；凍結時間 `2026-10-22T19:29:08.767182+00:00`。7個產品job全0且CI時限內；10專項只有P52／verifier原1，其餘8原0。因此本輪未全綠。

| 項目 | 原退出 | 耗時（秒） | 正式CI分鐘 |
|---|---:|---:|---:|
| native | 0 | 1741.748436 | 35 |
| canvas | 0 | 1811.399284 | 35 |
| assembly | 0 | 200.124664 | 15 |
| documents | 0 | 63.907218 | 10 |
| grid | 0 | 463.831913 | 15 |
| space | 0 | 219.415769 | 15 |
| timber | 0 | 126.534945 | 20 |
| mutation-check-final | 0 | 1.826145 | — |
| p52-prepare-main | 0 | 32.116999 | — |
| p52 | 1 | 407.988845 | — |
| p52-verifier | 1 | 0.134534 | — |
| q38 | 0 | 275.911195 | — |
| card-reference | 0 | 656.273931 | — |
| p189 | 0 | 181.668892 | — |
| architecture-contract | 0 | 5.151033 | — |
| architecture-judge-tests | 0 | 0.644019 | — |
| architecture-product-tests | 0 | 12.014047 | — |

`METRICS.json`保留structured counts／versions／scope／原returncode／CI與watchdog。`items/`保存原收據、topitem與必要原streams；其餘大完整證據由原publisher封存，並未複製候選binary或整包work。

關鍵界線：

- native：224 suites，5185＝5184pass＋GDI1允許skip；reader51、replay6、source-index14均綠。source-index14是6正常＋8負控，不是timing driver的14負控。
- canvas：唯一full CDP_RESULT，2267pass／0fail，85段golden matched、P73=69；raw例外總數1＝預期fb-auto-probe1，非預期0。兩first-failure診斷trace原樣保留。
- assembly／grid是workflow指定partial，保留未做full golden原值；documents未提供completed flag，未杜撰；space／timber保留原scope與omitted groups。
- P52：16+16；main243.0916735ms／fix252.3903700ms，ratio1.03825180997，原no_regression=false。5控制達預期，不能消掉性能紅；verifier第一個timing guard即紅，後續核對未到達。
- Q38：42＝41killed＋SPM24equivalent；baseline native27／model20全綠。SPM38／40原因果ModelError保留。
- §7：53＝50產品＋3裁判，全部killed及restore0；另一report V01–V05各紅1、恢復44綠。兩report在P189完成後才從raw.tgz串流讀取，沒有整包解壓。
- P-189：正式36樣本，四點ratio0.9124386／1.3143002／1.6890589／1.9510335；175dump原記錄全同（75接受＋100拒絕）；不是額外撤回自證。
- 架構三條原0；scanner333 owned／796edges／diagnostics0；generic205、product18、skip0。

原外層退出必須分開看：seven=1來自grid原publisher1／Git128，已普通push修復0並以lsremote確認，原1未改；all-specials=1來自P52／verifier兩個性能判準紅，10個special publisher全0。grid修復原始tool merged記錄不是分開stdout/stderr，收據照實標註。

本快照只彙整17項，沒有新增裁判或重測；額外同F修正自證由root另補。未改產品／測試／driver、未commit/push。快照凍結後不再追蹤新狀態。
