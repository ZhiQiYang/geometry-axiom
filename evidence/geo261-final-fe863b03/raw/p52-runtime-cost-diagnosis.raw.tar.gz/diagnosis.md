# P52 freshness 成本定位與候選省工

正式 F `fe863b0374eafd9f1e57ec5107e28a1101804b56` 的 P52 原退出 1 與 ratio 1.03825180997 維持；本文件不改門檻，也不把隔離 profile 當成 P52 通過。

以 F 的完整 731 檔、22,423,656 bytes 建立 RuntimeSnapshot，獨立 cProfile 20 次 fresh，每次均為 true。原實作總 1.121 秒，其中 source_files 0.679 秒；read_bytes 0.153 秒。單純 Path pool 候選總 0.893 秒；重用已確認相同路徑集合的既有排序及 Path 物件候選總 0.609 秒，其中 source_files 0.205 秒、read_bytes 0.149 秒。這是帶 profiler 的呼叫成本診斷；不是公平交錯 P52 樣本，也不證明原 9.299ms 差額的唯一成因。

擬採用後一個候選：每次仍完整 scandir、確認檔案型別及排除規則、比較整個路徑集合、逐檔讀取所有內容，最後再完整枚舉一次。只有當本次集合精確等於 immutable snapshot 的 keys，才沿用該集合原已排序的順序及 Path 物件；新增／移除仍回傳本次真實集合。沒有快取檔案內容、metadata 授權、TTL、略過守門或改 readonly allowlist。

在 repo 外載入候選 module，執行未修改的原 `tests.test_runtime_version`：31 tests、0 failure/error/skip、原退出 0。包含同大小／同 timestamp 改寫、二進位 vendor、symlink、啟動與 fresh 讀取中新增檔案、無重新 hash 等既有裁判。正式產品尚未修改；此處尚無候選的 P52 量測或撤回自證。

三份 profile 均已保留實際 module bytes、hash、pstats、完整文字 profile、所有 observations、外層原命令／環境／退出及 reaper 事件。讀取放大與共享模型庫的靜態限制另見 MEMO；不以工作區關閉為由刪除 library 讀取。
