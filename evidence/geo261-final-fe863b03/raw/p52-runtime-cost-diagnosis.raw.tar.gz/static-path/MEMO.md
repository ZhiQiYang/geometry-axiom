# P52 量測路徑：純讀定位（一頁）

來源：main `adbaebf9c73ea6801d7b4d5214e4b846b132923b`、F `fe863b0374eafd9f1e57ec5107e28a1101804b56`。**未找到可直接認定為此次9.3ms差額成因的單一非語意缺陷。** 以下是有原碼與既有transcript支持的成本位置；沒有跑產品、編譯、測試或新量測，沒有改repo／工具／判準。

**真正路徑。** `app.js:4889–4942` 點擊放置→newid→source-inspect pin驗證→`mutate():10120` 依序history-begin／timber／place／history-end→settlement的feLoadGuides。`apiRequest():615` 每個成功timber/place回應另發definition event。server `serve.py:525–537` 對非readonly命令先完整runtime freshness，`:181` recorded receipt→`:123` ask_bridge，所有native命令共用bridge_lock。references輪詢是readonly、免web freshness，但仍競逐同bridge_lock；它讀到timber3即結束appearedMs，故settlement後的DOM重繪通常不在此指標內，不能先優化後段render就宣稱修正它。main/F的serve.py、native_context.py逐bytes相同，JS上述transaction／transport流程亦未改。

**具體觀測：definition event放大了library讀取，但不是F新增。** `section-profile-workspace.js:109` 每個event都refreshLibrary→`:104` section-profile-read。F原16trial與main原16trial都恰有32個profile讀；第一筆每trial都在client時間與place request重疊。已完成的profile讀median為main **43.95ms**、F **40.30ms**；這一段F反而較快，不能拿它直接解釋相對紅。line timber為main41.40／F56.80ms，line place為86.80／95.10ms；均包含freshness、排隊與傳輸，不是native函式時間。profile-read不在server readonly allowlist，故也做全runtime檔案讀取；`section_profile_bridge.inc:97–104` 本身只是能力與既有state序列化，不能由40ms直接推為native profile重算瓶頸。

**closed不等於無消費者，不能直接跳讀。** close（workspace:41）只清state/model/viewer，保留cachedRuns/context。公開API是runCount/libraryMarkup；`space-workspace.js:666–690` 用library通知更新共享3D庫、兩個模型數量，並可在profile關閉後由卡片重開native run。main/F的refresh/event邏輯相同；該檔diff只有模板預設值抽離。

可研究的候選是「同一交易內合併presentation library刷新」，不是刪guard。但尚未證等價：每個event當下的++librarySerial仍須撤銷舊回應；open workspace的preview/generation/modelPin立即失效、dirty保留；history-end目前不發definition event，還須覆蓋成功、失敗rollback、abort、收據恢復與context切換。`read(s):39` 的兩次profile＋engineering revision夾讀是另一個必要guard，不能混作這兩筆event刷新刪除。既有 `source_navigation_test.js:68–77` 釘延遲刷新保留saved-model DOM／inspector／焦點及World／dirty／revision／history；`tests/test_section_profile_browser.js:47–57` 釘dirty/cancel/Undo/Redo與關閉後重開。未找到直接證明transaction合併及serial競態等價的現成專門斷言，因此此候選不是現在可直接套用的非語意修補。

**另一個確切成本是runtime完整讀取，不是正常路徑重複hash。** `runtime_version.py:160–184` 每個受守門命令盤點前後pathset、讀731檔約22.4MB（其中canonical reader約7MB）並與immutable bytes比較；只有bytes不同才進identity normalization。`tests/test_runtime_version.py:459` 的unchanged檢查明確禁止rehash；新增／刪除／讀失敗與讀取中race亦有測試。可讓caller profile區分「盤點、read_bytes／比較、native等待」，再評估分配／複製省工；不能先移除canonical route、減少守門、加TTL或以metadata代替完整讀取。新model_native/source_closure只在model端點，這條P52直接/API→C bridge路徑沒有呼叫，暫不列為直接定位目標。

**如何驗證候選。** 原P52可驗相同點擊→可見時間、原足跡與現有五等待控制；採候選後可用同規格撤回／恢復作效能自證，但目前基線gate已紅且樣本有波動，不能預保證撤回必紅／恢復必綠。P52五控制不能證明profile共享快取、dirty與收據恢復的語意；須連同上述既有相關測試及ownership/race證據。原F ratio1.0382518與verifier1維持，不據此備忘改判。

原樣本、731檔hash／runtime version與raw引用：`/workspace/geo261-environment/p52-final-red-audit/`；本頁僅補靜態路徑定位，交由後續實際caller profile決定成本來源。
