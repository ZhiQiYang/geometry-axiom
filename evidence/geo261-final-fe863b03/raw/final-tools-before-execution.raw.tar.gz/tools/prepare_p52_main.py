"""依原交接準備固定 main，只有 clone/build，不做 P52 量測。"""
import json
import os
from pathlib import Path
import subprocess
import hashlib

root=Path('/tmp/g261r2')
out=root/'p52-main-preparation'
out.mkdir(exist_ok=False)
work=root/'work/p52-main'
(work/'tmp').mkdir(parents=True)
repo=work/'main'
commands=[(['git','clone','--shared','--no-checkout','/tmp/g261r2/source-final',str(repo)],root),
          (['git','-c','core.autocrlf=false','checkout','--detach','adbaebf9c73ea6801d7b4d5214e4b846b132923b'],repo),
          (['npm','run','build'],repo)]
env=dict(os.environ,TMPDIR=str(work/'tmp'))
rows=[]
for i,(argv,cwd) in enumerate(commands):
    with (out/(str(i)+'.stdout')).open('wb') as stdout,(out/(str(i)+'.stderr')).open('wb') as stderr:
        result=subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    row={'command':argv,'cwd':str(cwd),'exit_code':result.returncode,'TMPDIR':env['TMPDIR']}
    rows.append(row)
    (out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    if result.returncode: raise SystemExit(result.returncode)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='adbaebf9c73ea6801d7b4d5214e4b846b132923b'
print('固定 main clone/build 已完成；尚未進行 P52 量測。')
