#!/usr/bin/env python3
"""只讀已完成P2 HTML架構產物與原streams，不import裁判或執行產品。"""
import datetime,hashlib,json,os,re,subprocess,sys,traceback
from pathlib import Path
OUT=Path(__file__).resolve().parent
RUN=Path('/tmp/g261htmlseal/architecture-html-refresh')
REPO=Path('/tmp/g261htmlseal/html-source')
SHA='8a80abc1402b0c4c394969025c93a6019b4bb91d'
ART='geometry-core/domain-decoupling/'
FOUR=('product-architecture.json','product-architecture-scan.json','PRODUCT-ARCHITECTURE.md','product-architecture-receipt.json')
ROOTS=('geometry-core','geometry-app','geometry-templates','geometry-web','geometry-guide')
STANDALONE=('current_geometry.c','tests/__init__.py','tests/binaries.py')
SUFFIXES={'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}
JUDGES=('tests/architecture_contract.py','tests/test_architecture_contract.py','tests/test_product_architecture.py')
TARGET='geometry-guide/公理層-閱讀器.html'
def h(raw):return hashlib.sha256(raw).hexdigest()
def lf(raw):return raw.replace(b'\r\n',b'\n')
def info(path):
 raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'raw_sha256':h(raw),'lf_sha256':h(lf(raw))}
def load(path):return json.loads(path.read_text())
def same(a,b):return json.dumps(a,sort_keys=True,ensure_ascii=False)==json.dumps(b,sort_keys=True,ensure_ascii=False)
report={'schema':'geo261-P2-html-architecture-independent-audit/1','source_sha':SHA,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'passed':False,'issues':[],'checks':[],'read_commands':[],'not_executed':['scanner/lexer','three judges','compilation','product','native','browser','mutation','census'],
 'tool':info(Path(__file__).resolve()),'environment':{'python':sys.version,'cwd':os.getcwd(),'LANG':os.environ.get('LANG'),'LC_ALL':os.environ.get('LC_ALL')}}
def need(label,value):
 report['checks'].append({'label':label,'passed':bool(value)})
 if not value:raise RuntimeError(label)
def git(label,*parts,data=None):
 prefix=OUT/'git-reads'/label;prefix.mkdir(parents=True)
 command=['git','-C',str(REPO),*parts];p=subprocess.run(command,input=data,capture_output=True)
 (prefix/'stdout').write_bytes(p.stdout);(prefix/'stderr').write_bytes(p.stderr)
 if data is not None:(prefix/'stdin').write_bytes(data)
 report['read_commands'].append({'command':command,'cwd':os.getcwd(),'source_sha':SHA,'actual_exit_code':p.returncode,
  'stdout':info(prefix/'stdout'),'stderr':info(prefix/'stderr'),'stdin':info(prefix/'stdin') if data is not None else None})
 need(label+' Git exit0',p.returncode==0);return p.stdout
try:
 result=load(RUN/'RESULT.json');r=load(RUN/'new'/FOUR[3]);m=load(RUN/'new'/FOUR[0]);scan=load(RUN/'new'/FOUR[1]);old=load(RUN/'previous'/FOUR[3])
 need('completed RESULT and no FAILED',result['passed'] is True and not (RUN/'FAILED.json').exists())
 need('summary finite schema and P2',result['schema']=='geo261-linux-canonical-html-architecture-refresh/1' and result['source_sha']==SHA)
 need('receipt observed source P2',r['schema']=='geometry-product-architecture-receipt/1' and all(r[k]==SHA for k in ('sourceBaseHead','headObservedBefore','headObservedAfter')))
 need('P2 checkout head clean before read',git('head-before','rev-parse','HEAD').decode().strip()==SHA and git('status-before','status','--porcelain=v1','--untracked-files=all')==b'')
 need('601/333/268/796/0 diagnostics/920 guard',all(r['counts'][k]==v for k,v in {'executableFiles':601,'ownedSources':333,'exclusions':268,'edges':796,'diagnostics':0,'forbiddenIdentifiers':920}.items()) and r['counts']==result['counts'])
 declared=sorted(x['path'] for x in m['sources']+m['exclusions']);need('601 unique declared',len(declared)==len(set(declared))==601 and len(m['sources'])==333 and len(m['exclusions'])==268)
 filesystem=set(STANDALONE)
 for root in ROOTS:
  for parent,dirs,files in os.walk(REPO/root,followlinks=False):
   need('no symlink source dirs '+str(parent),not any((Path(parent)/x).is_symlink() for x in dirs))
   for name in files:
    path=Path(parent)/name
    if path.suffix.lower() in SUFFIXES:
     need('no symlink input '+str(path),not path.is_symlink());filesystem.add(path.relative_to(REPO).as_posix())
 need('filesystem exactly601',sorted(filesystem)==declared)
 tree=git('tree','ls-tree','-r','-z',SHA,'--',*ROOTS,*STANDALONE);tracked=[]
 for item in tree.split(b'\0'):
  if not item:continue
  meta,path=item.split(b'\t',1);mode,kind,oid=meta.decode().split();path=path.decode()
  if Path(path).suffix.lower() in SUFFIXES:need('Git source regular '+path,mode in ('100644','100755') and kind=='blob');tracked.append(path)
 need('Git tree exactly601',sorted(tracked)==declared)
 blobraw=git('all-blobs','cat-file','--batch',data=''.join(SHA+':'+p+'\n' for p in declared).encode());cursor=0;inputs=[]
 for path in declared:
  e=blobraw.index(b'\n',cursor);header=blobraw[cursor:e].split();n=int(header[2]);body=blobraw[e+1:e+1+n];cursor=e+n+2;actual=(REPO/path).read_bytes()
  need('Git/fs bytes '+path,header[1]==b'blob' and body==actual and blobraw[cursor-1:cursor]==b'\n');inputs.append({'path':path,'sha256':h(lf(actual))})
 need('Git batch exact end',cursor==len(blobraw));closure=h(json.dumps(inputs,ensure_ascii=False,separators=(',',':')).encode())
 need('independent P2 closure',closure==r['inputClosureSha256']==result['inputClosureSha256'] and inputs==r['inputs'])
 inv=r['completeInventoryVerification'];need('before/after601 and closure',inv['filesBefore']==inv['filesAfter']==601 and inv['inputClosureSha256Before']==inv['inputClosureSha256After']==closure and inv['allRawAndLfInputsUnchanged'] is True)
 expected=[{'path':TARGET,'previousSha256':'3979f9858fa581df1d9c8f2ba0c21b471ebc0553464b1c1f7f2aa8c87952062a','sha256':'563da7a100e9053f3b23b87b04edec219ad223a0063d2509a380c2286a18482b'}]
 oldinputs={x['path']:x['sha256'] for x in old['inputs']};actualchanged=[dict(x,previousSha256=oldinputs[x['path']]) for x in inputs if oldinputs[x['path']]!=x['sha256']]
 need('only exact HTML changed',same(actualchanged,expected) and r['manifestRefresh']['changedPreviouslySealedInputs']==expected and result['changedPreviouslySealedInputs']==expected)
 need('canonical policy unchanged flags',all(result[k] is True for k in ('canonical_html_only','policy_delta_empty','manifest_byte_unchanged','allRawAndLfInputsUnchanged')))
 policy=r['manifestRefresh']['policyDelta'];need('policy delta exactly empty',all(policy[k]==[] for k in ('addedIdentifiers','removedIdentifiers','addedStrings','removedStrings')) and policy['identifiersBefore']==policy['identifiersAfter']==920 and policy['manifestByteUnchanged'] is True)
 report['four_files']={name:info(RUN/'new'/name) for name in FOUR}
 for name in FOUR:
  a=report['four_files'][name];b=result['outputs'][name];need('RESULT exact hash '+name,a['bytes']==b['bytes'] and a['raw_sha256']==b['rawSha256'] and a['lf_sha256']==b['lfSha256'])
 for name,key in ((FOUR[0],'manifestSha256'),(FOUR[1],'scanSha256'),(FOUR[2],'reportSha256')):need('receipt hash '+name,report['four_files'][name]['lf_sha256']==r[key])
 for name in FOUR[:2]:need('old/new bytes unchanged '+name,(RUN/'new'/name).read_bytes()==(RUN/'previous'/name).read_bytes())
 need('manifest exact known A raw',h((RUN/'new'/FOUR[0]).read_bytes())=='0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6')
 need('report actual P2 and receipt historical L',SHA in (RUN/'new'/FOUR[2]).read_text() and r['manifestRefresh']['previousSourceBaseHead']=='aa02a65e9d3923cc14c13340f05ed16c8b7d4fce')
 journal=load(RUN/'commands.json');by={x['label']:x for x in journal};need('unique command labels',len(by)==len(journal))
 for row in journal:
  need('command complete/source '+row['label'],row['complete'] is True and row['interrupted'] is None and row['sourceBaseHead']==SHA and type(row['exitCode']) is int)
  for stream in ('stdout','stderr'):
   a=info(Path(row[stream]));b=row[stream+'Info'];need('raw stream '+row['label']+'/'+stream,a['bytes']==b['bytes'] and a['raw_sha256']==b['rawSha256'] and a['lf_sha256']==b['lfSha256'])
  original=load(Path(row['stdout']).parent/'run.json');need('original run.json '+row['label'],all(k in row and same(row[k],v) for k,v in original.items()))
 judges=[r['actualCliScan'],*r['validation']];need('three original judges ordered',[x['label'] for x in judges]==['final-scan','generic-tests','product-tests'])
 for index,row in enumerate(judges):
  original=by[row['label']];need('judge actual rc0 cwd argv '+row['label'],row['exitCode']==original['exitCode']==0 and row['cwd']==str(REPO) and row['sourceBaseHead']==SHA and row['argv'][1:]==['-B',JUDGES[index]]+(['--root','.','--manifest',ART+FOUR[0]] if index==0 else []))
  need('judge raw fields '+row['label'],row['stdoutRawPath']==original['stdout'] and row['stderrRawPath']==original['stderr'])
 for row,count in zip(judges[1:],(205,18)):
  raw=Path(row['stdoutRawPath']).read_bytes()+b'\n'+Path(row['stderrRawPath']).read_bytes();matches=re.findall(rb'^Ran (\d+) tests? in [0-9.]+s\s*$',raw,re.M)
  need('real zero skip and full OK '+row['label'],row['tests']==row['passed']==count and row['failed']==row['skipped']==0 and len(matches)==1 and int(matches[0])==count and raw.rstrip().splitlines()[-1]==b'OK')
 need('scan original stdout and finite result',Path(judges[0]['stdoutRawPath']).read_bytes()==(RUN/'new'/FOUR[1]).read_bytes() and scan['ok'] is True and scan['diagnostics']==[] and len(scan['edges'])==796 and set(scan['sources'])=={x['path'] for x in m['sources']})
 need('no fictional fresh probes',r['supplementalStaticGuardProbes']['executedAtCurrentHead'] is False)
 need('actual driver source unchanged',info(Path(r['refreshDriver']['path']))['raw_sha256']==r['refreshDriver']['rawSha256']=='3747601b4a9cce23528263a9080f34f5dea5b45425161e510fedb5ba3000e595')
 outer_path=Path('/tmp/g261htmlseal/special/architecture-html-refresh/receipt.json');outer=load(outer_path);report['outer_receipt']=info(outer_path)
 need('outer true0 complete same P2',outer['sha']==SHA and outer['status']=='完成' and outer['exit_code']==outer['result']['actual_process_returncode']==outer['result']['exit_code']==0 and outer['result']['watchdog_expired'] is False and 'source_integrity_error' not in outer)
 need('outer before/after source clean',all(outer[k]['head']==SHA and outer[k]['status']=='' and Path(outer[k]['root']).resolve()==REPO for k in ('checkout_before','checkout_after')))
 for path,row in outer['files'].items():
  actual=info(outer_path.parent/path);need('outer raw inventory '+path,actual['bytes']==row['bytes'] and actual['raw_sha256']==row['sha256'])
 need('outer full original stdout RESULT',same(json.loads(Path(outer['result']['stdout']).read_text()),result))
 need('checkout still P2 clean',git('head-after','rev-parse','HEAD').decode().strip()==SHA and git('status-after','status','--porcelain=v1','--untracked-files=all')==b'')
 report.update(input_closure_sha256=closure,inventory={'total':601,'owned':333,'excluded':268,'edges':796,'diagnostics':0},changed_inputs=actualchanged,
  manifest_raw_unchanged=True,scan_raw_unchanged=True,judges=[{'label':x['label'],'actual_exit_code':x['exitCode'],'tests':x.get('tests'),'passed':x.get('passed'),'skipped':x.get('skipped')} for x in judges],
  original_command_count=len(journal),source_clean_after=True,refresh_result=info(RUN/'RESULT.json'),passed=True)
except BaseException as error:report['issues'].append({'exception':repr(error),'traceback':traceback.format_exc()})
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['check_count']=len(report['checks'])
(OUT/'AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'README.md').write_text('# P2 HTML 架構實際產物純讀覆核\n\n來源 `'+SHA+'`；結果 '+('通過' if report['passed'] else '失敗')+'。詳 AUDIT.json。\n\n僅讀既有601來源／Git blobs、原command streams與四檔，沒有重跑裁判或產品。generic 205、product18真退出0且skip0，只在本audit全綠時成立；manifest及scan原bytes不變，closure由本輪601重算。所有Git真argv/rc/fullstdoutstderr在git-reads/。\n')
print(json.dumps({'schema':report['schema'],'source_sha':SHA,'passed':report['passed'],'check_count':len(report['checks']),'issues':report['issues'],'audit':str(OUT/'AUDIT.json')},ensure_ascii=False));sys.exit(0 if report['passed'] else 1)
