此工具僅已準備，未執行、未產生pass。F尚未存在，所有來源、oldA/blob、路徑、共用鎖、Python/Node均為必填。

run_reader_counterfactual.py只在repo外新scratch建立隔離F clone，不改輸入repo，不commit/push。先驗輸入F完整且乾淨，再由GitHub integration ref真fetch＋ancestor證明F已公開；驗oldA為F祖先、oldReaderBlob與oldA:path完全相符。F canonical HTML必須逐byte等於oldA blob只把唯一一個 `<code>app_contact_facts</code>` 改為 `<code>app_contact_facts_prepare</code>`。SSOT/plain、原reader test、sync生成器、axiom_matrix在A與F之間也必須完全相同，否則不做撤回自證。

實際oldA參照（不是預設參數）：

- A：a12d184ec1865ad078700cea2387ac69e82ab62a
- canonical reader Git blob：8d2e5e987a850c487cf71315bd2eaa0327490662
- canonical old SHA256：3979f9858fa581df1d9c8f2ba0c21b471ebc0553464b1c1f7f2aa8c87952062a
- 預測精確trace-only修復 SHA256：563da7a100e9053f3b23b87b04edec219ad223a0063d2509a380c2286a18482b

工具選用「原具名test獨立三輪」而非讀取formal native收據，所以收據明列 formal_acceptance=false、full_native_receipt_verified=false；不能宣稱已驗完整F native51。每輪原命令固定為：

`<python> -m unittest -v tests.test_axiom_reader.CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews`

固定F乾淨時正常0；只在隔離clone撤canonical到精確oldA bytes後，必須正常1、只跑1 test、唯一指定FAIL、AssertionError中含facts/facts_prepare的trace差且無ERROR；compile/import/crash/timeout不能算撤回紅。finally先寫回F原HTML，再跑同一原test restored0，最後確認clone乾淨。任何baseline/withdraw異常也會先恢復，再做restored；不會重試withdraw挑綠。

原reader suite1200秒deadline沿用，每輪原退出與timeout分開。每命令保存argv/cwd/sha、安全env、起訖、真rc與完整stdout/stderr/hash；每階段前後HEAD/status、完整binarypatch/hash、protected與HTML hash保存，兩份完整F/oldA HTML亦保存。撤回phase會如實標為F HEAD＋唯一HTML dirty變體；不冒稱原乾淨F失敗。共用heavy.lock為必填且必須已存在，不另造一把新鎖。外層請使用既有subreaper，工具內也管理每個命令的process group。

待全部本輪工作完成、新F正式push且source-final保持乾淨後，由root排他執行（此例尚未執行）：

```bash
GEO261_REAPER_LOG=/tmp/g261freader-reaper.jsonl \
  <python> /workspace/geo261-environment/reap_children.py \
  <python> -B /workspace/geo261-environment/final-f-reader-counterfactual-tools/run_reader_counterfactual.py \
  --repo <clean-F-checkout> --sha <F40> \
  --old-a-sha a12d184ec1865ad078700cea2387ac69e82ab62a \
  --old-reader-blob 8d2e5e987a850c487cf71315bd2eaa0327490662 \
  --scratch /tmp/g261freader --out /tmp/g261freader/proof \
  --shared-lock <本輪共用heavy.lock絕對路徑> \
  --python <python絕對路徑> --node <Node24絕對路徑> \
  > /tmp/g261freader-launch.stdout 2> /tmp/g261freader-launch.stderr
```

只準備工具，不自動同步閱讀器、不改tests/斷言/SSOT。修復本身仍須先用原sync生成器，原51 reader suite與兩次生成byte一致另收據；sync --check只validate，不證明rebuild byte equality。
