#!/usr/bin/env python3
"""最終F閱讀器衍生trace修復的隔離0/1/0；只用既有原具名test，從不改裁判/SSOT。"""
import argparse,datetime,fcntl,hashlib,json,os,platform,re,resource,shutil,signal,subprocess,sys,time,traceback
from pathlib import Path
REL='geometry-guide/公理層-閱讀器.html'
OLD=b'<code>app_contact_facts</code>'
NEW=b'<code>app_contact_facts_prepare</code>'
TEST='tests.test_axiom_reader.CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews'
URL='https://github.com/ZhiQiYang/geometry-axiom.git'
REF='refs/heads/architecture/geo261-integration-20261016'
PROTECTED=('公理層.md','geometry-guide/公理層-白話.md','geometry-guide/sync_axiom_reader.py','geometry-guide/axiom_matrix.py','tests/test_axiom_reader.py')
ENV_ROOT=Path('/workspace/geo261-environment')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','scratch','shared-lock','out'):p.add_argument('--'+name,type=Path,required=True)
 for name in ('sha','old-a-sha','old-reader-blob'):p.add_argument('--'+name,required=True)
 p.add_argument('--python',type=Path,required=True);p.add_argument('--node',type=Path,required=True)
 a=p.parse_args();source=a.repo.resolve();scratch=a.scratch.resolve();lockpath=a.shared_lock.resolve();out=a.out.resolve()
 for value in (a.sha,a.old_a_sha,a.old_reader_blob):
  if not re.fullmatch('[0-9a-f]{40}',value):raise ValueError('必須明列完整40碼SHA/blob；禁止預設舊候選')
 if not scratch.is_relative_to(Path('/tmp')) or not out.is_relative_to(scratch) or out.is_relative_to(source) or scratch.is_relative_to(source):raise ValueError('scratch/out須在repo外/tmp，out須屬scratch')
 if not source.is_dir() or out.exists() or (scratch/'source').exists() or not lockpath.is_file():raise ValueError('需完整來源repo、新out/source與既有共用heavy.lock')
 python=a.python.resolve();node=a.node.resolve()
 if not python.is_file() or not node.is_file():raise ValueError('明列可用Python與Node絕對路徑')
 if os.environ.get('PYTHONOPTIMIZE') not in (None,'','0') or sys.flags.optimize:raise RuntimeError('拒絕停用Python assert的環境')
 env={k:v for k,v in os.environ.items() if not k.startswith(('GEOMETRY_','MUTATE_')) and k not in ('AXIOM_ONLY','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','CODEX_PRIMARY_RUNTIME_NODE')}
 env.update(PATH=str(ENV_ROOT/'bin')+':'+str(node.parent)+':'+env.get('PATH',''),LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',PYTHONUNBUFFERED='1',GITHUB_SHA=a.sha,GITHUB_WORKSPACE=str(scratch/'source'),CODEX_PRIMARY_RUNTIME_NODE=str(node),XDG_DATA_HOME=str(ENV_ROOT/'xdg-data'),XDG_CACHE_HOME=str(ENV_ROOT/'xdg-cache'))
 safe=('PATH','LANG','LC_ALL','PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','PYTHONUNBUFFERED','PYTHONOPTIMIZE','PYTHONPATH','PYTHONSTARTUP','NODE_OPTIONS','CC','CFLAGS','GITHUB_SHA','GITHUB_WORKSPACE','CODEX_PRIMARY_RUNTIME_NODE','XDG_DATA_HOME','XDG_CACHE_HOME','GEO261_REAPER_LOG')
 scratch.mkdir(parents=True,exist_ok=True)
 with lockpath.open('a+b') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  out.mkdir(parents=True);(out/'commands').mkdir();(out/'source-bytes').mkdir()
  env['TMPDIR']=str(out/'tmp');Path(env['TMPDIR']).mkdir()
  soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16384*1024,hard))
  r={'schema':'geo261-final-f-reader-counterfactual/1','status':'執行中','formal_acceptance':False,'baseline_scope':'原具名test單獨fixed0，不假稱工具已驗完整F native51','sha':a.sha,'old_a_sha':a.old_a_sha,'old_reader_blob':a.old_reader_blob,'source_repo':str(source),'scratch':str(scratch),'out':str(out),'shared_lock':str(lockpath),'started_utc':now(),'tool_sha256':sha(Path(__file__).read_bytes()),'test':TEST,'test_timeout_seconds':1200,'environment':{k:env.get(k) for k in safe},'TMPDIR':env['TMPDIR'],'platform':platform.platform(),'stack_before':[soft,hard],'stack_during':resource.getrlimit(resource.RLIMIT_STACK),'commands':[],'phases':[],'errors':[],'passed':False,'full_native_receipt_verified':False,'no_commit_or_push':True}
  (out/'tool.py.txt').write_bytes(Path(__file__).read_bytes());write(out/'receipt.json',r)
  def persist():write(out/'receipt.json',r)
  def capture(label,argv,cwd,timeout=300):
   folder=out/'commands'/('%03d-'%len(r['commands'])+label);folder.mkdir()
   row={'label':label,'argv':argv,'cwd':str(cwd),'sha':a.sha,'started_utc':now(),'timeout_seconds':timeout,'timeout_expired':False,'actual_exit':None,'environment':{k:env.get(k) for k in (*safe,'TMPDIR')},'stdout':str(folder/'stdout'),'stderr':str(folder/'stderr')};start=time.monotonic();process=None
   interrupted_error=None
   with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
    def end_group():
     if process is None:return
     try:os.killpg(process.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:process.wait(timeout=5)
     except subprocess.TimeoutExpired:
      try:os.killpg(process.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      process.wait()
    try:
     process=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
     process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:row['timeout_expired']=True;end_group()
    except OSError as error:
     row['launch_error']=str(error);stderr.write((str(error)+'\n').encode())
    except BaseException as error:
     interrupted_error=error;end_group()
    finally:row.update(actual_exit=process.returncode if process else None,ended_utc=now(),seconds=time.monotonic()-start)
   for stream in ('stdout','stderr'):
    data=(folder/stream).read_bytes();row[stream+'_bytes']=len(data);row[stream+'_sha256']=sha(data)
   write(folder/'command.json',row);r['commands'].append(row);persist()
   if interrupted_error is not None:raise interrupted_error
   return row
  def require_row(row,label):
   if row['actual_exit']!=0 or row['timeout_expired']:raise RuntimeError(label+'原指令未0')
   return Path(row['stdout']).read_bytes()
  def git(label,argv,cwd):return require_row(capture(label,['git',*argv],cwd),label)
  def state(label,repo):
   head=git(label+'-head',['rev-parse','HEAD'],repo).decode().strip();status=git(label+'-status',['status','--porcelain=v1','--untracked-files=all'],repo).decode();names=git(label+'-names',['diff','--name-only','HEAD'],repo).decode().splitlines();staged=git(label+'-staged',['diff','--cached','--name-only'],repo).decode().splitlines();patch=git(label+'-patch',['diff','--binary','HEAD'],repo)
   (out/(label+'.patch')).write_bytes(patch)
   value={'head':head,'status':status,'dirty_paths':names,'staged_paths':staged,'patch_sha256':sha(patch),'protected_sha256':{x:sha((repo/x).read_bytes()) for x in PROTECTED},'reader_sha256':sha((repo/REL).read_bytes())};write(out/(label+'-source.json'),value);return value
  clone=scratch/'source';fbytes=None;protected=None
  def phase(label,expected):
   before=state(label+'-before',clone)
   if before['head']!=a.sha or before['staged_paths'] or before['protected_sha256']!=protected:raise RuntimeError(label+'來源身分不符')
   allowed=[REL] if label=='withdrawn' else []
   if before['dirty_paths']!=allowed or any(x.startswith('??') for x in before['status'].splitlines()):raise RuntimeError(label+'出現非預期dirty來源')
   expected_hash=r['old_reader_sha256'] if label=='withdrawn' else r['fixed_reader_sha256']
   if before['reader_sha256']!=expected_hash:raise RuntimeError(label+'HTML bytes不是精確對照')
   result=capture(label+'-original-named-test',[str(python),'-m','unittest','-v',TEST],clone,1200)
   after=state(label+'-after',clone);err=Path(result['stderr']).read_text(errors='replace');joined=Path(result['stdout']).read_text(errors='replace')+'\n'+err
   if expected==0:matched=result['actual_exit']==0 and not result['timeout_expired'] and bool(re.search(r'Ran 1 test\b',joined)) and '\nOK\n' in joined and 'FAILED (' not in joined and 'ERROR:' not in joined
   else:matched=(result['actual_exit']==1 and not result['timeout_expired'] and ('FAIL: test_rebuild_is_byte_idempotent_and_keeps_reviews' in joined) and 'AssertionError:' in joined and 'facts_prepare</code>' in joined and 'facts</code>' in joined and 'trace-ro' in joined and bool(re.search(r'Ran 1 test\b',joined)) and 'FAILED (failures=1)' in joined and 'ERROR:' not in joined)
   matched=matched and after==before
   row={'label':label,'expected_normal_exit':expected,'actual_exit':result['actual_exit'],'timeout_expired':result['timeout_expired'],'expected_verdict_matched':matched,'source_before':before,'source_after':after,'command':result,'failure_kind_required':'原具名assert失敗、I11 trace facts/facts_prepare差；非error/crash/timeout' if expected else None};r['phases'].append(row);persist();print(json.dumps({'phase':label,'actual_exit':result['actual_exit'],'expected_exit':expected,'matched':matched},ensure_ascii=False),flush=True);return matched
  def interrupted(signum,frame):raise KeyboardInterrupt('signal '+str(signum))
  old_sigterm=signal.signal(signal.SIGTERM,interrupted)
  try:
   original=state('input-repo',source)
   if original['head']!=a.sha or original['status'] or original['staged_paths']:raise RuntimeError('輸入F必須完整且乾淨')
   git('clone-f',['clone','--shared','--no-checkout',str(source),str(clone)],scratch)
   git('checkout-f',['-c','core.autocrlf=false','checkout','--detach',a.sha],clone)
   git('fetch-published-f',['fetch','--no-tags',URL,REF],clone)
   published=git('published-ref',['rev-parse','FETCH_HEAD'],clone).decode().strip()
   git('f-is-public-ancestor',['merge-base','--is-ancestor',a.sha,published],clone)
   git('a-is-f-ancestor',['merge-base','--is-ancestor',a.old_a_sha,a.sha],clone)
   blob=git('old-reader-blob',['rev-parse',a.old_a_sha+':'+REL],clone).decode().strip()
   if blob!=a.old_reader_blob:raise RuntimeError('明列old A reader blob不符')
   oldbytes=git('old-reader-bytes',['show',a.old_a_sha+':'+REL],clone)
   fbytes=(clone/REL).read_bytes()
   if oldbytes.count(OLD)!=1 or NEW in oldbytes or fbytes!=oldbytes.replace(OLD,NEW,1):raise RuntimeError('F HTML不是舊A blob僅一處既定trace修復')
   protected={x:sha((clone/x).read_bytes()) for x in PROTECTED}
   for i,x in enumerate(PROTECTED):
    old=git('old-protected-'+str(i),['show',a.old_a_sha+':'+x],clone)
    if sha(old)!=protected[x]:raise RuntimeError('F修改了舊A裁判/SSOT/生成器:'+x)
   (out/'source-bytes/canonical-F.html').write_bytes(fbytes);(out/'source-bytes/canonical-old-A.html').write_bytes(oldbytes)
   r.update(published_source={'url':URL,'ref':REF,'remote_head':published,'f_is_published_ancestor':True,'old_a_is_f_ancestor':True},fixed_reader_sha256=sha(fbytes),old_reader_sha256=sha(oldbytes),protected_sha256=protected,one_trace_replacement_verified=True)
   fixed_patch=git('fixed-vs-a-reader',['diff','--binary',a.old_a_sha,a.sha,'--',REL],clone);(out/'fixed-vs-old-A.patch').write_bytes(fixed_patch);r['fixed_reader_patch_sha256']=sha(fixed_patch);persist()
   for name,argv in [('python',[str(python),'--version']),('node',[str(node),'--version']),('chrome',['google-chrome','--version'])]:require_row(capture('version-'+name,argv,clone,30),'version-'+name)
   node_version=Path(r['commands'][-2]['stdout']).read_text().strip()
   if not re.match(r'^v24\.',node_version):raise RuntimeError('本環境Node不是24:'+node_version)
   if not phase('fixed',0):raise RuntimeError('fixed原具名judge未綠；先恢復並驗restored，不冒稱撤回自證')
   (clone/REL).write_bytes(oldbytes)
   phase('withdrawn',1)
  except BaseException:
   r['errors'].append(traceback.format_exc())
  finally:
   # Restore first, even when fixed/withdrawn failed or timed out. The source
   # repository was never modified; only this disposable isolated clone changed.
   if fbytes is not None and protected is not None and clone.is_dir():
    try:
     (clone/REL).write_bytes(fbytes)
     phase('restored',0)
     r['final_source']=state('final-restored',clone)
     if r['final_source']['head']!=a.sha or r['final_source']['status'] or r['final_source']['staged_paths']:raise RuntimeError('finally來源未還原成乾淨F')
    except BaseException:r['errors'].append(traceback.format_exc())
   signal.signal(signal.SIGTERM,old_sigterm)
   r['passed']=not r['errors'] and [x['label'] for x in r['phases']]==['fixed','withdrawn','restored'] and all(x['expected_verdict_matched'] for x in r['phases'])
   r['status']='完成且具名0/1/0皆符合' if r['passed'] else '未符合；保留全部真實結果'
   r['finished_utc']=now();persist()
  print(json.dumps({'out':str(out),'sha':a.sha,'passed':r['passed'],'phases':[(x['label'],x['actual_exit']) for x in r['phases']]},ensure_ascii=False),flush=True)
  return 0 if r['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
