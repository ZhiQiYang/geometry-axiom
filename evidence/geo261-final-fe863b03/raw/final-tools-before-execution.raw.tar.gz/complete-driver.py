"""固定 F 完整七項後接全部專項，保留所有紅燈與原退出碼。"""
import argparse,datetime,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--repo',type=Path,required=True); p.add_argument('--sha',required=True); p.add_argument('--scratch',type=Path,required=True); a=p.parse_args()
assert len(a.sha)==40 and subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo).decode().strip()==a.sha
assert subprocess.check_output(['git','status','--porcelain'],cwd=a.repo)==b''
assert not (a.scratch/'continuation-results.json').exists()
base=Path('/workspace/geo261-environment')
commands=[('seven',[sys.executable,'-B',str(base/'run_acceptance_seven_configured.py'),'--repo',str(a.repo),'--sha',a.sha,'--scratch',str(a.scratch)]),('all-specials',[sys.executable,'-B',str(base/'run_acceptance_specials_configured.py'),'--repo',str(a.repo),'--sha',a.sha,'--scratch',str(a.scratch),'--tools',str(a.scratch/'tools')])]
rows=[]
for label,argv in commands:
 row={'label':label,'argv':argv,'cwd':str(a.repo),'source_sha':a.sha,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (a.scratch/(label+'-launch.stdout')).open('xb') as out,(a.scratch/(label+'-launch.stderr')).open('xb') as err:
  row['actual_exit']=subprocess.run(argv,cwd=a.repo,stdout=out,stderr=err).returncode
 row['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat(); rows.append(row)
 (a.scratch/'continuation-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(row,ensure_ascii=False),flush=True)
raise SystemExit(0 if all(r['actual_exit']==0 for r in rows) else 1)
