#!/usr/bin/env python3
"""讀取F的完整canvas baseline，在隔離cloneF保存P73撤回／恢復；不發布或改產品分支。"""
import argparse,difflib,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,traceback
from pathlib import Path
TOOLS=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p73_f_capture',TOOLS/'run_workflow.py')
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
FIXED=b"  const svg=$('spacePlanSvg');\n  // SVG \xe6\xb2\x92\xe6\x9c\x89 HTML \xe5\x85\x83\xe7\xb4\xa0\xe7\x9a\x84 hidden \xe5\x8f\x8d\xe5\xb0\x84\xe5\xb1\xac\xe6\x80\xa7\xef\xbc\x9b\xe8\x88\x87 renderSpacePlan \xe5\x85\xb1\xe7\x94\xa8 attribute \xe7\x8b\x80\xe6\x85\x8b\xe3\x80\x82\n  if(!svg||svg.hasAttribute('hidden'))return;\n  const matrix=svg.getScreenCTM();if(!matrix)return;\n"
WITHDRAWN=b"  const svg=$('spacePlanSvg'),matrix=svg?.getScreenCTM();if(!svg||svg.hidden||!matrix)return;\n"
def h(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def state(repo):return {'head':git(repo,'rev-parse','HEAD').decode().strip(),'status':git(repo,'status','--porcelain=v1','--untracked-files=all').decode()}
def canvas_baseline(path,repo,sha):
 r=json.loads(path.read_text());assert r['schema']=='geo261-cloud-workflow/1' and r['sha']==sha and r['job']=='canvas'
 assert r['exit_code']==0 and r['status']=='完成' and r['over_ci_timeout'] is False
 assert 'source_integrity_error' not in r and r['environment']['GITHUB_SHA']==sha
 assert r['environment']['GITHUB_WORKSPACE']==str(repo)
 for key in ('checkout_before','checkout_after'):
  assert r[key]['head']==sha and r[key]['root']==str(repo) and r[key]['status']==''
 workflow=git(repo,'show',sha+':.github/workflows/integration-tests.yml')
 assert hashlib.sha256(workflow).hexdigest()==r['workflow_sha256']
 assert h(path.parent/'driver.py.txt')==r['driver_sha256']
 for step in r['steps']:
  if 'result' not in step:continue
  result=step['result'];script=path.parent/'steps'/f"{step['index']:02d}.executed.sh"
  expected=(['bash','--noprofile','--norc','-eo','pipefail',str(script)] if step['original_step'].get('shell')=='bash' else ['bash','-e',str(script)])
  assert result['cwd']==str(repo) and result['command']==expected
  assert h(script)==step['script_sha256']
  expected_run=step['executed_run'];expected_run+=('' if expected_run.endswith('\n') else '\n')
  assert script.read_bytes()==expected_run.encode('utf-8')
 rows=[s for s in r['steps'] if s.get('name')=='Run actual browser regression group'];assert len(rows)==1
 step=rows[0];result=step['result'];assert result['exit_code']==result['actual_process_returncode']==0 and not result.get('watchdog_expired',False)
 log=Path(result['stdout']);relative=log.relative_to(path.parent);inventory=r['files'][str(relative)]
 assert log.stat().st_size==inventory['bytes'] and h(log)==inventory['sha256']
 records=[json.loads(line[len('CDP_RESULT '):]) for line in log.read_text().splitlines() if line.startswith('CDP_RESULT ')]
 assert len(records)==1;cdp=records[0]
 assert cdp['completed'] is True and cdp['failedAssertions']==0 and cdp['goldenCompare']=='matched'
 assert cdp['scope']['mode']=='full' and cdp['scope']['filters']==[] and cdp['scope']['modifiers']==[]
 golden=json.loads(git(repo,'show',sha+':geometry-web/cdp_sections.golden.json'))
 assert cdp['sections']['P73']==golden['sections']['P73']
 return {'sha':sha,'receipt':str(path),'receipt_sha256':h(path),'stdout':str(log),'stdout_sha256':h(log),'cdp':cdp,'expected_p73':golden['sections']['P73']}
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for name in ('repo','scratch','canvas-receipt','heavy-lock'):ap.add_argument('--'+name,type=Path,required=True)
 ap.add_argument('--sha',required=True);ap.add_argument('--service-port',type=int,required=True);ap.add_argument('--cdp-port',type=int,required=True)
 a=ap.parse_args();repo=a.repo.resolve();scratch=a.scratch.resolve();receipt=a.canvas_receipt.resolve()
 assert re.fullmatch('[0-9a-f]{40}',a.sha) and git(repo,'rev-parse',a.sha+'^{commit}').decode().strip()==a.sha
 assert Path(git(repo,'rev-parse','--show-toplevel').decode().strip()).resolve()==repo
 assert state(repo)=={'head':a.sha,'status':''}
 assert scratch.is_relative_to(Path('/tmp')) and not scratch.exists() and not scratch.is_relative_to(repo)
 heavy_lock=a.heavy_lock.resolve();assert heavy_lock.is_relative_to(Path('/tmp')) and heavy_lock.parent.is_dir()
 assert scratch/'heavy.lock'!=heavy_lock
 ports=[a.service_port,a.service_port+1,a.cdp_port,a.cdp_port+1];assert len(set(ports))==4 and all(1024<=p<=65535 for p in ports)
 baseline=canvas_baseline(receipt,repo,a.sha)
 scratch.mkdir(parents=True);clone=scratch/'source-proof';record={'schema':'geo261-final-p73-proof/1','sha':a.sha,'status':'執行中','fixed_baseline':baseline,'source_before':state(repo),'commands':[],'variants':[],'shared_heavy_lock':str(heavy_lock),'child_heavy_lock':str(scratch/'heavy.lock')}
 names=('run_final_p73_proof.py','run_p73_proof_adapted.py','run_workflow.py','reap_children.py','run_p73_proof.original.py.txt','driver-adaptation.patch','PREPARATION.json')
 record['tool_hashes']={name:h(TOOLS/name) for name in names};shutil.copytree(TOOLS,scratch/'tools-frozen')
 shutil.copy2(receipt,scratch/'fixed-canvas.receipt.json');shutil.copy2(Path(baseline['stdout']),scratch/'fixed-canvas.stdout')
 dump(scratch/'receipt.json',record)
 def run(label,argv,timeout):
  result=cap.capture(argv,scratch/'launch'/label,cwd=scratch,env=os.environ.copy(),timeout=timeout)
  record['commands'].append(result);dump(scratch/'receipt.json',record);return result
 app=None;fixed=None
 try:
  with heavy_lock.open('a+b') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   for name,wanted in record['tool_hashes'].items():assert h(TOOLS/name)==wanted
   for label,args in [('clone',['git','clone','--no-hardlinks','--no-checkout',str(repo),str(clone)]),('checkout',['git','-C',str(clone),'checkout','--detach',a.sha])]:
    result=run(label,args,300);assert result['actual_process_returncode']==0 and not result.get('watchdog_expired',False)
   assert state(clone)=={'head':a.sha,'status':''}
   app=clone/'geometry-web/app.js';fixed=app.read_bytes();assert fixed==git(repo,'show',a.sha+':geometry-web/app.js') and fixed.count(FIXED)==1
   mutant=fixed.replace(FIXED,WITHDRAWN,1);(scratch/'app-fixed.bin').write_bytes(fixed);(scratch/'app-withdrawn.bin').write_bytes(mutant)
   for index,(label,data,expected) in enumerate((('withdrawn',mutant,1),('restored',fixed,0))):
    expected_state={'head':a.sha,'status':' M geometry-web/app.js\n' if expected else ''}
    row={'label':label,'expected_exit':expected,'actual_exit':None,'passed':False}
    try:
     app.write_bytes(data);assert state(clone)==expected_state;row['app_js_sha256']=h(app)
     if expected:(scratch/'withdrawal.patch').write_bytes(git(clone,'diff','--binary','--','geometry-web/app.js'))
     command=[sys.executable,'-B',str(scratch/'tools-frozen/run_p73_proof_adapted.py'),'--repo',str(clone),'--sha',a.sha,'--scratch',str(scratch),'--label',label,'--port',str(a.service_port+index),'--cdp-port',str(a.cdp_port+index),'--expected-exit',str(expected)]
     result=run(label,command,6600);row['actual_exit']=result['actual_process_returncode'];proof_path=scratch/'p73-proof'/label/'receipt.json';proof=json.loads(proof_path.read_text())
     assert proof['sha']==a.sha and proof['actual_exit_code']==row['actual_exit']==expected
     assert proof['proof_expectation_matches'] is True and proof['over_ci_timeout'] is False
     assert proof['source_before']==proof['source_after'] and proof['source_before']['head']==a.sha and proof['source_before']['status']==expected_state['status']
     assert proof['source_before']['app_js_sha256']==h(app) and state(clone)==expected_state
     assert proof['source_before']['tests_sha256']=={str(path.relative_to(clone)):h(path) for path in sorted((clone/'tests').glob('*.py'))}|{str(clone/'geometry-web'/name).replace(str(clone)+'/',''):h(clone/'geometry-web'/name) for name in ('cdp_test.js','uiux_review_test.js','cdp_helpers.js','cdp_floor.js','cdp_evaluation.js','cdp_navigation.js','transport_failure_trace.js','grid_workspace_draft_test.js','cdp_sections.golden.json')}
     row.update(passed=True,receipt=str(proof_path),receipt_sha256=h(proof_path))
    except Exception:row['error']=traceback.format_exc()
    finally:
     try:
      app.write_bytes(fixed);assert state(clone)=={'head':a.sha,'status':''}
     except Exception:row.update(passed=False,restore_error=traceback.format_exc())
     record['variants'].append(row);dump(scratch/'receipt.json',record)
   assert state(repo)==record['source_before'] and app.read_bytes()==fixed
   for name,wanted in record['tool_hashes'].items():assert h(TOOLS/name)==wanted
   record.update(status='完成',exit_code=0 if all(x['passed'] for x in record['variants']) else 1,source_after=state(repo),restored_clone=state(clone))
 except Exception:record.update(status='失敗',exit_code=1,error=traceback.format_exc())
 finally:
  if app is not None and fixed is not None:
   try:
    app.write_bytes(fixed);assert state(clone)=={'head':a.sha,'status':''}
   except Exception:record.update(status='失敗',exit_code=1,outer_restore_error=traceback.format_exc())
  try:
   assert state(repo)==record['source_before'];record['source_after']=state(repo)
  except Exception:record.update(status='失敗',exit_code=1,source_integrity_error=traceback.format_exc())
  dump(scratch/'receipt.json',record)
 print(json.dumps({'sha':a.sha,'status':record['status'],'exit_code':record['exit_code'],'variants':record['variants']},ensure_ascii=False));return record['exit_code']
if __name__=='__main__':raise SystemExit(main())
