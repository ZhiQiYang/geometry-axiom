# F上的P73撤回／恢復工具（只準備，尚未執行）

必填`--repo`（實際乾淨F checkout）、`--sha`（完整40字元F）、`--scratch`（全新/tmp目錄）、`--canvas-receipt`（F已完成完整canvas的原始收據）、兩組埠起點。沒有硬編產品SHA或舊結果。此工具不commit/push，不在使用者電腦執行，不改原repo。

```bash
python3 -B /workspace/geo261-environment/final-f-p73-proof-tools/run_final_p73_proof.py \
  --repo <F的乾淨checkout絕對路徑> --sha <完整F> \
  --scratch /tmp/g261-p73-F --canvas-receipt <F canvas的receipt.json> \
  --service-port 19220 --cdp-port 9460 --heavy-lock <本輪完整驗收共用heavy.lock>
```

實際執行前把本工具目錄封存到F帳下。原driver與原始hash、exact adaptation diff在本包。原子集的workflow/判斷/版本/頭尾source checks原樣，僅必填repo/sha、驗受驗HEAD、收據加sha、改用本包相同reaper。capture helper及reaper亦按原bytes保存。PREPARATION.json僅表示已AST解析；沒有mock、Chrome、編譯或驗收。

先驗F canvas的sha/job/rc/status/正式CI時限/source integrity、checkout前後HEAD與乾淨狀態、GITHUB_SHA/workspace、workflow hash、原browser stdout hash；解析唯一CDP_RESULT，要求completed/full scope/filters及modifiers空/golden matched/零failed，P73數量與F golden相同。這份原始F canvas是fixed baseline，不能指向舊SHA收據或只有summary檔。

然後本地`git clone --no-hardlinks --no-checkout`至scratch/source-proof並detach F；只在該clone撤回syncSpacePlanAnnotations的四行attribute guard，原app.js、mutant bytes與exact patch都保存。withdrawn原子集要求真rc1與原具名P73失敗；即使此輪紅燈不符合期望或收據出錯，也先精確還原F，再跑restored要求真rc0及原69段等F golden數量。兩輪原始rc不改寫，aggregator另判proof是否符合。clone在每輪finally還原，原repo前後HEAD/status須完全相同。

父流程持必填`--heavy-lock`（應為F完整驗收同一把鎖）；子原工具持全新scratch/heavy.lock，兩者必須不同。不要另外外套同把global lock。兩輪各用service/CDP起點及+1，四埠必須各自不同；Chrome profile與tmp也獨立。scratch請短，避免Unix socket路徑過長。

限制：尚無runtime/mock證據；若F的修正block或正式workflow格式改變，本工具會拒絕而不是模糊替換。源碼／裁判固定檢查不可繞過。原子集不是完整canvas，完整F canvas必須先獨立綠。
