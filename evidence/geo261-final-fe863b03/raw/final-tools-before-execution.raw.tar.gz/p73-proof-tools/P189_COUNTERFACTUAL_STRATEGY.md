# 基於F撤回整體純性能修正的最小可建置策略（尚未生成／執行）

F還未固定，不能現在產出能冒稱F的exact patch。固定後從F隔離clone生成一份集中撤回所有最終實際採用純性能演算法的patch；HEAD仍記F，受驗來源明列「F＋counterfactual patch hash」，不是乾淨F。P73 app.js、全部tests、公理、容量、P177來源請求與守門次序都不得動。不要把已撤回的wd_read/borrowedview/BOX/gridBE/contactBE等候選加進去。

逐項以最終gitdiff確認實際累積範圍，保留所有已發布API而恢復舊實作：

1. W placement-contact窄view：保留新小API與型別，在內部用原full placement decoder再取placement_id/direction/order；或將H contact consumer改回原full placement read。不能刪API令永久harness/link失敗，這樣不是性能紅。
2. K node hash/hint：恢復原完整key hash/index查找算法，保留原K公開API、owned-key配置與所有edge/state/cycle/失敗流程。這可取原完整綠來源的舊實作，不回退任何P177守門。
3. H rawsnapshot：把reference_contact_facts恢復eager raw facts，並將app_contact_facts prepare恢復原eager計算。只撤回計算延後與snapshot機制，不動新的功能回歸tests；原source call順序/typed更新/partial output語意均應相同。
4. W contact faces malloc：只把原faces配置恢復calloc，保留facts/result/query配置和其餘policy。
5. 如果最終採用K host-definition header窄讀：保留新header API／完整canonical驗證，以既有full decode/API回傳後取header作舊算法fallback；H也可改回原full accessor。不可刪新API、略過驗證、變更source request，或把malformed行為換掉。
6. 若F又採其他純省工，逐項加入同一反向patch；以凍結最終diff為準，不能只撤其中一項卻稱「撤回全部」。

可用早期全功能來源作實作對照，但不要整個檔案盲覆蓋：先比對F的semantic hunks，確保P73與任何獨立功能修正保留。每個API的舊成本wrapper可由F仍存在的full API組成，所以新測試能編譯；code-level fallback diff/hash、bridge build真rc、source hashes全部存檔。此處只是策略，沒有修改root或產出假的已驗patch。

負控最小範圍是原N64門檻的反例：以原main adbaebf9／base3e600772／F-counterfactual建bridge、相同N64場景及3輪原交錯順序（9筆），確保每個child真rc0/loadok，並至少N64 loadfile+dump同main逐bytes相同。原2倍門檻若counterfactual/main>2才是性能撤回紅；timing driver本身exit0不等於門檻綠，要分列原程序exit與門檻verdict。此N64子集只作negative proof，不冒充四點完整P189。

之後精確還原乾淨F（產品bytes/tests/hash/status都相同），正式跑原完整main/base/F：四點各3輪36筆、每點≤2、完整loadfile+dump清單逐byte相同，作restored green。若撤回沒有轉紅就如實記錄，不能放寬門檻或製造錯資料來「殺」效能mutant；歷史不同來源紅與F綠仍可分開呈現，但不能改綁成F counterfactual自證。
