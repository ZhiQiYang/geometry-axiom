#!/usr/bin/env python3
"""保存單項原始命令收據；只在七項成功後使用，不改產品或裁判。"""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import sys
import time

ROOT = Path('/workspace/geo261-environment')
REPO = None
SHA = None
SCRATCH = None
spec = importlib.util.spec_from_file_location('geo261_workflow_capture',ROOT/'run_workflow_round.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)

def main():
    global REPO, SHA, SCRATCH
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--scratch',type=Path,required=True)
    parser.add_argument('--stdout-copy',type=Path)
    parser.add_argument('--label',required=True)
    parser.add_argument('--timeout',type=int,default=10800)
    parser.add_argument('--env',action='append',default=[])
    parser.add_argument('command',nargs=argparse.REMAINDER)
    args = parser.parse_args()
    REPO, SHA, SCRATCH = args.repo.resolve(), args.sha, args.scratch.resolve()
    driver.REPO, driver.SHA = REPO, SHA
    assert len(SHA)==40 and SCRATCH.is_relative_to(Path('/tmp'))
    soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
    resource.setrlimit(resource.RLIMIT_STACK,(max(soft,16384*1024),hard))
    command = args.command[1:] if args.command and args.command[0] == '--' else args.command
    assert command and args.label.replace('-','').replace('_','').isalnum()
    with (SCRATCH/'heavy.lock').open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        before = driver.checkout_state()
        driver.validate_checkout(before)
        # 依最新使用者規則：各前項紅燈均保留，專項仍繼續執行。
        out = SCRATCH/'special'/args.label
        out.mkdir(parents=True,exist_ok=False)
        env = {k:v for k,v in os.environ.items() if not k.startswith('GEOMETRY_') and k != 'AXIOM_ONLY'}
        env.update(PATH=str(ROOT/'bin')+':'+str(Path(shutil.which('node')).parent)+':'+env.get('PATH',''),
                   XDG_DATA_HOME=str(ROOT/'xdg-data'),XDG_CACHE_HOME=str(ROOT/'xdg-cache'),
                   TMPDIR=str(SCRATCH/'tmp'/'special'/args.label),LANG='C.UTF-8',LC_ALL='C.UTF-8',
                   PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
        for value in args.env:
            key,content = value.split('=',1)
            assert key in ('TMPDIR','GEOMETRY_MODEL_BASE','GEOMETRY_TEST_BRIDGE','GEOMETRY_TEST_CORE')
            env[key] = content
        Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
        safe = ('PATH','XDG_DATA_HOME','XDG_CACHE_HOME','TMPDIR','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','GEOMETRY_MODEL_BASE','GEOMETRY_TEST_BRIDGE','GEOMETRY_TEST_CORE')
        receipt = {'schema':'geo261-cloud-special-command/1','sha':SHA,'label':args.label,
                   'checkout_before':before,'command':command,'cwd':str(REPO),'started':driver.now(),
                   'environment':{k:env[k] for k in safe if k in env},'platform':platform.platform(),'stack_limit':resource.getrlimit(resource.RLIMIT_STACK),
                   'wrapper_sha256':driver.sha256(Path(__file__).read_bytes()),
                   'capture_driver_sha256':driver.sha256((ROOT/'run_workflow_round.py').read_bytes()),
                   'status':'執行中','exit_code':None,'versions':[]}
        (out/'wrapper.py.txt').write_bytes(Path(__file__).read_bytes())
        driver.write_json(out/'receipt.json',receipt)
        start = time.monotonic()
        # 原 Q38／§7 shell 自行設定 system PATH，另外記錄它實際解析的 Python／GCC。
        for index,version in enumerate((['google-chrome','--version'],['node','--version'],['python3','--version'],['cc','--version'],['/usr/bin/python3','--version'],['/usr/bin/gcc','--version'])):
            row = driver.capture(version,out/'versions'/str(index),cwd=REPO,env=env,timeout=30)
            receipt['versions'].append(row)
            assert row['exit_code'] == 0, version
        print('開始專項：'+args.label,flush=True)
        result = driver.capture(command,out/'command',cwd=REPO,env=env,timeout=args.timeout)
        if args.stdout_copy:
            assert args.stdout_copy.resolve().is_relative_to(SCRATCH) and not args.stdout_copy.exists()
            shutil.copy2(result['stdout'],args.stdout_copy)
            receipt['stdout_copy']={'path':str(args.stdout_copy),'sha256':driver.sha256(args.stdout_copy.read_bytes())}
        after = driver.checkout_state()
        code = result['exit_code']
        receipt.update(result=result,checkout_after=after,ended=driver.now(),seconds=time.monotonic()-start,
                       exit_code=code,status='完成' if code == 0 else '失敗')
        try:
            driver.validate_checkout(after)
        except Exception as error:
            receipt.update(source_integrity_error=str(error),exit_code=70,status='來源完整性受阻')
            code = 70
        receipt['files'] = driver.file_inventory(out)
        receipt['files'].pop('receipt.json',None)
        driver.write_json(out/'receipt.json',receipt)
        print(args.label+' 退出碼：'+str(code),flush=True)
        return code

if __name__ == '__main__':
    raise SystemExit(main())
