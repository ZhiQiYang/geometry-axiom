#!/usr/bin/env python3
"""固定來源全部專項；逐項記錄紅燈及基礎設施錯誤、持續執行並正常推進度。"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ENV = Path('/workspace/geo261-environment')
INTEGRATION = Path('/workspace/geometry-axiom')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def tasks(repo, sha, scratch, tools):
    # 與第一輪順序、引數一致；僅路徑及固定 SHA 由本輪設定提供。
    return [
        ('mutation-check-final', ['python3', 'tests/mutate.py', '--check'], None, []),
        ('p52-prepare-main', ['python3', str(tools / 'prepare_p52_main.py')], None,
         [scratch / 'p52-main-preparation']),
        ('p52', ['python3', '-B', '-u', str(tools / 'postfix_validate.py'), sha],
         tools / ('postfix-' + sha[:8] + '-launch.log'), [tools / ('postfix-' + sha[:8])]),
        ('p52-verifier', ['python3', '-B', str(tools / 'verify_postfix_receipt.py'), sha], None,
         [tools / ('postfix-' + sha[:8])]),
        ('q38', ['bash', str(tools / 'q38_gate.sh'), sha, 'cloud-resume', '-', 'gate'], None,
         [scratch / ('q38-cloud-resume-' + sha[:8])]),
        ('card-reference', ['bash', str(tools / 'card_ref_mutations.sh'), sha, 'cloud-resume'], None,
         [scratch / ('cardref-cloud-resume-' + sha[:8])]),
        ('p189', ['python3', '-B', '-u', str(tools / 'p189_verify.py'), sha], None,
         [tools / ('p189-' + sha[:8])]),
        ('architecture-contract', ['python', '-B', 'tests/architecture_contract.py', '--root', '.',
                                   '--manifest', 'geometry-core/domain-decoupling/product-architecture.json'], None, []),
        ('architecture-judge-tests', ['python', '-B', 'tests/test_architecture_contract.py'], None, []),
        ('architecture-product-tests', ['python', '-B', 'tests/test_product_architecture.py'], None, []),
    ]


def run_one(repo, sha, scratch, tools, launch, label, command, alias, extra):
    stdout = launch / (label + '.stdout')
    stderr = launch / (label + '.stderr')
    events = launch / (label + '-reaper.jsonl')
    infrastructure = launch / (label + '.infrastructure.json')
    args = [sys.executable, str(ENV / 'reap_children.py'), sys.executable, str(ENV / 'run_special_round.py'),
            '--repo', str(repo), '--sha', sha, '--scratch', str(scratch), '--label', label, '--timeout', '14400']
    if alias:
        args += ['--stdout-copy', str(alias)]
    args += ['--', *command]
    row = {'label': label, 'source_sha': sha, 'command': args, 'started_utc': now(),
           'exit_code': None, 'infrastructure_errors': [], 'receipt_validated': False,
           'stdout': str(stdout), 'stderr': str(stderr), 'reaper': str(events)}
    try:
        with stdout.open('xb') as out, stderr.open('xb') as err:
            done = subprocess.run(args, cwd=repo, env=dict(os.environ, GEO261_REAPER_LOG=str(events)),
                                  stdout=out, stderr=err)
        row['exit_code'] = done.returncode
    except Exception:
        row['infrastructure_errors'].append({'stage': 'launch', 'traceback': traceback.format_exc()})
    row['finished_utc'] = now()
    directory = scratch / 'special' / label
    receipt = directory / 'receipt.json'
    data = None
    if receipt.is_file():
        try:
            data = json.loads(receipt.read_text())
            assert isinstance(data, dict) and data['sha'] == sha
            assert data['command'] == command
            assert data['cwd'] == str(repo)
            assert isinstance(data['exit_code'], int)
            assert data['exit_code'] == row['exit_code']
            assert data['status'] in ('完成', '失敗', '來源完整性受阻')
            row.update(receipt_validated=True, status=data['status'], seconds=data.get('seconds'),
                       receipt_exit_code=data['exit_code'], receipt=str(receipt))
        except Exception:
            row['infrastructure_errors'].append({'stage': 'receipt', 'traceback': traceback.format_exc()})
    else:
        row['infrastructure_errors'].append({'stage': 'receipt', 'error': '沒有完整收據，不能當成功或有效 killed'})
    row['passed'] = (row['exit_code'] == 0 and row['receipt_validated'] and
                     row.get('status') == '完成' and not row['infrastructure_errors'])
    write_json(infrastructure, row)
    publish = [sys.executable, str(ENV / 'publish_progress.py'), '--sha', sha, '--label', label,
               '--result', '原退出' + str(row['exit_code']) + '；收據完整=' + str(row['receipt_validated']) +
               '；基礎設施錯誤=' + str(len(row['infrastructure_errors'])) + '；原始輸出完整封存，判準未變',
               '--next', '完成本輪其餘專項，收齊紅燈後集中分類修正；不以歷史綠燈替代',
               '--input', 'infrastructure=' + str(infrastructure),
               '--input', 'tools-adaptation=' + str(tools / 'ROUND_ADAPTATION.json')]
    for name, path in [('launch-stdout', stdout), ('launch-stderr', stderr), ('reaper', events)]:
        if path.exists():
            publish += ['--input', name + '=' + str(path)]
    if directory.is_dir():
        publish += ['--input', 'command=' + str(directory)]
    if row['receipt_validated']:
        publish += ['--receipt', str(receipt)]
    for index, path in enumerate(extra):
        if path.exists():
            publish += ['--input', 'artifact-' + str(index) + '=' + str(path)]
    if alias and alias.exists():
        publish += ['--input', 'required-launch-alias=' + str(alias)]
    row['publish_command'] = publish
    pstdout = launch / (label + '.publish.stdout')
    pstderr = launch / (label + '.publish.stderr')
    try:
        with pstdout.open('xb') as out, pstderr.open('xb') as err:
            published = subprocess.run(publish, cwd=INTEGRATION, stdout=out, stderr=err)
        row['progress_publish_exit'] = published.returncode
    except Exception:
        row['progress_publish_exit'] = None
        row['infrastructure_errors'].append({'stage': 'publish', 'traceback': traceback.format_exc()})
    row['publish_stdout'] = str(pstdout)
    row['publish_stderr'] = str(pstderr)
    # 此份最終 row 留在 round-results；已推的逐項 infrastructure 是推送前快照。
    # 不重試失敗項，不因某項紅燈或 JSON 問題阻斷下一專項。
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--scratch', type=Path, required=True)
    parser.add_argument('--tools', type=Path, required=True)
    args = parser.parse_args()
    repo, scratch, tools = args.repo.resolve(), args.scratch.resolve(), args.tools.resolve()
    assert len(args.sha) == 40 and all(c in '0123456789abcdef' for c in args.sha)
    assert scratch.is_relative_to(Path('/tmp')) and tools.is_relative_to(scratch)
    adaptation = json.loads((tools / 'ROUND_ADAPTATION.json').read_text())
    assert adaptation['source_sha'] == args.sha and adaptation['repo'] == str(repo)
    assert adaptation['scratch'] == str(scratch) and adaptation['tools'] == str(tools)
    assert digest(Path(__file__)) == adaptation['orchestrator_sha256']
    for item in adaptation['files']:
        assert digest(tools / item['name']) == item['adapted_sha256'], item['name']
    launch = scratch / 'special-launch'
    launch.mkdir(exist_ok=False)
    results_file = scratch / 'special-round-results.json'
    assert not results_file.exists(), '拒絕覆蓋舊結果或從中挑選重跑'
    rows = []
    write_json(results_file, rows)
    for label, command, alias, extra in tasks(repo, args.sha, scratch, tools):
        print('開始專項：' + label, flush=True)
        try:
            row = run_one(repo, args.sha, scratch, tools, launch, label, command, alias, extra)
        except Exception:
            row = {'label': label, 'source_sha': args.sha, 'exit_code': None, 'passed': False,
                   'progress_publish_exit': None, 'finished_utc': now(),
                   'infrastructure_errors': [{'stage': 'orchestrator', 'traceback': traceback.format_exc()}]}
            print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)
        write_json(results_file, rows)
        print('結束專項：' + label + '；原退出' + str(row['exit_code']) +
              '；進度推送退出' + str(row['progress_publish_exit']), flush=True)
    return 0 if len(rows) == 10 and all(r['passed'] and r['progress_publish_exit'] == 0 for r in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())
