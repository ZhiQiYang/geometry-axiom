/* The actual production file supplies both parsers and the encoder.
 * Unused provider APIs are removed by --gc-sections; no parser mirror/stub. */
#include "placement_sources.c"
#include <inttypes.h>
#include <stdio.h>

#define REQUIRE(label,expression) do {if(!(expression)){ \
    fprintf(stderr,"ASSERT:%s line=%d vector=%s case=%" PRIu64 " expr=%s\n",label,__LINE__,vector_name,comparisons,#expression);return 1;}} while(0)
enum { EXTRA_BYTES=64, FIELD_CAPACITY=128 };
typedef struct {unsigned char before[16];GeoPlacementDefinition value;unsigned char after[16];} FullOutput;
typedef struct {unsigned char before[16];GeoPlacementDefinitionHeader value;unsigned char after[16];} HeaderOutput;
typedef struct {size_t offset;uint32_t cap,original;const char *label;} CountField;
static FullOutput full,full_before;
static HeaderOutput header,header_before;
static GeoPlacementDefinition definition;
static _Alignas(uint64_t) unsigned char original[GEO_PLACEMENT_DEFINITION_MAX_BYTES+EXTRA_BYTES];
static _Alignas(uint64_t) unsigned char work[GEO_PLACEMENT_DEFINITION_MAX_BYTES+EXTRA_BYTES];
static unsigned char work_before[sizeof work];
static _Alignas(uint64_t) unsigned char aligned[GEO_PLACEMENT_DEFINITION_MAX_BYTES+EXTRA_BYTES];
static unsigned char aligned_before[sizeof aligned];
static CountField fields[FIELD_CAPACITY];
static size_t field_count;
static const char *vector_name="preparation";
static uint64_t comparisons,full_accepted,header_accepted,rejected,null_outputs,encoded_vectors;
static uint64_t transcript=UINT64_C(14695981039346656037);

static void mix(uint64_t value)
{for(unsigned i=0;i<8;++i){transcript^=(unsigned char)value;transcript*=UINT64_C(1099511628211);value>>=8;}}
static void put32(unsigned char *out,uint32_t value)
{for(size_t i=4;i>0;--i){out[i-1]=(unsigned char)(value%UINT32_C(256));value/=UINT32_C(256);}}
static uint32_t read32(const unsigned char *in)
{uint32_t value=0;for(size_t i=0;i<4;++i)value=value*UINT32_C(256)+in[i];return value;}
static int compare(const void *content,size_t size,uint32_t id,int known)
{
    ++comparisons;
    memset(&full,0xa5,sizeof full);memcpy(&full_before,&full,sizeof full);
    memset(&header,0x59,sizeof header);memcpy(&header_before,&header,sizeof header);
    bool full_ok=geo_placement_definition_decode(content,size,&full.value);
    bool expected=full_ok&&full.value.id==id;
    bool actual=geo_pd_definition_header(content,size,id,&header.value);
    if(actual!=expected){
        fprintf(stderr,"DIFFERENCE vector=%s size=%zu id=%u full=%d full-id=%u expected=%d header=%d\n",
            vector_name,size,(unsigned)id,(int)full_ok,full_ok?(unsigned)full.value.id:0,(int)expected,(int)actual);
        REQUIRE("accepted-set-and-requested-id",false);
    }
    REQUIRE("full-leading-canary",!memcmp(full.before,full_before.before,sizeof full.before));
    REQUIRE("full-trailing-canary",!memcmp(full.after,full_before.after,sizeof full.after));
    REQUIRE("header-leading-canary",!memcmp(header.before,header_before.before,sizeof header.before));
    REQUIRE("header-trailing-canary",!memcmp(header.after,header_before.after,sizeof header.after));
    if(!full_ok)REQUIRE("full-failure-output-unchanged",!memcmp(&full,&full_before,sizeof full));
    if(!actual)REQUIRE("header-failure-output-unchanged",!memcmp(&header,&header_before,sizeof header));
    else{
        REQUIRE("header-domain",header.value.domain==full.value.domain);
        REQUIRE("header-region-id-including-inactive-zero",header.value.region_id==full.value.region_id);
    }
    if(known>=0)REQUIRE("independent-known-acceptance",expected==(known!=0));
    if(full_ok)++full_accepted;
    if(actual)++header_accepted;else ++rejected;
    mix(size);mix(id);mix(full_ok);mix(actual);
    if(actual){mix((uint64_t)header.value.domain);mix(header.value.region_id);}
    return 0;
}
static int add_count(size_t offset,uint32_t cap,uint32_t count,const char *label)
{
    REQUIRE("count-field-room",field_count<FIELD_CAPACITY);
    REQUIRE("encoded-count-at-known-layout",read32(original+offset)==count);
    fields[field_count++]=(CountField){offset,cap,count,label};return 0;
}
static int count_layout(size_t size)
{
    field_count=0;
    if(definition.domain!=GEO_PLACEMENT_REGION_SET)return 0;
    REQUIRE("component-count-field",!add_count(101,GEO_PLACEMENT_COMPONENT_CAPACITY,(uint32_t)definition.component_count,"components"));
    size_t at=105;
    for(size_t c=0;c<definition.component_count;++c){const GeoRegionDefinition *region=&definition.components[c];
        REQUIRE("component-id-layout",read32(original+at)==region->id);at+=4;
        REQUIRE("outline-count-field",!add_count(at,GEO_LOOP_MAX_VERTICES,(uint32_t)region->outline.count,"outline-vertices"));
        at+=4+16*region->outline.count;
        REQUIRE("hole-count-field",!add_count(at,GEO_REGION_MAX_HOLES,(uint32_t)region->hole_count,"holes"));at+=4;
        for(size_t h=0;h<region->hole_count;++h){
            REQUIRE("hole-vertex-count-field",!add_count(at,GEO_LOOP_MAX_VERTICES,(uint32_t)region->holes[h].count,"hole-vertices"));
            at+=4+16*region->holes[h].count;
        }
    }
    REQUIRE("known-valid-layout-size",at==size);return 0;
}
static void report(const char *phase,size_t size)
{
    printf("vector=%s phase=%s wire=%zu comparisons=%" PRIu64 " full-accepted=%" PRIu64 " header-accepted=%" PRIu64 " rejected=%" PRIu64 " transcript=%016" PRIx64 "\n",
        vector_name,phase,size,comparisons,full_accepted,header_accepted,rejected,transcript);fflush(stdout);
}
static int run_vector(const char *name,bool maximum)
{
    vector_name=name;memset(original,0x7b,sizeof original);
    size_t size=geo_placement_definition_encode(&definition,original,GEO_PLACEMENT_DEFINITION_MAX_BYTES);
    REQUIRE("valid-vector-encodes",size>0);++encoded_vectors;
    if(maximum)REQUIRE("maximum-size-exact",size==GEO_PLACEMENT_DEFINITION_MAX_BYTES);
    REQUIRE("known-base-id",read32(original)==definition.id);
    REQUIRE("known-domain-offset",original[100]==(unsigned char)definition.domain);
    REQUIRE("base-full-header",!compare(original,size,definition.id,1));
    REQUIRE("base-frame-unchanged",!memcmp(&full.value.frame,&definition.frame,sizeof definition.frame));
    REQUIRE("base-domain",full.value.domain==definition.domain);
    REQUIRE("base-region-id",full.value.region_id==(definition.domain==GEO_PLACEMENT_REGION_REF?definition.region_id:0));
    REQUIRE("count-layout",!count_layout(size));

    for(size_t offset=0;offset<16;++offset){
        memset(aligned,0x6d,sizeof aligned);memcpy(aligned+16+offset,original,size);memcpy(aligned_before,aligned,sizeof aligned);
        REQUIRE("unaligned-valid",!compare(aligned+16+offset,size,definition.id,1));
        REQUIRE("unaligned-input-immutable",!memcmp(aligned,aligned_before,sizeof aligned));
    }
    ++null_outputs;REQUIRE("full-null-output",!geo_placement_definition_decode(original,size,NULL));
    ++null_outputs;REQUIRE("header-null-output",!geo_pd_definition_header(original,size,definition.id,NULL));
    report("base-alignments-null-output",size);

    memset(work,0x9d,sizeof work);unsigned char *bytes=work+17;memcpy(bytes,original,size);memcpy(work_before,work,sizeof work);
    for(size_t truncated=0;truncated<size;++truncated)REQUIRE("all-truncations",!compare(bytes,truncated,definition.id,0));
    REQUIRE("truncation-input-immutable",!memcmp(work,work_before,sizeof work));report("all-truncations",size);

    static const unsigned masks[]={1,0x80,0xff};
    for(size_t at=0;at<size;++at)for(size_t m=0;m<sizeof masks/sizeof masks[0];++m){
        bytes[at]^=(unsigned char)masks[m];
        REQUIRE("every-byte-three-variants",!compare(bytes,size,definition.id,-1));
        bytes[at]^=(unsigned char)masks[m];
    }
    REQUIRE("byte-variant-input-immutable",!memcmp(work,work_before,sizeof work));report("every-byte-xor-01-80-ff",size);

    for(unsigned domain=0;domain<256;++domain){bytes[100]=(unsigned char)domain;
        REQUIRE("all-domain-tags",!compare(bytes,size,definition.id,domain>GEO_PLACEMENT_REGION_SET?0:-1));}
    bytes[100]=original[100];
    for(unsigned bit=0;bit<32;++bit){uint32_t id=definition.id^(UINT32_C(1)<<bit);put32(bytes,id);
        REQUIRE("id-mismatch-rejected",!compare(bytes,size,definition.id,0));
        REQUIRE("id-new-match-accepted",!compare(bytes,size,id,1));}
    memcpy(bytes,original,4);
    if(definition.domain==GEO_PLACEMENT_REGION_REF){
        static const uint32_t region_ids[]={0,1,UINT32_MAX,UINT32_C(0x80000000),UINT32_C(0x7fffffff),UINT32_C(0x01020304)};
        for(size_t i=0;i<sizeof region_ids/sizeof region_ids[0];++i){put32(bytes+101,region_ids[i]);
            REQUIRE("all-region-id-values",!compare(bytes,size,definition.id,1));
            REQUIRE("known-region-id-value",header.value.region_id==region_ids[i]);}
        memcpy(bytes+101,original+101,4);
    }
    report("domain-id-region",size);

    for(size_t f=0;f<field_count;++f){CountField field=fields[f];
        uint32_t values[]={0,field.cap-1,field.cap,field.cap+1,UINT32_MAX,UINT32_C(0x80000000)};
        for(size_t i=0;i<sizeof values/sizeof values[0];++i){put32(bytes+field.offset,values[i]);
            REQUIRE("count-bound-variants",!compare(bytes,size,definition.id,values[i]>field.cap?0:-1));}
        put32(bytes+field.offset,field.original);
    }
    REQUIRE("count-variant-input-immutable",!memcmp(work,work_before,sizeof work));report("all-count-fields-boundaries",size);

    static const size_t tails[]={1,2,3,7,8,15,31};
    for(size_t t=0;t<sizeof tails/sizeof tails[0];++t){
        memset(bytes+size,0,tails[t]);REQUIRE("zero-tail",!compare(bytes,size+tails[t],definition.id,0));
        memset(bytes+size,0xff,tails[t]);REQUIRE("ff-tail",!compare(bytes,size+tails[t],definition.id,0));
        memset(bytes+size,0x9d,tails[t]);
    }
    REQUIRE("tail-input-immutable",!memcmp(work,work_before,sizeof work));
    REQUIRE("over-maximum-size",!compare(bytes,(size_t)GEO_PLACEMENT_DEFINITION_MAX_BYTES+1,definition.id,0));
    REQUIRE("size-max-rejected-before-pointer-arithmetic",!compare(bytes,SIZE_MAX,definition.id,0));
    report("tails-size-limit",size);return 0;
}
static GeoCoord extreme(size_t i)
{
    static const GeoCoord values[]={INT64_MIN,INT64_MAX,0,-1,1,INT64_C(-100000001),INT64_C(100000001),INT64_C(0x0102030405060708)};
    return values[i%(sizeof values/sizeof values[0])];
}
static void base(uint32_t id,GeoPlacementDomain domain,size_t seed)
{
    memset(&definition,0,sizeof definition);definition.id=id;definition.domain=domain;
    definition.frame.origin=(GeoPoint3){extreme(seed),extreme(seed+1),extreme(seed+2)};
    definition.frame.axis_u=(GeoVector3){extreme(seed+3),extreme(seed+4),extreme(seed+5)};
    definition.frame.axis_v=(GeoVector3){extreme(seed+6),extreme(seed+7),extreme(seed+8)};
    definition.frame.normal=(GeoVector3){extreme(seed+9),extreme(seed+10),extreme(seed+11)};
    definition.rect=(GeoRect2){INT64_MIN,INT64_MAX,-1,0};
    definition.region_id=UINT32_C(0xdeadbeef); /* inactive fields are not semantic input */
}
static void loop(GeoRegionLoop *value,size_t count,size_t seed)
{
    value->count=count;
    for(size_t v=0;v<count;++v)value->v[v]=(GeoPoint2){extreme(seed+v),extreme(seed+v+3)};
}
static int encoder_invalid_counts(void)
{
    unsigned char out[32],before[32];memset(out,0xa5,sizeof out);memcpy(before,out,sizeof out);
    base(1,GEO_PLACEMENT_REGION_SET,0);definition.component_count=GEO_PLACEMENT_COMPONENT_CAPACITY+1;
    REQUIRE("encoder-component-bound",!geo_placement_definition_encode(&definition,out,sizeof out)&&!memcmp(out,before,sizeof out));
    definition.component_count=1;definition.components[0].outline.count=GEO_LOOP_MAX_VERTICES+1;
    REQUIRE("encoder-outline-bound",!geo_placement_definition_encode(&definition,out,sizeof out)&&!memcmp(out,before,sizeof out));
    definition.components[0].outline.count=0;definition.components[0].hole_count=GEO_REGION_MAX_HOLES+1;
    REQUIRE("encoder-hole-bound",!geo_placement_definition_encode(&definition,out,sizeof out)&&!memcmp(out,before,sizeof out));
    definition.components[0].hole_count=1;definition.components[0].holes[0].count=GEO_LOOP_MAX_VERTICES+1;
    REQUIRE("encoder-hole-vertices-bound",!geo_placement_definition_encode(&definition,out,sizeof out)&&!memcmp(out,before,sizeof out));
    return 0;
}
int main(void)
{
    REQUIRE("null-content-zero",!compare(NULL,0,0,0));
    REQUIRE("null-content-one",!compare(NULL,1,0,0));
    REQUIRE("null-content-maximum",!compare(NULL,GEO_PLACEMENT_DEFINITION_MAX_BYTES,0,0));
    REQUIRE("null-content-size-max",!compare(NULL,SIZE_MAX,0,0));
    REQUIRE("invalid-encode-bounds",!encoder_invalid_counts());
    base(0,GEO_PLACEMENT_RECT,0);REQUIRE("rect-zero-id",!run_vector("RECT-zero-id-signed-extremes",false));
    base(UINT32_MAX,GEO_PLACEMENT_RECT,4);REQUIRE("rect-max-id",!run_vector("RECT-max-id-shifted-extremes",false));
    base(17,GEO_PLACEMENT_REGION_REF,1);definition.region_id=0;REQUIRE("ref-zero",!run_vector("REF-zero-region",false));
    base(UINT32_MAX,GEO_PLACEMENT_REGION_REF,5);definition.region_id=UINT32_MAX;REQUIRE("ref-max",!run_vector("REF-max-region-id",false));
    base(3,GEO_PLACEMENT_REGION_SET,2);REQUIRE("empty-set",!run_vector("SET-empty",false));
    base(4,GEO_PLACEMENT_REGION_SET,3);definition.component_count=1;REQUIRE("empty-component",!run_vector("SET-one-empty-component",false));
    base(5,GEO_PLACEMENT_REGION_SET,4);definition.component_count=1;definition.components[0].hole_count=GEO_REGION_MAX_HOLES;
    REQUIRE("empty-holes",!run_vector("SET-eight-empty-holes",false));
    base(6,GEO_PLACEMENT_REGION_SET,6);definition.component_count=1;definition.components[0].id=UINT32_MAX;
    loop(&definition.components[0].outline,GEO_LOOP_MAX_VERTICES,0);definition.components[0].hole_count=GEO_REGION_MAX_HOLES;
    for(size_t h=0;h<GEO_REGION_MAX_HOLES;++h)loop(&definition.components[0].holes[h],GEO_LOOP_MAX_VERTICES,h);
    REQUIRE("one-max-component",!run_vector("SET-one-max-component-eight-holes-32-vertices",false));
    base(7,GEO_PLACEMENT_REGION_SET,7);definition.component_count=GEO_PLACEMENT_COMPONENT_CAPACITY;
    for(size_t c=0;c<definition.component_count;++c){GeoRegionDefinition *r=&definition.components[c];r->id=(uint32_t)(c*31);
        loop(&r->outline,c,c);r->hole_count=c;
        static const size_t counts[]={0,1,31,32};for(size_t h=0;h<r->hole_count;++h)loop(&r->holes[h],counts[h%4],c+h);}
    REQUIRE("mixed-components",!run_vector("SET-eight-mixed-components",false));
    base(UINT32_MAX,GEO_PLACEMENT_REGION_SET,0);definition.component_count=GEO_PLACEMENT_COMPONENT_CAPACITY;
    for(size_t c=0;c<definition.component_count;++c){GeoRegionDefinition *r=&definition.components[c];r->id=c%2?0:UINT32_MAX;
        loop(&r->outline,GEO_LOOP_MAX_VERTICES,c);r->hole_count=GEO_REGION_MAX_HOLES;
        for(size_t h=0;h<r->hole_count;++h)loop(&r->holes[h],GEO_LOOP_MAX_VERTICES,c+h);}
    REQUIRE("all-max-components",!run_vector("SET-maximum-eight-components-eight-holes-32-vertices",true));
    printf("PASS placement-header-raw-equivalence vectors=%" PRIu64 " comparisons=%" PRIu64 " full-accepted=%" PRIu64 " header-accepted=%" PRIu64 " rejected=%" PRIu64 " null-output=%" PRIu64 " transcript=%016" PRIx64 "\n",
        encoded_vectors,comparisons,full_accepted,header_accepted,rejected,null_outputs,transcript);return 0;
}
