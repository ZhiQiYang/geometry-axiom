#!/usr/bin/env python3
"""只錄製 F 一個原 static checker：fixed0 / old-checker1 / restored0。"""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import sys
import traceback
import capture

DESIGN_SHA = 'fe863b0374eafd9f1e57ec5107e28a1101804b56'
OLD_SHA = '9535fcfcec9d1fc8ddd4b149f499bd4e2312f255'
TEST = 'tests/test_geo261_wood_contact_world.py'
METHOD = 'tests.test_geo261_wood_contact_world.ContactWorldBoundary.test_five_real_main_consumers_delegate_and_keep_original_member_identity'
FIXED_HASH = 'ca028800aa8d614fa34749b32b3e819d9dc6c351b8b4f09d7fd091f95402d181'
OLD_HASH = '5a73d425e113284924f2a842c3760012affe15e9735d1d6da3eb074bd531da48'
OLD_LINE = b'        adapter = function(source, "app_contact_facts")\n'
NEW_LINES = (b'        wrapper = function(source, "app_contact_facts")\n'
             b'        self.assertEqual("app_contact_facts_prepare(world,placement,boundary,facts,NULL);", wrapper.strip())\n'
             b'        adapter = function(source, "app_contact_facts_prepare")\n')
INPUTS = ('current_geometry.c', 'geometry-templates/woodworking/native/contact_world.c',
          'geometry-templates/woodworking/native/contact_world.h')
SAFE_ENV = ('PATH', 'LANG', 'LC_ALL', 'TMPDIR', 'PYTHONDONTWRITEBYTECODE', 'PYTHONIOENCODING',
            'PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONSTARTUP', 'NODE_OPTIONS', 'GITHUB_SHA',
            'GITHUB_WORKSPACE', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--scratch', required=True, type=Path)
    parser.add_argument('--heavy-lock', required=True, type=Path)
    args = parser.parse_args()
    require(not sys.flags.optimize, '不可用 Python optimize 執行錄製器')
    require(args.sha == DESIGN_SHA, '本工具只準備給明列 F；不得改綁別的 SHA')
    repo, out, lock_path = args.repo.resolve(), args.scratch.resolve(), args.heavy_lock.resolve()
    require(repo.is_dir(), '來源 repository 不存在')
    require(out != repo and not out.is_relative_to(repo) and not repo.is_relative_to(out), 'scratch 必須在來源外')
    require(any(out.is_relative_to(Path(p)) for p in ('/tmp', '/workspace')), 'scratch 必須位於 /tmp 或 /workspace')
    require(not out.exists() and out.parent.is_dir(), 'scratch 必須全新且父目錄已存在')
    require(lock_path.is_file() and not lock_path.is_relative_to(out), '須傳入已存在的正式 F 共用 heavy lock')
    require(Path(capture.__file__).resolve() == Path(__file__).resolve().with_name('capture.py'), 'capture 模組來源錯誤')
    out.mkdir()
    (out/'tmp').mkdir()
    (out/'tools').mkdir()
    frozen = {}
    for name in ('run_final_checker_proof.py', 'capture.py', 'checker-withdraw-F-to-9535.patch'):
        path = Path(__file__).resolve().with_name(name)
        raw = path.read_bytes()
        (out/'tools'/name).write_bytes(raw)
        frozen[str(path)] = digest(raw)
    env = dict(os.environ)
    cleared = []
    for name in list(env):
        if name.startswith('GEOMETRY_') or name in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONSTARTUP', 'NODE_OPTIONS'):
            cleared.append(name)
            env.pop(name)
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
               PYTHONIOENCODING='utf-8', GITHUB_SHA=args.sha,
               GITHUB_WORKSPACE=str(repo), TMPDIR=str(out/'tmp'))
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    require(hard == resource.RLIM_INFINITY or hard >= 16384 * 1024, 'hard stack 不足 16 MiB')
    resource.setrlimit(resource.RLIMIT_STACK, (16384 * 1024, hard))
    recorder = capture.Recorder(out, env, args.sha)
    clone = out/'checkout'
    errors, phases, guards = [], [], []
    fixed = None
    original_inputs = None
    receipt = {'schema': 'geo261-final-F-contact-checker-proof/1', 'sha': args.sha,
               'repo': str(repo), 'clone': str(clone), 'heavy_lock': str(lock_path),
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'method': METHOD, 'scope': 'one unchanged original unittest static method only',
               'product_tests_or_builds_expanded': False, 'tool_hashes': frozen,
               'python': sys.version, 'python_executable': sys.executable,
               'platform': platform.platform(), 'cleared_inherited_environment': cleared,
               'base_environment': {k: env.get(k) for k in SAFE_ENV},
               'stack_before': [soft, hard], 'stack_during': [16384 * 1024, hard],
               'phases': phases, 'guards': guards, 'errors': errors, 'passed': False}
    save(out/'receipt.json', receipt)

    def command(argv, cwd, *, check=True, variant=None):
        return recorder.run(argv, cwd=cwd, timeout=120, check=check,
                            source_sha=args.sha, source_variant=variant)

    def git(path, *parts):
        return command(['git', *parts], path)[1]

    def guard(path, label, old=False):
        head = git(path, 'rev-parse', 'HEAD').decode().strip()
        status = git(path, 'status', '--porcelain=v1', '--untracked-files=all').decode()
        changed = [x.decode() for x in git(path, 'diff', '--name-only', '-z', 'HEAD').split(b'\0') if x]
        # Full-tree diff/status prove only the checker differs, with no staged side effects.
        raw_diff = git(path, 'diff', '--binary', '--full-index', '--no-ext-diff', '--no-color', 'HEAD')
        staged = git(path, 'diff', '--cached', '--name-only', '-z')
        expected_status = ' M ' + TEST + '\n' if old else ''
        expected_hash = OLD_HASH if old else FIXED_HASH
        actual_inputs = {rel: digest((path/rel).read_bytes()) for rel in INPUTS}
        row = {'label': label, 'path': str(path), 'head': head, 'status': status,
               'changed': changed, 'full_diff_sha256': digest(raw_diff),
               'checker_sha256': digest((path/TEST).read_bytes()), 'product_input_sha256': actual_inputs}
        guards.append(row)
        require(head == args.sha, label + ': HEAD 不符 F')
        require(status == expected_status and changed == ([TEST] if old else []) and not staged,
                label + ': 整棵 tracked tree 有非預期變動')
        require(row['checker_sha256'] == expected_hash, label + ': checker bytes 不符')
        if original_inputs is not None:
            require(actual_inputs == original_inputs, label + ': 產品輸入 bytes 變更')
        return row

    def run_phase(name, expect_old):
        row = {'phase': name, 'expected_exit': 1 if expect_old else 0, 'passed': False}
        phases.append(row)
        try:
            guard(clone, name + '-before', old=expect_old)
            child_env = dict(env, GITHUB_WORKSPACE=str(clone))
            row['environment'] = {k: child_env.get(k) for k in SAFE_ENV}
            row['checker_sha256'] = digest((clone/TEST).read_bytes())
            row['source_variant'] = 'withdrawn-old-test-checker-only' if expect_old else 'clean-F'
            recorder.env = child_env
            try:
                result, stdout, stderr = command([sys.executable, '-B', '-m', 'unittest', '-v', METHOD], clone,
                                                check=False, variant=row['source_variant'])
            finally:
                recorder.env = env
            row['command_result'] = result
            text = stderr.decode('utf-8')
            require(result['actual_process_returncode'] == row['expected_exit'], name + ': 真退出碼不符')
            require(not result['timeout_expired'] and 'exception' not in result, name + ': 環境/啟動/逾時不能作裁判')
            require(stdout == b'', name + ': 原 static 方法 stdout 應空')
            require(re.search(r'^Ran 1 test in [0-9.]+s$', text, re.M) is not None, name + ': 必須恰執行一個方法')
            require('ERROR:' not in text and '... ERROR' not in text and 'skipped=' not in text, name + ': 不接受ERROR或skip')
            if expect_old:
                require('FAIL: ' + METHOD.rsplit('.', 1)[1] + ' (' + METHOD + ')' in text,
                        name + ': 缺原具名 FAIL')
                require("AssertionError: Regex didn't match:" in text and
                        "not found in 'app_contact_facts_prepare(world,placement,boundary,facts,NULL);'" in text,
                        name + ': 失敗不是既知 wrapper/prepare checker 病因')
                require(text.rstrip().endswith('FAILED (failures=1)'), name + ': 不能有額外failure/error')
            else:
                require(text.rstrip().endswith('OK') and 'FAIL:' not in text, name + ': 原方法未全綠')
            guard(clone, name + '-after', old=expect_old)
            row['passed'] = True
        except Exception:
            row['error'] = traceback.format_exc()
            errors.append(name + ': ' + row['error'])
        save(out/'receipt.json', receipt)

    lock = lock_path.open('a+b')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        guard(repo, 'original-before')
        original_inputs = {rel: digest((repo/rel).read_bytes()) for rel in INPUTS}
        fixed = git(repo, 'show', args.sha + ':' + TEST)
        old = git(repo, 'show', OLD_SHA + ':' + TEST)
        require(digest(fixed) == FIXED_HASH and digest(old) == OLD_HASH, '原 Git checker blobs 不符鎖定 hashes')
        require(fixed.count(NEW_LINES) == 1 and fixed.replace(NEW_LINES, OLD_LINE, 1) == old,
                '撤回必須恰為既知三行→一行 checker 差分')
        receipt['original_product_inputs'] = original_inputs
        receipt['old_checker_commit'] = OLD_SHA
        command(['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo), str(clone)], out)
        git(clone, 'checkout', '--detach', args.sha)
        guard(clone, 'clone-created')
        run_phase('fixed', False)
        try:
            (clone/TEST).write_bytes(old)
            actual = git(clone, 'diff', '--binary', '--full-index', '--no-ext-diff', '--no-color', 'HEAD')
            (out/'actual-withdraw-test-only.patch').write_bytes(actual)
            receipt['actual_withdraw_patch_sha256'] = digest(actual)
            run_phase('withdrawn', True)
        except Exception:
            errors.append('withdraw setup: ' + traceback.format_exc())
        finally:
            try:
                (clone/TEST).write_bytes(fixed)
            except Exception:
                errors.append('inner restore: ' + traceback.format_exc())
        run_phase('restored', False)
    except BaseException:
        errors.append('outer: ' + traceback.format_exc())
    finally:
        if fixed is not None and (clone/TEST).is_file():
            try:
                (clone/TEST).write_bytes(fixed)
                guard(clone, 'clone-final-restored')
            except BaseException:
                errors.append('final clone restore/guard: ' + traceback.format_exc())
        try:
            guard(repo, 'original-after')
        except BaseException:
            errors.append('final original guard: ' + traceback.format_exc())
        for path, expected in frozen.items():
            try:
                require(digest(Path(path).read_bytes()) == expected, '工具執行中改變: ' + path)
            except BaseException:
                errors.append('tool guard: ' + traceback.format_exc())
        receipt.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       commands=recorder.rows,
                       passed=not errors and [r['phase'] for r in phases] == ['fixed', 'withdrawn', 'restored']
                       and all(r['passed'] for r in phases))
        save(out/'receipt.json', receipt)
        # Keep command raw and clone evidence; never remove failed or withdrawn evidence.
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()
    print(json.dumps({'receipt': str(out/'receipt.json'), 'sha': args.sha,
                      'passed': receipt['passed'], 'phase_count': len(phases)}, ensure_ascii=False))
    return 0 if receipt['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
