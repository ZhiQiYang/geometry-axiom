#!/usr/bin/env python3
"""只讀真P2重綁產物／Git／raw；不import或執行待審工具，不改bundle。"""
import copy,datetime,difflib,hashlib,json,os,re,subprocess,sys,traceback
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/geo261-environment')
STAGE=Path('/tmp/g261p2bind2');BUNDLE=STAGE/'bundle'
LAUNCH=ROOT/'p2-rebind-launch-attempt2'
ORIGINAL=ROOT/'final-f-p189-counterfactual-tools'
REPO=Path('/tmp/g261htmlseal/html-source');PUBLIC_REPO=Path('/workspace/geometry-axiom')
P='b6646d10751a0d85a2f03f5d24fbe1073cb78980';P2='8a80abc1402b0c4c394969025c93a6019b4bb91d'
TARGET='geometry-guide/公理層-閱讀器.html';ART='geometry-core/domain-decoupling/product-architecture.json'
SUFFIXES={'.c','.cc','.cjs','.cpp','.cxx','.h','.hh','.hpp','.htm','.html','.inc','.js','.jsx','.mjs','.py','.ts','.tsx'}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def filehash(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def info(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':filehash(path)}
def load(path):return json.loads(path.read_text())
def same(a,b):return json.dumps(a,sort_keys=True,ensure_ascii=False)==json.dumps(b,sort_keys=True,ensure_ascii=False)
report={'schema':'geo261-actual-P2-binding-independent-audit/1','P2':P2,'original_P':P,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'passed':False,'issues':[],'checks':[],'read_commands':[],'approval_written':False,'bundle_modified':False,
 'not_executed':['rebind.py','rebind_gate','counterfactual tool','scanner','product','build','benchmark','native','browser'],
 'environment':{'python':sys.version,'cwd':os.getcwd(),'LANG':os.environ.get('LANG'),'LC_ALL':os.environ.get('LC_ALL')},'audit_tool':info(Path(__file__).resolve())}
def need(label,value):
 report['checks'].append({'label':label,'passed':bool(value)})
 if not value:raise RuntimeError(label)
def git(label,sha,*args,where=REPO,data=None):
 path=OUT/'git-reads'/label;path.mkdir(parents=True)
 command=['git','-C',str(where),*args];r=subprocess.run(command,input=data,capture_output=True)
 (path/'stdout').write_bytes(r.stdout);(path/'stderr').write_bytes(r.stderr)
 if data is not None:(path/'stdin').write_bytes(data)
 report['read_commands'].append({'command':command,'cwd':os.getcwd(),'source_sha':sha,'actual_exit_code':r.returncode,'stdout':info(path/'stdout'),'stderr':info(path/'stderr'),'stdin':info(path/'stdin') if data is not None else None})
 need('Git0 '+label,r.returncode==0);return r.stdout
def tree(label,sha,prefix=None):
 args=['ls-tree','-r','-z',sha]+(['--',prefix] if prefix else [])
 rows={}
 for part in git(label,sha,*args).split(b'\0'):
  if not part:continue
  meta,path=part.split(b'\t',1);mode,kind,oid=meta.decode().split();rows[path.decode()]={'mode':mode,'kind':kind,'blob_id':oid}
 return rows
def batch(label,sha,paths):
 raw=git(label,sha,'cat-file','--batch',data=''.join(sha+':'+p+'\n' for p in paths).encode());cursor=0;result={}
 for path in paths:
  e=raw.index(b'\n',cursor);head=raw[cursor:e].split();size=int(head[2]);body=raw[e+1:e+1+size];cursor=e+size+2
  need('Git blob valid '+label+'/'+path,head[1]==b'blob' and len(body)==size and raw[cursor-1:cursor]==b'\n');result[path]=body
 need('Git batch exact '+label,cursor==len(raw));return result
def manifest_check(directory,expected_sha=None):
 if expected_sha:need('manifest pinned '+str(directory),filehash(directory/'SHA256SUMS')==expected_sha)
 entries={}
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  value,name=line.split('  ',1);p=Path(name);need('manifest safe '+name,re.fullmatch('[0-9a-f]{64}',value) is not None and not p.is_absolute() and '..' not in p.parts and name not in entries);entries[name]=value
 need('manifest file set exact '+str(directory),{p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}==set(entries)|{'SHA256SUMS'})
 for name,wanted in entries.items():need('manifest raw '+str(directory/name),not (directory/name).is_symlink() and filehash(directory/name)==wanted)
 return {**entries,'SHA256SUMS':filehash(directory/'SHA256SUMS')}
try:
 inner=load(STAGE/'receipt.json');outer=load(LAUNCH/'receipt.json');evidence=load(BUNDLE/'REBIND_EVIDENCE.json');policy=load(BUNDLE/'rebind-policy.json');design=load(BUNDLE/'counterfactual-design.json');request=load(BUNDLE/'P2_REVIEW_REQUEST.json')
 initial_bundle=manifest_check(BUNDLE,'055a7f82a1d76feab40e74170751f1852949f75b33320460eb24d601b8f1fd4f')
 original_files=manifest_check(ORIGINAL,policy['original_ready_manifest_sha256'])
 need('inner source preparation real0',inner['schema']=='geo261-P2-counterfactual-rebind/1' and inner['P2']==P2 and inner['exit_code']==0 and inner['errors']==[] and inner['acceptance_execution'] is False and inner['product_build_or_execution'] is False and inner['bundle_ready_for_F_runtime'] is False)
 need('outer actual0 no timeout',outer['schema']=='geo261-P2-rebind-outer-launch/1' and outer['source_sha']==P2 and outer['actual_process_returncode']==0 and outer['timeout_expired'] is False and outer['tool_sources_unchanged'] is True and outer['frozen_tool_sources_unchanged'] is True)
 for stream in ('stdout','stderr'):
  raw=(LAUNCH/(stream+'.bin')).read_bytes();need('outer full '+stream,len(raw)==outer[stream+'_bytes'] and digest(raw)==outer[stream+'_sha256'])
 need('outer stderr genuinely empty',outer['stderr_bytes']==0)
 need('outer driver exact snapshot',filehash(LAUNCH/'outer-driver.py.txt')==outer['outer_driver_sha256'])
 for name,wanted in outer['tool_source_hashes'].items():need('outer frozen preparer '+name,filehash(LAUNCH/'preparer'/name)==wanted)
 for name,wanted in inner['preparer_source_sha256'].items():
  need('preparer hash chain '+name,filehash(LAUNCH/'preparer'/name)==filehash(STAGE/'preparer-source'/name)==filehash(BUNDLE/'PREPARER_SOURCE'/name)==wanted)
 need('actual reviewed preparer/gate',inner['preparer_source_sha256']['rebind.py']=='4f016b3cd1e97fdf3974fee54c04c3d92bd2c2bf54bee61d23915c3c2ce37521' and inner['preparer_source_sha256']['rebind_gate.py.txt']=='2b71fff98014522b1758da8518d42da7002294a14d618650bcaea6e4ae2c8eb3')
 need('original READY fully unchanged',original_files==inner['original_READY_hashes'])
 need('before after exact clean P2',inner['source_before']==inner['source_after']=={'head':P2,'status':''})
 need('current P2 clone still clean',git('current-head',P2,'rev-parse','HEAD').decode().strip()==P2 and git('current-status',P2,'status','--porcelain=v1','--untracked-files=all')==b'')
 parent=inner['P2_parent'];parents=git('parents',P2,'rev-list','--parents','-n','1',P2).decode().split()
 need('real single parent',parents==[P2,parent]);git('P-ancestor',P2,'merge-base','--is-ancestor',P,P2)
 changed=git('parent-diff',P2,'diff','--no-renames','--name-only','-z',parent,P2).decode().split('\0');need('parent diff exact HTML',[x for x in changed if x]==[TARGET])
 all_raw={};all_modes={};all_trees={};manifests={};paths=None
 for role,sha in [('P',P),('parent',parent),('P2',P2)]:
  mb=git('manifest-'+role,sha,'show',sha+':'+ART);m=json.loads(mb);manifests[role]=m
  declared={x['path'] for x in m['sources']+m['exclusions']};need('601/333/268 '+role,len(declared)==601 and len(m['sources'])==333 and len(m['exclusions'])==268)
  if paths is None:paths=sorted(declared)
  need('same full601 set '+role,sorted(declared)==paths)
  if role!='P':need('A policy raw '+role,digest(mb)==policy['required_P2_and_parent_manifest_sha256']=='0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6')
  t=tree('tree-'+role,sha);all_trees[role]=t;inv={p for p in t if (p in m['sourceFiles'] or any(p.startswith(x+'/') for x in m['sourceRoots'])) and Path(p).suffix.lower() in SUFFIXES}
  need('true Git601 '+role,inv==declared and len({p.casefold() for p in inv})==601 and all(t[p]['mode'] in ('100644','100755') and t[p]['kind']=='blob' for p in inv))
  all_modes[role]={p:t[p]['mode'] for p in paths};all_raw[role]=batch('blobs-'+role,sha,paths)
 need('601 modes identical',all_modes['P']==all_modes['parent']==all_modes['P2']==inner['input_modes'][P]==inner['input_modes'][parent]==inner['input_modes'][P2])
 need('parent all601 equals P',all_raw['P']==all_raw['parent'])
 need('600 raw untouched',[p for p in paths if all_raw['P'][p]!=all_raw['P2'][p]]==[TARGET])
 for role,key in [('P','all_601_original_raw_sha256'),('P2','all_601_P2_raw_sha256')]:need('all601 evidence raw '+role,{p:digest(v) for p,v in all_raw[role].items()}==inner[key]==evidence[key])
 owned={x['path'] for x in manifests['P2']['sources']};new_owned={p:digest(all_raw['P2'][p]) for p in owned};old_owned={p:digest(all_raw['P'][p]) for p in owned}
 need('exact333 new design binding',len(new_owned)==333 and new_owned==design['owned_product_hashes']==inner['owned_P2_raw_sha256']==evidence['owned_P2_raw_sha256'])
 original_design=load(ORIGINAL/'counterfactual-design.json');need('original333 evidence',old_owned==original_design['owned_product_hashes']==inner['owned_original_raw_sha256'])
 before=all_raw['P'][TARGET];after=all_raw['P2'][TARGET];old_anchor=policy['old_unique_full_trace_utf8'].encode();new_anchor=policy['new_unique_full_trace_utf8'].encode()
 at=before.index(old_anchor);a=before.rfind(b'<article',0,at);z=before.find(b'>',a)
 need('unique full trace inside I11',before.count(old_anchor)==1 and before.count(new_anchor)==0 and a>=0 and re.search(rb'\bid="I11"',before[a:z+1]) is not None)
 need('only approved fullfile +8',after==before.replace(old_anchor,new_anchor,1) and digest(before)==policy['original_HTML_sha256'] and digest(after)==policy['expected_P2_HTML_sha256'] and len(after)-len(before)==8==inner['exact_HTML_byte_delta'])
 for path in ('公理層.md','決策佇列.md'):
  need('SSOT mode/blob '+path,all_trees['P'][path]==all_trees['P2'][path]);raw=git('SSOT-'+path,P2,'show',P2+':'+path);need('SSOT protected raw '+path,digest(raw)==inner['protected_explicit_raw_sha256'][path])
 tests={role:{p:{'mode':v['mode'],'blob_id':v['blob_id']} for p,v in all_trees[role].items() if p.startswith('tests/')} for role in ('P','P2')}
 need('all tracked tests exact sets and evidence',len(tests['P'])>0 and set(tests['P'])==set(tests['P2']) and tests['P']==inner['tests_P_blob_ids'] and tests['P2']==inner['tests_P2_blob_ids'])
 test_changes=[p for p in sorted(tests['P']) if tests['P'][p]!=tests['P2'][p]];need('only prior ledger test artifact',test_changes==inner['tests_changed_from_P'] and set(test_changes)<={policy['only_allowed_changed_test_artifact_from_P']})
 for path,value in inner['protected_explicit_raw_sha256'].items():
  if path in new_owned:need('P73/C8/header protected '+path,new_owned[path]==old_owned[path]==value)
 journal=load(STAGE/'subcommands.json');snapshot=load(BUNDLE/'SOURCE_CHECK_COMMANDS.json');need('final39 snapshot37 exactprefix',journal==inner['commands'] and len(journal)==39 and len(snapshot)==37 and same(snapshot,journal[:37]))
 nonzero=[]
 for i,row in enumerate(journal,1):
  folder=Path(row['directory']);need('raw directory exact '+str(i),folder==STAGE/'subcommands'/('%06d'%i))
  need('original result complete '+str(i),same(load(folder/'result.json'),row) and row['timeout_expired'] is False and type(row['actual_process_returncode']) is int)
  need('recorded only Git '+str(i),row['command'][0]=='git' and row['acceptance_sha']==P2)
  for stream in ('stdout','stderr'):
   raw=(folder/(stream+'.bin')).read_bytes();need('fullraw '+str(i)+' '+stream,len(raw)==row[stream+'_bytes'] and digest(raw)==row[stream+'_sha256'])
  need('stdin original '+str(i),filehash(folder/'stdin.bin')==row['stdin_sha256'])
  req=load(folder/'request.json');need('original request fields '+str(i),all(same(req[k],row[k]) for k in ('command','cwd','acceptance_sha','source_sha','source_variant','environment','started_epoch','stdin_provided','stdin_sha256')))
  if row['actual_process_returncode']!=0:
   need('only read-only negative ancestry query '+str(i),row['actual_process_returncode']==1 and row['command'][3:6]==['merge-base','--is-ancestor',P2]);nonzero.append(i)
 public=inner['published_P2'];remote=[x for x in journal if x['command'][3:]==['ls-remote','--refs','origin']]
 need('actual recorded network public ref',len(remote)==1 and public['tip']+'\t'+public['ref'] in (Path(remote[0]['directory'])/'stdout.bin').read_text().splitlines())
 git('public-tip-ancestor',P2,'merge-base','--is-ancestor',P2,public['tip'],where=PUBLIC_REPO)
 need('source journal hash chain',filehash(BUNDLE/'SOURCE_CHECK_COMMANDS.json')==filehash(STAGE/'SOURCE_CHECK_COMMANDS.json')==evidence['source_check_command_journal_sha256']==inner['source_check_command_journal_sha256'])
 need('evidence/policy/design request actualhash',request['design_source_sha']==P2 and request['design_sha256']==filehash(BUNDLE/'counterfactual-design.json')==inner['new_design_sha256'] and request['rebind_evidence_sha256']==filehash(BUNDLE/'REBIND_EVIDENCE.json')==design['rebind_evidence_sha256'] and request['rebind_policy_sha256']==filehash(BUNDLE/'rebind-policy.json')==design['rebind_policy_sha256'])
 for name,value in request['tool_source_sha256'].items():need('four tool source '+name,filehash(BUNDLE/name)==value)
 for path,value in request['counterfactual_template_sha256'].items():need('six template unchanged '+path,filehash(BUNDLE/'counterfactual-templates'/path)==filehash(ORIGINAL/'counterfactual-templates'/path)==value)
 old_run=(ORIGINAL/'run.py').read_text();new_run=(BUNDLE/'run.py').read_text();expected_run=old_run.replace('from validate import MAIN,BASE,formal,samples\n','from validate import MAIN,BASE,formal,samples\nfrom rebind_gate import verify_rebind_review\n',1).replace(" design=json.loads((TOOLS/'counterfactual-design.json').read_text());assert a.sha!=design['design_source_sha'],'必須填正式新F，不能用設計P冒充'"," design=json.loads((TOOLS/'counterfactual-design.json').read_text());verify_rebind_review(TOOLS,design)\n assert a.sha!=design['design_source_sha'],'必須填正式新F，不能用設計P2冒充'",1)
 need('runtime only gate adaptation no criterion changes',new_run==expected_run and filehash(BUNDLE/'capture.py')==filehash(ORIGINAL/'capture.py') and filehash(BUNDLE/'validate.py')==filehash(ORIGINAL/'validate.py'))
 expected_design=copy.deepcopy(original_design);expected_design.update(design_source_sha=P2,owned_product_hashes=new_owned,original_design_source_sha=P,rebind_review_required=True,rebind_policy_sha256=filehash(BUNDLE/'rebind-policy.json'),rebind_evidence_sha256=filehash(BUNDLE/'REBIND_EVIDENCE.json'),status='P2 rebound source prepared; independent new P2 binding review pending; no runtime')
 need('design changes only approved binding fields',same(expected_design,design))
 need('pending no false approval/failed marker',request['status']=='pending-independent-review' and request['actual_independent_P2_binding_review_completed'] is False and not (BUNDLE/'P2_BINDING_REVIEW.json').exists() and not (BUNDLE/'NOT_READY.json').exists() and not any(x.name in ('run.py.pending','run.py.failed') for x in BUNDLE.iterdir()))
 freeze=load(ROOT/'p2-rebind-freeze-8a80abc1/FREEZE.json');need('frozen incomplete first attempt honestly retained',freeze['P2']==P2 and freeze['first_attempt_environment_failure_incomplete'] is True and freeze['no_approval_written'] is True)
 for group in freeze['groups'].values():
  base=Path(group['original_root'])
  for relative,value in group['files'].items():need('freeze preserved '+str(base/relative),(base/relative).stat().st_size==value['bytes'] and filehash(base/relative)==value['sha256'])
 archive=freeze['archive'];need('complete raw freeze archive',Path(archive['path']).stat().st_size==archive['bytes'] and filehash(Path(archive['path']))==archive['sha256'])
 need('bundle unchanged after audit',manifest_check(BUNDLE)==initial_bundle);need('original READY unchanged after audit',manifest_check(ORIGINAL)==original_files)
 need('source still clean after audit',git('end-head',P2,'rev-parse','HEAD').decode().strip()==P2 and git('end-status',P2,'status','--porcelain=v1','--untracked-files=all')==b'')
 report.update(passed=True,P2_parent=parent,published_P2=public,all_inputs=601,unchanged_raw_inputs=600,owned=333,exact_HTML_byte_delta=8,tracked_tests=len(tests['P']),tests_changed_from_P=test_changes,
  final_raw_command_count=39,source_check_snapshot_count=37,negative_ancestry_queries_with_actual_rc1=nonzero,outer_actual_exit_code=0,inner_actual_exit_code=0,
  design=info(BUNDLE/'counterfactual-design.json'),evidence=info(BUNDLE/'REBIND_EVIDENCE.json'),policy=info(BUNDLE/'rebind-policy.json'),request=info(BUNDLE/'P2_REVIEW_REQUEST.json'),
  tool_source_sha256=request['tool_source_sha256'],counterfactual_template_sha256=request['counterfactual_template_sha256'],freeze=info(ROOT/'p2-rebind-freeze-8a80abc1/FREEZE.json'),
  scope='Actual P2 binding accepted for root to seal gate; no F runtime verdict; bundle not modified by auditor')
except BaseException as error:report['issues'].append({'exception':repr(error),'traceback':traceback.format_exc()})
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['check_count']=len(report['checks'])
(OUT/'AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'schema':report['schema'],'P2':P2,'passed':report['passed'],'check_count':len(report['checks']),'issues':report['issues'],'audit':str(OUT/'AUDIT.json')},ensure_ascii=False));sys.exit(0 if report['passed'] else 1)
