#!/usr/bin/env python3
"""只import已審純gate並驗metadata/hash；不import/run counterfactual或產品。"""
import importlib.util,json,hashlib,sys
from pathlib import Path
sys.dont_write_bytecode=True
B=Path('/tmp/g261p2bind2/bundle');OUT=Path(__file__).resolve().parent
def fh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
seal=json.loads((OUT/'BINDING_SEAL.json').read_text())
if fh(B/'rebind_gate.py')!='2b71fff98014522b1758da8518d42da7002294a14d618650bcaea6e4ae2c8eb3':raise RuntimeError('gate source changed')
if not all(fh(B/name)==value for name,value in seal['original_32_sha256'].items()):raise RuntimeError('original32 changed before pure gate')
spec=importlib.util.spec_from_file_location('geo261_actual_P2_binding_gate_only',B/'rebind_gate.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
design=json.loads((B/'counterfactual-design.json').read_text());module.verify_rebind_review(B,design)
if not all(fh(B/name)==value for name,value in seal['original_32_sha256'].items()):raise RuntimeError('original32 changed after pure gate')
if {p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}!=set(seal['original_32_sha256'])|{'P2_BINDING_REVIEW.md','P2_BINDING_REVIEW.json'}:raise RuntimeError('pure import created unexpected file')
print(json.dumps({'schema':'geo261-P2-binding-pure-gate-verification/1','P2':design['design_source_sha'],'gate_verified':True,
 'reviewer':'/root/round2_tool_preparation','gate_sha256':fh(B/'rebind_gate.py'),'approval_sha256':fh(B/'P2_BINDING_REVIEW.json'),
 'markdown_sha256':fh(B/'P2_BINDING_REVIEW.md'),'original_32_unchanged':True,'product_executed':False,'counterfactual_imported_or_executed':False},ensure_ascii=False))
