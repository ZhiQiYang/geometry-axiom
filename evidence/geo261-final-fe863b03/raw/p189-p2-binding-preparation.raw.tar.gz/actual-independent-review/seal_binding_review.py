#!/usr/bin/env python3
"""按root明確授權只新增兩份實際P2審查檔；不執行gate或產品。"""
import copy,datetime,hashlib,json,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;B=Path('/tmp/g261p2bind2/bundle')
MD=Path('/workspace/geo261-environment/actual-P2-counterfactual-binding-review.md')
def h(raw):return hashlib.sha256(raw).hexdigest()
def fh(p):return h(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def require(v,m):
 if not v:raise RuntimeError(m)
require(fh(B/'SHA256SUMS')=='055a7f82a1d76feab40e74170751f1852949f75b33320460eb24d601b8f1fd4f','pending manifest changed')
original={}
for line in (B/'SHA256SUMS').read_text().splitlines():
 digest,path=line.split('  ',1);require(fh(B/path)==digest,'original file changed: '+path);original[path]=digest
original['SHA256SUMS']=fh(B/'SHA256SUMS')
require(len(original)==32 and {p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}==set(original),'original32 set changed')
require(not (B/'P2_BINDING_REVIEW.md').exists() and not (B/'P2_BINDING_REVIEW.json').exists(),'refuse overwrite approval')
audit=json.loads((OUT/'AUDIT.json').read_text());require(audit['passed'] is True and audit['issues']==[],'actual binding audit not passed')
request=json.loads((B/'P2_REVIEW_REQUEST.json').read_text());require(request['design_source_sha']==audit['P2'] and request['design_sha256']==fh(B/'counterfactual-design.json'),'request binding changed')
require(fh(MD)=='d52a9c42f958f9cfe4d2177cac3f86d3996bcd89f1a54de6c8816d446ccaa989','actual review changed')
approval=copy.deepcopy(request);approval.update(status='approved-for-future-F-runtime',actual_independent_P2_binding_review_completed=True,
 reviewer='/root/round2_tool_preparation',review_markdown_sha256=fh(MD))
(B/'P2_BINDING_REVIEW.md').write_bytes(MD.read_bytes());save(B/'P2_BINDING_REVIEW.json',approval)
require(all(fh(B/name)==value for name,value in original.items()),'an original32 file changed during seal')
require({p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}==set(original)|{'P2_BINDING_REVIEW.md','P2_BINDING_REVIEW.json'},'unexpected file added')
save(OUT/'BINDING_SEAL.json',{'schema':'geo261-P2-binding-independent-review-seal/1','P2':audit['P2'],'written_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'authorization':'root explicitly authorized only two added review paths and later pure gate verification','actual_review_audit_sha256':fh(OUT/'AUDIT.json'),
 'original_32_sha256':original,'added':{name:{'path':str(B/name),'sha256':fh(B/name)} for name in ('P2_BINDING_REVIEW.md','P2_BINDING_REVIEW.json')},
 'original_32_unchanged':True,'product_execution':False,'gate_executed_by_this_seal_script':False})
print(json.dumps({'P2':audit['P2'],'reviewer':approval['reviewer'],'added':2,'original_32_unchanged':True,'approval_sha256':fh(B/'P2_BINDING_REVIEW.json'),'markdown_sha256':fh(B/'P2_BINDING_REVIEW.md')},ensure_ascii=False))
