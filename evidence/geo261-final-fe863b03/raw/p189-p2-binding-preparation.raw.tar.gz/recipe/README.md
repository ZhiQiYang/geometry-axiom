# 僅準備：P2 canonical HTML 同步後的安全來源重綁

此目錄只準備腳本、精確 byte 政策、來源 P 原始 blob 與靜態說明，**尚未執行 rebinder、同步器、mock、建置或量測，也沒有檢查或杜撰 P2**。現有 `final-f-p189-counterfactual-tools/` 完全不改。

已釘住的唯一允許差異是 `geometry-guide/公理層-閱讀器.html` 的 I11 article 內，一個完整 trace row 的 `app_contact_facts` 改成 `app_contact_facts_prepare`。原 HTML raw hash `3979f9858fa581df1d9c8f2ba0c21b471ebc0553464b1c1f7f2aa8c87952062a`；精確替換後預期 raw hash `563da7a100e9053f3b23b87b04edec219ad223a0063d2509a380c2286a18482b`。+8 bytes 只是附帶核對，主要判準是完整檔案等於這一次唯一、位於 I11 的 full-anchor byte 替換；任何其他同步差異都拒絕，不自動批准。

## 之後有真正公開 P2 才可執行的命令稿

```sh
python3 -B /workspace/geo261-environment/final-f-p189-p2-rebind-preparation/rebind.py \
  --repo /tmp/<P2-round>/source-p2 \
  --p2-sha <真正已正常push的完整P2 SHA> \
  --scratch /tmp/geo261-counterfactual-rebind-<P2八碼> \
  --original-tools /workspace/geo261-environment/final-f-p189-counterfactual-tools \
  --published-repo /workspace/geometry-axiom
```

repo 須是固定 P2 的乾淨 checkout；P2 必須是原 P 的後代、單親，且相對其 parent 的完整 Git diff 只能有該 HTML 一檔。網路 remote refs 必須證明 P2 已可解析；不以本機物件存在當成已推送。scratch 須全新且在 `/tmp`，不得位於 repo／原工具包內。rebinder 只有 Git／bytes／JSON／AST 處理，不會建置、量測、執行 scanner 或產品；仍應在性能計時外安排此來源準備，避免 I/O 干擾計時。

安全檢查包括：

- 原 READY 包完整檔案集合與 manifest、每檔 raw hash 均維持既有固定值。
- P、P2 parent、P2 的真 Git executable inventory 都恰為原 601 inputs（333 owned／268 excluded），拒新增／刪除／symlink／submodule／大小寫衝突。parent 的 601 raw 全等原 P；P2 只准該 HTML 一個 exact byte 差分。
- P2 與 parent 的 manifest 原 bytes 保持已核 A 的 `0731cea2...`／guard920，不誤用原 P 的 guard918 作新政策基線。
- 333 owned、六撤回實現檔、兩新 public headers、P73 app.js 都逐 raw 綁原 P；只有允許的 HTML 改綁實際 P2 hash。兩 SSOT 檔 raw 全等 P。
- tests 路徑集合非空且全等 P，所有 tracked test blob ID 不變；唯一容許差分是先前已生成的 `tests/mutants_results.json`。expected JSON／任何測試程式新增刪改都拒絕。本次 P2 相對 parent 仍連 ledger 都不能動，只能改 HTML。

輸出只在新 scratch，完整 raw 指令與真退出碼保留，remote URL 原文為防認證複製而僅保存 hash；網路 refs raw 不省略。成功輸出是 `bundle/` 加上外層原始證據，**新包只標 peer pending**。新的 `run.py` 增加 P2-binding gate，必須另有釘住 P2／design／policy／evidence／四來源／六模板 hash 的獨立審查 JSON 與實際新審查原文才准跑 F；原 READY／舊 P 審查不會自動沿用。

新包的未來 F 檢查仍是 **exact333 == 真正 P2**，沒有例外路徑或自動忽略 HTML。原 N64 全組撤回方法、原 scale bytes、三輪、原 2× 判準及 compile／EOF 不能冒充負控紅等規則不變。若準備失敗，新包入口封存為 failed／pending 並明標 NOT_READY，不能使用部分輸出。

成功重綁只是來源準備，不是新的正式 F 驗收或性能自證。每一份收據保留真執行來源角色；不要把 rebinder 的 P2 來源核對改填為尚未出現的 F。
