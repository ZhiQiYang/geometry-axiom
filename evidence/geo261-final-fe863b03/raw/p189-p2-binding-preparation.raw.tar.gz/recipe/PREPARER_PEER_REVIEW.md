# P2 P-189 重綁準備器：獨立純靜態互審

本審查只批准準備器在具備真實已推送 P2 後進行來源核對的程式範圍；**不是對任何 P2 綁定的核准，也不是 F 驗收或性能負控制結果**。審查時尚未查詢／產生 P2，沒有 import 或執行 rebinder、gate、counterfactual 工具、AST、mock、同步器、scanner、編譯、產品或測試，沒有改 root repository。只用文字閱讀及 `sha256sum` 核對 repo 外程式。

最終審查來源：

| 檔案 | SHA256 |
|---|---|
| `rebind.py` | `4f016b3cd1e97fdf3974fee54c04c3d92bd2c2bf54bee61d23915c3c2ce37521` |
| `rebind_gate.py.txt` | `2b71fff98014522b1758da8518d42da7002294a14d618650bcaea6e4ae2c8eb3` |
| `rebind_capture.py` | `c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762` |
| `rebind-policy.json` | `82c5b3b6b108e9fc78826afddaecb48c6fec8e598a6857e86aa00df0320a48dd` |

已閱讀主程式、gate、byte policy、README、NEW_BUNDLE_README 與 PREPARATION。結論為目前未見靜態阻擋；作者仍須依這些最終來源更新 AST／PREPARATION／SHA256SUMS，不能沿用早期 `0576c1c0...`／`41a9841d...` 的 source metadata。

## 真 P2 的適用條件

P2 必須明填完整 SHA，不得用原 P `b6646d10751a0d85a2f03f5d24fbe1073cb78980` 代替。來源必須是真 checkout 根、固定 HEAD 等 P2 且乾淨；P2 必須是 P 的後代、單親，與 parent 的完整 diff 只能有 canonical HTML 一檔。遠端網路 refs 必須證明 P2 為 tip 或可證祖先，不能只用本地物件存在作發布證明。

原 P、P2 parent、P2 會各自讀真 Git tree。原裁判的完整 17 個 suffixes、五 roots／三 standalone 維持 601 inputs，333 owned／268 excluded，路徑集合、Git modes 與大小寫唯一性均固定；不接受新增、刪除、symlink 或 submodule。parent 的 601 raw bytes 全等 P，P2 只有指定 HTML 可改，其餘 600 raw 全等 P；333 owned map 由 P2 blobs 重新計算，不忽略 HTML 或改成寬鬆允許清單。

HTML 的全檔必須等於 P 內唯一、位於 I11 article 的完整 trace row，由 `app_contact_facts` 改為 `app_contact_facts_prepare` 的一次 exact byte 替換。原檔 hash、替換後預期 hash 與 +8 bytes 全核；+8 只是附帶核對，不能接受同長度的其他變更。P2 與 parent 的 manifest 都必須等已獨立核對的 A raw hash `0731cea2b2e783d0e36c20597d6986eb62729912f2f12c9e8b1c63cf77ed35d6`，保留 920 guard，沒有拿原 P 的 918 guard 當新政策基線。

六實現與兩 public headers、P73 app.js 都保持 P；兩份 SSOT 的 raw bytes 及 Git mode 都保持 P。tests tracked path set 必須非空且與 P 相同，內容識別及 mode 差異只允許已存在的 `tests/mutants_results.json` 衍生帳本；expected JSON 或測試來源變化不被默認接受。P2 自己相對 parent 仍只能改 HTML，不能把 ledger 變更夾在 P2 commit。

## 舊包與新包的身分

原 READY 包以既定 `SHA256SUMS` hash `9b335381...`、完整檔案集合及每檔 raw hash 釘住，重綁前後都核對，不覆寫舊包或把它改填 P2。新包才修改 `design_source_sha=P2` 與 333 raw map；原設計 P、f2 演算法來源、六模板 hash 與 P2 source-check 證據分欄保留。

新包從建立起便沒有原未加 gate 的 root `run.py`：先建 NOT_READY，copytree 忽略原 root run，原文以 pending／history 保留，僅加 gate 後的入口才出現。失敗或最終 source guard 失敗會把入口封為 failed 並保留 NOT_READY；成功也只產生 peer-pending request，不會自動產生 P2_BINDING_REVIEW approval。原 run 的變動只有 gate import 與 design 載入後的 gate 呼叫／P2 文字，原 N64／三輪／交錯／計時／2×／full raw／恢復流程沒有放寬。

新 `rebind_gate` 會拒 NOT_READY、缺審查、pending 狀態或錯 P2。實際新審查必須綁 design、policy、rebind evidence、SOURCE_CHECK_COMMANDS journal、準備器 raw snapshots、四份實際工具來源、六模板及該次審查 Markdown hash；舊 READY 或舊 P 的 peer review 不能自動打開 gate。source evidence／policy 的 hash 鏈不含它們自己，不存在自引要求。

## 原始證據與失敗路徑

準備器開頭凍結自身、capture、gate、policy、new README 五份 raw bytes／hash，後續 policy／gate／README 都從 frozen bytes 使用。這些快照連同 source-check journal 放進新包，前後核原始準備檔不變，避免檢查用舊 policy 卻封存新 policy 的不一致。原 READY 也前後整包核對。

Git 真 argv、來源 SHA、cwd、stdin、完整 stdout／stderr、真退出碼、環境與時間由既有完整 Recorder 保存；remote URL 原文僅保留 hash 的安全抑制有明文，遠端 refs 原輸出不省略。SOURCE_CHECK_COMMANDS 是 source-check 當時的不可變快照，後續 final source guard 與成功／失敗要看外層 `receipt.json` 與全部 raw，不能只看包內較早的 REBIND_EVIDENCE。新 README 明確要求連同外層 subcommands／receipt 一起封存；單獨拷貝 bundle 不代表證據完整。

## 本輪找到並已修的三點

1. 起初 copytree 會暫露舊未 gated root run；已改從複製開始忽略入口、先放 NOT_READY。
2. 起初 gate 未拒 NOT_READY，也沒核 source journal；已補失敗 marker、journal 與準備器 snapshot hash 鏈。
3. 起初沒有準備器自身 raw provenance，policy 先讀物件、後讀 hash／copy 可能不同；已凍結五來源、全程使用 frozen bytes 並前後 guard。

作者另補了 601 Git modes、tests mode／blob 與 SSOT mode 保護，靜態核對未見放寬原來源政策。

## 後續必須另做

真正 P2 出現並正常 push 後，才可執行此準備器；本審查不能替代那次真 Git／網路／raw 證據。新包產生後，還要另一輪實際 P2-binding 獨立審查，確認 outer receipt 真退出0、原始資料齊全、精確來源差異成立、包內實際四來源／六模板與新 design 均吻合，才能如實產生 P2_BINDING_REVIEW。這份 preparer review 不能直接改名當該 approval。

未來 F 仍必須是新的公開乾淨 SHA，333 owned raw **完全等 P2**，並先具備同 F 的完整正式四點 P-189 收據；額外全組 N64 撤回仍須實際證明 >2／恢復 ≤2。本輪沒有這些 runtime 結果，也沒有核准任何新的數值門檻或聲稱各性能元件單獨撤回均會轉紅。
