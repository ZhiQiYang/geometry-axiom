"""Independent read-only product/companion review; no C or subject imports."""
from pathlib import Path
import ast, difflib, hashlib, json

ROOT=Path('/workspace/geo323-provider-hint-fix-draft-20261024')
OUT=Path('/workspace/geo323-provider-hint-static-peer-combined-20261024')
checks=[]
def h(b): return hashlib.sha256(b).hexdigest()
def need(ok,label): checks.append({'label':label,'ok':bool(ok)})
def definitions(tree):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree)
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
manifest_bytes=(ROOT/'MANIFEST.json').read_bytes()
m=json.loads(manifest_bytes)
need(m['base_sha']=='2bbe54f19b2d19e8a816530f0c4edca950629a34','fixed F2bbe source')
leaves=['geometry-core/kernel/source.c','tests/test_geo261_source_index.py',
        'tests/run_all.expected.json','tests/geo323_provider_hint_harness.c']
need(m['changed']==leaves,'exact four leaves')
patch=[]
for rel in leaves:
    candidate=(ROOT/'candidate'/rel).read_bytes()
    old=ROOT/'before'/rel
    before=old.read_bytes() if old.exists() else b''
    need(len(candidate)==m['files'][rel]['bytes'],'candidate size '+rel)
    need(h(candidate)==m['files'][rel]['sha256'],'candidate pin '+rel)
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),candidate.decode().splitlines(True),
                 fromfile='a/'+rel if old.exists() else '/dev/null',tofile='b/'+rel))
need(''.join(patch).encode()==(ROOT/'FOUR_LEAF.patch').read_bytes(),'full patch exactly rebuilt')
test_before=(ROOT/'before/tests/test_geo261_source_index.py').read_text()
test_after=(ROOT/'candidate/tests/test_geo261_source_index.py').read_text()
oldtree=ast.parse(test_before); newtree=ast.parse(test_after)
olddefs=definitions(oldtree); newdefs=definitions(newtree)
for name,dump in olddefs.items(): need(newdefs.get(name)==dump,'old definition unchanged '+name)
oldmethods=[x for x in olddefs if x.startswith('test_')]
newmethods=[x for x in newdefs if x.startswith('test_')]
need(len(oldmethods)==17 and len(newmethods)==18,'17 original methods plus one')
oldglobals={n.targets[0].id:ast.dump(n,include_attributes=False) for n in oldtree.body
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
newglobals={n.targets[0].id:ast.dump(n,include_attributes=False) for n in newtree.body
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
for name,dump in oldglobals.items(): need(newglobals.get(name)==dump,'old global unchanged '+name)
edit=next(ast.literal_eval(n.value) for n in newtree.body if isinstance(n,ast.Assign)
          and any(isinstance(t,ast.Name) and t.id=='PROVIDER_HINT_EDIT' for t in n.targets))
original=(ROOT/'before/geometry-core/kernel/source.c').read_text()
candidate=(ROOT/'candidate/geometry-core/kernel/source.c').read_text()
need(original.count(edit[0])==1 and candidate.count(edit[1])==1,'whole replacement unique')
need(original.replace(*edit)==candidate,'sole product change is provider bucket')
need(candidate.replace(edit[1],edit[0])==original,'whole withdrawal exact original')
need('uint32_t provider_hint=(uint32_t)(source.provider*UINT32_C(2654435761));' in candidate,'full uint32 multiply fixed constant')
need('size_t slot=(size_t)(provider_hint>>24)^source.key_size;' in candidate,'high eight bits plus unchanged key-size mix')
need('if(source.key_size){const unsigned char *key=source.key;slot^=(size_t)key[0]^key[source.key_size-1];}' in candidate,'same guarded key fragment reads')
need('a.provider==b.provider&&a.key_size==b.key_size&&\n        (!a.key_size||!memcmp(a.key,b.key,a.key_size))' in candidate,'full byte identity retained')
need('size_t node_hint[256];' in candidate,'original fixed direct cache size')
oldexpected=json.loads((ROOT/'before/tests/run_all.expected.json').read_bytes())
newexpected=json.loads((ROOT/'candidate/tests/run_all.expected.json').read_bytes())
def compare(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b: yield path+'/'+k,a.get(k),b.get(k)
            else: yield from compare(a[k],b[k],path+'/'+k)
    elif a!=b: yield path,a,b
changes=list(compare(oldexpected,newexpected))
need(len(changes)==1 and changes[0][0].endswith('/py:test_geo261_source_index/count') and changes[0][1:]==(17,18),'only exact expected 17 to18')
harness=(ROOT/'candidate/tests/geo323_provider_hint_harness.c').read_text()
for text in ['union { uint64_t aligned; unsigned char bytes[8]; }',
             '(uintptr_t)(a+1)%sizeof(uint64_t)!=0', '(uintptr_t)(b+1)%sizeof(uint64_t)!=0',
             '{UINT32_C(0x80000002),a+1,4}', '{UINT32_MAX,a+1,4}', '{0,a+1,4}',
             '{2,b+1,4}', '{2,NULL,0}', '{2,b+1,0}',
             'fail_indexes=1;', 'index_failures>0&&ctx->node_index_capacity==0',
             'GEO_SOURCE_INVALID&&!memcmp(&old,&value,sizeof value)',
             'geo_eval_reset(ctx)&&geo_eval_node_count(ctx)==0&&geo_eval_provider_count(ctx)==0',
             'ctx->node_hint[i]==0','!graph_equal(ctx)','live_allocations==0']:
    need(text in harness,'semantic witness '+text)
for text in ['(("fixed", source, 0, 0), ("withdrawn", withdrawn, 1, 16), ("restored", source, 0, 0))',
             'self.assertEqual("PASS provider-hint-semantics\\n", semantic.stdout)',
             'self.assertEqual(1, result.returncode, result.stdout + result.stderr)',
             'provider-hint-full-width-provider','provider-hint-middle-byte-identity']:
    need(text in test_after,'phase/assertion '+text)

# Independent model: original key ownership, insertion order and complete equality;
# the hint chooses a candidate, and a miss always uses full linear identity.
def slot(ref,mixed):
    p,key=ref; bucket=((p*2654435761)&0xffffffff)>>24 if mixed else p
    return (bucket^len(key)^(key[0]^key[-1] if key else 0))&255
def run(refs,mixed):
    nodes=[]; cache=[None]*256; history=[]; misses=0
    for ref in refs:
        s=slot(ref,mixed); i=cache[s]
        if i is None or nodes[i]!=ref:
            misses+=1
            try:i=nodes.index(ref)
            except ValueError:i=len(nodes);nodes.append(ref)
            cache[s]=i
        history.append((i,tuple(nodes)))
    return history,misses
providers=[0,1,2,19,255,256,0x80000002,0xffffffff]
keys=[b'',b'\0',b'\0\1\0\0',b'\0\2\0\0',b'\0\1\0',b'\xff\0\xff',bytes(range(17))]
refs=[(p,k)for p in providers for k in keys]
sequence=refs+list(reversed(refs))+refs[::3]+refs[1::2]
before_hist,_=run(sequence,False); after_hist,_=run(sequence,True)
for i,(a,b) in enumerate(zip(before_hist,after_hist)):need(a==b,'independent full-identity sequence '+str(i))
pair=[(2,bytes([0,1,0,0])),(19,bytes([16,2,0,0,0]))]
need(slot(pair[0],False)==slot(pair[1],False),'original work pair collides')
need(slot(pair[0],True)!=slot(pair[1],True),'new work pair separates')
need(run(pair+pair*8,False)[1]-run(pair,False)[1]==16,'withdrawn exact16 postwarmup finds model')
need(run(pair+pair*8,True)[1]-run(pair,True)[1]==0,'fixed exact0 postwarmup finds model')
OUT.mkdir(exist_ok=False)
failed=[x for x in checks if not x['ok']]
report={'checks':len(checks),'failed_checks':len(failed),'failures':failed,
        'base_sha':m['base_sha'],'manifest_sha256':h(manifest_bytes),
        'patch_sha256':h((ROOT/'FOUR_LEAF.patch').read_bytes()),
        'files':m['files'],'independent_python_events':len(sequence),
        'scope':'Read-only exact product reversal, old AST/assertion preservation, registry delta, companion safety and independent full-identity/cache formula. No subject import, C, source mutation, network or performance run.',
        'limits':['Formal 18 methods, normal 0/1/0 controls and O2 wall results require actual receipts; this static peer does not certify them.','Independent work counts are formula expectations, not C measurements.']}
(OUT/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));raise SystemExit(bool(failed))
