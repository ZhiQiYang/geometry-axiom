from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/workspace/geo323-shadow-hint-F-diagnostic-draft-20261024');OUT=Path('/workspace/geo323-shadow-provider-static-peer-combined-r2-20261024');OUT.mkdir(exist_ok=False)
checks=[]
def check(label,value):checks.append({'label':label,'passed':bool(value)})
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((ROOT/'MANIFEST.json').read_bytes())
for n,item in m['files'].items():check('frozen-file-'+n,len((ROOT/n).read_bytes())==item['bytes']and sha((ROOT/n).read_bytes())==item['sha256'])
before=(ROOT/'before.c').read_text();candidate=(ROOT/'candidate.c').read_text();edits=json.loads((ROOT/'EXACT_EDITS.json').read_bytes())
if isinstance(edits,dict):edits=edits.get('edits',edits.get('changes',[]))
check('fourteen-hooks',len(edits)==14)
s=before
for i,e in enumerate(edits):
 a=e.get('before',e.get('old'));b=e.get('after',e.get('new'));check('forward-unique-'+str(i),s.count(a)==1);s=s.replace(a,b)
check('forward-exact-candidate',s==candidate)
for i,e in enumerate(reversed(edits)):
 a=e.get('before',e.get('old'));b=e.get('after',e.get('new'));check('reverse-unique-'+str(i),s.count(b)==1);s=s.replace(b,a)
check('whole-reverse-original',s==before)
patch=''.join(difflib.unified_diff(before.splitlines(True),candidate.splitlines(True),fromfile='a/geometry-core/kernel/source.c',tofile='b/geometry-core/kernel/source.c'))
check('exact-one-leaf-patch',patch==(ROOT/'SHADOW_ONLY.patch').read_text())
shadow=(ROOT/'shadow.inc').read_text()
check('failed-before-fill-and-lru',shadow.index('if(!success){sh_add(&count->failure,1);continue;}')<shadow.index('s->ordinal[model][slot+way]=ordinal+1;')<shadow.index('if(ways==2)s->victim[model][slot/2]'))
check('full-key-equality', 'a.provider!=b.provider||a.key_size!=b.key_size' in shadow and '!a.key_size||!memcmp(a.key,b.key,a.key_size)'in shadow)
check('read-before-original-clear',candidate.index('sh_clear(ctx);')<candidate.index('for(size_t i=0;i<ctx->provider_count;++i){free'))
check('no-heap-observer',all(x not in shadow for x in ['malloc(','calloc(','realloc(','free(']))
check('context-generation-check','s->ctx!=ctx||s->generation!=e->generation'in shadow)
mask=(1<<64)-1
def slots(key):
 provider,raw=key;n=len(raw);old=(provider^n^(raw[0]^raw[-1]if n else 0))&255
 check('admitted-provider32',0<=provider<2**32)
 bucket=((provider*2654435761)&0xffffffff)>>24
 mixed=old^(provider&255)^bucket
 check('mixed-bound-no-key-reads',0<=mixed<256)
 return [old,(old&127)*2,mixed,(mixed&127)*2]
for provider,expected in [(0,0),(1,158),(2,60),(0xffffffff,97)]:
 check('independent-Knuth-example-'+str(provider),slots((provider,b''))[2]==expected)
selftest=(ROOT/'observer_selftest_entry.c').read_text()
for marker in ['direct-known-sequence','two-way-LRU-known-sequence','failure-no-cache-or-recency-write','clear-new-generation','same-address-recreated','empty-key-null-safe','new-ordinal-outcome-separate','actual-hint-mismatch-detected','out-of-range-shadow-ordinal-detected','stale-generation-detected']:
 check('real-selftest-marker-'+marker,marker in selftest)
check('outcome-existing-new-guard','e.initial_node_count=ctx->node_count' in shadow and 'if(fresh&&(ordinal!=e->initial_node_count||ctx->node_count!=e->initial_node_count+1))'in shadow and 'if(!fresh&&ctx->node_count!=e->initial_node_count)'in shadow)
check('no-extra-key-sampling','positions['not in shadow and 'key_sample_reads'not in shadow and 'uint32_t mixed=(uint32_t)(source.provider*UINT32_C(2654435761));'in shadow)

keys=[(1,b''),(257,b''),(129,b''),(1,b'a'),(257,b'a'),(1,b'abcdef'),(1,b'abcxef'),(1,b'abcdefgh'),(1,b'abcdefghij'),(0xffffffff,b'abcdefgh'),(1,bytes(range(32))),(1,bytes(range(31))+b'X')]
allslots={k:slots(k)for k in keys}
event_total=0
for rotate in range(len(keys)):
 nodes={};hint=[None]*256;models=[[None]*256 for _ in range(4)];victim=[[0]*128 for _ in range(4)];refs=[{}for _ in range(4)]
 sequence=keys[rotate:]+keys[:rotate]+list(reversed(keys))+keys[::2]+keys[1::2]
 for step,key in enumerate(sequence):
  if step in [len(keys)+3,2*len(keys)+4]:
   nodes={};hint=[None]*256;models=[[None]*256 for _ in range(4)];victim=[[0]*128 for _ in range(4)];refs=[{}for _ in range(4)]
  success=not(step%7==0 and key not in nodes)
  if success and key not in nodes:nodes[key]=len(nodes)+1
  ordinal=nodes.get(key)
  for model in range(4):
   ways=2 if model in [1,3]else 1;slot=allslots[key][model];setid=slot//ways
   check('slot-in-range',0<=slot and slot+ways<=256)
   entries=models[model][slot:slot+ways];hit=next((i for i,v in enumerate(entries)if v==key),None)
   before_model=(models[model][:],victim[model][:])
   if success:
    way=hit if hit is not None else (0 if ways==1 or entries[0]is None else 1 if entries[1]is None else victim[model][setid])
    models[model][slot+way]=key
    if ways==2:victim[model][setid]=1-way
   else:check('failed-state-unchanged',before_model==(models[model],victim[model]))
   # Independent ordered-list LRU reference; no victim bit or ordinal arithmetic.
   q=refs[model].setdefault(setid,[])
   if success:
    if key in q:q.remove(key)
    q.append(key)
    if len(q)>ways:q.pop(0)
   check('independent-lru-retained-identities',set(x for x in models[model][slot:slot+ways]if x is not None)==set(q))
  if success:hint[allslots[key][0]]=key
  check('original-direct-mirror',models[0]==hint);event_total+=1
failed=[x['label']for x in checks if not x['passed']]
result={'subject_manifest_sha256':sha((ROOT/'MANIFEST.json').read_bytes()),'shadow_sha256':sha((ROOT/'shadow.inc').read_bytes()),'passed':len(checks)-len(failed),'failed':len(failed),'failures':failed,'independent_python_events':event_total,'scope':'Static original-hook reversal/boundary review and independent pure-Python cache/LRU model; no C, product mutation, benchmark or acceptance rerun.','limits':['Actual context/family/counter overflow and mirror errors must invalidate observation; this is no product capacity change.','Profile self time and shadow work counts cannot prove O2wall improvement.','Independent model does not replace real C allocator/clear/missing tests.']}
(OUT/'REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(result));raise SystemExit(bool(failed))
