"""Record the original 18-method suite at one public source SHA; no timing gate."""
from pathlib import Path
import argparse
import ast
import resource
import datetime
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/tmp/geo323-provider-hint-private-work-20261024')
OUT = Path('/tmp/geo323-provider-hint-formal-20261024')
OBSERVER = HERE / 'retain_source_index_streams.py'
OBSERVER_SHA = '4e73d3093f826b726ec080b03bf5f8721463e7c4843f77a7ebd8b182baddb7ad'
LOCK = Path('/tmp/g261r3/secondary.lock')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def need(condition, message):
    if not condition:
        raise RuntimeError(message)

def stream(row, name):
    meta = row[name]
    need(meta.get('captured'), 'missing original child stream')
    path = Path(meta['path']).resolve()
    need(path.is_relative_to(OUT), 'child stream outside private OUT')
    raw = path.read_bytes()
    need(len(raw) == meta['bytes'] and sha(raw) == meta['sha256'], 'child stream pin differs')
    return raw

def verify_binary(meta):
    path = Path(meta['retained']).resolve()
    need(path.is_relative_to(OUT), 'binary snapshot outside private OUT')
    raw = path.read_bytes()
    need(len(raw) == meta['bytes'] and sha(raw) == meta['sha256'], 'executed binary snapshot differs')

def control_proofs(observed):
    native = []
    for row in observed['commands']:
        argv = row.get('args', [None])[0]
        if not isinstance(argv, list) or len(argv) != 2:
            continue
        name = Path(argv[0]).name.removesuffix('.exe')
        if not (name.startswith('source-index-') or name.startswith('edge-probe-cost-') or name.startswith('provider-hint-')):
            continue
        verify_binary(row['actual_executable'])
        native.append({'number': row['number'], 'name': name, 'case': argv[1],
                       'exit': row['returncode'], 'stdout': stream(row, 'stdout'),
                       'stderr': stream(row, 'stderr'), 'binary': row['actual_executable']})
    need(all(native[i]['number'] < native[i+1]['number'] for i in range(len(native)-1)), 'native commands must retain strictly increasing original observation numbers')
    controls = [
        ('never-node', 'nodes', 'duplicate-node'),
        ('never-edge', 'edges', 'duplicate-edge'),
        ('node-key-bytes-ignored', 'nodes', 'merged-node'),
        ('node-probe-miss', 'nodes', 'duplicate-node'),
        ('node-probe-hit', 'nodes', 'merged-node'),
        ('edge-kind-ignored', 'edge-collisions', 'missing-edge'),
        ('edge-probe-miss', 'edge-collisions', 'duplicate-edge'),
        ('edge-probe-hit', 'edge-collisions', 'missing-edge'),
        ('edge-reuse-old-slot-after-resize', 'edge-probe', 'duplicate-edge'),
        ('edge-reuse-wrong-empty-slot', 'edge-probe', 'duplicate-edge'),
    ]
    proofs = []
    for name, case, marker in controls:
        mutants = [r for r in native if r['name'] == 'source-index-' + name and r['case'] == case]
        need(len(mutants) == 1, 'one actual mutant command required: ' + name)
        mutant = mutants[0]
        position = native.index(mutant)
        need(0 < position < len(native)-1, 'actual adjacent before/after executions required: ' + name)
        baseline, restored = native[position-1], native[position+1]
        need(all(r['name'] == 'source-index-client' and r['case'] == case for r in (baseline, restored)), 'each control must retain its own adjacent baseline/restoration: ' + name)
        need([baseline['exit'], mutant['exit'], restored['exit']] == [0, 1, 0], 'normal 0/1/0 required: ' + name)
        need(mutant['stdout'] == b'' and re.fullmatch(rb'ASSERT:' + marker.encode() + rb' line=\d+ expr=[^\n]+\n', mutant['stderr']), 'exact named normal assertion required: ' + name)
        for item in (baseline, restored):
            need(item['stdout'] == ('PASS ' + case + '\n').encode() and item['stderr'] == b'', 'baseline/restored raw stream differs: ' + name)
        proofs.append({'control': name, 'case': case, 'assertion': marker,
                       'actual_command_numbers': [baseline['number'], mutant['number'], restored['number']],
                       'actual_exits': [baseline['exit'], mutant['exit'], restored['exit']],
                       'restoration_scope': 'original baseline binary executed again after mutant; no recompiled restoration claimed',
                       'mutant_binary': mutant['binary'], 'passed': True})
    whole = []
    for phase, expected, count in [('fixed', 0, 21), ('withdrawn', 1, 31), ('restored', 0, 21)]:
        costs = [r for r in native if r['name'] == 'edge-probe-cost-' + phase and r['case'] == 'edge-probe-cost']
        semantics = [r for r in native if r['name'] == 'edge-probe-cost-' + phase and r['case'] == 'edge-probe']
        need(len(costs) == len(semantics) == 1, 'one actual semantic/cost pair required: ' + phase)
        cost, semantic = costs[0], semantics[0]
        need(semantic['number'] < cost['number'] and semantic['exit'] == 0 and semantic['stdout'] == b'PASS edge-probe\n' and semantic['stderr'] == b'', 'whole variant must first preserve ordered graph')
        need(cost['exit'] == expected, 'whole variant exit differs')
        need(cost['stdout'] == (f'PROBE_HASH_CALLS={count}\n' + ('PASS edge-probe-cost\n' if expected == 0 else '')).encode(), 'exact operation count stream differs')
        if expected:
            need(re.fullmatch(rb'ASSERT:edge-probe-reuses-lookup-hash line=\d+ expr=[^\n]+\n', cost['stderr']), 'whole withdrawal must fail normally at precise count assertion')
        else:
            need(cost['stderr'] == b'', 'unexpected whole green stderr')
        whole.append({'phase': phase, 'actual_exit': cost['exit'], 'semantic_exit': semantic['exit'],
                      'semantic_command': semantic['number'], 'cost_command': cost['number'],
                      'hash_calls_from_exact_stdout': count, 'binary': cost['binary']})
    need([x['cost_command'] for x in whole] == sorted(x['cost_command'] for x in whole), 'whole phase execution order changed')
    proofs.append({'control': 'whole-edge-probe-withdrawal', 'phases': whole,
                   'restoration_scope': 'three separately compiled instrumented sources', 'passed': True})
    return proofs, len(native), native


def provider_proofs(native):
    whole=[]
    for phase,expected,calls in [('fixed',0,0),('withdrawn',1,16),('restored',0,0)]:
        rows=[r for r in native if r['name']=='provider-hint-'+phase]
        need(len(rows)==2,'one actual provider semantic/work pair per phase')
        semantic,work=rows
        need(semantic['case']=='provider-hint-semantics'and semantic['exit']==0 and semantic['stdout']==b'PASS provider-hint-semantics\n'and semantic['stderr']==b'','whole variant preserves full identity/guard/order before work')
        need(work['case']=='provider-hint-work'and work['exit']==expected,'actual provider whole exit')
        need(work['stdout']==(f'PROVIDER_HINT_FIND_CALLS={calls}\n'+('PASS provider-hint-work\n'if expected==0 else'')).encode(),'actual deterministic find-call count')
        if expected:need(re.fullmatch(rb'ASSERT:provider-hint-cross-family-cache line=\d+ expr=[^\n]+\n',work['stderr']),'whole withdrawal precise normal assertion')
        else:need(work['stderr']==b'','green provider phase stderr empty')
        whole.append({'phase':phase,'semantic_exit':semantic['exit'],'work_exit':work['exit'],'find_calls':calls,'commands':[semantic['number'],work['number']],'binary':work['binary']})
    need([x['commands'][1]for x in whole]==sorted(x['commands'][1]for x in whole),'actual whole fixed/withdraw/restored order')
    controls=[]
    for name,marker in [('full-provider','provider-hint-full-width-provider'),('middle-key','provider-hint-middle-byte-identity')]:
        rows=[r for r in native if r['name']=='provider-hint-control-'+name]
        need(len(rows)==1,'one actual identity control')
        r=rows[0];need(r['case']=='provider-hint-semantics'and r['exit']==1 and r['stdout']==b'','identity control must fail normally1')
        need(re.fullmatch(rb'ASSERT:'+marker.encode()+rb' line=\d+ expr=[^\n]+\n',r['stderr']),'identity control exact first assertion')
        controls.append({'name':name,'assertion':marker,'actual_exit':1,'command':r['number'],'scope':'normal semantic negative control; no separate per-control restoration claimed'})
    return {'whole':whole,'identity_controls':controls,'elapsed_time_inference':False}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sha', required=True)
    args = parser.parse_args()
    need(re.fullmatch('[0-9a-f]{40}', args.sha), 'full SHA required')
    publication = json.loads(Path('/tmp/geo323-provider-hint-alignment-publication-r2-20261024/RESULT.json').read_text())
    need(publication['source_pushed'] is True and publication['source_sha'] == args.sha and publication['exit'] == 0, 'require actual fixed public source publication')
    need(sha(OBSERVER.read_bytes()) == OBSERVER_SHA, 'observer changed after review')
    need(not OUT.exists(), 'fresh formal output required')
    OUT.mkdir()
    report = {'source_sha': args.sha, 'root': str(ROOT), 'out': str(OUT),
              'original_entry': 'tests/test_geo261_source_index.py -v',
              'wall_clock_performance_run': False, 'ledger_regenerated': False,
              'architecture_regenerated': False, 'commands': [], 'exit': None}
    lock = None
    env = os.environ.copy()
    for name in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
                 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_NAMESPACE'):
        env.pop(name, None)
    env['TMPDIR'] = str(OUT / 'tmp')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONUNBUFFERED'] = '1'
    Path(env['TMPDIR']).mkdir()
    def run(command):
        folder = OUT / 'commands' / f'{len(report["commands"]) + 1:03d}'
        folder.mkdir(parents=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        row = {'command': command, 'cwd': str(ROOT), 'source_sha': args.sha,
               'started_utc': started, 'actual_process_exit': result.returncode,
               'stdout': str(folder / 'stdout'), 'stderr': str(folder / 'stderr')}
        for key in ('stdout', 'stderr'):
            raw = Path(row[key]).read_bytes()
            row[key + '_bytes'] = len(raw)
            row[key + '_sha256'] = sha(raw)
        (folder / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
        report['commands'].append(row)
        return row
    try:
        fs = os.statvfs(OUT.parent)
        report['free_bytes_before'] = fs.f_bavail * fs.f_frsize
        need(report['free_bytes_before'] >= 80 * 1024 * 1024, 'unchanged80MiB resource minimum on actual TMP output filesystem')
        lock = LOCK.open('a+')
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        report['exclusive_heavy_slot'] = str(LOCK)
        soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
        resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,hard));report['stack_bytes']=16*1024*1024
        for command in (['uname', '-a'], [sys.executable, '--version'], ['cc', '--version'], ['df', '-B1', '/workspace', '/tmp']):
            need(run(command)['actual_process_exit'] == 0, 'environment command failed')
        command = [sys.executable, '-B', str(OBSERVER), '--root', str(ROOT), '--sha', args.sha,
                   '--out', str(OUT / 'observed'), '--artifacts', str(OUT / 'native-retention'), '--', '-v']
        original = run(command)
        report['original_suite_process_exit'] = original['actual_process_exit']
        need(original['actual_process_exit'] == 0, 'original suite failed; retain exact raw output')
        stderr = Path(original['stderr']).read_bytes()
        need(re.search(rb'Ran 18 tests in [^\n]+\n\nOK\s*$', stderr), 'original suite must report exactly18/no skip')
        observed = json.loads((OUT / 'observed/receipt.json').read_text())
        need(observed['original_exit'] == 0 and observed['observer_complete'] and not observed['observation_errors'], 'complete unchanged observation required')
        for row in observed['commands']:
            stream(row, 'stdout')
            stream(row, 'stderr')
        report['control_proofs'], report['actual_native_commands'], native = control_proofs(observed)
        report['provider_hint_proofs']=provider_proofs(native)
        retention = json.loads((OUT / 'native-retention/retention.json').read_text())
        need(len(retention) == 1, 'one actual NativeBuild cleanup audit required')
        build_log = Path(retention[0]['retained']).read_bytes()
        need(sha(build_log) == retention[0]['sha256'], 'build log pin differs')
        builds = json.loads(build_log)
        need(builds and all(row['exit'] == 0 for row in builds), 'all original compiles and links must succeed')
        report['actual_compile_link_commands'] = len(builds)
        snapshots = json.loads((OUT / 'native-retention/all-c-header-inputs/source-snapshots.json').read_text())
        need(len(snapshots) == 1, 'one build source snapshot required')
        sources = {}
        for row in snapshots[0]['files']:
            raw = Path(row['retained']).read_bytes()
            need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'C/header snapshot differs')
            sources[Path(row['original']).relative_to(snapshots[0]['original_build_directory']).as_posix()] = raw
        current = ROOT / 'geometry-core/kernel/source.c'
        module=ast.parse((ROOT/'tests/test_geo261_source_index.py').read_bytes())
        constants={target.id:ast.literal_eval(node.value) for node in module.body if isinstance(node,ast.Assign) for target in node.targets if isinstance(target,ast.Name) and target.id in ['EDGE_PROBE_REUSE_EDITS','PROVIDER_HINT_EDIT']}
        edge_withdrawn=current.read_text()
        for old,new in reversed(constants['EDGE_PROBE_REUSE_EDITS']):
            need(edge_withdrawn.count(new)==1,'original edge withdrawal unique anchor')
            edge_withdrawn=edge_withdrawn.replace(new,old)
        provider_before,provider_after=constants['PROVIDER_HINT_EDIT']
        need(current.read_text().count(provider_after)==1,'provider whole withdrawal exact anchor')
        provider_withdrawn=current.read_text().replace(provider_after,provider_before).encode()
        instrumentation = b'{++edge_probe_hash_calls;'
        plain = b'{'
        report['whole_source_variants'] = []
        for phase in ('fixed', 'withdrawn', 'restored'):
            name = f'edge-probe-source-{phase}/source.c'
            raw = sources[name]
            need(raw.count(instrumentation) == 1, 'one precise instrumentation entry required')
            clean_source = raw.replace(instrumentation, plain)
            expected = edge_withdrawn.encode() if phase == 'withdrawn' else current.read_bytes()
            need(clean_source == expected, 'whole compiled variant must exactly match source pins')
            report['whole_source_variants'].append({'phase': phase, 'actual_instrumented_sha256': sha(raw),
                                                   'uninstrumented_sha256': sha(clean_source), 'bytes': len(raw)})
        report['provider_source_variants']=[]
        for phase in ('fixed','withdrawn','restored'):
            parent='provider-hint-source-'+phase+'/'
            actual=sources[parent+'source.c']
            need(actual.count(b'{++provider_hint_find_calls;')==1,'one provider work counter hook')
            clean=actual.replace(b'{++provider_hint_find_calls;',b'{')
            need(clean==(provider_withdrawn if phase=='withdrawn'else current.read_bytes()),'actual nested provider whole source binding')
            need(sources[parent+'geo261_source_index_harness.c']==(ROOT/'tests/geo261_source_index_harness.c').read_bytes(),'actual included original public oracle retained')
            need(sources[parent+'client.c']==(ROOT/'tests/geo323_provider_hint_harness.c').read_bytes(),'actual outer provider client retained')
            report['provider_source_variants'].append({'phase':phase,'compiled_nested_source_sha256':sha(actual),'clean_source_sha256':sha(clean)})
        for name,anchor,replacement in [('full-provider','a.provider==b.provider','(uint8_t)a.provider==(uint8_t)b.provider'),('middle-key','||!memcmp(a.key,b.key,a.key_size)','||1')]:
            parent='provider-hint-control-source-'+name+'/'
            need(current.read_text().count(anchor)==1,'one identity control anchor')
            need(sources[parent+'source.c']==current.read_text().replace(anchor,replacement).encode(),'actual local control source exact')
            need(sources[parent+'client.c']==(ROOT/'tests/geo323_provider_hint_harness.c').read_bytes()and sources[parent+'geo261_source_index_harness.c']==(ROOT/'tests/geo261_source_index_harness.c').read_bytes(),'actual two-level control client/header binding')
        report['original_methods'] = 18
        report['skips'] = 0
        report['exit'] = 0
    except BaseException as exc:
        report['exit'] = 1
        report['error'] = repr(exc)
    finally:
        if lock is not None:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            lock.close()
        (OUT / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k: report.get(k) for k in ('source_sha', 'original_suite_process_exit', 'actual_native_commands', 'actual_compile_link_commands', 'exit', 'error')}), flush=True)
    return report['exit']

if __name__ == '__main__':
    sys.exit(main())
