from pathlib import Path
import hashlib,json,os,subprocess,stat
P=Path('/tmp/geo323-provider-hint-alignment-publication-r2-20261024');O=Path(__file__).resolve().parent;r=json.loads((P/'RESULT.json').read_bytes());H=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(n,v):checks.append({'check':n,'passed':bool(v)})
for i,row in enumerate(r['commands'],1):
 d=Path(row['directory']);ck(str(i)+' row',json.loads((d/'result.json').read_bytes())==row);ck(str(i)+' exit0',row['exit']==0)
 for s in ['stdout','stderr']:ck(str(i)+' '+s,H((d/s).read_bytes())==row[s+'_sha256'])
 if row.get('stdin_sha256')is not None:ck(str(i)+' stdin',H((d/'stdin').read_bytes())==row['stdin_sha256'])
S=r['source_sha'];F=r['parent'];W=Path(r['worktree']);ck('exactS144parentS81',S=='1449d430d1c4734bb1bc3a9f91f3851c845cc0f3'and F=='81b6c388f8b73e9aaf885b1d948e5f306b77bafd');ck('original sourcepublic noC',r['exit']==0 and r['source_pushed']and not r['C_executed']);ck('originalnormalparent',(P/'commands/021/stdout').read_text().strip()==F);ck('originaloneleaf',(P/'commands/022/stdout').read_bytes()==b'tests/geo323_provider_hint_harness.c\0');ck('originalremoteexact',(P/'commands/025/stdout').read_text().split()==[S,'refs/heads/'+r['branch']]);ck('oldcommonhead unchanged',(P/'commands/026/stdout').read_text().strip()==F and (P/'commands/027/stdout').read_bytes()==b'')
reads=[];env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')}
def g(*args):
 argv=['git','--no-optional-locks','-C',str(W),*args];p=subprocess.run(argv,env=env,capture_output=True);reads.append({'argv':argv,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});ck('readonlyGit '+str(args),p.returncode==0);return p.stdout
ck('actualoneparent',g('show','-s','--format=%P',S).decode().strip()==F);ck('actualoneleaf',g('diff','--name-only',F,S)==b'tests/geo323_provider_hint_harness.c\n');raw=g('show',S+':tests/geo323_provider_hint_harness.c');ck('exact f510 and stagedsame',H(raw)=='f510591a12d094d2e7f09342f8d07dfd6d0c10dfafe611794c5cddacb9ed71b6'and raw==(P/'commands/018/stdout').read_bytes());ck('privateGitordinarydir',(W/'.git').is_dir());ck('readonlyalternatepath',(W/'.git/objects/info/alternates').read_text().strip()=='/workspace/geometry-axiom/.git/objects')
sm=json.loads((P/'SOURCE_MANIFEST.json').read_bytes());ck('manifestexact71',sm['source_sha']==S and len(sm['entries'])==71)
for x in sm['entries']:
 p=W/x['path'];s=p.lstat();b=p.read_bytes();ck('private source '+x['path'],stat.S_ISREG(s.st_mode)and s.st_nlink==1 and len(b)==x['bytes']and H(b)==x['sha256'])
(O/'ALIGNMENT_PUBLICATION_READS.json').write_text(json.dumps(reads,ensure_ascii=False,indent=2)+'\n');out={'scope':'Original27 Git full streams, parent/delta/remote and private71 source manifest; no new network, C or performance run.','source_sha':S,'subject_sha256':H((P/'RESULT.json').read_bytes()),'checks':checks,'passed':sum(x['passed']for x in checks),'failed':sum(not x['passed']for x in checks),'findings':[]};(O/'ALIGNMENT_PUBLICATION_ACTUAL_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['passed'],out['failed'],H((O/'ALIGNMENT_PUBLICATION_ACTUAL_REVIEW.json').read_bytes()));assert out['failed']==0
