from pathlib import Path
import hashlib,json,ast,difflib,subprocess,os
P=Path('/workspace/geo323-provider-hint-fix-draft-20261024');O=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((P/'MANIFEST.json').read_bytes());checks=[];reads=[]
def ck(n,v):checks.append({'check':n,'passed':bool(v)})
env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')}
def g(*args):
 argv=['git','--no-optional-locks','-C','/workspace/geometry-axiom',*args];p=subprocess.run(argv,env=env,capture_output=True);reads.append({'argv':argv,'exit':p.returncode,'stdout_sha256':H(p.stdout),'stderr':p.stderr.decode()});ck('original Git '+str(args),p.returncode==0);return p.stdout
base=m['base_sha'];ck('baseF2bbe',base=='2bbe54f19b2d19e8a816530f0c4edca950629a34');ck('exact4leaves',m['changed']==['geometry-core/kernel/source.c','tests/test_geo261_source_index.py','tests/run_all.expected.json','tests/geo323_provider_hint_harness.c'])
for n,v in m['files'].items():
 raw=(P/'candidate'/n).read_bytes();ck('candidate pin '+n,len(raw)==v['bytes'] and H(raw)==v['sha256'])
for p in sorted((P/'before').rglob('*')):
 if p.is_file():ck('actual base bytes '+str(p.relative_to(P/'before')),p.read_bytes()==g('show',base+':'+str(p.relative_to(P/'before'))))
old=(P/'before/geometry-core/kernel/source.c').read_text();new=(P/'candidate/geometry-core/kernel/source.c').read_text();testold=(P/'before/tests/test_geo261_source_index.py').read_text();testnew=(P/'candidate/tests/test_geo261_source_index.py').read_text();tree=ast.parse(testnew);before,after=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='PROVIDER_HINT_EDIT'for t in n.targets))
ck('single product substitution',old.count(before)==1 and new.count(after)==1 and old.replace(before,after)==new);ck('no equality allocation or lifecycle delta',new.replace(after,before)==old)
ck('uint32 provider type',b'typedef uint32_t GeoProviderToken;'in g('show',base+':geometry-core/kernel/source.h'));ck('bounded unsigned mixer','uint32_t provider_hint=(uint32_t)(source.provider*UINT32_C(2654435761));'in after and 'provider_hint>>24'in after)
ck('original keysize and firstlast','^source.key_size;'in after and 'slot^=(size_t)key[0]^key[source.key_size-1];'in new);ck('original256 and equalityguard','slot&=255;'in new and 'hint&&hint<=ctx->node_count&&geo_source_ref_equal(ctx->nodes[hint-1]->source,source)'in new)
def classmethods(t):
 c=next(x for x in ast.parse(t).body if isinstance(x,ast.ClassDef)and x.name=='SourceIndex');return {x.name:ast.dump(x,include_attributes=False)for x in c.body if isinstance(x,ast.FunctionDef)}
a=classmethods(testold);b=classmethods(testnew)
ck('original17 test methods',len([k for k in a if k.startswith('test_')])==17);ck('candidate18 testmethods',len([k for k in b if k.startswith('test_')])==18)
for n,v in a.items():ck('original method AST '+n,b[n]==v)
oldj=json.loads((P/'before/tests/run_all.expected.json').read_bytes());newj=json.loads((P/'candidate/tests/run_all.expected.json').read_bytes());ck('old expected17',oldj['suites']['py:test_geo261_source_index']['count']==17);oldj['suites']['py:test_geo261_source_index']['count']=18;ck('expected only17to18',oldj==newj)
h=(P/'candidate/tests/geo323_provider_hint_harness.c').read_text();oldh=(P/'before/tests/geo261_source_index_harness.c').read_text()
ck('original harness and independent oracle','#include "geo261_source_index_harness.c"'in h and 'static size_t linear_node(GeoSourceRef ref)'in oldh and 'old.provider==ref.provider&&old.key_size==ref.key_size'in oldh)
ck('original malloc fallback machinery','fail_indexes=1;'in h and 'index_failures>0&&ctx->node_index_capacity==0'in h)
ck('full five providers',all(x in h for x in ['{2,"hint.two"','{UINT32_C(0x80000002),"hint.high"','{UINT32_MAX,"hint.max"','{0,"hint.zero"','{19,"hint.nineteen"']))
ck('unaligned differing middle with sameends','a[8]={0,0,1,0,0,0,0,0},b[8]={0,0,2,0,0,0,0,0}'in h and '{2,b+1,4}'in h)
ck('zero malformed and status paths',all(x in h for x in ['{2,NULL,0}','{2,b+1,0}','{2,NULL,1}','(GeoDependencyKind)99','!geo_eval_reset(ctx)','{999,NULL,0}']))
ck('normal reset and clear','for(size_t i=0;i<256;++i)REQUIRE("provider-hint-clear",ctx->node_hint[i]==0)'in h)
ck('work source dirs do not collide','("provider-hint-source-" + phase)'in testnew and 'exe_name = "provider-hint-" + phase'in testnew)
ck('count only original find entry',testnew.count('anchor = "static size_t geo_source_find_node')==1 and 'anchor + "++provider_hint_find_calls;"'in testnew)
ck('three explicit work phases','(("fixed", source, 0, 0), ("withdrawn", withdrawn, 1, 16), ("restored", source, 0, 0))'in testnew)
ck('semantic assertion first',testnew.index('self.assertEqual(0, semantic.returncode',testnew.index('def test_provider_hint'))<testnew.index('result = self.case("provider-hint-work"'))
ck('whole exact restore','self.assertEqual(source, withdrawn.replace(before, after))'in testnew)
ck('not crash/timeouts as kills','self.assertIn(result.returncode, (0, 1)'in testnew and 'timeout=30'in testnew)
ck('whole normal cause named','^ASSERT:provider-hint-cross-family-cache'in testnew and 'REQUIRE("provider-hint-cross-family-cache",calls==0)'in h)
ck('control named causes','provider-hint-full-width-provider'in testnew and 'provider-hint-middle-byte-identity'in testnew and 'self.assertEqual(1, result.returncode'in testnew and 'self.assertEqual("", result.stdout)'in testnew)
oldslots=[(2^4^0^0)&255,(19^5^16^0)&255];newslots=[(((2*2654435761)&0xffffffff)>>24)^4,(((19*2654435761)&0xffffffff)>>24)^5^16]
ck('warm pair oldsame6',oldslots==[6,6]);ck('warm pair newseparate',newslots==[56,171]);ck('whole modeled16 alternations','repeat<8' in h and 'for(size_t i=0;i<2;++i)'in h)
ck('fullprovider named assertion precedes graph',h.index('REQUIRE(labels[i],')<h.index('REQUIRE("provider-hint-ordered-public-graph"'))
ck('full provider highsame8',((0x80000002&255)==2)and((0x80000002*2654435761&0xffffffff)>>24)!=((2*2654435761&0xffffffff)>>24))
ck('middle identity source mutation exact',new.count('||!memcmp(a.key,b.key,a.key_size)')==1 and new.count('a.provider==b.provider')==1)
ck('manifest preserves UNRUN',m['formal']=='UNRUN' and m['product_state']=='External draft only, no branch yet')
(O/'READS.json').write_text(json.dumps(reads,ensure_ascii=False,indent=2)+'\n');r={'scope':'Static source and test review; original base reads, four candidate pins, AST preservation, deterministic slot arithmetic. No C/benchmark/tool execution.','manifest_sha256':H((P/'MANIFEST.json').read_bytes()),'patch_sha256':H((P/'FOUR_LEAF.patch').read_bytes()),'checks':checks,'passed':sum(x['passed']for x in checks),'failed':sum(not x['passed']for x in checks),'findings':[],'reasoning':['Only hint bucket changes; original exact provider/key equality and complete fallback/lifecycle/allocator code remain byte-identical.','Withdrawn warm pair deliberately shares slot6; fixed buckets56 and171 are distinct. This predicts original find calls16 versus0 for the specified16 repeated lookups only, not a general performance bound.','Forced linear index fallback causes the truncated-provider mutant to fail at the second input under its named count assertion; middle-byte mutant first diverges at the fifth input. Both occur before graph_equal generic labels. Actual compiler and assertions must still run.','All17 existing test methods and helpers retain exact AST. One new method plus registry17to18 does not relax old assertions or30-second child limit.','No conclusion about R6 wall failures or full acceptance; formal new18 remains UNRUN.']};(O/'REVIEW.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['passed'],r['failed'],H((O/'REVIEW.json').read_bytes()));assert r['failed']==0
