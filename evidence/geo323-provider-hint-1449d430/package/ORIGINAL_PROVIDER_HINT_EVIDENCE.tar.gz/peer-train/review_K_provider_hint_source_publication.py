from pathlib import Path
import ast, datetime, hashlib, json, subprocess
O=Path('/workspace/train337-canvas-peer-resume')
A=Path('/tmp/geo323-provider-hint-source-publication-20261024')
E=Path('/tmp/geo323-provider-hint-alignment-publication-20261024')
B=Path('/tmp/geo323-provider-hint-alignment-publication-r2-20261024')
F='2bbe54f19b2d19e8a816530f0c4edca950629a34'
S='81b6c388f8b73e9aaf885b1d948e5f306b77bafd'
T='1449d430d1c4734bb1bc3a9f91f3851c845cc0f3'
branch='codex/train337-provider-hint-20261024'; findings=[]; checks=0
def h(b):return hashlib.sha256(b).hexdigest()
def ck(v,n):
 global checks
 checks+=1
 if not v: findings.append(n)
def js(p):return json.loads(Path(p).read_bytes())
def output(j,i):return (Path(j['commands'][i-1]['directory'])/'stdout').read_bytes()
a=js(A/'RESULT.json');e=js(E/'RESULT.json');b=js(B/'RESULT.json')
for base,r,count in [(A,a,46),(B,b,27)]:
 ck(len(r['commands'])==count,'original command count '+base.name)
 for i,c in enumerate(r['commands'],1):
  p=Path(c['directory']);ck(p==base/'commands'/f'{i:03d}','exact command locator')
  ck(js(p/'result.json')==c,'original command result equality')
  for name in ['stdout','stderr']:ck(h((p/name).read_bytes())==c[name+'_sha256'],'full original stream '+str(p/name))
  ck(c['exit']==(1 if base==A and i==3 else 0),'original command exit '+str(p))
  ck(c['started_utc']<=c['ended_utc'],'original terminal order')
  ck(not any(x in c['argv'] for x in ['--force','-f']) or 'add' in c['argv'],'no forced history mutation')
ck(a['base_sha']==F and a['source_sha']==S and a['source_pushed'] and a['exit']==0 and not a['C_executed'] and not a['ledger_regenerated'],'original source publication facts')
ck(e['parent']==S and e['source_sha'] is None and e['exit']==1 and e['commands']==[] and not e['source_pushed'] and not e['C_executed'],'environment rejection retained before any Git or C')
ck(e['free_before']['/workspace']<32*1024*1024 and 'same32MiB source publication guard' in e['error'],'exact initial environment reason')
ck(b['parent']==S and b['source_sha']==T and b['source_pushed'] and b['exit']==0 and not b['C_executed'] and not b['root_git_mutated'],'final successor publication facts')
leaves=['geometry-core/kernel/source.c','tests/geo323_provider_hint_harness.c','tests/run_all.expected.json','tests/test_geo261_source_index.py']
ck(output(a,29).decode().split('\0')[:-1]==leaves,'initial exact four staged paths')
ck(output(a,36).strip().decode()==S and output(a,37).strip().decode()==F,'original S parent F')
ck(output(a,46).decode()==S+'\trefs/heads/'+branch+'\n','original public S remote verification')
ck(output(b,16)==output(b,22)==b'tests/geo323_provider_hint_harness.c\0','successor only alignment harness leaf')
ck(output(b,20).strip().decode()==T and output(b,21).strip().decode()==S,'original T parent S')
ck(output(b,25).decode()==T+'\trefs/heads/'+branch+'\n','original public T remote verification')
ck(output(b,26).strip().decode()==S and output(b,27)==b'' and b['commands'][25]['cwd']==str(A.parent/'geo323-provider-hint-work-20261024'),'old shared worktree remains at S clean; not falsely T')
ma=js(A/'SOURCE_MANIFEST.json');mb=js(B/'SOURCE_MANIFEST.json')
ea={x['path']:x for x in ma['entries']};eb={x['path']:x for x in mb['entries']}
ck(len(ea)==len(eb)==71 and ea.keys()==eb.keys(),'same exact 71 declared source inputs')
ck(ma['source_sha']==S and mb['source_sha']==T and mb['clean'] and not mb['C_executed'],'manifest source identities')
root=Path(mb['root']);ck(root==Path('/tmp/geo323-provider-hint-private-work-20261024'),'private successor owner repository')
for name,x in eb.items():
 p=root/name;ck(p.is_file() and p.stat().st_size==x['bytes'] and h(p.read_bytes())==x['sha256'],'actual final source leaf '+name)
 if name!='tests/geo323_provider_hint_harness.c':ck(x==ea[name],'unchanged declared input '+name)
ck((root/'.git/objects/info/alternates').read_text().strip()=='/workspace/geometry-axiom/.git/objects','one-way read-only existing object dependency retained')
raw=O/'K_PROVIDER_HINT_SOURCE_SMALL_GIT_ORIGINALS';raw.mkdir(exist_ok=True);git_counter=0
def git(*args):
 global git_counter
 git_counter+=1;p=raw/f'{git_counter:03d}';cmd=['git','-c','gc.auto=0','-c','maintenance.auto=false',*args]
 if p.exists():
  old=js(p/'result.json');data=(p/'stdout').read_bytes();err=(p/'stderr').read_bytes();ck(old['argv']==cmd and old['cwd']==str(root) and old['exit']==0 and h(data)==old['stdout_sha256'] and h(err)==old['stderr_sha256'],'reuse exact original fixed Git capture '+str(args));return data
 p.mkdir();start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);end=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (p/'stdout').write_bytes(r.stdout);(p/'stderr').write_bytes(r.stderr);(p/'result.json').write_text(json.dumps({'argv':cmd,'cwd':str(root),'started_utc':start,'ended_utc':end,'exit':r.returncode,'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr)},indent=2)+'\n');ck(r.returncode==0,'read-only fixed Git '+str(args));return r.stdout
ck(git('show','-s','--format=%H%n%P',T).decode()==T+'\n'+S+'\n','fixed Git actual T and parent')
ck(git('diff','--name-only','-z',F,T).decode().split('\0')[:-1]==leaves,'fixed Git full product closure exactly four leaves')
for name in leaves:ck(git('show',T+':'+name)==(root/name).read_bytes(),'actual committed bytes '+name)
before=output(a,44);after=(root/leaves[1]).read_bytes()
old=b'    unsigned char a[8]={0,0,1,0,0,0,0,0},b[8]={0,0,2,0,0,0,0,0};'
new=b'    union { uint64_t aligned; unsigned char bytes[8]; } a_store={0},b_store={0};\n    unsigned char *a=a_store.bytes,*b=b_store.bytes;a[2]=1;b[2]=2;\n    REQUIRE("provider-hint-unaligned-keys",(uintptr_t)(a+1)%sizeof(uint64_t)!=0&&(uintptr_t)(b+1)%sizeof(uint64_t)!=0);'
ck(before.count(old)==1 and after==before.replace(old,new),'alignment repair exact and explicit normal assertion')
oldpy=output(a,16).decode();newpy=(root/leaves[3]).read_text()
def members(t):
 result={}
 def walk(nodes,prefix=''):
  for n in nodes:
   if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    if isinstance(n,ast.ClassDef):walk(n.body,prefix+n.name+'.')
    else:result[prefix+n.name]=ast.dump(n,include_attributes=False)
 walk(ast.parse(t).body);return result
oldmembers=members(oldpy);newmembers=members(newpy)
for name,value in oldmembers.items():ck(newmembers.get(name)==value,'old test/helper AST retained '+name)
ck(len([x for x in oldmembers if '.test_' in x])==17 and len([x for x in newmembers if '.test_' in x])==18,'17 original plus one new method; no C executed here')
oldreg=json.loads(output(a,17));newreg=json.loads((root/leaves[2]).read_bytes())
def diff(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in a.keys()|b.keys():out+=diff(a.get(k),b.get(k),path+'/'+k)
  return out
 return [] if a==b else [(path,a,b)]
rd=diff(oldreg,newreg);ck(len(rd)==1 and rd[0][1:]==(17,18),'registry only method count 17 to18')
report={'schema':'K-provider-hint-public-source-actual-peer-v1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'base_sha':F,'initial_source_sha':S,'final_source_sha':T,'branch':branch,'source_inputs':71,'original_commands':{'initial':46,'successor':27,'initial_expected_missing_ref_exit':1,'environment_rejected_before_Git':1},'original_receipts':{str(p/'RESULT.json'):h((p/'RESULT.json').read_bytes()) for p in [A,E,B]},'source_manifest_sha256':h((B/'SOURCE_MANIFEST.json').read_bytes()),'small_git_originals':str(raw),'subject_executions':0,'limits':['Source publication only. The final18 native methods and withdrawal/restoration controls require their own original terminal receipt; no C or timing run by reviewer.','Original environment rejection exit1 was before all Git/C and is preserved; final source published by ordinary descendant commit and normal push in private TMP repository.','Old shared worktree HEAD remains S81 clean; final private owner is S144. Read-only Git object alternate must remain available.','Full123 mutation ledger and architecture regeneration are root final-source tasks, not performed or claimed here.']}
out=O/'K_PROVIDER_HINT_PUBLIC_SOURCE_ACTUAL_PEER.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out.read_bytes()),'checks':checks,'exit_code':report['exit_code'],'findings':findings}));raise SystemExit(report['exit_code'])
