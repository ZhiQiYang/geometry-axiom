from pathlib import Path
import ast,hashlib,json,re
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/tmp/geo323-provider-hint-formal-20261024');ROOT=Path('/tmp/geo323-provider-hint-private-work-20261024');S='1449d430d1c4734bb1bc3a9f91f3851c845cc0f3';checks=0;findings=[]
def h(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(Path(p).read_bytes())
def ck(v,n):
 global checks
 checks+=1
 if not v:findings.append(n)
r=j(B/'RESULT.json');o=j(B/'observed/receipt.json');q=j(B/'observed/request.json');completion=j(B/'EXEC_COMPLETION.json')
ck(r['source_sha']==o['source_sha']==q['source_sha']==S and r['exit']==r['original_suite_process_exit']==o['original_exit']==completion['exit_code']==0,'fixed source and original driver/suite/tool actual0')
ck(o['observer_complete'] and o['original_completed'] and not o['observation_errors'] and not o['subject_verdicts_changed'] and o['source_tool_bytes_unchanged'],'complete observation without subject verdict changes')
ck(q['original_entry']=='tests/test_geo261_source_index.py' and q['original_argv']==['tests/test_geo261_source_index.py','-v'],'original full18 entry')
ck(q['observer_sha256']==h(Path('/workspace/geo323-provider-hint-formal-tools-20261024/retain_source_index_streams.py').read_bytes())=='4e73d3093f826b726ec080b03bf5f8721463e7c4843f77a7ebd8b182baddb7ad','fixed observed tool')
ck(r['stack_bytes']==16777216 and r['exclusive_heavy_slot']=='/tmp/g261r3/secondary.lock' and r['free_bytes_before']>=80*1024*1024,'actual resource admission and original stack')
for flags in ['wall_clock_performance_run','ledger_regenerated','architecture_regenerated']:ck(r[flags] is False,'no unexecuted claim '+flags)
for c in r['commands']:
 d=Path(c['stdout']).parent;ck(j(d/'result.json')==c and c['actual_process_exit']==0 and c['source_sha']==S,'actual original outer child')
 for k in ['stdout','stderr']:
  data=Path(c[k]).read_bytes();ck(len(data)==c[k+'_bytes'] and h(data)==c[k+'_sha256'],'outer complete original stream')
stderr=Path(r['commands'][-1]['stderr']).read_bytes();names=re.findall(rb'^(test_\w+) \(__main__\.SourceIndex\.\1\) \.\.\. ok$',stderr,re.M)
ck(len(names)==len(set(names))==18 and re.search(rb'Ran 18 tests in [^\n]+\n\nOK\s*$',stderr) is not None and not re.search(rb'skipped|expected failure|unexpected success',stderr),'exact18 distinct methods no skip')
module=ast.parse((ROOT/'tests/test_geo261_source_index.py').read_bytes());methods=[n.name for c in module.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];ck(sorted(x.decode() for x in names)==sorted(methods),'full declared method discovery')
for name,pin in q['source_tool_sha256_before'].items():ck(h((ROOT/name).read_bytes())==pin==o['source_tool_sha256_after'][name],'before/after actual source tool '+name)
for label,rows in [('pre',q['source_preflights']),('post',o['source_postflights'])]:
 for c in rows:
  ck(c['exit_code']==0 and bytes.fromhex(c['stderr_hex'])==b'','original source '+label+' Git0')
  data=bytes.fromhex(c['stdout_hex'])
  if c['argv']==['git','rev-parse','HEAD']:ck(data==S.encode()+b'\n','fixed source HEAD '+label)
  elif c['argv'][1]=='status':ck(data==b'','clean source '+label)
  elif c['argv'][1]=='show':ck(data==(ROOT/c['argv'][2].split(':',1)[1]).read_bytes(),'committed source original bytes')
native=[];builds=[];streamdata={}
ck([x['number'] for x in o['commands']]==list(range(1,118)),'117 ordered observed commands')
for c in o['commands']:
 d=B/'observed/commands'/f'{c["number"]:06d}';ck(j(d/'result.json')==c,'actual observed result '+str(c['number']))
 ck(c['completed_process_returned'] and c['exception'] is None and c['ended_epoch']>=c['started_epoch'],'normal process completion '+str(c['number']))
 for k in ['stdout','stderr']:
  x=c[k];p=Path(x['path']);data=p.read_bytes();ck(x['captured'] and p.is_relative_to(B) and len(data)==x['bytes'] and h(data)==x['sha256'],'full original observed '+k);streamdata[(c['number'],k)]=data
  ck(x['representation']=='original-text-encoded-utf8','preserve decoded text representation; no predecode OS claim')
 env=c['selected_environment'];ck(env['TMPDIR']==str(B/'tmp') and env['MUTATE_CACHE'] is None and env['MUTATE_RESULTS'] is None and env['PYTHONOPTIMIZE'] is None,'isolated exact environment')
 argv=c['args'][0];kw=c['keyword_arguments_except_env']
 if 'actual_executable' in c:
  x=c['actual_executable'];p=Path(x['retained']);data=p.read_bytes();ck(p.is_relative_to(B) and len(data)==x['bytes'] and h(data)==x['sha256'] and data.startswith(b'\x7fELF'),'actual native executable retained hash')
  ck(len(argv)==2 and x['path']==argv[0] and kw['timeout']==30,'original native30-second case and actual executable')
  native.append(c)
 else:
  ck(argv[0]=='/usr/bin/cc' and c['returncode']==0 and kw['timeout']==300,'original compiler/link success and300 limit');builds.append(c)
ck(len(native)==r['actual_native_commands']==51 and len(builds)==r['actual_compile_link_commands']==66,'actual51 native and66 compiler commands')
ret=j(B/'native-retention/retention.json');ck(len(ret)==1,'one NativeBuild cleanup audit')
buildfile=Path(ret[0]['retained']);ck(h(buildfile.read_bytes())==ret[0]['sha256'] and buildfile.stat().st_size==ret[0]['bytes'],'original retained complete buildlog')
blog=j(buildfile);ck(len(blog)==66,'original buildlog count')
for entry,c in zip(blog,builds):
 ck(entry['command']==entry['arguments']==c['args'][0] and entry['exit']==c['returncode']==0,'recorded compiler exact command and exit')
 ck(entry['stdout'].encode()==streamdata[(c['number'],'stdout')] and entry['stderr'].encode()==streamdata[(c['number'],'stderr')],'compiler full decoded streams exact')
snap=j(B/'native-retention/all-c-header-inputs/source-snapshots.json');ck(len(snap)==1 and len(snap[0]['files'])==103,'103 complete nested C/header snapshots')
sources={}
for x in snap[0]['files']:
 data=Path(x['retained']).read_bytes();ck(len(data)==x['bytes'] and h(data)==x['sha256'],'actual nested source snapshot')
 name=str(Path(x['original']).relative_to(snap[0]['original_build_directory']));ck(name not in sources,'unique nested source');sources[name]=data
for x in ret[0]['compiled_sources']:ck(h(Path(x['retained']).read_bytes())==x['sha256'] and Path(x['retained']).stat().st_size==x['bytes'],'cleanup retained compiled TU exact')
for name,data in sources.items():
 if name.startswith('isolated-kernel/'):ck(data==(ROOT/'geometry-core/kernel'/name[len('isolated-kernel/'):]).read_bytes(),'isolated K source exact final '+name)
current=(ROOT/'geometry-core/kernel/source.c').read_bytes();constants={t.id:ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name) and t.id in ['PROVIDER_HINT_EDIT','EDGE_PROBE_REUSE_EDITS']}
before,after=(x.encode() for x in constants['PROVIDER_HINT_EDIT']);ck(current.count(after)==1,'exact whole product change anchor')
providerold=current.replace(after,before);edgeold=current
for old,new in reversed(constants['EDGE_PROBE_REUSE_EDITS']):ck(edgeold.count(new.encode())==1,'original edge undo unique');edgeold=edgeold.replace(new.encode(),old.encode())
by_num={c['number']:c for c in native}
def nm(c):return Path(c['args'][0][0]).name
def raw(c,k):return streamdata[(c['number'],k)]
def assertion(c,label):return c['returncode']==1 and re.fullmatch(rb'ASSERT:'+label.encode()+rb' line=\d+ expr=[^\n]+\n',raw(c,'stderr')) is not None
def binary_matches(row,c):return row['binary']==c['actual_executable']
for proof in r['control_proofs'][:-1]:
 ns=proof['actual_command_numbers'];trip=[by_num[n] for n in ns];pos=native.index(trip[1]);ck(native[pos-1:pos+2]==trip,'adjacent original0/1/0 '+proof['control'])
 ck([c['returncode'] for c in trip]==proof['actual_exits']==[0,1,0] and assertion(trip[1],proof['assertion']) and raw(trip[1],'stdout')==b'','normal exact first assertion '+proof['control'])
 ck(all(nm(c)=='source-index-client' and c['args'][0][1]==proof['case'] and raw(c,'stdout')==('PASS '+proof['case']+'\n').encode() and raw(c,'stderr')==b'' for c in [trip[0],trip[2]]),'baseline and repeated binary restoration '+proof['control'])
ck(len(r['control_proofs'])==11,'ten original narrow and one edge whole proof')
for kind,proofs,prefix,hook,old,marker,counter,counts in [
 ('edge',r['control_proofs'][-1]['phases'],'edge-probe-source-',b'{++edge_probe_hash_calls;',edgeold,'edge-probe-reuses-lookup-hash','PROBE_HASH_CALLS',[21,31,21]),
 ('provider',r['provider_hint_proofs']['whole'],'provider-hint-source-',b'{++provider_hint_find_calls;',providerold,'provider-hint-cross-family-cache','PROVIDER_HINT_FIND_CALLS',[0,16,0])]:
 cmdorder=[]
 for i,x in enumerate(proofs):
  phase=['fixed','withdrawn','restored'][i];ck(x['phase']==phase,'whole phase order')
  ids=[x['semantic_command'],x['cost_command']] if kind=='edge' else x['commands'];sem,work=[by_num[n] for n in ids];cmdorder+=ids;case='edge-probe' if kind=='edge' else 'provider-hint-semantics';workcase='edge-probe-cost' if kind=='edge' else 'provider-hint-work'
  ck(sem['returncode']==0 and raw(sem,'stdout')==('PASS '+case+'\n').encode() and raw(sem,'stderr')==b'' and sem['args'][0][1]==case,'whole exact semantic0 '+kind+'/'+phase)
  expected=[0,1,0][i];ck(work['returncode']==expected and work['args'][0][1]==workcase and binary_matches(x,work),'whole actual work exit and binary '+kind+'/'+phase)
  want=f'{counter}={counts[i]}\n'+(f'PASS {workcase}\n' if expected==0 else '');ck(raw(work,'stdout')==want.encode() and (assertion(work,marker) if expected else raw(work,'stderr')==b''),'whole precise counted work0/1/0 '+kind+'/'+phase)
  src=sources[prefix+phase+'/source.c'];ck(src.count(hook)==1 and src.replace(hook,b'{')==(old if phase=='withdrawn' else current),'actual compiled whole variant exact '+kind+'/'+phase)
  parent=prefix+phase+'/';client=(ROOT/'tests/geo261_source_index_harness.c').read_bytes() if kind=='edge' else (ROOT/'tests/geo323_provider_hint_harness.c').read_bytes();ck(sources[parent+'client.c']==client,'whole client actual bytes')
  if kind=='provider':ck(sources[parent+'geo261_source_index_harness.c']==(ROOT/'tests/geo261_source_index_harness.c').read_bytes(),'nested original graph oracle exact')
 ck(cmdorder==sorted(cmdorder) and len(set(cmdorder))==6,'whole chronological six native calls')
for name,anchor,replacement,label in [('full-provider',b'a.provider==b.provider',b'(uint8_t)a.provider==(uint8_t)b.provider','provider-hint-full-width-provider'),('middle-key',b'||!memcmp(a.key,b.key,a.key_size)',b'||1','provider-hint-middle-byte-identity')]:
 rows=[c for c in native if nm(c)=='provider-hint-control-'+name];ck(len(rows)==1 and assertion(rows[0],label) and raw(rows[0],'stdout')==b'','exact normal identity negative control '+name)
 parent='provider-hint-control-source-'+name+'/';ck(current.count(anchor)==1 and sources[parent+'source.c']==current.replace(anchor,replacement),'exact identity control compiled source '+name)
 ck(sources[parent+'client.c']==(ROOT/'tests/geo323_provider_hint_harness.c').read_bytes() and sources[parent+'geo261_source_index_harness.c']==(ROOT/'tests/geo261_source_index_harness.c').read_bytes(),'nested identity clients exact')
 ck('no separate per-control restoration claimed' in next(x['scope'] for x in r['provider_hint_proofs']['identity_controls'] if x['name']==name),'supplementary control restoration scope truthful')
ck(b'provider-hint-unaligned-keys' in sources['provider-hint-source-fixed/client.c'] and b'uintptr_t' in sources['provider-hint-source-fixed/client.c'],'final strengthened alignment witness actually compiled and semantics0')
report={'schema':'K-provider-hint-full18-actual-peer-v1','checks':checks,'exit_code':int(bool(findings)),'findings':findings,'source_sha':S,'result_sha256':h((B/'RESULT.json').read_bytes()),'observation_sha256':h((B/'observed/receipt.json').read_bytes()),'original_request_sha256':h((B/'observed/request.json').read_bytes()),'original_tool_completion_sha256':h((B/'EXEC_COMPLETION.json').read_bytes()),'original_methods':18,'skips':0,'actual_native_commands':51,'actual_compile_link_commands':66,'actual_C_header_snapshots':103,'original_controls':{'ten_narrow':'actual adjacent0/1/0; baseline binary reexecuted after mutant','whole_edge':'semantic0/0/0; work21/31/21 with normal0/1/0'},'provider_fix':{'whole_semantics':[0,0,0],'whole_work_counts':[0,16,0],'whole_work_exits':[0,1,0],'identity_controls':['full-width provider normal1','middle key normal1'],'unaligned_witness':'natural uint64_t union + explicit uintptr_t misalignment assertion; final client actually compiled'},'limits':['No formal wall/performance inference: these are deterministic calls and original directed native correctness tests. R7 timing is separate and not executed by reviewer.','Original subprocess text=True streams preserved as original decoded text encoded UTF8, not invented predecode OS bytes. Top tool completion is truthful combined-output transcription with no separate stderr claimed.','Old ten controls use adjacent original baseline binary reexecution; whole source fixes have three separate compilation variants. Two supplemental identity controls are normal assertion1 and do not claim separate per-control restoration.','Full project native/browser/ledger/architecture remain separate final integration gates; this directed result does not mark READY-TO-MERGE.']}
out=O/'K_PROVIDER_HINT_FULL18_ACTUAL_PEER.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out.read_bytes()),'checks':checks,'exit_code':report['exit_code'],'findings':findings}));raise SystemExit(report['exit_code'])
