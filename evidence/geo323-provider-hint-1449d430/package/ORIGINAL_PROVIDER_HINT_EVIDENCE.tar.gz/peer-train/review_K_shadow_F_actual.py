from pathlib import Path
import hashlib,json,stat,re
O=Path('/workspace/train337-canvas-peer-resume');D=Path('/workspace/geo323-shadow-hint-F-diagnostic-draft-20261024');B=Path('/tmp/geo323-shadow-hint-F-observation-20261024');X=B/'execution';S=Path('/workspace/geo323-final-r6-source-20261024');F='2bbe54f19b2d19e8a816530f0c4edca950629a34';checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
r=j(X/'RESULT.json');m=j(D/'MANIFEST.json');diag=j(X/'SHADOW.json');tot=j(X/'TOTALS.json');rows=r['commands'];sources=j(X/'SOURCE_MANIFEST.json')
ck(h(D/'MANIFEST.json')=='8c3ecddeff22f69f1f7037fa94e112581a07c307163f8a4ed301726ab51cca2c','fixed diagnostic-only manifest')
ck(r['source_sha']==m['source_sha']==F and r['exit']==0 and r['source_clean_after'],'true F terminal0 source clean')
ck(not r['formal_performance_sample'] and not r['formal_timing_remeasured'] and not r['product_strategy_changed'] and not r['branch_written'],'not formal wall, product strategy or branch edit')
ck(len(rows)==9 and j(X/'EXEC_COMPLETION.json')['exit_code']==0,'nine original commands and observed tool exit0')
for i,row in enumerate(rows,1):
 p=X/'commands'/f'{i:03d}';ck(j(p/'result.json')==row and row['exit']==0 and row['source_sha']==F and row['finished_utc']>=row['started_utc'],'true command/source/terminal '+str(i))
 for stream in ['stdout','stderr']:ck(h(p/stream)==row[stream+'_sha256'],'full original stream '+str(i)+stream)
 ck(row['environment']['TMPDIR']==str(B/'tmp') and row['environment']['PYTHONDONTWRITEBYTECODE']=='1','private environment '+str(i))
 ck(h(p/'stdin')==row['stdin_sha256'] if row['stdin_sha256'] is not None else not (p/'stdin').exists(),'exact stdin or inherited absence '+str(i))
ck((X/'commands/001/stdout').read_text().strip()==(X/'commands/008/stdout').read_text().strip()==F,'before/after original fixed HEAD')
ck((X/'commands/002/stdout').read_bytes()==(X/'commands/009/stdout').read_bytes()==b'','before/after clean original source')
for i,entry,binary in [(4,'observer_selftest_entry.c','observer-selftest'),(6,'diagnostic_entry.c','bridge')]:
 ck(rows[i-1]['argv']==['gcc','-std=c11','-O1','-fno-inline','-pg',str(B/'source'/entry),'-o',str(X/binary),'-lm'],'exact diagnostic flags/source/binary '+str(i))
for key in ['selftest_binary','binary']:
 q=Path(r[key]['path']);ck(q.stat().st_size==r[key]['bytes'] and h(q)==r[key]['sha256'] and q.read_bytes()[:4]==b'\x7fELF','actual retained diagnostic ELF '+key)
ck((X/'commands/005/stdout').read_bytes().startswith(b'SHADOW_SELFTEST_OK:') and (X/'commands/005/stderr').read_bytes()==b'' and r['observer_selftest_exit']==0,'original selftest completed normally')
for name,pin in m['files'].items():ck(h(D/name)==pin['sha256'] and (D/name).stat().st_size==pin['bytes'],'static reviewed draft pin '+name)
before=(D/'before.c').read_text();candidate=before;edits=j(D/'EXACT_EDITS.json');ck(len(edits)==14,'fourteen exact observation edits')
for e in edits:ck(candidate.count(e['before'])==1,'unique forward hook');candidate=candidate.replace(e['before'],e['after'],1)
ck(candidate==(D/'candidate.c').read_text(),'exact instrumented candidate')
for e in reversed(edits):ck(candidate.count(e['after'])==1,'unique withdrawal hook');candidate=candidate.replace(e['after'],e['before'],1)
ck(candidate==before==(S/'geometry-core/kernel/source.c').read_text(),'full observation withdrawal original F bytes')
prep={x['path']:x for x in j(Path('/workspace/geo323-final-r6-stage-tools-20261024/preparation/RESULT.json'))['entries']}
ck(len(sources)==r['source_files']==188 and sum(x['bytes'] for x in sources)==r['source_bytes']==2157586,'188 exact private source leaves and bytes')
external={'geometry-core/kernel/geo323_shadow.inc':'shadow.inc','diagnostic_entry.c':'diagnostic_entry.c','observer_selftest_entry.c':'observer_selftest_entry.c'}
for row in sources:
 p=B/'source'/row['path'];s=p.lstat();ck(stat.S_ISREG(s.st_mode) and s.st_nlink==row['nlink']==1 and s.st_size==row['bytes'] and s.st_mode&0o222==0,'private independent readonly source '+row['path'])
 if row.get('external_only'):
  ck(row['path'] in external and h(p)==row['sha256']==h(D/external[row['path']]),'exact external observer '+row['path'])
 else:
  q=S/row['path'];qs=q.lstat();ck(h(q)==row['R_sha256']==prep[row['path']]['sha256'] and (s.st_dev,s.st_ino)!=(qs.st_dev,qs.st_ino),'unchanged actual original F source '+row['path'])
  ck(h(p)==row['instrumented_sha256'] and p.read_bytes()==((D/'candidate.c').read_bytes() if row['path']=='geometry-core/kernel/source.c' else q.read_bytes()),'exact instrumented only K source '+row['path'])
classification=j(X/'INCLUDE_CLOSURE_CLASSIFICATION.original.json');known=[x for x in classification['unresolved_relative_directives'] if x['entry_reachable']['geometry-web/web_bridge.c']]
ck(len(known)==30 and sorted((x['from'],x['include'],x['relative']) for x in known)==sorted((x['source'],x['include'],x['relative']) for x in r['unresolved_relative_includes']['items']),'exact30 original guarded fallback directives')
ck({x['path'] for x in sources if not x.get('external_only')}==set(classification['entry_closures']['geometry-web/web_bridge.c']['paths']),'all185 original entry compile closure')
scene=Path(r['scene']['path']);ck(scene.stat().st_size==r['scene']['bytes']==5485 and h(scene)==r['scene']['sha256'],'original exact R6 scene bytes')
ck(r['stack_bytes']==16777216 and (X/'commands/007/stdin').read_bytes()==b'loadfile /workspace/g337323R6/evidence/scenes/s64.scene\n','single original R6 N64 load and16MiB stack')
profile=Path('/workspace/g337323R6/evidence');stdout=(X/'commands/007/stdout').read_bytes();stderr=(X/'commands/007/stderr').read_bytes();lines=stderr.splitlines(keepends=True);ds=[x for x in lines if x.startswith(b'GEO323_SHADOW ')]
ck(stdout==(X/'original-R-load.stdout').read_bytes()==(profile/'checks/profile-fix-64-load.stdout').read_bytes(),'full original stdout byte identical')
ck(len(ds)==1 and json.loads(ds[0][len(b'GEO323_SHADOW '):])==diag,'one exact original stderr diagnostic JSON')
ck(b''.join(x for x in lines if not x.startswith(b'GEO323_SHADOW '))==(X/'original-R-load.stderr').read_bytes()==(profile/'checks/profile-fix-64-load.stderr').read_bytes(),'full non-diagnostic stderr identical')
ck(diag['created']==diag['destroyed']==4 and diag['cleared']==215 and all(diag[x]==0 for x in ['invalid','errors','counter_overflow','context_overflow','family_overflow']),'observer lifecycle and all counters complete without overflow')
names=['original-direct256','original-slot-2way128','provider-mixed-direct256','provider-mixed-slot-2way128'];ck(diag['models']==tot['models']==names and len(diag['families'])==r['diagnostic_families']==10,'four fixed models and ten exact families')
counts=[{} for _ in names]
for fi,fam in enumerate(diag['families']):
 ck(len(fam['models'])==4,'four models family '+str(fi))
 for mi,c in enumerate(fam['models']):
  ck(c['lookup']==c['hit']+c['empty_miss']+c['full_miss']==c['success']+c['failure'],'lookup partition '+str((fi,mi)))
  ck(c['success']==c['existing_success']+c['new_success'] and c['hit']<=c['existing_success'],'existing/new outcomes '+str((fi,mi)))
  ck(c['write']==c['success']-c['hit'] and c['replacement']<=c['write'] and c['provider_mixes']==(c['lookup'] if mi>=2 else 0),'actual writes and fixed mix work '+str((fi,mi)))
  ck(c['hit']<=c['compare']<=(2 if mi in (1,3) else 1)*c['lookup'],'bounded equality comparisons '+str((fi,mi)))
  ck(c['memcmp_requested']<=c['compare']*fam['key_size'] and (fam['key_size']==0 or c['memcmp_requested']%fam['key_size']==0),'requested memcmp bytes not memory loads '+str((fi,mi)))
  ck(all(c[k]==fam['models'][0][k] for k in ['lookup','success','failure','existing_success','new_success']),'same actual return events every model '+str((fi,mi)))
  for k,v in c.items():counts[mi][k]=counts[mi].get(k,0)+v
ck(counts==tot['counts']==r['diagnostic_totals'] and tot['extra_key_reads']==0 and not tot['timing_inference'],'complete derived totals exact')
for name in ['replacements','conflict_comparisons']:
 matrix=diag[name];ck(len({tuple(x[:3]) for x in matrix})==len(matrix),'unique sparse matrix '+name)
 for mi in range(4):
  for fi,fam in enumerate(diag['families']):
   vals=[x for x in matrix if x[0]==mi and x[2]==fi];ck(all(len(x)==4 and 0<=x[1]<10 and x[3]>0 for x in vals),'valid family matrix '+name+str((mi,fi)))
   c=fam['models'][mi];expect=c['replacement'] if name=='replacements' else c['compare']-c['hit'];ck(sum(x[3] for x in vals)==expect,'per-incoming-family real '+name+str((mi,fi)))
raw=(profile/'gprof-fix-64.stdout').read_bytes();ck(raw==(X/'original-R-gprof-fix-64.stdout').read_bytes(),'original formal profile bytes preserved')
flat={}
for line in raw.decode().splitlines():
 cols=line.split()
 if '[' not in line and len(cols)==7 and cols[3].isdigit():flat[cols[-1]]=int(cols[3])
selected={k:flat[k] for k in ['geo_source_node','geo_source_find_node','geo_source_node_hash']};ck(selected==j(X/'ORIGINAL_R_PROFILE_COUNTS.json'),'actual original formal profile counts')
ck(counts[0]['lookup']+diag['invalid']==selected['geo_source_node']==2364478 and counts[0]['lookup']-counts[0]['hit']==selected['geo_source_find_node']==1737765,'original direct mirror matches formal K calls')
comparison=j(X/'MODEL_COMPARISON.json')
for mi,x in enumerate(comparison['models']):
 c=counts[mi];ck(x['model']==names[mi] and x['hit']==c['hit'] and x['successful_lookup_hit_fraction']==c['hit']/c['success'] and x['existing_misses']==c['existing_success']-c['hit'] and x['all_misses']==c['lookup']-c['hit'] and x['nominal_memcmp_bytes']==c['memcmp_requested'] and x['compares']==c['compare'],'model summary raw derived counters '+str(mi))
ck(comparison['fixed_generic_constant']==2654435761 and 'not elapsed-time' in comparison['scope'] and 'not measured memory reads' in comparison['not_measured'],'one prechosen generic formula, no timing claim')
report={'schema':'K-shadow-fixed-F-actual-observation-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'source_sha':F,'original_result_sha256':h(X/'RESULT.json'),'original_commands':9,'private_source_files':188,'private_source_bytes':2157586,'original_stack_bytes':16777216,'diagnostic_families':10,'models':names,'observed_counts':counts,'actual_original_outputs_identical':True,'formal_performance_sample':False,'product_strategy_changed':False,'limits':['Independent actual original raw, two ELF hashes and all188 small private/original source bytes checked; no compiler/test/runtime rerun.','Four shadow policies observe one fixed F N64 event stream. Their hits/memcmp request counts are work estimates, not new CPU/wall performance samples or product acceptance.','Per-incoming-family replacement and conflict matrices conserve real observed write/equality events, and original-direct mirror exactly matches original formal gprof lookup/find totals.','Derived cold/hot/pose-definition summary labels need explicit family grouping from owner before those aggregate labels are accepted; raw sparse family matrices and all model totals are independently verified.','Original static manifest UNRUN/PENDING fields describe preparation time and were not rewritten as runtime evidence; actual RESULT governs completed observation.']}
q=O/'K_SHADOW_F_ACTUAL_OBSERVATION_PEER.json';q.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':report['exit_code'],'findings':find}));raise SystemExit(report['exit_code'])
