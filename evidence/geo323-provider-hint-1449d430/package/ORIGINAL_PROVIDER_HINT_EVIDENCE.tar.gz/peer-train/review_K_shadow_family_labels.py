from pathlib import Path
import hashlib,json,re
O=Path('/workspace/train337-canvas-peer-resume');B=Path('/tmp/geo323-shadow-hint-F-observation-20261024/execution');D=Path('/workspace/geo323-shadow-hint-F-diagnostic-draft-20261024');checks=0;find=[]
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def j(p):return json.loads(Path(p).read_text())
def ck(v,n):
 global checks
 checks+=1
 if not v:find.append(n)
old=j(B/'MODEL_COMPARISON.before-explicit-family-labels.json');new=j(B/'MODEL_COMPARISON.json');diag=j(B/'SHADOW.json');tot=j(B/'TOTALS.json')
ck({k:v for k,v in new.items() if k not in ['family_labels','matrix_direction']}==old,'all original derived counters unchanged; labels only')
source=Path('/tmp/geo323-shadow-hint-F-observation-20261024/source/geometry-app/native/reference_sources.inc');raw=source.read_text();body=re.search(r'enum\s*\{(.*?)\};',raw,re.S).group(1);value=-1;tokens={}
for item in body.split(','):
 parts=item.strip().split('=');name=parts[0].strip();value=int(parts[1]) if len(parts)==2 else value+1;tokens[name]=value
ck(tokens['APP_SOURCE_MEMBER_POSE']==2 and tokens['APP_SOURCE_CONTACT']==16 and tokens['APP_SOURCE_WOOD_DEFINITION']==19,'actual source enum binds named family labels')
cold={i for i,x in enumerate(diag['families']) if (x['provider'],x['key_size'])==(16,17)};hot={i for i,x in enumerate(diag['families']) if (x['provider'],x['key_size']) in {(2,4),(19,5)}}
ck(cold=={4} and hot=={0,1},'three exact named families; no numeric hotness threshold')
ck(new['family_labels']['cold_named_contact_family']=={'provider':16,'key_size':17,'index':4} and new['family_labels']['hot_named_pose_definition_families']==[{'provider':2,'key_size':4,'index':0},{'provider':19,'key_size':5,'index':1}],'explicit grouping fields exact')
ck('no threshold' in new['family_labels']['meaning'] and 'victim_family_index, incoming_family_index' in new['matrix_direction'],'scope labels and actual matrix direction explicit')
for mi,row in enumerate(new['models']):
 matrix=[x for x in diag['replacements'] if x[0]==mi]
 ck(row['cold_victim_hot_incoming_replacements']==sum(n for _,a,b,n in matrix if a in cold and b in hot),'cold victim hot incoming actual replacements '+str(mi))
 ck(row['hot_victim_cold_incoming_replacements']==sum(n for _,a,b,n in matrix if a in hot and b in cold),'hot victim cold incoming actual replacements '+str(mi))
 ck(row['pose_definition_cross_replacements']==sum(n for _,a,b,n in matrix if a in hot and b in hot and a!=b),'bidirectional pose definition actual replacements '+str(mi))
ck(j(O/'K_SHADOW_F_ACTUAL_OBSERVATION_PEER.json')['exit_code']==0,'prior complete188source9commands actual remains0')
r={'schema':'K-shadow-family-label-addendum-peer-v1','checks':checks,'exit_code':int(bool(find)),'findings':find,'source_sha':'2bbe54f19b2d19e8a816530f0c4edca950629a34','model_comparison_sha256':h(B/'MODEL_COMPARISON.json'),'old_model_comparison_sha256':h(B/'MODEL_COMPARISON.before-explicit-family-labels.json'),'derive_tool_sha256':h(D/'derive_comparison.py'),'source_enum_sha256':h(source),'actual_peer_sha256':h(O/'K_SHADOW_F_ACTUAL_OBSERVATION_PEER.json'),'family_mapping':{'4':'contact(provider16,key17)','0':'member pose(provider2,key4)','1':'wood definition(provider19,key5)'},'limits':['This addendum resolves prior actual peer limitation about undefined cold/hot summary labels. Raw counters were not changed or rerun.','Named labels only; no threshold or generalized policy about all cold/hot values, cacheability or elapsed-time benefit.','Mixed-direct model increases reported hit fraction but nominal memcmp request bytes also increase; wall and real CPU effects remain unmeasured.']}
q=O/'K_SHADOW_F_FAMILY_LABEL_ADDENDUM_PEER.json';q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(q),'sha256':h(q),'checks':checks,'exit_code':r['exit_code'],'findings':find}));raise SystemExit(r['exit_code'])
