"""One root-authorized instrumented N64 observation; never a formal timing sample."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,posixpath,re,resource,shutil,subprocess,sys,traceback
HERE=Path(__file__).resolve().parent;R='2bbe54f19b2d19e8a816530f0c4edca950629a34'
SOURCE=Path('/workspace/geo323-final-r6-source-20261024');DRAFT=Path('/workspace/geo323-shadow-hint-F-diagnostic-draft-20261024');PROFILE=Path('/workspace/g337323R6/evidence');RUNROOT=Path('/tmp/geo323-shadow-hint-F-observation-20261024');OUT=RUNROOT/'execution';PRIVATE=RUNROOT/'source'
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def clean_env():
 e=os.environ.copy()
 for k in list(e):
  if k.startswith(('GIT_','GEOMETRY_','GEO323_','MUTATE_'))or k in('PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'):del e[k]
 e.update(LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',TMPDIR=str(RUNROOT/'tmp'));return e
report={'source_sha':R,'variant':'F2bbe + external shadow observation only','formal_performance_sample':False,'product_strategy_changed':False,'branch_written':False,'commands':[],'exit':None,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def run(argv,cwd,data=None):
 q=OUT/'commands'/f'{len(report["commands"])+1:03d}';q.mkdir(parents=True)
 if data is not None:(q/'stdin').write_bytes(data)
 row={'argv':argv,'cwd':str(cwd),'source_sha':R,'variant':report['variant'],'environment':{k:ENV.get(k)for k in('PATH','TMPDIR','LANG','LC_ALL','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE')},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdin_sha256':None if data is None else sha(data)}
 r=subprocess.run(argv,cwd=cwd,input=data,capture_output=True,env=ENV)
 (q/'stdout').write_bytes(r.stdout);(q/'stderr').write_bytes(r.stderr)
 row.update(exit=r.returncode,stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(q/'result.json').write_text(json.dumps(row,indent=2)+'\n');report['commands'].append(row)
 need(r.returncode==0,'original diagnostic command failed '+str(q));return r
ENV=clean_env()
def main():
 lock=Path('/tmp/g261r3/heavy.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  need(not OUT.exists()and not PRIVATE.exists(),'fresh output and private independent source only');OUT.mkdir(parents=True);(RUNROOT/'tmp').mkdir(exist_ok=False)
  fs=os.statvfs('/tmp');report['free_before']=fs.f_bavail*fs.f_frsize;need(report['free_before']>=160*1024*1024,'source/ELF/receipt32MiB plus native TMP reserve128MiB; no product threshold')
  terminal=json.loads(Path('/workspace/geo323-final-r6-stage-tools-20261024/launch-five/RESULT.json').read_text());need(terminal['source_sha']==R and len(terminal['commands'])==5 and type(terminal['exit'])is int,'R6 true five-stage terminal before diagnostic')
  original_manifest=(DRAFT/'MANIFEST.json').read_bytes();need(sha(original_manifest)=='8c3ecddeff22f69f1f7037fa94e112581a07c307163f8a4ed301726ab51cca2c','original static-reviewed diagnostic manifest')
  m=json.loads(original_manifest)
  for name,pin in m['files'].items():
   raw=(DRAFT/name).read_bytes();need(sha(raw)==pin['sha256']and len(raw)==pin['bytes'],'original diagnostic pin '+name)
  git=lambda *args:run(['git','--no-optional-locks','-C',str(SOURCE),*args],HERE).stdout
  need(git('rev-parse','HEAD').decode().strip()==R and git('status','--porcelain','--untracked-files=all')==b'','clean exact fixed R source')
  prep=json.loads(Path('/workspace/geo323-final-r6-stage-tools-20261024/preparation/RESULT.json').read_text());entries={r['path']:r for r in prep['entries']}
  selected={};pending=['geometry-web/web_bridge.c'];unresolved=[]
  while pending:
   name=pending.pop()
   if name in selected:continue
   p=SOURCE/name;raw=p.read_bytes();need(name in entries and sha(raw)==entries[name]['sha256'],'original R frozen compile closure '+name);selected[name]=raw
   for inc in re.findall(rb'^\s*#\s*include\s*"([^"\r\n]+)"',raw,re.M):
    child=posixpath.normpath(posixpath.join(posixpath.dirname(name),os.fsdecode(inc)));need(not child.startswith('../')and not child.startswith('/'),'include escapes root')
    if (SOURCE/child).is_file():pending.append(child)
    else:unresolved.append({'source':name,'include':os.fsdecode(inc),'relative':child})
  classification_raw=Path('/workspace/geo323-union-stage-tools-20261024/INCLUDE_CLOSURE_CLASSIFICATION.json').read_bytes()
  classification=json.loads(classification_raw);known=[x for x in classification['unresolved_relative_directives']if x['entry_reachable']['geometry-web/web_bridge.c']]
  expected=sorted((x['from'],x['include'],x['relative'])for x in known)
  need(sorted((x['source'],x['include'],x['relative'])for x in unresolved)==expected and len(expected)==30,'exact original guarded K fallback include directives only')
  need(sorted(selected)==classification['entry_closures']['geometry-web/web_bridge.c']['paths'],'exact original web bridge source paths')
  for x in known:
   need(x['kernel_header']in selected,'real public K header exists in private closure')
   guard=b'#ifndef '+x['guard'].encode();directive=b'#include '+b'\"'+x['include'].encode()+b'\"'
   need(guard+b'\n'+directive in selected[x['from']],'original fallback guard still present')
  report['unresolved_relative_includes']={'count':30,'classification':'Original guarded public K fallbacks; not compiler missing includes','original_classification_sha256':sha(classification_raw),'items':unresolved}
  (OUT/'INCLUDE_CLOSURE_CLASSIFICATION.original.json').write_bytes(classification_raw)
  need(sum(map(len,selected.values()))<8*1024*1024,'private closure source budget only')
  core='geometry-core/kernel/source.c';before=(DRAFT/'before.c').read_bytes();need(selected[core]==before,'K source identical at new R; do not retarget old diagnostic to changed K')
  edits=json.loads((DRAFT/'EXACT_EDITS.json').read_text());candidate=before
  for edit in edits:
   a,b=edit['before'].encode(),edit['after'].encode();need(candidate.count(a)==1,'unique forward instrumentation edit');candidate=candidate.replace(a,b,1)
  need(candidate==(DRAFT/'candidate.c').read_bytes(),'exact exact 14-edit shadow candidate')
  restored=candidate
  for edit in reversed(edits):
   a,b=edit['before'].encode(),edit['after'].encode();need(restored.count(b)==1,'unique full withdrawal edit');restored=restored.replace(b,a,1)
  need(restored==before,'entire instrumentation withdrawal restores R byte-for-byte')
  PRIVATE.mkdir();source_manifest=[]
  for name,raw in sorted(selected.items()):
   p=PRIVATE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(candidate if name==core else raw)
   need(p.stat().st_nlink==1 and (p.stat().st_dev,p.stat().st_ino)!=((SOURCE/name).stat().st_dev,(SOURCE/name).stat().st_ino),'private file cannot alias original')
   p.chmod(0o444);source_manifest.append({'path':name,'R_sha256':sha(raw),'instrumented_sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'nlink':p.stat().st_nlink})
  inc=PRIVATE/'geometry-core/kernel/geo323_shadow.inc';inc.write_bytes((DRAFT/'shadow.inc').read_bytes());inc.chmod(0o444)
  entry=PRIVATE/'diagnostic_entry.c';entry.write_bytes((DRAFT/'diagnostic_entry.c').read_bytes());entry.chmod(0o444)
  self_entry=PRIVATE/'observer_selftest_entry.c';self_entry.write_bytes((DRAFT/'observer_selftest_entry.c').read_bytes());self_entry.chmod(0o444)
  source_manifest.extend({'path':p.relative_to(PRIVATE).as_posix(),'external_only':True,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'nlink':p.stat().st_nlink}for p in(inc,entry,self_entry))
  (OUT/'SOURCE_MANIFEST.json').write_text(json.dumps(source_manifest,indent=2)+'\n');report['source_files']=len(source_manifest);report['source_bytes']=sum(r['bytes']for r in source_manifest)
  profraw=(PROFILE/'gprof-fix-64.stdout').read_bytes();(OUT/'original-R-gprof-fix-64.stdout').write_bytes(profraw)
  flat={}
  for line in profraw.decode().splitlines():
   if '['in line:continue
   columns=line.split()
   if len(columns)==7 and columns[3].isdigit():flat[columns[-1]]=int(columns[3])
  need(all(n in flat for n in('geo_source_node','geo_source_find_node','geo_source_node_hash')),'original R gprof actual source counters available')
  (OUT/'ORIGINAL_R_PROFILE_COUNTS.json').write_text(json.dumps({n:flat[n]for n in('geo_source_node','geo_source_find_node','geo_source_node_hash')},indent=2)+'\n')
  run(['gcc','--version'],HERE)
  self_binary=OUT/'observer-selftest'
  run(['gcc','-std=c11','-O1','-fno-inline','-pg',str(self_entry),'-o',str(self_binary),'-lm'],PRIVATE)
  report['selftest_binary']={'path':str(self_binary),'bytes':self_binary.stat().st_size,'sha256':sha(self_binary.read_bytes())}
  self_work=OUT/'selftest-run';self_work.mkdir();self_result=run([str(self_binary)],self_work)
  need(self_result.stdout.startswith(b'SHADOW_SELFTEST_OK:')and self_result.stderr==b'','observer selftest true normal0')
  binary=OUT/'bridge';build=run(['gcc','-std=c11','-O1','-fno-inline','-pg',str(entry),'-o',str(binary),'-lm'],PRIVATE)
  report['binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary.read_bytes())}
  soft,hard=resource.getrlimit(resource.RLIMIT_STACK);need(hard==resource.RLIM_INFINITY or hard>=16777216,'original16MiB stack available');resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard));report['stack_bytes']=16777216
  original_load=json.loads((PROFILE/'checks/profile-fix-64-load.json').read_text());need(original_load['exit']==0 and original_load['stack_bytes']==16777216,'original R load capture')
  stdin=original_load['stdin'].encode();need(stdin==b'loadfile /workspace/g337323R6/evidence/scenes/s64.scene\n','one exact original N64 input')
  scene=PROFILE/'scenes/s64.scene';report['scene']={'path':str(scene),'bytes':scene.stat().st_size,'sha256':sha(scene.read_bytes())}
  work=OUT/'run';work.mkdir();observed=run([str(binary)],work,stdin)
  original_stdout=(PROFILE/'checks/profile-fix-64-load.stdout').read_bytes();original_stderr=(PROFILE/'checks/profile-fix-64-load.stderr').read_bytes();(OUT/'original-R-load.stdout').write_bytes(original_stdout);(OUT/'original-R-load.stderr').write_bytes(original_stderr)
  need(observed.stdout==original_stdout,'instrumented stdout must equal original R byte-for-byte')
  lines=observed.stderr.splitlines(keepends=True);diags=[line for line in lines if line.startswith(b'GEO323_SHADOW ')];need(len(diags)==1,'one shadow JSON line');need(b''.join(line for line in lines if not line.startswith(b'GEO323_SHADOW '))==original_stderr,'non-observer stderr equals original F')
  diag=json.loads(diags[0][len(b'GEO323_SHADOW '):]);need(all(diag[k]==0 for k in ['errors','counter_overflow','context_overflow','family_overflow']),'observer classifications must be complete and internally consistent')
  names=['original-direct256','original-slot-2way128','provider-mixed-direct256','provider-mixed-slot-2way128'];need(diag['models']==names,'one fixed generic formula and four equal-total-capacity models')
  totals=[{}for _ in names]
  for family in diag['families']:
   need(len(family['models'])==4,'all observer models')
   for model,c in enumerate(family['models']):
    need(c['lookup']==c['hit']+c['empty_miss']+c['full_miss'],'lookup outcomes partition')
    need(c['lookup']==c['success']+c['failure'],'original return outcomes partition')
    need(c['success']==c['existing_success']+c['new_success'],'original existing/new success partition')
    need(c['hit']<=c['existing_success'],'no impossible hit on a fresh original node')
    need(c['write']==c['success']-c['hit'] and c['replacement']<=c['write'],'successful miss only writes/replaces')
    need(c['provider_mixes']==(c['lookup']if model>=2 else 0),'fixed candidate operation count; zero extra key reads')
    for k,v in c.items():totals[model][k]=totals[model].get(k,0)+v
   for model in range(1,4):
    need(all(family['models'][model][k]==family['models'][0][k]for k in ['lookup','success','failure','existing_success','new_success']),'all shadows see same actual events')
  need(totals[0]['lookup']+diag['invalid']==flat['geo_source_node'],'original F gprof node call conservation including invalid')
  need(totals[0]['lookup']-totals[0]['hit']==flat['geo_source_find_node'],'per-event original hint mirrors real find-call count')
  for matrix,key in [('replacements','replacement'),('conflict_comparisons',None)]:
   for model in range(4):
    entries=[x for x in diag[matrix]if x[0]==model]
    need(all(len(x)==4 and 0<=x[1]<len(diag['families'])and 0<=x[2]<len(diag['families'])and x[3]>0 for x in entries),'valid sparse family matrix')
    if key:need(sum(x[3]for x in entries)==totals[model][key],'replacement matrix counts real writes only')
  (OUT/'SHADOW.json').write_text(json.dumps(diag,indent=2)+'\n');(OUT/'TOTALS.json').write_text(json.dumps({'models':names,'counts':totals,'denominator':'success for hit fraction; existing_success-hit for avoidable existing misses; missing/MEMORY/invalid never success','extra_key_reads':0,'timing_inference':False},indent=2)+'\n')
  need(git('rev-parse','HEAD').decode().strip()==R and git('status','--porcelain','--untracked-files=all')==b'','original R source untouched after diagnostic')
  for name,raw in selected.items():need(sha((SOURCE/name).read_bytes())==sha(raw),'original R closure unchanged after diagnostic')
  report.update(exit=0,diagnostic_families=len(diag['families']),diagnostic_totals=totals,observer_selftest_exit=0,stdout_byte_equal=True,non_diagnostic_stderr_byte_equal=True,formal_timing_remeasured=False,source_clean_after=True)
 except BaseException:report.update(exit=1,error=traceback.format_exc())
 finally:
  report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  if OUT.exists():(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  fcntl.flock(lock,fcntl.LOCK_UN);lock.close();print(json.dumps({k:report.get(k)for k in('source_sha','exit','diagnostic_families','error')}),flush=True)
 return report['exit']
if __name__=='__main__':sys.exit(main())
