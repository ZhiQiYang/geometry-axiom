/* Observer self-test only. The original bridge is linked for the real private
 * K types; original main is never called by this independent small client. */
#define GEOMETRY_BRIDGE_ENTRYPOINT geo323_shadow_unused_bridge_main
#include "geometry-web/web_bridge.c"
#define SH_CHECK(x,label) do {if(!(x)){fprintf(stderr,"SHADOW_SELFTEST_ASSERT:%s\n",label);return 1;}}while(0)
static size_t self_slot(GeoSourceRef r)
{
    size_t v=(size_t)r.provider^r.key_size;
    if(r.key_size){const unsigned char *p=r.key;v^=p[0]^p[r.key_size-1];}
    return v&255;
}
static void self_success(GeoEvalContext *ctx,GeoSourceRef r,size_t ordinal)
{
    size_t slot=self_slot(r);ShEvent e=sh_begin(ctx,r,slot);
    ctx->node_hint[slot]=ordinal+1;sh_finish(ctx,&e,true,ordinal);
}
int main(void)
{
    unsigned char keys[4][5]={{0,1,0,0,0},{0,2,0,0,0},{0,3,0,0,0},{0,4,0,0,0}};
    GeoSourceNode nodes[4];GeoSourceNode *pointers[4];GeoEvalContext ctx;
    memset(&ctx,0,sizeof ctx);memset(nodes,0,sizeof nodes);
    for(size_t i=0;i<4;++i){nodes[i].source=(GeoSourceRef){19,keys[i],5};pointers[i]=&nodes[i];}
    ctx.nodes=pointers;ctx.node_count=4;sh_create(&ctx);
    SH_CHECK(sh_errors==0&&sh_created==1,"create-zero-mirror");
    /* Five successful lookups, with known original one-way and true LRU paths. */
    size_t sequence[5]={0,1,0,2,1};
    for(size_t i=0;i<5;++i)self_success(&ctx,nodes[sequence[i]].source,sequence[i]);
    size_t f=sh_family(nodes[0].source);ShCounts *direct=&sh_families[f].model[0],*two=&sh_families[f].model[1];
    SH_CHECK(direct->lookup==5&&direct->hit==0&&direct->replacement==4,"direct-known-sequence");
    SH_CHECK(two->lookup==5&&two->hit==1&&two->replacement==2,"two-way-LRU-known-sequence");
    SH_CHECK(sh_errors==0,"each-success-actual-ordinal");
    /* Failed original lookup must leave all four models and recency untouched. */
    ShContext old=*sh_context(&ctx);
    ShEvent failed=sh_begin(&ctx,nodes[3].source,self_slot(nodes[3].source));
    sh_finish(&ctx,&failed,false,SIZE_MAX);
    SH_CHECK(!memcmp(&old,sh_context(&ctx),sizeof old),"failure-no-cache-or-recency-write");
    for(size_t m=0;m<SH_MODEL;++m)SH_CHECK(sh_families[f].model[m].failure==1,"failure-count-all-models");
    /* Clear the shadow before freeing keys, exactly like the real instrumented clear. */
    unsigned long long generation=sh_context(&ctx)->generation;
    sh_clear(&ctx);memset(ctx.node_hint,0,sizeof ctx.node_hint);
    SH_CHECK(sh_context(&ctx)->generation!=generation&&sh_errors==0,"clear-new-generation");
    for(size_t m=0;m<SH_MODEL;++m)for(size_t i=0;i<256;++i)
        SH_CHECK(sh_context(&ctx)->ordinal[m][i]==0,"clear-all-ordinal-caches");
    /* Pointer/ordinal reuse after destroy cannot inherit another generation. */
    sh_destroy(&ctx);generation=sh_sequence;ctx.node_count=3;sh_create(&ctx);
    SH_CHECK(sh_context(&ctx)->generation>generation,"same-address-recreated");
    self_success(&ctx,nodes[0].source,0);SH_CHECK(sh_errors==0,"recreated-first-lookup");
    /* Empty key is valid: neither mix nor equality may read NULL. */
    nodes[3].source=(GeoSourceRef){19,NULL,0};
    ShEvent created=sh_begin(&ctx,nodes[3].source,self_slot(nodes[3].source));
    ctx.node_count=4;ctx.node_hint[self_slot(nodes[3].source)]=4;sh_finish(&ctx,&created,true,3);
    size_t empty_family=sh_family(nodes[3].source);
    for(size_t m=0;m<SH_MODEL;++m)SH_CHECK(sh_families[empty_family].model[m].new_success==1&&sh_families[empty_family].model[m].existing_success==0,"new-ordinal-outcome-separate");
    SH_CHECK(sh_errors==0,"empty-key-null-safe");
    GeoSourceRef mix_refs[4]={{0,NULL,0},{1,NULL,0},{2,NULL,0},{UINT32_MAX,NULL,0}};
    size_t mix_expected[4]={0,158,60,97};
    for(size_t i=0;i<4;++i)SH_CHECK(sh_mixed_slot(mix_refs[i],self_slot(mix_refs[i]))==mix_expected[i],"fixed-uint32-Knuth-provider-bucket");
    /* Intentional observer corruption is detected before unsafe dereference.
     * These are observer self-controls, not kills of a product fix. */
    size_t slot=self_slot(nodes[0].source),saved=ctx.node_hint[slot];
    ctx.node_hint[slot]=saved+1;unsigned long long before_errors=sh_errors;
    ShEvent mismatch=sh_begin(&ctx,nodes[0].source,slot);(void)mismatch;
    SH_CHECK(sh_errors>before_errors,"actual-hint-mismatch-detected");ctx.node_hint[slot]=saved;
    ShContext *s=sh_context(&ctx);size_t shadow_saved=s->ordinal[0][slot];s->ordinal[0][slot]=ctx.node_count+1;
    before_errors=sh_errors;ShEvent invalid=sh_begin(&ctx,nodes[0].source,slot);(void)invalid;
    SH_CHECK(sh_errors>before_errors,"out-of-range-shadow-ordinal-detected");s->ordinal[0][slot]=shadow_saved;
    before_errors=sh_errors;ShEvent stale=sh_begin(&ctx,nodes[0].source,slot);sh_clear(&ctx);memset(ctx.node_hint,0,sizeof ctx.node_hint);
    sh_finish(&ctx,&stale,false,SIZE_MAX);SH_CHECK(sh_errors>before_errors,"stale-generation-detected");
    sh_destroy(&ctx);
    SH_CHECK(!sh_overflow&&!sh_context_overflow&&!sh_family_overflow,"bounded-observer-selftest");
    puts("SHADOW_SELFTEST_OK: full-equality ordinals, actual-hint mirror, LRU, failure no-write, clear, reuse, null-key, detected corruptions");
    return 0;
}
