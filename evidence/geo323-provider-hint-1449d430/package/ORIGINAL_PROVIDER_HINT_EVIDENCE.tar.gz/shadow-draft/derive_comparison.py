from pathlib import Path
import json
P=Path('/tmp/geo323-shadow-hint-F-observation-20261024/execution')
d=json.loads((P/'SHADOW.json').read_bytes());t=json.loads((P/'TOTALS.json').read_bytes())
# These are named observed families, not a new numerical hotness/coldness rule.
cold=next(i for i,f in enumerate(d['families'])if(f['provider'],f['key_size'])==(16,17))
hot={i for i,f in enumerate(d['families'])if(f['provider'],f['key_size'])in[(2,4),(19,5)]}
rows=[]
for m,name in enumerate(d['models']):
 c=t['counts'][m]
 rows.append({'model':name,'hit':c['hit'],'successful_lookup_hit_fraction':c['hit']/c['success'],'existing_misses':c['existing_success']-c['hit'],'all_misses':c['lookup']-c['hit'],'nominal_memcmp_bytes':c['memcmp_requested'],'compares':c['compare'],'cold_victim_hot_incoming_replacements':sum(n for mm,a,b,n in d['replacements']if mm==m and a==cold and b in hot),'hot_victim_cold_incoming_replacements':sum(n for mm,a,b,n in d['replacements']if mm==m and a in hot and b==cold),'pose_definition_cross_replacements':sum(n for mm,a,b,n in d['replacements']if mm==m and a in hot and b in hot and a!=b)})
r={'scope':'Single instrumented F2bbe event sequence, not elapsed-time or formal performance result','models':rows,'fixed_generic_constant':2654435761,'not_measured':'Actual CPU cost; memcmp requested bytes is call-argument work, not measured memory reads. No candidate tuning/resampling.','family_labels':{'cold_named_contact_family':{'provider':16,'key_size':17,'index':cold},'hot_named_pose_definition_families':[{'provider':d['families'][i]['provider'],'key_size':d['families'][i]['key_size'],'index':i}for i in sorted(hot)],'meaning':'Labels identify the previously observed contact family with many new nodes and two frequent pose/definition families; no threshold classifies other families, and neither label asserts cacheability or elapsed-time benefit.'},'matrix_direction':'Each original replacements tuple is [model, victim_family_index, incoming_family_index, count]; conflict comparisons are not replacement events.'}
(P/'MODEL_COMPARISON.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print('Derived named-family comparison only; no subject execution')
