#define GEOMETRY_BRIDGE_ENTRYPOINT geo323_shadow_bridge_main
#include "geometry-web/web_bridge.c"
int main(void)
{
    int result=geo323_shadow_bridge_main();
    sh_dump(stderr);
    return result;
}
