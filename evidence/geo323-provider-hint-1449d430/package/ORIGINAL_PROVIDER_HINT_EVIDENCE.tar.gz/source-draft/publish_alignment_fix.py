from pathlib import Path
import hashlib,importlib.util,json,traceback
P=Path(__file__).resolve().parent
ORIGINAL=P/'publish_source.py'
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()=='52b493d03a999cd492449e54ff6f36fd2c22f92aa61fc2167b4c74cc680f94f8'
spec=importlib.util.spec_from_file_location('original_publication_capture',ORIGINAL);base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
base.OUT=Path('/tmp/geo323-provider-hint-alignment-publication-20261024')
S='81b6c388f8b73e9aaf885b1d948e5f306b77bafd'
REL='tests/geo323_provider_hint_harness.c'
base.report={'parent':S,'branch':base.BR,'source_sha':None,'source_pushed':False,'C_executed':False,'commands':[],'exit':None}
need=base.need;git=base.git
def main():
    need(not base.OUT.exists(),'fresh correction receipt');base.OUT.mkdir()
    try:
        free={n:base.shutil.disk_usage(n).free for n in ['/workspace','/tmp']};base.report['free_before']=free
        need(min(free.values())>=32*1024*1024,'same32MiB source publication guard')
        candidate=(P/'candidate'/REL).read_bytes();old=(P/'provider-harness.before-alignment-proof.c').read_bytes()
        need(base.sha(candidate)=='f510591a12d094d2e7f09342f8d07dfd6d0c10dfafe611794c5cddacb9ed71b6','reviewed alignment candidate')
        need(git('rev-parse','HEAD',cwd=base.WORK).stdout.decode().strip()==S,'original published source exact')
        need(git('symbolic-ref','--short','HEAD',cwd=base.WORK).stdout.decode().strip()==base.BR,'owned branch')
        need(git('ls-remote','--heads','origin','refs/heads/'+base.BR,cwd=base.WORK).stdout.decode().split()==[S,'refs/heads/'+base.BR],'source remote exact')
        base.clean();need(git('show',S+':'+REL,cwd=base.WORK).stdout==old,'old witness exact published bytes')
        (base.WORK/REL).write_bytes(candidate);git('add','--sparse','--',REL,cwd=base.WORK)
        need(git('diff','--cached','--name-only','-z',cwd=base.WORK).stdout==REL.encode()+b'\0','only witness alignment changed')
        git('diff','--cached','--check',cwd=base.WORK)
        need(git('show',':'+REL,cwd=base.WORK).stdout==candidate,'staged exact candidate')
        git('commit','-m','Make the source hint unaligned-key witness explicit',cwd=base.WORK)
        source=git('rev-parse','HEAD',cwd=base.WORK).stdout.decode().strip();base.report['source_sha']=source
        need(git('show','-s','--format=%P',source,cwd=base.WORK).stdout.decode().strip()==S,'normal successor parent')
        need(git('diff','--name-only','-z',S,source,cwd=base.WORK).stdout==REL.encode()+b'\0','only one source leaf changed')
        base.clean();git('push','origin','refs/heads/'+base.BR+':refs/heads/'+base.BR,cwd=base.WORK)
        need(git('ls-remote','--heads','origin','refs/heads/'+base.BR,cwd=base.WORK).stdout.decode().split()==[source,'refs/heads/'+base.BR],'public corrected source exact')
        old_manifest=json.loads(Path('/tmp/geo323-provider-hint-source-publication-20261024/SOURCE_MANIFEST.json').read_bytes())
        for row in old_manifest['entries']:
            b=(base.WORK/row['path']).read_bytes()
            if row['path']==REL:row.update(bytes=len(b),sha256=base.sha(b))
            else:need(len(b)==row['bytes'] and base.sha(b)==row['sha256'],'unchanged closure '+row['path'])
        old_manifest.update(source_sha=source)
        base.save(base.OUT/'SOURCE_MANIFEST.json',old_manifest)
        base.report.update(exit=0,source_pushed=True)
    except BaseException:base.report.update(exit=1,error=traceback.format_exc())
    finally:base.save(base.OUT/'RESULT.json',base.report);print(json.dumps({k:base.report.get(k)for k in ['source_sha','source_pushed','exit','error']},ensure_ascii=False))
    return base.report['exit']
if __name__=='__main__':raise SystemExit(main())
