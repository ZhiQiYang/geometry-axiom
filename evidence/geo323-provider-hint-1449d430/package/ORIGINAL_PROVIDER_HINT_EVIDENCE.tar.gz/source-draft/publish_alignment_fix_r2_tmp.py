"""Normal successor in a private TMP repository, read-only root object alternates.
The original S81 common worktree/index and root Git config/objects are untouched.
"""
from pathlib import Path
import hashlib,importlib.util,json,traceback
P=Path(__file__).resolve().parent;ORIGINAL=P/'publish_source.py'
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()=='52b493d03a999cd492449e54ff6f36fd2c22f92aa61fc2167b4c74cc680f94f8'
spec=importlib.util.spec_from_file_location('original_publication_capture',ORIGINAL);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=Path('/tmp/geo323-provider-hint-alignment-publication-r2-20261024')
NEW=Path('/tmp/geo323-provider-hint-private-work-20261024')
S='81b6c388f8b73e9aaf885b1d948e5f306b77bafd';REL='tests/geo323_provider_hint_harness.c'
b.report={'parent':S,'branch':b.BR,'source_sha':None,'source_pushed':False,'C_executed':False,'root_git_mutated':False,'commands':[],'exit':None}
need=b.need;git=b.git
def main():
    need(not b.OUT.exists()and not NEW.exists(),'fresh TMP receipts and private repository');b.OUT.mkdir()
    try:
        old_result=json.loads(Path('/tmp/geo323-provider-hint-alignment-publication-20261024/RESULT.json').read_bytes())
        need(old_result['exit']==1 and old_result['commands']==[] and old_result['source_sha'] is None,'R1 stopped at resource guard before any Git')
        free=b.shutil.disk_usage('/tmp').free;b.report['free_TMP_before']=free
        need(free>=32*1024*1024,'same32MiB guard, checked where all source/index/newobjects/output reside')
        source_manifest=json.loads(Path('/tmp/geo323-provider-hint-source-publication-20261024/SOURCE_MANIFEST.json').read_bytes())
        need(source_manifest['source_sha']==S,'original S81 closure')
        old=(P/'provider-harness.before-alignment-proof.c').read_bytes();candidate=(P/'candidate'/REL).read_bytes()
        need(b.sha(candidate)=='f510591a12d094d2e7f09342f8d07dfd6d0c10dfafe611794c5cddacb9ed71b6','frozen alignment candidate')
        objects=Path(git('rev-parse','--git-path','objects').stdout.decode().strip())
        if not objects.is_absolute():objects=b.ROOT/objects
        objects=objects.resolve();need(objects.is_dir(),'root immutable object lookup available')
        user=git('config','user.name').stdout.decode().strip();email=git('config','user.email').stdout.decode().strip()
        need(git('ls-remote','--heads','origin','refs/heads/'+b.BR).stdout.decode().split()==[S,'refs/heads/'+b.BR],'exact public S81 before successor')
        NEW.mkdir();git('init','--quiet',str(NEW),cwd=Path('/tmp'))
        alternate=NEW/'.git/objects/info/alternates';alternate.parent.mkdir(parents=True,exist_ok=True);alternate.write_text(str(objects)+'\n')
        b.report['read_only_object_alternates']=str(objects)
        git('config','user.name',user,cwd=NEW);git('config','user.email',email,cwd=NEW)
        git('remote','add','origin','https://github.com/ZhiQiYang/geometry-axiom.git',cwd=NEW)
        git('update-ref','refs/heads/'+b.BR,S,cwd=NEW);git('symbolic-ref','HEAD','refs/heads/'+b.BR,cwd=NEW)
        paths=sorted(x['path']for x in source_manifest['entries']);sparse=''.join('/'+x+'\n'for x in paths).encode()
        git('sparse-checkout','set','--no-cone','--stdin',cwd=NEW,data=sparse)
        need(not(NEW/'.git/index').exists()and not(NEW/'.git/index.lock').exists(),'fresh private index before read-tree')
        git('read-tree','--dry-run','-m','-u',S,cwd=NEW);git('read-tree','-m','-u',S,cwd=NEW)
        need(git('status','--porcelain=v1','--untracked-files=all',cwd=NEW).stdout==b'','new real private S81 clean')
        for row in source_manifest['entries']:
            q=NEW/row['path'];raw=q.read_bytes();need(len(raw)==row['bytes'] and b.sha(raw)==row['sha256'],'exact unchanged original closure '+row['path'])
        need((NEW/REL).read_bytes()==old,'original alignment witness bytes preserved')
        (NEW/REL).write_bytes(candidate);git('add','--sparse','--',REL,cwd=NEW)
        need(git('diff','--cached','--name-only','-z',cwd=NEW).stdout==REL.encode()+b'\0','only one staged witness')
        git('diff','--cached','--check',cwd=NEW);need(git('show',':'+REL,cwd=NEW).stdout==candidate,'exact staged bytes')
        git('commit','-m','Make the source hint unaligned-key witness explicit',cwd=NEW)
        source=git('rev-parse','HEAD',cwd=NEW).stdout.decode().strip();b.report['source_sha']=source
        need(git('show','-s','--format=%P',source,cwd=NEW).stdout.decode().strip()==S,'normal successor parent')
        need(git('diff','--name-only','-z',S,source,cwd=NEW).stdout==REL.encode()+b'\0','only one committed witness')
        need(git('status','--porcelain=v1','--untracked-files=all',cwd=NEW).stdout==b'','private corrected source clean')
        git('push','origin','refs/heads/'+b.BR+':refs/heads/'+b.BR,cwd=NEW)
        need(git('ls-remote','--heads','origin','refs/heads/'+b.BR,cwd=NEW).stdout.decode().split()==[source,'refs/heads/'+b.BR],'published exact successor')
        for row in source_manifest['entries']:
            if row['path']==REL:row.update(bytes=len(candidate),sha256=b.sha(candidate))
        source_manifest.update(source_sha=source,root=str(NEW));b.save(b.OUT/'SOURCE_MANIFEST.json',source_manifest)
        need(git('rev-parse','HEAD',cwd=b.WORK).stdout.decode().strip()==S,'old common worktree HEAD remainsS81')
        need(git('status','--porcelain=v1','--untracked-files=all',cwd=b.WORK).stdout==b'','old common worktree/index unchanged')
        b.report.update(exit=0,source_pushed=True,worktree=str(NEW))
    except BaseException:b.report.update(exit=1,error=traceback.format_exc())
    finally:b.save(b.OUT/'RESULT.json',b.report);print(json.dumps({k:b.report.get(k)for k in ['source_sha','source_pushed','exit','error']},ensure_ascii=False))
    return b.report['exit']
if __name__=='__main__':raise SystemExit(main())
