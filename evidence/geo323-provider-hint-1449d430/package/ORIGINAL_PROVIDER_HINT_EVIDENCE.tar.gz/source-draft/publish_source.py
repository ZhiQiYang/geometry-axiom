from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,traceback
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/geometry-axiom')
WORK=Path('/tmp/geo323-provider-hint-work-20261024')
OUT=Path('/tmp/geo323-provider-hint-source-publication-20261024')
F='2bbe54f19b2d19e8a816530f0c4edca950629a34'
BR='codex/train337-provider-hint-20261024'
LEAVES=['geometry-core/kernel/source.c','tests/test_geo261_source_index.py','tests/run_all.expected.json','tests/geo323_provider_hint_harness.c']
EXPECTED_MANIFEST='103b99367c835e13956386d63b8a36000e9cc84dbd4d1c8b1060658a944cb927'
report={'base_sha':F,'branch':BR,'source_sha':None,'source_pushed':False,'C_executed':False,'ledger_regenerated':False,'commands':[],'exit':None}
def sha(b):return hashlib.sha256(b).hexdigest()
def need(x,message):
    if not x:raise RuntimeError(message)
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=ROOT,data=None,allowed=(0,)):
    env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')}
    argv=['git','-c','gc.auto=0','-c','maintenance.auto=false',*args]
    d=OUT/'commands'/f'{len(report["commands"])+1:03d}';d.mkdir(parents=True)
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=cwd,input=data,capture_output=True,env=env)
    for name,body in [('stdout',p.stdout),('stderr',p.stderr)]: (d/name).write_bytes(body)
    if data is not None:(d/'stdin').write_bytes(data)
    row={'argv':argv,'cwd':str(cwd),'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'stdin_sha256':None if data is None else sha(data),'directory':str(d),'removed_environment_names':sorted(k for k in os.environ if k.startswith('GIT_'))}
    save(d/'result.json',row);report['commands'].append(row)
    need(p.returncode in allowed,'actual Git failure: '+str(d));return p
def clean():
    need(git('status','--porcelain=v1','--untracked-files=all',cwd=WORK).stdout==b'','owned worktree clean')
    need(git('diff','--cached','--exit-code','--name-status','HEAD',cwd=WORK).stdout==b'','no staged changes')
    need(git('diff','--exit-code','--name-status',cwd=WORK).stdout==b'','no working changes')
def main():
    need(not OUT.exists()and not WORK.exists(),'fresh output and own worktree required')
    OUT.mkdir();save(OUT/'START.json',report)
    try:
        free={n:shutil.disk_usage(n).free for n in ['/workspace','/tmp']};report['free_before']=free
        need(min(free.values())>=32*1024*1024,'unchanged32MiB source publication guard on index/source filesystems')
        raw=(HERE/'MANIFEST.json').read_bytes();need(sha(raw)==EXPECTED_MANIFEST,'frozen four-leaf manifest')
        m=json.loads(raw);need(m['base_sha']==F and m['changed']==LEAVES,'exact base and four leaves')
        for rel in LEAVES:
            b=(HERE/'candidate'/rel).read_bytes();need(sha(b)==m['files'][rel]['sha256'] and len(b)==m['files'][rel]['bytes'],'accepted candidate '+rel)
        need(git('rev-parse',F+'^{commit}').stdout.decode().strip()==F,'base real commit')
        need(git('ls-remote','--heads','origin','refs/heads/'+BR).stdout==b'','new owned remote branch absent')
        need(git('show-ref','--verify','--quiet','refs/heads/'+BR,allowed=(0,1)).returncode==1,'new owned local branch absent')
        raw_tree=git('ls-tree','-r','-z',F,'geometry-core/kernel').stdout
        entries={}
        for line in raw_tree.rstrip(b'\0').split(b'\0'):
            meta,path=line.split(b'\t');mode,kind,oid=meta.split();name=path.decode()
            if Path(name).suffix in ['.c','.h','.inc']:
                need(mode==b'100644'and kind==b'blob','ordinary exact K input');entries[name]=oid.decode()
        for rel in ['tests/__init__.py','tests/test_geo261_native_kernel.py','tests/test_engineering_json.py','tests/_bridge.py','tests/binaries.py','tests/geo261_exact_harness.c','tests/geo261_source_index_harness.c','tests/_unittest_runner.py','tests/test_geo261_source_index.py','tests/run_all.expected.json']:
            entries[rel]=git('rev-parse',F+':'+rel).stdout.decode().strip()
        for rel in LEAVES[:-1]:
            b=git('show',F+':'+rel).stdout
            need(b==(HERE/'before'/rel).read_bytes(),'draft exact published base '+rel)
        sparse=''.join('/'+name+'\n'for name in sorted(set(entries)|set(LEAVES))).encode()
        (OUT/'SPARSE_STDIN.txt').write_bytes(sparse)
        git('worktree','add','--no-checkout','-b',BR,str(WORK),F)
        need(sorted(x.name for x in WORK.iterdir())==['.git'],'fresh worktree only .git link')
        need(git('rev-parse','HEAD',cwd=WORK).stdout.decode().strip()==F,'new HEAD exact base')
        need(git('symbolic-ref','--short','HEAD',cwd=WORK).stdout.decode().strip()==BR,'only owned branch')
        index=Path(git('rev-parse','--git-path','index',cwd=WORK).stdout.decode().strip())
        if not index.is_absolute():index=WORK/index
        need(not index.exists()and not Path(str(index)+'.lock').exists(),'fresh absent index, no writer')
        git('sparse-checkout','set','--no-cone','--stdin',cwd=WORK,data=sparse)
        need(not index.exists(),'sparse setup has not fabricated tracked deletions')
        git('read-tree','--dry-run','-m','-u',F,cwd=WORK)
        git('read-tree','-m','-u',F,cwd=WORK);clean()
        closure=[]
        for name,oid in sorted(entries.items()):
            q=WORK/name;b=q.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
            need(actual==oid and q.is_file()and not q.is_symlink(),'actual exact base input '+name)
            closure.append({'path':name,'base_blob':oid,'bytes':len(b),'sha256':sha(b)})
        need(sum(x['bytes']for x in closure)<8*1024*1024,'thin actual source budget')
        save(OUT/'BASE_CLOSURE.json',closure)
        for rel in LEAVES:
            q=WORK/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((HERE/'candidate'/rel).read_bytes())
        git('add','--sparse','-f','--',*LEAVES,cwd=WORK)
        need(set(git('diff','--cached','--name-only','-z',cwd=WORK).stdout.rstrip(b'\0').decode().split('\0'))==set(LEAVES),'exact four staged leaves')
        git('diff','--cached','--check',cwd=WORK)
        for rel in LEAVES:need(git('show',':'+rel,cwd=WORK).stdout==(HERE/'candidate'/rel).read_bytes(),'staged candidate exact '+rel)
        git('commit','-m','Reduce source hint collisions with a generic provider bucket',cwd=WORK)
        source=git('rev-parse','HEAD',cwd=WORK).stdout.decode().strip();report['source_sha']=source
        need(git('show','-s','--format=%P',source,cwd=WORK).stdout.decode().strip()==F,'ordinary one-parent source commit')
        clean()
        for rel in LEAVES:need(git('show',source+':'+rel,cwd=WORK).stdout==(HERE/'candidate'/rel).read_bytes(),'committed candidate exact '+rel)
        git('push','origin','refs/heads/'+BR+':refs/heads/'+BR,cwd=WORK)
        need(git('ls-remote','--heads','origin','refs/heads/'+BR,cwd=WORK).stdout.decode().split()==[source,'refs/heads/'+BR],'source publicly resolvable')
        report.update(source_pushed=True,exit=0,worktree=str(WORK),source_closure_count=len(closure)+1)
        final=[]
        for name in sorted(set(entries)|set(LEAVES)):
            b=(WORK/name).read_bytes();final.append({'path':name,'bytes':len(b),'sha256':sha(b)})
        save(OUT/'SOURCE_MANIFEST.json',{'source_sha':source,'root':str(WORK),'entries':final,'clean':True,'C_executed':False})
    except BaseException:report.update(exit=1,error=traceback.format_exc())
    finally:save(OUT/'RESULT.json',report);print(json.dumps({k:report.get(k)for k in ['source_sha','source_pushed','exit','error']},ensure_ascii=False))
    return report['exit']
if __name__=='__main__':raise SystemExit(main())
