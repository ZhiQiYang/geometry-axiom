"""Run all three original suites on one public source, keeping all red results."""
from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,resource,shutil,sys,traceback
HERE=Path(__file__).resolve().parent;PUB=Path('/tmp/geo323-provider-related-preparation-20261024')
ROOT=Path('/tmp/geo323-provider-hint-private-work-20261024');OUT=Path('/tmp/geo323-provider-related-formal-20261024');TMP=Path('/tmp/geo323-provider-related-formal-tmp-20261024');OBS=HERE/'observer'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
SUITES=[('native-sources','tests/test_geo261_native_sources.py',9),('describe','tests/test_geo261_source_describe.py',7),('context','tests/test_geo261_source_context.py',8)]
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def readj(p):return json.loads(p.read_bytes())
def main():
 need(not OUT.exists() and not TMP.exists(),'fresh formal directories');need(shutil.disk_usage('/tmp').free>=100*1024*1024,'original100MiB guard')
 pub=readj(PUB/'RESULT.json');need(pub['exit']==0 and json.loads(Path('/tmp/geo323-provider-hint-alignment-publication-r2-20261024/RESULT.json').read_bytes())['source_pushed'] is True,'public fixed source required');S=pub['source_sha'];manifest=readj(PUB/'SOURCE_MANIFEST.json');need(manifest['source_sha']==S,'manifest exact source')
 need(S=='1449d430d1c4734bb1bc3a9f91f3851c845cc0f3','fixed reviewed public source')
 need(len(manifest['files'])==213,'exact fixed213 closure')
 need(sha((OBS/'TOOL_PINS.json').read_bytes())=='217886aeee4107c7a55c8ff9a44546d00db662b2c15e4df195cae99d0203cf01','accepted bound observer manifest')
 pins=readj(OBS/'TOOL_PINS.json')
 for item in pins['tools']:need(sha((OBS/item['name']).read_bytes())==item['bound_sha256'],'bound observer pin '+item['name'])
 need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','original capture')
 lock=Path('/tmp/g261r3/secondary.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 OUT.mkdir();TMP.mkdir();stack=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,stack[1]))
 strip={'PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','PYTHONOPTIMIZE','PYTHONINSPECT','LD_PRELOAD','LD_LIBRARY_PATH','CC','CFLAGS','CPPFLAGS','LDFLAGS','CPATH','C_INCLUDE_PATH','COMPILER_PATH','LIBRARY_PATH','GCC_EXEC_PREFIX'}
 env={k:v for k,v in os.environ.items() if k not in strip and not k.startswith(('GIT_','GEOMETRY_','MUTATE_','GEO299316_','GEO261_CONTACT_','GEO318_'))};env.update(TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(ROOT),LANG='C.UTF-8',LC_ALL='C.UTF-8')
 spec=importlib.util.spec_from_file_location('capture',CAP);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);rec=cap.Recorder(OUT,env,S)
 report={'source_sha':S,'root':str(ROOT),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'suites':[],'secondary_lock':'/tmp/g261r3/secondary.lock','stack_before':stack,'stack_after':resource.getrlimit(resource.RLIMIT_STACK),'full_native':False,'ledger_regenerated':False,'performance':False,'errors':[],'exit':None}
 def git(*args):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=ROOT)[1]
 def guard():
  need(git('rev-parse','HEAD').decode().strip()==S,'fixed HEAD');need(git('status','--porcelain=v1','--untracked-files=all')==b'','fixed clean checkout')
  for name,pin in manifest['files'].items():need(sha((ROOT/name).read_bytes())==pin,'fixed closure '+name)
 try:
  rec.run(['df','-B1','/workspace','/tmp'],cwd=ROOT);guard();dump(OUT/'SOURCE_MANIFEST.json',manifest)
  for label,target,count in SUITES:
   if shutil.disk_usage('/tmp').free<100*1024*1024:report['suites'].append({'label':label,'state':'UNRUN_ENVIRONMENT','passed':False,'reason':'original100MiB disk guard'});continue
   where=OUT/label;where.mkdir();guard();dump(where/'manifest.json',{'source_sha':S,'source_variant':'fixed','files':manifest['files']})
   argv=[sys.executable,'-B',str(OBS/'run_observed_original.py'),'--root',str(ROOT),'--sha',S,'--out',str(where/'observed'),'--manifest',str(where/'manifest.json'),'--','tests/_unittest_runner.py',target,'--json-out',str(where/'runner.json'),'--log',str(where/'unittest.log')]
   row,stdout,stderr=rec.run(argv,cwd=ROOT,timeout=None,check=False);result={'label':label,'target':target,'state':'COMPLETED','source_sha':S,'actual_exit':row['actual_process_returncode'],'expected_methods':count,'command':row,'passed':False}
   try:
    detail=readj(where/'runner.json');entry=readj(where/'observed/ORIGINAL_ENTRY.json');observation=readj(where/'observed/OBSERVATION.json')
    result.update(runner=detail,entry=entry,observation=observation)
    complete=entry['observer_complete'] is True and observation['observer_complete'] is True and entry['original_completed'] is True and entry['original_exit']==row['actual_process_returncode'] and entry['source_sha']==observation['source_sha']==S and entry['source_files_before']==entry['source_files_after']==manifest['files']
    result['observation_complete']=complete;result['passed']=complete and row['actual_process_returncode']==0 and detail['total']==detail['run']==detail['passed']==count and all(detail.get(k,0)==0 for k in ['failed','skipped','extra_errors','blocked_by_error','expected_failed']) and detail['import_error'] is None
   except BaseException:result['evidence_error']=traceback.format_exc()
   report['suites'].append(result);dump(where/'RESULT.json',result);dump(OUT/'PROGRESS.json',report);print(json.dumps({'suite':label,'exit':result['actual_exit'],'passed':result['passed']}),flush=True)
  guard();report['source_clean_after']=True;report['exit']=0 if len(report['suites'])==3 and all(x['passed']for x in report['suites']) else 1
 except BaseException:report['errors'].append(traceback.format_exc());report['exit']=1
 finally:
  report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dump(OUT/'RESULT.json',report);fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
 return report['exit']
if __name__=='__main__':sys.exit(main())
