from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
ROOT=Path('/tmp/geo323-provider-hint-private-work-20261024');OUT=Path('/tmp/geo323-provider-related-preparation-20261024');S='1449d430d1c4734bb1bc3a9f91f3851c845cc0f3'
CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(x):return hashlib.sha256(x).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
need(not OUT.exists(),'fresh preparation');need(shutil.disk_usage('/tmp').free>=100*1024*1024,'original100MiB actual filesystem resource guard')
need(sha(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762','capture pin')
OUT.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')};env['PYTHONDONTWRITEBYTECODE']='1'
spec=importlib.util.spec_from_file_location('capture',CAP);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);rec=c.Recorder(OUT,env,S)
def git(*argv,input=None):return rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*argv],cwd=ROOT,data=input)[1]if input is not None else rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*argv],cwd=ROOT)[1]
r={'source_sha':S,'root':str(ROOT),'formal_executed':False,'exit':None}
try:
 need(git('rev-parse','HEAD').decode().strip()==S,'same S');need(git('status','--porcelain=v1','--untracked-files=all')==b'','clean')
 paths=json.loads(Path('/tmp/geo323-provider-related-paths.json').read_bytes());need(len(paths)==213,'exact213 closure')
 # Use original git blobs at fixed S; R6 metadata supplies names only.
 files={};total=0
 for name in paths:
  body=git('show',S+':'+name);files[name]=sha(body);total+=len(body)
 patterns=''.join('/'+n+'\n'for n in paths).encode()
 # Recorder's input argument is validated before execution below.
 row,out,err=rec.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','set','--no-cone','--stdin'],cwd=ROOT,data=patterns)
 for name,pin in files.items():need(sha((ROOT/name).read_bytes())==pin,'materialized Gitbytes '+name)
 need(git('rev-parse','HEAD').decode().strip()==S,'same S after');need(git('status','--porcelain=v1','--untracked-files=all')==b'','clean after')
 r.update(files=files,source_bytes=total,exit=0);dump(OUT/'SOURCE_MANIFEST.json',{'source_sha':S,'files':files,'source_bytes':total})
except BaseException as e:r.update(exit=1,error=repr(e));raise
finally:dump(OUT/'RESULT.json',r)
