"""Run the original nine-method suite; retain its existing NativeBuild logs.

Adapted from the previously reviewed Reading A audit hook. The hook only
copies existing logs and compiled C inputs before temporary cleanup. No
product, subprocess, compiler, test, timeout or return-value interception.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import runpy
import sys

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--artifacts',type=Path,required=True)
    args=parser.parse_args()
    root=args.root.resolve();out=args.artifacts.resolve();out.mkdir(parents=True,exist_ok=False)
    if Path.cwd().resolve()!=root:raise RuntimeError('exact subject cwd required')
    tmp=Path(os.environ['TMPDIR']).resolve();records=[]
    def audit(event,values):
        if event!='shutil.rmtree' or not values:return
        path=Path(os.fsdecode(values[0]))
        if not path.is_absolute():return
        path=path.resolve()
        if not path.is_relative_to(tmp) or not path.name.startswith('geo261-n1a-'):return
        log=path/'build-log.json'
        if not log.is_file():return
        raw=log.read_bytes();target=out/(path.name+'-build-log.json');target.write_bytes(raw)
        sources=[];seen=set()
        for row in json.loads(raw):
            for value in row['arguments']:
                original=Path(value)
                if not original.is_absolute() or original.suffix!='.c' or not original.is_file() or not original.is_relative_to(path) or str(original) in seen:continue
                seen.add(str(original));body=original.read_bytes();dest=out/path.name/'compiled-source'/original.relative_to(path)
                dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
                sources.append({'original':str(original),'retained':str(dest),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
        records.append({'original':str(log),'retained':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compiled_sources':sources,'before_event':'shutil.rmtree','scope':'original NativeBuild commands/text stdout/stderr and actual compiled C diagnostics, no interception'})
        (out/'retention.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    sys.addaudithook(audit)
    target='tests/test_geo318_reading_a_native.py'
    sys.path[0]=str(root/'tests')
    sys.argv=[target]
    runpy.run_path(target,run_name='__main__')

if __name__=='__main__':main()
