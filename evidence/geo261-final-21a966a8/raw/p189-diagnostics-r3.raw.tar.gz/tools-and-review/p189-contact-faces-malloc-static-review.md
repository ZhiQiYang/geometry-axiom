# Contact faces scratch 配置靜態審查

結論：支持僅將 `wood_contact_source_collection()` 的 faces 暫存配置從 `calloc(q->cap,sizeof *faces)` 改成 `malloc(q->cap*sizeof *faces)`，進行獨立效能量測。沒有找到讀取未初始化欄位的分支。本審查只讀 Git 來源並製作 repo 外報告，未改 root、未編譯、未跑測試或效能。

## 初始化與讀取範圍

1. `wood_contact_collect_stops()` 由 `count=0` 起，boundary／hole 與兩個方向的 member side 都用完整 `WoodStopFace` compound literal，依序寫滿 `out[0..count)`；每筆的九個 scalar 欄位全部有值。
2. boundary loop 只在 `count<cap` 追加，member 只在 `count+2<=cap` 成對追加；facts 已先驗證 component／hole／vertex／member 上限。沒有跳過寫入卻增加 count 的分支。
3. insertion sort 的 `i<count`、`j-1<i` 僅讀已初始化 prefix；struct assignment 重排同一個 prefix。去重的 `j<count` 與 `memmove(...,(count-i-1)*sizeof *out)` 也僅取當時 prefix，刪除後仍保持連續初始化範圍。
4. `wood_contact_source_encode_face()` 只逐欄編碼九個 scalar，呼叫只對 `i<count`。不會讀 allocation 尾部、不按 struct raw bytes 序列化、不讀 padding，因此不依賴 calloc 的全零 backing bytes。
5. cap0 仍給 faces=NULL；collector 的所有追加／排序／去重迴圈都不讀 faces，count0 只編碼八 byte 的 count。facts callback 依舊執行，來源依賴不減少。

## 配置與失敗

query 的唯一建構入口 `wood_contact_sources_collect()` 將 cap clamp 至 `WOOD_CONTACT_FACE_CAPACITY`；現有數值為 `8*32*(8+1)+64*2 = 2432`。在 root 指定的 48 byte struct ABI，最大乘積 116736 byte，受支援 Linux／Windows 32／64-bit size_t 不會溢位。程式沒有顯式 `SIZE_MAX/sizeof` 防溢位斷言；此結論依現有固定容量與受支援 ABI，不擴張成任意 16-bit C 的保證。

配置位置及數量不變：先 facts，再有 cap 才配置 faces，再 facts callback／validity、collector、輸出 bytes。faces 配置失敗仍在同一分支 free(facts)/free(faces) 後返回；callback 失敗、invalid facts、bytes 配置失敗的處理也不變。query identity、插入、sequence、失敗狀態及 collection 發布時點都維持原流程。

**allocator 函式種類刻意不同**，不能聲稱對任意 malloc/calloc interposition 的失敗事件完全相同；例如只攔第 n 次 calloc 的外部工具會看到差異。現有八個 contact source 控制沒有這種攔截，K source-index 的必要配置控制只針對 source.c，不經此檔。產品的 source calls、facts callback 次數及相對時點均不變。

`WoodContactSourceFacts` 有公開 zero-init hook 契約，必須繼續 calloc。此候選也不改 `result` 的 calloc。

## 既有負控

原八個 control 的 before anchor 以 AST literal 讀出並與 Git source 比對；原版與這一行候選均各恰好一處。FEATURE instrumentation 不在 allocation 行，因此不受此候選影響。逐一結果、來源 SHA／hash 及候選 hash 在同名 `.json`；這只是錨點靜態檢查，尚不是八個 control 已執行或已 killed 的收據。
