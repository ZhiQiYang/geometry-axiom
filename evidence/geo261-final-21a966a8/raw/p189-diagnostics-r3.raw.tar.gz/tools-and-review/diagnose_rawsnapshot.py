"""原時點 raw 幾何快照候選的三方診斷；不是最終 SHA 驗收。"""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys

repo = Path('/workspace/geometry-axiom')
root = Path('/tmp/g261rawsnapshot')
original = Path('/tmp/g261p3/tools/p189-551b00f6/provenance.json')
provenance = json.loads(original.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
changed = git('diff', '--name-only').decode().splitlines()
assert changed == ['current_geometry.c', 'geometry-app/native/reference_sources.inc', 'geometry-core/kernel/source.c', 'geometry-templates/woodworking/native/contact_sources.c', 'tests/geo261_definition_sources_harness.c', 'tests/test_geo261_definition_sources.py'], changed
out = root/'timing'
assert not out.exists()
out.mkdir()
work = root/'work'
work.mkdir()
candidate = root/'candidate'
candidate.mkdir()
shutil.copy2(root/'candidate-bridge', candidate/'bridge')
sides = {'main':Path('/tmp/g261p3/work/p189-551b00f6/main'),
         'old':Path('/tmp/g261contactmalloc/candidate'), 'candidate':candidate}
assert digest(sides['main']/'bridge') == provenance['binaries_sha256']['main']
old = json.loads(Path('/tmp/g261contactmalloc/timing/provenance.json').read_text())
assert digest(sides['old']/'bridge') == old['binaries_sha256']['candidate']
source = repo/changed[0]
(out/'source.patch').write_bytes(git('diff', '--binary'))
for name in changed:
    target = out/'source-snapshot'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((repo/name).read_bytes())
record = {'purpose':'候選診斷，不能替代新最終 SHA 的完整 P-189',
          'base_head':git('rev-parse', 'HEAD').decode().strip(), 'dirty_paths':changed,
          'source_sha256':digest(source), 'patch_sha256':digest(out/'source.patch'),
          'reference_shas':provenance['shas'],
          'old_candidate_provenance':'/tmp/g261contactmalloc/timing/provenance.json',
          'old_candidate_provenance_sha256':digest(Path('/tmp/g261contactmalloc/timing/provenance.json')),
          'old_is_dirty_hashword_hint_malloc_with_eager_raw_geometry':True,
          'binaries_sha256':{name:digest(path/'bridge') for name,path in sides.items()},
          'timing_driver_sha256':digest(Path('/tmp/g261r1/tools/scale_compare2.py'))}
args = [sys.executable, '/tmp/g261r1/tools/scale_compare2.py', str(work), str(out),
        *[name+'='+str(path) for name,path in sides.items()], '--ns','16,32,48,64',
        '--reps','3','--gen','/tmp/g261r1/tools/gen_scene.py']
record['source_hashes'] = {name:digest(repo/name) for name in changed}
record['command'] = args
(out/'provenance.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
result = subprocess.run(args, check=False)
record['timing_exit'] = result.returncode
with (out/'samples.tsv').open() as stream:
    rows = list(csv.DictReader(stream, delimiter='\t'))
assert len(rows) == 36 and all(r['status']=='ok' and r['ok']=='True' for r in rows)
ratios = []
for n in (16,32,48,64):
    medians = {}
    for label in sides:
        selected = [row for row in rows if row['n']==str(n) and row['side']==label]
        assert len(selected)==3 and {row['round'] for row in selected}=={'0','1','2'}
        medians[label] = statistics.median(float(row['seconds']) for row in selected)
    ratios.append({'n':n, 'medians':medians, 'candidate_main':medians['candidate']/medians['main'],
                   'candidate_old':medians['candidate']/medians['old']})
record['ratios'] = ratios
record['eligible_under_existing_p189_limit'] = result.returncode==0 and all(r['candidate_main']<=2 for r in ratios)
(out/'diagnosis.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(record, ensure_ascii=False), flush=True)
raise SystemExit(0 if record['eligible_under_existing_p189_limit'] else 1)
