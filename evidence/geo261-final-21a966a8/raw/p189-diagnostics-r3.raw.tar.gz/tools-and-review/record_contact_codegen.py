"""保存非 pg 既有受量測二進位的實際編解碼組譯，不執行產品。"""
import hashlib
import json
from pathlib import Path
import subprocess

binary = Path('/tmp/g261rawsnapshot/candidate-bridge')
out = Path('/tmp/g261-contact-codegen')
out.mkdir(exist_ok=False)
rows=[]
for name in ('wood_contact_source_ref','wood_contact_source_decode','wood_grid_source_ref','wood_definition_source_ref'):
    argv=['objdump','-d','--disassemble='+name,str(binary)]
    result=subprocess.run(argv,capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    rows.append({'command':argv,'exit_code':result.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'})
data={'diagnostic_only':True,'product_executed':False,'binary':str(binary),
      'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
      'binary_provenance':'/tmp/g261rawsnapshot/timing/provenance.json','records':rows}
(out/'receipt.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(data,ensure_ascii=False))
raise SystemExit(0 if all(row['exit_code']==0 for row in rows) else 1)
