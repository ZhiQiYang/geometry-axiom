# 固定8byte grid codec 大端序載入：靜態評估

repo外候選，未改root、未編譯、未測試或量測。patch SHA256 `3e2d0cf73542b74ca354e8776a09bd5db47e0e2d8c3c2f31e81a2f65f1a4e7fc`。只改 `wood_grid_codec_u64`，固定8次shift loop改成明示8個byte、各先cast uint64_t再shift0..56的OR式。

對原reader合法狀態0≤offset≤size，bounds guard完全逐字相同。可用bytes不足8時立即false，offset/out都不改；足8時同讀offset..offset+7，只在最後offset+=8及寫out，最後狀態同原8次offset++。因剩餘≥8且size≤SIZE_MAX，offset+8不溢位。原loop迭代所得sum(bytes[j]×2^(56-8j))正好就是新OR式；每byte占獨立8bit，OR等於sum，沒有int promotion或signed shift。

使用unsigned char逐byte存取，沒有uint64_t pointer cast、unaligned load要求、strict-aliasing或主機端序假定；GCC是否融合load+bswap屬最佳化機會，尚未看新assembly。原reader/out的非NULL前提與offset invariant不變；沒有順手增加invalid guard或改原失敗判準。所有public decoder的local temporary→成功才賦out原樣。

原codec測試有15個負控（非8），`static-control-audit.json` 以AST抽controls文字，只比對target function body和錨點：15/15 body原樣且原anchor各唯一。沒有執行tests。原測試的authored/derived/scalars/malformed/bounds/system-value/application-value/atomic八個case全應重跑，十五個negative exactASSERT都仍須各紅且恢復綠；可再以highbit/每byte不同值、offset未對齊、截斷0..7、最大/最小signedscalar做原新差分。

重要：不能用原O2 profile的wood_grid_codec_axis833,056calls/3.64%作此候選收益根據。callgraph列reference_contact_facts→axis685,575、reference_member_footprint→axis141,429，但這兩H並不呼叫gridcodec；其和827,004恰是原geo_box_face呼叫數。真正gridaxis caller是decode_application4,192與decode_application_value1,860，共6,052，原profile在這裡很可能重現support_coord_compare/find_node的符號歸因混淆。故這只是極小可測候選，不應外推有明顯收益。

更可靠相同形狀熱點：contact_sources.c固定BE64 helper被wood_contact_source_decode使用；原O2該public decode453,052call，describe/evaluate各226,526與原碼直接呼叫吻合，每次兩次BE64，另feature coord與collection view也讀BE64。可另測該helper，保持兩候選分開。
