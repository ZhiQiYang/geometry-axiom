# 本次 contact callback 的 raw footprint 純計算延後

狀態：repo 外提案。未改 root、未編譯、未測試、未量測、未 commit/push。BOX 候選已由 root 撤回，本候選不帶任何 BOX helper。patch SHA256：`fb1e008d132189effefe5168dbc9affcac0aa72893373b28c2fefbd32700809c`。

## 改動邊界

只改 `current_geometry.c` 與 `geometry-app/native/reference_sources.inc`。前者 CRLF 保留，新增31行。原 `app_contact_facts` 成為傳 NULL 的薄 wrapper；原 body 移至 `app_contact_facts_prepare`，NULL 路徑仍在原 member 迴圈完整計算 raw footprint，原使用者全部維持此路徑。只有 `reference_contact_facts` 的 source 模式傳入當次局部 snapshots，先保留同樣 metadata 和 pure raw 需要的 scalar，沒有跨 consumer/source eval 的值快取。

snapshot 每 member 保存原時點的 placed、length、size_a、anchor UV、length direction、depth side。不是 WoodMember/WoodMemberPlacement 的整份 copy，也不保存指向 live anchor 的替代指標。placement 已是 callback 的 local copy，整段計算只讀同一 frame。placed=false 時原 raw wrapper 不讀其餘 raw 輸入，snapshot 也不讀。置於 source callback stack 的64個 snapshot 各約48bytes（常見本環境 ABI），不新增 heap allocation、容量或資料庫生命週期。

保持原 typed member iteration、identity、order、metadata、source calls 與原 guard 順序。僅在成功 typed face 已確實寫入整個 footprint 後放棄 raw 純計算；若來源成功但 live placed 被 provider 改 false，face helper 回 false，仍須還原原 raw rectangle 並保留 footprint_valid=false。

## 三狀態與 partial output

每 snapshot 的 pending：

| 狀態 | 意義 | callback 返回前行為 |
| --- | --- | --- |
| 0 | 尚未暴露於 out、已恢復，或 typed face 已完整覆寫 | 不寫 |
| 1 | 已複製原 member fact，raw rectangle/valid 尚未計算 | 從 scalar snapshot 補 rectangle 與 valid |
| 2 | foreign placement 或 typed face false 已把 valid 改 false，但 coords 仍應是原 raw | 只補 rectangle，保留 valid=false |

原函式先在 private AppContactFacts 建立全量 raw，但只在迴圈訪問 i 時才 `*fact=facts.members[i]`。如果第 i 的 definition 或 pose 失敗，out 的已寫入範圍僅至 i（含）；tail i+1 之後仍是 caller 原 bytes。候選維持此逐項 assignment，所有 flush 限 visited prefix，不能以「修完整 partial」為由寫 tail。region_count/regions/member_count 的寫入順序原樣；host_read 失敗仍完全不碰 out。

若先前 nested provider 改 World，raw 仍用進入來源 member loop 前的 scalar snapshot，與原提前計算時點相同；metadata 也仍在 prepare 時以原 live pointer/anchor 值填入。原迴圈對 placed 的判斷仍讀當下 `fact->member->placed`，pose 後 `WoodMember geometry=*fact->member` 也不改，兩者都不能用 snapshot placed 取代。

| 分支 | 原輸出 | 候選對應 |
| --- | --- | --- |
| 初始 unplaced／excluded | t0 raw（可能 false+zero） | pending1，返回前補 |
| anchor definition 失敗 | i的 t0 raw及原metadata；tail untouched | 失敗前 flush visited，pending1 |
| typed anchor 指到 foreign placement | t0 raw coords，valid=false | pending2 |
| pose失敗 | i的 t0 raw及已更新typed anchor metadata；tail untouched | 失敗前 flush visited，pending1 |
| pose成功，provider後置placed=false | t0 raw coords，valid=false | face false→pending2 |
| pose成功，face true | actual BOX/frame 完整覆寫 rectangle+valid=true | pending0，不算raw |
| 原 snapshot/current-values 模式 | 原 raw validity先守門再決定pose eval | entry傳NULL，原路徑；若sourcecallback途中ctx臨時切current，原guard前materialize該i |

restore 仍呼叫原 `a0_rect_uv`，保留 length<=0、axis dot==1、depth 只有 POS 值走正向、所有其他 depth 值走反向、原乘加分組和相同 min/max。raw false 時不寫矩形，所以零初始化仍與原一致。沒有新數值門檻或 frame 拒絕。對原計算本已 signed overflow 的輸入不建立新契約；在原定義域內，只有純計算的時點改變，輸入值及算式相同。

## 中途可觀察性／alias 範圍

獨立唯讀 call graph 複核：

- `contact_sources.c:92` 為 collection 以 calloc 建立當次新 facts，只在 callback 返回後驗證及收集，失敗即free。
- `app_reference_end_stops` 用 local `AppReferenceContactResolve.facts`，原 target->members 只在 callback 成功返回後才刷新。
- ReferenceEval 沒有本次 facts/out 指標；WoodContactQuery 也沒有 facts 指標；nested provider只取得 ctx/graph/source/value，沒有產品路徑取得本次 out address。

因此既有產品流程只在 callback 返回後觀察 facts，本候選將 raw 物化至返回前符合該契約。不能泛稱「任何C caller/alias都等價」：如果測試刻意把 out 放在可被 nested provider 讀取的 global，provider可觀察到中途尚未補 raw；此不是現行產品 caller。正式測試仍應保留 canary caller、所有失敗prefix/tail bytes，不能以產品 calloc 為藉口省掉失敗可觀察性。

## 必要自證與驗收

應做原/候選完整 WoodContactSourceFacts 差分，包含非零 caller canary、所有可返回prefix和tail，逐具名欄位及 bytes；可同時比較 padding，因每個已訪問 fact 皆以原 memset facts 做完整struct assignment，tail不寫。另比 World狀態、ordered sourcecall transcript、node/edge counters、error status及 sourcefailure。

場景至少覆蓋：全部 members（含 foreign/excluded/unplaced）和 invalid direction/length/depth、negative size、current-values raw拒絕、first/middle/last definition或pose失敗、provider在前一/當前eval改未來member anchor/length/placed、provider把placed true→false及false→true、duplicate IDs/order、all64。shape/input validity門檻不得改。

具名負控可令 restore 讀 live World length/anchor（snapshot破壞）、把 pending2 當1（foreign/facefalse valid被錯恢復）、flush全member_count而非visited（tail canary破壞）、在pose success但facefalse時直接pending0（rawcoords丟失）；均需紅在正確具名 oracle，恢復後綠。將整個候選撤回會恢復原等價功能，因此功能差分不應變紅；效能自證則需要原P-189三方交錯 withdraw/fix 比較和固定2×門檻。

## 字面錨點、收據與風險

`static-anchor-audit.json` 僅做文字檢查：原 live placed/exclude guard、narrow placement source、current-values validity guard、pose VALUE_REQUIRED、postsource WoodMember copy、wood_member_face_room 呼叫各保留一份且同序；M27深度literal也仍唯一。沒有改任何 tests 或 ledger。

若採用要執行 `mutate.py --check` 判帳本過期；current_geometry.c 已是原帳本常見輸入，不能假定既有ledger仍有效。架構重產必須加入此新增 H source 變更；當時還有 W narrow definition c/h、Hreference、Ksource 改動，累計來源集合應由最終 git diff 和 manifest 決定，不能沿用 BOX候選的六檔清單（BOXc/h已撤回）。

最大風險是額外 snapshot/狀態管理、一次 final prefix loop、prepare wrapper 成本抵銷 raw arithmetic 節省；目前沒有量測證據。原 raw footprint熱點約7.84%（root後續profile），只會省掉真正被typedface成功覆寫者；remaining raw一個也不能少算。此候選是否足以把N64從約2.075降到≤2，需root排他原三方量測。
