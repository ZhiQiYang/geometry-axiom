# BOX 面投影候選：靜態等價與風險

狀態：只讀提案；本代理未改 root、未編譯、未執行測試或效能量測。root 已自行套用候選並排程量測。不能由此文件宣稱 P-189 已修復。

`candidate.patch` SHA256：`4d6456c2b373e65b14ef3958555716470132372efbd1ff134e6ef7cecbe82f21`。三檔 baseline/candidate SHA256 在 metadata.json。核對時 root 已套用，三檔與 candidate 完全相同，詳 ready-verification.json；沒有把套用後的 hash 誤稱原 baseline。

## 改動與選擇

新增 K `geo_box_face_project_rect(box, axis, side, frame, out)`，保留原 `geo_box_face` 逐位元原樣。H 在 `reference_member_footprint` 和 `reference_contact_facts` 的相同純投影時點改用新 helper。沒有快取、配置、來源請求減量、邊減量、provider 改序、World member 快照延後或 #323 member cache。

相較 raw A0 basis memo，此方案沒有局部 memo slot 與方向/depth 規格、也不碰 current_geometry.c 的 CRLF 和 M27 字面錨點。原 profile 有 827,004 次 geo_box_face，其中 contact 685,575、member footprint 141,429；兩處均屬同一個 BOX→UV 包圍矩形計算。主要候選節省是四個 world corner 與四次投影改成一次 origin 投影及四個方向 dot。A0 side0 粗算乘法從 60 減至 22，side1 約25；guard、call 與 branch 成本尚未量測，不能將乘法數當 wall time 保證。

## 與四角 oracle 相等

原 `geo_box_face` 定義 `u=(axis+1)%3, w=(axis+2)%3`，固定面座標是 side=0 的0或 side=1的 extent[axis]，另外兩座標各取0或 extent[u/w]。walk 只決定這四個 corner 的順序。

設面原點 `O=box.origin+side*extent[axis]*boxAxis[axis]`，其 UV 投影是 P。兩個投影 edge 分別是 d0、d1。原四點的任一投影分量依序集合為 `{P, P+d0, P+d1, P+d0+d1}`，最小值恰為 `P+min(0,d0)+min(0,d1)`，最大值恰為 `P+max(0,d0)+max(0,d1)`。所以負/零 extent、所有 axis/side、軸反向、UV 轉向都包含在同一式內；不依賴 extent 正值或完整 frame 正交。

## signed overflow 定義域

fast path 只驗本次真正使用的 box edge 各自為 signed unit coordinate axis、target UV 各自為 signed unit coordinate axis，來源/目標 origin 各分量和真正使用的 extent 在既有 ±GEO_COORD_LIMIT (1e8) 內。沒有新增數值語意門檻，該上限僅選演算法路徑。

- unit axis dot 的結果只可能 -1/0/1，dot 中乘加不溢位。
- side1 加 offset 後每個 O 分量絕對值至多2e8；減 target origin 至多3e8；target UV dot 各只選一個分量，因此 |P|≤3e8。
- 兩個 delta 各絕對值≤1e8；矩形任一端點絕對值≤5e8，遠小 int64。
- side0 不讀 fixed axis 的 extent/vector 去算 offset，原四角則對該 axis 乘0；即使其無用分量是 INT64_MIN，0乘法仍定義良好。無需為無用欄位新增拒絕。
- selected axes 不必互相垂直；相同 cardinal axes、target UV 重合等舊版可接受的畸形 frame 仍由同一 affine 公式得到相同 bbox。

不符合 fast guard 的輸入完整退回原 `geo_box_face` 加原四次 `geo_frame_project_uv` 與 min/max；沒有新增 frame 拒絕、enum 拒絕或正 extent 規則。對原算式本已 signed overflow 的輸入不宣稱新契約，也沒有用 wraparound 冒充原結果。

## H 觀察時點與失敗 bytes

`reference_member_footprint`：保留 index/placement 讀取、snapshot 原 raw path、reference_sources_ensure、full placement definition、placement id 判斷、APP_SOURCE_MEMBER_POSE 的 VALUE_REQUIRED 呼叫、kind==BOX、actual placement frame 來源請求、wood_member_face_spec(A0) 的原順序。只用新 helper 取代 face+project+bbox。

`reference_contact_facts`：原 app_contact_facts 先算全體 raw footprint 的時點不變。foreign/unplaced/excluded 迴圈與 current-values raw footprint eligibility 不變；typed placement narrow view 呼叫和 member pose 呼叫不變。原 `WoodMember geometry=*fact->member` 是在 pose eval 後才讀 member 的 placed；新式也在此時讀 `fact->member->placed`，不能以較早的 eligibility 測試取代。new helper 只成功才寫 footprint，因此 placed false/face invalid/helper false 都保留原先 raw footprint bytes，與原 wood_member_face_room(false) 分支一致。

W `wood_member_face_room` 的原行為僅 null、placed、face valid 檢查，再從 geometry 的六個 typed box 欄組 box 並呼叫 geo_box_face；其 axis/side 來自與 `wood_member_face_spec` 相同表。候選仍讀 W 的 face spec，沒有在 H 寫死 A0=axis2/side0。

新 API 先驗 box/frame/out、axis≤2、side≤1；失敗不改 out。成功 fast/fallback 均只在末端一次寫 out。沒有 provider callback 或 getter 夾在 projection 中，因此此純計算替換不會移動外部可觀察 eval 時點。

## 必須量測與自證

獨立 auditor 正在 repo 外擴充既有 geometry_harness 的 boxes()；保留全部原 case，逐一比對新 API 和原 geo_box_face 四角 oracle，覆蓋 all6face、24 signed permutations、negative/zero extent、±COORD_LIMIT、safe 大座標/noncardinal fallback、invalid/null 與 out 保留。候選本身尚未由本代理跑過。

需要具名的 direct-formula 負控，例如錯誤刪除 side1 offset、負 delta 改絕對值、錯用 target UV 或遺漏第二 edge，應被 exact corner oracle 拒絕；拿掉 fast path 是語意等價退回慢路，不能拿此撤回宣稱功能突變紅。P-189 的效能前後比較則可用整候選撤回，其性能驗收仍須原三方 main/base/final、36 interleaved samples 與2×門檻。

完整 AppContactFacts 差分應比較具名所有欄位與輸出範圍；placed provider side effect、raw-invalid/current-values path、source failure partial bytes 也須保留。不得只比新 bbox 或只拿合法 frame 樣本作為 H 等價證據。

## 錨點與收據風險

- 原 geo_box_face 的 function body、walk 和 geometry_harness 原 case 完整保留；既有 K box face 負控仍有原 API 可達 oracle。
- current_geometry.c 和 tests/mutate.py M27 深度錨點不動。
- H 移除 wood_member_face_room 呼叫及原 inline project loop；任何針對舊行做 literal replace 的控制應檢查是否仍可達，不能把沒命中/繞過當 killed。唯讀 rg 現行 test_geo261_host_authority 的 FOOTPRINT_ANCHOR 和 test_geo261_host_facts_authority 的 probe-projection/end-refresh/end-eager 等錨點都未改；authority 實際 pose/frame oracle仍走兩個 H消費端。
- 若採用，架構 allow/scan/manifest/report/receipt 必須含全部六個來源：W definition_sources.c/h、H reference_sources.inc、K source.c、K geometry.c/h；不能僅重新hash原三檔。
- 新 API 是 K 通用幾何 API，沒有 W enum、H cache 或來源請求規格；沒有跨層依賴。
- 實際快路占比與額外guard成本是目前最大不確定性，只有 root 排他 O2 原三方量測能決定是否採用。
