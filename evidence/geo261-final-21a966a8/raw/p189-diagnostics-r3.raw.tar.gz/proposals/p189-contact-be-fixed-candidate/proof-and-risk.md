# contact 固定BE32/BE64讀寫：靜態證明與驗收邊界

repo外候選；本代理未改root、未編譯、未執行測試或效能量測。baseline contact_sources.c為`0405a88453278501482381d452b564f74e0f91833c711002007b0ffcdb2498bd`，含既有faces malloc；candidate為`7bc914d4c48337ba7a74f2d0ea1776e68793b1ec66455077e81dac87ab62591a`。patch SHA256 `b3c3800e2c0d8dfaa4c8b83601b85d8060d2ba4fc54a91dc916e9c833061e84c`。

只將原四個 static helper wood_contact_source_u32/u64、wood_contact_source_read_u32/u64 的固定4/8次shift迴圈展開；沒有新名字、policy、include、intrinsic、pointercast、cache、容量或API。原faces malloc及facts/result/query配置一字不動。原API caller與鍵內容順序完全不動。

## 值與記憶體等價

寫入helper對寬度N∈{4,8}的每個i原本輸出`(unsigned char)(value >> (8*(N-1-i)))`；candidate在相同索引以相同型別和常數shift逐項賦值，仍由低地址到高地址，不改out範圍之外。參數value先按原uint32_t/uint64_t值傳入，signed enum/coord的原call-site cast完全不動。

讀取helper原遞迴value=(value<<8)|bytes[i]，展開後是所有`((uintN_t)bytes[i]) << (8*(N-1-i))`的OR，bitshift/OR分配得到相同uintN_t結果。每個byte在shift前cast到對應unsigned寬度，沒有高bit經signed int左移的UB。最大shift分別24與56，從不shift寬度本身。全0、全FF、每byte不同、UINT32/MAX、UINT64/MAX及signed端點bit表示都由同式涵蓋。

全部存取仍是unsigned char，不要求對齊、不假定主機端序、不違反strict aliasing；沒有改用uint64_t指標。讀取expression的operand次序與原迴圈可能不同，但所讀input為無volatile副作用的既有canonical buffer，且helper不寫input，所以產品契約內沒有可觀察差異。這不是讀取volatile/MMIO的API。

四helper原本沒有failure/offset/out validity guard，candidate也不新增或搬動；key-size/schema/content-size與collection exact-size檢查仍留在原caller。read_u64只是在原保證8bytes的相同位置讀同8bytes，read_u32同理。外層publicdecode失敗保留out、collect失敗保留out/count、成功keybytes17byte以及recordbytes48byte的處理完全不變。signed read_coord的INT64_MAX/UINT64_MAX分支原樣保留。

## 收益依據與不確定性

root對現有`/tmp/g261rawsnapshot/candidate-bridge`的objdump已確認wood_contact_source_ref中的兩次8byte寫入仍各有8次shr/jne迴圈；此是目前候選比gridcodec更直接的組譯依據。原O2 contactdecode453,052calls來自describe/evaluate各226,526，與實際原碼caller吻合；每decode有兩次BE64，另collection view與feature座標也用相同helper。它們都是固定寬度，展開可讓編譯器考慮load/store+bswap，尚未對本候選看assembly或量測，所以不能保證wall time收益。

不採原profile的wood_grid_codec_axis833,056作依據：其中827,004恰是H的geo_box_face誤歸因，真正axis來源只有6,052。grid BE64是另一個repo外候選，這個patch不包含grid修改。

## 原控制與必要驗收

static-control-audit.json用AST抽出原test_geo261_contact_sources.py的8個controls，確認所有before錨點在各自module原/候選皆唯一；所有wood_contact符號出現順序/次數及includes相同。此僅文字覆核，不是測試執行。

八個控制為：policy-bypass、feature-edge、query-reuse、hidden-coordinates、placement-order、duplicate-last-order、duplicate-earliest-order、failure-count；target literal與Feature instrumentation return錨點皆未改。8具名ASSERT仍應逐個紅，原/恢復baseline仍綠。

正常codec/publicAPI應覆蓋未對齊key及record、多種每byte非對稱值、完整uint64queryid、malformed17bytekey、各種signed座標及所有metadata欄，canonicalcollection逐byte一致、圖來源/依賴順序相同、failure preserves outputs。可對新式故意交換兩個shift、把query高byte漏寫等做具名自證；舊實作與新實作功能本應等價，因此整patch撤回不能宣稱功能測試應紅，效能撤回紅則仍由原P-189三方門檻證明。

若採用，mutate.py --check判帳本是否過期，架構來源集合追加contact_sources.c並以最終gitdiff/manifest重產；不應把已撤回BOX/helper或grid候選錯列為最終來源。最終仍須同SHA整份驗收，不能拿這份靜態證明代替。
