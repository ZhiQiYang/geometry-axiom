"""Static peer of only the scheduler around the frozen original six requests."""
import ast,hashlib,json
from pathlib import Path
P=Path('/workspace/geo345-runtime-launch-preparation-20261024/launch_six_original_requests.py');O=Path(__file__).parent
READY=Path('/tmp/issue214-http-fixture-preparation-20261024/RUNTIME_REQUESTS_READY.json');HELPER=READY.with_name('measure_fixture.py')
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(label,v):
 checks.append({'check':label,'passed':bool(v)})
 if not v:raise AssertionError(label)
body=P.read_bytes();code=body.decode();tree=ast.parse(code)
check('final exact24d148',sha(body)=='24d148c5c37e3ab423813e18336ed908d3291837fa6914c1ec32aae5f8e64f97')
check('only tighten partiallease snapshot from6802',sha(code.replace('if len(locks) == 2:','if locks:').encode())=='6802f5ce091cbaf5dd926a410da2313c3a2a5f398ccd33ff9720317169cd85d2')
check('original ready e994',sha(READY.read_bytes())=='e9940858709c45b5ccae5b326465a7a69b16b8d697f7d0b78d66cddb2b163fd0')
check('original helper6b45',sha(HELPER.read_bytes())=='6b45c67f97994a6a5e22c49dc3bcc9e02215b072c500e3732c58cbaebe44e04d')
ready=json.loads(READY.read_bytes());requests=ready['requests']
check('six original requests only',len(requests)==6)
check('original phase order',[(r['phase'],r['mode']) for r in requests]==[('original','formal'),('original','components'),('fixed','formal'),('fixed','components'),('withdrawn','components'),('restored','components')])
fixed='2199cda8896b47c7ad2b6c10479e5e0cbdb67c83';base='3c6633575ec0f9dccf35898380202aad8d0ffddf'
check('firsttwo truebase nextfourfixed',[r['requiredPhysicalHEAD'] for r in requests]==[base,base,fixed,fixed,fixed,fixed])
outs=[]
for i,r in enumerate(requests,1):
 argv=r['argv'];outs.append(argv[argv.index('--out')+1])
 check('original frozen helper perrequest'+str(i),argv[:3]==['python3','-B',str(HELPER)] and argv[argv.index('--sha')+1]==r['requiredPhysicalHEAD'])
check('six unique fresh workspace outputs',len(set(outs))==6 and all(p.startswith('/workspace/') and not Path(p).exists() for p in outs))
for label,needle in {
 'requiredrootlease':"parser.add_argument('--root-exclusive-runtime-cache-lease', action='store_true', required=True)",
 'fresh outer no retry':"need(not O.exists(), 'fresh outer capture only; no retry overwrite')",
 'original capture pin':'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762',
 'no outer timeout':"cwd=R, timeout=None, check=False",
 'original argv unmodified':"run(request['argv'], expected, check=False)",
 'one sequential request loop':"for number, request in enumerate(ready['requests'], 1):",
 'first2 truebase checkout':"run(ready['sourceCheckoutBeforeOriginal'], FIXED)",
 'fixed checkout only atthird':"if number == 3:",
 'root two locks':"Path('/tmp/g261r3/heavy.lock'), Path('/tmp/g261r3/secondary.lock')",
 'nonblocking lock noidlewait':"fcntl.LOCK_EX | fcntl.LOCK_NB",
 'clean actualsource':"['git','status','--porcelain=v1','--untracked-files=all']",
 'indexguard':"['git','diff','--cached','--name-status']",
 'row original OSexit':"'actualProcessExit':row['actual_process_returncode']",
 'allredcollected originalzero expected':"all(x['actualProcessExit'] == 0 for x in report['requests'])",
 'restoreoriginalsourcefinally':"if physical == BASE:",
 'fixed finalguard':"report['physicalSourceRestoredToFixed'] = True",
 'oldsharedlogs bytesrestore':"need(Path(entry['path']).read_bytes() == b, 'prior log bytes restoration failed')",
 'no cache snapshot underpartiallease':"if len(locks) == 2:",
 'save allfirstfailure':"report['errors'].append(traceback.format_exc())",
 'preserveoriginalphase receipts':"report['originalSixPhaseReceiptsNotDeleted'] = True",
 'no numericalperformance threshold':"'performanceQualificationThreshold':None",
 'no new oracle':'Raw six helper receipts define original19 correctness; this scheduler adds no test oracle.',
 'formal/components separate':'Formal timings and observed component inclusive spans must be reported separately.',
 'equivalent not killed':'All correctness exits are expected0, including equivalent polling withdrawal; no killed mutant claim.',
 'necessary build separate':'A genuinely necessary original bridge build remains allowed and must be disclosed separately from polling benefit.',
 'clear Gitredirect':"'GIT_OBJECT_DIRECTORY'",
 'clear aliasesenv':"key.startswith('GEOMETRY_')",
 'declared headroom only':"values['/workspace'] >= 128*1024*1024 and values['/tmp'] >= 16*1024*1024",
}.items():check(label,needle in code)
check('no source patch/assertion/timeout added',not any(x in code for x in ['time.sleep(',"'--force'",'setrlimit','subprocess.Popen','runpy.run_path','re.sub(']))
helper=HELPER.read_text()
check('original helper strict19 kept','report[\'total\']==report[\'run\']==report[\'passed\']==19' in helper and "report['failed']==report['skipped']==0" in helper)
check('original helper1200 andstack16MiB kept','original.run_process(command, dict(os.environ), 1200, cwd=repo)' in helper and 'resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))' in helper)
logs=[]
for suffix in ('.log','.json','.unittest.log'):
 p=Path('/tmp/geometry-tests/run_all-logs')/('py_test_rule_case_workbench_http'+suffix);st=p.stat();logs.append({'path':str(p),'bytes':st.st_size,'nlink':st.st_nlink})
 check('currentoriginalrow regular unaliased'+suffix,p.is_file() and not p.is_symlink() and st.st_nlink==1)
report={'scope':'Static scheduling peer only; frozen original20/0 helper not replaced, no C, no sixphase execution, no product gate credit',
 'subject_sha256':sha(body),'ready_sha256':sha(READY.read_bytes()),'helper_sha256':sha(HELPER.read_bytes()),
 'checks':checks,'passed':len(checks),'failed':0,'findings':[],
 'scheduling_condition':'Root exclusive runtime/cache lease, #348 true terminal first, acquire both original locks, fresh space guard; no fixed output reused.',
 'existing_shared_row_logs':logs,'wrapper_executed':False,'safe_after_root_runtime_schedule_authorization':True}
(O/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':len(checks),'failed':0,'report_sha256':sha((O/'REVIEW.json').read_bytes())}))
