from pathlib import Path
import ast, collections, hashlib, json, math, subprocess

OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
ROOT=Path('/workspace/geo345-six-original-requests-20261024')
READY=Path('/tmp/issue214-http-fixture-preparation-20261024/RUNTIME_REQUESTS_READY.json')
BASE='3c6633575ec0f9dccf35898380202aad8d0ffddf'
FIX='2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def check(label,value):checks.append({'name':label,'passed':bool(value)})
report=load(ROOT/'RESULT.json');ready=load(READY)
check('frozen scheduler original terminal',sha((ROOT/'RESULT.json').read_bytes())=='26cf6727fd50a90c1e8b122f43ebf3e20c37adf4c0de46e04f99a961e55c16ff')
check('frozen original requests',sha(READY.read_bytes())==report['readyRequestPin']=='e9940858709c45b5ccae5b326465a7a69b16b8d697f7d0b78d66cddb2b163fd0')
check('frozen original helper',sha(Path('/tmp/issue214-http-fixture-preparation-20261024/measure_fixture.py').read_bytes())==report['helperPin']=='6b45c67f97994a6a5e22c49dc3bcc9e02215b072c500e3732c58cbaebe44e04d')
check('accepted scheduler bytes',sha(Path('/workspace/geo345-runtime-launch-preparation-20261024/launch_six_original_requests.py').read_bytes())=='24d148c5c37e3ab423813e18336ed908d3291837fa6914c1ec32aae5f8e64f97')
check('actual outer OS terminal 0',load(ROOT/'EXEC_COMPLETION.json')['result']['exit_code']==0)
check('six requests original outer 0',report['exitCode']==0 and not report['errors'] and len(report['requests'])==6)
check('no invented threshold retry or timeout',report['performanceQualificationThreshold'] is None and report['automaticRetries']==0 and report['outerTimeout'] is None)
check('19 methods 1200 original timeout',report['originalMethodsPerRequest']==19 and report['originalSuiteTimeoutSeconds']==1200)
check('exclusive leases recorded',report['rootExclusiveCacheLeaseAuthorized'] and report['exclusiveLocks']==['/tmp/g261r3/heavy.lock','/tmp/g261r3/secondary.lock'])
check('original source/fixed source exact',report['sourceOriginal']==BASE and report['sourceFixed']==FIX)

sourcebytes={}
for name,commit in [('base',BASE),('fix',FIX)]:
 argv=['git','-C','/workspace/issue214-http-fixture-work-20261024','show',commit+':tests/test_rule_case_workbench_http.py']
 r=subprocess.run(argv,capture_output=True)
 (OUT/(name+'-test-source.stdout.bin')).write_bytes(r.stdout);(OUT/(name+'-test-source.stderr.bin')).write_bytes(r.stderr)
 (OUT/(name+'-test-source.COMMAND.json')).write_text(json.dumps({'argv':argv,'exit_code':r.returncode},indent=2)+'\n')
 check(name+' original Git source read',r.returncode==0)
 sourcebytes[name]=r.stdout

command_count=0;raw_bytes=0
def command_streams(rows,label):
 global command_count,raw_bytes
 for index,row in enumerate(rows):
  command_count+=1;prefix=label+' command '+str(index+1)
  check(prefix+' actual terminal0',row['actual_process_returncode']==0 and not row['timeout_expired'])
  check(prefix+' timing ordered',row['ended_epoch']>=row['started_epoch'])
  directory=Path(row['directory'])
  check(prefix+' receipt exact',load(directory/'result.json')==row)
  for name in ['stdout','stderr']:
   body=(directory/(name+'.bin')).read_bytes();raw_bytes+=len(body)
   check(prefix+' '+name+' raw hash',sha(body)==row[name+'_sha256'])
   check(prefix+' '+name+' raw length',len(body)==row[name+'_bytes'])

command_streams(load(ROOT/'subcommands.json'),'scheduler')
analysis=load('/workspace/geo345-runtime-analysis-20261024/ANALYSIS.json')
check('analysis frozen',sha(Path('/workspace/geo345-runtime-analysis-20261024/ANALYSIS.json').read_bytes())=='9b2cecb732adb91eec1b05dd74cc4bd22e12e674df2c4dc0f18bcd6a106f1b2c')
summaries=[]
for index,(executed,planned,analyzed) in enumerate(zip(report['requests'],ready['requests'],analysis['requests'])):
 label=executed['phase']+'-'+executed['mode'];path=Path('/workspace/issue214-'+label+'-once');r=load(path/'RECEIPT.json')
 expected_source=BASE if index<2 else FIX
 check(label+' exact original argv',executed['originalArgv']==planned['argv'])
 check(label+' expected actual source',executed['physicalSourceSHA']==planned['requiredPhysicalHEAD']==r['sourceSHA']==expected_source)
 check(label+' helper and process exit0',executed['actualProcessExit']==r['actualExit']==0 and r['passed'])
 check(label+' original timeout stack',r['originalSuiteTimeoutSeconds']==1200 and r['outerTimeout'] is None and r['stackBytes']==16777216)
 check(label+' unchanged source before/after',r['sourceBefore']==r['sourceAfter'] and r['sourceBefore']['head']==expected_source and r['sourceBefore']['status']==r['sourceBefore']['cached']=='')
 check(label+' no performance threshold',r['performanceQualificationThreshold'] is None)
 actual=(path/'executed-test-source.py.txt').read_bytes();variant='base' if index<2 or executed['phase']=='withdrawn' else 'fix'
 check(label+' exact in-memory executed source',actual==sourcebytes[variant] and sha(actual)==r['executedTestSourceSHA256'])
 check(label+' physical source remains branch identity',r['physicalTestSourceSHA256']==sha(sourcebytes['base' if index<2 else 'fix']))
 methods=sorted(n.name for n in ast.walk(ast.parse(actual)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
 check(label+' exact original 19 methods',methods==sorted(r['originalSuiteMethods']) and len(methods)==19)
 u=r['originalUnittestReport'];check(label+' strict 19 no skips/errors',u['total']==u['run']==u['passed']==19 and all(u[k]==0 for k in ['failed','skipped','explicit_skipped','unrun_skipped','blocked_by_error','expected_failed','extra_errors']) and u['import_error'] is None and not u['failures'])
 original_report=load(path/('formal.json' if executed['mode']=='formal' else 'original-unittest.json'))
 check(label+' original unittest report exact',original_report==u)
 log=(path/('formal.unittest.log' if executed['mode']=='formal' else 'original-unittest.log')).read_text()
 check(label+' original runner 19 summary and OK', 'Ran 19 tests' in log and '\nOK\n' in log)
 reaper=[json.loads(line) for line in (path/'reaper.jsonl').read_text().splitlines()]
 check(label+' true original reaper completion',reaper[-1]['event']=='完成' and reaper[-1]['primary_returncode']==0)
 command_streams(load(path/'subcommands.json'),label)
 check(label+' analysis links original receipt',analyzed['original_receipt']==str(path/'RECEIPT.json') and analyzed['original_receipt_sha256']==sha((path/'RECEIPT.json').read_bytes()))
 check(label+' analysis original unittest time exact',analyzed['original_unittest_seconds']==u['seconds'])
 check(label+' analysis original command wall exact',analyzed['original_outer_command_wall_seconds']==r['originalCommand']['ended_epoch']-r['originalCommand']['started_epoch'])
 if executed['mode']=='components':
  comp=load(path/'components.json');watch=load(path/'watchdog.json');events=comp['events']
  check(label+' original watchdog limits terminal',watch['originalTimeoutSeconds']==1200 and watch['actual_child_exit']==0 and watch['timed_out'] is False)
  check(label+' exposed decoded output not mislabelled raw', 'not two separate raw inner pipes' in watch['stream_limit'])
  check(label+' original component source',comp['executedSourceSHA256']==sha(actual) and comp['sourceVariant']==executed['phase'] and comp['originalJudgeUnchanged'])
  check(label+' inclusive parent spans not summed', 'inclusive' in comp['timing_limits'] and 'do not sum' in comp['nested_close'])
  check(label+' analysis original components exact',analyzed['components_sha256']==sha((path/'components.json').read_bytes()) and analyzed['watchdog_original']==watch and analyzed['original_events_count']==len(events))
  groups=collections.defaultdict(list)
  ids={x['id'] for x in events}
  for event in events:
   check(label+' event '+str(event['id'])+' wall/CPU nonnegative',event['end_ns']>=event['start_ns'] and event['cpu_end_ns']>=event['cpu_start_ns'])
   check(label+' event '+str(event['id'])+' parent valid',event['parent'] is None or event['parent'] in ids)
   groups[(event['phase'],event['component'])].append(event)
  check(label+' 19 shutdowns',len(groups[('tearDown','server.shutdown')])==19)
  for a in analyzed['components_inclusive']:
   group=groups[(a['phase'],a['component'])]
   check(label+' analyzed '+a['component']+' count',a['count']==len(group))
   check(label+' analyzed '+a['component']+' wall',math.isclose(a['inclusive_wall_seconds_sum'],sum((v['end_ns']-v['start_ns'])/1e9 for v in group),rel_tol=1e-12,abs_tol=1e-12))
   check(label+' analyzed '+a['component']+' CPU',math.isclose(a['inclusive_process_cpu_seconds_sum'],sum((v['cpu_end_ns']-v['cpu_start_ns'])/1e9 for v in group),rel_tol=1e-12,abs_tol=1e-12))
 summaries.append({'phase':label,'execution_sha':expected_source,'original_tests':19,'exit_code':0,'unittest_seconds':u['seconds'],'correctness_control_is_equivalent_not_mutant_kill':True})

before=report['cacheBefore'];after=report['cacheAfter']
check('same global cache path count',len(before)==len(after)==3)
for a,b in zip(before,after):
 check('recorded immutable cache before/after '+a['path'],{k:v for k,v in a.items() if k!='originalSidecarCopy'}=={k:v for k,v in b.items() if k!='originalSidecarCopy'})
 if 'originalSidecarCopy' in a:
  check('retained original sidecar bytes before/after',Path(a['originalSidecarCopy']).read_bytes()==Path(b['originalSidecarCopy']).read_bytes())
  check('retained original sidecar hash',sha(Path(a['originalSidecarCopy']).read_bytes())==a['sha256'])
prior=load(ROOT/'PRIOR_ROW_LOGS.json')
check('all three prior row logs restored by original scheduler',sorted(prior)==report['priorRowLogsRestored'] and len(prior)==3)
for name,row in prior.items():
 body=(ROOT/'prior-row-logs'/name).read_bytes()
 check('retained prior row log '+name,sha(body)==row['sha256'] and len(body)==row['bytes'])
check('source restored fixed and originals retained',report['physicalSourceRestoredToFixed'] and report['originalSixPhaseReceiptsNotDeleted'])
result={'scope':'Independent actual six original #345 requests and descriptive inclusive components; no rerun or new threshold', 'checks':len(checks),'exit_code':int(any(not x['passed'] for x in checks)),'failures':[x for x in checks if not x['passed']], 'subjects':summaries,'original_commands_verified':command_count,'original_stdout_stderr_bytes_verified':raw_bytes,'limitations':['All correctness controls expected0; equivalent polling withdrawal is not a killed mutant.','One observed sequence per phase; descriptive times do not establish a confidence interval or new qualification threshold.','Component wall/CPU are inclusive; RUSAGE_CHILDREN includes Python descendants and is not isolated native CPU.','Global cache verified against original before/after records and retained sidecars, not a post-lease live-cache reread.','No complete native/browser/ledger/architecture acceptance credit and no publication claimed.'],'details':checks}
(OUT/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['checks','exit_code','failures','original_commands_verified','original_stdout_stderr_bytes_verified']},ensure_ascii=False))
raise SystemExit(result['exit_code'])
