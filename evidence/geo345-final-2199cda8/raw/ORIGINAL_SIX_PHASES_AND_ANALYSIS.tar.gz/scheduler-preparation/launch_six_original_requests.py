"""Only schedule/capture the six already reviewed requests under root's lease."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import traceback

READY = Path('/tmp/issue214-http-fixture-preparation-20261024/RUNTIME_REQUESTS_READY.json')
READY_PIN = 'e9940858709c45b5ccae5b326465a7a69b16b8d697f7d0b78d66cddb2b163fd0'
HELPER = Path('/tmp/issue214-http-fixture-preparation-20261024/measure_fixture.py')
HELPER_PIN = '6b45c67f97994a6a5e22c49dc3bcc9e02215b072c500e3732c58cbaebe44e04d'
CAP = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
R = Path('/workspace/issue214-http-fixture-work-20261024')
O = Path('/workspace/geo345-six-original-requests-20261024')
FIXED = '2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'
BASE = '3c6633575ec0f9dccf35898380202aad8d0ffddf'
LOGS = Path('/tmp/geometry-tests/run_all-logs')

def need(value, message):
    if not value:
        raise RuntimeError(message)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def dump(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

parser = argparse.ArgumentParser()
parser.add_argument('--root-exclusive-runtime-cache-lease', action='store_true', required=True)
args = parser.parse_args()
need(sha(READY.read_bytes()) == READY_PIN and sha(HELPER.read_bytes()) == HELPER_PIN, 'original ready requests/helper frozen pins')
need(sha(CAP.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762', 'original capture pin')
ready = json.loads(READY.read_text())
need(not O.exists(), 'fresh outer capture only; no retry overwrite')
for request in ready['requests']:
    output = Path(request['argv'][request['argv'].index('--out') + 1])
    need(not output.exists() and not output.is_symlink(), 'one of six original OUT paths already used')
O.mkdir()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', LANG='C.UTF-8', LC_ALL='C.UTF-8')
redirects = ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY',
             'GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_NAMESPACE')
cleared = []
for key in list(env):
    if key.startswith('GEOMETRY_') or key in (*redirects, 'PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD'):
        cleared.append(key)
        env.pop(key)
spec = importlib.util.spec_from_file_location('capture', CAP)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
rec = cap.Recorder(O, env, FIXED)
report = {'schema':'issue214-six-original-request-scheduler/1','readyRequestPin':READY_PIN,'helperPin':HELPER_PIN,
          'sourceOriginal':BASE,'sourceFixed':FIXED,'rootExclusiveCacheLeaseAuthorized':True,
          'noAdditionalJudge':True,'performanceQualificationThreshold':None,'automaticRetries':0,
          'originalMethodsPerRequest':19,'originalSuiteTimeoutSeconds':1200,'outerTimeout':None,
          'requests':[],'errors':[],'exitCode':None,'clearedInheritedEnvironmentNames':cleared,
          'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
locks = []
old_logs = {}
source_touched = False

def run(argv, source, check=True):
    row, out, err = rec.run(argv, cwd=R, timeout=None, check=False,
        source_sha=source, source_variant='declared-original-six-request-scheduler')
    if check:
        need(row['actual_process_returncode'] == 0, 'environment/source command failed: ' + row['directory'])
    return row, out, err

def source_guard(expected):
    for argv, exact in [(['git','rev-parse','HEAD'], (expected+'\n').encode()),
                        (['git','status','--porcelain=v1','--untracked-files=all'], b''),
                        (['git','diff','--cached','--name-status'], b''),
                        (['git','diff','--name-status'], b'')]:
        _, out, _ = run(argv, expected)
        need(out == exact, 'owned physical source/index not exact and clean')

def disk(stage):
    values = {p:shutil.disk_usage(p).free for p in ('/workspace','/tmp')}
    report.setdefault('diskObservations', []).append({'stage':stage,'freeBytes':values})
    # Scheduling headroom, not a new product/performance threshold.
    need(values['/workspace'] >= 128*1024*1024 and values['/tmp'] >= 16*1024*1024,
         'ENV_SPACE: declared128MiB WS /16MiB TMP six-request scheduling headroom')

def cache_snapshot(label):
    rows = []
    for name in ('bridge','bridge.fingerprint.json','bridge.pending.json'):
        p = Path('/tmp/geometry-tests') / name
        if not p.exists():
            rows.append({'path':str(p),'exists':False})
            continue
        s = p.stat()
        entry = {'path':str(p),'exists':True,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,
                 'ctime_ns':s.st_ctime_ns,'inode':s.st_ino,'device':s.st_dev,'sha256':sha(p.read_bytes())}
        if name.endswith('.json'):
            dest = O / (label + '-' + name)
            dest.write_bytes(p.read_bytes())
            entry['originalSidecarCopy'] = str(dest)
        rows.append(entry)
    dump(O / (label + '-global-cache.json'), rows)
    return rows

try:
    disk('before-exclusive-lease')
    for p in (Path('/tmp/g261r3/heavy.lock'), Path('/tmp/g261r3/secondary.lock')):
        handle = p.open('a+b')
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(handle)
    report['exclusiveLocks'] = [str(h.name) for h in locks]
    source_guard(FIXED)
    for argv in (['uname','-a'], ['python3','--version'], ['cc','--version'], ['df','-B1','/workspace','/tmp']):
        run(argv, FIXED)
    report['cacheBefore'] = cache_snapshot('before')
    (O / 'prior-row-logs').mkdir()
    for suffix in ('.log','.json','.unittest.log'):
        p = LOGS / ('py_test_rule_case_workbench_http' + suffix)
        if p.exists():
            need(p.is_file() and not p.is_symlink(), 'shared log must be regular original file')
            b = p.read_bytes()
            (O / 'prior-row-logs' / p.name).write_bytes(b)
            old_logs[p.name] = {'bytes':len(b),'sha256':sha(b),'path':str(p)}
    dump(O / 'PRIOR_ROW_LOGS.json', old_logs)
    source_touched = True
    run(ready['sourceCheckoutBeforeOriginal'], FIXED)
    source_guard(BASE)
    for number, request in enumerate(ready['requests'], 1):
        if number == 3:
            source_guard(BASE)
            run(ready['sourceCheckoutBeforeFixed'], BASE)
        expected = request['requiredPhysicalHEAD']
        source_guard(expected)
        disk('before-declared-request-' + str(number))
        row, out, err = run(request['argv'], expected, check=False)
        report['requests'].append({'number':number,'phase':request['phase'],'mode':request['mode'],
            'physicalSourceSHA':expected,'originalArgv':request['argv'],
            'actualProcessExit':row['actual_process_returncode'],'fullOuterStreams':row['directory']})
        dump(O / 'LIVE.json', report)
        source_guard(expected)
    report['exitCode'] = 0 if all(x['actualProcessExit'] == 0 for x in report['requests']) else 1
except BaseException:
    report['errors'].append(traceback.format_exc())
    report['exitCode'] = 1
finally:
    try:
        if source_touched:
            _, head, _ = run(['git','rev-parse','HEAD'], FIXED)
            physical = head.decode().strip()
            source_guard(physical)
            if physical == BASE:
                run(ready['sourceCheckoutBeforeFixed'], BASE)
            source_guard(FIXED)
            report['physicalSourceRestoredToFixed'] = True
        for name, entry in old_logs.items():
            b = (O / 'prior-row-logs' / name).read_bytes()
            need(len(b) == entry['bytes'] and sha(b) == entry['sha256'], 'prior log backup changed')
            Path(entry['path']).write_bytes(b)
            need(Path(entry['path']).read_bytes() == b, 'prior log bytes restoration failed')
        report['priorRowLogsRestored'] = sorted(old_logs)
        if len(locks) == 2:
            report['cacheAfter'] = cache_snapshot('after')
        report['originalSixPhaseReceiptsNotDeleted'] = True
    except BaseException:
        report['errors'].append(traceback.format_exc())
        report['exitCode'] = 1
    for handle in reversed(locks):
        handle.close()
    report['endedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['scope'] = ['Six original declared requests only, no automatic retry or sample selection.',
        'Raw six helper receipts define original19 correctness; this scheduler adds no test oracle.',
        'Formal timings and observed component inclusive spans must be reported separately.',
        'All correctness exits are expected0, including equivalent polling withdrawal; no killed mutant claim.',
        'A genuinely necessary original bridge build remains allowed and must be disclosed separately from polling benefit.',
        'Global prior logs are restored only after their new formal copies are retained by the unchanged helper.']
    dump(O / 'RESULT.json', report)
print(json.dumps(report,ensure_ascii=False))
raise SystemExit(report['exitCode'])
