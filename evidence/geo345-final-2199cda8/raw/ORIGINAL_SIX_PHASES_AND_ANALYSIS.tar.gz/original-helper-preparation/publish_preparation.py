"""Publish only completed #214 preparation; no subject execution or index staging."""
from pathlib import Path
import hashlib, importlib.util, io, json, os, tarfile

P=Path(__file__).parent
R=Path('/workspace/issue214-http-fixture-work-20261024')
O=Path('/workspace/issue214-http-fixture-preparation-publication-20261024')
S='2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'
B='3c6633575ec0f9dccf35898380202aad8d0ffddf'
BR='codex/issue214-http-fixture-20261024'
PREFIX='issue214-fixture-2199cda8'
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
def h(b): return hashlib.sha256(b).hexdigest()
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not O.exists()
O.mkdir()
sp=importlib.util.spec_from_file_location('original_capture',C)
cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
for n in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):
    env.pop(n,None)
rec=cap.Recorder(O/'publication-execution',env,S)
def run(argv,data=None):
    row,out,err=rec.run(list(map(str,argv)),cwd=R,data=data,timeout=120,check=False,source_sha=S,source_variant='issue214-preparation-publication-only-detached-clean-source')
    if row['actual_process_returncode']!=0: raise RuntimeError('Original command failed: '+row['directory'])
    return out
def git(*args,data=None): return run(['git',*args],data)
def entries(tree):
    result={}
    for row in git('ls-tree','-z',tree).split(b'\0'):
        if not row: continue
        fields,name=row.split(b'\t',1)
        mode,kind,oid=fields.split(b' ')
        result[name]=(mode,kind,oid)
    return result
def tree(es):
    raw=b''.join(m+b' '+k+b' '+oid+b'\t'+n+b'\0' for n,(m,k,oid) in sorted(es.items()))
    return git('mktree','-z',data=raw).decode().strip()
def blob(raw): return git('hash-object','-w','--stdin',data=raw).strip()
def commit(t,parent,message): return git('commit-tree',t,'-p',parent,data=(message+'\n').encode()).decode().strip()

assert git('rev-parse','HEAD').decode().strip()==S
assert git('symbolic-ref','HEAD').decode().strip()=='refs/heads/'+BR
assert git('status','--porcelain=v1','--untracked-files=all')==b''
assert git('ls-remote','origin','refs/heads/'+BR).decode().split()[0]==S
assert h((P/'measure_fixture.py').read_bytes())=='6b45c67f97994a6a5e22c49dc3bcc9e02215b072c500e3732c58cbaebe44e04d'
for path,expected in (
    (Path('/tmp/issue214-http-fixture-peer/REVIEW.json'),'0d846a5119995e2792dae3cab8b37baad661bc8bee449856e23a7556e9bcc8cb'),
    (Path('/tmp/issue214-http-fixture-helper-peer/REVIEW.json'),'ab0108d6eb3ea242008e8d65ee47aae22d88c15ffc3a56be683bf6da6e8a3231')):
    assert h(path.read_bytes())==expected
    report=json.loads(path.read_text());assert report['exitCode']==0 and not report['findings']

sources={}
for label,root in (
    ('preparation',P),
    ('source-peer',Path('/tmp/issue214-http-fixture-peer')),
    ('helper-peer',Path('/tmp/issue214-http-fixture-helper-peer'))):
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_file(): sources[label+'/'+path.relative_to(root).as_posix()]=path
index={'schema':'issue214-completed-preparation-originals/1','sourceSHA':S,'baseSHA':B,'subjectExecutions':0,'formal19':'UNRUN','components':'UNRUN','sourcePeerChecks':14,'helperPeerChecks':20,'members':[]}
archive=O/'completed-preparation-originals.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
    for name,path in sources.items():
        raw=path.read_bytes();st=path.stat();ti=tarfile.TarInfo(name)
        ti.size=len(raw);ti.mode=st.st_mode&0o777;ti.mtime=st.st_mtime
        tf.addfile(ti,io.BytesIO(raw))
        index['members'].append({'member':name,'sourcePath':str(path),'bytes':len(raw),'sha256':h(raw)})
with tarfile.open(archive,'r:gz') as tf:
    members=tf.getmembers();assert [m.name for m in members]==list(sources)
    for m,row in zip(members,index['members']):
        raw=tf.extractfile(m).read();assert len(raw)==row['bytes'] and h(raw)==row['sha256'] and raw==sources[m.name].read_bytes()
index.update(archive=archive.name,archiveBytes=archive.stat().st_size,archiveSHA256=h(archive.read_bytes()),memberCount=len(sources),roundtripPassed=True)
dump(O/'INDEX.json',index)
progress='''# #214 A4 preparation progress\n\nSource S: `2199cda8896b47c7ad2b6c10479e5e0cbdb67c83`; base E: `3c6633575ec0f9dccf35898380202aad8d0ffddf`.\n\n只修改 HTTP fixture 的 Thread kwargs，明示 `serve_forever(poll_interval=0.05)`。原 19 方法、全部斷言與 teardown 順序保持。單檔獨立靜審 14/0，外部 helper 獨立靜審 20/0；均未執行 subject。\n\n正式 19 方法、component/CPU/wall、原/修正/等價撤回/恢復均 UNRUN；性能 UNMEASURED。原 suite 時限為 1200 秒，早先 900 秒準備文字保留更正原件。撤回輪詢優化預期 correctness 仍 0，不能冒充功能 kill。\n\n薄 source 僅物化一個測試檔，未配置完整 runtime。`/tmp/geometry-tests` 為原共用 build/log cache，須由 root 給排程與 cache 租約，不能與完整 native/required-eight 寫者並行。無新增性能門檻；收益可零或負，更密集喚醒的 CPU 成本尚待量測。\n\n包內保留 25 個 source publication 原命令與全部 streams。原 preparation recorder 將後 7 個 commit 後命令的 task/source 標籤仍記為 base E；實際 HEAD/commit/push/remote 輸出均為 S。原件不改，`SOURCE_AUDIT_BINDING_ADDENDUM.json` 另列每命令真實 base→S 身份；當時沒有任何測試執行。\n\n下一步：root 配置 runtime/cache 租約後，以已獨審 helper 逐原完整 19 方法保留正式與 component 收據；不在靜審準備階段宣稱執行通過。\n'''
(O/'PROGRESS.md').write_text(progress)

# Detach the one-leaf runtime snapshot before advancing its own branch with evidence.
# The private index continues to describe S; no read-tree/add or external index is used.
git('checkout','--detach',S)
index_hash=h((R/'.git/index').read_bytes())
root=entries(S);evidence=entries(S+':evidence')
assert PREFIX.encode() not in evidence
leaf={p.name.encode():(b'100644',b'blob',blob(p.read_bytes())) for p in (archive,O/'INDEX.json',O/'PROGRESS.md')}
evidence[PREFIX.encode()]=(b'040000',b'tree',tree(leaf).encode())
root[b'evidence']=(b'040000',b'tree',tree(evidence).encode())
E=commit(tree(root),S,'docs: preserve issue 214 fixture preparation and static reviews')
expected=sorted('evidence/'+PREFIX+'/'+p.name for p in (archive,O/'INDEX.json',O/'PROGRESS.md'))
assert sorted(git('diff-tree','--no-commit-id','--name-only','-r',S,E).decode().splitlines())==expected
git('update-ref','refs/heads/'+BR,E,S)
git('push','origin',E+':refs/heads/'+BR)
assert git('ls-remote','origin','refs/heads/'+BR).decode().split()[0]==E

body_path=Path('/tmp/issue214-http-fixture-prbody-20261024/PR_BODY.md')
original_body=body_path.read_text()
(body_path.parent/'PR_BODY.before-preparation-publication.md').write_text(original_body)
body=original_body.replace('尚未提交；準備與普通 push 收據目前留雲端，不冒原件已公開',f'`{E}`；`evidence/{PREFIX}/`，完成準備原件完整封包與逐 member roundtrip')
body=body.replace('| 原整套 workbench HTTP 正式驗收 |','| helper 獨立靜審 | 20 checks／0 findings；AST/身份/原期限與完整方法核對，非執行通過 |\n| 原整套 workbench HTTP 正式驗收 |')
body=body.replace('測試尚未執行，helper 正交第二人審查。','測試尚未執行；helper 已由第二人靜審 20/0。')
body+='\n準備原命令中的 commit 後 7 筆身份標籤更正另保留於包內 `SOURCE_AUDIT_BINDING_ADDENDUM.json`；原始 streams 不改，沒有將準備命令冒稱測試執行。\n'
body_path.write_text(body)
body_branch=BR+'-prbody'
assert git('ls-remote','origin','refs/heads/'+body_branch)==b''
body_root=entries(E);body_root[b'PR_BODY.md']=(b'100644',b'blob',blob(body.encode()))
D=commit(tree(body_root),E,'docs: describe issue 214 fixture scope and unrun validation')
assert git('diff-tree','--no-commit-id','--name-only','-r',E,D).decode().splitlines()==['PR_BODY.md']
git('update-ref','refs/heads/'+body_branch,D,'0'*40)
git('push','origin',D+':refs/heads/'+body_branch)
assert git('ls-remote','origin','refs/heads/'+body_branch).decode().split()[0]==D
assert git('rev-parse','HEAD').decode().strip()==S
assert git('status','--porcelain=v1','--untracked-files=all')==b''
assert h((R/'.git/index').read_bytes())==index_hash
result={'sourceSHA':S,'evidenceSHA':E,'prbodySHA':D,'sourceBranch':BR,'prbodyBranch':body_branch,'prefix':'evidence/'+PREFIX,'repoHEAD':S,'repoDetached':True,'indexUnchangedDuringIndexFreePublication':True,'ordinaryPushAndRemoteMatch':True,'subjectExecutions':0,'formal19':'UNRUN','components':'UNRUN','helperPeer':'20/0','sourcePeer':'14/0','archiveSHA256':index['archiveSHA256'],'archiveBytes':index['archiveBytes'],'memberCount':index['memberCount'],'index':str(O/'INDEX.json'),'prbodySHA256':h(body.encode()),'next':'Runtime materialization and explicit root cache lease; no subject started.'}
dump(O/'DELIVERY.json',result)
print(json.dumps(result,ensure_ascii=False))
