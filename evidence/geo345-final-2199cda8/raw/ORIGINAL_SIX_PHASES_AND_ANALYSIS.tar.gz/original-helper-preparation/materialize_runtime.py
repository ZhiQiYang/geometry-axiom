"""Expand this owner's S snapshot only. Never import a subject or touch native cache."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil

P=Path(__file__).parent
R=Path('/workspace/issue214-http-fixture-work-20261024')
O=Path('/workspace/issue214-runtime-materialization-20261024')
S='2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not O.exists()
O.mkdir()
spec=importlib.util.spec_from_file_location('original_capture',C)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
for name in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):
    env.pop(name,None)
rec=cap.Recorder(O/'commands',env,S)
def run(args,data=None):
    row,stdout,stderr=rec.run(args,cwd=R,data=data,timeout=120,check=False,source_sha=S,source_variant='runtime-sparse-materialization-only-no-subject-no-build')
    if row['actual_process_returncode']!=0:raise RuntimeError('Original command failed '+row['directory'])
    return stdout
def git(*args,data=None):return run(['git',*args],data)

plan_raw=(P/'RUNTIME_MATERIALIZATION_PLAN.json').read_bytes()
plan=json.loads(plan_raw);assert plan['sourceSHA']==S and plan['selectedCount']==834
(O/'PLAN_834_BEFORE.json').write_bytes(plan_raw)
dump(O/'PLAN_REVISION.json',{'sourceSHA':S,'initialStaticProposal':{'files':735,'logicalBytes':13082311,'minimumAllocatedBytes':14651392},'approvedRevision':{'files':834,'logicalBytes':14713787,'minimumAllocatedBytes':16486400},'addedReason':'Retain all99 additional tests-root C/H/INC primary/harness files so the original inspect_all static registry scan also sees original non-selected binary sources. No runner/source/threshold change.','preMaterializationPlanSHA256':h(plan_raw),'initialPlanFileWasRevisedInPlace':True,'originalInitialCountsPreservedHere':True,'subjectExecutions':0})
free=shutil.disk_usage(R).free
assert free>=plan['minimum4096AllocatedBytes']+12*1024*1024,'Environment: insufficient source/index rewrite headroom'
run(['df','-B1','/workspace','/tmp'])
assert git('rev-parse','HEAD').decode().strip()==S
assert git('status','--porcelain=v1','--untracked-files=all')==b''
tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('write-tree').decode().strip()==tree
before={'head':S,'tree':tree,'indexSHA256':h((R/'.git/index').read_bytes()),'indexBytes':(R/'.git/index').stat().st_size,'sourceOnlyPhysicalFile':'tests/test_rule_case_workbench_http.py','freeBytes':free}
(O/'SPARSE_BEFORE.txt').write_bytes((R/'.git/info/sparse-checkout').read_bytes())
def escaped(name):
    for char in ('\\','*','?','[',']'):
        name=name.replace(char,'\\'+char)
    return '/'+name
patterns=('\n'.join(escaped(row['path']) for row in plan['paths'])+'\n').encode()
(O/'SPARSE_AFTER_REQUEST.txt').write_bytes(patterns)
git('sparse-checkout','set','--no-cone','--stdin',data=patterns)
assert git('rev-parse','HEAD').decode().strip()==S
assert git('write-tree').decode().strip()==tree
assert git('diff','--name-only')==b''
assert git('diff','--cached','--name-only')==b''
assert git('status','--porcelain=v1','--untracked-files=all')==b''
actual=[]
for row in plan['paths']:
    path=R/row['path'];assert path.is_file() and not path.is_symlink()
    raw=path.read_bytes();st=path.stat()
    actual.append({**row,'physicalBytes':len(raw),'sha256':h(raw),'allocatedBytes':st.st_blocks*512,'device':st.st_dev,'inode':st.st_ino})
assert h((R/'tests/test_rule_case_workbench_http.py').read_bytes())=='82e248c664c2e591cd320037a141bfa4d52924ac2397274ad23af9fb7864b7fc'
known={row['path'] for row in actual}
for path in R.rglob('*'):
    if '.git' in path.relative_to(R).parts or not path.is_file():continue
    assert path.relative_to(R).as_posix() in known,'Unexpected physical source file'
dump(O/'PHYSICAL_INPUTS.json',actual)
result={'sourceSHA':S,'before':before,'after':{'head':S,'tree':tree,'indexSHA256':h((R/'.git/index').read_bytes()),'indexBytes':(R/'.git/index').stat().st_size,'fileCount':len(actual),'sourceBytes':sum(row['physicalBytes'] for row in actual),'allocatedBytes':sum(row['allocatedBytes'] for row in actual),'freeBytes':shutil.disk_usage(R).free},'sourceAndCompleteIndexTreeUnchanged':True,'indexStatAndSparseBitsExpectedToChange':True,'subjectExecutions':0,'nativeCacheTouched':False,'runtimeReadyOnlyForScheduledOriginalJudge':True,'globalCacheLeaseStillRequired':True}
run(['df','-B1','/workspace','/tmp'])
dump(O/'RESULT.json',result)
print(json.dumps(result,ensure_ascii=False))
