# #214 A4：單一 workbench HTTP fixture 的準備方案

Root 限定分支 `codex/issue214-http-fixture-20261024`，基底 `3c6633575ec0f9dccf35898380202aad8d0ffddf`（與 L 同產品）。本輪只有 repo 外一檔原件/候選/diff與靜態核，沒有建工作樹、分支或新 S，未 import 套件、compile、native、Chrome 或 bench。

候選只在 `tests/test_rule_case_workbench_http.py:40` 的原 Thread 加 `kwargs={"poll_interval":0.05}`。此值源自既有 issue214 A4 候選，是測試 server 的 shutdown 輪詢，不是 HTTP/native response timeout 或新的產品合格門檻。其餘19方法與全部helper AST同，tearDown 的 adapter.close→shutdown→server_close→join(2)順序、thread-dead/active-none斷言、每方法各自server/session均保。server_close 內還會呼叫一次 adapter.close，觀測時須標為 nested，不能和外層inclusive秒數重複加總。

## 動態量測（只列未執行 request，待 root 時槽）

1. 先在獨立乾淨基底以原 `python3 tests/run_all.py --build --only test_rule_case_workbench_http` 捕捉完整原19方法。這個 --only 只選整個既有suite，不選方法；不改fixtures/預期或任何既有15/30秒、5/10秒事件與join期限。候選採用後同一原命令再跑一次。原run_all suite timeout1200，最外層c387/reaper timeout=None，stack16MiB。記實際命令與版本、SHA/tree/index、source/test bytehash、原stdout/stderr、父程序退出碼與19個方法真結果，不把registry19當實跑。
2. Component另列診斷phase（不冒原run_all正式row）：由repo外透明觀察器載入原完整19方法並用原unittest結果，無刪選/取代assert；相同觀察器用在各variant。量 whole-suite wall與每方法 setUp/test/tearDown；component對每個實際 adapter.close/server.shutdown/server_close/thread.join 以 `time.monotonic_ns` entry/exit透明記錄，同一boundmethod、原args/kwargs/return/throw不變，失敗也記原exception。觀察需標nested parent-span，inclusive不能相加作淨wall。觀察器只在repo外，不改原時間函式、不mock HTTP/native回覆、不增等待、不攔或更換child。先核同一觀察器在兩variant都用；觀察開銷與baseline原乾淨run分開。
3. 基線/候選/撤回/恢復各真程序、只按root核可固定次序跑一次，不為追收益重抽。每phase19完整結果與原caller/child lifecycle保；沒有新數值通過門檻，淨收益可為0/負。報wall與實際shutdown/join/close分量及CPU；不把19×0.45=8.55秒當實績或上界。環境/編譯失敗另分類保原碼，不移除方法重跑成綠。
4. polling優化的撤回是**語意等價**：原/候選/撤回/恢復19個語意結果都應0；不能硬造功能assert紅或把變慢當既有功能kill。可以原source對照與觀察的poll設定/實際呼叫說明機制，但不新增只照抄實作的測試來充數。若原性能沒有改善，如實保留，不能放寬斷言追秒數。

## 生命週期反證與界線

- 原測例 `test_cancel_during_real_native_child_discards_late_receipt_and_reaps`、`test_close_reopen_during_real_native_child_does_not_revive_old_run`、`test_host_shutdown_waits_for_real_child_cleanup_before_returning`、project generation/serial/timeout 全部要真跑，保持5秒hold/release、10秒worker join、privateDirectoryRemoved、PID消失、RETIRED/無receipt等精確原斷言。
- 如額外做清理能力刀，只在隔離測試copy精確撤掉fixture shutdown，保join(2)/原thread-dead斷言，由原正常unittest AssertionFailure證紅；完整恢復再0。這是清理守門反證，不是poll改動收益證明。負控若不紅或僅setup/loader/timeout crash，標未證，不能替換成任意紅。
- 不預設刪join一定紅：shutdown本來會等serve_forever退出，去掉join可能語意仍綠。沒有具名真反證之前不得把它計作已殺控制；不加人工新deadline或調時間函式強迫紅。

## 隔離與後續

Peer 接受後才建新的獨立薄Git checkout：只物化本檔作source候選與完整原index，objects用root主Git的只讀alternate，不改主列車／舊323／#325/#331/#333。實跑時再由root排明確runtime來源/bridge lease與容量；本檔需要真bridge，不能用僅一檔薄source假跑。可按exact closure物化產品/tests/fixtures，或使用已釋放同產品runtime配合明示test-sourcevariant，身份必真記，不能共用可寫source inode。別在這個準備階段新clone整樹或占C槽。

此修正只屬測試fixture工程片，不解決整案214、全native/全部HTTP或產品性能；`tests/test_serve.py` 的51方法與198/1028行兩個thread不在本片。完成仍須原mutate --check判closure影響，必要變更由root在新列車處理，不能偷改已固定L。
