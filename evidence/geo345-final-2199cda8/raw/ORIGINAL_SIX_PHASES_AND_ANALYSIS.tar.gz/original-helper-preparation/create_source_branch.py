from pathlib import Path
import hashlib, importlib.util, json, os, subprocess

P = Path(__file__).parent
R = Path('/workspace/issue214-http-fixture-work-20261024')
B = '3c6633575ec0f9dccf35898380202aad8d0ffddf'
BRANCH = 'codex/issue214-http-fixture-20261024'
LEAF = 'tests/test_rule_case_workbench_http.py'
C = Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
assert hashlib.sha256(C.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
s = importlib.util.spec_from_file_location('original_capture', C)
cap = importlib.util.module_from_spec(s)
s.loader.exec_module(cap)
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1', PYTHONDONTWRITEBYTECODE='1', LANG='C.UTF-8', LC_ALL='C.UTF-8')
for n in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR'):
    env.pop(n, None)
rec = cap.Recorder(P/'source-publication', env, B)
def run(argv, cwd=P, data=None):
    row, out, err = rec.run(list(map(str, argv)), cwd=cwd, data=data, timeout=120, source_sha=B, source_variant='issue214-single-fixture-thin-source-preparation', check=False)
    (P/'source-publication/commands.json').write_text(json.dumps(rec.rows, ensure_ascii=False, indent=2)+'\n')
    if row['actual_process_returncode'] != 0:
        raise RuntimeError('Original command failed: '+str(row['directory']))
    return out

assert not R.exists(), 'Do not touch an existing owner worktree'
assert hashlib.sha256((P/'CANDIDATE.patch').read_bytes()).hexdigest() == '89db8f9feff3dbb6104feb4aba1d5d594d908719f3e206498ceb0f5b719aeeef'
run(['df', '-B1', '/workspace', '/tmp'])
# Read repository instructions before preparing the one-leaf branch.
for leaf in ('AGENTS.md', 'geometry-guide/PRODUCT-VISION.md'):
    raw = run(['git', '--git-dir=/workspace/geometry-axiom/.git', 'show', B+':'+leaf])
    (P/('BASE_'+Path(leaf).name)).write_bytes(raw)
run(['git', 'init', R])
(R/'.git/objects/info/alternates').write_text('/workspace/geometry-axiom/.git/objects\n')
run(['git', 'sparse-checkout', 'init', '--no-cone'], R)
run(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], R, ('/'+LEAF+'\n').encode())
run(['git', 'checkout', '-b', BRANCH, B], R)
assert (R/LEAF).read_bytes() == (P/'original.py.txt').read_bytes()
assert run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], R) == b''
run(['git', 'config', 'user.name', 'Codex'], R)
run(['git', 'config', 'user.email', 'codex@openai.com'], R)
run(['git', 'remote', 'add', 'origin', 'https://github.com/ZhiQiYang/geometry-axiom.git'], R)
remote = run(['git', 'ls-remote', 'origin', 'refs/heads/'+BRANCH], R)
assert remote == b'', 'Assigned branch already exists; preserve and inspect rather than overwrite'
run(['git', 'apply', '--check', P/'CANDIDATE.patch'], R)
run(['git', 'apply', P/'CANDIDATE.patch'], R)
assert (R/LEAF).read_bytes() == (P/'candidate.py.txt').read_bytes()
assert run(['git', 'diff', '--name-only'], R).decode().splitlines() == [LEAF]
run(['git', 'diff', '--check'], R)
run(['git', 'add', '--', LEAF], R)
run(['git', 'commit', '-m', 'test: shorten workbench HTTP fixture shutdown polling'], R)
sha = run(['git', 'rev-parse', 'HEAD'], R).decode().strip()
assert run(['git', 'rev-parse', 'HEAD^'], R).decode().strip() == B
assert run(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', sha], R).decode().splitlines() == [LEAF]
assert run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], R) == b''
run(['git', 'push', '-u', 'origin', 'HEAD:refs/heads/'+BRANCH], R)
remote = run(['git', 'ls-remote', 'origin', 'refs/heads/'+BRANCH], R)
assert remote.decode().split()[0] == sha
physical = []
for q in R.rglob('*'):
    if '.git' in q.relative_to(R).parts or not q.is_file():
        continue
    physical.append(q.relative_to(R).as_posix())
assert physical == [LEAF]
run(['df', '-B1', '/workspace', '/tmp'])
result = dict(sourceSHA=sha, baseSHA=B, branch=BRANCH, repo=str(R), ordinaryPush=True, remoteSameSHA=True,
              subjectExecutions=0, runtimeNotMaterialized=True, physicalSourceFiles=physical,
              indexBytes=(R/'.git/index').stat().st_size,
              objectAlternateReadOnly='/workspace/geometry-axiom/.git/objects',
              changedPaths=[LEAF], metadataOutput=str(P/'source-publication'))
(P/'SOURCE_PUBLICATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(result, ensure_ascii=False))
