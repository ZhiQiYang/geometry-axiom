"""Append only the completed sparse-runtime preparation and truthful PR state."""
from pathlib import Path
import hashlib,importlib.util,io,json,os,tarfile
P=Path(__file__).parent; R=Path('/workspace/issue214-http-fixture-work-20261024')
O=Path('/workspace/issue214-runtime-publication-20261024')
I=Path('/workspace/issue214-runtime-materialization-20261024')
S='2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'; E1='3bbbcf0063bb7ef34d908d370270dfc5d83f297c'; D1='7696528035c3132ab8c8875dd9bad27c29210e52'
BR='codex/issue214-http-fixture-20261024'; PRE=b'issue214-fixture-2199cda8'
C=Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not O.exists();O.mkdir()
sp=importlib.util.spec_from_file_location('original_capture',C); cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
for n in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):env.pop(n,None)
rec=cap.Recorder(O/'commands',env,S)
def git(*args,data=None):
    row,stdout,stderr=rec.run(['git',*args],cwd=R,data=data,timeout=120,check=False,source_sha=S,source_variant='runtime-preparation-publication-only-clean-source')
    if row['actual_process_returncode']!=0:raise RuntimeError('Original command failed '+row['directory'])
    return stdout
def entries(t):
    es={}
    for row in git('ls-tree','-z',t).split(b'\0'):
        if row:
            meta,n=row.split(b'\t',1);m,k,oid=meta.split(b' ');es[n]=(m,k,oid)
    return es
def tree(es):return git('mktree','-z',data=b''.join(m+b' '+k+b' '+oid+b'\t'+n+b'\0' for n,(m,k,oid) in sorted(es.items()))).decode().strip()
def blob(raw):return git('hash-object','-w','--stdin',data=raw).strip()
def commit(t,parent,msg):return git('commit-tree',t,'-p',parent,data=(msg+'\n').encode()).decode().strip()
assert git('rev-parse','HEAD').decode().strip()==S
assert git('status','--porcelain=v1','--untracked-files=all')==b''
ih=h((R/'.git/index').read_bytes())
assert git('rev-parse','refs/heads/'+BR).decode().strip()==E1
assert git('rev-parse','refs/heads/'+BR+'-prbody').decode().strip()==D1
result=json.loads((I/'RESULT.json').read_text());assert result['subjectExecutions']==0 and result['nativeCacheTouched'] is False and result['after']['fileCount']==834
sources={p.relative_to(I).as_posix():p for p in sorted(I.rglob('*')) if p.is_file()}
sources['tools/materialize_runtime.py']=P/'materialize_runtime.py'
sources['tools/publish_runtime_preparation.py']=Path(__file__)
sources['tools/RUNTIME_MATERIALIZATION_PLAN.json']=P/'RUNTIME_MATERIALIZATION_PLAN.json'
index={'schema':'issue214-runtime-materialization-completed-originals/1','sourceSHA':S,'subjectExecutions':0,'memberCount':len(sources),'members':[]}
archive=O/'runtime-preparation-originals.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf:
    for n,p in sources.items():
        assert not p.is_symlink();raw=p.read_bytes();st=p.stat();ti=tarfile.TarInfo(n);ti.size=len(raw);ti.mode=st.st_mode&0o777;ti.mtime=st.st_mtime;tf.addfile(ti,io.BytesIO(raw))
        index['members'].append({'member':n,'sourcePath':str(p),'bytes':len(raw),'sha256':h(raw)})
with tarfile.open(archive,'r:gz') as tf:
    assert tf.getnames()==list(sources)
    for m,row in zip(tf.getmembers(),index['members']):
        raw=tf.extractfile(m).read();assert len(raw)==row['bytes'] and h(raw)==row['sha256'] and raw==sources[m.name].read_bytes()
index.update(archive=archive.name,archiveBytes=archive.stat().st_size,archiveSHA256=h(archive.read_bytes()),roundtripPassed=True)
dump(O/'INDEX.json',index)
oldprogress=git('show',E1+':evidence/'+PRE.decode()+'/PROGRESS.md').decode()
progress=oldprogress+'\n## Runtime materialization\n\n已完成授權的834固定Git檔物化，14,713,787B／allocated16,486,400B；S與完整index tree不變，raw index的stat/skip-worktree位元變化另存原件。735→834僅補99個tests-root C/H/inc，使原inspect_all連未選中registry來源也完整；沒有改judge。仍未import subject／編譯／HTTP／native／量測，未碰共用 `/tmp/geometry-tests`，動態須等root租約。原單檔薄來源描述屬先前完成階段，現runtime已物化。\n'
root=entries(E1);ev=entries(E1+':evidence');pref=entries(E1+':evidence/'+PRE.decode())
assert b'runtime-materialization' not in pref
sub={p.name.encode():(b'100644',b'blob',blob(p.read_bytes())) for p in (archive,O/'INDEX.json')}
pref[b'runtime-materialization']=(b'040000',b'tree',tree(sub).encode());pref[b'PROGRESS.md']=(b'100644',b'blob',blob(progress.encode()))
ev[PRE]=(b'040000',b'tree',tree(pref).encode());root[b'evidence']=(b'040000',b'tree',tree(ev).encode())
E=commit(tree(root),E1,'docs: record isolated issue 214 runtime materialization')
paths=git('diff-tree','--no-commit-id','--name-only','-r',E1,E).decode().splitlines()
assert len(paths)==3 and all(p.startswith('evidence/'+PRE.decode()+'/') for p in paths)
git('update-ref','refs/heads/'+BR,E,E1);git('push','origin',E+':refs/heads/'+BR)
assert git('ls-remote','origin','refs/heads/'+BR).decode().split()[0]==E
bp=Path('/tmp/issue214-http-fixture-prbody-20261024/PR_BODY.md');before=bp.read_text();(bp.parent/'PR_BODY.before-runtime-materialization.md').write_text(before)
body=before.replace(E1,E).replace('完成準備原件完整封包與逐 member roundtrip','完成準備與runtime物化原件完整封包、逐 member roundtrip')
body=body.replace('目前只物化單檔薄來源，未編譯、未跑 native／HTTP／Chrome／bench','隔離來源已物化 834 個固定 Git 檔（約 16.5MB allocated），S 與完整 index tree 不變；未編譯、未跑 native／HTTP／Chrome／bench')
bp.write_text(body)
bt=entries(D1);bt[b'PR_BODY.md']=(b'100644',b'blob',blob(body.encode()));D=commit(tree(bt),D1,'docs: update issue 214 runtime preparation state')
assert git('diff-tree','--no-commit-id','--name-only','-r',D1,D).decode().splitlines()==['PR_BODY.md']
git('update-ref','refs/heads/'+BR+'-prbody',D,D1);git('push','origin',D+':refs/heads/'+BR+'-prbody')
assert git('ls-remote','origin','refs/heads/'+BR+'-prbody').decode().split()[0]==D
assert git('rev-parse','HEAD').decode().strip()==S and git('status','--porcelain=v1','--untracked-files=all')==b''
assert h((R/'.git/index').read_bytes())==ih
delivery={'sourceSHA':S,'evidenceSHA':E,'prbodySHA':D,'sourceBranch':BR,'prbodyBranch':BR+'-prbody','ordinaryPushRemoteMatch':True,'subjectExecutions':0,'formal19':'UNRUN','components':'UNRUN','runtimeFileCount':834,'runtimeAllocatedBytes':16486400,'runtimeCleanDetachedSourceSHA':S,'sharedNativeCacheTouched':False,'originalPreparationPackage':'/workspace/issue214-http-fixture-preparation-publication-20261024/INDEX.json','runtimePackage':str(O/'INDEX.json'),'PR_REQUEST':'/tmp/issue214-http-fixture-prbody-20261024/PR_REQUEST.json','PR_BODY_SHA256':h(body.encode()),'sourcePeer':'14/0','helperPeer':'20/0'}
dump(O/'DELIVERY.json',delivery);print(json.dumps(delivery,ensure_ascii=False))
