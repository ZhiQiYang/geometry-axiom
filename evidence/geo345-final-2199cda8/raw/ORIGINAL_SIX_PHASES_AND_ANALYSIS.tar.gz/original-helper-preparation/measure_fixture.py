"""One scheduled #214 phase. Preparation only until root grants its cache lease.

Formal mode invokes the original whole-suite run_all command. Component mode
uses the original _unittest_runner and run_all.run_process watchdog unchanged;
observations and an explicitly labelled in-memory withdrawal are diagnostic.
"""
from pathlib import Path
import argparse, ast, functools, hashlib, importlib.util, json, os, resource
import sys, threading, time, traceback

BASE = '3c6633575ec0f9dccf35898380202aad8d0ffddf'
FIXED = '2199cda8896b47c7ad2b6c10479e5e0cbdb67c83'
LEAF = 'tests/test_rule_case_workbench_http.py'
OLD = 'self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)'
NEW = 'self.thread = threading.Thread(target=self.server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)'
OLD_HASH = 'a5eae2c6cdadc80354503d858930a0a4d728d53eb63e528f150d42fa60c492bc'
NEW_HASH = '82e248c664c2e591cd320037a141bfa4d52924ac2397274ad23af9fb7864b7fc'
CAPTURE = Path('/workspace/geo288-main-merge-20261023/bound-3d681636/p73/capture.py')
REAPER = Path('/workspace/geo261-environment/reap_children.py')
PINS = {
    'tests/run_all.py': 'a9be8456567725b0138474195160e1414d384ef4eb09ae8a1b144dfdf69d2dc9',
    'tests/_unittest_runner.py': 'f4e72e7a771f903094d6973874da8ccb2c98ddb4ff51571cb9179eabe284290e',
    'tests/binaries.py': 'a0b797a44918be0d5aac2a3a947bdab9d445abbf0111839508c99643f17cc651',
}
H = lambda b: hashlib.sha256(b).hexdigest()
def dump(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
def no_alias(path):
    path = path.absolute()
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise RuntimeError('Refuse aliased source/output: '+str(path))
    return path.resolve()
def execution_bytes(repo, phase):
    physical = (repo/LEAF).read_bytes()
    if phase == 'original':
        assert H(physical) == OLD_HASH
        return physical
    assert H(physical) == NEW_HASH, 'Fixed source file differs from reviewed candidate'
    if phase == 'withdrawn':
        text = physical.decode()
        assert text.count(NEW) == 1
        physical = text.replace(NEW, OLD).encode()
        assert H(physical) == OLD_HASH
    return physical

def observed_runner(repo, out, phase, observe):
    """Run the byte-identical original judge; never change its outcomes."""
    target = (repo/LEAF).resolve()
    source = execution_bytes(repo, phase)
    (out/'executed-test-source.py.txt').write_bytes(source)
    sys.path[:0] = [str(repo/'tests'), str(repo)]
    runner = load(repo/'tests/_unittest_runner.py', 'issue214_original_unittest_runner')
    events, current = [], {'test': None, 'phase': 'class-setup'}
    local, event_lock = threading.local(), threading.Lock()
    original_spec = importlib.util.spec_from_file_location
    original_result = runner._ParentResult
    def span(label, call):
        stack = getattr(local, 'stack', [])
        with event_lock:
            key = len(events)
            event = {'id': key, 'parent': stack[-1] if stack else None,
                     'test': current['test'], 'phase': current['phase'],
                     'component': label, 'thread': threading.get_ident(),
                     'start_ns': time.monotonic_ns(), 'cpu_start_ns': time.process_time_ns()}
            events.append(event)
        local.stack = [*stack, key]
        try:
            return call()
        except BaseException as exc:
            event['exception_type'] = type(exc).__name__
            raise
        finally:
            event.update(end_ns=time.monotonic_ns(), cpu_end_ns=time.process_time_ns())
            local.stack = stack
    def instrument(module):
        if not observe:
            return
        cls = module.WorkbenchHTTP
        setup, teardown = cls.setUp, cls.tearDown
        @functools.wraps(setup)
        def timed_setup(self):
            current['phase'] = 'setUp'
            def perform():
                result = setup(self)
                saved = []
                for obj, name, label in ((self.adapter, 'close', 'adapter.close'),
                                         (self.server, 'shutdown', 'server.shutdown'),
                                         (self.server, 'server_close', 'server.server_close'),
                                         (self.thread, 'join', 'server-thread.join')):
                    original = getattr(obj, name)
                    had = name in vars(obj)
                    previous = vars(obj).get(name)
                    @functools.wraps(original)
                    def timed(*args, _f=original, _label=label, **kwargs):
                        return span(_label, lambda: _f(*args, **kwargs))
                    setattr(obj, name, timed)
                    saved.append((obj, name, had, previous))
                self._issue214_saved_observation_methods = saved
                return result
            try:
                return span('setUp', perform)
            finally:
                current['phase'] = 'test'
        @functools.wraps(teardown)
        def timed_teardown(self):
            current['phase'] = 'tearDown'
            try:
                return span('tearDown', lambda: teardown(self))
            finally:
                for obj, name, had, previous in getattr(self, '_issue214_saved_observation_methods', []):
                    if had:
                        setattr(obj, name, previous)
                    else:
                        delattr(obj, name)
                current['phase'] = 'test-finished'
        cls.setUp, cls.tearDown = timed_setup, timed_teardown
    class Proxy:
        def __init__(self, original): self.original = original
        def create_module(self, spec): return self.original.create_module(spec)
        def exec_module(self, module):
            if phase == 'withdrawn':
                exec(compile(source, str(target), 'exec'), module.__dict__)
            else:
                self.original.exec_module(module)
            instrument(module)
    def spec_for(name, location, *args, **kwargs):
        spec = original_spec(name, location, *args, **kwargs)
        if location is not None and Path(location).resolve() == target:
            spec.loader = Proxy(spec.loader)
        return spec
    class TimedResult(original_result):
        def startTest(self, test):
            current.update(test=test.id(), phase='test-start')
            self._issue214_start = (time.monotonic_ns(), time.process_time_ns())
            super().startTest(test)
        def stopTest(self, test):
            if observe:
                with event_lock:
                    events.append({'id': len(events), 'parent': None, 'test': test.id(),
                                   'phase': 'whole-test', 'component': 'whole-test',
                                   'start_ns': self._issue214_start[0], 'end_ns': time.monotonic_ns(),
                                   'cpu_start_ns': self._issue214_start[1], 'cpu_end_ns': time.process_time_ns()})
            super().stopTest(test)
            current.update(test=None, phase='between-tests')
    importlib.util.spec_from_file_location = spec_for
    runner._ParentResult = TimedResult
    try:
        code = runner.main([str(target), '--json-out', str(out/'original-unittest.json'),
                            '--log', str(out/'original-unittest.log')])
    finally:
        importlib.util.spec_from_file_location = original_spec
        runner._ParentResult = original_result
        dump(out/'components.json', {'observe': observe, 'events': events,
             'timing_limits': 'monotonic wall and process CPU deltas are inclusive; native child CPU is not included in these per-component CPU fields',
             'nested_close': 'server.server_close calls adapter.close; do not sum parent and child inclusive spans',
             'executedSourceSHA256': H(source), 'sourceVariant': phase,
             'originalJudgeUnchanged': True, 'performanceQualificationThreshold': None})
    return code

def watchdog(repo, out, phase, observe):
    # Reuse the original run_all process-group timeout, including its original
    # cleanup behavior. The outer c387/subreaper has no shorter timeout.
    sys.path[:0] = [str(repo/'tests'), str(repo)]
    original = load(repo/'tests/run_all.py', 'issue214_original_run_all_watchdog')
    command = [sys.executable, '-B', str(Path(__file__).resolve()), '--child',
               '--repo', str(repo), '--out', str(out), '--phase', phase,
               '--observe', 'on' if observe else 'off']
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = original.run_process(command, dict(os.environ), 1200, cwd=repo)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    (out/'original-run-process-exposed-output.txt').write_text(result.out)
    dump(out/'watchdog.json', {'command': command, 'originalTimeoutSeconds': 1200,
         'actual_child_exit': result.code, 'timed_out': result.timed_out,
         'seconds': result.seconds, 'reap_note': result.reap_note,
         'children_user_cpu_seconds_delta': after.ru_utime-before.ru_utime,
         'children_system_cpu_seconds_delta': after.ru_stime-before.ru_stime,
         'stream_limit': 'Original run_process exposes decoded stdout+stderr, not two separate raw inner pipes; complete exposed text is preserved.'})
    print(result.out, end='')
    return result.code if isinstance(result.code, int) and not result.timed_out else 2

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--phase', choices=('original','fixed','withdrawn','restored'), required=True)
    ap.add_argument('--observe', choices=('on','off'), default='on')
    ap.add_argument('--sha')
    ap.add_argument('--mode', choices=('formal','components'), default='components')
    ap.add_argument('--cache-lease-authorized', action='store_true')
    ap.add_argument('--child', action='store_true')
    ap.add_argument('--watchdog', action='store_true')
    a = ap.parse_args()
    if a.child: return observed_runner(a.repo, a.out, a.phase, a.observe=='on')
    if a.watchdog: return watchdog(a.repo, a.out, a.phase, a.observe=='on')
    assert a.cache_lease_authorized and not sys.flags.optimize
    assert a.sha == (BASE if a.phase=='original' else FIXED)
    assert a.mode != 'formal' or a.phase != 'withdrawn', 'In-memory withdrawal is a diagnostic, not original run_all'
    repo, out = no_alias(a.repo), no_alias(a.out)
    assert not out.exists() and not out.is_relative_to(repo) and not repo.is_relative_to(out)
    assert (repo/'.git').exists() and all((repo/n).is_file() for n in [LEAF,*PINS,'geometry-web/web_bridge.c'])
    for n, pin in PINS.items(): assert H((repo/n).read_bytes()) == pin, n
    assert H(CAPTURE.read_bytes()) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
    assert H(REAPER.read_bytes()) == '7d848d6c135b7f329852d16c6da5743effde8b29ccbbc6e70092b6ba25877760'
    executed = execution_bytes(repo, a.phase)
    source_ast = ast.parse(executed)
    names = [f.name for c in source_ast.body if isinstance(c, ast.ClassDef)
             for f in c.body if isinstance(f, ast.FunctionDef) and f.name.startswith('test_')]
    assert len(names) == 19 and len(set(names)) == 19
    out.mkdir(parents=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0',
               LANG='C.UTF-8', LC_ALL='C.UTF-8', GITHUB_SHA=a.sha, GITHUB_WORKSPACE=str(repo))
    cleared = []
    for key in list(env):
        if key.startswith('GEOMETRY_') or key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD','GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR'):
            cleared.append(key);env.pop(key)
    (out/'tmp').mkdir();env['TMPDIR']=str(out/'tmp');env['GEO261_REAPER_LOG']=str(out/'reaper.jsonl')
    cap = load(CAPTURE, 'issue214_original_capture')
    rec = cap.Recorder(out, env, a.sha)
    receipt = dict(sourceSHA=a.sha, phase=a.phase, mode=a.mode, observe=a.observe,
                   originalSuiteMethods=names, cacheLeaseAuthorized=True, passed=False,
                   performanceQualificationThreshold=None, sourceVariant=a.phase,
                   helperSHA256=H(Path(__file__).read_bytes()), executedTestSourceSHA256=H(executed),
                   physicalTestSourceSHA256=H((repo/LEAF).read_bytes()), clearedEnvironment=cleared,
                   originalSuiteTimeoutSeconds=1200, outerTimeout=None, commands=rec.rows)
    def guard(label):
        state={}
        for key, args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),
                          ('status',['status','--porcelain=v1','--untracked-files=all']),
                          ('cached',['diff','--cached','--name-only'])]:
            row, raw, err=rec.run(['git','-C',str(repo),*args],cwd=out,timeout=120,source_variant='issue214-source-'+label,check=False)
            assert row['actual_process_returncode']==0
            state[key]=raw.decode().strip()
        assert state['head']==a.sha and not state['status'] and not state['cached']
        state['testSHA256']=H((repo/LEAF).read_bytes())
        row, raw, _=rec.run(['git','-C',str(repo),'rev-parse','--git-path','index'],cwd=out,timeout=120,
                           source_variant='issue214-index-'+label,check=False)
        assert row['actual_process_returncode']==0
        index=Path(raw.decode().strip())
        if not index.is_absolute(): index=repo/index
        state['indexSHA256']=H(index.read_bytes())
        for n,pin in PINS.items(): assert H((repo/n).read_bytes())==pin,n
        return state
    code=2
    try:
        receipt['sourceBefore']=guard('before')
        soft, hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(16777216,hard))
        receipt['stackBytes']=16777216
        (out/'executed-test-source.py.txt').write_bytes(executed)
        if a.mode=='formal':
            prior=out/'preserved-before-formal-logs';prior.mkdir()
            for suffix in ('.log','.json','.unittest.log'):
                q=Path('/tmp/geometry-tests/run_all-logs')/('py_test_rule_case_workbench_http'+suffix)
                if q.exists():
                    assert q.is_file() and not q.is_symlink();(prior/q.name).write_bytes(q.read_bytes())
            command=[sys.executable,'-B',str(repo/'tests/run_all.py'),'--build','--only','test_rule_case_workbench_http']
        else:
            command=[sys.executable,'-B',str(Path(__file__).resolve()),'--watchdog','--repo',str(repo),
                     '--out',str(out),'--phase',a.phase,'--observe',a.observe]
        row,_,_=rec.run([sys.executable,'-B',str(REAPER),*command],cwd=repo,timeout=None,
                        source_variant='issue214-'+a.mode+'-'+a.phase,check=False)
        receipt['originalCommand']=row
        receipt['sourceAfter']=guard('after')
        assert receipt['sourceBefore']==receipt['sourceAfter']
        events=[json.loads(x)for x in(out/'reaper.jsonl').read_bytes().splitlines()]
        terminal=[x for x in events if x.get('event')=='完成'];assert len(terminal)==1
        assert terminal[0]['primary_returncode']==row['actual_process_returncode']
        if a.mode=='formal':
            for suffix in ('.log','.json','.unittest.log'):
                q=Path('/tmp/geometry-tests/run_all-logs')/('py_test_rule_case_workbench_http'+suffix)
                assert q.is_file();(out/('formal'+suffix)).write_bytes(q.read_bytes())
            report=json.loads((out/'formal.json').read_bytes())
        else:
            report=json.loads((out/'original-unittest.json').read_bytes())
            receipt['watchdog']=json.loads((out/'watchdog.json').read_bytes())
        receipt['originalUnittestReport']=report
        correct=report['total']==report['run']==report['passed']==19 and report['failed']==report['skipped']==0
        code=row['actual_process_returncode']
        if code==0 and not correct: code=2
        receipt['passed']=code==0
        assert H(Path(__file__).read_bytes())==receipt['helperSHA256'], 'Helper changed during phase'
    except BaseException:
        receipt['metadataError']=traceback.format_exc();receipt['passed']=False;code=2
    finally:
        receipt.update(actualExit=code, endedUTC=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
        dump(out/'RECEIPT.json',receipt)
    print(json.dumps({'mode':a.mode,'phase':a.phase,'actualExit':code,'passed':receipt['passed']},ensure_ascii=False))
    return code

if __name__=='__main__': raise SystemExit(main())
