# #214 A4 helper：待排程，未執行

Source S `2199cda8896b47c7ad2b6c10479e5e0cbdb67c83`，base E `3c6633575ec0f9dccf35898380202aad8d0ffddf`。正式 source 單leaf 已普通push，19方法未跑。当前 own checkout 只物化24KB測試檔，並不是可跑的 runtime；helper 會在缺原runner/bridge來源時拒絕。不得藉這個準備宣稱19通過。

Root 排定共享 `/tmp/geometry-tests` cache 租約並配置私有、完整必要runtime後，才執行。Linux 原 binaries cache硬釘此路徑，TMPDIR只隔離scratch，不能與完整native、required-eight或其他cache寫者並行。不可在browser readonly pool寫source。每phase新OUT，不自動重試或連跑；操作者先切私有source到所需真SHA，確認無其他consumer。

最外層由root原c387錄製以下正常入口，timeout=None。helper本身再以原subreaper包原程序；內層Python suite真時限是run_all註冊的1200秒。舊PLAN誤讀Suite預設900已原樣保存，未用錯誤值執行。

原基線正式row（repo必須真的在E）：

```
env -u PYTHONOPTIMIZE -u PYTHONPATH -u PYTHONHOME -u PYTHONSTARTUP -u NODE_OPTIONS \
python3 -B /tmp/issue214-http-fixture-preparation-20261024/measure_fixture.py \
  --repo <private-runtime-E> --sha 3c6633575ec0f9dccf35898380202aad8d0ffddf \
  --out /workspace/issue214-original-formal --mode formal --phase original \
  --cache-lease-authorized
```

候選正式row（repo真的在S）改用 `--sha 2199cda8896b47c7ad2b6c10479e5e0cbdb67c83 --phase fixed --out /workspace/issue214-fixed-formal`。底層原argv為 `python -B tests/run_all.py --build --only test_rule_case_workbench_http`，只選整個suite，不選方法。原三份專屬global log若已存在先保完整bytes，之後將新JSON/log/unittest.log複製到本phase OUT；沒有刪全域cache或其它suite原件。真19/19、零失敗、零skip與原exit0都必須成立，否則保原失敗，不能讓registry19代替實跑。

Component診斷用相同正常入口、`--mode components --observe on`，可選四phase：original實際HEAD=E；fixed/withdrawn/restored實際HEAD=S。withdrawn只在記憶體把已審那一行恢復為原設定，仍真記S與executedSource原hash；不寫source/index、不重標E。完整原_unittest_runner.py與原run_all.run_process byte-identical，1200秒watchdog/killpg/20秒pipe收尾照原邏輯，原19方法與所有原timeout/assertions保留。正式row與此診斷分開，不把後者叫原run_all row或full native。

觀察透傳同一原bound method、args/kwargs/return/throw，僅在repo外觀察setUp/tearDown、adapter.close、server.shutdown、server_close、server-thread.join以及whole-test。nested server_close→adapter.close要按parent欄讀，不把inclusive時間相加。monotonic wall與process CPU是觀察程序的inclusive數值；native子程序CPU另保原RUSAGE_CHILDREN差值，不能誇大為全系統獨占CPU。改成更短輪詢可能增加空閒喚醒，淨收益可以0/負，沒有新的性能通過門檻。

可另由root排一個 `components --phase original --observe off` 的完整19校準，與同一原流程observe on分開報開銷；不得用formal含build的wall直接減診斷wall當觀察成本。沒有自動多次重抽或挑安靜樣本。

原/候選/等價撤回/恢復的correctness都應為0。撤掉poll優化仍語意綠不是「功能突變已殺」；若要做shutdown生命週期控制，另行具名規劃，不能把join刪除後可能仍綠改成假陰性，也不增加假性能assert追求0/1/0。

原run_all.run_process對component child只暴露decode後stdout+stderr合併文字，完整原exposed text保存；不冒稱兩條OS raw child pipes、compiler已清除scratch或內部native每條pipe另有原件。原JSON、log、component events、真child/reaper/parent各exit、工具hash、實際source/index前後與16MiB stack均保。

`--child`、`--watchdog`只是helper內部端點，操作者不直接啟動。此包只有AST/小source核查，subjectExecutions=0；root時槽與實際runtime容量尚未放行。
