"""Publish only the reviewed GEO-314 PR body, recording every original Git stream."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import traceback

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--evidence-sha', required=True)
p.add_argument('--draft', required=True, type=Path)
p.add_argument('--out', required=True, type=Path)
a = p.parse_args()
F = 'cc67e2518f6ab331b5ab9fdbcd5bd6334134377f'
E = a.evidence_sha
source = Path('/tmp/g261-next314')
repo = Path('/workspace/geo314-prbody')
branch = 'codex/geo314-one-axis-stagger-20261022-prbody'
source_branch = 'codex/geo314-one-axis-stagger-20261022'
prefix = 'evidence/geo314-final-cc67e251/'
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert len(E) == 40 and all(c in '0123456789abcdef' for c in E)
assert not a.out.exists()
a.out.mkdir(parents=True)
spec = importlib.util.spec_from_file_location('original_capture', helper)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
recorder = capture.Recorder(a.out, env, F)
receipt = {'product_test_sha': F, 'source_evidence_sha': E, 'branch': branch,
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'online_pr_created_or_body_updated': False, 'history_rewritten_or_merged': False,
           'git_optional_locks': env['GIT_OPTIONAL_LOCKS']}

def git(*args, cwd=repo, check=True):
    return recorder.run(['git', *args], cwd=cwd, timeout=120, check=check,
                        source_variant='pull-request-body-publication-only')

def output(*args, cwd=repo):
    return git(*args, cwd=cwd)[1].decode().strip()

try:
    assert output('branch', '--show-current', cwd=source) == source_branch
    assert output('status', '--porcelain=v1', '--untracked-files=all', cwd=source) == ''
    assert output('rev-parse', 'HEAD', cwd=source) == E
    assert all(q.startswith(prefix) for q in output('diff', '--name-only', F, E, cwd=source).splitlines())
    assert output('ls-remote', '--exit-code', 'origin', 'refs/heads/' + source_branch, cwd=source).split() == [E, 'refs/heads/' + source_branch]
    assert output('branch', '--show-current') == branch
    assert output('status', '--porcelain=v1', '--untracked-files=all') == ''
    head, _, _ = git('rev-parse', '--verify', 'HEAD', check=False)
    assert head['actual_process_returncode'] == 128
    assert output('ls-files', '-z') == ''
    remote, remote_stdout, _ = git('ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch, check=False)
    assert remote['actual_process_returncode'] == 2 and remote_stdout == b''
    body = a.draft.read_bytes()
    text = body.decode('utf-8')
    assert F in text and E in text and body.endswith(b'\n')
    assert not any(q in text for q in ('FINAL_E_PENDING', 'TODO', '待填', '**待跑**'))
    (a.out / 'PR_BODY.original-draft.md').write_bytes(body)
    (repo / 'PR_BODY.md').write_bytes(body)
    git('add', '--', 'PR_BODY.md')
    git('diff', '--cached', '--check')
    assert output('diff', '--cached', '--name-only') == 'PR_BODY.md'
    git('commit', '-m', 'Document GEO-314 final cloud acceptance')
    D = output('rev-parse', 'HEAD')
    receipt.update(created_body_sha=D, body_bytes=len(body), body_sha256=hashlib.sha256(body).hexdigest())
    capture.dump(a.out / 'receipt.json', dict(receipt, commands=recorder.rows))
    assert output('ls-tree', '-r', '--name-only', 'HEAD') == 'PR_BODY.md'
    git('push', 'origin', 'HEAD:refs/heads/' + branch)
    assert output('ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch).split() == [D, 'refs/heads/' + branch]
    assert git('show', 'HEAD:PR_BODY.md')[1] == body
    assert output('status', '--porcelain=v1', '--untracked-files=all') == ''
    receipt.update(public_body_sha=D, body_bytes=len(body), body_sha256=hashlib.sha256(body).hexdigest(), exit_code=0)
except Exception:
    receipt.update(exit_code=1, error=traceback.format_exc())
finally:
    receipt.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=recorder.rows)
    capture.dump(a.out / 'receipt.json', receipt)
print(json.dumps({k: v for k, v in receipt.items() if k != 'commands'}, ensure_ascii=False))
raise SystemExit(receipt['exit_code'])
