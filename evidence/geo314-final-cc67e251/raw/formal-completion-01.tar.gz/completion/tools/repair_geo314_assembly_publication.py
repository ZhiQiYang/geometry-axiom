"""Preserve the original label collision and publish the already completed assembly job."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import traceback

F = 'cc67e2518f6ab331b5ab9fdbcd5bd6334134377f'
root = Path('/tmp/g261s7')
repo = Path('/tmp/g261-next314')
out = Path('/workspace/geo314-assembly-workflow-publication-repair')
branch = 'codex/geo314-one-axis-stagger-20261022'
helper = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not out.exists()
out.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', helper)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
env = dict(os.environ, LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
recorder = capture.Recorder(out, env, F)
receipt = {'schema': 'geo314-publication-label-repair/1', 'acceptance_sha': F,
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'product_or_test_rerun': False, 'original_receipts_modified': False,
           'classification': 'publication-only label collision with preserved assembly-final specialist archive'}

def git(*args):
    return recorder.run(['git', *args], cwd=repo, timeout=120,
                        source_variant='evidence-publication-only')[1].decode().strip()

try:
    original = json.loads((root / 'receipt.json').read_text())
    assert original['source_sha'] == F and original['ended_utc']
    outer = json.loads(Path('/workspace/geo314-final-outer/geo314-seven-final-cc67e251/receipt.json').read_text())
    assert outer['sha'] == F and outer['outer_process']['actual_process_returncode'] == original['exit_code']
    receipt['original_outer_exit_code'] = outer['outer_process']['actual_process_returncode']
    assert [j['job'] for j in original['jobs']] == ['native', 'canvas', 'assembly', 'documents', 'grid', 'space', 'timber']
    assert all(j['exit_code'] is not None and j.get('ended_utc') for j in original['jobs'])
    row = next(j for j in original['jobs'] if j['job'] == 'assembly')
    assert row['exit_code'] == row['inner_exit_code'] == 0 and row['derived_pass']
    assert row['receipt_validated'] and not row['over_ci_timeout'] and not row['errors']
    assert row['progress_publish_exit'] == 1
    assert git('branch', '--show-current') == branch
    assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
    assert all(q.startswith('evidence/geo314-final-cc67e251/') for q in git('diff', '--name-only', F, 'HEAD').splitlines())
    publisher = root / 'tools/publish_followup_progress.py'
    assert hashlib.sha256(publisher.read_bytes()).hexdigest() == 'c2fdeb5eb9174549c5a80726bdd37266b22f0f75ff94d744fdc82c0f384a14d2'
    failure = root / 'launch/assembly.publish.stderr'
    assert "assert not list(raw.glob(a.label + '-*.tar.gz'))" in failure.read_text()
    command = list(row['publication_command'])
    assert command[:3] == ['python3', '-B', str(publisher)]
    assert command[command.index('--label') + 1] == 'assembly'
    command[command.index('--label') + 1] = 'assembly-workflow'
    command[command.index('--result') + 1] = '原assembly測試0、CI內；原發布1因assembly-final封包撞名。只以獨立label補發布原輸出，不重跑或改判原測試'
    command[command.index('--next') + 1] = '封存整輪原終態與本次發布結果；保留原wrapper及publisher非零退出碼'
    for label, path in [('original-publish-stdout', root / 'launch/assembly.publish.stdout'), ('original-publish-stderr', failure)]:
        command += ['--input', label + '=' + str(path)]
    plan = out / 'PLAN.json'
    capture.dump(plan, {'acceptance_sha': F, 'original_wrapper_exit_code': original['exit_code'],
                        'original_assembly_row': row, 'repair_command': command,
                        'change': 'unique archive label only; original commands, tests and assertions unchanged'})
    command += ['--input', 'repair-plan=' + str(plan)]
    receipt.update(original_wrapper_exit_code=original['exit_code'], original_test_exit_code=row['exit_code'],
                   original_publication_exit_code=row['progress_publish_exit'], command=command)
    recorded, stdout, _ = recorder.run(command, cwd=repo, timeout=1200, check=False,
                                      source_variant='publication-only-unique-label-repair')
    receipt['publication_repair_process_exit_code'] = recorded['actual_process_returncode']
    assert recorded['actual_process_returncode'] == 0
    E = git('rev-parse', 'HEAD')
    assert git('ls-remote', '--exit-code', 'origin', 'refs/heads/' + branch).split() == [E, 'refs/heads/' + branch]
    assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
    receipt.update(public_evidence_sha=E, exit_code=0)
except Exception:
    receipt.update(exit_code=1, error=traceback.format_exc())
finally:
    receipt.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), commands=recorder.rows)
    capture.dump(out / 'receipt.json', receipt)
print(json.dumps({k: v for k, v in receipt.items() if k not in ('commands', 'command')}, ensure_ascii=False))
raise SystemExit(receipt['exit_code'])
