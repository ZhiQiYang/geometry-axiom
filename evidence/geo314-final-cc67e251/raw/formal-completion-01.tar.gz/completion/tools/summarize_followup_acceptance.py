#!/usr/bin/env python3
"""唯讀摘要既有 follow-up 收據；不是驗收裁判，不啟動產品、測試或編譯。"""

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re


BROWSER_JOBS = ('canvas', 'assembly', 'documents', 'grid', 'space', 'timber')
ARCHITECTURE_LABELS = ('architecture-cli', 'architecture-tests', 'product-architecture-tests')
TOTAL = re.compile(r'^合計\(已執行、有計數者\)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+(?:\.\d+)?)\s*$')
TABLE = re.compile(r'^(\S+)\s+(\d+|-)\s+(\d+|ok|-)\s+(\d+|FAIL|-)\s+(\d+|-)\s+(\d+(?:\.\d+)?|-)\s*(.*)$')
PROGRESS = re.compile(r'^\[(\d+)/(\d+)\]\s+(\S+)\s+…')
FOOTER = re.compile(r'^exit\s+(-?\d+)\s*[：:]')


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def fields(raw, names):
    """缺少原欄位保留 null，永不補零、通過或完成。"""
    return {name: raw.get(name) for name in names.split()}


def list_count(value):
    return len(value) if isinstance(value, list) else None


class Reader:
    """每個路徑僅取一次快照；來源變動或跨 input root 時不採用內容。"""

    def __init__(self):
        self.inputs = {}
        self.contents = {}
        self.lookup = {}
        self.issues = []

    def issue(self, path, reason):
        self.issues.append({'path': str(path), 'reason': reason})

    def read(self, path, root):
        path = Path(path).absolute()
        scoped_root = root.resolve()
        scope_error = None
        try:
            if not path.resolve().is_relative_to(scoped_root):
                scope_error = '收據參照越出指定 input root；未讀取'
        except (OSError, ValueError) as error:
            scope_error = str(error)
        # 每次先核 root，再查分 root 的 cache；其他 job 的已讀檔案不可繞過邊界。
        cache_key = (str(scoped_root), str(path))
        if scope_error is None and cache_key in self.lookup:
            key = self.lookup[cache_key]
            return {'input': key}, self.contents.get(key)
        key = f'input-{len(self.inputs) + 1:04d}'
        ref = {'path': str(path), 'scope_root': str(scoped_root),
               'available': False, 'bytes': None, 'sha256': None,
               'read_utc': now(), 'stable_during_read': None}
        self.inputs[key] = ref
        if scope_error is not None:
            ref['unavailable_reason'] = scope_error
            self.issue(path, scope_error)
            return {'input': key}, None
        self.lookup[cache_key] = key
        try:
            if not path.is_file():
                raise ValueError('原檔案不存在或不是一般檔案')
            before = path.stat()
            body = path.read_bytes()
            after = path.stat()
            stable = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            ref.update(bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
                       stable_during_read=stable)
            if not stable:
                raise ValueError('讀取時檔案有變動；只保留 bytes/hash，不採用內容')
            ref['available'] = True
            self.contents[key] = body
        except (OSError, ValueError) as error:
            ref['unavailable_reason'] = str(error)
            self.issue(path, str(error))
        return {'input': key}, self.contents.get(key)

    def obj(self, path, root):
        ref, body = self.read(path, root)
        if body is None:
            return ref, None
        try:
            value = json.loads(body)
            if not isinstance(value, dict):
                raise ValueError('原 JSON 頂層不是 object')
            return ref, value
        except (ValueError, UnicodeError) as error:
            self.issue(path, '無法採用原 JSON：' + str(error))
            return ref, None

    def text(self, path, root, excerpt=False):
        ref, body = self.read(path, root)
        result = {'source': ref, 'text': None}
        if body is not None:
            text = body.decode('utf-8', errors='replace')
            result['text'] = text[:32768] if excerpt else text
            if excerpt:
                result['excerpt_truncated'] = len(text) > 32768
        return result


def identity(raw_sha, requested):
    return {'recorded_sha': raw_sha,
            'matches_requested_sha': raw_sha == requested if isinstance(raw_sha, str) else None}


def errors_reference(raw, source, pointer):
    return {'recorded_error_count': list_count(raw.get('errors')),
            'original_errors': {'source': source, 'json_pointer': pointer}}


def command_summary(reader, raw, root, source, pointer, capture=False, version=False):
    result = {'original_metadata': {'source': source, 'json_pointer': pointer},
              **fields(raw, 'command cwd started ended started_epoch ended_epoch seconds '
                       'actual_process_returncode exit_code watchdog_expired timeout_expired '
                       'timeout_seconds owned_process_group_cleanup acceptance_sha source_sha '
                       'source_variant stdin_provided stdin_sha256')}
    if capture:
        directory = raw.get('directory')
        result['streams'] = None
        if isinstance(directory, str):
            directory = Path(directory)
            result['streams'] = {}
            for name in ('request.json', 'result.json', 'stdin.bin', 'stdout.bin', 'stderr.bin'):
                if version and name in ('stdout.bin', 'stderr.bin'):
                    result['streams'][name] = reader.text(directory / name, root, excerpt=True)
                else:
                    result['streams'][name] = reader.read(directory / name, root)[0]
    else:
        result['streams'] = {}
        for name in ('stdout', 'stderr', 'combined'):
            path = raw.get(name)
            if isinstance(path, str):
                result['streams'][name] = (reader.text(path, root, excerpt=True) if version
                                           else reader.read(path, root)[0])
            else:
                result['streams'][name] = None
    return result


def workflow(reader, root, job, requested, receipt_path=None):
    path = Path(receipt_path) if isinstance(receipt_path, str) else root / 'workflow' / job / 'receipt.json'
    source, raw = reader.obj(path, root)
    result = {'source': source, 'available': raw is not None, 'recorded': None,
              'sha_identity': None, 'versions': None, 'steps': None}
    if raw is None:
        return result, None
    result['recorded'] = fields(raw, 'schema sha job workflow_job_key matrix started ended status '
                                'exit_code seconds ci_timeout_minutes watchdog_factor over_ci_timeout '
                                'checkout_before checkout_after workflow_sha256 driver_sha256 '
                                'workflow_environment environment platform temporary_directory server_port '
                                'cleared_inherited_geometry_names notes')
    result['sha_identity'] = identity(raw.get('sha'), requested)
    versions = raw.get('versions')
    if isinstance(versions, list):
        result['versions'] = [command_summary(reader, v, root, source, f'/versions/{i}', version=True)
                              for i, v in enumerate(versions) if isinstance(v, dict)]
    steps = raw.get('steps')
    if isinstance(steps, list):
        result['steps'] = []
        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                reader.issue(path, f'原 steps/{i} 不是 object；未採用')
                continue
            row = fields(step, 'index name script_sha256 executed_run original_step')
            row['original_result'] = (command_summary(reader, step['result'], root, source, f'/steps/{i}/result')
                                      if isinstance(step.get('result'), dict) else None)
            result['steps'].append(row)
    return result, raw


def wrapper(reader, root, requested, expected_jobs):
    source, raw = reader.obj(root / 'receipt.json', root)
    result = {'source': source, 'available': raw is not None, 'recorded': None,
              'sha_identity': None, 'errors': None, 'jobs': []}
    if raw is not None:
        result['recorded'] = fields(raw, 'schema source_sha repo started_utc ended_utc exit_code '
                                    'stack_before stack_during tool_hashes policy')
        result['sha_identity'] = identity(raw.get('source_sha'), requested)
        result['errors'] = errors_reference(raw, source, '/errors')
    jobs = raw.get('jobs') if raw is not None else None
    for name in expected_jobs:
        matches = [(i, row) for i, row in enumerate(jobs or [])
                   if isinstance(row, dict) and row.get('job') == name] if isinstance(jobs, list) else None
        job = {'job': name, 'wrapper_occurrence_count': len(matches) if matches is not None else None,
               'wrapper_rows': None, 'workflow': None}
        if not matches:
            reader.issue(root / 'receipt.json', name + ' 原 wrapper job 尚不可用')
            job['workflow'], _ = workflow(reader, root, name, requested)
        else:
            job['wrapper_rows'] = []
            for i, row in matches:
                item = {'original_metadata': {'source': source, 'json_pointer': f'/jobs/{i}'},
                        'recorded': fields(row, 'job sha command cwd started_utc ended_utc exit_code '
                                           'inner_exit_code derived_pass receipt_validated receipt seconds '
                                           'ci_timeout_minutes over_ci_timeout status progress_publish_exit'),
                        'sha_identity': identity(row.get('sha'), requested),
                        'errors': errors_reference(row, source, f'/jobs/{i}/errors')}
                item['workflow'], _ = workflow(reader, root, name, requested, row.get('receipt'))
                job['wrapper_rows'].append(item)
            if len(matches) != 1:
                reader.issue(root / 'receipt.json', name + ' 有多筆原 job；全部列出，不選取通過項')
        result['jobs'].append(job)
    if isinstance(jobs, list):
        result['unrecognized_job_rows'] = [{'index': i, 'job': row.get('job')}
                                            for i, row in enumerate(jobs)
                                            if isinstance(row, dict) and row.get('job') not in expected_jobs]
    else:
        result['unrecognized_job_rows'] = None
    return result


def native_stdout(reader, root):
    directory = root / 'workflow/native/steps'
    result = {'directory': str(directory), 'available': directory.is_dir(), 'streams': None}
    if not directory.is_dir():
        reader.issue(directory, '原 native steps 目錄尚不可用')
        return result
    result['streams'] = []
    for path in sorted(directory.glob('*.stdout')):
        source, body = reader.read(path, root)
        row = {'source': source, 'original_aggregate_candidates': None, 'unique_original_aggregate': None,
               'progress_observations': None, 'original_footer_lines': None, 'original_table_rows': None}
        if body is not None:
            totals, progress, footers, table = [], [], [], []
            for lineno, line in enumerate(body.decode('utf-8', errors='replace').splitlines(), 1):
                total, advance, footer = TOTAL.match(line), PROGRESS.match(line), FOOTER.match(line)
                if total:
                    counts = dict(zip(('total', 'passed', 'failed', 'skipped'), map(int, total.groups()[:4])))
                    totals.append({'line_number': lineno, 'raw_line': line, **counts,
                                   'recorded_suite_sum_seconds': total.group(5)})
                if advance:
                    progress.append({'line_number': lineno, 'raw_line': line, 'ordinal': int(advance.group(1)),
                                     'registered_total': int(advance.group(2)), 'suite': advance.group(3)})
                if footer:
                    footers.append({'line_number': lineno, 'raw_line': line,
                                    'recorded_footer_exit_code': int(footer.group(1))})
                candidate = TABLE.match(line)
                if candidate and not total:
                    table.append({'line_number': lineno, 'raw_line': line,
                                  **dict(zip(('suite', 'total_text', 'passed_text', 'failed_text',
                                              'skipped_text', 'seconds_text', 'note'), candidate.groups()))})
            row.update(original_aggregate_candidates=totals,
                       unique_original_aggregate=totals[0] if len(totals) == 1 else None,
                       progress_observations={'observed_line_count': len(progress),
                                              'last_original_line': progress[-1] if progress else None,
                                              'registered_totals_observed': sorted({p['registered_total'] for p in progress})},
                       original_footer_lines=footers, original_table_rows=table)
        result['streams'].append(row)
    if not result['streams']:
        reader.issue(directory, '尚無原 native stdout；不補合計或 footer')
    return result


def suite_reports(reader, root):
    directory = root / 'workflow/native/run_all-logs'
    result = {'directory': str(directory), 'available': directory.is_dir(),
              'observed_json_count': None, 'suites': None, 'gdi_skip_raw_observations': None,
              'skip_classification_policy': '只引原 runner table note/footer；不執行 ALLOWED_SKIPS 分類器。'}
    if not directory.is_dir():
        reader.issue(directory, '本 job 尚未保存 run_all-logs；不讀全域 cache 代替')
        return result
    paths = sorted(directory.glob('*.json'))
    result.update(observed_json_count=len(paths), suites=[], gdi_skip_raw_observations=[])
    for path in paths:
        source, raw = reader.obj(path, root)
        row = {'source': source, 'available': raw is not None, 'recorded': None}
        if raw is not None:
            row['recorded'] = fields(raw, 'file total run passed failed skipped explicit_skipped '
                                     'unrun_skipped blocked_by_error expected_failed import_error extra_errors '
                                     'seconds skip_reasons skip_items')
            row['failure_record_count'] = list_count(raw.get('failures'))
            row['expected_failure_record_count'] = list_count(raw.get('expected_failures'))
            row['original_failure_details'] = {'source': source, 'json_pointer': '/failures'}
            if isinstance(raw.get('file'), str) and Path(raw['file']).name == 'test_gdi_contract.py':
                result['gdi_skip_raw_observations'].append({'source': source,
                    'recorded': fields(raw, 'file skipped explicit_skipped unrun_skipped '
                                      'skip_reasons skip_items import_error extra_errors'),
                    'allowlist_verdict': None,
                    'note': '原 per-suite JSON 不提供允許分類；只記錄原資料，允許說明見原 stdout table note。'})
        result['suites'].append(row)
    return result


def architecture(reader, root, requested):
    source, raw = reader.obj(root / 'receipt.json', root)
    result = {'source': source, 'available': raw is not None, 'recorded': None,
              'sha_identity': None, 'errors': None, 'versions': None, 'steps': []}
    steps = None
    if raw is not None:
        result['recorded'] = fields(raw, 'schema sha repo mode started_utc ended_utc exit_code '
                                    'source_before source_after stack_before stack_during tool_sha256 '
                                    'platform python python_executable clearedInheritedEnvironmentNames environment')
        result['sha_identity'] = identity(raw.get('sha'), requested)
        result['errors'] = errors_reference(raw, source, '/errors')
        if raw.get('mode') != 'architecture':
            reader.issue(root / 'receipt.json', '原 mode 不是 architecture；不可當作三條架構驗收')
        versions = raw.get('versions')
        if isinstance(versions, list):
            result['versions'] = [command_summary(reader, v['original_command_result'], root, source,
                                                   f'/versions/{i}/original_command_result', capture=True, version=True)
                                  for i, v in enumerate(versions)
                                  if isinstance(v, dict) and isinstance(v.get('original_command_result'), dict)]
        steps = raw.get('steps')
    for label in ARCHITECTURE_LABELS:
        matches = [(i, step) for i, step in enumerate(steps)
                   if isinstance(step, dict) and step.get('label') == label] if isinstance(steps, list) else None
        row = {'label': label, 'original_occurrence_count': len(matches) if matches is not None else None,
               'original_results': None}
        if not matches:
            reader.issue(root / 'receipt.json', label + ' 原命令結果尚不可用')
        else:
            row['original_results'] = []
            for i, step in matches:
                command = step.get('original_command_result')
                row['original_results'].append(command_summary(reader, command, root, source,
                    f'/steps/{i}/original_command_result', capture=True) if isinstance(command, dict) else None)
        result['steps'].append(row)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--native-root', required=True, type=Path)
    parser.add_argument('--browser-root', required=True, type=Path)
    parser.add_argument('--architecture-root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{40}', args.sha):
        parser.error('--sha 必須是完整的 40 位小寫 Git SHA')
    roots = {name: getattr(args, name + '_root').resolve() for name in ('native', 'browser', 'architecture')}
    output = args.output.resolve()
    if output.exists() or any(output.is_relative_to(root) for root in roots.values()):
        parser.error('--output 必須是 input roots 外的新檔案；不可覆寫來源或既有輸出')
    reader = Reader()
    report = {
        'schema': 'geometry-followup-original-receipt-summary/1', 'requested_sha': args.sha,
        'created_utc': now(), 'tool_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'input_roots': {name: str(root) for name, root in roots.items()},
        'policy': {'not_acceptance_gate': True, 'product_executed': False,
                   'tests_compiled_or_run': False, 'git_or_commit_push_executed': False,
                   'original_verdicts_reinterpreted': False, 'missing_is_null_not_pass': True,
                   'collector_exit_is_test_exit': False},
        'limitations': [
            '只整理既有檔案；本工具成功寫檔不代表任何驗收項目通過。',
            '原 wrapper、原 workflow、原命令與 progress_publish_exit 各自保留；出版退出碼不是測試退出碼。',
            '原 derived_pass 原樣引用，初始化 false 不代表已完成或已失敗；不產生全綠結論。',
            '沒有原合計/footer就保留 null 或空候選，不從進度、per-suite 子集推算合計。',
            '每個檔案只取一次穩定快照；整組來源不具跨檔案原子性。執行中請待原工具終態後另存新摘要。',
            '只讀 job 已保存的 run_all-logs，不用全域 cache 補齊缺項；不重跑、挑樣本或重新套門檻。',
            '完整輸出、環境與錯誤原文以 input 索引的原路徑/bytes/SHA256及 JSON pointer 為準。',
        ],
    }
    report['native'] = wrapper(reader, roots['native'], args.sha, ('native',))
    report['native']['original_stdout_summary'] = native_stdout(reader, roots['native'])
    report['native']['saved_per_suite_reports'] = suite_reports(reader, roots['native'])
    report['browser'] = wrapper(reader, roots['browser'], args.sha, BROWSER_JOBS)
    report['architecture'] = architecture(reader, roots['architecture'], args.sha)
    report['inputs'] = reader.inputs
    report['unavailable_or_caution'] = reader.issues
    # 除此全新輸出外，不寫來源、不建立 cache、不啟動任何 subprocess。
    with output.open('x', encoding='utf-8') as target:
        json.dump(report, target, ensure_ascii=False, indent=2)
        target.write('\n')
    print(json.dumps({'output': str(output), 'not_acceptance_gate': True,
                      'unavailable_or_caution_count': len(reader.issues)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
