"""Collect completed original results for publication; this is not an acceptance gate."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil

F = 'cc67e2518f6ab331b5ab9fdbcd5bd6334134377f'
root = Path('/tmp/g261s7')
out = Path('/workspace/geo314-final-completion-cc67e251')
seven = json.loads((root / 'receipt.json').read_text())
outer_root = Path('/workspace/geo314-final-outer/geo314-seven-final-cc67e251')
outer = json.loads((outer_root / 'receipt.json').read_text())
repair_root = Path('/workspace/geo314-assembly-workflow-publication-repair')
repair = json.loads((repair_root / 'receipt.json').read_text())
architecture = json.loads(Path('/workspace/geo314-final-architecture-cc67e251/receipt.json').read_text())
assert seven['source_sha'] == outer['sha'] == repair['acceptance_sha'] == architecture['sha'] == F
assert seven['ended_utc'] and seven['exit_code'] == outer['outer_process']['actual_process_returncode'] == 1
assert len(seven['jobs']) == 7
for row in seven['jobs']:
    assert row['sha'] == F and row['exit_code'] == row['inner_exit_code'] == 0
    assert row['derived_pass'] and row['receipt_validated'] and not row['over_ci_timeout'] and not row['errors']
    assert row['progress_publish_exit'] == (1 if row['job'] == 'assembly' else 0)
assert repair['exit_code'] == repair['publication_repair_process_exit_code'] == 0
assert repair['original_publication_exit_code'] == 1 and not repair['product_or_test_rerun']
assert architecture['exit_code'] == 0 and not architecture['errors']
assert all(step['original_command_result']['actual_process_returncode'] == 0 for step in architecture['steps'])
assert not out.exists()
out.mkdir()
copies = {
    'FORMAL_METRICS.json': Path('/workspace/geo314-formal-final-metrics-cc67e251.json'),
    'SOURCE_HANDOFF.json': Path('/workspace/geo314-work/FINAL_SOURCE_HANDOFF_cc67e251.json'),
    'BROWSER_SCOPE_FACTS.json': Path('/workspace/geo314-work/BROWSER_SCOPE_FACTS.json'),
    'ORIGINAL_SEVEN_RECEIPT.json': root / 'receipt.json',
    'PUBLICATION_REPAIR.json': repair_root / 'receipt.json',
}
for name, source in copies.items():
    shutil.copy2(source, out / name)
scopes = json.loads((out / 'BROWSER_SCOPE_FACTS.json').read_text())
assert scopes['source_sha'] == F and all(scopes['jobs'].values()) and scopes['monitoring_closed_utc']
index = {'schema': 'geo314-final-original-result-index/1', 'acceptance_sha': F,
         'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'not_acceptance_gate': True,
         'seven_root': str(root), 'outer_root': str(outer_root), 'original_seven_wrapper_exit_code': seven['exit_code'],
         'original_outer_exit_code': outer['outer_process']['actual_process_returncode'],
         'original_job_results': seven['jobs'], 'publication_only_repair': repair,
         'architecture_original_receipt': '/workspace/geo314-final-architecture-cc67e251/receipt.json',
         'assembly_specialist_published_receipt': 'evidence/geo314-final-cc67e251/receipts/assembly-final.json',
         'product_or_test_rerun_for_publication_repair': False}
(out / 'ORIGINAL_RESULT_INDEX.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
text = '# #314 正式雲端驗收\n\n固定受驗 F：`' + F + '`。七項原測試、原完整 ASM 與三條架構裁判均通過。後續 E 只保存證據，不冒稱 E 受驗。\n\n'
text += '| 原 workflow job | 原測試退出 | 原秒數 | 原 CI 分鐘 | 超時 | 原發布退出 |\n|---|---:|---:|---:|---|---:|\n'
for row in seven['jobs']:
    text += f"| {row['job']} | {row['exit_code']} | {row['seconds']:.6f} | {row['ci_timeout_minutes']} | {row['over_ci_timeout']} | {row['progress_publish_exit']} |\n"
text += '''
原 native：227 suites，5268 計數＝5267 pass、0 fail、1 允許的 Windows GDI skip；`mutation:check` 原退出0。每項來源前後為乾淨 F。

原完整 ASM 工具與 outer 均0：baseline／restored pass，三 mutants 具名正常斷言 killed，六 controls 符合原判準；原 timeout120不變。F 三架構原退出0／0／0，inner／outer均0。

canvas 原2267／0、full／golden matched；P73 原行1830空空間與1855「本模組」無未處理例外均通過。canvas整個原footer仍有P38預期注入的uncaughtBrowserExceptions=1，行561／563／564保留，不改稱整個canvas零例外。P52-5原行773同步等待240ms，只是正常job紀錄，不冒作獨立main／fix專項。

assembly150／0、grid356／0均原partial／golden not compared；documents47／0，原footer未有scope/completed欄，不補造。space242／0為full-space-suite，原omitted兩timber組；timber79／0為partial，原omitted五space組。完整原groups、範圍與行號見BROWSER_SCOPE_FACTS.json，沒有擴稱未執行範圍。

原assembly發布退出1：原publisher的assembly-*封包守門撞到既有assembly-final專項封包，因此原seven wrapper及outer均退出1。其餘六個原發布退出0。整輪完成後只用原publisher改唯一label為assembly-workflow補發布，實際退出0、遠端同且乾淨；原測試沒有重跑、原receipt／退出碼沒有改寫。PUBLICATION_REPAIR.json與完整原stderr／命令另存，不能把補發布0冒作原wrapper0。

新S不帶IDs整份原mutate.py與strict --check均0，100 records＝91 killed＋5 equivalent＋M20 crashed＋3 retired，97 execution全真新S；M20不算斷言killed。舊容量失敗2、M110 invalid、ASM anchor collector1及舊ASM外層1均保留。Linux四檔真來源L、F再跑三裁判；各來源角色詳SOURCE_HANDOFF.json，不將S／L／E改標F。

FORMAL_METRICS.json及本檔只整理原收據，不是新裁判。原工具未落盤的core內層streams不補造；Windows GDI／MSVC未動態驗證；超起始容量facts／realloc／OOM、確認後段逐分支故障、混合parameter-package Q3與完整P177全域動態計數不由靜態審查外推。本分支未與#323或combined補丁疊合驗收。沒有合併或force push，公理層與決策佇列未改。
'''
(out / 'FORMAL_SUMMARY.md').write_text(text)
tools = out / 'tools'
tools.mkdir()
for name in ['prepare_geo314_final_completion.py', 'summarize_followup_acceptance.py', 'repair_geo314_assembly_publication.py', 'publish_geo314_final_body.py']:
    shutil.copy2(Path('/workspace/geo261-environment') / name, tools / name)
inventory = [{'path': p.relative_to(out).as_posix(), 'bytes': p.stat().st_size,
              'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()]
(out / 'MEMBER_INVENTORY.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': str(out), 'files_before_inventory': len(inventory), 'not_acceptance_gate': True}, ensure_ascii=False))
