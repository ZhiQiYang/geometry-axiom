#!/usr/bin/env python3
"""建立固定 SHA 的獨立稀疏 worktree，保存準備過程；不執行驗收。"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import traceback


FIXTURES = (
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a.gcanvas',
    'tests/evidence/k2a-collection-capacity-20261012/legacy6a-with-scene.gcanvas',
    'tests/evidence/k2a-boundary-review-20261012/legacy/base49-capacity.gcanvas',
    'tests/release-evidence/20261008-cloud-closeout/contracts/grid-final/grid-rule-timber.scene',
)
ROOTS = ('geometry-core', 'geometry-app', 'geometry-templates', 'geometry-web', 'geometry-guide')
PATTERNS = b'/*\n!/evidence/\n!/tests/evidence/\n'
GIT_ROUTING_OVERRIDES = {
    'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_NAMESPACE',
    'GIT_SHALLOW_FILE', 'GIT_REPLACE_REF_BASE', 'GIT_CONFIG_PARAMETERS',
    'GIT_CONFIG_COUNT', 'GIT_CONFIG', 'GIT_CONFIG_SYSTEM', 'GIT_CONFIG_GLOBAL',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def excluded(path):
    return path.startswith(('evidence/', 'tests/evidence/'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publication-repo', required=True, type=Path)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--dest', required=True, type=Path)
    parser.add_argument('--receipt', required=True, type=Path)
    args = parser.parse_args()
    repo = args.publication_repo.resolve(strict=True)
    dest = args.dest.resolve()
    receipt = args.receipt.resolve()
    if re.fullmatch(r'[0-9a-f]{40}', args.sha) is None:
        parser.error('--sha 必須為完整的 40 位小寫 commit SHA')
    if not dest.is_relative_to(Path('/tmp')) or dest == Path('/tmp') or os.path.lexists(args.dest) or os.path.lexists(dest):
        parser.error('--dest 必須為 /tmp 下尚不存在的路徑')
    if dest.is_relative_to(repo) or repo.is_relative_to(dest):
        parser.error('新 worktree 與出版 worktree 不得互相包含')
    if receipt.is_relative_to(repo) or receipt.is_relative_to(dest) or os.path.lexists(args.receipt) or os.path.lexists(receipt):
        parser.error('--receipt 必須為兩個 worktree 外尚不存在的檔案')
    raw = receipt.parent / (receipt.stem + '.commands')
    if raw.exists():
        parser.error('命令輸出目錄已存在，不得覆寫：' + str(raw))
    receipt.parent.mkdir(parents=True, exist_ok=True)
    raw.mkdir()
    tool = Path(__file__).resolve()
    shutil.copyfile(tool, raw / 'tool.py.txt')
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
    unsafe_git_environment = sorted(name for name, value in env.items() if value and
                                    (name in GIT_ROUTING_OVERRIDES or
                                     name.startswith(('GIT_CONFIG_KEY_', 'GIT_CONFIG_VALUE_'))))
    report = {
        'schema': 'geometry-followup-fixed-worktree/1',
        'classification': '環境準備；尚未執行任何產品測試',
        'started_utc': utc(), 'publication_repo': str(repo), 'source_sha': args.sha,
        'destination': str(dest), 'python': sys.version, 'platform': platform.platform(),
        'tool_sha256': digest(tool.read_bytes()),
        'environment': {key: env.get(key) for key in ('PATH', 'LANG', 'LC_ALL', 'GIT_OPTIONAL_LOCKS')},
        'rejected_git_environment_names': unsafe_git_environment,
        'commands': [], 'fixtures': [], 'errors': [], 'exit_code': None,
        'sparse_patterns_utf8': PATTERNS.decode('ascii'),
        'policy': '只建立新 detached worktree；共用 Git objects；不重設其他 worktree、不推送、不合併、不動驗收暫存。',
        'fixture_reference_scripts': [
            '/workspace/geo314-work/materialize_native_fixture_prereqs.py',
            '/workspace/geo299316-work/materialize_fixtures.py',
        ],
    }

    def save():
        temporary = receipt.with_name(receipt.name + '.writing')
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temporary.replace(receipt)

    def run(label, argv, cwd, *, stdin=None, allowed=(0,)):
        number = len(report['commands'])
        stem = f'{number:03d}-{label}'
        row = {'label': label, 'command': argv, 'cwd': str(cwd), 'started_utc': utc(),
               'exit_code': None, 'stdout': stem + '.stdout', 'stderr': stem + '.stderr'}
        if stdin is not None:
            (raw / (stem + '.stdin')).write_bytes(stdin)
            row['stdin'] = stem + '.stdin'
            row['stdin_sha256'] = digest(stdin)
        report['commands'].append(row)
        save()
        result = subprocess.run(argv, cwd=cwd, env=env, input=stdin, capture_output=True)
        (raw / row['stdout']).write_bytes(result.stdout)
        (raw / row['stderr']).write_bytes(result.stderr)
        row.update(exit_code=result.returncode, ended_utc=utc(),
                   stdout_bytes=len(result.stdout), stdout_sha256=digest(result.stdout),
                   stderr_bytes=len(result.stderr), stderr_sha256=digest(result.stderr))
        save()
        if result.returncode not in allowed:
            raise RuntimeError(f'{label} 退出 {result.returncode}；完整輸出保存在 {raw / row["stderr"]}')
        return result

    def git(label, cwd, *values, stdin=None, allowed=(0,)):
        return run(label, ['git', *values], cwd, stdin=stdin, allowed=allowed).stdout

    def textgit(label, cwd, *values):
        return git(label, cwd, *values).decode('utf-8').strip()

    def flags(label, cwd):
        body = git(label, cwd, 'ls-files', '-v', '-z')
        entries = {}
        for record in body.split(b'\0'):
            if record:
                if len(record) < 3 or record[1:2] != b' ':
                    raise ValueError('不認識的 ls-files -v 記錄')
                entries[os.fsdecode(record[2:])] = record[:1].decode('ascii')
        return body, entries

    def snapshot(label):
        head = textgit(label + '-head', repo, 'rev-parse', 'HEAD')
        branch = textgit(label + '-branch', repo, 'branch', '--show-current')
        status = git(label + '-status', repo, 'status', '--porcelain=v1', '-z', '--untracked-files=all')
        stage = git(label + '-stage', repo, 'ls-files', '--stage', '-z')
        flagbody, _ = flags(label + '-flags', repo)
        config = {}
        for key in ('extensions.worktreeConfig', 'core.sparseCheckout', 'core.sparseCheckoutCone', 'core.autocrlf', 'core.eol'):
            value = run(label + '-config-' + key, ['git', 'config', '--get', key], repo, allowed=(0, 1))
            config[key] = value.stdout.decode('utf-8').strip() if value.returncode == 0 else None
        return {'head': head, 'branch': branch, 'status_clean': status == b'',
                'status_sha256': digest(status), 'logical_stage_sha256': digest(stage),
                'index_flags_sha256': digest(flagbody), 'effective_config': config}

    before = None
    try:
        if unsafe_git_environment:
            raise ValueError('拒絕可能將 Git 操作轉向外部 index、worktree、objects 或設定的環境覆寫；只記名稱：' +
                             ', '.join(unsafe_git_environment))
        git('git-version', repo, '--version')
        root = Path(textgit('publication-toplevel', repo, 'rev-parse', '--show-toplevel')).resolve()
        if root != repo:
            raise ValueError('--publication-repo 必須直接指向 worktree 根目錄')
        before = snapshot('publication-before')
        report['publication_before'] = before
        if not before['status_clean'] or not before['branch']:
            raise ValueError('出版 worktree 必須乾淨且位於具名分支')
        resolved = textgit('resolve-final-commit', repo, 'rev-parse', args.sha + '^{commit}')
        if resolved != args.sha:
            raise ValueError('最終 SHA 不相符')
        git('final-is-publication-ancestor', repo, 'merge-base', '--is-ancestor', args.sha, 'HEAD')
        common = Path(textgit('publication-common-dir', repo, 'rev-parse', '--path-format=absolute', '--git-common-dir')).resolve()
        report['shared_git_common_dir'] = str(common)
        # 只填入全新的 detached worktree；不 checkout/reset 出版來源。
        dest.parent.mkdir(parents=True, exist_ok=True)
        git('add-detached-no-checkout', repo, 'worktree', 'add', '--no-checkout', '--detach', str(dest), args.sha)
        git('sparse-init-no-cone', dest, 'sparse-checkout', 'init', '--no-cone')
        git('sparse-set-two-exclusions', dest, 'sparse-checkout', 'set', '--no-cone', '--stdin', stdin=PATTERNS)
        git('populate-new-worktree-only', dest, 'read-tree', '-m', '-u', 'HEAD')
        if textgit('destination-head', dest, 'rev-parse', 'HEAD') != args.sha:
            raise ValueError('新 worktree 的 HEAD 不符最終 SHA')
        if textgit('destination-branch', dest, 'branch', '--show-current'):
            raise ValueError('新 worktree 必須為 detached HEAD')
        new_common = Path(textgit('destination-common-dir', dest, 'rev-parse', '--path-format=absolute', '--git-common-dir')).resolve()
        if new_common != common:
            raise ValueError('未共用同一 Git objects 儲存庫')
        report['objects_shared_verified'] = True
        before_flags_body, before_flags = flags('destination-before-fixtures-flags', dest)
        for number, relative in enumerate(FIXTURES):
            if relative not in before_flags:
                raise ValueError('缺少既有 tracked fixture：' + relative)
            oid = textgit(f'fixture-{number}-oid', dest, 'rev-parse', args.sha + ':' + relative)
            body = git(f'fixture-{number}-exact-blob', dest, 'show', args.sha + ':' + relative)
            target = dest / relative
            existed = os.path.lexists(target)
            if existed:
                if target.is_symlink() or not target.is_file() or target.read_bytes() != body:
                    raise ValueError('不覆寫與同 SHA blob 不同的既有 fixture：' + relative)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(body)
            if target.read_bytes() != body:
                raise ValueError('物化後 bytes 不同：' + relative)
            report['fixtures'].append({'path': relative, 'source_sha': args.sha, 'blob_oid': oid,
                                       'bytes': len(body), 'sha256': digest(body), 'existed_before': existed,
                                       'index_flag_before': before_flags[relative], 'exact_bytes_verified': True})
            save()
        # Materialized ZIP fixtures are deliberately outside the sparse pattern.
        # Git clears their skip-worktree bit when it observes the real file; record
        # that exact environment change explicitly instead of asserting it stays S.
        materialized = [path for path in FIXTURES if before_flags[path].upper() == 'S']
        if materialized:
            git('materialized-fixtures-only-clear-skip-bits', dest, 'update-index', '--no-skip-worktree', '-z', '--stdin',
                stdin=b''.join(os.fsencode(path) + b'\0' for path in materialized))
        expected_flags = dict(before_flags)
        for path in materialized:
            expected_flags[path] = 'h' if before_flags[path].islower() else 'H'
        status = git('destination-clean-status', dest, 'status', '--porcelain=v1', '-z', '--untracked-files=all')
        if status:
            raise ValueError('新 worktree 物化後不是乾淨狀態；不繼續驗收')
        final_flags_body, final_flags = flags('destination-final-flags', dest)
        if final_flags != expected_flags:
            raise ValueError('除已驗同F原bytes夾具以外，出現額外index flag變更')
        report['fixture_index_changes'] = [{'path': path, 'before': before_flags[path], 'after': final_flags[path],
                                          'reason': 'explicitly materialized exact Git blob outside sparse pattern'}
                                         for path in materialized]
        report['all_other_index_flags_preserved'] = True
        missing, wrongly_skipped = [], []
        for path, flag in final_flags.items():
            if not excluded(path):
                if flag.upper() == 'S':
                    wrongly_skipped.append(path)
                if not os.path.lexists(dest / path):
                    missing.append(path)
        if missing or wrongly_skipped:
            raise ValueError('兩個排除目錄外仍有缺檔或 skip：' + repr((missing, wrongly_skipped)))
        manifest_path = 'geometry-core/domain-decoupling/product-architecture.json'
        manifest_blob = git('architecture-manifest-exact-blob', dest, 'show', args.sha + ':' + manifest_path)
        manifest = json.loads(manifest_blob)
        if manifest.get('sourceRoots') != list(ROOTS):
            raise ValueError('架構五個來源 root 與既有清單不同；需要另行檢查')
        owned = set(manifest.get('sourceFiles', [])) | {entry['path'] for entry in manifest['sources']}
        if any(excluded(path) or not (dest / path).is_file() for path in owned):
            raise ValueError('架構 owned source 缺檔或被排除')
        if any(not (dest / root_name).is_dir() for root_name in ROOTS):
            raise ValueError('缺少架構來源 root')
        report['coverage'] = {'tracked_entries': len(final_flags),
                              'tracked_entries_outside_two_exclusions': sum(not excluded(path) for path in final_flags),
                              'missing_outside_exclusions': missing, 'skipped_outside_exclusions': wrongly_skipped,
                              'architecture_source_roots': list(ROOTS), 'owned_sources_materialized': len(owned),
                              'destination_status_clean': True,
                              'index_flags_before_sha256': digest(before_flags_body),
                              'index_flags_final_sha256': digest(final_flags_body)}
        report['destination_final_head'] = textgit('destination-final-head', dest, 'rev-parse', 'HEAD')
        if report['destination_final_head'] != args.sha:
            raise ValueError('準備途中 HEAD 改變')
        report['exit_code'] = 0
    except Exception:
        report['errors'].append(traceback.format_exc())
        report['exit_code'] = 1
    finally:
        if before is not None:
            try:
                after = snapshot('publication-after')
                report['publication_after'] = after
                report['publication_unchanged'] = after == before
                if after != before:
                    report['errors'].append('出版分支的 HEAD、狀態、logical index、flags 或有效設定有變更；不宣稱準備成功。')
                    report['exit_code'] = 1
            except Exception:
                report['errors'].append(traceback.format_exc())
                report['exit_code'] = 1
        report['ended_utc'] = utc()
        save()
    print(json.dumps({'receipt': str(receipt), 'destination': str(dest), 'source_sha': args.sha,
                      'exit_code': report['exit_code'], 'publication_unchanged': report.get('publication_unchanged')}, ensure_ascii=False))
    return report['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
