"""Read-only peer of original VM records and immutable Git objects; never runs a test."""
from pathlib import Path
import datetime,difflib,hashlib,importlib.util,json,os,re,sys

B=Path('/workspace/issue320-20261024')
OUT=Path('/tmp/issue320-vm-7b45013d-kernel-peer-r2')
S='7b45013da647b791acda8f5977475e4123d5f8c4'
P='d2c583179219dafe2f575ef158c45f3cf17bd186'
OUT.mkdir()
checks=[];subjects={}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def raw(p):
 p=Path(p);v=p.read_bytes();subjects[str(p)]=sha(v);return v
def j(p):return json.loads(raw(p))
def check(name,condition):checks.append({'name':name,'passed':bool(condition)})
def recorded(root,count):
 rows=j(root/'subcommands.json');check(str(root)+':row-count',len(rows)==count)
 check(str(root)+':exact-directories',sorted(x.name for x in (root/'subcommands').iterdir())==[f'{n:06d}' for n in range(1,count+1)])
 for n,row in enumerate(rows,1):
  d=root/'subcommands'/f'{n:06d}'
  check(str(d)+':record-path',row['directory']==str(d))
  result=j(d/'result.json');request=j(d/'request.json')
  check(str(d)+':aggregate-result-identical',result==row)
  check(str(d)+':request-preserved',request['actual_process_returncode'] is None and all(row.get(k)==v for k,v in request.items() if k!='actual_process_returncode'))
  check(str(d)+':terminal',isinstance(row['actual_process_returncode'],int) and row['ended_epoch']>=row['started_epoch'] and not row['timeout_expired'])
  for stream in ['stdin','stdout','stderr']:
   data=raw(d/(stream+'.bin'))
   check(str(d)+':'+stream+'-hash',sha(data)==row[stream+'_sha256'])
   if stream!='stdin':check(str(d)+':'+stream+'-length',len(data)==row[stream+'_bytes'])
 return rows

proof=B/'fixed-source-proof-7b45013d';pub=B/'cdp-seed-source-publication';launch=B/'fixed-source-proof-7b45013d-launch'
r=j(proof/'RESULT.json');q=j(proof/'REQUEST.json');u=j(pub/'RESULT.json');l=j(launch/'RESULT.json');lq=j(launch/'REQUEST.json')
vm=recorded(proof,17);pr=recorded(pub,14);lr=recorded(launch,1)
bind=j(B/'VM_BINDING_7b45013d.json');old=raw(bind['originalDriver']);new=raw(bind['boundDriver'])
check('original-driver-pin',sha(old)==bind['originalDriverSHA256']=='a345f75018937f5bcbfdb016a599676f19b0134523f28b7716999f845bac20ad')
check('bound-driver-pin',sha(new)==bind['boundDriverSHA256']==q['driverSHA256']==lq['driverSHA256']=='be1940cc4fd2976ac3353023f5db8c5735719c647eefd928cb1d4be86c4a38ff')
expected=old.replace(b"O = B / 'fixed-source-proof-c1113f6f'",b"O = B / 'fixed-source-proof-7b45013d'").replace(b"S = 'c1113f6fd6c52a55d7df1a30ecd1684fe87b661c'",b"S = '7b45013da647b791acda8f5977475e4123d5f8c4'")
check('driver-only-two-literal-bindings',old!=new and expected==new)
diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=bind['originalDriver'],tofile=bind['boundDriver']))
check('saved-binding-diff-exact',raw(B/'VM_BINDING_7b45013d.diff').decode()==diff)
check('original-timeout-kept',q['timeoutSecondsEach']==bind['originalTimeoutSecondsEach']==lq['originalNodePhaseTimeoutSeconds']==300 and b'timeout=300, check=False' in new)
check('outer-no-timeout',lq['outerTimeout'] is None)
check('node-options-cleared-in-driver',b"env.pop('NODE_OPTIONS', None)" in new and b"env.pop('PYTHONOPTIMIZE', None)" in new)
check('all-source-identities',all(x['sourceSHA']==S for x in [r,q,u,l,lq,bind]))
check('real-browser-unrun',r['fullCanvas']=='UNRUN' and r['fullNative']=='UNRUN' and not r['globalLedgerWritten'] and u['realCDP']=='UNRUN')
check('publication-before-new-vm-honest',u['newVM']=='UNRUN' and pr[-1]['ended_epoch']<vm[0]['started_epoch'])
check('source-before-and-after-head',raw(Path(vm[0]['directory'])/'stdout.bin')==raw(Path(vm[14]['directory'])/'stdout.bin')==(S+'\n').encode())
check('source-before-and-after-clean',raw(Path(vm[1]['directory'])/'stdout.bin')==raw(Path(vm[15]['directory'])/'stdout.bin')==b'')
stage=raw(Path(vm[2]['directory'])/'stdout.bin')
check('source-before-after-stage-same',stage==raw(Path(vm[16]['directory'])/'stdout.bin'))
check('withdraw-only-app-dirty',raw(Path(vm[11]['directory'])/'stdout.bin')==b' M geometry-web/app.js\n')
stages={line.split(b'\t')[1].decode():line.split()[1].decode() for line in stage.splitlines()}
check('five-exact-stage-inputs',set(stages)==set(q['sourceScope']) and len(stages)==5)
inputs={}
for i,item in enumerate(r['originalSourceInputs']):
 path=item['path'];data=raw(proof/'inputs'/path);gitraw=raw(Path(vm[i+4]['directory'])/'stdout.bin');inputs[path]=data
 check(path+':fixed-source-and-bytehash',item['gitSourceSHA']==S and len(data)==item['bytes'] and sha(data)==item['sha256'])
 check(path+':original-git-show-command',vm[i+4]['command']==['git','show',S+':'+path] and vm[i+4]['actual_process_returncode']==0)
 check(path+':git-raw-and-physical-exact',data==gitraw)
 check(path+':git-blob-id',hashlib.sha1(b'blob '+str(len(gitraw)).encode()+b'\0'+gitraw).hexdigest()==stages[path])
fixed=inputs['geometry-web/app.js'];withdrawn=raw(proof/'withdrawn-app.js')
needle=b'connection.phase = "ready"; connection.known = true; connection.error = "";';replacement=b'connection.phase = "ready"; connection.known = true;'
check('one-unique-ready-clear-withdrawal',fixed.count(needle)==1 and withdrawn==fixed.replace(needle,replacement) and fixed!=withdrawn)
check('candidate-exact-reviewed-source',sha(inputs['geometry-web/cdp_test.js'])==u['candidateSHA256']=='1f3e2e36283ed7bbf6c4ad2cf3dc12c685667356d186d9fbd47bc5f0520f07ee')
check('app-test-registry-still-original',all(sha(inputs[p])==u['unchangedInputHashes'][p] for p in inputs if p!='geometry-web/cdp_test.js'))
check('nine-original-vm-test-declarations',len(re.findall(rb'^test\(',inputs['tests/test_connection_recovery.js'],re.M))==9)
check('explicit-vm-substitutes-not-browser',b'vm.runInContext' in inputs['tests/test_connection_recovery.js'] and b'unit guard unexpectedly reached real transport' in inputs['tests/test_connection_recovery.js'])
node=['node','--test','--test-reporter=spec','tests/test_connection_recovery.js']
check('three-original-node-rows',[(x['command'],x['actual_process_returncode']) for x in vm if x['command']==node]==[(node,0),(node,1),(node,0)])
for pos,(rowno,phase,exit_,pass_,fail_,appsha) in enumerate([(9,'baseline',0,9,0,sha(fixed)),(12,'withdraw-unique-ready-error-clear',1,6,3,sha(withdrawn)),(13,'restored',0,9,0,sha(fixed))]):
 row=vm[rowno];text=raw(Path(row['directory'])/'stdout.bin').decode();err=raw(Path(row['directory'])/'stderr.bin')
 check(phase+':original-row-source',row['command']==node and row['source_sha']==row['acceptance_sha']==S and row['source_variant']==phase and row['actual_process_returncode']==exit_)
 expected={'tests':9,'pass':pass_,'fail':fail_,'cancelled':0,'skipped':0}
 got={k:int(re.search(r'^ℹ '+k+r'\s+(\d+)\s*$',text,re.M)[1]) for k in expected}
 check(phase+':original-counts-no-skip',got==expected and r['phases'][pos]['counts']==expected)
 check(phase+':summary-is-original-row',r['phases'][pos]['originalCommand']==row and r['phases'][pos]['sourceAppSHA256']==appsha)
 check(phase+':no-fatal-error',not err and not re.search(r'SyntaxError|ReferenceError|TypeError|uncaughtException',text))
 check(phase+':normal-assertion-count',text.count('AssertionError [ERR_ASSERTION]')==(3 if fail_ else 0))
 if fail_:
  for message in ['successful recovery kept stale error','completed retry kept stale error','loading echoed stale error']:
   check('withdraw:'+message,text.count('AssertionError [ERR_ASSERTION]: '+message)==1)
check('proof-and-wrapper-original-exits',r['originalExits']==[0,1,0] and r['proofAccepted'] and l['actualDriverExit']==0 and l['originalCommand']==lr[0])
check('publication-only-cdp-path',raw(Path(pr[6]['directory'])/'stdout.bin')==b'geometry-web/cdp_test.js\n' and u['onlyChangedPath']=='geometry-web/cdp_test.js')
check('normal-push-no-force',pr[12]['command']==['git','push','origin','HEAD:refs/heads/'+u['branch']] and pr[12]['actual_process_returncode']==0)
check('original-remote-resolves-source',raw(Path(pr[13]['directory'])/'stdout.bin')==(S+'\trefs/heads/'+u['branch']+'\n').encode())
check('new-source-clean-at-publication',raw(Path(pr[11]['directory'])/'stdout.bin')==b'' and raw(Path(pr[10]['directory'])/'stdout.bin')==(S+'\n').encode())
initial=j(B/'VM_LAUNCH_SETUP_INITIAL_ERROR.json')
check('initial-launch-error-kept-separate',initial['actualHostProcessExit']==1 and initial['stage']=='before rec.run; no subject launched' and not initial['separateCapturedStderrFile'])

# Read immutable Git objects only; do not read/modify the current source materialization or rerun any judge.
capture=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
check('capture-pin',sha(raw(capture))=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762')
spec=importlib.util.spec_from_file_location('cap',capture);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT,env,S)
def git(args):return rec.run(['git',*args],cwd='/workspace/issue320-work-20261024',timeout=60)[1]
commit=git(['cat-file','commit',S]);changed=git(['diff-tree','--no-commit-id','--name-only','-r',P,S])
golden=git(['show',S+':geometry-web/cdp_sections.golden.json']);oldgolden=git(['show',P+':geometry-web/cdp_sections.golden.json'])
check('immutable-commit-object-id',hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==S)
check('immutable-parent-evidence',('parent '+P+'\n').encode() in commit)
check('immutable-only-cdp-change',changed==b'geometry-web/cdp_test.js\n')
check('immutable-golden-unchanged',golden==oldgolden and sha(golden)==u['unchangedInputHashes']['geometry-web/cdp_sections.golden.json'])
check('original-subject-files-still-hash-identical',all(sha(Path(p).read_bytes())==h for p,h in subjects.items()))
findings=[x['name'] for x in checks if not x['passed']]
result={'schema':'independent-original-record-peer/1','sourceSHA':S,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'exit_code':1 if findings else 0,'findings':findings,'outcome':'accepted within VM/source/publication scope' if not findings else 'not accepted','originalVMExits':[0,1,0],'originalVMTestCounts':[9,6,9],'originalVMSkipCounts':[0,0,0],'testOrBrowserRerun':False,'reviewerActions':'Read original records/streams, compare exact source variants, read four immutable Git objects only. No Node/compiler/browser/HTTP command executed.','limits':['VM with explicit DOM/transport substitutes does not prove real CDP/P53/P61, owner guards, native, or whole-project behavior. Three full canvas phases remain UNRUN.','Initial launcher FileNotFoundError has no separate stderr capture; original metadata and thread provenance retained, not relabeled as product failure.','Publication newVM=UNRUN was true at its earlier timestamp and remains historical.','No claim that private VM substitutes exercise real owner/editability guards; existing full canvas protocol remains required.'],'subjectPins':subjects,'details':checks}
(OUT/'REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['sourceSHA','checks','exit_code','findings']},ensure_ascii=False))
raise SystemExit(result['exit_code'])
