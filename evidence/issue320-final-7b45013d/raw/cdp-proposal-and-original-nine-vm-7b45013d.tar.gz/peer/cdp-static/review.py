"""Independent static peer only; never imports/evaluates JavaScript or runs browser."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

BASE=Path('/tmp/issue320-real-cdp-static-preparation')
OUT=Path('/tmp/issue320-cdp-kernel-static-peer')
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,ok):checks.append(dict(name=name,passed=bool(ok)))
manifest=json.loads((BASE/'FROZEN_MANIFEST.json').read_text())
check('manifest_pin',sha(BASE/'FROZEN_MANIFEST.json')=='339f86b7f0a061621b4f03082108288872044fb8c66352f74762de296346c949')
for x in manifest['files']:
 p=BASE/x['path'];check('frozen_file:'+x['path'],p.stat().st_size==x['bytes'] and sha(p)==x['sha256'])
check('proposal_subject_unrun',manifest['subjectExecuted'] is False)
pins=json.loads((BASE/'SOURCE_PINS.json').read_text());originals={}
for x in pins['inputs']:
 row=x['originalGitRead'];directory=Path(row['directory']);p=directory/'stdout.bin';originals[x['path']]=p.read_bytes()
 check('original_fixed_git_blob:'+x['path'],row['actual_process_returncode']==0 and row['command']==['git','show','c1113f6fd6c52a55d7df1a30ecd1684fe87b661c:'+x['path']] and sha(p)==x['sha256']==row['stdout_sha256'])
 check('original_raw_stderr:'+x['path'],sha(directory/'stderr.bin')==row['stderr_sha256'])
old=originals['geometry-web/cdp_test.js'].decode();new=(BASE/'candidate/geometry-web/cdp_test.js').read_text()
patch=(BASE/'CDP_ONLY_CANDIDATE.patch').read_text();plan=json.loads((BASE/'EXECUTION_PLAN.json').read_text());app=originals['geometry-web/app.js'].decode()
check('patch_exact_pin',sha(BASE/'CDP_ONLY_CANDIDATE.patch')=='3533145ff2f2364f4252e6009c46cc3854651ccc92db32ef78280bc1d445cdd9')
check('patch_exact_original_to_candidate',patch==''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/geometry-web/cdp_test.js',tofile='b/geometry-web/cdp_test.js')))
names=lambda s:re.findall(r"(?<![\w.])check\(\s*(['\"])(.*?)\1",s)
check('all_literal_check_name_sequence_preserved',names(old)==names(new))
check('lexical_check_call_count_preserved',len(re.findall(r'(?<!\w)check\(',old))==len(re.findall(r'(?<!\w)check\(',new)))
check('only_original_file_diff_headers',patch.count('--- a/')==1 and patch.count('+++ b/')==1)
p53_start=old.index("    const failedStart =");p53_end=old.index('    const offlineRequests =',p53_start)
p61_start=old.index("    check('P61-10");p61_end=old.index("    await eval_(`ReferenceWorkspace.openSource(g198PDF,1)`);",p61_start)
new_p53_start=new.index("    const failedStart =");new_p53_end=new.index('    const offlineRequests =',new_p53_start)
new_p61_start=new.index('    const uploadNotSentRecovery =');new_p61_end=new.index("    await eval_(`ReferenceWorkspace.openSource(g198PDF,1)`);",new_p61_start)
check('all_bytes_outside_three_target_checks_preserved',old[:p53_start]==new[:new_p53_start] and old[p53_end:p61_start]==new[new_p53_end:new_p61_start] and old[p61_end:]==new[new_p61_end:])
check('P53_original_four_predicates_retained',"failedStart.message.includes('403') && failedStart.empty && failedStart.count === '—' && failedStart.inert && failedStart.phase === 'error'" in new)
check('P53_seed_real_nonempty_403',"typeof failedStart.error === 'string' && failedStart.error.length > 0 && failedStart.error.includes('403')" in new)
check('P53_retry_check_exact_original',old[old.index("    check('P53-3"):old.index("    check('P53-4")]==new[new.index("    check('P53-3"):new.index("    check('P53-4")])
check('P61_unsent_original_fault_before_old_fetch',"if(input==='/upload/confirm'){confirmIntercepted=true;throw new TypeError('test upload disconnected');}return oldFetch(input,init);" in new)
check('P61_lost_response_real_fetch_before_fault',"const response=await oldFetch(input,init);confirmationResponseReceived=true;confirmationResponseOK=response.ok;confirmationStatus=response.status;throw new TypeError('test response lost');" in new)
check('P61_unsent_all_original_predicates_preserved',"proof.passed=confirmIntercepted&&seed.phase==='error'&&typeof seed.error==='string'&&seed.error.length>0&&blocked&&connection.phase==='ready'&&connection.error===''&&proof.dumpMatches&&proof.sourceMatches;" in new)
check('P61_unsent_exact_before_dump_and_source_alias',"beforeDump:before,afterDump:after,dumpMatches:after===before,sourceId:source,expectedSourceId:ref,sourceMatches:source===ref" in new)
check('P61_lost_all_original_predicates_preserved',"proof.passed=confirmIntercepted&&confirmationResponseReceived&&confirmationResponseOK&&seed.phase==='error'&&typeof seed.error==='string'&&seed.error.length>0&&blocked&&connection.phase==='ready'&&connection.error===''&&proof.dumpMatches&&distanceMm===1600&&typeof scenePath==='string'&&scenePath.endsWith('.scene');" in new)
check('P61_lost_exact_target_dump',"expectedDump:g198Dump,afterDump:after,dumpMatches:after===g198Dump" in new)
check('seed_read_before_recovery_twice',new.count("const seed={phase:connection.phase,error:connection.error};\n      await recoverConnection();")==2)
check('original_importBytes_and_recovery_calls_count_preserved',new.count('await ReferenceWorkspace.importBytes(g198Saved)')==old.count('await ReferenceWorkspace.importBytes(g198Saved)') and new.count('await recoverConnection()')==old.count('await recoverConnection()'))
check('two_non_verdict_diagnostic_markers',new.count("console.log('GEO320_RECOVERY_PROOF '")==2 and 'PASS GEO320' not in new)
check('unique_withdrawal_site_in_real_product',app.count(plan['withdrawal']['uniqueOriginalLine'])==1 and plan['withdrawal']['removeOnly']==' connection.error = "";')
check('only_empty_error_assignment_is_withdrawal_site',len(re.findall(r'connection\.error\s*=\s*[\"\']{2}',app))==1)
check('full_original_workflow_no_selector_new_runner',plan['newRunnerOrSelector'] is False and plan['originalCanvas']['nodeArgv']==['node','geometry-web/cdp_test.js'] and plan['originalCanvas']['filters']==[] and plan['originalCanvas']['ciTimeoutMinutes']==35 and plan['originalCanvas']['exclusive'] is True)
check('golden_not_updated_or_scope_waived',plan['originalCanvas']['goldenUpdateForbidden'] is True and plan['originalCanvas']['additionalSkips']==0 and plan['originalCanvas']['referenceOnlyForbidden'] is True)
golden=json.loads(originals['geometry-web/cdp_sections.golden.json'])
check('exact_original_pass_floor_counts',golden['total']==2267 and golden['sections']['P53']==28 and golden['sections']['P57']==56)
check('mutant_expected_floor_mismatch_not_false_new_product_red',plan['phases'][0]['goldenExpected']=='matched' and plan['phases'][2]['goldenExpected']=='matched' and plan['phases'][1]['expectedTotalFailedAssertions'] is None and 'mismatch' in plan['phases'][1]['goldenExpected'])
check('all_phases_unrun_actual_exits_null',all(x['executed'] is False and x['originalProcessExit'] is None for x in plan['phases']))
check('phase_port_binding_explicitly_pending',plan['portAndPathBindingPrepared'] is False)
check('no_product_or_new_loading_claim',plan['productChangeProposed'] is False and plan['loadingRealOwnerGuardCDPCaseAdded'] is False and plan['rootFinalLResultsInherited'] is False)
findings=[x['name'] for x in checks if not x['passed']]
report=dict(scope='STATIC_PROPOSAL_ONLY_NO_SUBJECT_EXECUTION',source='c1113f6fd6c52a55d7df1a30ecd1684fe87b661c',checks=checks,check_count=len(checks),findings=findings,exit_code=int(bool(findings)),
 conclusions=['No established assertion weakening or protocol substitution in these three changes.',
 'Unsent confirm and response-lost confirm remain distinct original imports/fetch protocol; original fixtures and prior world chain remain byte-identical outside target edits.',
 'Success-clear withdrawal is statically unique; seed and nonempty stale error checks have potential to kill it, but actual browser 0/1/0 is still required.',
 'Fixed/restored must match original golden; mutant floor mismatches from reduced sectionPass are expected consequences, not a waiver or separate new product defect.'],
 limitations=['No Node/JS/import/browser/HTTP/compiler or subject case executed by this peer.',
 'Actual browser scheduling, same public future source SHA, exact fault delivery, 3 named normal semantic failures and restored bytes remain UNRUN.',
 'Phase port-only adapter is explicitly not prepared; original fixed driver clears inherited GEOMETRY flags.',
 'Original producer Node --check had no separate capture; syntax-only host exit is not a product gate.',
 'For unrelated failed recovery, moving dump reads outside short circuit may expose errors that were previously only boolean failures; such failures must stay red and cannot substitute for the targeted stale-error kills.'])
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(checks=len(checks),findings=findings,exit_code=report['exit_code'])))
sys.exit(report['exit_code'])
