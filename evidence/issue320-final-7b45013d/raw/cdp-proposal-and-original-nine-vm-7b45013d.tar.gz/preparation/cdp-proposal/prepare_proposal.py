"""Static patch preparation only: no CDP entry, server, build or test execution."""
from pathlib import Path
import difflib, hashlib, importlib.util, json, os, re

OUT=Path(__file__).parent
REPO=Path('/workspace/issue320-work-20261024')
S='c1113f6fd6c52a55d7df1a30ecd1684fe87b661c'
C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
h=lambda b:hashlib.sha256(b).hexdigest()
assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec=importlib.util.spec_from_file_location('original_capture_metadata_only',C)
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=os.environ.copy()
for k in ('PYTHONOPTIMIZE','NODE_OPTIONS'):env.pop(k,None)
env['PYTHONDONTWRITEBYTECODE']='1'
rec=cap.Recorder(OUT/'original-source-reads-r2',env,S)
inputs=[]
def read(name):
 row,raw,err=rec.run(['git','show',S+':'+name],cwd=REPO,timeout=60,check=False,source_sha=S,source_variant='static-proposal-original-Git-read')
 assert row['actual_process_returncode']==0
 p=OUT/'original'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 inputs.append({'path':name,'bytes':len(raw),'sha256':h(raw),'originalGitRead':row})
 return raw.decode()
source=read('geometry-web/cdp_test.js')
app=read('geometry-web/app.js')
floor=read('geometry-web/cdp_floor.js')
golden=json.loads(read('geometry-web/cdp_sections.golden.json'))
workflow=read('.github/workflows/integration-tests.yml')
helper=read('geometry-web/cdp_helpers.js')
workspace=read('geometry-web/reference-workspace.js')
assert h(source.encode())=='0ffbd2c8d2df7fa9f0f731fcbddc411e0a39974de6f9abe1b91fa83507d5b669'
assert h(app.encode())=='c5f055915a039d90138824248b146552776286beb7544380c279a5586707ab60'
clear='    connection.phase = "ready"; connection.known = true; connection.error = "";'
assert app.count(clear)==1
candidate=source
old="const failedStart = await eval_(`({message:$('connectionMessage').textContent,empty:$('emptyState').hidden,count:$('objectCountBadge').textContent,inert:$('app').inert})`);"
new="const failedStart = await eval_(`({message:$('connectionMessage').textContent,empty:$('emptyState').hidden,count:$('objectCountBadge').textContent,inert:$('app').inert,phase:connection.phase,error:connection.error})`);"
assert candidate.count(old)==1;candidate=candidate.replace(old,new)
old="failedStart.count === '—' && failedStart.inert, failedStart);"
new="failedStart.count === '—' && failedStart.inert && failedStart.phase === 'error' && typeof failedStart.error === 'string' && failedStart.error.length > 0 && failedStart.error.includes('403'), failedStart);"
assert candidate.count(old)==1;candidate=candidate.replace(old,new)
start=source.index("    check('P61-10 載入未送達時")
end=source.index("    await eval_(`ReferenceWorkspace.openSource(g198PDF,1)`);",start)
old=source[start:end]
new="""    const uploadNotSentRecovery = await eval_(`(async()=>{
      const oldFetch=window.fetch.bind(window),before=(await api('dump')).text,ref=ReferenceWorkspace.active(1).id;
      let confirmIntercepted=false;
      window.fetch=async(input,init)=>{if(input==='/upload/confirm'){confirmIntercepted=true;throw new TypeError('test upload disconnected');}return oldFetch(input,init);};
      let blocked=false,importFailure=null;try{await ReferenceWorkspace.importBytes(g198Saved);}catch(e){blocked=connection.phase==='error';importFailure={name:e.name,message:e.message};}finally{window.fetch=oldFetch;}
      const seed={phase:connection.phase,error:connection.error};
      await recoverConnection();
      const after=(await api('dump')).text,source=ReferenceWorkspace.active(1).id;
      const proof={confirmIntercepted,blocked,importFailure,seed,phase:connection.phase,error:connection.error,beforeDump:before,afterDump:after,dumpMatches:after===before,sourceId:source,expectedSourceId:ref,sourceMatches:source===ref};
      proof.passed=confirmIntercepted&&seed.phase==='error'&&typeof seed.error==='string'&&seed.error.length>0&&blocked&&connection.phase==='ready'&&connection.error===''&&proof.dumpMatches&&proof.sourceMatches;
      return proof;
    })()`);
    console.log('GEO320_RECOVERY_PROOF '+JSON.stringify({case:'P61-10',...uploadNotSentRecovery}));
    check('P61-10 載入未送達時，重試連線保留原幾何與來源',uploadNotSentRecovery.passed,uploadNotSentRecovery);
    const uploadResponseLostRecovery = await eval_(`(async()=>{
      const oldFetch=window.fetch.bind(window);
      let confirmIntercepted=false,confirmationResponseReceived=false,confirmationResponseOK=false,confirmationStatus=null;
      window.fetch=async(input,init)=>{if(input==='/upload/confirm'){confirmIntercepted=true;const response=await oldFetch(input,init);confirmationResponseReceived=true;confirmationResponseOK=response.ok;confirmationStatus=response.status;throw new TypeError('test response lost');}return oldFetch(input,init);};
      let blocked=false,importFailure=null;try{await ReferenceWorkspace.importBytes(g198Saved);}catch(e){blocked=connection.phase==='error';importFailure={name:e.name,message:e.message};}finally{window.fetch=oldFetch;}
      const seed={phase:connection.phase,error:connection.error};
      await recoverConnection();
      const after=(await api('dump')).text,distanceMm=ReferenceWorkspace.active(1).calibration.distanceMm,scenePath=curScene.path;
      const proof={confirmIntercepted,confirmationResponseReceived,confirmationResponseOK,confirmationStatus,blocked,importFailure,seed,phase:connection.phase,error:connection.error,expectedDump:g198Dump,afterDump:after,dumpMatches:after===g198Dump,distanceMm,scenePath};
      proof.passed=confirmIntercepted&&confirmationResponseReceived&&confirmationResponseOK&&seed.phase==='error'&&typeof seed.error==='string'&&seed.error.length>0&&blocked&&connection.phase==='ready'&&connection.error===''&&proof.dumpMatches&&distanceMm===1600&&typeof scenePath==='string'&&scenePath.endsWith('.scene');
      return proof;
    })()`);
    console.log('GEO320_RECOVERY_PROOF '+JSON.stringify({case:'P61-11',...uploadResponseLostRecovery}));
    check('P61-11 載入已送達但回應遺失時，核對核心後恢復正確來源',uploadResponseLostRecovery.passed,uploadResponseLostRecovery);
"""
assert candidate.count(old)==1;candidate=candidate.replace(old,new)
assert len(re.findall(r'\bcheck\s*\(',source))==len(re.findall(r'\bcheck\s*\(',candidate))
assert source[:source.index('    const failedStart =')] == candidate[:candidate.index('    const failedStart =')]
assert source[end:] == candidate[candidate.index("    await eval_(`ReferenceWorkspace.openSource(g198PDF,1)`);",candidate.index('    const uploadNotSentRecovery =')):]
assert 'GEOMETRY_CDP_UPDATE_GOLDEN=1' in source and 'canvas) node geometry-web/cdp_test.js' in workflow
assert golden['sections']['P53']==28 and golden['sections']['P57']==56 and golden['total']==2267
assert "'=== P57–P61. …' → P57" in floor
p=OUT/'candidate/geometry-web/cdp_test.js';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(candidate)
patch=''.join(difflib.unified_diff(source.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/geometry-web/cdp_test.js',tofile='b/geometry-web/cdp_test.js'))
(OUT/'CDP_ONLY_CANDIDATE.patch').write_text(patch)
cap.dump(OUT/'SOURCE_PINS.json',{'source':S,'scope':'selected static input set; not a complete executable/browser closure','inputs':inputs,'candidate':{'path':str(p),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())},'patchSHA256':h(patch.encode()),'unchangedCheckCallCount':len(re.findall(r'\bcheck\s*\(',source)),'goldenOriginal':{'total':2267,'P53':28,'P57':56},'appUniqueWithdrawLine':clear,'noSubjectExecuted':True,'noSourceBranchWritten':True})
print(json.dumps({'prepared':True,'source':S,'candidateSHA256':h(p.read_bytes()),'patchSHA256':h(patch.encode()),'scope':'static only; actual CDP, faults and 0/1/0 remain UNRUN'}))
