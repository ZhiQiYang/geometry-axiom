# #344／#320 真 CDP：最小外部提案

這是尚未採用、未執行的測試差異提案。受讀來源為 `c1113f6fd6c52a55d7df1a30ecd1684fe87b661c`；其原 evidence 為 `d2c583179219dafe2f575ef158c45f3cf17bd186`、正文為 `8233916d152191fc48bf6f80a80a83dfc87f534b`。既有 9 VM 的 0/1/0 仍僅是 VM 結果。本目錄沒有修改任何工作分支、ROOT、SEED、帳本、裁判或 golden，沒有啟動 Chrome／server／編譯。

`CDP_ONLY_CANDIDATE.patch` 只對原 `geometry-web/cdp_test.js` 提案，實體候選在 `candidate/geometry-web/cdp_test.js`。這不是新 runner。`prepare_proposal.py` 只以原 c387 記錄 Git 讀取、機械產生候選並核對原 check 呼叫數，沒有載入／執行 CDP 本體。`node --check` 的原 host process exit 0 僅代表語法解析；當時未另設 c387 capture，不能稱產品測試。

## 必須保留的原流程

- P53 在原 reload 注入 403，以真 CDP mouse pointer 點 Retry；原 readonly 指令名單、失敗不發建立指令、完整 dump、部分失敗保快取、malformed/network/bridge 的 phase 與 editing guard 都保留。
- P61-10 仍在 `/upload/confirm` **尚未呼叫原 fetch** 時丟原 `TypeError('test upload disconnected')`。P61-11 仍先 `await oldFetch(...)`，收到原 HTTP 回應之後才丟原 `TypeError('test response lost')`。恢復使用真 `ReferenceWorkspace.importBytes`、transaction／lease／pendingLoad、`recoverConnection` 與原服務協定；沒有替換 owner guards。
- P61 必須沿整段 P57–P61 的原 fixtures：圖片、g198Saved／g198Dump、PDF、本機 PDF.js、1600 校準、目前較晚的世界、原 `.scene` 路徑。P61-10 比「當下原世界／來源 id」，P61-11 比「已送達目標 g198Dump／1600／.scene」；不可用同一前後 dump 取代兩條。
- 原 scope flags 沒有 P53+P61-only；`GEOMETRY_REFERENCE_ONLY=1` 還會略過 P53。抽出兩個 IIFE 會丟失前置協定及不同世界。正式編排沿原 default 全 canvas，原 35 分鐘 CI，獨占；不加 selector、不改等待上限、不改原 helper、golden 或 exception 規則。

## 候選僅補什麼

P53-1 的同一個 check 保留原四條 predicate，再直接記錄並要求 `phase=error` 與非空、含原 403 的 `connection.error`；P53-3 原 `error === ''` 與其它四條仍逐字不變。

P61 的兩個同名原 check 保留每一原 oracle，補實際 fault-hit、recover 前真非空 error seed，以及成功恢復的 phase／error、完整 dump、來源／校準／路徑診斷。P61-11 額外記錄原 confirm HTTP 回應確已收到且 `response.ok`，沒有新增數值門檻。每案僅在原恢復完成後讀取一次原 dump；候選將這個既有讀取移出短路 conjunction，讓撤回後也能證明 dump 與來源等其它條件仍正確。

兩個 `GEO320_RECOVERY_PROOF` JSON 無受控 verdict token，不增加通過數；它們讓 fixed／mutant／restored 都保存 seed 與結果，而非只在失敗時印診斷。原 check 名字與總呼叫數不變。原 P61-12..17、P53-5/6、例外計數及後續整合流程不動。Loading 的 owner-guard／transport／fallback／fetch=0 目前仍只在明示 substitutes 的 VM 中驗過；此提案不宣稱新增真 CDP loading 案。

## 獲排程後的 0/1/0

1. 先將候選採用為公開、可解析的新 source F，記所有 Git/source/golden bytes。現在沒有這個 F，也沒有任何 CDP 結果；不能把候選變成 Sc111 上已跑的斷言。
2. 依同一 F 的原 workflow 完整跑 fixed canvas，要求原 exit 0、35 分鐘內、`CDP_RESULT.completed=true`、`scope.mode=full`、空 filters、零新增 skip、原 golden `matched`。原受控例外規則照舊，不另訂 uncaught=0。
3. 只在獨立受驗樹撤回 app.js 的唯一 `connection.phase = "ready"; connection.known = true; connection.error = "";` 中的 ` connection.error = "";`；保 ready／known 與同一 F 的 tests/golden。完整 canvas 原 exit 預期 1，必須看到 P53-3、P61-10、P61-11 的具名正常 assertion 紅；每案 seed 仍非空、真 fault 命中，ready／dump／來源／1600／.scene 等其它條件仍正確，差異是舊 error 未清。啟動、缺檔、編譯、timeout、FATAL 或其它語意失敗不能代替這三個牙齒；有額外失敗先保 raw 再分類。
4. 還原 app.js 的同一 F 原 bytes，原完整 canvas exit 0 與 golden matched，最後核原 tests／golden／產品 bytes 均恢復。每階段分開 full stdout/stderr、環境、exit、時限、phase tree 與 base execution F；撤回樹要明示 variant 與實際檔案 hash，不能冒 clean F。

原 golden 總數2267；P53–P56 歸 key `P53`=28，P57–P61 歸 key `P57`=56。`cdp_floor.js`／`evaluateSections()` 比的是 **通過數**。若只三個目標 assertion 轉紅，紅階段會衍生 P53 與 P57 兩項 golden mismatch；這是原裁判正常結果。**fixed／restored 必 matched；mutant 不要求 matched，也不能硬把總 failedAssertions 訂為3**（原 floor 也加 failN）。不開 UPDATE_GOLDEN，不把衍生 mismatch 冒額外產品缺陷。

沿既有已審 workflow driver `57f3a2d8932572a8d6b54ed3238a3f1c1c5056783973529077f4ddeb2320bc1d` 的完整 canvas CLI：`<approved-python> -B <phase-bound-existing-driver> --repo <isolated-F-or-declared-variant-tree> --sha <F> --job canvas --out-root <new-phase-output>`。原 driver 會清繼承 GEOMETRY flags；不能靠外部 env 偷渡 selector／port。三階段的 HTTP／CDP 埠若需各自唯一，僅做埠／路徑機械 binding，執行前另封最小 diff/hash 並 peer；此提案尚未產生或驗收該 binding。每階段使用新 TMP／feedback／profile／runtime root、私有輸出、同時僅一個 canvas。原 3× watchdog 只保收集，不放寬35分鐘正式 gate。套件、版本、build、readiness、原 shell、清理、wait trace／artifacts、golden 皆沿原 workflow。

採用新 test driver 後，runtime／架構登錄等影響須在真 F 判定；`mutate.py --check` 只判帳本 freshness，整份重產仍由 root 統一安排。本提案不擅自繼承 root final-L 任一結果，也不把此候選當 L 的六 browser closure。

## 來源與限制

`SOURCE_PINS.json` 僅列本次靜態輸入子集合，不冒完整 browser closure。原 selected Git blobs 與完整 c387 stdout/stderr 在 `original-source-reads/`、`original-source-reads-r2/`；初版 producer 因尾段比對用到較早的同名 openSource 行而自身 AssertionError1，原 script／分類同目錄保留，修正 metadata index 後產案0，沒有執行產品。先前一次讀薄 checkout 的 workflow 路徑不存在，是靜態讀取缺物化；後續直接讀固定 Git blob，沒有將它算 gate 紅燈。

kernel 的原清單 `/tmp/issue320-cdp-existing-checklist.md` SHA256 `704ecbd1800ed5826aea6b9fa8db453600caa1b95573ac612e4d222d45682bc4` 保持原 bytes；kernel 隨後明確澄清 full golden matched 僅指 fixed/restored。該清單是現在將舊訊息落檔，不是更早已存在的計畫收據。

目前結論：最小測試差異可供獨立靜審，真 CDP、三個協定案例及撤回／恢復均 **UNRUN**。沒有證據可稱跨版本瀏覽器已綠。
