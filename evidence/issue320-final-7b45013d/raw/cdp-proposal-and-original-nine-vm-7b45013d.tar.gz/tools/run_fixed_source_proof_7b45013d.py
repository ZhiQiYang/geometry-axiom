from pathlib import Path
import hashlib, importlib.util, json, os, re, time

B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
O = B / 'fixed-source-proof-7b45013d'
S = '7b45013da647b791acda8f5977475e4123d5f8c4'
assert not O.exists()
O.mkdir()
H = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
assert hashlib.sha256(H.read_bytes()).hexdigest() == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
spec = importlib.util.spec_from_file_location('cap', H)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['LC_ALL'] = 'C.UTF-8'
env['NO_COLOR'] = '1'
env['GITHUB_SHA'] = S
env['GITHUB_WORKSPACE'] = str(W)
env['TMPDIR'] = str(B / 'tmp')
rec = cap.Recorder(O, env, S)
paths = ['geometry-web/app.js', 'geometry-web/cdp_test.js', 'tests/test_connection_recovery.js', 'tests/run_all.py', 'tests/run_all.expected.json']
command = ['node', '--test', '--test-reporter=spec', 'tests/test_connection_recovery.js']
cap.dump(O / 'REQUEST.json', {
    'sourceSHA': S,
    'actualCommandEachPhase': command,
    'phaseOrder': ['baseline', 'withdraw-unique-ready-error-clear', 'restored'],
    'expectedOriginalExitCodes': [0, 1, 0],
    'sourceScope': paths,
    'driverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'captureSHA256': hashlib.sha256(H.read_bytes()).hexdigest(),
    'timeoutSecondsEach': 300,
    'classification': '9 original-function VM unit tests with explicit DOM/transport substitutes; not browser, HTTP, native or whole-project acceptance',
    'heavySlot': 'pure Node only; no compiler/browser/performance process; no secondary/R3 changes',
})
_, head, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
assert head.decode().strip() == S
_, before_status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert before_status == b''
_, before_stage, _ = rec.run(['git', 'ls-files', '--stage', '--', *paths], cwd=W)
rec.run(['node', '--version'], cwd=W)
inputs = []
for path in paths:
    _, raw, _ = rec.run(['git', 'show', S + ':' + path], cwd=W)
    physical = (W / path).read_bytes()
    assert physical.replace(bytes([13, 10]), bytes([10])) == raw.replace(bytes([13, 10]), bytes([10])), path
    dest = O / 'inputs' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(physical)
    inputs.append({'path': path, 'bytes': len(physical), 'sha256': hashlib.sha256(physical).hexdigest(), 'gitSourceSHA': S})
app_path = W / 'geometry-web/app.js'
fixed = app_path.read_bytes()
needle = b'connection.phase = "ready"; connection.known = true; connection.error = "";'
original = b'connection.phase = "ready"; connection.known = true;'
assert fixed.count(needle) == 1
withdrawn = fixed.replace(needle, original)
(O / 'withdrawn-app.js').write_bytes(withdrawn)
phases = []
def run_phase(name):
    row, stdout, stderr = rec.run(command, cwd=W, timeout=300, check=False, source_variant=name)
    text = stdout.decode('utf-8', 'strict')
    counts = {}
    for field in ['tests', 'pass', 'fail', 'cancelled', 'skipped']:
        match = re.search(r'^ℹ ' + field + r'\s+(\d+)\s*$', text, re.M)
        counts[field] = int(match.group(1)) if match else None
    phases.append({'phase': name, 'actualProcessReturnCode': row['actual_process_returncode'], 'originalCommand': row, 'counts': counts, 'stdoutHasNormalAssertion': 'ERR_ASSERTION' in text, 'hasUnexpectedErrorClass': bool(re.search(r'SyntaxError|ReferenceError|TypeError|uncaughtException', text + stderr.decode('utf-8', 'replace'))), 'sourceAppSHA256': hashlib.sha256(app_path.read_bytes()).hexdigest()})

try:
    run_phase('baseline')
    app_path.write_bytes(withdrawn)
    rec.run(['git', 'diff', '--', 'geometry-web/app.js'], cwd=W, source_variant='withdrawn-source-diff')
    _, status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W, source_variant='withdrawn-controlled-dirty-status')
    assert status.decode().splitlines() == [' M geometry-web/app.js']
    run_phase('withdraw-unique-ready-error-clear')
finally:
    app_path.write_bytes(fixed)
    run_phase('restored')

_, final_head, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
_, after_status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
_, after_stage, _ = rec.run(['git', 'ls-files', '--stage', '--', *paths], cwd=W)
assert final_head == head and after_status == b'' and after_stage == before_stage
assert app_path.read_bytes() == fixed
expected_counts = [{'tests': 9, 'pass': 9, 'fail': 0, 'cancelled': 0, 'skipped': 0}, {'tests': 9, 'pass': 6, 'fail': 3, 'cancelled': 0, 'skipped': 0}, {'tests': 9, 'pass': 9, 'fail': 0, 'cancelled': 0, 'skipped': 0}]
accepted = [p['actualProcessReturnCode'] for p in phases] == [0, 1, 0] and [p['counts'] for p in phases] == expected_counts and phases[1]['stdoutHasNormalAssertion'] and not any(p['hasUnexpectedErrorClass'] for p in phases)
out = Path(phases[1]['originalCommand']['directory']) / 'stdout.bin'
normal_messages = ['successful recovery kept stale error', 'completed retry kept stale error', 'loading echoed stale error']
accepted = accepted and all(s in out.read_text() for s in normal_messages)
cap.dump(O / 'RESULT.json', {'sourceSHA': S, 'endedEpoch': time.time(), 'originalSourceInputs': inputs, 'phases': phases, 'expectedNormalAssertionMessages': normal_messages, 'sourceBeforeAfterClean': True, 'selectedStageListingBeforeAfterEqual': True, 'appBytesRestored': True, 'proofAccepted': accepted, 'originalExits': [p['actualProcessReturnCode'] for p in phases], 'fullCanvas': 'UNRUN', 'fullNative': 'UNRUN', 'globalLedgerWritten': False, 'limits': ['VM executes exact original app function spans; transport/DOM collaborators are substitutes, not real browser/UI/native coverage.', 'Controlled withdrawn variant is intentionally dirty only in this independent worktree app.js; actual source identity remains S and variant is explicit.', 'No golden assertion or existing timeout was changed; P53/P61 browser predicates strengthened without changing original check census.']})
print(json.dumps({'source': S, 'originalExits': [p['actualProcessReturnCode'] for p in phases], 'counts': [p['counts'] for p in phases], 'proofAccepted': accepted}, ensure_ascii=False))
raise SystemExit(0 if accepted else 1)
