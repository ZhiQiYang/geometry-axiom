from pathlib import Path
import hashlib, importlib.util, io, json, os, tarfile

B = Path('/workspace/issue320-20261024')
W = Path('/workspace/issue320-work-20261024')
S = '7b45013da647b791acda8f5977475e4123d5f8c4'
BRANCH = 'codex/issue320-connection-recovery-20261024'
PREFIX = 'evidence/issue320-final-7b45013d'
O = B / 'seed-evidence-publication-7b45013d'
C = Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(C) == 'c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert not O.exists()
O.mkdir()
spec = importlib.util.spec_from_file_location('original_capture', C)
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
env = dict(os.environ)
env.pop('PYTHONOPTIMIZE', None)
env.pop('NODE_OPTIONS', None)
env.update(PYTHONDONTWRITEBYTECODE='1', LC_ALL='C.UTF-8')
rec = cap.Recorder(O, env, S)
proof = json.loads((B / 'fixed-source-proof-7b45013d/RESULT.json').read_bytes())
launch = json.loads((B / 'fixed-source-proof-7b45013d-launch/RESULT.json').read_bytes())
assert proof['sourceSHA'] == S and proof['proofAccepted'] and proof['originalExits'] == [0, 1, 0]
assert launch['sourceSHA'] == S and launch['actualDriverExit'] == 0
static_peer = Path('/tmp/issue320-cdp-kernel-static-peer/REVIEW.json')
assert sha(static_peer) == 'fc4d666dc87cebd99a6401296743b37aadbac0a66e28e1c4ca4fc1e58cf0e6bf'
cap.dump(O / 'REQUEST.json', {'sourceSHA': S, 'branch': BRANCH, 'prefix': PREFIX, 'publicationOnly': True, 'driverSHA256': sha(__file__), 'subjectExecution': False})
_, head, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
_, status, _ = rec.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
assert head.decode().strip() == S and status == b''

originals = {}
groups = {
    'originals/source-publication': B / 'cdp-seed-source-publication',
    'originals/original-nine-vm': B / 'fixed-source-proof-7b45013d',
    'originals/prelaunched-outer': B / 'fixed-source-proof-7b45013d-launch',
    'preparation/cdp-proposal': Path('/tmp/issue320-real-cdp-static-preparation'),
    'peer/cdp-static': static_peer.parent,
    'peer/vm-initial-checker-schema-error': Path('/tmp/issue320-vm-7b45013d-kernel-peer'),
    'peer/vm-r2-outer': Path('/tmp/issue320-vm-7b45013d-kernel-peer-launch-r2'),
}
for prefix, directory in groups.items():
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            originals[prefix + '/' + path.relative_to(directory).as_posix()] = path
for name in ['run_fixed_source_proof.py', 'run_fixed_source_proof_7b45013d.py', 'prepare_seed_vm_binding.py', 'VM_BINDING_7b45013d.json', 'VM_BINDING_7b45013d.diff', 'launch_seed_vm_7b45013d.py', 'launch_seed_vm_7b45013d_initial_missing_output_dir.py.txt', 'VM_LAUNCH_SETUP_INITIAL_ERROR.json', 'publish_cdp_seed_source.py', 'publish_seed_evidence_7b45013d.py']:
    originals['tools/' + name] = B / name
originals['tools/capture.py'] = C
originals['peer/review_vm_r2.py'] = Path('/tmp/peer_issue320_vm_7b45013d_r2.py')
actual_binding_path = B / 'ACTUAL_PEER_7b45013d_PATH.json'
actual_peer_binding = None
if actual_binding_path.is_file():
    actual_peer_binding = json.loads(actual_binding_path.read_bytes())
    actual_peer = Path(actual_peer_binding['path'])
    assert sha(actual_peer) == actual_peer_binding['sha256']
    peer = json.loads(actual_peer.read_bytes())
    assert not peer.get('findings')
    for path in sorted(actual_peer.parent.rglob('*')):
        if path.is_file():
            originals['peer/new-source-vm-actual/' + path.relative_to(actual_peer.parent).as_posix()] = path
    originals['peer/ACTUAL_PEER_PATH.json'] = actual_binding_path
inventory = [{'member': member, 'originalPath': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)} for member, path in sorted(originals.items())]
dest = W / PREFIX
assert not dest.exists()
(dest / 'raw').mkdir(parents=True)
archive = dest / 'raw/cdp-proposal-and-original-nine-vm-7b45013d.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for item in inventory:
        payload = Path(item['originalPath']).read_bytes()
        info = tarfile.TarInfo(item['member'])
        info.size, info.mode, info.mtime = len(payload), 0o644, 0
        tf.addfile(info, io.BytesIO(payload))
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(inventory)
    for item in inventory:
        raw = tf.extractfile(item['member']).read()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert raw == Path(item['originalPath']).read_bytes()
cap.dump(dest / 'RAW_INVENTORY.json', inventory)
cap.dump(dest / 'PACKAGE.json', {'sourceSHA': S, 'archive': archive.relative_to(dest).as_posix(), 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive), 'members': len(inventory), 'inventorySHA256': sha(dest / 'RAW_INVENTORY.json'), 'roundtripAllOriginalBytes': True, 'scope': 'new-source Node VM actual and real-CDP preparation only; no browser execution'})
current = {
    'productSHA': S, 'nodeExecutionSHA': S, 'originalNodeExits': [0, 1, 0],
    'originalMethodsEachPhase': 9, 'passedEachPhase': [9, 6, 9], 'failedEachPhase': [0, 3, 0], 'skipsEachPhase': [0, 0, 0],
    'expectedNormalAssertions': proof['expectedNormalAssertionMessages'], 'originalProofSHA256': sha(B / 'fixed-source-proof-7b45013d/RESULT.json'),
    'originalVMResult': 'PASS: explicit DOM/transport/ReferenceWorkspace substitutes; not browser/HTTP/native',
    'newSourceVMActualPeer': actual_peer_binding if actual_peer_binding else 'PENDING; not claimed completed',
    'cdpProposalStaticPeer': {'path': str(static_peer), 'sha256': sha(static_peer), 'checks': 49, 'scope': 'static only'},
    'realP53P61CDP': 'UNRUN', 'fullCanvas': 'UNRUN', 'otherFiveBrowserJobs': 'UNRUN', 'fullNative': 'UNRUN',
    'mutationCheckAndFullLedger': 'UNRUN; root owns final ledger', 'architectureThreeAndDerivedFour': 'UNRUN',
    'priorExecutionSHA': 'c1113f6fd6c52a55d7df1a30ecd1684fe87b661c', 'priorEvidenceSHA': 'd2c583179219dafe2f575ef158c45f3cf17bd186',
    'outerCapture': 'This new-source run has prelaunched REQUEST and independent c387 driver pipes. Earlier c111 host-only outer limitation remains historical.',
    'initialLauncherError': 'FileNotFoundError before request/subject launch; preserved, corrected mkdir only, not a product test failure',
    'goldenChanged': False, 'noNewSkip': True, 'noGlobalLedgerWritten': True,
}
cap.dump(dest / 'CURRENT_STATE.json', current)
(dest / 'PROGRESS.md').write_text('''# #344 / #320 進度

受測及產品來源 S=`7b45013da647b791acda8f5977475e4123d5f8c4`，本次只加強真 CDP 三個原 checks 的非空舊錯誤 seed／診斷；app、golden、原 check 名稱數量及時限未改。舊 Sc111 的結果保原 SHA，不轉標。

本 S 原 Node 九案真完成 0／1／0，pass 9／6／9、fail 0／3／0、全零 skip；撤回僅唯一 ready error clear，三個正常具名 ERR_ASSERTION，還原 app bytes／HEAD／選定 stage listing 與 clean source。17 個原 inner commands、事前 outer REQUEST／完整 c387 streams／退出碼／環境與五 Git inputs 全封。

VM 使用明示 DOM／transport／ReferenceWorkspace 替身，不能當成瀏覽器、HTTP 或原生驗收。真 P53／P61／完整 canvas 以及其他正式項仍 UNRUN。CDP 49／0 是靜審，不是反證擊殺。新 S 的 actual peer 若尚未完成，CURRENT_STATE 明列 pending。

原 launcher 首次缺 output mkdir，未啟動 subject；原 helper 與錯誤說明保留，沒有冒為產品紅。完整原件逐成員 bytes/hash roundtrip；MANIFEST 排自身。舊 Sc111 原 setup 失敗、peer 與證據包仍在原公開 prefix。

下一步：原 full canvas／35min／golden／獨占三態編排先 peer 再等 root 時槽。clean-S driver 不能以 dirty checkout 前置失敗冒 CDP kill；需要顯式唯一 app 變體及全部其餘 inputs 的精確綁定。未產全帳本，不 force push，不合併 PR。
''', encoding='utf-8')
manifest = [{'path': p.relative_to(dest).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(dest.rglob('*')) if p.is_file()]
cap.dump(dest / 'MANIFEST.json', {'scope': 'all other files in this prefix, excluding this MANIFEST.json', 'files': manifest})
rec.run(['git', 'add', '--force', '--sparse', '--', PREFIX], cwd=W)
_, staged, _ = rec.run(['git', 'diff', '--cached', '--name-only'], cwd=W)
assert staged and all(p.startswith(PREFIX + '/') for p in staged.decode().splitlines())
rec.run(['git', 'diff', '--cached', '--check'], cwd=W)
rec.run(['git', 'commit', '-m', 'evidence: archive seeded CDP proposal and new-source VM proof'], cwd=W)
_, raw, _ = rec.run(['git', 'rev-parse', 'HEAD'], cwd=W)
evidence = raw.decode().strip()
rec.run(['git', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH], cwd=W)
_, remote, _ = rec.run(['git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/' + BRANCH], cwd=W)
assert remote.decode().split()[0] == evidence
cap.dump(O / 'RESULT.json', {'sourceSHA': S, 'evidenceSHA': evidence, 'branch': BRANCH, 'prefix': PREFIX, 'normalPushExit': 0, 'remoteEqual': True, 'archiveSHA256': sha(archive), 'members': len(inventory), 'actualPeer': actual_peer_binding})
print(json.dumps({'sourceSHA': S, 'evidenceSHA': evidence, 'prefix': PREFIX, 'members': len(inventory), 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive)}))
