from pathlib import Path
import hashlib,importlib.util,json,os
B=Path('/workspace/issue320-20261024');W=Path('/workspace/issue320-work-20261024');O=B/'cdp-seed-source-publication';assert not O.exists();O.mkdir()
OLD='d2c583179219dafe2f575ef158c45f3cf17bd186';BRANCH='codex/issue320-connection-recovery-20261024'
PATCH=Path('/tmp/issue320-real-cdp-static-preparation/CDP_ONLY_CANDIDATE.patch');CANDIDATE=Path('/tmp/issue320-real-cdp-static-preparation/candidate/geometry-web/cdp_test.js')
C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');h=lambda raw:hashlib.sha256(raw).hexdigest()
assert h(C.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762'
assert h(PATCH.read_bytes())=='3533145ff2f2364f4252e6009c46cc3854651ccc92db32ef78280bc1d445cdd9'
assert h(CANDIDATE.read_bytes())=='1f3e2e36283ed7bbf6c4ad2cf3dc12c685667356d186d9fbd47bc5f0520f07ee'
PEER=Path('/tmp/issue320-cdp-kernel-static-peer/REVIEW.json');assert h(PEER.read_bytes())=='fc4d666dc87cebd99a6401296743b37aadbac0a66e28e1c4ca4fc1e58cf0e6bf'
spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None);env.update(PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',NO_COLOR='1')
rec=cap.Recorder(O,env,OLD)
cap.dump(O/'REQUEST.json',{'baseEvidenceHEAD':OLD,'branch':BRANCH,'exactOnlyChangedPath':'geometry-web/cdp_test.js','patchSHA256':h(PATCH.read_bytes()),'candidateSHA256':h(CANDIDATE.read_bytes()),'independentPeerSHA256':h(PEER.read_bytes()),'subjectExecuted':False,'rootOrOtherBranchesWritten':False,'commitMessage':'test: trace browser connection recovery faults','forcePush':False})
def run(argv,sha=OLD):
 row,out,err=rec.run(argv,cwd=W,timeout=120,check=False,source_sha=sha,source_variant='own source publication; not gate execution')
 if row['actual_process_returncode']!=0:raise RuntimeError('publication command failed: '+repr(argv))
 return out
assert run(['git','rev-parse','HEAD']).decode().strip()==OLD
assert run(['git','branch','--show-current']).decode().strip()==BRANCH
assert run(['git','status','--porcelain=v1','--untracked-files=all'])==b''
assert run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH]).decode().split()[0]==OLD
unchanged={p:h((W/p).read_bytes())for p in ['geometry-web/app.js','geometry-web/cdp_sections.golden.json','tests/test_connection_recovery.js','tests/run_all.py','tests/run_all.expected.json']}
assert h((W/'geometry-web/cdp_test.js').read_bytes())=='0ffbd2c8d2df7fa9f0f731fcbddc411e0a39974de6f9abe1b91fa83507d5b669'
run(['git','apply','--check',str(PATCH)]);run(['git','apply','--index',str(PATCH)])
assert run(['git','diff','--cached','--name-only']).decode().splitlines()==['geometry-web/cdp_test.js']
run(['git','diff','--cached','--check']);run(['git','diff','--cached','--','geometry-web/cdp_test.js'])
assert (W/'geometry-web/cdp_test.js').read_bytes()==CANDIDATE.read_bytes()
assert all(h((W/p).read_bytes())==digest for p,digest in unchanged.items())
run(['git','commit','-m','test: trace browser connection recovery faults'])
S=run(['git','rev-parse','HEAD']).decode().strip()
assert run(['git','status','--porcelain=v1','--untracked-files=all'],S)==b''
run(['git','push','origin','HEAD:refs/heads/'+BRANCH],S)
remote=run(['git','ls-remote','--heads','origin','refs/heads/'+BRANCH],S).decode().split()[0];assert remote==S
result={'sourceSHA':S,'parentEvidenceHEAD':OLD,'branch':BRANCH,'normalPushAndRemoteSame':True,'sourceCleanAfter':True,'onlyChangedPath':'geometry-web/cdp_test.js','candidateSHA256':h(CANDIDATE.read_bytes()),'unchangedInputHashes':unchanged,'oldVMExecutionSHA':'c1113f6fd6c52a55d7df1a30ecd1684fe87b661c','newVM':'UNRUN','realCDP':'UNRUN','noGlobalLedgerWritten':True,'noRootSourceWritten':True,'commands':rec.rows}
cap.dump(O/'RESULT.json',result);print(json.dumps({'sourceSHA':S,'remoteSame':remote==S,'onlyChangedPath':'geometry-web/cdp_test.js','actualSubjectExecuted':False}));
