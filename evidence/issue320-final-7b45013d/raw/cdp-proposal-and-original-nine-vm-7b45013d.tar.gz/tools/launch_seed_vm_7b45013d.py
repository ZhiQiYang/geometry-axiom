from pathlib import Path
import hashlib,importlib.util,json,os,sys,ast
B=Path('/workspace/issue320-20261024');O=B/'fixed-source-proof-7b45013d-launch';D=B/'run_fixed_source_proof_7b45013d.py';C=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');S='7b45013da647b791acda8f5977475e4123d5f8c4';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not O.exists();assert h(C)=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762';assert h(D)=='be1940cc4fd2976ac3353023f5db8c5735719c647eefd928cb1d4be86c4a38ff';ast.parse(D.read_text())
spec=importlib.util.spec_from_file_location('original_capture',C);cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)
env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env.pop('NODE_OPTIONS',None);env.update(PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',GITHUB_SHA=S)
O.mkdir();rec=cap.Recorder(O,env,S);argv=[sys.executable,'-B',str(D)]
cap.dump(O/'REQUEST.json',{'sourceSHA':S,'argv':argv,'driverSHA256':h(D),'bindingPath':str(B/'VM_BINDING_7b45013d.json'),'outerTimeout':None,'originalNodePhaseTimeoutSeconds':300,'scope':'original9VM only; no Chrome/compiler/HTTP/native/R3/secondary lock','sourceAlreadyNormallyPushed':True})
row,out,err=rec.run(argv,cwd=B,timeout=None,check=False,source_sha=S,source_variant='new publishedS original9VM 0/1/0 wrapper')
cap.dump(O/'RESULT.json',{'sourceSHA':S,'actualDriverExit':row['actual_process_returncode'],'originalCommand':row});sys.stdout.buffer.write(out);sys.stderr.buffer.write(err);raise SystemExit(row['actual_process_returncode'])
