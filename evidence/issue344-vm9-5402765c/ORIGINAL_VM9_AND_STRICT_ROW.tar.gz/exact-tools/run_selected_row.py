from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,re,shutil,stat,traceback
S='5402765c795769a77a7b249de1e3db80045a41de';R=Path('/tmp/geo344-S540-source-20261024');B=Path('/tmp/geo344-S540-vm9-20261024');O=B/'selected-aggregate';CACHE=Path('/tmp/geometry-tests');LOGS=CACHE/'run_all-logs';CAP=Path('/workspace/geo261-environment/final-f-contact-checker-proof-tools/capture.py');H=lambda b:hashlib.sha256(b).hexdigest();assert H(CAP.read_bytes())=='c387835c03fce36be0861b7fa5228ae494ad2be94bfa9cd62d4f36b9782dc762';assert not O.exists();O.mkdir();(O/'prior-row-logs').mkdir();(O/'new-row-logs').mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('GIT_')and k not in ['PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME','PYTHONSTARTUP','NODE_OPTIONS','LD_PRELOAD']};env.update(PYTHONDONTWRITEBYTECODE='1',LC_ALL='C.UTF-8',GITHUB_SHA=S,GITHUB_WORKSPACE=str(R),TMPDIR=str(B/'tmp'),NO_COLOR='1');sp=importlib.util.spec_from_file_location('cap',CAP);cap=importlib.util.module_from_spec(sp);sp.loader.exec_module(cap);rec=cap.Recorder(O,env,S)
report={'source_sha':S,'argv':['python3','-B','tests/run_all.py','--only','node:connection_recovery'],'original_row_timeout_seconds':300,'needs':[],'original_subject_exit':None,'exit':1,'full_native':'UNRUN','full_canvas':'UNRUN','build_requested':False,'C_executed':False,'errors':[]};beforecache=None;prior={};buildlock=None;prior_rootdir=None

def need(v,m):
 if not v:raise RuntimeError(m)
def g(*args):
 row,out,err=rec.run(['git','--no-optional-locks',*args],cwd=R,timeout=None,check=False,source_variant='same cleanS540 original selected Node aggregate');need(row['actual_process_returncode']==0,'original Git failure '+row['directory']);return out
def clean():
 need(g('rev-parse','HEAD').decode().strip()==S,'realS HEAD');need(g('status','--porcelain=v1','--untracked-files=all')==b'' and g('diff','--cached','--name-status')==b'','true clean source/index')
def cache():
 rows={}
 for p in sorted(CACHE.iterdir()):
  if p.is_dir()or p.name in ['run_all.lock','build.lock']:continue
  st=p.lstat();need(stat.S_ISREG(st.st_mode),'ordinary globalcache leaf');data=p.read_bytes();end=p.stat();need((st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(end.st_ino,end.st_size,end.st_mtime_ns,end.st_ctime_ns),'globalcache changed while read');rows[p.name]={'bytes':len(data),'sha256':H(data),'mode':stat.S_IMODE(st.st_mode),'dev':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
 return rows
try:
 need(shutil.disk_usage('/tmp').free>=16*1024*1024,'private capture16MiB resourceguard');clean();before_source={p:H((R/p).read_bytes())for p in ['geometry-web/app.js','tests/run_all.py','tests/binaries.py','tests/run_all.expected.json','tests/test_connection_recovery.js']};cap.dump(O/'SOURCE_BEFORE.json',before_source)
 expected=json.loads((R/'tests/run_all.expected.json').read_bytes())['suites']['node:connection_recovery'];need(expected=={'mode':'count','count':9,'unit':'node test'},'original strict count9')
 probe=(CACHE/'run_all.lock').open('a+b');fcntl.flock(probe.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);report['original_run_all_lock_probe_acquired']=True;probe.close()
 buildlock=(CACHE/'build.lock').open('a+b');fcntl.flock(buildlock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);report['original_build_lock_held']=True
 # The child takes its own unchanged ProcessLock(run_all). The probe is released first to avoid self-deadlock.
 beforecache=cache();cap.dump(O/'GLOBAL_CACHE_BEFORE.json',beforecache)
 for p in sorted(LOGS.glob('node_connection_recovery.*')):
  st=p.lstat();need(stat.S_ISREG(st.st_mode)and st.st_nlink==1,'shared row regular independent file');data=p.read_bytes();(O/'prior-row-logs'/p.name).write_bytes(data);prior[p.name]={'bytes':len(data),'sha256':H(data),'mode':stat.S_IMODE(st.st_mode),'atime_ns':st.st_atime_ns,'mtime_ns':st.st_mtime_ns}
 cap.dump(O/'PRIOR_ROW_LOGS.json',prior)
 row,out,err=rec.run(['python3','-B','tests/run_all.py','--only','node:connection_recovery','--list'],cwd=R,timeout=None,check=False,source_variant='original full registry and selected needs check');need(row['actual_process_returncode']==0,'original registry check failed');need('node:connection_recovery'in out.decode()and'登記問題：'not in out.decode(),'original selected row present with complete registry')
 row,out,err=rec.run(report['argv'],cwd=R,timeout=None,check=False,source_variant='original strict selected aggregate row9; child original300 seconds');report['original_subject_exit']=row['actual_process_returncode'];report['subject_command_directory']=row['directory']
 for p in sorted(LOGS.glob('node_connection_recovery.*')):
  need(p.is_file()and not p.is_symlink(),'new row ordinary file');(O/'new-row-logs'/p.name).write_bytes(p.read_bytes())
 clean();after_source={p:H((R/p).read_bytes())for p in before_source};cap.dump(O/'SOURCE_AFTER.json',after_source);need(after_source==before_source,'source unchanged')
 log=(O/'new-row-logs/node_connection_recovery.log').read_text();counts={}
 for field in ['tests','pass','fail','cancelled','skipped']:
  match=re.search(r'^ℹ '+field+r'\s+(\d+)\s*$',log,re.M);counts[field]=int(match.group(1))if match else None
 report['node_counts']=counts;report['strict_expected']=expected;need(row['actual_process_returncode']==0 and counts=={'tests':9,'pass':9,'fail':0,'cancelled':0,'skipped':0},'original selected strict9 not green; fullraw retained');report['exit']=0
except BaseException:report['errors'].append(traceback.format_exc());report['exit']=1
finally:
 try:
  for name,m in prior.items():
   data=(O/'prior-row-logs'/name).read_bytes();need(H(data)==m['sha256'],'backup bytes fixed');p=LOGS/name;p.write_bytes(data);os.chmod(p,m['mode']);os.utime(p,ns=(m['atime_ns'],m['mtime_ns']));need(p.read_bytes()==data,'original row restored')
  report['prior_row_logs_restored']=len(prior);report['new_global_logs_retained_without_prior']=[p.name for p in LOGS.glob('node_connection_recovery.*')if p.name not in prior];report['no_old_or_new_receipts_deleted']=True
  if beforecache is not None:
   aftercache=cache();cap.dump(O/'GLOBAL_CACHE_AFTER.json',aftercache);need(beforecache==aftercache,'binary/sidecar bytes or stablemetadata changed');report['global_binary_sidecar_hashes_unchanged']=True
 except BaseException:report['errors'].append(traceback.format_exc());report['exit']=1
 if buildlock:buildlock.close()
 report['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cap.dump(O/'RESULT.json',report);print(json.dumps(report,ensure_ascii=False))
raise SystemExit(report['exit'])
