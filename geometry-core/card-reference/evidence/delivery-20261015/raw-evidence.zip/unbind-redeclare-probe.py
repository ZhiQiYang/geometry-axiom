import sys
import json
sys.path.insert(0,'/workspace/geometry-axiom')
from tests.test_grid_card_reference import GridCardReference, parameter, unbind
GridCardReference.setUpClass()
c=GridCardReference('test_CR13_EXPLICIT_UNBIND_ORDERED_CAPTURE')
c.setUp()
try:
    c.seed()
    p=c.request([{'op':'delete-parameter','id':10},parameter(),unbind('parameter')])['preview']
    print(json.dumps({'valid':p['valid'],'violations':p['violations']},ensure_ascii=False,indent=2))
    assert p['valid'],'EXPLICIT_UNBIND after last deletion must declare the two newly created ParameterRefs'
finally:
    c.doCleanups()
