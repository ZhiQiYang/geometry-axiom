'use strict';
const assert=require('node:assert/strict');
const R='/workspace/geometry-axiom';
const P=require(R+'/geometry-web/project-store.js'),S=require(R+'/geometry-web/scenario-snapshots.js');
const zip=require(R+'/geometry-web/vendor/fflate/umd/index.js');
(async()=>{
  const scene='requires parameters/1\nrequires grid-card-reference/1\nparameters begin\nparameters end\ngrid-system 4 name-hex 47 main-along none card-reference 10 3 8 u repeat -5 card v repeat 7 card\n';
  const leaf=await P.unpack(await P.pack(scene,{projectId:'card-project',name:'leaf',faces:[],sources:[]},new Map(),zip),zip);
  const archive=S.create({project:P,featureAttachments:{validate:P.Features.validate,references:P.Features.sourceIds},verifyProject:async()=>({ok:true,capabilities:['grid-card-reference/1','parameters/1'],final_objects:{boundaries:[],placements:[]},objects:[]})});
  await archive.capture(leaf,{scenarioId:'card-leaf',label:'card-leaf'});
  const root={projectId:'card-project',name:'root',faces:[],sources:[],scenarioCatalog:{schema:S.SCHEMA,scenarios:archive.list()}};
  const p=await P.unpack(await P.pack('reset\n',root,new Map(),zip),zip);
  console.log(JSON.stringify({format:p.manifest.format,required:p.manifest.requiredCapabilities}));
  assert.equal(p.manifest.format,'geometry-canvas/18','CARD_SAVE_ROUNDTRIP nested card capability must reach root');
  assert.ok(p.manifest.requiredCapabilities.includes('grid-card-reference/1'));
  assert.ok(p.manifest.requiredCapabilities.includes('parameters/1'));
})().catch(e=>{console.error(e);process.exitCode=1;});
