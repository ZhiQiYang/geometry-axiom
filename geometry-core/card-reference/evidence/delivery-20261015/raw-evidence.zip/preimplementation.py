from pathlib import Path
import subprocess
import json
import hashlib
import sys
R=Path('/workspace/geometry-axiom');D=Path('/tmp/geometry-task20/preimplementation-193');D.mkdir()
ref='6236f5733052a19362132738a4eb79cac7924e0b'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'current_geometry.c','geometry-core','geometry-web'],cwd=R,text=True).splitlines()
for path in files:
    if not path.endswith(('.c','.h','.inc')):continue
    target=D/path;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(subprocess.check_output(['git','show',ref+':'+path],cwd=R))
command=['cc','-std=c11','-O0',str(D/'geometry-web/web_bridge.c'),'-lm','-o',str(D/'bridge')]
p=subprocess.run(command,capture_output=True);(D/'compile.stdout').write_bytes(p.stdout);(D/'compile.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr
command=[sys.executable,str(R/'geometry-core/card-reference/run_mutations.py'),'--child','--bridge',str(D/'bridge'),'--model','/tmp/geometry-task20/mutations-r1/baseline/model','--case','CR01','--result',str(D/'test.json')]
p=subprocess.run(command,cwd=R,capture_output=True);(D/'test.stdout').write_bytes(p.stdout);(D/'test.stderr').write_bytes(p.stderr)
report={'source_head':ref,'compile_exit':0,'test_exit':p.returncode,'binary_sha256':hashlib.sha256((D/'bridge').read_bytes()).hexdigest(),'test_result':json.loads((D/'test.json').read_text())}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
assert p.returncode==1 and report['test_result']['failures']==1 and report['test_result']['errors']==0
