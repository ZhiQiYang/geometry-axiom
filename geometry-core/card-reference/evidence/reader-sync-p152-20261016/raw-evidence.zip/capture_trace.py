from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
import sys

R=Path('/workspace/geometry-axiom')
spec=importlib.util.spec_from_file_location('reader_sync',R/'geometry-guide/sync_axiom_reader.py')
reader=importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
raw=reader.CANONICAL.read_bytes()
html=raw.decode()
state=json.loads(reader.script_text(html,'axiom-review-data'))
clauses=state['clauses']
incoming={c['id']:[] for c in clauses}
for c in clauses:
    for ref in sorted({m[1] for m in reader.CLAUSE_REF.finditer(c['body']) if m[1]!=c['id']}):
        if ref in incoming: incoming[ref].append(c['id'])
trace=reader.clause_trace(clauses,incoming)
lights=dict(re.findall(r'data-clause="([DIR]\d+[a-z]?)" data-trace="(ok|partial|none)"',html))
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
record={
    'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    'html_sha256':sha(raw),'rendered_lights':lights,
    'rendered_counts':{key:list(lights.values()).count(key) for key in ('ok','partial','none')},
    'computed_trace':trace,
    'state_digests':{key:digest(value) for key,value in state.items()},
    'protected_sha256':{p:sha((R/p).read_bytes()) for p in (
        '公理層.md','geometry-guide/公理層-白話.md','決策佇列.md',
        'geometry-guide/sync_axiom_reader.py','geometry-guide/axiom_matrix.py',
        'tests/test_axiom_reader.py','current_geometry.c','geometry-core/parameters.inc',
        'geometry-core/parameter_types.h')},
}
target=Path(sys.argv[1])
target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'html_sha256':record['html_sha256'],'counts':record['rendered_counts'],
                  'I74_rendered':lights.get('I74'),'I74_computed':trace['I74']},ensure_ascii=False))
