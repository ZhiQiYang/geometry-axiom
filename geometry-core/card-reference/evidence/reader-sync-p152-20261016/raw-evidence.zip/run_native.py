import hashlib
import json
from pathlib import Path
import platform
import resource
import shutil
import subprocess
import sys
import time

R=Path('/workspace/geometry-axiom');D=Path('/tmp/task20-p152/native');D.mkdir()
command=[sys.executable,'-u','tests/run_all.py','--build']
report={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        'before_status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),
        'command':command,'os':platform.platform(),'python':platform.python_version(),
        'stack_limit_bytes':resource.getrlimit(resource.RLIMIT_STACK)[0],
        'gcc':subprocess.check_output(['cc','--version'],text=True).splitlines()[0]}
start=time.monotonic();print('Starting complete native at '+report['source_head'],flush=True)
with (D/'stdout.log').open('wb') as out,(D/'stderr.log').open('wb') as err:
    p=subprocess.run(command,cwd=R,stdout=out,stderr=err)
report.update(exit_code=p.returncode,seconds=time.monotonic()-start)
report['after_status']=subprocess.check_output(['git','status','--short'],cwd=R,text=True)
report['stdout_sha256']=hashlib.sha256((D/'stdout.log').read_bytes()).hexdigest()
report['stderr_sha256']=hashlib.sha256((D/'stderr.log').read_bytes()).hexdigest()
(D/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
shutil.copytree('/tmp/geometry-tests/run_all-logs',D/'logs')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
print((D/'stdout.log').read_text(errors='replace')[-18000:],flush=True)
raise SystemExit(p.returncode)
