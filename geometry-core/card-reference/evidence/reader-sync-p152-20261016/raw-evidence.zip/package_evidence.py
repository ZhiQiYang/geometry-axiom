from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R=Path('/workspace/geometry-axiom')
D=Path('/tmp/task20-p152')
E=R/'geometry-core/card-reference/evidence/reader-sync-p152-20261016'
def read(p):return json.loads((D/p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
native=read('native/receipt.json')
before=read('before.json')
after=read('after.json')
diff=read('trace-diff.json')
source='82e439e32ba31c1eddd04cae58c967c4054d3295'
assert native['source_head']==source and native['exit_code']==0
assert native['before_status']==native['after_status']==''
table=(D/'native/stdout.log').read_text()
total_line=next(l for l in table.splitlines() if l.startswith('合計(已執行、有計數者)'))
counts=list(map(int,total_line.split()[1:5]))
assert counts==[3031,3030,0,1],total_line
assert before['state_digests']==after['state_digests']
assert before['protected_sha256']==after['protected_sha256']
assert before['rendered_lights']['I74']=='none' and after['rendered_lights']['I74']=='partial'
assert set(diff['changes'])=={'I74'}
assert read('reader41-receipt.json')['tests']==41
# This round changes only the canonical generated file before validation.
names=subprocess.check_output(['git','diff','--name-only','-z','2975ed5f',source],cwd=R).decode().rstrip('\0').split('\0')
assert names==['geometry-guide/公理層-閱讀器.html'],names
assert subprocess.check_output(['git','diff','--name-only',source],cwd=R,text=True)==''
members={}
for p in D.rglob('*'):
    if p.is_file() and (p.suffix in {'.json','.log','.stdout','.stderr','.py','.diff'}):
        members[str(p.relative_to(D))]=p.read_bytes()
manifest={p:{'bytes':len(b),'sha256':sha(b)} for p,b in sorted(members.items())}
E.mkdir(parents=True,exist_ok=True)
zpath=E/'raw-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,b in sorted(members.items()):z.writestr(p,b)
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(E/'raw-evidence.sha256').write_text(sha(zpath.read_bytes())+'  raw-evidence.zip\n')
summary={'tested_head':source,'baseline_head':'2975ed5f54f376e81dce570f881d50436759db2d',
         'authority':'PR #253 P-152 issuecomment-6202090461 and user delegation',
         'trace_diff':diff,'direct_reader41':read('reader41-receipt.json'),
         'i74_sites':read('i74-sites.json'),'native':native,
         'native_counts':{'suites':99,'total':3031,'passed':3030,'failed':0,'skipped':1},
         'changed_files_before_test':names,'protected_sources_unchanged':True,
         'reader_state_unchanged':True,'raw_files':len(manifest),
         'archive_sha256':sha(zpath.read_bytes()),
         'remaining':['B2/S1 pending #193','formal WSL native and six browser jobs',
                      'CR18 identity-ledger/M12','CR24 UI/M23','final integration after B2/S1']}
(E/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(E/'README.md').write_text(f'''# P-152 正典標準同步與驗證

完整 native 受測 head：`{source}`。依 P-152 與 AGENTS.md，只執行既有 `sync_axiom_reader.py` 原位同步唯一正典；沒有 HTML 副本、手改 HTML、條文變更或測試放寬。雲端 native，非正式 WSL 收據。

實際追溯差異是 **I74 none → partial**；ok 維持 62，partial 32→33，none 113→112。原閱讀器測試由追溯器動態推導期望，沒有寫死 I74=partial，故完全未改測試。追溯器只以既有主檔條號／scene／官方 mutant 的弱代理推導；本輪沒有擴大掃描範圍或把 Python 具名測試冒充 scene 連結。

`trace-diff.json`、`i74-sites.json`、before/after.json 與 generated-trace.diff 提供全部變動、兩個原始碼條號位置與前後差異。正典只改四行。全部 reader state 欄位摘要相同（含條文、blocks、批註、提案、draft、document identity/hash），公理／白話／決策佇列／核心／同步器／閱讀器測試的 byte hash 均未變。

同步：exit 0、84 patches；check：exit 0、patches 0、207 條、五道 assert 與獨立 SSOT pass。直接閱讀器 41/41，118.666 秒；沒有 errors／skips。直接測試啟動於原 head 加同步後 HTML，隨即以相同 bytes 提交為本次完整受測 head；完整 native 在該已提交 head 重驗全部 41 題。

完整 `ulimit -s 16384; python -u tests/run_all.py --build`：99 suites、3031 計數／3030 pass／0 fail／1 既有 GDI skip、exit 0；原始 exit、時間與每個 suite 日誌見 summary.json／ZIP native/。沿用既有 expected，沒有 update-expected、降低數量、新增 skip。官方 mutation --check 另有原始輸出，原 B1 變異證據仍綁原始 9ba75476，這輪未重跑那些變異。

ZIP 收 {len(manifest)} 份原件與逐檔 SHA-256；未收完整 HTML 副本或執行檔。上一輪六個閱讀器 failure 保留於 b1-adoption-20261016，沒有覆寫。本輪不接入 B2/S1；正式 WSL 七項、身分帳與 UI 邊界仍待後續。
''')
print(json.dumps({'tested_head':source,'raw_files':len(manifest),'zip_bytes':zpath.stat().st_size},indent=2))
