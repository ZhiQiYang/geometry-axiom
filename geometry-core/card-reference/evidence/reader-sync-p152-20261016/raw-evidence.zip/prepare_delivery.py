from pathlib import Path
import json
import subprocess

R=Path('/workspace/geometry-axiom')
D=Path('/tmp/task20-p152')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
source='82e439e32ba31c1eddd04cae58c967c4054d3295'
native=json.loads((D/'native/receipt.json').read_text())
assert native['exit_code']==0 and native['source_head']==source
evidence=f'https://github.com/ZhiQiYang/geometry-axiom/tree/{head}/geometry-core/card-reference/evidence/reader-sync-p152-20261016'
comment=f'''【Codex】P-152 閱讀器同步與驗證收尾交付。

**交付 head**：`{head}`。
**完整 native 受測 head**：`{source}`。同步提交之後僅新增本輪證據，產品、測試、expected 與正典 bytes 均與受測來源一致；不冒稱證據提交另跑完整 native。

已重讀 AGENTS.md、看板 `71dbeae374f41a555486f2c0543f388003cd76d1` 與 P-152；開工確認本地／遠端同為 2975ed5f、工作區乾淨、無其他 owner ACK，接手留言 6202258829。依本輪使用者明示與 P-152，只走既有同步器的標準程序，沒有手改 HTML、另做閱讀器副本、改公理／白話或修改閱讀器測試。

實際同步差異：
- I74 的原生成燈號為 **none**，依本分支原始碼重新推導後為 **partial**；不是預設 partial→ok。全表 ok 維持 62、partial 32→33、none 113→112；207 條中只有 I74 燈號改變，正典 diff 為 **4 行新增／4 行移除**。
- 既有追溯器在主檔找到 I74 兩處（`current_geometry.c:1380` 的 card_length 宣告註解、`:12763` 的卡片能力拒絕），未列 `.scene` 或官方 mutant 連結，故依既有門檻是 partial。這個追溯器是弱代理；原生／bridge 的 Python 具名測試與獨立整卡突變仍另有實跑收據，不把它們改寫成 scene 追溯。
- 原 `test_traceability_lights_and_hub_badges_exist` 是動態推導期望，沒有寫死 I74=partial，故 **測試與斷言完全不變**。同步前後 reader state 全部欄位摘要相同，包含條文、blocks、批註、提案、草稿、文件身分及 documentHash；公理／白話／決策佇列／核心／同步器／追溯器／閱讀器測試均逐 byte 未變。

實跑驗證（**雲端 native,非正式 WSL 收據**）：
1. `python geometry-guide/sync_axiom_reader.py`：exit 0，84 patches，五道 assert／independent SSOT pass；唯一正典原位同步。
2. `python geometry-guide/sync_axiom_reader.py --check`：exit 0、patches 0、207 條、five_asserts／independent_ssot pass。
3. `python tests/test_axiom_reader.py`：**41/41，0 failure／error／skip，118.666 秒**，原六筆失敗均自然回綠；沒有改測試。直接測試啟動於原 head 加生成後 HTML，該 HTML 原 bytes 隨即提交為 82e439e3；後述完整 native 又在已提交來源重驗全部 41 題。
4. `ulimit -s 16384; python -u tests/run_all.py --build`：**99 suites，3031 計數／3030 pass／0 fail／1 既有 GDI 平台 skip，exit 0，{native['seconds']:.2f} 秒**。受測來源與工作區前後狀態見 receipt。expected 嚴格相符；本輪沒有使用 update-expected、改數量、放寬斷言或新增 skip。
5. 官方 `python tests/mutate.py --check`：exit 0，50 筆 fresh（42 killed／1 crashed／4 equivalent／3 retired，無 stale／survived／blocked）。本輪沒有重跑核心或 B1 變異；原 48 筆原生整卡 + 1 helper、四筆版本防線及六筆保存變異證據維持原受測 head 9ba75476，不冒稱新來源重跑。

[同步前後 trace／原始 diff、各欄位與保護檔案 SHA-256、41 題與完整 native 原始輸出及 receipts]({evidence})。上一輪六筆 failure 的 b1-adoption-20261016 證據原封保留。

仍未完成：**B2／S1 等 #193**，本輪沒有接入面材試排三欄守門、逐欄改綁／重建取 99 的整合回歸；其後最終整合來源還須重新驗證。正式 WSL native＋六 browser、CR18 身分帳／M12、CR24 UI／M23 與其他獨立 owner 的 browser 邊界仍未驗。本輪只解除 P-152 的閱讀器同步問題，不宣稱整張 PR 可合併。

原分支已推送，既有 PR 維持 open／draft；未合併 PR、Ready、關閉、刪分支或改設定。本輪至此停止。

【Codex】請 Claude 核對
'''
(D/'delivery-comment.md').write_text(comment)
body=f'''【Codex】網格以一份 CardReference 保存卡片身分與 u/v 欄位映射，整組建立、換卡、對調、解除及復原走同候選全量驗證。整卡 direct 解除讀有序步驟當下來源；已重建取新值，仍缺來源則拒絕。

相依 #193，base 維持 `fix/geo-258-parameter-remove-refs-20261011`。能力 `grid-card-reference/1` + `parameters/1`；完整專案 /18、快照根能力、I38／I8a／bridge／來源索引均保留。依 P-133 保存完整 canonical base_scene，不擴張幾何根走訪。

P-146 的錯誤欄位斷言、id 診斷、SAME_CARD／COMPLETE_MAPPING 分離、一般邏輯突變與有序當步取值回歸已交付。P-142 B1 已合入採納後 main a898ad6e，版本指向採納提交 b3c79615；所有採納前版本在 manifest 或 base_scene 宣告／使用整卡時，以 AXIOM_VERSION 拒絕，含移除宣告後的整卡語法。舊版無整卡包維持相容。

P-152 已用唯一同步器原位重同步正典：I74 none→partial、無追溯數 113→112；只改生成追溯四行，條文／批註／測試未變，check 0、原 41/41。先前六筆閱讀器失敗已解除，原始紅燈紀錄保留。

交付 head `{head}`；最新完整 native 受測 head `{source}`。**雲端 native,非正式 WSL 收據：99 suites、3030 pass／0 fail／1 既有 GDI skip、exit 0**；閱讀器 41/41、相容性 36/36、整卡 34/34、Node 718/718，expected 不變。[本輪同步差異及完整收據]({evidence})。

B1 原受測來源 9ba75476 的四筆版本防線、48 筆原生整卡 + 1 helper 負對照及六筆保存端突變，皆真轉紅／還原綠；該批原件保存在 b1-adoption-20261016，本輪未重跑變異。官方 50 筆帳本本輪 check 0，42 killed／1 crashed／4 equivalent／3 retired，無 stale。追溯燈號是既有弱代理，不能當完整功能驗收。

記憶體成本（P-146 來源／Linux x86-64 ABI）：capture 40 bytes × 256 + count 8 = 每 World 10,248 bytes；Undo／Redo 各 32 槽共增加 655,872 bytes，其他快照另計。上限依據與版本防線見 [NATIVE-CONTRACT](geometry-core/card-reference/NATIVE-CONTRACT.md)。

**維持 draft：B2／S1 仍等 #193 P-141／P-142 合併**，尚未接入面材試排 gap／stagger／threshold 共用引用檢查、網格系統「無法改綁」訊息／註解、逐欄改綁對照及重建取 99 的整合回歸。正式 WSL 七項、B2／S1 後最終整合驗證、CR18 啟用身分帳／M12、CR24／M23 UI／草稿與其他 owner／browser 邊界仍未驗。

請 Claude 核對。
'''
(D/'pr-body.md').write_text(body)
print(json.dumps({'delivery_head':head,'tested_head':source,'seconds':native['seconds']},indent=2))
