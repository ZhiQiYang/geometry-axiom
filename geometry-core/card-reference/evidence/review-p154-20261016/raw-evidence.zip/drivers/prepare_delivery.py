from pathlib import Path
import json
import subprocess

R=Path('/workspace/geometry-axiom');D=Path('/tmp/task20-p154')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
source='300cb953d84b37f542cbad2b4940417ab4cf7629'
n=json.loads((D/'native/receipt.json').read_text());assert n['exit_code']==0 and n['source_head']==source
evidence=f'https://github.com/ZhiQiYang/geometry-axiom/tree/{head}/geometry-core/card-reference/evidence/review-p154-20261016'
audit=f'https://github.com/ZhiQiYang/geometry-axiom/blob/{head}/geometry-core/card-reference/MODEL-ADMISSION-AUDIT.md'
comment=f'''【Codex】P-154 交付，維持既有 draft PR。

**交付 head**：`{head}`。
**完整受測 head**：`{source}`（產品／測試／同步正典）。後續只有協定說明、expected、官方帳本及證據，產品／測試／正典 bytes 與受測來源相同；不冒稱證據提交另跑完整 native。開工確認本地與遠端 4390b1fd、乾淨工作區、無其他 owner ACK，接手留言 6202680650；看板為 71dbeae3。

須改項目：
- **M1**：把 struct 欄位的 I74 註解移入 `grid_card_mark`。標準同步後 I74 不再錯連 `guide_line_get_local_segments`，只保留真正含條號的 `parse_scene_file`；燈號仍 partial，統計維持 62／33／112。全部 reader state 摘要相同，條文、批註、提案、草稿及文件身分不變。只用原同步器，沒有手改 HTML、另做閱讀器、修改追溯器或閱讀器斷言。
- **M2**：網格定義的缺 name、未知鍵、mainAlong 型別／值錯誤，回獨立 `D29 GRID_DEFINITION`，並保留有效的網格 id；真正映射缺欄仍回 `I74 COMPLETE_MAPPING`。原軸模式轉換原因碼維持不變。具名 `test_P154_GRID_DEFINITION_DIAGNOSTIC` 覆蓋四種格式錯誤與映射對照。

記錄項目：
- reject helper 現在逐則取錯誤 message，要求**同一則**同時含原因與全部完整 id token；使用詞邊界，field 3 不會比中 field 30。具名負對照涵蓋數字前綴、跨則身分、原因在另一則；CR11 的 set 路徑補 COMPLETE_MAPPING 原因碼斷言。
- 舊版案例由驗證器共用 `_accepted_axiom_versions(current)` 減去現行版本推導，移除另一份手寫家族清單；允收版本內容與 B1 的三路防線未改。
- **網頁模型載入已查證**：`validateModelPackage`／pack／unpack 本身只做結構與容器檢查。正式開檔 `importProjectData`、本機恢復、試改續接點、候選方案及子快照都進 `readProjectContext:1807`；`:1821` 在 `c.models` 賦值、場景上傳與 context 替換前，對每個 model 呼叫 `verifyStoredModel:1745`，逐包送 `/model/verify`，由 `serve.py:694–695` 呼叫 `verify_package`。詳細入口與內部新建／修改 API 的差別見 [載入邊界核對]({audit})。
- 真客戶端 VM＋私有真服務探針：結構／容器合法的舊版號整卡模型，只呼叫一次 `/model/verify` 就收到原生 `UNSUPPORTED/AXIOM_VERSION`，context、完整狀態、history、模型數與原生 dump 全部不變。只在 VM 撤除一般驗證呼叫後，探針轉紅於具名 `P154_MODEL_ADMISSION` 斷言，並觀察到 upload/prepare、upload/confirm 與模型進入隔離測試 context；還原後回綠。沒有在 repo 產品檔撤掉驗證，也沒有在 JS 複製版本政策。這是實際 HTTP／客戶端邊界驗證，未冒稱真瀏覽器操作。

實跑（**雲端 native,非正式 WSL 收據**）：
- 最終新案例對舊產品／舊 helper：**2 方法、7 個失敗子案例、0 errors／skips**；修正後整卡 36＋相容性 36，共 **72/72**。
- 本受測來源 **53 筆整卡反證 = 50 原生產品碼＋3 helper 負對照**，全數具名轉紅／逐 byte 還原重編回綠，包含 M2 原因碼、網格 id、詞邊界及單則診斷退化。
- 四筆版本防線變異、六筆保存端變異全紅／還原綠。另將錯誤 struct 註解放回的負對照，讓既有閱讀器冪等斷言轉紅／還原綠；這筆只證明註解追溯，未計作原生語意 mutant。
- 官方 50 筆帳本本輪重產，`--check` exit 0：42 killed／1 crashed（M20 同夾具三次 SIGSEGV）／4 equivalent／3 retired，0 survived／stale／blocked／invalid。未借用 4390b1fd 或更早來源的收據。
- 官方同步 exit 0（84 patches）、`--check` exit 0（patches 0、207 條、five_asserts／independent SSOT pass）；原 reader **41/41**，閱讀器測試未改。
- `ulimit -s 16384; python -u tests/run_all.py --build --update-expected`：**99 suites，3033 計數／3032 pass／0 fail／1 既有 GDI skip，exit 0，{n['seconds']:.2f} 秒**，完整前後狀態與逐 suite 日誌保留。唯一新增 expected 為整卡 **34→36**；其餘數量不變，沒有新增 skip、放寬斷言或降低門檻。

[原始證據 ZIP、逐檔 SHA-256、每筆 patch／red／restored、trace 差異及完整 native receipt]({evidence})。早期未採認的軸診斷擴張、部分基準與未重算容器能力的探針初稿原件亦保留，未計入有效反證。

未驗／仍阻擋：**B2／S1 等 #193**，本輪沒有合入其新候選，`parameters.inc`／`parameter_types.h` 與本輪開始相同。面材試排三欄共用守門、逐欄改綁與重建取 99 的整合回歸、其後最終來源驗證、正式 WSL native＋六 browser、CR18 身分帳／M12、CR24 UI／M23 仍未完成。只推原分支，未合併 PR、Ready、關閉、刪分支或改設定。

【Codex】請 Claude 核對
'''
(D/'delivery-comment.md').write_text(comment)
body=f'''【Codex】網格以一份 CardReference 保存卡片身分與 u/v 欄位映射，整組建立、換卡、對調、解除及復原走同候選全量驗證。整卡 direct 解除讀有序步驟當下來源；已重建取新值，仍缺來源則拒絕。

相依 #193，base 維持 `fix/geo-258-parameter-remove-refs-20261011`。能力 `grid-card-reference/1` + `parameters/1`；完整專案 /18、快照根能力、I38／I8a／bridge／來源索引均保留。依 P-133 保存完整 canonical base_scene，不擴張幾何根走訪。

P-146 與 B1 已完成；版本指向含 D64/I74/R60 的採納提交 b3c79615，採納前版本在 manifest／source／移除宣告後的整卡語法三路皆以 AXIOM_VERSION 拒絕。P-154 修正網格格式診斷為 D29 GRID_DEFINITION 並指名網格，卡片映射保留 I74 COMPLETE_MAPPING；診斷測試逐則比對完整 id，舊版案例取自共用允收集合。struct 的 I74 註解已移入正確函式，唯一正典經標準同步移除錯誤 guide_line_get_local_segments 連結，條文與閱讀器測試不變。

網頁外部資料的開檔／恢復／續接／方案與子快照，均由 readProjectContext → verifyStoredModel → /model/verify → verify_package 在替換模型與場景前核對。結構檢查與 ZIP 解包本身不冒稱語意驗證。真客戶端 VM＋私有服務探針實證舊版整卡包在原生 AXIOM_VERSION 拒絕、零狀態變更；VM 撤除一般驗證呼叫即具名轉紅。[載入路徑與探針]({audit})。

交付 head `{head}`；完整受測 head `{source}`。**雲端 native,非正式 WSL 收據：99 suites、3032 pass／0 fail／1 既有 GDI skip、exit 0**；整卡 36/36、相容性 36/36、reader 41/41、Node 718/718。expected 只新增整卡 34→36。53 筆整卡反證（50 原生產品碼＋3 helper）、四筆版本防線與六筆保存端變異均本來源真轉紅／還原綠；另有 reader 註解追溯負對照。官方 50 筆帳本 42 killed／1 crashed／4 equivalent／3 retired、check 0、無 stale。[本輪全部證據與精確來源]({evidence})。

記憶體成本（P-146 來源／Linux x86-64 ABI）：每 World 增加 10,248 bytes；Undo／Redo 各 32 槽共增加 655,872 bytes，其他快照另計。依據與介面見 [NATIVE-CONTRACT](geometry-core/card-reference/NATIVE-CONTRACT.md)。

**維持 draft：B2／S1 仍等 #193 P-141／P-142 合併**，尚未接入面材試排 gap／stagger／threshold 共用引用檢查、網格系統「無法改綁」訊息／註解、逐欄改綁對照及重建取 99 的整合回歸。正式 WSL 七項、B2／S1 後最終整合驗證、CR18 身分帳／M12、CR24／M23 UI／草稿與其他 owner／browser 邊界仍未驗。

請 Claude 核對。
'''
(D/'pr-body.md').write_text(body)
print(json.dumps({'delivery_head':head,'tested_head':source,'native_seconds':n['seconds']},indent=2))
