from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R=Path('/workspace/geometry-axiom');D=Path('/tmp/task20-p154')
E=R/'geometry-core/card-reference/evidence/review-p154-20261016'
SOURCE='300cb953d84b37f542cbad2b4940417ab4cf7629'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads((D/p).read_text())
n=read('native/receipt.json');o=read('official/report.json')
c=read('card-mutations/report.json');a=read('axiom-mutations/report.json');t=read('trace-mutation/report.json')
assert n['source_head']==o['source_head']==c['source_head']==a['source_head']==t['source_head']==SOURCE
assert n['exit_code']==o['check']['exit_code']==0
assert len(c['mutants'])==53 and all(m['verdict']=='killed' and m['restored']['run']['exit_code']==0 for m in c['mutants'])
assert len(a['mutants'])==4 and all(m['verdict']=='killed' for m in a['mutants'])
assert t['verdict']=='killed'
archives=read('archive-mutations/report.json')['mutants']
assert len(archives)==6 and all(m['verdict']=='killed' for m in archives)
for p in ('model-admission-valid','model-admission-restored'):
    r=read(p+'/receipt.json');assert r['exit_code']==0 and r['calls']==['/model/verify']
    assert all(r[k] for k in ('context_unchanged','state_unchanged','history_unchanged','dump_unchanged'))
r=read('model-admission-omitted/receipt.json');assert r['exit_code']==1 and not r['rejected'] and r['calls']==['/upload/prepare','/upload/confirm']
assert 'P154_MODEL_ADMISSION' in r['failure']
old=json.loads(subprocess.check_output(['git','show',SOURCE+':tests/run_all.expected.json'],cwd=R))
new=json.loads((R/'tests/run_all.expected.json').read_text())
counts={k:{'before':old['suites'].get(k),'after':v} for k,v in new['suites'].items() if old['suites'].get(k)!=v}
assert set(counts)=={'py:test_grid_card_reference'} and counts['py:test_grid_card_reference']['before']['count']==34 and counts['py:test_grid_card_reference']['after']['count']==36,counts
changes=subprocess.check_output(['git','diff','--name-only',SOURCE],cwd=R,text=True).splitlines()
assert set(changes)<={'geometry-core/card-reference/NATIVE-CONTRACT.md','tests/run_all.expected.json','tests/mutants_results.json'},changes
table=(D/'native/stdout.log').read_text();line=next(l for l in table.splitlines() if l.startswith('合計(已執行、有計數者)'))
assert list(map(int,line.split()[1:5]))==[3033,3032,0,1],line
E.mkdir(parents=True,exist_ok=True);members={}
folders=('card-mutations','axiom-mutations','official','trace-mutation','archive-mutations',
         'model-admission','model-admission-valid','model-admission-omitted','model-admission-restored','native')
for folder in folders:
    for p in (D/folder).rglob('*'):
        if p.is_file() and 'cache' not in p.relative_to(D).parts:
            b=p.read_bytes()
            if not b.startswith(b'\x7fELF') and p.suffix!='.gcanvas':members[str(p.relative_to(D))]=b
for p in D.iterdir():
    if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.py','.diff'}:members['drivers/'+p.name]=p.read_bytes()
manifest={p:{'bytes':len(b),'sha256':sha(b)} for p,b in sorted(members.items())}
zpath=E/'raw-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,b in sorted(members.items()):z.writestr(p,b)
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(E/'raw-evidence.sha256').write_text(sha(zpath.read_bytes())+'  raw-evidence.zip\n')
summary={'tested_head':SOURCE,'native':n,'native_counts':{'suites':99,'total':3033,'passed':3032,'failed':0,'skipped':1},
         'official':o,'card_mutants':{'total':53,'native_product':50,'test_helper_negative_controls':3},
         'axiom_mutants':4,'trace_annotation_negative_controls':1,'archive_mutants':6,
         'model_admission':{p:read(p+'/receipt.json') for p in ('model-admission-valid','model-admission-omitted','model-admission-restored')},
         'trace_diff':read('trace-diff.json'),'scope_audit':read('scope-audit.json'),'expected_changes':counts,
         'raw_files':len(manifest),'archive_sha256':sha(zpath.read_bytes()),
         'excluded_attempts':['before: early test draft also classified incomplete axis; existing MODE_TRANSITION behavior restored before final source',
             'after: early axis diagnostic expansion caused CR14 failure; retained raw and reverted expansion',
             'before-final: partial baseline with new helper; final before-valid uses old product and old helper with final new test cases',
             'model-admission: raw ZIP mutation lacked normalized root capabilities and failed before requests; final probe repacks with the normal writer'],
         'remaining':['B2/S1 pending #193','formal WSL native and six browser jobs','CR18 identity-ledger/M12','CR24 UI/M23','final integration after B2/S1']}
(E/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(E/'README.md').write_text(f'''# P-154：診斷、追溯與網頁模型載入核對

完整受測 head：`{SOURCE}`；雲端 native,非正式 WSL 收據。後續交付提交只補文件、expected、官方帳本及本證據，產品與測試保持受測 bytes。

M1 把 struct 的 I74 註解移入 grid_card_mark，標準同步後不再錯連 guide_line_get_local_segments；I74 仍 partial，統計與全部 reader state 不變。M2 格式錯誤使用 D29 GRID_DEFINITION 並指名網格；真正卡片映射仍是 I74 COMPLETE_MAPPING，原軸模式診斷保持。helper 對同一則診斷與完整 id token 比對；舊版本案例從驗證器共用允收集合減現行版本推導。

測試先行：最終新案例對舊產品／舊 helper 為 2 方法、7 個失敗子案例、0 errors／skips；修正後整卡 36 與相容性 36 共 72 方法全綠。完整 native 99 suites、3033 計數／3032 pass／0 fail／1 既有 GDI skip；reader 41/41。唯一新增 expected 是整卡 34→36，未降低門檻或新增 skip。

本來源 53 筆反證為 50 原生產品碼 + 3 helper 負對照，均具名轉紅／逐 byte 還原重編回綠；另四筆版本防線、六筆保存端變異及一筆註解追溯負對照。註解對照撤回 M1 後讓原 reader 冪等斷言轉紅，不冒稱原生語意 mutant。

MODEL-ADMISSION-AUDIT.md 列出正式開啟／本機恢復／續接／方案及子快照共用的 readProjectContext → verifyStoredModel → /model/verify → verify_package 路徑。真私有服務與真客戶端 VM 探針，對結構合法但舊版號帶整卡能力的模型包，只送一次 /model/verify 就得到 AXIOM_VERSION，context/history/models/dump 不變；VM 內撤除一般驗證呼叫後，具名斷言轉紅並觀察到 upload/prepare、upload/confirm；還原探針回綠。沒有在產品檔撤掉驗證，也沒有新增網頁版本表。

ZIP 收 {len(manifest)} 份原件及逐檔 SHA-256，沒有編譯執行檔或 HTML 副本。早期未採認嘗試亦保留並在 summary.json 標明，不以它們充當有效反證。完整 stdout/stderr、每筆 patch、編譯／測試 receipts 及官方 check 見 ZIP；B2/S1、正式 WSL 七項與身分帳／UI 邊界仍未驗。
''')
print(json.dumps({'tested_head':SOURCE,'raw_files':len(manifest),'zip_bytes':zpath.stat().st_size,'expected_changes':counts},ensure_ascii=False,indent=2))
