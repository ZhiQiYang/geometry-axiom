from pathlib import Path
import hashlib
import json
import subprocess
import sys

R=Path('/workspace/geometry-axiom');D=Path('/tmp/task20-p154/trace-mutation');D.mkdir()
P=R/'current_geometry.c';original=P.read_bytes()
old=b'bool card_length;'
new=b'bool card_length; /* I74: length comes exclusively from GridSystem.card_reference. */'
assert original.count(old)==1 and new not in original
command=[sys.executable,'-m','unittest','tests.test_axiom_reader.CanonicalReader.test_rebuild_is_byte_idempotent_and_keeps_reviews']
def run(name):
    p=subprocess.run(command,cwd=R,capture_output=True,timeout=60)
    (D/(name+'.stdout')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr)
    return {'command':command,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},p.stderr.decode()
b,_=run('baseline');assert b['exit_code']==0
try:
    P.write_bytes(original.replace(old,new,1))
    red,trace=run('red')
finally:
    P.write_bytes(original)
green,_=run('restored')
assert red['exit_code']==1 and 'FAIL: test_rebuild_is_byte_idempotent_and_keeps_reviews' in trace and 'FAILED (failures=1)' in trace
assert 'ERROR:' not in trace and green['exit_code']==0 and P.read_bytes()==original
report={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        'source_sha256':hashlib.sha256(original).hexdigest(),'baseline':b,'red':red,'restored':green,
        'kind':'annotation trace negative control; not a native semantic mutant','verdict':'killed'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
