"""Index actual unchanged receipts plus the corrected targeted Undo proof."""
import hashlib
import json
from pathlib import Path
import re
import sys

R=Path('/workspace/geometry-axiom');T=Path('/tmp/task20-p146')
sys.path.insert(0,str(R/'geometry-core/card-reference'))
from mutations import MUTATIONS

first=json.loads((T/'mutations/report.json').read_text())
retake=json.loads((T/'mutations-retake/report.json').read_text())
current={m['id']:m for m in MUTATIONS}
assert len(current)==49 and len(first['mutants'])==49 and len(retake['mutants'])==1
assert retake['mutants'][0]['id']=='M11-undo'
assert first['test_sha256']==retake['test_sha256']==hashlib.sha256((R/'tests/test_grid_card_reference.py').read_bytes()).hexdigest()
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==value for p,value in first['source_sha256'].items())
assert hashlib.sha256((R/'geometry-core/card-reference/run_mutations.py').read_bytes()).hexdigest()==retake['runner_sha256']
assert hashlib.sha256((R/'geometry-core/card-reference/mutations.py').read_bytes()).hexdigest()==retake['table_sha256']
records=[];excluded=[]
for folder,report in [('mutations',first),('mutations-retake',retake)]:
    for item in report['mutants']:
        identifier=item['id']
        stderr=(T/folder/identifier/'test.stderr').read_text()
        setup_codes=[int(c) for c in re.findall(r'0 != (-?\d+) : CANDIDATE_LIFECYCLE injection:',stderr) if int(c)!=1]
        if folder=='mutations' and identifier=='M11-undo':
            assert setup_codes==[3]
            assert item['patches']!=current[identifier]['patches']
            excluded.append({'id':identifier,'report':folder+'/report.json','original_verdict':item['verdict'],
                             'accepted_for_delivery':False,'reason':'probe setup exit 3; shared restore mutation affected confirm before Undo'})
            continue
        assert not setup_codes
        assert item['patches']==current[identifier]['patches'] and item['case']==current[identifier]['case']
        counts=item['red']['counts']
        assert item['verdict']=='killed' and item['red']['run']['exit_code']==1 and counts['failures']>0
        assert counts['errors']==counts['skips']==counts['compile_failures']==0
        assert item['restored']['run']['exit_code']==0
        records.append({'id':identifier,'report':folder+'/report.json','source_head':report['source_head'],
                        'case':item['case'],'verdict':item['verdict'],'patches_match_current':True,
                        'infrastructure_failures':0,'restored_exit':item['restored']['run']['exit_code']})
assert {m['id'] for m in records}==set(current) and len(records)==49
result={'accepted_count':49,'native_product_mutations':48,'test_helper_negative_controls':1,
        'attempts':50,'records':records,'excluded':excluded,
        'product_and_test_sources_identical':True,'native_receipt_epoch':retake['source_head'],
        'first_epoch':first['source_head'],'retake_epoch':retake['source_head'],
        'note':'48 unchanged patch definitions retain actual red/restore receipts; only corrected M11-undo rerun. All raw traces rechecked under the stricter infrastructure gate.'}
(T/'mutation-delivery-index.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('records',)},ensure_ascii=False,indent=2))
