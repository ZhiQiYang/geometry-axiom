#define main geometry_core_entry
#include "/workspace/geometry-axiom/current_geometry.c"
#undef main
typedef struct {
    ParameterSet cards[PARAM_CARD_MAX]; size_t card_count;
    ParameterField fields[PARAM_FIELD_MAX]; size_t field_count;
    /* I38/I39: card identities deleted earlier in the operation sequence that is editing this World. Candidate-owned scratch:
     * copied with the candidate, cleared when the sequence ends (batch_preview / engineering archive), never serialized. */
    uint32_t retired[PARAM_RETIRED_MAX]; size_t retired_count;
    /* P-062/P-065: last-valid values before a card or its upstream disappears.
     * Live fields may be captured, but only explicitly unbound deleted sources can consume them.
     * Both arrays and counts are cleared before comparison, staging, or history. */
    DeletedParameterValue deleted_values[PARAM_DELETED_VALUE_MAX]; size_t deleted_value_count;
    ParameterFieldRetirement field_retirements[PARAM_FIELD_RETIREMENT_MAX]; size_t field_retirement_count;
    ParameterDeclaration declarations[PARAM_DECLARATION_MAX]; size_t declaration_count;
    unsigned candidate_order; bool tracking;
    bool loading; /* only native full-scene loading may stage a parameter block */
} ParameterStateWithoutCaptures;
int main(void) {
    size_t slots=sizeof(((ParameterState *)0)->card_captures)/sizeof(GridCardCapture);
    size_t delta=sizeof(ParameterState)-sizeof(ParameterStateWithoutCaptures);
    printf("{\"world_bytes\":%zu,\"parameter_state_bytes\":%zu,\"capture_bytes\":%zu,"
           "\"capture_slots\":%zu,\"capture_array_bytes\":%zu,\"capture_count_bytes\":%zu,"
           "\"added_per_world_bytes\":%zu,\"history_slots_per_stack\":%u,"
           "\"added_undo_redo_capacity_bytes\":%zu,\"max_operations\":%u}\n",
           sizeof(World),sizeof(ParameterState),sizeof(GridCardCapture),slots,
           sizeof(((ParameterState *)0)->card_captures),sizeof(((ParameterState *)0)->card_capture_count),
           delta,HISTORY_MAX,delta*HISTORY_MAX*2,ENG_OPERATION_MAX);
    return slots==ENG_OPERATION_MAX ? 0 : 1;
}
