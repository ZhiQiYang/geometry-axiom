"""AGENTS.md permits per-ID parallel runs with separate result/cache namespaces.
Merge only each shard's assigned tool-produced records, then strict official check.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

R=Path('/workspace/geometry-axiom');D=Path('/tmp/task20-p146/official');D.mkdir()
sys.path.insert(0,str(R/'tests'))
import mutate
groups=[[m['id'] for m in mutate.MUTANTS][i::4] for i in range(4)]
report={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'groups':[]}
active=[]
for i,ids in enumerate(groups):
    folder=D/f'group-{i}';folder.mkdir()
    env=os.environ.copy();env['MUTATE_RESULTS']=str(folder/'results.json');env['MUTATE_CACHE']=str(folder/'cache')
    command=[sys.executable,'-u','tests/mutate.py',*ids]
    out=(folder/'stdout.log').open('wb');err=(folder/'stderr.log').open('wb')
    start=time.monotonic();p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err)
    active.append((i,ids,folder,command,p,out,err,start))
    print('started',i,ids,flush=True)
merged={}
for i,ids,folder,command,p,out,err,start in active:
    code=p.wait();out.close();err.close()
    report['groups'].append({'index':i,'ids':ids,'command':command,'exit_code':code,'seconds':time.monotonic()-start})
    (D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print('finished',i,'exit',code,flush=True)
    if code:continue
    data=json.loads((folder/'results.json').read_text())
    for identifier in ids:
        assert identifier not in merged and identifier in data,(identifier,'not an independently completed assigned record')
        merged[identifier]=data[identifier]
if any(g['exit_code'] for g in report['groups']):raise SystemExit(1)
assert set(merged)=={m['id'] for m in mutate.MUTANTS}
mutate.save_records(R/'tests/mutants_results.json',merged)
command=[sys.executable,'tests/mutate.py','--check']
p=subprocess.run(command,cwd=R,capture_output=True)
(D/'check.stdout').write_bytes(p.stdout);(D/'check.stderr').write_bytes(p.stderr)
report.update(check={'command':command,'exit_code':p.returncode},records=len(merged),
              ledger_sha256=hashlib.sha256((R/'tests/mutants_results.json').read_bytes()).hexdigest())
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(p.stdout.decode(),flush=True)
raise SystemExit(p.returncode)
