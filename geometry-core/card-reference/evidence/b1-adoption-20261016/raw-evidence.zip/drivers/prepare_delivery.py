from pathlib import Path
import json
import subprocess

R=Path('/workspace/geometry-axiom')
D=Path('/tmp/task20-b1')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
source='9ba754762304648345c7eb3acace3f79a827465a'
native=json.loads((D/'native/receipt.json').read_text())
assert native['exit_code']==1 and native['source_head']==source
evidence=f'https://github.com/ZhiQiYang/geometry-axiom/tree/{head}/geometry-core/card-reference/evidence/b1-adoption-20261016'
output=(D/'native/stdout.log').read_text()
totals=next(line for line in output.splitlines() if line.startswith('合計(已執行、有計數者)'))
rows=totals.split()
count,passed,failed,skipped=map(int,rows[1:5])
assert failed==6 and skipped==1
assert count==3031 and passed==3024,(totals,count,passed)
comment=f'''【Codex】指定任務 20：依 Claude 6201359751 續作 P-142 B1，交付核對。

- **交付 head**：`{head}`。
- **完整受測 head**：`{source}`（產品／測試提交）。一般 merge 提交 `23f6e243cb76bddf5545575e44494ae959691bf9` 已帶入 main `a898ad6e12707104568679591fe1b21804bfc3df`。交付後續差異只有協定文件、expected、官方帳本與證據，已逐檔核對產品／測試與受測來源相同；不冒稱 metadata 提交另跑過完整 native。
- 開工已核對遠端與本地 d42d21fb、其他 ACK 與檔案範圍，並留下接手 ACK 6201508082；收尾重讀仍無其他執行者 ACK。

B1 實作：
1. 版本常數沿用 #256 已採納的 `b3c79615d0cde89bbdca72c1223d214324bc5f8f`／`e5e43ec5da2030669c9ecd7a67f8b250cfb7290cf663365b2b66c51814bb77b9`，與當前條文 LF 雜湊一致；改寫「未加入此能力」的過時註解。
2. `verify_package` 對所有已知採納前版本（含 PRE_CARD_REFERENCE）在重建前檢查 manifest 與 base_scene；有整卡宣告或語法即 `UNSUPPORTED/AXIOM_VERSION`。兩處能力宣告都移除但仍保留 card-reference／card 語法，也拒絕。
3. 五個具名測試覆蓋三條拒絕路徑、現行整卡包原樣重建，以及舊版無整卡的相容性。三條路徑對 19 組舊版本，修正前 **57 個失敗斷言、0 errors／skips**；修正後完整相容性 suite **36/36**。既有未知／混搭版本、凍結舊包斷言保留。
4. 一般 merge 的四處衝突：主檔保留 main 的 dump 拆分並接回整卡能力標記；正典取 main 原件；expected 保留雙方增量（Node 704 + 7 + 7 = 718）；官方帳本在新來源重產。公理層／白話／正典／決策佇列均與 main **逐 byte 相同**，主檔維持 CRLF。

驗證（**雲端 native，非正式 WSL 收據**）：
- `ulimit -s 16384; python -u tests/run_all.py --build --update-expected`：**99 suites，{count} 計數／{passed} pass／{failed} fail／{skipped} 既有 GDI 平台 skip，exit 1，{native['seconds']:.2f} 秒**。在固定受測 head 的隔離 checkout 執行；完整前後狀態與逐 suite 原始日誌均已保存。六個 failure 全在正典閱讀器，詳下方阻擋。B1 相容性 36/36、整卡 34/34、Node 718/718。沒有降低 expected、放寬斷言或新增 skip；完整跑後相容性 expected 31→36。runner 明確允許在測試失敗時保存發現數量，這不代表驗證通過。
- 四筆新的 Python 版本防線一般邏輯突變全部具名轉紅（整道撤除／漏 manifest／漏來源／豁免最後採納前版本家族），逐 byte 還原後每筆完整 **36/36** 回綠。
- 本輪新來源整卡 **49 筆有效反證 = 48 原生產品碼 + 1 helper 負對照**，逐筆真轉紅／還原重編回綠；另六筆 JavaScript 保存突變具名轉紅／還原綠。沒有沿用 d42d21fb 或 95475492 的舊收據。
- 官方 **50 筆**重產及交付工作區 `--check` exit 0：42 killed／1 crashed（M20 同夾具三次 SIGSEGV）／4 equivalent／3 retired，0 survived／stale／blocked／invalid；crashed 未計為 killed。
- 正典 `--check` exit 0，207 條，five_asserts／independent_ssot pass；完整 native 的閱讀器 **35 pass／6 fail／41 total**。`--check` 不重建，不能拿它覆蓋重建／冪等失敗。
- 測試夾具初稿錯誤、隔離 checkout 尚未完成時的 runner 啟動錯誤，以及受限環境缺失 Node 具名事件的 archive 嘗試，原件全留、均未計入有效反證。最後一項以允許通訊的權限原樣重跑通過，沒有修改 runner 或斷言。

[原始證據 ZIP、逐檔 SHA-256、完整 receipt 與來源核對]({evidence})。

**範圍阻擋，依使用者指示停手回報**：完整 native 的六個 failure 都在 `tests/test_axiom_reader.py`：`test_color_contract_allows_unrelated_properties_and_untracked_selectors`、`test_current_layout_change_does_not_relock_historical_migration_tests`、`test_legacy_image_handler_retires_without_changing_live_svg_handler`、`test_rebuild_is_byte_idempotent_and_keeps_reviews`、`test_retired_color_migrations_allow_format_and_unrelated_layout_changes`、`test_traceability_lights_and_hub_badges_exist`。前五筆呈現重建的 112／113 統計差異，最後一筆要求 `data-clause="I74" data-trace="partial"` 卻未找到；原始 traceback 全保留。這涉及受保護正典／追溯同步，超出本輪僅 B1 授權；請 Claude 指定閱讀器 owner 核對並決定同步方式，未自行重產或修改正典，也未改閱讀器測試。完整 native 未通過，不能上車。

其餘尚未驗／仍阻擋：**B2／S1 等 #193**，本輪沒有提前接入；`parameters.inc`／`parameter_types.h` 與本輪開始的 d42d21fb 完全相同。面材試排三欄共用守門、put-grid-system 逐欄改綁與逐欄重建應得 99 的整合回歸，仍待該前置。CR18 身分帳／M12、CR24 UI／M23、正式 WSL native＋六 browser 及 B2／S1 後最終整合來源的驗證，均未宣稱完成。

仍為既有 open／draft PR；只推自己的原分支，未合併 PR、轉 Ready、關閉、刪分支或改設定。本輪 B1 至此停止。

【Codex】請 Claude 核對
'''
(D/'delivery-comment.md').write_text(comment)
body=f'''【Codex】網格以一份 CardReference 保存卡片身分與 u/v 欄位映射，整組建立、換卡、對調、解除及復原走同候選全量驗證。整卡 direct 解除讀有序步驟當下來源；已重建取新值，仍缺來源則拒絕。

相依 #193，base 維持 `fix/geo-258-parameter-remove-refs-20261011`。能力 `grid-card-reference/1` + `parameters/1`；完整專案 /18、快照根能力、I38／I8a／bridge／來源索引均保留。依 P-133 保存完整 canonical base_scene，不擴張幾何根走訪。

P-146 的錯誤欄位斷言、id 診斷、SAME_CARD／COMPLETE_MAPPING 分離、一般邏輯突變與有序當步取值回歸已交付。P-142 **B1 已完成**：一般合入採納後 main `a898ad6e`，執行器版本指向採納提交 `b3c79615`；所有採納前版本在 manifest 或 base_scene 宣告／使用整卡時，一律以 AXIOM_VERSION 拒絕，含移除宣告後的整卡語法。舊版無整卡包維持相容。

交付 head `{head}`；完整受測產品／測試 head `{source}`。雲端 native，非正式 WSL 收據：99 suites、{passed} pass／6 fail／1 既有 GDI skip、exit 1；相容性 36/36，整卡 34/34，Node 718/718。**六個 failure 全在正典閱讀器（35/41），涉及 I74 追溯狀態與重建統計 112／113 的差異；已依受保護檔案範圍停止，待 Claude／閱讀器 owner 核對，不自行同步或改測試。完整 native 未通過。** 四筆 B1 版本防線突變、48 筆原生整卡突變 + 1 helper 負對照、六筆保存端突變，皆本輪新來源真轉紅／還原綠；官方 50 筆新帳本 42 killed／1 crashed／4 equivalent／3 retired，check 0。Node expected 合併為 718，相容性新增 31→36；沒有降低門檻或新增 skip。[原始證據與精確來源]({evidence})。

記憶體成本（P-146 來源／Linux x86-64 ABI）：capture 40 bytes × 256 + count 8 = 每 World 10,248 bytes；Undo／Redo 各 32 槽共增加 655,872 bytes，其他快照另計。清零不消除固定配置空間。上限依據與版本防線見 [NATIVE-CONTRACT](geometry-core/card-reference/NATIVE-CONTRACT.md)。

**維持 draft：B2／S1 仍等 #193 P-141／P-142 合併**，尚未接入面材試排 gap／stagger／threshold 的共用引用檢查、網格系統「無法改綁」訊息／註解、逐欄改綁對照及重建取 99 的整合回歸。正式 WSL 七項、B2／S1 後最終整合來源的驗證、CR18 啟用身分帳／M12、CR24／M23 UI／草稿與獨立 owner／browser 仍未驗。本輪受保護文件僅隨已授權 main 合併，與 main 逐 byte 相同。

請 Claude 核對。
'''
(D/'pr-body.md').write_text(body)
print(json.dumps({'delivery_head':head,'tested_head':source,'count':count,'passed':passed,'comment_bytes':len(comment.encode())},indent=2))
