from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R=Path('/workspace/geometry-axiom')
D=Path('/tmp/task20-b1')
E=R/'geometry-core/card-reference/evidence/b1-adoption-20261016'
E.mkdir(parents=True,exist_ok=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads((D/path).read_text())
native=read('native/receipt.json')
official=read('official-retry/report.json')
cards=read('card-mutations/report.json')
axioms=read('axiom-mutations/report.json')
archives=read('archive-mutations/report.json')
assert native['exit_code']==1 and official['check']['exit_code']==0
reader=json.loads((D/'native/logs/py_test_axiom_reader.json').read_text())
assert (reader['total'],reader['passed'],reader['failed'],reader['skipped'])==(41,35,6,0)
assert len(cards['mutants'])==49 and all(x['verdict']=='killed' and x['restored']['run']['exit_code']==0 for x in cards['mutants'])
assert len(axioms['mutants'])==4 and all(x['verdict']=='killed' for x in axioms['mutants'])
assert len(archives['mutants'])==6 and all(x['verdict']=='killed' for x in archives['mutants'])
head=native['source_head']
assert head==cards['source_head']==axioms['source_head']==official['source_head']
# Final tracked product and tests must remain identical to the tested commit.
# Documentation, expected census, the refreshed ledger and this evidence are
# the only allowed post-test changes.
names=subprocess.check_output(['git','diff','--name-only',head],cwd=R,text=True).splitlines()
allowed={'geometry-core/card-reference/NATIVE-CONTRACT.md','tests/run_all.expected.json','tests/mutants_results.json'}
assert set(names)<=allowed,names
before=json.loads(subprocess.check_output(['git','show',head+':tests/run_all.expected.json'],cwd=R))
after=json.loads((R/'tests/run_all.expected.json').read_text())
changes={k:{'before':before['suites'].get(k),'after':v} for k,v in after['suites'].items() if before['suites'].get(k)!=v}
assert set(changes)=={'py:test_engineering_model_compatibility'},changes
assert changes['py:test_engineering_model_compatibility']['before']['count']==31
assert changes['py:test_engineering_model_compatibility']['after']['count']==36
members={}
for folder in ('axiom-mutations','card-mutations','archive-mutations','archive-sandbox','official-retry','native'):
    for path in (D/folder).rglob('*'):
        if path.is_file() and 'cache' not in path.relative_to(D).parts:
            data=path.read_bytes()
            if not data.startswith(b'\x7fELF'):
                members[str(path.relative_to(D))]=data
for path in D.glob('*'):
    if path.is_file() and path.suffix in {'.json','.stdout','.stderr','.py','.diff'}:
        members['drivers/'+path.name]=path.read_bytes()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())}
archive=E/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(E/'raw-evidence.sha256').write_text(sha(archive.read_bytes())+'  raw-evidence.zip\n')
summary={
    'tested_head':head,'merged_main':'a898ad6e12707104568679591fe1b21804bfc3df',
    'merge_commit':'23f6e243cb76bddf5545575e44494ae959691bf9',
    'native':native,'official':official,'reader_blocker':reader,
    'card_mutants':{'attempted':49,'killed':49,'native_product_mutants':48,'test_helper_negative_control':1},
    'axiom_mutants':{'attempted':4,'killed':4},'archive_mutants':{'attempted':6,'killed':6},
    'expected_changes':changes,'merge_expected':read('expected-merge.json'),
    'protected_files':read('protected-files.json'),'b2_s1_files_unchanged':read('b2-s1-unchanged.json'),
    'raw_files':len(manifest),'archive_sha256':sha(archive.read_bytes()),
    'excluded_attempts':[
        'before.stdout/stderr: first test-fixture draft had invalid name token; corrected before accepting the 57-assertion red baseline',
        'official.stdout/stderr: launch before isolated checkout completed; import failed before any mutant; retried in official-retry',
        'archive-sandbox: restricted Node --test emitted only the file wrapper event; named failure was unavailable and NOT_KILLED. Rerun with network permission restored all seven test events; runner and assertions unchanged',
    ],
    'remaining':['Protected canonical reader: 6 failures after integration; stop for owner decision, no reader edits','B2/S1 pending #193','CR18 identity ledger/M12','CR24 UI/M23','formal WSL native and six browser jobs'],
}
(E/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(E/'README.md').write_text(f'''# P-142 B1：採納後版本與舊版能力防線

受測完整 head：`{head}`。一般合入 main `a898ad6e12707104568679591fe1b21804bfc3df`，合併提交 `23f6e243cb76bddf5545575e44494ae959691bf9`。
本資料夾後續提交只保存文件、expected、帳本與證據；產品與測試逐 byte 對照受測 head。雲端 native，非正式 WSL 收據。

**完整 native exit 1：99 suites，3031 計數／3024 pass／6 fail／1 既有 GDI skip。六個 failure 全在受保護的正典閱讀器 suite（35/41），涉及 I74 追溯狀態及 112／113 統計的重建差異；此輪停止並回報 owner，沒有修改正典、放寬斷言或再跑以掩蓋失敗。B1 相容性 36/36、整卡 34/34、Node 718/718。**

- B1 測試先行：五個具名方法，三條拒絕路徑 × 19 組舊版本 = 57 個修正前失敗斷言，0 errors／skips；修正後完整相容性 suite 36/36。
- 四個一般邏輯突變：整道防線撤除、漏查 manifest、漏查來源、豁免最後一組採納前版本。逐筆具名轉紅，逐 byte 還原後完整 36 題回綠。
- 整卡 49 筆新來源反證：48 筆原生產品碼與 1 筆測試 helper 負對照；沒有借用舊來源收據。保存／格式另六筆 JavaScript 突變。
- 官方 50 筆帳本完整重產與 check；原始 crashed／equivalent／retired 分開保留，不冒稱 killed。
- 完整 native 的 exit、數量、耗時、執行前後狀態與每個 suite 原始輸出見 `summary.json` 與 ZIP 的 native/。
- expected 合併保留兩方 suite，Node 704 + 7 整卡 + 7 transport = 718；完整跑之後唯一新增數量為相容性 31→36，沒有降低門檻或新增 skip。
- 正典直接採用 main 原件。四份受保護文件與 main 逐 byte 相同；參數守門檔案與本輪開始的 d42d21fb 相同，B2／S1 尚未接入。

`raw-evidence.zip` 內含 {len(manifest)} 份原件與逐檔 SHA-256 的 MANIFEST.json；未收執行檔／編譯快取。首份測試夾具錯誤與官方 runner 過早啟動的失敗原件有保留，均排除於有效反證之外。
正式 WSL 七項、B2／S1 與既有身分帳／UI 邊界仍未驗，不宣稱任務 20 最終整合驗收完成。
''')
print(json.dumps({'files':len(manifest),'zip_bytes':archive.stat().st_size,'tested_head':head,'expected_changes':changes},ensure_ascii=False,indent=2))
