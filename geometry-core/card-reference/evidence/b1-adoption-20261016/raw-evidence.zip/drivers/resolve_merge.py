from pathlib import Path
import json
import subprocess

R=Path('/workspace/geometry-axiom')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=R)
p=R/'current_geometry.c'
raw=p.read_bytes()
a=raw.index(b'<<<<<<< HEAD\r\n')
b=raw.index(b'>>>>>>> origin/main\r\n',a)+len(b'>>>>>>> origin/main\r\n')
raw=raw[:a]+raw[b:]
marker=b'    if(grid_subdivision_used(world)) fputs("requires " GRID_SUBDIVISION_CAPABILITY "\\n",out);\r\n'
assert raw.count(marker)==1
raw=raw.replace(marker,b'    if(grid_card_used(world)) fputs("requires " GRID_CARD_CAPABILITY "\\n",out);\r\n'+marker)
assert raw.count(b'\n')==raw.count(b'\r\n')
p.write_bytes(raw)
p=R/'geometry-guide/公理層-閱讀器.html'
p.write_bytes(git('show','origin/main:geometry-guide/公理層-閱讀器.html'))
p=R/'tests/run_all.expected.json'
ours=json.loads(git('show',':2:tests/run_all.expected.json'))
theirs=json.loads(git('show',':3:tests/run_all.expected.json'))
merged=json.loads(json.dumps(ours))
for key,value in theirs['suites'].items():
    own=merged['suites'].get(key)
    if own is None or value.get('count',0)>own.get('count',0):
        merged['suites'][key]=value
# Both sides independently add seven Node tests to the shared 704 baseline:
# card-reference persistence and transport-failure tracing, respectively.
assert ours['suites']['node:tests-js']['count']==theirs['suites']['node:tests-js']['count']==711
merged['suites']['node:tests-js']['count']=718
p.write_text(json.dumps(merged,ensure_ascii=False,indent=2)+'\n')
(Path(__file__).parent/'expected-merge.json').write_text(json.dumps({
    k:{'ours':ours['suites'].get(k),'main':theirs['suites'].get(k),'merged':v}
    for k,v in merged['suites'].items()
    if v!=ours['suites'].get(k) or v!=theirs['suites'].get(k)
},ensure_ascii=False,indent=2)+'\n')
# Provisional old ledger is explicitly stale; regenerate after source settles.
(R/'tests/mutants_results.json').write_bytes(git('show',':2:tests/mutants_results.json'))
